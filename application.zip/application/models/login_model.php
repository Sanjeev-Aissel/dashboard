<?php

/**
 * 
 * 
 * @package application.models
 * @author Vinod S T
 * @since
 * @created on 
 */
class Login_model extends Model {

    /**
     * constructor
     * @return unknown_type
     */
    function Login_model() {
        parent::Model();
        $this->load->model('common_helpers');
    }

    function login_validate() {
        $this->db->where('id', $this->input->post('email'));
        $this->db->where('passwd', md5($this->input->post('passwd')));
        $query = $this->db->get('user_list');
        return $query;
    }

    function change_password() {
        $conf_password = $this->input->post('conf_password');
        $userid = $this->session->userdata('userid');
        $qry = "update user_list set passwd=md5(\"" . $conf_password . "\") where id=\"" . $userid . "\"";
        mysql_query($qry) or die(mysql_error());
    }

    /**
     * Save the user analytics like user id, login and logout time etc.
     * @author 	Ramesh B
     * @since	3.0
     * @return unknown_type
     * @created 16-08-11
     */
    function saveUserAnalytics($arrUserAnalytics) {
        if ($this->db->insert('users_analytics', $arrUserAnalytics)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * Updates the user analytics record with logout time.
     * @author 	Ramesh B
     * @since	3.0
     * @return unknown_type
     * @created 16-08-11
     */
    function updateUserAnalytics($arrUserAnalytics) {
        $this->db->where('id', $arrUserAnalytics['id']);
        if ($this->db->update('users_analytics', $arrUserAnalytics)) {
            return true;
        } else {
            return false;
        }
    }

    function getAllUserAnalytics($startFrom, $limit) {
        $arrUserAnalytics = array();
        $this->db->select('users_analytics.*,client_users.user_name,clients.name');
        $this->db->join('client_users', 'users_analytics.user_id = client_users.id', 'left');
        $this->db->join('clients', 'client_users.client_id = clients.id', 'left');
        //$this->db->where('client_users.client_id !=',1);
        $this->db->order_by('login_time', 'desc');
        if (isset($startFrom) && $limit != 0)
            $this->db->limit($limit, $startFrom);
        $results = $this->db->get('users_analytics');
        foreach ($results->result_array() as $row) {
            $arrUserAnalytics[] = $row;
        }
        return $arrUserAnalytics;
    }

    function getAllUserAnalyticsDetails($startFrom, $limit) {
        $arrUserAnalytics = array();
        $this->db->select('users_analytics.*,client_users.user_name,clients.name');
        $this->db->join('client_users', 'users_analytics.user_id = client_users.id', 'left');
        $this->db->join('clients', 'client_users.client_id = clients.id', 'left');
        //$this->db->where('client_users.client_id !=',1);
        $this->db->order_by('login_time', 'desc');
        if (isset($startFrom) && $limit != 0)
            $this->db->limit($limit, $startFrom);
        $arrUserAnalytics['count'] = $this->db->count_all_results('users_analytics');
        $results = $this->db->get('users_analytics');
        foreach ($results->result_array() as $row) {
            $arrUserAnalytics[] = $row;
        }
        return $arrUserAnalytics;
    }

    function getAllUserAnalyticsDetailsData($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = '',$arrFilter) {
        $managerId=$this->input->post('manager_id');
        
        $users=$this->common_helpers->getManagerAlignedUsers($managerId);
        $originalDate = $where['start_date'];
        if ($where['start_date'] != '') {
            $where['start_date'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $where['end_date'];
        if ($where['end_date'] != '') {
            $where['end_date'] = date("Y-m-d", strtotime($originalDate1));
        }
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $arrParam = ($_POST);
        if (!$doCount) {
            $this->db->select('log_activities.*,client_users.user_name,clients.name,groups.group_name,client_users.title');
        }

        $this->db->join('client_users', 'log_activities.created_by = client_users.id', 'left');
        $this->db->join('clients', 'client_users.client_id = clients.id', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $this->db->where('(groups.group_type = "Team")');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        //Add the where conditions for any jqgrid filters
        if (isset($where['name'])) {
            $this->db->like('clients.name', $where['name']);
        }
        if (isset($where['user_name'])) {
            $this->db->like('client_users.user_name', $where['user_name']);
        }
        if (isset($where['login_time'])) {
            $this->db->like('log_activities.created_on', $where['login_time']);
        }
        if (isset($where['logout_time'])) {
            $this->db->like('log_activities.created_on', $where['logout_time']);
        }
        if (isset($where['group_name'])) {
            $this->db->like('groups.group_name', $where['group_name']);
        }
        if (isset($where['title'])) {
            $this->db->like('client_users.title', $where['title']);
        }
          if (isset($where['os'])) {
            $this->db->like('log_activities.os', $where['os']);
        }
          if (isset($where['browser'])) {
            $this->db->like('log_activities.browser', $where['browser']);
        }
        if (isset($where['browser'])) {
            $this->db->like('log_activities.browser', $where['browser']);
        }
        if($managerId!=''){
            $this->db->where_in('log_activities.created_by ' , $users);
        }
        
        
        $this->db->where('log_activities.transaction_name ', "login");
        $this->db->where('log_activities.status ', "success");
        $dateString = "";
        if ($where['start_date'] != '' && $where['end_date'] != '')
            $dateString = ' BETWEEN "' . $where['start_date'] . '" AND "' . $where['end_date'] . '"';
        else if ($where['start_date'] != '')
            $dateString = ' >= "' . $where['start_date'] . '"';
        else if ($where['end_date'] != '')
            $dateString = ' <= "' . $where['end_date'] . '"';

        if ($dateString != '') {
            $this->db->where('DATE(log_activities.created_on) ' . $dateString);
        }
        if (isset($arrParam['msl'])) {
            $this->db->where_in("client_users.id", $arrParam['msl']);
        }
        if (isset($arrParam['team'])) {
            $this->db->where_in('user_groups.group_id ', $arrParam['team']);
        }
        if ($userRole == ROLE_USER) {
            $this->db->where('client_users.id', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('client_users.id', $userIds);
        }
        if ($doCount) {
            $this->db->select('count(distinct client_users.user_name,DATE(log_activities.created_on),HOUR(log_activities.created_on),MINUTE(log_activities.created_on),MINUTE(log_activities.created_on)) as numrows', false);
            $count = $this->db->get('log_activities');
            $count = $count->row_array();
            return $count['numrows'];
        } else {
            if ($sidx != '' && $sord != '') {
                switch ($sidx) {
                    case 'name' : $this->db->order_by("clients.name", $sord);
                        break;
                    case 'user_name' :$this->db->order_by("client_users.user_name", $sord);
                        break;
                    case 'login_time' :$this->db->order_by("users_analytics.login_time", $sord);
                        break;
                    case 'logout_time' :$this->db->order_by("users_analytics.logout_time", $sord);
                        break;
                    case 'group_name' :$this->db->order_by("groups.group_name", $sord);
                        break;
                    case 'title' :$this->db->order_by("client_users.title", $sord);
                        break;
                    case 'os' :$this->db->order_by("log_activities.os", $sord);
                        break;
                    case 'browser' :$this->db->order_by("log_activities.browser", $sord);
                        break;
                }
                //$this->db->order_by($sidx,$sord);
            }
            $this->db->order_by('log_activities.created_on', 'desc');
            //$this->db->group_by("users_analytics.user_id,users_analytics.login_time");
           // $this->db->group_by("log_activities.id");
            $this->db->group_by("client_users.user_name,DATE(log_activities.created_on),HOUR(log_activities.created_on),MINUTE(log_activities.created_on),MINUTE(log_activities.created_on)");
            if ($limit != 0) {
                $this->db->limit($limit, $startFrom);
            }
            $arrKolDetail = $this->db->get('log_activities');
                      
//			pr($this->db->last_query()); exit;
            return $arrKolDetail;
        }
    }

    function getUserAnalyticDetails($arrIds) {
        $arrUserAnalytics = array();
        //$this->db->select('users_analytics.*,client_users.user_name,clients.name,is_login_failed');
        $this->db->select('users_analytics.*,client_users.user_name,clients.name,groups.group_name,client_users.title,is_login_failed');
        $this->db->join('client_users', 'users_analytics.user_id = client_users.id', 'left');
        $this->db->join('clients', 'client_users.client_id = clients.id', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $this->db->where_in('users_analytics.id', $arrIds);
        $this->db->order_by('login_time', 'desc');
        $results = $this->db->get('users_analytics');
        if (is_object($results) && $results->num_rows() > 0)
            $arrUserAnalytics = $results->result_array();
        return $arrUserAnalytics;
    }

    /**
     * Returns the id of the given username, if username doesn't exist returns 0
     * @author 	Ramesh B
     * @since Apr 20, 2012
     * @version 3.8
     * @params $userName
     * @return unknown_type
     */
    function getUserIdByUserName($userName) {
        $this->db->select("id");
        $this->db->where("user_name", $userName);
        $results = $this->db->get("client_users");
        if ($results->num_rows() > 0) {
            $row = $results->row_array();
            return $row['id'];
        } else {
            return 0;
        }
    }

    function getUserId($emailId) {
        $userId = array();
        $this->db->select('id,first_name,last_name');
        $this->db->where('email', $emailId);
        $arrResultSet = $this->db->get('client_users');        
        if ($arrResultSet->num_rows() == 0) {
            return false;
        } else {
//             foreach ($arrResultSet->result_array() as $row) {
//                 $userId = $row;
//             }
            //pr($userId);
            
            return $arrResultSet->row_array();
        }
    }

    function updateNewPasswordKey($newPasskey, $userId) {
        $this->db->set('new_password_key', $newPasskey);
        $this->db->set('new_password_creation', date('Y-m-d H:i:s'));
        $this->db->where('id', $userId);

        $this->db->update('client_users');
        //echo $this->db->last_query();
    }

    function resetPassword($arrDeatails, $userId) {
        $arrDeatails['new_password_key'] = NULL;
        $arrDeatails['new_password_creation'] = NULL;
        $this->db->where('id', $userId);
        $this->db->update('client_users', $arrDeatails);
    }

    function checkExpirekey($arrDetails) {
        $this->db->where('id', $arrDetails['userId']);
        $this->db->where('new_password_key', $arrDetails['newPassKey']);
        $arrRsult = $this->db->get('client_users');

        if ($arrRsult->num_rows() == 0) {
            return false;
        } else {
            foreach ($arrRsult->result_array() as $row) {
                $arrDetails1[] = $row;
            }

            $todaysDate = date('Y-m-d H:i:s');
            $creationDate = $arrDetails1[0]['new_password_creation'];

            $todaysDate = strtotime($todaysDate);
            $creationDate = strtotime($creationDate);
            $minus = $todaysDate - $creationDate;
            if ($minus > 86400) {
                return false;
            } else {
                return true;
            }
        }
    }

    /*
     * Get Client Users Detail
     * @author Vinayak Mallaldad
     * @since 1.5.1
     * @created on 13/3/2011
     * $return array
     */

    function getUserdetail($id) {
        $arrUser = array();
        $this->db->where('id', $id);
        $arrUserResult = $this->db->get('client_users');
        foreach ($arrUserResult->result_array() as $row) {
            $arrUser = $row;
        }
        return $arrUser;
    }

    function getTopMslForUserDetails() {
        $arrMsl = array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('count(users_analytics.username) as entry_count ,client_users.*');
        $this->db->join('client_users', 'users_analytics.user_id = client_users.id', 'left');
        $this->db->where('users_analytics.user_id IS NOT NULL');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        if ($userRole == ROLE_USER) {
            $this->db->where('client_users.id', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('client_users.id', $userIds);
        }
        $this->db->group_by('users_analytics.user_id');
        $this->db->order_by('entry_count', 'desc');
        $arrCoachingResultSet = $this->db->get('users_analytics');

        foreach ($arrCoachingResultSet->result_array() as $row) {

            $row['entry_count'] = $row['entry_count'];
            $arrMsl[] = $row;
        }
//              echo $this->db->last_query();
        return $arrMsl;
    }

}
