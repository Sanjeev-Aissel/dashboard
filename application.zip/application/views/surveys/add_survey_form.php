<?php
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 23-03-2013
 *  
 */
// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	'jquery/jquery.validate1.9.min',
								'chosen.jquery',
								'jquery/date',
								'jquery/jquery-ui-1.8.16.datepicket',
								'jquery/daterangepicker.jQuery'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url();?>css/ui.daterangepicker.css" type="text/css" />
<style type="text/css">
#contentWrapper.span-23 {
	background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
    background-position: 135px 50%;
    background-repeat: repeat-y;
}
.multiselect {
    height:35em;
  /*  border:solid 1px #c0c0c0;*/
    overflow:auto;
}
.multiselect label.group{
	background-color:#f5f5f5;
	background-color:#1D92EE;
	background-color:#f6f6ff;
	border:1px solid #eef;
	font-size:12px;
	padding: 5px;
	color: #333 !important;
}
.multiselect label.group a{
	float: right;
	text-decoration: none;
}
.multiselect label.group:hover{
 	background-color:#f6f6ff !important;
 	border:1px solid #eef;
}
.multiselect label {
    display:block;
	background-color:#fff;
	border:1px solid #fff;
	font-size:11px !important;
	border-bottom-color: #f5f5f5;
	color: #888 !important;
	margin-bottom: 5px;
}
.multiselect label:hover{
	background-color:#f5f5f5;
	border:1px solid #88f;
}
fieldset legend{
	font-size: 12px;
	padding: 2px;
}
fieldset{
	padding-top: 0px;
	margin: 0px;
}
span.required{
	color: #f00;
}
#surveyName{
	width:355px;
	margin-right: 15px;
}
textarea{
	width:100%;
	padding:0px;
}
.ui-daterangepicker li{
    text-align: left;
    }
.ui-daterangepicker ul{
	width: 175px !important;
}
.ui-daterangepicker button.btnDone{
	font-size: 12px !important;
	color:#FFF !important;
	padding-bottom: 22px;
	background: -moz-linear-gradient(center top , #5689DB 0%, #4D7BD6 100%) repeat scroll 0 0 transparent !important;
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#5689DB),color-stop(100%,#4D7BD6)) !important;
	background: -webkit-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
	background: -o-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
	background: -ms-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#5689db,endColorstr=#4d7bd6,GradientType=0) !important;
	background: linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
}
span.dateMandatory{
	display: none;
}
#startDate, #endDate{
	width: 65px;
}
#assignQuestions label {
    display: inline-block;
    font-weight: bold;
    height: 22px;
    vertical-align: super;
}
#selectedQuestions table td{
	vertical-align: top;
	border-bottom: 1px solid #f5f5f5;
}
#selectedQuestions table tr:hover{
	background-color: #f5f5f5;
}
#selectedQuestions table td label{
	font-weight: normal;
}
#selectedQuestions label input[type="checkbox"]{
	display: none;
}
#selectedQuestions table tr td:nth-child(2){
	width: 90%;
	text-align: justify;
}
#selectedQuestions table tr td:nth-child(3){
	width:45px;
	padding: 0px;
	vertical-align: top;
}
#selectedQuestions table tr td .action{
	display: none;
}
#selectedQuestions table tr:hover td .action{
	display: block;
}
.existingQuestion{
	display: none;
}
.profileContent .assignMsg{
	color: #0a0;
	border: 1px solid #0a0;
	display: none;
	padding: 5px;
}
#msg{
	height: 18px;
}
.highlightOption{
	color:#0000dd;
}
.chzn-container .chzn-results .highlighted.highlightOption{
	color:#00ff00;
}
.microView .contentHeader span{
	padding: 2px 10px;
}
#newOptionValue{
	width: 100%;
}
#surveyContainer {
    position: relative;
}
#tooltip-survey-name, /*{
	position: absolute;
    right: 300px;
    top: 53px;
}*/
#tooltip-survey-status, /*{
	left: 232px;
    position: absolute;
    top: 143px;
}*/
#tooltip-survey-questions{
/*	left: 145px;
    position: absolute;
    top: 178px;*/
    display: inline-block;
}
#visibilityContainer{
	height: 150px;
	overflow: auto;
}
#visibilityContainer p{
	float: left;
    margin-bottom: 2px;
    padding: 2px;
    width: 180px;
}
#visibilityContainer p:hover{
	background-color: #eee;
}
#visibilityContainer p label{
	font-weight: normal;
}
p.dividingHeader{
	background-color: #eee;
	font-weight: bold;
	clear:both;
	width: 99% !important;
}
#OptionsContainer{
	display: none;
}
</style>
<script type="text/javascript">
	var isSubmitted	= false;
	var newSurveyId	= <?php echo (isset($surveyData['id']))?$surveyData['id']:0; ?>;
	var surveyValidationStatus	= '<?php echo (isset($surveyData['id']))?true:false; ?>';
	var isSavingSurvey	= false;
	var selectedGroupIds	= new Array();
	<?php
		if(sizeof($arrSelectedGroups)>1){?>
			selectedGroupIds	= new Array(<?php echo implode(',',$arrSelectedGroups);?>);
		<?php }else{?>
			selectedGroupIds.push('<?php echo $arrSelectedGroups[0];?>');
		<?php }
	?>
	function toggleSelection(){
		var checkBoxes	= $('.multiselect label input:checkbox');
		checkBoxes.prop("checked", !checkBoxes.prop("checked"));
	}
	function toggleGroup(thisObj){
		var group	= $(thisObj).parent().attr('id');
		var checkBoxes	= $('.multiselect label.'+group+' input:checkbox');
		checkBoxes.prop("checked", !checkBoxes.prop("checked"));
	}
	function addNewQuestion(){
		//$.ajax({
		//	url: '<?php echo base_url();?>surveys/add_question_form',
		//	success: function(returnData){
		//		$('#surveyData').hide();
		//		$('#surveyQuestionData').html(returnData).show();
		//	}
		//});
		$("#addSurveyContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addSurveyContainer").dialog("open");
		$("#addSurveyProfileContent").load(base_url+'surveys/add_question_form');
	}
	function addPreviousQuestions(){
		$('.profileContent .assignMsg').html('');
		$('.profileContent .assignMsg').hide();
		var questions	= '';
	//	questions		+= '<div>Search question: <input type="text" name="search" class="search" /><input type="button" value="Select/Deselect All" onclick="toggleSelection();" /><input type="button" value="Assign selected Question(s)" onclick="assignSelectedQuestion();" /></div>';
		questions		+= $('#previousSurveyQuestions').html();
		$("#addSurveyQuestionContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addSurveyQuestionContainer").dialog("open");
		$("#addSurveyQuestionProfileContent").html(questions);
	}
	function editNewQuestion(questionId){
		$('.existingQuestion:eq(0)').val('Update');
		$('.existingQuestion:eq(0)').attr('onclick','updateQuestion();');
		editQuestion(questionId);
	}
	function editExistingQuestion(questionId){
		$('.existingQuestion:eq(0)').val('Save as New Question');
		$('.existingQuestion:eq(0)').attr('onclick','updateQuestion(0);');
		editQuestion(questionId);
	}
	function editQuestion(questionId){
		isQuestionExists	= $('#selectedQuestions input[value="'+questionId+'"]');
		if(isQuestionExists.length>0){
			$('html, body').animate({scrollTop: ($("body").offset().top)}, 1000);
			$("#assignQuestions").parent().css('border-color','#00f');
			$('#question').val($(isQuestionExists).parent().text());
			$('#questionId').val(questionId);
			$('#qta').val(($(isQuestionExists).parent().attr('class')).replace('group','')).trigger('liszt:updated');
			$('#qtype').val($('.type'+questionId).val()).trigger('liszt:updated');
			$('#qrole').val($('.role'+questionId).val()).trigger('liszt:updated');
			$('.newQuestion').hide();
			$('.existingQuestion').show();
		}
	}
	function updateQuestion(isNew){
		isQuestionExists	= $('#selectedQuestions input[value="'+$('#questionId').val()+'"]');
		if(isQuestionExists.length>0){
			$(isQuestionExists).parent().parent().parent().remove();
		}
		if(isNew===0){
			$('#questionId').val('0');
		}
		saveNewQuestion();
		$("#assignQuestions").parent().css('border-color','#ccc');
		$('.newQuestion').toggle();
		$('.existingQuestion').toggle();
	}
	function cancelUpdating(){
		$("#assignQuestions").parent().css('border-color','#ccc');
		$('#qta').val('').trigger('liszt:updated');
		$('#qrole').val('').trigger('liszt:updated');
		$('#qtype').val('').trigger('liszt:updated');
		$('#question').val('');
		$('#questionId').val('0');
		$('.newQuestion').toggle();
		$('.existingQuestion').toggle();
	}
	function removeQuestion(questionId){
		jConfirm("Are you sure you want to delete this question?","Please confirm",function(r){
				if(r){
					isQuestionExists	= $('#selectedQuestions input[value="'+questionId+'"]');
					if(isQuestionExists.length>0){
						$(isQuestionExists).parent().parent().parent().remove();
						$('.multiselect label input[value="'+questionId+'"]:checkbox:checked').attr("disabled", false);
						$('.multiselect label input[value="'+questionId+'"]:checkbox:checked').removeAttr('checked');
						saveSurvey();
					}
					}else{
							return false;
						}
			});
	}
	function assignSelectedQuestion(){
		var isQuestionExists	= 0;
		var value	= 0;
		var count	= 0;
		count		= $('#selectedQuestions input:checkbox').length;
		$('.multiselect label input:checkbox:checked').attr("disabled", true);
		$('.multiselect label input:checkbox:checked').each(function (index){
			value	= 0;
			value	= $(this).val();
			isQuestionExists.length	= 0;
			isQuestionExists	= $('#selectedQuestions input:checkbox[value="'+value+'"]');
			if(isQuestionExists.length<1){
				count++;
				$(this).attr('checked','checked');
				var appendData	= '<tr><td>'+count+')</td><td><label class="'+$(this).parent().attr('class')+'">'+$(this).parent().html()+'</label></td>';
				appendData	+= "<td><div class='action'><div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editExistingQuestion('"+value+"');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"removeQuestion('"+value+"');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Remove\"></a></div></div></div></td></tr>";
				$('#selectedQuestions table').append(appendData);
				$('#previousSurveyQuestions').find('input[value="'+value+'"]').attr('checked','checked');
				$('#previousSurveyQuestions').find('input[value="'+value+'"]').attr("disabled", true);
				$('#selectedQuestions table').find('input[value="'+value+'"]').attr("disabled", false);
			}
		});
		$('.profileContent .assignMsg').show();
		$('.profileContent .assignMsg').html('Selected question(s) are assigned to survey.');
		saveSurvey();
	}
	function saveNewQuestion(){
		moveFromCurrentStep(13);
		$('#msg').html('');
		var question	= $.trim($('#question').val());
		var questionId	= $.trim($('#questionId').val());
		var qtype		= $.trim($('#qtype').val());
		var qta			= $.trim($('#qta').val());
		var qrole		= $.trim($('#qrole').val());
		if(questionId==0){
			questionId	= '';
		}
		//if(question!='' && qtype!='' && qta!='' && qrole!=''){
		if(question!='' && qtype!='' && qta!=''){
			if(question.length>256){
				jAlert('Maximum of 256 characters are allowed');
			}else{
				var alphaNumeric	= /^([a-zA-z]{1}[a-zA-Z0-9 ]+)$/g;
			//	if(!alphaNumeric.test(question)){
			//		jAlert('Question should be alpha numeric');
			//	}else{
					$.ajax({
						type: "post",
						dataType:"json",
						data:{
					        'category_id':qta,
					        'role_id':qrole,
					        'type_id':qtype,
					        'question':question,
					        'questionId':questionId,
					        'is_enabled':'1'
					    },
						url: '<?php echo base_url();?>surveys/save_question/'+questionId,
						success: function(returnData){
							if(returnData.status=="failed"){
								$('#msg').css('color','#55CC99').html('Unable to save');
							}else{
								var isQuestionExists	= $('#selectedQuestions input[value="'+returnData.id+'"]');
								if(isQuestionExists.length<1){
									if(returnData.status=="exist"){
										$('#msg').css('color','#FF9999').html('Question is assigned to survey');
									}else{
										$('#msg').css('color','#FF9999').html('Successfully saved and assigned to survey');
									}
									var count	= 0;
									count		= $('#selectedQuestions input:checkbox').length;
									count++;
									var appendData	= '<tr><td>'+count+')</td>';
									appendData	+= '<td><label class="group'+returnData.category_id+'"><input type="hidden" class="type'+returnData.id+'" name="type'+returnData.id+'" value="'+qtype+'" /><input type="hidden" class="role'+returnData.id+'" name="role'+returnData.id+'" value="'+qrole+'" /><input type="checkbox" name="question_ids[]" checked="checked" value="'+returnData.id+'" />'+returnData.question+'</label></td>';
									appendData	+= "<td><div class='action'><div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editNewQuestion('"+returnData.id+"');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"removeQuestion('"+returnData.id+"');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Remove\"></a></div></div></div></td></tr>";
									$('#selectedQuestions table').append(appendData);
								}else{
									$('#msg').css('color','#FF9999').html('Question is already assigned to survey');
								}
								$('#qta').val('').trigger('liszt:updated');
								$('#qrole').val('').trigger('liszt:updated');
								$('#qtype').val('').trigger('liszt:updated');
								$('#question').val('');
								$('#questionId').val('0');
								saveSurvey();
							}
						}
					});
			//	}
			}
		}else{
			jAlert('All fields are mandatory to add new Question');
		}
	}
	function saveSurvey(){
		if(!isSavingSurvey){
			isSavingSurvey	= true;
			var surveyName	= $.trim($('#surveyName').val());
			if(surveyName!=''){
				$('#msg').html('Saving..');
				var formData	= $("#surveyform").serialize();
				$.ajax({
					type: "post",
					dataType:"json",
					data:formData,
					url: '<?php echo base_url();?>surveys/autosave_survey/'+newSurveyId,
					success: function(returnData){
						$('#msg').html('Saved.');
						newSurveyId	= returnData.id;
						if(newSurveyId>0){
							$("#surveyform").attr('action','<?php echo base_url();?>surveys/save_survey/'+newSurveyId);
							//$("#surveyform").submit();
						}
					},
					complete:function(){
						isSavingSurvey	= false;
					}
				});
			}
		}
	}
	function validateSurveyName(){
			var surveyName	= $.trim($('#surveyName').val());
			var startDate	= $('#startDate').val();
			var endDate		= $('#endDate').val();
			var isActive	= $('.isActive:checked').val();
			if(surveyName==''){
				surveyValidationStatus	= false;
				jAlert('Please fill in all the mandatory fields marked with *');
			}else{
				$.ajax({
					type: "post",
					dataType:"json",
					data:{
				        'survey_name':surveyName,
				        'start_date':startDate,
				        'end_date':endDate
				    },
					url: '<?php echo base_url();?>surveys/validate_survey/'+newSurveyId,
					success: function(returnData){
						if(returnData.status=="new" || isActive==0){
							surveyValidationStatus	= true;
							if(isSubmitted){
								$('#surveyform').submit();
							}else{
								saveSurvey();
							}
						}else{
							jAlert('Survey name already exists with the current date. please change the value of at least one among mandatory fields');
							surveyValidationStatus	= false;
						}
					}
				});
			}
	}
	$('input.search').live('keyup',function (){
		var searchValue	= $(this).val();
		$(".multiselect label").show();
		$(".multiselect label").not($(".multiselect label:contains("+searchValue+")")).hide();
		$(".multiselect label.group").show();
	});
	function addNewOptions(valueId){
		var labelName	= '';
		$("#addNewContainer").dialog("open");
		$("#addNewContainer").html($('#OptionsContainer').html());
		switch(valueId){
			case '1' : labelName = 'Type';break;
			case '2' : labelName = 'Therapeutic Area';$('#qta').val('Select Therapeutic Area');$('#qta').trigger('liszt:updated');break;
			case '3' : labelName = 'Role';$('#qrole').val('Select Role');$('#qrole').trigger('liszt:updated');break;
		}
		$("#addNewProfileContent #newOptionValueId").val(valueId);
		$("#addNewProfileContent label").html(labelName+': ');
	}
	function cancelNewOptionValue(){
		$("#addNewProfileContent #newOptionValueId").val('0');
		$("#addNewProfileContent #newOptionValue").val('');
		$("#addNewContainer").dialog("close");
		var optionValueId	= $("#addNewProfileContent #newOptionValueId").val();
		switch(optionValueId){
			case '1' : labelName = 'Type';break;
			case '2' : $('#qta').val('Select Therapeutic Area');$('#qta').trigger('liszt:updated');break;
			case '3' : $('#qrole').val('Select Role');$('#qrole').trigger('liszt:updated');break;
		}
	}
	function saveNewOptionValue(){
		var optionValueId	= $(".microProfileDialogBox #newOptionValueId").val();
		var optionValue		= $.trim($(".microProfileDialogBox #newOptionValue").val());
		switch(optionValueId){
			case '1' : var newTypename	= optionValue;
				break;
			case '2' : var newCategoryname	= optionValue;
						if(newCategoryname!=null && newCategoryname!='' && newCategoryname.length>32){
							jAlert('Maximum of 32 characters are allowed');
							$('#qta').val('Select Therapeutic Area');
							$('#qta').trigger('liszt:updated');
						}else{
							var alphaNumeric	= /^([a-zA-z]{1}[a-zA-Z0-9 ]+)$/g;
							if(!alphaNumeric.test(newCategoryname)){
								jAlert('Therapeutic Area should be alpha numeric');
								$('#qta').val('Select Therapeutic Area');
								$('#qta').trigger('liszt:updated');
							}else{
								if(newCategoryname!=null && newCategoryname!=''){
									$.ajax({
										type: "post",
										dataType:"json",
										data:{
									        'category_name':newCategoryname
									    },
										url: '<?php echo base_url();?>surveys/save_category',
										success: function(returnData){
											if(returnData.status=="saved"){
												$('#qta').append('<option value="'+returnData.id+'" selected="selected">'+newCategoryname+'</option>');
											}else if(returnData.status=="exist"){
												$('#qta').val(returnData.id);
											}else{
												$('#qta').val('Select Therapeutic Area');
											}
											$('#qta').trigger('liszt:updated');
										}
									});
								}else{
									$('#qta').val('Select Therapeutic Area');
									$('#qta').trigger('liszt:updated');
								}
							}
						}
				break;
			case '3' : var newRolename	= optionValue;
						if(newRolename!=null && newRolename!='' && newRolename.length>32){
							jAlert('Maximum of 32 characters are allowed');
							$('#qrole').val('Select Role');
							$('#qrole').trigger('liszt:updated');
						}else{
							var alphaNumeric	= /^([a-zA-z]{1}[a-zA-Z0-9 ]+)$/g;
							if(!alphaNumeric.test(newRolename)){
								jAlert('Role should be alpha numeric');
								$('#qrole').val('Select Role');
								$('#qrole').trigger('liszt:updated');
							}else{
								if(newRolename!=null && newRolename!=''){
									$.ajax({
										type: "post",
										dataType:"json",
										data:{
									        'role_name':newRolename
									    },
										url: '<?php echo base_url();?>surveys/save_role',
										success: function(returnData){
											if(returnData.status=="saved"){
												$('#qrole').append('<option value="'+returnData.id+'" selected="selected">'+newRolename+'</option>');
												$('#qrole').val(returnData.id);
											}else if(returnData.status=="exist"){
												$('#qrole').val(returnData.id);
											}else{
												$('#qrole').val('Select Role');
											}
											$('#qrole').trigger('liszt:updated');
										}
									});
								}else{
									$('#qrole').val('Select Role');
									$('#qrole').trigger('liszt:updated');
								}
							}
						}
				break;
		}
		cancelNewOptionValue();
	}
	$(document).ready(function (){
		var surveyName	= $.trim($('#surveyName').val());
		if(surveyName==''){
			surveyValidationStatus	= false;
		}else{
			validateSurveyName();
		}
		if(selectedGroupIds!=''){
			for(groupId in selectedGroupIds){
				var thisObj	= $('input[name="users[]"].'+selectedGroupIds[groupId]);
				$(thisObj).attr("checked","checked");
				$(thisObj).attr("disabled","disabled");
			}
		}
		$('.chosenSelect').chosen({allow_single_deselect: false});
		$("#qtype").chosen().change(function(){
			moveFromCurrentStep(10);
		});
		$("#qta").chosen().change(function(){
			moveFromCurrentStep(11);
			if($(this).val()==0){
				addNewOptions('2');
			}
		});
		$("#qrole").chosen().change(function() {
			moveFromCurrentStep(12);
			if($(this).val()==0){
				addNewOptions('3');
			}
		});
		//$('#startDate, #endDate').daterangepicker();
		$('#startDate').datepicker({
			changeMonth: true,
	    	changeYear: true,
			dateFormat: 'mm/dd/yy'
		});
		$('#endDate').datepicker({
			changeMonth: true,
	    	changeYear: true,
			dateFormat: 'mm/dd/yy'
		});
		// Settings for the Dialog Box
		var surveyAddEditDialogOpts = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView addSurveyModalContainer",
				position: ['center', modalBoxTopPosition]
		};
		var addNewOptionsValue = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 400,
				dialogClass: "microView",
				position: ['center']
		};
		$("#addSurveyContainer").dialog(surveyAddEditDialogOpts);
		$("#addSurveyQuestionContainer").dialog(surveyAddEditDialogOpts);
		$("#addNewContainer").dialog(addNewOptionsValue);
		$('.isActive').click(function (){
			var isActive	= $('.isActive:checked').val();
			if(isActive==1){
				$('span.dateMandatory').show();
			}else{
				$('span.dateMandatory').hide();
			}
		});
		$('#surveyName').live('blur',function (){
			//validateSurveyName();
			saveSurvey();
		});
		$('#surveyName').keypress(function (){
			moveFromCurrentStep(5);
		});
		$('#startDate').live('blur',function (){
			//validateSurveyName();
			saveSurvey();
		});
		$('#startDate').focus(function (){
			moveFromCurrentStep(6);
		});
		$('#endDate').live('blur',function (){
			//validateSurveyName();
			saveSurvey();
		});
		$('#description').live('blur',function (){
			saveSurvey();
		});
		$('#description').keypress(function (){
			moveFromCurrentStep(7);
		});
		$('.isActive').change(function (){
			moveFromCurrentStep(8);
		});
		$('#question').keypress(function (){
			moveFromCurrentStep(9);
		});
		$('#surveyform').submit(function (event){
			isSubmitted	= true;
			if(surveyValidationStatus){
				var isMandatoryFieldEmpty	= false;
				var surveyName	= $.trim($('#surveyName').val());
				var startDate	= $('#startDate').val();
				var endDate		= $('#endDate').val();
				var isActive	= $('.isActive:checked').val();
				var tempStartDate = new Date(startDate.replace(/-/g, '/')).getTime();
				var tempEndDate =  new Date(endDate.replace(/-/g, '/')).getTime();
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				today	= mm+'/'+dd+'/'+yyyy;
				var temptoday =  new Date(today.replace(/-/g, '/')).getTime();
				if(surveyName=='')
					isMandatoryFieldEmpty = true;
				if(isActive==1){
					if(startDate==''){
						isMandatoryFieldEmpty = true;
					}else if(endDate==''){
						isMandatoryFieldEmpty = true;
					}
				}
				if(tempStartDate > tempEndDate){
					jAlert('End date should be greater than start date');
					return false;
				}
				if(temptoday > tempEndDate){
					jAlert('End date should not be past date');
					return false;
				}
				if(isMandatoryFieldEmpty){
					jAlert('Please fill all mandatory fields which are marked with *');
					return false;
				}else{
					if(surveyValidationStatus){
						if(isActive==0){
							jAlert('This survey has been saved as a draft. Users cannot see this survey');
						}else{
							var noOfQuestions	= $('#selectedQuestions label input:checkbox:checked');
							if(noOfQuestions.length<1){
								jAlert('At least one question should exist in the survey to go live');
								return false;
							}
							if(tempStartDate > temptoday){
								jAlert('This survey has been saved. It will become active on the start date set by you');
							}else if(tempStartDate == temptoday){
								jAlert('This survey has been saved in active status');
							}
						}
						return true;
					}else{
						return false;
					}
				}
			}else{
				validateSurveyName();
				return false;
			}
		});
		$('p.groups input[type="checkbox"]').click(function (event){
			if($(this).attr("checked")!="checked"){
				$(this).removeAttr("checked");
				$('p.users input[type="checkbox"].'+$(this).val()).removeAttr("checked").removeAttr('disabled');
			}else{
				$(this).attr("checked","checked");
				$('p.users input[type="checkbox"].'+$(this).val()).attr('checked','checked').attr('disabled','disabled');
			}
		});
	});
</script>
<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/129921-creating-new-surveys' target='_new'>View Additional Help</a>"; ?>
<div id="surveyContainer">
<div id="surveyData">
	<div class="contentHeader"><span><?php echo (isset($surveyData['name'])?'Edit':'Create new');?> survey</span></div>
	<div id="msg"></div>
	<form id="surveyform" name="surveyform" action="<?php echo base_url();?>surveys/save_survey<?php echo (isset($surveyData['id'])?'/'.$surveyData['id']:'');?>" method="post">
		<table>
			<tr>
				<th class="alignRight" style="width:10%;">Survey Name<span class="required">*</span>:</th>
				<td style="width: 55%;">
					<input type="text" id="surveyName" name="survey_name" <?php if(isset($surveyData['name'])) echo 'value="'.$surveyData['name'].'"';?> /> 
					<span id="tooltip-survey-name" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Survey name will be seen by all users and will help identify the right survey. You will need this in all reports & maps, so please use a short survey name indicative of your purpose.<br><br>Users can submit responses only between the start & end date during which the survey is in live status.</span>">&nbsp;</a></span>
				</td>
				<td colspan="2" style="padding-right:1px;width: 35%;">
					<label>Start Date<span class="dateMandatory required">*</span>: </label>
					<input type="text" name="start_date" id="startDate" readonly="readonly" value="<?php if(isset($surveyData['start_date']) && $surveyData['start_date']!="00/00/0000") echo $surveyData['start_date'];?>" />
					<label>End Date<span class="dateMandatory required">*</span>: </label>
					<input type="text" name="end_date" id="endDate" readonly="readonly" value="<?php if(isset($surveyData['end_date']) && $surveyData['end_date']!="00/00/0000") echo $surveyData['end_date'];?>" />
				</td>
			</tr>
			<tr>
				<th class="alignRight" width="110px" style="vertical-align: top;">Description:</th>
				<td colspan="3"><textarea rows="1" cols="40" id="description" name="description"><?php if(isset($surveyData['description'])) echo $surveyData['description'];?></textarea></td>
			</tr>
			<tr>
				<th class="alignRight">Status:</th>
				<td colspan="3">
				<?php
				 $status	= 0;
				if(isset($surveyData['is_active']) && $surveyData['is_active']==1){
					$status	= 1;
				}?>
					<input class="isActive" type="radio" name="is_active" value="0" <?php if($status==0) echo 'checked="checked"';?> />Draft
					<input class="isActive" type="radio" name="is_active" value="1" <?php if($status==1) echo 'checked="checked"';?> />Live
					<span id="isActiveForHint" style="width: 10px;"></span>
					<span id="tooltip-survey-status" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>You can save in draft status so that the users will not see the survey. Once you make it live, all users can submit responses from start date until end date.<?php echo $helpLink;?></span>">&nbsp;</a></span>
				</td>
			</tr>
			<tr>
				<td colspan="4">
					<fieldset>
						<legend>
							Survey Visibility
							<span class="map-info tooltop-bottom helpToolTip"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Here you can control who can see the survey. Only those who you select below will see the survey. Either select the user group(s) or individual users or a combination of both to set up who can see this survey.</span>">&nbsp;</a></span>
						</legend>
						<div id="visibilityContainer">
							<p class="dividingHeader">User Groups
								<span class="map-info tooltop-bottom helpToolTip"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Select the user groups to set the survey visibility. All users in this group will see the survey. If you want to add more users, you can select from the user list as well.</span>">&nbsp;</a></span>
							</p>
							<?php
								foreach($arrGroups as $key=>$arrRow){
									$selected	= '';
									if(in_array($arrRow['group_id'],$arrSelectedGroups)){
										$selected	= 'checked="checked"';
									}
									echo '<p class="groups"><input type="checkbox" id="group'.$arrRow['group_id'].'" name="groups[]" value="'.$arrRow['group_id'].'" '.$selected.' /><label for="group'.$arrRow['group_id'].'">'.$arrRow['group_name'].'</label></p>';
								}?>
									<p class="dividingHeader">Users
										<span class="map-info tooltop-bottom helpToolTip"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Select the users to set the survey visibility. Survey will be visible only to the users selected here. If you have selected any user groups above, the individuals in the groups are automatically selected here.</span>">&nbsp;</a></span>
									</p>
								<?php foreach($arrClientUsers as $key=>$arrRow){
									$selected	= '';
									if(in_array($arrRow['id'],$arrSelectedClientUsers)){
										$selected	= 'checked="checked"';
									}
									echo '<p class="users"><input type="checkbox" id="user'.$arrRow['id'].'" class="'.str_replace(',',' ',$arrRow['group_ids']).'" name="users[]" value="'.$arrRow['id'].'" '.$selected.' /><label for="user'.$arrRow['id'].'">'.$arrRow['first_name'].' '.$arrRow['last_name'].'</label></p>';
								}
							?>
						</div>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td colspan="4">
					<fieldset style="padding:4px;">
						<table id="assignQuestions">
							<caption>Add Survey Question(s)
								<span id="tooltip-survey-questions" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter the survey question, select the categories and click on add question. The 3 categories, Type, TA & Role of influencer is not seen by users; but is used to generate reports and maps.</span>">&nbsp;</a></span>
							</caption>
							<tr>
								<td colspan="3" style="padding-bottom: 0px;"><div id="msg"></div></td>
								<td style="padding-bottom: 0px;text-align: right;"><a style="text-decoration: none;" href="#" onclick="addPreviousQuestions();return false;">Select question(s) from previous surveys</a></td>
							</tr>
							<tr>
								<th style="vertical-align: top;">Question:</th>
								<td colspan="3">
									<input type="hidden" name="question_id" id="questionId" value="0" />
									<textarea id="question" name="question" rows="2" cols="25"></textarea>
								</td>
							</tr>
							<tr>
								<td></td>
								<td><select id="qtype" name="qtype" class="chosenSelect" data-placeholder="Select Type" style="width:152px;">
										<option value=""></option>
										<?php 
											foreach($arrTypes as $id=>$name){
												echo '<option value="'.$id.'">'.$name.'</option>';
											}
										?>
									</select>
								</td>
								<td><select id="qta" name="qta" class="chosenSelect" data-placeholder="Select Therapeutic Area" style="width:200px;">
										<option value=""></option>
										<option value="0" class="highlightOption">Add New Therapeutic Area</option>
										<?php 
											foreach($arrSpecialties as $name=>$id){
												echo '<option value="'.$id.'">'.$name.'</option>';
											}
										?>
									</select>
								</td>
								<td><select id="qrole" name="qrole" class="chosenSelect" data-placeholder="Select Role" style="width:152px;">
										<option value=""></option>
										<option value="0" class="highlightOption">Add New Role</option>
										<?php 
											foreach($arrRoles as $name=>$id){
												echo '<option value="'.$id.'">'.$name.'</option>';
											}
										?>
									</select>
								</td>
							</tr>
							<tr>
								<td colspan="4"><center>
									<input class="newQuestion" type="button" value="Add Question" onclick="saveNewQuestion();" />&nbsp;
									<input class="existingQuestion" type="button" value="Update" onclick="updateQuestion();" />&nbsp;
									<input class="existingQuestion" type="button" value="Cancel" onclick="cancelUpdating();" />
								</center></td>
							</tr>
						</table>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td colspan="4">
					<fieldset>
						<legend>Survey Question(s)</legend>
						<div>
							<!--<div>
								<input type="button" value="Add new question" onclick="addNewQuestion();" />
								<input type="button" value="Select question(s) from previous surveys" onclick="addPreviousQuestions();" />
							</div>
							--><div id="selectedQuestions">
								<table>
								<?php 
									$count	= 0;
									if(isset($arrSelectedQuestions)){
										foreach($arrSelectedQuestions as $key=>$arrCategoryData){
											foreach($arrCategoryData['questions'] as $i=>$arrQuestion){
												$count++;
												echo '<tr><td>'.$count.')</td>';
												echo '<td><label class="group'.$arrCategoryData['category_id'].'">';
												echo '<input type="hidden" class="type'.$arrQuestion['id'].'" name="type'.$arrQuestion['id'].'" value="'.$arrQuestion['type_id'].'" />';
												echo '<input type="hidden" class="role'.$arrQuestion['id'].'" name="role'.$arrQuestion['id'].'" value="'.$arrQuestion['role_id'].'" />';
												echo '<input checked="checked" type="checkbox" name="question_ids[]" value="'.$arrQuestion['id'].'" />'.$arrQuestion['question'].'</label>';
												echo '</td><td>';
												echo "<div class='action'><div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editQuestion('".$arrQuestion['id']."');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"removeQuestion('".$arrQuestion['id']."');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Remove\"></a></div></div></div>";
												echo '</td></tr>';
												
											}
										}
									}?>
								</table>
							</div>
						</div>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td colspan="4" class="alignCenter"><input id="saveSurvey" type="submit" value="Save Survey" /></td>
			</tr>
		</table>
	</form>
</div>
<div id="surveyQuestionData"></div>
<!-- Container for the 'Interaction Add' modal box -->
<div id="dailog1">	
	<div id="addSurveyContainer" class="microProfileDialogBox">
		<div class="profileContent" id="addSurveyProfileContent"></div>
	</div>
</div>
<div id="dailog2">	
	<div id="addSurveyQuestionContainer" class="microProfileDialogBox">
		<div class="profileContent" id="addSurveyQuestionProfileContent">
		</div>
	</div>
</div>
<div id="dailog3">
	<div id="addNewContainer" class="microProfileDialogBox">
		<div class="profileContent" id="addNewProfileContent1">
			
		</div>
	</div>
</div>
<div id="OptionsContainer">
	<div id="addNewProfileContent" style="width:350px;padding: 18px;">
		<div class="contentHeader"><span>Enter new value</span></div>
		<input type="hidden" name="newOptionValueId" value="0" id="newOptionValueId" />
		<table>
			<tr>
				<td class="alignRight"><label for="newOptionValue"></label></td>
				<td><input type="text" name="newOptionValue" id="newOptionValue" /></td>
			</tr>
			<tr>
				<td colspan="2" class="alignCenter"><button onclick="saveNewOptionValue(); return false;">OK</button> <button onclick="cancelNewOptionValue(); return false;">Cancel</button></td>
			</tr>
		</table>
	</div>
</div>
<div id="previousSurveyQuestions" style="display: none;">
	<div class="assignMsg"></div>
	<div>
		Search question: <input type="text" name="search" class="search" />
		<input type="button" value="Select/Deselect All" onclick="toggleSelection();" />
		<input type="button" value="Assign selected Question(s)" onclick="assignSelectedQuestion();" />
	</div>
	<div class="multiselect">
		<?php 
		$selected	= '';
		foreach($arrCategories as $key=>$arrCategoryData){
			echo '<label id="group'.$arrCategoryData['category_id'].'" class="group"><a href="#" onclick="toggleGroup(this); return false;" >Select/Deselect All </a>Category - '.$key.'</label>';
			foreach($arrCategoryData['questions'] as $i=>$arrQuestion){
				$selected	= '';
				if(isset($surveyData['arrQuestionIds'][$arrQuestion['id']])){
					$selected	= 'checked="checked" disabled="disabled"';
				}
				echo '<label class="group'.$arrCategoryData['category_id'].'">';
				echo '<input type="hidden" class="type'.$arrQuestion['id'].'" name="type'.$arrQuestion['id'].'" value="'.$arrQuestion['type_id'].'" />';
				echo '<input type="hidden" class="role'.$arrQuestion['id'].'" name="role'.$arrQuestion['id'].'" value="'.$arrQuestion['role_id'].'" />';
				echo '<input '.$selected.' type="checkbox" name="question_ids[]" value="'.$arrQuestion['id'].'" />'.$arrQuestion['question'].'</label>';
			}
		}?>
	</div>
</div>
</div>
