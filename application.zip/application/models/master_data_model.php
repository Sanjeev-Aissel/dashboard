<?php
/**
 * @author	: Kishan Ravindra
 * @since	: V7.0
 * @package	: application.models
 * @created	: 27-07-2017
 */
class Master_data_model extends Model {
    //Constructor
	function Master_data_model() {
        parent::Model();
        $this->load->model('common_helpers');
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : getTitles()
     * @Action : returns records of 'Titles' Entity
     */
    function getTitles($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
    	if(!$doCount){
    		$this->db->select(array('titles.*'));
    	}
    	//Add the where conditions for any jqgrid filters
    	if(!$this->common_helpers->isDataNull($where['title'])){
    		$this->db->where("(titles.title LIKE '%".$where['title']."%')");
    	}
    	if(!$this->common_helpers->isDataNull($where['abbr'])){
    		$this->db->like('titles.abbr',$where['abbr']);
    	}
    	if(!$this->common_helpers->isDataNull($where['client_id'])){
    		$this->db->like('titles.client_id',$where['client_id']);
    	}
    	if(!$this->common_helpers->isDataNull($where['status'])){
    		$this->db->like('titles.status',$where['status']);
    	}
    	if($doCount){
    		$this->db->distinct();
    		$count=$this->db->count_all_results('titles');
    		return $count;
    	} else {
    		if(!$this->common_helpers->isDataNull($sidx) && !$this->common_helpers->isDataNull($sord)){
    			switch($sidx){
    				case 'title' : $this->db->order_by("titles.title",$sord);
    				break;
    				case 'abbr' :$this->db->order_by("titles.abbr",$sord);
    				break;
    				case 'client_id' :$this->db->order_by("titles.client_id",$sord);
    				break;
    				case 'status' :$this->db->order_by("titles.status",$sord);
    				break;
    			}
    		}
    		$this->db->order_by('title','asc');
    		$arrTitleDetail = $this->db->get('titles',$limit,$startFrom);
    		return $arrTitleDetail;
    	}
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : getTitleDetailsById()
     * @Action : returns records of 'Titles' Entity where id matches
     */
    function getTitleDetailsById($id){
    	return $this->db->get_where("titles",array("id"=>$id));
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : smartMergeTitle()
     * @Action : Inserts / Updates 'Titles'
     */
    function smartMergeTitle($data){
    	$retValue = 0;
    	if($data['id'] > 0){
    		$this->db->where('id', $data['id']);
    		$this->db->update('titles',$data);
    		$retValue = $data['id'];
    	} else {
    		$this->db->insert('titles',$data);
    		$retValue = $this->db->insert_id();
    	}
    	return $retValue;
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : deleteTitle()
     * @Action : Deletes 'Titles'
     */
    function deleteTitle($id){
    	$this->db->where('id', $id);
    	return $this->db->delete('titles');
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : getArrClientIds()
     * @Action : Returns array of ClientIDS from 'Title Client Mappings' where titleId matches
     */
    function getArrClientIds($titleId){
    	$this->db->select('group_concat(client_id) as client_ids');
    	$this->db->where('title_id', $titleId);
    	$this->db->group_by('title_id');
    	return $this->db->get('title_client_mappings');
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : getClientDetails()
     * @Action : Returns Client Details from 'Clients' (if 'id' metches : matched records, else : all records)
     */
    function getClientDetails($id=null){
    	if (!$this->common_helpers->isDataNull($id)) {
    		$this->db->where('id',$id);
    	}
    	$resultSet = $this->db->get('clients');
    	return $resultSet->result_array();
    }
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : saveTitleClientMappings()
     * @Action : Inserts 'Title Client Mappings' on creating new 'Titles'
     */
    function saveTitleClientMappings($data){
    	return $this->db->insert('title_client_mappings',$data);
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : deleteTitleClientMappings()
     * @Action : Removes 'Title Client Mappings' on creating new 'Titles'
     */
    function deleteTitleClientMappings($data){
    	$this->db->where($data);
    	return $this->db->delete('title_client_mappings');
    }
    
    //@Author : Kumaresh
    function checkSpecialty($specialty) {
    	$retFlag = false;
    	$this->db->where ( 'specialties.specialty', $specialty );
    	$query = $this->db->get ( 'specialties' );
    	if ($query->num_rows () > 0) {
    		$retFlag = true;
    	} 
    	return $retFlag;
    }
    
    function saveSpecialty($data, $id = 0) {
    	$status = false;
    	if ($id == 0) {
    		$status = $this->db->insert ( "specialties", $data );
    	} else {
    		$this->db->where ( "id", $id );
    		$status = $this->db->update ( "specialties", $data );
    	}
    	return $status;
    }
    
    function deleteSpecialty($id) {
    	return $this->db->delete ("specialties", array("id" => $id));
    }
    
    function getSpecClients($specId){
    	$this->db->select('specialty_client_association.client_id');
    	$this->db->where('specialty_client_association.specialty_id',$specId);
    	$arrClientsResult = $this->db->get('specialty_client_association');    	
    	return $arrClientsResult->result_array ();
    }
    
    function saveClientSpecialty($data) {
    	return $this->db->insert("specialty_client_association", $data );
    }
    
    function deleteClientSpecialty($specialty) {
    	return $this->db->delete("specialty_client_association", array ("specialty_id" => $specialty));
    }
    
    function specialtyClientAssociation() {
    	$clientId = $this->session->userdata("client_id");
    	$this->db->select('specialties.specialty');
    	if ($clientId != INTERNAL_CLIENT_ID) {
    		$this->db->join('specialty_client_association', 'specialties.id = specialty_client_association.specialty_id', 'inner');
    		$this->db->where('specialty_client_association.client_id', $clientId);
    	}
    	return $this->db->get('specialties');
    }
    
    function getSpecialtyDetails($limit, $startFrom,$sidx = '', $sord = ''){
    	$this->db->select ( 'specialties.*');
    	if (!$this->common_helpers->isDataNull($sidx) && !$this->common_helpers->isDataNull($sord)) {
    		$this->db->order_by ( "specialties.specialty", $sord );
    	}
    	$this->db->order_by ( 'specialties.specialty', 'asc' );
    	$arrSpecialtyDetails= $this->db->get ( 'specialties', $limit, $startFrom );
    	return $arrSpecialtyDetails->result_array();
    }
    
    /**
     * @Author	: Soumya R S
     * @Created	: 27-07-2017
    **/
    
    //to get list of countries with jqgrid filters applied
    function getCountriesList($start, $limit, $sidx, $sord, $arrFilter, $isCount = false){
		$this->db->select ( '*' );
		$this->db->from ( 'countries' );
		if (!$this->common_helpers->isDataNull( $arrFilter ['Country'] )) {
			$this->db->like ( 'Country', $arrFilter ['Country'] );
		}
		if (!$this->common_helpers->isDataNull( $arrFilter ['Capital'] )) {
			$this->db->like ( 'Capital', $arrFilter ['Capital'] );
		}
		if (!$this->common_helpers->isDataNull( $arrFilter ['NationalitySingular'] )) {
			$this->db->like ( 'NationalitySingular', $arrFilter ['NationalitySingular'] );
		}
		if (!$this->common_helpers->isDataNull( $arrFilter ['NationalityPlural'] )) {
			$this->db->like ( 'NationalityPlural', $arrFilter ['NationalityPlural'] );
		}
		if (!$this->common_helpers->isDataNull( $arrFilter ['Currency'] )) {
			$this->db->like ( 'Currency', $arrFilter ['Currency'] );
		}
		$this->db->limit ( $limit );
		$this->db->order_by ($sidx, $sord );
		if(!$isCount){
			$query = $this->db->get ('', $limit, $start );
			return $query->result ();
		}
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	//to get list of states  with jqgrid filters applied
    function getStatesList($start,$limit,$sidx,$sord,$countryId,$whereResultArray,$isCount=false){
		$this->db->select ( '*' );
		$this->db->from ( 'regions' );
		if (!$this->common_helpers->isDataNull( $whereResultArray ['Region'] )) {
			$this->db->like ( 'Region', $whereResultArray ['Region'] );
		}
		if (!$this->common_helpers->isDataNull( $whereResultArray ['Code'] )) {
			$this->db->like ( 'Code', $whereResultArray ['Code'] );
		}
		$this->db->where ( 'CountryID', $countryId );
		$this->db->order_by ($sidx, $sord );
		if(!$isCount){
			$query = $this->db->get ( '', $limit, $start );
			return $query->result ();
		}
		$query = $this->db->get ();
		return $query->num_rows ();
		
	}
	
	//to get list of cities with jqgrid filters applied.
    function getCitiesList($start, $limit, $sidx, $sord, $RegionID, $whereResultArray, $isCount = false){
		$this->db->select ( '*' );
		$this->db->from ( 'cities' );
		$this->db->limit ( $limit );
		$this->db->where ( 'RegionID', $RegionID );
		if (!$this->common_helpers->isDataNull( $whereResultArray ['City'] )) {
			$this->db->like ( 'City', $whereResultArray ['City'] );
		}
		if (!$this->common_helpers->isDataNull( $whereResultArray ['Latitude'] )) {
			$this->db->like ( 'Latitude', $whereResultArray ['Latitude'] );
		}
		if (!$this->common_helpers->isDataNull( $whereResultArray ['Longitude'] )) {
			$this->db->like ( 'Longitude', $whereResultArray ['Longitude'] );
		}
		if (!$this->common_helpers->isDataNull( $whereResultArray ['TimeZone'] )) {
			$this->db->like ( 'TimeZone', $whereResultArray ['TimeZone'] );
		}
		if (!$this->common_helpers->isDataNull( $whereResultArray ['Code'] )) {
			$this->db->like ( 'Code', $whereResultArray ['Code'] );
		}
		$this->db->order_by ( $sidx, $sord );
		if(!$isCount){
			$query = $this->db->get ( '', $limit, $start );
			return $query->result ();
		}
		$query = $this->db->get ();
		return $query->num_rows ();
	}
	
	//get details of a particular Country,by CountryId.
    function getDetailsById($table,$column_name,$id){
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($column_name, $id);
		$this->db->limit(1);
		$query = $this->db->get();
		return $query->row();
	}
    
	//adds a new country details into db
    function checkCountryIfExistElseAdd($arrCountry){
		$this->db->select ( 'CountryId' );
		$this->db->where ( 'Country', $arrCountry ['Country'] );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'countries' );
		$result = $query->result_array ();
		$retFlag = false;
		if ($this->common_helpers->isDataNull($result['0']['CountryId'])) {
			$retFlag = $this->db->insert ( 'countries', $arrCountry );
		}
		return $retFlag;
	}
	
	//adds state into db
    function checkStateIfExistElseAdd($state, $country, $code = null){
		$this->db->select ( 'RegionID' );
		$this->db->where ( 'Region', $state );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'regions' );
		$result = $query->result_array ();
		$retFlag = false;
		if ($this->common_helpers->isDataNull($result ['0'] ['RegionID'])) {
			$data = array (
					'CountryID' => $country,
					'Region' => $state,
					'Code' => $code 
			);
			$retFlag = $this->db->insert ( 'regions', $data );
		}
		return $retFlag;
	}

	//adds a new city details into db
    function addCity($arrCity){
    	$retFlag = false;
		$this->db->select ( 'CityId' );
		$this->db->where ( 'CountryID', $arrCity ['CountryID'] );
		$this->db->where ( 'RegionID', $arrCity ['RegionID'] );
		$this->db->where ( 'City', $arrCity ['City'] );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'cities' );
		$result = $query->result_array ();
		if ($this->common_helpers->isDataNull($result ['0'] ['CityId'])) {
			$retFlag = $this->db->insert ( 'cities', $arrCity );
		}
		return $retFlag;
	}
	
	//updates a City/state/country details by its Id
    function update($table,$column_name,$column_value,$arrDetails){
		$this->db->where ( $column_name, $arrDetails [$column_name] );
		return $this->db->update($table, $arrDetails);
	}
	
	//deletes a City/state/country by its Id
    function delete($arraydetails){
		$this->db->where($arraydetails ['column_name'], $arraydetails ['column_value']);
		$tables = strtoupper ( $arraydetails['table_name']);
		// Add log activity		
		$arrLogDetails = array (
				'type' => DELET_RECORD,
				'description' => 'deleting ' . $arraydetails['table_name']. ' data',
				'status' => SUCCESS,
				'transaction_id' => $arraydetails ['column_value'],
				'transaction_table_id' => constant ( $tables),
				'transaction_name' => "delete " . $arraydetails['table_name'],
				'parent_object_id' => $arraydetails ['column_value']
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		return $this->db->delete($arraydetails['table_name']);
	}
}