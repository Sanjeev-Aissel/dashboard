<style type="text/css">
.expire_msg {
    border-radius: 4px 4px 4px 4px;
    font-size: 13px;
    line-height: 20px;
    margin:0 auto;
    padding: 5px;
    background: #fff;
    width: 400px;
    margin-top: 5%;
}
</style>
<div class="expire_msg">
	<p>Your activation key is incorrect or expired. Please check your email again and follow the instructions.</p>
</div>