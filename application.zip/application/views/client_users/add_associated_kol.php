<?php
/*
 * To show list of clients
 * @author Vinayak Mallladad
 * @since 1.5.1
 * 
 * 
 * 
 */

?>
		<script type="text/javascript">
			$(document).ready(function(){
				$("#applyLink").click(function(){
					var hrefVal ='<?php echo base_url()?>client_users/list_multiple_kols/';
					clientId=$("#clientId").val();
					hrefVal+=clientId;
					$("#listMultipleKols").load(hrefVal);
				});
			});
				
		</script>			
		
		<label>Clients:</label>
		<select name="client_id" id="clientId">
			<option value="0">--- Select ---</option>
			<?php foreach ($arrClients as $clients)
						echo '<option value="'.$clients["id"].'">'.$clients["name"].'</option>';
			?>
		</select>
		

	<div id="Client">
	
	<a href='#' id="applyLink">Apply</a>
	</div>
	
	<div id="listMultipleKols">
	
	</div>