<?php
/**
	* @Description : Controller for tracking user log activities
	* @Author : Sanjeev K, Kishan Ravinda (00001111)
	* @Since : Colpal 1.7
	* @Package : application.controllers	
	* @Created : 30-09-2016
	* @Refactored : 01-08-2017
*/
class Client_user_log_activities extends Controller{
 	
 	private $loggedUserId	= null;
 	
 	//Constructor
	function client_user_log_activities(){
		parent::Controller();
		$this->load->model('log_activities');
		$this->load->model('common_helpers');
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	function show_client_log_activities($urlString = null){
	    $this->common_helpers->checkUsers();
		if($urlString != null){
			$data['urlString'] = json_encode($this->filters_to_array($urlString));
		}
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Client Users Log Actvity Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Client Users Log Actvity"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage'] = 'kols/client_users_log_activity';
		$this->load->view('layouts/analyst_view',$data);
// 		$this->load->view('layouts/client_view',$data);
	}

	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : list_client_log_activities()
	 * @Params : page, rows, sortIndex, sortOrder, filters (By REQUEST)
	 * @Action : returns log details to jQgrid
	 */
	function list_client_log_activities($startDate='',$endDate='',$clientId=''){
		$page = $_REQUEST['page'];
		$limit = $_REQUEST['rows'];
		$sidx = $_REQUEST['sidx'];
		$sord = $_REQUEST['sord'];
		if(!$sidx)	$sidx = 1;
		$filterData = $_REQUEST['filters'];
		$arrFilter = array();
		$arrFilter = json_decode(stripslashes($filterData));
		$field = 'field';
		$data = 'data';
		$searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray = array();
		foreach($searchField as $key => $val) {
			$whereResultArray[$val] = $searchString[$key];
		}
// 		$whereResultArray['startDate'] = $startDate;
// 		$whereResultArray['endDate'] = $endDate;
		if($endDate != '')
		    $whereResultArray['endDate'] = date("Y-m-d",strtotime("+1 day", strtotime($endDate)));
		    
	    if($startDate != '')
	        $whereResultArray['startDate'] = date("Y-m-d",strtotime($startDate));
		    
		$whereResultArray['clientId'] = $clientId;
		$count = $this->log_activities->getLogActivities($limit, $start, true, $sidx, $sord, $whereResultArray);
		$total_pages = $count > 0 ? ceil ( $count / $limit ) : 0;
		if ($page > $total_pages) $page = $total_pages;
		$start = $limit * $page - $limit;
		if ($start < 0)	$start = 0;
		$data = array();
		$arrLogsResult = array();
		if($arrLogsResult= $this->log_activities->getLogActivities($limit, $start, false, $sidx, $sord, $whereResultArray)) {
			$arrLogDetail = array();
			foreach($arrLogsResult->result_array() as $row) {
// 				$row["page_visited"] = $row["module"].'/'.$row["controller"];
			    $row["page_visited"] = $row['url'];
				$row["created_on"] = date("F j, Y g:i a",strtotime($row["created_on"]));
				$row["username"] = $row["first_name"].' '.$row["last_name"];
				$row["status"] = ($row["status"]==NULL) ? 'Success' : $row["status"];
				$arrLogDetail[] = $row;
			}
			$data ['records'] = $count;
			$data ['total'] = $total_pages;
			$data ['page'] = $page;
			$data ['rows'] = $arrLogDetail;
		}
		echo json_encode($data);
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : export_log_activities()
	 * @Params : From and To Date (By POST)
	 * @Action : Exports Log Activities to Excel
	 */
	function export_log_activities($fromDate, $toDate, $clientId) {
		$startTime = microtime(true);
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$this->load->plugin('php_excel/classes/PHPExcel.php');
		$whereArray = array();
// 		$whereArray['startDate'] = $fromDate;
// 		$whereArray['endDate'] = $toDate;
		if($toDate != '')
		    $whereArray['endDate'] = date("Y-m-d",strtotime("+1 day", strtotime($toDate)));
		    
	    if($fromDate != '')
	        $whereArray['startDate'] = date("Y-m-d",strtotime($fromDate));
	    
		$whereArray['clientId'] = $clientId;
		$arrLogDetails = $this->log_activities->getLogActivities(null, null, false, null, null, $whereArray);
		$objPHPExcel = new PHPExcel();
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Log Activities');
		$objWorksheet->setCellValue('A1','Log Id')
        ->setCellValue('B1','User Name')
        ->setCellValue('C1','User Role')
		->setCellValue('D1','User Email Id')
		->setCellValue('E1','Client')
		->setCellValue('F1','Action')
		->setCellValue('G1','KOL/ORG TYPE')
		->setCellValue('H1','KOL/ORG ID')
		->setCellValue('I1','Transaction Id')
		->setCellValue('J1','Transaction Name')
		->setCellValue('K1','Date of Action')
		->setCellValue('L1','OS')
		->setCellValue('M1','Browser')
		->setCellValue('N1','Status')
		->setCellValue('O1','City')
		->setCellValue('P1','State')
		->setCellValue('Q1','Country')
		->setCellValue('R1','Description')
		->setCellValue('S1','Miscellaneous2');
		$i = 2;
	 	foreach($arrLogDetails->result_array() as $logRecord) {
	 		$userName = $logRecord["first_name"].' '.$logRecord["last_name"];
	 		$emailId = $logRecord['email'];
	 		$createdOn = date("F j, Y g:i a",strtotime($logRecord['created_on']));
	 		$os = $logRecord['os'];
	 		$browser =  $logRecord['browser'];
	 		$status = ($logRecord["status"]==NULL) ? 'Success' : $logRecord["status"];
	 		$city = $logRecord['cityName'];
	 		$region = $logRecord['regionName'];
	 		$country = $logRecord['countryName'];
	 		$logRecord["created_on"] = date("F j, Y g:i a",strtotime($logRecord["created_on"]));
	 		$pageVisited = $logRecord["module"].'/'.$logRecord["controller"];
	 		$objWorksheet->setCellValue ('A'.$i,$logRecord['log_id'])
	 		->setCellValue('B'.$i,$userName)
	 		->setCellValue('c'.$i,$logRecord['user_role'])
	 		->setCellValue('D'.$i,$logRecord['email'])
	 		->setCellValue('E'.$i,$logRecord['client_name'])
	 		->setCellValue('F'.$i,$logRecord['action'])
	 		->setCellValue('G'.$i,$logRecord['kols_or_org_type'])
	 		->setCellValue('H'.$i,$logRecord['kols_or_org_id'])
	 		->setCellValue('I'.$i,$logRecord['transaction_id'])
	 		->setCellValue('J'.$i,$logRecord['transaction_name'])
	 		->setCellValue('K'.$i,$logRecord["created_on"])
	 		->setCellValue('L'.$i,$os)
	 		->setCellValue('M'.$i,$browser)
	 		->setCellValue('N'.$i,$status)
	 		->setCellValue('O'.$i,$city)
	 		->setCellValue('P'.$i,$region)
	 		->setCellValue('Q'.$i,$country)
	 		->setCellValue('R'.$i,$logRecord["log_description"])
	 		->setCellValue('S'.$i,$logRecord["miscellaneous2"]);
			$i++;
		}
		$objPHPExcel->addSheet($objWorksheet);
		$objPHPExcel->removeSheetByIndex(0);
		$objPHPExcel->setActiveSheetIndex(0);
		foreach(range('A','S') as $columnID ) {
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
		}
		$arrStyles = array (
			'font' => array ('bold' => true,'italic' => false),
			'borders' => array (
				'bottom' => array ('style' => PHPExcel_Style_Border::BORDER_THICK, 'color' => array ('rgb' => '000000')),
				'quotePrefix' => true
			)
		);
		$objPHPExcel->getActiveSheet()->getStyle('A1:S1')->applyFromArray($arrStyles);
 		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="Log_Activities '.$fromDate." to ".$toDate.'.xlsx"');
		header('Cache-Control: max-age=0');
		header('Cache-Control: max-age=1');
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').'GMT');
		header('Cache-Control: cache, must-revalidate');
		header('Pragma: public');
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
		// Add log activity
		$arrLogDetails = array (
				'type' => EXPORT_RECORD,
				'description' => 'Exporting Log Activities',
				'status' => SUCCESS,
				'file_name' => 'Log_Activities',
				'transaction_name' => "Exporting Log Activities",
				'client_id' => $clientId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		$objWriter->save('php://output');
		exit();
	}
}