<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<!-- <link rel="stylesheet" href="http://localhost/hmvc/assets/css/chosen.css" media="screen"/> -->
<!-- <script type="text/javascript" src="http://localhost/hmvc/assets/jqgrid/jquery.js"></script> -->
<!-- <script type="text/javascript" src="http://localhost/hmvc/assets/js/chosen.jquery.js"></script> -->
<script>
var base_url = "<?php echo base_url(); ?>";
</script>
<script type="text/javascript">
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts =array('modules/organizations/js/org_filters_li_style');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#savedFilterValue").chosen();
		$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
			doSearchFilter1(-1,this);
		});
		$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
				if($("#savedFilterValue").val()){
				activeCustmFilters();
				return true;
				} 
			doSearchFilter1(-1,this);
		});
	});
</script>
<style>
.filterDiv{
border-bottom: 1px solid #adadad;
    padding-top: 7px;
    padding-bottom: 8px;
}
.no_bottom_margin{
margin-bottom:0px;
}
div#categoriesContainer {
    font-size: 85%;
    font-weight: 100;
}
#pageSidebar{
border-left:1px solid #ccc;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding-top: 0px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 0px solid #ddd;
    padding-bottom: 3px;
}
.progress {
    height: 15px;
}
.progress-bar {
    font-size: 10px;
    line-height: 16px;
}
.input_hight_for_filters {
    height: 25px;
    font-size: 10px;
}
.right_side_bar_btn{
    font-size: 8px;
}
.progress-bar {
    color: #000000;
    background-color: #2b9af3;
    }
</style>
<style>
#searchFiltersElements ul li {
    font-size: 12px;
    list-style: none;
    color: #000000;
    font-style: normal;
    font-family: inherit;
}
.hideCheckbox{
display: none;
}
h3 {
    background: none repeat scroll 0 0 #2283AE;
    /* border: 1px outset #0000FF; */
    /* -webkit-border-radius: 10px 0px 0px 0px; */
    color: #FFFFFF;
    font-size: 12px;
    font-weight: bold;
    margin-bottom: 0;
    margin-left: -5px;
    margin-left: 0px;
    margin-right: 5px;
    margin-right: 0px;
    padding: 5px 0 3px 5px;
    text-align: left;
    background: url(../images/kolm-sprite-image.png) repeat-x scroll 2px -237px transparent;
    color: #2b9af3;
    background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
    background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
    background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
    background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
    background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
    line-height: 17px;
    background: none;
}
.funnelIcon {
    background: rgba(0, 0, 0, 0) url(<?php echo base_url(); ?>assets/modules/organizations/images/refine_by.svg) no-repeat scroll 0 0 / 18px auto;
}
#resetBttn {
    /* background: url(../images/kolm-sprite-image.png) no-repeat scroll -217px -62px #fbf; */
    background: url(../images/all_icons.png) repeat scroll 31% 45% transparent;
}
#resetBttn {
    /* background: url(../images/refreshicon2.png) repeat scroll -239px -70px cyan; */
    cursor: pointer;
    float: left;
    height: 16px !important;
    margin-left: 4px;
    margin-right: 5px;
    margin-top: 2px;
    margin-top: 0px;
    vertical-align: middle;
    width: 15px !important;
}
#resetBttn {
    background: rgba(0, 0, 0, 0) url(<?php echo base_url(); ?>assets/modules/organizations/images/reset_active.svg) no-repeat scroll 0 3px / 12px auto !important;
}

ul{
    padding-left: 0px;
}

.filterDiv ul li {
    font-size: 12px;
    list-style: none;
    color: #000000;
    font-style: normal;
    font-family: inherit;
}
.filterDiv ul li {
    padding-bottom: 5px;
    padding-left: 10px;
    padding-top: 5px;
}
.assigned {
    background-image: url(<?php echo base_url(); ?>assets/modules/organizations/images/assigned_active.svg);
    background-size: 22px auto;
    height: 22px;
    width: 22px;
}

.filterDropdownActive {
    background-image: url(<?php echo base_url(); ?>assets/modules/organizations/images/saved_filters.svg);
    background-size: 22px auto;
    height: 22px;
    width: 22px;
}
.typeDropDownActive {
    background-image: url(<?php echo base_url(); ?>assets/modules/organizations/images/profile_type_active.svg);
    background-size: 22px auto;
    height: 22px;
    width: 22px;
}
</style>
<h3>
<div class="funnelIcon sprite_iconSet"></div>Refine By
<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label>Reset</div>
</h3>
<div id="searchFiltersElements">

	<form action="<?php echo base_url()?>organizations/filter_search_organizations" name="searchForm" method="post" id="searchFilterForm">
	
	<input type="hidden" class="hiddenSearchField" name="keyword" id="keyword" value="<?php echo $keyword; ?>"/>
	<input type="hidden" class="hiddenSearchField" name="search_type" id="searchType" value="<?php echo $searchType; ?>"/>
	<input type="hidden" class="hiddenSearchField" name="filterCategory" id="filterCategory" value="organization"/>	
	<div id="categoriesContainer">
	<!-- Start Organization profile search (Assigned, Saved Filters, Profile Type) : Sanjeev K -->
		<div class="filterDiv">
		<ul>
		<li class="">
				<div>
					<div class="assigned sprite_iconSet" id="assignedIcon"></div>
					<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
					<div style="">
						<select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
							<option value="1" <?php if($viewType == MY_RECORDS)echo "selected='selected'";?>>My Organizations</option>
							<option value="2" <?php if($viewType == ALL_RECORDS)echo "selected='selected'";?>>All Organizations</option>
						</select>
					</div>
				</div>
			</li>
		<li id="customFilters" class="">
				<div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
				<label class="categoryName" style="border-bottom: 0px none; margin-right: 5px; float: left;">Saved Filters</label>
				<div style="">
					<select id="savedFilterValue" data-placeholder="Choose saved filters..." style="width:150px;" class="chosen-select" onchange="activeCustmFilters();">
						<option></option>
						<?php foreach($customFilters as $customFilter){ ?>
			 				<option value='<?php echo $customFilter['id'];?>' <?php if($savedFilterId == $customFilter['id']){ echo 'selected="selected"';}?> ><?php echo $customFilter['name'];?></option>
						<?php }?>
					</select>
					<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
						<a data-original-title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
					</div>
				</div>
			</li>
			<li class="">
				<div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
				<label class="categoryName" style="border-bottom: 0px none; margin-right: 9px; float: left;">Profile Type</label>
				<div style="">
					<select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
						<option value="0">All Profiles</option>
						<option value="<?php echo FULL;?>" <?php if($selectedProfileTypes == FULL) echo "selected='selected'";?>>Full Profiles</option>
						<option value="<?php echo BASIC;?>" <?php if($selectedProfileTypes == BASIC) echo "selected='selected'";?>>Basic Profiles</option>
					</select>
				</div>
			</li>	
	   	</ul>
	    <div class="input-group">
	    	<div class="input-group-btn">
		        <button class="btn btn-default right_side_bar_btn" >
		        <i class="glyphicon glyphicon-search"></i></button>
	     	</div>
	      	<input type="text" name="org_name" class="form-control input_hight_for_filters autocompleteInputBox" id="orgName" value="Enter Org Name" title="" />
			<input type="hidden" id="orgIdForAutocomplete" value='' name="org_id">
		</div>
	</div>
	<!-- End Organization profile search -->
	
	<!-- Start Organization Type search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
			<caption>Org Type</caption>
				<tr class="allOrgTypes">
					<td width="45%">
					<input class="hideCheckbox" type="checkbox" name="all_org_types" id="allOrgTypes" value="orgType" <?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>
					All Org Types
					</td>
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%">
					<?php if(isset($allOrgTypeCount)) echo $allOrgTypeCount; else echo 0;?>
					</td>
				</tr>
				<?php $i=0;
				 	foreach($arrOrgByTypeCount as $orgTypeCountDetails){ ?>
				 	<?php if($orgTypeCountDetails['org_type_id']>0){ ?>
					 	<tr class="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>" value="<?php echo $orgTypeCountDetails['org_type_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php
									if(isset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']])){
										unset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']]);
										echo 'checked="checked"';
									}
								?>
								/><?php echo $orgTypeCountDetails['type'];?>
					 		</td>
						 		<td>
						 			<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						 title="<?php echo $orgTypeCountDetails['count']."(".round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100)."%)";?>"
						  						style="width: <?php if(isset($allOrgTypeCount)) echo round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100); else echo 0;?>%;"
						  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				</div>
									</div>
								</td>
								<td>
								<?php if(isset($orgTypeCountDetails['count'])) echo $orgTypeCountDetails['count']; else echo 0;?>
								</td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null){
						foreach($selectedOrgTypes as $typeId=>$org_type_id){
							?>
						<tr class="orgType<?php echo $org_type_id;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="org_type_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $org_type_id;?>" value="<?php echo $org_type_id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;
								<?php echo $arrOrgByTypeCount[$org_type_id]['type'];?>
							</td>
					 		<td>
					 			<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						 title="<?php echo $arrOrgByTypeCount[$org_type_id]['count']."(".round(($arrOrgByTypeCount[$org_type_id]['count']/$allOrgTypeCount)*100)."%)";?>"
						  						 style="width: <?php if(isset($allOrgTypeCount)) echo round(($arrOrgByTypeCount[$org_type_id]['count']/$allOrgTypeCount)*100); else echo 0;?>%;"
						  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				<?php if (array_key_exists($org_type_id, $arrOrgByTypeCount)) echo $arrOrgByTypeCount[$org_type_id]['count']; else echo 0;?>
						  				</div>
									</div>
							</td>
						</tr>
					<?php }
					}?>
			</table>
		    <div class="input-group">
		    	<div class="input-group-btn">
			        <button class="btn btn-default right_side_bar_btn">
			       	 <i class="glyphicon glyphicon-search"></i>
			        </button>
		     	</div>
		      	<input type="text" name="org_type" class="form-control input_hight_for_filters autocompleteInputBox" id="orgType" value="Enter Org Type" title="" />
				<input type="hidden" name="org_type_id" id="orgTypeId" value="" />
		    </div>
		</div>	
	<!-- End Organization Type search -->
	
	<!-- Start Global Region search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
			<caption>Global Region</caption>
				<tr>
					<td width="45%">
						<input  class="hideCheckbox" type="checkbox" name="all_region_types" id="allRegionTypes" value="regionType" <?php if(isset($selectedGlobalRegions) && $selectedGlobalRegions!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>
						All Regions 
					</td>
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" 
						  style="width: <?php if(isset($allRegionCount)) echo round(($allRegionCount/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="25" 
						  aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%">
						<?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?>
					</td>
				</tr>
				<?php $i=0;
					 	foreach($arrOrgByRegionCount as $regionCountDetails){ ?>
					 	<?php if($regionCountDetails['GlobalRegion']!=''){?>
						 	<tr class="regionType<?php echo $i;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $i;?>" value="<?php echo $regionCountDetails['GlobalRegion'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedRegionTypes[$regionCountDetails['GlobalRegion']])){
											unset($selectedRegionTypes[$regionCountDetails['GlobalRegion']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $regionCountDetails['GlobalRegion'];?>
						 		</td>
						 		<td class="histoGram">
						 		<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$allRegionCount)*100)."%)";?>" 
						  						style="width: <?php if(isset($allRegionCount)) echo round(($regionCountDetails['count']/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				</div>
									</div>
								</td>
								<td><?php if(isset($regionCountDetails['count'])) echo $regionCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null){foreach($selectedRegionTypes as $typeId=>$regionName){?>
						<tr class="regionType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $regionName;?>
							</td>
					 		<td class="histoGram">
					 		<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  				title="<?php echo $arrRegionCount[$regionName]['count']."(".round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100)."%)";?>"
						  				style="width: <?php if(isset($allRegionCount)) echo round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
									</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrRegionCount)) echo $arrRegionCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
			</table>
		    <div class="input-group">
		    	<div class="input-group-btn">
			        <button class="btn btn-default right_side_bar_btn" >
			        <i class="glyphicon glyphicon-search"></i></button>
		     	</div>
		    	<input type="text" name="region_type" class="form-control input_hight_for_filters autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" />
		    </div>
		</div>
	<!-- End Global Region search -->
	
	<!-- Start Country search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
			<caption>Country</caption>
				<tr>
					<td width="45%">
						<input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  onclick="doSearchFilter1(-1,this)" value="country" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> />
						All Countries
					</td>
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%">
					<?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?>
					</td>
				</tr>
				<?php $i=0;
					 	foreach($arrOrgByCountryCount as $countryCountDetails){ ?>
					 	<?php if($countryCountDetails['country_id']>0){?>
							<tr class="country<?php echo $countryCountDetails['country_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $countryCountDetails['country_id'];?>" value="<?php echo $countryCountDetails['country_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedCountries[$countryCountDetails['country_id']])){
										unset($selectedCountries[$countryCountDetails['country_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $countryCountDetails['country'];?>
					 		</td>
					 		<td class="histoGram">
					 		<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allCountryCount)*100)."%)";?>" 
						  						style="width: <?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"
						  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				</div>
									</div>
							</td>
							<td><?php if(isset($countryCountDetails['count'])) echo $countryCountDetails['count']; else echo 0;?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCountries) && $selectedCountries!=null){foreach($selectedCountries as $countryKey=>$countryName){?>
						<tr class="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>" value="<?php echo $countryKey;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $countryName;?>
							</td>
					 		<td class="histoGram">
								<div class="progress no_bottom_margin">
						  			<div class="progress-bar" role="progressbar" title="<?php echo $arrOrgByCountryCount[$countryName]['count']."(".round(($arrOrgByCountryCount[$countryName]['count']['count']/$allCountryCount)*100).'%)';?>" style="width:<?php if(isset($allCountryCount)) echo round(($arrOrgByCountryCount[$countryName]['count']/$allCountryCount)*100); else echo 0;?>%;">
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($countryName, $arrOrgByCountryCount)) echo $arrOrgByCountryCount[$countryName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
			</table>
		    <div class="input-group">
		    	<div class="input-group-btn">
			        <button class="btn btn-default right_side_bar_btn" >
			        <i class="glyphicon glyphicon-search"></i></button>
		     	</div>
				<input type="text" name="country" class="form-control input_hight_for_filters autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
		    </div>
		</div>
	<!-- End Country search -->
	
	<!-- Start State search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
			<caption>State</caption>
				<tr>
					<td width="45%">
								<input class="hideCheckbox" type="checkbox" name="all_states" id="allStates"  onclick="doSearchFilter1(-1,this)" value="state" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> />
								All States
					</td>
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%">
					<?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?>
					</td>
				</tr>
				<?php $i=0;
					 	foreach($arrOrgByStateCount as $stateCountDetails){ ?>
					 	<?php if($stateCountDetails['state_id']>0){?>
					<tr class="state<?php echo $stateCountDetails['state_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $stateCountDetails['state_id'];?>" value="<?php echo $stateCountDetails['state_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedStates[$stateCountDetails['state_id']])){
										unset($selectedStates[$stateCountDetails['state_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $stateCountDetails['state'];?>
					 		</td>
					 		<td>
					 		<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $stateCountDetails['count']."(".round(($stateCountDetails['count']/$allStateCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allStateCount)) echo round(($stateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
							</td>
							<td><?php if(isset($stateCountDetails['count'])) echo $stateCountDetails['count']; else echo 0;?></td>
						</tr>
					
				<?php $i++; if($i>3) break; }}?>
					<?php
					//for each remaining selected values add checkbox and make them checked
					 if(isset($selectedStates) && $selectedStates!=null){foreach($selectedStates as $key=>$stateName){?>
						<tr class="state<?php echo $key;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $key;?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $stateName;?>
							</td>
					 		<td>
								<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						 title="<?php echo $arrOrgByStateCount[$stateName]['count']."(".round(($arrOrgByStateCount[$stateName]['count']['count']/$allStateCount)*100)."%)";?>"
						  						  style="width: <?php if(isset($allStateCount)) echo round(($arrOrgByStateCount[$stateName]['count']/$allStateCount)*100); else echo 0;?>%;"
						  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				</div>
									</div>
							</td>
							<td><?php if (isset($arrOrgByStateCount[$key])) echo $arrOrgByStateCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
			</table>
		    <div class="input-group">
		    	<div class="input-group-btn">
			        <button class="btn btn-default right_side_bar_btn" >
			        <i class="glyphicon glyphicon-search"></i></button>
		     	</div>
				<input type="text" name="state" class="form-control input_hight_for_filters autocompleteInputBox" id="state" value="Enter State" title=""/>
				<input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
		    </div>
		</div>
	<!-- End State search -->
	
	<!-- Start City search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
			<caption>City</caption>
				<tr class="allCities">
					<td class="textAlignRight" width="45%">
								<input class="hideCheckbox" type="checkbox" name="all_cities" id="allCities"  value="city" <?php if(isset($selectedCities) && $selectedCities!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/> All Cities</td>
						
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%"><?php if(isset($allCityCount)) echo $allCityCount; else echo 0;?></td>
				</tr>
				<?php $i=0;
					 	foreach($arrOrgByCityCount as $cityCountDetails){ ?>
					 	<?php if($cityCountDetails['state']!='' && $cityCountDetails['city_id']>0){?>
					 	<tr class="city<?php echo $cityCountDetails['city_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $cityCountDetails['city_id'];?>" value="<?php echo $cityCountDetails['city_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedCities[$cityCountDetails['city_id']])){
										unset($selectedCities[$cityCountDetails['city_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $cityCountDetails['city'];?>
					 		</td>
					 		<td>
					 			<div class="progress no_bottom_margin">
					  				<div class="progress-bar" role="progressbar" 
					  						 title="<?php echo $cityCountDetails['count']."(".round(($cityCountDetails['count']/$allCityCount)*100)."%)";?>"
					  						style="width: <?php if(isset($allCityCount)) echo round(($cityCountDetails['count']/$allCityCount)*100); else echo 0;?>%;"
					  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
					  				</div>
								</div>
							</td>
							<td><?php if(isset($cityCountDetails['count'])) echo $cityCountDetails['count']; else echo 0;?></td>
						</tr>
				<?php $i++; if($i>3) break; }}?>
					<?php
					//for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCities) && $selectedCities!=null){foreach($selectedCities as $key=>$cityName){?>
						<tr class="city<?php echo $key;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $key;?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $cityName;?>
							</td>
							<td>
					 			<div class="progress no_bottom_margin">
						  				<div class="progress-bar" role="progressbar" 
						  						 title="<?php echo $arrOrgByCityCount[$cityName]['count']."(".round(($arrOrgByCityCount[$cityName]['count']['count']/$allCityCount)*100)."%)";?>"
						  						 style="width: <?php if(isset($allCityCount)) echo round(($arrOrgByCityCount[$cityName]['count']/$allCityCount)*100); else echo 0;?>%;"
						  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
						  				</div>
									</div>
							</td>
							<td><?php if (isset($arrOrgByCityCount[$key])) echo $arrOrgByCityCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
			</table>
		    <div class="input-group">
		    	<div class="input-group-btn">
			        <button class="btn btn-default right_side_bar_btn" >
			        <i class="glyphicon glyphicon-search"></i></button>
		     	</div>
				<input type="text" name="city" class="autocompleteInputBox form-control input_hight_for_filters" id="city" value="Enter City" title=""/>
				<input type="hidden" id="cityIdForAutocomplete" value='' name="city_id">
		    </div>
		</div>
	<!-- End City search -->
	
	<!-- Start Organization Type (parent, child, others) search : Sanjeev K -->
		<div class="filterDiv">
			<table class="table no_bottom_margin no">
				<caption>Organization Type</caption>
				<tr class="allOrgs">
					<td  width="45%" class="textAlignRight">
								<input class="hideCheckbox" type="checkbox" id="allOrgs" value="ALL" <?php if(isset($selectedOrgs) && ($selectedOrgs=='ALL' || in_array("ALL", $selectedOrgs))) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> 
								All Organizations
					</td>
						
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					
					<td width="5%">
					<?php if(isset($allOrgsCount)) echo $allOrgsCount; else echo 0;?>
					</td>
				</tr>
				<tr class="parentOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="parentOrgs" <?php if(isset($selectedOrgs) && in_array("PARENT", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Parent Organizations</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $parentOrgsCount."(".round(($parentOrgsCount/$allOrgsCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($parentOrgsCount)) echo round(($parentOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($parentOrgsCount)) echo $parentOrgsCount; else echo 0;?></td>
				</tr>
				<tr class="childOrgs">
					<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="childOrgs" <?php if(isset($selectedOrgs) && in_array("CHILD", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Child Organizations</td>
					<td class="histoGram"><div class="filterBar">
							<div class="progress" title="<?php echo $childOrgsCount."(".round(($childOrgsCount/$allOrgsCount)*100)."%)";?>">
								<div class="bar" style="width: <?php if(isset($childOrgsCount)) echo round(($childOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
							</div>
						</div>
					</td>
					<td><?php if(isset($childOrgsCount)) echo $childOrgsCount; else echo 0;?></td>
				</tr>
				<tr class="otherOrgs">
					<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="otherOrgs" <?php if(isset($selectedOrgs) && in_array("OTHER", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Others</td>
					<td class="histoGram"><div class="filterBar">
							<div class="progress" title="<?php echo $otherOrgsCount."(".round(($otherOrgsCount/$allOrgsCount)*100)."%)";?>">
								<div class="bar" style="width: <?php if(isset($otherOrgsCount)) echo round(($otherOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
							</div>
						</div>
					</td>
					<td><?php if(isset($otherOrgsCount)) echo $otherOrgsCount; else echo 0;?></td>
				</tr>
			</table>
		</div>
	<!-- End Organization Type (parent, child, others) search -->
	</div>	
	</form>
</div>	

<script type="text/javascript">
	//	$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
		$('#categoriesContainer input:checked').each(function (index){
			$(this).parent().parent().css('background-color','#D3DFED');
		});
		
		$('#searchFiltersElements table tr').click(function (){
			if($('#'+$(this).attr('class')).attr('checked')=="checked"){
				$(this).css('background-color','#ffffff');
				$('#'+$(this).attr('class')).removeAttr('checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}else{
				$(this).css('background-color','#D3DFED');
				$('#'+$(this).attr('class')).attr('checked','checked');
				$('#'+$(this).attr('class')).next().attr('checked','checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}
		});
/*		$("#searchFiltersElements ul li table tr").hover(
				function () {
					$(this).toggleClass('activeRow');
				},
				function () {
					$(this).toggleClass('activeRow');
				}
			);
*/
		var a,options;

		// Autocomplet Options for the 'org name' field
		var orgNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.organizations').html();
					var selId = $(event).children('.organizations').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#orgName').val(selText);
					$('#orgIdForAutocomplete').val(selId);
					if(event.length>20){
						//$('#orgIdForAutocomplete').val(kolId);
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		// Autocomplet Options for the 'org name' field
		var regionTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_region',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.regionTypes').html();
					var selId = $(event).children('.regionTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#regionType').val(selText);
					$('#regionTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		
		// Autocomplet Options for the 'country' field
		var countryNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.countries').html();
					var selId = $(event).children('.countries').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#country').val(selText);
					$('#countryId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		// Autocomplet Options for the 'country' field
		var stateNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names/1',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var stateId = $(event).children('.autocompleteStateId').html();
					var selText = $(event).children('.stateName').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#state').val(selText);
					$('#stateIdForAutocomplete').val(stateId);
					if(selText.length>20){
						if(selText.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	

		// Autocomplet Options for the 'city' field
		var cityNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names/1',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var cityId = $(event).children('.autocompleteCityId').html();
					var selText = $(event).children('.cityName').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#city').val(selText);
					$('#cityIdForAutocomplete').val(cityId);
					if(selText.length>20){
						if(selText.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		
		// Autocomplet Options for the 'org type' field
		var orgTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>organizations/get_org_types',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.orgTypes').html();
					var selId = $(event).children('.orgTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#orgType').val(selText);
					$('#orgTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		$(document).ready(function(){
			// Trigger the Autocompleter for 'Role' field of  Event'
		
			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#orgName').autocomplete(orgNameAutoCompleteOptions);

			a = $('#regionType').autocomplete(regionTypeAutoCompleteOptions);
			
			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#country').autocomplete(countryNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#state').autocomplete(stateNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'city' field of  Event'
			a = $('#city').autocomplete(cityNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#orgType').autocomplete(orgTypeAutoCompleteOptions);
			
			$('.autocomplete').click(function(){
				//doSearchFilter1(-1);
			});

			
			$('#orgName').focus(function(){
				$('#orgName').val(' ');
			});
			       
			$('#orgName').blur(function(){
				$('#orgName').val('Enter Org Name');
			});
			$('#regionType').focus(function(){
			    $('#regionType').val(" ");
			    });
			            
			$('#regionType').blur(function(){
			    $('#regionType').val('Enter Global Region');
			    });
			$('#country').focus(function(){
				$('#country').val(' ');
			});
			       
			$('#country').blur(function(){
				$('#country').val('Enter Country');
			});

			$('#state').focus(function(){
				$('#state').val(' ');
			});
			       
			$('#state').blur(function(){
				$('#state').val('Enter State');
			});

			$('#city').focus(function(){
				$('#city').val(' ');
			});
			       
			$('#city').blur(function(){
				$('#city').val('Enter City');
			});

			$('#orgType').focus(function(){
				$('#orgType').val(' ');
			});
			       
			$('#orgType').blur(function(){
				$('#orgType').val('Enter Org Type');
			});

			if($('#country').val()=='Enter Country' || $('#state').val()=='Enter State' || $('#city').val()=='Enter City' || $('#orgType').val()=='Enter Org Type'){
				$('.autocompleteInputBox').css({color:'grey'});
			}
			
	});
</script>