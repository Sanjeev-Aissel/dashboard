<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logins extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('login');
		$this->load->model('helpers/common_helper');
		$this->load->library('SimpleLoginSecure');
	}
	function index()
	{
		if($this->session->userdata('logged_in')) {
			$landing_page=$this->login->getLandingPageByClientID($this->session->userdata('client_id'));
			redirect('/'.$landing_page);
		}else{
			$data['contentPage']='login_view_page';
			$this->load->view(ANALYST_LAYOUT,$data);
		}
	}
	function validate_login()
	{
		$username= $_POST['username'];
		$password= $_POST['password'];
		$loginDetails=$this->simpleloginsecure->login($username,$password);
		if($loginDetails['status']) {
			$userDetails		=$this->login->getUserDetails($username,true);
			$client_name		=$this->common_helper->getClientNameByClientId($userDetails['client_id']);
			$role_type			=$this->login->checkUserRoleType($userDetails['id']);
			$client_name		=strtolower($client_name);
			$landing_page=$this->login->getLandingPageByClientID($userDetails['client_id']);

			$newdata = array(
					'client_id'		=>$userDetails['client_id'],
					'client_name'	=>$client_name,
					'logged_in' 	=>true,
					'role_id'		=>$userDetails['user_role_id'],
					'user_id'		=>$userDetails['id'],
					'user_full_name'=>$userDetails['first_name']." ".$userDetails['last_name'],
					'user_name'		=>$userDetails['user_name'],
					'name_order'	=>$userDetails['name_order'],
					'role_type'		=>$role_type,
					'landing_page'	=>$landing_page
			);	
			$this->session->set_userdata($newdata);
			//get permissions of user-role
			$json 			= file_get_contents(APPPATH.'views/permission/'.$this->session->userdata('role_id').'.php');
			$arrPermissions	=json_decode($json,true);
			//save permisssion array into config
			$this->config->set_item('role_permissions',$arrPermissions);
			
			if($this->session->userdata('back_url')) {
				$redirect_page=$this->session->userdata('back_url');
			}else{
				$redirect_page=$landing_page;
			}
			$loginDetails['landing_page']=$redirect_page;
		}
// 		pr($this->session->all_userdata());exit;
// 		pr($loginDetails);exit;
		echo json_encode($loginDetails);
	}
	function show_forgot_password_page() {
		if ($this->session->userdata ( 'logged_in' )) {
			$landing_page=$this->login->getLandingPageByClientID($this->session->userdata('client_id'));
			$loginDetails['landing_page']=$landing_page;
		}
		$data ['contentPage'] = 'logins/forgot_password';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function forgot_password() {
		$emailId = $this->input->post('email');
		$mailStatus = false;
		if ($userDetails = $this->login->getUserDetailsByEmailId($emailId)) {
			$userId = $userDetails ['id'];
			$newPasswordkey = md5 ( rand () . microtime () ); //generate new password key
			$this->login->updateNewPasswordKey ( $newPasswordkey, $userId ); //update newpassword key in database
			$arrDetails ['userId'] = $userId;
			$arrDetails ['key'] = $newPasswordkey;
			$arrDetails ['userName'] = ucwords((strtolower($userDetails ['first_name'] . " " . $userDetails ['last_name'])));
			$html = $this->load->view('forgot_password-html',$arrDetails,true ); //generate email content (message body with reset password link) 
			
			$config= $this->common_helper->getMailConfig();
			$this->email->initialize($config);
			$this->email->set_newline("\r\n");
			$this->email->clear();
			$this->email->from('soumyas@aissel.com','Soumya');
			$this->email->to($userDetails['email']);
			$this->email->subject('Link to reset password(Testing)');
			$this->email->message($html);
			$mailStatus =$this->email->send();			
		}
		$response['status'] = $mailStatus;
		$response['message'] = $mailStatus ? "We have sent you an email with a link to reset your password" : "Invalid Email/Server Error, Retry";
		echo json_encode($response);
	}
	function reset_password($newPassKey) {
		$arrUsers = $this->common_helper->getEntityById('client_users', array ('new_password_key' => $newPassKey));
		$arrUserData = $arrUsers->result_array();
		$data ['userId'] = $arrUserData[0]['id'];
		$data ['newPassKey'] = $newPassKey;
		$data ['pageTitle'] = "Reset Password";
		if (! ($this->login->checkExpirekey ( $data ))) {
			$data ['contentPage'] = 'logins/reset_password_expired';
		} else {
			$data ['contentPage'] = 'logins/reset_password';
		}
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function update_password() {
		$status=false;
		$newPassKey = $this->input->post('new_password_key');
		$newPassword = $this->input->post('password');
		
		$arrUsers = $this->common_helper->getEntityById('client_users',array('new_password_key'=>$newPassKey));
		$arrUserData = $arrUsers->result_array();
		$userId = $arrUserData[0]['id'];
		$hasher = new PasswordHash( PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE );
		$arrUser ['password'] = $hasher->HashPassword ( $newPassword );
		$arrPassword = $this->login->getUserRecentPassword( $userId );
		$password = 0;
		foreach ( $arrPassword as $row ){
			if ($hasher->CheckPassword ( $newPassword, $row ['password'] )) {
				$password = 1;
				$status=false;
			}
		}
		if ($password == 0) {
			$resetStatus = $this->login->resetPassword($arrUser,$userId);//update password
			if($resetStatus){
				$status=true;
				$arrUser ['user_id'] = $userId;
				$this->common_helper->insertEntity('password_analytics', $arrUser );
				$this->login->resetFailedAttempts($userId);
				$userDetail = $this->login->getUserDetails($userId,false);
				$fullName = $userDetail['first_name']." ".$userDetail['last_name'];
				$userDetail['fullName'] = ucwords(strtolower($fullName));
				$html = $this->load->view ('confirm_message-html', $userDetail, true );
				$config= $this->common_helper->getMailConfig();
				$this->email->initialize($config);
				$this->email->set_newline("\r\n");
				$this->email->clear();
				$this->email->from('soumyas@aissel.com','Soumya');
				$this->email->to($userDetail['email']);
				$this->email->subject('Your ' . PRODUCT_VERSION . ' Application password has been changed');
				$this->email->message($html);
				$this->email->send();
			}
		} 
		$response['status'] = $status;
		$response['message'] = $status ? "Password is succesfully updated":"sorry...Try again...";
		echo json_encode($response);
	}
	function logout(){
		$data = array('client_id'  => '','client_name'  => '','logged_in' =>'');
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		redirect('/logins');
		$data['contentPage']='login_view_page';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function try_hmvc2(){
		echo "<br>try_hmvc function in  logins controller";
	}
}