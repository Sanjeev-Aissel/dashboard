<?php
$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";

?>
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts =array('search/org_filters_li_style');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
	}
</script>
<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999;*/
		margin-top:0.7em;
		overflow:visible;
		padding-top:0.8em;
		padding-top:0px;
		margin-top:0px;
		clear:both;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryOrgName{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	#searchLeftBar label.facet-toggle:hover {
	
	}
	
	#searchLeftBar label.collapsed{
		
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px;
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		margin-top: 0px;
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
	#categotyOrgType .navLinkOrgs{
		background: url("<?php echo base_url();?>images/ipad/organisation_active.svg");
		background-size: 18px;
		background-repeat: no-repeat;
	}
	#categoryOrgType .navLinkOrgs{
		background: url("<?php echo base_url();?>images/ipad/organisation_active.svg");
		background-size: 18px;
		background-repeat: no-repeat;
	}
	.region{
		background: url('../images/ipad/region_active.svg');
		background-size: 22px auto;
		height: 22px;
		width: 22px;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$("#savedFilterValue").chosen();
		$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
			doSearchFilter1(-1,this);
		});
		$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
				if($("#savedFilterValue").val()){
				activeCustmFilters();
				return true;
				} 
			doSearchFilter1(-1,this);
		});
	});
</script>
<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>organizations/filter_search_organizations" name="searchForm" method="post" id="searchFilterForm">
		<input type="hidden" class="hiddenSearchField" name="keyword" id="keyword" value="<?php echo $keyword; ?>"/>
		<input type="hidden" class="hiddenSearchField" name="search_type" id="searchType" value="<?php echo $searchType; ?>"/>
		<input type="hidden" class="hiddenSearchField" name="filterCategory" id="filterCategory" value="organization"/>		
		<!--<div id="resetBttnContainer"><label id="resetBttn" onclick="resetFilters();">&nbsp</label>Reset</div>
		-->
		<ul id="categoriesContainer">
			<li class="">
				<div>
					<div class="assigned sprite_iconSet" id="assignedIcon"></div>
					<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
					<div style="">
						<select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
							<option value="1" <?php if($viewType == MY_RECORDS)echo "selected='selected'";?>>My Organizations</option>
							<option value="2" <?php if($viewType == ALL_RECORDS)echo "selected='selected'";?>>All Organizations</option>
						</select>
					</div>
				</div>
			</li>
			<li id="customFilters" class="">
				<div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
				<label class="categoryName" style="border-bottom: 0px none; margin-right: 5px; float: left;">Saved Filters</label>
				<div style="">
					<select id="savedFilterValue" data-placeholder="Choose saved filters..." style="width:150px;" class="chosen-select" onchange="activeCustmFilters();">
						<option></option>
						<?php foreach($customFilters as $customFilter){ ?>
			 				<option value='<?php echo $customFilter['id'];?>' <?php if($savedFilterId == $customFilter['id']){ echo 'selected="selected"';}?> ><?php echo $customFilter['name'];?></option>
						<?php }?>
					</select>
					<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
						<a data-original-title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
					</div>
				</div>
			</li>
			<li class="">
				<div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
				<label class="categoryName" style="border-bottom: 0px none; margin-right: 9px; float: left;">Profile Type</label>
				<div style="">
					<select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
						<option value="0">All Profiles</option>
						<option value="<?php echo FULL;?>" <?php if($selectedProfileTypes == FULL) echo "selected='selected'";?>>Full Profiles</option>
						<option value="<?php echo BASIC;?>" <?php if($selectedProfileTypes == BASIC) echo "selected='selected'";?>>Basic Profiles</option>
					</select>
				</div>
			</li>
			<li id="categoryOrgName" class="category">
<!--				<div class="navLinkOrgs sprite_iconSet"></div><label class="categoryName">Organization Name</label>-->
				<table>
					<?php if(isset($selectedOrgNames)){?>
						<?php foreach($selectedOrgNames as $orgId => $orgName){?>
							<tr class="orgName<?php echo $orgId;?>">
								<td class="textAlignRight"><input type="checkbox" name="org_ids[]" class="orgNameElement hideCheckbox" id="orgName<?php echo $orgId;?>" value="<?php echo $orgId;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $orgName;?>
									<input type="checkbox" class="hideCheckbox" name="org_names[]" value="<?php echo $orgName;?>" checked="checked" />
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="1(<?php echo round((1/1)*100);?>%)">
											<div class="bar" style="width: <?php if(isset($orgId)) echo round((1/1)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td>1</td>
							</tr>
						<?php }?>					
					<?php }?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="org_name" class="autocompleteInputBox" id="orgName" value="Enter Org Name" title="" /><input type="hidden" id="orgIdForAutocomplete" value='' name="org_id">
			</li>
			<li id="categotyOrgType" class="category">
				<div class="navLinkOrgs sprite_iconSet"></div><label class="categoryName">Org Type</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allOrgTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_org_types" id="allOrgTypes" value="orgType" <?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Org Types</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allOrgTypeCount."(".round(($allOrgTypeCount/$allOrgTypeCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgTypeCount)) echo round(($allOrgTypeCount/$allOrgTypeCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allOrgTypeCount)) echo $allOrgTypeCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrOrgByTypeCount as $orgTypeCountDetails){ ?>
					 	<?php if($orgTypeCountDetails['org_type_id']>0){?>
						 	<tr class="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>" value="<?php echo $orgTypeCountDetails['org_type_id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']])){
											unset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']]);
											echo 'checked="checked"';
										}
									?>
									/>&nbsp;<?php echo $orgTypeCountDetails['type'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $orgTypeCountDetails['count']."(".round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allOrgTypeCount)) echo round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($orgTypeCountDetails['count'])) echo $orgTypeCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null){foreach($selectedOrgTypes as $typeId=>$orgTypeName){?>
						<tr class="orgType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $orgTypeName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOrgByTypeCount[$orgTypeName]['count']."(".round(($arrOrgByTypeCount[$orgTypeName]['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrOrgByTypeCount[$orgTypeName]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrOrgByTypeCount)) echo $arrOrgByTypeCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="org_type" class="autocompleteInputBox" id="orgType" value="Enter Org Type" title="" /><input type="hidden" name="org_type_id" id="orgTypeId" value="" />
				</div>
			</li>
			<li id="categotyRegions" class="category">
				<div class="region sprite_iconSet"></div><label class="categoryName">Global Region</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allRegionTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_region_types" id="allRegionTypes" value="regionType" <?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Regions </td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allRegionCount."(".round(($allRegionCount/$allRegionCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($allRegionCount/$allRegionCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrOrgByRegionCount as $regionCountDetails){ ?>
					 	<?php if($regionCountDetails['GlobalRegion']!=''){?>
						 	<tr class="regionType<?php echo $i;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $i;?>" value="<?php echo $regionCountDetails['GlobalRegion'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedRegionTypes[$regionCountDetails['GlobalRegion']])){
											unset($selectedRegionTypes[$regionCountDetails['GlobalRegion']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $regionCountDetails['GlobalRegion'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$allRegionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($regionCountDetails['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($regionCountDetails['count'])) echo $regionCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null){foreach($selectedRegionTypes as $typeId=>$regionName){?>
						<tr class="regionType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $regionName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrRegionCount[$regionName]['count']."(".round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrRegionCount)) echo $arrRegionCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="region_type" class="autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" />
				</div>
            </li>
			<li id="categoryCountry" class="category">
				<div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Country</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allCountries">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/> All Countries</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allCountryCount."(".round(($allCountryCount/$allCountryCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($allCountryCount/$allCountryCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?></td>
					</tr>
			
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrOrgByCountryCount as $countryCountDetails){ ?>
					 	<?php if($countryCountDetails['country_id']>0){?>
					 	<tr class="country<?php echo $countryCountDetails['country_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $countryCountDetails['country_id'];?>" value="<?php echo $countryCountDetails['country_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedCountries[$countryCountDetails['country_id']])){
										unset($selectedCountries[$countryCountDetails['country_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $countryCountDetails['country'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if(isset($countryCountDetails['count'])) echo $countryCountDetails['count']; else echo 0;?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCountries) && $selectedCountries!=null){foreach($selectedCountries as $countryKey=>$countryName){?>
						<tr class="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>" value="<?php echo $countryKey;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $countryName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOrgByCountryCount[$countryName]['count']."(".round(($arrOrgByCountryCount[$countryName]['count']['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrOrgByCountryCount[$countryName]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($countryName, $arrOrgByCountryCount)) echo $arrOrgByCountryCount[$countryName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="country" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
				</div>
			</li>
			<li id="categoryState" class="category">
				<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName">State</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allStates">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_states" id="allStates"  value="state" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/> All States</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allStateCount."(".round(($allStateCount/$allStateCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($allStateCount/$allStateCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?></td>
					</tr>
			
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrOrgByStateCount as $stateCountDetails){ ?>
					 	<?php if($stateCountDetails['state_id']>0){?>
					 	<tr class="state<?php echo $stateCountDetails['state_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $stateCountDetails['state_id'];?>" value="<?php echo $stateCountDetails['state_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedStates[$stateCountDetails['state_id']])){
										unset($selectedStates[$stateCountDetails['state_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $stateCountDetails['state'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $stateCountDetails['count']."(".round(($stateCountDetails['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($stateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if(isset($stateCountDetails['count'])) echo $stateCountDetails['count']; else echo 0;?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php
					//for each remaining selected values add checkbox and make them checked
					 if(isset($selectedStates) && $selectedStates!=null){foreach($selectedStates as $key=>$stateName){?>
						<tr class="state<?php echo $key;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $key;?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $stateName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOrgByStateCount[$stateName]['count']."(".round(($arrOrgByStateCount[$stateName]['count']['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($arrOrgByStateCount[$stateName]['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (isset($arrOrgByStateCount[$key])) echo $arrOrgByStateCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="state" class="autocompleteInputBox" id="state" value="Enter State" title=""/><input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
				</div>
			</li>
		
			<li id="categoryCity" class="category">
				<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName">City</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allCities">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_cities" id="allCities"  value="city" <?php if(isset($selectedCities) && $selectedCities!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/> All Cities</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allCityCount."(".round(($allCityCount/$allCityCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($allCityCount/$allCityCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCityCount)) echo $allCityCount; else echo 0;?></td>
					</tr>
			
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrOrgByCityCount as $cityCountDetails){ ?>
					 	<?php if($cityCountDetails['city_id']>0){?>
					 	<tr class="city<?php echo $cityCountDetails['city_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $cityCountDetails['city_id'];?>" value="<?php echo $cityCountDetails['city_id'];?>" onclick="doSearchFilter1(-1,this)"
				 				<?php
									if(isset($selectedCities[$cityCountDetails['city_id']])){
										unset($selectedCities[$cityCountDetails['city_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $cityCountDetails['city'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $cityCountDetails['count']."(".round(($cityCountDetails['count']/$allCityCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($cityCountDetails['count']/$allCityCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if(isset($cityCountDetails['count'])) echo $cityCountDetails['count']; else echo 0;?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php
					//for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCities) && $selectedCities!=null){foreach($selectedCities as $key=>$cityName){?>
						<tr class="city<?php echo $key;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $key;?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $cityName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOrgByCityCount[$cityName]['count']."(".round(($arrOrgByCityCount[$cityName]['count']['count']/$allCityCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($arrOrgByCityCount[$cityName]['count']/$allCityCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (isset($arrOrgByCityCount[$key])) echo $arrOrgByCityCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="city" class="autocompleteInputBox" id="city" value="Enter City" title=""/><input type="hidden" id="cityIdForAutocomplete" value='' name="city_id">
				</div>
			</li>
			<!-- START : Organization (Parent-Child Filter) - by Kishan Ravindra -->
			<li id="categoryOrgType" class="category">
				<div class="navLinkOrgs sprite_iconSet"></div><label class="categoryName">Organization Type</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="allOrgs" value="ALL" <?php if(isset($selectedOrgs) && ($selectedOrgs=='ALL' || in_array("ALL", $selectedOrgs))) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> All Organizations</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allOrgsCount."(".round(($allOrgsCount/$allOrgsCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgsCount)) echo round(($allOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allOrgsCount)) echo $allOrgsCount; else echo 0;?></td>
					</tr>
					<tr class="parentOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="parentOrgs" <?php if(isset($selectedOrgs) && in_array("PARENT", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Parent Organizations</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $parentOrgsCount."(".round(($parentOrgsCount/$allOrgsCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($parentOrgsCount)) echo round(($parentOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($parentOrgsCount)) echo $parentOrgsCount; else echo 0;?></td>
					</tr>
					<tr class="childOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="childOrgs" <?php if(isset($selectedOrgs) && in_array("CHILD", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Child Organizations</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $childOrgsCount."(".round(($childOrgsCount/$allOrgsCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($childOrgsCount)) echo round(($childOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($childOrgsCount)) echo $childOrgsCount; else echo 0;?></td>
					</tr>
					<tr class="otherOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" id="otherOrgs" <?php if(isset($selectedOrgs) && in_array("OTHER", $selectedOrgs)) echo "checked='checked'"; else echo '';?> onclick="doSearchFilter1(-1,this)"/> Others</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $otherOrgsCount."(".round(($otherOrgsCount/$allOrgsCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($otherOrgsCount)) echo round(($otherOrgsCount/$allOrgsCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($otherOrgsCount)) echo $otherOrgsCount; else echo 0;?></td>
					</tr>
				</table>
				</div>
			</li>
			<!-- END : Organization (Parent-Child Filter) -->
		</ul>
	</form>
</div>
<script type="text/javascript">
	//	$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
		$('#categoriesContainer input:checked').each(function (index){
			$(this).parent().parent().css('background-color','#D3DFED');
		});
		
		$('#searchFiltersElements ul li table tr').click(function (){
			if($('#'+$(this).attr('class')).attr('checked')=="checked"){
				$(this).css('background-color','#ffffff');
				$('#'+$(this).attr('class')).removeAttr('checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}else{
				$(this).css('background-color','#D3DFED');
				$('#'+$(this).attr('class')).attr('checked','checked');
				$('#'+$(this).attr('class')).next().attr('checked','checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}
		});
/*		$("#searchFiltersElements ul li table tr").hover(
				function () {
					$(this).toggleClass('activeRow');
				},
				function () {
					$(this).toggleClass('activeRow');
				}
			);
*/
		var a,options;

		// Autocomplet Options for the 'org name' field
		var orgNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.organizations').html();
					var selId = $(event).children('.organizations').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#orgName').val(selText);
					$('#orgIdForAutocomplete').val(selId);
					if(event.length>20){
						//$('#orgIdForAutocomplete').val(kolId);
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		// Autocomplet Options for the 'org name' field
		var regionTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_region',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.regionTypes').html();
					var selId = $(event).children('.regionTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#regionType').val(selText);
					$('#regionTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		
		// Autocomplet Options for the 'country' field
		var countryNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.countries').html();
					var selId = $(event).children('.countries').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#country').val(selText);
					$('#countryId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		// Autocomplet Options for the 'country' field
		var stateNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names/1',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var stateId = $(event).children('.autocompleteStateId').html();
					var selText = $(event).children('.stateName').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#state').val(selText);
					$('#stateIdForAutocomplete').val(stateId);
					if(selText.length>20){
						if(selText.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	

		// Autocomplet Options for the 'city' field
		var cityNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names/1',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var cityId = $(event).children('.autocompleteCityId').html();
					var selText = $(event).children('.cityName').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#city').val(selText);
					$('#cityIdForAutocomplete').val(cityId);
					if(selText.length>20){
						if(selText.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
		
		// Autocomplet Options for the 'org type' field
		var orgTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>organizations/get_org_types',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.orgTypes').html();
					var selId = $(event).children('.orgTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#orgType').val(selText);
					$('#orgTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};	
if(js_files_loaded){
		$(document).ready(function(){
			// Trigger the Autocompleter for 'Role' field of  Event'
		
			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#orgName').autocomplete(orgNameAutoCompleteOptions);

			a = $('#regionType').autocomplete(regionTypeAutoCompleteOptions);
			
			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#country').autocomplete(countryNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#state').autocomplete(stateNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'city' field of  Event'
			a = $('#city').autocomplete(cityNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#orgType').autocomplete(orgTypeAutoCompleteOptions);
			
			$('.autocomplete').click(function(){
				//doSearchFilter1(-1);
			});

			
			$('#orgName').focus(function(){
				$('#orgName').val(' ');
			});
			       
			$('#orgName').blur(function(){
				$('#orgName').val('Enter Org Name');
			});
			$('#regionType').focus(function(){
			    $('#regionType').val(" ");
			    });
			            
			$('#regionType').blur(function(){
			    $('#regionType').val('Enter Global Region');
			    });
			$('#country').focus(function(){
				$('#country').val(' ');
			});
			       
			$('#country').blur(function(){
				$('#country').val('Enter Country');
			});

			$('#state').focus(function(){
				$('#state').val(' ');
			});
			       
			$('#state').blur(function(){
				$('#state').val('Enter State');
			});

			$('#city').focus(function(){
				$('#city').val(' ');
			});
			       
			$('#city').blur(function(){
				$('#city').val('Enter City');
			});

			$('#orgType').focus(function(){
				$('#orgType').val(' ');
			});
			       
			$('#orgType').blur(function(){
				$('#orgType').val('Enter Org Type');
			});

			if($('#country').val()=='Enter Country' || $('#state').val()=='Enter State' || $('#city').val()=='Enter City' || $('#orgType').val()=='Enter Org Type'){
				$('.autocompleteInputBox').css({color:'grey'});
			}
			
	});
}
/*
		// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
			var parentId=$(thisEle).parent().attr("id");
			if($(thisEle).hasClass('expanded')){
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				$('#searchLeftBar #'+parentId+' ul').hide();
			}
			else {
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
				$('#searchLeftBar #'+parentId+' ul').show();
			}
		}

		//uncheck all the checkbox and reload the filtered results
		function resetFilters(){
			$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
				$(this).removeAttr('checked');
			});
			$.each($("#categoriesContainer input[type='text']"), function() {
				$(this).val('');
			});

			$(".hiddenSearchField").each(function(){
				$(this).val('');
			});
						
			doSearchFilter1(-1);		
		}
*/
</script>