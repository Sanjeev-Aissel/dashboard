 <?php
 $optionValues	= array (
							1=>'Not Met',
							2=>'Partially Met',
							3=>'Fully Met',
							4=>'Exceeds'
						);
				  $scoreArray = array('N/A' => 0, 'Not Met'=>1,
							'Partially Met'=>2,
							'Fully Met'=>3,
							'Exceeds'=>4);		
?>
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	
/*	#addCoaching{
		width: 805px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
	}*/

table{
 font-size:14px;   
}
	legend {
	    color: #626262;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		background-color:#C4D8EF;
		/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -274px transparent;*/
		color: #4D7BD6;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	select.chosenMultipleSelect, select.chosenSelect{
		width:200px;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.scoreContainer{
		color:#4D7BD6;
	}
</style>

<h3 style="margin-bottom:20px">Customer Engagement Form</h3>
	<table style="margin-top:10px;">
		<tr>
			<th class="alignRight">Engagement ID :</th>
			<td><?php   echo $coachingDetails[0]['generic_id'] ?></td>
			
		</tr>
		<tr>
			<th style="margin-left:13px;" ><span style='margin-left:09px;'>MSL/MML Name:</th>
			<td><?php  echo  $coachingDetails[0]["username"] ?></td>
			<td>&nbsp;</td>
			<th class="alignRight"> <span style='margin-left:33px;'>Date:</th>
			<td><?php echo  $coachingDetails[0]["date"] ?></td>
		</tr>
		<tr>
			<th class="alignRight">Therapeutic Area:</th>
			<td><?php echo  $coachingDetails[0]["specialty"] ?></td>
			<td>&nbsp;</td>
			<th class="alignRight"><?php echo lang("HCP");?> Name(s):</th>
                        <td ><?php echo  $coachingDetails[0]["kol_id"] ?></td>
		</tr>
		<tr>
			<th class="alignRight"><span style='margin-left:10px;'>Engagement Status:</th>
			<td><?php echo  $coachingDetails[0]["status"] ?></td>
			<td>&nbsp;</td>

		</tr>
	</table><br/><br/>

	<fieldset style="border-color:#4D7BD6;">
		<legend style="color:#4D7BD6;">Evaluation Details</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter">Weight</th><th class="alignCenter">Topic</th><th class="alignCenter" style="width: 50px;">Evaluation (use scale below)</th>
			</tr>
			<tr class="tableSubHeader">
				<th>25%</th>
				<th>Planning and Preparation</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Has a firm understanding of KDMs, their role within health system and their sphere of influence</td>
				<td>
					
						<?php 
						if(isset($optionValues[$coachingDetails[0]['plan_topic1']])){
							echo $optionValues[$coachingDetails[0]['plan_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Has a detailed understanding of KDM needs and drivers of decision making</td>
				<td>
					
						
                                    
						<?php 
						if(isset($optionValues[$coachingDetails[0]['plan_topic2']])){
							echo $optionValues[$coachingDetails[0]['plan_topic5']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Clearly identifies objective(s) prior to meeting</td>
				<td>
					
					<?php 
						if(isset($optionValues[$coachingDetails[0]['plan_topic3']])){
							echo $optionValues[$coachingDetails[0]['plan_topic2']];
						}else{
							echo 'N/A';
						}
					?>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified available tools, resources and support needed for use with KDM</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails[0]['plan_topic4']])){
							echo $optionValues[$coachingDetails[0]['plan_topic3']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified and prepared for potential KDM questions that may arise during interaction</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['plan_topic5']])){
							echo $optionValues[$coachingDetails[0]['plan_topic4']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
                 <th ></th><th align="left">Over All Score</th>
				
                                <td><?php  $key = array_search( $coachingDetails[0]['planscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			<tr class="tableSubHeader">
				<th>10%</th>
				<th>Rapport Building Dialogue</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively connected/reconnected with KDM to establish constructive environment for engagement</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails[0]['open_topic1']])){
							echo $optionValues[$coachingDetails[0]['open_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Effectively set the tone and communicated objective(s) of interaction</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails[0]['open_topic2']])){
							echo $optionValues[$coachingDetails[0]['open_topic2']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
         <th ></th><th  align="left">Over All Score</th>
				
                                 <td><?php  $key = array_search( $coachingDetails[0]['openscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			<tr class="tableSubHeader">
				<th>50%</th>
				<th>Medical Dialogue</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively listened to KDM and understood their issues, concerns, and medical needs within health system</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic1']])){
							echo $optionValues[$coachingDetails[0]['med_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified the barriers for care delivery through effective engagement and dialogue with KDM</td>
				<td>
					
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic2']])){
							echo $optionValues[$coachingDetails[0]['med_topic2']];
						}else{
							echo 'N/A';
						}
					?>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Asked questions to gain better understanding of health care system and landscape including patient flow and other KDM influencers</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic3']])){
							echo $optionValues[$coachingDetails[0]['med_topic3']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Discussed and shared ideas with KDM that appropriately addressed barriers to care delivery within health system through evidence application</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic4']])){
							echo $optionValues[$coachingDetails[0]['med_topic4']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Competently shared product and disease state information including appropriate use of FMA resources and tools
	</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic5']])){
							echo $optionValues[$coachingDetails[0]['med_topic5']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Responded appropriately to unsolicited KDM requests for information including use of FMA resources and tools</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic6']])){
							echo $optionValues[$coachingDetails[0]['med_topic6']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                          <tr>
				<td></td>
				<td>Respectfully challenged KDM when faced with positions that go against evidence based data and its appropriate application</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails[0]['med_topic7']])){
							echo $optionValues[$coachingDetails[0]['med_topic7']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
          <th ></th><th  align="left">Over All Score</th>
				
                                  <td><?php  $key = array_search( $coachingDetails[0]['medscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
                        
			
                        
                        
                        
                        
                        
                       
                        
                        
                        <tr class="tableSubHeader">
				<th>15%</th>
				<th>Next Steps</th>
				<th></th>
			</tr>
                       
			<tr>
				<td></td>
				<td>Reviewed action items including questions that need follow-up at conclusion of interaction</td>
				<td>
					
							
                                       <?php 
						if(isset($optionValues[$coachingDetails[0]['wrap_topic1']])){
							echo $optionValues[$coachingDetails[0]['wrap_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td >Identified and reported medical insights gleaned from interaction within 5 business days</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails[0]['wrap_topic2']])){
							echo $optionValues[$coachingDetails[0]['wrap_topic2']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Took appropriate steps to secure a follow up appointment to address action items including scheduling of educational presentations and/or collaborative opportunities</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails[0]['wrap_topic3']])){
							echo $optionValues[$coachingDetails[0]['wrap_topic3']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Completed MIRF including documenting unsolicited customer requests for off-label information consistent with company policies</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails[0]['wrap_topic4']])){
							echo $optionValues[$coachingDetails[0]['wrap_topic4']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
         <th ></th><th  align="left">Over All Score</th>
				
                                 <td><?php  $key = array_search( $coachingDetails[0]['wrapscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			
                        <tr>
                        <th style="width:80px !important;" >Evaluated By:</th>
			<td><?php echo $this->session->userdata('user_full_name');?></td>
                        </tr>
                        <tr>
                        <th style="width:80px !important;" >Comment:</th>
                        <td><?php echo $coachingDetails[0]['comment']?></td>
                        </tr>
		</table>
	</fieldset><br/><br/><br/>
	
        
        <fieldset style="border-color:#4D7BD6;">
		<legend style="color:#4D7BD6;">Anchor</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter" style="width:10px;">Rank</th><th style='width:150px;'>Values</th><th >Description</th>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Planning and Description</th>
			</tr>
			<tr>
				<td>1.</td>
				<td >Not Met</td>
				<td>
				Demonstrated little to no planning.	
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated planning was done to some degree but did not fully meet criteria and insufficient to have effective engagement with the KDM.	
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Fully met the criteria of successfully planning for a KDM meeting including appropriate research and preparation to facilitate an effective interaction.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully prepared for interaction with KDM, but also conducted additional research and preparation on the KDM’s broader interests and areas of specialty. This may extend to include other experts and key issues and findings in the field beyond the KDM.	
				</td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Rapport Building Dialogue</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not demonstrate an effective medical dialogue nor appropriately captured insights. Failed to listen and was focused on own agenda without regard to what was being said or shared. Additionally, did not ask appropriate questions to gain better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not appropriately challenge KDM where appropriate nor use available resources.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated some effort but insufficient to engage <?php echo lang("HCP");?> in an effective medical dialogue. Acknowledged views of KDM but was more focused on own agenda with only some or little regard to what was being said or shared. Made some attempt to ask questions but insufficient to gain a better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not adequately challenge KDM or fully communicate relevant disease and product information using available resources.
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Completely met the criteria for successful medical dialogue including highlighted evidenced based data and appropriate use of MSL resources to share disease and product information. Demonstrated active listening skills, asked appropriate probing questions to better understand patient flow and healthcare system to help identify issues and challenges that stand in the way of optimized care delivery. Insights gained from dialogue were sufficiently refined as applicable to <?php echo PRODUCT_NAME;?>. Appropriately and respectfully challenged KDM if their comment(s) or position(s) was/were not supported by available evidence.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully meets the criteria for successful medical dialogue but also demonstrated superior listening and probing skills to develop a thorough understanding of the KDMs issues, concerns and needs. Additionally, consistently sought opportunities to collaborate with KDM to develop health management, quality improvement, care coordination tools as well as other collaborative projects related to optimized care delivery.
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Next Steps</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not complete/adjourn the meeting by providing follow-up or action items.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
Did not appropriately complete/adjourn the meeting by providing follow-up or action items in sufficient detail. Did not secure follow-up appointment nor submit medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
Completely met the criteria for successful completion/adjournment of meeting including review of follow-up and actions items, identified the plan for determining a future interaction and submitted key medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
Not only fully meets the criteria for successful completion/adjournment of meeting, but conducted a detailed review of all follow-up and actions items, identified the plan for determining a future interaction and submitted critical medical insights shortly after meeting.				</td>
			</tr>
			
		</table>
	</fieldset>