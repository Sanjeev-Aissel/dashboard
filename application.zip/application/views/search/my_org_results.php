<?php
/**
 * Page to show list of organizations as google results
 * 
 * @author Ramesh B
 * @since	2.4
 * @created: 07-06-2011
 * @package application.views.search
 */
?> 
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts =array(	'search/my_org_results',										
										'jquery/jquery.validate1.9.min'
										
			);
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
	}
</script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<style>/*    Enable Verticle separator between content and side menu list  By Laxman   */
/* #contentWrapper.span-23 {
		background-image: url("../images/verticlesep.jpg");
	    background-position: 185px 50%;
	    background-repeat: repeat-y;
	}
*/
</style>

<style type="text/css">
	.record_name{
		font-weight:bold;
		letter-spacing:1.5px
	}
	#searchResultsContainer {
		margin-top: 0px;
	}
	#checkAll {
		float: left;
		font-size:12px;
		padding-left:3px;
		width: 100px;
		text-align: left;
	}
	table.listResultSet {
		margin-top: 0px;
	}
	
	table.listResultSet tr:hover{
		background-color: #D3DFED;
	}
	tr.searchPagination:hover{
		background-color: white;
	}
	tr.selectedRow{
		background:#d8dfea repeat-x scroll 50% 50% !important;
	}
	.loadingIndicator {
		background-image: url("<?php echo base_url();?>images/ajax-loader-round.gif");
		background-position:center;
		background-repeat:no-repeat;
		position:absolute;
		top:250px;
		left:550px;
		height: 75px;
		width: 75px;
	}
	.blockUI .blockMsg .blockPage {
		border: 0px;
	}
	
	#searchResultsContainer .searchResultsMsg {
		padding-right:0px;
		margin-right: 0px;
	    border-bottom: 1px solid #BBBBBB;
	    border-top: 1px solid #BBBBBB;
	    padding-bottom: 7px;
	}
	#searchResultsContainer table, table.listResultSet{
		padding:0px;
	}
	#list{
		clear:left;
	}
	#excelExport{
		text-align: right;
		float: right;
	}
	.extraOptions{
	    height: 23px;
	}
	
	#profileType_chzn{
		font-size: 12px;
		width: 107px; 
		/*margin-left: 8px; */
		margin-top: 1px;
	}
	#profileType_chzn a.chzn-single{
		height: 18px;
		line-height: 18px;
	}
	.chzn-container-single .chzn-single div{
		top: -3px;
	}
/*	.chzn-container .chzn-results li{
		padding: 3px 4px;
		line-height: 12px;
	}
*/
	.chzn-drop{
		min-width: 106px !important;
		min-width: 100px\9  !important;
	}
	select#profileTypesd {
	    background: linear-gradient(#FFFFFF, #D2D3D4) repeat scroll 0 0 transparent;
	    border: 1px solid #D4D5D6;
	    border-radius: 3px 3px 3px 3px;
	    color: #0070BD;
	    font-size: 12px;
	    margin-left: 10px;
	    margin-top: 0px; 
	    padding: 1px;
	    width: 125px;
	    /*
	    -moz-appearance: none;
	    background: none repeat scroll 0 0 #F8F8F8;
	    border-radius: 3px 3px 3px 3px;
	    box-shadow: 0 0 0 #CCCCCC, 1px 1px 5px 1px #D6D6D6 inset;
	    cursor: pointer;
	    display: inline-block;
	    font-size: 12px;    
	    width: 121px; */
	}
	#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td{
		-ms-word-break: break-all;
	    word-break: break-all;
	}
	#addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_active.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
	#addFilters:HOVER #addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_inactive.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
</style>
<script type="text/javascript">	

  
 	$(document).ready(function(){
 	 	$('#profileType_chzn').live('click',function(){
 	 		moveFromCurrentStep(6);
 	 	});
 		initializeCustomToolTips();
	// Added by laxman for IE6 to change background color of tr on mouse over	
		/*
			$('table.listResultSet tr').hover (function () {
			  $(this).addClass ("rowhover");
			}, function () {
			  $(this).removeClass ("rowhover");
			});

			// To show background color clicking up on row
			$('table.listResultSet tr').click(function(){
				
				$('table.listResultSet tr').each(function(){
					if($(this).hasClass('selectedRow')){
						$(this).removeClass('selectedRow');
					}
				});
				$(this).addClass('selectedRow');
			});
*/
			//To get the Org Ids for Exporting
	//   End 
	});

	
	function orgExportExcel(){ 
		var valuesForPayrs=new Array();
		var valuesForOthers=new Array();
		$.each($("input[name='list[]']:checked"), function() {
			var type = $('#export_'+$(this).val()).val();
			
			if(type=='Payer'){
			  valuesForPayrs.push($(this).val());
			}else{
				valuesForOthers.push($(this).val());
			}
			 
		});

		if(valuesForPayrs=='' && valuesForOthers=='' ){
			jAlert('Please select atleast one Organization');
			return false;
		}
		
		if(valuesForPayrs!=''){
			window.location.href = '<?php echo base_url()?>organizations/multiple_org_export/'+valuesForPayrs+'/8';
		}

		if(valuesForOthers!=''){
			window.location.href = '<?php echo base_url()?>organizations/multiple_org_export/'+valuesForOthers+'/6';
		}
	}	
			
	function exportOrgPdf(){
		var values = new Array();
		$.each($("input[name='list[]']:checked"), function() {
		  values.push($(this).val());
		});
		if(values == ""){
			jAlert("Please select at least one Organization");
			return false;	
		}
		if(values.length > 1){
			jAlert("Multiple profiles export not allowed");
			return false;	
		}
		var profType = $("#pdf_"+values[0]).val();
		if(profType == 1){
			jAlert("Basic profiles can not export as PDF");
			return false;
		}
		
		$('#orgPdf').attr('href','<?php echo base_url();?>/organizations/export_as_pdf/'+values);
		

	}
			//var currUrl=base_url+'kols/export_pdf/'+values;
			//$("#kolPdfExport").attr("action",currUrl);
			//$('#kolPdfExport').submit();
		
	var viewTypeData = '<?php echo $this->uri->segment(3)?>';
	//Added By vivek Saved filters
	$(document).ready(function(){
		var addOrgCustomFilters={
			title: "Add Custom Filters",
			modal: true,
			autoOpen: false,
			width: 400,
			height: 400,
			dialogClass: "microView",
			draggable:false,
			open: function(){
	
			}
		};
		$( "#addOrgCustomFilters" ).dialog(addOrgCustomFilters);
	});
	function addFilters(){
		$("#addOrgCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addOrgCustomFilters').dialog("open");
		$('#addOrgCustomFiltersContainer').load(base_url+'organizations/add_org_saved_filters/');
	}
	
	function getSavedFilters(){
		$("#addOrgCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addOrgCustomFilters').dialog("open");
		$('#addOrgCustomFiltersContainer').load(base_url+'organizations/get_org_saved_filters/');
	}

	$(document).ready(function(){
			<?php if(isset($profileType) && $profileType != ''){ ?>
				var profileType = "<?php echo $profileType;?>";
				$("#profileType option[value='"+profileType+"']").attr("selected","selected");
				$("#profileType").trigger('liszt:updated');
		<?php }
			if($orgsCount==0) 
				$msgText = "No Organizations found";
			else{
				$msgText = "<div id='countMsg'>".$msg['countMsg']." </div>";
			}
		?>
			var msgText = "<?php echo $msgText;?>";
			$("#countMsg").html(msgText);
		});
</script>
		
	<?php 
		$viewType	= $this->uri->segment(3);
		//if($orgsCount!=0){
	?>
		<form id="list">
				<table class="listResultSet">
					<thead>
						<tr class="tableInfo">
							<th>
								<input type='checkbox' name='checkall' onclick='checkedAll(this);' />
							</th>
							<th colspan="<?php echo ($viewType=='list')?'7':'4';?>">
								<label><?php echo lang("Mykols.SelectAll");?></label>
								<?php 
									if(!empty($filtersApplied)){
										echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
										echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$filtersApplied.'</span> | ';
										echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
										echo '<div id="addFilters" onclick="addFilters();" style="display: inline;color: #000099;"><a href="#" rel="tooltip" title="Save all active filter selections"><div id="addFilters1" ></div></a>&nbsp;<a href="#">Save Filters</a></div>&nbsp;&nbsp;';
										echo '</div>';
									}else if(!empty($savedQueryFilterApplied)){
										echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
										echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$savedQueryFilterApplied.'</span> | <div style="display: inline;color: #000099;">'.$savedFilterName.'</div>';
										echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
										echo '&nbsp;&nbsp;';
										echo '</div>';
									}
									
								?>
								<div class="countKolMsgContainer">
									<label id="countMsg"></label>								
								</div>
							</th>
						</tr>
					</thead>
					<tbody>
					<!-- Sart of loop trough each search result, and displaying as a row result -->
						
						<?php 
						
						if($viewType=='list'){
							?>
							<style type="text/css">
								table.listResultSet tbody tr td{
									padding-top: 0px !important;
									padding-bottom: 0px !important;
								}
								#searchResultsContainer table th, table.listResultSet th{
									text-align: left;
								}
							</style>
							<tr class="headerBg">
								<th></th>
								<th></th>
								<th class="sortColumn" onclick="sortList('name');"><?php echo lang("MyLists.Name");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='name')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('type');"><?php echo lang("Overview.Type");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='type')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('state');"><?php echo lang("Surveys.State");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='state')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('country');"><?php echo lang("Surveys.City");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='country')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th><?php echo lang("Overview.Phone");?></th>
								<!--  <th><?php //echo lang("Overview.Website");?></th>-->
                                                                <th style="text-align: center !important;"><?php echo lang("Overview.Action");?></th>
							</tr>
							<?php
							$evenOrOddRow	= true;
							foreach($arrOrganiations as $organization){ 
								if($evenOrOddRow){
									$evenOrOddRow	= false;
								}else{
									$evenOrOddRow	= true;
								}
					?>
							<tr id="org<?php echo $organization['id'];?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
								<td width="3%">
									<input type="hidden" id="pdf_<?php echo $organization['id'];?>" value="<?php echo $organization['profile_type'];?>"></input>
									<input type="checkbox" name="list[]" value="<?php echo $organization['id']?>" id="list"></input>	
									<input type="hidden" name="type" value="<?php echo $organization['type']?>" id="export_<?php echo $organization['id'];?>"></input>					
								</td>
								<td width="1%"><label><div class="tooltip-demo tooltop-right orgProfile sprite_iconSet<?php echo $organization['gender'];?>" onClick="viewOrgMicroProfile('<?php echo $organization['id'];?>',event); return false;"><a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a></div></label></td>
								<td width="30%"><span class="record_name"><a href="<?php echo base_url();?>organizations/view/<?php echo $organization['id'];?>" ><?php echo $organization['name'];?></a></span></td>
								<td width="12%"><?php echo $organization['type'];?></td>
								<td width="12%"><?php echo $organization['state'];?></td>
								<td width="12%"><?php echo $organization['city'];?></td>
								<td width="10%"><?php echo '<a class="linkClickToCall" href="callto:'.$organization['phone'].'" >'.$organization['phone'].'</a>';?></td>
								<!--  <td width="20%"><a target="new" href="<?php //echo $organization['website']; ?>"><?php //echo $organization['website']; ?></a></td>-->
								<td width="20%">
									<ul class="pageRightOptions">
									<?php if($this->common_helpers->isActionAllowed('org','edit',$organization)) { ?>
										<li>
											<div class="actionIcon editIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>organizations/add_org/<?php echo $organization['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Edit"></a></div>
										</li>
									<?php } $organization['org_id'] = $organization['id']; if($this->common_helpers->isActionAllowed('org_profile_request','',$organization)) { ?> 
										<li>
											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<a class="blueButton" href="#" onclick="addNewOrgProfile(<?php echo $organization['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
											</div>
										</li>
									<?php } ?>
									</ul>
									&nbsp;
								</td>								
							</tr>
					<?php 
							}
							
						}else{
						
							$evenOrOddRow	= true; 
							foreach($arrOrganiations as $organization){
								if($evenOrOddRow){
									$evenOrOddRow	= false;
								}else{
									$evenOrOddRow	= true;
								}
						?>
							<tr id="org<?php echo $organization['id'];?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
								<td width="3%">
									<input type="hidden" id="pdf_<?php echo $organization['id'];?>" name="profType" value="<?php echo $organization['profile_type']?>"></input>
									<input type="checkbox" name="list[]" value="<?php echo $organization['id']?>" id="list"></input>
									<input type="hidden" name="type" value="<?php echo $organization['type']?>" id="export_<?php echo $organization['id'];?>"></input>						
								</td>
								<?php if($organization['company_logo'] != ''){?>
									<?php if(strpos($organization['company_logo'], ":")!=false) {?>
										<td width="5%">
											<div class="tooltip-demo tooltop-top">
												<a href="#" class="tooltipLink" rel='tooltip' title="Organization Profile Snapshot">
													<img class="defaultOrgIcon"  width="40" height="40" src="<?php echo $organization['company_logo'];?>" onClick="viewOrgMicroProfile('<?php echo $organization['id'];?>',event); return false;"/>
												</a>
											</div>
										</td>
									<?php } else {?>
										<td width="5%">
											<div class="tooltip-demo tooltop-top">
												<a href="#" class="tooltipLink" rel='tooltip' title="Organization Profile Snapshot">
													<img class="defaultOrgIcon"  width="40" height="40" src="<?php echo base_url().'images/organization_images/resized/'.$organization['company_logo'];?>" onClick="viewOrgMicroProfile('<?php echo $organization['id'];?>',event);return false;" />
												</a>
											</div>
										</td>
									<?php }?>
								<?php }
								 else{ ?>
									<td width="5%">
										<div class="tooltip-demo tooltop-top">
											<a href="#" class="tooltipLink" rel='tooltip' title="Organization Profile Snapshot">
												<img class="defaultOrgIcon" width="40" height="40" src="<?php echo base_url().'images/organisation_inactive.svg'?>"  onClick="viewOrgMicroProfile('<?php echo $organization['id'];?>',event); return false;"/>
											</a>
										</div>
									</td>
								<?php }?>		
								
								<td width="100%">
									<span class="record_name"><a href="<?php echo base_url()?>organizations/view/<?php echo $organization['id'];?>"><?php echo $organization['name']; ?></a></span>
									<?php echo "<br />"; ?>
									
									
									<?php if(isset($organization['city']))
											echo $organization['city'];
                                                                         if(isset($organization['city']) && isset($organization['state']))
										 	echo ', ';
                                                                         
//										 if($organization['country']!='' && ($organization['founded']!='') || $organization['headquarters']!='' || $organization['phone']!='')
//										 	echo ', ';
                                                                         if(isset($organization['state']))
										echo $organization['state'];
									?>
									<?php echo "<br />"; ?>
									<?php if(isset($organization['type']))
										echo $organization['type'];
									?>											
								</td>
								<!--<td width="1%"><label onClick="viewOrgMicroProfile('<?php echo $organization['id'];?>',event);"><img class="micro_view_icon" src="<?php echo base_url().'images/company-1.png'?>" /></label></td>
								-->
                                                                <td width="20%">
									<ul class="pageRightOptions">
									<li>	
									<?php if($this->common_helpers->isActionAllowed('org','edit',array('org_id' => $organization['id'],'created_by' => $organization['created_by']))) { ?>
											<div class="actionIcon editIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>organizations/add_org/<?php echo $organization['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Edit"></a></div>
									 <?php } ?>
										</li>
										<li>
                                         <?php $organization['org_id'] = $organization['id'];if($this->common_helpers->isActionAllowed('org_profile_request','',$organization)) { ?> 
											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<a class="blueButton" href="#" onclick="addNewOrgProfile(<?php echo $organization['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
											</div>
                                                        <?php } ?>
                                        </li>
									</ul>
									&nbsp;
								</td>
							</tr>
						<?php } }?>
							<tr class="searchPagination" style="background-color: white;">
								<td colspan="<?php echo ($viewType=='list')?'7':'4';?>">
									<?php 
									if($viewType=='list'){?>
										 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('list')">
										<?php 
									}else{?>
									 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('main')">	
									<?php
									} 
									$arrPaginationValues	= explode(',',PAGINATION_VALUES);
									foreach($arrPaginationValues as $key =>$value){
										if($value==$this->ajax_pagination->per_page){
											echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
										}else{
											echo '<option value="'.$value.'" >'.$value.'</option>';
										}
									}
									echo '</select> Records Per Page ';
								?>
								<?php
									$config['first_link'] = 'First';
									$config['div'] = 'searchResultsContainer'; //Div tag id
									$urlPrfix="";
									if($searchType=='simple')
										$urlPrfix="filter_search_organizations";
									$config['base_url'] = base_url()."organizations/".$urlPrfix;
									$config['total_rows'] = $orgsCount;
									$config['per_page'] = $this->ajax_pagination->per_page;
									$config['postVar'] = 'page';
									
									$this->ajax_pagination->initialize($config);
									print $this->ajax_pagination->create_links();
								?>		
								</td>
							</tr>
					</tbody>
				</table>
			</form>
		<?php //}?>
<!-- Container to add Custom filters -->
<div id="addOrgCustomFilters1"></div>
<div id="addOrgCustomFilters" class="addCustomFilters">
	<div id="addOrgCustomFiltersContainer" class="profileContent"></div>
</div>