<?php

/*
 * Controller for the new module 'KOL Rating'
 *
 * @Author : Laxman K
 * @since : KOLM v3.7 Abbott 1.0
 * Created on : 17-03-2012
 *
 */
class Coachings extends Controller {
	private $loggedUserId = null;
	private $arrComplianceLocations = array (
			'KTL - Office (Medical Center)',
			'KTL - Office (Non-Medical Center)',
			'Advisory Board',
			'Offsite (Meal)',
			'Offsite (Non-Meal)',
			'Congress',
			'Speaker Program',
			'Investigator Meeting',
			'Other' 
	);
	
	// constructor to initialize the data
	function Coachings() {
		parent::Controller ();
		// $this->output->enable_profiler(TRUE);
		
		$this->load->model ( 'coaching' );
		$this->load->model ( 'kol' );
		$this->load->model ( 'interaction' );
		$this->load->model ( 'Client_User' );
		$this->load->model ( 'country_helper' );
		$this->load->model ( 'common_helpers' );
		$this->loggedUserId = $this->session->userdata ( 'user_id' );
	}
	function index() {
		$this->list_coachings ();
	}
	function get_managers() {
		$result = $this->coaching->getManagers ();
		return $result;
	}
	function export_compliance_details($kolId = null) {
		$fileName = "Compliance_Monitoring_Form"; //
		$arrCompliances = array ();
		
		$arrCompliances [0] = array (
				'Id',
				'Date',
				'Interaction type',
				'HCP/HCO',
				'FMA',
				'Monitored By',
				'Compliance violation',
				'Recorded By' 
		);
		$complianceIds = $this->input->post ( 'compliance_ids' );
		
		$arrComplianceIds = explode ( ',', $complianceIds );
		$filters = $this->input->post ( 'grid_filter' );
		
		$arrFilters = stripslashes ( $filters );
		$arrFilters = str_replace ( '"{', '{', $arrFilters );
		$arrFilters = str_replace ( '}"', '}', $arrFilters );
		$arrFilters = trim ( $arrFilters, '"' );
		
		if ($arrComplianceResults = $this->coaching->exportCompliance ( $arrComplianceIds, $arrFilters )) {
			
			foreach ( $arrComplianceResults as $arrComplianceResult ) {
				$arrCompliance [0] = $arrComplianceResult ['generic_id'];
				$arrCompliance [1] = $arrComplianceResult ['date'];
				$arrCompliance [2] = $arrComplianceResult ['interaction_type'];
				$arrCompliance [3] = preg_replace ( '/<\/?a[^>]*>/', '', $arrComplianceResult ['kols'] );
				$arrCompliance [4] = $arrComplianceResult ['monitored_by_name'];
				$arrCompliance [5] = $arrComplianceResult ['manager_name'];
				$arrCompliance [6] = $arrComplianceResult ['compliance_violation'];
				$arrCompliance [7] = $arrComplianceResult ['created_user'];
				
				$arrCompliances [] = $arrCompliance;
			}
		}
		// pr($arrInteractions);
		$this->load->plugin ( 'phpxls/writer' );
		if (IS_IPAD_REQUEST) {
			
			$path = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/kol_personal_documents/" . $fileName . ".xls";
			$workbook = new Spreadsheet_Excel_Writer ( $path );
		} else {
			$workbook = new Spreadsheet_Excel_Writer ();
		}
		
		$format_und = & $workbook->addFormat ();
		$format_und->setBottom ( 2 ); // thick
		$format_und->setBold ();
		$format_und->setColor ( 'black' );
		$format_und->setFontFamily ( 'Calibri' );
		$format_und->setAlign ( 'centre' );
		$format_und->setSize ( 12 );
		
		$format_reg = & $workbook->addFormat ();
		// $format_reg->setBorder(1);
		$format_reg->setHAlign ( 'left' );
		$format_reg->setVAlign ( 'vcentre' );
		$format_reg->setColor ( 'black' );
		$format_reg->setFontFamily ( 'Arial' );
		$format_reg->setSize ( 10 );
		
		$excelFilters = $this->input->post ( 'filters' );
		$filters = array ();
		if ($excelFilters != '')
			$arrFilters = explode ( ",", $excelFilters );
		$filterHeaders [0] = 'Filter Name';
		$filterHeaders [1] = 'Filter Value';
		$filters [] = $filterHeaders;
		foreach ( $arrFilters as $filter ) {
			if ($filter != '') {
				$filterRow = array ();
				$filterRowElements = explode ( ":", $filter );
				$filterName = trim ( $filterRowElements [0] );
				$filterRow [0] = '';
				$filterNameElements = explode ( "_", $filterName );
				foreach ( $filterNameElements as $value ) {
					$filterRow [0] .= ucfirst ( $value ) . " ";
				}
				$filterRow [1] = trim ( $filterRowElements [1] );
				$filters [] = $filterRow;
			}
		}
		
		$arr = array (
				'Compliance Details' => $arrCompliances,
				'Filters' => $filters 
		);
		
		foreach ( $arr as $wbname => $rows ) {
			
			$rowcount = count ( $rows );
			$colcount = count ( $rows [0] );
			
			$worksheet = & $workbook->addWorksheet ( $wbname );
			// Setting the column width for 'COMPANY OVERVIEW' Sheet
			if ($wbname == 'Compliance Details') {
				$worksheet->setColumn ( 0, 0, 40 ); // setColumn(startcol,endcol,float)
				$worksheet->setColumn ( 1, 1, 40.00 );
				$worksheet->setColumn ( 2, 2, 20.00 );
				$worksheet->setColumn ( 3, 3, 25.00 );
				$worksheet->setColumn ( 4, 4, 25.00 );
				$worksheet->setColumn ( 5, 5, 30.00 );
			}
			if ($wbname == 'Filters') {
				$worksheet->setColumn ( 0, 0, 25 );
				$worksheet->setColumn ( 1, 1, 25 );
			}
			
			for($j = 0; $j < $rowcount; $j ++) {
				for($i = 0; $i < $colcount; $i ++) {
					$fmt = & $format_reg;
					
					if ($j == 0) {
						$fmt = & $format_und;
					}
					if (isset ( $rows [$j] [$i] )) {
						$data = $rows [$j] [$i];
						$worksheet->write ( $j, $i, $data, $fmt );
					}
				}
			}
		}
		
		// if($kolId != null){
		// $kolDetails = $this->kol->getKolName($kolId);
		// $kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
		// $fileName = $userName."_".$kolName."_interactions";
		// }
		// $fileName = "Compliance Form" . "_" . date('m/d/y');
		// for downloading the file
		if (IS_IPAD_REQUEST) {
			$workbook->close ();
			return $path;
		} else {
			$workbook->send ( $fileName . '.xls' );
		}
		$workbook->close ();
	}
	function complianceMapping() {
		$this->coaching->complianceMapping ();
	}
	function interactionMapping() {
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		$this->coaching->interactionMapping ();
	}
	function mapping() {
		$this->coaching->mapping ();
	}
	function send_email_for_export_compliance() {
		$config ['protocol'] = PROTOCOL;
		$config ['smtp_host'] = HOST;
		$config ['smtp_port'] = PORT;
		$config ['smtp_user'] = USER;
		$config ['smtp_pass'] = PASS;
		$config ['mailtype'] = 'html';
		$this->load->library ( 'email', $config );
		$this->email->set_newline ( "\r\n" );
		$this->email->initialize ( $config );
		$this->email->clear ();
		$this->email->set_newline ( "\r\n" );
		$this->email->from ( USER, SENDER );
		// $this->email->to("shrutip@aissel.com");
		
		$loggedInUserName = $this->session->userdata ( 'user_full_name' );
		
		$loggedInUserName = substr ( $loggedInUserName, 0, strpos ( $loggedInUserName, ' ' ) );
		$messageBody = "Hi $loggedInUserName, <br/><br/> Attached is the export of Compliance report data from " . PRODUCT_NAME . ".";
		
		$loggedInUserEmail = $this->session->userdata ( 'email' );
		$this->email->to ( $loggedInUserEmail );
		$this->email->message ( $messageBody );
		$this->email->subject ( PRODUCT_NAME . ":Compliance" );
		
		// $this->email->message("hjkh");
		$path = $this->export_compliance_details ();
		
		$this->email->attach ( $path );
		
		if ($this->email->send ()) {
			$emailData ['status'] = 'Excel has been mailed successfully';
			unlink ( $path );
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email Sent',
					'status' => 'success',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_compliance',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
		} else {
			$emailData ['status'] = 'Mail not sent';
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email Failed',
					'status' => 'fail',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_compliance',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
		}
		// echo $this->email->print_debugger();
		echo $emailData ['status'];
		// return $emailData;
	}
	function send_email_for_export() {
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		// error_reporting(E_ALL);
		$config ['protocol'] = PROTOCOL;
		$config ['smtp_host'] = HOST;
		$config ['smtp_port'] = PORT;
		$config ['smtp_user'] = USER;
		$config ['smtp_pass'] = PASS;
		$config ['mailtype'] = 'html';
		$this->load->library ( 'email', $config );
		$this->email->set_newline ( "\r\n" );
		$this->email->initialize ( $config );
		$this->email->clear ();
		$this->email->set_newline ( "\r\n" );
		$this->email->from ( USER, SENDER );
		// $this->email->to("shrutip@aissel.com");
		$loggedInUserName = $this->session->userdata ( 'user_full_name' );
		$loggedInUserName = substr ( $loggedInUserName, 0, strpos ( $loggedInUserName, ' ' ) );
		$messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of Field Coaching report data from ' . PRODUCT_NAME . '.';
		$loggedInUserEmail = $this->session->userdata ( 'email' );
		$this->email->to ( $loggedInUserEmail );
		$this->email->message ( $messageBody );
		$this->email->subject ( PRODUCT_NAME . ": Field Coaching" );
		
		// $this->email->message("hjkh");
		$path = $this->export_coaching_details ();
		$this->email->attach ( $path );
		$this->email->set_crlf ( "\r\n" );
		if ($this->email->send ()) {
			$emailData ['status'] = 'Excel has been mailed successfully';
			unlink ( $path );
			link ( $path );
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email Sent',
					'status' => 'success',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_compliance',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
		} else {
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email Sent',
					'status' => 'success',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_compliance',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			$emailData ['status'] = 'Mail not sent';
		}
		// echo $this->email->print_debugger();
		echo $emailData ['status'];
		// return $emailData;
	}
	function export_coaching_details($kolId = null) {
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		$fileName = "Field_Coaching_Form";
		$filters = $this->input->post ( 'grid_filter' );
		
		$arrFilters = stripslashes ( $filters );
		$arrFilters = str_replace ( '"{', '{', $arrFilters );
		$arrFilters = str_replace ( '}"', '}', $arrFilters );
		$arrFilters = trim ( $arrFilters, '"' );
		
		$arrCoachings = array ();
		
		$arrCoachings [0] = array (
				'Id ',
				'MSL Name',
				'Therapeutic Area',
				'Engagement Status',
				'Recorded Date',
				'KTL Name(s)',
				'Evaluated By' 
		);
		$coachingIds = $this->input->post ( 'coaching_ids' );
		
		$arrCoachingsIds = explode ( ',', $coachingIds );
		
		if ($arrCoachingsResults = $this->coaching->exportCoaching ( $arrCoachingsIds, $arrFilters )) {
			
			foreach ( $arrCoachingsResults as $arrCoachingsResult ) {
				$arrCoaching [0] = $arrCoachingsResult ['generic_id'];
				$arrCoaching [1] = $arrCoachingsResult ['username'];
				$arrCoaching [2] = $arrCoachingsResult ['specialty'];
				$arrCoaching [3] = $arrCoachingsResult ['status'];
				$arrCoaching [4] = $arrCoachingsResult ['date'];
				$arrCoaching [5] = preg_replace ( '/<\/?a[^>]*>/', '', $arrCoachingsResult ['kol_id'] );
				$arrCoaching [6] = $arrCoachingsResult ['evaluated_by'];
				
				$arrCoachings [] = $arrCoaching;
			}
		}
		// pr($arrInteractions);
		$this->load->plugin ( 'phpxls/writer' );
		
		if (IS_IPAD_REQUEST) {
			
			$path = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/kol_personal_documents/" . $fileName . ".xls";
			$workbook = new Spreadsheet_Excel_Writer ( $path );
		} else {
			$workbook = new Spreadsheet_Excel_Writer ();
		}
		
		$format_und = & $workbook->addFormat ();
		$format_und->setBottom ( 2 ); // thick
		$format_und->setBold ();
		$format_und->setColor ( 'black' );
		$format_und->setFontFamily ( 'Calibri' );
		$format_und->setAlign ( 'centre' );
		$format_und->setSize ( 12 );
		
		$format_reg = & $workbook->addFormat ();
		// $format_reg->setBorder(1);
		$format_reg->setHAlign ( 'left' );
		$format_reg->setVAlign ( 'vcentre' );
		$format_reg->setColor ( 'black' );
		$format_reg->setFontFamily ( 'Arial' );
		$format_reg->setSize ( 10 );
		
		$excelFilters = $this->input->post ( 'filters' );
		$filters = array ();
		if ($excelFilters != '')
			$arrFilters = explode ( ",", $excelFilters );
		$filterHeaders [0] = 'Filter Name';
		$filterHeaders [1] = 'Filter Value';
		$filters [] = $filterHeaders;
		foreach ( $arrFilters as $filter ) {
			if ($filter != '') {
				$filterRow = array ();
				$filterRowElements = explode ( ":", $filter );
				$filterName = trim ( $filterRowElements [0] );
				$filterRow [0] = '';
				$filterNameElements = explode ( "_", $filterName );
				foreach ( $filterNameElements as $value ) {
					$filterRow [0] .= ucfirst ( $value ) . " ";
				}
				$filterRow [1] = trim ( $filterRowElements [1] );
				$filters [] = $filterRow;
			}
		}
		
		$arr = array (
				'Coaching Details' => $arrCoachings,
				'Filters' => $filters 
		);
		
		foreach ( $arr as $wbname => $rows ) {
			
			$rowcount = count ( $rows );
			$colcount = count ( $rows [0] );
			
			$worksheet = & $workbook->addWorksheet ( $wbname );
			// Setting the column width for 'COMPANY OVERVIEW' Sheet
			if ($wbname == 'Coaching Details') {
				$worksheet->setColumn ( 0, 0, 40 ); // setColumn(startcol,endcol,float)
				$worksheet->setColumn ( 1, 1, 40.00 );
				$worksheet->setColumn ( 2, 2, 20.00 );
				$worksheet->setColumn ( 3, 3, 25.00 );
				$worksheet->setColumn ( 4, 4, 25.00 );
				$worksheet->setColumn ( 5, 5, 30.00 );
			}
			if ($wbname == 'Filters') {
				$worksheet->setColumn ( 0, 0, 25 );
				$worksheet->setColumn ( 1, 1, 25 );
			}
			
			for($j = 0; $j < $rowcount; $j ++) {
				for($i = 0; $i < $colcount; $i ++) {
					$fmt = & $format_reg;
					
					if ($j == 0) {
						$fmt = & $format_und;
					}
					if (isset ( $rows [$j] [$i] )) {
						$data = $rows [$j] [$i];
						$worksheet->write ( $j, $i, $data, $fmt );
					}
				}
			}
		}
		
		// if($kolId != null){
		// $kolDetails = $this->kol->getKolName($kolId);
		// $kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
		// $fileName = $userName."_".$kolName."_interactions";
		// }
		
		// for downloading the file
		
		if (IS_IPAD_REQUEST) {
			$workbook->close ();
			return $path;
		} else {
			$workbook->send ( $fileName . '.xls' );
		}
		$workbook->close ();
	}
	function add_coaching($userId = '', $interactionId) {
		$interactionDetails = array ();
		$userRoleID = $this->session->userdata ( 'user_role_id' );
		if ($interactionId != '') {
			$arrInteractionsResults = $this->interaction->getInteractionDetails ( $interactionId );
			
			$interactionDetails ['user_id'] = $arrInteractionsResults ["created_by"];
			$interactionDetails ["kol_name"] = $arrInteractionsResults ['attendees'] ['kol_names'] [0];
			$interactionDetails ["kol_id"] = $arrInteractionsResults ['attendees'] ['kol_ids'] [0];
			$interactionDetails ["date"] = $arrInteractionsResults ['date'];
		}
		$data ['interactionDetails'] = $interactionDetails;
		
		if ($userRoleID == ROLE_MANAGER || $userRoleID == ROLE_ADMIN) {
			$clientId = $this->session->userdata ( 'client_id' );
			$data ['arrKols'] = $this->coaching->getAllKols ();
			// $data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
			$managerId = $this->session->userdata ( 'user_id' );
			$data ['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager ( $managerId );
			$data ['arrSpecialties'] = $this->coaching->getAllAreas ();
			
			$data ['arrEngagement'] = $this->coaching->getAllEngagement ();
			
			// check is coaching entry present for user
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_ADD,
					'description' => 'Add Coaching',
					'status' => 'success',
					'transaction_id' => $medicalInsightId,
					'transaction_table_id' => COACHING,
					'transaction_name' => "add coaching",
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			if ($userId != '' && $userId != 0) {
				$latestCoachingId = $this->coaching->getLatestCoachingIdByUser ( $userId );
				if ($latestCoachingId != 0) {
					$data ['coachingDetails'] = $this->coaching->editCoaching ( $latestCoachingId );
					unset ( $data ['coachingDetails'] [0] ['id'] );
					$data ['contentPage'] = 'coachings/edit_form';
					$this->load->view ( 'layouts/client_view', $data );
				} else {
					$data ['contentPage'] = 'coachings/add_form';
					$this->load->view ( 'layouts/client_view', $data );
				}
			} else {
				$data ['contentPage'] = 'coachings/add_form';
				$this->load->view ( 'layouts/client_view', $data );
			}
		} else {
			$this->list_coachings ();
		}
	}
	function save_coaching() {
		$userRoleID = $this->session->userdata ( 'user_id' );
		$arrCoaching ['username'] = $this->input->post ( 'usernames' );
		$arrCoaching ['specialty'] = $this->input->post ( 'specialty' );
		$arrCoaching ['status'] = $this->input->post ( 'status' );
		$date = $this->input->post ( 'date' );
		// list($month, $day, $year) = split('[/.-]', $date);
		$arrCoaching ['date'] = date ( "Y-m-d", strtotime ( $date ) );
		$kolIds = $this->input->post ( 'kol' );
		$kolId = implode ( ',', $kolIds );
		$kols = $this->coaching->kolNameById ( $kolId );
		$arrCoaching ['hcname'] = preg_replace ( '/<\/?a[^>]*>/', '', $kols );
		$arrCoaching ['kol_id'] = $kolId;
		$arrCoaching ['evaluated_by'] = $userRoleID;
		$arrCoaching ['plan_topic1'] = $this->input->post ( 'plan_topic1' );
		$arrCoaching ['plan_topic2'] = $this->input->post ( 'plan_topic2' );
		$arrCoaching ['plan_topic3'] = $this->input->post ( 'plan_topic3' );
		$arrCoaching ['plan_topic4'] = $this->input->post ( 'plan_topic4' );
		$arrCoaching ['plan_topic5'] = $this->input->post ( 'plan_topic5' );
		$arrCoaching ['open_topic1'] = $this->input->post ( 'open_topic1' );
		$arrCoaching ['open_topic2'] = $this->input->post ( 'open_topic2' );
		$arrCoaching ['med_topic1'] = $this->input->post ( 'med_topic1' );
		$arrCoaching ['med_topic2'] = $this->input->post ( 'med_topic2' );
		$arrCoaching ['med_topic3'] = $this->input->post ( 'med_topic3' );
		$arrCoaching ['med_topic4'] = $this->input->post ( 'med_topic4' );
		$arrCoaching ['med_topic5'] = $this->input->post ( 'med_topic5' );
		$arrCoaching ['med_topic6'] = $this->input->post ( 'med_topic6' );
		$arrCoaching ['med_topic7'] = $this->input->post ( 'med_topic7' );
		$arrCoaching ['wrap_topic1'] = $this->input->post ( 'wrap_topic1' );
		$arrCoaching ['wrap_topic2'] = $this->input->post ( 'wrap_topic2' );
		$arrCoaching ['wrap_topic3'] = $this->input->post ( 'wrap_topic3' );
		$arrCoaching ['wrap_topic4'] = $this->input->post ( 'wrap_topic4' );
		$arrCoaching ['planscore'] = $this->input->post ( 'scoreforplan' );
		$arrCoaching ['openscore'] = $this->input->post ( 'scoreforopen' );
		$arrCoaching ['medscore'] = $this->input->post ( 'scoreformed' );
		$arrCoaching ['wrapscore'] = $this->input->post ( 'scoreforwrap' );
		$arrCoaching ['totalscore'] = $arrCoaching ['planscore'] + $arrCoaching ['openscore'] + $arrCoaching ['medscore'] + $arrCoaching ['wrapscore'];
		$arrCoaching ['comment'] = $this->input->post ( 'comment' );
		$genericId = $this->common_helpers->getGenericId ( "Field Coaching Form" );
		$arrCoaching ['generic_id'] = $genericId;
		if ($lastId = $this->coaching->saveCoachings ( $arrCoaching )) {
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_SAVE,
					'description' => 'Save Coaching',
					'status' => 'success',
					'transaction_id' => $lastId,
					'parent_object_id' => $lastId,
					'user_id' => $arrCoaching ['username'],
					'manager_id' => '',
					'transaction_table_id' => COACHINGS,
					'transaction_name' => "Save coaching",
					'module' => "coaching",
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			$data ['status'] = 'success';
			$result = $this->coaching->getEmailId ( $arrCoaching ['username'] );
			$evaluator = $this->session->userdata ( "user_full_name" );
			$kolNames = $this->coaching->kolNameById ( $kolId );
			$content = 'Hi  ' . $result ['first_name'] . " " . $result ["last_name"] . ', <br/><br/>
 
This is an alert email to inform you that ' . $evaluator . '  has completed the evaluation of the Field Coaching during the interaction with ' . $kolNames . '. <br/> You can view the evaluation by clicking on the below URL. <br/>
 
<a href=' . base_url () . 'coachings/view/' . $lastId . '/>View</a> <br/>
 
Note: This is an auto generated message do not reply to this message. If you wish to report an issue, please write to support@aissel.com.';
			$sub = 'Field Coaching Evaluation Alert : ' . $kolNames . '';
			
			$this->send_mail ( $sub, $content, $result ["email"] );
		} else {
			$data ['status'] = 'unsuccess';
		}
		redirect ( 'coachings/list_coachings' );
	}
	function send_mail($sub, $content, $email) {
		$config ['protocol'] = PROTOCOL;
		$config ['smtp_host'] = HOST;
		$config ['smtp_port'] = PORT;
		$config ['smtp_user'] = USER;
		$config ['smtp_pass'] = PASS;
		$config ['mailtype'] = 'html';
		$this->load->library ( 'email', $config );
		$this->email->set_newline ( "\r\n" );
		$this->email->initialize ( $config );
		$this->email->clear ();
		$this->email->set_newline ( "\r\n" );
		$this->email->from ( USER, SENDER );
		$this->email->to ( $email );
		$this->email->subject ( preg_replace ( '/<\/?a[^>]*>/', '', $sub ) );
		$this->email->message ( $content );
		$this->email->set_crlf ( "\r\n" );
		$res = $this->email->send ();
		// echo $this->email->print_debugger();
	}
	function list_coachings() {
		$data ['coaching_add'] = $this->common_helpers->isActionAllowed ( 'coaching', 'add', $data );
		$data ['contentPage'] = 'coachings/list_coachings';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function list_coaching_grid() {
		// $this->output->enable_profiler(TRUE);
		$page = $_POST ['page'];
		$limit = $_POST ['rows']; // get how many rows we want to have into the grid
		$sidx = $_POST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_POST ['sord']; // get the direction
		$start = $limit * ($page - 1); // do not put $limit*($page - 1)
		$filterData = $_REQUEST ['filters'];
		
		$gridPageParam = array (
				"page" => $page,
				"limit" => $limit,
				"sidx" => $sidx,
				"start" => $start,
				"sord" => $sord 
		);
		$arrCoachingResult = $this->coaching->listCoaching ( NULL, $filterData, $gridPageParam, false );
		$count = $this->coaching->listCoaching ( NULL, $filterData, $gridPageParam, true );
		// pr($arrCoachingResult);exit;
		foreach ( $arrCoachingResult as $row ) {
			$row ['eAllowed'] = $this->common_helpers->isActionAllowed ( 'coaching', 'edit', $row );
			$row ['dAllowed'] = $this->common_helpers->isActionAllowed ( 'coaching', 'delete', $row );
			$arrCoaching [] = $row;
		}
		$count = $count [0] ['count'];
		// $count = sizeof($arrCoaching);
		
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrCoaching;
		echo json_encode ( $data );
	}
	function export_pdf($id) {
		$data ['coachingDetails'] = $this->coaching->listCoaching ( $id );
		$content = $this->load->view ( 'coachings/pdf_view_coaching', $data, TRUE );
		
		ini_set ( 'memory_limit', "800M" );
		$this->load->plugin ( 'export_pdf' );
		$filename = 'Field Coaching Form';
		pdf_create ( $content, $filename );
	}
	function export_pdf_compliance($id) {
		$aarData = $this->coaching->listCompliance ( $id );
		$data ['arrData'] = $aarData [0];
		$data ["id"] = $id;
		$data ['managerId'] = $this->coaching->getManagerId ( $id );
		$data ["managers"] = $this->get_managers ();
		$data ['arrKOLs'] = $this->coaching->getComplianceKOLs ( $id );
		$data ['arrLocations'] = $this->coaching->getComplianceStateCityId ( $id );
		foreach ( $data ['arrLocations'] [0] as $values ) {
			$arrLocation [] = $values;
		}
		$data ['arrCity'] = $this->Country_helper->getCitiesByStateId ( $arrLocation [0] );
		
		$data ['arrStates'] = $this->Country_helper->getStatesByCountryId ( 254 );
		$data ['arrTopics'] = $this->coaching->getComplianceTopics ( $id );
		$data ['arrOrgs'] = $this->coaching->getComplianceOrgs ( $id );
		$data ['arrTopicInt'] = $this->coaching->getInteractionTopics ();
		$data ['arrTypeInt'] = $this->coaching->getInteractionTypes ();
		$data ['arrProductInt'] = $this->coaching->getInteractionProdcuts ();
		
		$data ['arrLocations'] = $this->arrComplianceLocations;
		
		$content = $this->load->view ( 'coachings/pdf_view_compliance', $data, TRUE );
		ini_set ( 'memory_limit', "800M" );
		$this->load->plugin ( 'export_pdf' );
		$filename = 'Compliance Monitoring Form';
		pdf_create ( $content, $filename );
	}
	function view($id) {
		$data ['coachingDetails'] = $this->coaching->listCoaching ( $id );
		$data ['contentPage'] = 'coachings/view_form';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function edit_coaching($id) {
		$userRoleID = $this->session->userdata ( 'user_role_id' );
		if ($userRoleID == ROLE_MANAGER || $userRoleID == ROLE_ADMIN) {
			$clientId = $this->session->userdata ( 'client_id' );
			$data ['arrKols'] = $this->coaching->getAllKols ();
			// $data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
			$managetId = $this->session->userdata ( 'user_id' );
			
			// $data['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager($managetId);
			$data ['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager ( $managetId, false );
			
			$userIds = array ();
			foreach ( $data ['arrClientUsers'] as $key => $row ) {
				$userIds [] = $row ['id'];
			}
			$data ['arrSpecialties'] = $this->coaching->getAllAreas ();
			$data ['coachingDetails'] = $this->coaching->editCoaching ( $id );
			
			if (! in_array ( $data ['coachingDetails'] [0] ['username'], $userIds )) {
				$userName = $this->common_helpers->getUserName ( $data ['coachingDetails'] [0] ['username'] );
				$details = explode ( " ", $userName );
				
				$data ['arrClientUsers'] [] = array (
						"first_name" => $details [0],
						"last_name" => $details [2],
						"id" => $data ['coachingDetails'] [0] ['username'] 
				);
			}
			$data ['contentPage'] = 'coachings/edit_form';
			$this->load->view ( 'layouts/client_view', $data );
		} else {
			$this->list_coachings ();
		}
	}
	function update_coaching() {
		$userRoleID = $this->session->userdata ( 'user_id' );
		$arrCoaching ['id'] = $this->input->post ( 'id' );
		$arrCoaching ['username'] = $this->input->post ( 'usernames' );
		$arrCoaching ['specialty'] = $this->input->post ( 'specialty' );
		$arrCoaching ['status'] = $this->input->post ( 'status' );
		$date = $this->input->post ( 'date' );
		// list($month, $day, $year) = split('[/.-]', $date);
		$arrCoaching ['date'] = date ( "Y-m-d", strtotime ( $date ) );
		$kolIds = $this->input->post ( 'kol' );
		$kolId = implode ( ',', $kolIds );
		$kols = $this->coaching->kolNameById ( $kolId );
		$arrCoaching ['hcname'] = preg_replace ( '/<\/?a[^>]*>/', '', $kols );
		$arrCoaching ['kol_id'] = $kolId;
		$arrCoaching ['evaluated_by'] = $userRoleID;
		$arrCoaching ['plan_topic1'] = $this->input->post ( 'plan_topic1' );
		$arrCoaching ['plan_topic2'] = $this->input->post ( 'plan_topic2' );
		$arrCoaching ['plan_topic3'] = $this->input->post ( 'plan_topic3' );
		$arrCoaching ['plan_topic4'] = $this->input->post ( 'plan_topic4' );
		$arrCoaching ['open_topic1'] = $this->input->post ( 'open_topic1' );
		$arrCoaching ['open_topic2'] = $this->input->post ( 'open_topic2' );
		$arrCoaching ['med_topic1'] = $this->input->post ( 'med_topic1' );
		$arrCoaching ['med_topic2'] = $this->input->post ( 'med_topic2' );
		$arrCoaching ['med_topic3'] = $this->input->post ( 'med_topic3' );
		$arrCoaching ['med_topic4'] = $this->input->post ( 'med_topic4' );
		$arrCoaching ['med_topic5'] = $this->input->post ( 'med_topic5' );
		$arrCoaching ['med_topic6'] = $this->input->post ( 'med_topic6' );
		$arrCoaching ['med_topic7'] = $this->input->post ( 'med_topic7' );
		$arrCoaching ['wrap_topic1'] = $this->input->post ( 'wrap_topic1' );
		$arrCoaching ['wrap_topic2'] = $this->input->post ( 'wrap_topic2' );
		$arrCoaching ['wrap_topic3'] = $this->input->post ( 'wrap_topic3' );
		$arrCoaching ['wrap_topic4'] = $this->input->post ( 'wrap_topic4' );
		$arrCoaching ['planscore'] = $this->input->post ( 'scoreforplan' );
		$arrCoaching ['openscore'] = $this->input->post ( 'scoreforopen' );
		$arrCoaching ['medscore'] = $this->input->post ( 'scoreformed' );
		$arrCoaching ['wrapscore'] = $this->input->post ( 'scoreforwrap' );
		$arrCoaching ['totalscore'] = $arrCoaching ['planscore'] + $arrCoaching ['openscore'] + $arrCoaching ['medscore'] + $arrCoaching ['wrapscore'];
		;
		$arrCoaching ['comment'] = $this->input->post ( 'comment' );
		$arrCoaching ['plan_topic5'] = $this->input->post ( 'plan_topic5' );
		$arrCoaching ['med_topic6'] = $this->input->post ( 'med_topic6' );
		
		if ($this->coaching->updateCoachings ( $arrCoaching )) {
			$data ['status'] = 'success';
		} else {
			$data ['status'] = 'unsuccess';
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'kols',
				'type' => LOG_UPDATE,
				'description' => 'Coaching Update',
				'status' => 'success',
				'transaction_id' => $arrCoaching ['id'],
				'transaction_table_id' => COACHINGS,
				'transaction_name' => "Update Coaching",
				'form_data' => $formData,
				'user_id' => $arrCoaching ['username'],
				'manager_id' => '',
				'module' => "coaching" 
		);
		
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		redirect ( 'coachings/list_coachings' );
	}
	function medical_insight() {
		$clientId = $this->session->userdata ( 'client_id' );
		$data ['arrClientUsers'] = $this->Client_User->getUsers ( $clientId );
		$therapeuticArea = $this->coaching->getTherapeuticAreaNames ();
		$arrTemp = array ();
		foreach ( $therapeuticArea as $key => $value ) {
			$arrTemp [$value ['id']] = ($value ['name']);
		}
		$investigationalAgent = $this->coaching->getInvestigationalAgentNames ();
		$arrInvestigational = array ();
		foreach ( $investigationalAgent as $key => $value ) {
			$arrInvestigational [$value ['id']] = ($value ['name']);
		}
		$sourceType = $this->coaching->getSourceTypeNames ();
		$arrSourceType = array ();
		foreach ( $sourceType as $key => $value ) {
			$arrSourceType [$value ['id']] = ($value ['name']);
		}
		$sphereOfInfluence = $this->coaching->getSphereOfInfluenceNames ();
		$arrSphereOfInfluence = array ();
		foreach ( $sphereOfInfluence as $key => $value ) {
			$arrSphereOfInfluence [$value ['id']] = ($value ['name']);
		}
		$congressSources = $this->coaching->getCongressSources ();
		$arrCongressSources = array ();
		foreach ( $congressSources as $key => $value ) {
			$arrCongressSources [$value ['id']] = ($value ['name']);
		}
		$data ['therapeuticArea'] = $arrTemp;
		$data ['investigationalAgent'] = $arrInvestigational;
		$data ['sourceType'] = $arrSourceType;
		$data ['sphereOfInfluence'] = $arrSphereOfInfluence;
		$data ['congressSources'] = $arrCongressSources;
		$data ['contentPage'] = 'coachings/add_med_insight';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function get_congress_sources() {
		$congressSources = $this->coaching->getCongressSources ();
		echo json_encode ( $congressSources );
	}
	function save_medical_insight() {
		$arrData = array ();
		$arrData ['specialty'] = $this->input->post ( 'specialty' );
		$arrData ['agent'] = $this->input->post ( 'agent' );
		$arrData ['source_type'] = $this->input->post ( 'source_type' );
		$arrData ['product'] = $this->input->post ( 'product' );
		$arrData ['summary'] = $this->input->post ( 'summary' );
		$arrData ['topics'] = $this->input->post ( 'topics' );
		$arrData ['other'] = $this->input->post ( 'other' );
		$arrData ['sphere_of_influence'] = $this->input->post ( 'sphere_of_influence' );
		$arrData ['congress_name'] = $this->input->post ( 'congress_name' );
		$arrData ['actions_to_consider'] = $this->input->post ( 'actions_to_consider' );
		$arrData ['kol_id'] = $this->input->post ( 'kol_id' );
		$arrData ['congress_sources'] = $this->input->post ( 'congress_sources' );
		$genericId = $this->common_helpers->getGenericId ( "Medical Insight" );
		$arrData ['generic_id'] = $genericId;
		$kolId = $this->input->post ( 'kol_id' );
		$arrData ['profile_type'] = $this->input->post ( 'profile_type' );
		$medicalInsightId = $this->coaching->saveMedicalInsight ( $arrData );
		// Add Log activity
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_SAVE,
				'description' => 'Save Medical Insight',
				'status' => 'success',
				'transaction_id' => $medicalInsightId,
				'transaction_table_id' => MEDICAL_INSIGHT,
				'transaction_name' => "Save Medical Insight",
				'module' => 'Medical Insight',
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		// exit;
		if ($kolId == 0) {
			redirect ( 'coachings/list_medical_insights' );
		} else {
			redirect ( 'kols/view/' . $kolId . '/list_medical_insights' );
		}
	}
	function update_medical_insight($id) {
		$arrData = array ();
		$arrData ['id'] = $id;
		$arrData ['specialty'] = $this->input->post ( 'specialty' );
		$arrData ['agent'] = $this->input->post ( 'agent' );
		$arrData ['source_type'] = $this->input->post ( 'source_type' );
		$arrData ['product'] = $this->input->post ( 'product' );
		$arrData ['summary'] = $this->input->post ( 'summary' );
		$arrData ['topics'] = $this->input->post ( 'topics' );
		$arrData ['sphere_of_influence'] = $this->input->post ( 'sphere_of_influence' );
		$arrData ['relevance'] = $this->input->post ( 'relevance' );
		$arrData ['actions_to_consider'] = $this->input->post ( 'actions_to_consider' );
		$arrData ['other'] = $this->input->post ( 'other' );
		$arrData ['kol_id'] = $this->input->post ( 'kol_id' );
		$arrData ['congress_sources'] = $this->input->post ( 'congress_sources' );
		$arrData ['congress_name'] = $this->input->post ( 'congress_name' );
		$currentController = $this->input->post ( 'current_controller' );
		$kolId = $this->input->post ( 'kol_id' );
		$arrData ['profile_type'] = $this->input->post ( 'profile_type' );
		$this->coaching->updateMedicalInsight ( $arrData );
		$medicalInsightId = $arrData ['id'];
		// Add Log activity
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_UPDATE,
				'description' => 'Update Medical Insight',
				'status' => 'success',
				'transaction_id' => $medicalInsightId,
				'transaction_table_id' => MEDICAL_INSIGHT,
				'transaction_name' => "Update Medical Insight",
				'module' => 'Medical Insight',
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		// exit;
		if ($currentController == 'coachings') {
			redirect ( 'coachings/list_medical_insights' );
		} else {
			redirect ( 'kols/view/' . $kolId . '/list_medical_insights' );
		}
	}
	function edit_medical_insight($id) {
		$clientId = $this->session->userdata ( 'client_id' );
		$data ['arrClientUsers'] = $this->Client_User->getUsers ( $clientId );
		$data ['medicalInsightDetails'] = $this->coaching->editMedicalInsight ( $id );
		$speciltyName = $data ['medicalInsightDetails'] [0] ['specialty'];
		$therapeuticAreaId = $this->coaching->therapeuticAreaIdByName ( $speciltyName );
		foreach ( $therapeuticAreaId as $key => $value ) {
			$arrTempArea = ($value ['id']);
		}
		$data ['speciltyName'] = $arrTempArea;
		$arrProductName = $this->coaching->getProductByTheraputicArea ( $arrTempArea );
		$arrTemp1 = array ();
		foreach ( $arrProductName as $key => $value ) {
			$arrTemp1 [] = $value;
			// $arrTemp1[$value['id']] = ($value['name']);
		}
		$data ['productName'] = $arrTemp1;
		$productName = $data ['medicalInsightDetails'] [0] ['product'];
		
		$productId = $this->coaching->getProductIdByName ( $productName );
		foreach ( $productId as $key => $value ) {
			$arrTempProduct = ($value ['id']);
		}
		$arrTempKeyInsight = $this->coaching->getKeyInsightByProduct ( $arrTempProduct, $arrTempArea );
		$arrTemp2 = array ();
		foreach ( $arrTempKeyInsight as $key => $value ) {
			$arrTemp2 [$value ['id']] = ($value ['name']);
		}
		$data ['KeyInsightName'] = $arrTemp2;
		$kolID = $data ['medicalInsightDetails'] [0] ['kol_id'];
		$kolname = array ();
		$kolname = $this->kol->getKolName ( $kolID );
		$arrSalutations = array (
				1 => 'Dr.',
				2 => 'Prof.',
				3 => 'Mr.',
				4 => 'Ms.' 
		);
		$data ['arrSalutations'] = $arrSalutations;
		$arrKolDetail ['salutation'] = $arrSalutations [$kolname ['salutation']];
		$data ['arrKolDetail'] = $arrKolDetail;
		$therapeuticArea = $this->coaching->getTherapeuticAreaNames ();
		$arrTemp = array ();
		foreach ( $therapeuticArea as $key => $value ) {
			// foreach ($value as $key1 => $value1) {
			// echo $key1 ."=>". $value1."<br/>";
			$arrTemp [$value ['id']] = ($value ['name']);
			// }
		}
		$investigationalAgent = $this->coaching->getInvestigationalAgentNames ();
		$arrInvestigational = array ();
		foreach ( $investigationalAgent as $key => $value ) {
			$arrInvestigational [$value ['id']] = ($value ['name']);
		}
		$sourceType = $this->coaching->getSourceTypeNames ();
		$arrSourceType = array ();
		foreach ( $sourceType as $key => $value ) {
			$arrSourceType [$value ['id']] = ($value ['name']);
		}
		$sphereOfInfluence = $this->coaching->getSphereOfInfluenceNames ();
		$arrSphereOfInfluence = array ();
		foreach ( $sphereOfInfluence as $key => $value ) {
			$arrSphereOfInfluence [$value ['id']] = ($value ['name']);
		}
		$congressSources = $this->coaching->getCongressSources ();
		$arrCongressSources = array ();
		foreach ( $congressSources as $key => $value ) {
			$arrCongressSources [$value ['id']] = ($value ['name']);
		}
		$data ['therapeuticArea'] = $arrTemp;
		$data ['investigationalAgent'] = $arrInvestigational;
		$data ['sourceType'] = $arrSourceType;
		$data ['sphereOfInfluence'] = $arrSphereOfInfluence;
		$data ['congressSources'] = $arrCongressSources;
		$data ['kolname'] = $kolname;
		$data ['contentPage'] = 'coachings/add_med_insight';
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_EDIT,
				'description' => 'Edit medicalInsight',
				'status' => 'success',
				'transaction_id' => $id,
				'transaction_table_id' => MEDICAL_INSIGHT,
				'transaction_name' => "'Edit medicalInsight",
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		$this->load->view ( 'layouts/client_view', $data );
	}
	function list_medical_insights() {
		$managerId = $this->session->userdata ( 'user_id' );
		$data ['arrManager'] = $this->common_helpers->getAllManagersForReports ( $managerId );
		$data ['contentPage'] = 'coachings/list_medical_insights';
		$this->load->view ( 'layouts/client_view', $data );
	}
	
	// function list_medical_insight_grid(){
	// $page = $_REQUEST['page'];
	// $limit = $_REQUEST['rows'];
	// $arrCoaching = $this->coaching->listMedicalInsight();
	// $count = sizeof($arrCoaching);
	// if( $count >0 ){
	// $total_pages = ceil($count/$limit);
	// }else{
	// $total_pages = 0;
	// }
	// $data['records']= $count;
	// $data['total'] = $total_pages;
	// $data['page'] = $page;
	// $data['rows'] = $arrCoaching;
	// echo json_encode($data);
	// }
	function list_medical_insight_grid($kolId, $allUserRecords) {
		$page = $_REQUEST ['page'];
		$limit = $_REQUEST ['rows'];
		$sidx = $_POST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_POST ['sord']; // get the direction
		$start = $limit * ($page - 1); // do not put $limit*($page - 1)
		$filterData = $_REQUEST ['filters'];
		$Details = array ();
		$Details ['page'] = $page;
		$Details ['limit'] = $limit;
		$Details ['sidx'] = $sidx;
		$Details ['sord'] = $sord;
		$Details ['start'] = $start;
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchGroupOperator = $this->common_helpers->search_nested_arrays ( $arrFilter, $groupOp );
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchOper = $this->common_helpers->search_nested_arrays ( $arrFilter, $op );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		
		foreach ( $searchField as $key => $val ) {
			$Details [$val] = $searchString [$key];
		}
		// pr($Details); exit;
		// pr($start);
		// if(!$sidx) $sidx =1; // connect to the database
		$arrCoachingResult = $this->coaching->listMedicalInsight ( $limit, $start, false, $sidx, $sord, $Details, $allUserRecords, $kolId );
		
		foreach ( $arrCoachingResult as $row ) {
			$row ['eAllowed'] = $this->common_helpers->isActionAllowed ( 'medical insight', 'edit', $row );
			$row ['dAllowed'] = $this->common_helpers->isActionAllowed ( 'medical insight', 'delete', $row );
			$arrCoaching [] = $row;
		}
		
		$count = $this->coaching->listMedicalInsight ( $limit, $start, true, $sidx, $sord, $Details, $allUserRecords, $kolId );
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		
		$data ['page'] = $page;
		$data ['rows'] = $arrCoaching;
		// pr($total_pages);
		// ob_start('ob_gzhandler');
		echo json_encode ( $data );
		// echo $this->db->last_query();
		// pr($data);
	}
	function view_medical_insight($id) {
		$aarData = $this->coaching->listMedicalInsight ( '', '', '', '', '', '', '', '', $id );
		
		// pr($aarData);
		$kolID = $aarData [0] ['kol_id'];
		$kolname = array ();
		$kolname = $this->kol->getKolName ( $kolID );
		$arrSalutations = array (
				1 => 'Dr.',
				2 => 'Prof.',
				3 => 'Mr.',
				4 => 'Ms.' 
		);
		$data ['arrSalutations'] = $arrSalutations;
		$arrKolDetail ['salutation'] = $arrSalutations [$kolname ['salutation']];
		$data ['arrKolDetail'] = $arrKolDetail;
		$data ['arrData'] = $aarData [0];
		$data ['kolname'] = $kolname;
		$medicalInsightId = $id;
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_VIEW,
				'description' => 'View Medical Insight',
				'status' => 'success',
				'transaction_id' => $medicalInsightId,
				'transaction_table_id' => MEDICAL_INSIGHT,
				'transaction_name' => "ViewMedicalInsight",
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		$data ['contentPage'] = 'coachings/view_medical_insight';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function compliance($userId, $interactionId) {
		if ($interactionId != '') {
			$arrInteractionsResults = $this->interaction->getInteractionDetails ( $interactionId );
			$interactionDetails ['user_id'] = $arrInteractionsResults ["created_by"];
			$interactionDetails ["kol_name"] = $arrInteractionsResults ['attendees'] ['kol_names'] [0];
			$interactionDetails ["kol_id"] = $arrInteractionsResults ['attendees'] ['kol_ids'] [0];
			$interactionDetails ["city_id"] = $arrInteractionsResults ['city_id'];
			$interactionDetails ["state_id"] = $arrInteractionsResults ['state_id'];
			$interactionDetails ["date"] = sql_date_to_app_date ( $arrInteractionsResults ['date'] );
			;
			$interactionDetails ["employee_id"] = $arrInteractionsResults ['employee_id'];
		}
		$data ['interactionDetails'] = $interactionDetails;
		// pr($interactionDetails);
		// exit;
		// pr($interactionDetails);
		// pr($arrInteractionsResults);
		// exit;
		$arrTopics = $this->interaction->getInteractionDiscussionTopics ( $interactionId );
		// echo $this->db->last_query();
		$data ['arrInteractionsResults'] = $arrInteractionsResults;
		// pr($arrInteractionsResults);
		$data ['interactionProductTypeTopicCount'] = count ( $arrInteractionsResults ['aboutTopics'] ['product_names'] );
		if ($userId == 0) {
			$userId = '';
			$latestComlienceId = $this->coaching->getLatestComplienceIdByUser ( $userId );
		}
		if ($latestComlienceId != 0 || $interactionId != '') {
			$arrComplianceData = $this->coaching->listCompliance ( $latestComlienceId );
			// pr($arrComplianceData);
			$data ['arrComplianceData'] = $arrComplianceData [0];
			unset ( $data ['arrComplianceData'] ['id'] );
			$data ['arrComplianceKOLs'] = $this->coaching->getComplianceKOLs ( $latestComlienceId );
			
			$data ['arrComplianceOrgs'] = $this->coaching->getComplianceOrgs ( $latestComlienceId );
			
			$data ['arrCity'] = $this->Country_helper->getCitiesByStateId ( $interactionDetails ["state_id"] );
			
			// $data['arrComplianceTopics'] = $this->coaching->getComplianceTopics($id);
			if ($interactionId == '')
				$arrTopics = $this->coaching->getComplianceTopics ( $latestComlienceId );
			
			foreach ( $arrTopics as $row ) {
				$row ['type_id'] = $row ['interaction_type'];
				// pr($row);
				$arrDiscussion [] = $this->prepare_discussion_topic_data ( $row );
			}
			// pr($arrDiscussion);
			// exit;
			$data ['arrDiscussion'] = $arrDiscussion;
			foreach ( $arrTopics as $row ) {
				$row ['topics'] = $this->interaction->getTpicByProduct ( $interactionDetails ['grouping'], $row ['product_id'], $row ['objective_id'] );
				$arr [] = $row;
			}
			$data ['arrComplianceData'] ['arrSelectedTopics'] = $arr;
			$data ['arrComplianceData'] ['noOfObjectives'] = sizeOf ( $data ['arrComplianceData'] ['arrSelectedTopics'] ) - 1;
		}
		$data ["managers"] = $this->get_managers ();
		$clientId = $this->session->userdata ( 'client_id' );
		$data ['arrLocations'] = $this->arrComplianceLocations;
		// $data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
		$managetId = $this->session->userdata ( 'user_id' );
		/**
		 * Check if logged in manager is aligned to field group
		 */
		$result = $this->customer_engagement->groupAlignmentCheck ( $managetId );
		
		if ($result)
			$all = true;
		else
			$all = false;
		
		$data ['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager ( $managetId, $all );
		
		$userIds = array ();
		foreach ( $data ['arrClientUsers'] as $key => $row ) {
			$userIds [] = $row ['id'];
		}
		if (! in_array ( $interactionDetails ["employee_id"], $userIds ) && count ( $interactionDetails ) > 0) {
			$userName = $this->common_helpers->getUserName ( $interactionDetails ["employee_id"] );
			$details = explode ( " ", $userName );
			
			$data ['arrClientUsers'] [] = array (
					"first_name" => $details [0],
					"last_name" => $details [2],
					"id" => $interactionDetails ["employee_id"] 
			);
		}
		
		//
		
		// $data['arrKols'] = $this->coaching->getAllKols();
		// $data['arrOrgs'] = $this->coaching->getAllOrgs();
		$data ['arrInteractionCat'] = $this->coaching->getInteractionCat ();
		$data ['arrProduct'] = $this->common_helpers->getUserProducts ();
		// $data['arrType'] = $this->interaction->getAllTypesOfClient();
		$data ['arrStates'] = $this->Country_helper->getStatesByCountryId ( 254 );
		$data ['contentPage'] = 'coachings/add_compliance';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function save_compliance() {
		$compliance_id = $this->input->post ( 'compliance_id' );
		if ($compliance_id == null || $compliance_id == '') {
			$arrData = array ();
			$arrData ['date'] = $this->input->post ( 'date' );
			$arrData ['location'] = implode ( ', ', $this->input->post ( 'location' ) );
			$arrData ['monitored_by'] = $this->input->post ( 'monitored_by' );
			$arrData ['fma'] = $this->input->post ( 'fma' );
			$kolId = $this->input->post ( 'kol' );
			
			$arrData ['kols'] = $kolId;
			$arrData ['organization'] = $this->input->post ( 'org' );
			$arrData ['interaction_type'] = $this->input->post ( 'interaction_type' );
			$arrData ['topics'] = $this->input->post ( 'topics' );
			$arrData ['additional_topics'] = $this->input->post ( 'additional_topics' );
			$arrData ['off_label_inquiry'] = $this->input->post ( 'off_label_inquiry' );
			$arrData ['inquiry_unsolicited'] = $this->input->post ( 'inquiry_unsolicited' );
			$arrData ['response_consistancy'] = $this->input->post ( 'response_consistancy' );
			$arrData ['compliance_violation'] = $this->input->post ( 'compliance_violation' );
			$arrData ['compliance_violated_by'] = $this->input->post ( 'compliance_violated_by' );
			$arrData ['compliance_violated_by_title'] = $this->input->post ( 'compliance_violated_by_title' );
			$arrData ['compliance_violated_by_date'] = $this->input->post ( 'compliance_violated_by_date' );
			$arrData ['violation_description'] = $this->input->post ( 'violation_description' );
			$arrData ['contact_type'] = $this->input->post ( 'contact_type' );
			$arrData ['signature'] = $this->input->post ( 'hcp_signature' );
			$arrData ['state_id'] = $this->input->post ( 'state' );
			$arrData ['city_id'] = $this->input->post ( 'city' );
			$genericId = $this->common_helpers->getGenericId ( "Compliance Form" );
			$arrData ['generic_id'] = $genericId;
			// pr($arrData);
			// exit();
			
			$noOfObjectives = $this->input->post ( 'noOfObjectives' );
			$topicDeatil ['product_id'] = $this->input->post ( 'product' );
			$topicDeatil ['interaction_type'] = $this->input->post ( 'objective' );
			$topicDeatil ['topic_id'] = $this->input->post ( 'topic' );
			$topicDeatil ['sub_topic_id'] = $this->input->post ( 'subtopic' );
			$arrTopicDetail [] = $topicDeatil;
			if ($noOfObjectives >= 1) {
				for($j = 1; $j <= $noOfObjectives; $j ++) {
					if ($this->input->post ( 'topic' . $j ) != '') {
						$topicDeatil1 ['product_id'] = $this->input->post ( 'product' . $j );
						$topicDeatil1 ['interaction_type'] = $this->input->post ( 'objective' . $j );
						$topicDeatil1 ['topic_id'] = $this->input->post ( 'topic' . $j );
						$topicDeatil1 ['sub_topic_id'] = $this->input->post ( 'subtopic' . $j );
						$arrTopicDetail [] = $topicDeatil1;
					}
				}
			}
			$arrData ['topics'] = $arrTopicDetail;
			$lastId = $this->coaching->saveComplianceMonitoring ( $arrData );
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_SAVE,
					'description' => 'Save Compliance',
					'status' => 'success',
					'transaction_id' => $lastId,
					'transaction_table_id' => COMPLIANCE_MONITORING,
					'transaction_name' => "Save Compliance",
					'module' => 'Compliance',
					'parent_object_id' => '',
					'user_id' => $arrData ['fma'],
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			$result = $this->coaching->getEmailId ( $arrData ['fma'] );
			$evaluator = $this->session->userdata ( "user_full_name" );
			$kolNames = $this->coaching->kolNameById ( $kolId = implode ( ',', $kolId ) );
			$content = 'Hi  ' . $result ['first_name'] . " " . $result ["last_name"] . ', <br/><br/>
 
This is an alert email to inform you that ' . $evaluator . '  has completed the evaluation of the Field compliance Monitoring during the interaction with ' . $kolNames . '. <br/> You can view the evaluation by clicking on the below URL. <br/>
 
<a href=' . base_url () . 'coachings/view_compliance/' . $lastId . '/>View</a> <br/>
 
Note: This is an auto generated message do not reply to this message. If you wish to report an issue, please write to support@aissel.com.';
			$sub = 'Field Compliance Monitoring Alert  : ' . $kolNames . '';
			
			// pr($sub);
			// pr($content);
			// pr($result["email"]);
			// exit;
			$this->send_mail ( $sub, $content, $result ["email"] );
			// $this->send_mail($form, $content, $email);
		} else {
			$arrData = array ();
			$arrData ['date'] = $this->input->post ( 'date' );
			$arrData ['location'] = implode ( ', ', $this->input->post ( 'location' ) );
			$arrData ['monitored_by'] = $this->input->post ( 'monitored_by' );
			$kolId = $this->input->post ( 'kol' );
			$arrData ['fma'] = $this->input->post ( 'fma' );
			$arrData ['kols'] = $kolId;
			$arrData ['organization'] = $this->input->post ( 'org' );
			$arrData ['interaction_type'] = $this->input->post ( 'interaction_type' );
			$arrData ['topics'] = $this->input->post ( 'topics' );
			$arrData ['additional_topics'] = $this->input->post ( 'additional_topics' );
			$arrData ['off_label_inquiry'] = $this->input->post ( 'off_label_inquiry' );
			$arrData ['inquiry_unsolicited'] = $this->input->post ( 'inquiry_unsolicited' );
			$arrData ['response_consistancy'] = $this->input->post ( 'response_consistancy' );
			$arrData ['compliance_violation'] = $this->input->post ( 'compliance_violation' );
			$arrData ['compliance_violated_by'] = $this->input->post ( 'compliance_violated_by' );
			$arrData ['compliance_violated_by_title'] = $this->input->post ( 'compliance_violated_by_title' );
			$arrData ['compliance_violated_by_date'] = $this->input->post ( 'compliance_violated_by_date' );
			$arrData ['violation_description'] = $this->input->post ( 'violation_description' );
			$arrData ['contact_type'] = $this->input->post ( 'contact_type' );
			$arrData ['signature'] = $this->input->post ( 'hcp_signature' );
			// pr($arrData);
			// exit();
			
			$noOfObjectives = $this->input->post ( 'noOfObjectives' );
			$topicDeatil ['product_id'] = $this->input->post ( 'product' );
			$topicDeatil ['interaction_type'] = $this->input->post ( 'objective' );
			$topicDeatil ['topic_id'] = $this->input->post ( 'topic' );
			$topicDeatil ['sub_topic_id'] = $this->input->post ( 'subtopic' );
			$arrTopicDetail [] = $topicDeatil;
			if ($noOfObjectives >= 1) {
				for($j = 1; $j <= $noOfObjectives; $j ++) {
					if ($this->input->post ( 'topic' . $j ) != '') {
						$topicDeatil1 ['product_id'] = $this->input->post ( 'product' . $j );
						$topicDeatil1 ['interaction_type'] = $this->input->post ( 'objective' . $j );
						$topicDeatil1 ['topic_id'] = $this->input->post ( 'topic' . $j );
						$topicDeatil1 ['sub_topic_id'] = $this->input->post ( 'subtopic' . $j );
						$arrTopicDetail [] = $topicDeatil1;
					}
				}
			}
			$arrData ['topics'] = $arrTopicDetail;
			
			$this->coaching->deleteComplianceMonitoringKOLs ( $compliance_id );
			$this->coaching->deleteComplianceMonitoringOrganizations ( $compliance_id );
			$this->coaching->deleteComplianceMonitoringTopics ( $compliance_id );
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Update Compliance',
					'status' => 'success',
					'transaction_id' => $compliance_id,
					'transaction_table_id' => COMPLIANCE_MONITORING,
					'transaction_name' => "Update Compliance",
					'module' => 'Compliance',
					'parent_object_id' => '',
					'user_id' => $arrData ['fma'],
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			if ($this->coaching->updateComplianceMonitoring ( $arrData, $compliance_id )) {
				redirect ( 'coachings/list_compliance' );
			}
		}
		
		redirect ( 'coachings/list_compliance' );
	}
	function list_compliance() {
		$data ['compliance_add'] = $this->common_helpers->isActionAllowed ( 'coaching', 'add', $data );
		$data ['contentPage'] = 'coachings/list_compliance';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function list_compliance_grid() {
		$page = $_POST ['page'];
		$limit = $_POST ['rows']; // get how many rows we want to have into the grid
		
		$sidx = $_POST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_POST ['sord']; // get the direction
		$start = $limit * ($page - 1); // do not put $limit*($page - 1)
		$filterData = $_REQUEST ['filters'];
		// pr($filterData);
		$gridPageParam = array (
				"page" => $page,
				"limit" => $limit,
				"sidx" => $sidx,
				"start" => $start,
				"sord" => $sord 
		);
		$arrCoachingResult = $this->coaching->listCompliance ( NULL, $filterData, $gridPageParam, false );
		
		$count = $this->coaching->listCompliance ( NULL, $filterData, $gridPageParam, true );
		// pr($count);
		$count = $count [0] ['count'];
		
		// pr($arrCoachingResult);
		foreach ( $arrCoachingResult as $row ) {
			$row ['eAllowed'] = $this->common_helpers->isActionAllowed ( 'compliance', 'edit', $row );
			$row ['dAllowed'] = $this->common_helpers->isActionAllowed ( 'compliance', 'delete', $row );
			$arrCoaching [] = $row;
		}
		
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		
		// pr($count);
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrCoaching;
		echo json_encode ( $data );
	}
	function view_compliance($id) {
		$aarData = $this->coaching->listCompliance ( $id );
		$data ['arrData'] = $aarData [0];
		$data ["id"] = $id;
		$data ['managerId'] = $this->coaching->getManagerId ( $id );
		$data ["managers"] = $this->get_managers ();
		$data ['arrKOLs'] = $this->coaching->getComplianceKOLs ( $id );
		$data ['arrLocations'] = $this->coaching->getComplianceStateCityId ( $id );
		foreach ( $data ['arrLocations'] [0] as $values ) {
			$arrLocation [] = $values;
		}
		$data ['arrCity'] = $this->Country_helper->getCitiesByStateId ( $arrLocation [0] );
		
		$data ['arrStates'] = $this->Country_helper->getStatesByCountryId ( 254 );
		$data ['arrTopics'] = $this->coaching->getComplianceTopics ( $id );
		$data ['arrOrgs'] = $this->coaching->getComplianceOrgs ( $id );
		$data ['arrTopicInt'] = $this->coaching->getInteractionTopics ();
		$data ['arrTypeInt'] = $this->coaching->getInteractionTypes ();
		$data ['arrProductInt'] = $this->coaching->getInteractionProdcuts ();
		
		$data ['arrLocations'] = $this->arrComplianceLocations;
		
		// exit();
		$data ['contentPage'] = 'coachings/view_compliance';
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_VIEW,
				'description' => 'View Compliance',
				'status' => 'success',
				'transaction_id' => $id,
				'transaction_table_id' => COMPLIANCE_MONITORING,
				'transaction_name' => "View Compliance",
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		$this->load->view ( 'layouts/client_view', $data );
	}
	function delete_coaching($id) {
		$this->coaching->deleteCoaching ( $id );
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_DELETE,
				'description' => 'DELETE Coaching',
				'status' => 'success',
				'transaction_id' => $id,
				'transaction_table_id' => COACHINGS,
				'transaction_name' => "delete coaching",
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
	}
	function delete_medical_insight($id) {
		$this->coaching->deleteMedicalInsight ( $id );
	}
	function delete_compliance($id) {
		$this->coaching->deleteCompliance ( $id );
	}
	function edit_compliance($id, $reloadFlag) {
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		$clientId = $this->session->userdata ( 'client_id' );
		
		$arrComplianceData = $this->coaching->listCompliance ( $id );
		
		$data ['arrComplianceData'] = $arrComplianceData [0];
		$data ['arrComplianceKOLs'] = $this->coaching->getComplianceKOLs ( $id );
		
		$data ['arrComplianceOrgs'] = $this->coaching->getComplianceOrgs ( $id );
		$data ['arrLocations'] = $this->coaching->getComplianceStateCityId ( $id );
		foreach ( $data ['arrLocations'] [0] as $values ) {
			$arrLocation [] = $values;
		}
		$data ['arrLocationId'] = $arrLocation;
		$data ['arrCity'] = $this->Country_helper->getCitiesByStateId ( $arrLocation [0] );
		
		$data ['arrStates'] = $this->Country_helper->getStatesByCountryId ( 254 );
		// $data['arrComplianceTopics'] = $this->coaching->getComplianceTopics($id);
		$arrTopics = $this->coaching->getComplianceTopics ( $id );
		
		foreach ( $arrTopics as $row ) {
			// pr($row);
			$arrDiscussion [] = $this->prepare_discussion_topic_data ( $row );
		}
		// pr($arrDiscussion);
		// exit;
		
		if ($reloadFlag == 1)
			$data ["reloadFlag"] = 1;
		$data ['arrDiscussion'] = $arrDiscussion;
		foreach ( $arrTopics as $row ) {
			$row ['topics'] = $this->interaction->getTpicByProduct ( $interactionDetails ['grouping'], $row ['product_id'], $row ['objective_id'] );
			$arr [] = $row;
		}
		$data ['arrComplianceData'] ['arrSelectedTopics'] = $arr;
		
		$data ['arrComplianceData'] ['noOfObjectives'] = sizeOf ( $data ['arrComplianceData'] ['arrSelectedTopics'] ) - 1;
		
		$data ['arrComplianceLocations'] = $this->arrComplianceLocations;
		// pr($data['arrComplianceData']);
		
		$data ['arrLocations'] = $this->arrComplianceLocations;
		$data ['arrClientUserss'] = $this->Client_User->getUsers ( $clientId );
		
		$data ['managerId'] = $this->coaching->getManagerId ( $id );
		// pr($data['managerId']);
		// $data["managers"] = $this->get_managers();
		
		$managetId = $this->session->userdata ( 'user_id' );
		/**
		 * Check if logged in manager is aligned to field group
		 */
		$result = $this->customer_engagement->groupAlignmentCheck ( $managetId );
		
		if ($result)
			$all = true;
		else
			$all = false;
		
		$data ['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager ( $managetId, $all );
		$userIds = array ();
		foreach ( $data ['arrClientUsers'] as $key => $row ) {
			$userIds [] = $row ['id'];
		}
		
		if (! in_array ( $data ['arrComplianceData'] ['fma'], $userIds )) {
			$userName = $this->common_helpers->getUserName ( $data ['arrComplianceData'] ['fma'] );
			
			$details = explode ( " ", $userName );
			
			$data ['arrClientUsers'] [] = array (
					"first_name" => $details [0],
					"last_name" => $details [1],
					"id" => $data ['arrComplianceData'] ['fma'] 
			);
		}
		$data ["managers"] = $this->common_helpers->getTeamAllManagers ( $managetId );
		
		// $data['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager($managetId);
		$data ['arrKols'] = $this->coaching->getAllKols ();
		$data ['arrTypes'] = $this->interaction->getAllTypesOfClient ();
		$data ['arrOrgs'] = $this->coaching->getAllOrgs ();
		
		$data ['contentPage'] = 'coachings/add_compliance';
		// echo json_encode($data);
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => LOG_EDIT,
				'description' => 'edit Compliance',
				'status' => 'success',
				'transaction_id' => $id,
				'transaction_table_id' => COMPLIANCE_MONITORING,
				'transaction_name' => "edit coaching",
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		
		log_user_activity ( $arrLogDetails, true );
		$this->load->view ( 'layouts/client_view', $data );
	}
	function get_productname_basedon_theraputicArea($id) {
		$arrProductName = $this->coaching->getProductByTheraputicArea ( $id );
		echo json_encode ( $arrProductName );
	}
	function get_keyinsightname_basedon_productname($id, $specilaty) {
		$arrKeyInsightName = $this->coaching->getKeyInsightByProduct ( $id, $specilaty );
		echo json_encode ( $arrKeyInsightName );
	}
	function prepare_discussion_topic_data($row) {
		$arr = array ();
		$arr ['arrProducts'] = $this->common_helpers->getUserProducts ();
		$arr ['arrTypes'] = $this->interaction->getAllTypesOfClient ();
		$arr ['arrTopics'] = $this->interaction->getTopicByType ( $row ['type_id'], $row ['product_id'] );
		$arr ['arrSubTopics'] = $this->interaction->getSubTopics ( $row ['product_id'], $row ['interaction_type'], $row ['topic_id'] );
		$arr ['row'] = $row;
		return $arr;
	}
	function is_complience_exist_for_user($userId) {
		$latestComlienceId = $this->coaching->getLatestComplienceIdByUser ( $userId );
		$data ['complience_id'] = $latestComlienceId;
		echo json_encode ( $data );
	}
	function is_coaching_exist_for_user($userId) {
		$latestCoachingId = $this->coaching->getLatestCoachingIdByUser ( $userId );
		$data ['coaching_id'] = $latestCoachingId;
		echo json_encode ( $data );
	}
	function medicalinsightMapping() {
		$result = $this->db->query ( "select * from  customer_dynamic where table_id=7888500000002230" );
		
		foreach ( $result->result_array () as $values ) {
			
			// specialty
			if (($values ['code_1']) == "NSC")
				$specialty = "CNS";
			if (($values ['code_1']) == "ONC")
				$specialty = "Oncology";
			if (($values ['code_1']) == "HOSP")
				$specialty = "Cardio-Renal";
			// source_type
			if (($values ['code_4']) == "KTL")
				$source_type = "KTL direct knowledge";
			if (($values ['code_4']) == "PDK")
				$source_type = "Payer direct knowledge";
			if (($values ['code_4']) == "CSPS")
				$source_type = "Congress symposia/poster session";
			if (($values ['code_4']) == "KTLS")
				$source_type = "KTL secondary knowledge";
			if (($values ['code_4']) == "MWLE")
				$source_type = "Media: Websites, Listserve, etc.";
			if (($values ['code_4']) == "IPDK")
				$source_type = "Industry professional direct knowledge";
			if (($values ['code_4']) == "IPSK")
				$source_type = "Industry professional secondary knowledge";
			if (($values ['code_4']) == "PSK")
				$source_type = "Payer secondary knowledge";
			if (($values ['code_4']) == "NA")
				$source_type = "N/A";
			// agent
			if (($values ['code_3']) == "OTH")
				$agent = "Other";
			if (($values ['code_3']) == "SATX")
				$agent = "Sativex";
			if (($values ['code_3']) == "OTHI")
				$agent = "Other";
			if (($values ['code_3']) == "BREX")
				$agent = "Brexpiprazole";
			if (($values ['code_3']) == "LUUA")
				$agent = "LUU AE58054";
			
			// Sphere of Influence
			if (($values ['code_2']) == "LOC")
				$sphere = "Local";
			if (($values ['code_2']) == "REG")
				$sphere = "Regional";
			if (($values ['code_2']) == "NAT")
				$sphere = "National";
			if (($values ['code_2']) == "GLOB")
				$sphere = "Global";
			
			// email
			$userEmail = $this->db->query ( "select email_address from employee " . "left join customer_dynamic on customer_dynamic.number_1=employee.employee_id " . "where customer_dynamic.number_1=" . $values ['number_1'] . "" );
			$email = $userEmail->row_array ();
			// echo $this->db->last_query();
			// created_by
			$userIds = $this->db->query ( "select id from client_users where email='" . strtolower ( $email ['email_address'] ) . "'" );
			$userId = $userIds->row_array ();
			// echo $userId;
			// echo $this->db->last_query();
			// product
			
			$productIds = $this->db->query ( "SELECT name from products where otsuka_id='" . $values ['text_1'] . "'" );
			$productId = $productIds->row_array ();
			
			$kolIds = $this->db->query ( "SELECT id from kols where customer_id='" . $values ['customer_id'] . "'" );
			$kolId = $kolIds->row_array ();
			
			$keyInsightArray = $this->db->query ( "SELECT name from key_insight_topics where otsuka_code='" . $values ['code_5'] . "'" );
			$keyInsightId = $keyInsightArray->row_array ();
			
			$old_startdate_timestamp_create = strtotime ( $values ['date_1'] );
			$create_date = date ( 'Y-m-d', $old_startdate_timestamp_create );
			
			$insertDataArray = array (
					"specialty" => $specialty,
					"agent" => $agent,
					"product" => $productId ['name'],
					"source_type" => $source_type,
					"summary" => $values ['text_5'],
					"topics" => $keyInsightId ['name'],
					"created_by" => $userId ['id'],
					"created_on" => $create_date,
					"sphere_of_influence" => $sphere,
					"relevance" => $values ['text_2'],
					"actions_to_consider" => $values ['text_3'],
					"other" => '',
					"kol_id" => $kolId ['id'],
					"profile_type" => '',
					"ireport_id" => $values ['customer_dynamic_id'] 
			);
			$this->db->insert ( "medical_insight", $insertDataArray );
			// $lastId= $this->db->insert_id();
		}
	}
	function codeMapping() {
		$topic = $this->db->query ( "SELECT * from keyinsightcode" );
		$keytopic = $topic->result_array ();
		// pr($keytopic);
		foreach ( $keytopic as $values ) {
			
			$this->db->query ( "update key_insight_topics set otsuka_code='" . $values ['code'] . "' where name='" . $values ['name'] . "'" );
		}
	}
	function export_medical_insight_details_new() {
		$startTime = microtime ( true );
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		$this->load->plugin ( 'php_excel/Classes/PHPExcel.php' );
		$showAllUserFlag = $this->input->post ( 'allUserFlag' );
		$arrKolIds = $this->input->post ( 'medical_ids' );
		$kolId = $this->input->post ( 'kolId' );
		$arrFilters = $this->input->post ( 'grid_filter' );
		$arrFilters = stripslashes ( $arrFilters );
		$arrFilters = str_replace ( '"{', '{', $arrFilters );
		$arrFilters = str_replace ( '}"', '}', $arrFilters );
		$arrFilters = trim ( $arrFilters, '"' );
		$arrFilters = json_decode ( $arrFilters, JSON_UNESCAPED_SLASHES );
		$Details = array ();
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$arrFilter = $arrFilters ['filters'];
		if (isset ( $arrFilters ['filters'] )) {
			$searchGroupOperator = $this->common_helpers->search_nested_arrays ( $arrFilter, $groupOp );
			$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
			$searchOper = $this->common_helpers->search_nested_arrays ( $arrFilter, $op );
			$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
			
			foreach ( $searchField as $key => $val ) {
				$Details [$val] = $searchString [$key];
			}
		} else {
			$Details = $arrFilters;
		}
		$sidx = $arrFilters ['sidx'];
		$sord = $arrFilters ['sord'];
		$arrKolIds = explode ( ',', $arrKolIds );
		$Details ['excelExport'] = 1;
		// $arrKolDeatil = $this->coaching->listMedicalInsight(0, 0, false, $sidx, $sord, $Details, $kolId);
		$objPHPExcel = new PHPExcel ();
		$arrExcelData = array ();
		$arrKolDetails [] = $this->coaching->listMedicalInsight ( 0, 0, false, $sidx, $sord, $Details, $showAllUserFlag, $kolId );
		// New Worksheet
		$objWorksheet = new PHPExcel_Worksheet ( $objPHPExcel );
		// $objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle ( 'Medical Insights' );
		// Add header
		// $arrDetails[0] = array('Id','Therapeutic Area', 'Product', 'Source Type', 'Agent', 'Topics', 'Sphere of Influence','Congress Source','Congress Name', 'Medical Insight Summary', 'Describe Relevance to OPDC', 'Actions to Consider', 'HCP Name', 'Recorded By', 'Recorded On');
		$fileName = 'Medical Insight';
		$objWorksheet->setCellValue ( 'A1', 'Id' )->setCellValue ( 'B1', 'Therapeutic Area' )->setCellValue ( 'C1', 'Product' )->setCellValue ( 'D1', 'Source Type' )->setCellValue ( 'E1', 'Agent' )->setCellValue ( 'F1', 'Topics' )->setCellValue ( 'G1', 'Sphere of Influence' )->setCellValue ( 'H1', 'Congress Source' )->setCellValue ( 'I1', 'Congress Name' )->setCellValue ( 'J1', 'Medical Insight Summary' )->setCellValue ( 'K1', 'Describe Relevance to OPDC' )->setCellValue ( 'L1', 'Actions to Consider' )->setCellValue ( 'M1', 'KTL Name' )->setCellValue ( 'N1', 'Recorded By' )->setCellValue ( 'O1', 'Recorded On' );
		$i = 2;
		foreach ( $arrKolDetails [0] as $row ) {
			
			// $objWorksheet->setCellValue('A' . $i, $rows['generic_id']);
			if ($row ['agent'] == 'Select Investigational Agent')
				$row ['agent'] = "";
			if ($row ['agent'] == '0')
				$row ['agent'] = "";
			if ($row ['topics'] == '0')
				$row ['topics'] = "";
			if ($row ['sphere_of_influence'] == '0')
				$row ['sphere_of_influence'] = "";
			if ($row ['congress_sources'] == '0')
				$row ['congress_sources'] = "";
			if ($row ['congress_name'] == '0')
				$row ['congress_name'] = "";
			if ($row ['summary'] == '0')
				$row ['summary'] = "";
			if ($row ['relevance'] == '0')
				$row ['relevance'] = "";
			if ($row ['actions_to_consider'] == '0')
				$row ['actions_to_consider'] = "";
			$objWorksheet->setCellValue ( 'A' . $i, $row ['generic_id'] )->setCellValue ( 'B' . $i, $row ['specialty'] )->setCellValue ( 'C' . $i, $row ['product'] )->setCellValue ( 'D' . $i, $row ['source_type'] )->setCellValue ( 'E' . $i, $row ['agent'] )->setCellValue ( 'F' . $i, $row ['topics'] )->setCellValue ( 'G' . $i, $row ['sphere_of_influence'] )->setCellValue ( 'H' . $i, $row ['congress_sources'] )->setCellValue ( 'I' . $i, $row ['congress_name'] )->setCellValue ( 'J' . $i, $row ['summary'] )->setCellValue ( 'K' . $i, $row ['relevance'] )->setCellValue ( 'L' . $i, $row ['actions_to_consider'] )->setCellValue ( 'M' . $i, $row ['kol_id'] )->setCellValue ( 'N' . $i, $row ['created_user'] )->setCellValue ( 'O' . $i, $row ['created_on'] );
			$i ++;
		}
		$objPHPExcel->addSheet ( $objWorksheet );
		
		// remove first sheet
		
		$styleArray = array (
				'borders' => array (
						'bottom' => array (
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array (
										'argb' => '0000000' 
								) 
						) 
				) 
		);
		
		$arrStyles = array (
				'font' => array (
						'bold' => true,
						'italic' => false 
				),
				'borders' => array (
						'bottom' => array (
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array (
										'rgb' => '000000' 
								) 
						),
						'quotePrefix' => true 
				) 
		);
		// remove first sheet
		$objPHPExcel->removeSheetByIndex ( 0 );
		// iterate each sheet and add the style for each sheet
		foreach ( $objPHPExcel->getWorksheetIterator () as $sheet ) {
			$exportOpts = array (
					strtolower ( $sheet->getTitle () ) 
			);
			// if(in_array('professional',$exportOpts)){
			$objPHPExcel->setActiveSheetIndexByName ( $sheet->getTitle () );
			foreach ( range ( 'A', 'O' ) as $columnID ) {
				$objPHPExcel->getActiveSheet ()->getColumnDimension ( $columnID )->setWidth ( 30 );
				// $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
			}
			$objPHPExcel->getActiveSheet ()->getStyle ( 'A1:O1' )->applyFromArray ( $arrStyles );
			// }
		}
		$objPHPExcel->setActiveSheetIndex ( 0 );
		$objWriter = PHPExcel_IOFactory::createWriter ( $objPHPExcel, 'Excel2007' );
		if (IS_IPAD_REQUEST) {
			$path = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/kol_personal_documents/" . $fileName . ".xls";
			$objWriter->save ( $path );
			return $path;
		} else {
			// Redirect output to a client’s web browser (Excel2007)
			header ( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			header ( 'Content-Disposition: attachment;filename="medical insight.xlsx"' );
			header ( 'Cache-Control: max-age=0' );
			// If you're serving to IE 9, then the following may be needed
			header ( 'Cache-Control: max-age=1' );
			
			// If you're serving to IE over SSL, then the following may be needed
			header ( 'Expires: Mon, 26 Jul 1997 05:00:00 GMT' ); // Date in the past
			header ( 'Last-Modified: ' . gmdate ( 'D, d M Y H:i:s' ) . ' GMT' ); // always modified
			header ( 'Cache-Control: cache, must-revalidate' ); // HTTP/1.1
			header ( 'Pragma: public' ); // HTTP/1.0
			
			$objWriter = PHPExcel_IOFactory::createWriter ( $objPHPExcel, 'Excel2007' );
			$objWriter->save ( 'php://output' );
			exit ();
		}
	}
	function send_email_for_export_medical() {
		$currentMethod = $this->uri->segment ( 3 );
		$config ['protocol'] = PROTOCOL;
		$config ['smtp_host'] = HOST;
		$config ['smtp_port'] = PORT;
		$config ['smtp_user'] = USER;
		$config ['smtp_pass'] = PASS;
		$config ['mailtype'] = 'html';
		$this->load->library ( 'email', $config );
		$this->email->set_newline ( "\r\n" );
		$this->email->initialize ( $config );
		$this->email->clear ();
		$this->email->set_newline ( "\r\n" );
		$this->email->from ( USER, SENDER );
		// $this->email->to("shrutip@aissel.com");
		$loggedInUserName = $this->session->userdata ( 'user_full_name' );
		$loggedInUserName = substr ( $loggedInUserName, 0, strpos ( $loggedInUserName, ' ' ) );
		$messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of Medical Insight report data from ' . PRODUCT_NAME . '.';
		$loggedInUserEmail = $this->session->userdata ( 'email' );
		$this->email->to ( $loggedInUserEmail );
		$this->email->message ( $messageBody );
		$this->email->subject ( PRODUCT_NAME . ":Medical Insight" );
		$path = $this->export_medical_insight_details_new ();
		$this->email->attach ( $path );
		$this->email->set_crlf ( "\r\n" );
		if ($this->email->send ()) {
			$emailData ['status'] = 'Excel has been mailed successfully';
			unlink ( $path );
			link ( $path );
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email Sent',
					'status' => 'success',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_medical',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
		} else {
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'type' => LOG_UPDATE,
					'description' => 'Email failed',
					'status' => 'failed',
					'transaction_id' => '',
					'transaction_table_id' => '',
					'transaction_name' => "Email",
					'module' => 'send_email_for_export_medical',
					'parent_object_id' => '',
					'user_id' => $loggedInUserName,
					
					'form_data' => $formData 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			
			log_user_activity ( $arrLogDetails, true );
			$emailData ['status'] = 'Mail not sent';
		}
		echo $emailData ['status'];
	}
	function list_one_on_one_coaching() {
		$data ['contentPage'] = 'coachings/list_coaching_one_on_one';
		$this->load->view ( 'layouts/client_view', $data );
	}
	function add_coaching_one_on_one() {
		$data ['contentPage'] = 'coachings/add_coaching_one_on_one';
		$this->load->view ( 'layouts/client_view', $data );
	}
}

?>
