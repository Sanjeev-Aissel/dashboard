<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<?php
	$queued_js_scripts = array('js/custom_js/jqgridExportToExcel',
			'jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'alerts/jquery.alerts'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.action_icons{
    font-size: 16px;
    padding: 0px 5px;
}
</style>
<div class="row">
	<div class="pull-right row_padding form-inline">
		<?php $role_permissions=$this->config->item('role_permissions');
			if($role_permissions[$module_id]["add"]==1){?>
			<a href="<?php echo base_url().'clinical_trials/clinical_trials/add_clinical_trial/'.$arrKol['kols_client_visibility_unique_id'];?>" type="button" class="btn custom-btn" title="Add Affiliation">Add New Clinical Trial</a>
		<?php }?>
		<div data-toggle="tooltip" data-placement="left" title="Export Clinical Trails Details into Excel format" class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistClinicalTrialsResultSet','clinical_trails');">
	     <a href="#" >&nbsp;</a>
	   </div>
	</div>
</div>
<div id="trials" class="clear">
	<div class="gridWrapper clear" id="clinicalGridContainer">
		<table id="JQBlistClinicalTrialsResultSet"></table>
		<div id="listlistClinicalTrialsPage"></div>
	</div>
</div>
<script>
var kolId 			= '<?php echo $arrKol['kols_client_visibility_id']?>'; 
var kol_unique_id 	= '<?php echo $arrKol['kols_client_visibility_unique_id']?>'; 
var arrExcludeColumnsInExcelExport 			= new Array('act'); 
var arrExcludeHeaderColumnsInExcelExport	= new Array('Id','ClientID','User Id','is_analyst','first_name','last_name');

$(document).ready(function(){
	getClinicalDataOnLoad();
});
function getClinicalDataOnLoad(){
	var ele=document.getElementById('clinicalGridContainer');
	var gridWidth=ele.clientWidth;
	$('#clinicalGridContainer').html('<table id="JQBlistClinicalTrialsResultSet"></table><div id="listlistClinicalTrialsPage"></div>');
	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid({
	   	url:base_url+'clinical_trials/clinical_trials/list_clinical_trials_details/'+kolId,
		datatype: "json",
		colNames:['Id','','User Id','ClientID','','CT ID','Trial Name','Status','Sponsors','Condition','Intervention','Phase','Action','is_analyst','first_name','last_name','eAllowed','data_type_indicator'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'trial_id',index:'trial_id', hidden:true},
			{name:'user_id',index:'user_id', hidden:true},
			{name:'client_id',index:'client_id', hidden:true},
			{name:'micro',index:'micro',width:35, search:false, hidden:true},
			{name:'ct_id',index:'ct_id',width:105},
	   		{name:'trial_name',index:'trial_name',width:290,editable:true},
	   		{name:'status',index:'status',width:80,editable:true},
	   		{name:'sponsors',index:'sponsors',width:160,editable:true},
	   		{name:'condition',index:'condition',width:130,editable:true},
	   		{name:'interventions',index:'interventions',width:120,editable:true},
	   		{name:'phase',index:'phase',width:60,editable:true},
	   		{name:'act', resizable:true,search:false,width:100,align:'center',sortable:false},
	   		{name:'is_analyst',index:'is_analyst',width:175, resizable:false,search:false,hidden:true},
	   		{name:'first_name',index:'first_name',width:175, resizable:false,search:false,hidden:true},
	   		{name:'last_name',index:'last_name',width:175, resizable:false,search:false,hidden:true},
	   		{name:'eAllowed',index:'eAllowed', hidden:true},
	   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	multiselect: false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listlistClinicalTrialsPage',
	   	mtype: "POST",
	   	sortname: 'trial_name',
	    viewrecords: true,
	    sortorder: "desc",
	    gridComplete: function(){						     
		    var ids = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getDataIDs'); 
		    var be = '';
	    	for(var i=0;i < ids.length;i++){ 
	    			be = '';
			    	var id = ids[i];	
			    	var ret = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getRowData',id);
		    		var dataTypeIndicator = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getCell',id,'data_type_indicator');
			    	be += data_type_indicator(dataTypeIndicator);
			        <?php $role_permissions=$this->config->item('role_permissions');
					        if(($role_permissions[$module_id]['delete'])==1){?>
					        be += "<a onclick=\"deleteClinicalTrial('"+id+"','"+ret.trial_id+"'); return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
							<?php }?>
							<?php if(($role_permissions[$module_id]['edit'])==1){?>
							be += "<a href=\"<?php echo base_url();?>clinical_trials/clinical_trials/add_clinical_trial/"+kol_unique_id+"/"+ret.trial_id+"\"><span class='glyphicon glyphicon-edit action_icons'></span></a>";
					<?php }?>                  
					jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be});
			    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewClinicalTrialMicroProfile('"+id+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Clinical Trial Snapshot\">&nbsp;</a></div></label>";
			    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
				} 
		      	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id");
	    	}, 
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:'TRIALS',
		rowList:[10,20,30,40,50,60,70,80,90,100]		
	});
	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','#listlistClinicalTrialsPage',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setGridWidth',gridWidth);
}
function deleteClinicalTrial(id,ctsId){
	jConfirm("Are you sure you want to delete the clinical trial?","Confirm box", function(r){
		if(r){
			var formAction = base_url+'clinical_trials/clinical_trials/delete_client_clinical_trial/'+id+'/'+ctsId;	
			$.ajax({
				url: formAction,
				dataType: "json",
				type: "post",
				success: function(retData){
					getClinicalDataOnLoad();
				}
			});
		}
	});
}	
</script>