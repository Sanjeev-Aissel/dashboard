<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
    var todayDate = "<?php echo date("m/d/Y"); ?>";
    var monthFirstDate = "<?php echo date("m/01/Y"); ?>";
    $(document).ready(function () {
        $("#resetBttnContainer").remove();
        $('.chosenMultipleSelect').chosen({
            allow_single_deselect: true
        });
        $('.chosenMultipleSelectTeam').chosen({
            allow_single_deselect: true
        });
        $('.chosenMultipleSelectManager').chosen({
            allow_single_deselect: true
        });
        $('#start_date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('#start_date').val(monthFirstDate);
        $('#end_date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('#end_date').val(todayDate);
        reloaReport();
    });

    function reloaReport() {
        var data = {};
        var filter = {};
        // var filter = $("form").serialize();
        var sd = $('#start_date').val();
        var ed = $('#end_date').val();
        if (sd != '') {
            var sdSplits = sd.split("/");
            data['start_date'] = sdSplits[2] + "-" + sdSplits[0] + "-" + sdSplits[1];
        }
        if (ed != '') {
            var edSplits = ed.split("/");
            data['end_date'] = edSplits[2] + "-" + edSplits[0] + "-" + edSplits[1];
        }
        var mslData = new Array();
        if ($("#msl_user").val() != null) {
            mslData = $("#msl_user").val();
        }
        var teamData = new Array();
        if ($("#teams").val() != null) {
            teamData = $("#teams").val();
        }
        var managerData = new Array();
        if($("#managers").val() != ''){

                managerData = $("#managers").val();
        }
        data['msl'] = mslData;
        data['team'] = teamData;
        data['manager_id']=managerData;
        $("#applyFilter").val("Cancel");
	$("#applyFilter").attr("onclick","cancelLastRequest()");
	$("#hideSideBarButton").val("Hide Sidebar");
	$("#resetFilter").val("Reset");
//         alert(JSON.stringify(data));
        // data=filter;

//  var filter = $("#searchFilterForm").serialize();
//  data=filter;
        //filterCurrentReport(data);
    }

    function resetFilters() {
        $("select").find('option').removeAttr("selected");
        $("input").val('');
        $("input").text('');
        $('.search-choice').remove();
        $('#start_date').val("");
        $('#end_date').val("");
        reloaReport();
    }


    jqgridIds.push("listMirfResultSet","test");
    var gridMinWidth = 600;
    var gridMaxWidth = 880;
    function toggleIreportSidebar(ele){
    	if ($(ele).attr('value') == "Hide Sidebar") {
    		resizeMaxGridWidth();
    		$("#subContainer").before('<input type="button" class="toggle-button" id="showSideBarButton" onclick="toggleIreportSidebar(this);"  value="Show Sidebar" style="float: right;">');
    		$("#rightSideBar").hide();
        } else {
        	resizeMinGridWidth();
        	$("#showSideBarButton").remove();
        	$("#rightSideBar").show();
        }
    }

    function resizeMinGridWidth(){
    	jqgridMinWidth = gridMinWidth;
    	$.each(jqgridIds,function(index,value){
    		$('#'+value).setGridWidth(gridMinWidth,false);
    	});
    	$(".tabsContent").css("width","630px");
    	$(".tabsContainer").css("width","630px");
    }

    function resizeMaxGridWidth(){
    	jqgridMinWidth = gridMaxWidth;
    	$.each(jqgridIds,function(index,value){
    		$('#'+value).setGridWidth(gridMaxWidth,false);
    		$('#'+value).css("width",gridMaxWidth+"px");
    	});
    	$(".tabsContent").css("width","880px");
    	$(".tabsContainer").css("width","880px");
    }
</script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery/jquery-ui-1.8.16.datepicket.js"></script>
<?php $currentMethod = $this->uri->segment(2); ?>
<style>



    #resetBttnContainer {
        color: #2b9af3 !important;
        float: right;
        margin-top: 0;
        padding-bottom: 0;
        padding-right: 2px;
    }
    #resetBttn {
        background: transparent url("../images/all_icons.png") repeat scroll 31% 45%;
    }
    #resetBttn {
        cursor: pointer;
        float: left;
        height: 16px !important;
        margin-left: 4px;
        margin-right: 5px;
        margin-top: 0;
        vertical-align: middle;
        width: 15px !important;
    }


    #searchLeftBar {
    }
    #searchLeftBar.span-5 {
        width: 180px;
    }
    #searchLeftBar label.facet-toggle {
        cursor: pointer;
        display: block;
        font-size: 85%;
        height: 11px;
        position: absolute;
        right: 0;
        text-indent: -99999px;
        top: 12px;
        width: 11px;
    }
    #searchLeftBar h3 {
        background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
        color: #2b9af3;
        font-size: 12px;
        font-weight: bold;
        line-height: 17px;
        margin-bottom: 0;
        margin-left: 0;
        margin-right: 0;
        padding: 5px 0 3px 5px;
        text-align: left;
    }
    .chzn-container-multi .chzn-choices .search-field input { 
        height: 20px !important;
        padding: 2px 2px 2px 0;
    }

    #searchFiltersElements ul {
        margin-right: 5px;
        padding-left: 0px;
    }
    #searchFiltersContainer {
        /*min-height: 600px;*/
        padding: 0;
    }
    #searchFilterForm li {
        list-style: outside none none;
    }
    .chzn-results{
        color:black !important;
    }
    #rightSideBarContainer {
        width: 311px;
    }
    #rightSideBar::before {
        border-top: 1px solid #bbbbbb !important;
        height: 0 !important;
        margin-left: 0 !important;
    }
    #rightSideBarWrapper {
        border-left: 1px solid #bbbbbb;
        /*overflow: hidden;*/
    }
    .rightRefinedByFilter {
        float: unset;
    }
    #searchFiltersElements ul li.search-field{
        padding-bottom: 0px;
        padding-left: 10px;
        padding-top: 0px;
    }
    #categoriesContainer table{
        margin-bottom: 0 !important;
    }
    .chzn-container-multi .chzn-choices .search-field input{
        color: #444444 !important;
    }
    #contentWrapper.span-23{
        width: 1342px !important;
    }
    #categoriesContainer .category{
        padding-bottom: 0;
    }
    #searchFiltersElements ul li{
        padding-left: 15px;
    }
    <?php if (IS_IPAD_REQUEST) { ?>
        .chosenMultipleSelect,.chosenMultipleSelectTeams ,.chosenMultipleSelectManager{
            width: 230px;
        }
        label.categoryName{
            border-bottom: 0 !important;
            font-size: 11px;
            color: #444444;
        }
        #categoriesContainer .category{
            margin-top: 15px;
        }
        .chzn-container-multi .chzn-choices .search-field .default {
            height: 25px !important;
            border-radius: 2px !important;
        }
        .search-field{
            height: 25px !important;
        }
        .chzn-container-multi .chzn-choices {
            border-radius: 4px;
        }
        form label {
            font-weight: normal !important;
            text-align: right;
        }
        .dateText {
            font-size: 11px;
            color: #444444;
        }
        #start_date, #end_date {
            width: 80px;
            border: 1px solid #aaaaaa !important;
            margin-right: 10px;
            font-size: 12px;
            height: 20px;
        }
        .ui-widget-content {
        background: white;
        }
        .ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active {
    border: 1px solid #003eff;
    background: #007fff;
    font-weight: normal;
    color: #fff;
}
    <?php } else { ?>

        select.chosenMultipleSelect,.select.chosenMultipleSelectTeam,select.chosenMultipleSelectManager{
            width:280px;
        }
        #start_date, #end_date {
            width: 80px;
        }
        label.categoryName {
            border: 0 none !important;
            color: #333333 !important;
            color: #38537c;
            border-radius: 10px 0 0;
            display: block;
            margin: 0 -10px 3px 0;
            text-align: left;
            background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
            border-bottom: 1px solid #2283ae;
            border: 0 none !important;
            color: #333333 !important;
        }
    <?php } ?>
    #hideSideBarButton{
		margin: 5px 20px 5px 10px;
		font-size: 11px;
	}
</style>
<div id="searchFiltersContainer">
    <div id="searchFiltersElements">
        <form id="searchFilterForm" method="post" name="searchFilterForm" action="#">
            <ul id="categoriesContainer">
                <li id="categotyChannels" class="category"> </li>
                <?php if (IS_IPAD_REQUEST == 1) { ?>
                    <div class="row">
                    	<div class="col-md-12 text-right">
							<input type="button" id="hideSideBarButton" class="toggle-button" onclick="toggleIreportSidebar(this);" value="Hide Sidebar">
						</div>
                        <div class="col-md-12 text-center">
                            <input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" class="toggle-button applyFilter" onclick="reloaReport();">
                            <input type="button" name="applyFilter" class="toggle-button applyFilter" id="resetFilter" onclick="resetFilters();" value="Reset">		
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <label class="dateText">From </label>
                            <input type="text" name="start_date" value="<?php if ($fromDate != '') {
                    echo $fromDate;
                } ?>" id="start_date">
                            <label class="dateText">To </label>
                            <input type="text" name="end_date" value="<?php if ($toDate != '') {
                    echo $toDate;
                } ?>" id="end_date">
                        </div>
                    </div>

<?php } else { ?>
                    <table>
                        <tbody>
                            <tr>
                                <td colspan="2" style="text-align: center;">
                                    <input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" class="toggle-button applyFilter" onclick="reloaReport();">
                                    <button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="resetFilters();">Reset</button>		
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;">From </label>
                                    <div style="">
                                        <input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="start_date" id="start_date">
                                    </div>
                                </td>
                                <td>
                                    <label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;">To </label>
                                    <div style="">
                                        <input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="end_date" id="end_date">
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
<?php } ?>	                  
                <li id="categotyChannels" class="category"> </li>
                        <?php //if($currentMethod=="list_uoq" || $currentMethod=="list_speaker_evaluations") {  ?>
                <li id="categotyCountry" class="category">
                    <label class="categoryName">MSL Name</label>
                    <select name="msl[]" id="msl_user" multiple="multiple" class="chosenMultipleSelect" data-placeholder="Select Users">
                        <option value=""></option>
                        <?php
                        foreach ($arrClientUsers as $key => $arrRow) {
                            $selected = '';
                            ?>
                            <option value="<?php echo $arrRow['id'] ?>" ><?php echo $arrRow['first_name'] . ' ' . $arrRow['last_name'] ?></option>;
<?php }
?>
                    </select>
                </li>
                <li id="categotyCountry" class="category">
                    <label class="categoryName">Team Name</label>
                    <select name="team[]" id="teams" multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectTeam" data-placeholder="Select Teams">
                        <option value=""></option>
                        <?php
                        foreach ($arrTeam as $key => $arrRow) {
                            $selected = '';
                            ?>
                            <option value="<?php echo $arrRow['group_id'] ?>" ><?php echo $arrRow['group_name'] ?></option>;
<?php }
?>
                    </select>
                </li>
                <?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
                <li id="Manager" class="category">
                    <label class="categoryName">Manager Name</label>
                    <div id="ManagerCheck">
                        <table id="mslData">
							<select name="manager_name" id="managers"  class="chosenMultipleSelect chosenMultipleSelectManager" data-placeholder="Select Manager">
	            				<option value=""></option>
		            			<?php 
					                foreach($arrManager as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name']?>&nbsp;<?php echo $arrRow['last_name']?></option>;
		                		<?php }?>
				        	</select>
                        </table>
                    </div>
                </li>
                
                <?php }  ?>
            </ul>
        </form>
    </div>
</div>
