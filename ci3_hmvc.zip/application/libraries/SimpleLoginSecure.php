<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once('phpass-0.3/PasswordHash.php');

define('PHPASS_HASH_STRENGTH', 8);
define('PHPASS_HASH_PORTABLE', false);
class SimpleLoginSecure
{
	protected $CI; // CodeIgniter object
	protected $user_table = 'client_users'; // Table name
	public function __construct()
    {
        // Assign the CodeIgniter super-object
		$this->CI =& get_instance();
	}
	function login($user_name = '', $user_pass = '') 
	{
		$arrReturnData=array();
// 		pr($user_name);pr($user_pass);
		if($user_name == '' OR $user_pass == ''){
			$arrReturnData['message']="Username Or password is empty";
			$arrReturnData['status']=false;
			return $arrReturnData;
		}
		//Check if already logged in
		if($this->CI->session->userdata('user_name') == $user_name){
			$arrReturnData['message']="User has already logged-in";
			$arrReturnData['status']=true;
			return $arrReturnData;
		}
		//Check against user table
		$this->CI->db->where('user_name', $user_name); 
		$query = $this->CI->db->get_where($this->user_table);
		if ($query->num_rows() > 0) 
		{
			$user_data = $query->row_array(); 
			$this->CI->db->where('user_name', $user_name);
			$this->CI->db->where('status', ACTIVATED_USER);
			$query2 = $this->CI->db->get($this->user_table);
			$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
			if(!$hasher->CheckPassword($user_pass, $user_data['password']))
			{
				$this->CI->db->where('user_name', $user_name);
				$this->CI->db->set('failed_attempts', 'failed_attempts+1', FALSE);
				$this->CI->db->update('client_users');
				
				$this->CI->db->select('failed_attempts');
				$this->CI->db->where('user_name', $user_name);
				$query = $this->CI->db->get('client_users');
				$no_of_failed_attempts=$query->row('failed_attempts');
				if($no_of_failed_attempts >= BLOCK_ON_NO_OF_FAILED_ATTEMPTS){
					$this->CI->db->where('user_name', $user_name);
					$this->CI->db->set('status',DEACTIVATED_USER);
					$this->CI->db->update('client_users');
				}
				$arrReturnData['message']="Invalid password";
				$arrReturnData['status']=false;
				return $arrReturnData;
			}	
			if ($query2->num_rows() == 0)
			{
				$arrReturnData['message']="Your Account is Blocked";
				$arrReturnData['status']=false;
				return $arrReturnData;
			}
			//Create a fresh, brand new session
			if (CI_VERSION >= '3.0') {
				$this->CI->session->sess_regenerate(TRUE);
			} else {
				//Destroy old session
				$this->CI->session->sess_destroy();
				$this->CI->session->sess_create();
			}
			$this->CI->db->where('user_name', $user_name);
			$this->CI->db->set('failed_attempts', '0');
			$this->CI->db->update('client_users');
// 			//Set session data
// 			unset($user_data['user_pass']);
// 			$user_data['user'] = $user_data['user_email']; // for compatibility with Simplelogin
// 			$user_data['logged_in'] = true;
// 			$this->CI->session->set_userdata($user_data);			
			$arrReturnData['message']="Successfully logged-in";
			$arrReturnData['status']=true;
			return $arrReturnData;
		} 
		else 
		{
			$arrReturnData['message']="Invalid username/Account does not exists";
			$arrReturnData['status']=false;
			return $arrReturnData;
		}	
	}
}
?>