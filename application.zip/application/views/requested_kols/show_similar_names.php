<?php
?>
<style type="text/css">
	#similarNames{
		margin-bottom: 13px;
	}
	#similarNames ul{
		border-bottom: 1px solid #EBEBEB;
	    margin: 0;
	    padding-bottom: 5px;
	    padding-left: 0;
	    margin: 13px 0 0;
	}
	#similarNames select{
		height: 21px;
	    width: 100px;
	}
	#found-similar-causion{
		background-image: url("<?php echo base_url();?>images/caution_mark.png");
	    background-position: left center;
	    background-repeat: no-repeat;
	    background-size: 44px auto;
	    border-bottom: 1px solid #DFDFDF;
	    font-style: italic;
	    margin-top: 7px;
	    min-height: 36px;
	    padding-left: 52px;
	}
	.formButtons input[type='button']{
		display: block;
	    margin: 10px auto auto;
	    width: 350px;
	}
	#requestName{
		 border-bottom: 1px solid #DFDFDF;
		 text-align:center;
	}
	#similarNames th{
		border-bottom: 1px solid #EEEEEE;
		font-size: 12px;
    	padding: 4px 4px;
	}
	#similarNames td{
		padding: 4px 4px;
		font-size: 12px;
	}
	#similarNames td input[value='Upgrade']{
		margin-left: 105px;
	}
</style>
<div id="requestName">
	You are requesting <label></label>
</div>
<div id="found-similar-causion">
	We found some names that look similar to what you are requesting. Please see if any names below match your request.
</div>

<table>
  <tr>
    <th>Name</th>
    <th>Specialty</th>
    <th>City</th>
    <th>State</th>
    <th style="width: 77px;">Profile Type</th>
    <th>Status</th>
    <th style="width: 180px;">Action</th>
  </tr>
  <?php $i=0;  foreach ($similarKols as $kol){?>
		<tr class="<?php if($i%2 == 0) echo 'evenRow'; else echo 'oddRow'; ?>"> 
			<td>
				<?php if($kol['status'] == COMPLETED){ ?>
				<a href="<?php echo base_url();?>kols/view/<?php echo $kol['id'];?>" target="_NEW">
					<?php echo $arrSalutations[$kol['salutation']]." ".$kol['first_name']." ".$kol['middle_name']." ".$kol['last_name'];?>
				</a>
				<?php } else {?>
					<?php echo $arrSalutations[$kol['salutation']]." ".$kol['first_name']." ".$kol['middle_name']." ".$kol['last_name'];?>
				<?php }?>
				<input type="hidden" id="kol_id" value="<?php echo $kol['id'];?>"/>
			</td>
			<td>
				<?php echo $kol['specialty'];?>
			</td>
			<td>
				<?php echo $kol['city'];?>
			</td>
			<td>
				<?php echo $kol['state'];?>
			 </td>
			<td>
				<input type="hidden" id="current_profile_type" value="<?php echo $kol['profile_type'];?>"/>
				<?php echo $kol['profile_type'];?>
			</td>
			<?php if($kol['status'] == COMPLETED){ ?>
					<td>
						Available
					</td>
					<td>
					<?php if($kol['profile_type'] != 'Full Profile') {?>
						<label>Upgrade To</label>
						<select id="profile_type">
							<?php if($kol['profile_type'] == 'Basic'){?>
								<option value="Full Profile">Full Profile</option>
								<option value="Basic Plus">Basic Plus</option>
							<?php } else {?>
								<option value="Full Profile">Full Profile</option>
							<?php }?>
						</select>
						<input type="button" value="Upgrade" onclick="saveUpgradeRequest(this);"/>
					<?php }?>
					</td>
			<?php }	else if($kol['status'] == REJECT){ ?>
					<td>
					Rejected
					</td>
					<td>
					<input class="" type="button" value="Re Request" onclick="sendReRequest(this);"/>
					</td>
			<?php }	else{ ?>
					<td>
					Requested
					</td>
					<td>
						&nbsp;
					</td>
			<?php }?>
		</tr>
<?php $i++; }?>
</table>

<div class="formButtons">	
	<input type="button" value="These do not match, Proceed to Request" name="submit" onclick="saveDupliecte();"></input>
	<input type="button" value="Start Over" name="start_over" onclick="startOver();"></input>
	<input type="button" value="Cancel" name="submit" onclick="closeDialog();"></input>
</div>

