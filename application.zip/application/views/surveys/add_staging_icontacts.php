<style>
	.form_container{
		margin-right: 50px;
    	text-align: center;
	}
	.form_container .each_field input:not([type='button']),select{
		width: 200px;
	}
	.form_container .each_field string{
		color: red;
	}
	.form_container .each_field textarea{
		width: 190px;
	}
	.form_container .each_field label {
		width : 112px;
		display: inline-block;
		text-align: right !important;
		vertical-align: top;
	}
	.form_container .each_field{
		margin: 2px;
	}
	.form_label{
		margin-bottom: 20px; 
		font-weight: bold;
		color: #333333;
	}
	.form_label label{
		font-size: 11px;
		font-weight: bold;
	}
	#similar_names table tr th{
		padding: 2px 0 2px 4px;
		color: #333333;
    	font-size: 12px;
	}
	#similar_names table tr td {
		padding: 2px 0 2px 4px;
		color: #333333;
    	font-size: 12px;
	}
	#similar_names table tr:hover{
		background-color: #d3dfed;
	}
	#similar_names .button_section{
		margin-top: 12px;
    	text-align: center;
	}
</style>
<?php 
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
	$autoSearchOptions1 = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 2,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<script>
	
	var stateNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names_by_country_id',
		<?php echo $autoSearchOptions1;?>,
		onSelect : function(event, ui) {
			var stateId = $(event).children('.autocompleteStateId').html();
			var selText = $(event).children('.stateName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#state').val(selText);
			$('#stateIdForAutocomplete').val(stateId);
		}
	};

	var cityNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names_by_state_id_and_country_id',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var cityId = $(event).children('.autocompleteCityId').html();
				var selText = $(event).children('.cityName').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#city').val(selText);
				$('#cityIdForAutocomplete').val(cityId);
			}
		};
	
	function save(){
		var SurveyID = $("#active_survey_id").val();
		var data = $("#stagingIcontact").serializeArray();
		if(!whichOne){
			var arr = $("#respondentId").val();
			data.push({name:"respondent_id",value:arr});
		}else{
			var arr = '';
			data.push({name:"respondent_id",value:arr});
		}
		
		var result = { };
		$.each(data,function(){
			result[this.name] = this.value;
		});
		var countryValString = $("#country_id option:selected").text();
		var stateValString = $("#state").val();
		var cityValString = $("#city").val();
		result["country"] = countryValString;
		result["state"] = stateValString;
		result["city"] = cityValString;
		$.each(data,function(k,v){
			if(v.name == "country"){
				data[k].value = countryValString;
			}
			if(v.name == "state"){
				data[k].value = stateValString;
			}
			if(v.name == "city"){
				data[k].value = cityValString;
			}
		});
		if(!whichOne){
			var appendTo	= $(thisEleObj).attr('class');
			if($('.'+appendTo).length < 3 || $('.'+appendTo).length < 11){
				addMore(appendTo);
			}else{
				jAlert('Maximum of 10 answers are allowed for each question');
				return false;
			}
		}
		if(result.first_name == '' || result.last_name == '' || result.state == '' || result.city == ''){
			jAlert("Please fill the mandatory fields (*).");
			return false;
		}
		if($("#stateIdForAutocomplete").val() == ''){
			jAlert("Please select the state from autocomplete.");
			return false;
		}
		$.ajax({
			url:base_url+'surveys/save_staging_icontacts/'+SurveyID+'/'+surQueId,
			data:data,
			type:'post',
			dataType:'json',
			success: function(retData){
				if(retData.status){
//					alert(retData.id);
					if(whichOne){
						$("#respondentId").val(retData.id);	
						$("#respondentName").val(result.first_name+' '+result.middle_name+' '+result.last_name);
						$("#respondent_state").val(result.state);
						$("#respondent_city").val(result.city);
						$("#respondent_postal").val(result.postal_code);
						$("#respondent_mdm").val(result.mdm_id);
//						$("#stagingRespondent").val();
						$(".respondentClass").each(function (){
							$(this).attr("disabled","disabled");
							$(this).css("background-color","#EEEEEE");
						});
//						$("#stagingRespondent").css("background","red");
//						$("#stagingRespondent").val("Delete Missing Customer");
//						$("#stagingRespondent").attr("onclick","deleteMissingRespondent('"+retData.id+"','"+SurveyID+"')");
						$("#is_stging").val("1");
						closeDialog();
					}else{
						var flag = false;
						$("."+appendTo).each(function(key,val){
							if(typeof $(this).attr('id') != 'undefined' && $(this).find('input[type="text"]:eq(0)').prev('input').val() == '' && flag == false){
//								arr.push($(this).attr('id'));
								editFlag=true;
								var appendToId = $(this).attr('id');
								$('tr#'+appendToId+':last').css("border","1px solid red");
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(0)').prev('input').val(retData.id);
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(0)').val(result.first_name+' '+result.middle_name+' '+result.last_name);
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(1)').val(result.state);
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(2)').val(result.city);
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(3)').val(result.postal_code);
								$('tr#'+appendToId+':last').find('input[type="text"]:eq(4)').val(result.mdm_id);
								$(thisEleObj).parent().append('<input type="hidden" class="missing_influencer_ids" name="missing_influencer[]" value="'+retData.id+'"></input>');
								flag = true;
							}
						});
//						var arr = new Array();
//						$("."+appendTo).each(function(key,val){
//							if($(this).children("td").find('.kolNameAutoComplete').val() == '' && !$(this).find("td").children().hasClass('advSearchIcon')){
//								$(this).remove();
//								var vcountVal = $('#count_'+appendTo).val()-1;
//								$('#count_'+appendTo).val(vcountVal);
//							}
//						});
//						$('tr.'+appendTo+':last').css("border","1px solid red");
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(0)').prev('input').val(retData.id);
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(0)').val(result.first_name+' '+result.middle_name+' '+result.last_name);
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(1)').val(result.state);
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(2)').val(result.city);
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(3)').val(result.postal_code);
//						$('tr.'+appendTo+':last').find('input[type="text"]:eq(4)').val(result.mdm_id);
//						$(thisEleObj).parent().append('<input type="hidden" class="missing_influencer_ids" name="missing_influencer[]" value="'+retData.id+'"></input>');
//						addMore(appendTo);
						closeDialog();
					}	
				}
			}
		});
		surQueId='';
	}

	function closeDialog(){
		$("#addNewKol").dialog('option','width',550);
		$("#addNewKol").dialog('option','position',['center', 80]);
		$("#addNewKol").dialog("close");
	}

	$(document).ready(function(){
		if(whichOne){
			$(".form_label").text("Add Missing Customer");
		}else{
			$(".form_label").text("Add Missing Influencer");
		}
	});

	function check_missing_icontact(){
		var data = $("#stagingIcontact").serializeArray();
		var result = { };
		$.each(data,function(){
			result[this.name] = $.trim(this.value);
		});
		var countryValString = $("#country_id option:selected").text();
		var stateValString = $("#state").val();
		var cityValString = $("#city").val();
		result["country"] = countryValString;
		result["state"] = stateValString;
		result["city"] = cityValString;
		$.each(data,function(k,v){
			if(v.name == "country"){
				data[k].value = countryValString;
			}
			if(v.name == "state"){
				data[k].value = stateValString;
			}
			if(v.name == "city"){
				data[k].value = cityValString;
			}
		});
		
		if(result.first_name == '' || result.last_name == '' || result.state == '' || result.city == ''){
			jAlert("Please fill the mandatory fields (*).");
			return false;
		}
		if($("#stateIdForAutocomplete").val() == ''){
			jAlert("Please select the state from autocomplete.");
			return false;
		}
		$("#addNewKol").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
			url:base_url+'surveys/similar_names',
			data:data,
			type:'post',
			dataType:'json',
			success: function(retData){
				if(retData.data.length > 0){
					$(".form_label").text("Similar Names Found");
					$(".form_container").hide();
					var retDataStr = '';//'<button onclick="save();">Continue saving missing influencer</button>';
					retDataStr += '<table border="1">';
					retDataStr += '<tr class="headerBg"><th>&nbsp;</th><th>MDM-ID</th><th>Name</th><th>State</th><th>City</th><th>Postal Code</th></tr>';
					var i = 1;
					$.each(retData.data,function(key,val){
						if(i%2 == 0)
							retDataStr += '<tr class="oddRow" id="'+val.address_id+'"><td><input type="radio" class="missing_customer address_id" name="select_radio" value="'+val.address_id+'"><input class="kol_id" type="hidden" name="kol_id[]" value="'+val.kol_id+'"></td><td>'+val.master_customer_id+'</td><td>'+val.name+'</td><td>'+val.state+'</td><td>'+val.city+'</td><td>'+val.postal_code+'</td></tr>';
						else
							retDataStr += '<tr class="evenRow" id="'+val.address_id+'"><td><input type="radio" class="missing_customer address_id" name="select_radio" value="'+val.address_id+'"><input class="kol_id" type="hidden"  name="kol_id[]" value="'+val.kol_id+'"></td><td>'+val.master_customer_id+'</td><td>'+val.name+'</td><td>'+val.state+'</td><td>'+val.city+'</td><td>'+val.postal_code+'</td></tr>';	
						i++;	
					});
					retDataStr += '</table>';
					if(whichOne){
						retDataStr += '<div class="button_section"><button onclick="save_selected();return false;">Select from list</button>  <button onclick="save(); return false;">Continue saving missing Customer</button></div>';
					}else{
						retDataStr += '<div class="button_section"><button onclick="save_selected();return false;">Select from list</button>  <button onclick="save(); return false;">Continue saving missing Influencer</button></div>';
					}
					$("#similar_names").html(retDataStr);
				}else{
					save();
//					alert("dd");	
				}
			},
		complete: function (){
				$("#addNewKol").unblock();		
			}
		});
	}

	function save_selected(){
		var selected = $(".missing_customer:checked");
	    if(!selected.val()){
	    	if(whichOne){
	    		jAlert("Please select the missing customer from the above list");
		    	return false;
			}else{
				jAlert("Please select the missing influencer from the above list");
		    	return false;
			}
	    }else{
		    var addressId = $("#"+selected.val()).children("td:eq(0)").find(".address_id").val();
		    var kolId = $("#"+selected.val()).children("td:eq(0)").find(".kol_id").val();
		    var name = $("#"+selected.val()).children("td:eq(2)").html();
		    var state = $("#"+selected.val()).children("td:eq(3)").text();
		    var city = $("#"+selected.val()).children("td:eq(4)").text();
		    var postal_code = $("#"+selected.val()).children("td:eq(5)").text();
		    var mdm_id = $("#"+selected.val()).children("td:eq(1)").text();
//		    alert(addressId+" - "+kolId+" - "+name+" - "+state+" - "+city+" - "+postal_code+" - "+mdm_id);
	    	if(whichOne){
	    		$("#respondentId").val(kolId+"-"+addressId);	
				$("#respondentName").val(name);
				$("#respondent_state").val(state);
				$("#respondent_city").val(city);
				$("#respondent_postal").val(postal_code);
				$("#respondent_mdm").val(mdm_id);
	    		isRespondentAlreadySurveyed(kolId);
				closeDialog();
			}else{
				var appendTo	= $(thisEleObj).attr('class');
				if($('.'+appendTo).length < 3 || $('.'+appendTo).length < 11){
					addMore(appendTo);
				}else{
					jAlert('Maximum of 10 answers are allowed for each question');
					return false;
				}
				var arr = new Array();
				$("."+appendTo).each(function(key,val){
					if($(this).children("td").find('.kolNameAutoComplete').val() == '' && !$(this).find("td").children().hasClass('advSearchIcon')){
						$(this).remove();
						var vcountVal = $('#count_'+appendTo).val()-1;
						$('#count_'+appendTo).val(vcountVal);
					}
				});
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(0)').prev('input').val(kolId+"-"+addressId);
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(0)').val(name);
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(1)').val(state);
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(2)').val(city);
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(3)').val(postal_code);
				$('tr.'+appendTo+':last').find('input[type="text"]:eq(4)').val(mdm_id);
				addMore(appendTo);
				closeDialog();
			}
		}
	}

	$(document).ready(function (){
		$('#state').autocomplete(stateNameAutoCompleteOptions);
		$('#city').autocomplete(cityNameAutoCompleteOptions);
		$("#state").focus(function (){
			country_name = $("#country_id").val();
		});
		$("#state").keyup(function (){
			$("#city").val("");
			$("#cityIdForAutocomplete").val("");
		});
		$("#city").focus(function (){
			country_name = $("#country_id").val();
			state_name = $("#stateIdForAutocomplete").val();
		});
	});

	function resetStateCity(){
		$("#city").val("");
		$("#cityIdForAutocomplete").val("");
		$("#state").val("");
		$("#stateIdForAutocomplete").val("");
	}
</script>
<form id="stagingIcontact" method="post" >
	<div class="form_label">
		<label>Add Missing Customer</label>
	</div>
	<div class="msgBox"></div>
	<div class="form_container">
		<div class="each_field">
			<label>First name<string>*</string> : </label>
			<input type="text" name="first_name" ></input>	
		</div>
		<div class="each_field">
			<label>Middle name : </label>
			<input type="text" name="middle_name" ></input>	
		</div>
		<div class="each_field">
			<label>Last name<string>*</string> : </label>
			<input type="text" name="last_name" ></input>	
		</div>
		<div class="each_field">
			<label>Country : </label>
			<select name="country" id="country_id" onchange="resetStateCity();">
				<option value="">-- Select --</option>
					<?php foreach( $arrCountry as $country ){ ?>
					<option value="<?php echo $country['country_id'];?>" <?php if($country['country_id']==254){?> selected="selected" <?php }?>>
					<?php echo $country['country_name'];?>
					</option>
					<?php }?>
			</select>
		</div>
		<div class="each_field">
			<label>State<string>*</string> : </label>
			<input type="text" name="state" class="autocompleteInputBox" id="state" value="" title=""/>
			<input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
		</div>
		<div class="each_field">
			<label>City<string>*</string> : </label>
			<input type="text" name="city" class="autocompleteInputBox" id="city" value="" title=""/>
			<input type="hidden" id="cityIdForAutocomplete" value='' name="city_id">
		</div>
		<div class="each_field">
			<label>Postal code : </label>
			<input type="text" name="postal_code" ></input>	
		</div>
		<div class="each_field">
			<label>NPI Number : </label>
			<input type="text" name="npi" ></input>		
		</div>
		<!-- <div class="each_field">
			<label>MDM ID : </label>
			<input type="text" name="mdm_id" ></input>		
		</div> -->
		<div class="each_field">
			<label>Organization : </label>
			<input type="text" name="organization" ></input>	
		</div>
		<div class="each_field">
			<label>Specialty : </label>
			<input type="text" name="specialty" ></input>	
		</div>
		<div class="each_field"  style="text-align: center; padding-left: 114px;">
			<input type="button" value="Save" onclick="check_missing_icontact();" ></input>
		</div>
	</div>
</form>
<div id="similar_names"></div>