<script type="text/javascript">
function list_event_organizer_types_grid(){
	$('#gridKolsListing').html('');
    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
    grid = $("#gridKolsListingResultSet")
    
    grid.jqGrid({
		url:'<?php echo base_url();?>master_data_controller/load_grid_event_organizer_types',
		datatype: "json",
		colNames:['Id','Type','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'type',index:'type',width:75, search:true},	   		
			{name:'action',index:'action',width:10, align:'center',search:false, resizable:false}
			
	   	],       
	   	rowNum:10,
	   	multiselect: true,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#gridKolsListingPagintaion',
	   	mtype: "POST",
	   	sortname: 'type',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"List_Event_Organizer_Types ",
	    gridComplete: function(){	
	    },
		rowList:paginationValues
	});
	    grid.jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
    	 grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
}
$(document).ready(function(){	
	var eventDialogOpts = {
			title: "Add/Edit Event_Organizer_Types",
			modal: true,
			autoOpen: false,
			height: 300,
			width: 350,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			},
			close:function(){
			}
	};
	$("#eventContainer").dialog(eventDialogOpts);
	list_event_organizer_types_grid();	
});
function editEventOrgType(id,type){
	$(".addEventOrgTypesContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#eventContainer").dialog("open");
	$(".addEventOrgTypesContent").load('<?php echo base_url().'master_data_controller/edit_event_organizer_types'?>',function(){
		$("#hiddenId").val(id);
		$("#eventorgtypes").val(type);
	});
	return false;	
}
function saveEventOrgTypes(){
	var type = $('#eventorgtypes').val();
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;		
	var url = 'master_data_controller/save_event_organizer_types';
	//var confirmed = confirm('Are you sure to Update ?');	
		eventOrgTypes(id,type,url,false);
}
function eventOrgTypes(id,type,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"type="+type+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				alert(returnData);
			}
			list_event_organizer_types_grid();
	 	},
	 	error:function(){
		 	alert("already exist");
		}
	 });
}
function deleteSelectedEventOrgTypes(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	var url = 'master_data_controller/delete_event_organizer_types';
	var confirmed = confirm('Are you sure to Delete ?');
	if(confirmed){
		eventOrgTypes(id,'',url,true);
	} else {
		alert("Operation Cancelled");
	}
}
function closeModal(){
	$("#eventContainer").dialog("close");
	
}
</script>
<style>
.ui-jqgrid .ui-jqgrid-btable{
        table-layout:auto;
    }
    .ui-jqgrid .ui-jqgrid-htable{
        table-layout:auto;
    }
</style>
<div>
	<div class="extraOptions">
		<div class="rightSideOptions">
			<a class="addLink" style="cursor: pointer;"
				onclick="editEventOrgType();return false;"><img
				src="<?php echo base_url();?>images/bullet_add.png" border="0"
				style="height: 30px; vertical-align: middle;" />Add_Event_Organizer_Type </a>
		</div>
	</div>
	<div id="gridKolsListing">
		<div class="gridWrapper">
			<div id="gridKolsListingPagintaion"></div>
			<table id="gridKolsListingResultSet"></table>
		</div>
	</div>
</div>
<!-- Modal content -->
<div id="eventContainer" class="microViewLoading">
	<div class="addEventOrgTypesContent"></div>
</div>
<div id="specclientContainer" class="microViewLoading">
	<div class="addSpecclientContent"></div>
</div>
