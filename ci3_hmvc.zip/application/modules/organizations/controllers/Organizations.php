<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Organizations extends MX_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('organization');
		$this->load->model('logins/login');
		$this->load->model('helpers/country_helper');
		$this->load->model('helpers/common_helper');
		$this->load->library("Ajax_pagination");
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	function list_organizations_client_view(){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		
		$arrFilterById = false;
		$arrFiltersOrg = array();
		$arrFiltersOrg	   = ($arrFilterById['arrFilterFields'])?$arrFilterById['arrFilterFields']:array();
		
		$viewType									= $this->uri->segment(3);
		$noOfRecordsPerPage							= $this->uri->segment(4);
		
		if($noOfRecordsPerPage=='' && $viewType=='list'){
			$noOfRecordsPerPage						= 10;
		}
		if($noOfRecordsPerPage=='' && ($viewType=='main' || $viewType=='')){
			$noOfRecordsPerPage						= 10;
		}
		
		//$noOfRecordsPerPage						= 10;
		
		$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		$limit=$this->ajax_pagination->per_page;
		
		$count=0;
		$startFrom=0;
		$arrOrganizations	= array();
		$searchType	= 'simple';
		$arrFiltersOrg['keyword']	= $this->input->post('keyword');
		if($arrFiltersOrg['keyword']==null)
			$arrFiltersOrg['keyword']="";
		
		$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
		if(sizeof($viewMyOrgs) > 0){
			$viewTypeMyOrgs = MY_RECORDS;
			$arrFiltersOrg['viewType'] = $viewMyOrgs;
		}
		else{
			$viewTypeMyOrgs = ALL_RECORDS;
			//			$arrFiltersOrg['viewType'] = array(0);
		}
		
		if(sizeof($arrFilterById['filter_value']['org_id'])>0 && $viewTypeMyOrgs = MY_RECORDS){
			foreach($arrFilterById['filter_value']['org_id'] as $key => $val){
				$orgId = $val;
			}
			if(in_array($orgId,$arrFiltersOrg['viewType'])){
				$arrFiltersOrg['viewType'] = $arrFilterById['filter_value']['org_id'];
				//				echo "its in";
			}else{
				$arrFiltersOrg['viewType'] = '';
			}
		}
		
		$arrOrganizations		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false);
		$count					= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrOrgByCountryCount	= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'country');
		$arrOrgByStateCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'state');
		$arrOrgByCityCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'city');
		$arrOrgByTypeCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'type');
		$arrOrgByRegionCount	= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'region');
		
		$arrFilterOrgs=array();
		$this->session->set_userdata('keyword',$arrFiltersOrg['keyword']);
		$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);
		
		$allRegionCount=0;
		$assoArrOrgByRegionCount=array();
		foreach($arrOrgByRegionCount as $row){
			$assoArrOrgByRegionCount[$row['GlobalRegion']]=$row;
			$allRegionCount+=$row['count'];
		}
		
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrgByCountryCount as $row){
			$assoArrOrgByCountryCount[$row['country_id']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrOrgByStateCount=array();
		foreach($arrOrgByStateCount as $row){
			$assoArrOrgByStateCount[$row['state_id']]=$row;
			$allStateCount+=$row['count'];
		}
		$allCityCount=0;
		$assoArrOrgByCityCount=array();
		foreach($arrOrgByCityCount as $row){
			$assoArrOrgByCityCount[$row['city_id']]=$row;
			$allCityCount+=$row['count'];
		}
		$allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['org_type_id']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
		
		$profileType = 	($arrFiltersOrg['profile_type'])?$arrFiltersOrg['profile_type']:0;
		$arrFilterOrgs['global_region'] 	= ($arrFiltersOrg['global_region'])?$arrFiltersOrg['global_region']:'';
		$arrFilterOrgs['country'] 	= ($arrFiltersOrg['country'])?$arrFiltersOrg['country']:'';
		$arrFilterOrgs['state'] 	= ($arrFiltersOrg['state'])?$arrFiltersOrg['state']:'';
		$arrFilterOrgs['city'] 		= ($arrFiltersOrg['city'])?$arrFiltersOrg['city']:'';
		$arrFilterOrgs['type'] 		= ($arrFiltersOrg['org_types'])?$arrFiltersOrg['org_types']:'';
		$arrFilterOrgs['profileType'] = ($arrFiltersOrg['profile_type'])?$arrFiltersOrg['profile_type']:array($profileType);
		$arrFilterOrgs['view_type'] = array($viewTypeMyOrgs);
		
	$arrFiltersApplied	= array();
//			$arrFilterOrgs['profileType'] 	= array($profileType);	
			foreach($arrFilterOrgs as $section =>$arrValues){
				if((sizeof(array_filter($arrValues)))>0){
					$separator	= ' | ';
					switch($section){
						case 'orgIds': 
										$arrFiltersApplied['organizations']	= 'Organization Name';
										break;
						case 'global_region':
										//$arrFiltersApplied['global_region']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($arrSelectedCountries).'">Global Region</a>';
										$arrFiltersApplied['global_region']	= 'Global Region';
							break;
						case 'country':  
										$arrSelectedCountries			= $this->country_helper->getCountryNameById($arrFilterOrgs['country']);
										$arrFiltersApplied['country']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCountries).'">Country</a>';
										break;
						case 'state':  
										$arrSelectedStates			= $this->country_helper->getStateNameById($arrFilterOrgs['state']);
										$arrFiltersApplied['state']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedStates).'">State</a>';
										break;
						case 'city':  
										$arrSelectedCities			= $this->country_helper->getCityNameById($arrFilterOrgs['city']);
										$arrFiltersApplied['city']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCities).'">City</a>';
										break;
						case 'type':  
										$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrFilterOrgs['type']);
										$arrFiltersApplied['organization_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedOrgTypes).'">Organization Type</a>';
										break;
						case 'profileType':  
	//									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
										if($profileType == 2)
											$profileTypeValue = "Full Profiles";
										else
											$profileTypeValue = "Basic Profiles";
										$arrFiltersApplied['profile_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$profileTypeValue.'">Profile Type</a>';
										break;
						case 'view_type':
										if($arrValues[0] == 1)
											$viewTypeString = "My Organizations";
										else
											$viewTypeString = "All Organizations";
										$arrFiltersApplied['viewType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$viewTypeString.'">View Type</a>';
										break;
					}
				}
			}
		
		//		$orgResultsData['savedQueryFilterApplied']			= implode(', ',$arrFiltersApplied);
		//		pr($assoArrOrgByCountryCount);
		//Setting all the required data and forwording in to respective page
		$filterData['allRegionCount']		=	$allRegionCount;
		$filterData['allCountryCount']		=	$allCountryCount;
		$filterData['allStateCount']		=	$allStateCount;
		$filterData['allCityCount']			=	$allCityCount;
		$filterData['allOrgTypeCount']		=	$allOrgTypeCount;
		$filterData['arrOrgByRegionCount']	=	$assoArrOrgByRegionCount;
		$filterData['arrOrgByCountryCount']	=	$assoArrOrgByCountryCount;
		$filterData['arrOrgByStateCount']	=	$assoArrOrgByStateCount;
		$filterData['arrOrgByCityCount']	=	$assoArrOrgByCityCount;
		$filterData['arrOrgByTypeCount']	=	$assoArrOrgByTypeCount;
		//		$filterData['selectedOrgNames']		=   $arrOrgIdsAndNames;
		$filterData['selectedRegionTypes']	=	$arrFiltersOrg['global_region'];
		$filterData['selectedCountries']	=   $this->country_helper->getCountryNameById(($arrFiltersOrg['country']) ? $arrFiltersOrg['country'] : 0);
		$filterData['selectedStates']		=   $this->country_helper->getStateNameById(($arrFiltersOrg['state']) ? $arrFiltersOrg['state'] : 0);
		$filterData['selectedCities']		=   $this->country_helper->getCityNameById(($arrFiltersOrg['city']) ? $arrFiltersOrg['city'] : 0);
		$filterData['selectedOrgTypes']		=   $this->organization->getOrgTypeById(($arrFiltersOrg['org_types']) ? $arrFiltersOrg['org_types'] : 0);
		$filterData['savedFilterId']		=   $arrFilterById['id'];
		$filterData['keyword']				=	$arrFiltersOrg['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['viewType']			= 	$viewTypeMyOrgs;
		$arrFiltersOrg['resOrgType'] = "ALL";
		$allOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrFiltersOrg['resOrgType'] = "PARENT";
		$parentOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrFiltersOrg['resOrgType'] = "CHILD";
		$childOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$filterData['selectedOrgs']			= "ALL";
		$filterData['allOrgsCount']			= $allOrgsCount;
		$filterData['parentOrgsCount']		= $parentOrgsCount;
		$filterData['childOrgsCount']		= $childOrgsCount;
		$filterData['otherOrgsCount']		= $allOrgsCount - ($parentOrgsCount + $childOrgsCount);
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	"";
		$filterData['customFilters']		= $this->organization->getAllCustomFilterByUser($this->loggedUserId);
		$orgResultsData['orgsCount']=$count;
		//pr($arrOrganizations);
		$orgResultsData['arrOrganiations']	=	$arrOrganizations;
		$orgResultsData['searchType']		=	"simple";
		//$orgResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrFiltersOrg['keyword']);
		if(sizeof($arrFiltersOrg['profile_type'])>0){
			foreach ($arrFiltersOrg['profile_type'] as $k=>$v){
				$arrFiltersOrg['profile_type'] = $v;
			}
			$details['profileType'] = $arrFiltersOrg['profile_type'];
		
		}
		if(isset($arrFilterById['id']) && $arrFilterById['id'] != ''){
			$details['savedFilterName']						= $arrFilterById['name'];
			$details['savedQueryFilterApplied']				= implode(', ',$arrFiltersApplied);
		}else if($viewTypeMyOrgs != ''){
			$details['savedQueryFilterApplied']				= implode(', ',$arrFiltersApplied);
		}
		//$details['add_org']	= $this->common_helpers->isActionAllowed('org','add',$details);
		$details['orgResultsPage']			=	'organizations_listing';
		$details['orgsCount']			=	$count;
		$details['orgResultsData']			=	$orgResultsData;
		
		$details['arrOrganiations']			=	$arrOrganizations;
		$details['sidebar'] 				=	'organizations_filter';
		$details['filterData']				=	$filterData;
		$data['contentData']						=	$details;
		$data['contentPage'] 				=	'organizations_layout';
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	
	function view($organizationId = null,$subContentPage=''){
		if(!$organizationId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations_client_view');
		}
		if(!is_numeric($organizationId)){
			$organizationId = $this->process_url_parameters($organizationId);
		}
		if(!is_numeric($organizationId)){
			redirect('organizations/list_organizations_client_view');
		}
		
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
		//			pr($arrOrganizationDetail); exit;
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations_client_view');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $organizationId);
		
		//		$data['arrCountry']		=	$this->country_helper->listCountries();
		
		//		$arrStates 	= array();
		//		$arrCities	= array();
		if($arrOrganizationDetail['country_id'] != 0){
			$arrStates = $this->country_helper->getStatesByCountryId($arrOrganizationDetail['country_id']);
			$arrOrganizationDetail['country_name']=$this->country_helper->getCountryById($arrOrganizationDetail['country_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
			//			$arrCities = $this->country_helper->getCitiesByStateId($arrOrganizationDetail['state_id']);
			//			$stateCode	=	$this->country_helper->getStatecodeByStateIdorName($arrOrganizationDetail['state_id'],'id');
			//			$data['stateCode']	=	$stateCode;
			$arrOrganizationDetail['state_name'] = $this->country_helper->getStateById($arrOrganizationDetail['state_id']);
		}
		if($arrOrganizationDetail['city_id'] != 0){
			$arrOrganizationDetail['city_name']=$this->country_helper->getCityeById($arrOrganizationDetail['city_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
			if($arrOrganizationDetail['country_name']=='United States'){
				//$arrCities = $this->country_helper->getCitiesByStateId($arrKolDetail['state_id']);
				$stateCode	=	$this->country_helper->getStatecodeByStateIdorName($arrOrganizationDetail['state_id'],'id');
				$arrOrganizationDetail['state_code']	=	$stateCode;
			}
		}
		//		$data['arrStates']	= $arrStates;
		//		$data['arrCities']	= $arrCities;
		
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		
		$data['arrCountry']=$this->country_helper->listCountries();
		
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		$data['arrContactDetails']	= array();
		$arrContactDetails = array();
		if($arrContactDetails = $this->organization->listContacts($organizationId)){
			foreach ($arrContactDetails->result_array() as $row){
				$data['arrContactDetails'][] = $row;
			}
		}
		
		
		
		if($arrOrganizationDetail['type_id']!=PAYOR){
			$medicalDetails	= $this->organization->getMedicalServiceDetails($organizationId);
			if(isset($medicalDetails) && !empty($medicalDetails)){
				foreach($medicalDetails as $row){
					$medicalDetail[]=$row['name'];
				}
				$medicalDetails = implode(', ',$medicalDetail);
			}
			$data['medicalDetails'] = $medicalDetails;
				
			$arrStatFacts = $this->organization->getStatsAndFacts($organizationId);
			$data['arrStatFacts'] 			= $arrStatFacts;
		}
		
		if($arrOrganizationDetail['type_id']==PAYOR){
			//Payer starts
			$data['arrFacts'] = $this->organization->getAllOrgPayersFact($organizationId);
			$year = $this->get_enrollment_years();
			$data['years'] = $year;
			$data['arrEnroll'] 				= $this->organization->getAllOrgEnrollData($organizationId,$year);
			$fromularyIds 					= $this->organization->getOrgPayerFormularies($organizationId);
			$data['arrFormularies'] 		= $this->organization->getAllFormulariesData($fromularyIds);
			$dmIds							= $this->organization->getAllOrgDiseaseManagementIds($organizationId);
			$data['arrDiseseMngmt'] 		= $this->organization->getAllOrgDiseaseManagementData($dmIds);
			$data['arrCollabCategory'] 			= $this->organization->getAllCollaborationCategories();
			$data['arrCollabRatings'] 		= $this->organization->getAllOrgCollabarationRatings($organizationId);
			foreach ($data['arrCollabCategory'] as $k=>$v){
				if(array_key_exists($k,$data['arrCollabRatings'])){
					$data['arrCollabCategory'][$k]['ratings'] = $data['arrCollabRatings'][$k]['ratings'];
				}else{
					$data['arrCollabCategory'][$k]['ratings'] = '';
				}
			}
			//Payer ends
		}
		
		//$data['edit_org']	= $this->common_helpers->isActionAllowed('org','edit',$data);
		$data['arrNotes']  				= $this->organization->getNotes($organizationId);
		$data['arrOrganization']		= $arrOrganizationDetail;
		
		$data['contentPage'] 	= 'view_organization';
		$data['subContentPage']	=	$subContentPage;
		//$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
		
		if($subContentPage == 'details'){
			$this->load->model('Specialty');
			$specialtyName            = $this->Specialty->getAllSpecialties();
			$mcoType            = $this->organization->getMcoTypeNames();
			$addressType            = $this->organization->getAddressTypeNames();
			$data['arrCountries']=$this->country_helper->listCountries();
			$data['staffs'] = $this->organization->getStaffs($organizationId, 'organization');
			$data['phones'] = $this->organization->getPhones($organizationId, 'organization');
			//                       pr($organizationId); pr(    $data['staffs']); exit;
			$data['arrInstitutions']=$this->country_helper->listCountries();
			$validationStatus            = $this->organization->getValidationStatusNames();
			$arrMcoTypeTemp = array();
			foreach ($mcoType as $key => $value) {
				$arrMcoTypeTemp[$value['id']] = ($value['name']);
			}
			$arrAddressTypeTemp = array();
			foreach ($addressType as $key => $value) {
				$arrAddressTypeTemp[$value['id']] = ($value['name']);
			}
			$arrValidationStatusTemp = array();
			foreach ($validationStatus as $key => $value) {
				$arrValidationStatusTemp[$value['id']] = ($value['name']);
			}
			$data['validationStatus']=$arrValidationStatusTemp;
			$data['specialtyName']=$specialtyName;
			$data['mcoType']=$arrMcoTypeTemp;
			$data['addressType']=$arrAddressTypeTemp;
			$data['arrLocations'] = $this->organization->getAllLocationsByOrgId($organizationId);
			//                pr( $data['arrLocations']); exit;
			$arrContactData = $this->organization->getContactRestrictions($organizationId);
			$data['arrContactData']= $arrContactData[0];
		}
		//pr($data);exit;
		$data['contentPage'] 				=	'organizations_view';
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	
	/**
	 * returns the simple filter search results for Event, matching the keyword with event name
	 * @return Array
	 */
	function filter_search_organizations(){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
//            pr($_POST);
		$page=$this->input->post('page');
		$count=0;
		$arrQueryOptions['sort_by']				= 'name';
		$arrQueryOptions['sort_order']			= 'asc';
		$viewType								= $this->uri->segment(3);
		$noOfRecordsPerPage						= $this->uri->segment(4);
		if($viewType=='list'){
			$arrQueryOptions['sort_by']			= $this->input->post('sort_by');
			$arrQueryOptions['sort_order']		= $this->input->post('sort_order');
			if($noOfRecordsPerPage==''){
				$noOfRecordsPerPage				= 10;
			}
		}
		if($noOfRecordsPerPage=='' && ($viewType=='main' || $viewType=='')){
			$noOfRecordsPerPage					= 10;
		}
		
//		$noOfRecordsPerPage	= $this->uri->segment(3);
		if(!empty($noOfRecordsPerPage))
			$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$details=array();
		$keyword	= $this->input->post('keyword');
		$orgName	= $keyword;
		$searchType = $this->input->post('search_type');
	//	if((int)$page>-1){
			//if the request is for the next page result then get the already saved search and filter fields from session
//			$keyword=trim($this->session->userdata('keyword'));	
//			$arrFilterOrgs=$this->session->userdata('arrFilterFields');	
	//	}
	//	else{
			$acOrgName	= trim($this->input->post('org_name'));
			$global_region 	= trim($this->input->post('region_type_id'));
			$country 	= trim($this->input->post('country_id'));		
			$state	 	= trim($this->input->post('state_id'));
			$city	 	= trim($this->input->post('city_id'));
			$orgType 	= trim($this->input->post('org_type_id'));
			//$resOrgType = "ALL";
			$orgsType = trim($this->input->post('orgsType'));
			if($orgsType != ''){
				/* $arrOrgs = array(array("ALL","CHILD"),array("PARENT","BOTH"));
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				$resOrgType = $arrOrgs[$arrOrgsType[0]][$arrOrgsType[1]]; */
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				foreach($arrOrgsType as $row){
					if($row != '0'){
						$resOrgType[] = $row;
					}
				}
				if(empty($resOrgType)){
					$resOrgType[] = "ALL";
				}
			}
			if($orgType=="Enter Org Type"){
				$orgType	= '';
			}
			if($acOrgName=="Enter Org Name"){
				$acOrgName	= '';
			}
			if($global_region=="Enter Global Region"){
				$global_region	= '';
			}
			if($country=="Enter Country"){
				$country	= '';
			}
			if($acOrgName=='Enter Org Name'){
				$acOrgName	= '';
			}
			//Get all the selected checkboxs details for respective category
			$arrOrgIds	=	array();
			$arrOrgIds	=	$this->input->post('org_ids');
			if(sizeof($arrOrgIds)>0 && $arrOrgIds!=''){
				$arrOrgIds	=explode(",",$arrOrgIds);
			}
			if($acOrgName!=''){
				$arrIds			= $this->organization->getOrgIdByOrgName($acOrgName,true);
				//$arrOrgIds		= array_merge((array)$arrOrgIds, (array)$arrIds);
				$arrOrgIds		= $arrIds;
			}
			//pr($arrOrgIds);
			$arrGlobalRegions	=	$this->input->post('global_regions');
			if($arrGlobalRegions!='')
				$arrGlobalRegions	=explode(",",$arrGlobalRegions);
				//if the input field is not blank add the value in to respective category array values
				if($global_region!='')
					$arrGlobalRegions[]	=	$global_region;
						
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			//if the input field is not blank add the value in to respective category array values
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			//if the input field is not blank add the value in to respective category array values
			if($state!='')
				$arrStates[]	=	$state;
				
			$arrCities	=	$this->input->post('cities');
			if($arrCities!='')
				$arrCities	=explode(",",$arrCities);
			//if the input field is not blank add the value in to respective category array values
			if($city!='')
				$arrCities[]	=	$city;
			
			$arrOrgTypes	=	$this->input->post('org_types');
			if($arrOrgTypes!='')
				$arrOrgTypes	=explode(",",$arrOrgTypes);
			if($orgType!=''){
				$arrOrgTypes[]	=	$orgType;
			}
			$profileType	=	$this->input->post('profile_type');
                          
			$viewTypeMyOrgs = $this->input->post('view_type');
// 			$viewTypeMyOrgs = $this->input->post('viewTypeMyOrgs');
			//echo 'profile '.$viewMyOrgs;
		if($viewTypeMyOrgs == MY_RECORDS){
			$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
			//echo $this->db->last_query();
			if(sizeof($viewMyOrgs) > 0){
				$viewTypeMyOrgs = MY_RECORDS;
				$arrFilterOrgs['viewType'] = $viewMyOrgs;
			}else{
				$arrFilterOrgs['viewType'] = array(0);
			}						
		}
		$arrFilterOrgs['view_type'] 	= array($viewTypeMyOrgs);
		$arrFilterOrgs['profileType'] 	= array($profileType);
		$arrFilterOrgs['orgIds'] 		= $arrOrgIds;
		$arrFilterOrgs['type'] 			= $arrOrgTypes;
		$arrFilterOrgs['global_region'] = $arrGlobalRegions;
		$arrFilterOrgs['country'] 		= $arrCountries;
		$arrFilterOrgs['state'] 		= $arrStates;
		$arrFilterOrgs['city'] 			= $arrCities;
		$arrFilterOrgs['profileType'] 	= $profileType;
		$arrFilterOrgs['resOrgType'] 	= $resOrgType;
//                pr($arrFilterOrgs); exit;
		//Getting "filter Search MatchingEvents"
		$arrOrganizations	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,false,null,$arrQueryOptions);
		//echo $this->db->last_query();
		$count				= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
//		echo $this->db->last_query();
//		$this->session->set_userdata('keyword',$keyword);
//		$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);
//		pr($this->session->userdata('arrFilterFields'));
		$arrFiltersApplied	= array();
		
		foreach($arrFilterOrgs as $section =>$arrValues){
			if((sizeof(array_filter($arrValues)))>0){
				$separator	= ' | ';
				switch($section){
					case 'orgIds': 
									$arrFiltersApplied['organizations']	= 'Organization Name';
									break;
					case 'global_region':
					                $arrSelectedRegion = $arrGlobalRegions;
					                $arrFiltersApplied['global_region']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedRegion).'">Region</a>';
									break;
					case 'country':  
									$arrSelectedCountries			= $this->country_helper->getCountryNameById($arrCountries);
									$arrFiltersApplied['country']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCountries).'">Country</a>';
									break;
					case 'state':  
									$arrSelectedStates			= $this->country_helper->getStateNameById($arrStates);
									$arrFiltersApplied['state']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedStates).'">State</a>';
									break;
					case 'city':  
									$arrSelectedCities			= $this->country_helper->getCityNameById($arrCities);
									$arrFiltersApplied['city']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCities).'">City</a>';
									break;
					case 'type':  
									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
									$arrFiltersApplied['organization_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedOrgTypes).'">Organization Type</a>';
									break;
					case 'profileType':  
//									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
									if($profileType == 2)
										$profileTypeValue = "Full Profiles";
									else
										$profileTypeValue = "Basic Profiles";
									$arrFiltersApplied['profile_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$profileTypeValue.'">Profile Type</a>';
									break;
					case 'view_type':
									if($arrValues[0] == 1)
										$viewTypeString = "My Organizations";
									else
										$viewTypeString = "All Organizations";
									$arrFiltersApplied['viewType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$viewTypeString.'">View Type</a>';
									break;
				}
			}
		}
// 		$orgsTypeStr = ($resOrgType == "BOTH" ? "All" : ucwords(strtolower($resOrgType)))." Organizations";
// 		$arrFiltersApplied['resOrgType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$orgsTypeStr.'">Orgs Type</a>';
		$orgResultsData['filtersApplied']	= implode(', ',$arrFiltersApplied);
		
		//$filterData['arrConfSessionTypes'] 	= $arrFilterOrgs['type'] ;
		$filterData['keyword']				= $keyword;
		$filterData['searchType']			= $searchType;
		$filterData['arrFilterFields']		= $arrFilterOrgs;
		$filterData['arrAdvSearchFields']	= "";
		$orgResultsData['orgsCount']		= $count;
		$orgResultsData['arrOrganiations']	= $arrOrganizations;
		$orgResultsData['searchType']		= "simple";
		//$orgResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$orgResultsData['profileType']		= $profileType;
		$details['orgResultsPage']			= 'search/my_org_results';
		$details['orgResultsData']			=	$orgResultsData;
		$orgResultsData['arrSortBy']		= $arrQueryOptions;
		$details['arrOrganiations']			= $arrOrganizations;
		$details['filterPage']				= 'search/org_filters';
		$details['filterData']				= $filterData;
		$data['data']						= $details;
		$data['contentPage'] 				= 'search/org_results';
		//$this->load->model('Event_helper');
		//$arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
		$data['arrConfSessionTypes']	= $arrConfSessionTypes;
		$this->load->view('organizations_listing',$orgResultsData);
	}
	
	function reload_filters(){
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$details=array();
		$keyword	= $this->input->post('keyword');
		$orgName	= $keyword;
		$searchType = $this->input->post('search_type');
		$viewTypeMyOrgs = $this->input->post("viewTypeMyOrgs");
	//	if((int)$page>-1){
			//if the request is for the next page result then get the already saved search and filter fields from session
	//		$keyword=trim($this->session->userdata('keyword'));	
	//		$arrFilterOrgs=$this->session->userdata('arrFilterFields');	
	//	}
	//	else{
			$acOrgName	= trim($this->input->post('org_name'));
			$global_region = trim($this->input->post('region_type_id')); 
			$country 	= trim($this->input->post('country_id'));
			$state	 	= trim($this->input->post('state_id'));
			$city	 	= trim($this->input->post('city_id'));
			$orgType 	= trim($this->input->post('org_type_id'));
			//$resOrgType = "ALL";
			$orgsType = trim($this->input->post('orgsType'));
			if($orgsType != ''){
				/* $arrOrgs = array(array("ALL","CHILD"),array("PARENT","BOTH"));
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				$resOrgType = $arrOrgs[$arrOrgsType[0]][$arrOrgsType[1]]; */
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				foreach($arrOrgsType as $row){
					if($row != '0'){
						$resOrgType[] = $row;
					}
				}
				if(empty($resOrgType)){
					$resOrgType[] = "ALL";
				}
			}
			//Get all the selected checkboxs details for respective category
			$arrOrgIds=array();
			$arrOrgIds	=	$this->input->post('org_ids');
			if($arrOrgIds!=''){
				//$arrOrgIds	=	$this->input->post('org_ids');
				$arrOrgIds	=explode(",",$arrOrgIds);
			}
			if($acOrgName!=''){
				$arrOrgIds	=	array($this->organization->getOrgIdByOrgName($acOrgName));
			}
			$arrGlobalRegions	=	$this->input->post('global_regions');
			if($arrGlobalRegions!='')
				$arrGlobalRegions	=explode(",",$arrGlobalRegions);
				//if the input field is not blank add the value in to respective category array values
				if($global_region!='')
					$arrGlobalRegions[]	=	$global_region;
						
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			//if the input field is not blank add the value in to respective category array values
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			//if the input field is not blank add the value in to respective category array values
			if($state!='')
				$arrStates[]	=	$state;
				
			$arrCities	=	$this->input->post('cities');
			if($arrCities!='')
				$arrCities	=explode(",",$arrCities);
			//if the input field is not blank add the value in to respective category array values
			if($city!='')
				$arrCities[]	=	$city;
			
			$arrOrgTypes	=	$this->input->post('org_types');
			if($arrOrgTypes!='')
				$arrOrgTypes	=explode(",",$arrOrgTypes);
			if($orgType!=''){
				$arrOrgTypes[]	=	$orgType;
			}
			$profileType	=	$this->input->post('profile_type');

			$arrFilterOrgs['orgIds'] 	= $arrOrgIds;
			$arrFilterOrgs['global_region'] 	= $arrGlobalRegions;
			$arrFilterOrgs['country'] 	= $arrCountries;
			$arrFilterOrgs['state'] 	= $arrStates;
			$arrFilterOrgs['city'] 		= $arrCities;
			$arrFilterOrgs['type'] 		= $arrOrgTypes;
			$arrFilterOrgs['profileType'] 	= $profileType;
				
	//	}
		if($viewTypeMyOrgs == MY_RECORDS){
				$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
				if(sizeof($viewMyOrgs) > 0){
					$viewTypeMyOrgs = MY_RECORDS;
					$arrFilterOrgs['viewType'] = $viewMyOrgs;
				}else{
					$arrFilterOrgs['viewType'] = array(0);
				}				
			}
		$arrOrgByRegionCount	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"region");
		$arrOrgByCountryCount	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"country");
		$arrOrgByStateCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"state");
		$arrOrgByCityCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"city");
		$arrOrgByTypeCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"type");
		//$this->session->set_userdata('keyword',$keyword);
		//$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);

		$arrFilterOrgs['resOrgType'] = "ALL";
		$allOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "PARENT";
		$parentOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "CHILD";
		$childOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "OTHER";
		$otherOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		/* pr($this->db->last_query());
		exit; */
		$arrOrgIdsAndNames=array();		
		if($arrOrgIds !=''){
			foreach($arrOrgIds as $id){
				$arrOrgIdsAndNames[$id]=$this->organization->getOrgNameByOrgId($id);
			}
		}
		
		$allRegionCount=0;
		$assoArrOrgByRegionCount=array();
		foreach($arrOrgByRegionCount as $row){
			$assoArrOrgByRegionCount[$row['GlobalRegion']]=$row;
			$allRegionCount+=$row['count'];
		}
		
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrgByCountryCount as $row){
			$assoArrOrgByCountryCount[$row['country_id']]=$row;
			$allCountryCount+=$row['count'];
		}
		
		$allStateCount=0;
		$assoArrOrgByStateCount=array();
		foreach($arrOrgByStateCount as $row){
			$assoArrOrgByStateCount[$row['state_id']]=$row;
			$allStateCount+=$row['count'];
		}
		
		$allCityCount=0;
		$assoArrOrgByCityCount=array();
		foreach($arrOrgByCityCount as $row){
			$assoArrOrgByCityCount[$row['city_id']]=$row;
			$allCityCount+=$row['count'];
		}
		
		$allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['org_type_id']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
		//$filterData['arrConfSessionTypes']= $arrFilterOrgs['type'] ;
		$filterData['allRegionCount']		= $allRegionCount;
		$filterData['allCountryCount']		= $allCountryCount;
		$filterData['allStateCount']		= $allStateCount;
		$filterData['allCityCount']			= $allCityCount;
		$filterData['allOrgTypeCount']		= $allOrgTypeCount;
		$filterData['arrOrgByRegionCount']	= $assoArrOrgByRegionCount;
		$filterData['arrOrgByCountryCount']	= $assoArrOrgByCountryCount;
		$filterData['arrOrgByStateCount']	= $assoArrOrgByStateCount;
		$filterData['arrOrgByCityCount']	= $assoArrOrgByCityCount;
		$filterData['arrOrgByTypeCount']	= $assoArrOrgByTypeCount;
		$filterData['selectedOrgNames']		= $arrOrgIdsAndNames;
		foreach($arrFilterOrgs['global_region'] as $values){
			$selectedRegionTypes[$values]=$values;
		}
		$filterData['selectedRegionTypes']	=	$selectedRegionTypes;
		$filterData['selectedCountries']	= $this->country_helper->getCountryNameById($arrCountries);
		$filterData['selectedStates']		= $this->country_helper->getStateNameById($arrStates);
		$filterData['selectedCities']		= $this->country_helper->getCityNameById($arrCities);
		$filterData['selectedOrgTypes']		= $this->organization->getOrgTypeById($arrOrgTypes);
		$filterData['selectedProfileTypes']	= $profileType;
		$filterData['viewType']				= $viewTypeMyOrgs;
		$filterData['selectedOrgs']			= $resOrgType; //$resOrgType;
		$filterData['allOrgsCount']			= $allOrgsCount;
		$filterData['parentOrgsCount']		= $parentOrgsCount;
		$filterData['childOrgsCount']		= $childOrgsCount;
		$filterData['otherOrgsCount']		= $otherOrgsCount; //$allOrgsCount - ($parentOrgsCount + $childOrgsCount);
		$filterData['keyword']				= $keyword;
		$filterData['searchType']			= $searchType;
		$filterData['arrFilterFields']		= $arrFilterOrgs;
		$filterData['arrAdvSearchFields']	= "";
		$filterData['customFilters']		= $this->organization->getAllCustomFilterByUser($this->loggedUserId);
		$this->load->view('organizations_filter',$filterData);
	}
			
	/**
	 * Retruns the Organization Types matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return JSON
	 * @created 25-07-2011
	 */
	function get_org_types($orgType){
		$orgType		= $this->input->post($orgType);
		$arrOrgTypes = $this->organization->getMatchingOrgTypes($orgType);
		$arrSuggestTypes	= array();
		if(sizeof($arrOrgTypes)==0){
			$arrSuggestTypes[0]		= 'No results found for '.$orgType;
		}else{
			$flag	= 1;
			foreach($arrOrgTypes as $typeId=>$type){
				if($flag){
					$arrSuggestTypes[]='<div class="autocompleteHeading">Organization Types</div><div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestTypes[]='<div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $orgType;
		$arrReturnData['suggestions']	= $arrSuggestTypes;
		echo json_encode($arrReturnData);
	}
	
	function add_org_saved_filters() {
		$this->load->view('add_saved_filters',$data);
	}
	
	function save_custom_filters() {
		$arrData['name'] 			= trim(ucfirst($this->input->post('filterName')));
		$arrData['filter_type'] 	= 2;
		$arrData['filter_value'] 	= json_encode($this->input->post('saveFilter'));
		$arrData['created_on'] 		= date('Y-m-d H:i:s');
		$arrData['created_by'] 		= $this->loggedUserId;
		$arrData['client_id'] 		= $this->session->userdata('client_id');
		$arrData['applied_on'] 		= date('Y-m-d H:i:s');
		$lastId = $this->organization->saveCustomFilters($arrData);
		if($lastId){
			$data['status'] = true;
			$data['id'] = $lastId;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	function add_org($id=''){
		$this->load->model('specialties/specialty');
		
		if (!is_numeric($id)){
			$contentPage=$id;
			
			if($contentPage=="pharmacy"){
				$specialtyName            = $this->specialty->getAllSpecialties("pharamacy");
			}
			elseif($contentPage=="department"){
				$specialtyName            = $this->specialty->getAllSpecialties("department");
			}
			elseif($contentPage=="managed_care_org"){
				$specialtyName            = $this->specialty->getAllSpecialties("mco");
			}
			else{
				$specialtyName            = $this->specialty->getAllSpecialties();
			}
		}
		
		$mcoType            = $this->organization->getMcoTypeNames();
		$addressType            = $this->organization->getAddressTypeNames();
		$data['arrCountries']=$this->country_helper->listCountries();
		$first_key = key($data['arrCountries']);
		$data['arrFirstCountry'] = $data['arrCountries'][$first_key]['country_id'];
		if(!is_numeric($id)){
			//                 	$data['arrStates'] = $this->country_helper->getStatesByCountryId($data['arrFirstCountry']);
			$data['arrStates'] = array();
			$data['checkKolAssignedToUser']=true;
		}
		$data['arrInstitutions']=$this->country_helper->listCountries();
		$validationStatus            = $this->organization->getValidationStatusNames();
		$arrMcoTypeTemp = array();
		foreach ($mcoType as $key => $value) {
			$arrMcoTypeTemp[$value['id']] = ($value['name']);
		}
		$arrAddressTypeTemp = array();
		foreach ($addressType as $key => $value) {
			$arrAddressTypeTemp[$value['id']] = ($value['name']);
		}
		$arrValidationStatusTemp = array();
		foreach ($validationStatus as $key => $value) {
			$arrValidationStatusTemp[$value['id']] = ($value['name']);
		}
		$data['validationStatus']=$arrValidationStatusTemp;
		
		$data['mcoType']=$arrMcoTypeTemp;
		$data['addressType']=$arrAddressTypeTemp;
		if((!empty($id)) && (is_numeric($id))){
			$data['locationData'] = $this->organization->getLocationByOrganizationId($id);
			$data['locationData'] = $data['locationData'][0];
			$arr = array();//$this->kol->getKolPrimaryPhoneDetails($id);
			if (isset($arr['id'])) {
				$data['locationData']['phone_number_primary'] = $arr['number'];
				$data['locationData']['phone_type_primary'] = $arr['type'];
			} else {
				$data['locationData']['phone_number_primary'] = '';
				$data['locationData']['phone_type_primary'] = '';
			}
			$data['arrCountries'] = $this->country_helper->listCountries();
			$data['arrStates'] = $this->country_helper->getStatesByCountryId($data['locationData']['country_id']);
		
			$stateID=$data['locationData']['state_id'];
			$data['arrCities']=$this->country_helper->getCitiesByStateId($stateID);
			//                    $data['arrStates'] = $this->country_helper->listStates();
			$data['orgDetails']= $this->organization->editOrg($id);
			$orgType =$data['orgDetails'][0]['org_type'];
			if($orgType=="pharmacy"){
				$specialtyName            = $this->specialty->getAllSpecialties("pharamacy");
			}
			elseif($orgType=="department"){
				$specialtyName            = $this->specialty->getAllSpecialties("department");
			}
			elseif($orgType=="managed_care_org"){
				$specialtyName            = $this->specialty->getAllSpecialties("mco");
			}
		
			else{
				$specialtyName            = $this->specialty->getAllSpecialties();
			}
			$data['contactRestrictions']= $this->organization->getContactRestrictions($id);
			$data['checkKolAssignedToUser']=$this->organization->checkOrgAissenedToUser($id);
		}
		 
		$data['specialtyName']=$specialtyName;
		$data['arrPhoneType'] = array("woprk", "others");//$this->kol->getPhoneType();
		$data['contentPage'] 	=	'organizations/organizations_add';
		
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	
	function save_org(){
		$previousUrl=$this->input->post('previousUrl');
		$org_id = $this->input->post('id');
		if($org_id==null || $org_id=='') {
			$arrData = array();
			$data=array();
			$orgData=array();
			$arrData['name'] = $this->input->post('name');
			$arrData['foundation'] = $this->input->post('foundation');
			$arrData['phone'] = $this->input->post('phone');
			$arrData['specialty'] = $this->input->post('specialty');
			$arrData['admission_per_year'] = $this->input->post('admission_per_year');
			$arrData['website'] = $this->input->post('website');
			$arrData['patients_per_week'] = $this->input->post('patients_per_week');
			$arrData['institution_type']	= $this->input->post('institution_type');
			$arrData['number_of_beds']	= $this->input->post('number_of_beds');
			$arrData['fax']	= $this->input->post('fax');
			$arrData['num_of_physician'] = $this->input->post('num_of_physician');
			$arrData['licensing_opertunities'] = $this->input->post('licensing_opertunities');
			$arrData['email'] = $this->input->post('email');
			$arrData['rx_vol'] = $this->input->post('rx_vol');
			$arrData['num_of_residents'] = $this->input->post('num_of_residents');
			$arrData['ists'] = $this->input->post('ists');
			$arrData['size']	= $this->input->post('size');
			$arrData['background']	= $this->input->post('background');
			$arrData['research']	= $this->input->post('research');
			$arrData['csts']	= $this->input->post('csts');
			$arrData['irb_present']	= $this->input->post('irb_present');
			$arrData['ceo_name']	= $this->input->post('ceo_name');
			$arrData['org_type']	= $this->input->post('org_type');
			if($arrData['org_type'] == "managed_care_org")
				$arrData['org_type'] = "Managed Care Organization";
				$arrOrgTypes = $this->organization->getMatchingOrgTypes($arrData['org_type']);
				reset($arrOrgTypes);
				$arrData['type_id'] = key($arrOrgTypes);
				if($arrData['type_id']==''){
					$typeId = $this->organization->getOrgTypeByName($arrData['org_type']);
					$arrData['type_id'] = $typeId['id'];
				}
				$typeId = $this->organization->getOrgTypeByName($arrData['institution_type']);
				$arrData['type_id'] = $typeId['id'];
				$arrData['status_otsuka'] = "ACTV";
				$arrData['mco_type']	= $this->input->post('mco_type');
				if($this->input->post('address2')!="")
					$arrData['address'] 	= trim($this->input->post('address1').', '.$this->input->post('address2'));
				else
					$arrData['address'] 	= trim($this->input->post('address1'));
					$arrData['country_id'] 	= $this->input->post('country_id');
					$arrData['state_id'] 	= $this->input->post('state_id');
					$arrData['city_id'] 		= $this->input->post('city_id');
	
				if($arrData['state_id'] == '')
					unset($arrData['state_id']);
				if($arrData['state_id'] == '')
					unset($arrData['state_id']);
	
				$arrData['postal_code'] 	= $this->input->post('postal_code');
				$arrData['status']	= "Completed";
				$arrData['profile_type']	= 1;
				//pr($arrData);exit;
				$data['visit'] = $this->input->post('visit');
				$data['call'] = $this->input->post('call');
				$data['fax'] = $this->input->post('contact_fax');
				$data['mail'] = $this->input->post('mail');
				$data['email'] = $this->input->post('emailCheck');
				$data['contact_type'] = "organization";
				$lastId	=$this->organization->saveOrg($arrData,$data);

				$orgData['org_id'] 			= $lastId;
				$orgData['main'] 		= $this->input->post('organization');
				$orgData['address1'] 			= trim($this->input->post('address1'));
				$orgData['address2'] 			= trim($this->input->post('address2'));
				$orgData['address3'] 			= trim($this->input->post('address3'));
				$orgData['validation_status'] 		= trim($this->input->post('validation_status'));
				$orgData['address_type'] 		= trim($this->input->post('address_type'));
				$orgData['country_id'] 	= $this->input->post('country_id');
				$orgData['state_id'] 	= $this->input->post('state_id');
				$orgData['city_id'] 		= $this->input->post('city_id');
	
				if($orgData['state_id'] == '')
					unset($orgData['state_id']);
				if($orgData['state_id'] == '')
					unset($orgData['state_id']);
	
				$orgData['postal_code'] 	= $this->input->post('postal_code');
				$orgData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
				$orgData['phone_type_primary'] 	= $this->input->post('phone_type_primary');

				if($this->input->post('is_primary') == "1")
					$orgData['is_primary'] 			= $this->input->post('is_primary');
				$orgData['created_by'] 		= $this->loggedUserId;
				$orgData['created_on'] 		= date('Y-m-d H:i:s');
				$orgData['modified_by'] 		= $this->loggedUserId;
				$orgData['modified_on'] 		= date('Y-m-d H:i:s');
				$orgLocLasId = $this->organization->saveLocation($orgData);
	
				if(isset($orgData['phone_type_primary']) && $orgData['phone_type_primary'] > 0){
					$orgPhone = array();
					$orgPhone['type'] = $this->input->post('phone_type_primary');
					$orgPhone['number'] = $this->input->post('phone_number_primary');
					$orgPhone['contact_type'] = 'organization';
					$orgPhone['contact'] = $lastId;
					$orgPhone['is_primary'] = $this->input->post('is_primary');
					$orgPhone['location_id'] = $orgLocLasId;
					$orgPhone['created_by'] = $this->loggedUserId;
					$orgPhone['created_on'] = date('Y-m-d H:i:s');
					//$lastPhoneId = $this->kol->savePhone($orgPhone);
				}
				//Assign User
				$arrAssignData = array();
				$arrAssignData['user_id'] = $this->loggedUserId;
				$arrAssignData['org_id'] = $lastId;
				$saveAssignId = $this->organization->saveOrgAssignClient($arrAssignData);
				//                        redirect($previousUrl);
				redirect('/organizations/view/'.$lastId);
		} else {
			$arrData = array();
			$data=array();
			$orgData=array();
			$arrData['id'] = $this->input->post('id');
			$arrData['name'] = $this->input->post('name');
			$arrData['foundation'] = $this->input->post('foundation');
			$arrData['phone'] = $this->input->post('phone');
			$arrData['specialty'] = $this->input->post('specialty');
			$arrData['admission_per_year'] = $this->input->post('admission_per_year');
			$arrData['website'] = $this->input->post('website');
			$arrData['patients_per_week'] = $this->input->post('patients_per_week');
			$arrData['institution_type']	= $this->input->post('institution_type');
			$arrData['number_of_beds']	= $this->input->post('number_of_beds');
			$arrData['fax']	= $this->input->post('fax');
			$arrData['num_of_physician'] = $this->input->post('num_of_physician');
			$arrData['licensing_opertunities'] = $this->input->post('licensing_opertunities');
			$arrData['email'] = $this->input->post('email');
			$arrData['rx_vol'] = $this->input->post('rx_vol');
			$arrData['num_of_residents'] = $this->input->post('num_of_residents');
			$arrData['ists'] = $this->input->post('ists');
			$arrData['size']	= $this->input->post('size');
			$arrData['research']	= $this->input->post('research');
			$arrData['background']	= $this->input->post('background');
			$arrData['csts']	= $this->input->post('csts');
			$typeId = $this->organization->getOrgTypeByName($arrData['institution_type']);
			$arrData['type_id'] = $typeId['id'];
			$arrData['irb_present']	= $this->input->post('irb_present');
			$arrData['ceo_name']	= $this->input->post('ceo_name');
			$arrData['mco_type']	= $this->input->post('mco_type');
			$arrData['status']	= "Completed";
			if($this->input->post('address2')!="")
				$arrData['address'] 	= trim($this->input->post('address1').', '.$this->input->post('address2'));
			else
				$arrData['address'] 	= trim($this->input->post('address1'));
			$arrData['country_id'] 	= $this->input->post('country_id');
			$arrData['state_id'] 	= $this->input->post('state_id');
			$arrData['city_id'] 		= $this->input->post('city_id');

			if($arrData['state_id'] == '')
				unset($arrData['state_id']);
			if($arrData['state_id'] == '')
				unset($arrData['state_id']);
	
			$arrData['postal_code'] 	= $this->input->post('postal_code');
			$data['visit'] = $this->input->post('visit');
			$data['call'] = $this->input->post('call');
			$data['fax'] = $this->input->post('contact_fax');
			$data['mail'] = $this->input->post('mail');
			$data['email'] = $this->input->post('emailCheck');
			$data['contact_type'] = "organization";
			$data['contact'] = $this->input->post('id');
			$this->organization->updateOrg($arrData,$data);
			$orgID=$arrData['id'];
			$orgData['org_id'] 			= $this->input->post('id');

			$orgData['main'] 		= $this->input->post('organization');
			$orgData['address1'] 			= trim($this->input->post('address1'));
			$orgData['address2'] 			= trim($this->input->post('address2'));
			$orgData['address3'] 			= trim($this->input->post('address3'));
			$orgData['validation_status'] 		= trim($this->input->post('validation_status'));
			$orgData['address_type'] 		= trim($this->input->post('address_type'));
			$orgData['country_id'] 	= $this->input->post('country_id');
			$orgData['state_id'] 	= $this->input->post('state_id');
			$orgData['city_id'] 		= $this->input->post('city_id');
			if($orgData['state_id'] == '')
				unset($orgData['state_id']);
			if($orgData['state_id'] == '')
				unset($orgData['state_id']);
			$orgData['postal_code'] 	= $this->input->post('postal_code');
			$orgData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
			$orgData['phone_type_primary'] 	= $this->input->post('phone_type_primary');
			if($this->input->post('is_primary') == "1")
				$orgData['is_primary'] 			= $this->input->post('is_primary');
			$orgData['created_by'] 		= $this->loggedUserId;
			$orgData['created_on'] 		= date('Y-m-d H:i:s');
			$orgData['modified_by'] 		= $this->loggedUserId;
			$orgData['modified_on'] 		= date('Y-m-d H:i:s');
			$orgId=$arrData['id'];
			if($orgData['id'] > 0){
				$orgData['id'] 			= $this->input->post('org_location_id');
				$this->organization->updateOrgLocation($orgData);
				$arrPhoneDataExist['contact'] = $this->input->post('id');
				$arrPhoneDataExist['location_id'] = $this->input->post('org_location_id');
			}else{
				$orgLocLasId = $this->organization->saveLocation($orgData);
				$arrPhoneDataExist['contact'] = $this->input->post('id');
				$arrPhoneDataExist['location_id'] = $orgLocLasId;
			}
			redirect('/organizations/view/'.$orgId);
		}
	}
	
	function list_sub_org_details($orgId){
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$subOrgDetails			=	array();
		if($subOrgDetails	= $this->organization->getSubOrg($orgId)){
			//echo $this->db->last_query();
			$count	=	sizeof($subOrgDetails);
			if( $count >0 ) {
				$total_pages = ceil($count/$limit);
			}else{
				$total_pages = 0;
			}
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$subOrgDetails;
		}else{
			$data['records']	=	0;
		}
		echo json_encode($data);
	}
	
	function save_notes($kolId) {
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$arr['note'] = trim($this->input->post('user_note'));
		$arr['created_by'] = $this->loggedUserId;
		$arr['created_on'] = date("Y-m-d H:i:s");
		$arr['org_id'] = $kolId;
		$arr['document']= '';
		$arr['document_name']= '';
		if($_FILES["note_file"]['name']!=''){
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
			$path_info = pathinfo($_FILES["note_file"]['name']);
			$newFileName	= random_string('unique', 20).".".$path_info['extension'];
			$overview_file_target_path = $target_path ."/". $newFileName;
			if(move_uploaded_file($_FILES['note_file']['tmp_name'],$overview_file_target_path)){
				$arr['document'] = $newFileName;
				$fname = explode('.', $_FILES["note_file"]['name']);
				$arr['orginal_doc_name']= $_FILES["note_file"]['name'];
				$arr['document_name']= $fname[0];
				if($this->input->post('fileName')){
					$arr['document_name']= trim($this->input->post('fileName'));
				}
			}
		}
		$arr['id'] = $this->organization->saveNote($arr);
		$arr['name'] = $this->session->userdata('user_full_name');
		$currentDateTime = $arr['created_on'];
	
		$arr['created_on'] = date('d M Y, h:i A', strtotime($currentDateTime));
		$arr['note'] = nl2br($arr['note']);
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'module' => 'organizations',
				'type' => LOG_ADD,
				'description' => 'Save Org Note',
				'status' => 'success',
				'transaction_id' => $arr['id'],
				'transaction_table_id' => ORG_NOTES,
				'transaction_name' => 'Save Org Note',
				'form_data' => $formData,
				'parent_object_id'=>$arr['org_id'],
		);
	
		$this->config->set_item('log_details', $arrLogDetails);
		//log_user_activity(null, true);
		 
		//log_user_activity($arrLogDetails, true);
		echo json_encode($arr);
	}
	
	
	/*
	 *  Display organization Associated People
	 */
	function view_keypeople($organizationId = null,$subContentPage=''){
		if(!$organizationId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $organizationId);
	
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		//$data['arrAssocPeople']	= $this->organization->listOrgAssociatedPpl($organizationId);
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		//$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
	
		$data['arrOrganization']	= $arrOrganizationDetail;
		//$data['contentPage'] 	= 'organizations/view_associated_people';
		$data['subContentPage']	=	$subContentPage;
		//$this->load->view('layouts/client_view',$data);
		$data['contentPage'] 	=	'organizations/view_associated_people';
		
		$this->load->view(CLIENT_LAYOUT.'header',$data);
		
	}
	
	function list_key_peoples($orgId=null){
		//$arrKols				= $this->payment->getAllKolsName1();
		//$arrKols  = $this->pubmed_org->getKolNamesWithConcat();
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$arrKeyPeople			=	array();
		$data['arrKeyPeople']	=	$arrKeyPeople;
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
	
		$arrAssociltedPeople = array();
		$arrDetails = array();
		//$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeople =  $this->organization->listKeyPeoples($orgId);
		foreach($arrKeyPeople as $row){
			$row['kol_name'] = $row['salutation']." ".$this->common_helper->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
	
			$kolId = array_search($row[FIRST_ORDER].$row[SECOND_ORDER].$row[THIRD_ORDER],$arrKols);
			if($kolId){
				$row['kol_id'] = $kolId;
				$row['is_kol'] = 'Yes';
			}else{
				$row['is_kol'] = 'No';
			}
			$row['role'] = $row['role_id'];
			$arrDetails[]    = $row;
		}
		$arrAssocPeople	=  $this->organization->listOrgAssociatedPpl($orgId);
		foreach($arrAssocPeople as $people){
			$arrDetail = array();
			$arrDetail['id'] = $people['id'];
			$arrDetail['kol_id'] = $people['id'];
			$arrDetail['kol_name'] = $arrSalutations[$people['salutation']]." ".$people[FIRST_ORDER]." ".$people[SECOND_ORDER]." ".$people[THIRD_ORDER];
			$arrDetail['title'] = $people['title_name'];
			$arrDetail['department'] = $people['division'];
			$arrDetail['role'] = 'Associated People';
			$arrDetail['is_kol'] = 'Yes';
			$arrDetail['org_id'] = $people['org_id'];
			$arrDetail['created_by'] = $people['created_by_org'];
			$arrDetail['eAllowed'] = $this->common_helper->isActionAllowed('org_details','edit',$arrDetail);
			$data_type = $people['kol_profile_type'];
			if($people['kol_profile_type']=='Basic' || $people['kol_profile_type']=='Full Profile'){
				$data_type = 'Aissel Analyst';
			}
	
			$arrDetail['data_type_indicator'] = $data_type;
			$arrAssociltedPeople[]=$arrDetail;
		}
		$arrDetails = (is_array($arrDetails))?$arrDetails:array($arrDetails);
		$arrAssociltedPeople = (is_array($arrAssociltedPeople))?$arrAssociltedPeople:array($arrAssociltedPeople);
	
		$arrOfKeyandAssocPeople = array_merge($arrDetails,$arrAssociltedPeople);
		$count	=	sizeof($arrOfKeyandAssocPeople);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$data['records']	=	$count;
		$data['total']		=	$total_pages;
		$data['page']		=	$page;
		$data['rows'] 		= 	$arrOfKeyandAssocPeople;
	
		echo json_encode($data);
	}
	
	function add_client_keypeople($orgId){
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		$data['orgId'] = $orgId;
		$data['arrkeyPeople']='';
		$this->load->view('organizations/add_client_keypeople',$data);
	}
	
	function add_keypeople($orgId, $key_people_id = false){
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		$data['orgId'] = $orgId;
		if($key_people_id != false){
			$data['arrkeyPeople'] = $this->organization->getKeyPeopleData($key_people_id);
		}else{
			$data['arrkeyPeople']='';
		}
		$data['contentPage'] 	=	'organizations/add_client_keypeople';
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	function save_key_people(){
		if(isset($_POST) && count($_POST)>0){
		    $dataType = 'User Added';
		    $client_id =$this->session->userdata('client_id');
		    if($client_id == INTERNAL_CLIENT_ID){
		        $dataType = 'Aissel Analyst';
		    }
			// Getting the POST details of Organization
			$keyPeopleDetails = array(		'id'				=> 	$this->input->post('id'),
											'org_id' 			=> 	$this->input->post('org_id'),
											'role_id' 			=> 	$this->input->post('role_id'),
											'salutation'		=> 	$this->input->post('salutation'),
											'first_name'		=> 	ucwords(trim($this->input->post('first_name'))),
											'middle_name'		=> 	ucwords(trim($this->input->post('middle_name'))),
											'last_name'			=>	ucwords(trim($this->input->post('last_name'))),
											'title' 			=> 	ucwords(trim($this->input->post('title'))),
											'email'	 			=> 	trim($this->input->post('email')),
											'department'	 			=> 	trim($this->input->post('department')),
											'created_by'		=>	'1',//$this->loggedUserId,
											'created_on'		=>	date('Y-m-d H:i:s'),
			                                'data_type_indicator' => $dataType
			);
		
				
			// Create an array to return the result
			
			$arrResult = array();
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
			
			if($lastInsertId = $this->organization->saveKeyPeople($keyPeopleDetails)){
				$arrResult['saved']				= true;
				$arrResult['lastInsertId']		= $lastInsertId;
				if($keyPeopleDetails['salutation'] !=''){
					$keyPeopleDetails['salutation']	= $arrSalutations[$keyPeopleDetails['salutation']];
				}
				$keyPeopleDetails['role_id']	= $this->organization->getKeyPeopleRoleNameById($keyPeopleDetails['role_id']);
				$keyPeopleDetails['kol_name']   = $keyPeopleDetails['first_name']." ".$keyPeopleDetails['middle_name']." ".$keyPeopleDetails['last_name'];
				$arrResult['data']				= $keyPeopleDetails;
				//$this->update->insertUpdateEntry(ORG_KEY_PEOPLE_ADD, $lastInsertId, MODULE_ORG_KEY_PEOPLE, $keyPeopleDetails['org_id']);
			}else{
				$arrResult['saved']				= false;
			}
			echo json_encode($arrResult);
		}
	}
	function update_key_people(){
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		if(isset($_POST) && count($_POST)>0){
	
			// Getting the POST details of Organization
			$keyPeopleDetails = array(		'id'				=> 	$this->input->post('id'),
					'org_id' 			=> $this->input->post('org_id'),
					'role_id' 			=> 	$this->input->post('role_id'),
					'salutation'		=> 	$this->input->post('salutation'),
					'first_name'		=> 	ucwords(trim($this->input->post('first_name'))),
					'middle_name'		=> 	ucwords(trim($this->input->post('middle_name'))),
					'last_name'			=>	ucwords(trim($this->input->post('last_name'))),
					'title' 			=> 	ucwords(trim($this->input->post('title'))),
					'email'	 			=> 	trim($this->input->post('email')),
					'department'	 	=> 	trim($this->input->post('department')),
					'modified_by'		=>	$this->loggedUserId,
					'modified_on'		=>	date('Y-m-d H:i:s'),
					'data_type_indicator' => $dataType);
				
	
			// Create an array to return the result
				
			$arrResult = array();
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
				
			if($this->organization->updateKeyPeople($keyPeopleDetails)){
				$arrResult['saved']			= true;
				$arrResult['lastInsertId']	= $keyPeopleDetails['id'];
				if($keyPeopleDetails['salutation'] !=''){
					$keyPeopleDetails['salutation']= $arrSalutations[$keyPeopleDetails['salutation']];
				}
				$keyPeopleDetails['role_id'] = $this->organization->getKeyPeopleRoleNameById($keyPeopleDetails['role_id']);
				$keyPeopleDetails['kol_name']   = $keyPeopleDetails['first_name']." ".$keyPeopleDetails['middle_name']." ".$keyPeopleDetails['last_name'];
				$arrResult['data']			= $keyPeopleDetails;
				//$this->update->insertUpdateEntry(ORG_KEY_PEOPLE_UPDATE, $keyPeopleDetails['id'], MODULE_ORG_KEY_PEOPLE, $keyPeopleDetails['org_id']);
			}else{
				$arrResult['saved']			= false;
			}
			echo json_encode($arrResult);
		}
	}
	
	function delete_key_people($id){
		if($this->organization->deleteKeyPeople($id)){
			$data['status'] = true;
		}
		else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function view_sub_organizations($orgId=null,$subContentPage=null){
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
			
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		//$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($orgId);
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
	
		$data['arrOrganization']	= $arrOrganizationDetail;
		$data['contentPage'] 		=	'organizations/list_sub_organizations';
		
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	
	

	function add_sub_org($orgId, $sub_org_id = false){
		$data['orgId'] = $orgId;
		$data['arrCountry']				=	$this->country_helper->listCountries();
		if($sub_org_id == true){
			$arrDetail = $this->organization->editOrganization($orgId);
			if($arrDetail['country_id'] != 0){
				$arrStates = $this->country_helper->getStatesByCountryId($arrDetail['country_id']);
			}
			
			if($arrDetail['state_id'] != 0){
				$arrCities					= $this->country_helper->getCitiesByStateId($arrDetail['state_id']);
			}
			$data['arrStates']				= $arrStates;
			$data['arrCities']				= $arrCities;
			$data['arrDetail']				= $arrDetail;
		}
		$data['contentPage'] 	=	'organizations/add_sub_org';
		$this->load->view(CLIENT_LAYOUT.'header',$data);
	}
	
	function save_sub_org($orgId){
		//$orgName	 		= ucwords(trim($this->input->post('name')));
		$orgName	 		= trim($this->input->post('name'));
		$arrOrg['name']		= $orgName;
		$arrOrg['country_id']	 		=	trim($this->input->post('country_id'));
		$arrOrg['state_id']	 			=	trim($this->input->post('state_id'));
		$arrOrg['city_id']     			=	trim($this->input->post('city_id'));
		$arrOrg['postal_code']     		=	trim($this->input->post('postal_code'));
		$arrOrg['phone']     			=	trim($this->input->post('phone'));
		$arrOrg['address']     			=	trim($this->input->post('address'));
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['created_on']	 		=	date("Y-m-d H:i:s");
		$arrOrg['status']	 			=	New1;
		$arrOrg['npi_num']        =	$this->input->post('npi_num');
		$arrOrg['sub_org_id'] = $this->organization->saveOrganization($arrOrg);
	
		if($arrOrg['sub_org_id']!=''){
			unset($arrOrg['created_by']);
			unset($arrOrg['created_on']);
			unset($arrOrg['name']);
			unset($arrOrg['status']);
			$arrOrg['org_id']	 		=	$orgId;
			if($id = $this->organization->saveAffiliatesPartnershipsManaul($arrOrg)){
				$arrOrg['affiliate_id'] = $id;
				$arrOrg['status'] = "Saved";
			}else{
				$arrOrg['status'] = "Not";
			}
				
				
		}
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['name'] = $orgName;
		echo json_encode($arrOrg);
		//ending post details
	}
	
	function update_sub_org(){
		$arrOrg['name']	 		=	ucwords(trim($this->input->post('name')));
		$arrOrg['id']	 		=	ucwords(trim($this->input->post('id')));
		$orgName = $arrOrg['name'];
		$arrOrg['country_id']	 		=	trim($this->input->post('country_id'));
		$arrOrg['state_id']	 			=	trim($this->input->post('state_id'));
		$arrOrg['city_id']     			=	trim($this->input->post('city_id'));
		$arrOrg['postal_code']     		=	trim($this->input->post('postal_code'));
		$arrOrg['phone']     			=	trim($this->input->post('phone'));
		$arrOrg['address']     			=	trim($this->input->post('address'));
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['created_on']	 		=	date("Y-m-d H:i:s");
		$arrOrg['status']	 			=	New1;
		$arrOrg['npi_num']        =	$this->input->post('npi_num');
	
		if($this->organization->updateOrganization($arrOrg)){
			$arrOrg['status']			= 'Saved';
			$arrOrg['sub_org_id']	= $arrOrg['id'];
	
			//	$this->session->set_userdata('organizationId', $lastInsertId);
		}else{
			$arrOrg['status']			= false;
		}
			
		echo json_encode($arrOrg);
	}
	
	function delete_sub_org($orgId){
		$result = $this->organization->deleteSubOrg($orgId);
		if($result){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
}