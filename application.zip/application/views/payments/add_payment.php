<?php
/**
 * Contains a form to add payments
 * 
 * @package views.payments
 * @author Ramesh B
 * @since 3.1
 * @created 02-06-2017
 */
$kolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";


?>
<style type="text/css">
	#paymentForm table tr th label {
	    font-size: 12px !important;
	}
	#paymentForm textarea {
    width: 86%;
}
    #paymentForm input[type="text"]{
        width:210px;
    }
    .error{
        color:#ff0000;   
        padding: 2px 0px !important;
    }
    .required{
        color:#ff0000;
    }
    .add-icon{
        background-image: url("<?php echo base_url(); ?>images/add_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
        background-repeat: no-repeat;
    }
    .remove-icon{
        background-image: url("<?php echo base_url(); ?>images/delete_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
    }
    /*	div.addIcon {
                    margin-top: 24px;
            }
    */
    #paymentAddContiner tr td select{
        width:190px;
    }
    div.actionIcon{
        margin-top: 15px;
    }
    .pd{
        width:75px;
        font-weight: bold;
    }
    table.tabularGrid caption{
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
        box-shadow: 0 0 4px #d1d1d1 inset;
        color: #333333;
        padding-left: 5px;
    }
    table.tabularGrid td:FIRST-CHILD{
        padding-left: 5px;
    }
    
    
    h5.heading{
        background: none repeat scroll 0 0 #D8E5F4;
        color: #2D53AF;
        margin-bottom: 2px;
        padding: 5px;
    }

    #historyContainer > div > div{
        border-bottom: 1px solid #bbbbbb;
    }
    #historyContainer ul{
        list-style: none;
    }
    .align-label{
    	width: 75px;
    	float: left;
    	margin-top: 6px;
    }
    #ktlDetails,#paymentDetails,#payment{
    	padding-left: 40px;
    	padding-bottom: 10px;
    }
   #payment{
    	padding-top: 10px;
    }
    
</style>

<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<script>
$(document).ready(function(){
	getKolOtherDetails();
});
var kolNameAutoCompleteOptions = {
		<?php 
		if(KOL_CONSENT){?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1/1',
		<?php }else{ ?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1',
		<?php } ?>
		onSelect: function(event, ui) { 
		
			var kolId = $(event).children('.id1').html();
		
			var selText = $(event).children('.kolName').html();
		
			selText=selText.replace(/\&amp;/g,'&');
			selText=selText.replace(/\&nbsp;/g,'');
		
			$('#kolName').val(selText);
			$('#kolId').val(kolId);
			
			$('#kolNameForAuto').val(selText);
			getKolOtherDetails();
		 },
		<?php echo $kolAutoCompleteOptions;?>,
	
	};
//get the kol other detaiols.
function getKolOtherDetails(){
	var kolAutoCompleteId = "kolNameForAuto";
	var kolId	= $("#"+kolAutoCompleteId).prev().val();
	var kolName=$("#"+kolAutoCompleteId).val();
	var data = {};
	data['kol_name'] = kolName;
	if(!kolId){
		kolId = '<?php echo $kolId;?>';
	}
	var otherDetailsUrl = '<?php echo base_url()?>payments/get_kol_other_details/'+kolId;
	
	if(kolName!=''){
		$.ajax({
			url:otherDetailsUrl,
			type:'post',
			data:data,
			dataType:"json",
			success:function(returndData){
				
				var speccialtyId=returndData.specialtyId;
				var specialtyName=returndData.specialtyName;
				var last_interaction=returndData.title;
				$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(1).find('input').val(specialtyName);
				$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(2).find('input').val(last_interaction);
				
			}
		});
	}else{
		$("#therapeuticArea").val("");
	}
}		
$(function(){
	<?php 
			/**@Author Vinayak
			 ** @since  22 Aug 2012
		 	**The following code is used to disable caching in IE
		 	**/	
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
		a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
		$('#paymentDate').datepicker({
			dateFormat: 'mm/dd/yy',
			maxDate: new Date,
			onSelect: function(dateText, inst) {
				$("#paymentDate").removeClass("error");
				$("#paymentDate").next().remove();
		    }
		});

		$('#paymentDate').focus(function(){
			$('table.ui-datepicker-calendar').show();
		});
		$('.map-info.tooltop-bottom').tooltip({
	     	selector: "a[rel=tooltip]",
	    	placement:'bottom',
	    	delay:tooltipDelay
	    });
});

var validationRules	=  {
		kol_name: {
			required:true
			
		}
		
			
	};

	var validationMessages = {
			kol_name: {
			number: "required"
		}
	};

function validateDateFormat(e,src) {
	if (!e) var e = window.event
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
 
 	if(src.value == null || src.value == "") {
 		return true;
 	}
 
	if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
		jAlert("Please enter the date in mm/dd/yyyy format!");
		src.focus();
	}
}

function dateFormat(e,src) {		
	if (!e) var e = window.event
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
	
	if(code != 37 && code != 38 && code != 39 && code != 40) { 
		if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
			src.value=src.value.replace(/[^0-9\/]/g,'');  
		
			if(code!=8 && code!=46) // not backspace or delete
			{	
				src.value=src.value.replace(/[^0-9]/g,'');
				
				if (src.value.length == 2) {
			        src.value += "/";
			    }
			    				
				if (src.value.length > 2) {
					if(src.value.indexOf('/') != 2) {
						src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
					}
				}
				
				if (src.value.length == 5) {
			        src.value += "/";
			    }
			    
				if (src.value.length > 5) {
					if(src.value.lastIndexOf('/') != 5) {
						src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
					}
				}
				
				if(src.value.length >= 10)
				{
					return false;
				}
			}  
		}
	}
	return true;
}

/**
* Validate the text for 'Numeric Only'
*/
function allowNumericOnly(src) {
	
	if(!src.value.match(/^\d{4}$/)) {
		src.value=src.value.replace(/[^0-9]/g,'');  
	}
	
}

function getPaymentThreshhold(){
	var kolId=$("#paymentKOL").val();
	if(kolId == ''){
		$("#paymentThreshholdRate").val("");
		return false;
	}
	method		= '<?php echo base_url();?>payments/get_threshhold/'+kolId; 
	
	$.post(method,function(returnData){
		if(returnData.threshholdLimit){
			$("#paymentThreshholdRate").val(returnData.threshholdLimit.threshhold_rate);
			$("#paymentBudget").html(returnData.budget);
		}
		else{
			$("#paymentThreshholdRate").val("");
			$("#paymentBudget").html("");
		}
	},"json");
}

$(document).ready(function () {
	$('table.tabularGrid caption div.collapseSlider').click(function () {
        if ($(this).attr('class') != "collapseSlider") {
            $(this).parent().parent().find('tr').hide();
            $(this).find('a').attr('data-original-title', 'Expand');
        } else {
            $(this).parent().parent().find('tr').show();
            $(this).find('a').attr('data-original-title', 'Collapse');
        }
        $(this).toggleClass('expandSlider');
    });

	$("#paymentForm").validate({
		onkeyup:false,
		rules: validationRules,
		messages: validationMessages
	});

});
function savePayement(){

	var kolName = $('#kolName').val();
	var kolNameAuto = $('#kolNameForAuto').val();
	if(kolName !=kolNameAuto){
		$('#kolId').val('');
	}
	
	var data=$("#paymentForm").serialize();
	if(!$("#paymentForm").validate().form()){
		return false;
	}else{

		var kolName = $('#kolName').val();
		
		kolName = $.trim(kolName);
		if(kolName.indexOf(' ')>=1){
		}else if(kolName.indexOf(',')>=1){
		}else{
			status='False';
			jAlert('Single word <?php echo lang('KOL'); ?> not allowed');
			return false;
		}
		
	//	return true;
	 $('div.planMsgBox').removeClass('success');
     $('div.planMsgBox').addClass('notice');
     $('div.planMsgBox').show();
     $('div.planMsgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:"<?php echo base_url()?>payments/<?php if($arrPayment['id']=='') echo 'save_payment'; else if($arrPayment['id']!='') echo 'update_payment/'.$arrPayment['id'];?>",
		data:data,
		type:'POST',
		dataType:'json',
		beforeSend: function(){
			$("#savePayment1").removeAttr("onclick", null);
        },
		success:function(returnData){
			if(returnData.saved == true){
				/* $("#paymentAddContainer").dialog("close");
				$("#paymentEditContainer").dialog("close");
				reloadPayments(); */
				$('div.planMsgBox').fadeOut('500');
				if(kolId != ''){
					var url = "<?php echo base_url() ?>kols/view/"+kolId+"/payments";
					}else{
					var url	= "<?php echo base_url() ?>payments/list_payments/payments";
						}
				 window.location.href	= url;
			}else{
				jAlert('Error occured while saving. Try Again..');
			} 
		},
		complete:function(){
			$('#savePayment1').attr('onclick','savePayement()');
		}
	});
	}
}
	function cancelPayment(){
			if(kolId != ''){
				var url = "<?php echo base_url() ?>kols/view/"+kolId+"/payments";
			}else{
				var url	= "<?php echo base_url() ?>payments/list_payments/payments";
				}
		 window.location.href	= url;
	
		}
 function showNextFields(){
		var no_of_filed = $('#noOfFields').val();
		no_of_filed = parseInt(no_of_filed)+1;
		$('#noOfFields').val(no_of_filed);

		$('#payment').append("<tr>"+$('#amount1').html()+"</tr>");
		
		var lastTypeName1 = "type"+no_of_filed;
		$('#payment tr:last td:eq(0) select').attr('name',lastTypeName1);
		$('#payment tr:last td:eq(0) select').attr('id',lastTypeName1);
		$('#payment tr:last td:eq(0) select option:first').val('').text('Select').attr('selected','selected');

		var lastCurrency1 = "currency"+no_of_filed;
		$('#payment tr:last td:eq(1) select').attr('name',lastCurrency1);
		$('#payment tr:last td:eq(1) select').attr('id',lastCurrency1);
		$('#payment tr:last td:eq(1) select option:first').val('').text('Select').attr('selected','selected');
		
		var lastAmountName1 = "amount"+no_of_filed;
		$('#payment tr input:last').attr('name',lastAmountName1);
		$('#payment tr input:last').attr('id',lastAmountName1);
		$('#payment tr input:last').val('');
		$('#payment tr input:last').val('');

		$('#payment tr:last td:last').html('<img onclick="deleteAmount(this)" alt="add" title="Delete" style="cursor:pointer" src="<?php echo base_url()?>images/delete_active.png"></img>');
 }

 function deleteAmount(thisEle){
	var amountDeletd = $(thisEle).parent().parent().find('input[type="text"]').val();
	$(thisEle).parent().parent().remove();
	//var totalAmount = $('#totalAmount').html();
	//alert(totalAmount+'----'+amountDeletd);
	//var amount = totalAmount-amountDeletd;
	//amount = parseFloat(amount);
	calculateTotal();
	//$('#totalAmount').html(amount);
 }
</script>
<div id="paymentAddContiner">
    <form action="<?php echo base_url()?>payments/<?php if($arrPayment['id']=='') echo 'save_payment'; else if($arrPayment['id']!='') echo 'update_payment';?>"  method="post" id="paymentForm" class="validateForm" name="paymentForm">
       <div class="msgBoxContainer"><div class="planMsgBox"></div></div>
       <table id="ktlDetails" class="highlightHeadings tabularGrid">
            <caption><?php echo lang("KOL");?> Details
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
            <tbody>
            	<tr>
					<th>
						<label>KTL Name:<span class="required">*</span></label>
					</th>
					<th>
						<label>Specialty:</label>
					</th>
					<th>
						<label>Title:</label>
					</th>
				</tr>
				<tr>
					<td>
						<input type="text" id="kolName" name="kol_name" value="<?php  if($arrPayment['kol_name']!='') echo $arrPayment['kol_name'];if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox" <?php if(isset($kol_name)){?> readonly="readonly" <?php }?>></input>
						<input type="hidden" name="kol_id" id="kolId" value="<?php if($arrPayment['kol_id']!=''){ echo $arrPayment['kol_id']; }else{if(isset($kolId)) echo $kolId;}?>"></input>
						<input type="hidden" name="kol_name_of_auto" id="kolNameForAuto" value="<?php if($arrPayment['kol_name']!='') echo $arrPayment['kol_name'];if(isset($kol_name)) echo $kol_name;?>"></input>
					</td>
					<td>
						<input type="text" name="date" value="" id="date" readonly="readonly">
					
					</td>
					<td>
						<input type="text" name="date" value="" id="date" readonly="readonly">
					</td>
				</tr>
			</tbody>
        </table>
        <table id="paymentDetails" class="highlightHeadings tabularGrid">
            <caption>Payment Details
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
  			<tbody>
            	<tr>
					<th>
						<label>Date:<span class="required">*</span></label>
					</th>
					<th>
						<label>Requested By :<span class="required">*</span>
					</th>
					<th>
						<label>Paid By :<span class="required">*</span></label>
					</th>
				</tr>
				<tr>
					<td>
						<input type="text" id="paymentDate" name="date" value="<?php if($arrPayment['date']!='') echo $arrPayment['date'];?>" class="required"></input>
					</td>
					<td>
						<select name="requested_by" id="requestedBy" class="required" >
						<option value="">--Select--</option>
						<?php foreach($arrPaymentRequestBy as $key => $value){ 
							if($arrPayment['requested_by'] == $key){ ?>
								<option value="<?php echo $key;?>" selected="selected"><?php echo $value;?></option>
							<?php }else{?>	
								<option value="<?php echo $key;?>"><?php echo $value;?></option>
						<?php } }?>
					</select>
					
					</td>
					<td>
						<select name="paid_by" id="paid_by" class="required">
						<option value="">--Select--</option>
						<?php foreach($arrPaymentPaidBy as $key => $value){
								if($arrPayment['paid_by'] == $key){ ?>
									<option value="<?php echo $key;?>" selected="selected"><?php echo $value;?></option>
							<?php }else{?>	
							<option value="<?php echo $key;?>"><?php echo $value;?></option>
						<?php }}?>
					</select>
					
					</td>
				</tr>
				</tr>
					<th>
						<label>Reason :</label>
					</th>
				</tr>
				</tr>
					<td colspan="3">
						<textarea id="notes" name="reason" rows="2" cols="700"><?php if(isset($arrPayment['reason'])) echo $arrPayment['reason'];?></textarea></td>
				</tr>
			</tbody>


        </table>
        <table id="payment" class="highlightHeadings tabularGrid">
            <caption>Payment
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
            <tbody>
            <input type="hidden" name="no_of_fileds" id="noOfFields" value="<?php if(isset($noOfFields)) echo $noOfFields;else echo 1; ?>"></input>
            	<tr id="amount1">
                    <td>
                    <div class="align-label"><label for="kolId1">Type:<span class="required">*</span></label></div>
                    <select name="type" id="type" class="required">
						<option value="">Select</option>
						<?php
						foreach($arrPaymentTypes as $key=>$value){
								if($arrPayment['arrTypesAndAmount'][0]['type']==$key){?>
								<option value="<?php echo $key ?>" selected="selected"><?php echo $value ?></option>
						<?php }else{?>
							<option value="<?php echo $key ?>"><?php echo $value ?></option>
						<?php } }?>
					</select>
                    </td>
                    <td>
                        <label for="userId1">Currency:<span class="required">*</span></label>
                        <select name="currency" id="currency" class="required" >
						<option value="">Select</option>
							<?php
						foreach($arrPaymentCurrencies as $key=>$value){
								if($arrPayment['arrTypesAndAmount'][0]['currency']==$key){?>
								<option value="<?php echo $key ?>" selected="selected"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
						<?php }else{?>
							<option value="<?php echo $key ?>"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
						<?php } }?>
					</select>
                    </td>
                    <td>
                        <label for="status1">Amount:<span class="required">*</span></label>
                        <input type="text" name="amount" value="<?php if($arrPayment['arrTypesAndAmount']!='') echo $arrPayment['arrTypesAndAmount'][0]['indAmount'];?>"  id="amount" class="totalAmount required"></input>
                    </td>
                    <td id="addDeleteLinks">
                        <label><img onclick="showNextFields()" alt="add" style="cursor:pointer" title="Add" src="<?php echo base_url()?>images/add_active.png"></img></label>
                    </td>
                </tr>
				<?php if($arrPayment['arrTypesAndAmount']!=''){
			unset($arrPayment['arrTypesAndAmount'][0]);
			$totalFields=2;	
			foreach($arrPayment['arrTypesAndAmount'] as $key1=>$arrAmounts){
		?>
			<tr>
			<td>
				<p>
					<div class="align-label"><label>Type <span class="required">*</span></label></div>
					<select name="type<?php echo $totalFields;?>" id="type<?php echo $totalFields;?>" class="required">
						<option value="">Select</option>
							<?php  foreach($arrPaymentTypes as $key=>$value){
							if($arrAmounts['type']==$key){ ?>
								<option value="<?php echo $key ?>" selected="selected"><?php echo $value ?></option>
							<?php }else{?>
								<option value="<?php echo $key ?>"><?php echo $value ?>"</option>
							<?php } }?>
					</select>
				</p>
			</td>
			 <td>
                        <label for="userId1">Currency:<span class="required">*</span></label>
                        <select name="currency<?php echo $totalFields;?>" id="currency<?php echo $totalFields;?>" class="required" >
						<option value="">Select</option>
							<?php  foreach($arrPaymentCurrencies as $key=>$value){
							if($arrAmounts['currency']==$key){ ?>
								<option value="<?php echo $key ?>" selected="selected"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
							<?php }else{?>
								<option value="<?php echo $key ?>"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?>"</option>
							<?php } }?>
					</select>
                    </td>
			<td>
					<label>Amount:<span class="required">*</span></label>
					<input type="text" name="amount<?php echo $totalFields;?>" value="<?php  echo $arrAmounts['indAmount'];?>"  id="amount<?php echo $totalFields;?>" class="totalAmount required"" onblur="calculateTotal()"></input>
			</td>
			<td>
				<img onclick="deleteAmount(this)" style="cursor:pointer" alt="Delete"  title="Delete" src="<?php echo base_url()?>images/delete_active.png"></img>
			</td>
		</tr>
		<?php $totalFields++;}}?>
            </tbody>
        </table>


    </form>
    <center><?php if($arrPayment['id']==''){
				echo '<input type="button" value="Submit" name="submit" id="savePayment1" onclick="savePayement()">';
		 	}else {
				echo '<input type="button" value="Update" name="submit" id="savePayment1" onclick="savePayement()">';
			}
		 ?>&nbsp;<input type="button" value="Cancel" onclick="cancelPayment()"/></center>
</div>
