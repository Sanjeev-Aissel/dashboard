<?php
/**
*Description:
*
*Created by:Vinod H
*
*Created on:March 28, 2016
*/?>

		<style type="text/css">
			#contents{
				text-align:left;
				font-size:110%;
				padding-left:150px;
			}
			
			#contents label{
				float:left;
				width:150px;
				text-align:right;
				padding-right:6px;
				padding-top:2px;
			}
			
			h1{
				color:#2E6E9E;
				font-size:170%;
				margin-bottom:10px;
				margin-top:15px;
			}

			.ui-jqgrid-bdiv{
				height:auto !important;
			}
			div.extraOptions div.rightSideOptions {
			    text-align: right;
			}
		
		</style>

				<div class="extraOptions">
					<div class="rightSideOptions">
						<a class="addLink" href="<?php echo base_url();?>campaigns/add_campaign"><img src="<?php echo base_url();?>images/bullet_add.png" style="height: 30px;vertical-align: middle;" border="0">Add New Campaign</a>
					</div>
				</div>
	             <table id="gridCampains"></table>
				 <div id="gridCampaignListingPagintaion"></div> <br /> 
				<script>
				function deleteCampaign(campaignId){
					var name = $('.del_'+campaignId).text();

					if(name == 'Enable'){
						var responceName = 'Disable';
						var color = 'red';
						var value = 1;
					}
					else{
						var responceName = 'Enable';
						var color = 'green';
						var value = 0;
					}
					jConfirm("Are you sure you want to "+name+" selected Campaign?","Please confirm",function(r){
							if(r){
								$.ajax({
									url:'<?php echo base_url()?>campaigns/delete_campaigns/'+campaignId+'/'+value,
									type:'post',
									dataType:"json",
									success:function(returnMsg){
											$('.del_'+campaignId).text(responceName);
											$('.del_'+campaignId).css('color',color);
										}
								});
								}else{
										return false;
									}
						});
				}
				function toggleSearchToolbar(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
				};
				jQuery("#gridCampains").jqGrid({
					url:'<?php echo base_url();?>campaigns/list_campaigns_grid',
					datatype: "json",
					colNames:['Id','Name','Short Code','Registration URL','Description','Action'],
					colModel:[
						{name:'id',index:'id',width:20,search:false,hidden:true},
						{name:'name',index:'name',search:true},
						{name:'short_code',index:'short_code',search:true},
						{name:'url',index:'url',search:true},
						{name:'description',index:'description',search:true},
						{name:'action',index:'action',search:false,align:'center'}
					],
					rowNum:10,
					autowidth:true,
					rownumbers: true,
					rowList:paginationValues,
					pager: '#gridCampaignListingPagintaion',
					sortname: 'id',
					mtype: "POST",
					recordpos: 'left',
					viewrecords: true,
					sortorder: "desc",
					loadonce: false,
 					caption: "Campaigns"
                                });
				jQuery("#gridCampains").jqGrid('navGrid','#gridCampaignListingPagintaion',{add:false,del:false,edit:false,position:'right',search:false}); 
				 jQuery("#gridCampains").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
					//Toggle Toolbar Search 
				jQuery("#gridCampains").jqGrid('navButtonAdd',"#gridCampaignListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
					onClickButton:toggleSearchToolbar
				});
				jQuery("#gridCampains").jqGrid ('navButtonAdd', '#gridCampaignListingPagintaion',
	             { caption: "Choose Columns", buttonicon: "ui-icon-calculator",
	               title: "Choose Columns",
	               onClickButton: function() {
	            	   jQuery("#gridCampains").jqGrid('columnChooser');
	               }
	             });
				</script>
					<!-- End of Personal and Professional Information -->
