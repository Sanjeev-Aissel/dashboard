Hi Team,
<p><strong>
<?php if($data['demo']=='Yes'){?>
<?php echo $data['user_name'];?> has requested for the demo. </strong></p>
<?php }else{?>
<?php echo $data['user_name'];?> has not requested for the demo. </strong></p>
<?php }?>
<p>
Full Name: <?php echo $data['user_full_name'];?>
</p>
<p>
Email: <?php echo $data['email'];?>
</p>
<p>
Company Name: <?php echo $data['company_name'];?>
</p>

<p>
Page Visited: <?php echo $data['tab'];?>
</p>
<div>
	Thanks,<br />
	Aissel Support Team
</div>
