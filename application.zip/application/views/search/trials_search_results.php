<?php
/**
*File To Know Basics.
*Created By:
*Created On:6:32:26 PM
*/
?>
<style type="text/css">
	.record_name{
		padding-left: 5px:
		font-family:arial,helvetica,sans-serif;
		font-weight:bold;
		letter-spacing:0.5px;
	}
	#searchResultsContainer {
		margin-top: 0px;
	}
	table.listResultSet {
		margin-top: 0px;
		border: 0px;
	}
	table.listResultSet td{
		border-right: 0px;
	}
	table.listResultSet tr{
		border-bottom: 1px;
	}
	table.listResultSet tr:hover{
		background-color: #d0e5f5;
		background-color: #D3DFED;
	}
	tr.searchPagination:hover{
		background-color: white;
	}
	tr.selectedRow{
		background:#d8dfea repeat-x scroll 50% 50% !important;
	}
	.blockUI .blockMsg .blockPage {
		border: 0px;
	}
	
	#searchResultsContainer .searchResultsMsg {
		padding-right:0px;
		margin-right: 0px;
	}

</style>
		<div class="searchResultsMsg">
			<?php 	if($trialsCount==0) 
						echo "No Trials found";
					else{
						if(trim($msg['resFor']) != "Search results for")
							echo "<div id='resFor'>".$msg['resFor']." </div>";
						echo "<div id='countMsg'>".$msg['countMsg']." </div>";
					}
			?>
		</div>
		<?php if($trialsCount!=0){?>
		<table class="listResultSet">
			<tbody>
			<!-- Start of loop trough each search result, and displaying as a row result -->
				<?php 
					$evenOrOddRow	= true;
					foreach($arrClinicalTrial as $clinicalTrial) {
						if($evenOrOddRow){
							$evenOrOddRow	= false;
						}else{
							$evenOrOddRow	= true;
						}
				?>
						<tr class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
							<td width="1%">
								<div class="microViewIcon" onClick="viewTrialsMicroProfile('<?php echo $clinicalTrial['id'];?>'); return false;"></div>
								<!--<label onClick="viewTrialsMicroProfile('<?php echo $clinicalTrial['id'];?>');"><img class="micro_view_icon" src="<?php echo base_url().'images/user3.png'?>" /></label> -->
							</td>
							<td width="90%">
								<span class="record_name"><a href="<?php echo base_url();?>clinical_trials/view_clinical_trial/<?php echo $clinicalTrial['id'];?>"><?php echo $clinicalTrial['trial_name']?></a></span>
								<?php echo "<br />"; ?>
								<?php echo $clinicalTrial['sponsors'];
									if(isset($clinicalTrial['sponsors']) && isset($clinicalTrial['condition']))
										echo ', '; ?>
								<?php echo $clinicalTrial['condition'];
									if(isset($clinicalTrial['condition']) && isset($clinicalTrial['interventions']))
										echo ', '; ?>
								<?php echo $clinicalTrial['interventions']?>
							</td>
							
						</tr>
				<?php }?>
					<tr class="searchPagination" style="background-color: white;">
						<td colspan="4">
							<select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage()">	
							<?php 
								
								for($i=10;$i<151;$i+=10){
									if($i==$this->ajax_pagination->per_page){
										echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
									}else{
										echo '<option value="'.$i.'" >'.$i.'</option>';
									}
								}	
								echo '</select> Records Per Page ';
								$config['first_link'] = 'First';
								$config['div'] = 'searchResultsContainer'; //Div tag id
								$urlPrfix="";
								if($searchType=='simple')
									$urlPrfix="filter_search_trials";
								else
									$urlPrfix="filter_search_trials";
								$config['base_url'] = base_url()."kols/".$urlPrfix;
								$config['total_rows'] = $trialsCount;
								$config['per_page'] = $this->ajax_pagination->per_page;
								$config['postVar'] = 'page';
								
								$this->ajax_pagination->initialize($config);
								print $this->ajax_pagination->create_links();
								
							?>		
						</td>
					</tr>
			</tbody>		
		</table>
	<?php }?>