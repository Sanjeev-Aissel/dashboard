<?php
class My_list_kol extends CI_Model {
	function listCategories($userId,$clientId){
		$arrCategories=array();
		$this->db->where('user_id',$userId);
		$this->db->where('client_id',$clientId);
		$arrCategoriesResult=$this->db->get('list_categories');
		foreach($arrCategoriesResult->result_array() as $row){
			$row['count']=$arrCategoriesResult->num_rows();
			$arrCategories[]=$row;
		}
		return $arrCategories;
	}	
	function getListNames($categoryId){
		$arrlist=array();
		$arrListResult=$this->db->query('select list_names.*,list_categories.is_public
											from list_names
											left join list_categories on list_categories.id=list_names.category_id
											where list_names.category_id='.$categoryId.'');
		if($arrListResult->num_rows()!=0){
			foreach($arrListResult->result_array() as $row){
				$arrlist[]=$row;
			}
			return $arrlist;
		}else{
			$this->db->where('id',$categoryId);
			$reult=$this->db->get('list_categories');
			foreach($reult->result_array() as $row){
				$arrlist[]=$row;
			}
			return $arrlist;
		}
	}
	function saveListOfKols($arrKols,$lastInsertId){
		foreach($arrKols as $kols){
			$arrKol['user_id']=$this->session->userdata('user_id');
			$arrKol['kol_id']=$kols;
			$arrKol['list_name_id']=$lastInsertId;
			$this->db->insert('list_kols',$arrKol);
		}
		return true;
	}
}
?>