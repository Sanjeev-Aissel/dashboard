<?php
/**
*File To Know Basics.
*Created By:
*Created On:7:57:04 PM
*/
?>

<!--<script type="text/javascript" src="<?php echo base_url()?>js/chosen.jquery.js"></script>-->
<!--<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">-->
<style type="text/css">
	
	#searchResultsContainer {
		margin-top: 0px;
	}
	#checkAll {
		float: left;
		font-size:12px;
		width:84px;
	}
	table.listResultSet {
		margin-top: 0px;
	}
	
	table.listResultSet tr:hover{
		background-color: #D3DFED;
	}
	tr.searchPagination:hover{
		background-color: white;
	}
	tr.selectedRow{
	/*	background:#d8dfea repeat-x scroll 50% 50% !important;*/
		background:#D3DFED repeat-x scroll 50% 50% !important;
	}
	.loadingIndicator {
		background-image: url("<?php echo base_url();?>images/ajax-loader-round.gif");
		background-position:center;
		background-repeat:no-repeat;
		position:absolute;
		top:250px;
		left:550px;
		height: 75px;
		width: 75px;
	}
	.blockUI .blockMsg .blockPage {
		border: 0px;
	}
	#searchResultsContainer .searchResultsMsg {
		margin-left:0px;
		/*margin-right:9px;*/
	}
	#countMsg {
	    margin-right:-25px;
		padding-top:2px;
	}
	.micro_view_icon:hover,.defaultProfileIcon:hover{
		cursor:pointer;
	}
	select#profileTypesd {
	    background: linear-gradient(#FFFFFF, #D2D3D4) repeat scroll 0 0 transparent;
	    border: 1px solid #D4D5D6;
	    border-radius: 3px 3px 3px 3px;
	    color: #0070BD;
	    font-size: 12px;
	    margin-left: 10px;
	    margin-top: 0px; 
	    padding: 1px;
	    width: 125px;
	    /*
	    -moz-appearance: none;
	    background: none repeat scroll 0 0 #F8F8F8;
	    border-radius: 3px 3px 3px 3px;
	    box-shadow: 0 0 0 #CCCCCC, 1px 1px 5px 1px #D6D6D6 inset;
	    cursor: pointer;
	    display: inline-block;
	    font-size: 12px;    
	    width: 121px; */
	}
	#addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_active.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
	#addFilters:HOVER #addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_inactive.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
	#searchResultsContainer ul.pageRightOptions{
	   width:180px;
	}
	#popup_container{
	   word-wrap: break-word;
	}
	#popup_message{
        text-align: left;
        margin: 0px 25px;
	}
</style>
	
	<script type="text/javascript">
	function redirectToProfile(thisObj){
		var redirectTo	= $(thisObj).find('span.record_name a').attr('href');
		window.location.href	= redirectTo;
	}
	if(js_files_loaded){
		checked=false;
		function checkedAll (thisEle) {
			//jAlert(thisEle);
		/*	if($(thisEle).attr("checked")==true){
				$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').attr("checked","checked");
				});
			}else{
					$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').removeAttr("checked");
				});
			}
		*/
			var checked = $(thisEle).attr("checked");
			if(checked=='checked'){
				checked=true;
			}
			if(checked){
				$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').attr("checked","checked");
				});
			}else{
				$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').removeAttr("checked");
				});
			}
		//	var aa= document.getElementById('list');
			//jAlert(aa.toSource.value());
		/*	 if (checked == false)
		          {
		           checked = true;
		          }
		        else
		          {
		          checked = false;
		          }
		   */
	/*			for (var i =0; i < aa.elements.length; i++) 
			{
		
				 aa.elements[i].checked = checked;
			}
	*/
	}
	
		function displayModelBox(){
			var values = new Array();
			if(allPageSelected == false){
				$.each($("input[name='list[]']:checked"), function() {
				  values.push($(this).val());
				});
			}
			else
				values=allPageKolIds;
			
			if(values==''){
				jAlert("Please select at least one KTL");
			}else{
				$("#categoryModalBox .profileContent").html("<div class='microViewLoading'>Loading...</div>");
				//$("#categoryModalBox").dialog("open");
				$("#categoryModalBox").dialog("open");
				$(".addListContent").load('<?php echo base_url()?>my_list_kols/add_list/'+values);
			}
			return false;	
		}
	
	
		$(document).ready(function(){
		// Added by laxman for IE6 to change background color of tr on mouse over
//		$("#profileType").chosen();
//		$('.chzn-search').hide();
		initializeCustomToolTips();
				$('table.listResultSet tr').hover (function () {
				  $(this).addClass ("rowhover");
				}, function () {
				  $(this).removeClass ("rowhover");
				});
		//   End 
			
			var categoryAddOpts = {
					title: "Add Payment",
					modal: true,
					autoOpen: false,
					width: 400,
					draggable:false,
					dialogClass: "microView",
					position: ['center', modalBoxTopPosition],
					open: function() {
						//display correct dialog content
						var category	= sessionStorage['categoryName'];
						if(category=="kol_create_list"){
							moveFromCurrentStep(4);
						}
					}
			};
			$("#categoryModalBox").dialog(categoryAddOpts);
		
			$('table.listResultSet tr').click(function(){
				$('table.listResultSet tr').each(function(){
					if($(this).hasClass('selectedRow')){
						$(this).removeClass('selectedRow')
					}
				});
				$(this).addClass('selectedRow');
			});
		});
	}else{
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts = array(	'search/my_kol_results'	);
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
			if(isset($listView)){
				if($listView>1){
					$viewType	= 'list';
				}else{
					$viewType	= 'main';
				}
			}else{
				$viewType	= $this->uri->segment(3);
			}
		?>
		viewType	= '<?php echo $viewType;?>';
	}
	$(document).ready(function(){
 	 	$('#profileType_chzn').live('click',function(){
 	 		moveFromCurrentStep(7);
 	 	});

 	 	<?php if(isset($profileType) && $profileType != ''){ ?>
				var profileType = "<?php echo $profileType;?>";
				$("#profileType option[value='"+profileType+"']").attr("selected","selected");
				$("#profileType").trigger('liszt:updated');
//				$("#profTypeText").html($("#profileType option[value='"+profileType+"']").text());
		<?php }
			if($kolsCount==0) 
				$msgText = "No KTLs found";
			else{
				$msgText = $msg['countMsg'];
			}
		?>
			var msgText = "<?php echo $msgText;?>";
			$("#countKolMsg").html(msgText);
		
	});
	function setLangUrlLink(kolId){
		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
    	$.ajax({
            url: '<?php echo base_url() ?>kol_consents/set_lang_url_link/'+kolId,
            type: 'post',
            dataType: 'json',
            success: function (returnData) {
            	generateUrlLink(kolId);
            }
    	});
    	return false;
    }
	function generateUrlLink(kolId){
    	$.ajax({
            url: '<?php echo base_url() ?>kol_consents/generate_url_link/'+kolId,
            type: 'post',
            dataType: 'json',
            success: function (returnData) {
                if(returnData.status == true){
                	jAlert('One time Opt-in/Opt-out link has been generated and sent to '+returnData.emailId, '', function(result) {
                		window.location	= "<?php echo base_url().'kols/list_kols_client_view';?>";
                    });
                }
            },
            complete: function(){
            	$('#searchResultsContainer').unblock();
            }
    	});
    	return false;
    }
	</script>
	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
		<form id="list">
			<table class="listResultSet">
				<thead>
					<tr class="tableInfo">
						<th>
							<input type='checkbox' name='checkall' onclick='checkedAll(this);' />
							<input style="display:none;" type='checkbox' name='checkall_page' onclick='selectAllPageResults(-1,this);' id="checkAllPage">
							<label style="display:none;">Select All Pages</label>
						</th>
						<th colspan="<?php echo ($viewType=='list')?'9':'4';?>">
							<label><?php echo lang("Mykols.SelectAll");?></label>
							<?php 
								if(!empty($filtersApplied)){
									echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
									echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$filtersApplied.'</span> | ';
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
									echo '<div id="addFilters" onclick="addFilters();" style="display: inline;color: #000099;"><a href="#" rel="tooltip" title="Save all active filter selections"><div id="addFilters1" ></div></a>&nbsp;<a href="#">Save Filters</a></div>&nbsp;&nbsp;';
									echo '</div>';
								}else if(!empty($savedQueryFilterApplied)){
									echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
									echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$savedQueryFilterApplied.'</span> | <div style="display: inline;color: #000099;">'.$savedFilterName.'</div>';
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
									echo '&nbsp;&nbsp;';
									echo '</div>';
								}
//								echo '<label style="float:right;">';
//							 	if($kolsCount==0){
//									echo "No KOLs found";
//								}else{
//									echo $msg['countMsg'];
//								}
//								echo '</label>';
							?>
							<div class="countKolMsgContainer">
		                        <label id="countKolMsg"></label>
							</div>
						</th>
					</tr>
				</thead>
				<tbody>
				<!-- Sart of loop trough each search result, and displaying as a row result -->
				
					<?php 
						
						if($viewType=='list'){
							?>
							<style type="text/css">
								table.listResultSet tbody tr td{
									padding-top: 0px !important;
									padding-bottom: 0px !important;
								}
								#searchResultsContainer table th, table.listResultSet th{
									text-align: left;
								}
							</style>
							<tr class="headerBg">
								<th></th>
								<th></th>
								<th class="sortColumn" onclick="sortList('name');"><?php echo lang("MyLists.Name");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='name')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('specialty');"><?php echo lang("track.Specialty");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='specialty')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('state');"><?php echo lang("Surveys.State");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='state')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th class="sortColumn" onclick="sortList('city');"><?php echo lang("Surveys.City");?><span class="sortOrder <?php echo (($arrSortBy['sort_by']=='city')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<th><?php echo lang("Overview.Phone");?></th>
								<th><?php echo lang("Overview.Email");?></th>
								<?php 
								    if(KOL_CONSENT){?>
									<th class="sortColumn" onclick="sortList('opt_status');">Status <span class="sortOrder <?php echo (($arrSortBy['sort_by']=='opt_status')?$arrSortBy['sort_order']:'');?>">&nbsp;</span></th>
								<?php }?>
								<th style="text-align: center !important;"><?php echo lang("Overview.Action");?></th>
							</tr>
							<?php 
							$evenOrOddRow	= true;
							foreach($arrKols as $kolDetails) {
								if(!empty($kolDetails['primary_phone']) && sizeof($kolDetails['primary_phone'])>10){
									$kolDetails['primary_phone']	= (($kolDetails['primary_phone'][0]=="+")?'':'+').$kolDetails['primary_phone'];
								}
								if($evenOrOddRow){
									$evenOrOddRow	= false;
								}else{
									$evenOrOddRow	= true;
								}
					?>
							<tr id="kol<?php echo $kolDetails['id'];?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
								<td width="3%">
									<input type="hidden" id="pdf_<?php echo $kolDetails['id'];?>" value="<?php echo $kolDetails['profile_type'];?>"></input>
									<input type="checkbox" name="list[]" value="<?php echo $kolDetails['id']?>" id="list"></input>					
								</td>
								<td width="1%">
    								<label>
    								<?php 
    								if(KOL_CONSENT){
								        if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
        								<div class="tooltip-demo tooltop-top microViewIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;">
        									<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a>
        								</div>
        							<?php }else {?>
        								<div class="tooltip-demo tooltop-top microViewIcon <?php echo $kolDetails['gender'];?>">
        									<a href="#" class="tooltipLink" rel='tooltip' >&nbsp;</a>
        								</div>
        							<?php }
								    }else {?>
								    	<div class="tooltip-demo tooltop-top microViewIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;">
        									<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a>
        								</div>
								    <?php }?>
    								</label>
								</td>
								<td><span class="record_name">
								<?php 
								if(KOL_CONSENT){
								    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
									<a href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>" ><?php echo $arrSalutations[$kolDetails['salutation']]." ".$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);//echo $arrSalutations[$kolDetails['salutation']]." ".$kolDetails[FIRST_ORDER]." ".$kolDetails[SECOND_ORDER]." ".$kolDetails[THIRD_ORDER]?></a>
									<?php }else { echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']); }?>
								<?php }else { ?>
									<a  href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>"><?php echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);?></a>
								<?php }?>
								
								</span></td>
								<td><?php if(isset($kolDetails['specs']))
											echo $kolDetails['specs'];
									?></td>
								<td><?php if(isset($kolDetails['state']))
											echo $kolDetails['state'];
									?></td>
								<td><?php if(isset($kolDetails['city']))
											echo $kolDetails['city']; 
								?></td>
								<td><?php echo '<a class="linkClickToCall" href="callto:'.$kolDetails['primary_phone'].'" >'.$kolDetails['primary_phone'].'</a>';?></td>
								<td><a href="mailto:<?php echo $kolDetails['primary_email']; ?>" id="emailHolder"><?php echo $kolDetails['primary_email']; ?></a></td>
								<!--<td><?php echo $kolDetails['name'];?></td>
								<td><?php echo $kolDetails['primary_phone'].', '.$kolDetails['primary_email']; ?></td>
								-->
								
								<?php if(KOL_CONSENT) {?>
    								<td>	
    										<?php 
    										if($kolDetails['opt_in_out_status']==0){
    										    echo '';
    										}else{
    										    echo $kolDetails['opt_status_name'].' on '.date("d-M-Y", strtotime($kolDetails['modified_on']));
								            }?>
    								</td>	
									<?php }?>
								
								<td>
									
									<ul class="pageRightOptions">
									<?php $kolDetails['kol_id'] = $kolDetails['id']?>
									<?php if($this->common_helpers->isActionAllowed('kol','edit',$kolDetails)){ ?>
										<li>
											<!-- <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<a class="blueButton" href="#" onclick="edit(<?php echo $kolDetails['id'];?>); return false;" class="tooltipLink" rel='tooltip' title="Edit Contact">Edit Contact</a>
											</div> -->
											<div class="actionIcon editIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>/edit/" class="tooltipLink" rel="tooltip" data-original-title="Edit"></a></div>
										</li>
                                                                        <?php  } 
                                                                       
                                                                        if($this->common_helpers->isActionAllowed('kol','delete',$kolDetails)){ ?>
										 <li>
											<!--<div class="actionIcon deleteIcon tooltip-demo tooltop-bottom" onclick="deleteNonRequestededKol(<?php echo $kolDetails['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Delete"></a></div>-->
											<div class="actionIcon deleteIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>kols/delete_created_ol/<?php echo $kolDetails['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Delete"></a></div>
										</li> 
									<?php }?>
									<?php 
									if(KOL_CONSENT){
									    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
									<?php $kolDetails['kol_id']=$kolDetails['id']; if($this->common_helpers->isActionAllowed('profile_request','edit',$kolDetails)){  ?>
										<li>
											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<?php if($kolDetails['profile_type']=='User Added' || $kolDetails['profile_type']=='Legacy'){ ?>
												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfileUAL(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
    											<?php }else{ ?>
    												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfile(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
    											<?php }?>
											</div>
										</li>
									<?php }
									}else {
									       $butName = 'Create Opt-in Link';
									       if($kolDetails['opt_in_out_status']==2){
									           $butName = 'Resend Opt-in Link';
									       }?>
										
										<li>
    											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
    												<a class="blueButton" href="#" onclick="setLangUrlLink(<?php echo $kolDetails['id'];?>); return false;" class="tooltipLink" rel='tooltip' title="<?php echo $butName;?>"><?php echo $butName;?></a>
    											</div>
    									</li>
    								<?php }
									} else{?>
									<?php $kolDetails['kol_id']=$kolDetails['id']; if($this->common_helpers->isActionAllowed('profile_request','edit',$kolDetails)){  ?>
										<li>
											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<?php if($kolDetails['profile_type']=='User Added' || $kolDetails['profile_type']=='Legacy'){ ?>
												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfileUAL(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
    											<?php }else{ ?>
    												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfile(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
    											<?php }?>
											</div>
										</li>
									<?php }
									}?>
									</ul>
									&nbsp;
								</td>
								
							</tr>
					<?php 
							}
							
						}else{
							$evenOrOddRow	= true;
							foreach($arrKols as $kolDetails) {
								if($evenOrOddRow){
									$evenOrOddRow	= false;
								}else{
									$evenOrOddRow	= true;
								}
					?>
							<tr id="kol<?php echo $kolDetails['id'];?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
								<td width="3%">
									<input type="hidden" id="pdf_<?php echo $kolDetails['id'];?>" value="<?php echo $kolDetails['profile_type'];?>"></input>
									<input class="selectKolForHint" type="checkbox" name="list[]" value="<?php echo $kolDetails['id']?>" id="list"></input>					
								</td>
								<?php if($kolDetails['profile_image'] != ''){?>
									<td width="5%">
										<div class="tooltip-demo tooltop-top">
											<?php 
                								if(KOL_CONSENT){
                								    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
            											<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
            												<img class="defaultProfileIcon"  width="40" src="<?php echo base_url().'images/kol_images/resized/'.$kolDetails['profile_image'].''?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;" />
            											</a>
											<?php }else {?>
														<a href="#" class="tooltipLink" rel='tooltip' >
            												<img class="defaultProfileIcon"  width="40" src="<?php echo base_url().'images/kol_images/resized/'.$kolDetails['profile_image'].''?>" />
            											</a>
											<?php }
                						    }else {?>
                						    			<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
            												<img class="defaultProfileIcon"  width="40" src="<?php echo base_url().'images/kol_images/resized/'.$kolDetails['profile_image'].''?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;" />
            											</a>
                						    <?php }?>
										</div>
									</td>
								<?php }
								 else{ ?>
									<!--
										<td width="5%"><img class="micro_view_icon"  width="40" src="<?php echo base_url().'images/user_doctor.jpg'?>" /></td>
									-->
										<td width="5%">
                                                                                    
											<div class="tooltip-demo tooltop-top">
												<?php 
                								if(KOL_CONSENT){
                								    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
            											<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
        													<div class="defaultProfileIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;"></div>
        												</a>
    											<?php }else {?>
														<a href="#" class="tooltipLink" rel='tooltip'>
        													<div class="defaultProfileIcon <?php echo $kolDetails['gender'];?>" ></div>
        												</a>
    											<?php }
                    						    }else {?>
                    						    		<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
        													<div class="defaultProfileIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;"></div>
        												</a>
                    						    <?php }?>
											</div>
										</td>
								<?php }?>
<!--								<td width="100%" onclick="redirectToProfile(this);">-->
								<td width="50%">
								
								<?php 
								if(KOL_CONSENT){
								    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
									<a  href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>"><?php echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);?></a>
									<?php }else { echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']); }?>
								<?php }else { ?>
									<a  href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>"><?php echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);?></a>
								<?php }?>
									
									<?php echo "<br />"; ?>
									<?php if(isset($kolDetails['specs'])){
											echo $kolDetails['specs']; 
                                                                                        echo "<br />"; 
                                                                        }
                                                                        if(isset($kolDetails['city']))
											echo $kolDetails['city'];
										 if(isset($kolDetails['city']) && isset($kolDetails['state']))
										 	echo ', ';
									?>
									<?php if(isset($kolDetails['state']))
										echo $kolDetails['state'];
									if(isset($kolDetails['name']))
										echo "<br />";
									?>
									<?php echo $kolDetails['name'];?>
								</td>
								<td width="30%">
								<?php if(KOL_CONSENT && $kolDetails['opt_in_out_status'] > 0) {?>
    									<span class="record_name">Status: 
    										<?php 
    									       echo $kolDetails['opt_status_name'].' on '.date("d-M-Y", strtotime($kolDetails['modified_on']));
									        ?>
    									       
    									</span><br />
									<?php }?>
								<span class="record_name">Profile Type: <?php 
								echo $kolDetails['profile_type'];
								?> </span>
									<br /><span class="record_name">Created by: <?php 
									if($kolDetails['is_analyst'] == '1'){
										echo 'Aissel Analyst';
									}else{
										echo $kolDetails['created_by'];
										
									}?> on <?php echo date("d-M-Y", strtotime($kolDetails['created_on']));?></span><br/>
								</td>
								<td width="40%">
								
									<ul class="pageRightOptions">
									<li>
									<?php $kolDetails['kol_id'] = $kolDetails['id']?>
									<?php if($this->common_helpers->isActionAllowed('kol','edit',$kolDetails)){ ?>
										
											<!-- <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
												<a class="blueButton" href="#" onclick="edit(<?php echo $kolDetails['id'];?>); return false;" class="tooltipLink" rel='tooltip' title="Edit Contact">Edit Contact</a>
											</div> -->
											<div class="actionIcon editIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>/edit" class="tooltipLink" rel="tooltip" data-original-title="Edit"></a></div>
                                                                        <?php }
                                                                            
                                                                            if($this->common_helpers->isActionAllowed('kol','delete',$kolDetails)){ ?>
                                                                                     <li>
											<!--<div class="actionIcon deleteIcon tooltip-demo tooltop-bottom" onclick="deleteNonRequestededKol(<?php echo $kolDetails['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Delete"></a></div>-->
											<div class="actionIcon deleteIcon tooltip-demo tooltop-bottom"><a href="<?php echo base_url();?>kols/delete_created_ol/<?php echo $kolDetails['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Delete"></a></div>
										</li>
									<?php }?>
									</li>
									<li>
									<?php 
									if(KOL_CONSENT){
									    if($kolDetails['opt_in_out_status'] == 4 || $kolDetails['opt_in_out_status'] == 0) {?>
										<?php $kolDetails['kol_id']=$kolDetails['id'];if($this->common_helpers->isActionAllowed('profile_request','edit',$kolDetails)){ 
									    ?>
										
											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
											<?php if($kolDetails['profile_type']=='User Added' || $kolDetails['profile_type']=='Legacy'){ ?>
												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfileUAL(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
											<?php }else{ ?>
												<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfile(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
											<?php }?>
											</div>
    									<?php }
    									}else {
        									    $butName = 'Create Opt-in Link';
        									    if($kolDetails['opt_in_out_status']==2){
        									        $butName = 'Resend Opt-in Link';
    									       }?>
    											<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
    												<a class="blueButton" href="#" onclick="setLangUrlLink(<?php echo $kolDetails['id'];?>); return false;" class="tooltipLink" rel='tooltip' title="<?php echo $butName;?>"><?php echo $butName;?></a>
    											</div>
    									<?php }
    								}else {
    								    $kolDetails['kol_id']=$kolDetails['id'];if($this->common_helpers->isActionAllowed('profile_request','edit',$kolDetails)){?>
    								    <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
    										<?php if($kolDetails['profile_type']=='User Added' || $kolDetails['profile_type']=='Legacy'){ ?>
    											<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfileUAL(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
    										<?php }else{ ?>
    											<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewKolProfile(<?php echo $kolDetails['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
    										<?php }?>
										</div>
									<?php } 
    								}?>
    								
									</li>
									</ul>
									&nbsp;
								</td>
								
								<!--<td width="1%"><label onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event);"><img class="micro_view_icon" src="<?php echo base_url().'images/user3.png'?>" /></label></td>
								-->
								
							</tr>
					<?php 
							}
						}
					?>
						<tr class="searchPagination" style="background-color: white;">
							<td colspan="<?php echo ($viewType=='list')?'10':'5';?>" style="padding-top:6px !important;padding-bottom:6px !important;">
								<?php 
									if($viewType=='list'){?>
										 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('list')">
										<?php 
									}else{?>
									 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('main')">	
									<?php
									} 
									/*
										for($i=20;$i<151;$i+=10){
											if($i==$this->ajax_pagination->per_page){
												echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
											}else{
												echo '<option value="'.$i.'" >'.$i.'</option>';
											}
										}	
										echo '</select> Records Per Page ';
										for($i=10;$i<151;$i+=10){
											if($i==$this->ajax_pagination->per_page){
												echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
											}else{
												echo '<option value="'.$i.'" >'.$i.'</option>';
											}
										}	
									
									*/	
										//echo 'Display <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage()">';
									$arrPaginationValues	= explode(',',PAGINATION_VALUES);
									foreach($arrPaginationValues as $key =>$value){
										if($value==$this->ajax_pagination->per_page){
											echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
										}else{
											echo '<option value="'.$value.'" >'.$value.'</option>';
										}
									}
									echo '</select> Records Per Page ';
								?>
								<?php
									$config['first_link'] = 'First';
									$config['div'] = 'searchResultsContainer'; //Div tag id
									$urlPrfix="filter_search_kols";
									$config['base_url'] = base_url()."kols/".$urlPrfix;
									
									$config['total_rows'] = $kolsCount;
									$config['per_page'] = $this->ajax_pagination->per_page;
									$config['postVar'] = 'page';
									
									$this->ajax_pagination->initialize($config);
									print $this->ajax_pagination->create_links();
								?>				
							</td>
						</tr>
				</tbody>
			</table>
		</form>
		
		<div class="loadingIndicator" style="display: none;">
			
		</div>
