<?php
/**
 * Interactions numeric report
 * 
 * @author Ramesh B
 * @Created on: 13-10-12
 * @since 
 */
?>
<div style="height:800px;overflow-y:scroll">
<!-- <label class="ui-jqgrid-titlebar">Results</label> -->
<label>
	Interaction Type (All) 
	<?php if($interaction_for!='org') {?>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip" href="<?php echo base_url();?>interactions/export_numeric_report/mode/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
	<?php }?>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php krsort($arrModeResults); $i=0; foreach ($arrModeResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = 'Interaction Type (All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/mode/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrModeResults);?>
			</td>
		</tr>
	</tbody>
</table>

<label>
	Category (All)
	<?php if($interaction_for!='org') {?>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip" href="<?php echo base_url();?>interactions/export_numeric_report/grouping/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
	<?php }?>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php krsort($arrGroupingResults); $i=0; foreach ($arrGroupingResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = 'Category (All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/grouping/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrGroupingResults);?>
			</td>
		</tr>
	</tbody>
</table>

<label>
	Discussion Type (All)
	<?php if($interaction_for!='org') {?>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip"  href="<?php echo base_url();?>interactions/export_numeric_report/type/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
	<?php }?>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php 
			krsort($arrTypeResults); $i=0; foreach ($arrTypeResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = 'Discussion Type (All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/type/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrTypeResults);?>
			</td>
		</tr>
	</tbody>
</table>


<label>
	<?php echo lang("Overview.Product");?> (All)
	<?php if($interaction_for!='org') {?>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip" href="<?php echo base_url();?>interactions/export_numeric_report/product/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
	<?php }?>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php krsort($arrProductResults); $i=0; 
		foreach ($arrProductResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = lang("Overview.Product").'(All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/product/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrProductResults);?>
			</td>
		</tr>
	</tbody>
</table>

<label>
	Topic (All)
	<?php if($interaction_for!='org') {?>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip" href="<?php echo base_url();?>interactions/export_numeric_report/topic/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
	<?php }?>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php krsort($arrTopicResults); $i=0; foreach ($arrTopicResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = 'Topic (All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/topic/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrTopicResults);?>
			</td>
		</tr>
	</tbody>
</table>

<!--
<label>
	Subtopic (All)
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="margin-top: -2px;float:right;margin-right: 36px;">
		<a data-original-title="Export to Excel" rel="tooltip" href="<?php echo base_url();?>interactions/export_numeric_report/subtopic/<?php echo $urlFilterSuffix;?>">&nbsp;</a>
	</div>
</label>
<table>
	<thead>
		<tr>
			<th>&nbsp;</th>
			<th>Given Period</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>YTD</th>
		</tr>
	</thead>
	<tbody>
		<?php krsort($arrSubTopicResults); $i=0; foreach ($arrSubTopicResults as $row){ 
			$labelName = $row['name'];
			$id =  $row['id'];
			if($i == 0){ $labelName = 'Topic (All)'; $id = 0;}
			?>
			<tr>
				<td class="reportLabels"><?php echo $labelName;?></td>
				<td>
					<?php if($row['gp'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/gp/<?php echo $urlFilterSuffix;?>" ><?php echo $row['gp'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q1'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/q1/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q1'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q2'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/q2/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q2'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q3'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/q3/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q3'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['q4'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/q4/<?php echo $urlFilterSuffix;?>" ><?php echo $row['q4'];?></a>
					<?php }?>
				</td>
				<td>
					<?php if($row['ytd'] == 0){?>
						0
					<?php }else{ ?>
						<a href="<?php echo base_url();?>interactions/view_drilldown_list/subtopic/<?php echo $id;?>/ytd/<?php echo $urlFilterSuffix;?>" ><?php echo $row['ytd'];?></a>
					<?php }?>
				</td>
			</tr>
		<?php $i++; }?>
		<tr class="lastColumn">
			<td colspan="7">
				Records : <?php echo sizeof($arrSubTopicResults);?>
			</td>
		</tr>
	</tbody>
</table>-->

</div>