
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php if(isset($title) && $title!=null) { echo $title; } else { echo "KOLM"; }?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	
	<link type="text/css" href="<?php echo base_url()?>css/login.css"  rel="stylesheet" />
	<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	<meta http-equiv="X-UA-Compatible" content="chrome=1">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url()?>css/ipad_login_only.css">
	<?php /* if(IS_IPAD_REQUEST == 1){
			?>
			<meta content='initial-scale=1.0;' name='viewport' />
			<link type="text/css" rel="stylesheet" media="only screen and (min-device-width: 481px) and (max-device-width: 1024px)" href="<?php echo base_url()?>css/ipad_login_only.css">
			<?php 
		}*/?>
	<?php
	//	header("Cache-Control: no-cache, must-revalidate");
		header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");
	?>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<script type="text/javascript">
	    window.history.forward();
	    function noBack() { window.history.forward(); }
	    $(document).ready(function (){
	    	//$('form#redirectForm').submit();
	    	$("#submitForm").trigger('click');
	    });
	</script>
	<div>
	<form id="redirectForm" action="<?php echo base_url()?>login" method="get">
		<input type="submit" id="submitForm" style="display: none;">
	</form>
		<!--<div class="headerBG"><h2 class="productName">KOLM</h2></div>
		<div id="loginContainer">
			<div id="loginWrapper">
				<div  title="Login" id="loginFormContainer">
					<div class="boldText"><center>You are successfully Logged Out.</center></div><br />
				</div>
			</div>
		</div>
		<div class="headerBG"><h1>&nbsp;</h1></div>
		<div id="loginFooter">
			&nbsp;&nbsp;<img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" style="float:right;" />&nbsp;&nbsp;
			<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | KOLM <?php echo PRODUCT_VERSION;?> Copyright &copy; 2012 <a href="http://www.aissel.com" target="new">Aissel</a> Solutions | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
		</div>
	-->
		<table style="width:100%;border-collapse: collapse;">
			<tr>
				<td colspan="2" class="productNameContainer"><h2 class="productName"><?php echo PRODUCT_NAME;?></h2></td>
			</tr>
			<tr class="container">
				<td style="padding:15% 0 0% 10%;">
					<div class="logo"></div>
				</td>
				<td style="padding:15% 10% 0% 0;">
					<div id="loginContainer">
						<div id="loginWrapper">
							<div  title="Login" id="loginFormContainer">
								<div class="boldText"><center>You are successfully Logged Out.</center></div><br />
							</div>
						</div>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="2" class="footerContainer">
					<div id="loginFooter">
						&nbsp;&nbsp;<img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" style="float:right;" />&nbsp;&nbsp;
						<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | <?php echo PRODUCT_NAME;?> <?php echo PRODUCT_VERSION;?> Copyright &copy; <?php echo COPYRIGHT;?> <a href="http://www.aissel.com" target="new">Aissel</a> Technologies | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
					</div>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>
