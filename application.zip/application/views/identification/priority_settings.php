<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<script type="text/javascript">
	var curentTab = 'Journals';
        var projectId;
	$(document).ready(function(){  
                 projectId= <?php echo $projectId; ?>;//localStorage.getItem("ProjectId");
                 projectName=localStorage.getItem("ProjectName");
                 if(projectId==0 || typeof projectId==="undefined" ){
                 
                 }else{
                      $('#projectSelection').val(projectId);
                 }
		$('.secondaryMenuItem a').on('click',function(){
			var filterData = {};
			curentTab = $(this).html();
			curentTab = curentTab.replace(/<\/?[^>]+(>|$)/g, "");
			filterData["type"] = curentTab;
			filterData["projectId"] = projectId;
			loadPriorityData(filterData);
			$("#secondaryNav li").each(function(){
				$(this).removeClass('active');
			});
			$(this).parent().parent().addClass('active');
			/*$.ajax({
				dataType:"text",
				url:base_url+"identifications/load_priority_data",
				type:"POST",
				data:filterData,
				success:function(returnData){
					$("#listHolder").html(returnData);
				}
			});*/
		});
                $("#projectSelection").change(function(){ 
                        var filterData = {};
                        filterData["type"] = curentTab;
                        if(this.value!=''){
                            filterData["projectId"] = this.value;
                        	projectId = this.value;
                        }
                        loadPriorityData(filterData);
                });
		var filterData = {};
		filterData["type"] = curentTab;
                filterData["projectId"] = projectId;
		loadPriorityData(filterData);
	});

     
	function searchSelectChange(thiEle){
		var selText = $(thiEle).find("option:selected").text();
		var selVal = $(thiEle).val();
		$(thiEle).removeClass("priorityHigh priorityMedium priorityLow priority");
		$(thiEle).addClass('priority'+selText);
	}
	
	var priorRequest;
	function loadPriorityData(filterData){
		var priorityDropDowns	= ":All;2:High;1:Medium;0:Low";
		$("#listHolder").html("");
		// Append the required div and table
		$("#listHolder").html('<div class="gridWrapper"><table id="priorityResultSet"></table><div id="priorityPager"></div></div>');
		jQuery("#priorityResultSet").jqGrid({
		   	url:base_url+'identifications/load_priority_data/',
		   	postData:filterData,
			datatype: "json",
			colNames:['Id','Name','Priority'],
		   	colModel:[
						{name:'id',index:'id', hidden:true},
						{name:'name',index:'name', width:700},
				    	{name:'priority',index:'priority', width:120,title: false,formatter: function (cellvalue, options, rowObject) {
					    	var cellcontent = rowObject.priority;
					    	if(cellcontent == '0')
					    		cellcontent = "Low";
					    	if(cellcontent == '1')
					    		cellcontent = "Medium";
					    	if(cellcontent == '2')
					    		cellcontent = "High";
				    		if(cellcontent == '')
				    			cellcontent = '';
							var selectContent = "<select rowid='"+rowObject.id+"' name='priority' onchange='saveSelectedValue(this); return false;' class='priority"+cellcontent+"'>";
							selectContent +="<option value=''";
							if(cellcontent == '') selectContent +=" selected='selected'";
							selectContent +=">None</option>";

							selectContent +="<option value='2'";
							if(cellcontent == 'High') selectContent +=" selected='selected'";
							selectContent +=">High</option>";

							selectContent +="<option value='1'";
							if(cellcontent == 'Medium') selectContent +=" selected='selected'";
							selectContent +=">Medium</option>";

							selectContent +="<option value='0'";
							if(cellcontent == 'Low') selectContent +=" selected='selected'";
							selectContent +=">Low</option>";
							selectContent +="</select>";

							return selectContent;
			    		},stype:'select', editoptions:{value:priorityDropDowns}}
		   	],
		   	rowNum:10,
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	hidegrid: false,
		   	height: "auto",	
		   	width:850,
		   	resizable:true,
		   	shrinkToFit: true,
		   	pager: '#priorityPager',
		   	mtype: "POST",
		   	sortname: 'institute_id',
		    viewrecords: true,
		    sortorder: "desc",
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:'',
		   	rowList:paginationValues,
		    gridComplete: function(){ 
		    	jQuery("#priorityResultSet").jqGrid('setCaption', curentTab);
		    	$("#listHolder .ui-jqgrid-titlebar").append('<span id="updateStatus" style="display: block; text-align: center; color: green;"> </span>');
		    	initilizeGridSearchPlaceholder();

		    	$(".ui-search-input select").attr('onchange',"searchSelectChange(this)");
	    	},
	    	loadBeforeSend: function(jqXHR)  {
		    	if(priorRequest != null)
	    			priorRequest.abort();
	    		
	    		priorRequest = jqXHR;
	        },
	    	onCellSelect: function(rowid, icol, cellcontent, e) {
				if(icol == 3){
					/*var selectContent = "<select rowid='"+rowid+"' name='priority' onchange='saveSelectedValue(this); return false;'>";
					selectContent +="<option value=''";
					if(cellcontent == '') selectContent +=" selected='selected'";
					selectContent +=">None</option>";

					selectContent +="<option value='High'";
					if(cellcontent == 'High') selectContent +=" selected='selected'";
					selectContent +=">High</option>";

					selectContent +="<option value='Medium'";
					if(cellcontent == 'Medium') selectContent +=" selected='selected'";
					selectContent +=">Medium</option>";

					selectContent +="<option value='Low'";
					if(cellcontent == 'Low') selectContent +=" selected='selected'";
					selectContent +=">Low</option>";
					selectContent +="</select>";

					$(e.target).html(selectContent);*/

					//$(e.target).find('select').trigger('click');
				}
		    }
		});
		//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
		jQuery("#priorityResultSet").jqGrid('navGrid','#priorityPager',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		jQuery("#priorityResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
			/*$(".ui-search-toolbar input[type='text']").each(function(){
				if($(this).val() == 'Search')
					$(this).val("");
		    });*/
		},afterSearch:function(){
			/*$(".ui-search-toolbar input[type='text']").each(function(){
				if($(this).val() == '')
					$(this).val("Search");
		    });*/
		}});

	}

	function saveSelectedValue(thisEle){
		rowId = $(thisEle).parent().parent().attr('id');
		celValue = $(thisEle).val();
		var rowData = $('#priorityResultSet').jqGrid('getRowData', rowId);
		var filterData = {};
		filterData["type"] = curentTab;
		filterData["id"] = rowData.id;
		filterData["priority"] = celValue;

		$.ajax({
		dataType:"text",
		url:base_url+"identifications/update_priority",
		type:"POST",
		data:filterData,
		success:function(returnData){
			rowData.priority= $(thisEle).val();
			$('#priorityResultSet').jqGrid('setRowData', rowId, rowData);
			$("#updateStatus").show();
			$("#updateStatus").html("Data Saved.........");
			$("#updateStatus").fadeOut('slow');
		}
		});
	
		//$(thisEle).parent().html($(thisEle).val());
		//alert($(thisEle).attr('rowid'));
	}
	
</script>
<style>
	#listHolder select{
		width: 80px !important;
	}
	.ui-search-input select{
		margin-left: -4px !important;
	}
	#sideBarContents #secondaryNav ul li .sprite_iconSet{
		margin-top: 0px;
	}
	#listHolder select option[value='2'], #listHolder .priorityHigh{
		color: white;
		background: green;
	}
	#listHolder select option[value='1'], #listHolder .priorityMedium{
		color: black;
		background: yellow;
	}
	#listHolder select option[value='0'], #listHolder .priorityLow{
		color: white;
		background: red;
	}
	#listHolder select option[value=''], #listHolder .priority{
		color: black;
		background: white;
	}
</style>
<label style="font-size: 15px;font-weight: bold;">Priority Settings</label>

		
			
				<div> <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 36px;">Projects</label>
					<div style="border-bottom:1px solid #2283AE;">
						<select id="projectSelection" name="project" class="chosenSelect" style="width:180px;" >
							<!--<option value="">All Therapeutic area</option>-->
							<?php foreach($arrProjects as $project){?>
								<option id="<?php echo $project['name'];?>" value="<?php echo $project['id'];?>" <?php if($defaultProjectId == $project['id']){echo "selected='selected'";}?> ><?php echo $project['name'];?></option>
							<?php }?>
						</select>
					</div>
				</div>
			
<div id="listHolder">
	
</div>

<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min','chosen.jquery');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>