<style type="text/css">
	.eventsMicroWrapper table caption h3{
		margin: 5px 0px;
	}
</style>
<div class="eventsMicroWrapper">
	<?php foreach($arrEvents as $result){?>
		<table class="microViewTbl">
			<caption><h3><?php echo $result['name']?></h3></caption>
			<tr>
				<th><span class="addrHeading">Event Type :</span></th>
				<td><?php echo $result['conf_event_type'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Session Type :</span></th>
				<td><?php echo $result['conf_session_type'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Session Name :</span></th>
				<td><?php echo $result['session_name'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Topic :</span></th>
				<td><?php echo $result['event_topic'];?></td>
			</tr>
		
			<tr>
				<th><span class="addrHeading">Role :</span></th>
				<td><?php echo $result['role'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Start date :</span></th>
				<td><?php if($result['start']>0) echo $result['start'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">End Date :</span></th>
				<td><?php if($result['end']>0) echo $result['end'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Location :</span></th>
				<td><?php echo $result['location'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Country :</span></th>
				<td><?php echo $result['country'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Organizer :</span></th>
				<td><?php echo $result['organizer'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Session Sponsor :</span></th>
				<td><?php echo $result['session_sponsor'];?></td>
			</tr>
			<tr>
				<th><span class="addrHeading">Sponsor Type :</span></th>
				<td><?php echo $result['sponsor_type_name'];?></td>
			</tr>
		<!--  
			<tr>
				<th><span class="addrHeading">Event Location:</span></th> 
				<td><?php 
						if($result['type'] == 'online')
							echo 'Online';
						else{
							if($result['address'] != '')
								echo $result['address']. '<br />';
							
							if($result['region'] != '')
								echo $result['region'] .' ';
							
							echo $result['postal_code'] .' ';
							
							echo '<br />' .$result['country'];
						}
					?>
				</td>
			</tr>-->
		</table>
	<?php }?>	
</div>
<!-- End of leftAdressBar Div -->