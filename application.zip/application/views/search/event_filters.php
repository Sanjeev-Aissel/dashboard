<?php
/**
 * 
 *
 * @author: Vinayak
 * @created on: 9-12-10
 */
//	$autoSearchOptions = "width: 140, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
	$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";

?>

<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999; */
	/*	margin-top:0.7em;*/
		overflow:visible;
		padding-top:0.8em;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url(../../images/sprite_facetsearch_v7.png) no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:11px;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttn{
		width: 11px;
		height: 11px;
		float: right;
		background-color:buttonshadow;
		-moz-border-radius-bottomleft:2px;
		-moz-border-radius-bottomright:2px;
		-moz-border-radius-topleft:2px;
		-moz-border-radius-topright:2px;
		vertical-align: middle;
		margin-left:4px;
		margin-top:4px;
		cursor: pointer;
		margin-right: 10px;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
</style>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<script type="text/javascript">
		var options, a;
		
		// Autocomplet Options for the 'Event Type' field 
	  	var commonEventTypeAutoCompleteOptions = {
				lookup:['Congress', 'Conference', 'Grand Rounds', 'Annual Meeting', 'CME','Symposium','Seminar','Workshop','Meeting','Grand Round','Poster Session','Abstract Presentation','Webcast','Webinar','Podcast'],
				<?php echo $autoSearchOptions;?>
				
			};	
	

		// Autocomplet Options for the 'role' field 
	  	var confRoleNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_search_role_names',
				<?php echo $autoSearchOptions;?>
				
			};	

	 	// Autocomplet Options for the 'Organizer' field 
		var organizerNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_organizer_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		// Autocomplet Options for the 'country' field
		var countryNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		// Autocomplet Options for the 'country' field
		var stateNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		$(document).ready(function(){

			$('#categoriesContainer input:checked').each(function (index){
				$(this).parent().parent().css('background-color','#D3DFED');
			});

			$('#searchFiltersElements ul li table tr').click(function (){
				if($('#'+$(this).attr('class')).attr('checked')=="checked"){
					$(this).css('background-color','#ffffff');
					$('#'+$(this).attr('class')).removeAttr('checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}else{
					$(this).css('background-color','#D3DFED');
					$('#'+$(this).attr('class')).attr('checked','checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}
			});
			
			// Trigger the Autocompleter for 'Role' field of  Event'
			a = $('#type').autocomplete(commonEventTypeAutoCompleteOptions);

			// Trigger the Autocompleter for 'Role' field of  Event'
			a = $('#role').autocomplete(confRoleNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'organizer' field of  Event'
			a = $('#organizer').autocomplete(organizerNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#country').autocomplete(countryNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#state').autocomplete(stateNameAutoCompleteOptions);

		});

		// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
			var parentId=$(thisEle).parent().attr("id");
			if($(thisEle).hasClass('expanded')){
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				//$('#searchLeftBar #'+parentId+' ul').hide();
				$(thisEle).next().hide();
			}
			else {
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
				//$('#searchLeftBar #'+parentId+' ul').show();
				$(thisEle).next().show();
			}
		}
</script>
	
<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>kols/<?php if($searchType=='simple') echo 'filter_search_events'; else echo 'filter_adv_search_events' ;?>" name="searchForm" method="post" id="searchFilterForm">
		<input type="hidden" name="keyword" id="keyword" value="<?php echo $keyword; ?>"/>
		<input type="hidden" name="search_type" id="searchType" value="<?php echo $searchType; ?>"/>
		<input type="hidden" name="filterCategory" id="filterCategory" value="events"/>
		
		<?php if($arrAdvSearchFields != null){ ?>
			<input type="hidden" name="type" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['type']; ?>"/>
			<input type="hidden" name="eventRole" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['role']; ?>"/>
			<input type="hidden" name="evntCountry" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['country']; ?>"/>
			<input type="hidden" name="evntState" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['state']; ?>"/>
			<input type="hidden" name="eventOrganizer" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['organizer']; ?>"/>
		<?php }?>							
		
		<!--<div id="resetBttnContainer"><label id="resetBttn" onclick="resetFilters();">&nbsp</label>Reset</div>
		-->
		<ul id="categoriesContainer">
			<li id="categoryCountry" class="category">
				<div class="countryIcon sprite_iconSet"></div>
				<label class="categoryName">Country</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allCountries">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Countries</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allCountryCount."(".round(($allCountryCount/$allCountryCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($allCountryCount/$allCountryCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?></td>
					</tr>
						<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrEventsByCountryCount as $countryCountDetails){ ?>
					 	<?php if($countryCountDetails['country']!=''){?>
					 	<tr class="country<?php echo str_replace(' ','',str_replace('&','and',$countryCountDetails['country']));?>">
					 		<td class="textAlignRight"><input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(' ','',str_replace('&','and',$countryCountDetails['country']));?>" value="<?php echo $countryCountDetails['country'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedCountries) && sizeof($selectedCountries)>0 && $selectedCountries!=null){if(in_array($countryCountDetails['country'], $selectedCountries)) {?>
									checked="checked"
								<?php //remove the checked vlues from selected array
								$key = array_search($countryCountDetails['country'], $selectedCountries);if(array_key_exists($key, $selectedCountries))unset($selectedCountries[$key]);$selectedCountries=array_values($selectedCountries);}}?>
								/>&nbsp;<?php echo $countryCountDetails['country'];?>
							</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							 <td><?php echo $countryCountDetails['count'];?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCountries) && $selectedCountries!=null){foreach($selectedCountries as $countryName){?>
						<tr class="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>">
							<td class="textAlignRight"><input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>" value="<?php echo $countryName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $countryName;?>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrEventsByCountryCount[$countryName]['count']."(".round(($arrEventsByCountryCount[$countryName]['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrEventsByCountryCount[$countryName]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($countryName, $arrEventsByCountryCount)) echo $arrEventsByCountryCount[$countryName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					<div class="filterSearchIcon"></div>
					<input type="text" name="country" class="autocompleteInputBox" id="country" value="" title=""/>
				</div>
			</li>
			<li id="categoryState" class="category">
				<div class="stateIcon sprite_iconSet"></div>
				<label class="categoryName">State</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allStates">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_states" id="allStates"  value="state" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All States</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allStateCount."(".round(($allStateCount/$allStateCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($allStateCount/$allStateCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?></td>
					</tr>
						<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrEventsByStateCount as $stateCountDetails){ ?>
					 	<?php if($stateCountDetails['country']!=''){?>
					 	<tr class="state<?php echo str_replace(' ','',str_replace('&','and',$stateCountDetails['state']));?>">
					 		<td class="textAlignRight"><input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo str_replace(' ','',str_replace('&','and',$stateCountDetails['state']));?>" value="<?php echo $stateCountDetails['state'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedStates) && sizeof($selectedStates)>0 && $selectedStates!=null){if(in_array($stateCountDetails['state'], $selectedStates)) {?>
									checked="checked"
								<?php //remove the checked vlues from selected array
								$key = array_search($stateCountDetails['state'], $selectedStates);if(array_key_exists($key, $selectedStates))unset($selectedStates[$key]);$selectedStates=array_values($selectedStates);}}?>
								/>&nbsp;<?php echo $stateCountDetails['state'];?>
							</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $stateCountDetails['count']."(".round(($stateCountDetails['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($stateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							 <td><?php echo $stateCountDetails['count'];?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedStates) && $selectedStates!=null){foreach($selectedStates as $stateName){?>
						<tr class="state<?php echo str_replace(' ','',str_replace('&','and',$stateName));?>">
							<td class="textAlignRight"><input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo str_replace(' ','',str_replace('&','and',$stateName));?>" value="<?php echo $stateName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $stateName;?>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrEventsByStateCount[$stateName]['count']."(".round(($arrEventsByStateCount[$stateName]['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($arrEventsByStateCount[$stateName]['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($stateName, $arrEventsByStateCount)) echo $arrEventsByStateCount[$stateName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					<div class="filterSearchIcon"></div>
					<input type="text" name="state" class="autocompleteInputBox" id="state" value="" title=""/>
				</div>
			</li>
			<li id="categotyRole" class="category">
				<label class="categoryName">Role</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allRoles">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_roles" id="allRoles" value="role" <?php if(isset($selectedRoles) && $selectedRoles!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Roles</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allRoleCount."(".round(($allRoleCount/$allRoleCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allRoleCount)) echo round(($allRoleCount/$allRoleCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allRoleCount)) echo $allRoleCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrEventsByRoleCount as $roleCountDetails){ ?>
					 	<?php if($roleCountDetails['role']!=''){?>
					 	<tr class="edu<?php echo str_replace(' ','',str_replace('&','and',$roleCountDetails['role']));?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="role_ids[]" class="roleElement hideCheckbox" id="edu<?php echo str_replace(' ','',str_replace('&','and',$roleCountDetails['role']));?>" value="<?php echo $roleCountDetails['role'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedRoles) && sizeof($selectedRoles)>0 && $selectedRoles!=null){if(in_array($roleCountDetails['role'], $selectedRoles)) {?>
									checked="checked"
								<?php $key = array_search($roleCountDetails['role'], $selectedRoles);if(array_key_exists($key, $selectedRoles))unset($selectedRoles[$key]);$selectedRoles=array_values($selectedRoles);}}?>
								/>&nbsp;<?php echo $roleCountDetails['role'];?>
							</td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $roleCountDetails['count']."(".round(($roleCountDetails['count']/$allRoleCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allRoleCount)) echo round(($roleCountDetails['count']/$allRoleCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php echo $roleCountDetails['count'];?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedRoles) && $selectedRoles!=null){foreach($selectedRoles as $roleName){?>
						<tr class="edu<?php echo str_replace(' ','',str_replace('&','and',$roleName));?>">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="role_ids[]" class="roleElement" id="edu<?php echo str_replace(' ','',str_replace('&','and',$roleName));?>" value="<?php echo $roleName;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $roleName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrEventsByRoleCount[$roleName]['count']."(".round(($arrEventsByRoleCount[$roleName]['count']/$allRoleCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allRoleCount)) echo round(($arrEventsByRoleCount[$roleName]['count']/$allRoleCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($roleName, $arrEventsByRoleCount)) echo $arrEventsByRoleCount[$roleName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="role" class="autocompleteInputBox" id="role" value="" title=""/>
				</div>
			</li>
			
			<li id="categotyOrganizer" class="category">
				<label class="categoryName">Oraganizer</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allOrgs">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_orgs" id="allOrgs" value="organizer" <?php if(isset($selectedOrgs) && $selectedOrgs!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Organizers</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allOrgCount."(".round(($allOrgCount/$allOrgCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($allOrgCount/$allOrgCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allOrgCount)) echo $allOrgCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrEventsByOrgCount as $orgCountDetails){ ?>
					 	<?php if($orgCountDetails['organizer']!=''){?>
					 	<tr class="org<?php echo str_replace(' ','',str_replace('&','and',$orgCountDetails['organizer']));?>">
							<td class="textAlignRight">
							<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo str_replace(' ','',str_replace('&','and',$orgCountDetails['organizer']));?>" value="<?php echo $orgCountDetails['organizer'];?>" onclick="doSearchFilter1(-1,this)" 
							<?php if(isset($selectedOrgs) && sizeof($selectedOrgs)>0 && $selectedOrgs!=null){if(in_array($orgCountDetails['organizer'], $selectedOrgs)) {?>
								checked="checked"
							<?php $key = array_search($orgCountDetails['organizer'], $selectedOrgs);if(array_key_exists($key, $selectedOrgs))unset($selectedOrgs[$key]);$selectedOrgs=array_values($selectedOrgs);}}?>
							/>&nbsp;<?php echo $orgCountDetails['organizer'];?>
							</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $orgCountDetails['count']."(".round(($orgCountDetails['count']/$allOrgCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($orgCountDetails['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php echo $orgCountDetails['count'];?></td>
						</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgs) && $selectedOrgs!=null){foreach($selectedOrgs as $orgName){?>
							<tr class="org<?php echo str_replace(' ','',str_replace('&','and',$orgName));?>">
								<td class="textAlignRight">
									<input type="checkbox"  name="org_ids[]" class="orgElement" id="org<?php echo str_replace(' ','',str_replace('&','and',$orgName));?>" value="<?php echo $orgName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $orgName;?>
								</td>
								<td class="histoGram">
									<div class="filterBar">
										<div class="progress" title="<?php echo $orgCountDetails['count']."(".round(($arrEventsByOrgCount[$orgName]['count']/$allOrgCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($arrEventsByOrgCount[$orgName]['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if (array_key_exists($orgName, $arrEventsByOrgCount)) echo $arrEventsByOrgCount[$orgName]['count']; else echo 0;?></td>
							</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="organizer" class="autocompleteInputBox" id="organizer" value="" title=""/>
				</div>
			</li>
		</ul>
	</form>
</div>