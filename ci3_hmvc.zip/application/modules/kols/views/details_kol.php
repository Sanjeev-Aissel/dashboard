<?php 
/**
 * File to 'add and list' kols details from analyst application
 *
 * @author: Sanjeev K
 * @package application.module.views.kols.details_kol
 * @version HMVC 1.0
 * @created on: 29-04-2018
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<script>
var emailCount=0;
//autocomplete script
var organizationNameAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names/1',
					<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {                    	
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    console.log(selId);
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#saveKolLocationForm #organizationLocation').val(selText);
                    $('input[name="org_institution_id"]').val(selId);
//                     $('#saveKolLocationForm #org_institution_id').val(selId);
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#saveKolLocationForm #organizationLocation').val(trim(split(' ', selText)[4]));
                            return false;
                        }
                    }                       
                }
    };
    
//Validation rules for Location
		var validationLocationRules	=  {
			organization: {
				required:true	
			},
			address1: {
				required:true
			},
			country_id: {
				required:true
			},
			state_id: {
				required:true
			},
			city_id: {
				required:true
			}			
		};
		//Validation messages for Location
		var validationLocationMessages = {
				organization: {
					required: "Required"
				},
				address1: {
					required: "Required"
				},
				country_id: {
					required: "Required"
				},
				state_id: {
					required: "Required"
				},
				city_id: {
					required: "Required"
				}
			
		};
		
//Load DOM on page gets load
$(document).ready(function(){
	var a = '';
	a = $('#saveKolLocationForm #organizationLocation').autocomplete(organizationNameAutoCompleteOptions);

	$('.nav-tabs li a').click(function(){
		loadSelectedTab(this);
	});
	
	locationTab();
	
	/**
	* Save the 'Location Details'
	*/
	$("#saveLocationInfo").click(function(){
			// Disable the SAVE Button
			disableButton("saveLocationInfo");
			$("#saveKolLocationForm").validate().resetForm();
			
			if(!$("#saveKolLocationForm").validate().form()){
				enableButton("saveLocationInfo");
				return false;
			}else{
				var kolId = $('#kolId').val();
				var locationId = $('#locationId').val();
				$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
				if (!$("#saveKolLocationForm").validate().form()){
			        return false;
			    }
				$.ajax({
			        url: base_url+'kols/save_location/'+kolId,
			        type: 'post',
			        dataType: 'json',
			      	data: $('#saveKolLocationForm').serialize(),
			        success: function (returnData) {
			          if(returnData.status){
			        	  enableButton("saveLocationInfo");
			        	  $("#msgBox").html('');
			        	  $("#genericGridContainer").html('<table id="LocationResultSet"></table><div id="listLocationPage"></div>');
			        	  locationTab();
			          }else{
			        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
			        		return false;
			          }
			        },
		        complete: function(returnData){
							if(locationId == ''){
								 document.getElementById("saveKolLocationForm").reset();
								}
			        }
				});
				}
	});		
	/**
	* Save the 'Phone Details'
	*/
	$("#savePhoneInfo").click(function(){
			$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
			if (!$("#saveKolPhoneNumberForm").validate().form()){
		        return false;
		    }
			$.ajax({
		        url: base_url+'kols/save_phone',
		        type: 'post',
		        dataType: 'json',
		      	data: $('#saveKolPhoneNumberForm').serialize(),
		        success: function (returnData) {
		          if(returnData.status){
		        	  $("#msgBox").html('');
		        	  $("#genericGridContainer").html('<table id="PhoneNumberResultSet"></table><div id="listPhoneNumberPage"></div>');
		        	  phoneNumberTab();
		          }else{
		        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
		        		return false;
		          }
		        }
			});
	});	
	$("#saveStaffInfo").click(function(){
		var kolId = $('#kolId').val();
		$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
		if (!$("#saveKolStaffForm").validate().form()){
	        return false;
	    }
		$.ajax({
	        url: base_url+'kols/save_staff',
	        type: 'post',
	        dataType: 'json',
	      	data: $('#saveKolStaffForm').serialize(),
	        success: function (returnData) {
	          if(returnData.status){
	        	  $("#msgBox").html('');
	        	  staffTab();
	          }else{
	        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
	        		return false;
	          }
	        }
		});
	});	
	$("#saveEmailInfo").click(function(){
		var kolId = $('#kolId').val();
		$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
		if (!$("#saveKolEmailForm").validate().form()){
	        return false;
	    }
		$.ajax({
	        url: base_url+'kols/save_email',
	        type: 'post',
	        dataType: 'json',
	      	data: $('#saveKolEmailForm').serialize(),
	        success: function (returnData) {
	          if(returnData.status){
	        	  close_dialog();
	        	  $("#msgBox").html('');
	              getEmailsData();
	          }else{
	        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
	        		return false;
	          }
	        }
		});
	});
	$("#saveStateLicenseInfo").click(function(){
		var kolId = $('#kolId').val();
		$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
		if (!$("#saveKolStateLicenseForm").validate().form()) {
	        return false;
	    }
		$.ajax({
	        url: base_url+'kols/save_state_license',
	        type: 'post',
	        dataType: 'json',
	      	data: $('#saveKolStateLicenseForm').serialize(),
	        success: function (returnData) {
	          if(returnData.status){
	        	  close_dialog();
	        	  $("#msgBox").html('');
	        	  getStateLicenceData();
	          }else{
	        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
	        		return false;
	          }
	        }
		});
	});
	$("#saveUserAssignInfo").click(function(){
		var kolId = $('#kolId').val();
		$("#msgBox").html('<div class="alert alert-info">Saving the data... <img src="'+base_url +'assets/images/ajax_loader_black.gif"></div>');
		if (!$("#saveKolAssignClientForm").validate().form()) {
	        return false;
	    }
		$.ajax({
	        url: base_url+'kols/save_client_assign',
	        type: 'post',
	        dataType: 'json',
	      	data: $('#saveKolAssignClientForm').serialize(),
	        success: function (returnData) {
	          if(returnData.status){
	        	  close_dialog();
	        	  $("#msgBox").html('');
	        	  getAssignedData();
	          }else{
	        	  $("#msgBox").html('<div class="alert alert-danger">Kol with same details already exists..</div>');
	        		return false;
	          }
	        }
		});
	});
});
$(function(){
	$("#saveKolLocationForm").validate({
		debug:true,
		//onkeyup:true,
		rules: validationLocationRules,
		messages: validationLocationMessages
	});
});	
//Javascript Functions goes here
function disableButton(buttonId){
	$("#"+buttonId).attr("disabled", "disabled");
}

function enableButton(buttonId){
	$("#"+buttonId).removeAttr("disabled");
}	
function getStatesByCountryId() {   //get states names of that country ,onchange/selecting of a country.
    $("#loadingStates").show();
    var countryId = $('#country_id').val();
    if(countryId!=0){
	    var params = "country_id=" + countryId;
	    var states = document.getElementById('state_id');
	    $.ajax({
	        url: base_url+'helpers/country_helpers/get_states_by_countryid',
	        dataType: "json",
	        data: params,
	        type: "POST",
	        success: function (responseText) {
	        	$("#state_id").html('');
	        	$("#state_id").append("<option value=''>-- Select State --</option>");
	            $.each(responseText, function (key, value) {
	                $('#state_id').append("<option value='"+value.state_id+"'>"+value.state_name+"</option>");
	            });
	        },
	        complete: function () {
	            $("#loadingStates").hide();
	        }
	    });
    }else
    	{
    	$("#state_id").html('');
    	$("#state_id").append("<option value=''>-- Select State --</option>");
    	}
}
function getStatesByCountryIdLicense() {   //get states names of that country ,onchange/selecting of a country.
    $("#loadingStates").show();
    var countryId = $('#country_id_license').val();
    if(countryId!=0){
	    var params = "country_id=" + countryId;
	    var states = document.getElementById('state_id');
	    $.ajax({
	        url: base_url+'helpers/country_helpers/get_states_by_countryid',
	        dataType: "json",
	        data: params,
	        type: "POST",
	        success: function (responseText) {
	        	$("#state_id_license").html('');
	        	$("#state_id_license").append("<option value=''>-- Select State --</option>");
	            $.each(responseText, function (key, value) {
	                $('#state_id_license').append("<option value='"+value.state_id+"'>"+value.state_name+"</option>");
	            });
	        },
	        complete: function () {
	            $("#loadingStates").hide();
	        }
	    });
    }else
    	{
    	$("#state_id_license").html('');
    	$("#state_id_license").append("<option value=''>-- Select State --</option>");
    	}
}
function getCitiesByStateId() {   //get states names of that country ,onchange/selecting of a country.
    $("#loadingStates").show();
    var stateId = $("#state_id").val();
    if(stateId!=0){
	    var params = "state_id=" + stateId;
	    var cities = document.getElementById('city_id');
	    $.ajax({
	        url: base_url+'helpers/country_helpers/get_cities_by_stateid',
	        dataType: "json",
	        data: params,
	        type: "POST",
	        success: function (responseText) {
	        	$("#city_id").html('');
	        	$("#city_id").append("<option value=''>-- Select City --</option>");
	            $.each(responseText, function (key, value) {
	                $('#city_id').append("<option value='"+value.city_id+"'>"+value.city_name+"</option>");
	            });
	        },
	        complete: function () {
	            $("#loadingStates").hide();
	        }
	    });
    }else{
    	$("#city_id").html('');
    	$("#city_id").append("<option value=''>-- Select City --</option>");
	}
}
//Grid Function Goes Here
var commonJQGridConfiguration = {
			 	datatype: "json",
			   	rowNum:10,
			   	rownumbers: true, 
			   	autowidth:true,
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",	
			   	resizable:true,   
			   	mtype: "POST",
			    viewrecords: true,
			    sortorder: "desc",
			   	rowList:paginationValues,
			    jsonReader: { repeatitems : false, id: "0" },
			   	multiselect: false
		};
		
function locationTab(){
	/*
	*jqgrid for Education table
	*/
	var kolId = $('#kolId').val();
	var locationGridConfiguration = {
			url: base_url+'kols/list_locations/'+ kolId,
			colNames: ['Id', '', '', 'Institution', 'Address', 'City','State', 'Postal Code', 'Address Type', '','','Action','created_by_full_name','client_id','data_type_indicator'],
		    colModel: [
		        {name: 'id', index: 'id', hidden: true},
		        {name: 'micro', resizable: true, width: 20, sortable: false},
		        {name: 'is_primary', index: 'is_primary', resizable: true, width: 20, sortable: false},
		        {name: 'org_name', index: 'org_name', resizable: true, width: 200},
		        {name: 'address', index: 'address', resizable: true, width: 200},
		        {name: 'city', index: 'city', resizable: false, width: 80},
		        {name: 'state', index: 'state', resizable: false, width: 80},
		        {name: 'postal_code', index: 'postal_code', resizable: true, width: 80},
		        {name: 'address_type', index: 'address_type', resizable: false, width: 100,hidden:true},
		        {name: 'created_by', index: 'created_by', hidden: true},
		        {name: 'is_primary_value', index: 'is_primary_value', hidden: true},
		        {name: 'act', resizable: true, width: 70, sortable: false},
		        {name:'created_by_full_name',index:'created_by_full_name', hidden:true},
		        {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
		    ],
		    pager: '#listLocationPage',
		   	sortname: 'date',
		    gridComplete: function () {
	            var ids =$("#LocationResultSet").jqGrid('getDataIDs');
	            for (var i = 0; i < ids.length; i++) {
	            	var primaryLable = '';
	                var actionLink = '';
	                var id = ids[i];
//	                console.log(id);
//	                var isAnalyst = grid.jqGrid('getCell',cl,'client_id');
//	                var createdByName = grid.jqGrid('getCell',cl,'created_by_full_name');
	                var rowData =$("#LocationResultSet").jqGrid('getRowData', id);
		    		var dataTypeIndicator =$("#LocationResultSet").jqGrid('getCell',id,'data_type_indicator');
		    		actionLink += data_type_indicator(dataTypeIndicator);	
			    		
	                var is_prime = '';
	                if(rowData.is_primary_value == 1){
	                	is_prime += "<span class='is_primary'></span>";
	                     $("#LocationResultSet").jqGrid('setRowData', id, {is_primary: is_prime});
	                }
	                actionLink += "<a onclick='editForm("+id+", \"location\");return false;'><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick='deleteLocation("+id+","+rowData.is_primary_value+");return false;'><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
	                $("#LocationResultSet").jqGrid('setRowData', id, {act: actionLink});
	                microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewLocationSnapshot('" + id + "'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Location Snapshot\"></a></div></label>";
	                $("#LocationResultSet").jqGrid('setRowData', id, {micro: microviewLink});
	            }
	            	$("#LocationResultSet").jqGrid('navGrid', 'hideCol', "id");
	        }, 	
		    editurl:"<?php echo base_url();?>kols/update_education_detail",		   
		    caption:"Locations"
			};

			$.extend(locationGridConfiguration, commonJQGridConfiguration);

			jQuery("#LocationResultSet").jqGrid(locationGridConfiguration);

			jQuery("#LocationResultSet").jqGrid('navGrid','#listLocationPage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#LocationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#LocationResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#LocationResultSet").jqGrid('navButtonAdd',"#listLocationPage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#LocationResultSet").jqGrid('navButtonAdd',"#listLocationPage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}
function deleteSelectedlocation(lcoationIds){
	jConfirm("Are you sure you want to delete selected Location?","Please confirm",function(r){
		if(r){
			$.ajax({
				url:'<?php echo base_url()?>kols/delete_selected_educations/'+eduIds,
				type:'post',
				dataType:"json",
				success:function(returnMsg){
					if(returnMsg.status)
						$('a[href="#educationTabId"]').trigger('click');
					}
			});
			}else{
					return false;
				}
	});
}

function phoneNumberTab(){
	/*
	*jqgrid for Phone Number table
	*/
	var kolId = $('#kolId').val();
	var phoneCount=0;
	
	var phoneNumberGridConfiguration = {
			url: base_url + 'kols/list_kol_details/phone/' + kolId,
			colNames: ['Id', 'Phone Type', 'Locations', 'Phone Number', 'Is Primary','','Action','created_by_full_name','client_id','data_type_indicator'],
			colModel:[
		   				{name:'id',index:'id', hidden:true, search:false,align:'left'},
		   				{name:'phone_type',index:'phone_type',search:true,align:'left'},
		   		   		{name:'name',index:'name',search:true,align:'left'},
		   		   		{name:'number',index:'number',search:true,align:'left'},
		   				{name:'is_primary',index:'is_primary',search:true,align:'center'},
		   				{name:'created_by', index: 'created_by', hidden: true},
//		   				{name:'eAllowed', index: 'eAllowed', hidden: true},
//		   	            {name:'dAllowed', index: 'dAllowed', hidden: true},
		   				{name:'act', resizable: true, width: 60, sortable: false},
		   				{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
		   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
		   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
		   		   	  ], 
		    pager: '#listPhoneNumberPage',
		   	sortname: 'date',
		    gridComplete: function () {
	               var ids = $("#PhoneNumberResultSet").jqGrid('getDataIDs');
	               for (var i = 0; i < ids.length; i++) {
	            	   var actionLink = '';
	                   var id = ids[i];
	                   var isAnalyst =$("#PhoneNumberResultSet").jqGrid('getCell',id,'client_id');
	                   var createdByName =$("#PhoneNumberResultSet").jqGrid('getCell',id,'created_by_full_name');
	                   var rowData =$("#PhoneNumberResultSet").jqGrid('getRowData', id);
                     	var dataTypeIndicator =$("#PhoneNumberResultSet").jqGrid('getCell',id,'data_type_indicator');
                     	actionLink += data_type_indicator(dataTypeIndicator);		    		
	                   var is_prime = '';
	                   if(rowData.is_primary == 'Yes'){
	                   	is_prime = 1;
	                   }
	                   actionLink += "<a onclick=\"editForm("+id+", \'phoneNum\');return false;\"><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick=\"addPhoneNumber('delete',"+id+","+is_prime+");return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
	                   $("#PhoneNumberResultSet").jqGrid('setRowData', id, {act: actionLink});
	                   phoneCount++;
	               }
	           },	   
		    caption:"Phone Numbers"
			};

			$.extend(phoneNumberGridConfiguration, commonJQGridConfiguration);

			jQuery("#PhoneNumberResultSet").jqGrid(phoneNumberGridConfiguration);

			jQuery("#PhoneNumberResultSet").jqGrid('navGrid','#listPhoneNumberPage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#PhoneNumberResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#PhoneNumberResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#PhoneNumberResultSet").jqGrid('navButtonAdd',"#listPhoneNumberPage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#PhoneNumberResultSet").jqGrid('navButtonAdd',"#listPhoneNumberPage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}

function staffTab(){
	/*
	*jqgrid for Staff table
	*/
	var kolId = $('#kolId').val();
	var staffGridConfiguration = {
			url: base_url + 'kols/list_kol_details/staff/' + kolId,
			colNames: ['Id', 'Title', 'Locations', 'Name','Email', 'Phone Type', 'Phone Number','','','', 'Action','created_by_full_name','client_id','data_type_indicator'],
	      	colModel:[
	      				{name:'id',index:'id', hidden:true, search:false,align:'left'},
	      				{name:'staff_title',index:'staff_title',search:true,align:'left'},
	      		   		{name:'loc_name',index:'loc_name',search:true,align:'left'},
	      		   		{name:'name',index:'name',search:true,align:'left'},
	      		   		{name:'email',index:'email',search:true,align:'left'},
	      		   		{name:'phone_type',index:'phone_type',search:true,align:'left'},
	      				{name:'phone_number',index:'phone_number',search:true,align:'left',width:'100'},
	      				{name:'created_by', index: 'created_by', hidden: true},
		   				{name:'eAllowed', index: 'eAllowed', hidden: true},
		   	            {name:'dAllowed', index: 'dAllowed', hidden: true},
		   	            {name:'act', resizable: true, width: 80, sortable: false},
		   	         	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
		   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
		   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
	      	], 
		    pager: '#listStaffPage',
		   	sortname: 'date',
		   	gridComplete: function () {
	              var ids =  $("#StaffResultSet").jqGrid('getDataIDs');
	              for (var i = 0; i < ids.length; i++) {
	            	  var actionLink = '';
	                   var id = ids[i];
	                   var isAnalyst = $("#StaffResultSet").jqGrid('getCell',id,'client_id');
	                   var createdByName = $("#StaffResultSet").jqGrid('getCell',id,'created_by_full_name');
	                   var rowData = $("#StaffResultSet").jqGrid('getRowData', id);
                     //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                     	var dataTypeIndicator =$("#StaffResultSet").jqGrid('getCell',id,'data_type_indicator');
                     	actionLink += data_type_indicator(dataTypeIndicator);	
                     	
                     actionLink += "<a onclick=\"addStaffs('edit',"+id+");return false;\"><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick=\"addStaffs('delete',"+id+");return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
                     $("#StaffResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	               }
	                 
	        },	   
	           caption:"Staff",
			};

			$.extend(staffGridConfiguration, commonJQGridConfiguration);

			jQuery("#StaffResultSet").jqGrid(staffGridConfiguration);

			jQuery("#StaffResultSet").jqGrid('navGrid','#listStaffPage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#StaffResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#StaffResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#StaffResultSet").jqGrid('navButtonAdd',"#listStaffPage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#StaffResultSet").jqGrid('navButtonAdd',"#listPhoneNumberPage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}

function emailTab(){
	/*
	*jqgrid for Staff table
	*/
	var kolId = $('#kolId').val();
	
	var emailGridConfiguration = {
			url: base_url + 'kols/list_kol_details/emails/' + kolId,
			colNames: ['Id', 'Email Type', 'Email', 'Is Primary','','Action','created_by_full_name','client_id','data_type_indicator'],
    		colModel:[
    				{name:'id',index:'id', hidden:true, search:false,align:'left'},
    				{name:'type',index:'type',search:true,align:'left'},
    		   		{name:'email',index:'email',search:true,align:'left'},
    				{name:'is_primary',index:'is_primary',search:true,align:'center'},
    				{name: 'created_by', index: 'created_by', hidden: true},
//	   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
//	   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
	   	        	{name: 'act', resizable: true, width: 60, sortable: false},
	   	        	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
	   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
    		   	  ], 
		    pager: '#listEmailPage',
		   	sortname: 'date',
		   	gridComplete: function () {
                var ids = $("#EmailResultSet").jqGrid('getDataIDs');
                for (var i = 0; i < ids.length; i++) {
                	 var actionLink = '';
	                   var id = ids[i];
                       var isAnalyst = $("#EmailResultSet").jqGrid('getCell',id,'client_id');
                       var createdByName = $("#EmailResultSet").jqGrid('getCell',id,'created_by_full_name');
                       var rowData =  $("#EmailResultSet").jqGrid('getRowData', id);
                     	var dataTypeIndicator =  $("#EmailResultSet").jqGrid('getCell',id,'data_type_indicator');
                     console.log(dataTypeIndicator);
                     	actionLink += data_type_indicator(dataTypeIndicator);		    		
	                   var is_prime = '';
	                   if(rowData.is_primary == 'Yes'){
	                   	is_prime = 1;
	                   }
	                   actionLink += "<a onclick=\"addEmails('edit',"+id+");return false;\"><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick=\"addEmails('delete',"+id+","+is_prime+");return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
	                   $("#EmailResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	                   emailCount++;
	               }
            },	   
            caption:"Emails"
			};

			$.extend(emailGridConfiguration, commonJQGridConfiguration);

			jQuery("#EmailResultSet").jqGrid(emailGridConfiguration);

			jQuery("#EmailResultSet").jqGrid('navGrid','#listEmailPage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#EmailResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#EmailResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#EmailResultSet").jqGrid('navButtonAdd',"#listStaffPage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#EmailResultSet").jqGrid('navButtonAdd',"#listEmailPage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}

function stateLicenseTab(){
	/*
	*jqgrid for Staff table
	*/
	var kolId = $('#kolId').val();
	
	var stateLicenseGridConfiguration = {
			url: base_url + 'kols/list_kol_details/statelicense/' + kolId,
			colNames: ['Id', 'License Number', 'State', 'Is Primary','','','','Action','created_by_full_name','client_id','data_type_indicator'],
    		colModel:[
    				{name:'id',index:'id',hidden:true, search:false,align:'left'},
    				{name:'state_license',index:'state_license',search:true,align:'left'},
    		   		{name:'state_name',index:'state_name',search:true,align:'left'},
    				{name:'is_primary',index:'is_primary',search:true,align:'center'},
    				{name:'created_by',index: 'created_by',hidden: true},
   					{name:'eAllowed',index: 'eAllowed', hidden: true},
   	            	{name:'dAllowed',index: 'dAllowed', hidden: true},
   	         		{name:'act',resizable: true, width: 60, sortable: false},
  	   	         	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
	   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
    		   	  ], 
		    pager: '#listStatelicensePage',
		   	sortname: 'date',
		   	gridComplete: function () {
                var ids = $("#StatelicenseResultSet").jqGrid('getDataIDs');
                for (var i = 0; i < ids.length; i++) {
                	var actionLink = '';
                   	var id = ids[i];
                    var isAnalyst = $("#StatelicenseResultSet").jqGrid('getCell',id,'client_id');
                    var createdByName = $("#StatelicenseResultSet").jqGrid('getCell',id,'created_by_full_name');
                    var rowData = $("#StatelicenseResultSet").jqGrid('getRowData', id);
                  if(isAnalyst != 1){                    
                 		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                  }else{
                  	var dataTypeIndicator = $("#StatelicenseResultSet").jqGrid('getCell',id,'data_type_indicator');
                  	actionLink += data_type_indicator(dataTypeIndicator);		    		
                  }
                   var is_prime = '';
                   if(rowData.is_primary == 'Yes'){
                   	is_prime = 1;
                   }
                   actionLink += "<a onclick=\"addLicenses('edit',"+id+");return false;\"><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick=\"addLicenses('delete',"+id+","+is_prime+");return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
                   $("#StatelicenseResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
               }
            },	   
		    caption:"State License"
			};

			$.extend(stateLicenseGridConfiguration, commonJQGridConfiguration);

			jQuery("#StatelicenseResultSet").jqGrid(stateLicenseGridConfiguration);

			jQuery("#StatelicenseResultSet").jqGrid('navGrid','#listStatelicensePage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#StatelicenseResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#StatelicenseResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#StatelicenseResultSet").jqGrid('navButtonAdd',"#listStatelicensePage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#StatelicenseResultSet").jqGrid('navButtonAdd',"#listStatelicensePage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}
function assignProfileTab(){
	/*
	*jqgrid for Staff table
	*/
	var kolId = $('#kolId').val();
	
	var assignProfileGridConfiguration = {
			url: base_url + 'kols/list_kol_details/assign/' + kolId,
			colNames: ['Id', 'Name','Email', 'Type','','Action','client_id','data_type_indicator'],
    		colModel:[
    				{name:'id',index:'id', hidden:true, search:false,align:'left'},
    				{name:'name',index:'name',search:true,align:'left'},
    		   		{name:'email',index:'email',search:true,align:'left'},
    		   		{name:'type',index:'type',search:true,align:'left'},
    		   		{name: 'created_by', index: 'created_by', hidden: true},
//	   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
//	   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
	   	        	{name: 'act', resizable: true, width: 60, sortable: false},
	   	        	{name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
    		   	  ], 
		    pager: '#listAssignProfilePage',
		   	sortname: 'date',
		    gridComplete: function () {
                var ids = jQuery("#JQBlistAssignResultSet").jqGrid('getDataIDs');
                for (var i = 0; i < ids.length; i++) {
	                   var primaryLable = '';
	                   var id = ids[i];
	                   var isAnalyst = jQuery("#AssignProfileResultSet").jqGrid('getCell',id,'client_id');
                       var createdByName = jQuery("#AssignProfileResultSet").jqGrid('getCell',id,'created_by');
	                   var rowData = jQuery("#AssignProfileResultSet").jqGrid('getRowData', id);
	                   var actionLink = '';
	                   if(isAnalyst != 1){                    
                   		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                        }else{
                        	var dataTypeIndicator = jQuery("#AssignProfileResultSet").jqGrid('getCell',id,'data_type_indicator');
                        	actionLink +=data_type_indicator(dataTypeIndicator);		    		
                        } 
	                   actionLink += "<a onclick=\"addAssign('edit','"+id+"');return false;\"><span class='glyphicon glyphicon-edit action_icons'></span></a><a onclick=\"addAssign('delete','"+id+"');return false;\"><span class='glyphicon glyphicon-remove-circle action_icons'></span></a>";
	                   jQuery("#AssignProfileResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	                   emailCount++;
	               }
            },	   
            caption:"Assign Profile",
			};

			$.extend(assignProfileGridConfiguration, commonJQGridConfiguration);

			jQuery("#AssignProfileResultSet").jqGrid(assignProfileGridConfiguration);

			jQuery("#AssignProfileResultSet").jqGrid('navGrid','#listAssignProfilePage',{edit:false,add:false,del:false,search:false,refresh:false});	

			//Toolbar search bar below the Table Headers
			jQuery("#AssignProfileResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			//jQuery("#t_EducationResultSet").height(25).jqGrid('filterGrid',"EducationResultSet",{gridModel:true,gridToolbar:true});
			jQuery("#AssignProfileResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		

			// Delete selected row(s)
			jQuery("#AssignProfileResultSet").jqGrid('navButtonAdd',"#listAssignProfilePage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
				onClickButton:function (){
					var selectedEdus	= $(this).getGridParam('selarrrow');
					if(selectedEdus.length>0){
						deleteSelectedEducations(selectedEdus);
					}else{
						jAlert('Please select atleast one Education');
					}
				}
			}); 
			//Toggle Toolbar Search 
			jQuery("#AssignProfileResultSet").jqGrid('navButtonAdd',"#listAssignProfilePage",{caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}
					
				} 
			});	    
	}	
//Function to toggle 
function loadSelectedTab(selected){
				var sel= $(selected).attr('aria-controls');
				switch(sel){
					case 'location': $("#genericGridContainer").html("");
							
							// Append the required div and table
							$("#genericGridContainer").html('<table id="LocationResultSet"></table><div id="listLocationPage"></div>');

							locationTab();
							break;
					
					case 'phone_number': 
							getAvailableLocations();
							$("#genericGridContainer").html("");
							// Append the required div and table
							$("#genericGridContainer").html('<table id="PhoneNumberResultSet"></table><div id="listPhoneNumberPage"></div>');
							
							phoneNumberTab();
							break;
					
					case 'staff': $("#genericGridContainer").html("");
							
							// Append the required div and table
							$("#genericGridContainer").html('<table id="StaffResultSet"></table><div id="listStaffPage"></div>');

							staffTab();
							break;
									
					case 'emailPanel': $("#genericGridContainer").html("");
							// Append the required div and table
							$("#genericGridContainer").html('<table id="EmailResultSet"></table><div id="listEmailPage"></div>');

							emailTab();
							break;	
					case 'state_license': $("#genericGridContainer").html("");
					
							// Append the required div and table
							$("#genericGridContainer").html('<table id="StatelicenseResultSet"></table><div id="listStatelicensePage"></div>');
		
							stateLicenseTab();
							break;
					case 'assign_profile': $("#genericGridContainer").html("");
					
							// Append the required div and table
							$("#genericGridContainer").html('<table id="AssignProfileResultSet"></table><div id="listAssignProfilePage"></div>');
		
							assignProfileTab();
							break;		
								
				}
			}

function getAvailableLocations(){
	var typeOption = '';
	var locationOption = '';
			$.ajax({
				url:'<?php echo base_url()?>kols/get_available_location/'+<?php echo $arrKol['vid']; ?>,
				type:'post',
				dataType:"json",
				success:function(returnMsg){
						$.each(returnMsg.arrPhoneType, function(index, value){
								typeOption += '<option value="'+index+'">'+value+'</option>'; 
							});
						$.each(returnMsg.arrLocations, function(index, value){
							locationOption += '<option value="'+index+'">'+value+'</option>'; 
						});		
						$("#phone_type").append(typeOption);
						$("#phone_location").append(locationOption);
					}
			});
}
//function to edit and delete rpt, form
function editForm(id, tabType){
	switch(tabType) {
    case 'location':
    	$('.formLocationType').html("Edit");
    	document.getElementById("saveKolLocationForm").reset();
    	$('#saveLocationInfo').val("Update");
    	$('#cancelLocationInfo').attr("onclick", "cancelInfo(true, 'location')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
        			if(data.is_primary == 1){
        				$('#is_primary').prop('checked', true);
            			}else{
            			$('#is_primary').prop('checked', false);
                		}
	    			$('#locationId').val(data.id);
	    			$('#org_institution_id').val(data.org_institution_id);
	    			$('#organizationLocation').val(data.private_practice);
	    			$('#org_typeLocation').val(data.orgTypeId);
	    			$('#department_loc').val(data.division);
	    			$('#title_loc').val(data.title);
	    			$('#address1').val(data.address1);
	    			$('#address2').val(data.address2);
	    			$('#country_id').val(data.country_id);
	    			//State Option
	    			var stateOption = '';
	    			$.each(data.arrStates, function(index, value){
	    					var stateSelected = '';
							if(index === data.state_id){
								stateSelected = 'selected';
								}
    						stateOption +='<option value="'+index+'" '+stateSelected+'>'+value+'</option>';
		    			});
	    			$('#state_id').html(stateOption);
	    			//State Option
	    			var cityOption = '';
	    			$.each(data.arrCities, function(index, value){
	    					var citySelected = '';
	    					if(index === data.city_id){
	    						citySelected = 'selected';
								}
	    					cityOption +='<option value="'+index+'" '+citySelected+'>'+value+'</option>';
		    			});
	    			$('#city_id').html(cityOption);
	    			$('#postal_code').val(data.postal_code);
    			}
    	});
        break;
    case 'phoneNum':
    	$('.formPhoneNumType').html("Edit");
    	document.getElementById("saveKolPhoneNumberForm").reset();
    	$('#savePhoneInfo').val("Update");
    	$('#cancelPhoneNumInfo').attr("onclick", "cancelInfo(true, 'phoneNum')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
    				$('#phoneNumId').val(data.id);
        			if(data.is_primary == 1){
        				$('#phone_is_primary').prop('checked', true);
            			}else{
            			$('#phone_is_primary').prop('checked', false);
                		}
	    			$('#phone_type').val(data.type);
	    			$('#phone_location').val(data.location_id);
	    			$('#saveKolPhoneNumberForm #phone_number').val(data.number);
    			}
    	});
    	break;
    case 'staff':
    	$('.formStaffType').html("Edit");
    	document.getElementById("saveKolStaffForm").reset();
    	$('#saveStaffInfo').val("Update");
    	$('#cancelStaffInfo').attr("onclick", "cancelInfo(true, 'staff')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
        		
    			}
    	});
        break;
    case 'email':
    	$('.formEmailType').html("Edit");
    	document.getElementById("saveKolEmailForm").reset();
    	$('#saveEmailInfo').val("Update");
    	$('#cancelEmailInfo').attr("onclick", "cancelInfo(true, 'email')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
        		
    			}
    	});
        break;
    case 'stateLicense':
    	$('.formStateLicenseType').html("Edit");
    	document.getElementById("saveKolStateLicenseForm").reset();
    	$('#saveStateLicenseInfo').val("Update");
    	$('#cancelStateLicenseInfo').attr("onclick", "cancelInfo(true, 'stateLicense')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
        		
    			}
    	});
        break;
    case 'userAssign':
    	$('.formUserAssignType').html("Edit");
    	document.getElementById("saveKolAssignClientForm").reset();
    	$('#saveUserAssignInfo').val("Update");
    	$('#cancelUserAssignInfo').attr("onclick", "cancelInfo(true, 'userAssign')");
    	$.ajax({
    		url:'<?php echo base_url()?>kols/update_details/'+id+'/'+tabType,
    		type:'post',
    		dataType:"json",
    		success:function(data){
        		
    			}
    	});
        break; 	
}

	
	
}
//function update button
function cancelInfo(type, tabType){
	switch(tabType) {
    case 'location':
	    	if(type == true){
				$('.formLocationType').html("Add");
				$('#saveLocationInfo').val("Add");	
				$('#cancelLocationInfo').attr("onclick", "cancelInfo(false, 'location')");
				document.getElementById("saveKolLocationForm").reset();
			}else{
				document.getElementById("saveKolLocationForm").reset();
			}
    	break;

    case 'phoneNum':
    	if(type == true){
			$('.formPhoneNumType').html("Add");
			$('#savePhoneInfo').val("Add");	
			$('#cancelPhoneNumInfo').attr("onclick", "cancelInfo(false, 'phoneNum')");
			document.getElementById("saveKolPhoneNumberForm").reset();
		}else{
			document.getElementById("saveKolPhoneNumberForm").reset();
		}
		break;	

    case 'staff':
    	if(type == true){
			$('.formStaffType').html("Add");
			$('#saveStaffInfo').val("Add");	
			$('#cancelStaffInfo').attr("onclick", "cancelInfo(false, 'staff')");
			document.getElementById("saveKolStaffForm").reset();
		}else{
			document.getElementById("saveKolStaffForm").reset();
		}
        break;
    case 'email':
    	if(type == true){
			$('.formEmailType').html("Add");
			$('#saveEmail').val("Add");	
			$('#cancelEmailInfo').attr("onclick", "cancelInfo(false, 'email')");
			document.getElementById("saveKolEmailForm").reset();
		}else{
			document.getElementById("saveKolEmailForm").reset();
		}
        break;
    case 'stateLicense':
    	if(type == true){
			$('.formStateLicenseType').html("Add");
			$('#saveStateLicenseInfo').val("Add");	
			$('#cancelStateLicenseInfo').attr("onclick", "cancelInfo(false, 'stateLicense')");
			document.getElementById("saveKolStateLicenseForm").reset();
		}else{
			document.getElementById("saveKolStateLicenseForm").reset();
		}
        break;
    case 'userAssign':
    	if(type == true){
			$('.formUserAssignType').html("Add");
			$('#saveUserAssignInfo').val("Add");	
			$('#cancelUserAssignInfo').attr("onclick", "cancelInfo(false, 'userAssign')");
			document.getElementById("saveKolAssignClientForm").reset();
		}else{
			document.getElementById("saveKolAssignClientForm").reset();
		}
        break; 	
		   
	}
}
</script>
<style>
.badge {
    display: inline-block;
    min-width: 10px;
    padding: 3px 7px;
    font-size: 12px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    background-color: #777;
    border-radius: 10px;
}
.action_icons {
    font-size: 16px;
    padding: 0px 5px;
}
</style>
<!-- Start of Html Content -->
<?php $this->load->view('kols/secondary_menu'); ?>
<div class="main-content">
	<div class="row">
		<div class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Details" class="active"><a href="#location" aria-controls="location" role="tab" data-toggle="tab">Locations</a></li>
                  <li role="Details"><a href="#phone_number" aria-controls="phone_number" role="tab" data-toggle="tab">Phone Numbers</a></li>
                  <li role="Details"><a href="#staff" aria-controls="staff" role="tab" data-toggle="tab">Staff</a></li>
                  <li role="Details"><a href="#emailPanel" aria-controls="emailPanel" role="tab" data-toggle="tab">Emails</a></li>
                  <li role="Details"><a href="#state_license" aria-controls="state_license" role="tab" data-toggle="tab">State License</a></li>
                  <li role="Details"><a href="#assign_profile" aria-controls="assign_profile" role="tab" data-toggle="tab">Assign Profile</a></li>
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               	<h5 style="font-weight:bold;color:#656565;">Profile of : Kols Name</h5>
	               </div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="location">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formLocationType">Add</span> Location Information</h3> </div> 
	                  			<div class="panel-body">
	                  				<form action="save_kol_location" method="post" id="saveKolLocationForm" name="saveKolLocationForm" class="validateForm form-horizontal">
	                  					<input type="hidden" name="type" value="location"></input>
										<input type="hidden" name="id" id="locationId" value=""></input>
										<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['vid']; ?>"></input>
	                  					<input type="hidden" name="org_inst_selected" value="">
										<input type="hidden" name="org_institution_id" value="">
										<input type="hidden" name="private_practice" value="1">
	                  					<div class="form-group" style="border-bottom: 1px solid #ccc; padding-bottom:10px;">
											<div class="col-md-12">
												<label class="control-label">Primary Address : </label>
												<input type="checkbox" name="is_primary" value="1" id="is_primary" style="vertical-align: middle;margin-top:0px;"></input>
											</div>
										</div>
	                  					<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Institution <span class="required">*</span> :</label>
												<input type="text" name="organization" value="" id="organizationLocation" class="form-control autocompleteInputBox" placeholder="Enter Organization" autocomplete="off">
											</div>
											<div class="col-md-2">
												<label class="control-label">Institution Type :</label>
												<select name="org_type" id="org_typeLocation" class="required form-control" onchange="changeAutoComplete();">
												<option value="" selected="selected">---Select---</option>
												<?php 
													foreach( $arrOrganizationTypes as $organizationTypeKey => $organizationTypeValue ){
															echo '<option value="'.$organizationTypeKey.'">'.$organizationTypeValue.'</option>';
													}
												?>
												</select>
											</div>
											<div class="col-md-2">
												<label class="control-label">Department :</label>
												<input type="text" name="department_loc" value="" id="department_loc" class="form-control"></input>
											</div>
											<div class="col-md-2">
												<label class="control-label">Position :</label>
												<select name="title_loc" id="title_loc" class="chosenMultipleSelect form-control">
												<option value="" selected="selected">---Select---</option>
												<?php 
													foreach( $arrTitles as $titleKey => $titleValue ){
															echo '<option value="'.$titleKey.'">'.$titleValue.'</option>';
													}
												?>
												</select>
											</div>
										</div>
										<div class="clearfix"></div>
										<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Address 1 <span class="required">*</span> :</label>
												<input type="text" name="address1" value="" id="address1" class="form-control required gray"></input>
											</div>
											<div class="col-md-6">
												<label class="control-label">Address 2 :</label>
														<input type="text" name="address2" value="" id="address2" class="form-control gray"></input>
											</div>
										</div>
										<div class="form-group">
										<div class="col-md-3">
											<label class="control-label">Country <span class="required">*</span> :</label>
											<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="form-control">
																<option value="">-- Select --</option>
																<?php 
																foreach( $arrCountry as $country){
																		echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
																}
																?>
															</select>
										</div>
										<div class="col-md-3">
											<label class="control-label">State <span class="required">*</span> :</label>
											<select name="state_id" id="state_id" onchange="getCitiesByStateId();" class="form-control">		
																<option value="">-- Select State --</option>
																<?php 
																foreach( $arrStates as $state){
																		echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
																}
																?>
											</select>
											<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
										</div>
										<div class="col-md-3">
											<label class="control-label">City <span class="required">*</span> :</label>
											<select name="city_id" id="city_id" class="form-control">
																<option value="">-- Select City --</option>
																<?php 
																foreach( $arrCities as $city){
																		echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
																}
																?>												
											</select>
											<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
										</div>
										<div class="col-md-3">
											<label class="control-label">Postal Code :</label>
											<input type="text" name="postal_code" value="" id="postal_code" class="form-control"></input>
										</div>
									</div>
									<div style="text-align: center;">
										<input type="button" value="Add" name="submit" id="saveLocationInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelLocationInfo" onclick="cancelInfo(false, 'location');" class="btn btn-primary pull-center"/>
										<!-- button type="button" class="btn btn-primary" name="submit" id="saveLocationInfo" onclick="save_location_form();return false;">Save</button> -->
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="phone_number">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formPhoneNumType">Add</span> Phone Number</h3> </div> 
	                  			<div class="panel-body">
	                  			<form action="saveKolPhoneNumberForm" method="post" id="saveKolPhoneNumberForm" name="saveKolPhoneNumberForm" class="form-horizontal validateForm">
	                  					
										<input type="hidden" name="id" id="phoneNumId" value="">
										<input type="hidden" name="contact" value="<?php echo $arrKol['vid']?>">
										<input type="hidden" name="contact_type" value="kol">
	                  					<div class="form-group" style="border-bottom: 1px solid #ccc; padding-bottom:10px;">
											<div class="col-md-12">
												<label class="control-label">Primary Address : </label>
												<input type="checkbox" name="phone_is_primary" value="on" id="phone_is_primary" class="" style="vertical-align: middle;margin-top:0px;">
											</div>
										</div>
										<div class="form-group">
										<div class="col-md-4">
											<label class="control-label">Type <span class="required">*</span> :</label>
											<select name="phone_type" id="phone_type" class="form-control required">
																<option value="">-- Select --</option>
															</select>
										</div>
										<div class="col-md-4">
											<label class="control-label">Location <span class="required">*</span> :</label>
											<select name="phone_location" id="phone_location" class="form-control">		
																<option value="">-- Select --</option>
											</select>
											</div>
										<div class="col-md-4">
											<label class="control-label">Phone Number :</label>
											<input type="text" name="phone_number" id="phone_number" class="form-control"></input>
										</div>
									</div>
									<div style="text-align: center;">
										<!--  button type="button" class="btn btn-primary" id="savePhoneInfo">Save</button  -->
										<input type="button" value="Add" name="submit" id="savePhoneInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelPhoneNumInfo" onclick="cancelInfo(false, 'phoneNum');" class="btn btn-primary pull-center"/>
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="staff">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formStaffType">Add</span> Staff Details</h3> </div> 
	                  			<div class="panel-body">
	                  				<form action="saveKolStaffForm" method="post" id="saveKolStaffForm" name="saveKolStaffForm" class="form-horizontal">
										<input type="hidden" name="id" id="staffId" value="">
										<input type="hidden" name="contact" value="<?php echo $arrKol['vid']?>">
										<input type="hidden" name="contact_type" value="kol">
										<div class="form-group">
											<div class="col-md-4">
												<label class="control-label">Title <span class="required">*</span> :</label>
												<select name="staff_title" id="staff_title" class="required form-control">
													<option value="1">Administrative Assistant</option>
													<option value="2">NP</option>
													<option value="3">Nurse</option>
													<option value="4">Office Manager</option>
													<option value="5">Physician's Assistant</option>
													<option value="6">Receptionist</option>
													<option value="7">Social Worker</option>
													<option value="8">Therapist</option>
													<option value="9">Other</option>
													<option value="10">Assistant</option>
													</select>
											</div>
											<div class="col-md-4">
												<label class="control-label">Name <span class="required">*</span> :</label>
												<input type="text" name="staff_name" value="" id="staff_name" class="required form-control">
												</div>
											<div class="col-md-4">
												<label class="control-label">Email :</label>
												<input type="text" name="email" value="" id="email" class="form-control">
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-4">
												<label class="control-label">Location <span class="required">*</span> :</label>
												<select name="staff_location" id="staff_location" class="form-control">
												<option value="848">Test</option>
												<option value="210">Baker IDI Heart and Diabetes Institute</option>
												</select>
											</div>
											<div class="col-md-4">
												<label class="control-label">Phone Type <span class="required">*</span> :</label>
												<select name="phone_type" id="phone_type" class="form-control">
												<option value="1">Answering Service</option>
												<option value="2">Cell</option>
												<option value="3">Face Time</option>
												<option value="4">Fax</option>
												<option value="5">Office Phone</option>
												<option value="6">Pager</option>
												<option value="7">Voice Mail</option>
												<option value="8">Web Address</option>
												<option value="9">Work</option>
												<option value="10">Others</option>
												<option value="11">Mobile</option>
												</select>
												</div>
											<div class="col-md-4">
												<label class="control-label">Phone Number :</label>
												<input type="text" name="staff_phone" value="" id="staff_phone" class="form-control">
											</div>
									</div>
									<div style="text-align: center;">
										<input type="button" value="Add" name="submit" id="saveStaffInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelStaffInfo" onclick="cancelInfo(false, 'staff');" class="btn btn-primary pull-center"/>
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>		
                  </div>
                  <div role="tabpanel" class="tab-pane" id="emailPanel">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formEmailType">Add</span> Emails</h3> </div> 
	                  			<div class="panel-body">
	                  			<form action="saveKolEmailForm" method="post" id="saveKolEmailForm" name="saveKolEmailForm" class="form-horizontal">
	                  					<input type="hidden" name="id" id="emailId" value="">
										<input type="hidden" name="contact" value="<?php echo $arrKol['vid']?>">
										<input type="hidden" name="contact_type" value="kol">
	                  					<div class="form-group" style="border-bottom: 1px solid #ccc; padding-bottom:10px;">
											<div class="col-md-12">
												<label class="control-label">Primary Address : </label>
												<input type="checkbox" name="email_is_primary" value="on" id="email_is_primary" class="" style="vertical-align: middle;margin-top:0px;"></input>
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Type<span class="required">*</span> :</label>
												<select name="email_type" id="email_type" class="required form-control valid" aria-invalid="false">
												<option value="Work">Work</option>
												<option value="Other">Other</option>
												</select>
											</div>
											<div class="col-md-6">
												<label class="control-label">Email<span class="required">*</span> :</label>
												<input type="text" name="email" value="" id="email" class="required form-control">
											</div>
										</div>
									<div style="text-align: center;">
										<input type="button" value="Add" name="submit" id="saveEmailInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelEmailInfo" onclick="cancelInfo(false, 'email');" class="btn btn-primary pull-center"/>
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="state_license">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formStateLicenseType">Add</span> State License Details</h3> </div> 
	                  			<div class="panel-body">
	                  			<form action="saveKolStateLicenseForm" method="post" id="saveKolStateLicenseForm" name="saveKolStateLicenseForm" class="form-horizontal">
	                  					<input type="hidden" name="id" id="stateLicenseId" value="">
										<input type="hidden" name="contact" value="<?php echo $arrKol['vid']?>">
	                  					<div class="form-group" style="border-bottom: 1px solid #ccc; padding-bottom:10px;">
											<div class="col-md-12">
												<label class="control-label">Primary Address : </label>
												<input type="checkbox" name="license_is_primary" value="on" id="license_is_primary" class=""  style="vertical-align: middle;margin-top:0px;">
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-4">
												<label class="control-label">Number <span class="required">*</span> :</label>
												<input type="text" name="state_license_number" value="" id="state_license_number" class="required form-control">
											</div>
											<div class="col-md-4">
												<label class="control-label">Country <span class="required">*</span> :</label>
												<select name="country_id" id="country_id_license" class="required form-control" onchange="getStatesByCountryIdLicense();">
													<option value="">---Select---</option>
													<?php
													foreach( $arrCountry as $country){
														echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
													}
													?>
													</select>
												</div>
											<div class="col-md-4">
												<label class="control-label">State :</label>
												<select name="state_id" id="state_id_license" class="required form-control">
												<option value="">---Select---</option>
												<?php 
												foreach( $arrStates as $state){
														echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
												}
												?>
</select>
											</div>
										</div>
									<div style="text-align: center;">
										<input type="button" value="Add" name="submit" id="saveStateLicenseInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelStateLicenseInfo" onclick="cancelInfo(false, 'stateLicense');" class="btn btn-primary pull-center"/>
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="assign_profile">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title"><span class="formUserAssignType">Add</span> Assign Profile</h3> </div> 
	                  			<div class="panel-body">
	                  				<form action="saveKolAssignClientForm" method="post" id="saveKolAssignClientForm" name="saveKolAssignClientForm" class="form-horizontal">
	                  					<input type="hidden" name="kol_id" value="<?php echo $arrKol['vid']?>">
										<input type="hidden" name="id" id="assignUserId">
	                  					<div class="form-group" style="border-bottom: 1px solid #ccc; padding-bottom:10px;">
											<div class="col-md-12">
												<label class="control-label">Primary Address : </label>
												<input type="checkbox" name="first_name" id="first_name" value="<?php echo $arrKol['first_name'];?>" onkeyup="makeFirstLetterCapltal(this.value,this)" style="vertical-align: middle;margin-top:0px;"></input>
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">User <span class="required">*</span> :</label>
												<select name="client" id="client" class="required form-control">
												<option value="" selected="selected">---Select---</option>
												<option value="232">Laxman K</option>
												</select>
											</div>
											<div class="col-md-6">
												<label class="control-label">Type <span class="required">*</span> :</label>
												<select name="client_type" id="client_type" class="required form-control">
													<option value="" selected="selected">---Select---</option>
													<option value="1">Primary</option>
													<option value="2">Secondary</option>
													<option value="3">Professional</option>
													</select>
												</div>
										</div>
									<div style="text-align: center;">
										<input type="button" value="Add" name="submit" id="saveUserAssignInfo" class="btn btn-primary pull-center"/>
										<input type="button" value="Cancel" name="cancel" id="cancelUserAssignInfo" onclick="cancelInfo(false, 'userAssign');" class="btn btn-primary pull-center"/>
									</div>
	                  				</form>
	                  			</div> 
	                  		</div>	
                  </div>
        <!-- End Tab panels -->   
        <!-- Generic Grid Panel to load all four respective grid content --> 
			<div class="col-md-12 gridData">
                  <div class="gridWrapper" id="genericGridContainer">
					<table id="LocationResultSet"></table>
					<div id="listLocationPage"></div>
				  </div>
            </div>
		<!-- End of Grid Panel -->    
               </div>     
        </div>
	</div>
</div>
<!-- End of Html Content -->