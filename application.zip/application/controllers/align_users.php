<?php
/**
 * Profiles (KOL or Organization) aligned/assigned to Users
 * @author Laxman K
 * @since KOLM CORE v6.0.6
 * @created on 23 DEC 2013
 * 
 */

class Align_users extends Controller{
	
	function Align_users(){
		parent::Controller();
			$this->load->model('Align_user');
                        $this->load->model('coaching');                        
	}
	function align_kols($kols=0){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->Align_user->listUsers($client_id);
		$data['arrKols']	= $kols;
		$this->load->view('align_users/align_kols',$data);
	}
	function save_kol_alignment(){
		$kolIds		= explode(',',$this->input->post('kol_id'));
		$arrUsers	= $this->input->post('users');
                $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_ADD,
                    'description' => 'Save Alignment',
                    'status' => 'success',
                    'transaction_id' => implode(",",$kolIds),
                    'transaction_table_id' => USER_KOLS,
                    'transaction_name' => "save_alignment",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUsers)
                );
                $this->config->set_item('log_details', $arrLogDetails);
                
                log_user_activity($arrLogDetails, true);
                $this->Align_user->saveKolAlignment($kolIds,$arrUsers);
	}
	function align_orgs($orgs=0){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->Align_user->listUsers($client_id);
              
		$data['arrOrgs']	= $orgs;
                
		$this->load->view('align_users/align_orgs',$data);
	}
	function save_org_alignment(){
		$orgIds		= explode(',',$this->input->post('org_id'));
		$arrUsers	= $this->input->post('users');
		$this->Align_user->saveOrgAlignment($orgIds,$arrUsers);
                $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_ADD,
                    'description' => 'Save Alignment',
                    'status' => 'success',
                    'transaction_id' => $this->input->post('org_id'),
                    'transaction_table_id' => USER_ORGS,
                    'transaction_name' => "save_alignment_org",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUsers)
                );
                $this->config->set_item('log_details', $arrLogDetails);
                
                log_user_activity($arrLogDetails, true);
	}
	
	function edit_align_users($kolId,$type){	    
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->Align_user->listUsers($client_id);
		$data['assignedUsers'] = $this->Align_user->getAssignedUsers($kolId);
		//pr($data);
		///$arrKols = array($kolId);
		$data['arrKols']	= $kolId;
		$data['type'] = $type;
		$this->load->view('align_users/align_kols_within_view',$data);
		
	}
	
	function save_kol_alignment_within_profile(){
		$kolId		= $this->input->post('kol_id');
		$kolIds		= array($kolId);
		$arrUsers	= $this->input->post('users');
		$role	= $this->session->userdata('user_role_id');
		
		$this->Align_user->deleteKolAlignment($kolIds,$arrUsers,$role);
		$this->Align_user->saveKolAlignment($kolIds,$arrUsers);
		$formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_ADD,
                    'description' => 'Save Alignment',
                    'status' => 'success',
                    'transaction_id' => implode(',',$kolIds),
                    'transaction_table_id' => USER_KOLS,
                    'transaction_name' => "save_alignment",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUsers)
                );
                $this->config->set_item('log_details', $arrLogDetails);

                log_user_activity($arrLogDetails, true);
		//echo '<label>Assigned To:</label>';
		$data['assignedUsers'] = $this->Align_user->getAssignedUsers($kolId);
		$data['kolId'] = $kolId;
		echo $this->load->view('align_users/users',$data);
		//echo $this->uri->segment(2);
		//redirect('')
	}
	
	function edit_org_align_users($orgId,$type){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->Align_user->listUsers($client_id);
		$data['assignedUsers'] = $this->Align_user->getAssignedOrgUsers($orgId);
		//pr($data);
		///$arrKols = array($kolId);
		$data['arrOrgs']	= $orgId;
		$data['type'] = $type;
		$this->load->view('align_users/align_orgs_within_profile',$data);
		
	}
	
	function save_org_alignment_within_profile(){
		$arrUsers	= $this->input->post('users');
		$orgIds		= explode(',',$this->input->post('org_id'));
		$role	= $this->session->userdata('user_role_id');
		$this->Align_user->deleteOrgAlignment($orgIds,$arrUsers,$role);
		$this->Align_user->saveOrgAlignment($orgIds,$arrUsers);
		
		$data['assignedUsers'] = $this->Align_user->getAssignedOrgUsers($orgIds[0]);
		$data['orgId'] = $orgIds[0];
                 $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_ADD,
                    'description' => 'Save Alignment',
                    'status' => 'success',
                    'transaction_id' => $this->input->post('org_id'),
                    'transaction_table_id' => USER_ORGS,
                    'transaction_name' => "save_alignment_org",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUsers)
                );
                $this->config->set_item('log_details', $arrLogDetails);
                
                log_user_activity($arrLogDetails, true);
		echo $this->load->view('align_users/org_users',$data);
		
	}
	function remove_kol_alignment(){
		$arrUserId   = array($this->session->userdata('user_id'));
		$kolIds		= explode(',',$this->input->post('kol_id'));
                $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_DELETE,
                    'description' => 'Delete Alignment',
                    'status' => 'success',
                    'transaction_id' => $this->input->post('kol_id'),
                    'transaction_table_id' => USER_KOLS,
                    'transaction_name' => "delete_alignment",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUserId)
                );
                $this->config->set_item('log_details', $arrLogDetails);

                log_user_activity($arrLogDetails, true);
		$this->Align_user->deleteKolAlignment($kolIds,$arrUserId);
	}
	function remove_org_alignment(){
		$arrUserId   = array($this->session->userdata('user_id'));
		$orgIds		= explode(',',$this->input->post('org_id'));
		$this->Align_user->deleteOrgAlignment($orgIds,$arrUserId);
                 $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'type' => LOG_DELETE,
                    'description' => 'Delete Alignment',
                    'status' => 'success',
                    'transaction_id' => $this->input->post('org_id'),
                    'transaction_table_id' => USER_ORGS,
                    'transaction_name' => "delete_alignment_org",
                    'form_data' => $formData,
                    'user_id' => implode(',', $arrUserId)
                );
                $this->config->set_item('log_details', $arrLogDetails);
                
                log_user_activity($arrLogDetails, true);
	}
        
        function export_as_email_alignment_changes() {
           
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $fromDate = date("Y-m-d 12:04:12", strtotime('monday last week'));
        $toDate = date("Y-m-d H:i:s", strtotime("sunday last week"));
//        kolNameById
        $this->db->select("client_users.first_name as mslF,client_users.last_name as mslL,log_activities.*", false);
        $this->db->join('client_users', 'client_users.id = log_activities.created_by', 'left');
//
        $this->db->where("log_activities.created_on >='" . $fromDate . "'");
        $this->db->where("log_activities.created_on <='" . $toDate . "'");
        $this->db->where("log_activities.transaction_name ='save_alignment' OR log_activities.transaction_name ='delete_alignment'");
        
        $arrResult = $this->db->get('log_activities');
        foreach ($arrResult->result_array() as $val) {
            $usernames=array();
            $val['kol_id']=$this->coaching->kolNameById(json_decode($val['form_data'])->kol_id);
            $users=explode(",",$val['user_id']);
            foreach($users as $user){
                $usernames[]=$this->common_helpers->getUserName($user);
            }
            $val['created_by']=$this->common_helpers->getUserName($val['created_by']);
            $val['created_on']=sql_date_to_app_date($val['created_on']);
            $val['usernames']=implode(',',$usernames);
            if($val['transaction_name']=='save_alignment')
                $val['alignment']="Aligned";
            else
                 $val['alignment']="Unaligned";
            $arrInteractions[] = $val;
        }
       
       
       //New Worksheet
         $fileName = 'Alignment Weekly Report';
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('MSL Weekly MIRF Report');
        //Add header
         $objWorksheet->setCellValue('A1', 'Date ')
                ->setCellValue('B1', 'Aligned / Unaligned')
                ->setCellValue('C1', 'From User ')
                ->setCellValue('D1', 'To Users')
                ->setCellValue('E1', 'Kols');
                
        $i = 2;;;
        foreach ($arrInteractions as $rows) {
          
            $objWorksheet->setCellValue('A' . $i, $rows['created_on'])
                    ->setCellValue('B' . $i, $rows['alignment'])
                    ->setCellValue('C' . $i, $rows['created_by'])
                    ->setCellValue('D' . $i, $rows['usernames'])
                    ->setCellValue('E' . $i, preg_replace('/<\/?a[^>]*>/', '', $rows['kol_id']));
                   
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);




        // remove first sheet

        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );

        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'F') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        
        $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
        $objWriter->save($path);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody='Hi  Tony , <br/><br/> Attached is the export of Alignment Weekly  Report from '.PRODUCT_NAME;
        //$loggedInUserEmail=$this->session->userdata('email');
//        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        
        $this->email->to("yuvarajm@aissel.com");
        $this->email->subject(PRODUCT_NAME.":Alignment Weekly Report");
        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
//           link($path);
            
        } else {
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
    }

}