<?php
/**
 * Side bar which includes secondary navigation links & ternary navigation etc
 *
 * @author: Laxman K
 * @Since: KOLM3.7
 * @created on: 31-03-12
 */
$mirfWithin=0;
$link = $_SERVER['HTTP_REFERER'];
    $link_array = explode('/',$link);
     $page = end($link_array);
     if($page=="interaction_report")
         $mirfWithin=1;
     
?>
<?php
$isUserAllowedForSalesReport	= $this->session->userdata('is_allowed_for_sales_report');
$isUserAllowedForHCPReport	= $this->session->userdata('is_allowed_for_hcp_report');
$optInOut = 1;
if(KOL_CONSENT){
    if($arrKol['opt_in_out_status'] == 4 || $arrKol['opt_in_out_status'] == 0){
        $optInOut = $optInOut;
    }else{
        $optInOut = 0;
    }
}
	$arrMenuVisibility	= array(
	                             'kols'			=> array(	'view'					=> $optInOut,
															'view_affiliations'		=> 1,
															'view_events'			=> 1,
															'view_publications'		=> 1,
															'view_clinical_trials'	=> 1,
															'view_social_media'		=> 1,
															'survey_form'			=> 1,
															'view_kol_interactions'	=> 1
														),
								'organizations'	=> array(	'view'					=> 1,
															'view_keypeople'		=> 1,
															'view_publications'		=> 1,
															'view_clinical_trials'	=> 1,
															'view_stats_facts'		=> 1,
															'view_sub_organizations'=> 1,
															'view_network_map' 		=> 1,
															'view_interactions'		=> 1,
															'view_events'			=> 1,
                                                                                                                        'add_org'=>0
															
														),
								'plannings'		=> array(	'show_plans'			=> 1,'view_plan'   =>1,'add_plans'=>1),
								'interactions'	=> array(	'list_interactions'		=> 1,
															'add_interaction'		=> 1,
															'edit_interaction'		=> 1,
                                                                                                                        'add_mirf'=>1,
                                                                                                                        'edit_mirf'=>1,
                                                                                                                        'list_mirf'=>1,
                                                                                                                        'view_mirf'=>1,
                                                                                                                        'view_micro_interaction'=>1,
																														'view_drilldown_list'=>1,			
															'view_numeric_report'	=> 1),
								'payments'		=> array(	'list_payments'			=> 1,'add_payment'=>1),
								'monthly_reports'=> array(	'list_monthly_events'	=> 0),
								'contracts'		=> array(	'show_contracts'		=> 1),
								'my_list_kols'	=> array(	'list_categories_and_names'	=> 1,
															'list_categories'		=> 1
														),
								'maps'			=> array(	'search_kols_map'		=> 1,
															'view_influence_map'	=> 1,
															'view_influence_map_ipad'	=> 1,
															'view_influence_map_org' => 1,
															'view_geo_map_org'		=> 1,
															'view_network_map'		=> 1,
															'view_geo_map'			=> 1,
														'view_influence_geo_map'	=> 1
														),
								'reports'		=> array(	'view_reports'			=> 1,
															'view_interaction_reports'	=> 1,
                                                                      'view_coaching_quarterly_reports'	=> 1,
                                                                    'view_engagement_reports'	=> 1,
                                                                    'msl_activity_report' => 1,
															'user_access_report' => 1,
                                                                    'customer_seen_report'=> 1,
                                                                    'institution_seen_report'=>1,
															 'view_coaching_reports'	=> 1,
                                                                    '                                                       view_coaching_quarterly_reports'	=> 1,
															'list_uoq' => 1,
															'list_speaker_evaluations' => 1,
															'medical_insight_reports' => 1
														),
								'calendars'		=> array(	'view_calendar'			=> 0),
								'coachings'		=> array(	'add_coaching'			=> 1,
															'list_coachings'		=> 1,
                                                                    'list_one_on_one_coaching'		=> 1,
															'edit_coaching'			=> 1,
															'view'					=> 1,
															'medical_insight'		=> 1,
															'compliance'			=> 1,
															'list_medical_insights'	=> 1,
															'view_medical_insight'	=> 1,
                                                                                                                        'edit_medical_insight'=>1,
															'list_compliance'		=> 1,
															'view_compliance'		=> 1,
                                                                                                                        'edit_compliance'               => 1
														),
								'customer_engagements'	=> array(	'add'	=> 1,
												'list_engagements'	=> 1
											),
								'surveys'		=> array(	'list_surveys'			=> 1,
															'add_survey'			=> 1,
															'list_active_surveys'	=> 1,
															'view'					=> 1,
															'edit_survey_data'		=> 1,
															'edit_survey'			=> 1,
															'survey_form'			=> 1,
															'view_reports'			=> 1,
															'report'				=> 1,
															'view_network_map'		=> 1,
														    'view_geo_map'			=> 1,
															'sales_report'			=> 1,
															'hcp_report'			=> 1
														),
            'identifications'		=> array(	'home'			=> 1,
																	'priority_settings' => 1
														),
								'speaker_evaluations' => array('list_surveys'=>1),
									'notifications'		=> array('notifications_home'=>0),					
							  'media_intel_extractions'       => array('get_kol_id'=>1)							
							);
							
	// Get the URI segment. Helps in setting the link as 'ACTIVE'
	$currentController	= $this->uri->segment(1);
	$currentMethod		= $this->uri->segment(2);
	$param				= $this->uri->segment(3);
	//Conditions data for Role based user
	$userRoleId 		=	$this->session->userdata('user_role_id');
	$hideSideBar		= 1;
        if($mirfWithin==1) {  
            if($arrMenuVisibility['interactions']['add_mirf']==1)
            $arrMenuVisibility['interactions']['add_mirf']=0;
             if($arrMenuVisibility['interactions']['view_mirf']==1)
            $arrMenuVisibility['interactions']['view_mirf']=0;
        }
	if(isset($arrMenuVisibility[$currentController][$currentMethod])){
		if($arrMenuVisibility[$currentController][$currentMethod]){
			$hideSideBar	= 0;
		}else{
			$hideSideBar	= 1;
		}
	}
        
	$isCustomerProfile	= 0;
	if($clientId!=INTERNAL_CLIENT_ID && ($arrKol['status']!=COMPLETED)){
		$isCustomerProfile = 1;
	}
?>
<style type="text/css">
	#sideBarWrapper{
		display:<?php echo ($hideSideBar)?'none':'block';?>;
		background-color: #fff;
/*		position: absolute;*/
		width: 158px;
	}
	#profileImage{
		background-color:#fff;
		margin-left: -3px;
		width: 126px;
		z-index: 948;
	}
	#sideBarShortCuts{
		background-color:#fff;
		margin-left: -5px;
		top:190px;
		top:290px;
		width: 128px;
		z-index: 1001;
	}
	#sideBarContents{
		background-color:#fff;
		margin-left: -6px;
		top:333px;
		width: 158px;
		z-index: 948;
		border:1px solid #BCBCBC;
		border-top:0px;
		border-bottom:0px;
		border-right-color: #D9DFEB;
		border-bottom-color: #D9DFEB;
	}
	#sideBarContents ul{
		list-style: none outside none;
		margin: 0;
		padding-left:0px;
	}
	#sideBarContents ul .treeview ul{
		margin-left: -16px;
	}
	#sideBarContents ul .treeview ul li, .treeview li{
		border: 0px !important;
		padding-bottom: 0px !important;
	}
	#sideBarContents ul .treeview ul li a{
		margin-top: 0px !important;
		padding-top: 0px !important;
		padding-left: 0px !important;
		height: auto !important;
	}
	#sideBarContents #secondaryNav ul li{
		clear:both;
	/*	border-bottom:1px solid;*/
	/*	background: url("<?php echo base_url();?>images/kolm-sprite-image.png") no-repeat scroll -2px -236px transparent;
	*/
		background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
		background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
		background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		margin-top:2px;
		border-color: #CCCCCC;
	    border-style: solid none;
	    border-width: 1px 0 1px 0;
	}
	#sideBarContents #secondaryNav ul li:hover{
/*		background-color: #4096ee;
		background-color: #77A4E4;
		background-color: #DDE7F5;
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -273px transparent;
*/		background: #DDE7F5;
		background: -moz-linear-gradient(top, #ffffff 0%, #77A4E4 100%);
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ffffff), color-stop(100%,#77A4E4));
		background: -webkit-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -o-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -ms-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: linear-gradient(to bottom, #ffffff 0%,#77A4E4 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#77A4E4',GradientType=0 );
	}
	#sideBarContents #secondaryNav ul li.active{
		padding-left: 0px;
	/*	background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -273px transparent;
	*/	background: #DDE7F5;
		background: -moz-linear-gradient(top, #ffffff 0%, #77A4E4 100%);
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ffffff), color-stop(100%,#77A4E4));
		background: -webkit-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -o-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -ms-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: linear-gradient(to bottom, #ffffff 0%,#77A4E4 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#77A4E4',GradientType=0 );
		
	}
	#sideBarContents #secondaryNav ul li.active a{
		color:#000;	
		font-weight: bold;
	}
	#sideBarContents #secondaryNav ul li.active .sprite_iconSet{
		/*float: right;*/
	}
	#sideBarContents #secondaryNav ul li .sprite_iconSet{
		margin-right: 5px;
	}
	#sideBarContents #secondaryNav ul li a{
		letter-spacing: 0px;
		font-size:11px;
    	display: block;
	    height: 20px;
	    padding-top: 3px;
	    text-decoration: none;
	    text-align: left;
	    color:#000;
	}
	#secondaryNav ul li+div.ternaryNavLinks{
		background:#fff;
		display:none;
		padding-top: 1px;
	}
	#secondaryNav ul li+div.ternaryNavLinks a{
		background-color:#ffffff;
		border:1px solid #C9D9EF;
		border:1px solid #ffffff;
		display: block;
		font-weight: normal;
		margin:0px 0 0 5px;
		padding-left: 0px;
		/*height: 15px !important;*/
		min-height: 23px;
		/*line-height: 11px;*/
		line-height: 23px;
		border-right:0px;
		font-size: 10px;
		clear: both;
		color:#000;
		text-decoration: none;
	}
	#secondaryNav ul li+div.ternaryNavLinks a div.sprite_iconSet{
		margin-top: 0px;
	}
	#sideBarContents #secondaryNav ul li .treeview{
		background: none !important;
	}
	#sideBarContents .treeview {
		background-color: #DDE7F5;
		background-color: #FFFSSFFF;
		margin-top: -1px !important;
		margin-left: 14px;
		
    }
	.treeview li{
		background: url("<?php echo base_url();?>images/treeview-default-line.gif") no-repeat scroll 0 0 transparent !important;
		margin-top:0px !important;
	}
	.treeview li.collapsable, .treeview li.expandable {
	    background-position: 0 -170px !important;
	}
	.treeview li.listName a {
	    margin-top: -3px !important;
	}
	.treeview li.last {
	    /*background-position: 0 -1759px !important;*/
		padding-top: 0px !important;
	}
	.treeview li.lastCollapsable{
	   background-image: url("<?php echo base_url();?>images/treeview-default.gif");
	}
	.treeview li.lastExpandable {
	    background-image: url("<?php echo base_url();?>images/treeview-default.gif") !important;
	}
	.treeview div.lastExpandable-hitarea {
		margin-top: 0;
	   	background: url("<?php echo base_url();?>images/treeview-default.gif") no-repeat scroll -32px -70px transparent !important;
	}
	.treeview div.lastCollapsable-hitarea{
	    background: url("<?php echo base_url();?>images/treeview-default.gif") no-repeat scroll -64px -25px transparent !important;
	    margin-top: 0;
	}
	.treeview li.lastCollapsable {
	    background-position: 0 -111px !important;
	}
	.treeview li.lastExpandable {
	    background-position: -32px -67px !important;
	}
/*	.treeview div.lastCollapsable-hitarea{
		margin-top: 4px;
	}
*/
	li.lastExpandable span.listBgColor, li.lastCollapsable span.listBgColor {
	    margin-top: -4px;
	}
	#listLeftBar {
    	margin-left: 6px;
    }
/*    .profileImage {
	    height: 120px;
	}
*/
	p.profileName{
		margin-bottom: 0px;
		font-weight: bold;
		text-align: center;
	}
    <?php 
    	if($currentController=='my_list_kols'){
    		//echo '#sideBarContents{width: 144px;}';
    	}
    ?>
    #secondaryNav li.active+div.ternaryNavLinks{
    	display:block;
    }
    <?php 
    /*
	if(($currentController == 'organizations') && ($currentMethod!='list_organizations_client_view')) : ?>
		#sideBarWrapper{
			margin-top: 35px;
		}
	<?php endif;
	*/
	?>
	#sideBarContents #secondaryNav ul li .sprite_iconSet {
	    margin-left: 3px;
	    margin-right: 3px;
	}
</style>
<script type="text/javascript">
	var hideSidebar = "<?php echo ($hideSideBar)?'1':'0';?>";
	function toggleContent(hideContent,showContent){
		$('#'+hideContent).hide('slow');
		$('#'+showContent).show('slow');
	}
	$(document).ready(function (){
		$("#contentWrapper.span-23").css("background-position","158px 50%");
		//jAlert($('#secondaryNav ul li.active').next().find('div.ternayActiveLink').parent().html());
		$('div.ternayActiveLink').parent().addClass('currentTernaryNav');
/*		$('div.ternaryNavLinks a').hover(function (){
				$(this).css('background-color','#DDE7F5');
				if($(this).attr('class')!='currentTernaryNav'){
					//$(this).css('margin-left','5px');
					$(this).animate({
					    paddingLeft: "15px"
					  }, 500 );
				}
			},function (){
				$(this).css('background-color','#ffffff');
				if($(this).attr('class')!='currentTernaryNav'){
					//$(this).css('margin-left','0px');
					$(this).animate({
						paddingLeft: "0px"
					  }, 500 );
				}
			});
*/
//		$('#secondaryNav ul li.active').next().find('div.ternaryNavLinks').slideDown('slow');
//		$('#secondaryNav ul li.active').next().find('#collapseExpandButton').toggleClass('expandSlider');
		$('#secondaryNav ul li.active').find('#collapseExpandButton').toggleClass('expandSlider');
		$('#secondaryNav ul li div.secondaryMenuItem div').click(function (){
			//jAlert($('#secondaryNav ul li').find('div.expandSlider').parent().html());
			$('#secondaryNav ul li').find('div.expandSlider').parent().parent().next().slideToggle();
			$('#secondaryNav ul li').find('div.expandSlider').toggleClass('expandSlider');
			$(this).parent().parent().next().slideToggle();
			$(this).toggleClass('expandSlider');
		});
		// Settings for the Add category Dialog Box
		var categoryAddOpts = {
				title: "Add Payment",
				modal: true,
				autoOpen: false,
				width: 510,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		$("#profileScoreChartContent").dialog(categoryAddOpts);
		
	});

	function showHistogramChart(id){
		$("#profileScoreChart").html("<div class='microViewLoading'>Loading...</div>");
		var specialtyId='<?php echo (!empty($arrKol['specialty']))?$arrKol['specialty']:"";?>';
		$("#profileScoreChartContent").dialog("open");
		$("#profileScoreChart").load(base_url+'profile_ratings/show_profile_score_chart/'+id+'/'+specialtyId);
		return false;
	}

	
</script>
<div id="sideBarWrapper">
  <?php
  if(isset($arrKol) && !empty($arrKol)){?>
	<div id="profileImage">
		<?php 
			if($arrKol['salutation'] != 0)
				$salutation	= $arrSalutations[$arrKol['salutation']];
			else
				$salutation = "";
			$firstName	= $arrKol[FIRST_ORDER];
			$middleName	= $arrKol[SECOND_ORDER];
			$lastName	= $arrKol[THIRD_ORDER];
			
			$fullName	= $firstName;
			if(!empty($middleName))
				$fullName	.= ' '. $middleName;
			if(!empty($lastName))
				$fullName	.= ' '. $lastName;
			
			if($arrKol['gender']=="Male"){
				$imgName="male_kol_profile.svg";
			}else if($arrKol['gender']=="Female"){
				$imgName="female_kol_profile.svg";
			}else{
				$imgName="ipad/user.svg";
			}
		?>
		<div id="kolShortDetails">
			<p class="profileName"><?php echo $salutation . ' ' .$this->common_helpers->get_name_format($firstName,$middleName,$lastName);//$fullName ?></p>
			<div class="profileImage">
				<?php 
					if($arrKol['profile_image'] != ''){
						echo '<img alt="Image"  src="'. base_url(). 'images/kol_images/resized/'. $arrKol['profile_image'].'"/>';
					}else{?>
							<img alt="Image" width="100" src="<?php echo base_url();?>images/<?php echo $imgName;?>" />
						<?php 
					}
				?>
			</div>
			<div class="fiveStars tooltip-demo tooltop-right">
				<?php 
					if(isset($kolsPforfileScore) && isset($kolsPforfileScore)){
				?>
						<div class="progress" id="profileScoreForHint">
							<div class="profileScore bar" style="width: <?php echo round($kolsPforfileScore)."%";?>">
								<a style="display:inline !important;" onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Profile Score : <?php echo round($kolsPforfileScore);?>%">
									<img height="18" src="<?php echo base_url();?>images/five_stars.png" alt="Profile Score : <?php echo round($kolsPforfileScore);?>%" onclick="showHistogramChart(<?php echo $arrKol['id']?>)"/>
								</a>
							</div>
						</div>
				<?php 
					}
				?> 
				<?php 
					if(isset($asmtPercentageScore) && ASSESSMENT_STATUS){
				?>
						<div class="progress">
							<div class="asmtScore bar" style="width: <?php echo round($asmtPercentageScore);?>%;">
								<a style="cursor: default;display:inline;" onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Assessment Score : <?php echo round($asmtPercentageScore)."%";?>">
									<img height="18" alt="Assessment Score"  src="<?php echo base_url();?>images/five_stars.png" />
								</a>
							</div>
						</div>
				<?php 
					}
				?> 
			</div>
			<div style="text-align: center;">
				<?php 
				if($arrKol['profile_type']!='Full Profile' && ($arrKol['imported_as']>0)){
				    $profilType = DISCOVERY;
				}else{
					if($arrKol['profile_type']=='Full Profile'){
						$profilType = 'Full';
					}elseif($arrKol['profile_type']=='Market Access'){
						$profilType = 'Market Access';
					}elseif($arrKol['profile_type']=='Basic Plus'){
						$profilType = 'Basic +';
					}elseif($arrKol['profile_type']=='Basic'){
						$profilType = 'Basic';
					}elseif($arrKol['profile_type']=='User Added'){
						$profilType = 'User Added';
					}elseif($arrKol['profile_type']=='Legacy'){
						$profilType = 'Legacy';
					}
				}
					//echo '<p style="margin-bottom:0px">Profile Type: '.$profilType.'</p>';
					echo '<p style="margin-bottom:0px">'.$profilType.' Profile</p>';
				?>
			</div>
		</div>
	</div>
  <?php }else if(isset($arrOrganization) && !empty($arrOrganization)){
		if($arrOrganization['type_id'] != 0)
			$organizationType	= $arrOrganizationTypes[$arrOrganization['type_id']];
		else
			$organizationType = "";
		
	?>
	<style>
	.profileImage {
		height: auto;
	}
	</style>
	<div id="profileImage">
		<div id="organizationShortDetails">
			<p class="profileName">
				<?php echo $arrOrganization['name']; ?> <br />
				<?php echo $organizationType; ?>
			</p>
			<div class="profileImage">
				<?php 
					if($arrOrganization['company_logo'] != ''){
						if(strpos($arrOrganization['company_logo'], ":")!=false) {
							echo '<img alt="Image" width=120" src="'. $arrOrganization['company_logo'].'"/>';
						}else{
						echo '<img alt="Image" width=120" src="'. base_url(). 'images/organization_images/resized/'. $arrOrganization['company_logo'].'"/>';
						}
					}else{?>
						<img alt="Image" src="<?php echo base_url()?>images/organisation_inactive.svg" width="120px" />
						<?php 
					}
				?>
			</div>
			<div style="text-align: center;">
				<p style="margin-bottom:0px">
				<?php if($arrOrganization['profile_type'] == FULL){
					echo 'Full';
				 }else{
				 	echo 'Basic';
				 }?> Profile
				</p>
			</div>
		</div>
	</div>
  <?php 
  	}else{
  ?>
  			<style type="text/css">
  				#sideBarContents{
					top:150px;
				}
  			</style>
  <?php 
  	}
  ?>

	<div id="sideBarContents">
		<div id="secondaryNav">
			<ul>
				<?php 
					// If the 'View KOL' is the action
					if((($currentController == 'kols') && 
						($currentMethod != 'search_kols') && 
						($currentMethod != 'view_kol_adv_search') &&
						($currentMethod != 'adv_search_kols') &&
						($currentMethod != 'search_events') &&
						($currentMethod != 'view_event_adv_search') &&
						($currentMethod != 'adv_search_events') &&
						($currentMethod != 'client_index') &&
						($currentMethod != 'list_kols_client_view') &&
						($currentMethod != 'adv_search') &&
						($currentMethod != 'import_kol_profiles')) || (($currentController == 'interactions') && ($currentMethod == 'add_interaction' || $currentMethod == 'edit_interaction'))): ?>
					
						
							<li <?php if(($currentMethod == 'view') && !($subContentPage=='interaction_report' || $subContentPage=='add_payment' || $subContentPage=='edit_payment' || $subContentPage=='payments' || $subContentPage=='interaction' || $subContentPage=='add_interaction' || $subContentPage=='view_interaction' || $subContentPage=='list_medical_insights' || $subContentPage=='view_medical_insight' ||  $subContentPage=='list_speaker_evaluation' || $subContentPage=='medical_insight' || $subContentPage=='edit_medical_insight' || $subContentPage=='show_contracts')) echo 'class="active"';?>>
								<div class="navLinkOverview sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>" class="biographyLink"><?php echo lang('Mykols.Overview')?></a>
									<div id="collapseExpandButton" class="collapseSlider"><a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse <?php echo lang("KOL");?> overview">&nbsp;</a></div>
								</div>
							</li>
								<div class="ternaryNavLinks">
									<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/bio"><div class="terBio <?php echo ($subContentPage=='' || $subContentPage=='bio')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Biography');?></a>
									<a id="detailsForHint" href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/details"><div class="terDetails <?php echo ($subContentPage=='details')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Details');?></a>
									<?php if(!$isCustomerProfile){?>
									<a id="dashboardForHint" href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/dashboard"><div class="terDash <?php echo ($subContentPage=='dashboard')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Dashboard');?></a>
									<!--  <a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['id']?>/personalinfo"><div class="<?php echo ($subContentPage=='personalinfo')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.PersonalInfo');?></a>-->
									<?php if(ASSESSMENT_STATUS){ ?> 
									<a id="assessmentScoreForHint" href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/assessment"><div class="terAsses <?php echo ($subContentPage=='assessment')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Assessment');?></a>
									<?php  } ?>
									<!--	<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['id']?>/interaction" id="interactionType"><div class="<?php echo ($subContentPage=='interaction' || $subContentPage=='add_interaction' || $subContentPage=='view_interaction')?'ternayActiveLink':'interaction';?> sprite_iconSet"></div>Interactions</a>                  
									 	<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['id']?>/payments" id="payementType"><div class="<?php echo ($subContentPage=='payments')?'ternayActiveLink':'payment';?> sprite_iconSet"></div>Payments</a>
									 -->
								 	<?php }?>
								</div>
							<li <?php if((($currentMethod == 'view') && ($subContentPage=='interaction_report' || $subContentPage=='payments' || $subContentPage=='add_payment' || $subContentPage=='edit_payment' || $subContentPage=='show_contracts' || $subContentPage=='interaction' || $subContentPage=='add_interaction' || $subContentPage=='view_interaction' || $subContentPage=='list_medical_insights' || $subContentPage=='view_medical_insight' ||  $subContentPage=='list_speaker_evaluation' || $subContentPage=='medical_insight')) || $subContentPage=='edit_medical_insight' || ($currentMethod == 'view_kol_interactions') || ($currentMethod == 'add_mirf')) echo 'class="active"';?>>
								<div class="navLinkTrack sprite_iconSet" style="margin-top:-1px;"></div>
								<div class="secondaryMenuItem" <?php if((isset($arrKol) && $arrKol['imported_as']==1)){?>onclick="is_id_profile();return false;" <?php }?>>
									<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/interaction_report"><?php echo lang('Track')?></a>
									<?php if((isset($arrKol) && $arrKol['imported_as']!=1)){?>
									<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse Track">&nbsp;</a></div>
									<?php } ?>
								</div>
							</li>
								<div class="ternaryNavLinks">
								<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/interaction_report"><div class="terInter <?php echo ($subContentPage=='interaction_report')?'ternayActiveLink':'interaction';?> sprite_iconSet"></div><?php echo lang('Mykols.Interactions');?></a>
								<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/payments" id="payementType"><div class="terPayments <?php echo ($subContentPage=='payments' || $subContentPage=='add_payment' || $subContentPage=='edit_payment')?'ternayActiveLink':'payment';?> sprite_iconSet"></div><?php echo lang('Mykols.Payments');?></a>
								<a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['unique_id']?>/show_contracts" id="conratctType"><div class="terContracts <?php echo ($subContentPage=='show_contracts')?'ternayActiveLink':'contract';?> sprite_iconSet"></div><?php echo lang('Mykols.Contracts');?></a> 
									
                                                                       <?php if($currentMethod == 'list_medical_insights' || $currentMethod == 'view_medical_insight' ) echo 'class="active"';?>
<!--                                                                        <a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['id']?>/list_medical_insights"><div class="terMedical <?php echo ($subContentPage=='list_medical_insights' || $subContentPage=='medical_insight' || $subContentPage=='edit_medical_insight')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Track.MedicalInsight');?></a>
                                                                         <a href="<?php echo base_url()?>kols/view/<?php echo $arrKol['id']?>/list_speaker_evaluation"><div class="terSpeakerEval <?php echo ($subContentPage=='list_speaker_evaluation')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Speaker Evaluation</a>-->
								</div>

						
						<?php //if($arrKol['profile_type']=='Full Profile' && !$isCustomerProfile){?>
							<li <?php if($currentMethod == 'view_affiliations') echo 'class="active"';?>>
								<div class="navLinkAffiliation sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>" class="affiliationsLink"><?php echo lang('Mykols.Affiliations')?></a>
									<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
								</div>
							</li>
								<div class="ternaryNavLinks">
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/all"><div class="terAffAll <?php echo ($subContentPage=='' || $subContentPage=='all')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('all');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/university"><div class="terAffUniv <?php echo ($subContentPage=='university')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.UnivHospital');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/associations"><div class="terAffAsso <?php echo ($subContentPage=='associations')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Associations');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/industry"><div class="terAffIndus <?php echo ($subContentPage=='industry')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Industry');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/govt_agency"><div class="terAffGovt <?php echo ($subContentPage=='govt_agency')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.GovtAgency');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/others"><div class="terAffOthers <?php echo ($subContentPage=='others')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Others');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/reports_org"><div class="terAffReportOrg <?php echo ($subContentPage=='reports_org')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.ReportsOrg');?></a>
									<a href="<?php echo base_url()?>kols/view_affiliations/<?php echo $arrKol['unique_id']?>/reports_eng"><div class="terAffReportEng <?php echo ($subContentPage=='reports_eng')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.ReportsEng');?></a>
								</div>
							
						<?php //}?>
						
						<?php //if($arrKol['profile_type']=='Full Profile' && !$isCustomerProfile){?>
							<li <?php if($currentMethod == 'view_events') echo 'class="active"';?>>
								<div class="navLinkEvents sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['unique_id']?>" class="eventsLink"><?php echo lang('Mykols.Events')?></a>
									<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse events">&nbsp;</a></div>
								</div>
							</li>
								<div class="ternaryNavLinks">
									<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['unique_id']?>/conference"><div class="EventsAll <?php echo ($subContentPage=='' || $subContentPage=='conference')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('all');?></a>
								
								<!-- as per the Client requirement  we are hiding the links,later if clients tells to show that time we can remove the Comment to show links  -->
								<!--  	<div class="<?php echo ($subContentPage=='online')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['id']?>/online">Online</a>
									<div class="<?php echo ($subContentPage=='event_type')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['id']?>/event_type">Event Type</a>-->
									<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['unique_id']?>/session_type"><div class="EventsChart <?php echo ($subContentPage=='session_type')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php //echo lang('Mykols.SessionType');?>Events Charts</a>
									<!--<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['id']?>/topics"><div class="<?php echo ($subContentPage=='topics')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Topics');?></a>
									<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['id']?>/role"><div class="<?php echo ($subContentPage=='role')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Role');?></a>
								<a href="<?php echo base_url()?>kols/view_events/<?php echo $arrKol['id']?>/map"><div class="<?php echo ($subContentPage=='map')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div>Geo Map</a>-->
								</div>
							<?php //}?>
						<?php //if(($arrKol['profile_type']=='Full Profile' || $arrKol['profile_type']=='Basic Plus')&& !$isCustomerProfile){?>
								<li <?php if($currentMethod == 'view_publications') echo 'class="active"';?>>
									<div class="navLinkPublications sprite_iconSet"></div>
									<div class="secondaryMenuItem">
										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/search" class="pubsLink"><?php echo lang('Mykols.Publications')?></a>
										<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse publications">&nbsp;</a></div>
									</div>
								</li>
									<div class="ternaryNavLinks">
										
										
										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/search"><div class="pubsAll <?php echo ($subContentPage=='' || $subContentPage=='search')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('all');?></a>
										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/reports"><div class="pubsChart <?php echo ($subContentPage=='reports')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php //echo lang('Mykols.PubsbyTime');?>Pubs Charts</a>
<!--//										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/co_authors"><div class="<?php echo ($subContentPage=='co_authors')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Coauthors');?></a>-->
<!--//										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/auth_position"><div class="<?php echo ($subContentPage=='auth_position')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.AuthPosition');?></a>-->
<!--//										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/keywords"><div class="<?php echo ($subContentPage=='keywords')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Keywords');?></a>-->
<!--//										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/substances"><div class="<?php echo ($subContentPage=='substances')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Substances');?></a>-->
<!--//										<a href="<?php echo base_url()?>kols/view_publications/<?php echo $arrKol['unique_id']?>/journals"><div class="<?php echo ($subContentPage=='journals')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Journals');?></a>-->
									</div>
						<?php if(HIDE_CLINICAL_TRIALS){?>	
						<li <?php if($currentMethod == 'view_clinical_trials') echo 'class="active"';?>>
							<div class="navLinkTrials sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>kols/view_clinical_trials/<?php echo $arrKol['unique_id']?>/all" class="trialsLink"><?php echo lang('Mykols.Clinicaltrials')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse clinical trials">&nbsp;</a></div>
							--></div>
							<!--<div class="ternaryNavLinks">
								<div class="<?php echo ($subContentPage=='' || $subContentPage=='all')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>kols/view_clinical_trials/<?php echo $arrKol['id']?>/all">All</a>
							</div>
						--></li>
						<?php } ?>
						<?php //}?>
						<?php // if($arrKol['profile_type']=='Full Profile' && !$isCustomerProfile){?>
						<?php if(!HIDE_CLINICAL_TRIALS){?>
							 <li <?php if($currentMethod == 'view_social_media') echo 'class="active"';?>>
								<div class="navLinkMedia sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>kols/view_social_media/<?php echo $arrKol['unique_id']?>/social_media" class="mediaLink"><?php echo lang('Mykols.SocialMedia')?></a>
									<!-- <div id="collapseExpandButton" class="collapseSlider"><a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse social media">&nbsp;</a></div>
								 --></div>
								<!-- <div class="ternaryNavLinks">
									<div class="<?php echo ($subContentPage=='' || $subContentPage=='social_media')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>kols/view_social_media/<?php echo $arrKol['id']?>/social_media">Social Media</a>
								--></div>
							</li> 
						<?php }?>
						<?php //}?>
					<?php 
					endif;
	
					// If the 'View Organization' is the action
					if(($currentController == 'organizations') && 
						($currentMethod != 'search_organizations') &&
						($currentMethod != 'list_organizations_client_view')&&
						($currentMethod != 'import_org_profiles_xls')): ?>
						<li <?php if($currentMethod == 'view' && $subContentPage!='show_contracts') echo 'class="active"';?>>
							<div class="navLinkOverview sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>" class="orgOverviewLink"><?php echo lang('Org.Overview')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse Organization overview">&nbsp;</a></div>
							</div>
						</li>
							<div class="ternaryNavLinks">
								<a href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>/about"><div class="terOrgAbout <?php echo ($subContentPage=='' || $subContentPage=='about')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang("Org.About");?></a>
								<!-- <a href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>/details"><div class="terDetails <?php echo ($subContentPage=='details')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Details</a> -->
								<?php if($arrOrganization['profile_type'] != BASIC){ ?>
								<!--<div class="<?php echo ($subContentPage=='key_people')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>/key_people">Key People</a>
								<a id="socialMediaForHint" href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>/social_media"><div class="terOrgSocial <?php echo ($subContentPage=='social_media')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang("Org.SocialMedia");?></a>-->
								<?php }?>
								</div>
						<?php 
						//if($arrOrganization['profile_type'] != BASIC){ ?>
						<li <?php if($currentMethod == 'view_keypeople') echo 'class="active"';?>>
							<div class="keyPeople  sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a id="organizationKeypeopleForHint" href="<?php echo base_url()?>organizations/view_keypeople/<?php echo $arrOrganization['id']?>" class="orgOverviewLink"><?php echo lang("Organizations.KeyPeople");?></a>
							</div>
						</li>
						
						<?php //}?>
						
						<li <?php if((($currentMethod == 'view') && ($subContentPage=='show_contracts' || $subContentPage=='interaction_report' || $subContentPage=='payments' || $subContentPage=='interaction' || $subContentPage=='add_interaction' || $subContentPage=='view_interaction' || $subContentPage=='list_medical_insights' || $subContentPage=='view_medical_insight')) || ($currentMethod == 'view_interactions')) echo 'class="active"';?>>
							<div class="navLinkTrack sprite_iconSet" style="margin-top:-1px;"></div>
							<div class="secondaryMenuItem">
								<!--  --><a href="<?php echo base_url()?>organizations/view_interactions/<?php echo $arrOrganization['id']?>/interaction"><?php echo lang('Track')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse track">&nbsp;</a></div>
							</div>
						</li>
						<div class="ternaryNavLinks">
							<!--<a href="<?php echo base_url()?>organizations/view_interactions/<?php echo $arrOrganization['id']?>/interaction" id="interactionType"><div class="<?php echo ($currentMethod=='view_kol_interactions')?'ternayActiveLink':'interaction';?> sprite_iconSet"></div><?php echo lang('Mykols.Interactions');?></a>-->         
                                <a href="<?php echo base_url()?>organizations/view_interactions/<?php echo $arrOrganization['id']?>/interaction_report" id="interactionType"><div class="terInter <?php echo ($currentMethod=='view_interactions')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Mykols.Interactions');?></a>
                                <?php if(ORGS_CONTRACT){?>
                                <a href="<?php echo base_url()?>organizations/view/<?php echo $arrOrganization['id']?>/show_contracts" id="conratctType"><div class="terContracts <?php echo ($subContentPage=='show_contracts')?'ternayActiveLink':'contract';?> sprite_iconSet"></div><?php echo lang('Mykols.Contracts');?></a>
                                <?php }?>                  
						</div>
						
					<?php 
						//if($arrOrganization['profile_type'] != BASIC){ ?>
						<?php 							
							if($arrOrganization['type_id']!=PAYOR){/*	?>
						<li <?php if($currentMethod == 'view_events') echo 'class="active"';?>>
							<div class="navLinkEvents  sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a id="organizationPublicationsForHint" href="<?php echo base_url()?>organizations/view_events/<?php echo $arrOrganization['id']?>" class="orgOverviewLink"><?php echo lang("Mykols.Events");?></a>
							</div>
						</li>
						<li <?php if($currentMethod == 'view_publications') echo 'class="active"';?>>
							<div class="navLinkPublications  sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a id="organizationPublicationsForHint" href="<?php echo base_url()?>organizations/view_publications/<?php echo $arrOrganization['id']?>" class="orgOverviewLink"><?php echo lang("Organizations.Publications");?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse Organization Publication">&nbsp;</a></div>
							</div>
						</li>
							<div class="ternaryNavLinks">
								<a href="<?php echo base_url()?>organizations/view_publications/<?php echo $arrOrganization['id']?>"><div class="pubsAll <?php echo ($subContentPage=='')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('all');?></a>
								<a href="<?php echo base_url()?>organizations/view_publications/<?php echo $arrOrganization['id']?>/reports"><div class="pubsChart <?php echo ($subContentPage=='reports')?'ternayActiveLink':'reportIcon';?> sprite_iconSet"></div>Pubs Chart</a>
							</div>
							
						<li <?php if($currentMethod == 'view_clinical_trials') echo 'class="active"';?>>
							<div class="navLinkTrials sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a id="organizationTrialsForHint" href="<?php echo base_url()?>organizations/view_clinical_trials/<?php echo $arrOrganization['id']?>" class="orgOverviewLink"><?php echo lang("Organizations.ClinicalTrials");?></a>
							
							</div>
						</li><?php */?>
						<li <?php if($currentMethod == 'view_sub_organizations') echo 'class="active"';?>>
							<div class="navLinkAffiliation sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>organizations/view_sub_organizations/<?php echo $arrOrganization['id']?>/all" class="orgPartnersLink">Affiliate Orgs</a>
							</div>
						</li>
						<?php }?>
						<li <?php if($currentMethod == 'view_network_map') echo 'class="active"';?>>
							<div class="orgNetMap influenceMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a id="organizationNetworkMapForHint" href="<?php echo base_url()?>organizations/view_network_map/<?php echo $arrOrganization['id']?>" class="orgPartnersLink"><?php echo lang("Organizations.OrgNetwork");?></a>
							</div>
						</li>
							<?php //}?>
					<?php 
					endif;
				?>
				<?php 
					
					// If the 'View Payments' is the action
					if(($currentController == 'speaker_evaluations' || $currentController == 'payments' || $currentController == 'interactions' || $currentController == 'plannings' || $currentController == 'monthly_reports' || $currentController == 'contracts' || $currentController == 'coachings' || $currentController == 'customer_engagements')  
						): ?>
						 <li <?php if($currentMethod == 'show_plans' || $currentMethod == 'add_plans' || $currentMethod == 'view_plan') echo 'class="active"';?>>
							<div class="planning sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>plannings/show_plans/objectives" class="planningLink"><?php echo lang('Track.Planning')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse Plan">&nbsp;</a></div>
							</div>
						</li>
						<div class="ternaryNavLinks">
						 <a href="<?php echo base_url()?>plannings/show_plans/objectives"><div class="<?php echo ($subContentPage=='objectives')?'ternayActiveLink':'dataIcon';?> "></div><?php echo lang("Track.Objectives");?></a>
							<a href="<?php echo base_url()?>plannings/show_plans/plans"><div class="<?php echo ($subContentPage=='' || $subContentPage=='plans' || $subContentPage=='create_plan')?'ternayActiveLink':'dataIcon';?> "></div><?php echo lang("Track.Plans");?></a>
							<?php if($userRoleId == ROLE_MANAGER || $userRoleId == ROLE_ADMIN){?>
								<!--<a href="<?php echo base_url()?>plannings/show_plans/create_plan"><div class="<?php echo ($subContentPage=='create_plan')?'ternayActiveLink':'dataIcon';?> "></div><?php echo lang("Track.CreatePlan");?></a>-->
							<?php }?>
                                                               
							<!--<a href="<?php echo base_url()?>plannings/show_plans/reports"><div class="<?php echo ($subContentPage=='reports')?'ternayActiveLink':'dataIcon';?> "></div><?php echo lang("Reports");?></a>-->
						</div> 
						
						 
						<li <?php if($currentMethod == 'view_numeric_report' || $currentMethod == 'save_interaction' || $currentMethod == 'add_mirf' || $currentMethod == 'view_mirf' || $currentMethod == 'view_drilldown_list' || $currentMethod == 'view_micro_interaction') echo 'class="active"';?>>
							<div class="interInteraction interaction sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>interactions/view_numeric_report" class="interactionLink"><?php echo lang('Track.Interactions')?></a>
							</div>
						</li>
						<li <?php if($currentMethod == 'list_payments' || $currentMethod == 'add_payment') echo 'class="active"';?>>
							<div class="payment sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>payments/list_payments/payments" class="paymentsLink"><?php echo lang('Track.Payments')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse Payments">&nbsp;</a></div>
							--></div>
							<!--
							<div class="ternaryNavLinks">
								<div class="<?php echo ($subContentPage=='' || $subContentPage=='payments')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>payments/list_payments/payments">Payments</a>
								<div class="<?php echo ($subContentPage=='add_threshold')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><a href="<?php echo base_url()?>payments/list_payments/add_threshold">Add Threshold</a>
							</div>
							-->
						</li>
			<?php	/*		<li <?php if($currentMethod == 'list_monthly_events') echo 'class="active"';?>>
							<div class="navLinkEvents sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>monthly_reports/list_monthly_events" class="clientEventsLink"><?php echo lang('Track.EventsReport')?></a>
							</div>
						</li>

						<?php 
						*/
							
						?>
								<li <?php if($currentMethod == 'show_contracts' || $currentMethod == 'save_contract') echo 'class="active"';?>>
									<div class="contractIcon sprite_iconSet"></div>
									<div class="secondaryMenuItem">
										<a href="<?php echo base_url()?>contracts/show_contracts" class="contractLink"><?php echo lang('Track.Contracts')?></a>
									</div>
								</li>
						
<!--							<li <?php if($currentController == 'coachings' && ($currentMethod == 'medical_insight' || $currentMethod == 'list_medical_insights' || $currentMethod == 'view_medical_insight' || $currentMethod == 'edit_medical_insight')) echo 'class="active"';?>>
								<div class="interMedical dataIcon sprite_iconSet" style="margin-top: 1px;"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>coachings/list_medical_insights" class="coachingLink"><?php echo lang('Track.MedicalInsight')?></a>
								</div>
							</li>-->
                                                        
							<!-- <li <?php if(($currentController == 'coachings' && ($currentMethod == 'add_coaching' || $currentMethod == 'view' || $currentMethod == 'list_coachings' || $currentMethod == 'edit_coaching' || $currentMethod == 'compliance' || $currentMethod == 'list_compliance' || $currentMethod == 'view_compliance')) || ($currentController == 'customer_engagements')) echo 'class="active"';?>>
								<div class="contractIcon dataIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>coachings/list_coachings" class="coachingLink">Field Coaching</a>
									
								</div>
							</li> -->

<!--							<div class="ternaryNavLinks">
								<a href="<?php echo base_url()?>coachings/list_coachings" class="coachingLink <?php  if($currentController == 'coachings' && ($currentMethod == 'add_coaching' || $currentMethod == 'view' || $currentMethod == 'list_coachings' || $currentMethod == 'edit_coaching')) echo 'currentTernaryNav';?> " ><?php echo "Customer Engagement";?></a>
								<a href="<?php echo base_url()?>customer_engagements/list_engagements/one" class="coachingLink <?php  if($currentController == 'customer_engagements' && ($param=="" || $param=="one")) echo 'currentTernaryNav';?> " ><?php echo "Customer Engagement 1:1";?></a>
								<a href="<?php echo base_url()?>customer_engagements/list_engagements/group" class="coachingLink <?php  if($currentController == 'customer_engagements' && ($param=="group")) echo 'currentTernaryNav';?> " ><?php echo "Customer Engagement Group";?></a>
								<a href="<?php echo base_url()?>coachings/list_compliance" class="coachingLink <?php  if($currentController == 'coachings' && ($currentMethod == 'compliance' || $currentMethod == 'list_compliance' || $currentMethod == 'view_compliance')) echo 'currentTernaryNav';?> " ><?php echo lang('Track.ComplianceForm')?></a>
                                                                
							</div>-->
							
<!--							<li <?php if($currentMethod == 'list_surveys') echo 'class="active"';?>>
								<div class="interSpeakerEval reportIcon sprite_iconSet" style="margin-top: 1px;"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>speaker_evaluations/list_surveys" class="coachingLink">Speaker Evaluation </a>
								</div>
							</li>-->
					<?php
					endif;
					?>
					<?php 
					// If the 'my_list_kols' is the action
					if(($currentController == 'my_list_kols')  
						): ?>
						<li <?php if($currentMethod == 'list_categories') echo 'class="active"';?>>
							<div class="navLinkManageList sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>my_list_kols/list_categories" class="managelistsLink"><?php echo lang('Mylists.Managelist')?></a>
							</div>
						</li>
						<li <?php if($currentMethod == 'list_categories_and_names') echo 'class="active"';?>>
							<div class="navLinkMyList sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>my_list_kols/list_categories_and_names" class="listsLink"><?php echo lang('Mylists.Lists')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse lists menu">&nbsp;</a></div>
							</div>
						</li>
							<div class="ternaryNavLinks">
								<?php 
									if($subContentPage=='my_list'){
								?>		
										<a href="<?php echo base_url()?>my_list_kols/list_categories_and_names/public_list"><div class="<?php echo ($subContentPage=='' || $subContentPage=='public_list')?'public_list ternayActiveLink':'publicList';?> sprite_iconSet"></div>Public List</a>
										<a href="<?php echo base_url()?>my_list_kols/list_categories_and_names/my_list"><div class="<?php echo ($subContentPage=='my_list')?'privateList ternayActiveLink':'privateList';?> sprite_iconSet"></div>Private List</a>
										<div id="listLeftBar" class="span-4 last">
											<div id="listPrivateContainer">
												<ul class="treeview list" id="myListTree">
													<?php 
														foreach ($arrCatagoriesPrivate as $lastkey=>$lastvalue);
															array_pop($arrCatagoriesPrivate);
													?>
													<?php 
														foreach($arrCatagoriesPrivate as $key=>$value){
													?>
															<li class="expandable rootTree" ><div class="hitarea expandable-hitarea"></div><span class="listBgColor"><?php echo $key;?></span>
																						
																<ul style="display: none;">
																	<?php 
																		foreach ($value as $lastid=>$lastval);
																			$rowLastId="listNameId_".$lastid;
																	?>
																	<?php array_pop($value)?>
																	<?php foreach ($value as $id=>$val){
																		$rowId="listNameId_".$id;
																	?>
																		<li class="listName">
																			<a onclick="displayKOlDetails('<?php echo $id;?>');" class="listBgColor textDecorationNone" id="<?php echo $rowId;?>">
																				<?php echo $val;
																					foreach($arrKols as $kols){
																						if($id==$kols['list_name_id'])
																						echo ' '.'('.$kols['count'].')';
																					}
																				?> 
																			</a>
																		</li>
																	<?php }?>
																	
																	<li class="last">
																		<a onclick="displayKOlDetails('<?php echo $lastid;?>');" class="listBgColor textDecorationNone" id="<?php echo $rowLastId;?>">
																			<?php echo $lastval;
																				foreach($arrKols as $kols){
																					if($lastid==$kols['list_name_id'])
																					echo ' '.'('.$kols['count'].')';
																				}			
																			?>
																		</a>
																	</li>
																</ul>
															</li>
													<?php }?>
													
													<?php if(isset($lastvalue)){?>
														<li class="lastExpandable"><div class="hitarea expandable-hitarea lastExpandable-hitarea"></div><span class="listBgColor"><?php echo $lastkey;?></span>
															<ul style="display: none;">
																<?php 
																	foreach ($lastvalue as $lastid=>$lastval);
																	$rowlastId="listNameId_".$lastid;
																?>
																<?php array_pop($lastvalue)?>
																<?php foreach ($lastvalue as $id=>$val){
																	$rowId="listNameId_".$id;
																?>
																	
																	<li class="listName">
																		<a onclick="displayKOlDetails('<?php echo $id;?>');" class="listBgColor textDecorationNone" id="<?php echo $rowId;?>">
																			<?php echo $val;
																			foreach($arrKols as $kols){
																					if($id==$kols['list_name_id'])
																					echo '  '.'('.$kols['count'].')';
																				}
																			?> 
																		</a>
																	</li>
																<?php }?>
																<li class="last">
																	<a onclick="displayKOlDetails('<?php echo $lastid;?>');" class="listBgColor textDecorationNone" id="<?php echo $rowlastId;?>">
																		<?php echo $lastval;
																			foreach($arrKols as $kols){
																						if($lastid==$kols['list_name_id'])
																						echo ' '.'('.$kols['count'].')';
																					}
																		?>
																	</a>
																</li>
															</ul>
														</li>
													<?php }?>
													
								  				</ul>
								  			</div>
										</div>
								<?php 		
									}
								?>
								
								<?php 
									if($subContentPage=='public_list' || $subContentPage==''){
								?>		<a href="<?php echo base_url()?>my_list_kols/list_categories_and_names/my_list"><div class="<?php echo ($subContentPage=='my_list')?'privateList ternayActiveLink':'privateList';?> sprite_iconSet"></div>Private List</a>
										<a href="<?php echo base_url()?>my_list_kols/list_categories_and_names/public_list"><div class="<?php echo ($subContentPage=='' || $subContentPage=='public_list')?'publicList ternayActiveLink':'publicList';?> sprite_iconSet"></div>Public List</a>
										<div id="listLeftBar" class="span-4 last">
											<div id="listPublicContainer">
												<ul class="treeview" id="publicListTree">
													<?php foreach($arrCatagoriesPublic as $pubCategotyLastkey=>$pubCategorylastValue);
														array_pop($arrCatagoriesPublic);		
													?>
														
													<?php foreach($arrCatagoriesPublic as $key=>$value){
													?>
														<li class="expandable"><div class="hitarea expandable-hitarea"></div><span class="listBgColor textDecorationNone"><?php echo $key;?></span>
															<ul style="display: none;">
																<?php foreach ($value as $lastid=>$lastval);
																	$rowLastId="listNameId_".$lastid;
																
																?>
																	<?php array_pop($value)?>
																	<?php foreach ($value as $id=>$val){
																		$rowId="listNameId_".$id;
																	?>
																	<li>
																		<a onclick="displayKOlDetails('<?php echo $id;?>');" id="<?php echo $rowId; ?>" class="publiListBgColor textDecorationNone">
																			<?php echo $val;
																				foreach($arrKolsPublic as $kols){
																					if($id==$kols['list_name_id'])
																					echo ' '.'('.$kols['count'].')';
																				}
																			?> 
																		</a>
																	</li>
																<?php }?>
																<li class="last">
																	<a onclick="displayKOlDetails('<?php echo $lastid;?>');" id="<?php echo $rowLastId; ?>" class="listBgColor textDecorationNone">
																		<?php echo $lastval;
																			foreach($arrKolsPublic as $kols){
																					if($lastid==$kols['list_name_id'])
																					echo ' '.'('.$kols['count'].')';
																				}
																			?> 
																	</a>
																</li>
															</ul>
														</li>
													<?php }?>
								  				
								  				
								  				<?php if(isset($pubCategorylastValue)){?>
									  				<li class="lastExpandable"><div class="hitarea lastExpandable-hitarea"></div><span class="listBgColor"><?php echo $pubCategotyLastkey;?></span>
																<ul style="display: none;">
																		<?php foreach ($pubCategorylastValue as $lastid=>$lastval);
																			$rowLastId="listNameId_".$lastid;
																		?>
																		<?php array_pop($pubCategorylastValue);?>
																		<?php foreach ($pubCategorylastValue as $id=>$val){
																			$rowId="listNameId_".$id;
																		?>
																		<li>
																			<a onclick="displayKOlDetails('<?php echo $id;?>');" id="<?php echo $rowId; ?>" class="publiListBgColor textDecorationNone">
																				<?php echo $val;
																					foreach($arrKolsPublic as $kols){
																						if($id==$kols['list_name_id'])
																						echo ' '.'('.$kols['count'].')';
																					}
																				?>
																			</a>
																		</li>
																	<?php }?>
																	<li class="last">
																		<a onclick="displayKOlDetails('<?php echo $lastid;?>');" id="<?php echo $rowLastId; ?>" class="listBgColor textDecorationNone">
																			<?php echo $lastval;
																				foreach($arrKolsPublic as $kols){
																						if($lastid==$kols['list_name_id'])
																						echo ' '.'('.$kols['count'].')';
																					}
																				?>
																		</a>
																	</li>
																</ul>
															</li>
														<?php }?>
								  				</ul>
											</div>
										</div>
								<?php 		
									}
								?>
							</div>
					<?php 
					endif;
				?>
					
				<?php 
					// If the 'Reports' is the action
					if(($currentController == 'reports')  && (
																$currentMethod == 'view_reports' 
																|| $currentMethod == 'view_interaction_reports' 
																|| $currentMethod == "msl_activity_report" 
																|| $currentMethod == 'user_access_report'  
																|| $currentMethod == 'view_interaction_reports' 
																|| $currentMethod == 'view_coaching_reports' || $currentMethod == 'view_engagement_reports'
                                                                                                                                || $currentMethod == 'view_coaching_quarterly_reports' || 'view_engagement_reports'
																|| $currentMethod == 'list_uoq' 
                                                                                                                                || $currentMethod == 'customer_seen_report'
                                                                                                                                || $currentMethod == 'institution_seen_report'
																|| $currentMethod == 'list_speaker_evaluations'
																|| $currentMethod == 'medical_insight_reports') 
						): ?>
						<!-- 
						<li <?php if($param == 'activity') echo 'class="active"';?>>
							<div class="reportsActivity reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/activity" class=""><?php echo lang('Report.Activity')?></a>
							</div>
						</li>
						<li <?php if($param == 'rating') echo 'class="active"';?>>
							<div class="reportsProfScore reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/rating" class=""><?php echo lang('Report.ProfileScore')?></a>
							</div>
						</li>
						
						<li <?php if($param == 'events') echo 'class="active"';?>>
							<div class="reportsEvents reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/events" class=""><?php echo lang('Report.Events')?></a>
							</div>
						</li>
						<li <?php if($param == 'affiliations') echo 'class="active"';?>>
							<div class="reportsAffiliations reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/affiliations" class=""><?php echo lang('Report.Affiliations')?></a>
							</div>
						</li>
						<li <?php if($param == 'publications') echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/publications" class=""><?php echo lang('Report.Publications')?></a>
							</div>
						</li>
						 -->
						<!-- <li <?php if($currentMethod == 'view_interaction_reports') echo 'class="active"';?>>
							<div class="reportsInteractions reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_interaction_reports" class="">Interactions</a>
							</div>
						</li>
                         <li <?php if($currentMethod == 'view_coaching_reports') echo 'class="active"';?>>
							<div class="reportsInteractions reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_coaching_reports" class="">Field Coaching</a>
							</div>
						</li>
						 <li <?php if($currentMethod == 'medical_insight_reports') echo 'class="active"';?>>
							<div class="reportsInteractions reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/medical_insight_reports" class="">Medical Insight</a>
							</div>
						</li>
						<li <?php if($currentMethod == 'list_speaker_evaluations') echo 'class="active"';?>>
							<div class="reportsInteractions reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/list_speaker_evaluations" class=""><?php echo lang('Report.SpeakerEvaluations')?></a>
							</div>
						</li> -->
						<li <?php if($currentMethod == 'view_interaction_reports'  )  echo 'class="active"';?>>
							<div class="reportsInteractions reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_interaction_reports" class=""><?php //echo lang('Mykols.Others')?>Interactions</a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
						<?php if($this->common_helpers->isActionAllowed('interaction_reports')){?>
<!--						<li <?php if($currentMethod == 'user_access_report' || $currentMethod == 'customer_seen_report' || $currentMethod == 'institution_seen_report' || $currentMethod == 'view_engagement_reports' || $currentMethod == 'msl_activity_report' || $currentMethod== 'list_uoq' || $currentMethod== 'view_interaction_reports' || $currentMethod== 'view_coaching_reports' || $currentMethod== 'medical_insight_reports' || $currentMethod == 'list_speaker_evaluations' || $currentMethod == 'view_coaching_quarterly_reports'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_interaction_reports" class=""><?php //echo lang('Mykols.Others')?>Colpal</a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->                        
<!--                                                <li <?php if($currentMethod == 'list_uoq'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/list_uoq" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.UOQ')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<!--                                                 <li <?php if($currentMethod == 'medical_insight_reports'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/medical_insight_reports" class=""><?php //echo lang('Mykols.Others')?>Medical Insight</a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<!--                                                <li <?php if($currentMethod == 'list_speaker_evaluations'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/list_speaker_evaluations" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.SpeakerEvaluations')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<!--                                                  <li <?php if($currentMethod == 'msl_activity_report'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/msl_activity_report" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.MSLActivity')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<?php /*                        <li <?php if($currentMethod == 'user_access_report'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/user_access_report" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.UserAccess')?></a>
<!--								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
	*/ ?>
<!--                                                    <li <?php if($currentMethod == 'customer_seen_report'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/customer_seen_report" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.CustomerSeen')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<!--                                                <li <?php if($currentMethod == 'institution_seen_report'  )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/institution_seen_report" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.InstitutionSeen')?></a>
								<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>
							</div>
						</li>-->
<!--						<div class="ternaryNavLinks">
							<a href="<?php echo base_url()?>reports/view_interaction_reports" class=""><div class="terInter <?php echo ($currentMethod == 'view_interaction_reports')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Interactions</a>
							<a href="<?php echo base_url()?>reports/list_uoq" class=""><div class="terAffReportOrg <?php echo ($currentMethod == 'list_uoq')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.UOQ')?></a>
							<a href="<?php echo base_url()?>reports/view_coaching_reports" class=""><div class="interField <?php echo ($currentMethod == 'view_coaching_reports')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Customer Engagement (Old) </a>
                                                        <a href="<?php echo base_url()?>reports/view_engagement_reports" class=""><div class="interField <?php echo ($currentMethod == 'view_engagement_reports')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Customer Engagement</a>
							 <a href="<?php echo base_url()?>reports/view_coaching_quarterly_reports" class=""><div class="interField <?php echo ($currentMethod == 'view_coaching_quarterly_reports')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Engagement Quarterly </a> 
							<a href="<?php echo base_url()?>reports/medical_insight_reports" class=""><div class="terMedical <?php echo ($currentMethod == 'medical_insight_reports')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div>Medical Insight</a>
							<a href="<?php echo base_url()?>reports/list_speaker_evaluations" class=""><div class="terSpeakerEval <?php echo ($currentMethod == 'list_speaker_evaluations')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.SpeakerEvaluations')?></a>
							<a href="<?php echo base_url()?>reports/msl_activity_report" class=""><div class="terAffReportOrg <?php echo ($currentMethod == 'msl_activity_report')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.MSLActivity')?></a>
							<?php if($this->common_helpers->isActionAllowed('user_access_reports')){?>
							<a href="<?php echo base_url()?>reports/user_access_report" class=""><div class="terAffReportOrg <?php echo ($currentMethod == 'user_access_report')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.UserAccess')?></a>
							<?php }?>
							<a href="<?php echo base_url()?>reports/customer_seen_report" class=""><div class="terAffReportOrg <?php echo ($currentMethod == 'customer_seen_report')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.CustomerSeen')?></a>
							<a href="<?php echo base_url()?>reports/institution_seen_report" class=""><div class="terAffReportOrg <?php echo ($currentMethod == 'institution_seen_report')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.InstitutionSeen')?></a>
						</div>-->
						<?php }?>
						<li <?php if($param == 'activity' )  echo 'class="active"';?>>
							<div class="reportsActivity reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/activity" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.Activity')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
						</div>
						</li>
                                                <li <?php if($param == 'rating' )  echo 'class="active"';?>>
							<div class="reportsProfScore reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/rating" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.ProfileScore')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
                                                <li <?php if($param == 'events' )  echo 'class="active"';?>>
							<div class="reportsEvents reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/events" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.Events')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
                                                 <li <?php if($param == 'affiliations' )  echo 'class="active"';?>>
							<div class="reportsAffiliations reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/affiliations" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.Affiliations')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
						<li <?php if($param == 'publications' )  echo 'class="active"';?>>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/publications" class=""><?php //echo lang('Mykols.Others')?><?php echo lang('Report.Publications')?></a>
								<!--<div id="collapseExpandButton" class="collapseSlider"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Expand/Collapse affiliations">&nbsp;</a></div>-->
							</div>
						</li>
<!--						<div class="ternaryNavLinks">
							<a href="<?php echo base_url()?>reports/view_reports/activity" class=""><div class="reportsActivity <?php echo ($param == 'activity')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.Activity')?></a>
							<a href="<?php echo base_url()?>reports/view_reports/rating" class=""><div class="reportsProfScore <?php echo ($param == 'rating')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.ProfileScore')?></a>
							<a href="<?php echo base_url()?>reports/view_reports/events" class=""><div class="reportsEvents <?php echo ($param == 'events')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.Events')?></a>
							<a href="<?php echo base_url()?>reports/view_reports/affiliations" class=""><div class="reportsAffiliations <?php echo ($param == 'affiliations')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.Affiliations')?></a>
							<a href="<?php echo base_url()?>reports/view_reports/publications" class=""><div class="reportsPublications <?php echo ($param == 'publications')?'ternayActiveLink':'dataIcon';?> sprite_iconSet"></div><?php echo lang('Report.Publications')?></a>
						</div>-->
<!--						<li>
							<div class="reportsPublications reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>surveys/report" class=""><?php //echo lang('Mykols.Others')?>Surveys</a>
							</div>
						</li>-->						
						<li <?php if($param == 'segmentation') echo 'class="active"';?>>
							<div class="reportsSegmentation reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/segmentation" class=""><?php echo lang('Report.Segmentation')?></a>
							</div>
						</li>
						<?php
						$clientId = $this->session->userdata('client_id');
						//$arrAllowedUsers	= array('12415','12446');
						if(isset($enableReportForUsers)){
						if($clientId === INTERNAL_CLIENT_ID || in_array($this->session->userdata('user_id'),$enableReportForUsers)){
						?>
						<li <?php if($param == 'user_analytics') echo 'class="active"';?>>
							<div class="reportsUserAnalytics reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/user_analytics" class=""><?php echo lang('Report.Useranalytics')?></a>
							</div>
						</li>
						<li <?php if($param == 'ktl_analytics') echo 'class="active"';?>>
							<div class="reportsKtlAnalytics reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/ktl_analytics" class=""><?php echo lang('Report.Ktlanalytics')?></a>
							</div>
						</li>
						<li <?php if($param == 'summary') echo 'class="active"';?>>
							<div class="reportsEvents reportIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>reports/view_reports/summary"
									class=""><?php echo lang('Report.Summary')?></a>
							</div>
						</li>
						<?php } 
						} ?>
					<?php 
					endif;
				
					// If the 'View Payments' is the action
					if(($currentController == 'maps')  
						): ?>
						
						
						<?php $mobile = mobile_device_detect(); 
							if(IS_IPAD_REQUEST == 1){?>
								<li <?php if($currentMethod == 'view_influence_map_ipad') echo 'class="active"';?>>
									<div class="NetkolNet influenceMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
										<a href="<?php echo base_url()?>maps/view_influence_map_ipad" class="influenceLink"><?php echo lang('NetworkMaps.KOL_Network')?></a>
							</div>
						</li>
						<?php }else	if(!isset($mobile[1])) {?>
							<li <?php if($currentMethod == 'view_influence_map') echo 'class="active"';?>>
							<div class="NetkolNet influenceMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
										<a href="<?php echo base_url()?>maps/view_influence_map" class="influenceLink"><?php echo lang('NetworkMaps.KOL_Network')?></a>
									</div>
								</li>
						<?php }?>	
						 
						<li <?php if($currentMethod == 'view_influence_geo_map') echo 'class="active"';?>>
									<div class="NetkolGeoNet influenceMapIcon sprite_iconSet"></div>
									<div class="secondaryMenuItem">
										<a href="<?php echo base_url()?>maps/view_influence_geo_map" class="influenceLink"><?php echo lang('NetworkMaps.KOLGeoNetwork')?></a>
									</div>
							</li>  
						<!--li <?php if($currentMethod == 'view_influence_map_org') echo 'class="active"';?>>
							<div class="NetOrgNet influenceMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>maps/view_influence_map_org" class="influenceLink"><?php echo lang('NetworkMaps.OrgNetwork')?></a>
							</div>
						</li-->
						
<!--						<li <?php if($currentMethod == 'view_network_map') echo 'class="active"';?>>
							<div class="NetInfluNet influenceMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>surveys/report"><?php echo lang('NetworkMaps.InfluenceNetwork')?></a>
							</div>
						</li>-->
								
<!--						<li <?php if($currentMethod == 'view_geo_map') echo 'class="active"';?>>
							<div class="NetInflueGeo geoMapIcon sprite_iconSet"></div>
							<div class="secondaryMenuItem">
								<a href="<?php echo base_url()?>surveys/report"><?php echo lang('NetworkMaps.InfluenceGeoMap')?></a>
							</div>
						</li>-->
					<?php 
					endif;
                                        // If the 'Identifications' is the action
					if(($currentController == 'identifications' && $currentMethod == 'home')): ?>
					<form name="leftSidebarForm" id="leftSidebarForm">
						<a href="#" rel="tooltip" class="NewBlueButton btnTopSpeakers" onclick="loadTopSpeakers(); return false;" data-original-title="<?php echo lang('Identification.TopSpeakers');?>"><?php echo lang('Identification.TopSpeakers');?></a>
						<a href="#" rel="tooltip" class="NewBlueButton btnTopSpeakers" onclick="loadTopResearchers();return false;" data-original-title="<?php echo lang('Identification.TopResearches');?>"><?php echo lang('Identification.TopResearches');?></a>
						<!-- <li>
							<div class="secondaryMenuItem">
								<a href="#" onclick="loadTopSpeakers(); return false;"><?php echo lang('Identification.TopSpeakers');?></a>
							</div>
						</li>
						<li>
							<div class="secondaryMenuItem">
								<a href="#" onclick="loadTopResearchers();return false;"><?php echo lang('Identification.TopResearches');?></a>
							</div>
						</li> -->
					</form>
					<li>
						<label>
							<input type="checkbox" id="toggleWeightage"></input>
							Weightages
							<div id="weightageSettingOptions" class="userSettings sprite_iconSet tooltip-demo tooltop-right active"><a data-original-title="Custom Weightage" rel="tooltip" href="" onclick="showCustomWeightage(); return false;">&nbsp;</a>	</div>
						</label>
					</li>
					<div id='showWeighatages' style="display: none;">
						<ul>
							<li class="parent">
								<label>Events <span class="weight events_all"></span></label>
								<ul>
									<li class="child">
										<label>Speaking<span class="weight events_speaker"></span></label>
									</li>
									<li class="child">
										<label>Organizing Committee<span class="weight events_orgcom"></span></label>
									</li>
								</ul>
							</li>
                                                        <li class="parent">
								<label>Affiliations <span class="weight affiliations_all"></span></label>
								<ul>
                                                                        <li class="child">
                                                                                <label>Industry Affiliation <span class="weight industry_all"></span></label>
                                                                        </li>
                                                                        <li class="child">
                                                                                <label>Associations <span class="weight assoc_all"></span></label>
                                                                        </li>
                                                                        <li class="child">
                                                                                <label>Editorial Boards <span class="weight editorial_all"></span></label>
                                                                        </li>
                                                                        <li class="child">
                                                                                <label>Univ/Hospital <span class="weight expert_all"></span></label>
                                                                        </li>
                                                                </ul>
							</li>
                                                        
                                                        <li class="parent">
								<label>Guidelines<span class="weight guideline_all"></span></label>
							</li>
                                                        <li class="parent">
								<label>Publications <span class="weight pubs_all"></span></label>
								<ul>
									<li class="child">
										<label>Lead Auth<span class="weight pubs_lead"></span></label>
									</li>
									<li class="child">
										<label>Contributing Author<span class="weight pubs_ma"></span></label>
									</li>
									<li class="child">
										<label>Single Auth<span class="weight pubs_sa"></span></label>
									</li>
									<li class="child">
										<label>First Auth<span class="weight pubs_fa"></span></label>
									</li>
									<li class="child">
										<label>Last Auth<span class="weight pubs_la"></span></label>
									</li>
								</ul>
							</li>
							
							<li class="parent">
								<label>Trials <span class="weight trials_all"></span></label>
								<ul style="display: none;">
									<li class="child">
										<label>Principal Investigator<span class="weight trials_pi"></span></label>
									</li>
									<li class="child">
										<label>Co-Investigator<span class="weight trials_ci"></span></label>
									</li>
								</ul>
							</li>
                                                       
                                                        
                                                        
							<li class="parent">&nbsp;
								<label class="totalWeight weight">0%</label>
							</li>
						</ul>
					</div>
					
					<?php 
					endif;
					// If the 'Identifications Priority' is the action
					if(($currentController == 'identifications' && $currentMethod == 'priority_settings')): ?>
						<li class="active">
							<div class="secondaryMenuItem">
								<a href="#"><div class="navLinkPublications sprite_iconSet"></div><?php echo 'Journals';?></a>
							</div>
						</li>
						<li>
							<div class="secondaryMenuItem">
								<a href="#"><div class="navLinkAffiliation sprite_iconSet"></div><?php echo 'Institutions';?></a>
							</div>
						</li>
						<li>
							<div class="secondaryMenuItem">
								<a href="#"><div class="navLinkEvents sprite_iconSet"></div><?php echo 'Events';?></a>
							</div>
						</li>
						<li>
							<div class="secondaryMenuItem">
								<a href="#"><div class="navLinkTrials sprite_iconSet"></div><?php echo 'Trials';?></a>
							</div>
						</li>
						<li>
							<div class="secondaryMenuItem">
								<a href="#"><div class="navLinkPublications sprite_iconSet"></div><?php echo 'Guidelines';?></a>
							</div>
						</li>
					
					<?php 
					endif;
					// If the 'Surveys' is the action
					if(($currentController == 'surveys')): ?>
							<li <?php if($currentMethod == '' || $currentMethod == 'list_active_surveys' || $currentMethod == 'survey_form') echo 'class="active"';?>>
								<div class="SurActvieSur dataIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a href="<?php echo base_url()?>surveys/list_active_surveys" id="activeSurveySecondaryLink"><?php echo lang('Surveys.ActiveSurveys');?></a>
								</div>
							</li>
							<li <?php if($currentMethod == 'list_surveys' || $currentMethod == 'edit_survey_data' || $currentMethod == 'edit_survey' || $currentMethod == 'view' || $currentMethod == 'add_survey') echo 'class="active"';?>>
								<div class="SurAllSur dataIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a id="allSurveysSecondaryLink" href="<?php echo base_url()?>surveys/list_surveys"><?php echo lang('Surveys.AllSurveys');?></a>
								</div>
							</li>
							<?php 
							// Remove Sales Report and Remove HCP Completion menus hidded from all users
							/* if($isUserAllowedForSalesReport){?>
							<li <?php if($currentMethod == 'sales_report') echo 'class="active"';?>>
								<div class="SurSalesSur reportIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a id="surveyReportsSecondaryLink" href="<?php echo base_url()?>surveys/sales_report">Sales Report</a>
								</div>
							</li>
							<?php }
							if($isUserAllowedForHCPReport){?>
							<li <?php if($currentMethod == 'hcp_report') echo 'class="active"';?>>
								<div class="SurHCPSur reportIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a id="surveyReportsSecondaryLink" href="<?php echo base_url()?>surveys/hcp_report">HCP Completion</a>
								</div>
							</li>
							<?php }  */ ?>
							<li <?php if($currentMethod == 'view_reports' || $currentMethod == 'report') echo 'class="active"';?>>
								<div class="SurReportSur reportIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
								
										<?php
										$clientId = $this->session->userdata('client_id');
										$userId	=$this->session->userdata('user_id');
										$email	= $this->session->userdata('email');
										if($showReports){?>
												<a id="surveyReportsSecondaryLink" href="<?php echo base_url()?>surveys/report"><?php echo lang('Surveys.Reports');?></a>
											
											<?php }else{?>
											<a id="surveyReportsSecondaryLink" href="#" onclick="comingsoon()"><?php echo lang('Surveys.Reports');?></a>
								
								<?php }?>
								</div>
							</li>
							
							<!-- <li <?php if($currentMethod == 'view_network_map') echo 'class="active"';?>>
								<div class="influenceMapIcon sprite_iconSet"></div>
								<div class="secondaryMenuItem">
									<a id="surveyInfluenceMapSecondaryLink" href="<?php echo base_url()?>surveys/view_network_map"><?php echo lang('Surveys.InfluenceMap');?></a>
								</div>
							</li>
							<li <?php if($currentMethod == 'view_geo_map') echo 'class="active"';?>>
								<div class="geoMapIcon sprite_iconSet"></div>
									<div class="secondaryMenuItem">
									<a id="surveyGeoMapSecondaryLink" href="<?php echo base_url()?>surveys/view_geo_map"><?php echo lang('Surveys.InfluenceGeoMap');?></a>
								</div>
							</li> -->
					<?php 
					endif;
				?>
			</ul>
		</div>
		<br />
		<br />
	</div>
</div>
<div>	
	<div id="profileScoreChartContent" class="microProfileDialogBox">
	<div class="profileScoreChart" id="profileScoreChart"></div>
	</div>
</div>
<style>
<?php if (isset($arrKol) && $arrKol['imported_as']==1){?>
    #addInterButton{
        display:none;
    }
<?php }?>
</style>
<script>

function comingsoon(){
	alert("Feature Coming Soon");
}
function is_id_profile(){
	jAlert("Please add the KTL to your Contacts");
}
$(document).ready(function(){
	<?php if (isset($arrKol) && $arrKol['imported_as']==1){?>
		$('.NewAddIcon').removeAttr('onclick');
		$('.exportOptionsContainer .link').attr('onclick','is_id_profile();return false;');
		var addToContact = '<?php echo '<a class="addToContact blueButton" class="tooltipLink" rel="tooltip" title="Add to Contacts">Add to Contact</a>' ?>';		
		$('#addInterButton').parent().html(addToContact);
		$("#editKTL").removeAttr('href');
		$("#editKTL").addClass('NewAddIcon');
    	$(document).on('click','.NewAddIcon',function(){
    		is_id_profile();return false;
    	});
    	$(document).on('click','.addToContact',function(e){
    		jAlert('KTL added to contacts', '', function(result) {
    			var href = '<?php echo base_url().'identifications/save_kol_to_contact/'. $arrKol['id'] ?>';
            	window.location.href = href;
            });  
    	});    	
    	
    	$(document).on('click','.editIcon, .deleteIcon',function(e){ 
        	$(".ui-dialog-titlebar-close").click();   		 		
    		is_id_profile();return false;
    	});	
    	  	
    	
	<?php } ?>
});
</script>
