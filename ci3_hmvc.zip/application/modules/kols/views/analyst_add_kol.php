<style>
	ul.horizontal-menu li {
	    display: inline;
	    font-size: 14px;
	    font-weight: bold;
	    margin: 0px 40px;
	}
	ul.horizontal-menu li a{
		text-decoration: none;
	}
	div#kolOverviewTernaryNav {
	    margin-top: 20px;
	    border: 1px solid #ccc;
	    padding: 0 0 0 0;
	}
	.col-md-2.vertical-menu {
	    padding: 10px;
	}
	.col-md-12.content {
	    padding: 10px;
	    background: rgb(248, 248, 248);
	}
	ul.span-4.ternaryNav {
	    list-style: none;
	    margin-top: 20px;
	}
	.form-control {
	    display: block;
	    width: 100%;
	    height: 30px;
	    padding: 6px 6px;
	    font-size: 14px;
	    line-height: 1.0;
	    color: #555;
	    background-color: #fff;
	    background-image: none;
	    border: 1px solid #ccc;
	    border-radius: 0px !important; 
	    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
	    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
	    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
	    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
	    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
	}
	.ui-widget input, .ui-widget select, .ui-widget textarea, .ui-widget button {
	    font-family: Lucida Grande, Lucida Sans, Arial, sans-serif;
	    font-size: 12px;
	}
	label.control-label {
	    font-size: 12px;
	    color: #62626b;
	}
	img.add-org {
	    position: absolute;
	    left: 18pc;
	    top: 26px;
	}
	.note {
    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms"!important;
    font-size: 12px;
    color: #626262;
    margin: 0 0 20px 0;
}
</style>
<div class="container" style="margin-top:20px;">
	<div id="kolOverviewTernaryNav" class="col-md-12  ui-tabs ui-widget ui-corner-all ui-tabs-vertical ui-helper-clearfix">
		
		<div id="editKolForm" class="col-md-12 content span-18 last">
			<!-- Start of Persnoal and Professional Information -->
				<form action="save_kol" method="post" id="persnoalForm" name="persnoalForm" class="validateForm form-horizontal col-md-12">
					<input type="hidden" name="kol_id" id="kolId" value="">
					<div id="profId" class="ui-tabs-panel ui-widget-content ui-corner-bottom">
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
					 	<h1>Add New KTL for Processing</h1>
					 	<p class="note">Note: This is a temporary interface for the Demo. Later this will be replaced by the Import Job</p>
						<p>
							<label for="npiNum" style="font-size: 15px">Profile Type :</label>
							<input type="radio" name="profile_type" value="Full Profile" checked="checked">Full Profile
							<input type="radio" name="profile_type" value="Basic Plus">Basic Plus 
							<input type="radio" name="profile_type" value="Basic">Basic
							<a href="http://support.aisselkolm.com/solution/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile-" target="_NEW">Compare</a>
						</p>
						 <div class="form-group">
							<div class="col-md-4">
								<label class="control-label">Salutation  :</label>
								<select name="salutation" id="salutation" class="form-control required">
									<?php 
												foreach($arrSalutations as $key => $value){
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
								</select>
							</div>
							<div class="col-md-4  col-md-offset-2">
								<label class="control-label">Gender  :</label>
								<select name="gender" id="gender" class="form-control required">
									<option value="">--- Select ---</option>
									<option value="Male">Male</option>
								    <option value="Female">Female</option>
						    	</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-4">
								<label class="control-label">First Name  :</label>
								<input type="text" name="first_name" id="first_name" value="" maxlength="50" class="form-control required gray">
							</div>
							<div class="col-md-4 col-md-offset-2">
								<label class="control-label">Middle Name :</label>
										<input type="text" name="middle_name" id="middle_name" value="" maxlength="50" class="form-control gray">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-4">
								<label class="control-label">last Name  :</label>
								<input type="text" name="last_name" id="last_name" value="" maxlength="50" class="form-control required gray">
							</div>
							<div class="col-md-4 col-md-offset-2">
								<label class="control-label">Suffix :</label>
								<input type="text" name="suffix" id="suffix" value="" maxlength="50" class="form-control">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-4">
								<label class="control-label">Specialty  :</label>
								<select name="specialty" id="specialty" class="form-control required" style=">
											<option value="0">--- Select ---</option>
											<?php 
												foreach($arrSpecialties as $key => $value){
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
								</select>
							</div>
							<div class="col-md-4 col-md-offset-2">
								<label class="control-label">Organization Name:  :</label>
								<input style="vertical-align: top;margin-top: 5px;" class="form-control required ui-autocomplete-input" type="text" name="org_id" id="orgName" value="" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-4">
								<label class="control-label">NPI Number :</label>
								<input type="text" name="npi_num" id="npiNum" value="" class="form-control">
							</div>
						</div>
						<div style="text-align: center;">
							<input type="submit" value="Save" name="submit" id="savePersonalInfo" class="btn btn-primary pull-center">
						</div>
					</div>
					<!-- End of Personal and Professional Information -->
		</div>
	</div>
</div>