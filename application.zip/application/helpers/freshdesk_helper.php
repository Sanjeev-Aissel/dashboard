<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Fresh Desk Helpers
 *
 *
 * @package		application.helpers
 * @author		Vinayak
 * @since		Version 1.6
 */

// ------------------------------------------------------------------------


/**
 * getSSOUrl
 *
 * Get The SSO Url for Help desk
 *
 * @access	public
 * @param	$strName,$strEmail
 * @return	Helpdesk link
 */
if ( ! function_exists('getSSOUrl'))
{
	
		define('FRESHDESK_SHARED_SECRET','6b7edb194b8dcf90dd474581a8e63ca3');
		define('FRESHDESK_BASE_URL','http://colpalsupport.aisselkolm.com/');	//With Trailing slashes
		
	function getSSOUrl($strName, $strEmail) {
	
		//$link = FRESHDESK_BASE_URL."login/sso/?name=".urlencode($strName)."&email=".urlencode($strEmail)."&hash=".getHash($strName,$strEmail);
		//$this->session->set_userdata('comiareLink',$link);
		return FRESHDESK_BASE_URL."login/sso/?name=".urlencode($strName)."&email=".urlencode($strEmail)."&hash=".getHash($strName,$strEmail);
	}
	

}

if ( ! function_exists('getHash'))
{
	
	function getHash($strName, $strEmail) {
		//return hash('md5',$strName.$strEmail.FRESHDESK_SHARED_SECRET);
		$timeStamp = new DateTime();
		$hashString	= $strName.FRESHDESK_SHARED_SECRET.$strEmail.$timeStamp;
		return hash('md5',$hashString);
	}
}
// ------------------------------------------------------------------------
