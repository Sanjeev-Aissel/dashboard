<?php
/*
 * Interactions drilldown list
 * @author Ramesh B
 * @since 1.5
 * @package application.views.publications
 * 
 */
?>
	<!-- JQGrid Plugins -->
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min.js" type="text/javascript"></script>
	
<!--	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>-->

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/client_layout.css" />
<!--	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.blockUI.js"></script>-->
<script type="text/javascript">
	var isiPad			= false;
	<?php if(IS_IPAD_REQUEST == 1){?>
				isiPad	= true;
	<?php }?>
	var paginationValues	= new Array();
	<?php 
		$paginationValues	= explode(',',PAGINATION_VALUES);
		foreach($paginationValues as $key=>$value){
	?>
		paginationValues.push('<?php echo $value;?>');
	<?php
		}
	?>

	var base_url = '<?php echo base_url(); ?>';
	$(document).ready(function(){
		<?php $currUrl =  $_SERVER['REQUEST_URI']; 
			 $listUrl = str_replace("view_drilldown_list", "interactions_drilldown_list", $currUrl);
			 //echo $listUrl;
		?>
		listInteractions();

		$("#back-to-list").click(function(){
			$('#interactionsList').show();
			$("#viewInteractionContainer").hide();
			$("#interaction-details").html('&nbsp;');
		});		
	});

	var clientId		= '<?php echo $this->session->userdata('client_id')?>';
    var userId			= '<?php echo $this->session->userdata('user_id')?>';
    var userRoleId		= '<?php echo $this->session->userdata('user_role_id')?>';
	var ROLE_MANAGER 	= '<?php echo ROLE_MANAGER?>';
	var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
	var ROLE_USER		= '<?php echo ROLE_USER?>';
	var INTERNAL_CLIENT_ID = '<?php echo INTERNAL_CLIENT_ID?>';
	var product = "<?php echo lang("Overview.Product");?>";
	/*
	*Jqgrid for Interactions table
	*/
	function listInteractions(){
			
		var ele=document.getElementById('gridContainer');
		var gridWidth=ele.clientWidth;
		//gridWidth+=10;
		var colSecName = '<?php if($interaction_from == 'org') echo 'Organization Name'; else echo lang("KOL").' / Org Name';?>';
		jQuery("#listInteractionsResultSet").jqGrid({
			url:'<?php echo $listUrl;?>',
			datatype: "json",
			colNames:['Id','',colSecName,'Date','Recorded By','Interaction Type','Discussion Type',product,'Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'micro',width:30, search:false,align:'center',sortable:false},
				{name:'kol_name',index:'kol_name',width:170, resizable:false},
				{name:'date',index:'date', width:70, resizable:false},
		   		{name:'recorded_by',index:'recorded_by',width:170, resizable:false},
		   		{name:'mode_name',index:'mode_name',width:100, resizable:false},
				{name:'objective_name',index:'objective_name',width:210, resizable:false},
		   		{name:'product_name',index:'product_name',width:150, resizable:false},
		   		{name:'act',width:100, hidden:true,align:'center',search:false}   		
		   	],
		   	rowNum:10,
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#listInteractionsPage',
		   	mtype: "POST",
		   	sortname: 'date',
		    viewrecords: true,
		    sortorder: "desc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Interactions",
		    grouping: false, 
			groupingView : { 
				groupField : ['kol_name'], 
				groupColumnShow : [false], 
				groupText : ['<b>{0}</b>  ({1})'], 
				groupCollapse : false, 
				groupOrder: ['asc'], 
				groupSummary : [true], 
				groupDataSorted : false,
			},
			gridComplete: function(){
				//Get array of id'f from jqgrid			   
		    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 
		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
		    	for(var i=0;i < arrIds.length;i++){ 
		    		var arrId =  jQuery('#listInteractionsResultSet').jqGrid ('getRowData',  arrIds[i]);
			    	var id = arrId.id;		    	
			    	//Edit and Delete labels 	
		    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
			    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
		    		jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
		    		//Microview label	
			    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";
		    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";
			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
			    	} 
		    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");
		    	<?php $mobile = mobile_device_detect(); 
				if(!isset($mobile[1])){	?>			
					initializeCustomToolTips();
				<?php }?>
		    },
		    rowList:paginationValues
		});

		//Hide the column recorded by if the logged in user role is not manager
	   	var userRole=userRoleId;
	   	var managerRoleId=ROLE_MANAGER;
	   	var adminRoleId=ROLE_ADMIN;
	   	
	   	if(userRole!=managerRoleId || userRole!=adminRoleId)	 
	   		jQuery("#listInteractionsResultSet").hideCol("recorded_by"); 
			
		jQuery("#listInteractionsResultSet").jqGrid('navGrid','#listInteractionsPage',{edit:false,add:false,del:false,search:false,refresh:false});

		//Toolbar search bar below the Table Headers
		jQuery("#listInteractionsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#listInteractionsResultSet").jqGrid('navButtonAdd',"#listInteractionsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		});	
		
		jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth);  
	}
	function initializeCustomToolTips(){
		
		$('.tooltip-demo.tooltop-top').tooltip({
	      selector: "a[rel=tooltip]", placement:'top'
	    });
	    $('.tooltip-demo.tooltop-bottom').tooltip({
	      selector: "a[rel=tooltip]", placement:'bottom'
	    });
	    $('.tooltip-demo.tooltop-right').tooltip({
	      selector: "a[rel=tooltip]", placement:'right'
	    });
	    $('.tooltip-demo.tooltop-left').tooltip({
	      selector: "a[rel=tooltip]", placement:'left'
	    });

	}

	/**
	* Toggles (Show/Hide) the Grouping of 'KOL' for the Interactions
	* @param: gridId
	* @param: buttonId
	*/
	function toggleKolGrouping(gridId, buttonId){
		var ele=document.getElementById('gridContainer');
		var gridWidth=ele.clientWidth;
	//	gridWidth+=10;
		toggleValue	= $("#"+buttonId).val();
		if(toggleValue == 'Remove Grouping'){
			jQuery("#"+gridId).jqGrid('showCol', ["kol_name"]);
			jQuery("#"+gridId).jqGrid('groupingRemove', true);
			// Change the Value of Button
			$("#"+buttonId).val("Group By "+CONST_LANG_KOL);
		}else{
			jQuery("#"+gridId).jqGrid('hideCol', ["kol_name"]);
			jQuery("#"+gridId).jqGrid('groupingGroupBy', "kol_name");
			// Change the Value of Button
			$("#"+buttonId).val("Remove Grouping");
		}
		jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth);
	}

	function export_excel(){
		var excelFilters = '';
		$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
			if($(this).val() != ''){
				var filterName = $(this).attr('name');
				var filterValue = $(this).val();
				excelFilters += filterName+" : "+filterValue+",";
			}
		});
		$("#excel-filters").val(excelFilters);
		var selectedOPtion = $(".ui-pg-selbox").val();
		$(".ui-pg-selbox option:last").attr('selected','selected');
    	$('.ui-pg-selbox').trigger('change');
    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 
    	$('#ids').val(arrIds);
    	$('#export').submit();
    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
    	$('.ui-pg-selbox').trigger('change');
	}

	/**
	* Opens the Modal Box with the Micro Profile content of KOL
	* @param: kolId
	*/
	function viewInteractionMicroProfile(interactionId){
		
		$('.tooltip').hide();
		$('#interactionsList').hide();
		$("#viewInteractionContainer").show();
		$("#interaction-details").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url(); ?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#interaction-details").load(base_url+'interactions/view_micro_interaction/'+interactionId);
	}
		

</script>

<style type="text/css">
	#filters-selected{
		margin: 8px 0 0 11px;
	    padding: 0;
	    list-style:none;
	    text-align: left;
	}
	#filters-selected label{
		display: block;
	    float: left;
	    margin-right: 5px;
	    text-align: right;
	    width: 140px;
	}
	.toggleBtnWrapper{
		margin-right: 50px;
    	text-align: right;
	}
	#interactionMicroProfileContent{
		margin:auto;
	}
	#interaction-details{
		min-height:400px;
	}
	#header .nav-box ul li a:hover{
		color: #2b9af3 !important;
	}
</style>

</head>
<div id="interactionsList">
	<ul id="filters-selected">
	 	<?php echo $filterData;?>
	</ul>
	<div class="buttonsWarpper">
		<div class="toggleBtnWrapper">
			<!-- <input type="button" onClick="toggleKolGrouping('listInteractionsResultSet', 'toggleKolGrouping');" value="Group By KOL" name="toggleKolGrouping" id="toggleKolGrouping" /> -->
		</div>
<!--		<div class="addLink">-->
<!--			<div style="margin-top: -20px;float: right;margin-right: 15px;" class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();">-->
<!--				<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>-->
<!--			</div>-->
<!--		</div>-->
		
	</div>
	<form action="<?php echo base_url()?>interactions/export_interaction_details" method='post' id="export">
		<input type="hidden" name="interaction_ids" value="" id='ids'></input>
		<input type="hidden" name="filters" id="excel-filters" />
	</form>
	<div class="gridWrapper" id="gridContainer">
		<div id="listInteractionsPage"></div>
		<table id="listInteractionsResultSet"></table>
	</div>
</div>
<div id="viewInteractionContainer" style="display: none;">
	<button id="back-to-list">Back to List</button>
	<div id="interaction-details">&nbsp;</div>
</div>
