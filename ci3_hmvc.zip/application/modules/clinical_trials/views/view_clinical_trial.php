<head>
<title></title>
</head>
<style>
block {
    background: none repeat scroll 0 0 #EEEEEE;
    display: block;
    font-weight: bold;
    padding: 5px;
    border: 1px solid #CCCCCC;
}
.ctDetails{
	width: 100%;
	clear: both;
}
.ctDetails th, .ctDetails td{
	text-align: left;
	vertical-align: top;
}
.ctDetails th{
	background-color:#eee; 
}
.ctDetails td{
	color:#333;
}
.ctSection{
	clear: both;
    color: #333333;
    min-height: 20px;
    padding-bottom: 10px;
}
.ctSection strong{
	clear: both;
    display: block;
    float: left;
    padding-right: 5px;
    text-align: right;
    width: 100px;
}
</style>
<div id="background">
	<block><strong><?php echo $ctDetailsResult['trial_name'];?></strong></block>
	<div class="ctSection">
		<strong>Status: </strong>
		<?php echo $ctDetailsResult['status'];?>
	</div>
	<div class="ctSection">
		<strong>Study Type: </strong>
		<?php echo $ctDetailsResult['study_type'];?>
	</div>
	<div class="ctSection">
		<strong>Sponsor: </strong>
		<?php 
			$separator	= '';
			foreach($arrSponsors as $sponsor){
				if($sponsor['type']=='lead sponsor'){
				echo $separator.$sponsor['agency'];
				$separator	= ', ';
				}
			}
		?>
	</div>
	<div class="ctSection">
		<strong>Collaborator: </strong>
		<?php echo $ctDetailsResult['collaborator'];?>
	</div>
	<div class="ctSection">
		<strong>CT ID: </strong>
		<?php echo $ctDetailsResult['ct_id'];?>
	</div>
	<div class="ctSection">
		<strong>Purpose: </strong>
		<?php echo $ctDetailsResult['purpose'];?>
	</div>
	<div class="ctSection">
		<strong>Official Title: </strong>
		<?php echo $ctDetailsResult['official_title'];?>
	</div>
	<div>
		<table class="ctDetails">
			<tr>
				<th>Condition(s)</th>
				<th>Intervention(s)</th>
				<th>Phase</th>
			</tr>
			<tr>
				<td>
				<?php echo str_replace(',','<br />',$ctDetailsResult['condition']);?>
				</td>
				<td>
					<?php foreach($arrInterventions as $inetrVention){
							echo $inetrVention['name'].'<br />';
					}?>
				</td>
				<td>
					<?php echo $ctDetailsResult['phase'];?>
				</td>
			</tr>
			<tr>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Study Type</th>
			</tr>
			<tr>
				<td>
					<?php echo $ctDetailsResult['start_date'];?>
				</td>
				<td>
					<?php echo $ctDetailsResult['end_date'];?>
				</td>
				<td>
					<?php echo $ctDetailsResult['study_type'];?>
				</td>
			</tr>
			<tr>
				<th>Minimum Age</th>
				<th>Maximum Age</th>
				<th>Gender</th>
			</tr>
			<tr>
				<td>
					<?php echo $ctDetailsResult['min_age'];?>
				</td>
				<td>
					<?php echo $ctDetailsResult['max_age'];?>
				</td>
				<td>
					<?php echo $ctDetailsResult['gender'];?>
				</td>
			</tr>
			<tr>
				<th>Keywords</th>
				<th>MeSh Terms</th>
				<th>Investigator(s)</th>
			</tr>
			<tr>
				<td>
				<?php foreach($arrKeyWords as $key=>$arrRow){
					echo $arrRow['name'].'<br />';
				}?>
				</td>
				<td>
				<?php foreach($arrMeshTerms as $key=>$arrRow){
					echo $arrRow['term_name'].'<br />';
				}?>
				</td>
				<td>
				<?php foreach($arrInvestigators as $key=>$arrRow){
					echo $arrRow['last_name'].' '.$arrRow['role'].'<br />';
				}?>
				</td>
			</tr>
		</table>
	</div>
</div>