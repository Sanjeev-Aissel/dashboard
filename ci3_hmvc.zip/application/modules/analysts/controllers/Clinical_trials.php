<?php
/**
 * @Author : Sanjeev K
 * @Desc : Controller for Publications data manipulation 
 * @Since : KOLM_hmvc 1.0
 * @Package : application.controllers
 * @Created : 13-06-2018
 * @Refactored : 13-06-2018
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class clinical_trials extends MX_Controller {
	
	private $loggedUserId = null;
	
	//Constructor
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('analysts/clinical_trial');
		$this->load->model('analysts/kol');
		$this->load->model('align_users/align_user');
		
		//variables
		$this->loggedUserId = $this->session->userdata('user_id');
		$this->clientId		=$this->session->userdata('client_id');
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : view_clinical_trials
	 * @Param  : $kolId, $subContentPage
	 * @return : loads clinical Trials with in publications view
	 */
	function view_clinical_trials($kolId){
		$data['isClientView']	= false;
		$clientId				= $this->session->userdata('client_id');
		if($clientId==INTERNAL_CLIENT_ID){
			$data['enableEdit']	= true;
		}
		// Get the KOL details
		$arrKolDetail 			= $this->kol->editKol($kolId);
		$data['arrKol']			= $arrKolDetail;
			
		//$arrSalutations		= array(1 => 'Mr.', 'Mrs.', 'Miss.', 'Ms.', 'Dr.', 'Prof.');
		$arrSalutations			= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		$data['contentPage']	= 'clinical_trials/list_clinical_trials';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
			
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : process_CITDs_only_KOLs
	 * @Param  : $kolId, $subContentPage
	 * @return : loads clinical Trials with in publications view
	 */
	function process_CITDs_only_KOLs(){
		//Get all the KOLs having the CTIDs only
		$arrKols = $this->clinical_trial->getClinicalTrialsUnprocessedKols();
	
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
		$this->startTime	= microtime(true);
		$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		
		fwrite($this->logFile, $this->logText);
			
		if(sizeof($arrKols) > 0){
			//Loop trough each KOL
			foreach($arrKols as $arrKolDetail){
				$kolId = $arrKolDetail['id'];
				$this->logText	= "Starting Crawling of CT IDs for KOL Id ".$kolId."\r\n";
				fwrite($this->logFile, $this->logText);
	
				//Get the CTIDs for this KOL
				$arrCtIds = $this->clinical_trial->getCTIDs($kolId);
				//Check for already existing Clinical Trial's and associate them with kol
				$arrCtIds		= $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrCtIds, $kolId);
				$this->logText	= "Total No of CTIDs found after associating with existing trials: ".sizeof($arrCtIds)." \r\n";
				fwrite($this->logFile, $this->logText);
				$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
				fwrite($this->logFile, $this->logText);
				//End of checking and associating already existing Clinical Trials
				if(sizeof($arrCtIds)>0){
					foreach($arrCtIds as $key=>$ctID){
						$uniqueCTID	= rtrim(trim($ctID),',');
						if(!empty($uniqueCTID)){
							// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
							$ctFetchStartTime	= microtime(true);
							$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
							$this->logText		= "Url generated: ".$url."\r\n";
							fwrite($this->logFile, $this->logText);
							$content 			= $this ->retrieve_page_get($url);
							if(!$content)	return false;
							$timeTaken			= microtime(true)-$ctFetchStartTime;
							$this->logText		= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
							fwrite($this->logFile, $this->logText);
							$xml 				= new DOMDocument();
							if(!$xml->loadXML($content)){
								$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
								
								fwrite($this->logFile, $this->logText);
								//continue;
								die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
							}
								
							//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
							$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
							foreach($clinicalStudys as $clinicalStudy){
								$timeElapsed	= (microtime(true) - $this->startTime);
								$remTime		= $this->maxScriptTime-$timeElapsed;
								//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed
								if($remTime<$this->safeTime){
									$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
									fwrite($this->logFile, $this->logText);
									die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
								}
								$ctStartTime	= microtime(true);
								$arrKolName		= $this->kol->getKolName($kolId);
								//get the different combinations of names
								$arrKolNameCombination	= $this->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
								//getting the parsed values for Clinical trial
								$ctDetails		= $this->parse_ct_details($clinicalStudy,$arrKolNameCombination);
								//saves the Clinical trial details
								$ctId			= $this->save_clinical_trials($ctDetails, $kolId, 1);
								if($ctId!=null){
									//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
									//fwrite($this->logFile, $this->logText);
								}else{
									$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
									
									fwrite($this->logFile, $this->logText);
									continue;
								}
	
								//getting the parsed values for sponsers
								$arrSponsers	= $this->parse_clinicle_sponsers($clinicalStudy);
	
								//saves sponser details and returns bollean value
								$isSaved		= $this->clinical_trial->saveSponsers($arrSponsers, $ctId);
	
								//getting the parsed values for Intervention
								$arrIntervention= $this->parse_clinicle_intervention($clinicalStudy);
	
								//saves Intervention details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInterventions($arrIntervention, $ctId);
	
								//getting the parsed values for Keywords
								$arrKeyword		= $this->parse_clinicle_keyword($clinicalStudy);
	
								//saves Keyword details and returns bollean value
								$isSaved		= $this->save_keyword($arrKeyword, $ctId);
	
								//getting the parsed values for Meshterms
								$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
	
								//saves Meshterms details and returns bollean value
								$isSaved		= $this->save_meshterms($arrMeshterms, $ctId);
	
								//getting and parsed values for Investigators
								$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination);
	
								//saves $arrInvestigators details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);
									
								$timeTaken		= microtime(true)-$ctStartTime;
								$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
								$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
								fwrite($this->logFile, $this->logText);
							}
							sleep($this->sleepTime);
							$arrData['message']	= 'Completed processing';
						}
						$arrStatusData['id'] = $kolId;
						$arrStatusData['is_clinical_trial_processed'] = 1;
						$this->clinical_trial->updateClinicalTrialProcessedKol($arrStatusData);
					}
	
				}else{
					$arrData['message']	= 'Terminated';
				}
	
				$this->logText	= "End of Procesing all the CTID's \r\n";

				fwrite($this->logFile, $this->logText);
			}
		}else{
			echo "No Unprocessed KOL ids";
			$this->logText	= "No Unprocessed KOL ids \r\n";

			fwrite($this->logFile, $this->logText);
		}
		echo "Completed processing ";
		$this->logText	= "Completed processing \r\n";

		fwrite($this->logFile, $this->logText);
		$this->logText	= "Processing Ended on: " . date("d-m-Y H:i:s") . "\r\n";
		echo $this->logText;
		fwrite($this->logFile, $this->logText);
	}
	
	function parse_clinicle_sponsers($clinicalStudy){
		//getting the Sponsers
		$arrSponsers=array();
		$sponsorsObj = $clinicalStudy->getElementsByTagName('sponsors')->item(0);
		$leadSponsers=$sponsorsObj->getElementsByTagName('lead_sponsor');
		foreach($leadSponsers as $leadSponserObj){
			if($leadSponserObj!=null){
				$leadSponser=array();
				$type='lead sponsor';
				$agency='';
				$agencyClass='';
				$agencyObj = $leadSponserObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){
					$agency= $agencyObj->nodeValue;
				}
				$agencyClassObj = $leadSponserObj->getElementsByTagName('agency_class')->item(0);
				if($agencyClassObj!=null){
					$agencyClass= $agencyClassObj->nodeValue;
				}
				$leadSponser['type']=$type;
				$leadSponser['agency']=$agency;
				$leadSponser['agency_class']=$agencyClass;
				$arrSponsers[]=$leadSponser;
			}
		}
	
		$collaborators = $sponsorsObj->getElementsByTagName('collaborator');
		foreach($collaborators as $collaboratorObj){
			if($collaboratorObj!=null){
				$collaborator=array();
				$type='collaborator';
				$agency='';
				$agencyClass='';
				$agencyObj = $collaboratorObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){
					$agency= $agencyObj->nodeValue;
				}
				$agencyClassObj = $collaboratorObj->getElementsByTagName('agency_class')->item(0);
				if($agencyClassObj!=null){
					$agencyClass= $agencyClassObj->nodeValue;
				}
				$collaborator['type']=$type;
				$collaborator['agency']=$agency;
				$collaborator['agency_class']=$agencyClass;
				$arrSponsers[]=$collaborator;
			}
		}
		return $arrSponsers;
	}
	
	/**
	 * parse the values for Interventions
	 *
	 * @param $clinicalStudy
	 * @return Array $arrIntervention
	 */
	function parse_clinicle_intervention($clinicalStudy){
		//getting the Interventions
		$arrIntervention=array();
		$interventions = $clinicalStudy->getElementsByTagName('intervention');
	
		foreach($interventions as $interventionObj){
			if($interventionObj!=null){
				$intervention=array();
				$type='';
				$name='';
				$description = '';
				$armGroupLabel='';
				$othrName='';
				$interventionTypeObj = $interventionObj->getElementsByTagName('intervention_type')->item(0);
				if($interventionTypeObj!=null){
					$type= $interventionTypeObj->nodeValue;
				}
					
				$interventionNameObj = $interventionObj->getElementsByTagName('intervention_name')->item(0);
				if($interventionNameObj!=null){
					$name= $interventionNameObj->nodeValue;
				}
					
				$descriptionObj = $interventionObj->getElementsByTagName('description')->item(0);
				if($descriptionObj!=null){
					$description= $descriptionObj->nodeValue;
				}
					
				$armGroupLabels = $interventionObj->getElementsByTagName('arm_group_label');
				$armGroupLabelValue;
				foreach ($armGroupLabels as $armGroupLabelObj){
					if($armGroupLabelObj!=null){
						$armGroupLabelValue= $armGroupLabelObj->nodeValue;
					}
					$armGroupLabel=$armGroupLabel+$armGroupLabelValue+",";
				}
				//					//Right now saving all the Array of Arm groups as one String
				//					foreach ($armGroupLabelArr as $armGroup){
				//						$armGroupLabel=$armGroupLabel+$armGroup.",";
				//					}
						
				$othrNameObj = $interventionObj->getElementsByTagName('other_name')->item(0);
				if($othrNameObj!=null){
					$othrName= $othrNameObj->nodeValue;
				}
	
				$intervention['type']=$type;
				$intervention['name']=$name;
				$intervention['description']=$description;
				$intervention['arm_group_label']=$armGroupLabel;
				$intervention['other_name']=$othrName;
				$arrIntervention[]=$intervention;
			}
	
		}
		return  $arrIntervention;
	}
	
	
	/**
	 * parse the values for keywords
	 *
	 * @param $clinicalStudy
	 * @return Array $arrKeywords
	 */
	function parse_clinicle_keyword($clinicalStudy){
		//getting the Keywords
		$arrKeyword=array();
		$keywords = $clinicalStudy->getElementsByTagName('keyword');
		foreach ($keywords as $keywordObj){
			$keywordName=array();
			if($keywordObj!=null){
				$keywordName['name']= $keywordObj->nodeValue;
			}
			$arrKeyword[]=$keywordName;
		}
		return  $arrKeyword;
	}
	
	/**
	 * Saves the array of Keyword one by one
	 *
	 * @param Array $arrKeyword
	 * @param Integer $ctId
	 * @return boolean
	 */
	function save_keyword($arrKeyword, $ctId){
		$isSaved=false;
		foreach($arrKeyword as $keyword){
			$keywordId=$this->clinical_trial->saveKeyword($keyword);
				
			$ctKeyword=array();
			$ctKeyword['cts_id']=$ctId;
			$ctKeyword['keyword_id']=$keywordId;
				
			$isSaved=$this->clinical_trial->saveCtKeyword($ctKeyword);
		}
		return $isSaved;
	}
	/**
	 * parse the values for Meshterms
	 *
	 * @param $clinicalStudy
	 * @return Array $arrMeshterms
	 */
	function parse_clinicle_meshterms($clinicalStudy){
		//getting the Meshterms
		$arrMeshterms=array();
		//For Condition Browse
		$conditionBrowseObj = $clinicalStudy->getElementsByTagName('condition_browse')->item(0);
		if($conditionBrowseObj!=null){
			$conditionBrowse=array();
			$type='condition_browse';
			$name='';
			$meshterms = $conditionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){
					$name= $meshtermsObj->nodeValue;
				}
				$conditionBrowse['term_name']=$name;
				$conditionBrowse['type']=$type;
				$arrMeshterms[]=$conditionBrowse;
			}
		}
	
		//For Intervention Browse
		$interventionBrowseObj = $clinicalStudy->getElementsByTagName('intervention_browse')->item(0);
		if($interventionBrowseObj!=null){
			$interventionBrowse=array();
			$type='intervention_browse';
			$name='';
			$meshterms = $interventionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){
					$name= $meshtermsObj->nodeValue;
				}
				$interventionBrowse['term_name']=$name;
				$interventionBrowse['type']= $type;
				$arrMeshterms[]=$interventionBrowse;
			}
		}
		return  $arrMeshterms;
	}
	
	function save_meshterms($arrMeshterms, $ctId){
		$isSaved=false;
		foreach($arrMeshterms as $meshterms){
			$meshtermId=$this->clinical_trial->saveMeshterms($meshterms);
			$ctMeshterms=array();
			$ctMeshterms['cts_id']=$ctId;
			$ctMeshterms['term_id']=$meshtermId;
			$isSaved=$this->clinical_trial->saveCtMeshterms($ctMeshterms);
		}
		return $isSaved;
	}
	
	function parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination=array()){
		//getting the Investigators(
		$arrInvestigators=array();
	
		$investigators = $clinicalStudy->getElementsByTagName('overall_official');
		if($investigators!=null){
			foreach($investigators as $investigatorObj){
				if($investigatorObj!=null){
					$investigator=array();
					$lastName='NA';
					$role='Investigator';
					$affiliation='NA';
					$lastNameObj=$investigatorObj->getElementsByTagName('last_name')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
						$roleObj=$investigatorObj->getElementsByTagName('role')->item(0);
						if($roleObj!=null)
							$role=$roleObj->nodeValue;
							$affiliationObj=$investigatorObj->getElementsByTagName('affiliation')->item(0);
							if($affiliationObj!=null)
								$affiliation=$affiliationObj->nodeValue;
								$investigator['last_name']=$lastName;
								$investigator['role']=$role;
								$investigator['affiliation']=$affiliation;
								$arrInvestigators[$investigator['last_name']]=$investigator;
				}
			}
		}
		$overallInvestigatorObj	= $clinicalStudy->getElementsByTagName('investigator');
		foreach($overallInvestigatorObj as $investigatorsObj){
			$investigator	= array();
			$last_nameObj	= $investigatorsObj->getElementsByTagName('last_name')->item(0);
			$roleObj		= $investigatorsObj->getElementsByTagName('role')->item(0);
			if($last_nameObj!=''){
				$investigator['last_name']	= $last_nameObj->nodeValue;
			}
			if($roleObj!=''){
				$investigator['role']		= $roleObj->nodeValue;
			}
			$arrInvestigators[$investigator['last_name']]=$investigator;
		}
		$kolnameExists	= false;
		if(sizeof($arrKolNameCombination)>0){
			foreach($arrInvestigators as $investigators){
				if (in_array(str_replace('.','',$investigator['last_name']), str_replace('  ',' ',$arrKolNameCombination))){
					$kolnameExists	= true;
				}
			}
		}
		if(!$kolnameExists){
			$investigator	= array();
			$investigator['last_name']	= $arrKolNameCombination[sizeof($arrKolNameCombination)-1];
			$investigator['role']		= 'Principal Investigator';
			$investigator['affiliation']= '';
			$arrInvestigators[]			= $investigator;
		}
		return  $arrInvestigators;
	}
	
	function list_clinical_trials_details($kolId,$type = 'verified'){
	
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrClinicalTrials	= array();
		$data				= array();
		if($arrClinicalTrialsResults=$this->clinical_trial->listClinicalTrialsDetailsByType($kolId,$type)){
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['asoc_id'];
				$arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				$arrClinicalTrial['is_analyst']	= $arrClinicalTrialsResult['is_analyst'];
				$arrClinicalTrial['first_name']	= $arrClinicalTrialsResult['first_name'];
				$arrClinicalTrial['last_name']	= $arrClinicalTrialsResult['last_name'];
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['trial_id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
				// 				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="images/user3.png" /></label>';
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
					$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
					$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
					$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
					$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
					$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
					$arrClinicalTrial['eAllowed']							= $this->common_helper->isActionAllowed('kol_details','edit',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
					if($arrClinicalTrialsResult['is_industry_trial'] == 1){
						$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1' checked='checked'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'/>";
					}else if($arrClinicalTrialsResult['is_industry_trial'] == 2){
						$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'  checked='checked'/>";
					}else{
						$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'/>";
					}
					$arrClinicalTrial['data_type_indicator']	= $arrClinicalTrialsResult['data_type_indicator'];;
					$arrClinicalTrials[]			= $arrClinicalTrial;
			}
			$count				= sizeof($arrClinicalTrials);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrClinicalTrials;
		}
		echo json_encode($data);
	}
	
	function clinical_trial_manual_dropdowns(){
		$arrStatusIds = array(	4		 => COMPLETED,
				1		 => 'Recruiting',
				3 	 	 => 'Terminated',
				12		 => 'Ongoing',
				13 		 => 'Others');
	
		$arrPhaseIds = array(	'I'	 	=> 'I',
				'II'	=> 'II',
				'III' 	=> 'III',
				'IV'	=> 'IV');
	
		$arrGenders = array(	'male'	=> 'Male',
				'female'=> 'Female',
				'both' 	=> 'Both');
	
		$arrKOLRoles = array(	'Co-investigator'		=> 'Co-investigator',
				'Principal Investigator'=> 'Principal Investigator',
				'Study Director' 		=> 'Study Director',
				'Sub-investigator' 		=> 'Sub-investigator');
	
		$data['arrStatusIds']	= $arrStatusIds;
		$data['arrPhaseIds']	= $arrPhaseIds;
		$data['arrKOLRoles']	= $arrKOLRoles;
		$data['arrGenders']		= $arrGenders;
		return $data;
	}
	
	function add_clinical_trial_analyst($kolId=null,$ctId=null){
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$arrClinicalTrialDetails	= array('id'=>	'',
				'trial_name'		=>	'',
				'status_id'			=>	'',
				'sponsor'	 		=> 	'',
				'condition'			=> 	'',
				'intervention'	 	=> 	'',
				'phase'	 			=> 	'',
				'investigators'	 	=> 	'',
				'keyword'			=>	'',
				'meshterm'			=>	'',
				'official_title'	=>	'',
				'link'				=>	'',
				'study_type'		=>	'',
				'collaborator'		=>	'',
				'start_date'		=>	'',
				'end_date'			=>	'',
				'no_of_enrollees'	=>	'',
				'no_of_trial_sites'	=>	'',
				'min_age'			=>	'',
				'max_age'			=>	'',
				'purpose'			=>	'',
				'kol_role'			=>	'',
				'gender'			=>	''
		);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';
	
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
	
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
	
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
	
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		if($ctId!=null){
			$arrClinicalTrialDetails= $this->clinical_trial->getClinicalTrial($ctId);
			$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
			$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
			$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
			$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
			$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
			$i=0;
			foreach ($arrMeshterms as $meshterms){
				$i++;
				if($i == 2)
					break;
					$manualMeshterms['meshterms']	= $meshterms['term_name'];
					$manualMeshterms['id'] 			= $meshterms['id'];
			}
			$i=0;
			foreach ($arrKeywords as $keywords){
				$i++;
				if($i == 2)
					break;
					$manualKeywords['keywords']  = $keywords['name'];
					$manualKeywords['id']		 = $keywords['id'];
			}
			$i=0;
			foreach ($arrSponsors as $sponsors){
				$i++;
				if($i == 2)
					break;
					$manualSponsors['sponsor']  = $sponsors['agency'];
					$manualSponsors['id'] = $sponsors['id'];
			}
			$i=0;
			foreach ($arrInterventions as $interventions){
				$i++;
				if($i == 2)
					break;
					$manualInterventions['intervention'] = $interventions['name'];
					$manualInterventions['id'] = $interventions['id'];
			}
			$i=0;
			foreach ($arrInvestigators as $investigators){
				$i++;
				if($i == 2)
					break;
					$manualInvestigators['investigators'] = $investigators['last_name'];
					$manualInvestigators['id'] = $investigators['id'];
			}
		}
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$arrClinicalTrialDetails['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
	
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$arrClinicalTrialDetails['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
	
	
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$arrClinicalTrialDetails['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
	
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$arrClinicalTrialDetails['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
	
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$arrClinicalTrialDetails['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['kolId'] = $kolId;
		$data['contentData']	=$data;
		$this->load->view('clinical_trials/add_clinical_trials',$data);
	}
	
	/**
	 * Controller functions for Organization module Scripts Starts
	 * @Author : Sanjeev K
	 * @Method : add_clinical_trial
	 * @Param  : $orgId
	 * @return : none
	 */
	function add_clinical_trial($orgId){
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		//$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		$arrClinicalTrialDetails	= array('id'                =>	'',
				'trial_name'		=>	'',
				'status_id'			=>	'',
				'sponsor'	 		=> 	'',
				'condition'			=> 	'',
				'intervention'	 	=> 	'',
				'phase'	 			=> 	'',
				'investigators'	 	=> 	'',
				'keyword'			=>	'',
				'meshterm'			=>	'',
				'official_title'	=>	'',
				'link'				=>	'',
				'study_type'		=>	'',
				'collaborator'		=>	'',
				'start_date'		=>	'',
				'end_date'			=>	'',
				'no_of_enrollees'	=>	'',
				'no_of_trial_sites'	=>	'',
				'min_age'			=>	'',
				'max_age'			=>	'',
				'purpose'			=>	'',
				'kol_role'			=>	'',
				'gender'			=>	''
		);
	
		$arrClinicalTrialDetails['no_of_sponsors']=1;
		$manualSponsor['id'] = '';
		$manualSponsor['sponsor'] = $arrClinicalTrialDetails['sponsor'];
	
		$arrClinicalTrialDetails['no_of_intervention']=1;
		$manualIntervention['id'] = '';
		$manualIntervention['intervention'] = $arrClinicalTrialDetails['intervention'];
	
		$arrClinicalTrialDetails['no_of_investigators']=1;
		$manualInvestigator['id'] = '';
		$manualInvestigator['investigators'] = $arrClinicalTrialDetails['investigators'];
	
		$arrClinicalTrialDetails['no_of_meshterms']=1;
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = $arrClinicalTrialDetails['meshterm'];
	
		$arrClinicalTrialDetails['no_of_keywords']=1;
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = $arrClinicalTrialDetails['keyword'];
	
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
	
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['orgId'] = $orgId;
	
		$this->load->view('clinical_trials/add_org_clinical_trials',$data);
	}
}
