<?php
/**
 * Contains a form to add plans
 * 
 * @package views.plannings
 * @author Ramesh B
 * @since 3.1
 * @created 12-09-2011
*/
$kolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<style type="text/css">
	#addPlansForm input[type="text"]{
		width:155px;
	}
/*	div.addIcon {
		margin-top: 24px;
	}
*/
	#createPlansContiner #plansDetails tr td select{
		width:190px;
	}
	div.actionIcon{
		margin-top: 15px;
	}
</style>
<script type="text/javascript">
	var globalId = '';
	var kolAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_autocomplete',
		<?php echo $kolAutoCompleteOptions;?>,
		onSelect : function(event, ui) {
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			selText=selText.replace(/\&amp;/g,'&');
			$('#'+globalId).val(selText);
			$('#'+globalId.replace("kolName", "kolId")).val(kolId);
		 }
	};
	$(".test1").live("focus",function(){
		 globalId = $(this).attr('id');
	});
	var kolAutoComplete	= $('#kolName1').autocomplete(kolAutoCompleteOptions);
	
	$(document).ready(function(){
		//Function to handle request to add another plan, to the same objective
		$("#addMorePlan").click(function(){
			//get the number of plans already entered in this page, by default it is 1
			var numberOfPlans=$("#numberOfPlans").val();
			numberOfPlans++;
			var planFormContent=$("#plan1").html();
			var newPlanContent='<tr id="plan'+numberOfPlans+'">'+planFormContent+'</tr>';
			$("#plansDetails").append(newPlanContent);
			//remove add another plan button from other plans, as it is unnessesary to give this button infront of each plan
			$('#plan'+numberOfPlans+' #addMorePlan').attr('id','cancelPlan'+numberOfPlans);
			var cancelButton='<div class="actionIcon deleteIcon" alt="Cancel Plan" title="Delete" onclick="cancelPlan('+numberOfPlans+')" />';
			$('#plan'+numberOfPlans+' #cancelPlan'+numberOfPlans).html(cancelButton);

			//Rename the names and ids of all the inputs for this plan
			$('#plan'+numberOfPlans+' #kolName1').attr('id','kolName'+numberOfPlans);
			$('#plan'+numberOfPlans+' #kolName'+numberOfPlans).attr('name','kol_name_'+numberOfPlans);
			$('#plan'+numberOfPlans+' #kolId1').attr('id','kolId'+numberOfPlans);
			$('#plan'+numberOfPlans+' #kolId'+numberOfPlans).attr('name','kol_id_'+numberOfPlans);
			$('#plan'+numberOfPlans+' td:nth-child(1) label').attr('for','kolId'+numberOfPlans);
			$('#plan'+numberOfPlans+' #kolId'+numberOfPlans).val('');
			$('#plan'+numberOfPlans+' #kolId'+numberOfPlans).removeClass('error');


			$('#plan'+numberOfPlans+' #userId1').attr('id','userId'+numberOfPlans);
			$('#plan'+numberOfPlans+' #userId'+numberOfPlans).attr('name','user_id_'+numberOfPlans);
			$('#plan'+numberOfPlans+' td:nth-child(2) label').attr('for','userId'+numberOfPlans);
			$('#plan'+numberOfPlans+' #userId'+numberOfPlans).val('');
			$('#plan'+numberOfPlans+' #userId'+numberOfPlans).removeClass('error');

			$('#plan'+numberOfPlans+' #month1').attr('id','month'+numberOfPlans);
			$('#plan'+numberOfPlans+' #month'+numberOfPlans).attr('name','month_'+numberOfPlans);
			$('#plan'+numberOfPlans+' td:nth-child(3) label').attr('for','month'+numberOfPlans);
			$('#plan'+numberOfPlans+' #month'+numberOfPlans).val('');
			$('#plan'+numberOfPlans+' #month'+numberOfPlans).removeClass('error');

			$('#plan'+numberOfPlans+' #targets1').attr('id','targets'+numberOfPlans);
			$('#plan'+numberOfPlans+' #targets'+numberOfPlans).attr('name','targets_'+numberOfPlans);
			$('#plan'+numberOfPlans+' td:nth-child(4) label').attr('for','targets'+numberOfPlans);
			$('#plan'+numberOfPlans+' #targets'+numberOfPlans).val('');
			$('#plan'+numberOfPlans+' #targets'+numberOfPlans).removeClass('error');

			$('#plan'+numberOfPlans+' #planCancel1').attr('id','planCancel'+numberOfPlans);
			$('#plan'+numberOfPlans+' #planCancel'+numberOfPlans).attr('name','plan_cancel_'+numberOfPlans);

			//Set the updated value of number of plans in this page
			$("#numberOfPlans").val(numberOfPlans);

			//Remove the error messages
			$('#plan'+numberOfPlans+' label.error').remove();

			//remove the class 'duplicatePlan' from all td's if exist
			$('#plan'+numberOfPlans+' td').each(function(){
				$(this).removeClass('duplicatePlan');
			});
			
			$('#month'+numberOfPlans).rules("add", {
				 required: true,
				 validMonth : true,
				 messages: {
				   required: "Required input",
				   validMonth: "Month should not be past"
				 }
			});
			$("#targets"+numberOfPlans).rules("add", {
				 digits: true,
				 messages: {
					digits: "Please enter only digits"
				 }
			});

			var kolAutoComplete	= $('#kolName'+numberOfPlans).autocomplete(kolAutoCompleteOptions);
		});

		//Validate the plans form using jquery plugin
		$("#addPlansForm").validate({
			debug:false,
			onkeyup:true
		});

		
		$("#targets1").rules("add", {
			 digits: true,
			 messages: {
				digits: "Please enter only digits"
			 }
		});
		
	
		$("#month1").rules("add", {
			 required: true,
			 validMonth : true,
			 messages: {
			   required: "Required input",
			   validMonth: "Month should not be past"
			 }
		});
		

		jQuery.validator.addMethod("greaterThanZero1", function(value, element) {
		    return this.optional(element) || (parseFloat(value) > 0);
		}, "* Amount must be greater than zero");
				
	});

	//Cancel the adding plan, just hide the plan and set it as cancelled, while saving exclude the plans whose planCancelled is '1'
	function cancelPlan(planNumber){
		$("tr#plan"+planNumber+" #planCancel"+planNumber).val(1);
		$("tr#plan"+planNumber).fadeOut(600,function(){
			$("tr#plan"+planNumber).remove();
		});
	}

	function validatePlans(){
		//validate the plans 
		if(!$("#addPlansForm").validate().form()){
			return false;
		}else
			return true;
	}

	//Save all the plans using AJAX.
	function savePlans(){
		//remove the class 'duplicatePlan' from all td's if exist
		$("#addPlansForm td").each(function(){
			$(this).removeClass('duplicatePlan');
		});
		
		//validate the plans 
		if(!$("#addPlansForm").validate().form()){
			return false;
		}
		
		var numberOfPlans=$("#numberOfPlans").val();
		var isAllMatched = true;
		for(i=1; i<=numberOfPlans; i++){
			if(document.getElementById('kolName'+i) != null){
				var enteredKolText = $('#kolName'+i).val();
				var matched = false;
				$.each(allKols, function(key, value){
					if(value == enteredKolText) {
						matched = true;
					}
				});
				if(!matched){
					isAllMatched = false;
					$("#kolName"+i).after(' <label for="kolId" generated="true" class="error">KOL Not Exists.</label>');
				}
			}
		}
		if(isAllMatched){
			//Show Saving message...
			$('div.planMsgBox').removeClass('success');
			$('div.planMsgBox').addClass('notice');
			$('div.planMsgBox').show();
			$('div.planMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');		
			
			//Serialize the form data
			var data=$("#addPlansForm").serialize();
			$.ajax({
				url:"<?php echo base_url()?>plannings/save_plans",
				data:data,
				type:'POST',
				dataType:'json',
				success:function(returnData){
					var duplicatePlans=returnData.duplicatePlans;
					var savedPlans=returnData.savedPlans;
					$.each(duplicatePlans,function(key, value){
						$('#plan'+value+' td').each(function(){
							$(this).addClass('duplicatePlan');
						});
						
					});
					if(duplicatePlans>0){
						$('div.planMsgBox').fadeOut('500'); 
						$('div.planMsgBox').addClass('notice');
						$('div.planMsgBox').fadeIn('500');
						$('div.planMsgBox').html('Rows with red background color are the duplicate plans');		
					}else{
						$('div.planMsgBox').fadeOut(1500); 
						var numberOfPlans=$("#numberOfPlans").val();
						for(i=2;i<=numberOfPlans;i++){
							cancelPlan(i);
						}
						$('#addPlansForm #objectiveId').val('');
						$('#plan1 #kolId1').val('');
						$('#plan1 #kolName1').val('');
						$('#plan1 #userId1').val('');
						$('#plan1 #month1').val('');
						$('#plan1 #targets1').val('');
						$('#plan1 #numberOfPlans').val('1');
					}
				}
			});
		}
	}
</script>

<div id="createPlansContiner">
	<form name="addPlansForm" id="addPlansForm" action="<?php echo base_url()?>plannings/save_plans" >
		<div class="msgBoxContainer"><div class="planMsgBox"></div></div>
		<input type="hidden" name="number_of_plans" value="1" id="numberOfPlans"></input>
		<p id="objectivesSelect">
			<label>Objective :<span class="required">*</span></label>
			<select name="objective_id" id="objectiveId" class="required">
				<option value="">Select Objective</option>
				<?php if(isset($arrObjectives)){?>
					<?php foreach($arrObjectives as $key => $value){?>
						<option value="<?php echo $key;?>"><?php echo $value;?></option>
					<?php }?>
				<?php }?>
			</select>
		</p>
		
		<table id="plansDetails">
		
			<tr id="plan1">
				<td>
					<label for="kolId1"><?php echo lang("KOL");?> Name :<span class="required">*</span></label>
					<input type="text" name="kol_name_1"  id="kolName1" class="test1 required autocompleteInputBox" />
					<input type="hidden" name="kol_id_1"  id="kolId1" />
					<span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter <?php echo lang("KOL");?> name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span>
				</td>
				<td>
					<label for="userId1">Assign To :<span class="required">*</span></label>
					<select name="user_id_1" id="userId1" class="required">
						<option value="">Select Responsible</option>
						<?php if(isset($arrUsers)){?>
							<?php foreach($arrUsers as $key => $value){?>
								<option value="<?php echo $key;?>"><?php echo $value;?></option>
							<?php }?>
						<?php }?>
					</select>
				</td>
				<td>
					<label for="month1">Month :<span class="required">*</span></label>
					<input type="text" name="month_1" id="month1"  class="planMonth required" onclick="showCalendarControl(this.id);"></input>
				</td>
				<td>
					<label for="targets1">Targets :<span class="required">*</span></label>
					<input type="text" name="targets_1" id="targets1"  class="required"></input>
					<input type="hidden" name="plan_cancel_1"  id="planCancel1" value="0"></input>
				</td>
				<td id="addDeleteLinks">
					<label id="addMorePlan"><div class="actionIcon addIcon"></div></label>
				</td>
			</tr>
		</table>
		<center><input type="button" name="save_plans" value="Save" onclick="savePlans();" /></center>
	</form>
</div>
