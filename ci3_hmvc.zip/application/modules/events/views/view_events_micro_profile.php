<style type="text/css">
.eventsMicroWrapper table caption h3{
	margin: 5px 0px;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    border-top: 0px;
    padding: 3px;
}
</style>
<script type="text/javascript">
$(document).ready(function (){
	$('.modal-header .modal-title').html('<?php echo $arrEvents[0]['name'];?>');
});
</script>
<div class="eventsMicroWrapper">
	<?php foreach($arrEvents as $result){?>
		<table class="table">
			<tr>
				<th class="align_right" width="22%">Event Type :</th>
				<td><?php echo $result['conf_event_type'];?></td>
			</tr>
			<tr>
				<th class="align_right">Session Type :</th>
				<td><?php echo $result['conf_session_type'];?></td>
			</tr>
			<tr>
				<th class="align_right">Session Name :</th>
				<td><?php echo $result['session_name'];?></td>
			</tr>
			<tr>
				<th class="align_right">Topic :</th>
				<td><?php echo $result['event_topic'];?></td>
			</tr>
			<tr>
				<th class="align_right">Role :</th>
				<td><?php echo $result['role'];?></td>
			</tr>
			<tr>
				<th class="align_right">Start date :</th>
				<td><?php if($result['start']>0) echo $result['start'];?></td>
			</tr>
			<tr>
				<th class="align_right">End Date :</th>
				<td><?php if($result['end']>0) echo $result['end'];?></td>
			</tr>
			<tr>
				<th class="align_right">Location :</th>
				<td><?php echo $result['location'];?></td>
			</tr>
			<tr>
				<th class="align_right">Country :</th>
				<td><?php echo $result['country'];?></td>
			</tr>
			<tr>
				<th class="align_right">Organizer :</th>
				<td><?php echo $result['organizer'];?></td>
			</tr>
			<tr>
				<th class="align_right">Session Sponsor :</th>
				<td><?php echo $result['session_sponsor'];?></td>
			</tr>
			<tr>
				<th class="align_right">Sponsor Type :</th>
				<td><?php echo $result['sponsor_type_name'];?></td>
			</tr>
		</table>
	<?php }?>	
</div>
<!-- End of leftAdressBar Div -->