<?php
/**
 * Controller for handling ID project actions
 * 
 * @author Ramesh B
 * @since  
 * @package application.controllers	
 * @created 05 Feb 2015
 */

class Identifications extends Controller{
    private $loggedUserId = null;
 	//Constructor
	function Identifications(){
		parent::Controller();
		
		$this->load->model('organization');
		$this->load->model('kol');
		$this->load->model('identification');
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	/**
	 * List ID Projects
	 */
	
	function list_projects(){
		$arrProjects = array();
		$data['arrProjects'] = $this->identification->listProjects();
		$data['contentPage']					= 'identification/list_projects';
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited List ID Projects Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "List Projects"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	function getIdProject($clientId){
	    $page				= (int)$this->input->post('page'); // get the requested page
	    $limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
	    $data				= array();
	    $arrReturnData = array();
	    $arrKolData = $this->identification->listProjects();
	    foreach ($arrKolData as $row) {
	        $row['edit_link'] = '<a target="_blank" href="' . base_url() . 'identifications/edit_project/' . $row['id'] . '">Edit</a>';
	        $row['name'] = '<a target="_NEW" href="' . base_url() . 'identifications/list_project_associations/'. $row['id'] . '">' . $row['name'] . '</a>';
	        $arrReturnData[] = $row;
	    }
	    $count=sizeof($arrReturnData);
	    if( $count >0 ){
	        $total_pages = ceil($count/$limit);
	    }else{
	        $total_pages = 0;
	    }
	    
	    $data['records']=$count;
	    $data['total']=$total_pages;
	    $data['page']=$page;
	    $data['rows']=$arrReturnData;
	    echo json_encode($data);
	}
	
	function list_project_associations($projectId){
	    $data = array();
	    $arrClientList = $this->kol->getAllClients();
	    $data['arrClientList'] = $arrClientList;
	    $data['selectedClients'] = $this->identification->getClientProjects($projectId);
	    $data['rowData'] = $this->identification->getProject($projectId);
	    $data['yearRange'] = $this->identification->getProjectYearRange($projectId);
	    $data['contentPage']					= 'identification/list_project_associations';
	    //Add Log activity
	    $arrLogDetails = array(
	        'type' => LIST_RECORD,
	        'description' => "Visited List ID Project Associations",
	        'status' => STATUS_SUCCESS,
	        'transaction_name' => "List Project Associations"
	    );
	    $this->config->set_item('log_details', $arrLogDetails);
	    
	    $this->load->view('layouts/analyst_view',$data);
	}
	
	function list_project_kols_details_grid($project_id,$startYear,$endYear){
	    ini_set('memory_limit','-1');
	    
	    $page	= $_REQUEST['page']; // get the requested page
	    
	    $limit 	= $_REQUEST['rows']; // get how many rows we want
	    
	    $sidx 	= $_REQUEST['sidx']; // get index row - i.e. user click to sort
	    
	    $sord 	= $_REQUEST['sord']; // get the direction
	    
	    if(!$sidx) $sidx =1;
	    
	    // connect to the database
	    
	    $filterData=$_REQUEST['filters'];
	    $arrFilter=array();
	    $arrFilter=json_decode(stripslashes($filterData));
	    $field='field';
	    $op='op';
	    $data='data';
	    $groupOp='groupOp';
	    $searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
	    $searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
	    $searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
	    $searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
	    $whereResultArray=array();
	    foreach($searchField as $key=> $val){
	        $whereResultArray[$val]=$searchString[$key];
	    }
	    $searchGroupOperator=$searchGroupOperator[0];
	    $searchResults=array();
	    $count	= $this->identification->getProjectAssociatedKols($project_id,$limit,$start,true,$sidx,$sord,$whereResultArray);
	    
	    if( $count >0 )
	    
	    {
	        
	        $total_pages = ceil($count/$limit);
	        
	    }
	    
	    else { $total_pages = 0;
	    
	    }
	    
	    if ($page > $total_pages)
	        
	        $page=$total_pages;
	        
	        $start = $limit*$page - $limit; // do not put  $limit*($page - 1)
	        
	        $arrProjectKolsDetailResult	= $this->identification->getProjectAssociatedKols($project_id,$limit,$start,false,$sidx,$sord,$whereResultArray);
// 	        echo $this->db->last_query();exit;
	        $i = 0;
	        $arrKolDetails = array();
	        foreach($arrProjectKolsDetailResult->result_array() as $row){
// 	            $responce->rows[$i]['id']=$row['kol_id'];
	            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
	            $row['kol_name'] = $row['kol_name'] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
	            $row['event_count'] =  $this->identification->getKolsIdActivityCount('kol_events',$project_id,$row['kol_id'],$startYear,$endYear);
	            $row['affiliation_count'] =  $this->identification->getKolsIdActivityCount('kol_memberships',$project_id,$row['kol_id'],$startYear,$endYear);
	            $row['publication_count'] =  $this->identification->getKolsIdActivityCount('kol_publications',$project_id,$row['kol_id'],$startYear,$endYear);
	            $row['trial_count'] =  $this->identification->getKolsIdActivityCount('kol_clinical_trials',$project_id,$row['kol_id'],$startYear,$endYear);
// 	            $row['kol_name'] = $kolName;
	            $arrKolDetails[] = $row;
	            //                 $responce->rows[$i]['cell']=array($row['id'],$row['name'],$row['short_code'],$row['url'],$row['description'],$row['action']);
	            
	            $i++;
	            
	        }
// 	        pr($arrKolDetails);exit;
	        $dataRec['records'] = $count;
	        $dataRec['total'] = $total_pages;
	        $dataRec['page'] = $page;
	        $dataRec['rows'] = $arrKolDetails;
	        echo json_encode($dataRec);
	}
	
	/**
	 * Show create project page
	 * @return html
	 */
	function create_project(){
		$arrClientList = $this->kol->getAllClients();
		$data['arrClientList'] = $arrClientList;
		$data['contentPage']					= 'identification/project_form';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add New Project Form Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add Project Form"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
// 		$this->load->view('identification/project_form',$data);
	}
	
	/**
	 * Save Project Details
	 * @return html
	 */
	function save_project(){
		$rowData = $_POST;
		$arrDataDisply = array();
		$dataSetProjectId ='';
                $resultArray = array();
		if(!isset($rowData['id'])){
			$data['created_by'] = $this->session->userdata('user_id');
			$data['created_on'] = date("Y-m-d H:i:s");
                        $data['name'] = $rowData['name'];
                        $data['description'] = $rowData['description'];
                        $data['year_range'] = $rowData['year_range'];
                        $kol_ids=$rowData['kol_ids'];
                        if(!isset($kol_ids) && sizeof($kol_ids) == 0){
                            $kol_ids=explode(",",$kol_ids);
                        }
//                         $kol_ids=explode(",",$kol_ids);
                        $overwrite_association = $rowData['overwrite_association'];
                        $duplicate_kols_in_id_project=$this->identification->duplicateCheckProjectKols($kol_ids,$overwrite_association);
                        if($duplicate_kols_in_id_project==0){
                            if(empty($rowData['kol_ids'])){
                                $project_details=$this->identification->saveProject($data);
                                $project_details=$project_details[0];
                                $kolProArray['project_id'] = $project_details['id'];
                                $dataSetProjectId = $project_details['id'];
                                $kolProArray['client_id'] = $rowData['client'];
                                $kol_project_visibility = $this->identification->saveKolsProjectVisibility($kolProArray);
//                                 echo "Project Name : ".$project_details['name']." with project Id ".$project_details['id']. " is created.";
                                $arrDataDisply['data'] = "Project Name : ".$project_details['name']." with project Id ".$project_details['id']. " is created.";
//                                 exit;
                            }
                            else{
                                $project_details=$this->identification->saveProject($data);
                                $project_details=$project_details[0];
                                $project_id=$project_details['id'];
                                $kolProArray = array();
                                $kolProArray['project_id'] = $project_id;
                                $kolProArray['client_id'] = $rowData['client'];
//                                 pr($kolProArray);
                                $kol_project_visibility = $this->identification->saveKolsProjectVisibility($kolProArray);
                                $kolClientArray = array();
                                $kolClientArray['client_ids'] = $rowData['client'];
                                $kolClientArray['kol_ids'] = $kol_ids;
                                $kols_client_visibility = $this->identification->saveKolsClientVisibility($kolClientArray);
//                                 echo $this->db->last_query();exit;
                                $is_imported=$this->identification->updateKolIsImported($kol_ids);
                                array_push($resultArray,"<br/>no of rows updated : ".$is_imported);
                                $kol_mem_rows=$this->identification->UpdatekolMembershipKolIds($kol_ids,$project_id);
                                array_push($resultArray,"no of rows affected in kol_memberships : ".$kol_mem_rows);

                                $kol_event_rows=$this->identification->UpdatekolEventKolIds($kol_ids,$project_id);
                                array_push($resultArray,"no of rows affected in kol_events : ".$kol_event_rows);

                                $kol_pub_rows=$this->identification->UpdatekolPubKolIds($kol_ids,$project_id);
                                array_push($resultArray,"no of rows affected in kol_publications : ".$kol_pub_rows);

                                $kol_clinical_rows=$this->identification->UpdatekolClinicalTrialsKolIds($kol_ids,$project_id);
                                array_push($resultArray,"no of rows affected in kol_clinical_trials : ".$kol_clinical_rows);

                                $num_rows=$this->identification->save_project_kols($kol_ids,$project_id);
                                array_push($resultArray,"no of rows inserted in project_kols : ".$num_rows);

                                $activityTypeCountIn=$this->identification->UpdateActivityTypeInKolEvent($project_id,"IN");
                                array_push($resultArray,"no of rows affected with activity_type = Organizing Committee : ".$activityTypeCountIn);

                                $activityTypeCountNotIn=$this->identification->UpdateActivityTypeInKolEvent($project_id,"NOT IN");
                                array_push($resultArray,"no of rows affected with activity_type =Speaking : ".$activityTypeCountNotIn);

                                foreach ($resultArray as $key => $value) {
                                    $arrDataDisply['data'] .= $value."<br/>";
//                                     echo $value."<br/>";
                                }
//                                 exit;
                            }
                        }
		}else{
		    $dataSetProjectId = $rowData['id'];
		    $getProjectKolIds = $this->identification->getProjectKolIds($rowData['id']);
			$projectVisibilityId = $rowData['id'];
			$data['updated_by'] = $this->session->userdata('user_id');
			$data['updated_on'] = date("Y-m-d H:i:s");
                        $data['name'] = $rowData['name'];
                        $data['description'] = $rowData['description'];
                        $data['year_range'] = $rowData['year_range'];
                        $data['id'] = $rowData['id'];
						$this->identification->updateProject($data);
                        $kol_ids=$rowData['kol_ids'];
                        if(!isset($kol_ids) && sizeof($kol_ids) == 0){
                            $kol_ids=explode(",",$kol_ids);
                        }
                        $disassociate_kol_ids=$rowData['assocciatedkolId'];
//                         $kol_ids=explode(",",$kol_ids);
                        $overwrite_association = $rowData['overwrite_association'];
		                if($projectVisibilityId!=''){
	                        $kolProArray = array();
	                        $kolProArray['project_id'] = $projectVisibilityId;
	                        $kolProArray['client_id'] = $rowData['client'];
	                        //                                 pr($kolProArray);
	                        $kol_project_visibility = $this->identification->updateKolsProjectVisibility($kolProArray);
	                        
	                        $getProjectKolIds = $this->identification->getProjectKolIds($rowData['id']);
	                        $kolClientArray = array();
	                        $kolClientArray['client_ids'] = $rowData['client'];
	                        $kolClientArray['kol_ids'] = $getProjectKolIds;
	                        $kols_client_visibility = $this->identification->saveKolsClientVisibility($kolClientArray);
	                        
	                        if(isset($disassociate_kol_ids) && sizeof($disassociate_kol_ids > 0)){
	                            $kolDeleteClientArray = array();
	                            $kolDeleteClientArray['client_ids'] = $rowData['client'];
	                            $kolDeleteClientArray['kol_ids'] = $disassociate_kol_ids;
	                            $kols_client_visibility = $this->identification->deleteKolsClientVisibility($kolDeleteClientArray);
	                        }
	                        
	                        $kolClientArray = array();
	                        $kolClientArray['client_ids'] = $rowData['client'];
	                        $kolClientArray['kol_ids'] = $kol_ids;
	                        $kols_client_visibility = $this->identification->saveKolsClientVisibility($kolClientArray);
	                        
                       	    }
                        $duplicate_kols_in_id_project=$this->identification->duplicateCheckProjectKols($kol_ids,$overwrite_association);
                        if($duplicate_kols_in_id_project==0){
                            $project_id=$data['id'];
                            $num_rows=$this->identification->save_project_kols($kol_ids,$project_id);
                            array_push($resultArray,"no of rows inserted in project_kols : ".$num_rows);
                            
                            $kol_ids = $this->identification->getProjectKolIds($rowData['id']);
                            
                            $data['yearRange'] = $this->identification->getProjectYearRange($project_id);
                            if((!empty($data['yearRange'][0]) || $data['yearRange'][0]!='') && (!empty($data['yearRange'][1]) || $data['yearRange'][1]!='')){
                                $startYear =  $data['yearRange'][0];
                                $endYear = $data['yearRange'][1];
                            }else{
                                $startYear =  0;
                                $endYear = 0;
                            }
                            $is_imported=$this->identification->updateKolIsImported($kol_ids);
                            array_push($resultArray,"<br/>no of rows updated : ".$is_imported);
//                             $kol_mem_rows=$this->identification->UpdatekolMembershipKolIds($kol_ids,$project_id);
//                             array_push($resultArray,"no of rows affected in kol_memberships : ".$kol_mem_rows);

//                             $kol_event_rows=$this->identification->UpdatekolEventKolIds($kol_ids,$project_id);
//                             array_push($resultArray,"no of rows affected in kol_events : ".$kol_event_rows);

                            $kol_pub_rows=$this->identification->UpdatekolPubKolIds($kol_ids,$project_id,$startYear,$endYear);
                            array_push($resultArray,"no of rows affected in kol_publications : ".$kol_pub_rows);

                            $kol_clinical_rows=$this->identification->UpdatekolClinicalTrialsKolIds($kol_ids,$project_id);
                            array_push($resultArray,"no of rows affected in kol_clinical_trials : ".$kol_clinical_rows);

                            $activityTypeCountIn=$this->identification->UpdateActivityTypeInKolEvent($project_id,"IN");
                            array_push($resultArray,"no of rows affected with activity_type = Organizing Committee : ".$activityTypeCountIn);

                            $activityTypeCountNotIn=$this->identification->UpdateActivityTypeInKolEvent($project_id,"NOT IN");
                            array_push($resultArray,"no of rows affected with activity_type =Speaking : ".$activityTypeCountNotIn);
                            
                            if((!empty($disassociate_kol_ids)) && sizeof($disassociate_kol_ids > 0)){
                                array_push($resultArray,"<br/>no of rows updated : ".$is_imported);
                                $kol_mem_rows=$this->identification->UpdateDisassociatedkolMembershipKolIds($disassociate_kol_ids,$project_id);
                                array_push($resultArray,"no of rows Disassociated in kol_memberships : ".$kol_mem_rows);
                                
                                $kol_event_rows=$this->identification->UpdateDisassociatedkolEventKolIds($disassociate_kol_ids,$project_id);
                                array_push($resultArray,"no of rows Disassociated in kol_events : ".$kol_event_rows);
                                
                                $kol_pub_rows=$this->identification->UpdateDisassociatedkolPubKolIds($disassociate_kol_ids,$project_id);
                                array_push($resultArray,"no of rows Disassociated in kol_publications : ".$kol_pub_rows);
                                
                                $kol_clinical_rows=$this->identification->UpdateDisassociatedkolClinicalTrialsKolIds($disassociate_kol_ids,$project_id);
                                array_push($resultArray,"no of rows Disassociated in kol_clinical_trials : ".$kol_clinical_rows);
                                
                                $num_rows=$this->identification->deleteProjectKols($disassociate_kol_ids,$project_id);
                                array_push($resultArray,"no of rows Disassociated in project_kols : ".$num_rows);
                            }
                            foreach ($resultArray as $key => $value) {
                                $arrDataDisply['data'] .= $value."<br/>";
//                                 echo $value."<br/>";
                            }
//                             exit;
                        }
		}
		$arrDataDisply['project_id'] = $dataSetProjectId;
		$arrDataDisply['status'] = true;
// 		pr($arrDataDisply);exit;
		echo json_encode($arrDataDisply);
// 		redirect(base_url()."identifications/list_projects");
	}
	
	/**
	 * Show edit project page
	 * @return html
	 */
	function edit_project($id){
		$arrClientList = $this->kol->getAllClients();
		$data['arrClientList'] = $arrClientList;
		$data['selectedClients'] = $this->identification->getClientProjects($id);
		$data['rowData'] = $this->identification->getProject($id);
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Edit Project Form Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Edit Project Form"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage']					= 'identification/project_form';
		$this->load->view('layouts/analyst_view',$data);
// 		$this->load->view('identification/project_form',$data);
	}
	
	/**
	 * Delete given project
	 * @return html
	 */
	function delete_project($id){
		
	}
	
	function home(){
		$data = array();
		$this->load->model('survey');
		$userId = $this->session->userdata('user_id');
		$projectIds = $this->identification->getUserProjectsIds($userId);
		if(count($projectIds) > 0){
			$data['projectId'] = $projectIds[0];
		}else{
			$data['projectId'] = $this->identification->getLatestProjectId();
		}
		$data['yearRange'] = $this->identification->getProjectYearRange($data['projectId']);
		$data['arrSurveys'] 							= $this->survey->getCompletedSurveys();
		$data['contentPage'] 							= 'identification/home_page';
		$this->load->view('layouts/client_view',$data);
	}
	
	
	function get_ranking_report($section = ''){
// 	    pr($_POST);exit;
	    $customePost = $this->input->post('custom_post');
	    $customePost = str_replace(";", "", $customePost);
	    $customePost = str_replace("[object Object]&", "", $customePost);
	    parse_str($customePost,$out);
	    ini_set("max_execution_time",0);
	    ini_set("memory_limit","-1");
	    
		$startTime = microtime(true);
		$data = array();
		$arrFilters = array();
		$arrFilters = $_POST;
		$arrFilters= array_merge($arrFilters,$out);
		
// 		var_dump($this->input->post("project"));exit;
		if($this->input->post("project") != false)
			$arrFilters['project'] = $this->input->post("project");
// 		else
// 			$arrFilters['project'] = 9;
// 		$keyword = $arrFilters['keywords'];
        $arrFilters['meshTermIds'] = $arrFilters['multi_keywords_id'];
		$arrFilters['keywords'] = $arrFilters['multi_keywords'];
		/* if($keyword != '')
			$arrFilters['keywords'][] = $keyword;
		foreach ($arrFilters['keywords'] as $str){
			$id = $this->identification->getTermIdByTermName($str);
			if($id != '')
				$termId[] = $id;
		}
		
		foreach($termId as $id){
			$termKeywords = $this->identification->getSubTermIdByTermId($id);
			$arrFilters['keywords'] = array_merge($arrFilters['keywords'],$termKeywords);
		} */
		$arrFilters['keywords'] = array_unique($arrFilters['keywords']);
		
		//$arrFilters['keywords'][] = "the";
		//$arrFilters['keywords'][] = "a";
		/*$weightages['wyn'] = 'yes';
		$weightages['assoc']['all'] = 10;
		$weightages['events']['all'] = 5;
		$weightages['events']['speaker'] = 0;
		$weightages['events']['orgcom'] = 0;
		$weightages['editorial']['all'] = 20;
		$weightages['expert']['all'] = 10;
		$weightages['pubs']['all'] = 0;
		$weightages['pubs']['lead'] = 40;
		$weightages['pubs']['ma'] = 10;
		$weightages['pubs']['fa'] = 0;
		$weightages['pubs']['sa'] = 0;
		$weightages['pubs']['la'] = 0;
		$weightages['trials']['all'] = 5;
		$weightages['guidlines']['all'] = 5;*/
		
		$arrAffsData = $this->identification->getKolsByAffiliationsCount($arrFilters);
		$arrKolIds = array_keys($arrAffsData);
		//pr($arrAffsData);
		
		$arrEventsData = $this->identification->getKolsByEventsCount($arrFilters);
		$arrKolIds = array_merge($arrKolIds,array_keys($arrEventsData));
		
		$arrPubsCounts = $this->identification->getKolPublicationCountsByAuthPos($arrFilters);
		$arrKolIds = array_merge($arrKolIds,array_keys($arrPubsCounts));
		//pr($arrPubsCounts);
		
		$arrGuidlinesCount= $this->identification->getKolGuidelinesCount($arrFilters);
		$arrKolIds = array_merge($arrKolIds,array_keys($arrGuidlinesCount));
		
		$arrTrialsCount= $this->identification->getKolTrialsCount($arrFilters);
		$arrKolIds = array_merge($arrKolIds,array_keys($arrTrialsCount));
		
		if($arrFilters['include_survey'] == 'on'){
			$arrInfluencesCount= $this->identification->getKolsByInfluencesCount($arrFilters);
			$arrKolIds = array_merge($arrKolIds,array_keys($arrInfluencesCount));
		}
		
		$arrFilters['category'] = 'kolIds';
		$arrKolIds = $this->identification->getKolCountsByCategory($arrFilters);
		
		//pr("Time Taken for featching data : ".(microtime(true)-$startTime));
		$startTime2 = microtime(true);
		//$arrKolIds = array_unique($arrKolIds);
		$arrKols = array();
		foreach($arrKolIds as $kolId => $row){
			$kolDetails = array();
			$kolDetails['id'] = $kolId;
			$kolDetails['unique_id'] = $row['unique_id'];
			$kolDetails['score'] = 0;
			$kolDetails['numevc'] = 0;
			$kolDetails['numtc'] = 0;
			$kolDetails['numic'] = 0;
			$kolDetails['salutation'] = $row['salutation'];
			$kolDetails['first_name'] = $row['first_name'];
			$kolDetails['middle_name'] = $row['middle_name'];
			$kolDetails['last_name'] = $row['last_name'];
			$kolDetails['profile_type'] = $row['profile_type'];
			if(isset($arrPubsCounts[$kolId])){
				$kolDetails = $arrPubsCounts[$kolId];
			}else{
				$kolDetails['numsa'] = 0;
				$kolDetails['numfa'] = 0;
				$kolDetails['numma'] = 0;
				$kolDetails['numla'] = 0;
				$kolDetails['leadc'] = 0;
				$kolDetails['nump'] = 0;
			}
			
			if(isset($arrEventsData[$kolId])){
				$kolDetails['salutation'] = $arrEventsData[$kolId]['salutation'];
				$kolDetails['first_name'] = $arrEventsData[$kolId]['first_name'];
				$kolDetails['middle_name'] = $arrEventsData[$kolId]['middle_name'];
				$kolDetails['last_name'] = $arrEventsData[$kolId]['last_name'];
				$kolDetails['profile_type'] = $arrEventsData[$kolId]['profile_type'];
				$kolDetails['numspc'] = $arrEventsData[$kolId]['numspc'];
				$kolDetails['numocc'] = $arrEventsData[$kolId]['numocc'];
				$kolDetails['numevc'] = $arrEventsData[$kolId]['numevc'];
			}else{
				$kolDetails['numspc'] = 0;
				$kolDetails['numocc'] = 0;
				$kolDetails['numevc'] = 0;
			}
			
			if(isset($arrTrialsCount[$kolId])){
				$kolDetails['salutation'] = $arrTrialsCount[$kolId]['salutation'];
				$kolDetails['first_name'] = $arrTrialsCount[$kolId]['first_name'];
				$kolDetails['middle_name'] = $arrTrialsCount[$kolId]['middle_name'];
				$kolDetails['last_name'] = $arrTrialsCount[$kolId]['last_name'];
				$kolDetails['profile_type'] = $arrTrialsCount[$kolId]['profile_type'];
				$kolDetails['numtc'] = $arrTrialsCount[$kolId]['numtc'];
			}else{
				$kolDetails['numtc'] = 0;
			}
			
			if(isset($arrAffsData[$kolId])){
				$kolDetails['salutation'] = $arrAffsData[$kolId]['salutation'];
				$kolDetails['first_name'] = $arrAffsData[$kolId]['first_name'];
				$kolDetails['middle_name'] = $arrAffsData[$kolId]['middle_name'];
				$kolDetails['last_name'] = $arrAffsData[$kolId]['last_name'];
				$kolDetails['profile_type'] = $arrAffsData[$kolId]['profile_type'];
				$kolDetails['numia'] = $arrAffsData[$kolId]['numia'];
				$kolDetails['numas'] = $arrAffsData[$kolId]['numas'];
				$kolDetails['numeb'] = $arrAffsData[$kolId]['numeb'];
				$kolDetails['numec'] = $arrAffsData[$kolId]['numec'];
				$kolDetails['numgc'] = $arrAffsData[$kolId]['numgc'];
				$kolDetails['numed'] = $arrAffsData[$kolId]['numed'];
				
			}else{
				$kolDetails['numia'] = 0;
				$kolDetails['numas'] = 0;
				$kolDetails['numeb'] = 0;
				$kolDetails['numec'] = 0;
				$kolDetails['numgc'] = 0;
				$kolDetails['numed'] = 0;
			}
			/* if(isset($arrGuidlinesCount[$kolId])){
				$kolDetails['salutation'] = $arrGuidlinesCount[$kolId]['salutation'];
				$kolDetails['first_name'] = $arrGuidlinesCount[$kolId]['first_name'];
				$kolDetails['middle_name'] = $arrGuidlinesCount[$kolId]['middle_name'];
				$kolDetails['last_name'] = $arrGuidlinesCount[$kolId]['last_name'];
				$kolDetails['profile_type'] = $arrGuidlinesCount[$kolId]['profile_type'];
				$kolDetails['numgc'] = $arrGuidlinesCount[$kolId]['numgc'];
			}else
				$kolDetails['numgc'] = 0; */
				
			if(isset($arrInfluencesCount[$kolId])){
				$kolDetails['salutation'] = $arrInfluencesCount[$kolId]['salutation'];
				$kolDetails['first_name'] = $arrInfluencesCount[$kolId]['first_name'];
				$kolDetails['middle_name'] = $arrInfluencesCount[$kolId]['middle_name'];
				$kolDetails['last_name'] = $arrInfluencesCount[$kolId]['last_name'];
				$kolDetails['profile_type'] = $arrInfluencesCount[$kolId]['profile_type'];
				$kolDetails['numic'] = $arrInfluencesCount[$kolId]['numic'];
			}else
				$kolDetails['numic'] = 0;
			
				
			//pr($kolDetails);
				//pr($kolDetails);
				if($arrFilters['wyn'] == 'yes'){
				    
				    //Apply Events weightages
				    if($arrFilters['events_all'] == 0 && $arrFilters['events_speaker'] == 0 && $arrFilters['events_orgcom'] == 0 && $arrFilters['affiliations_all'] == 0 && $arrFilters['guideline_all'] == 0 && $arrFilters['expert_all'] == 0 && $arrFilters['editorial_all'] == 0 && $arrFilters['assoc_all'] == 0 && $arrFilters['industry_all'] == 0 && $arrFilters['pubs_all'] == 0 && $arrFilters['pubs_lead'] == 0 && $arrFilters['pubs_ma'] == 0 && $arrFilters['pubs_sa'] == 0 && $arrFilters['pubs_fa'] == 0 && $arrFilters['pubs_la'] == 0 && $arrFilters['trials_all'] == 0 && $arrFilters['surveys_all'] == 0){
				        $kolDetails['score'] =  $kolDetails['nump'];
				        $kolDetails['score'] += $kolDetails['numed'];
				        $kolDetails['score'] += $kolDetails['numevc'];
				        $kolDetails['score'] += $kolDetails['numtc'];
				        $kolDetails['score'] += $kolDetails['numic'];
				    }else{
				        if($arrFilters['events_all'] != 0)
				            $kolDetails['score'] += (($kolDetails['numevc']/100)*$arrFilters['events_all']);
			            else{
			                if($arrFilters['events_speaker'] != 0)
			                    $kolDetails['score'] += (($kolDetails['numspc']/100)*$arrFilters['events_speaker']);
			                    if($arrFilters['events_orgcom'] != 0)
			                        $kolDetails['score'] += (($kolDetails['numocc']/100)*$arrFilters['events_orgcom']);
			            }
				    
    				    
				        if($arrFilters['affiliations_all'] != 0)
				            $kolDetails['score'] += (($kolDetails['numed']/100)*$arrFilters['affiliations_all']);
			            else{
			                if($arrFilters['guideline_all'] != 0)
			                    $kolDetails['score'] += (($kolDetails['numgc']/100)*$arrFilters['guideline_all']);
		                    if($arrFilters['expert_all'] != 0)
		                        $kolDetails['score'] += (($kolDetails['numec']/100)*$arrFilters['expert_all']);
	                        if($arrFilters['editorial_all'] != 0)
	                            $kolDetails['score'] += (($kolDetails['numeb']/100)*$arrFilters['editorial_all']);
                            if($arrFilters['assoc_all'] != 0)
                                $kolDetails['score'] += (($kolDetails['numas']/100)*$arrFilters['assoc_all']);
                            if($arrFilters['industry_all'] != 0)
                                $kolDetails['score'] += (($kolDetails['numia']/100)*$arrFilters['industry_all']);
				            }
				    //Apply Industry Affliations weightages
				    // 				if($arrFilters['industry_all'] != 0)
				        // 					$kolDetails['score'] += (($kolDetails['numia']/100)*$arrFilters['industry_all']);
				    
				    
				    //Apply Association/Socities weightages
				    // 				if($arrFilters['assoc_all'] != 0)
				        // 					$kolDetails['score'] += (($kolDetails['numas']/100)*$arrFilters['assoc_all']);
				    
				    //Apply Editorial Boards weightages
				    // 				if($arrFilters['editorial_all'] != 0)
				        // 					$kolDetails['score'] += (($kolDetails['numeb']/100)*$arrFilters['editorial_all']);
				        // 				else{
				    
				        // 				}
				    
				    //Apply Expert Center weightages
				    // 				if($arrFilters['expert_all'] != 0)
				        // 					$kolDetails['score'] += (($kolDetails['numec']/100)*$arrFilters['expert_all']);
				        // 				else{
				    
				        // 				}
				    
				    //Apply Publications weightages
				    
    			        if($arrFilters['pubs_all'] != 0)
    			            $kolDetails['score'] += (($kolDetails['nump']/100)*$arrFilters['pubs_all']);
			            else{
			                if($arrFilters['pubs_lead'] != 0)
			                    $kolDetails['score'] += (($kolDetails['leadc']/100)*$arrFilters['pubs_lead']);
		                    if($arrFilters['pubs_ma'] != 0)
		                        $kolDetails['score'] += (($kolDetails['numma']/100)*$arrFilters['pubs_ma']);
	                        if($arrFilters['pubs_fa'] != 0)
	                            $kolDetails['score'] += (($kolDetails['numfa']/100)*$arrFilters['pubs_fa']);
                            if($arrFilters['pubs_sa'] != 0)
                                $kolDetails['score'] += (($kolDetails['numsa']/100)*$arrFilters['pubs_sa']);
                            if($arrFilters['pubs_la'] != 0)
                                $kolDetails['score'] += (($kolDetails['numla']/100)*$arrFilters['pubs_la']);
    			            }
				    //Apply Trials weightages
				    if($arrFilters['trials_all'] != 0)
				        $kolDetails['score'] += (($kolDetails['numtc']/100)*$arrFilters['trials_all']);
// 				        else
// 				            $kolDetails['score'] += $kolDetails['numtc'];
				            
				            
				            //Apply Guidelines weightages
				            // 				if($arrFilters['guideline_all'] != 0)
				                // 					$kolDetails['score'] += (($kolDetails['numgc']/100)*$arrFilters['guideline_all']);
				                // 				else{
				            
				                // 				}
				            
				            //Apply Surveys weightages
				            if($arrFilters['surveys_all'] != 0)
				                $kolDetails['score'] += (($kolDetails['numic']/100)*$arrFilters['surveys_all']);
// 				                else
// 				                    $kolDetails['score'] += $kolDetails['numic'];
				    }
				}else{
				$kolDetails['score'] =  $kolDetails['nump'];
				$kolDetails['score'] += $kolDetails['numed'];
				$kolDetails['score'] += $kolDetails['numevc'];
				$kolDetails['score'] += $kolDetails['numtc'];
				$kolDetails['score'] += $kolDetails['numic'];
			}
			if($row['middle_name'] == ''){
			    $kolDetails['name'] = $row['first_name'].' '.$row['last_name'];
			}else{
			    $kolDetails['name'] = $row['first_name'].' '.$row['middle_name'].' '.$row['last_name'];
			}
//             $kolDetails['name'] = $this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);
			//$kolDetails['name'] = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
// 			if($kolDetails['profile_type'] != 'Basic' && $kolDetails['profile_type'] != '0' && $kolDetails['profile_type'] != '')
				$kolDetails['micro'] = "1";
// 			else
// 				$kolDetails['micro'] = "0";
			$arrKols[] = $kolDetails;
		}
		$arrKols = $this->common_helpers->array_multi_subsort($arrKols, 'score','arsort');
		//pr("Time Taken for Preparing data : ".(microtime(true)-$startTime2));
		$startTime3 = microtime(true);
		//pr("Time Taken for Sorting data : ".(microtime(true)-$startTime3));
		//$data['arrData'] = $arrData;
		//pr($arrData);
		//$this->load->view('identification/view_ranking_report',$data);
		
		foreach($arrKols as $rank => $rowData)
			$arrKols[$rank]['rank'] = $rank+1;
		
		$count				= sizeof($arrKols);				
		if( $count >0 ){ 
			$total_pages    = ceil($count/$limit); 
		}else{ 
			$total_pages 	= 0; 
		} 
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $arrKols;  
		//pr($arrKolDetailResult1);
		if($section == ''){
			//ob_start('ob_gzhandler');
			echo json_encode($arrKols);
		}
		else{
			$i=0;
			$arrEventsData = array();
			$arrAffsData = array();
			$arrPublicationsData = array();
			$arrTrialsData = array();
			$arrGuidelineData = array();
			$arrInfluenceData = array();
			foreach($arrKols as $kol){
				$topKolNames[] = $kol['name'];
				$arrEventsData[] = (int)$kol['numevc'];
				$arrAffsData[] = (int)($kol['numed']);
				$arrPublicationsData[] = (int)$kol['nump'];
				$arrTrialsData[] = (int)$kol['numtc'];
				$arrGuidelineData[] = (int)$kol['numgc'];
				$arrInfluenceData[] = (int)$kol['numic'];
				$i++;
				if($i == 10)
					break;
			}
			$data = array();
			$data[]=array_values($topKolNames);
			$data[]=$arrEventsData;
			$data[]=$arrAffsData;
			$data[]=$arrPublicationsData;
			$data[]=$arrTrialsData;
			$data[]=$arrGuidelineData;
			$data[]=$arrInfluenceData;
			ob_start('ob_gzhandler');
			echo json_encode($data);
		}
		$descp = 'Visited Identification Ranking Report';
		if($section == 'chart'){
		    $descp = 'Visited Identification Chart';
		}
		//Add Log activity
		$arrLogDetails = array(
		    'type' => VIEW_RECORD,
		    'description' => $descp,
		    'status' => STATUS_SUCCESS,
		    'transaction_name' => $descp
		);
		$this->config->set_item('log_details', $arrLogDetails);
		
	}
	
	function load_filters(){
		$data = array();
		$arrFilters = array();
		$arrFilters = $_POST;
		$customePost = $this->input->post('custom_post');
		$customePost = str_replace(";", "", $customePost);
		$customePost = str_replace("[object Object]&", "", $customePost);
		parse_str($customePost,$out);
		ini_set("max_execution_time",0);
		ini_set("memory_limit","-1");
		
		$startTime = microtime(true);
		$data = array();
		$arrFilters = array();
		$arrFilters = $_POST;
		$savedFilterNotInJson=false;
		// 		pr($arrFilters);
		// 		pr($out);
		$arrFilters= array_merge($arrFilters,$out);
		if(!isset($arrFilters['project']))
		    $arrFilters['project']=1;
		
		$data['arrProjects'] = $this->identification->listProjects();
// 		echo $this->db->last_query();exit;
		$arrFilters['category'] = 'specialty';
		$data['arrKolsBySpecialtyCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		$arrFilters['category'] = 'country';
		$data['arrKolsByCountryCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		$arrFilters['category'] = 'state';
		$data['arrKolsByStateCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		$arrFilters['category'] = 'region';
		$data['arrKolsByRegionCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		$arrFilters['category'] = 'city';
		$data['arrKolsByCityCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		$arrFilters['category'] = 'industry';
		$data['arrKolsByIndustryCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'org_ids';
		$data['arrKolsByOrgCount'] = $this->identification->getKolCountsByCategory($arrFilters);
	//	echo $this->db->last_query();
		$arrFilters['docount'] = true;
		$arrFilters['category'] = 'specialty';
		$data['allSpecialtyCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'country';
		$data['allCountryCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'state';
		$data['allStateCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'region';
		$data['allRegionCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'city';
		$data['allCityCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'industry';
		$data['allIndustryCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		$arrFilters['category'] = 'org_ids';
		$data['allOrgCount'] = $this->identification->getKolCountsByCategory($arrFilters);
		
		//selected filters
		$this->load->model('specialty');
		$this->load->model('Country_helper');
		if($arrFilters['specialty'] != '')
			$data['selectedSpecialties']					= $this->specialty->getSpecialtiesById($arrFilters['specialty']);
		foreach($arrFilters['region'] as $id){
			$data['selectedRegions'][$id] = $id;
		}
		if($arrFilters['country'] != '')
			$data['selectedCountries']					= $this->Country_helper->getCountryNameById($arrFilters['country']);
		
		if($arrFilters['state'] != '')
		    $data['selectedStates']					= $this->Country_helper->getStateNameById($arrFilters['state']);
		
		if($arrFilters['city'] != '')
			$data['selectedCities']					= $this->Country_helper->getCityNameById($arrFilters['city']);
		//$data['selectedStates']						= $this->Country_helper->getStateNameById($arrStates);
		if($arrFilters['industry'] != '')
			$data['selectedIndustries']					= $this->identification->getInstituteNameById($arrFilters['industry']);
		
		if($arrFilters['org_ids'] != '')
		    $data['selectedOrgs']					= $this->organization->getOrgsById($arrFilters['org_ids']);
		    $data['customFilters']						= $this->identification->getAllCustomFilterByUser($this->session->userdata('user_id'));
		$data['customFilters']						= $this->identification->getAllCustomFilterByUser($this->session->userdata('user_id'));
		$data['filters'] = $arrFilters;
		$data['yearRange'] = $this->identification->getProjectYearRange($arrFilters['project']);
		if(IS_IPAD_REQUEST){
		    $this->load->view(IPAD_APP_FOLDER.'/identification/identification_filtres_li_style',$data);
		}else{
		  $this->load->view('identification/identification_filtres_li_style',$data);
		}
	}
	
	function load_columns_settings(){
		$this->load->view('identification/columns_settings');
	}
	
	function load_trends_data(){
		$trendsData = array();
		$arrFilters = array();
		$arrFilters = $_POST;
		$customePost = $this->input->post('custom_post');
		$customePost = str_replace(";", "", $customePost);
		$customePost = str_replace("[object Object]&", "", $customePost);
		parse_str($customePost,$out);
		ini_set("max_execution_time",0);
		ini_set("memory_limit","-1");
		
		$startTime = microtime(true);
		$data = array();
		$arrFilters = array();
		$arrFilters = $_POST;
		$savedFilterNotInJson=false;
		// 		pr($arrFilters);
		// 		pr($out);
		$arrFilters= array_merge($arrFilters,$out);
		$arrFilters['meshTermIds'] = $arrFilters['multi_keywords_id'];
		$arrFilters['keywords'] = $arrFilters['multi_keywords'];
		 $arrFilters['keywords'] = array_unique($arrFilters['keywords']);
		//$arrFilters['keywords'][] = "the";
		//$arrFilters['keywords'][] = "a";
		$arrTrends['last5']['max'] = date("Y");
		$arrTrends['last5']['min'] = $arrTrends['last5']['max'] - 5;
		$arrTrends['last3']['max'] = date("Y");
		$arrTrends['last3']['min'] = $arrTrends['last3']['max'] - 3;
		$arrTrends['last1']['max'] = date("Y");
		$arrTrends['last1']['min'] = $arrTrends['last1']['max'] - 1;
		unset($arrFilters['pubs_year_range']);
		unset($arrFilters['events_year_range']);
		unset($arrFilters['trials_year_range']);
		unset($arrFilters['editorial_year_range']);
		unset($arrFilters['assoc_year_range']);
		unset($arrFilters['industry_year_range']);
		unset($arrFilters['guideline_year_range']);
		unset($arrFilters['expert_year_range']);
		unset($arrFilters['aff_year_range']);
		foreach($arrTrends as $key => $arrYears){
			$arrFilters['year_range'] = $arrYears['min'].','.$arrYears['max'];
			$arrAffsData = $this->identification->getKolsByAffiliationsCount($arrFilters);
			$arrKolIds = array_keys($arrAffsData);
			//pr($arrAffsData);
			
			$arrEventsData = $this->identification->getKolsByEventsCount($arrFilters);
			$arrKolIds = array_merge($arrKolIds,array_keys($arrEventsData));
			
			$arrPubsCounts = $this->identification->getKolPublicationCountsByAuthPos($arrFilters);
			$arrKolIds = array_merge($arrKolIds,array_keys($arrPubsCounts));
			//pr($arrPubsCounts);
			
			$arrGuidlinesCount= $this->identification->getKolGuidelinesCount($arrFilters);
			$arrKolIds = array_merge($arrKolIds,array_keys($arrGuidlinesCount));
			
			$arrTrialsCount= $this->identification->getKolTrialsCount($arrFilters);
			$arrKolIds = array_merge($arrKolIds,array_keys($arrTrialsCount));
			
			if($arrFilters['include_survey'] == 'on'){
				$arrInfluencesCount= $this->identification->getKolsByInfluencesCount($arrFilters);
				$arrKolIds = array_merge($arrKolIds,array_keys($arrInfluencesCount));
			}
			
			$arrFilters['category'] = 'kolIds';
			$arrKolIds = $this->identification->getKolCountsByCategory($arrFilters);
			//$arrKolIds = array_unique($arrKolIds);
			$arrData = array();
			foreach($arrKolIds as $kolId => $row){
				$kolDetails = array();
				$kolDetails['id'] = $kolId;
				$kolDetails['score'] = 0;
				$kolDetails['numevc'] = 0;
				$kolDetails['numtc'] = 0;
				$kolDetails['numic'] = 0;
				$kolDetails['salutation'] = $row['salutation'];
				$kolDetails['first_name'] = $row['first_name'];
				$kolDetails['middle_name'] = $row['middle_name'];
				$kolDetails['last_name'] = $row['last_name'];
				$kolDetails['profile_type'] = $row['profile_type'];
				$kolDetails['unique_id'] = $row['unique_id'];
				if(isset($arrPubsCounts[$kolId])){
					$kolDetails = $arrPubsCounts[$kolId];
				}else{
					$kolDetails['numsa'] = 0;
					$kolDetails['numfa'] = 0;
					$kolDetails['numma'] = 0;
					$kolDetails['numla'] = 0;
					$kolDetails['leadc'] = 0;
					$kolDetails['nump'] = 0;
				}
				
				if(isset($arrEventsData[$kolId])){
					$kolDetails['salutation'] = $arrEventsData[$kolId]['salutation'];
					$kolDetails['first_name'] = $arrEventsData[$kolId]['first_name'];
					$kolDetails['middle_name'] = $arrEventsData[$kolId]['middle_name'];
					$kolDetails['last_name'] = $arrEventsData[$kolId]['last_name'];
					$kolDetails['profile_type'] = $arrEventsData[$kolId]['profile_type'];
					$kolDetails['numspc'] = $arrEventsData[$kolId]['numspc'];
					$kolDetails['numocc'] = $arrEventsData[$kolId]['numocc'];
					$kolDetails['numevc'] = $arrEventsData[$kolId]['numevc'];
				}else{
					$kolDetails['numspc'] = 0;
					$kolDetails['numocc'] = 0;
					$kolDetails['numevc'] = 0;
				}
				
				if(isset($arrTrialsCount[$kolId])){
					$kolDetails['salutation'] = $arrTrialsCount[$kolId]['salutation'];
					$kolDetails['first_name'] = $arrTrialsCount[$kolId]['first_name'];
					$kolDetails['middle_name'] = $arrTrialsCount[$kolId]['middle_name'];
					$kolDetails['last_name'] = $arrTrialsCount[$kolId]['last_name'];
					$kolDetails['profile_type'] = $arrTrialsCount[$kolId]['profile_type'];
					$kolDetails['numtc'] = $arrTrialsCount[$kolId]['numtc'];
				}else{
					$kolDetails['numtc'] = 0;
				}
				
				if(isset($arrAffsData[$kolId])){
					$kolDetails['salutation'] = $arrAffsData[$kolId]['salutation'];
					$kolDetails['first_name'] = $arrAffsData[$kolId]['first_name'];
					$kolDetails['middle_name'] = $arrAffsData[$kolId]['middle_name'];
					$kolDetails['last_name'] = $arrAffsData[$kolId]['last_name'];
					$kolDetails['profile_type'] = $arrAffsData[$kolId]['profile_type'];
					$kolDetails['numia'] = $arrAffsData[$kolId]['numia'];
					$kolDetails['numas'] = $arrAffsData[$kolId]['numas'];
					$kolDetails['numeb'] = $arrAffsData[$kolId]['numeb'];
					$kolDetails['numec'] = $arrAffsData[$kolId]['numec'];
					$kolDetails['numgc'] = $arrAffsData[$kolId]['numgc'];
					$kolDetails['numed'] = $arrAffsData[$kolId]['numed'];
					
				}else{
				    $kolDetails['numia'] = 0;
				    $kolDetails['numas'] = 0;
				    $kolDetails['numeb'] = 0;
				    $kolDetails['numec'] = 0;
				    $kolDetails['numgc'] = 0;
				    $kolDetails['numed'] = 0;
				}
// 				if(isset($arrGuidlinesCount[$kolId])){
// 					$kolDetails['salutation'] = $arrGuidlinesCount[$kolId]['salutation'];
// 					$kolDetails['first_name'] = $arrGuidlinesCount[$kolId]['first_name'];
// 					$kolDetails['middle_name'] = $arrGuidlinesCount[$kolId]['middle_name'];
// 					$kolDetails['last_name'] = $arrGuidlinesCount[$kolId]['last_name'];
// 					$kolDetails['profile_type'] = $arrGuidlinesCount[$kolId]['profile_type'];
// 					$kolDetails['numgc'] = $arrGuidlinesCount[$kolId]['numgc'];
// 				}else
// 					$kolDetails['numgc'] = 0;
					
				if(isset($arrInfluencesCount[$kolId])){
					$kolDetails['salutation'] = $arrInfluencesCount[$kolId]['salutation'];
					$kolDetails['first_name'] = $arrInfluencesCount[$kolId]['first_name'];
					$kolDetails['middle_name'] = $arrInfluencesCount[$kolId]['middle_name'];
					$kolDetails['last_name'] = $arrInfluencesCount[$kolId]['last_name'];
					$kolDetails['profile_type'] = $arrInfluencesCount[$kolId]['profile_type'];
					$kolDetails['numic'] = $arrInfluencesCount[$kolId]['numic'];
				}else
					$kolDetails['numic'] = 0;
					
				//pr($kolDetails);
				if($arrFilters['wyn'] == 'yes'){
					//Apply Events weightages
				    if($arrFilters['events_all'] == 0 && $arrFilters['events_speaker'] == 0 && $arrFilters['events_orgcom'] == 0 && $arrFilters['affiliations_all'] == 0 && $arrFilters['guideline_all'] == 0 && $arrFilters['expert_all'] == 0 && $arrFilters['editorial_all'] == 0 && $arrFilters['assoc_all'] == 0 && $arrFilters['industry_all'] == 0 && $arrFilters['pubs_all'] == 0 && $arrFilters['pubs_lead'] == 0 && $arrFilters['pubs_ma'] == 0 && $arrFilters['pubs_sa'] == 0 && $arrFilters['pubs_fa'] == 0 && $arrFilters['pubs_la'] == 0 && $arrFilters['trials_all'] == 0 && $arrFilters['surveys_all'] == 0){
				        $kolDetails['score'] =  $kolDetails['nump'];
				        $kolDetails['score'] += $kolDetails['numed'];
				        $kolDetails['score'] += $kolDetails['numevc'];
				        $kolDetails['score'] += $kolDetails['numtc'];
				        $kolDetails['score'] += $kolDetails['numic'];
				    }else{
				        //Apply Event weightages
				        if($arrFilters['events_all'] != 0)
				            $kolDetails['score'] += (($kolDetails['numevc']/100)*$arrFilters['events_all']);
			            else{
			                if($arrFilters['events_speaker'] != 0)
			                    $kolDetails['score'] += (($kolDetails['numspc']/100)*$arrFilters['events_speaker']);
			                    if($arrFilters['events_orgcom'] != 0)
			                        $kolDetails['score'] += (($kolDetails['numocc']/100)*$arrFilters['events_orgcom']);
			            }
			            //Apply Affiliations weightages
			            if($arrFilters['affiliations_all'] != 0)
			                $kolDetails['score'] += (($kolDetails['numed']/100)*$arrFilters['affiliations_all']);
		                else{
		                    if($arrFilters['guideline_all'] != 0)
		                        $kolDetails['score'] += (($kolDetails['numgc']/100)*$arrFilters['guideline_all']);
		                        if($arrFilters['expert_all'] != 0)
		                            $kolDetails['score'] += (($kolDetails['numec']/100)*$arrFilters['expert_all']);
		                            if($arrFilters['editorial_all'] != 0)
		                                $kolDetails['score'] += (($kolDetails['numeb']/100)*$arrFilters['editorial_all']);
		                                if($arrFilters['assoc_all'] != 0)
		                                    $kolDetails['score'] += (($kolDetails['numas']/100)*$arrFilters['assoc_all']);
		                                    if($arrFilters['industry_all'] != 0)
		                                        $kolDetails['score'] += (($kolDetails['numia']/100)*$arrFilters['industry_all']);
		                }
		                //Apply Publications weightages
		                
		                if($arrFilters['pubs_all'] != 0)
		                    $kolDetails['score'] += (($kolDetails['nump']/100)*$arrFilters['pubs_all']);
	                    else{
	                        if($arrFilters['pubs_lead'] != 0)
	                            $kolDetails['score'] += (($kolDetails['leadc']/100)*$arrFilters['pubs_lead']);
	                            if($arrFilters['pubs_ma'] != 0)
	                                $kolDetails['score'] += (($kolDetails['numma']/100)*$arrFilters['pubs_ma']);
	                                if($arrFilters['pubs_fa'] != 0)
	                                    $kolDetails['score'] += (($kolDetails['numfa']/100)*$arrFilters['pubs_fa']);
	                                    if($arrFilters['pubs_sa'] != 0)
	                                        $kolDetails['score'] += (($kolDetails['numsa']/100)*$arrFilters['pubs_sa']);
	                                        if($arrFilters['pubs_la'] != 0)
	                                            $kolDetails['score'] += (($kolDetails['numla']/100)*$arrFilters['pubs_la']);
	                    }
	                    //Apply Trial weightages
	                    if($arrFilters['trials_all'] != 0)
	                        $kolDetails['score'] += (($kolDetails['numtc']/100)*$arrFilters['trials_all']);
				    }
			    }else{
			        $kolDetails['score'] =  $kolDetails['nump'];
			        $kolDetails['score'] += $kolDetails['numed'];
			        $kolDetails['score'] += $kolDetails['numevc'];
			        $kolDetails['score'] += $kolDetails['numtc'];
			        $kolDetails['score'] += $kolDetails['numic'];
			    }
				
				$arrData[$kolId] = $kolDetails;
			}
		
			uasort($arrData,"sortbykey");
			$trendsData[$key] = $arrData;
		}
		$arrKols = array();
		$last5Ranks = array_keys($trendsData['last5']);
		$last3Ranks = array_keys($trendsData['last3']);
		$last1Ranks = array_keys($trendsData['last1']);
		$last3 = count($last3Ranks);
		$last1 = count($last1Ranks);
		$arrKolIds = array();
		foreach($trendsData['last5'] as $kolId => $row){
			$kolDetails = array();
			$arrKolIds[] = $kolId;
			$kolDetails['id'] = $kolId;
			$kolDetails['unique_id'] = $row["unique_id"];
			if($row['middle_name'] == ''){
			 $kolDetails['name'] = $row['first_name'].' '.$row['last_name'];
			}else{
			 $kolDetails['name'] = $row['first_name'].' '.$row['middle_name'].' '.$row['last_name'];
			}
			//$kolDetails['micro'] = "<label><div class='tooltip-demo tooltop-right microViewIcon Male' onclick=\"viewKolMicroProfile('".$kolDetails['id']."',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
			if($row['profile_type'] != 'Basic' && $row['profile_type'] != '0' && $row['profile_type'] != '')
				$kolDetails['micro'] = "<label><div class='tooltip-demo tooltop-right microViewIcon Male' onclick=\"viewKolMicroProfile('".$kolDetails['id']."',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
			else
				$kolDetails['micro'] = "<label><div class='tooltip-demo tooltop-right requestProfile sprite_iconSet' onclick=\"addNewKolProfile('".$kolDetails['id']."',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Request Profile\">&nbsp;</a></div></label>";
			$kolDetails['last5'] = array_search($kolId,$last5Ranks)+1;
			if(array_search($kolId,$last1Ranks) !== false)
				$kolDetails['last3'] = array_search($kolId,$last3Ranks)+1;
			else{
				$last3++;
				$kolDetails['last3'] = $last3;
			}
			
			$last3Text = "Up";
			$last3TextChange = "rankUp";
			if($kolDetails['last3'] > $kolDetails['last5']){
				$last3Text = "Down";
				$last3TextChange = "rankDown";
			}
			if($kolDetails['last3'] == $kolDetails['last5']){
				$last3Text = "No Change";
				$last3TextChange = "rankEqual";
			}
			$kolDetails['last3_text'] = "<span style='width: 35px;display: inline-block;'>".$kolDetails['last3']."</span><span class='".$last3TextChange."'>&nbsp;</span>&nbsp;&nbsp;".$last3Text;

			if(array_search($kolId,$last1Ranks) !== false)
				$kolDetails['last1'] = array_search($kolId,$last1Ranks)+1;
			else{
				$last1++;
				$kolDetails['last1'] = $last1;
			}
			$last1Text = "Up";
			$last1TextChange = "rankUp";
			if($kolDetails['last1'] > $kolDetails['last3']){
				$last1Text = "Down";
				$last1TextChange = "rankDown";
			}
			if($kolDetails['last1'] == $kolDetails['last3']){
				$last1Text = "No Change";
				$last1TextChange = "rankEqual";
			}
			$kolDetails['last1_text'] = "<span style='width: 35px;display: inline-block;'>".$kolDetails['last1']."</span><span class='".$last1TextChange."'>&nbsp;</span>&nbsp;&nbsp;".$last1Text;
			$kolDetails['last5_score'] = $row['score'];
			$kolDetails['last3_score'] = $trendsData['last3'][$kolId]['score'];
			$kolDetails['last1_score'] = $trendsData['last1'][$kolId]['score'];
			
			$arrKols[] = $kolDetails;
		}
		$count				= sizeof($arrKols);				
		if( $count >0 ){ 
			$total_pages    = ceil($count/$limit); 
		}else{ 
			$total_pages 	= 0; 
		} 
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $arrKols;  
		//pr($arrKols);
		$data = array();
		ob_start('ob_gzhandler');
		//Add Log activity
		$arrLogDetails = array(
		    'type' => VIEW_RECORD,
		    'description' => "Visited Trends Data Page",
		    'status' => STATUS_SUCCESS,
		    'transaction_name' => "View Trends Data Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		
		echo json_encode($arrKols);
		
	}
	
	/**
	 * Parse the uploaded xls from all the sheet, and map and save the data to respective tables
	 * @return 
	 */
	function import_id_project($id){
// 	    ini_set('display_errors', 1);
// 	    error_reporting(E_ALL);
// 	    ini_set('memory_limit',"-1");
// 	    ini_set("max_execution_time",0);
		$projectId = $id;
		//$userId = 11;
		$clientId = 1;
		$userId						= $this->session->userdata('user_id');
		//$clientId					= $this->session->userdata('client_id');
		$isFileUploaded = false;
		$fileInfo 					= pathinfo($_FILES["file_name"]['name']);
		// Location of the folder where all the Uploaded Excel documents will be stored
		$folderLocation 			= $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/idprojects/uploaded/";
		// Generate the Random Text, which will be used to store as FILE NAME, on the server
		// This will ensure that we won't be over-writing any files on the server, even by mistake, while importing
		$randomText					= random_string('unique', 20);
		$uploadedFile 				= $folderLocation . $randomText . "." . $fileInfo['extension'];
		if($_FILES["file_name"]['name']!= null){
			//Proceed only if the uploaded file if of type 'xls' or 'xlsx
			if($fileInfo['extension']=='xls' || $fileInfo['extension']=='xlsx'){
				// Move the Uploaded file to predefined location on server with constructed new name
				if(move_uploaded_file($_FILES['file_name']['tmp_name'], $uploadedFile)) {
					$isFileUploaded = true;
				}
			}
		}
		$file1 = $randomText;
		if(!$isFileUploaded)
			exit;
		
		$this->load->plugin('excelReader/reader2');
		$this->load->model('Event_helper');
		$this->load->model('Country_helper');
		$this->load->model('Specialty');
		$arrSalutations				= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrEventTypes		= $this->Event_helper->getAllConferenceEventTypes();
		$arrSessionTypes	= $this->Event_helper->getAllConferenceSessionTypes();
		$arrCountries 		= $this->Country_helper->listCountries();
		$arrStates			= $this->Country_helper->listStates();
		$arrCities			= $this->Country_helper->listCities();
		$arrEventOrganizerTypes   = $this->Event_helper->getOrganizerTypes();
		$arrEventSponsorTypes  = $this->Event_helper->getSponsorTypes();
// 		$arrEventRoles = $this->Event_helper->getEventRoles();
		$arrSpecialitys					= $this->Specialty->getAllSpecialties();
		/*$folderLocation 			= $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/idprojects/uploaded/";
		
		$file1 = "Straumann_Expert_Identification_Sample_Report.xls";
		$uploadedFile = $folderLocation."".$file1;*/
	
		$reader				=	new Spreadsheet_Excel_Reader($uploadedFile, true, 'utf-8');
		// Dump the EXCEL data for debugging
		//Prepare the data required fileds
		$profile_type = 'Aissel Analyst';
		//To Read the shhet name and its index
		foreach ($reader->boundsheets as $k=>$sheet){
			/**
			 * The EXCEL file information is available as an array of SHEETS.
			 * Each sheet information is available as a two dimensional array or ROW AND COLUMN
			 * Example: The First cell of the First Sheet can be accessed as
			 * $reader->sheets[1]["cells"][1][1]	== $reader->sheets[SHEET_NUMBER]["cells"][ROW_NUMBER][COLUMN_NUMBER]
			 */
		//	pr($sheet);
			// Start of processing the sheet - "Professional Info"
			if((trim($sheet['name'])=='Professional Info') || (trim($sheet['name'])=='Prof_Info')){
				//echo "started personal info<br />";
				//Check the Professional Info Header Format
				$row = 1;
				//pr($reader->sheets[$k]["cells"][$row]);
				 if(
				    trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				    trim($reader->sheets[$k]["cells"][$row][2])!="Salutation" ||
				    trim($reader->sheets[$k]["cells"][$row][3])!="KOL Name" ||
				    trim($reader->sheets[$k]["cells"][$row][4])!="First Name" ||
				    trim($reader->sheets[$k]["cells"][$row][5])!="Middle Name" ||
				    trim($reader->sheets[$k]["cells"][$row][6])!="Last Name" ||
				    trim($reader->sheets[$k]["cells"][$row][7])!="Suffix" ||
				    trim($reader->sheets[$k]["cells"][$row][8])!="Gender" ||
				    trim($reader->sheets[$k]["cells"][$row][9])!="Specialty" ||
				    trim($reader->sheets[$k]["cells"][$row][10])!="Sub-Specialty" ||
				    trim($reader->sheets[$k]["cells"][$row][11])!="Keywords" ||
				    trim($reader->sheets[$k]["cells"][$row][12])!="Affiliation" ||
				    trim($reader->sheets[$k]["cells"][$row][13])!="Department" ||
				    trim($reader->sheets[$k]["cells"][$row][14])!="Position" ||
				    trim($reader->sheets[$k]["cells"][$row][15])!="Email" ||
				    trim($reader->sheets[$k]["cells"][$row][16])!="Phone" ||
				    trim($reader->sheets[$k]["cells"][$row][17])!="Address" ||
				    trim($reader->sheets[$k]["cells"][$row][18])!="City" ||
				    trim($reader->sheets[$k]["cells"][$row][19])!="State" ||
				    trim($reader->sheets[$k]["cells"][$row][20])!="Country" ||
				    trim($reader->sheets[$k]["cells"][$row][21])!="Region" ||
				    trim($reader->sheets[$k]["cells"][$row][22])!="Postal Code" ||
				    trim($reader->sheets[$k]["cells"][$row][24])!="Latitude" ||
				    trim($reader->sheets[$k]["cells"][$row][25])!="Longitude"
				    ){
				        $arrImportStatusMsg[$file1]['professional']['incorrect_format']='Professional Info Header format is incorrect';
				        break;
				} 
				/* if(	trim($reader->sheets[$k]["cells"][$row][1])!="Salutation" ||
				trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				trim($reader->sheets[$k]["cells"][$row][3])!="First Name" ||
				trim($reader->sheets[$k]["cells"][$row][4])!="Middle Name" ||
				trim($reader->sheets[$k]["cells"][$row][5])!="Last Name" ||
				trim($reader->sheets[$k]["cells"][$row][6])!="Suffix" ||
				trim($reader->sheets[$k]["cells"][$row][7])!="Gender" ||
				trim($reader->sheets[$k]["cells"][$row][8])!="Specialty" ||
				trim($reader->sheets[$k]["cells"][$row][9])!="Sub-Specialty" ||
				trim($reader->sheets[$k]["cells"][$row][10])!="Keywords" ||
				trim($reader->sheets[$k]["cells"][$row][11])!="Affiliation" ||
				trim($reader->sheets[$k]["cells"][$row][12])!="Department" ||
				trim($reader->sheets[$k]["cells"][$row][13])!="Position" ||
				trim($reader->sheets[$k]["cells"][$row][14])!="Email" ||
				trim($reader->sheets[$k]["cells"][$row][15])!="Phone" ||
				trim($reader->sheets[$k]["cells"][$row][16])!="Address" ||
				trim($reader->sheets[$k]["cells"][$row][17])!="City" ||
				trim($reader->sheets[$k]["cells"][$row][18])!="State" ||
				trim($reader->sheets[$k]["cells"][$row][19])!="Country" ||
				trim($reader->sheets[$k]["cells"][$row][20])!="Region" ||
				trim($reader->sheets[$k]["cells"][$row][21])!="Postal Code" ||
				trim($reader->sheets[$k]["cells"][$row][27])!="Latitude" ||
				trim($reader->sheets[$k]["cells"][$row][28])!="Longitude"
				        ){
					$arrImportStatusMsg[$file1]['professional']['incorrect_format']='Professional Info Header format is incorrect';
					break;
				} */
				
				
				$arrImportStatusMsg[$file1]['professiona']['success']					= true;
				$existingkols = array();
				
				$arrLocationData = array(); // for kol_location
				
				for($row=2; $row<= count($reader->sheets[$k]["cells"])+1; $row++){
					//pr($reader->sheets[$k]["cells"][$row]);
					//continue;
					$kolsDetails						= array();
					$detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
					if ($detailsPin != "") {
					    $kolId = $this->kol->getKolIdByPin($detailsPin);
					    if ($kolId != 0) {
					        $insData = true;
					    } else {
					        $insData = false;
					        $arrImportStatusMsg[$file1]['professional']['no_matching_pin_num'][] = $detailsPin;
					    }
					} else {
					    //aray of Affiliation having no 'pin'
					    $insData = false;
					    $arrImportStatusMsg[$file1]['professional']['no_pin_num'][]= $detailsPin;
					}
// 					exit;
					$kolsDetails['id'] = $kolId;
					$kolsDetails['pin'] = $detailsPin;
					$kolsDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][3]);
					$nameEls = explode(".",$kolsDetails['full_name']);
					$salutation = trim($reader->sheets[$k]["cells"][$row][2]);
					// Get Salutation ID based on the Salutation Text
					$kolsDetails['salutation'] 			= array_search(trim($salutation),$arrSalutations);
					if(!$kolsDetails['salutation']){
						$kolsDetails['salutation']		='';
					}
					$kolsDetails['first_name']			= trim($reader->sheets[$k]["cells"][$row][4]);
					$kolsDetails['middle_name'] 		= trim($reader->sheets[$k]["cells"][$row][5]);
					$kolsDetails['last_name']			= trim($reader->sheets[$k]["cells"][$row][6]);
					$kolsDetails['suffix'] 				= trim($reader->sheets[$k]["cells"][$row][7]);
					$kolsDetails['gender'] 				= ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
					// Get Specialty ID based on the Specialty Text
					$kolsDetails['specialty'] 			= array_search(trim($reader->sheets[$k]["cells"][$row][9]),$arrSpecialitys);
					if(!$kolsDetails['specialty']){
						$kolsDetails['specialty']		= '';
					}
					$kolsDetails['sub_specialty'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][10]));
					
					$kolsDetails['research_interests'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][11]));
					$kolsDetails['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][14]));
					if(!empty($kolsDetails['title'])){
					    $kolsDetails['title'] = $this->kol->saveTitle($kolsDetails['title']); // save title if not exists / if exsits get id
					}
					$kolsDetails['division'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][13]));
					$organization['name'] 				= trim($reader->sheets[$k]["cells"][$row][12]);
					if($organization['name']!=''){
						$kolsDetails['org_id'] 			= $this->organization->saveOrganization($organization);
						if($kolsDetails['org_id'] ){
							//Update pin as kolid
							$updateData['id'] 			=  $kolsDetails['org_id'] ;
							$updateData['cin_num'] 		=  $kolsDetails['org_id'] ;
							$this->organization->updateOrganization($updateData);
						}
					}
					$kolsDetails['primary_email'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][15]));
					$kolsDetails['primary_phone'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][16]));
					$kolsDetails['address1'] 		= ucwords(trim($reader->sheets[$k]["cells"][$row][17]));
					$countryId					= $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][20]))]['country_id'];
					$state					= ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
					if($state!=''){
						$stateId= $this->kol->getStateIdByCountry($state,$countryId);
						 $kolsDetails['state_id'] 		= $stateId;
					}
					$city					= ucwords(trim($reader->sheets[$k]["cells"][$row][18]));
					if($city!=''){
						$kolsDetails['city_id'] = $this->kol->getCityIdByState($city,$stateId);
					}

					$kolsDetails['postal_code']		= ucwords(trim($reader->sheets[$k]["cells"][$row][22]));
					if(array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][20])),$arrCountries))
					
					$kolsDetails['country_id'] 		= $countryId;

					$arrLocationData['org_institution_id'] = $kolsDetails['org_id'];
					$arrLocationData['address1'] = $kolsDetails['address1'];
					$arrLocationData['address3'] = '';
					$arrLocationData['validation_status'] = 'VALD';
					$arrLocationData['address_type'] = 'Physical';
					$arrLocationData['country_id'] = $countryId;
					$arrLocationData['state_id'] = $kolsDetails['state_id'];
					$arrLocationData['city_id'] = $kolsDetails['city_id'];
					$arrLocationData['postal_code'] = $kolsDetails['postal_code'];
					$arrLocationData['latitude'] = trim($reader->sheets[$k]["cells"][$row][24]);
					$arrLocationData['longitude'] = trim($reader->sheets[$k]["cells"][$row][25]);
					$arrLocationData['is_primary'] = 1;
					$arrLocationData['data_type_indicator'] = $profile_type;
					$arrLocationData['processed_latlong'] = 0;
					if($arrLocationData['latitude']!='' && $arrLocationData['longitude']!=''){
					   $arrLocationData['processed_latlong'] = 1;
					}
					$arrLocationData['created_by'] = $this->loggedUserId;
					$arrLocationData['created_on'] = date('Y-m-d H:i:s');
					$arrLocationData['modified_by'] = $this->loggedUserId;
					$arrLocationData['modified_on'] = date('Y-m-d H:i:s');
					$genericId = $this->common_helpers->getGenericId("Location Form");
					$arrLocationData['generic_id'] = $genericId;
					
					$arrEmailData['type'] = 'Work';
					$arrEmailData['email'] = $kolsDetails['primary_email'];
					$arrEmailData['is_primary'] = 1;
					$arrEmailData['created_by'] = $this->loggedUserId;
					$arrEmailData['created_on'] = date('Y-m-d H:i:s');
					$arrEmailData['modified_by'] = $this->loggedUserId;
					$arrEmailData['modified_on'] = date('Y-m-d H:i:s');
					$arrEmailData['data_type_indicator'] = $profile_type;
					
					$arrPhoneData['number'] = $kolsDetails['primary_phone'];
					$arrPhoneData['is_primary'] = 1;
					$arrPhoneData['contact_type'] = "location";
					$arrPhoneData['created_by'] = $this->loggedUserId;
					$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
					$arrPhoneData['modified_by'] = $this->loggedUserId;
					$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
					$arrPhoneData['data_type_indicator'] = $profile_type;
					$arrPhoneData['type'] = 5;
					
					//$kolsDetails['license'] 			= trim($reader->sheets[$k]["cells"][$row][13]);
					//$kolsDetails['npi_num'] 			= trim($reader->sheets[$k]["cells"][$row][14]);
					$kolsDetails['profile_type'] 		= DISCOVERY;
	
					$kolsDetails['created_by']			= $userId;
					$kolsDetails['created_on']			= date("Y-m-d H:i:s");
					//2 to indicate that its id project profile
					$kolsDetails['is_imported'] 		= 2;
					$kolsDetails['is_pubmed_processed'] = 0;
					$kolsDetails['status'] = COMPLETED;
					/*$kolsDetails['address2'] = '';
					$kolsDetails['biography'] = '';
					$kolsDetails['is_clinical_trial_processed'] = 1;
					$kolsDetails['is_kol'] = 1; */
					//pr($kolsDetails);
					//continue;
					
					if ($detailsPin != "") {
						unset($kolsDetails['full_name']);
						$id = $this->identification->saveIDKol($kolsDetails);
						//If the kol already Exists then it won't save
						if($id==false){
							//need to check what to do
							/*//array of already existing kols
							$existingkols[]=$kolsDetails['first_name']." ".$kolsDetails['middle_name']." ".$kolsDetails['last_name'];
							unset($kolsDetails['first_name']);
							unset($kolsDetails['middle_name']);
							unset($kolsDetails['last_name']);
							$this->kol->updateImportedKol($kolsDetails);*/
						}else{
							//Associate the KOL to the Project
							$projKolDetails['project_id'] = $projectId;
							$projKolDetails['kol_id'] = $id;
							$projKolDetails['created_by']			= $userId;
							$projKolDetails['created_on']			= date("Y-m-d H:i:s");
							//$projectId
							$this->identification->saveProjectKol($projKolDetails);
							$updateData    = array();
							$updateData['id'] = $id;
							$updateData['pin'] = $detailsPin;
							$updateData['unique_id'] = md5($id);
							$arrLocationData['kol_id'] = $id;
							$lastLocId = $this->kol->saveKolLocation($arrLocationData); // insert in kol_location	
							
							$arrPhoneData['contact'] = $id;
							$arrPhoneData['location_id'] = $lastLocId;
							
							$arrEmailData['contact'] = $id;
							
							$this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
							$this->kol->saveKolEmails($arrEmailData); // insert in email
							
							$this->kol->updateKol($updateData);
						}
					}else{
						//array of KOL having no 'PIN'
						$arrImportStatusMsg[$file1]['professional']['no_pin_num'][] 	= $kolsDetails['first_name']." ".$kolsDetails['middle_name']." ".$kolsDetails['last_name'];
					}
				}
				$arrImportStatusMsg[$file1]['professional']['success']					= true;
				$arrImportStatusMsg[$file1]['professional']['existingKols']				= $existingkols;
				pr($arrImportStatusMsg);
			}
			
			// Start of processing the sheet - 'Congresses & Conferences'
			if(trim($sheet['name'])=='Congresses & Conferences'){
				//echo "In Events<br />";
				//Check the Event Info Header Format
				$row=1;
				if(
				    trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				    trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				    trim($reader->sheets[$k]["cells"][$row][3])!="Event Name" ||
				    trim($reader->sheets[$k]["cells"][$row][4])!="Event Type" ||
				    trim($reader->sheets[$k]["cells"][$row][5])!="Session Name/Committee" ||
				    trim($reader->sheets[$k]["cells"][$row][6])!="Session Type" ||
				    trim($reader->sheets[$k]["cells"][$row][7])!="Role" ||
				    trim($reader->sheets[$k]["cells"][$row][8])!="Topic" ||
				    trim($reader->sheets[$k]["cells"][$row][9])!="Speaking" ||
				    trim($reader->sheets[$k]["cells"][$row][10])!="Organizing Committee" ||
				    trim($reader->sheets[$k]["cells"][$row][11])!="Start Date" ||
				    trim($reader->sheets[$k]["cells"][$row][12])!="End Date" ||
				    trim($reader->sheets[$k]["cells"][$row][13])!="Organizer" ||
				    trim($reader->sheets[$k]["cells"][$row][14])!="Organizer Type" ||
				    trim($reader->sheets[$k]["cells"][$row][15])!="Session Sponsor" ||
				    trim($reader->sheets[$k]["cells"][$row][16])!="Sponsor Type" ||
				    trim($reader->sheets[$k]["cells"][$row][17])!="City" ||
				    trim($reader->sheets[$k]["cells"][$row][18])!="State" ||
				    trim($reader->sheets[$k]["cells"][$row][19])!="Country" ||
				    trim($reader->sheets[$k]["cells"][$row][20])!="Url"){
				        $arrImportStatusMsg['event']['incorrect_format']='Event Info Header format is incorrect';
				        pr($reader->sheets[$k]["cells"][$row]);
				        break;
				}
				/* if(
				trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				trim($reader->sheets[$k]["cells"][$row][2])!="Event Name" ||
				trim($reader->sheets[$k]["cells"][$row][3])!="Event Type" ||
				trim($reader->sheets[$k]["cells"][$row][4])!="Session Name/Committee" ||
				trim($reader->sheets[$k]["cells"][$row][5])!="Session Type" ||
				trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				trim($reader->sheets[$k]["cells"][$row][7])!="Topic" ||
				trim($reader->sheets[$k]["cells"][$row][8])!="Speaking" ||
				trim($reader->sheets[$k]["cells"][$row][9])!="Organizing Committee" ||
				trim($reader->sheets[$k]["cells"][$row][10])!="Start Date" ||
				trim($reader->sheets[$k]["cells"][$row][11])!="End Date" ||
				trim($reader->sheets[$k]["cells"][$row][12])!="Organizer" ||
				trim($reader->sheets[$k]["cells"][$row][13])!="Organizer Type" ||
				trim($reader->sheets[$k]["cells"][$row][14])!="Session Sponsor" ||
				trim($reader->sheets[$k]["cells"][$row][15])!="Sponsor Type" ||
				trim($reader->sheets[$k]["cells"][$row][16])!="City" ||
				trim($reader->sheets[$k]["cells"][$row][17])!="State" ||
				trim($reader->sheets[$k]["cells"][$row][18])!="Country" ||
				trim($reader->sheets[$k]["cells"][$row][19])!="Url"){
					$arrImportStatusMsg['event']['incorrect_format']='Event Info Header format is incorrect';
					pr($reader->sheets[$k]["cells"][$row]);
					break;
				} */
				for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
					$kolDetails								= array();
					$detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
					if ($detailsPin != "") {
					    $kolId = $this->kol->getKolIdByPin($detailsPin);
					    if ($kolId != 0) {
					        $insData = true;
					    } else {
					        $insData = false;
					        $arrImportStatusMsg[$file1]['event']['no_matching_pin_num'][] = $detailsPin;
					    }
					} else {
					    //aray of Affiliation having no 'pin'
					    $insData = false;
					    $arrImportStatusMsg[$file1]['event']['no_pin_num'][]= $detailsPin;
					}
					$eventDetails							= array();
					$event 									= array();
					$countryId								= 0;
					$stateId								= 0;
					$cityId									= 0;
					$kolDetails['full_name'] 						= trim($reader->sheets[$k]["cells"][$row][2]);
					$nameEls = explode(".",$kolDetails['full_name']);
					if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
						$salutation = $nameEls[0].".";
						$kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
					}
					
					$event['name'] 							= trim($reader->sheets[$k]["cells"][$row][3]);
					if($kolDetails['full_name']!='' && $event['name']!=''){
					 	$eventDetails['type'] 					= 'conference';
					 	//Get event id
					 	$event['category']						= 'conference';
					 	//$event['created_by']					= $this->loggedUserId;
					 	$event['created_by']					= $userId;
					 	$event['created_on']					= date('Y-m-d H:i:s');
					 	$eventId								= $this->kol->getEventIdElseSave($event);
					 	$eventDetails['event_id']				= $eventId;
					 	//Get the event type ID
					 	$eventType	= array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][4])),$arrEventTypes);
					 	if(!$eventType){
					 		$arrEventType['event_type']			= ucwords(trim($reader->sheets[$k]["cells"][$row][4]));
					 		if($this->db->insert('conf_event_types',$arrEventType)){
					 			$eventType						= $this->db->insert_id();
					 			$arrEventTypes[$eventType]		= $arrEventType['event_type'];
					 		}else{
					 			$eventType						= "";
					 		}
					 	}
					 	$eventDetails['event_type'] 			= $eventType;
					 	//Get the Session type ID
					 	$sessionType							= array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][6])),$arrSessionTypes);
					 	if(!$sessionType){
					 		$arrSessionType['session_type']		= ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
					 		if($this->db->insert('conf_session_types',$arrSessionType)){
					 			$sessionType					= $this->db->insert_id();
					 			$arrSessionTypes[$sessionType]	= $arrSessionType['session_type'];
					 		}else{
					 			$sessionType	= "";
					 		}
					 	}
					 	$eventDetails['session_type'] 			= $sessionType;
					 		
					 	$eventDetails['session_name'] 			= trim($reader->sheets[$k]["cells"][$row][5]);
					 	$eventDetails['role']					= ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
					 	//Get the Evet Topic Id and then Save
					 	$topic = '';
					 	$topicId = '';
					 	$topic = ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
					 	if($topic !=''){
					 		$topicId = $this->kol->getTopicId($topic);
					 		if($topicId==0){
					 			$arrEventTopic['name']			= $topic;
					 			if($this->db->insert('event_topics',$arrEventTopic)){
					 				$topicId					= $this->db->insert_id();
					 			}
					 		}
					 	}
					 	$eventDetails['topic'] 			= $topicId;
					 	//Get the start and end Dates
					 	$startDate						='';
					 	$endDate						= '';
					 	$startDate 						= $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][11]));
					 	$endDate 						= $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][12]));
					 	$eventDetails['start'] 			=  $startDate;
					 	$eventDetails['end'] 			=  $endDate;
					 	$eventDetails['organizer'] 		= trim($reader->sheets[$k]["cells"][$row][13]);
					 	
					 	$oranizerType		= array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][14])),$arrEventOrganizerTypes);
					 	
					 		$eventDetails['organizer_type'] =$oranizerType;
					 	
					 	$eventDetails['session_sponsor']	= ucwords(trim($reader->sheets[$k]["cells"][$row][15]));
					 	
					 	$sponsorType		= array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][16])),$arrEventSponsorTypes);
					
					 	$eventDetails['sponsor_type'] =$sponsorType;
					 
					 	if(isset($reader->sheets[$k]["cells"][$row][9]) && $reader->sheets[$k]["cells"][$row][9] != '')
					 		$eventDetails['activity_type'] =$reader->sheets[$k]["cells"][$row][9];
					 	if(isset($reader->sheets[$k]["cells"][$row][10]) && $reader->sheets[$k]["cells"][$row][10] != '')
					 		$eventDetails['activity_type'] =$reader->sheets[$k]["cells"][$row][10];
					 	
					 	//
					 	/*$eventDetails['location'] 		= trim($reader->sheets[$k]["cells"][$row][14]);
					 	
					 	$eventDetails['address'] 		= trim($reader->sheets[$k]["cells"][$row][15]);*/
					 	if(array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][19])),$arrCountries))
					 	$countryId=$arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][19]))]['country_id'];
					 	$eventDetails['country_id'] 	= $countryId;
					 	if(array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][18])),$arrStates))
					 	$stateId					= $arrStates[ucwords(trim($reader->sheets[$k]["cells"][$row][18]))]['state_id'];
					 	$eventDetails['state_id'] 		= $stateId;
					 	//if(array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][16])),$arrCities))
					 	//$cityId						= $arrCities[ucwords(trim($reader->sheets[$k]["cells"][$row][16]))]['city_id'];
					 	$cityId = $this->kol->getCityIdByState(ucwords(trim($reader->sheets[$k]["cells"][$row][17])),$stateId,$countryId);
					 	$eventDetails['city_id'] 		= $cityId;
					 	//$eventDetails['postal_code']	= ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
					 	$eventDetails['url']	= ucwords(trim($reader->sheets[$k]["cells"][$row][20]));
					 	$eventDetails['location']		= '';
					 	$eventDetails['address']		= '';
					 	$eventDetails['postal_code']		= '';
					 	$eventDetails['data_type_indicator'] = $profile_type;
					 	//$eventDetails['created_by']		=	$this->loggedUserId;
					 	$eventDetails['created_by']		=	$userId;
					 	$eventDetails['created_on']		=	date("Y-m-d H:i:s");
					 	$eventDetails['client_id']		=	$this->session->userdata('client_id');
					 	$eventDetails['project_id']		=	$projectId;
					 	//Save only if the 'pin' is not blank
					 	if ($detailsPin != "") {
					 	    $kolId = $this->kol->getKolIdByPin($detailsPin);
					 		if($kolId != 0){
					 			$eventDetails['kol_id'] = $kolId;
					 			//$id						= $this->kol->saveEvent($eventDetails);
					 			//$edcationDetailCount[$kolId]['kolId'] = $kolId;
					 			$arrEventsForBulk[]= $eventDetails;
					 			
					 		}else{
					 			$arrImportStatusMsg[$file1]['event']['no_matching_pin_num'][]= $kolDetails['full_name'];
					 		}
					 	}else{
					 		//aray of Event having no 'pin'
					 		$arrImportStatusMsg[$file1]['event']['no_pin_num'][]= $event['name'];
					 	}
					 }
					}
				//	echo "End Time".(microtime(true)-$startTime);
					$arrImportStatusMsg[$file1]['event']['success']=true;
					$this->identification->saveEventDetailByBulk($arrEventsForBulk);
					//Add Log activity
					$arrLogDetails = array(
							'type' => IMPORT_RECORD,
							'description' => 'Congresses & Conferences sheet has been imported',
							'status' => STATUS_SUCCESS,
							'kols_or_org_type' => 'Kol',
							'kols_or_org_id' => $kolId,
							'transaction_name' => IMPORT_RECORD,
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity ( null, true );
				}
			// End of processing the sheet - 'Congresses & Conferences'
			
			// Start of processing the sheet - 'Associations & Societies'
				if(trim($sheet['name'])=='Associations & Societies'){
				    $arrAffiliationForBulk = array();
				    //echo "started affiliation<br />";
				    //Check the Affiliation Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="Organization Name" ||
				        trim($reader->sheets[$k]["cells"][$row][4])!="Organization Type" ||
				        trim($reader->sheets[$k]["cells"][$row][5])!="Committee" ||
				        trim($reader->sheets[$k]["cells"][$row][6])!="Time frame" ||
				        trim($reader->sheets[$k]["cells"][$row][7])!="Role" ||
				        trim($reader->sheets[$k]["cells"][$row][8])!="Engagement Type" ||
				        trim($reader->sheets[$k]["cells"][$row][9])!="Url"){
				            $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="Organization Name" ||
				     trim($reader->sheets[$k]["cells"][$row][3])!="Organization Type" ||
				     trim($reader->sheets[$k]["cells"][$row][4])!="Committee" ||
				     trim($reader->sheets[$k]["cells"][$row][5])!="Time frame" ||
				     trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				     trim($reader->sheets[$k]["cells"][$row][7])!="Engagement Type" ||
				     trim($reader->sheets[$k]["cells"][$row][8])!="Url"){
				     $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $detailsPin;
				        }
				        $affDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        //Check for the  Organization Type(Type of Affiliation)
				        $affDetails['type'] 			= trim($reader->sheets[$k]["cells"][$row][4]);
				        //Get Institute id//Oranization Id
				        $institution = array();
				        $institution['name']   			= trim($reader->sheets[$k]["cells"][$row][3]);
				        //$institution['created_by']		=	$this->loggedUserId;
				        $institution['created_by']		=	$userId;
				        $institution['created_on']		=	date('Y-m-d H:i:s');
				        if($institution['name']!='')
				            $institueId	= $this->kol->getInstituteIdElseSave($institution);
				            $affDetails['institute_id']		= $institueId;
				            $affDetails['department'] = '';
				            if(isset($reader->sheets[$k]["cells"][$row][4]))
				                $affDetails['department'] 		= trim($reader->sheets[$k]["cells"][$row][5]);
				                $affDetails['role']				= trim($reader->sheets[$k]["cells"][$row][7]);
				                //Get the start and end years
				                $timeFrame 						= trim($reader->sheets[$k]["cells"][$row][6]);
				                $startDate 						= "";
				                $endDate 						= "";
				                $arrTimeFrame 					= explode('-',$timeFrame);
				                if(sizeof($arrTimeFrame)>0){
				                    $startDate 					= trim($arrTimeFrame[0]);
				                }
				                if(sizeof($arrTimeFrame)>1){
				                    $endDate 					= trim($arrTimeFrame[1]);
				                }
				                $this->load->model('Engagement_type');
				                //Get Engagement id
				                $engagement   					= ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
				                $engagementId					= $this->Engagement_type->getEngagementId($engagement);
				                if($engagementId){
				                    $affDetails['engagement_id']= $engagementId;
				                }
				                $affDetails['start_date'] 		=  	$startDate;
				                $affDetails['end_date'] 		=  	$endDate;
				                $affDetails['url']				= trim($reader->sheets[$k]["cells"][$row][9]);
				                //$affDetails['created_by']		=	$this->loggedUserId;
				                $affDetails['created_by']		=	$userId;
				                $affDetails['created_on']		=	date("Y-m-d H:i:s");
				                $affDetails['client_id']		=	$this->session->userdata('client_id');
				                $affDetails['project_id']		=	$projectId;
				                $affDetails['data_type_indicator'] = $profile_type;
				                //pr($affDetails);
				                //continue;
				                //Save only if the 'pin' is not blank
				                if ($detailsPin != "") {
				                    $kolId = $this->kol->getKolIdByPin($detailsPin);
				                    //pr($this->db->last_query());
				                    if($kolId != 0){
				                        $affDetails['kol_id'] 	= $kolId;
				                        //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                        //$edcationDetailCount[$kolId]['affCount'] = 12;
				                        //$id						= $this->kol->saveMembership($affDetails);
				                        $arrAffiliationForBulk[]=$affDetails;
				                        
				                    }else{
				                        $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                    }
				                }else{
				                    //aray of Affiliation having no 'pin'
				                    $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $institution['name'];
				                }
				                
				    }
				    /*foreach($edcationDetailCount as $kolId=>$values){
				     if(!(isset($edcationDetailCount[$kolId]['affiliationCount']))){
				     $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
				     }
				     
				     }*/
				    
				    //pr($edcationDetailCount);
				    $arrImportStatusMsg[$file1]['affiliation1']['success']=true;
				    $this->identification->saveAffiliationDetailByBulk($arrAffiliationForBulk);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Associations & Societies sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
				//- End of processing the sheet - 'Associations & Societies'
				
				// Start of processing the sheet - 'Associations & Societies'
				if(trim($sheet['name'])=='Industry Affiliation'){
				    $arrAffiliationForBulk = array();
				    //echo "started affiliation<br />";
				    //Check the Affiliation Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="Organization Name" ||
				        trim($reader->sheets[$k]["cells"][$row][4])!="Organization Type" ||
				        trim($reader->sheets[$k]["cells"][$row][5])!="Time frame" ||
				        trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				        trim($reader->sheets[$k]["cells"][$row][7])!="Engagement Type" ||
				        trim($reader->sheets[$k]["cells"][$row][8])!="Url"){
				            $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="Organization Name" ||
				     trim($reader->sheets[$k]["cells"][$row][3])!="Organization Type" ||
				     trim($reader->sheets[$k]["cells"][$row][4])!="Time frame" ||
				     trim($reader->sheets[$k]["cells"][$row][5])!="Role" ||
				     trim($reader->sheets[$k]["cells"][$row][6])!="Engagement Type" ||
				     trim($reader->sheets[$k]["cells"][$row][7])!="Url"){
				     $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $detailsPin;
				        }
				        $affDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        //Check for the  Organization Type(Type of Affiliation)
				        $affDetails['type'] 			= trim($reader->sheets[$k]["cells"][$row][4]);
				        //Get Institute id//Oranization Id
				        $institution = array();
				        $institution['name']   			= trim($reader->sheets[$k]["cells"][$row][3]);
				        //$institution['created_by']		=	$this->loggedUserId;
				        $institution['created_by']		=	$userId;
				        $institution['created_on']		=	date('Y-m-d H:i:s');
				        if($institution['name']!='')
				            $institueId	= $this->kol->getInstituteIdElseSave($institution);
				            $affDetails['institute_id']		= $institueId;
				            $affDetails['role']				= trim($reader->sheets[$k]["cells"][$row][6]);
				            //Get the start and end years
				            $timeFrame 						= trim($reader->sheets[$k]["cells"][$row][5]);
				            $startDate 						= "";
				            $endDate 						= "";
				            $arrTimeFrame 					= explode('-',$timeFrame);
				            if(sizeof($arrTimeFrame)>0){
				                $startDate 					= trim($arrTimeFrame[0]);
				            }
				            if(sizeof($arrTimeFrame)>1){
				                $endDate 					= trim($arrTimeFrame[1]);
				            }
				            $this->load->model('Engagement_type');
				            //Get Engagement id
				            $engagement   					= ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
				            $engagementId					= $this->Engagement_type->getEngagementId($engagement);
				            if($engagementId){
				                $affDetails['engagement_id']= $engagementId;
				            }
				            $affDetails['start_date'] 		=  	$startDate;
				            $affDetails['end_date'] 		=  	$endDate;
				            $affDetails['url1']				= trim($reader->sheets[$k]["cells"][$row][8]);
				            $affDetails['department'] 		= '';
				            //$affDetails['created_by']		=	$this->loggedUserId;
				            $affDetails['created_by']		=	$userId;
				            $affDetails['created_on']		=	date("Y-m-d H:i:s");
				            $affDetails['client_id']		=	$this->session->userdata('client_id');
				            $affDetails['project_id']		=	$projectId;
				            $affDetails['data_type_indicator'] = $profile_type;
				            //pr($affDetails);
				            //continue;
				            //Save only if the 'pin' is not blank
				            if ($detailsPin != "") {
				                $kolId = $this->kol->getKolIdByPin($detailsPin);
				                //pr($this->db->last_query());
				                if($kolId != 0){
				                    $affDetails['kol_id'] 	= $kolId;
				                    //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                    //$edcationDetailCount[$kolId]['affCount'] = 12;
				                    //$id						= $this->kol->saveMembership($affDetails);
				                    $arrAffiliationForBulk[]=$affDetails;
				                    
				                }else{
				                    $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                }
				            }else{
				                //aray of Affiliation having no 'pin'
				                $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $institution['name'];
				            }
				            
				    }
				    /*foreach($edcationDetailCount as $kolId=>$values){
				     if(!(isset($edcationDetailCount[$kolId]['affiliationCount']))){
				     $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
				     }
				     
				     }*/
				    
				    //pr($edcationDetailCount);
				    $arrImportStatusMsg[$file1]['affiliation1']['success']=true;
				    $this->identification->saveAffiliationDetailByBulk($arrAffiliationForBulk);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Industry Affiliation sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
			//- End of processing the sheet - 'Associations & Societies'
			
			
			
			// Start of processing the sheet - 'Editorial Boards'
				if(trim($sheet['name'])=='Editorial Boards'){
				    $arrAffiliationForBulk = array();
				    //echo "started affiliation<br />";
				    //Check the Affiliation Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="Journal Name" ||
				        trim($reader->sheets[$k]["cells"][$row][4])!="Organization Type" ||
				        trim($reader->sheets[$k]["cells"][$row][5])!="Committee" ||
				        trim($reader->sheets[$k]["cells"][$row][6])!="Time frame" ||
				        trim($reader->sheets[$k]["cells"][$row][7])!="Role" ||
				        trim($reader->sheets[$k]["cells"][$row][8])!="Engagement Type" ||
				        trim($reader->sheets[$k]["cells"][$row][9])!="Url"){
				            //pr($reader->sheets[$k]["cells"][$row]);
				            $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="Journal Name" ||
				     trim($reader->sheets[$k]["cells"][$row][3])!="Organization Type" ||
				     trim($reader->sheets[$k]["cells"][$row][4])!="Committee" ||
				     trim($reader->sheets[$k]["cells"][$row][5])!="Time frame" ||
				     trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				     trim($reader->sheets[$k]["cells"][$row][7])!="Engagement Type" ||
				     trim($reader->sheets[$k]["cells"][$row][8])!="Url"){
				     //pr($reader->sheets[$k]["cells"][$row]);
				     $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $detailsPin;
				        }
				        $affDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        //Check for the  Organization Type(Type of Affiliation)
				        $affDetails['type'] 			= trim($reader->sheets[$k]["cells"][$row][4]);
				        //Get Institute id//Oranization Id
				        $institution = array();
				        $institution['name']   			= trim($reader->sheets[$k]["cells"][$row][3]);
				        //$institution['created_by']		=	$this->loggedUserId;
				        $institution['created_by']		=	$userId;
				        $institution['created_on']		=	date('Y-m-d H:i:s');
				        if($institution['name']!='')
				            $institueId	= $this->kol->getInstituteIdElseSave($institution);
				            $affDetails['institute_id']		= $institueId;
				            $affDetails['department'] = '';
				            if(isset($reader->sheets[$k]["cells"][$row][4]))
				                $affDetails['department'] 		= trim($reader->sheets[$k]["cells"][$row][5]);
				                $affDetails['role']				= trim($reader->sheets[$k]["cells"][$row][7]);
				                //Get the start and end years
				                $timeFrame 						= trim($reader->sheets[$k]["cells"][$row][6]);
				                $startDate 						= "";
				                $endDate 						= "";
				                $arrTimeFrame 					= explode('-',$timeFrame);
				                if(sizeof($arrTimeFrame)>0){
				                    $startDate 					= trim($arrTimeFrame[0]);
				                }
				                if(sizeof($arrTimeFrame)>1){
				                    $endDate 					= trim($arrTimeFrame[1]);
				                }
				                $this->load->model('Engagement_type');
				                //Get Engagement id
				                $engagement   					= ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
				                $engagementId					= $this->Engagement_type->getEngagementId($engagement);
				                if($engagementId){
				                    $affDetails['engagement_id']= $engagementId;
				                }
				                $affDetails['start_date'] 		=  	$startDate;
				                $affDetails['end_date'] 		=  	$endDate;
				                $affDetails['url']				= trim($reader->sheets[$k]["cells"][$row][9]);
				                //$affDetails['created_by']		=	$this->loggedUserId;
				                $affDetails['created_by']		=	$userId;
				                $affDetails['created_on']		=	date("Y-m-d H:i:s");
				                $affDetails['client_id']		=	$this->session->userdata('client_id');
				                $affDetails['project_id']		=	$projectId;
				                $affDetails['data_type_indicator'] = $profile_type;
				                //pr($affDetails);
				                //continue;
				                //Save only if the 'pin' is not blank
				                if ($detailsPin != "") {
				                    $kolId = $this->kol->getKolIdByPin($detailsPin);
				                    //pr($this->db->last_query());
				                    if($kolId != 0){
				                        $affDetails['kol_id'] 	= $kolId;
				                        //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                        //$edcationDetailCount[$kolId]['affCount'] = 12;
				                        //$id						= $this->kol->saveMembership($affDetails);
				                        $arrAffiliationForBulk[]=$affDetails;
				                        
				                    }else{
				                        $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                    }
				                }else{
				                    //aray of Affiliation having no 'pin'
				                    $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $institution['name'];
				                }
				                
				    }
				    /*foreach($edcationDetailCount as $kolId=>$values){
				     if(!(isset($edcationDetailCount[$kolId]['affiliationCount']))){
				     $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
				     }
				     
				     }*/
				    
				    //pr($edcationDetailCount);
				    $arrImportStatusMsg[$file1]['affiliation1']['success']=true;
				    $this->identification->saveAffiliationDetailByBulk($arrAffiliationForBulk);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Editorial Boards sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
				//- End of processing the sheet - 'Editorial Boards'
				
				
				// Start of processing the sheet - 'Expert Center'
				if(trim($sheet['name'])=='Expert Center'){
				    $arrAffiliationForBulk = array();
				    //echo "started affiliation<br />";
				    //Check the Affiliation Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="Hospital Name" ||
				        trim($reader->sheets[$k]["cells"][$row][4])!="Organization Type" ||
				        trim($reader->sheets[$k]["cells"][$row][5])!="Department/Division/Center" ||
				        trim($reader->sheets[$k]["cells"][$row][6])!="Time frame" ||
				        trim($reader->sheets[$k]["cells"][$row][7])!="Role" ||
				        trim($reader->sheets[$k]["cells"][$row][8])!="Engagement Type" ||
				        trim($reader->sheets[$k]["cells"][$row][9])!="Url"){
				            pr($reader->sheets[$k]["cells"][$row]);
				            $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="Hospital Name" ||
				     trim($reader->sheets[$k]["cells"][$row][3])!="Organization Type" ||
				     trim($reader->sheets[$k]["cells"][$row][4])!="Department/Division/Center" ||
				     trim($reader->sheets[$k]["cells"][$row][5])!="Time frame" ||
				     trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				     trim($reader->sheets[$k]["cells"][$row][7])!="Engagement Type" ||
				     trim($reader->sheets[$k]["cells"][$row][8])!="Url"){
				     pr($reader->sheets[$k]["cells"][$row]);
				     $arrImportStatusMsg[$file1]['affiliation1']['incorrect_format']='Associations & Societies Info Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $detailsPin;
				        }
				        $affDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        //Check for the  Organization Type(Type of Affiliation)
				        $affDetails['type'] 			= trim($reader->sheets[$k]["cells"][$row][4]);
				        //Get Institute id//Oranization Id
				        $institution = array();
				        $institution['name']   			= trim($reader->sheets[$k]["cells"][$row][3]);
				        //$institution['created_by']		=	$this->loggedUserId;
				        $institution['created_by']		=	$userId;
				        $institution['created_on']		=	date('Y-m-d H:i:s');
				        if($institution['name']!='')
				            $institueId	= $this->kol->getInstituteIdElseSave($institution);
				            $affDetails['institute_id']		= $institueId;
				            $affDetails['department'] = '';
				            if(isset($reader->sheets[$k]["cells"][$row][4]))
				                $affDetails['department'] 		= trim($reader->sheets[$k]["cells"][$row][5]);
				                $affDetails['role']				= trim($reader->sheets[$k]["cells"][$row][7]);
				                //Get the start and end years
				                $timeFrame 						= trim($reader->sheets[$k]["cells"][$row][6]);
				                $startDate 						= "";
				                $endDate 						= "";
				                $arrTimeFrame 					= explode('-',$timeFrame);
				                if(sizeof($arrTimeFrame)>0){
				                    $startDate 					= trim($arrTimeFrame[0]);
				                }
				                if(sizeof($arrTimeFrame)>1){
				                    $endDate 					= trim($arrTimeFrame[1]);
				                }
				                $this->load->model('Engagement_type');
				                //Get Engagement id
				                $engagement   					= ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
				                $engagementId					= $this->Engagement_type->getEngagementId($engagement);
				                if($engagementId != false){
				                    $affDetails['engagement_id']= $engagementId;
				                }
				                $affDetails['start_date'] 		=  	$startDate;
				                $affDetails['end_date'] 		=  	$endDate;
				                $affDetails['url']				= trim($reader->sheets[$k]["cells"][$row][9]);
				                //$affDetails['created_by']		=	$this->loggedUserId;
				                $affDetails['created_by']		=	$userId;
				                $affDetails['created_on']		=	date("Y-m-d H:i:s");
				                $affDetails['client_id']		=	$this->session->userdata('client_id');
				                $affDetails['project_id']		=	$projectId;
				                $affDetails['data_type_indicator'] = $profile_type;
				                //pr($affDetails);
				                //continue;
				                //Save only if the 'pin' is not blank
				                if ($detailsPin != "") {
				                    $kolId = $this->kol->getKolIdByPin($detailsPin);
				                    //pr($this->db->last_query());
				                    if($kolId != 0){
				                        $affDetails['kol_id'] 	= $kolId;
				                        //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                        //$edcationDetailCount[$kolId]['affCount'] = 12;
				                        //$id						= $this->kol->saveMembership($affDetails);
				                        $arrAffiliationForBulk[]=$affDetails;
				                        
				                    }else{
				                        $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                    }
				                }else{
				                    //aray of Affiliation having no 'pin'
				                    $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $institution['name'];
				                }
				                
				    }
				    /*foreach($edcationDetailCount as $kolId=>$values){
				     if(!(isset($edcationDetailCount[$kolId]['affiliationCount']))){
				     $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
				     }
				     
				     }*/
				    
				    //pr($edcationDetailCount);
				    $arrImportStatusMsg[$file1]['affiliation1']['success']=true;
				    $this->identification->saveAffiliationDetailByBulk($arrAffiliationForBulk);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Expert Center sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
			//- End of processing the sheet - 'Expert Center'
			
			// Start --- Guidlines Import
				if(trim($sheet['name'])=='Guideline'){
				    $arrGlsForBulk = array();
				    //Check the Guidelines Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="Organization Name" ||
				        trim($reader->sheets[$k]["cells"][$row][4])!="Organization Type" ||
				        trim($reader->sheets[$k]["cells"][$row][5])!="Committee" ||
				        trim($reader->sheets[$k]["cells"][$row][6])!="Time frame" ||
				        trim($reader->sheets[$k]["cells"][$row][7])!="Role" ||
				        trim($reader->sheets[$k]["cells"][$row][8])!="Engagement Type" ||
				        trim($reader->sheets[$k]["cells"][$row][9])!="Url"){
				            pr($reader->sheets[$k]["cells"][$row]);
				            $arrImportStatusMsg[$file1]['guidelines']['incorrect_format']='Guidelines Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="Organization Name" ||
				     trim($reader->sheets[$k]["cells"][$row][3])!="Organization Type" ||
				     trim($reader->sheets[$k]["cells"][$row][4])!="Committee" ||
				     trim($reader->sheets[$k]["cells"][$row][5])!="Time frame" ||
				     trim($reader->sheets[$k]["cells"][$row][6])!="Role" ||
				     trim($reader->sheets[$k]["cells"][$row][7])!="Engagement Type" ||
				     trim($reader->sheets[$k]["cells"][$row][8])!="Url"){
				     pr($reader->sheets[$k]["cells"][$row]);
				     $arrImportStatusMsg[$file1]['guidelines']['incorrect_format']='Guidelines Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $detailsPin;
				        }
				        $affDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        //Check for the  Organization Type(Type of Affiliation)
				        $affDetails['type'] 			= trim($reader->sheets[$k]["cells"][$row][4]);
				        //Get Institute id//Oranization Id
				        $institution = array();
				        $institution['name']   			= trim($reader->sheets[$k]["cells"][$row][3]);
				        //$institution['created_by']		=	$this->loggedUserId;
				        $institution['created_by']		=	$userId;
				        $institution['created_on']		=	date('Y-m-d H:i:s');
				        if($institution['name']!='')
				            $institueId	= $this->kol->getInstituteIdElseSave($institution);
				            $affDetails['institute_id']		= $institueId;
				            $affDetails['department'] = '';
				            if(isset($reader->sheets[$k]["cells"][$row][4]))
				                $affDetails['department'] 		= trim($reader->sheets[$k]["cells"][$row][5]);
				                $affDetails['role']				= trim($reader->sheets[$k]["cells"][$row][7]);
				                //Get the start and end years
				                $timeFrame 						= trim($reader->sheets[$k]["cells"][$row][6]);
				                $startDate 						= "";
				                $endDate 						= "";
				                $arrTimeFrame 					= explode('-',$timeFrame);
				                if(sizeof($arrTimeFrame)>0){
				                    $startDate 					= trim($arrTimeFrame[0]);
				                }
				                if(sizeof($arrTimeFrame)>1){
				                    $endDate 					= trim($arrTimeFrame[1]);
				                }
				                $this->load->model('Engagement_type');
				                //Get Engagement id
				                $engagement   					= ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
				                $engagementId					= $this->Engagement_type->getEngagementId($engagement);
				                if($engagementId){
				                    $affDetails['engagement_id']= $engagementId;
				                }
				                $affDetails['start_date'] 		=  	$startDate;
				                $affDetails['end_date'] 		=  	$endDate;
				                $affDetails['url']				= trim($reader->sheets[$k]["cells"][$row][9]);
				                //$affDetails['created_by']		=	$this->loggedUserId;
				                $affDetails['created_by']		=	$userId;
				                $affDetails['created_on']		=	date("Y-m-d H:i:s");
				                $affDetails['client_id']		=	$this->session->userdata('client_id');
				                $affDetails['project_id']		=	$projectId;
				                $affDetails['data_type_indicator'] = $profile_type;
				                //pr($affDetails);
				                //continue;
				                //Save only if the 'pin' is not blank
				                if ($detailsPin != "") {
				                    $kolId = $this->kol->getKolIdByPin($detailsPin);
				                    //pr($this->db->last_query());
				                    if($kolId != 0){
				                        $affDetails['kol_id'] 	= $kolId;
				                        //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                        //$edcationDetailCount[$kolId]['affCount'] = 12;
				                        //$id						= $this->kol->saveMembership($affDetails);
				                        $arrGlsForBulk[]=$affDetails;
				                        
				                    }else{
				                        $arrImportStatusMsg[$file1]['affiliation1']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                    }
				                }else{
				                    //aray of Affiliation having no 'pin'
				                    $arrImportStatusMsg[$file1]['affiliation1']['no_pin_num'][]= $institution['name'];
				                }
				                
				    }
				    /*foreach($edcationDetailCount as $kolId=>$values){
				     if(!(isset($edcationDetailCount[$kolId]['affiliationCount']))){
				     $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
				     }
				     
				     }*/
				    
				    //pr($edcationDetailCount);
				    $arrImportStatusMsg[$file1]['affiliation1']['success']=true;
				    $this->identification->saveAffiliationDetailByBulk($arrGlsForBulk);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Guideline sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
				// End --- Guidlines Import
				
				
				// Start --- Publications Import
				if(trim($sheet['name'])=='Publications'){
				    $arrPubsForBulk = array();
				    //Check the publication Info Header Format
				    $row=1;
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="PMIDs"){
				            $arrImportStatusMsg[$file1]['publication']['incorrect_format']='Publication Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="PMIDs"){
				     $arrImportStatusMsg[$file1]['publication']['incorrect_format']='Publication Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['publication']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['publication']['no_pin_num'][]= $detailsPin;
				        }
				        $pubDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        $pubDetails['pmids'] = '';
				        if(isset($reader->sheets[$k]["cells"][$row][3]))
				            $pubDetails['pmids'] = trim($reader->sheets[$k]["cells"][$row][3]);
				            //Save only if the 'pin' is not blank
				            if($detailsPin!="" && $pubDetails['pmids'] != ''){
				                $kolId = $this->kol->getKolIdByPin($detailsPin);
				                //pr($this->db->last_query());
				                if($kolId != 0){
				                    $pubDetails['kol_id'] 	= $kolId;
				                    //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                    //$edcationDetailCount[$kolId]['affCount'] = 12;
				                    //$id						= $this->kol->saveMembership($affDetails);
				                    $arrPubsForBulk[]=$pubDetails;
				                    
				                }else{
				                    $arrImportStatusMsg[$file1]['publication']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                }
				            }else{
				                //aray of publication having no 'pin'
				                $arrImportStatusMsg[$file1]['publication']['no_pin_num'][]= $institution['name'];
				            }
				    }
				    pr($arrPubsForBulk);
				    pr($projectId);
				    $this->identification->savePMIDsBulk($arrPubsForBulk,$projectId);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Publications sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
				// End --- Publications Import
				
				
				// Sttar --- Clinial trials Import
				if(trim($sheet['name'])=='Clinical Trials'){
				    $arrTrialsForBulk = array();
				    //Check the Clinical Trials Info Header Format
				    $row=1;
				    //pr($reader->sheets[$k]["cells"][$row]);
				    if(
				        trim($reader->sheets[$k]["cells"][$row][1])!="Pin" ||
				        trim($reader->sheets[$k]["cells"][$row][2])!="KOL Name" ||
				        trim($reader->sheets[$k]["cells"][$row][3])!="CTIDs"){
				            $arrImportStatusMsg[$file1]['trial']['incorrect_format']='Clinical Trials Header format is incorrect';
				            break;
				    }
				    /* if(
				     trim($reader->sheets[$k]["cells"][$row][1])!="KOL Name" ||
				     trim($reader->sheets[$k]["cells"][$row][2])!="CTIDs"){
				     $arrImportStatusMsg[$file1]['trial']['incorrect_format']='Clinical Trials Header format is incorrect';
				     break;
				     } */
				    for($row=2; $row<= count($reader->sheets[$k]["cells"]); $row++){
				        $kolDetails						= array();
				        $detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
				        if ($detailsPin != "") {
				            $kolId = $this->kol->getKolIdByPin($detailsPin);
				            if ($kolId != 0) {
				                $insData = true;
				            } else {
				                $insData = false;
				                $arrImportStatusMsg[$file1]['trial']['no_matching_pin_num'][] = $detailsPin;
				            }
				        } else {
				            //aray of Affiliation having no 'pin'
				            $insData = false;
				            $arrImportStatusMsg[$file1]['trial']['no_pin_num'][]= $detailsPin;
				        }
				        $trialDetails						= array();
				        $kolDetails['full_name'] 				= trim($reader->sheets[$k]["cells"][$row][2]);
				        $nameEls = explode(".",$kolDetails['full_name']);
				        if(count($nameEls) > 1 and in_array($nameEls[0].".",$arrSalutations)){
				            $salutation = $nameEls[0].".";
				            $kolDetails['full_name'] = trim(str_replace($salutation,"",$kolDetails['full_name']));
				        }
				        $trialDetails['ctids'] = '';
				        if(isset($reader->sheets[$k]["cells"][$row][3]))
				            $trialDetails['ctids'] = trim($reader->sheets[$k]["cells"][$row][3]);
				            //Save only if the 'pin' is not blank
				            if($detailsPin!="" && $trialDetails['ctids'] !=''){
				                $kolId = $this->kol->getKolIdByPin($detailsPin);
				                //pr($this->db->last_query());
				                if($kolId != 0){
				                    $trialDetails['kol_id'] 	= $kolId;
				                    //$edcationDetailCount[$kolId]['kolId'] = $kolId;
				                    //$edcationDetailCount[$kolId]['affCount'] = 12;
				                    //$id						= $this->kol->saveMembership($affDetails);
				                    $arrTrialsForBulk[]=$trialDetails;
				                }else{
				                    $arrImportStatusMsg[$file1]['trial']['no_matching_pin_num'][]= $kolDetails['full_name'];
				                }
				            }else{
				                //aray of publication having no 'pin'
				                $arrImportStatusMsg[$file1]['trial']['no_pin_num'][]= $institution['name'];
				            }
				            
				    }
				    pr($arrTrialsForBulk);
				    $this->identification->saveCTIDsBulk($arrTrialsForBulk,$projectId);
				    //Add Log activity
				    $arrLogDetails = array(
				        'type' => IMPORT_RECORD,
				        'description' => 'Clinical Trials sheet has been imported',
				        'status' => STATUS_SUCCESS,
				        'kols_or_org_type' => 'Kol',
				        'kols_or_org_id' => $kolId,
				        'transaction_name' => IMPORT_RECORD,
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity ( null, true );
				}
			// End --- Clinial trials Import	
		}
// 		$this->kol->UpdateLocationPhoneEmail();
		//Add Log activity
		$arrLogDetails = array(
				'type' => 'ID PROJECT '.IMPORT_RECORD,
				'description' => 'Importing Project details',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
// 				'kols_or_org_id' => $kolId,
				'transaction_id' =>  $projectId,				
				'file_name' => $_FILES["file_name"]['name'],
				'transaction_name' => IMPORT_RECORD,
		);
		$this->config->set_item('log_details', $arrLogDetails);
		
	}
	
	function priority_settings(){
	    $data = array();
	    $userId = $this->session->userdata('user_id');
	    $projectIds = $this->identification->getUserProjectsIds($userId);
	    if(count($projectIds) > 0){
	        $data['projectId'] = $projectIds[0];
	    }else{
	        $data['projectId'] = $this->identification->getLatestProjectId();
	    }
	    $data['arrProjects'] = $this->identification->listProjects();
	    $data['defaultProjectId'] = $data['projectId'];
		$data['contentPage'] 							= 'identification/priority_settings';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited priority settings Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View priority settings Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	}
	
	function load_priority_data(){
		//$arrPriorities = array('' => '',0 => 'Low',1=>'Medium',2=>'High');
		$arrPriorities = array('' => '',0 => '0',1=>'1',2=>'2');
		$data = array();
		$arrRows = array();
		$filters = $_POST;
		$page = $filters['page'];
		$limit = $filters['rows'];
		switch($filters['type']){
		    case 'Journals' : $arrRows = $this->identification->getAllJournals($filters);
		    //                            echo $this->db->last_query();exit;
		    foreach($arrRows as $key => $row){
		        $arrRows[$key]['id'] = $row['id'];
		        $arrRows[$key]['priority_id'] = $row['priority_id'];
		        $arrRows[$key]['name'] = $row['name'];
		        $arrRows[$key]['priority'] = $arrPriorities[$row['priority']];
		    }
		    break;
		    case 'Events'	: $arrRows = $this->identification->getAllEvents($filters);
		    foreach($arrRows as $key => $row){
		        $arrRows[$key]['id'] = $row['id'];
		        $arrRows[$key]['priority_id'] = $row['priority_id'];
		        $arrRows[$key]['name'] = $row['name'];
		        $arrRows[$key]['priority'] = $arrPriorities[$row['priority']];
		    }
		    break;
		    case 'Institutions'	: $arrRows = $this->identification->getAllInstitutions($filters);
		    //                            echo $this->db->last_query();exit;
		    foreach($arrRows as $key => $row){
		        $arrRows[$key]['id'] = $row['id'];
		        $arrRows[$key]['priority_id'] = $row['priority_id'];
		        $arrRows[$key]['name'] = $row['name'];
		        $arrRows[$key]['priority'] = $arrPriorities[$row['priority']];
		    }
		    break;
		    case 'Trials'	:$arrRows = $this->identification->getAllSponsors($filters);
		    foreach($arrRows as $key => $row){
		        $arrRows[$key]['id'] = $row['id'];
		        $arrRows[$key]['priority_id'] = $row['priority_id'];
		        $arrRows[$key]['name'] = $row['agency'];
		        $arrRows[$key]['priority'] = $arrPriorities[$row['priority']];
		    }
		    break;
		    case 'Guidelines' : $arrRows = $this->identification->getAllGuidelines($filters);
// 		                               echo $this->db->last_query();
		    foreach($arrRows as $key => $row){
		        $arrRows[$key]['id'] = $row['id'];
		        $arrRows[$key]['priority_id'] = $row['priority_id'];
		        $arrRows[$key]['name'] = $row['department'];
		        $arrRows[$key]['priority'] = $arrPriorities[$row['priority']];
		    }
		    break;
		}
			
		
		$count				= sizeof($arrRows);				
		if( $count >0 ){ 
			$total_pages    = ceil($count/$limit); 
		}else{ 
			$total_pages 	= 0; 
		} 
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $arrRows;  
		//pr($arrKolDetailResult1);
		echo json_encode($data);
	}
	
	function update_priority(){
	    $filters = $_POST;
	    $arrPriorities = array('' => NULL,'0' => 0,'1' => 1,'2' => 2);
	    $rowData['client_id'] = $this->session->userdata('client_id');
	    $rowData['priority'] = $arrPriorities[$filters['priority']];
	    switch($filters['type']){
	        case 'Journals' : 		$rowData['journal_id'] = $filters['id'];
	        $this->identification->updateJournal($rowData);
	        break;
	        case 'Events'	: 		$rowData['event_id'] = $filters['id'];
	        $this->identification->updateEvent($rowData);
	        break;
	        case 'Institutions'	: 	$rowData['institution_id'] = $filters['id'];
	        $this->identification->updateInstitution($rowData);
	        break;
	        case 'Trials' :			$rowData['sponser_id'] = $filters['id'];
	        $res = $this->identification->updateSponsors($rowData);
	        break;
	        case 'Guidelines' : 	$rowData['guideline_id'] = $filters['id'];
	        $this->identification->updateGuidelines($rowData);
	        break;
	    }
	    
	}
	
	function update_activity_type(){
	    $arrData = array();
	    $arrData['id'] = $this->input->post('id');
	    $arrData['activity_type'] = $this->input->post('activity_type');
	    $this->identification->updateActivityType($arrData);
	}
	
	
	function keywords_autocomplete($params){
		pr($params);
	}
	
	function export_ranking_data(){
		$postData = json_decode($_POST['json_data']);
		$postData = (array)$postData;
		$this->load->plugin('php_excel/classes/phpexcel.php');
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Ranking');
		//Add header
		$chkNominee =  $_POST['nominee_chk_box'];
		if( $chkNominee==1){
		$objWorksheet->setCellValue('A1', 'KOL Name')
					->setCellValue('B1', 'Rank')
					->setCellValue('C1', 'Score')
					->setCellValue('D1', 'Total')
					->setCellValue('E1', 'Speaking')
					->setCellValue('F1', 'Organizing Committee')
					->setCellValue('G1', 'Industry')
					->setCellValue('H1', 'Associations')
					->setCellValue('I1', 'Editorial Boards')
					->setCellValue('J1', 'Univ/Hospital')
					->setCellValue('K1', 'All Pubs')
					->setCellValue('L1', 'Lead Author')
					->setCellValue('M1', 'Middle Author')
					->setCellValue('N1', 'Single Author')
					->setCellValue('O1', 'First Author')
					->setCellValue('P1', 'Last Author')
					->setCellValue('Q1', 'Clinical Trials')
					->setCellValue('R1', 'Guidelines')
					->setCellValue('S1', 'Peer Nominations');
		}else{
			$objWorksheet->setCellValue('A1', 'KOL Name')
					->setCellValue('B1', 'Rank')
					->setCellValue('C1', 'Score')
					->setCellValue('D1', 'Total')
					->setCellValue('E1', 'Speaking')
					->setCellValue('F1', 'Organizing Committee')
					->setCellValue('G1', 'Industry')
					->setCellValue('H1', 'Associations')
					->setCellValue('I1', 'Editorial Boards')
					->setCellValue('J1', 'Univ/Hospital')
					->setCellValue('K1', 'All Pubs')
					->setCellValue('L1', 'Lead Author')
					->setCellValue('M1', 'Middle Author')
					->setCellValue('N1', 'Single Author')
					->setCellValue('O1', 'First Author')
					->setCellValue('P1', 'Last Author')
					->setCellValue('Q1', 'Clinical Trials')
					->setCellValue('R1', 'Guidelines');
				
		}
		
		//Add Data
		$i	=	2;
		if( $chkNominee==1){
		foreach($postData as $row){
				$row = (array)$row;
				$objWorksheet->setCellValue('A'.$i, $row['first_name']." ".$row['middle_name']." ".$row['last_name'])
							->setCellValue('B'.$i, $row['rank'])
							->setCellValue('C'.$i, $row['score'])
							->setCellValue('D'.$i, $row['numevc'])
							->setCellValue('E'.$i, $row['numspc'])
							->setCellValue('F'.$i, $row['numocc'])
							->setCellValue('G'.$i, $row['numia'])
							->setCellValue('H'.$i, $row['numas'])							
							->setCellValue('I'.$i, $row['numeb'])
							->setCellValue('J'.$i, $row['numec'])
							->setCellValue('K'.$i, $row['nump'])
							->setCellValue('L'.$i, $row['leadc'])
							->setCellValue('M'.$i, $row['numma'])
							->setCellValue('N'.$i, $row['numsa'])
							->setCellValue('O'.$i, $row['numfa'])
							->setCellValue('P'.$i, $row['numla'])
							->setCellValue('Q'.$i, $row['numtc'])
							->setCellValue('R'.$i, $row['numgc'])
							->setCellValue('S'.$i, $row['numic']);
	
				$i++;
			}
		}else{
			foreach($postData as $row){
				$row = (array)$row;
				$objWorksheet->setCellValue('A'.$i, $row['first_name']." ".$row['middle_name']." ".$row['last_name'])
							->setCellValue('B'.$i, $row['rank'])
							->setCellValue('C'.$i, $row['score'])
							->setCellValue('D'.$i, $row['numevc'])
							->setCellValue('E'.$i, $row['numspc'])
							->setCellValue('F'.$i, $row['numocc'])
							->setCellValue('G'.$i, $row['numia'])
							->setCellValue('H'.$i, $row['numas'])
							->setCellValue('I'.$i, $row['numeb'])
							->setCellValue('J'.$i, $row['numec'])
							->setCellValue('K'.$i, $row['nump'])
							->setCellValue('L'.$i, $row['leadc'])
							->setCellValue('M'.$i, $row['numma'])
							->setCellValue('N'.$i, $row['numsa'])
							->setCellValue('O'.$i, $row['numfa'])
							->setCellValue('P'.$i, $row['numla'])
							->setCellValue('Q'.$i, $row['numtc'])
							->setCellValue('R'.$i, $row['numgc']);
							
	
				$i++;
			}
			
		}
		
		//Weightage Shhet
		
		$weightageValue  = $_POST['weightage_values'];
		parse_str($weightageValue,$weightageArray);
		
		//foreach()
		//pr($weightageArray);
		foreach($weightageArray as $key=>$row){
			
			if($row!='0'){
				//echo $row;
				$weightage[$key] = $row;
			}
			
		}
		//pr($weightage);
		//exit();
		if($weightageArray['keywords']!=''){
			//$weightage['Keywords'] = $weightageArray['keywords'];
		}
		/*$weightage['pub_priority'] = $weightageArray['pub_priority'];
		$weightage['aff_priority'] = $weightageArray['aff_priority'];
		$weightage['trials_priority'] = $weightageArray['trials_priority'];
		$weightage['events_priority'] = $weightageArray['events_priority'];
		$weightage['events_priority'] = $weightageArray['events_priority'];*/
		$includeSurvey = $weightage['include_survey2'];
		unset($weightage['include_survey2']);
		unset($weightage['wyn']);
		unset($weightage['keywords']);
		unset($weightage['total_weight']);
		unset($weightage['year_range']);
	//	pr($weightage);
		//exit();
				$this->load->model('survey');
				$priorityArray = array(2=>'High',1=>'Medium',0=>'Low');
				$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
				$objWorksheet->setTitle('Weightages');
				$objWorksheet->setCellValue('A1', 'Weightages');
				$objWorksheet->setCellValue('B1', 'Values');			
								
//	$arrKolDetails['arrInteraction'][$kolsId]			$data6[0]=array('PIN','KOL Name','Date','Time','Mode','Location',' Topic','Brand','Role','Follow-Up On','Category','Therapeutic Area','Notes');
				$i=2;
				$psercentageText="%";
				foreach($weightage as $key=>$value){
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
					//foreach($arrKolDetails['arrInteraction'][$kolsId] as $row){
						if($key=='pubs_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Publications Year Range';
						}
						if($key=='events_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Events Year Range';
						}
						
						if($key=='trials_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Trails Year Range';
						}
						
						if($key=='trials_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Trails Year Range';
						}
						if($key=='aff_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Affiliations Year Range';
						}
						
						if($key=='guideline_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Guidelines Year Range';
						}
						if($key=='pubs_sa'){
							$value =$value.$psercentageText;
							$key = 'Single Author';
						}
						if($key=='pubs_ma'){
							$value =$value.$psercentageText;
							$key = 'Contributing Author';
						}
						if($key=='pubs_fa'){
							$value =$value.$psercentageText;
							$key = 'First Author';
						}
						if($key=='pubs_la'){
							$value =$value.$psercentageText;
							$key = 'Last Author';
						}
						if($key=='industry_all'){
							$value =$value.$psercentageText;
							$key = 'Industry';
						}
						
						if($key=='assoc_all'){
							$value =$value.$psercentageText;
							$key = 'Associations';
						}
						
						if($key=='editorial_all'){
							$value =$value.$psercentageText;
							$key = 'Editorial Board';
						}
						if($key=='expert_all'){
							$value =$value.$psercentageText;
							$key = 'Expert Center';
						}
						
						if($key=='trials_all'){
							$value =$value.$psercentageText;
							$key = 'Trials';
						}
						if($key=='pubs_all'){
							$value =$value.$psercentageText;
							$key = 'Publications';
						}
						if($key=='events_all'){
							$value =$value.$psercentageText;
							$key = 'Events';
						}
						
						if($key=='events_speaker'){
							$value =$value.$psercentageText;
							$key = 'Speaker';
						}
						if($key=='events_orgcom'){
							$value =$value.$psercentageText;
							$key = 'Events';
						}
						if($key=='events_all'){
							$value =$value.$psercentageText;
							$key = 'Organizing Commitee';
						}
					if($key=='guideline_all'){
								$value =$value.$psercentageText;
							$key = 'Guidelines';
						}
						
						if($key=='surveys_all'){
							$value =$value.$psercentageText;
							$key = 'Peer Nominations';
						}
						
						if($key=='pub_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Journal Priority';
						}
						
						if($key=='aff_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Affiliations Priority';
						}
						if($key=='trials_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Trials Priority';
						}
						if($key=='events_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Events Priority';
						}
						if($key=='guideline_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Guidelines Priority';
						}
						
						if($key=='events_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Events Priority';
						}
						
						if($key=='surveys_priority'){
							
							$key = 'Survey';
							//echo $value;
							if($value!=''){
								$arrSurveys		= $this->survey->getSurveyName($value);
								$value= $arrSurveys[$value];
							}else{
								
								if($includeSurvey=='on'){
									$value="All";
								}else{
									$value='';
								}
							}
							
						}
						if($key=='multi_keywords'){
							//echo "ss";
							$key = 'Keywords';
						//	echo $value;
							$value = implode(',',$value);
							//echo $value;
							
						}
						
						$objWorksheet->setCellValue('A'.$i, $key);
						$objWorksheet->setCellValue('B'.$i, $value);
						$i++;;
									
					//}
				}
				//exit();
				$objPHPExcel->addSheet($objWorksheet);
		
		
				$filterValue  = $_POST['filter_values'];
				parse_str($filterValue,$filterArray);
	
				if($filterArray['specialty']!=''){
					
					$sepcailtyArrays=array();
					$this->load->model('Specialty');
						$arrSpecialitys					= $this->Specialty->getAllSpecialties();
						
					foreach($filterArray['specialty'] as $value){
						$sepcailtyArrays[] = $arrSpecialitys[$value];
					}
				//	pr($sepcailtyArrays);
					$filters['Specialty'] = implode(',',$sepcailtyArrays);
					
				}
				
				if($filterArray['country']!=''){
					//pr($filterArray);
					$countryArrays=array();
					$this->load->model('Country_helper');
						
				
					$countryArrays = $this->Country_helper->getCountryNameById($filterArray['country']);
					//pr($countryArrays);
					$filters['Country'] =implode(',',$countryArrays);
					
				}
				
				if($filterArray['city']!=''){
					
					$cityArrays=array();
					$this->load->model('Country_helper');
					$cityArrays = $this->Country_helper->getCityNameById($filterArray['city'] );
					$filters['City'] =implode(',',$cityArrays);
					
					
				}
				
				if($filterArray['region']!=''){
						
					$filters['Region'] =implode(',',$filterArray['region']);
										
				}
				//pr($filters);
			//	exit();
				$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
				$objWorksheet->setTitle('Filters');
				$objWorksheet->setCellValue('A1', 'Filter Name');
				$objWorksheet->setCellValue('B1', 'Filter value');			
								
//	$arrKolDetails['arrInteraction'][$kolsId]			$data6[0]=array('PIN','KOL Name','Date','Time','Mode','Location',' Topic','Brand','Role','Follow-Up On','Category','Therapeutic Area','Notes');
				$i=2;
				foreach($filters as $key=>$value){
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
					//foreach($arrKolDetails['arrInteraction'][$kolsId] as $row){
						$objWorksheet->setCellValue('A'.$i, $key);
						$objWorksheet->setCellValue('B'.$i, $value);
						$i++;;
									
					//}
				}
				$objPHPExcel->addSheet($objWorksheet);
		
		
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle(' ');
		
		$objPHPExcel->addSheet($objWorksheet);
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
		foreach(range('A','R') as $columnID) {
		    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(0)->getStyle('A1:Q1')->applyFromArray($arrStyles); 
		$objPHPExcel->getSheet(1)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
		
		 $objPHPExcel->getSheet(2)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(2)->getColumnDimension($columnID)->setWidth(30);
		}
		
		$fileName ='Ranking Report';
		
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client�s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=$fileName.xlsx");
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		$arrLogDetails = array(
		    'type' => EXPORT_RECORD,
		    'description' => 'Export Ranking Data',
		    'status' => STATUS_SUCCESS,
		    'transaction_name' => "Export Ranking Data",
		);
		$this->config->set_item('log_details', $arrLogDetails);
		
		exit;
	}
	
	function export_trends_data(){
		$psercentageText="%";
		$postData = json_decode($_POST['json_data']);
		$postData = (array)$postData;
		$this->load->plugin('php_excel/classes/phpexcel.php');
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Trends');
		//Add header
		$objWorksheet->setCellValue('A1', 'KOL Name')
					->setCellValue('B1', 'Last 5 Year')
					->setCellValue('C1', 'Last 3 Year')
					->setCellValue('D1', 'Last 1 Year');
		
		//Add Data
		$i	=	2;
		foreach($postData as $row){
			$row = (array)$row;
			$objWorksheet->setCellValue('A'.$i, $row['name'])
						->setCellValue('B'.$i, $row['last5'])
						->setCellValue('C'.$i, $row['last3'])
						->setCellValue('D'.$i, $row['last1']);

			$i++;
		}
		
		//Weightage Shhet
		
		$weightageValue  = $_POST['weightage_values_trend'];
		parse_str($weightageValue,$weightageArray);
		
		//foreach()
		//pr($weightageArray);
		foreach($weightageArray as $key=>$row){
			
			if($row!='0'){
				//echo $row;
				$weightage[$key] = $row;
			}
			
		}
		//pr($weightage);
		//exit();
		if($weightageArray['keywords']!=''){
			//$weightage['Keywords'] = $weightageArray['keywords'];
		}
		/*$weightage['pub_priority'] = $weightageArray['pub_priority'];
		$weightage['aff_priority'] = $weightageArray['aff_priority'];
		$weightage['trials_priority'] = $weightageArray['trials_priority'];
		$weightage['events_priority'] = $weightageArray['events_priority'];
		$weightage['events_priority'] = $weightageArray['events_priority'];*/
			$includeSurvey = $weightage['include_survey2'];
		unset($weightage['include_survey2']);
		unset($weightage['wyn']);
		unset($weightage['keywords']);
		unset($weightage['total_weight']);
		unset($weightage['year_range']);

		$this->load->model('survey');
		$priorityArray = array(2=>'High',1=>'Medium',0=>'Low');
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Weightages');
		$objWorksheet->setCellValue('A1', 'Weightages');
		$objWorksheet->setCellValue('B1', 'Values');			
						
		$i=2;
				foreach($weightage as $key=>$value){
				
					if($key=='pubs_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Publications Year Range';
						}
						if($key=='events_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Events Year Range';
						}
						
						if($key=='trials_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Trails Year Range';
						}
						
						if($key=='trials_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Trails Year Range';
						}
						if($key=='aff_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Affiliations Year Range';
						}
						
						if($key=='guideline_year_range'){
							$value = str_replace(',','-',$value);
							$key = 'Guidelines Year Range';
						}
						if($key=='pubs_sa'){
							$value =$value.$psercentageText;
							$key = 'Single Author';
						}
						if($key=='pubs_ma'){
							$value =$value.$psercentageText;
							$key = 'Contributing Author';
						}
						if($key=='pubs_fa'){
							$value =$value.$psercentageText;
							$key = 'First Author';
						}
						if($key=='pubs_la'){
							$value =$value.$psercentageText;
							$key = 'Last Author';
						}
						if($key=='industry_all'){
							$value =$value.$psercentageText;
							$key = 'Industry';
						}
						
						if($key=='assoc_all'){
							$value =$value.$psercentageText;
							$key = 'Associations';
						}
						if($key=='guideline_all'){
								$value =$value.$psercentageText;
							$key = 'Guidelines';
						}
						
						if($key=='editorial_all'){
							$value =$value.$psercentageText;
							$key = 'Editorial Board';
						}
						if($key=='expert_all'){
							$value =$value.$psercentageText;
							$key = 'Expert Center';
						}
						
						if($key=='trials_all'){
							$value =$value.$psercentageText;
							$key = 'Trials';
						}
						if($key=='pubs_all'){
							$value =$value.$psercentageText;
							$key = 'Publications';
						}
						if($key=='events_all'){
							$value =$value.$psercentageText;
							$key = 'Events';
						}
						
						if($key=='events_speaker'){
							$value =$value.$psercentageText;
							$key = 'Speaker';
						}
						if($key=='events_orgcom'){
							$value =$value.$psercentageText;
							$key = 'Events';
						}
						if($key=='events_all'){
							$value =$value.$psercentageText;
							$key = 'Organizing Commitee';
						}
						
						if($key=='surveys_all'){
							$value =$value.$psercentageText;
							$key = 'Peer Nominations';
						}
						
						if($key=='pub_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Journal Priority';
						}
						
						if($key=='aff_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Affiliations Priority';
						}
						if($key=='trials_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Trials Priority';
						}
						if($key=='events_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Events Priority';
						}
						if($key=='guideline_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Guidelines Priority';
						}
						
						if($key=='events_priority'){
							if($value==''){
								$value='All';
							}else{
								$value = $priorityArray[$value];
							}
							$key = 'Events Priority';
						}
						
						if($key=='surveys_priority'){
							
							$key = 'Survey';
							//echo $value;
							if($value!=''){
								$arrSurveys		= $this->survey->getSurveyName($value);
								$value= $arrSurveys[$value];
							}else{
								
								if($includeSurvey=='on'){
									$value="All";
								}else{
									$value='';
								}
							}
							
						}
				
						if($key=='multi_keywords'){
							//echo "ss";
							$key = 'Keywords';
						//	echo $value;
							$value = implode(',',$value);
							//echo $value;
							
						}
						
						$objWorksheet->setCellValue('A'.$i, $key);
						$objWorksheet->setCellValue('B'.$i, $value);
						$i++;;
									
					//}
				}
				//exit();
				$objPHPExcel->addSheet($objWorksheet);
		
		
				$filterValue  = $_POST['filter_values_trend'];
				parse_str($filterValue,$filterArray);
	
				if($filterArray['specialty']!=''){
					
					$sepcailtyArrays=array();
					$this->load->model('Specialty');
						$arrSpecialitys					= $this->Specialty->getAllSpecialties();
						
					foreach($filterArray['specialty'] as $value){
						$sepcailtyArrays[] = $arrSpecialitys[$value];
					}
				//	pr($sepcailtyArrays);
					$filters['Specialty'] = implode(',',$sepcailtyArrays);
					
				}
				
				if($filterArray['country']!=''){
					//pr($filterArray);
					$countryArrays=array();
					$this->load->model('Country_helper');
						
				
					$countryArrays = $this->Country_helper->getCountryNameById($filterArray['country']);
					//pr($countryArrays);
					$filters['Country'] =implode(',',$countryArrays);
					
				}
				
				if($filterArray['city']!=''){
					
					$cityArrays=array();
					$this->load->model('Country_helper');
					$cityArrays = $this->Country_helper->getCityNameById($filterArray['city'] );
					$filters['City'] =implode(',',$cityArrays);
					
					
				}
				
					if($filterArray['region']!=''){
						
					$filters['Region'] =implode(',',$filterArray['region']);
										
				}
				//pr($filters);
			//	exit();
				$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
				$objWorksheet->setTitle('Filters');
				$objWorksheet->setCellValue('A1', 'Filter Name');
				$objWorksheet->setCellValue('B1', 'Filter value');			
								
//	$arrKolDetails['arrInteraction'][$kolsId]			$data6[0]=array('PIN','KOL Name','Date','Time','Mode','Location',' Topic','Brand','Role','Follow-Up On','Category','Therapeutic Area','Notes');
				$i=2;
				foreach($filters as $key=>$value){
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
					//foreach($arrKolDetails['arrInteraction'][$kolsId] as $row){
						$objWorksheet->setCellValue('A'.$i, $key);
						$objWorksheet->setCellValue('B'.$i, $value);
						$i++;;
									
					//}
				}
		$objPHPExcel->addSheet($objWorksheet);
		
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle(' ');
		$objWorksheet->setCellValue('A1', 'Filter Name')
							->setCellValue('B1', 'Filter Value');
		$i	=	2;
		foreach($filters as $row){
			$objWorksheet->setCellValue('A'.$i, $row[0])
						->setCellValue('B'.$i, $row[1]);
			$i++;
		}
		$objPHPExcel->addSheet($objWorksheet);
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
		foreach(range('A','H') as $columnID) {
		    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(0)->getStyle('A1:H1')->applyFromArray($arrStyles); 
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(1)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		$objPHPExcel->getSheet(1)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
		
		 $objPHPExcel->getSheet(2)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(2)->getColumnDimension($columnID)->setWidth(30);
		}
        
		$fileName ='Trends';
		
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client�s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=$fileName.xlsx");
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		$arrLogDetails = array(
		    'type' => EXPORT_RECORD,
		    'description' => 'Export Trends Data',
		    'status' => STATUS_SUCCESS,
		    'transaction_name' => "Export Trends Data",
		);
		$this->config->set_item('log_details', $arrLogDetails);
		exit;
	}
	
	function get_saved_filters() {
		$data['savedFilters'] = $this->identification->getAllCustomFilterByUser($this->session->userdata('user_id'));
		//Add Log activity
		$arrLogDetails = array(
		    'type' => VIEW_RECORD,
		    'description' => "View Saved filter for Identify",
		    'status' => STATUS_SUCCESS,
		    'transaction_name' => "View Saved filter for Identify"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('search/edit_saved_filters',$data);
	}
	
	function add_saved_filters() {
		$data['savedFilters'] =  $this->identification->getAllCustomFilterByUser($this->session->userdata('user_id'));
		$data['identification'] = true;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Saved filter for Identify",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "Saved filter for Identify"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('search/add_saved_filters',$data);
	}
	
	function get_industry_names($industryName){
		$industryName	= utf8_urldecode($this->input->post($industryName));
		$arrIndustryNames = $this->identification->getIndustryNames($industryName);
		$arrSuggestIndustryNames	= array();
		if(sizeof($arrIndustryNames)==0){
			$arrSuggestIndustryNames[0]			= 'No results found for '.$industryName;
		}else{
			$flag	= 1;
			foreach($arrIndustryNames as $id=>$name){
				if($flag){
					$arrSuggestIndustryNames[]='<div class="autocompleteHeading">Industries</div><div class="dataSet"><label name="'.$id.'" class="industries" style="display:block">'.$name."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestIndustryNames[]='<div class="dataSet"><label name="'.$id.'" class="industries" style="display:block">'.$name."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $industryName;
		$arrReturnData['suggestions']	= $arrSuggestIndustryNames;
		echo json_encode($arrReturnData);
	}
	
	function search_term(){
		$meshString = utf8_urldecode($this->input->post('keyword'));
		$arrMeshTerms 	= $this->identification->getMeshTerms($meshString);
		$arrSuggestMeshTerm			= array();
		if(sizeof($arrMeshTerms)==0){
			$arrSuggestMeshTerm[0]	= 'No results found for '.$meshString;
		}else{
			foreach($arrMeshTerms as $id=>$name){
				$arrSuggestMeshTerm[]='<div class="dataSet"><input type="hidden" class="meshTree" value="'.$name['mesh_term_id'].'"></input><input type="hidden" class="meshTerm" value="'.$name['name'].'"></input><label name="'.$name['search_term'].'" style="display:block">'.$name['search_term'].' ('.$name['name'].') '."</label></div>";
			}
		}
		$arrReturnData['query'] 		= $meshString;
		$arrReturnData['suggestions']	= $arrSuggestMeshTerm;
		echo json_encode($arrReturnData);
	}
	
	function save_custom_filters() {
//		pr($_POST);
//		exit;
		$arrData['name'] 			= trim(ucfirst($this->input->post('filterName')));
		$arrData['filter_type'] 	= 3;
		$arrData['filter_value'] 	= json_encode($this->input->post('saveFilter'));
		$arrData['created_on'] 		= date('Y-m-d H:i:s');
		$arrData['created_by'] 		= $this->session->userdata('user_id');
		$arrData['client_id'] 		= $this->session->userdata('client_id');
		$arrData['applied_on'] 		= date('Y-m-d H:i:s');
		
		$lastId = $this->identification->saveCustomFilters($arrData);
		if($lastId){
			$data['status'] = true;
			$data['id'] = $lastId;
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Filters',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $lastId,
					'transaction_table_id' => CUSTOM_FILTERS,
					'transaction_name' => 'Add New Filters',
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$data['status'] = false;
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Filters',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $lastId,
					'transaction_table_id' => CUSTOM_FILTERS,
					'transaction_name' => 'Add New Filters',
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}
		echo json_encode($data);
	}
	
	function update_custom_filters(){
		$arrData['name'] 			= $this->input->post('filterName');
		$arrData['id'] 				= $this->input->post('filterId');
		$arrData['filter_value'] 	= json_encode($this->input->post('saveFilter'));
		$arrData['modified_on'] 	= date('Y-m-d H:i:s');
		$arrData['created_by'] 		= $this->session->userdata('user_id');
		$arrData['client_id'] 		= $this->session->userdata('client_id');
		if($this->identification->updateCustomFilters($arrData)){			
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update custom filters',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrData['id'],
					'transaction_table_id' => CUSTOM_FILTERS,
					'transaction_name' => 'Update custom filters',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$data['status'] = true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update custom filters',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrData['id'],
					'transaction_table_id' => CUSTOM_FILTERS,
					'transaction_name' => 'Update custom filters',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	function export(){
		$data['arrProjects'] = $this->identification->listProjects();
		$data['contentPage']	= 'identification/export';
		$this->load->view('layouts/client_view',$data);
	}
	function prepare_to_export($id=0){
		$arrIDProjectData	= $this->identification->getProject($id);
		$projectName	= trim(strtolower($arrIDProjectData['name']));
		$storeExportDataInFld = $projectName.'_'.date('d-m-Y');
		mkdir($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld);
		chmod($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld, 0777);
		
		$storeExplodedKolsId	= explode(",", $arrIDProjectData['kol_ids']);
		$totalKolsIdFound	= count($storeExplodedKolsId);
		$bulkKolsExportValues	= '';
		$bulkInsertExportLimit	= 50;
		$bulkInsertArraySeparator	= '';
		$bulkCountSet	= 0;
		$fileCreateCount = 0;
		for($i = 0; $i<$totalKolsIdFound; $i++){
			$bulkCountSet++;
			$bulkKolsExportValues .= $bulkInsertRowSeparator;
			$bulkKolsExportValues .= $storeExplodedKolsId[$i];
			$bulkInsertRowSeparator	= ',';
			
				if($bulkCountSet > $bulkInsertExportLimit){
					$fileCreateCount++;
					$this->export_kol_new($storeExportDataInFld,$fileCreateCount,$bulkKolsExportValues);
					$bulkCountSet = 0;
					$bulkKolsExportValues = '';
					$bulkInsertRowSeparator = '';
				}
			}
			if($bulkCountSet > 0){
				$fileCreateCount++;
				$this->export_kol_new($storeExportDataInFld,$fileCreateCount,$bulkKolsExportValues);
				$bulkCountSet = 0;
				$bulkKolsExportValues = '';
				$bulkInsertRowSeparator = '';
			}
			
			// Get real path for our folder
			$rootPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld;
			$zipName = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld.'.zip';
				
			// Initialize archive object
			$zip = new ZipArchive();
			$zip->open($zipName, ZipArchive::CREATE | ZipArchive::OVERWRITE);
				
			// Create recursive directory iterator
			$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($rootPath), RecursiveIteratorIterator::LEAVES_ONLY);
				
			foreach ($files as $name => $file)
			{
				// Skip directories (they would be added automatically)
				if (!$file->isDir())
				{
					// Get real and relative path for current file
					$filePath = $file->getRealPath();
					$relativePath = substr($filePath, strlen($rootPath) + 1);
						
					// Add current file to archive
					$zip->addFile($filePath, $relativePath);
				}
			}
				
			// Zip archive will be created only after closing object
			$zip->close();
				
			$dir = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld;
			$it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
			$files = new RecursiveIteratorIterator($it,RecursiveIteratorIterator::CHILD_FIRST);
			foreach($files as $file) {
				if ($file->isDir()){
					rmdir($file->getRealPath());
				} else {
					unlink($file->getRealPath());
				}
			}
			if(rmdir($dir)){
				echo 'archive generated for '.$arrIDProjectData['name']; 	
			}
			/* header('Content-Type: application/zip');
			header('Content-Disposition: attachment;filename="'.$zipName.'"');
			header('Cache-Control: max-age=0');
			// If you're serving to IE 9, then the following may be needed
			header('Cache-Control: max-age=1');
			
			// If you're serving to IE over SSL, then the following may be needed
			header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
			header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
			header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
			header('Pragma: public'); // HTTP/1.0 */
	// exit;
			redirect(base_url().'identifications/file_download/'.$storeExportDataInFld);
			
	}
	
	function file_download($storeExportDataInFld){
		$this->load->helper('download');
		$data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/export_data/".$storeExportDataInFld.".zip");
		$name = $storeExportDataInFld.".zip";
		force_download($name, $data);
	}
	
	function export_kol_new($folder, $filecount, $kols) {
// 		error_reporting(E_ALL);
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/classes/phpexcel.php');
        $exportOpts = $this->input->post('export_opts');
        $arrKolIds = explode(',', $kols);

        // Get PIN
        $kolArray = $this->kol->getKolsIdAndPin();
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
		$exportOpts = array();
		$exportOpts[] = "professional";
		$exportOpts[] = "contact";
		$exportOpts[] = "biography";
		$exportOpts[] = "education";
		$exportOpts[] = "affiliation";
		$exportOpts[] = "event";
		$exportOpts[] = "publication";
		$exportOpts[] = "trial";
		$exportOpts[] = "media";
//		pr($exportOpts);
//		exit;
        $clientId = $this->session->userdata('client_id');

        $objPHPExcel = new PHPExcel();
//		$objPHPExcel->setActiveSheetIndex(0);
//		$arrKolIds = array(2016,1619,1976,264,2018);
        $arrExcelData = array();
        foreach ($arrKolIds as $kolsId) {
            $arrKolDetails[$kolsId] = $this->kol->getKolDetailsById($kolsId);
        }

//		foreach ($arrKolIds as $kolsId){
//			$arrKolDetails	=	$this->kol->getKolDetailsById($kolId);
        if (in_array('professional', $exportOpts)) {
            //New Worksheet
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//				$objWorksheet = $objPHPExcel->getActiveSheet();
            $objWorksheet->setTitle('Prof_Info');
            //Add header
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Salutation')
                    ->setCellValue('C1', 'First Name')
                    ->setCellValue('D1', 'Middle Name')
                    ->setCellValue('E1', 'Last Name')
                    ->setCellValue('F1', 'Suffix')
                    ->setCellValue('G1', 'Gender')
                    ->setCellValue('H1', 'Specialty')
                    ->setCellValue('I1', 'Sub-Specialty')
                    ->setCellValue('J1', 'Company Name')
                    ->setCellValue('K1', 'Division')
                    ->setCellValue('L1', 'Title')
                    ->setCellValue('M1', 'License #')
                    ->setCellValue('N1', 'NPI Number')
                    ->setCellValue('O1', 'Profile Type');

            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('P1', 'Url');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$row['id']])
                            ->setCellValue('B' . $i, $row['salutation'])
                            ->setCellValue('C' . $i, $row['first_name'])
                            ->setCellValue('D' . $i, $row['middle_name'])
                            ->setCellValue('E' . $i, $row['last_name'])
                            ->setCellValue('F' . $i, $row['suffix'])
                            ->setCellValue('G' . $i, $row['gender'])
                            ->setCellValue('H' . $i, $arrSpecialties[$row['specialty']])
                            ->setCellValue('I' . $i, $row['sub_specialty'])
                            ->setCellValue('J' . $i, $row['org_id'])
                            ->setCellValue('K' . $i, $row['division'])
                            ->setCellValue('L' . $i, $row['title'])
                            ->setCellValue('M' . $i, $row['license'])
                            ->setCellValue('N' . $i, $row['npi_num'])
                            ->setCellValue('O' . $i, $row['profile_type']);

                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $objWorksheet->setCellValue('P' . $i, $row['url']);
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Contact info section
        if (in_array('contact', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Contact Info');
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Primary Phone')
                    ->setCellValue('C1', 'Fax')
                    ->setCellValue('D1', 'Primary Email')
                    ->setCellValue('E1', 'Address 1')
                    ->setCellValue('F1', 'Address 2')
                    ->setCellValue('G1', 'City')
                    ->setCellValue('H1', 'State / Province')
                    ->setCellValue('I1', 'Postal Code')
                    ->setCellValue('J1', 'Country');
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['primary_phone'])
                            ->setCellValue('C' . $i, $row['fax'])
                            ->setCellValue('D' . $i, $row['primary_email'])
                            ->setCellValue('E' . $i, $row['address1'])
                            ->setCellValue('F' . $i, $row['address1'])
                            ->setCellValue('G' . $i, $row['City'])
                            ->setCellValue('H' . $i, $row['Region'])
                            ->setCellValue('I' . $i, $row['postal_code'])
                            ->setCellValue('J' . $i, $row['Country']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Biography section
        if (in_array('biography', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Biography');
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Biography')
                    ->setCellValue('C1', 'Clinical Research Interests');
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['biography'])
                            ->setCellValue('C' . $i, $row['research_interests']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Education section
        if (in_array('education', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Education');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Education Type')
                        ->setCellValue('C1', 'Institution Name')
                        ->setCellValue('D1', 'Degree')
                        ->setCellValue('E1', 'Specialty')
                        ->setCellValue('F1', 'Time Frame')
                        ->setCellValue('G1', 'Url1')
                        ->setCellValue('H1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Education Type')
                        ->setCellValue('C1', 'Institution Name')
                        ->setCellValue('D1', 'Degree')
                        ->setCellValue('E1', 'Specialty')
                        ->setCellValue('F1', 'Time Frame');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrEducationDetails = $this->kol->getEducationDetailById($kolsId);
                foreach ($arrEducationDetails as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['type']);
                    if ($row['type'] == 'honors_awards') {
                        $objWorksheet->setCellValue('C' . $i, $row['honor_name']);
                    } else {
                        $objWorksheet->setCellValue('C' . $i, $row['name']);
                    }
                    $objWorksheet->setCellValue('D' . $i, $row['degree'])
                            ->setCellValue('E' . $i, $row['specialty']);
                    $eduDate = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $eduDate .= $row['start_date'];
                   if (($row['start_date'] != '' || $row['start_date'] != 0) || ($row['end_date']!=""))
                        $eduDate .= " - ";
                    if ($row['end_date'] != '')
                        $eduDate .= $row['end_date'];
                    $objWorksheet->setCellValue('F' . $i, $eduDate);


                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $objWorksheet->setCellValue('G' . $i, $row['url1'])
                                ->setCellValue('H' . $i, $row['url2']);
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Affiliation section
        if (in_array('affiliation', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Affiliation');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Organization Name')
                        ->setCellValue('C1', 'Dept/Committee')
                        ->setCellValue('D1', 'Title/Purpose')
                        ->setCellValue('E1', 'Time frame')
                        ->setCellValue('F1', 'Organization Type')
                        ->setCellValue('G1', 'Engagement Type')
                        ->setCellValue('H1', 'Url1')
                        ->setCellValue('I1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Organization Name')
                        ->setCellValue('C1', 'Dept/Committee')
                        ->setCellValue('D1', 'Title/Purpose')
                        ->setCellValue('E1', 'Time frame')
                        ->setCellValue('F1', 'Organization Type')
                        ->setCellValue('G1', 'Engagement Type');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrMembershipDetails = $this->kol->listAllMembershipsDetails($kolsId);
                foreach ($arrMembershipDetails as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['name'])
                            ->setCellValue('C' . $i, $row['department'])
                            ->setCellValue('D' . $i, $row['role']);
                    $affDate = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $affDate .= $row['start_date'];
                    if (($row['start_date'] != '') && ($row['end_date']))
                        $affDate .= " - ";
                    if ($row['end_date'] != '')
                        $affDate .= $row['end_date'];
                    $objWorksheet->setCellValue('E' . $i, $affDate)
                            ->setCellValue('F' . $i, ucwords($row['type']))
                            ->setCellValue('G' . $i, $row['engagement_type']);
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        if (isset($row['url1ForExport'])) {
                            $objWorksheet->setCellValue('H' . $i, $row['url1ForExport']);
                        }
                        if (isset($row['ur12ForExport'])) {
                            $objWorksheet->setCellValue('I' . $i, $row['ur12ForExport']);
                        }
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Events section
        if (in_array('event', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Event');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Event Name')
                        ->setCellValue('C1', 'Event Type')
                        ->setCellValue('D1', 'Session Type')
                        ->setCellValue('E1', 'Session Name')
                        ->setCellValue('F1', 'Role')
                        ->setCellValue('G1', 'Topic')
                        ->setCellValue('H1', 'Start')
                        ->setCellValue('I1', 'End')
                        ->setCellValue('J1', 'Organizer')
                        ->setCellValue('K1', 'Organizer Type')
                        ->setCellValue('L1', 'Session Sponsor')
                        ->setCellValue('M1', 'Sponsor Type')
                        ->setCellValue('N1', 'Location')
                        ->setCellValue('O1', 'Address')
                        ->setCellValue('P1', 'Country')
                        ->setCellValue('Q1', 'State')
                        ->setCellValue('R1', 'City')
                        ->setCellValue('S1', 'Postal Code')
                        ->setCellValue('T1', 'Url1')
                        ->setCellValue('U1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Event Name')
                        ->setCellValue('C1', 'Event Type')
                        ->setCellValue('D1', 'Session Type')
                        ->setCellValue('E1', 'Session Name')
                        ->setCellValue('F1', 'Role')
                        ->setCellValue('G1', 'Topic')
                        ->setCellValue('H1', 'Start')
                        ->setCellValue('I1', 'End')
                        ->setCellValue('J1', 'Organizer')
                        ->setCellValue('K1', 'Organizer Type')
                        ->setCellValue('L1', 'Session Sponsor')
                        ->setCellValue('M1', 'Sponsor Type')
                        ->setCellValue('N1', 'Location')
                        ->setCellValue('O1', 'Address')
                        ->setCellValue('P1', 'Country')
                        ->setCellValue('Q1', 'State')
                        ->setCellValue('R1', 'City')
                        ->setCellValue('S1', 'Postal Code');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrEventsDetails = $this->kol->listAllEvents($kolsId);
                foreach ($arrEventsDetails as $row) {
                    if ($row['type'] == 'conference') {
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                                ->setCellValue('B' . $i, $row['name'])
                                ->setCellValue('C' . $i, $row['event_type'])
                                ->setCellValue('D' . $i, $row['session_type'])
                                ->setCellValue('E' . $i, $row['session_name'])
                                ->setCellValue('F' . $i, $row['role'])
                                ->setCellValue('G' . $i, $this->kol->getTopicName($row['topic']))
                                ->setCellValue('H' . $i, $row['start'])
                                ->setCellValue('I' . $i, $row['end'])
                                ->setCellValue('J' . $i, $row['organizer'])
                                ->setCellValue('K' . $i, $row['otype'])
                                ->setCellValue('L' . $i, $row['session_sponsor'])
                                ->setCellValue('M' . $i, $row['stype'])
                                ->setCellValue('N' . $i, $row['location'])
                                ->setCellValue('O' . $i, $row['address'])
                                ->setCellValue('P' . $i, $row['Country'])
                                ->setCellValue('Q' . $i, $row['Region'])
                                ->setCellValue('R' . $i, $row['City'])
                                ->setCellValue('S' . $i, $row['postal_code']);
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $objWorksheet->setCellValue('T' . $i, $row['url1ForExport']);
                            }
                            if (isset($row['ur12ForExport'])) {
                                $objWorksheet->setCellValue('U' . $i, $row['ur12ForExport']);
                            }
                        }
                    }

                    if ($row['type'] == 'online') {
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                                ->setCellValue('B' . $i, ucwords($row['type']))
                                ->setCellValue('C' . $i, $row['name'])
                                ->setCellValue('D' . $i, $row['event_type'])
                                ->setCellValue('E' . $i, $row['session_type'])
                                ->setCellValue('F' . $i, $row['role'])
                                ->setCellValue('G' . $i, $this->kol->getTopicName($row['topic']))
                                ->setCellValue('H' . $i, $row['start'])
                                ->setCellValue('I' . $i, $row['end'])
                                ->setCellValue('J' . $i, $row['organizer'])
                                ->setCellValue('K' . $i, '')
                                ->setCellValue('L' . $i, '')
                                ->setCellValue('M' . $i, '')
                                ->setCellValue('N' . $i, $row['location'])
                                ->setCellValue('O' . $i, $row['Address'])
                                ->setCellValue('P' . $i, $row['Country'])
                                ->setCellValue('Q' . $i, $row['Region'])
                                ->setCellValue('R' . $i, $row['City'])
                                ->setCellValue('S' . $i, '');
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $objWorksheet->setCellValue('T' . $i, $row['url1ForExport']);
                            }
                            if (isset($row['ur12ForExport'])) {
                                $objWorksheet->setCellValue('U' . $i, $row['ur12ForExport']);
                            }
                        }
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Publications section
        if (in_array('publication', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('publication');
            //Add header
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Article Title')
                    ->setCellValue('C1', 'PMID')
                    ->setCellValue('D1', 'Journal Name')
                    ->setCellValue('E1', 'Date')
                    ->setCellValue('F1', 'Authors')
                    ->setCellValue('G1', 'Authorship Position');

            $i = 2;
            $this->load->model('pubmed');
            foreach ($arrKolIds as $kolsId) {
                //Get the details for Pubmed
                $arrPublications = array();
                if ($arrPublicationsResults = $this->pubmed->listPublicationDetails($kolsId)) {
                    foreach ($arrPublicationsResults as $arrPublicationsResult) {
                        $arrPublication['id'] = $arrPublicationsResult['id'];
                        $arrPublication['pmid'] = $arrPublicationsResult['pmid'];
                        $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                        $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                        $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                        $arrPublication['date'] = $this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
                        $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                        $arrPublication['auth_pos'] = $arrPublicationsResult['auth_pos'];
                        //$arrPublication['auth_pos']		= $this->pubmed->getAuthPosForPublication($arrPublicationsResult['journal_id']);
                        $arrPublication['kol_id'] = $kolsId;
                        $arrPublications[] = $arrPublication;
                    }
                }

                foreach ($arrPublications as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['article_title'])
                            ->setCellValue('C' . $i, $row['pmid'])
                            ->setCellValue('D' . $i, $row['journal_name'])
                            ->setCellValue('E' . $i, $row['date'])
                            ->setCellValue('F' . $i, $row['authors'])
                            ->setCellValue('G' . $i, $row['auth_pos']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Trial section
        if (in_array('trial', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Trial');
            $i = 2;
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'CTID')
                    ->setCellValue('C1', 'Study Type')
                    ->setCellValue('D1', 'Trial Name')
                    ->setCellValue('E1', 'Condition')
                    ->setCellValue('F1', 'Intervention')
                    ->setCellValue('G1', 'Phase')
                    ->setCellValue('H1', 'Role')
                    ->setCellValue('I1', 'Number of enrollees')
                    ->setCellValue('J1', 'Number of trial sites')
                    ->setCellValue('K1', 'Sponsors')
                    ->setCellValue('L1', 'Status')
                    ->setCellValue('M1', 'Start Date')
                    ->setCellValue('N1', 'End Date')
                    ->setCellValue('O1', 'Minimum Age')
                    ->setCellValue('P1', 'Maximum Age')
                    ->setCellValue('Q1', 'Gender')
                    ->setCellValue('R1', 'Investigators')
                    ->setCellValue('S1', 'Collaborator')
                    ->setCellValue('T1', 'Purpose')
                    ->setCellValue('U1', 'Official Title')
                    ->setCellValue('V1', 'Keywords')
                    ->setCellValue('W1', 'MeSH Terms')
                    ->setCellValue('X1', 'Url');
            //Get the details for Clinical Trials
            $this->load->model('clinical_trial');
            foreach ($arrKolIds as $kolsId) {
                $arrClinicalTrials = array();
                if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolsId)) {
                    foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                        $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                        $arrClinicalTrial['ct_id'] = $arrClinicalTrialsResult['ct_id'];
                        $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                        $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                        $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                        $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                        $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['kol_id'] = $kolsId;
                        $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                        $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                        $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                        $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                        $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                        $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                        $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                        $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                        $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                        $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                        $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                        $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                        $arrKeywordsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrKeywordsData .= $separator . $row['name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['keywords'] = $arrKeywordsData;
                        $arrMeshtermsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrMeshtermsData .= $separator . $row['term_name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                        $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                        $arrClinicalTrials[] = $arrClinicalTrial;
                    }
                }

                foreach ($arrClinicalTrials as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['ct_id'])
                            ->setCellValue('C' . $i, $row['study_type'])
                            ->setCellValue('D' . $i, $row['trial_name'])
                            ->setCellValue('E' . $i, $row['condition'])
                            ->setCellValue('F' . $i, $row['interventions'])
                            ->setCellValue('G' . $i, $row['phase'])
                            ->setCellValue('H' . $i, $row['kol_role'])
                            ->setCellValue('I' . $i, $row['no_of_enrollees'])
                            ->setCellValue('J' . $i, $row['no_of_trial_sites'])
                            ->setCellValue('K' . $i, $row['sponsors'])
                            ->setCellValue('L' . $i, $row['status'])
                            ->setCellValue('M' . $i, $row['start_date'])
                            ->setCellValue('N' . $i, $row['end_date'])
                            ->setCellValue('O' . $i, $row['min_age'])
                            ->setCellValue('P' . $i, $row['max_age'])
                            ->setCellValue('Q' . $i, $row['gender'])
                            ->setCellValue('R' . $i, $row['investigators'])
                            ->setCellValue('S' . $i, $row['collaborator'])
                            ->setCellValue('T' . $i, $row['purpose'])
                            ->setCellValue('U' . $i, $row['official_title'])
                            ->setCellValue('V' . $i, $row['keywords'])
                            ->setCellValue('W' . $i, $row['mesh_terms'])
                            ->setCellValue('X' . $i, $row['url']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Social Media section
        if (in_array('media', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Social Media');
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Blog')
                    ->setCellValue('C1', 'Linkedin')
                    ->setCellValue('D1', 'Facebook')
                    ->setCellValue('E1', 'Twitter')
                    ->setCellValue('F1', 'YouTube');
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['blog'])
                            ->setCellValue('C' . $i, $row['linked_in'])
                            ->setCellValue('D' . $i, $row['facebook'])
                            ->setCellValue('E' . $i, $row['twitter'])
                            ->setCellValue('F' . $i, $row['you_tube']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
//		}
        // remove first sheet

        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );

        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            if (in_array('professional', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'P') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($arrStyles);
            }
            if (in_array('contact', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'J') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($arrStyles);
            }
            if (in_array('contact', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'J') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($arrStyles);
            }
            if (in_array('biography', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'C') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($arrStyles);
            }
            if (in_array('education', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'H') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($arrStyles);
            }
            if (in_array('affiliation', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'I') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($arrStyles);
            }
            if (in_array('event', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'U') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:U1')->applyFromArray($arrStyles);
            }
            if (in_array('publication', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'G') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($arrStyles);
            }
            if (in_array('trial', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'X') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:X1')->applyFromArray($arrStyles);
            }
            if (in_array('media', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'F') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

        /* // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="kol_profiles.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output'); */
        //$objWriter->setInputEncoding('ISO-8859-1');
        //$objWriter->setUseBOM(true);
        $filePath	= $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/export_data/".$folder."/KTL_profiles".$filecount.".xlsx";
        $objWriter->save($filePath);
    }
	function get_pub_authors($pubId) {
        $authNames = '';
        $arrAuthors = $this->pubmed->listPublicationAuthors($pubId);
        foreach ($arrAuthors as $author) {
            $authName = $author['last_name'] . " " . $author['initials'];
            if ($authNames == '') {
                $authNames = $authName;
            } else {
                $authNames = $authNames . "," . $authName;
            }
        }
        return $authNames;
    }
	function get_sponsers($ctId) {
        $sponsersNames = '';
        $arrSponsers = $this->clinical_trial->listCTSponsors($ctId);
        foreach ($arrSponsers as $sponser) {
            $sponserName = $sponser['agency'];
            if ($sponsersNames == '') {
                $sponsersNames = $sponserName;
            } else {
                $sponsersNames = $sponsersNames . ";" . $sponserName;
            }
        }
        return $sponsersNames;
    }

    function get_interventions($ctId) {
        $interventionsNames = '';
        $arrInterventions = $this->clinical_trial->listCTInterventions($ctId);
        foreach ($arrInterventions as $intervention) {
            $interventionName = $intervention['name'];
            if ($interventionsNames == '') {
                $interventionsNames = $interventionName;
            } else {
                $interventionsNames = $interventionsNames . ";" . $interventionName;
            }
        }
        return $interventionsNames;
    }

    function get_investigators($ctId) {
        $investigatorsNames = '';
        $arrInvestigators = $this->clinical_trial->listCTInvestigators($ctId);
        foreach ($arrInvestigators as $investigator) {
            $investigatorName = $investigator['last_name'];
            if ($investigatorsNames == '') {
                $investigatorsNames = $investigatorName;
            } else {
                $investigatorsNames = $investigatorsNames . ";" . $investigatorName;
            }
        }
        return $investigatorsNames;
    }
	function import(){
		$data['contentPage']					= 'identification/import';
		$this->load->view('layouts/client_view',$data);
	}
	
	function sortbykey($a, $b) {
	    //return $b['score'] - $a['score'];
	    return $b['score'] > $a['score'] ? 1 : -1;
	}
	
	function get_activity_details_by_kol_id($kol_id,$projectId,$activityType,$startYear,$endYear){
	    ini_set('memory_limit','-1');
	    
	    $page	= $_REQUEST['page']; // get the requested page
	    
	    $limit 	= $_REQUEST['rows']; // get how many rows we want
	    
	    $sidx 	= $_REQUEST['sidx']; // get index row - i.e. user click to sort
	    
	    $sord 	= $_REQUEST['sord']; // get the direction
	    
	    if(!$sidx) $sidx =1;
	    
	    // connect to the database
	    
	    $filterData=$_REQUEST['filters'];
	    $arrFilter=array();
	    $arrFilter=json_decode(stripslashes($filterData));
	    $field='field';
	    $op='op';
	    $data='data';
	    $groupOp='groupOp';
	    $searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
	    $searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
	    $searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
	    $searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
	    $whereResultArray=array();
	    foreach($searchField as $key=> $val){
	        $whereResultArray[$val]=$searchString[$key];
	    }
	    $searchGroupOperator=$searchGroupOperator[0];
	    $searchResults=array();
	    
	    $count	= $this->identification->getActivityByKolId($kol_id,$projectId,$activityType,$startYear,$endYear,$limit,$start,true,$sidx,$sord,$whereResultArray);
	    if( $count >0 )
	    
	    {
	        
	        $total_pages = ceil($count/$limit);
	        
	    }
	    
	    else { $total_pages = 0;
	    
	    }
	    
	    if ($page > $total_pages)
	        
	        $page=$total_pages;
	        
	        $start = $limit*$page - $limit; // do not put  $limit*($page - 1)
	        
	        $arrActivityDetailResult	= $this->identification->getActivityByKolId($kol_id,$projectId,$activityType,$startYear,$endYear,$limit,$start,false,$sidx,$sord,$whereResultArray);
// 	        	        echo $this->db->last_query();exit;
	        $i = 0;
	        $arrActivityDetails = array();
	        foreach($arrActivityDetailResult->result_array() as $row){
	            if($row['project_id'] == '' || $row['project_id'] == null || $row['project_id'] == 0){
	                $row['is_project'] = '<span style="color:red;font-weight:bold;">No</span>';
	            }else{
	                $row['is_project'] = '<span style="color:green;font-weight:bold;">Yes</span>';
	            }
	            if($activityType=='affiliation'){
	                if ($row['type'] == "university") {
	                    $row['type'] = "Univ/Hospital";
	                } else {
	                    $row['type'] = ucfirst($row['type']);
	                }
	                $row['date'] = '';
	                if ($row['start_date'] != '')
	                    $row['date'] .= $row['start_date'];
                    else
                        $row['date'] .= 'NA';
                    
                    $row['date'] .= " - ";
                    
                    if ($row['end_date'] != '')
                        $row['date'] .= $row['end_date'];
                    else
                        $row['date'] .= 'NA';
                            
                    if ($row['date'] == 'NA - NA')
                        $row['date'] = '';
	            }
	            if($activityType=='publication'){
	                $row['date'] = sql_date_to_app_date($row['created_date']);
	            }
	            if($activityType=='trial'){
	                if($row['link'] != null && $row['link'] != '')
	                    $trialLink					= $row['link'];
	                
                    $row['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$row['trial_name'].'</a>';
                    $row['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$row['ct_id'].'</a>';
	            }
	            $arrActivityDetails[] = $row;
	            $i++;
	        }
	        $dataRec['records'] = $count;
	        $dataRec['total'] = $total_pages;
	        $dataRec['page'] = $page;
	        $dataRec['rows'] = $arrActivityDetails;
	        echo json_encode($dataRec);
	}
	
	function save_project_activity_association(){
	    $actionIds = $this->input->post('actionIds');
	    $actionType = $this->input->post('actionType');
	    $action = $this->input->post('action');
	    $project_id = $this->input->post('project_id');
	    $kol_id = $this->input->post('kol_id');
	    $this->identification->updateProjectAssociations($actionIds,$actionType,$action,$project_id,$kol_id);
	    if($actionType=='publication' && $action=='association'){
	       $this->calculate_kol_auth_position($kol_id);
	    }
	    $data['status'] = true;
	    echo json_encode($data);
	}
	
	function calculate_kol_auth_position($kolId=0){
	    $this->db->where("kol_id",$kolId);
	    $result1 = $this->db->get('kol_publications');
	    //             pr($result1->result_array());
	    if($result1->num_rows() > 0){
	        foreach ($result1->result_array() as $kolPubs){
	            $this->db->where("pub_id",$kolPubs["pub_id"]);
	            $kolPubAuthresult = $this->db->get('publications_authors');
	            $totalAuthCount = $kolPubAuthresult->num_rows();
	            $authPosCat = '';
	            if($totalAuthCount == 1){
	                $authPosCat = 'sa';
	            }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] == 1){
	                $authPosCat = 'fa';
	            }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] == $totalAuthCount){
	                $authPosCat = 'la';
	            }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] < $totalAuthCount && $kolPubs["auth_pos"] > 1){
	                $authPosCat = 'ma';
	            }
	            //                     pr($kolPubs);
	            $this->db->where("id",$kolPubs['id']);
	            $this->db->set("position_category",$authPosCat);
	            $this->db->update("kol_publications");	            
	        }
	    }
	}
	
	
	function get_client_kolIds(){
	    $data=$this->identification->getClentKolIds();
	    echo json_encode($data);
	}
	
	function save_kol_to_contact($kolIds=0,$ipad=false){
	    $kol_id = 0;
	    if($kolIds==0){
	       $kolIds = $this->input->post('kol_id');
	    }else{
	        $kol_id = $kolIds;
	        $kolIds = array($kol_id);
	    }
	    //Assign User
	    $dataType = 'User Added';
	    $client_id =$this->session->userdata('client_id');
	    if($client_id == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
	    foreach($kolIds as $key=>$value){
    	    $arrAssData = array();
    	    $arrAssData['created_by'] = $this->session->userdata('user_id');
    	    $arrAssData['created_on'] = date('Y-m-d H:i:s');
    	    $arrAssData['user_id'] = $this->session->userdata('user_id');
    	    $arrAssData['kol_id'] = $value;
    	    $arrAssData['data_type_indicator'] = $dataType;
    	    $arrAssData['type'] = 1;
    	    $saveAssignId = $this->kol->saveAssignClient($arrAssData);
    	    //Add Log activity
    	    $formData = $_POST;
    	    $formData = json_encode($formData);
    	    $arrLogDetails = array(
    	        'type' => ADD_RECORD,
    	        'description' => 'Save Add to Contact',
    	        'status' => STATUS_SUCCESS,
    	        'kols_or_org_type' => 'Kol',
    	        'kols_or_org_id' => $value,
    	        'transaction_id' => $saveAssignId,
    	        'transaction_table_id' => KOLS,
    	        'transaction_name' => "Save Add to Contact",
    	        'form_data' => $formData,
    	        'parent_object_id' => $value
    	    );
    	    $this->config->set_item('log_details', $arrLogDetails);
    	    log_user_activity(null,true);
	    }
	    $this->identification->saveKolToContact($kolIds);
	    $data['status']=true;
	    if($kol_id==0){
	       echo json_encode($data);
	    }else{
	        if(!$ipad){
	           redirect(base_url() . 'kols/view/' . $kol_id);
	        }else if($ipad==1){
	            redirect(base_url() .IPAD_URL_SEGMENT .'/kols/view/' . $kol_id);
	        }else if($ipad==2){
	            redirect(base_url() .MOBILE_URL_SEGMENT .'/kols/view/' . $kol_id);
	        }
	    }
	}
	
	function get_kols_by_project($projectId,$projectAssoc = false){
	    $page				= (int)$this->input->post('page'); // get the requested page
	    $limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
	    $data				= array();
	    $arrReturnData = array();
	    $arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
	    if($projectAssoc){
	        $arrKolData = $this->identification->getAssociatedNonAssociatedProjectKols($projectId,true);
	    }else{
	        $arrKolData = $this->identification->getAssociatedNonAssociatedProjectKols($projectId,false);
	        
	    }
	    foreach ($arrKolData as $row) {
	        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
	        $kolName = $arrSalutations[$row['salutation']] . ' ' . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
	        $row['kol_name'] = $kolName;
	        $row['id'] = $row['id'];
	        $row['is_imported'] = $row['is_imported'];
	        //				$row['kol_name']	.= (isset($row['is_imported']) && $row['is_imported']==1) ? '<span class="highlightImported"> (xls)<span>':'';
	        $row['created_by'] = $row['user_full_name'];
	        if ($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN) {
	            if ($row['is_pubmed_processed'] == 0)
	                $pubStatusHtml = "No";
	                
	                if ($row['is_pubmed_processed'] == 1)
	                    $pubStatusHtml = "Yes";
	                    
	                    if ($row['is_pubmed_processed'] == 2)
	                        $pubStatusHtml = "Re crawl";
	                        
	                        $row['pubmed_processed'] = $pubStatusHtml;
	        }else {
	            $pubStatus = 'No';
	            if ($row['is_pubmed_processed'] == 1)
	                $pubStatus = 'Yes';
	                if ($row['is_pubmed_processed'] == 2)
	                    $pubStatus = 'Re crawl';
	                    $row['pubmed_processed'] = $pubStatus;
	        }
	        $row['trial_processed'] = ($row['is_clinical_trial_processed'] == 1) ? 'Yes' : 'No';
	        $row['organization'] = $row['org_name'];
	        $row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['id'] . '">' . $kolName . '</a>';
	        $arrReturnData[] = $row;
	    }
	    $count=sizeof($arrReturnData);
	    if( $count >0 ){
	        $total_pages = ceil($count/$limit);
	    }else{
	        $total_pages = 0;
	    }
	    
	    $data['records']=$count;
	    $data['total']=$total_pages;
	    $data['page']=$page;
	    $data['rows']=$arrReturnData;
	    echo json_encode($data);
	}
}



