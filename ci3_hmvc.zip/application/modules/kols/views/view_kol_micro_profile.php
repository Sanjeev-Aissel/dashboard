<style>
#kolMicroProfileContent{
	font-size:75%;
}
</style>
<?php 
	if(!empty($arrKol['primary_phone']) && sizeof($arrKol['primary_phone'])>10){
		$arrKol['primary_phone']	= (($arrKol['primary_phone'][0]=="+")?'':'+').$arrKol['primary_phone'];
	}
	if(!empty($arrKol['fax']) && sizeof($arrKol['fax'])>10){
		$arrKol['fax']				= (($arrKol['fax'][0]=="+")?'':'+').$arrKol['fax'];
	}
	if($arrKol['gender']==''){
		$arrKol['gender']	= 'male';
	}
	if($arrKol['name'] != '' && $arrKol['org_status'] == 'Completed'){
		//$arrKol['name']	= '<a href="'.base_url().'organizations/view/'.$arrKol['org_id'].'">'.$arrKol['name'].'<a/>';
		$arrKol['name']	= $arrKol['name'];
	}
?>
<!-- Start of Micro View -->
<div id="kolMicroProfileContent">
<?php $requestKolId = 'requestKolId'.$arrKol['id'];?>
	<div class="microViewThumbnail">
		<?php 
			if($arrKol['profile_image'] != ''){?>
				<img alt="Image" src="<?php echo base_url();?>images/kol_images/resized/<?php echo  $arrKol['profile_image'];?>"/>
			<?php } else{?>
				<img width="100" height="100" src="<?php echo base_url();?>assets/modules/kols/images/<?php echo strtolower($arrKol['gender']);?>_kol_profile.svg" alt="Image">
			<?php 
			}
			if($arrKol['opt_in_out_status']!='5'){
				echo '<div class="view-link">';
					echo '<a class="btn custom-btn" href="'.base_url().'kols/kols/view/'.$arrKol['unique_id'].'" target="_new">View Profile</a>';
					$arrKol['kol_id'] = $arrKol['id']; 
					if($showProfileRequestButton != 1){
					    if($arrKol['profile_type']!='User Added' && $arrKol['profile_type']!='Legacy'){
					        if($arrKol['request_status']==1 || $arrKol['request_status']==2) {
					            echo '<a rel="tooltip" class="btn custom-btn requestProfileIcon '.$requestKolId.'"  style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>';
					        } else {					            
					            echo '<a rel="tooltip" onclick="addNewKolProfile('.$arrKol['id'].'); return false;" class="btn custom-btn '.$requestKolId.'" title="Submit new profile request" style="">Request</a>';
					        }
					    }else{
					        if($arrKol['request_status']==1 || $arrKol['request_status']==2) {
					            echo '<a rel="tooltip" class="btn custom-btn requestProfileIcon '.$requestKolId.'"  style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>';
					        } else {
					            echo '<a rel="tooltip" onclick="addNewKolProfileUAL('.$arrKol['id'].'); return false;" class="requestProfileIcon btn custom-btn '.$requestKolId.'" title="Submit new profile request">Request</a>';
					        }
					    }
					}
				echo '</div>';
			}
		?>
	</div>
	<div>
		<div>
			<p class="kolName">
			<?php echo $arrSalutations[$arrKol['salutation']]." ".$this->common_helper->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'<span class="suffix">('.str_replace(",", ", ", $arrKol['suffix']).')</span>'?>
			</p>
		</div>
		<table style="width:290px">
			<?php if(!empty($arrKol['specialty_name'])){?>
			<tr>
				<td>
					<div>
						<?php echo '<div class="kolSpecialty sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Specialty" style="cursor: default;">&nbsp;</a></div><p>'.$arrKol['specialty_name'].'<br/>'.implode(", ",$arrSubSpecialties).'</p>';?>
					</div>
				</td>
			</tr>
			<?php }?>
			<?php if(!empty($arrKol['title']) || !empty($arrKol['division'])){ ?>
			<tr>
				<td>
					<div>
						<?php 
						$arrTitleDivision	= array();
						if ($arrKol['title'] != '') {
						    $arrTitleDivision[]	= $arrKol['title'];
						}
						if ($arrKol['division'] != '') {
						    $arrTitleDivision[]	= $arrKol['division'];
						}?>
						
						<div class="kolDesignation sprite_iconSet">
							<a href="#" class="tooltipLink" rel='tooltip' title="Position/Department" style="cursor: default;">&nbsp;</a>
						</div>
						<p><?php echo implode(", ",$arrTitleDivision);?></p>
					</div>
				</td>
			</tr>
			<?php }?>
			<?php if(!empty($arrKol['name']) || !empty($arrKol['private_practice'])){?>
			<tr>
				<td>
					<div>
					<?php if($arrKol['name'] != '' && $arrKol['org_id'] != ''){
	// 					if($this->organization->isOrgLinkAllowed($arrKol['org_id'])){
							$orgLink = '<a href="'.base_url().'organizations/view/'.$arrKol['org_id'].'">'.$arrKol['name'].'</a>';
	// 					} else {
	// 						$orgLink = $arrKol['name'];
	// 					}
						echo '<div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Institution Name" style="cursor: default;">&nbsp;</a></div>'.$orgLink;
					} else{
					    if($arrKol['private_practice']!=''){
	    						$orgLink = $arrKol['private_practice'];
						    echo '<div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Institution Name" style="cursor: default;">&nbsp;</a></div>'.$orgLink;
					    }
					}?>
					</div>
				</td>
			</tr>
			<?php }?>
		</table>
	</div>
	<table class="microViewTbl">
		<tr>
			<td colspan="4">
				<div class="kolAddress sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Address" style="cursor: default;">&nbsp;</a></div>
				<?php
					if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
						echo $arrKol['address1'].", ";
					if(!empty($arrKol['address2']) && isset($arrKol['address2']))
						echo $arrKol['address2'].", ";
					if(!empty($arrKol['city']) && isset($arrKol['city']))
						echo $arrKol['city'].", ";
					if(!empty($arrKol['state']) && isset($arrKol['state'])){
						if($arrKol['country']=='United States')
							echo $arrKol['state_code']." ";
						else
							echo $arrKol['state']." ";
					}
					if((!empty($arrKol['postal_code']) && isset($arrKol['postal_code'])))
						echo " ".$arrKol['postal_code'].", ";
					if(!empty($arrKol['country']) && isset($arrKol['country']))
						echo $arrKol['country']." ";
				?>
			</td>
		</tr>
		<tr>
			<?php if(!empty($arrKol['primary_phone'])){?>
			<td colspan="2">
				<div class="sprite_iconSet contactNumber">
					<a href="#" class="tooltipLink" rel='tooltip' title="Phone No." style="cursor: default;">&nbsp;</a>
				</div>
				<?php if($arrKol['primary_phone']!=''){
					 echo '<a class="linkClickToCall" href="callto:'.$arrKol['primary_phone'].'" >'.$arrKol['primary_phone'].'</a>';
				}?>
			</td>
			<?php }?>
			<?php if(!empty($arrKol['fax'])){?>
			<td colspan="2">
				<div class="sprite_iconSet faxNumber">
					<a href="#" class="tooltipLink" rel='tooltip' title="Fax No." style="cursor: default;">&nbsp;</a>
				</div>
				<?php if($arrKol['fax']!=''){
					echo '<a class="linkClickToCall" href="callto:'.$arrKol['fax'].'" >'.$arrKol['fax'].'</a>';
				}?>
			</td>
			<?php }?>
		</tr>
		<?php if(!empty($arrKol['primary_email'])){?>
		<tr>
			<td colspan="4">
				<div class="sprite_iconSet emailId">
					<a href="#" class="tooltipLink" rel='tooltip' title="Email ID" style="cursor: default;">&nbsp;</a>
				</div>
				<a id="emailHolder" href="mailto:<?php echo $arrKol['primary_email'];?>" >
					<?php echo $arrKol['primary_email'];?>
				</a>
			</td>
		</tr>
		<?php }?>
		<?php if($type==null){?>
			<tr>
				<th><span class="addrHeading">Affiliations</span></th>
				<th><span class="addrHeading">Events</span></th>
				<th><span class="addrHeading">Publications</span></th>
 				<th><span class="addrHeading">Trials</span></th>
			</tr>
			<tr>
				<td class="alignCenter"><?php echo $noOfAffilitions;?></td>
				<td class="alignCenter"><?php echo $noOfEvents;?></td>
				<td class="alignCenter"><?php echo $noOfPublications;?></td>
				<td class="alignCenter"><?php echo $noOfTrials;?></td>
			</tr>
		<?php }?>
	</table>
</div>