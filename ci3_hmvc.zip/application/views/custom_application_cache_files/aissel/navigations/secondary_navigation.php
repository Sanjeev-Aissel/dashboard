<?php
							$current_tab= ltrim($_SERVER["PATH_INFO"],"/");
							$uri_elements=explode("/",$current_tab);
							$url_id=implode("_",$uri_elements);
							$currentModule	= $uri_elements[0];
							$currentController	= $uri_elements[1];
							$currentMethod	= $uri_elements[2];
							$param1	= $uri_elements[3]==""?"":"/".$uri_elements[3];
							$param2	= $uri_elements[4]==""?"":"/".$uri_elements[4];
							$menuGenerator	= "";
							switch ($current_tab) {
										
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="add_kol") && ($uri_elements[4]=="details") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="dashboard") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="track") && true):
										case (($uri_elements[0]=="interactions") && ($uri_elements[1]=="interactions") && ($uri_elements[2]=="view_interactions") && true):
										case (($uri_elements[0]=="payments") && ($uri_elements[1]=="payments") && ($uri_elements[2]=="list_kol_payments") && true):
										case (($uri_elements[0]=="contracts") && ($uri_elements[1]=="contracts") && ($uri_elements[2]=="list_kol_contracts") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="all") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="all") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="university") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="associations") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="industry") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="govt_agency") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="others") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="reports_org") && true):
										case (($uri_elements[0]=="kols") && ($uri_elements[1]=="kols") && ($uri_elements[2]=="view_affiliations") && ($uri_elements[4]=="reports_eng") && true):
										case (($uri_elements[0]=="events") && ($uri_elements[1]=="events") && ($uri_elements[2]=="view_events") && ($uri_elements[4]=="conference") && true):
										case (($uri_elements[0]=="events") && ($uri_elements[1]=="events") && ($uri_elements[2]=="view_events") && ($uri_elements[4]=="conference") && true):
										case (($uri_elements[0]=="events") && ($uri_elements[1]=="events") && ($uri_elements[2]=="view_events") && ($uri_elements[4]=="session_type") && true):
										case (($uri_elements[0]=="pubmeds") && ($uri_elements[1]=="pubmeds") && ($uri_elements[2]=="view_publications") && ($uri_elements[4]=="search") && true):
										case (($uri_elements[0]=="pubmeds") && ($uri_elements[1]=="pubmeds") && ($uri_elements[2]=="view_publications") && ($uri_elements[4]=="search") && true):
										case (($uri_elements[0]=="pubmeds") && ($uri_elements[1]=="pubmeds") && ($uri_elements[2]=="view_publications") && ($uri_elements[4]=="reports") && true):
										case (($uri_elements[0]=="clinical_trials") && ($uri_elements[1]=="clinical_trials") && ($uri_elements[2]=="view_clinical_trials") && true):
															$menuGenerator	.= ' <div id="MainMenu"><div class="list-group panel">
																<a id="kols_kols_view'.str_replace('/','_',$param1).'" href="'.base_url().'kols/kols/view'.$param1.'" class="list-group-item list-group-item-default strong kols_kols_view'.str_replace('/','_',$param1).'">
																'.$this->load->view("kols/kol_profile",array("kol_id"=>$uri_elements[3]),true).'
																</a>
																<a href="#Overview" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																Overview<span class="caret"></span>
																</a><div class="collapse" id="Overview">
																	<a id="kols_kols_view'.str_replace('/','_',$param1).'" href="'.base_url().'kols/kols/view'.$param1.'" class="list-group-item kols_kols_view'.str_replace('/','_',$param1).'">Profile summary
																			 </a>
																			<a id="kols_kols_add_kol'.str_replace('/','_',$param1).'_details" href="'.base_url().'kols/kols/add_kol'.$param1.'/details" class="list-group-item kols_kols_add_kol'.str_replace('/','_',$param1).'_details">Details
																			 </a>
																			<a id="kols_kols_dashboard'.str_replace('/','_',$param1).'" href="'.base_url().'kols/kols/dashboard'.$param1.'" class="list-group-item kols_kols_dashboard'.str_replace('/','_',$param1).'">Dashboard
																			 </a>
																			</div> 
																<a href="#Track" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																Track<span class="caret"></span>
																</a><div class="collapse" id="Track">
																	<a id="interactions_interactions_view_interactions'.str_replace('/','_',$param1).'" href="'.base_url().'interactions/interactions/view_interactions'.$param1.'" class="list-group-item interactions_interactions_view_interactions'.str_replace('/','_',$param1).'">Interactions
																			 </a>
																			<a id="payments_payments_list_kol_payments'.str_replace('/','_',$param1).'" href="'.base_url().'payments/payments/list_kol_payments'.$param1.'" class="list-group-item payments_payments_list_kol_payments'.str_replace('/','_',$param1).'">Payments
																			 </a>
																			<a id="contracts_contracts_list_kol_contracts'.str_replace('/','_',$param1).'" href="'.base_url().'contracts/contracts/list_kol_contracts'.$param1.'" class="list-group-item contracts_contracts_list_kol_contracts'.str_replace('/','_',$param1).'">Contracts
																			 </a>
																			</div> 
																<a href="#Affiliations" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																Affiliations<span class="caret"></span>
																</a><div class="collapse" id="Affiliations">
																	<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_all" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/all" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_all">All
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_university" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/university" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_university">Univ/Hospital
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_associations" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/associations" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_associations">Associations
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_industry" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/industry" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_industry">Industry
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_govt_agency" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/govt_agency" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_govt_agency">Govt. Agency
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_others" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/others" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_others">Others
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_reports_org" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/reports_org" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_reports_org">Report Org
																			 </a>
																			<a id="kols_kols_view_affiliations'.str_replace('/','_',$param1).'_reports_eng" href="'.base_url().'kols/kols/view_affiliations'.$param1.'/reports_eng" class="list-group-item kols_kols_view_affiliations'.str_replace('/','_',$param1).'_reports_eng">Report Eng
																			 </a>
																			</div> 
																<a href="#Events" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																Events<span class="caret"></span>
																</a><div class="collapse" id="Events">
																	<a id="events_events_view_events'.str_replace('/','_',$param1).'_conference" href="'.base_url().'events/events/view_events'.$param1.'/conference" class="list-group-item events_events_view_events'.str_replace('/','_',$param1).'_conference">All
																			 </a>
																			<a id="events_events_view_events'.str_replace('/','_',$param1).'_session_type" href="'.base_url().'events/events/view_events'.$param1.'/session_type" class="list-group-item events_events_view_events'.str_replace('/','_',$param1).'_session_type">Event Charts
																			 </a>
																			</div> 
																<a href="#Publications" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																Publications<span class="caret"></span>
																</a><div class="collapse" id="Publications">
																	<a id="pubmeds_pubmeds_view_publications'.str_replace('/','_',$param1).'_search" href="'.base_url().'pubmeds/pubmeds/view_publications'.$param1.'/search" class="list-group-item pubmeds_pubmeds_view_publications'.str_replace('/','_',$param1).'_search">All
																			 </a>
																			<a id="pubmeds_pubmeds_view_publications'.str_replace('/','_',$param1).'_reports" href="'.base_url().'pubmeds/pubmeds/view_publications'.$param1.'/reports" class="list-group-item pubmeds_pubmeds_view_publications'.str_replace('/','_',$param1).'_reports">Pubs Charts
																			 </a>
																			</div> 
																<a id="clinical_trials_clinical_trials_view_clinical_trials'.str_replace('/','_',$param1).'" href="'.base_url().'clinical_trials/clinical_trials/view_clinical_trials'.$param1.'" class="list-group-item list-group-item-default strong clinical_trials_clinical_trials_view_clinical_trials'.str_replace('/','_',$param1).'">
																Clinical Trials
																</a>
															</div></div> ';
														break;
										 }
			if(!empty($menuGenerator)){
				echo '<td class="col-sm-2"><div id="secondaryMenuWrapper">'.$menuGenerator.'</div></td>';
			}
			?>
			<script type="text/javascript">
			var url_id='<?php echo $url_id;?>';
			$(document).ready(function(){
			    $("."+url_id).addClass("highlight_subtab");
			    
			    $("."+url_id).parent().prev().removeClass("collapsed");    
			    $("."+url_id).parent().prev().attr("aria-expanded","true");
			    $("."+url_id).parent().prev().addClass("active");
			
			    $("."+url_id).parent().removeClass("collapse");
			    $("."+url_id).parent().addClass("collapse in");
			});
			</script>	
		