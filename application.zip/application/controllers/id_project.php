<?php
/*
 * File to crawl publications and fetch unique authors and their publications count based on user input 
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v3.7
 * Created on	: 14-02-2012
 *  
 */
class Id_Project extends Controller{
	private $loggedUserId	= null;
	// constructor to initialize the data
	function Id_Project(){
		parent::Controller();
		$this->load->model('pubmed');
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	// by Default show form to process
	function index(){
		$data['showform']		= 1;
		$data['processStatus']	= 0;
		$data['contentPage'] 	= 'id_project/process_form';
		$this->load->view('layouts/client_view', $data);		
	}
	// display analysis result
	function display_result($projectId='',$limit=''){
		$data['project']		= $this->get_project_details($projectId);
		if($projectId!=''){
			$data['arrData']		= $this->get_unique_authors_analysis($projectId,$limit,'pubs_count');
		}
		$data['contentPage'] 	= 'id_project/unique_authors';
		$this->load->view('layouts/client_view', $data);
	}
	// start counting publications based on author name as input
	function process_form_data_author_name(){
		
		$projectName= (isset($_POST['project_name'])?$_POST['project_name']:'');
		$last_name	= (isset($_POST['lastname'])?$_POST['lastname']:'');
		$fore_name	= (isset($_POST['forename'])?$_POST['forename']:'');
		$initials	= (isset($_POST['initials'])?$_POST['initials']:'');
		
		if($projectName!=''){
		/*	if(empty($arrAuthorName['last_name']) && $arrAuthorName['last_name']==''){
				$arrAuthorName['last_name']	= ' ';
			}
			if(empty($arrAuthorName['fore_name']) && $arrAuthorName['fore_name']==''){
				$arrAuthorName['fore_name']	= ' ';
			}
			if(empty($arrAuthorName['initials']) && $arrAuthorName['initials']==''){
				$arrAuthorName['initials']	= ' ';
			}
		*/
			if(!empty($last_name)){
				$arrAuthorName['last_name'] = trim($last_name);
			}else{
				$arrAuthorName['last_name']	= ' ';
			}
			if(!empty($fore_name)){
				$arrAuthorName['fore_name'] = trim($fore_name);
			}else{
				$arrAuthorName['fore_name']	= ' ';
			}
			if(!empty($initials)){
				$arrAuthorName['initials'] = trim($initials);
			}else{
				$arrAuthorName['initials']	= ' ';
			}
				
			//pr($arrAuthorName);
			$arrAuthorName['unique_name']	= '';
			//$projectName				= $arrAuthorName['last_name'].$arrAuthorName['fore_name'].$arrAuthorName['initials'];
			$tableName					= 'id_unique_authors';
			
			$resultSet	= $this->db->query("select id from ".$tableName." where last_name='".$arrAuthorName['last_name']."' and fore_name='".$arrAuthorName['fore_name']."' and initials='".$arrAuthorName['initials']."'");
			if($resultSet->num_rows!=0){
				echo "Already exists";
			}else{
				$author_id		= $this->save_author($arrAuthorName);
				$project_id		= $this->save_project($projectName);
				$input_query_id	= $this->save_project_inputs($project_id,$projectName,0);
				$this->process_id_analysis($project_id,$input_query_id,$author_id,0);
				$this->unique_authors($project_id);
			}
		}else{
			
			$data['msg']			= '<span class="error">Identification Name should not be empty</span>';
			$data['processStatus']	= 0;
			$data['contentPage'] 	= 'id_project/process_form';
			$this->load->view('layouts/client_view', $data);
		}
		
	}
	// count publications of individual author in an project
	function individual_authors_process($projectId='', $authorId=''){
		$this->unique_authors($projectId,1, 'author_id', $authorId);
	}
	
	// fetch authors combination and count publications for each authors for all authors belongs to the project
	function unique_authors($projectId='',$limit='', $orderByfieldName='', $authorId=''){
		
		$arrUniqueAuthors	= $this->get_unique_authors_analysis($projectId,$limit,$orderByfieldName,$authorId);
		//pr($arrUniqueAuthors);
		foreach($arrUniqueAuthors as $key=>$arrAuthorFullName){
			$totalPMIDsCount	= $this->process_author_pubs_count($arrAuthorFullName['last_name'],$arrAuthorFullName['fore_name'],$arrAuthorFullName['initials']);
			//$arrAuthorsCount['authorName']	= $arrAuthorFullName;
			//$arrAuthorsCount['pmidsCount']	= $totalPMIDsCount;
			//$arrData[]	= $arrAuthorsCount;
			
			$updatePubsCount['pubs_count']	= $totalPMIDsCount;
			$this->db->where('project_id',$projectId);
			$this->db->where('author_id',$arrAuthorFullName['author_id']);
			$this->db->update('id_analysis',$updatePubsCount);
		}
		redirect('/id_project/display_result/'.$projectId.'/'.$limit);
	}
	
	// count publications on author name
	function process_author_pubs_count($lastName,$foreName,$initials){
		$maxScriptTime	= 360000;
		//$maxPMIDs		= 100000;
		ini_set("max_execution_time",$maxScriptTime);
		$arrPMIDsCount	= array();
		//echo $lastName.$foreName.$initials;
		$arrAuthorNames	= $this->pubmed->generate_name_combinations($lastName, $foreName, $initials);
		//pr($arrAuthorNames);
		/*foreach($arrAuthorNames as $key => $authorName){
			$term			= $authorName."[Author]";
			$url			= "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&usehistory=y&retmode=xml&term=$term";
			//$url		= "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=$maxPMIDs&usehistory=y&retmode=xml&term=$term";
			//echo $url."<br />";
			$content = file_get_contents($url);	
		
			if($content){				
				$xml = new DOMDocument();
				if(!$xml->loadXML($content)){
					$msg	.= "Error in Loading XML, Illigal format received <br />Terminating process..";
				}else{
					$arrPMIDs	= array();
					//$this->shownode($xml->getElementsByTagName('eSearchResult')->item(0));
										
					$arrPMIDsCount[]	= $xml->getElementsByTagName('Count')->item(0)->nodeValue;
				}
			}
			//$arrPMIDsCount[]	= sizeof($arrPMIDs);
		}
		*/
			$arrPMIDs=array();
			//$count=0;	
				
			foreach($arrAuthorNames as $authName){	
				
				//Notes about url
				//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results			
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=1000&usehistory=y&retmode=xml&term=".str_replace(" ", "%20", $authName)."[author";
				$content = file_get_contents($url);	
				if(!$content)	return false;				
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($content)){
					echo "Error in Loading XML, Illigal format received <br />";
				}	
				$idListObj = $xml->getElementsByTagName('IdList')->item(0);
				$idList=$idListObj->getElementsByTagName('Id');
				foreach($idList as $idObj){
					$arrPMIDs[]=$idObj->nodeValue;
				}
				//$count=sizeof($arrPMIDs);	
				//$this->logText	= "No of PMID's found for name '".$authName."': ".(sizeof($arrPMIDs)-$count)."\r\n";
			}
			$arrUniquePMIDs = array_unique($arrPMIDs);
		return sizeof($arrUniquePMIDs);
	}
	
	//	start processing of form data to get PMID's' and respective authors
	function process_form_data(){
		$maxPMIDs			= 50;
		$maxScriptTime		= 360000;
		$pmidBatchSize		= 10;
		$processStatus		= 0;
		$msg				= '';
		ini_set("max_execution_time",$maxScriptTime);
		
	//	pr($_POST);
		$arrParam			= array();
		$projectName		= (isset($_POST['project_name'])?$_POST['project_name']:'');
		
		$countries			= (isset($_POST['country'])?$_POST['country']:'');
		$specialities		= (isset($_POST['speciality'])?$_POST['speciality']:'');
		$meshterms			= (isset($_POST['meshterm'])?$_POST['meshterm']:'');
		$keywords			= (isset($_POST['keyword'])?$_POST['keyword']:'');
		if($projectName!=''){
			if($project_id	= $this->save_project($projectName)){
				$arrData	= array();
				foreach($countries as $ckey=>$country){
					foreach($specialities as $skey=>$speciality){
						foreach($meshterms as $mkey=>$meshterm){
							foreach($keywords as $kkey=>$keyword){
								$arrData[]	= $country.' '.$speciality.' '.$meshterm.' '.$keyword;
							}
						}
					}
				}
				//pr($arrData);
				foreach($arrData as $key => $term){
					$arrPMIDs	= '';
					$term		= trim($term);
					$url		= "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=$maxPMIDs&usehistory=y&retmode=xml&term=$term";
					$content	= file_get_contents($url);	
					if($content){
						$xml = new DOMDocument();
						if(!$xml->loadXML($content)){
							$msg	.= "Error in Loading XML, Illigal format received <br />";
							$msg	.= $url."<br />";
						}else{
							$idListObj	= $xml->getElementsByTagName('IdList')->item(0);
							$idList		= $idListObj->getElementsByTagName('Id');
							foreach($idList as $idObj){
								$arrPMIDs[]	= $idObj->nodeValue;
							}
							$msg	.= "No of PMID's found for query ".$term." : ".sizeof($arrPMIDs)."<br />";
							$arrUniqueAuthorsName	= $this->get_unique_authors();
							//pr($arrPMIDs);
							//echo $url."<br />";
							if($input_query_id	= $this->save_project_inputs($project_id,$term,sizeof($arrPMIDs))){
								//echo "query saved";
								for($i=0; $i<count($arrPMIDs);$i=$i+$pmidBatchSize){
									$pmidList	= '';
									for($j=$i; $j<$i+$pmidBatchSize; $j++){
										if(isset($arrPMIDs[$j]))
										if($arrPMIDs[$j]!=''){
											$this->save_pmid($arrPMIDs[$j]);
											$pmidList	= $pmidList."".$arrPMIDs[$j];
											if($j!=$i+9 )
												$pmidList	= $pmidList.",";
										}
									} // End of batching PMIDs
									$url	= "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmidList;
									//echo $url."<br />";
									$content = file_get_contents($url);	
									if($content){
										$xml = new DOMDocument();
										if(!$xml->loadXML($content)){
											$msg	.= "Error in Loading XML, Illigal format received <br />";
											$msg	.= $url."<br />";
										}else{
											$publications = $xml->getElementsByTagName('PubmedArticle');
												foreach($publications as $publication){
												//parse and save publication details
												$medlineCitation	= $publication->getElementsByTagName('MedlineCitation')->item(0);
												$pmidObj			= $medlineCitation->getElementsByTagName('PMID')->item(0);
												if($pmidObj!=null){
													$pmid		= $pmidObj->nodeValue;
													//if(!($this->is_pmid_processed($pmid))){
														$arrAuthors	= $this->parse_pubmed_details($medlineCitation);
														if(sizeof($arrAuthors)>0){
															//echo $input_query_id.'-'.$pmid.'<br />';
															//pr($arrAuthors);
															foreach($arrAuthors as $key => $arrAuthorName){
																if(isset($arrUniqueAuthorsName[$arrAuthorName['unique_name']])){
																//	echo "Already exists";
																//	pr($arrAuthorName);
																	$author_id	= $arrUniqueAuthorsName[$arrAuthorName['unique_name']];
																}else{
																	$author_id	= $this->save_author($arrAuthorName);
																	if(!$author_id){
																		$msg	.= "Unable to insert author ".$arrAuthorName['last_name'].' '.$arrAuthorName['fore_name'].' '.$arrAuthorName['initials']."<br />";
																		//pr($arrAuthorName);
																	}else{
																		$arrUniqueAuthorsName[$arrAuthorName['unique_name']]=$author_id;
																	}
																}
																if($author_id){
																	// then start counting.... $pmid, $project_id, $input_query_id
																	if($this->process_id_analysis($project_id,$input_query_id,$author_id,$pmid)){
																		// counted authors
																		$processStatus	= 1;
																	}else{
																		$msg	.= "Unable to count authors <br />";
																		$processStatus	= 0;
																	}
																}
															}
														}
												//		$updatePubsCount['is_processed']	= 1;
												//		$this->db->where('unique_pmid',$pmid);
												//		$this->db->update('id_processed_pubs',$updatePubsCount);
												//	}else{
														// PMID already Processed
														//$msg	.= $pmid." - Already Processed<br />";
												//	}
												}
											}
										}
									}
								}
							}else{
								$msg	.= "Unable to save query <br />";
							}
							//echo $url."<br />";
						}
					}else{
						$msg	.= "Unable to fetch data for the URL ".$url."<br />";
					}
				}
			}
		}else{
			$msg .= '<span class="error">Project Name should not be empty</span>';
			$data['processStatus']	= 0;
		}
		
		$data['msg']			= $msg;
		$data['projectId'] 		= $project_id;
		$data['processStatus'] 	= $processStatus;
		$data['contentPage'] 	= 'id_project/process_form';
		$this->load->view('layouts/client_view', $data);	
		
	} // end of function
	
	// save project name in DB table
	function save_project($projectName){
		$tableName	= 'id_project';
		$arrProject['project_name']	= $projectName;
		$arrProject['created_on']	= date("Y-m-d H:i:s");
		$arrProject['created_by']	= $this->loggedUserId;
		if($this->db->insert($tableName,$arrProject)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	//end of save_project function
	
	// save input queries/combinations in DB table
	function save_project_inputs($projectId, $inputQuery, $pmid_count){
		$tableName	= 'id_project_inputs';
		$arrInputQuery['project_id']	= $projectId;
		$arrInputQuery['input_query']	= $inputQuery;
		$arrInputQuery['total_pmids']	= $pmid_count;
		if($this->db->insert($tableName,$arrInputQuery)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	//end of save_project_inputs function
	
	
	//save unique PMID in Db table
	function save_pmid($pmid){
		$tableName		= 'id_processed_pubs';
		$resultSet	= $this->db->query("select unique_pmid from ".$tableName." where unique_pmid=".$pmid."");
		if($resultSet->num_rows!=0){
			return false;
		}else{
			$arrPMID['unique_pmid']	= $pmid;
			if($this->db->insert($tableName,$arrPMID)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
		
		
	}	//end of save_pmids function
	
	// process xml data of respective PMID
	function process_publications($publications){
		$arrUniqueAuthorsName	= $this->get_unique_authors();
		foreach($publications as $publication){
			//parse and save publication details
			$medlineCitation	= $publication->getElementsByTagName('MedlineCitation')->item(0);
			$pmidObj			= $medlineCitation->getElementsByTagName('PMID')->item(0);
			if($pmidObj!=null){
				$pmid		= $pmidObj->nodeValue;
				$arrAuthors	= $this->parse_pubmed_details($medlineCitation);
				if(sizeof($arrAuthors)>0){
					//echo $input_query_id.'-'.$pmid.'<br />';
					//pr($arrAuthors);
					foreach($arrAuthors as $key => $arrAuthorName){
						if(isset($arrUniqueAuthorsName[$arrAuthorName['unique_name']])){
						//	echo "Already exists";
						//	pr($arrAuthorName);
							$author_id	= $arrUniqueAuthorsName[$arrAuthorName['unique_name']];
						}else{
							$author_id	= $this->save_author($arrAuthorName);
							if(!$author_id){
								echo "Unable to insert author";
								//pr($arrAuthorName);
							}else{
								$arrUniqueAuthorsName[$arrAuthorName['unique_name']]=$author_id;
							}
						}
						$idAnalysisResult	= $this->process_id_analysis($input_query_id,$pmid,$author_id);
						if($idAnalysisResult){
							//echo "Successfull";
						}else{
							echo "Unable to process ID analysis";
							//pr($arrAuthorName);
						}
					}
				}
				$updatePubsCount['is_processed']	= 1;
				$this->db->where('unique_pmid',$pmid);
				$this->db->update('id_processed_pubs',$updatePubsCount);
			}
		}
	}	//end of process_publications function
	
	// get authors from PMID
	function parse_pubmed_details($medlineCitation){
		$arrAuthors	= array();
		// End Parsing article related data
		//$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$authors	= $medlineCitation->getElementsByTagName('Author');

		if($authors!=null){
			//$i	= 1;
			foreach($authors as $authorObj){
				//if($authorObj!=null && $i != 0){
				if($authorObj!=null){
					//pr($authorObj->nodeValue);
					$author		= array();
					$lastName	= '';
					$foreName	= '';
					$initials	= '';
					$lastNameObj	= $authorObj->getElementsByTagName('LastName')->item(0);
					$foreNameObj	= $authorObj->getElementsByTagName('ForeName')->item(0);
					$initialsObj	= $authorObj->getElementsByTagName('Initials')->item(0);
					if($lastNameObj!=null)
						$lastName	= $lastNameObj->nodeValue;
					if($foreNameObj!=null)
						$foreName	= $foreNameObj->nodeValue;
					if($initialsObj!=null)
						$initials	= $initialsObj->nodeValue;
					
					$author['last_name']	= $lastName;
					$author['fore_name']	= $foreName;
					$author['initials']		= $initials;
					$author['unique_name']	= str_replace(' ','',$lastName.$foreName.$initials);
					$arrAuthors[]			= $author;	
				
				}
				//$i++;
			}
		}
		
		return $arrAuthors;
		
	} // end of parse_pubmed_details function
	
	// get unique authors from DB table
	function get_unique_authors(){
		$arrUniqueAuthors	= array();
		$tableName	= 'id_unique_authors';
		$resultSet	= $this->db->query("select id, concat(last_name,fore_name,initials) as unique_name from ".$tableName);
		if($resultSet->num_rows!=0){
			foreach($resultSet->result_array() as $row){
				$arrUniqueAuthors[str_replace(' ','',$row['unique_name'])]	= $row['id'];
			}
			return $arrUniqueAuthors;
		}else{
			return false;
		}
		
	}//end of get_unique_authors function
	
	// save unique author in DB table
	function save_author($arrAuthorName){
		$tableName	= 'id_unique_authors';
		$arrNewAuthorName['last_name']	= $arrAuthorName['last_name'];
		$arrNewAuthorName['fore_name']	= $arrAuthorName['fore_name'];
		$arrNewAuthorName['initials']	= $arrAuthorName['initials'];
		unset($arrNewAuthorName['unique_name']);
		if(!(empty($arrNewAuthorName['last_name']) && empty($arrNewAuthorName['fore_name']) && empty($arrNewAuthorName['initials']))){
			if($this->db->insert($tableName,$arrNewAuthorName)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}else{
			return false;
		}
		
	}//end of save_author function
	
	// start analysing data
	function process_id_analysis($project_id,$input_query_id,$author_id,$pmid){
		$tableName	= 'id_analysis';
		$resultSet	= $this->db->query("select id,auth_count from ".$tableName." where project_id=".$project_id." and pmid=".$pmid." and author_id=".$author_id);
		if($resultSet->num_rows==0){
			//echo "insert new";
			$arrAnalysis['project_id']	= $project_id;
			$arrAnalysis['query_id']	= $input_query_id;
			$arrAnalysis['author_id']	= $author_id;
			$arrAnalysis['pmid']		= $pmid;
			$arrAnalysis['auth_count']	= 1;
			if($this->db->insert($tableName,$arrAnalysis)){
				return $this->db->insert_id();
			}else{
				return false;
			}
			
		}else{
			//echo "updating existing";
			foreach($resultSet->result_array() as $row){
				//update pubs count by 1
				$updatePubsCount['auth_count']	= ($row['auth_count']+1);
				$this->db->where('id',$row['id']);
				$this->db->where('project_id',$project_id);
				//$this->db->where('query_id',$input_query_id);
				$this->db->where('author_id',$author_id);
				$this->db->where('pmid',$pmid);
				$this->db->update($tableName,$updatePubsCount);
				
			}
		}
		return true;
	}	//end of process_id_analysis function
	// get author analysis data from DB Table
	function get_unique_authors_analysis($projectId,$limit='',$orderByfieldName='', $authorId=''){
		$tableName			= 'id_analysis';
		$authorTableName	= 'id_unique_authors';
		$arrUniqueAuthors	= array();
		$query	= "select ia.author_id,a.last_name,a.fore_name,a.initials,ia.auth_count,ia.pubs_count from ".$tableName." as ia, ".$authorTableName." as a";
		$query	.= " where ia.project_id=".$projectId;
		$query	.= " and a.id=ia.author_id";
		if($authorId!=''){
			$query	.= " and ia.author_id=".$authorId;
		}
		if($orderByfieldName!=''){
			$query	.= " order by ia.".$orderByfieldName." desc";
		}else{
			$query	.= " order by ia.auth_count desc";
		}
		if($limit!='')
			$query	.= " limit ".$limit;
		//echo $query;
		$resultSet	= $this->db->query($query);
		if($resultSet->num_rows!=0){
			foreach($resultSet->result_array() as $row){
				$arrUniqueAuthors[]	= $row;
			}
		}
		return $arrUniqueAuthors;
	}
	// get project details
	function get_project_details($projectId=''){
		$tableName	= 'id_project';
		if($projectId!=''){
			$this->db->where('id',$projectId);
			$resultSet	= $this->db->get($tableName);
			return $resultSet->result_array();
		}else{
			$resultSet	= $this->db->get($tableName);
			foreach($resultSet->result_array() as $row){
				$arrprojects[]	= $row;
			}
			return $arrprojects;
		}
	}
	
	
} // end of class


?>