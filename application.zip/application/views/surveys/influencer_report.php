<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {}";

?>
<style>
#tabularView .rowView{
	display: table-row;
}
#tabularView .cellView{
	display: table-cell;
	padding:5px;
}
.rowView label{
	margin-right:4px;
}

.input{
	
	
	width: 237px;
}
#nameWrapper .nameContainer{
	
}
#nameWrapper .nameDetails{
	border: 1px solid;
    display: inline-block;
    padding:10px;
}
#nameWrapper .nameDetails p{
	margin: 0px;
}
#nameWrapper .nameDetails p span{
	display:inline-block;
	width:56px;
	text-align:right;
}
#tabularView img{
	width:100px;
}
.physianLabel{
	margin-left:-131px;
}
.addresContent{
	font-weight:bold;
}
#listAllPager_left,#listAllPagerResp_left{
	display:none;
}

	.ui-collapsible-content{
		display:none;	
	}
	.ui-collapsible-content-collapsed{
		display:block;	
	}
	.table2 tr td{
		border:0px solid red !important;	
	}
	.table2 {
	border:0px solid red !important;	
	}
	#influencerRespondentName{
		width:316px;
	}
</style>
<div>
	
	<input type="hidden" name="influencer_respondent_name1" class="autocompleteInputBox1 kolElement1" id="influencerRespondentKolId" value="" title=""/>
	<input type="hidden" name="adress" class="" id="adressId" value="" title=""/>


</div>

<div id="tabularView">
	<!-- 
	<div>
	<b>Respondents</b><img src="http://localhost/imap/images/a.png" /><b>Roger Gadsby</b><img src="http://localhost/imap/images/a.png" /><b>Influencers</b>
	</div>
	-->
	<div id="nameWrapper">
		<div class="nameContainer">
					<table class="table2" style="width:100%;border:none !important;">
				<tr>
					<td rowspan="2" style="text-align:right"><img src="<?php echo base_url();?>/images/arrow-right_desktop.png" /></td>
					<td style="width:37%;position:relative" valign="top" colspan="1">
						<div class="nameContainer1" style="position:absolute;">
						
							<input type="text" name="influencer_respondent_name" class="autocompleteInputBox kolElement input" id="influencerRespondentName" value="Enter Physician Last Name" title=""/>
							<!-- <div class="cellView" style="text-align:right"><img src="<?php echo base_url();?>/images/43.jpg" /></div>
							<div class="cellView" ><img src="<?php echo base_url();?>/images/4.png" /></div>-->
						</div>
					</td>
				
					<td rowspan="2">
					<div><img src="<?php echo base_url();?>/images/arrow-down_desktop.png" / style="position:relative;top:7px"></td></div>
					<td>
					<div class="nameDetails" style="display:none">
					<p id="cityContainer"><span class="addresContent">City:</span> </p>
					<p id="stateContainer"><span class="addresContent">Sate:</span></p>
					<p id="countryContainer"><span class="addresContent">Country :</span> </p>
				</div></td>
					</tr>
					
					<tr>
						
						
					</tr>
				
				
			</table>
		</div>
		
	</div> 



	<div>
	
	</div>
	<div class="rowView">
		
		<div class="cellView"></div>
		<div class="cellView">
			
		</div>
		<div class="cellView">
			
		</div>
	</div>
</div>	


	<div>
		<div class="gridWrapper" id="allNomeeniesGridContainer1" style="float: left;width:46%;">
						<table id="JQBlistAllResultSetNom"></table>
						<div id="listAllPagerNom"></div>
		</div>	
					
		<div class="gridWrapper" id="allRespondentGridContainer" style="float: right;width:46%;">
			<table id="JQBlistAllResultSetResp"></table>
			<div id="listAllPagerResp"></div>
		</div>	
		</div>	
<script type="text/javascript">
var reEscape = new RegExp("(\\"
		+ [ "/", ".", "*", "+", "?", "|", "(", ")", "[", "]", "{", "}",
				"\\" ].join("|\\") + ")", "g");
	var kolName =''
	var influencerNamesAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_kol_names_for_autocomplete/',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			autocompleteOnSelect(event, ui);
		},
			fnFormatResult:fnFormatResultNew
	};
	function fnFormatResultNew(a, b, c) {
		var g = c.replace(reEscape, "\\$1");
		//var d = "(" + g + ")";
		var d = "("+g+"(?![=]))";
		return a;//a.replace(new RegExp(d, "gi"), "<strong>$1</strong>")
	}
	function autocompleteOnSelect(event, ui){
		//console.log(event);
		var kolId = $(event).children('.id1').html();
		var selText = $(event).children('.kolName').text();
		var classname	= ($(event).children('.kolName').attr('class'));
		selText=selText.replace(/\&amp;/g,'&');
		//alert(kolId);
		var adressId = $(event).children('.addressId').html();
		$('#influencerRespondentName').val(selText);
		$('#influencerRespondentKolId').val(kolId);
		$('#adressId').val(adressId);
		//kolName = selText;
		listSurveyNominnes();
		listSurveyRespondents();
		getKolDetails(kolId,adressId);
		$('#physianName').val(selText);
	}
	//$(document).load(function(){
		//alert("ss");
		a= $('#influencerRespondentName').autocomplete(influencerNamesAutoCompleteOptions);
	//});
	
	function getRespndentsAndInfluencers(){
		$.ajax({
			url:'<?php echo base_url();?>surveys/get_Influencers_respondents/290',
			datType:'json',
			success:function(returndata){
				alert(returndata);
			}		

		});

	}

	function listSurveyNominnes(){
		//alert(id);
		$('#allNomeeniesGridContainer1').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		id=$('#influencerRespondentKolId').val();
		
		//listSurveyRespondents(id);
		var data1={};
		
		data	= $('#searchFiltersContainer').find('form').serialize();
		
		data		+= '&id='+$('#surveyInfluencer').val();
		data		+= '&chart_type=2';
		var result = { };
		data		+= '&survey_id='+$('#surveyInfluencer').val();
		//data		+='&_search=false';
		data1 = JSON.parse(JSON.stringify(data));

		var type="nominees";

		$.ajax({
			type: "post",
			dataType:"json",
			data:	data,
			  url:'<?php echo base_url();?>surveys/get_Influencers_by_id/'+id+'/'+type,
			success: function(returnData){
				listRespondentById(returnData);
				//listInfluencersById(returnData);
			},
			complete: function(){
				//$('#summaryGridContainer').unblock();
				$('#allNomeeniesGridContainer1').unblock();
			}
		});

	}

	function listSurveyRespondents(){
		$('#allRespondentGridContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		id=$('#influencerRespondentKolId').val();
		
		//listSurveyRespondents(id);
		var data1={};
		
		 data	= $('#searchFiltersContainer').find('form').serialize();
		
		data		+= '&id='+$('#surveyInfluencer').val();
		data		+= '&chart_type=2';
		var result = { };
		data		+= '&survey_id='+$('#surveyInfluencer').val();
		
		var type="resp";

		$.ajax({
			type: "post",
			dataType:"json",
			data:	data,
			  url:'<?php echo base_url();?>surveys/get_Influencers_by_id/'+id+'/'+type,
			success: function(returnData){
				listInfluencersById(returnData);	
				//listRespondentById(returnData);
			},
			complete: function(){
				$('#allRespondentGridContainer').unblock()
			}
		});

	}
	
	function listRespondentById(returnData){
		
		var data = {
	            "page": "1",
	            "rows":returnData
	        }
		var type="resp";
		$("#allRespondentGridContainer").html('');
		$("#allRespondentGridContainer").html('<table id="JQBlistAllResultSetResp"></table><div id="listAllPagerResp"></div>');
// 		if(agent=='Apple iPad'){
// 			var gridWidth	= 350;
// 		}else{
// 			var gridWidth	= 400;
// 		}
	
	      jQuery("#JQBlistAllResultSetResp").jqGrid({
	    	  	datatype: "jsonstring",
      			datastr: data,
			   	colNames:['Id','Name','Do Not Call','City','State'],
			   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'name',index:'name'},
					{name:'do_not_call_flag',index:'do_not_call_flag'},
					{name:'city',index:'city'},
					{name:'state',index:'state'}
					
			   		
			   	],
			   	rowNum:10,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#listAllPagerResp',
			   	mtype: "POST",
			   
			//   	sortname: 'name',
			    viewrecords: true,
			//    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:'Influencees',
			    rowList:paginationValues
			    
			});
	      jQuery("#JQBlistAllResultSetResp").jqGrid('navGrid','#listAllPagerResp',{edit:false,add:false,del:false,search:false,refresh:false});	
			//Toolbar search bar below the Table Headers
			jQuery("#JQBlistAllResultSetResp").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			jQuery("#JQBlistAllResultSetResp").jqGrid('navButtonAdd',"#listAllPagerResp",{
				caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}							
				} 
			}); 
			
// 			jQuery("#JQBlistAllResultSetResp").jqGrid('setGridWidth',gridWidth); 
	  //  grid.jqGrid('setGridWidth',gridWidth);
	    initilizeGridSearchPlaceholder();
	    initializeHelpToolTip();
	}

function listInfluencersById(returnData){
		
		var data = {
	            "page": "1",
	            "rows":returnData
	        }
		var type="resp";
		$("#allNomeeniesGridContainer1").html('');
		$("#allNomeeniesGridContainer1").html('<table id="JQBlistAllResultSetNom"></table><div id="listAllPagerNom"></div>');
// 		if(agent=='Apple iPad'){
// 			var gridWidth	= 350;
// 		}else{
// 			var gridWidth	= 400;
// 		}
		var data = {
	            "page": "1",
	            "rows":returnData
	        }
	      jQuery("#JQBlistAllResultSetNom").jqGrid({
	    	 
				 datatype: "jsonstring",
        		datastr: data,
			   	colNames:['Id','Name','Do Not Call','City','State'],
			   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'name',index:'name'},
					{name:'do_not_call_flag',index:'do_not_call_flag'},
					{name:'city',index:'city'},
					{name:'state',index:'state'}
					
			   		
			   	],
			   	rowNum:10,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#listAllPagerNom',
			   	mtype: "POST",
			   	//postData:  data1 ,
			//   	sortname: 'name',
			    viewrecords: true,
			//    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:'Influencers',
			    rowList:paginationValues
			    
			});
	      jQuery("#JQBlistAllResultSetNom").jqGrid('navGrid','#listAllPagerNom',{edit:false,add:false,del:false,search:false,refresh:false});	
			//Toolbar search bar below the Table Headers
			jQuery("#JQBlistAllResultSetNom").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			//Toolbar search bar above the Table Headers
			
		 	jQuery("#JQBlistAllResultSetNom").jqGrid('navButtonAdd',"#listAllPagerNom",{
				caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}							
				} 
			}); 
// 			jQuery("#JQBlistAllResultSetNom").jqGrid('setGridWidth',gridWidth); 
	  //  grid.jqGrid('setGridWidth',gridWidth);
	    initilizeGridSearchPlaceholder();
	    initializeHelpToolTip();
	}
	function getKolDetails(kolId,addressId){
		
		$.ajax({
			type: "post",
			dataType:"json",
			data:{
		        'kol_id':kolId,
		        'addressId':addressId
		    },
			url: '<?php echo base_url();?>surveys/getKolData',
			success: function(returnData){
					
					$('#cityContainer').html('<span class="addresContent">City:</span> '+returnData.City);
					$('#stateContainer').html('<span class="addresContent">Sate:</span> '+returnData.State);
					$('#countryContainer').html('<span class="addresContent">Country:</span> '+returnData.Country);
				//$(thisObj).parent().parent().prev().html(enableMIcroview);
			}
		});
	}
	$(document).ready(function(){

		$('#influencerRespondentName').focus(function(){
				
			//	var name=$('#kolName').val();
			//	if(name=='Enter KOL Name'){
					$('#influencerRespondentName').val(" ");
					var emptyData = [];
					listInfluencersById(emptyData);
					listRespondentById(emptyData);
			//	}
			});

			$('#influencerRespondentName').blur(function() {
				var name=$('#influencerRespondentName').val();
				if(name==' '){
					$('#influencerRespondentName').val('Enter Physician Name');
				}
			});
		$('div.autocomplete').on("click", "div.autocomplete > div", function() {
				autocompleteOnSelect($(this).html());
				$(document).click();
		});
		$('div.autocomplete').on("mouseover", "div.autocomplete > div", function() {
			$(this).addClass("selected");
		});
		$('div.autocomplete').on("mouseout", "div.autocomplete > div", function() {
			$(this).removeClass("selected");
		});
		$('div.autocomplete').bind('scroll', function() {
			
	        if($(this).scrollTop() + $(this).innerHeight() >= this.scrollHeight) {
	        	
//	        	$('autocomplete-w1').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$.ajax({
						type: "post",
						dataType:"json",
						data: {'offset':offset,
								kolSearchkeyword:kolSearchkeyword
								
								},
						url: '<?php echo base_url();?>surveys/get_kol_names_for_autocomplete/kolSearchkeyword',
						success: function(returnData){
							$.each(returnData.suggestions,function(id,val){
									if(!returnData.isStillRequest)
										$('div.autocomplete').append(val);
								});
							offset = offset + 50;
//							$('div.autocomplete').unblock();
						}
					});
	        }
	    })
	});
	
</script>


