<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for publication from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 13-06-2018
 * @Refactored : 13-06-2018
 */

class kol_rating extends model{
	
	
	/**
	 * Returns the all assessment categories
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 17-03-2012
	 */
	function getAllAsmtCategories(){
		$arrAsmtCategories		= array();
		$this->db->order_by('asmt_categories.name','asc');
		$resultSet	= $this->db->get('asmt_categories');
		foreach($resultSet->result_array() as $row){
				$arrAsmtCategories[]	= $row;
		}
		return $arrAsmtCategories;
	}
	
	/**
	 * Returns the all assessment criteria
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 17-03-2012
	 */
	function getAllAsmtCriteria(){
		$arrAsmtCriteria		= array();
		$this->db->order_by('asmt_criteria.criteria','asc');
		$resultSet	= $this->db->get('asmt_criteria');
		foreach($resultSet->result_array() as $row){
				$arrAsmtCriteria[]	= $row;
		}
		return $arrAsmtCriteria;
	}
	/**
	 * Returns the all assessment Ratings
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 17-03-2012
	 */
	function getAllAsmtRatings(){
		$arrAsmtRatings		= array();
		$this->db->order_by('asmt_ratings.rating','asc');
		$this->db->order_by('asmt_ratings.rating_score','asc');
		$resultSet	= $this->db->get('asmt_ratings');
		foreach($resultSet->result_array() as $row){
				$arrAsmtRatings[]	= $row;
		}
		return $arrAsmtRatings;
	}
	
	/**
	 * get all assessment rules with respect to country
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 18-03-2012
	 */	
	function getAllAsmtRules($countryId){
		$arrAsmtRules	= array();
		$resultSet		= '';
		$this->db->select("asmt_rules.*,asmt_categories.name as cat_name,asmt_criteria.criteria,asmt_ratings.rating,asmt_ratings.rating_score");
		$this->db->join('asmt_categories','asmt_categories.id=asmt_rules.category_id','inner');
		$this->db->join('asmt_criteria','asmt_criteria.id=asmt_rules.criteria_id','inner');
		$this->db->join('asmt_ratings','asmt_ratings.id=asmt_rules.rating_id','inner');
		$this->db->order_by('asmt_rules.category_id','asc');
		$this->db->order_by('asmt_rules.criteria_id','asc');
		$this->db->order_by('asmt_rules.order_no','asc');
//		$this->db->where('asmt_rules.country_id',$countryId);
		$resultSet	= $this->db->get('asmt_rules');
		foreach($resultSet->result_array() as $row){
				$arrAsmtRules[]	= $row;
		}
		return $arrAsmtRules;
	}
	
	/**
	 * save KOL ratings
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 18-03-2012
	 */	
	function saveKolRatings($kolId,$asmtCatId,$asmtCriteriaId,$asmtRatingId){
		$arrData				= array();
		$arrData['kol_id']		= $kolId;
		$arrData['category_id']	= $asmtCatId;
		$arrData['criteria_id']	= $asmtCriteriaId;
		$arrData['rating_id']	= $asmtRatingId;
		$this->db->select('kol_id');
		$this->db->where('kol_id',$kolId);
		$this->db->where('category_id',$asmtCatId);
		$this->db->where('criteria_id',$asmtCriteriaId);
		$resultSet	= $this->db->get('asmt_kols_rating');
		//echo $this->db->last_query();
		if($resultSet->num_rows()>0){
			$this->db->where('kol_id',$kolId);
			$this->db->where('category_id',$asmtCatId);
			$this->db->where('criteria_id',$asmtCriteriaId);
			$this->db->update('asmt_kols_rating',$arrData);
		}else{
			$this->db->insert('asmt_kols_rating',$arrData);
		}
		
	}
	
	/**
	 * get KOL ratings
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return Array
	 * @created 18-03-2012
	 */	
	function getKolRatings($kolId){
		$arrCriteriaRating	= array();
		$this->db->select('criteria_id,rating_id');
		$this->db->where('kol_id',$kolId);
		$resultSet	= $this->db->get('asmt_kols_rating');
		if($resultSet->num_rows()>0){
			foreach($resultSet->result_array() as $row){
				$arrCriteriaRating[$row['criteria_id']]	= $row['rating_id'];
			}
		}
		return $arrCriteriaRating;
	}
	
	/**
	 * get maximum rating score 
	 * on KOL id - returns KOL assessment rating score
	 * on Country- return maximum rating score (sum of high rating scores)
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return  Score in integer
	 * @created 18-03-2012
	 */	
	function getMaxRatingScore($id,$isKolMaxScore=false){
		//select max(rating_id) from asmt_rules where country_id=254 group by criteria_id
	//	SELECT asmt_ratings.rating, max(asmt_ratings.rating_score) as max_rating_score FROM `asmt_rules`, asmt_ratings 
	//	WHERE asmt_ratings.id=asmt_rules.rating_id and asmt_rules.`country_id` = '254' GROUP BY asmt_rules.`criteria_id`;
		$arrMaxRatingScore	= array();
		$this->db->select('asmt_categories.name,max(asmt_ratings.rating_score) as max_rating_score');
		
		if($isKolMaxScore){
			$this->db->join('asmt_categories','asmt_categories.id=asmt_kols_rating.category_id','inner');
			$this->db->join('asmt_ratings','asmt_ratings.id=asmt_kols_rating.rating_id','inner');
			$this->db->where('asmt_kols_rating.kol_id',$id);
			//$this->db->where('asmt_ratings.id','asmt_kols_rating.rating_id');
			$this->db->group_by('asmt_kols_rating.criteria_id');
			$resultSet	= $this->db->get('asmt_kols_rating');
		}else{
			$this->db->join('asmt_categories','asmt_categories.id=asmt_rules.category_id','inner');
			$this->db->join('asmt_ratings','asmt_ratings.id=asmt_rules.rating_id','inner');
		//	$this->db->where('asmt_rules.country_id',$id);
			//$this->db->where('asmt_ratings.id','asmt_rules.rating_id');
			$this->db->group_by('asmt_rules.criteria_id');
			$resultSet	= $this->db->get('asmt_rules');
		}
		//echo $this->db->last_query();
		if($resultSet->num_rows()>0){
			$i	= 0;
			foreach($resultSet->result_array() as $row){
				$uniqueIndex	= $row['name'].'_'.$i++;
				//$arrMaxRatingScore[$uniqueIndex]	= $row['max_rating_score'];
				$arrMaxRatingScore[]	= array('count'=>$row['max_rating_score'],'category_name'=>$row['name']);
			}
		}
		return $arrMaxRatingScore;
	}
	
	function getMaxActivitiesCount(){
		$maxActvityCount=array();;
		$this->db->select("max(totalScore) as maxActivityCount,kols.specialty");
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->group_by('kols.specialty');
		$arrResultSet = $this->db->get('kol_activities_count');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$maxActvityCount[$row['specialty']]=$row;
		}
		
		return $maxActvityCount;
	}
	
	function getKolTotalActivityCount($kolId){
		$arrKolTotalActivitiesCount = array();
		$this->db->select('kol_activities_count.totalScore,kols.specialty');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kol_activities_count.kol_id',$kolId);
		$arrTotalActivityResultset = $this->db->get('kol_activities_count');
		foreach($arrTotalActivityResultset->result_array() as $arrTotalActivitiesCount){
			$arrKolTotalActivitiesCount[] = $arrTotalActivitiesCount;
		}
		//echo $this->db->last_query();
		return $arrKolTotalActivitiesCount;
	}
	
	/**
	 * save new assessment rule
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @created 18-03-2012
	 */	
	function saveAsmtRules($arrAsmtRule){
		$this->db->insert('asmt_rules',$arrAsmtRule);
	}
	
	/**
	 * save new assessment category
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @return  category id on saving new catgory or if category already present
	 * 			false on error or if not saved
	 * @created 18-03-2012
	 */	
	function addAsmtCategory($arrNewRecord){
		$this->db->select('id');
		$this->db->where('name',$arrNewRecord['name']);
		$resultSet	= $this->db->get('asmt_categories');
		if($resultSet->num_rows>0){
			$row	= $resultSet->result_array();
			return $row->id;
		}else{
			if($this->db->insert('asmt_categories',$arrNewRecord)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	
	function getMaxCountBySpecialty($specialtyId){
	    $client_id = $this->session->userdata('client_id');
		$maxActvityCount=array();
		$this->db->select("max(teachingCount),max(practiseCount),
							max(trialCount),max(socialComitteCount),
						max(socialBoardCount),max(guidelineCount),
						max(governmentCount),max(executiveCount),
						max(speakingCount),max(facultyCount),
						max(panelistCount),max(authPosCount)");
		$this->db->join('kols','kols.id=kol_activities_count.kol_id');
		$this->db->where('kols.specialty',$specialtyId);
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		//$this->db->where('status',COMPLETED);
		$arrResultSet = $this->db->get('kol_activities_count');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$maxActvityCount[]=$row;
		}
		
		return $maxActvityCount;
	}
	
	function getKolTotalActivityCount1($kolId){
		$arrKolTotalActivitiesCount = '';
		$this->db->select('kol_activities_count.totalAllscore');
		$this->db->where('kol_activities_count.kol_id',$kolId);
		$arrTotalActivityResultset = $this->db->get('kol_activities_count');
		foreach($arrTotalActivityResultset->result_array() as $arrTotalActivitiesCount){
			$arrKolTotalActivitiesCount = $arrTotalActivitiesCount['totalAllscore'];
		}
		return $arrKolTotalActivitiesCount;
	}
	
	function getCountOfAllParameter($id){
	    $client_id = $this->session->userdata('client_id');
		$arrCounts = array();
		$this->db->select('kol_activities_count.*,kols.salutation,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kol_activities_count.kol_id',$id);
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrReultSet =$this->db->get('kol_activities_count');
		foreach($arrReultSet->result_array() as $row){
			$arrCounts[]=$row;
		}
		return $arrCounts;
	}
	
	function gerSpecilatyIdByKol($kolId){
	    $client_id = $this->session->userdata('client_id');
		$specialltyId = '';
		$this->db->select('specialty');
		$this->db->where('kols.id',$kolId);
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$specialtyReusltSet = $this->db->get('kols');
		foreach($specialtyReusltSet->result() as $row){
			$panelistCount=$row->specialty;
		}
		return $panelistCount;
	}
	
	function getAllKolsCountOfIndividualParam($specialtyId){
		$client_id = $this->session->userdata('client_id');
		$this->db->select('kol_activities_count.*,kols.unique_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.specialty');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kols.specialty',$specialtyId);
		$this->db->order_by('kol_activities_count.totalAllScore desc');
		//$this->db->where('status',COMPLETED);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$arrReultSet =$this->db->get('kol_activities_count');
		foreach($arrReultSet->result_array() as $row){
			$arrCounts[]= $row;
		}
// 		print $this->db->last_query();
// 		exit;
		return $arrCounts;
	}
	
	function getmaxCategoriesCounts($specialtyId){
	    $client_id = $this->session->userdata('client_id');
		$this->db->select('max(totalProfessionalCount) as maxProfessionalCount,
							max(totalEvents) as maxEventsPresenceCount,
							max(totalResearch) as maxResearchCount');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kols.specialty',$specialtyId);
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrResulSet = $this->db->get('kol_activities_count');
		//$this->db->where('status',COMPLETED);
		foreach($arrResulSet->result_array() as $row){
			$arrCounts[]= $row;
		}
		return $arrCounts;
		
	}
	
	function getMaxTotalCountOfKolBySpecialty($specialtyId){
	    $client_id = $this->session->userdata('client_id');
		$maxTolalScore=array();
		$this->db->select("max(totalAllScore) as maxTolalScore");
		$this->db->join('kols','kols.id=kol_activities_count.kol_id');
		$this->db->where('kols.specialty',$specialtyId);
		//$this->db->where('status',COMPLETED);
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrResultSet = $this->db->get('kol_activities_count');
		foreach($arrResultSet->result() as $row){
			$maxTolalScore=$row->maxTolalScore;
		}
		
	//	pr($maxTolalScore);
		
		return $maxTolalScore;
	}
	
	function getProfileScore($kolId){
		$profileScore = '';
		$this->db->select('profileScore');
		$this->db->where('kol_id',$kolId);
		$profoleScoreResultSet = $this->db->get('kol_activities_count');
		foreach($profoleScoreResultSet->result_array() as $row){
			$profileScore =$row['profileScore'];
		}
		return $profileScore;
	}
	
	/**
	 * get assessment category score
	 * @author 	Laxman K
	 * @since	Otsuka v1.0.5 KOLM v4.3
	 * @return  array of category score in percentage
	 * @created 15-11-2012
	 */	
	function getAsmtChartScore($kolId){
		$arrData	= array();
		$resultSet	= $this->db->query('select ac.id as cat_id, ac.name as category_name,sum(ar.rating_score) as total_cat_score,max(ar.rating_score) as cat_max_score, count(ar.rating_score) as cat_criteria_count
							from asmt_ratings ar, asmt_kols_rating akr, asmt_categories ac
							where ac.id=akr.category_id and ar.id=akr.rating_id and akr.kol_id='.$kolId.' 
							group by akr.category_id');
		$resultSetCri	= $this->db->query('select arules.catid,sum(arules.maxcriscore) as criteriamaxcount
												from
												(
													select asmtr.category_id as catid,ac.*,max(ar.rating_score) as maxcriscore from asmt_ratings ar, asmt_rules asmtr, asmt_criteria ac
													where ac.id=asmtr.criteria_id
													and ar.id=asmtr.rating_id
													group by asmtr.criteria_id
												) as arules
												group by arules.catid
											');
		$arrCriteriaMaxCount	= $resultSetCri->result_array();
		if($resultSet->num_rows()>0){
			$i	= 0;
			foreach($resultSet->result_array() as $row){
				$criteriaMaxCount			= $arrCriteriaMaxCount[$i++]['criteriamaxcount'];
				$row['percentage']			= (int)(($row['total_cat_score']/($criteriaMaxCount))*100);
				$arrData[$row['cat_id']]	= $row;
			}
		}else{
			$resultSet	= $this->db->query('select id,name as category_name from asmt_categories group by id');
			foreach($resultSet->result_array() as $row){
				$row['percentage']		= 0;
				$row['total_cat_score']	= 0;
				$arrData[$row['id']]	= $row;
			}
		}
		return $arrData;
	}
}
