<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>

<script type="text/javascript">
    var filters={}; ;
            var mainFilter = 0;
            var mainFilterId = '';
            var mainCateogry = '';
             var todayDate = "<?php echo date("m/d/Y");?>";
		var monthFirstDate = "<?php echo date("m/01/Y");?>";
            if (!js_files_loaded){
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
    }
</script>
<style type="text/css">
    .selectBoxMsl
    {
        width: 165px;
    }
    #timeLineSliderContainer {
        padding-left: 10px;
        padding-right: 8px;
    }
    #timeLineSlider{
        margin-right:10px;
    }
    #searchLeftBar li.category{
        border-top: 0px;
    }
    #searchLeftBar{
        /*	margin-top:-40px; */
    }
    <?php
    if (IS_IPAD_REQUEST == 1) {
        echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
        echo ' select.chosenMultipleSelectManager,select.chosenMultipleSelectMsl,select.chosenMultipleSelectTherp,select.chosenMultipleSelectStatus,select.chosenMultipleSelectTeams{
        width:247px !important;
    }';
    }
    ?>
    .chzn-container-multi .chzn-choices{
        padding-left: 0px !important;
    }
    .chzn-container{
        font-size: 12px;
    }
    .chzn-container-single .chzn-single{
        border-radius: 2px;
        height: 18px;
        padding: 0 0 0 5px;		
    }
    .chzn-container-single .chzn-single span{
        margin-top: -3px;
    }
    .chzn-container .chzn-results{
        padding-left: 0px !important;
        margin: 0px;
    }
    #profileType_chzn .chzn-single span{
        /*margin-top: 0px;*/
    }
    #savedFilterValue_chzn .chzn-drop .chzn-search input{
        border-radius: 2px;
    }
    .highlighted{
       // background: #5A86B8 !important;
        color: white;
    }
    .chzn-container-single .chzn-search input{
        padding: 2px 20px 2px 4px;
    }
    .chzn-search li input[type="text"]{
        border-radius: 2px !important;
    }
    div.actionIcon{
        float: right;
    }
    .chzn-container-single .chzn-single div{
        top: -3px !important;
    }
    /*	.chzn-container .chzn-results li{
                    padding: 3px 4px !important;
                    line-height: 12px !important;
            }
    */
    .chzn-drop{
        min-width: 106px !important;
    }
    .ui-widget-content, #timeLineSliderContainer p, #yearRange {
        background: inherit;
    }
    
    select.chosenMultipleSelectMsl,select.chosenMultipleSelectTherp,select.chosenMultipleSelectStatus,select.chosenMultipleSelectTeams{
        width:280px;
    }
    .microView .ui-dialog-content {
   background-color: white;
   }
    .users{
       list-style-type: none;
       margin:0;
       padding:0
       
   }
   .users li{
       float:left;
   }
   .editIcon{
    margin-left: 3px;
   }
   #categoriesContainer table{
		margin-bottom: 0 !important;
	}
	#searchFiltersElements ul li.search-field{
		padding-bottom: 0px;
	    padding-left: 10px;
	    padding-top: 0px;
	}
	.chzn-container-multi .chzn-choices .search-field input{
		color: #444444 !important;
	}
        
</style>
<?php
$arrfilterdata = $this->session->userdata('filterContent');
$selectedKolId = $arrfilterdata['selected_kol_id'];
if (!empty($selectedKolId) && $selectedKolId != 0) {
    foreach ($arrKolDetails as $key => $rowData) {
        if ($key == $selectedKolId) {
            $selectedKol[$key] = $rowData['name'];
        }
    }
} else {
    $selectedKol = $arrfilterdata['arrKolNames']; //$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
}
if ($arrfilterdata['profileType'] != '') {
    $profileType = $arrfilterdata['profileType'];
}
if ($arrfilterdata['savedFilterId'] != '') {
    $savedFilterId = $arrfilterdata['savedFilterId'];
}
if (!empty($arrfilterdata['arrSpecialities'])) {
    if (!is_array($arrfilterdata['arrSpecialities'])) {
        $arrfilterdata['arrSpecialities'] = explode(',', $arrfilterdata['arrSpecialities']);
    }
    $selectedSpecialty = $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
} else {
    $selectedSpecialty = array();
}
if (sizeof($arrfilterdata['arrCountries']) > 0) {
    if (!is_array($arrfilterdata['arrCountries'])) {
        $arrfilterdata['arrCountries'] = explode(',', $arrfilterdata['arrCountries']);
    }
    $selectedCountry = $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
} else {
    $selectedCountry = array();
}
//$selectedState		= $arrfilterdata['arrStates'];
if (!empty($arrfilterdata['arrStates'])) {
    if (!is_array($arrfilterdata['arrStates'])) {
        $arrfilterdata['arrStates'] = explode(',', $arrfilterdata['arrStates']);
    }
    $selectedState = $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
} else {
    $selectedState = array();
}
if (sizeof($arrfilterdata['arrListNames']) > 0) {
    if (!is_array($arrfilterdata['arrListNames'])) {
        $arrfilterdata['arrListNames'] = explode(',', $arrfilterdata['arrListNames']);
    }
    $CI = & get_instance();
    $CI->load->model("My_list_kol");
    //$selectedListName	= $arrfilterdata['arrListNames'];
    $selectedListName = $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
} else {
    $selectedListName = array();
}
?>
<script type="text/javascript">

    $(document).ready(function (){
       $("#resetBttnContainer").remove();
            $('.chosenMultipleSelectMsl').chosen({
        allow_single_deselect: true
    });
     $('.chosenMultipleSelectTherp').chosen({
        allow_single_deselect: true
    });
     $('.chosenMultipleSelectStatus').chosen({
        allow_single_deselect: true
    });
     $('.chosenMultipleSelectTeams').chosen({
         allow_single_deselect: true
     });
       $('.chosenMultipleSelectManager').chosen({
         allow_single_deselect: true
     });
        // resetFilters();
        
    $('#from').datepicker({
    dateFormat: 'mm/dd/yy'
        ,
            onSelect: function(date, instance) {
//            filters += "&from=" + date;
                  
            }
    });
      $('#from').val(monthFirstDate);
            $('#to').datepicker({
    dateFormat: 'mm/dd/yy'
        ,
            onSelect: function(date, instance) {
//            filters += "&to=" + date;
                    
            }
    });
      $('#to').val(todayDate);
        filter('this','0');
            //$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
    
//            initializeCustomToolTips();
    });
            var options, a;
            // Autocomplet Options for the 'role' field 
            var SpecialtyNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_specialty_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.specialties').html();
                            var selId = $(event).children('.specialties').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#specialty').val(selText);
                            $('#specialtyId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var countryNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>country_helpers/get_country_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.countries').html();
                            var selId = $(event).children('.countries').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#country').val(selText);
                            $('#countryId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var stateNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>country_helpers/get_state_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var stateId = $(event).children('.autocompleteStateId').html();
                            var selText = $(event).children('.stateName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#state').val(selText);
                            $('#stateIdForAutocomplete').val(stateId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }
            };
            var kolNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var kolId = $(event).children('.id1').html();
                            //var selText = $(event).children('.kolName').html();
                            var selText = $(event).children('.kolName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#kolName').val(selText);
                            $('#kolIdForReport').val(kolId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var listNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>my_list_kols/get_list_names_with_category',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.lists').html();
                            var selId = $(event).children('.lists').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#listName').val(selText);
                            $('#listNameId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    //  displaySelectedChart(true);
                    }
                    } else{
                    // displaySelectedChart(true);
                    }
                    }

            };
            /*		
             $(document).ready(function(){
             
             // Trigger the Autocompleter for 'education' field of  Event'
             a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'country' field of  Event'
             a = $('#country').autocomplete(countryNameAutoCompleteOptions);
             
             a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'list' field of  Event'
             a = $('#listName').autocomplete(listNameAutoCompleteOptions);
             
             // Binding the function for slidechange event 
             $( "#timeLineSlider" ).bind( "slidechange", filterChart);
             
             });
             */
            //Initiallize the Timeline slider
<?php $date = date('Y'); ?>
    //	var minYear=<?php echo ($date - 35); ?>;
    var minYear =<?php echo ($date - 60); ?>;
            var maxYear =<?php echo $date; ?>;
            var startDate = '<?php
if (isset($startDate))
    echo $startDate;
else
    echo 0;
?>';
            var endDate = '<?php
if (isset($endDate))
    echo $endDate;
else
    echo 0;
?>';
            var rangeValue1 = minYear;
            var rangeValue2 = maxYear;
            if (startDate != null && startDate != 0)
            rangeValue1 = startDate;
            if (endDate != null && endDate != 0)
            rangeValue2 = endDate;
            /*			
             $(function() {
             $( "#timeLineSlider" ).slider({
             range: true,
             min: minYear,
             max: maxYear,
             values: [ rangeValue1, rangeValue2 ],
             step:1,
             slide: function( event, ui ) {
             $( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
             }
             });
             
             $( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
             });
             
             
             
             
             
             // Hide or Show the Category checkbox's 
             
             
             $(document).ready(function(){
             $('#kolName').css({color:"gray"});
             $('#specialty').css({color:"gray"});
             $('#country').css({color:"gray"});
             $('#listName').css({color:"gray"});
             
             
             $('#kolName').focus(function(){
             
             var name=$('#kolName').val();
             if(name=='Enter KOL Name'){
             $('#kolName').val(" ");
             }
             });
             
             $('#kolName').blur(function() {
             var name=$('#kolName').val();
             if(name==' '){
             $('#kolName').val('Enter KOL Name');
             }
             });
             
             $('#specialty').focus(function(){
             
             var name=$('#specialty').val();
             if(name=='Enter Specialty'){
             $('#specialty').val(" ");
             }
             });
             
             $('#specialty').blur(function() {
             var name=$('#specialty').val();
             if(name==' '){
             $('#specialty').val('Enter Specialty');
             }
             });
             
             $('#country').focus(function(){
             
             var name=$('#country').val();
             if(name=='Enter Country'){
             $('#country').val(" ");
             }
             });
             
             $('#country').blur(function() {
             var name=$('#country').val();
             if(name==' '){
             $('#kolName').val('Enter Country');
             }
             });
             
             $('#listName').focus(function(){
             
             var name=$('#listName').val();
             if(name=='Enter List Name'){
             $('#listName').val(" ");
             }
             });
             
             $('#listName').blur(function() {
             var name=$('#listName').val();
             if(name==' '){
             $('#listName').val('Enter List Name');
             }
             });
             });
             */
            if (js_files_loaded){

    // Hide or Show the Category checkbox's 
    function toggleCategory(toggleFlag, thisEle){
    //	jAlert("Ds");
    /*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
     $('#specialtyCheckBox').slideToggle();	
     
     }else if($(thisEle).parent().attr('id')=='categotyCountry'){
     $('#countryCheckBox').slideToggle();	
     }else if($(thisEle).parent().attr('id')=='categotyLists'){
     $('#listCheckBox').slideToggle();
     }else{
     $('#kolsCheckBox').slideToggle();
     }
     */
    $(thisEle).next().slideToggle('slow');
            $(thisEle).toggleClass('expanded');
            $(thisEle).toggleClass('collapsed');
    }

    $(function() {
    $("#timeLineSlider").slider({
    range: true,
            min: minYear,
            max: maxYear,
            values: [ rangeValue1, rangeValue2 ],
            step:1,
            slide: function(event, ui) {
            $("#yearRange").val("" + ui.values[ 0 ] + " - " + ui.values[ 1 ]);
            }
    });
            $("#yearRange").val("" + $("#timeLineSlider").slider("values", 0) + " - " + $("#timeLineSlider").slider("values", 1));
    });
            $(document).ready(function(){

    // Trigger the Autocompleter for 'education' field of  Event'
    a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'country' field of  Event'
            a = $('#country').autocomplete(countryNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'country' field of  Event'
            a = $('#state').autocomplete(stateNameAutoCompleteOptions);
            a = $('#kolName').autocomplete(kolNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'list' field of  Event'
            a = $('#listName').autocomplete(listNameAutoCompleteOptions);
            // Binding the function for slidechange event 
            $("#timeLineSlider").bind("slidechange", filterChart);
    });
            $(document).ready(function(){
    $('#kolName').css({color:"gray"});
            $('#specialty').css({color:"gray"});
            $('#country').css({color:"gray"});
            $('#state').css({color:"gray"});
            $('#listName').css({color:"gray"});
            $('#kolName').focus(function(){

    //	var name=$('#kolName').val();
    //	if(name=='Enter KOL Name'){
    $('#kolName').val(" ");
            //	}
    });
            $('#kolName').blur(function() {
    //	var name=$('#kolName').val();
    //	if(name==' '){
    $('#kolName').val('Enter KOL Name');
            //	}
    });
            $('#specialty').focus(function(){

    //	var name=$('#specialty').val();
    //	if(name=='Enter Specialty'){
    $('#specialty').val(" ");
            //	}
    });
            $('#specialty').blur(function() {
    //	var name=$('#specialty').val();
    //	if(name==' '){
    $('#specialty').val('Enter Specialty');
            //	}
    });
            $('#country').focus(function(){

    //	var name=$('#country').val();
    //	if(name=='Enter Country'){
    $('#country').val(" ");
            //	}
    });
            $('#country').blur(function() {
    //	var name=$('#country').val();
    //	if(name==' '){
    $('#country').val('Enter Country');
            //	}
    });
            $('#state').focus(function(){

    //	var name=$('#state').val();
    //	if(name=='Enter State'){
    $('#state').val(" ");
            //	}
    });
            $('#state').blur(function() {
    //	var name=$('#state').val();
    //	if(name==' '){
    $('#state').val('Enter State');
            //	}
    });
            $('#listName').focus(function(){

    //	var name=$('#listName').val();
    //	if(name=='Enter List Name'){
    $('#listName').val(" ");
            //	}
    });
            $('#listName').blur(function() {
    //	var name=$('#listName').val();
    //	if(name==' '){
    $('#listName').val('Enter List Name');
            //	}
    });
    });
            /*
             $('#rightSideBarSliderShow').click(function() {
             $('#searchLeftBar').show(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
             });
             $("#rightSideBarSliderHide").show();
             $("#rightSideBarSliderShow").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             
             $('#rightSideBarSliderHide').click(function() {
             $('#searchLeftBar').hide(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
             $("#rightSideBarSliderShow").show(500);
             });
             $("#rightSideBarSliderHide").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             */
    }
    $(document).ready(function(){
  
        var a,options;
      



            
            // Autocomplet Options for the 'role' field 
              var MslNameAutoCompleteOptions = {
                    serviceUrl: '<?php echo base_url();?>reports/get_suggestions_for_msl_autocomplete_refineby',
                    <?php echo $autoSearchOptions;?>,
                    onSelect : function(event, ui) {
                        var selText = $(event).children('.msl').html();
                        var selId = $(event).children('.msl').attr('name');
                       
                        selText=selText.replace(/\&amp;/g,'&');
                        $('#mslAuto').val(selId);
                        //$('#mslId').val(selId);
                        filter(null,"msl")
                         $('#mslAuto').val('');
                        if(event.length>20){
                            if(event.substring(0,21)=="No results found for "){
                                return false;
                            }else{
                               // displaySelectedChart(true);
                            }
                        }else{
                          //  displaySelectedChart(true);
                        }
                    }
                    
                };
                  a = $('#mslAuto').autocomplete(MslNameAutoCompleteOptions);
//	$("#savedFilterValue").chosen().change(function(){
//		activeCustmFilters(this);
//	});
//	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
//		displaySelectedChart(this);
//	});
//	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
//		if($("#savedFilterValue").val()){
//			activeCustmFilters($("#savedFilterValue").val());
//			return true;
//			}
////		doSearchFilter1(-1,this);
//		displaySelectedChart(this);
//	});
    });
            function toggleCategory(toggleFlag, thisEle){
            //	jAlert("Ds");

            if ($(thisEle).parent().attr('id') == 'MSL'){

            $('#MslCheck').slideToggle();
            } else if ($(thisEle).parent().attr('id') == 'TherpyArea'){
            $('#ThrpCheck').slideToggle();
            } else if ($(thisEle).parent().attr('id') == 'EngStatus'){

            $('#EngCheck').slideToggle();
            }

            }
    function filter(thisEle, category){


filters={};

            if (category == 0)
            category = "msl";
            if (category == 1)
            category = "therp";
            if (category == 2)
            category = "status";
            mainCategory = category;
            if (mainFilter == 0){
    mainFilterId = $(thisEle).children().val();
            mainFilter = 1;
    }

    if ($(thisEle).children().attr('checked') == "checked"){

    

    //$(thisEle).css('background-color', '#fff')
            $(thisEle).children().removeAttr("checked");
         
    }
    else{
   // $(thisEle).css('background-color', '#D3DFED')
            $(thisEle).children().attr("checked", "checked");
    }
//    if (mainCategory != '')
//            mainCategory = '';
 var data={};
 var mslData = new Array();
           if($("#users").val() != null){
                   mslData = $("#users").val();
           }
           var teamData = new Array();
           if($("#teams").val() != null){
                   teamData = $("#teams").val();
           }
           var thrpData = new Array();
           if($("#therp").val() != null){
                   thrpData = $("#therp").val();
           }
           var statusData = new Array();
           if($("#status").val() != null){
                   statusData = $("#status").val();
           }
            var typeData = new Array();
           if($("#typeName").val() != ''){
                   typeData = $("#typeName").val();
           }
           
           var   sd = $("#from").val()
          if(sd!=''){        
                  var sdSplits = sd.split("/");            
                  data['from'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];        
          }        
          var ed = $("#to").val();        
          if(ed!=''){            
                  var edSplits = ed.split("/");            
                  data['to'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];        
          }
          
            var fromDate = new Date( $("#from").val());
           var toDate = new Date($("#to").val());
           if(sd != '' && ed != ''){
               if (toDate < fromDate){
                   jAlert(" 'To Date' Should be greater than 'From Date' ");
                   return false;
               }
           }
            var managerData = new Array();
           if($("#managers").val() != ''){
            
                   managerData = $("#managers").val();
           }
           //var data = $("form").serialize();
           data['msl_name']=mslData;
           data['thrp_name']=thrpData;
           data['eng_name']=statusData;
           data['team_name']=teamData;
           data['type_name']=typeData;
            data['manager_id']=managerData;
         
                   filters = data;
                   
//    var data = $("form ").serialize();


//            filters += data;
            list_kols_grid(filters);
                  $('#gridKolsListingFilter').html('');
          
            $(".gridWrapper").children().addClass('gridHeight');
            if(tabReportClick==1){
                loadtherapeuticareachart();
            loadtherapeuticareaBarChart();
            }
    }
    
    
    function resetFilters(){
$("select").find('option').removeAttr("selected");
$("input[type='text']").val('');
$("input").text('');
$('.search-choice').remove();
      filter(null,"msl");
    }
</script>

<style>
       <?php      if(IS_IPAD_REQUEST){ ?>
		form label {
	        font-weight: normal !important;
	        text-align: right;
		}
		.chzn-container-multi .chzn-choices .search-field .default {
		    height: 25px !important;
                   
		    border-radius: 2px !important;
		}
                .chzn-container chzn-container-multi{
                width:250px !important;
                }
                #users_chzn{
                 width:250px !important;   
                }
                #teams_chzn{
                     width:250px !important;   
                }
                #therp_chzn{
                    width:250px !important;   
                }
                #status_chzn{
                     width:250px !important;   
                }
                .search-field{
                     height: 25px !important;
                }
		.chzn-container-multi .chzn-choices {
		    border-radius: 4px;
		}
	    .postalerror{
	    	display: block !important;
	    	text-align: left !important;
	    	color: green !important;
	    }
	    .alignRight{
	    	vertical-align: top !important;
	    }
	    .chosenMultipleSelect,.chosenMultipleSelectTeams {
	    	width: 230px;
	    }
	    label.categoryName{
	    	border-bottom: 0 !important;
                font-size: 11px;
                color: #444444;
	    }
	    #categoriesContainer .category{
	    	margin-top: 15px;
	    }
	    #from, #to{
			width: 80px;
			border: 1px solid #aaaaaa !important;
			margin-right: 10px;
			font-size: 12px;
			height: 20px;
		}
		.filtersButton{
			margin-left: 16px;
		}
		.filtersButton label{
			font-size: 12px !important;
		}
		#applyFilter{
			font-size: 12px !important;
		}
		.ui-widget-content{
			background: white;
		}
	<?php }else{ ?>
    select.chosenMultipleSelect,select.chosenMultipleSelectTherap,select.chosenMultipleSelectAgent,select.chosenMultipleSelectSphere,select.chosenMultipleSelectSource_type,select.chosenMultipleSelectProduct,select.chosenMultipleSelectTopic,select.chosenMultipleSelectTeams,select.chosenMultipleSelectManager{
        width:280px;
    }
    .microView .ui-dialog-content {
        background-color: white;
    }
    .users{
        list-style-type: none;
        margin:0;
        padding:0

    }
    .users li{
        float:left;
    }
    .editIcon{
        margin-left: 3px;
    }
    #rightSideBarContainer {
	    width: 311px;
	}
	#rightSideBar::before {
	    border-top: 1px solid #bbbbbb !important;
	    height: 0 !important;
	    margin-left: 0 !important;
	}
	#rightSideBarWrapper {
	    border-left: 1px solid #bbbbbb;
	    /*overflow: hidden;*/
	}
	#categoriesContainer .category{
	    padding: 5px 0px 0 15px;
	}
	#from, #to{
		width: 80px;
	}
        <?php } ?> 
</style>

<div id="searchFiltersContainer">
    <div id="searchFiltersElements">
        <form action="<?php echo base_url() ?>kols/"  method="post" id="searchFilterForm">
            <ul id="categoriesContainer">
            	 <li id="categotyChannels" class="category"> </li>
              <?php if(IS_IPAD_REQUEST == 1){?>
									<div class="row">
                						<div class="col-md-12 text-center">
                                                                       <button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="filter('this','0');">Apply Filters</button>	
                                                                         <button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="resetFilters();">Reset</button>		
                						</div>
                					</div>
                					<br>
                					<div class="row">
                						<div class="col-md-12 text-center">
											<label class="dateText">From </label>
											<input type="text" name="from" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="from">
											<label class="dateText">To </label>
											<input type="text" name="to" value="<?php if($toDate != ''){echo $toDate;}?>" id="to">
										</div>
									</div>
									
							<?php }else{?>
                    <table style='  margin-left: 7px;' id="dateFilter">
                    			<tr>
										<td colspan="2" style="text-align: center;">
                                                                                    <button type="button" name="applyFilter"  id="applyFilter" onclick="filter('this','0');">Apply Filters</button>
                                                                                    <button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="resetFilters();">Reset</button>
										</td>
									</tr>
								<tr>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;"  >From </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="from" value="" id="from">
										</div>
									</td>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;" >To </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="to" value="" id="to">
										</div>
									</td>
								</tr>
							</table>
                                                        <?php }?>	
				<li id="categotyChannels" class="category"> </li>
                                  <li id="MSL" class="category">
                    <label class="categoryName">Engagement Type</label>
                    <div id="MslCheck">
                        <table id="mslData">
							<select name="type_name" id="typeName"  class="chosenMultipleSelectMsl" data-placeholder="Select Type">
					            <option value="">All</option>
					             <option value="1">1:1</option>
                                                      <option value="2">Group</option>
					        </select>
                        </table>
                    </div>
                </li>
                <li id="MSL" class="category">
                    <label class="categoryName">MSL Name</label>
                    <div id="MslCheck">
                        <table id="mslData">
							<select name="msl_name[]" id="users" multiple="multiple" class="chosenMultipleSelectMsl" data-placeholder="Select Users">
					            <option value=""></option>
					            <?php 
					                
					                foreach($arrClientUsers as $key=>$arrRow){
					                    $selected    = '';?>
					                    <option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name'].' '.$arrRow['last_name']?></option>;
					                <?php }
					                
					            ?>
					        </select>
                        </table>
                    </div>
                </li>
                 <?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
                   <li id="Manager" class="category">
                    <label class="categoryName">Manager Name</label>
                    <div id="ManagerCheck">
                        <table id="mslData">
							<select name="manager_name" id="managers"  class="chosenMultipleSelectManager" data-placeholder="Select Manager">
	            				<option value=""></option>
		            			<?php 
					                foreach($arrEngagementManager as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name']?>&nbsp;<?php echo $arrRow['last_name']?></option>;
		                		<?php }?>
				        	</select>
                        </table>
                    </div>
                </li>
                 <?php } ?>
<!--				<li id="Team" class="category">
                    <label class="categoryName">Team Name</label>
                    <div id="TeamCheck">
                        <table id="mslData">
							<select name="team_name[]" id="teams" multiple="multiple" class="chosenMultipleSelectTeams" data-placeholder="Select Teams">
	            				<option value=""></option>
		            			<?php 
					                foreach($arrTeam as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['group_id']?>"><?php echo $arrRow['group_name']?></option>;
		                		<?php }?>
				        	</select>
                        </table>
                    </div>
                </li>-->
                <li id="TherpyArea" class="category">
                    <label class="categoryName">Therapeutic Area:</label>
                    <div id="ThrpCheck">
                        <table id="therpData">	
                            <select name="thrp_name[]" id="therp" multiple="multiple" class=" chosenMultipleSelectTherp" data-placeholder="Select Area">
					            <option value=""></option>
					            <?php 
					                
					                foreach($arrSpecialties as $key=>$arrRow){
					                    $selected    = '';?>
					                    <option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['name']?></option>;
					                <?php }
					                
					            ?>
					            
					        </select>
                        </table>
                    </div>
                </li>
<!--                <li id="EngStatus" class="category">
                    <label class="categoryName">Engagement Status:</label>
                    <div id="EngCheck">
                        <table id="engData">
							<select name="eng_name[]" id="status" multiple="multiple" class="chosenMultipleSelectStatus" data-placeholder="Select Engagement Status">
					            <option value=""></option>
					            <?php 
					                
					                foreach($arrEngagement as $key=>$arrRow){
					                   
					                    $selected    = '';?>
					                    <option value="<?php echo $arrRow['status']?>"><?php echo $arrRow['status']?></option>;
					                <?php }
					                
					            ?>
					            
					        </select>
                        </table>
                    </div>
                </li>-->
            </ul>
        </form>
    </div>
</div>
