<?php
class Common_helper extends CI_Model {
	function search_nested_arrays($array,$key){
		if(is_object($array))
			$array = (array)$array;
		$result = array();
		foreach ($array as $k => $value) {
			if(is_array($value) || is_object($value)){
				$r = $this->search_nested_arrays($value, $key);
				if(!is_null($r))
					array_push($result,$r);
			}
		}
		if(array_key_exists($key, $array))
			array_push($result,$array[$key]);
		if(count($result) > 0){
			$result_plain = array();
			foreach ($result as $k => $value) {
				if(is_array($value))
					$result_plain = array_merge($result_plain,$value);
				else
					array_push($result_plain,$value);
			}
			return $result_plain;
		}
		return NULL;
	}
	function getUserName($id) {
		$name = '';
		if ($id != '' && $id != null) {
			$this->db->select('first_name,last_name,client_id');
			$this->db->where('id', $id);
			$results = $this->db->get('client_users');
			if ($results->num_rows() != 0) {
				$row = $results->first_row();
			if ($row->client_id == INTERNAL_CLIENT_ID)
				$name = "Aissel Analyst";
			else
				$name = $row->first_name . " " . $row->last_name;
			}
		}		
		return $name;
	}
	function getClientNameByClientId($client_id){
		$client_name="";
		$this->db->select('name');
		$this->db->where('id',$client_id);
		$this->db->limit(1);
		$query=$this->db->get('clients');
		$result = $query->result_array();
		foreach($result as $key=>$value){
			$client_name=$value['name'];
		}
		return $client_name;
	}
	function menuListing($client_id=null){
		$this->db->select('client_menu_visibilities.*,primary_name.label as primaryName,primary_name.parent_id as prim_parent_id,secondary_name.label as secondaryName,secondary_name.parent_id as sec_parent_id');
		$this->db->join('client_menu_visibilities as primary_name','primary_name.id=client_menu_visibilities.parent_id','left');
		$this->db->join('client_menu_visibilities as secondary_name','secondary_name.id=primary_name.parent_id','left');
		if($client_id!=null){
			$this->db->where('client_menu_visibilities.client_id',$client_id);
		}
		$this->db->where('client_menu_visibilities.is_visible',1);
		$this->db->order_by('prim_parent_id','asc');
		$this->db->order_by('sec_parent_id','asc');
		$this->db->order_by('client_menu_visibilities.order','asc');
		$query=$this->db->get('client_menu_visibilities');
// 		echo $this->db->last_query();
		$result = $query->result_array();
		$arrModuleId=array();
		foreach($result as $key=>$value){
			if($value['parent_id']==0){
				$arrModuleId[$value['label']][]=$value['url'];
				$arrModuleId[$value['label']][]=$value['is_sec_nav_visible'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']==0)){
				$arrModuleId[$value['primaryName']][$value['label']][]=$value['url'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']!=0) && ($value['sec_parent_id']==0)){
				$arrModuleId[$value['secondaryName']][$value['primaryName']][$value['label']][]=$value['url'];
			}
		}
// 		pr($arrModuleId);
		return $arrModuleId;
	}
	function getEntityById($entityName, $arrWhere = array(), $dbObj = false) {
		$databaseObject	= $dbObj;
		$resultSet = null;
		if(is_array($arrWhere)){
			$arrWhere = array_filter($arrWhere);
		}
		if (!$databaseObject) {
			$databaseObject	= $this->db;
		}
		$databaseObject->where($arrWhere);
		$resultSet = $databaseObject->get ( $entityName );
		return $resultSet->result_array();
	}
	function insertEntity($entityName, $data){
		return $this->db->insert ( $entityName, $data ) ? $this->db->insert_id () : false;
	}
	function updateEntity($entityName, $arrData, $arrWhere = array()) {
		$arrWhere = array_filter($arrWhere);
		$this->db->where ( $arrWhere );
		return $this->db->update ( $entityName, $arrData );
	}
	function deleteById($arrdetails){
		$this->db->delete($arrdetails['table'], array('id' => $arrdetails['id']));
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
	}
// 	//works oly if primary column name is 'id'
// 	function deleteEntityById($table,$id){
// 		$this->db->delete($table, array('id' => $id));
// 		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
// 	}
	function deleteEntityByWhereCondition($table,$arrWhere){
		$this->db->delete($table,$arrWhere);
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
	}
	function deleteRow($table,$columnName,$values=array()){
		$this->db->where_in($columnName,$values);
		if($this->db->delete($table)){
			return true;
		}else{
			return false;
		}
	}
	function getModuleIdByModuleName($module_name){
		$this->db->select('id');
		$this->db->where('module_name',$module_name);
		$this->db->limit(1);
		$query=$this->db->get('module_details');
		$result = $query->result_array();
		foreach($result as $key=>$value){
			$module_id=$value['id'];
		}
		return $module_id;
	}
	function getMailConfig() {
		$arrConfig = array (
				'protocol' => PROTOCOL,
				'smtp_host' => HOST,
				'smtp_port' => PORT,
				'smtp_user' => USER,
				'smtp_pass' => PASS,
				'mailtype' => 'html',
				'charset' => 'iso-8859-1',
				'wordwrap' => TRUE
		);
		return $arrConfig;
	}
	function checkDuplicate($arrdetails){
		$is_duplicate=0;
		$this->db->where($arrdetails['column'],$arrdetails['value']);
		if($arrdetails['id']!=NULL){
			$this->db->where('id !=',$arrdetails['id'],FALSE);
		}
		$query=$this->db->get($arrdetails['table']);
		$array1=$query->result_array();
		$is_duplicate=(sizeof($array1)>0)?1:0;
		return $is_duplicate;
	}
	function deleteByArrayOfDetails($arrdata){
		$this->db->delete($arrdata['table'], array($arrdata['column']=> $arrdata['value']));
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
	}
	function get_name_format($first_name, $middle_name, $last_name) {
		$nameOrder = $this->session->userdata('name_order');
		// $nameOrder = 2;
		switch ($nameOrder) {
			case 1: return $first_name . " " . $last_name;
			break;
			case 2:
				if ($last_name == '')
					return $first_name;
				else if ($middle_name == '')
					return $last_name . ", " . $first_name;
				else
					return $last_name . ", " . $first_name . " " . $middle_name;
				break;
			case 3:
				if ($last_name == '')
					return $first_name;
				else if ($middle_name == '')
					return $first_name . " " . $last_name;
				else
					return $first_name . ", " . $middle_name . " " . $last_name;
				break;
			default :return $first_name . " " . $last_name;
		}
	}
	function getFieldValueByEntityDetails($table_name,$primary_key_column,$primary_key_value,$required_column){
		$this->db->select($required_column);
		$this->db->where($primary_key_column,$primary_key_value);
		$query = $this->db->get($table_name);
		$result = $query->result_array();
		$returnvalue = $result[0][$required_column];
		return $returnvalue;
	}
	function isActionAllowed($section = '', $action = '', $options = array(),$kolDetails=array()) {
		return true;
	}
	function isDataNull($dataVar){
		$isNull = false;
		if(isset($dataVar) && !empty($dataVar) && !is_null($dataVar)){
			$isNull = ($dataVar == 'null' || $dataVar == 'undefined') ? true : $isNull;
		} else {
			$isNull = true;
		}
		return $isNull;
	}
	function getUserProducts($userId = '',$latestDate) {
		$arrProducts = array();
		if ($userId == '')
			$userId = $this->session->userdata('user_id');
		$arrGroupIds = array();
		$this->db->select('group_id');
		$this->db->where('user_id', $userId);
		$res = $this->db->get('user_groups');
		if (is_object($res) && $res->num_rows() > 0) {
			foreach ($res->result_array() as $row)
				$arrGroupIds[] = $row['group_id'];
		}
		if (count($arrGroupIds) > 0) {
			$this->db->select('DISTINCT products.id,products.name,products.modified_on as date,products.sort_id', false);
			$this->db->where('products.status', 1);
			$this->db->where_in('group_products.group_id', $arrGroupIds);
			if($latestDate!='')
				$this->db->where('products.modified_on >', $latestDate);
			$this->db->join('products', 'group_products.product_id = products.id', 'left');
			$this->db->order_by('products.sort_id', 'asc');
			$res = $this->db->get('group_products');
			if (is_object($res) && $res->num_rows() > 0) {
				$noProdId = 0;
				$otherId = 0;
				$noProdRow = array();
				$otherRow = array();
				foreach ($res->result_array() as $row) {
					$arrProducts[$row['sort_id']] = $row;
				}
			}
		}
		return $arrProducts;
	}
	function getGenericId($moduleName) {
		
		switch ($moduleName) {
			
			case "Compliance Form" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Customer Engagement Form" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Medical Insight" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Speaker Evaluation" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Interactions Name" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Location Form" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "Organization Locations" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
				
			case "U O Q" :
				$result = $this->createUniqueId($moduleName);
				return $result;
				break;
		}
	}
	function createUniqueId($moduleName) {
		$expr = '/(?<=\s|^)[a-z]/i';
		preg_match_all($expr, $moduleName, $matches);
		$result = implode('', $matches[0]);
		$uniqueId = strtoupper($result);
		return $uniqueId . now();
	}
	function convertDateToMM_DD_YYYY($inputDate, $delimiter = '/') {
		$ddDate = substr($inputDate, 8, 2);
		$mmDate = substr($inputDate, 5, 2);
		$yyDate = substr($inputDate, 0, 4);
		return ($mmDate . $delimiter . $ddDate . $delimiter . $yyDate);
	}
	function convertArrayToCommaSeparatedElements($arrElements) {
		$commaSeparatedElements = "";
		if (sizeof($arrElements) > 0) {
			foreach ($arrElements as $element)
				$commaSeparatedElements.=$element . ",";
				$commaSeparatedElements = substr($commaSeparatedElements, 0, -1);
		}
		return $commaSeparatedElements;
	}
	
	function checkUsers() {
		if ($this->session->userdata('client_id') != INTERNAL_CLIENT_ID) {
			redirect('kols/client_index');
		}
	}
	function getAllManagersForReports($userId) {
		$arrUserIds = array();
		
		$userRole = $this->session->userdata('user_role_id');
		$userIds = $this->getTeamOtherUserIDs($userId);
		$teamName = $this->getUserTeamName($userId);
		$this->db->select('client_users.id,client_users.first_name,client_users.last_name,client_users.email,client_users.user_name');
		$this->db->join('client_users', 'user_groups.user_id = client_users.id', 'left');
		$this->db->where_in('client_users.user_role_id', array(ROLE_MANAGER));
		if ($userRole == ROLE_MANAGER && strtolower($teamName) != "home office") {
			//get all managers aligned to a team
			$this->db->where_in('client_users.id', $userIds);
			$this->db->where('client_users.client_id', $this->session->userdata('client_id'));
		}		
		$res = $this->db->get('user_groups');
// 		echo $this->db->last_query();
		if (is_object($res) && $res->num_rows() > 0){
			foreach ($res->result_array() as $row)
				$arrUserIds[$row['id']] = $row;
		}
		$arrUserIds = array_values($arrUserIds);
		return $arrUserIds;
	}
	function getTeamOtherUserIDs($userId) {
		$arrUserIds = array();
		//Get user groups
		$arrGroupIds = array();
		$this->db->select('user_groups.group_id');
		$this->db->where('user_id', $userId);
		$this->db->where('groups.group_type', "Team");
		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
		$res = $this->db->get('user_groups');
		if (is_object($res) && $res->num_rows() > 0) {
			foreach ($res->result_array() as $row)
				$arrGroupIds[] = $row['group_id'];
		}
		if (count($arrGroupIds) > 0) {
			$arrGroupIds = array_values($arrGroupIds);
			$this->db->select('DISTINCT user_id', false);
			$this->db->where_in('group_id', $arrGroupIds);
			$res = $this->db->get('user_groups');
			if (is_object($res) && $res->num_rows() > 0) {
				foreach ($res->result_array() as $row)
					$arrUserIds[] = $row['user_id'];
			}			
			$arrUserIds = array_values($arrUserIds);
		}
		$arrUserIds[] =$this->session->userdata('user_id');
		return $arrUserIds;
	}
	function getUserTeamName($userID) {
		$name = "";
		$this->db->select("groups.group_name");
		$this->db->where("groups.group_type", "Team");
		$this->db->where("user_id", $userID);
		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
		$res = $this->db->get('user_groups');
		if ($res->num_rows() > 0) {
			$row = $res->row_array();
			$name = $row['group_name'];
		}
		return $name;
	}
	function getManagerAlignedUsers($userId) {
		$user = array();
		$this->db->select("id");
		if(!is_array($userId)){
			$userId	= array($userId);
		}
		$this->db->where_in('manager_id', $userId);
		$arrUserResult = $this->db->get('client_users');
		foreach ($arrUserResult->result_array() as $row) {
			$user[] = $row['id'];
		}
		$user = array_values($user);
		return $user;
	}
	function get_name_format_order_simple($table='') {
		// $nameOrder = $this->session->userdata('name_order');
		 $nameOrder = 3;
		switch ($nameOrder) {
			case 3:
				if(is_null($table.middle_name)){
					return "$table.first_name,' ',$table.middle_name,' ', $table.last_name";
				}else{
					return "$table.first_name,' ',$table.last_name";
				}
				break;
			case 1:
				return "$table.first_name,' ',$table.last_name";
				break;
			case 2:
				if(is_null($table.middle_name)){
					return "$table.last_name,', ',$table.first_name,' ',$table.middle_name";
				}else{
					return "$table.last_name,', ',$table.first_name";
				}
				break;
		}
	}  
	function checkApproverId(){
		$arrUserIds    = array();
		$group_name = 'ProfileRequestAccess';
		$this->db->select('user_groups.user_id');
		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'join');
		$this->db->where("groups.group_name",$group_name);
		$res = $this->db->get('user_groups');
		if (is_object($res) && $res->num_rows() > 0) {
			foreach ($res->result_array() as $key => $value){
				$arrUserIds[] = $value['user_id'];
			}
		}
		return $arrUserIds;
	}
	function check_module($module_name){
		$filename = APPPATH.'modules/'.$module_name;
		return file_exists($filename);
	}
	function getKolClientVisiblityId($id){
		$clientId = $this->session->userdata('client_id');
		if($this->session->userdata('changedClientId')){
			$clientId = $this->session->userdata('changedClientId');
		}
		$this->db->select('id');
		if(!is_numeric($id)){
			$this->db->where('unique_id', $id);
		}else{
			$this->db->where('kol_id', $id);
		}
		$this->db->where('client_id', $clientId);
		$query = $this->db->get('kols_client_visibility');
		// 		pr($this->db->last_query());exit;
		$result = $query->result_array();
		$returnId = $result[0]['id'];
		return $returnId;
	}
	
	function getOnlyYearByDate($date) {
		if ($date == '0000-00-00')
			return '';
			if ($date != '') {
				$str = $date;
				$time = strtotime($str);
				if ($time == 0) {
					return '';
				} else {
					$yyyy = date("Y", $time);
				}
				return $yyyy;
			} else {
				return $date;
			}
	}
}