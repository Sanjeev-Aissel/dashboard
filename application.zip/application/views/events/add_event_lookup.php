<?php
/**
 * File to 'add' Event Lookup details
 *
 * @author: Ambarish
 * @created on: 24-12-10
 */
?>

	<style type="text/css">
		#eventLookupForm{
			text-align:left;
		}
		#eventLookupForm label{
			text-align:right;
			float:left;
			width:130px;
			padding-right:8px;
		}
		
		#eventLookupForm textarea{
			height:30px;
			width:250px;
		}
		
		#eventLookupForm eventLookupName{
			width:250px;
		}		
		
		#eventLookupForm div.formButtons{
			text-align:center;
		}
		
		#eventLookupFormContainer div.msgBoxContainer{
			margin-bottom:20px;
		}		
	
	</style>
	
		<script type="text/javascript">
		/**
		* Save the new Event Lookup Name
		*/
		function saveEventLookup(){
			formData	= $("#eventLookupForm").serialize();
			$.ajax({
				type:"post",
				dataType:"json",
				data: formData,
				url:'<?php echo base_url()?>kols/save_event_lookup',
				success:function(returnMsg){
					$('div.eventLookupMsgBox').fadeIn("fast");
					$('div.eventLookupMsgBox').text(returnMsg.msg);
					if(returnMsg.saved){
						$('div.eventLookupMsgBox').removeClass('error');
						$('div.eventLookupMsgBox').addClass('success');

						// Remove/Hide the 'Event name Not Found' text
						$(".instNotFound").hide();

						// Call the 'CloseDialog' method with delay
						setTimeout(closeDialog, 1000);
					}else{
						$('div.eventLookupMsgBox').removeClass('success');
						$('div.eventLookupMsgBox').addClass('error');
					}

					// Clear the existing form details 
					$("#eventLookupNotes").val("");
					$('div.eventLookupMsgBox').fadeOut(10000);
				}
			});
		}

		/**
		* Closes the Dialog Box with some time delay
		*/
		function closeDialog(){
			$("#eventLookupProfile").dialog("close");
		}
	
	</script>

<div id="eventLookupFormContainer">
	<form action="<?php echo base_url()?>kols/save_event_lookup" method="post" id="eventLookupForm" name="eventLookupForm" class="validateForm">
		<div class="msgBoxContainer"><div class="eventLookupMsgBox"></div></div>
		<p>
			<label for="eventLookupCategory">Category:<span class="required">*</span></label>
			<select name="category" id="eventLookupCategory">
	     		<option value="conference">Conference</option>
	     		<option value="online">Online</option>
	    	</select>
		</p>
	
		<p>
			<label for="eventLookupName">Name:<span class="required">*</span></label>
			<input type="text" name="name" value="<?php echo$eventName?>" id="eventLookupName" />
		</p>
	
		<p>
			<label for="eventLookupNotes">Notes:</label>
			<textarea name="notes" class="textArea" id="eventLookupNotes"></textarea>
		</p>
		
		<div class="formButtons">
			<input type="button" value="Add Event" name="submit"  onClick="saveEventLookup();">
		</div>
	</form>				
</div>	