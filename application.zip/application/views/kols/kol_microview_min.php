<style>
	#microview-container img{
		float:left;
	}
	#microview-container .conns{
		clear:both;
	}
</style>

<?php if($arrKol['profile_image'] != ''){
	echo '<img width="40" alt="Image" src="'. base_url(). 'images/kol_images/resized/'. $arrKol['profile_image'].'"/>';
}else{?>
	<img alt="Image" width="40" src="<?php echo base_url()?>images/user_doctor.jpg" />
	<?php 
}?>
<p class='details'>
	<?php 
	if(KOL_CONSENT){
	    if($arrKol['opt_in_out_status'] == 4 || $arrKol['opt_in_out_status'] == 0) {?>
    	<a href="<?php echo base_url();?>kols/view/<?php echo $arrKol['unique_id'];?>" target="_new">
    		<?php echo $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name'])?>
    	</a>
	<?php }else{?>
    		<?php echo $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name'])?>
	<?php }
    }else{ ?>
        <a href="<?php echo base_url();?>kols/view/<?php echo $arrKol['unique_id'];?>" target="_new">
        	<?php echo $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name'])?>
    	</a>
    <?php }?>
		
	<br>
	<?php echo $arrKol['name']; ?>
</p>
<p class="conns">Number of Connections:</p>