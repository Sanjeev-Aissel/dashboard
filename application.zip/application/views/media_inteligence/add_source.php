<?php
    // prepare array of JS files to insert into queue
    $queued_js_scripts = array('index/client_index','jquery/jquery-ui-1.8.16.datepicket');
    // add the JS files into queue i.e Append to the existing queue
    $this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<html>
    <head>
        <script type="text/javascript">
            function addSource()
            {
               var  data=$("form").serialize();
               if(($("#link").val()!='') && ($("#an").val()!='') && ($("#av").val()!='') && ($("#tn").val()!='') && ($("#pub").val()!='') )
               {
                $.ajax({                    
                        url:'<?php echo base_url();?>media_intel_extractions/save_source_data/',
                        type:'POST',
                        dataType :'TEXT',
                        data:data,
                        success:function(returnData){

                        if(returnData==1){
                            jAlert("Source Added successfully");
                            window.location = "<?php echo base_url()?>media_intel_extractions/analystSourceGrid";
                        }else
                            jAlert("There was a problem in adding the source.");

                        }
                    });
                }
                else
                    jAlert("All fields are Manadatory!");
            }
        </script>
        <style>
          
           .box_style{
                width:500px;
                height:25px;
            }
            
        </style>
    </head>
    <div class="container_details">
        <fieldset>
            <legend>Add New Source</legend>
            <form name="details" method="post">

                <table>
                    <tr><td>Source</td><td><input id="link" required class='box_style '  type="text" name="link" /></td></tr>
                    <tr><td>Attribute Name</td><td><input id="an" required class='box_style '  type="text" name="attribute_name"   /></td></tr>
                    <tr><td>Attribute Value</td><td><input id="av" required  class='box_style '  type="text" name="attribute_value"   /></td></tr>
                    <tr><td>Tag name</td><td><input  id="tn" required class='box_style '  type="text" name="tag_name"   /></td></tr>
                    <tr><td>Publisher</td><td><input id="pub" required  class='box_style '  type="text" name="publisher"   /></td></tr>
                    <tr><td></td><td><input type="button" onclick="addSource()" name="save" value='Save' /><input type="reset" name="reset" value='Reset' /></td></tr>
                </table>



            </form>
        </fieldset>
    </div>
    
    
    
    
    
    
    
    
</html>
