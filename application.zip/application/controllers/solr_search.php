<?php
/*
 * To sync with Apache's SOLR
 * @author: Laxman K
 * @date  : 10-02-2012
 * 
 */
class Solr_Search extends controller{
	function Solr_Search(){
		error_reporting(E_ALL);
		parent::Controller();
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		require_once $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."system/plugins/Apache/Solr/Service.php";
		$this->solr	= new Apache_Solr_Service('localhost', 8983, '/solr/');
		if (!$this->solr->ping()){
			echo "Search Server Not Running";
		}
	}
	
	function index(){
		$data['contentPage'] 	= 'solr_search/search_form';
		$this->load->view('layouts/client_view', $data);
	}
	function advancedsearch($searchTab=''){
		$page		= $this->input->post('page');
		//$limit		= $this->ajax_pagination->per_page;
		$limit		= 100;
		$startFrom	= $page;
		if($startFrom==-1)
			$startFrom=0;
		$startTime			= microtime(true);
		$arrSearchInputs	= $_POST;
		$inputCountFlag		= 0;
	//	pr($arrSearchInputs);
		$kolFName			= '';
		$kolLName			= '';
		$keywords			= '';
		$pKeywords			= '';
		$pCondition			= 0;
		$eTopic				= '';
		$eRole				= '';
		$eCondition			= 0;
		$tKeywords			= '';
		$tCondition			= 0;
		$prepareQuery		= '';
		foreach($arrSearchInputs as $index => $value){
			if(empty($value)){
				unset($arrSearchInputs[$index]);
			}else{
				if(isset($arrSearchInputs['kols'])){
					switch($index){
						case 'fname': $kolFName		.= trim($value);
								break;
						case 'lname': $kolLName	.= trim($value);
								break;
						case 'keywords': $keywords	.= trim($value);
								break;
						case 'pkeywords': $pKeywords	.= trim($value);
											$pCondition	= $arrSearchInputs['pqtype'];
								break;
						case 'etopic': $eTopic	.= trim($value);
											$eCondition	= $arrSearchInputs['eqtype'];
											$eRole	= $arrSearchInputs['erole'];
								break;
						case 'tkeywords': $tKeywords	.= trim($value);
											$tCondition	= $arrSearchInputs['tqtype'];
								break;
					}
				}
			}
		}
		$searchInputs	= $arrSearchInputs;
		unset($arrSearchInputs['kols']);
		if(!empty($kolFName)){
			$prepareQuery	.= '(f_name:'.$kolFName.'*)';
			$inputCountFlag	= 1;
		}
		if(!empty($kolLName)){
			if($inputCountFlag){
				$prepareQuery	.= 'AND';
			}else{
				$inputCountFlag	= 1;
			}
			$prepareQuery	.= '(l_name:'.$kolLName.'*)';
		}
		if(!empty($keywords)){
			if($inputCountFlag){
				$prepareQuery	.= 'AND';
			}else{
				$inputCountFlag	= 1;
			}
			$prepareQuery	.= '(kol_title:*'.$keywords.'*';
			$prepareQuery	.= ' OR kol_bio:*'.$keywords.'*';
			$prepareQuery	.= ' OR research_interest:*'.$keywords.'*';
			$prepareQuery	.= ' OR kol_address:'.$keywords.'*';
			$prepareQuery	.= ' OR specialty:'.$keywords.'*';
			$prepareQuery	.= ' OR sub_specialty:'.$keywords.'*';
			$prepareQuery	.= ' OR kol_country:'.$keywords.'*';
			$prepareQuery	.= ' OR kol_state:'.$keywords.'*';
			$prepareQuery	.= ' OR kol_city:'.$keywords.'*';
			$prepareQuery	.= ' OR org_name:'.$keywords.'*';
			$prepareQuery	.= ' OR kol_institute_name:'.$keywords.'*';
			$prepareQuery	.= ' OR event_name:*'.$keywords.'*';
			$prepareQuery	.= ' OR event_role:'.$keywords.'*';
			$prepareQuery	.= ' OR session_name:*'.$keywords.'*';
			$prepareQuery	.= ')';
		}
		if(!empty($pKeywords)){
			if($inputCountFlag){
				if($pCondition){
					$prepareQuery	.= ' AND ';
				}else{
					$prepareQuery	.= ' OR ';
				}
			}else{
				$inputCountFlag	= 1;
			}
			$prepareQuery	.= '(pub_abstract_text:*'.$pKeywords.'*';
			$prepareQuery	.= ' OR pub_article_title:*'.$pKeywords.'*';
			$prepareQuery	.= ')';
		}
		if(!empty($eTopic) || !empty($eRole)){
			if($inputCountFlag){
				if($eCondition){
					$prepareQuery	.= ' AND ';
				}else{
					$prepareQuery	.= ' OR ';
				}
			}else{
				$inputCountFlag	= 1;
			}
			if(!empty($eTopic))
				$prepareQuery	.= '(event_name:*'.$eTopic.'*)';
			if(!empty($eTopic) && !empty($eRole)){
				$prepareQuery	.= ' AND ';
			}
			if(!empty($eRole))
				$prepareQuery	.= '(event_role:*'.$eRole.'*)';
		}
		if(!empty($tKeywords)){
			if($inputCountFlag){
				if($tCondition){
					$prepareQuery	.= ' AND ';
				}else{
					$prepareQuery	.= ' OR ';
				}
			}else{
				$inputCountFlag	= 1;
			}
			$prepareQuery	.= '(trial_name:*'.$tKeywords.'*';
			$prepareQuery	.= ' OR trial_purpose:*'.$tKeywords.'*';
			$prepareQuery	.= ' OR trial_condition:*'.$tKeywords.'*';
			$prepareQuery	.= ' OR trial_title:*'.$tKeywords.'*';
			$prepareQuery	.= ')';
		}
		
		$query		= 'q='.$prepareQuery;
		$error_msg	= '';
		$results	= '';
		$query 		= stripslashes($query);
		echo $query;
		try{
	    	$results	= $this->solr->search($query, $startFrom, $limit);
			$total		= (int) $results->response->numFound;
			$end		= min(($startFrom+ $limit), $total);
			$arrData	= array();
			$i			= 0;
			  // iterate result documents
			  foreach ($results->response->docs as $doc)
			  {
				$relativeCount	= 0;
			    // iterate document fields / values
			    foreach ($doc as $field => $value)
			    {
			    	$perColumn		= 1;
			    	foreach($searchInputs as $key=>$input){
			    		if((preg_match_all('/'.$input.'/i',$value,$matches))>0 && $perColumn==1){
			    			$relativeCount++;
			    			$perColumn = 0;
				    		//pr($matches);
			    		}
			    	}
			    	switch($field){
			    		case 'specialty':$field	= 'specs';
			    				break;
	    				case 'kol_country':$field	= 'country';
			    				break;
			    		case 'f_name':$field	= 'first_name';
			    				break;
			    		case 'm_name':$field	= 'middle_name';
			    				break;
			    		case 'l_name':$field	= 'last_name';
			    				break;
			    	}
			    	$arrData[$i][$field]	= htmlspecialchars($value, ENT_NOQUOTES, 'utf-8');
			    }
			    $arrData[$i]['relative_count']	= $relativeCount;
			    $arrData[$i]['salutation']		= 1;
			    $arrKols[$i][1]					= $arrData[$i];
			    $i++;
			  }
			  
		}
		catch (Exception $e){
	        //die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
	        $error_msg	= $e->__toString();
		}
	//	pr($arrKols);
		$data['arrSalutations']	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['searchInputs']	= $arrSearchInputs;
		$data['startTime'] 		= $startTime;
		$data['start'] 			= $startFrom;
		$data['limit'] 			= $limit;
		$data['error_msg'] 		= $error_msg;
		$data['msg'] 			= $this->common_helpers->genSearchResMsgs($startFrom,$limit,$total,$arrSearchInputs);
		$data['arrKols'] 		= $arrKols;
	//	$data['contentPage'] 	= 'solr_search/search';
		$data['kolsCount']		= $total;
		$data['searchType']		= 'advanced';
		$data['contentPage'] 	= 'search/kol_search_results';
		$this->load->view('layouts/client_view', $data);
	}
	function getAllKOLnames($limitStart,$limitEnd){
		$arrKOLData = array();
/*		$query ='select k.first_name, k.middle_name,k.last_name, k.suffix, k.sub_specialty, k.title as kol_title
, c.Country as country_name
, reg.Region as state_name
, citi.City as city_name

, ins.name as institute_name
, o.name as organization_name
, kev.session_name as session_name
, kev.role as event_role
, ke.name as event_name
, kmem.title as member_title
, spl.specialty as specialty_name

from kols k
,institutions ins
,kol_educations ked
,kol_events kev
,events ke
,kol_memberships kmem
,organizations o
,specialties spl
,countries c
,regions reg
,cities citi


where k.id=81 
and ked.kol_id=k.id
and kev.kol_id=k.id
and kmem.kol_id=k.id
and ins.id = ked.institute_id
and ke.id=kev.event_id
and o.id=k.org_id
and spl.id=k.specialty
and c.CountryId=k.country_id
and reg.RegionID=k.state_id
and citi.CityId=k.city_id';
*/
		$this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.division, kols.research_interests, kols.biography, kols.profile_image,kols.gender,kols.sub_specialty,kols.title,specialties.specialty,countries.Country as country,regions.Region as state,cities.City as city,organizations.name as organization');
		$this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
		$this->db->join('regions', 'regions.RegionID=kols.state_id', 'left');
		$this->db->join('cities', 'cities.CityId=kols.city_id', 'left');
		$this->db->join('organizations', 'organizations.id=kols.org_id', 'left');
		$this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
		$this->db->where("(kols.status='".COMPLETED."')",null);
		$this->db->limit($limitEnd,$limitStart);
		$resultSet	= $this->db->get('kols');
		//echo $this->db->last_query();
		foreach($resultSet->result_array() as $row){
			
			$separator		= '|| ';
			$institutes		= '';
			$query			= 'select i.name as institute_name from institutions i,kol_educations ke where i.id=ke.institute_id and ke.kol_id='.$row['id'];
			$subResultSet	= $this->db->query($query);
			foreach($subResultSet->result_array() as $institutes_data){
				$institutes[]	= $institutes_data['institute_name'];
			}
			$arrEvents		= '';
			$arrRoles		= '';
			$arrSessions	= '';
			$query			= 'select ke.session_name,ke.role,e.name as event_name,et.name as topic_name from kol_events ke, events e, event_topics et where e.id=ke.event_id and et.id=ke.topic and kol_id='.$row['id'];
			$subResultSet	= $this->db->query($query);
			foreach($subResultSet->result_array() as $events_data){
				if(!empty($events_data['event_name']))
					$arrEvents[]	= $events_data['event_name'].' - '.$events_data['topic_name'];
				if(!empty($events_data['role']))
					$arrRoles[]		= $events_data['role'];
				if(!empty($events_data['session_name']))
					$arrSessions[]	= $events_data['session_name'];
			}
			$pub_abstract_text	= '';
			$pub_article_title	= '';
			$pub_auth_pos		= '';
			
			$query			= "select publications.abstract_text as abstract_text, publications.article_title as article_title, kol_publications.auth_pos as auth_pos from kol_publications join publications on publications.id=kol_publications.pub_id
			where kol_publications.is_verified=1 and 
				kol_publications.is_deleted=0 and
				kol_publications.kol_id=".$row['id'];
			$subResultSet	= $this->db->query($query);
			foreach($subResultSet->result_array() as $pubs_data){
				$pub_abstract_text[]	= $pubs_data['abstract_text'];
				$pub_article_title[]	= $pubs_data['article_title'];
				$pub_auth_pos[]			= $pubs_data['auth_pos'];
			}
			$trial_name		= '';
			$trial_condition= '';
			$trial_title	= '';
			$trial_purpose	= '';
			$query			= "select clinical_trials.trial_name as trial_name, clinical_trials.purpose as trial_purpose,
								clinical_trials.condition as trial_condition,
								clinical_trials.official_title as trial_title from clinical_trials join kol_clinical_trials on clinical_trials.id=kol_clinical_trials.cts_id where kol_clinical_trials.kol_id=".$row['id'];
			$subResultSet	= $this->db->query($query);
			foreach($subResultSet->result_array() as $trials_data){
				$trial_name[]		= $trials_data['trial_name'];
				$trial_condition[]	= $trials_data['trial_condition'];
				$trial_title[]		= $trials_data['trial_title'];
				$trial_purpose[]	= $trials_data['trial_purpose'];
			}
			$arrKOLData[]	= array(
								'id'				=> $row['id'],
								'kol_title'			=> $row['title'],
							//	'suffix_t'			=> $row['suffix'],
								'name'				=> $row['first_name'].' '.$row['middle_name'].' '.$row['last_name'],
								'f_name'			=> $row['first_name'],
								'm_name'			=> $row['middle_name'],
								'l_name'			=> $row['last_name'],
								'gender'			=> $row['gender'],
								'profile_image'		=> $row['profile_image'],
								'division'			=> $row['division'],
								'profile_image'		=> $row['profile_image'],
								'research_interest'	=> $row['research_interests'],
								'kol_bio'			=> $row['biography'],
								'kol_country'		=> $row['country'],
								'kol_state'			=> $row['state'],
								'kol_city'			=> $row['city'],
								'org_name'			=> $row['organization'],
								'specialty'			=> $row['specialty'],
								'sub_specialty'		=> $row['sub_specialty'],
								'kol_institute_name'=> implode($separator,array_unique($institutes)),
								'event_name'		=> implode($separator,array_unique($arrEvents)),
								'event_role'		=> implode($separator,array_unique($arrRoles)),
								'session_name'		=> implode($separator,array_unique($arrSessions)),
								'pub_abstract_text'	=> implode($separator,array_unique($pub_abstract_text)),
								'pub_article_title'	=> implode($separator,array_unique($pub_article_title)),
								'pub_auth_pos'		=> implode($separator,array_unique($pub_auth_pos)),
								'trial_name'		=> implode($separator,array_unique($trial_name)),
								'trial_condition'	=> implode($separator,array_unique($trial_condition)),
								'trial_title'		=> implode($separator,array_unique($trial_title)),
								'trial_purpose'		=> implode($separator,array_unique($trial_purpose))
								//'m_name_t'	=> $row['middle_name'],
								//'l_name_t'	=> $row['last_name']
							);
		}
		//pr($arrKOLData);
		return($arrKOLData);
	}
	/*
	 * Fetch the required data from database and add fetched records to SOLR document
	 * @author: Laxman K
	 *   User/custom defined fields should be end with following 
     *  <dynamicField name="*_i"  type="sint"    indexed="true"  stored="true"/>
	 *  <dynamicField name="*_s"  type="string"  indexed="true"  stored="true"/>
	 *  <dynamicField name="*_l"  type="slong"   indexed="true"  stored="true"/>
	 *  <dynamicField name="*_t"  type="text"    indexed="true"  stored="true"/>
	 *  <dynamicField name="*_b"  type="boolean" indexed="true"  stored="true"/>
	 *  <dynamicField name="*_f"  type="sfloat"  indexed="true"  stored="true"/>
	 *  <dynamicField name="*_d"  type="sdouble" indexed="true"  stored="true"/>
	 *  <dynamicField name="*_dt" type="date"    indexed="true"  stored="true"/>
	 *
	 */	
	function sync_search_data($limitStart=0,$limitEnd=100){
	
/*		$document			= new Apache_Solr_Document();
		$document->id		= 'title4'; //or something else suitably unique
        $document->title 	= 'title4';
        $document->name 	= 'title4';
        $document->desc_t 	= 'Some content for this wonderful document. Blah blah blah.';
*/      
	//	ini_set("max_execution_time",3600);
	//	ini_set('memory_limit', '2000M');
		$arrData	= $this->getAllKOLnames($limitStart,$limitEnd);
		$arrSolrObj	= array();	
		foreach ($arrData as $key => $fields){
			$solrObj	= new Apache_Solr_Document();
			foreach ($fields as $fieldname => $fieldvalue){
				$solrObj->$fieldname	= $fieldvalue;
			}
			$arrSolrObj[]	= $solrObj;
		}
		
        //if you're going to be adding documents in bulk using addDocuments
        //with an array of documents is faster
		try {
			//$this->solr->addDocuments($arrSolrObj); for single row
		    $this->solr->addDocuments($arrSolrObj);    
		    $this->solr->commit(); //commit to see the deletes and the document
	        $this->solr->optimize(); //merges multiple segments into one
	         echo "Search Data is Updated";
		}
		catch ( Exception $e ) {
		    echo "Error : ".$e->getMessage();
		}
	}
	
	function search($query, $limit=10, $start=0){
		$startTime	= microtime(true);
		$query		= $query.' desc_t:'.$query;
		$query		= 'q='.$query;
		$error_msg	= '';
		$results	= '';
		$query 		= stripslashes($query);
		try{
	    	$results	= $this->solr->search($query, $start, $limit);
		}
		catch (Exception $e){
	        //die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
	        $error_msg	= $e->__toString();
		}
		$data['startTime'] 		= $startTime;
		$data['limit'] 			= $limit;
		$data['error_msg'] 		= $error_msg;
		$data['responseData'] 	= $results;
		$data['contentPage'] 	= 'solr_search/search';
		$this->load->view('layouts/client_view', $data);
	}
	
	function searchkol($query, $limit=10, $start=0){
		$startTime	= microtime(true);
		$query		= $query.'* m_name_t:'.$query.'* l_name_t:'.$query.'*';
		$query		= 'q='.$query;
		$error_msg	= '';
		$results	= '';
		$query 		= stripslashes($query);
		try{
	    	$results	= $this->solr->search($query, $start, $limit);
		}
		catch (Exception $e){
	        //die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
	        $error_msg	= $e->__toString();
		}
		$data['startTime'] 		= $startTime;
		$data['start'] 			= $start;
		$data['limit'] 			= $limit;
		$data['error_msg'] 		= $error_msg;
		$data['responseData'] 	= $results;
		$data['contentPage'] 	= 'solr_search/search';
		$this->load->view('layouts/client_view', $data);
	}
	
}
?>