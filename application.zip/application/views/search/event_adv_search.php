<div id="advSearchFieldsContainer">
	<div class="msgBoxContainer">
		<div class="advSearchMsgBox">
		</div>
	</div>
	<form action="<?php echo base_url()?>kols/adv_search_events" name="advSearchForm" method="post" id="advSearchForm">
		<fieldset class="ui-corner-all"><legend>Events Advanced Search</legend> 
			<p>
				<label for="confEventType">Event Type:</label>
				<select name="type" id="confEventType">
		   			<option value="">--- Select ---</option>
					<?php 
						foreach($arrEventSessionTypes as $key => $value){
							echo '<option value="'.$value.'">'.$value.'</option>';
						}
					?>
		    	</select>
			</p>

			<p>
				<label>Role</label>
				<input type="text" name="role" id="role"/>
			</p>
	
			<p>
				<label>Country</label>
				<input type="text" name="country" id="country"/>
			</p>
		
			<p>
				<label>Oraganizer</label>
				<input type="text" name="organizer" id="organizer"/>
			</p>
		
		<input type="button" name="do_earch" id="doSearch" onclick="validateAdvSearchForm()" value="search"/>			
		</fieldset>
	</form>
</div>