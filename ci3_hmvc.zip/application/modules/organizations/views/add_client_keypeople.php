<script src="http://localhost/hmvc/assets/js/jquery.validate1.9.min.js"></script>
<script type="text/javascript">
var base_url = "<?php echo base_url(); ?>";
var orgId = '<?php echo $arrOrganization['id'];?>';
$(document).ready(function(){
	
});

</script>
<script>


	$(document).ready(function(){
		<?php 
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
				$this->output->set_header("Pragma: no-cache"); 
			?>
		
		$("#keyPeopleForm").validate({
			debug:false,
			onkeyup:false,
			rules: validationRules,
			messages: validationMessages
		});
	});


	var validationRules	=  {
			role_id: {
				required:true
			},
			salutation: {
				required:true
			}, 
			first_name: {
				required:true
			},			
			email: "email"
		};

		var validationMessages = {
			role_id: {
					required:"Required"
				},
			salutation: {
				required:"Required"
			},
			first_name: {
					required: "Required"
			}		
		};
	function save(){
		if(!$("#keyPeopleForm").validate().form()){
			return false;
		}
		$('.uniMsgBox').removeClass('success');
		$('.uniMsgBox').addClass('notice');
		$('.uniMsgBox').show();

		$('.uniMsgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

		var id = $('#id').val();
		
		if(id==''){
			var action  ='<?php echo base_url()?>organizations/save_key_people/'+orgId;
		}else{
			var action  ='<?php echo base_url()?>organizations/update_key_people/'+orgId;
		}
		$.ajax({
			url:action,
			data:$('#keyPeopleForm').serialize(),
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved){
					$('div.uniMsgBox').removeClass('error');
					$('div.uniMsgBox').addClass('success');
					$('.uniMsgBox').html("Saved Successfully.")
				}
			}

		});

	}
</script>
<style>
label.error {
    color: #ff0000 !important;
}
.object-name {
    display: inline-block;
}
.panel{
border-radius:0px !important;
}
.panel-group .panel+.panel {
    margin-top: 0px !important;
}
.panel-title {
    font-size: 13px !important;
    font-weight: bold;
}
.title{
	font-size: 14px;
	margin-top: 20px;
    font-weight: bold;
    border-bottom:1px dashed #ccc;
}
.box-background{
	background: #f4f4f4;

}
.top-buttons{
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 5px;
    font-size: 12px;
}
.glyphicon { margin-right:10px; }
.panel-body { padding:0px; }
.panel-body table tr td { padding-left: 15px }
.panel-body .table {margin-bottom: 0px; }
.org-box{margin-bottom:10px;padding :10px; min-height: 190px;}
.border-box{ border:1px solid #ccc;} 
.subnotes{margin-top:10px;}
input[type=file] {
    display: inline !important;
}
.organization-container-head{
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,f4f4f4+47,c9c9c9+100 */
background: #ffffff; /* Old browsers */
background: -moz-linear-gradient(top,  #f0f0f0 0%, #f4f4f4 47%, #c9c9c9 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f0f0f0', endColorstr='#c9c9c9',GradientType=0 ); /* IE6-9 */
	
}
p.profileName {
    margin-bottom: 0px;
    font-weight: bold;
    text-align: center;
}
#organizationShortDetails {
    text-align: center;
    width: 100%;
    background: #ffffff;
    padding: 10px 0;
    color: #000000;
    font-weight: bold;
    border-top: 1px solid #ccc;
}
.top-header{
	padding:5px 0;
}
.margin-zero{
	margin-top:0 !important;
}
/*key people css */
.tab-pane{
	border-left:1px solid #ccc;
	border-right:1px solid #ccc;
	border-bottom:1px solid #ccc;
	padding: 10px;
	height: 100%;
}
.content{
	min-height: 600px;
}
</style>
<script>
function saveFiltersLayout(){
	$(".modal-body").load('http://localhost/hmvc/organizations/add_client_keypeople/'+orgId);
}
</script>
<div class="row top-header">
	<?php $this->load->view('organizations/organization_header_bar'); ?>
</div>
<div class="row">
		<div class="secondary-menu col-md-2" style="padding-right: 0px;padding-left: 0px;">
			<?php $this->load->view('organizations/organization_left_side_bar'); ?>
		</div>
		<div class="content col-md-10" style="border-left: 1px solid #ccc;">
<div class="container box">
	<div class="msgBoxContainer"><div class="uniMsgBox"></div></div>
	<form action="save_key_people" method="post" id="keyPeopleForm" name="peopleForm" class="validateForm form-horizontal">
	        <input type="hidden" name="org_id" id="orgId" value="<?php echo $orgId;?>"/>
		    <input type="hidden" name="id" id="id" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['id']?>"/>
				<h4 class="page-header" style="margin-top:0px;"><?php if($arrkeyPeople!='') echo 'Edit'; else echo 'New';?> Key Person</h4>
					<div class="form-group">
						<label class="col-sm-2 control-label">Role <span class="error">*</span> :</label>
						<div class="col-sm-4">
							<select class="form-control" name="role_id" id="keyRole" class="required">
							<option value="">Select Role</option>
                            <?php 
							foreach($arrKeyPeopleRoles as $key => $value){
							if($key == $arrkeyPeople['role_id'])
								echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
							else
								echo '<option value="'.$key.'">'.$value.'</option>';
							}
							?>
							</select>
						</div>
						<label class="col-sm-2 control-label">Salutation <span class="error">*</span> :</label>
						<div class="col-sm-4">
							<select class="form-control" name="salutation" id="keySalutation" class="required">
								<option value="">Select Salutation</option>
                            	<?php 
								foreach($arrSalutations as $key => $value){
									if($key == $arrkeyPeople['salutation'])
										echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
									else
										echo '<option value="'.$key.'">'.$value.'</option>';
								}
								?>
                            </select>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">First Name :</label>
						<div class="col-sm-4">
							<input type="text" name="first_name" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['first_name']?>" id="keyFirstName" maxlength="30" class="required form-control" placeholder="First Name">
						</div>
						<label class="col-sm-2 control-label">Middle Name :</label>
						<div class="col-sm-4">
							<input type="text" name="middle_name" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['middle_name']?>" id="keyMiddleName" maxlength="30" class="form-control" placeholder="Middle Name">
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Last Name :</label>
						<div class="col-sm-4">
							<input type="text" name="last_name" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['last_name']?>" id="keyLastName" maxlength="30" class="form-control" placeholder="Last Name">
						</div>
						<label class="col-sm-2 control-label">Title :</label>
						<div class="col-sm-4">
							<input type="text" name="title" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['title']?>" id="keyTitle" class="form-control" placeholder="Title">
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Email :</label>
						<div class="col-sm-4">
							<input type="text" name="email" value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['email']?>" id="keyEmail" class="email form-control" maxlength="30" placeholder="Email Id">
						</div>
						<label class="col-sm-2 control-label">Department :</label>
						<div class="col-sm-4">
							<input type="text" name="department"  value="<?php if($arrkeyPeople!='') echo $arrkeyPeople['department']?>" id="department" class="form-control" placeholder="Department">
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-sm-offset-5  col-sm-2">
							<button type="button" name="submit" id="saveKeyPeople" onclick="save()" class="btn btn-primary btn-label-left">
							<span><i class="fa fa-clock-o"></i></span>
								Save
							</button>
							<button type="cancel" class="btn btn-default btn-label-left">
							<span><i class="fa fa-clock-o txt-danger"></i></span>
								Cancel
							</button>
						</div>
					</div>
	</form>
</div>
		</div>
</div>