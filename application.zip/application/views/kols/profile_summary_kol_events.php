<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$queued_js_scripts =array('i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

?>
<style>
    
    #events{
        height:400px !important;
        overflow-y:scroll;
    }
    .ui-jqgrid-titlebar.ui-widget-header.ui-corner-top.ui-helper-clearfix {
	    font-weight: normal;
	}    
</style>

<script>
function viewMicro(id){
    
    if(segment!='i'){
    $("#event").html("<div class='microViewLoading'>Loading...</div>");
		$("#event").dialog("open");
                var url='<?php echo base_url()?>kols/view_kol_micro/'+id;
		$("#event").load(url,function(){
                    
                    $("#event").prepend('<button onclick="back()">Back</button><br/><br/>')
                    
                });
            }
            
            if(segment=='i'){
                 $("#modalBoxMyList").modal("show");
                $('#modalBoxMyList .title').html("<span id='title'>KTL Profile<span>");
                $('#modalBoxMyList div').addClass("modal-md").removeClass("modal-sm");
                $('#modalBoxMyList .modal-header').prepend(" <button id='back' onclick='back()' style='float:left;width:100px;height:36px' class='btn btn-default' type=\"button\" >Back</button> ");
                $('#modalBoxMyList .content').empty();
                $('#modalBoxMyList .content').load(ipad_base_url + 'kols/view_kol_micro/' + id);
                
                }
    
    
}


    function list_events(){
        if(topicType == 'events'){
            var title = "Similar speakers on the topic"+" <i><b>"+topicName+"</b></i>";
            var topicCount = "No. of events";
        }else if(topicType == 'pubs'){
        	var title = "Similar experts who have also published on"+" <i><b>"+topicName+"</b></i>";
        	var topicCount = "No. of publications";
        }
    	
		var ele=document.getElementById('events');
		var gridWidth=ele.clientWidth;
			$('#events').html('');
		    $('#events').html('<div class="gridWrapper"><div id="eventPage"></div><table id="eventsResultSet"></table><div>');
		    jQuery("#eventsResultSet").jqGrid({
				url:'<?php echo base_url();?>kols/list_KOLS_events/<?php echo $kol_id ?>/',
				datatype: "json",
				postData: {
		            "name": encodeURIComponent(topicName),"topicType": topicType
		        },
				colNames:['Id','','Name',topicCount,'Specialty','Location'],
			   	colModel:[
					{name:'kol_id',index:'kol_id', hidden:true, search:false, resizable:false,resizable:false},
					{name:'micro',width:20, search:false,align:'center'},
                                        {name:'kol_name',index:'kol_name',search:true,width:100},
                                        {name:'topic_count',index:'topic_count',search:true,width:80,align:'center'},
                                        {name:'specialty',index:'specialty',search:true,width:80},
                                        {name:'location',index:'location',search:true,width:80},
					
			   	],
			   	rowNum:10,
			   	multiselect: false,
			   	rownumbers: true,
			   	autowidth: false,
			   	width:550,
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#eventPage',
			   	mtype: "POST",
			   	sortname: 'date',
			    viewrecords: true,
			    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption: title,
			    gridComplete: function(){
					//Get array of id'f from jqgrid			   
			    	var arrIds = jQuery("#eventsResultSet").jqGrid('getDataIDs'); 
			    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
			    	var roleId = '<?php echo $this->session->userdata('user_role_id')?>';
			    	var role = '<?php echo ROLE_MANAGER ?>';
			    	for(var i=0;i < arrIds.length;i++){ 
				    	var id = arrIds[i];		    	
				    	//Edit and Delete labels 	
			    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
				    	var rowData = jQuery('#eventsResultSet').jqGrid ('getRowData', id);
//                                        alert(JSON.stringify(rowData.dAllowed));
				    	//Edit and Delete labels 
                                        var actionLink='';
//                                        alert(rowData.id+"-"+rowData.eAllowed);
				    	if((rowData.eAllowed =="true")){
//					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
//					    	jQuery("#eventsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
                                                actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editCoaching('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";
					    	
           
				    	}
                                        if((rowData.dAllowed == 'true')){
//					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
//					    	jQuery("#eventsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
                                                actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteCoaching('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                                        }   
    
//                                        if(roleId==role){
//				    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editCoaching('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteCoaching('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
			    		jQuery("#eventsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
//				    	}
			    		//Microview label	
				    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";
			    		microviewLink = "<label><div class=' tooltop-right microViewIcon' onclick=\"viewMicro('"+rowData.kol_id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Snapshot\">&nbsp;</a></div></label>";
				    	jQuery("#eventsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
				    	} 
			    	jQuery("#eventsResultSet").jqGrid('navGrid','hideCol',"id");
			    	//Initialize the tooltips
//			    	initializeCustomToolTips();

			    },
			    
				rowList:paginationValues
			});
		    jQuery("#eventsResultSet").jqGrid('navGrid','#eventPage',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#eventsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
			//Toggle Toolbar Search 
// 			jQuery("#eventsResultSet").jqGrid('navButtonAdd',"#eventPage",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search"});
		}


	$(document).ready(function(){
		list_events();
	});
    
</script> 
<div id="events" class="clear"></div>