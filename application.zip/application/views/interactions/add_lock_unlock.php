<?php
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket'
);
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
<style type="text/css">
	.locContainer{
		text-align: center;
	}
	.locContainer .caption{
		font-size: 12;
		font-weight: bold;
		padding: 0 10px;
	}
	.locContainer .eachFields{
		text-align: left;
		margin: 10px 20px;
	}
	.locContainer .locfields input[type="text"]{
		width: 395px;
	}
	.locContainer .locfields labels{
		text-align: right;
		vertical-align: top;
	}
	#lockUnlckForm .require{
		color: red;
	}
</style>
<script>
     var todayDate = "<?php echo date("m/d/Y");?>";
     
	var maxPastDate = new Date();
	maxPastDate.setMonth(maxPastDate.getMonth()-1);
	
	 jQuery.validator.addMethod("maxPastDateValidate",
             function (value, element, params) {
                 var curDate = maxPastDate;
                 curDate.setHours(00);
                 curDate.setMinutes(00);
                 curDate.setSeconds(00);
                 alert('hi');
                 var inputDate = new Date(value);
                 if(inputDate.toString() == curDate.toString())
                     return true;
                 if (inputDate >= curDate)
                     return true;
                 return false;
             }, 'Past Dates not allowed');
     $(document).ready(function () {

        $('#date_of_request').datepicker({
            changeMonth: true,
            changeYear: true,
		dateFormat: 'mm/dd/yy',
		maxDate:new Date(),
		minDate: maxPastDate
        });
        $('#date_of_request').val(todayDate);


    });
	var validationRules = {
            date_of_request:{
                 required: true 
            },
        description: {
            required: true
        }
    };
    var validationMessages = {
        date_of_request:{
                 required: "Please enter date" 
            },
        description: {
            required: "Please enter description"
        }
    };

    $("#lockUnlckForm").validate({
        debug: true,
        onkeyup: true,
        rules: validationRules,
        messages: validationMessages
    });
    
	function submitLockUnlock(){
		if (!$("#lockUnlckForm").validate().form()) {
	        return false;
	    }else{
//			alert("Success !!");
			process_unlock_interaction();
		}
	}
</script>
<div class="locContainer">
	<form action="" id="lockUnlckForm">
		<div class="caption">Unlock Interaction</div>
                <div class="eachFields">
			<div class="locfields">
				<label>Date of Request:<span class="require">*</span></label>
			</div>
                        <div class="locfields">
				<input type="text" name="date_of_request" id="date_of_request" class="required"></input>
			</div>
			
		</div>
		<div class="eachFields">
			<div class="locfields">
				<label>Ticket Id:</label>
			</div>
			<div class="locfields">
				<input type="text" name="ticket_id" id="ticketId"></input>
			</div>
		</div>
		<div class="eachFields">
			<div class="locfields">
				<label>Description:<span class="require">*</span></label>
			</div>
			<div class="locfields">
				<textarea name="description" id="description" rows="3" cols="15" class="required"></textarea>
			</div>
		</div>
		<div class="eachFields" style="text-align: center;">
			<div class="locfields">
				<input type="button" value="Submit" onclick="submitLockUnlock();"></input>
			</div>
		</div>
	</form>
</div>