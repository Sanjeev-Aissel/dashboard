<style type="text/css">
	.contactNumber, .faxNumber, .emailId{
		margin-top: 0px;
	}
	#emailHolder{
		display: inline !important;
	}
	.microView .microViewTbl{
		margin-top: 10px;
		margin-bottom: 0px;
		clear: both;
	}
	.microView .microViewTbl th{
		padding-right: 0px;
		padding-left: 0px;
	}
	.microView .microViewTbl span{
		text-align: center;
		background-color: #e3e3e3;
	}
	.microView .kolSpecialty{
		margin-top: 0px;
	}
	.suffix{
		vertical-align: sub;
		font-weight: normal;
		font-size: 10px;
	}
	p.kolName{
		color: #333333;
	    font-size: 13px;
	    font-weight: bold;
	}
	.microView table td{
		padding-top: 0px;
	}
	.microView .kolAddress{
		background-position:44% 26%;
	}
	/*
	#talkbubble {
		width: 120px;
		height: 80px;
		background: red;
		position: relative;
		-moz-border-radius: 10px;
		-webkit-border-radius: 10px;
		border-radius: 10px;
	}
	#talkbubble:before {
		content:"";
		position: absolute;
		right: 50%;
		top: 100%;
		width: 0;
		height: 0;
		border-left: 13px solid transparent;
		border-right: 13px solid red;
		border-bottom: 26px solid transparent;
	} 
	*/
</style>
<?php 
	if(!empty($arrKol['primary_phone']) && sizeof($arrKol['primary_phone'])>10){
		$arrKol['primary_phone']	= (($arrKol['primary_phone'][0]=="+")?'':'+').$arrKol['primary_phone'];
	}
	if(!empty($arrKol['fax']) && sizeof($arrKol['fax'])>10){
		$arrKol['fax']				= (($arrKol['fax'][0]=="+")?'':'+').$arrKol['fax'];
	}
	if($arrKol['gender']==''){
		$arrKol['gender']	= 'male';
	}
	if($arrKol['name'] != '' && $arrKol['org_status'] == 'Completed'){
		//$arrKol['name']	= '<a href="'.base_url().'organizations/view/'.$arrKol['org_id'].'">'.$arrKol['name'].'<a/>';
		$arrKol['name']	= $arrKol['name'];
	}
?>
<!-- Start of Micro View -->
<div id="kolMicroProfileContent">
	<!--<div id="talkbubble">Events</div>
	--><div class="microViewThumbnail">
		<?php 
			if($arrKol['profile_image'] != ''){
				echo '<img alt="Image" src="'. base_url(). 'images/kol_images/resized/'. $arrKol['profile_image'].'"/>';
			}else{?>
				<img width="100" height="100" src="<?php echo base_url();?>images/<?php echo strtolower($arrKol['gender']);?>_kol_profile.svg" alt="Image">
				<!-- div class="defaultProfileIcon <?php echo $arrKol['gender'];?>"></div-->
			<?php 
			}
			//if($type!='myCustomer' && $arrKol['status'] == COMPLETED){
				echo '<div class="view-link">';
					echo '<a class="blueButton" href="'.base_url().'kols/view/'.$arrKol['unique_id'].'" target="_new">View Profile</a>';
			//}else{ pr($arrKol);
				if($this->common_helpers->isActionAllowed('profile_request','edit',$arrKol)){
					if($showProfileRequestButton != 1){
						echo '<a rel="tooltip" onclick="addNewKolProfile('.$arrKol['id'].'); return false;" href="#" class="NewBlueButton requestProfileIcon" data-original-title="Submit new profile request" style="">Request</a>';
					}
				}
				echo '</div>';
			//}
		?>
	</div>
	<div>
<!--		<div><p class="kolName"><?php echo $arrSalutations[$arrKol['salutation']]." ".$arrKol['first_name'].' '.$arrKol['middle_name'].' '.$arrKol['last_name'].'<span class="suffix">('.$arrKol['suffix'].')</span>'?></p></div>-->
		<div><p class="kolName"><?php echo $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'<span class="suffix">('.str_replace(",", ", ", $arrKol['suffix']).')</span>'?></p></div>

		<table style="width:290px">
			<tr>
				<td><div><?php if($arrKol['specialty_name'] != ''){
					echo '<div class="kolSpecialty sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Specialty" style="cursor: default;">&nbsp;</a></div>'.$arrKol['specialty_name'].'<br/>'.implode(", ",$arrSubSpecialties);
				}?></div></td>
			</tr>
			<tr>
				<td><div><?php if($arrKol['title'] != ''){
					echo '<div class="kolDesignation sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Title/Department" style="cursor: default;">&nbsp;</a></div>'.$arrKol['title'];
					}?></div>
					<div><?php if($arrKol['division'] != ''){
						echo $arrKol['division'];
					}?></div>
				</td>
			</tr>
			<tr>
				<td><div><?php if($arrKol['name'] != ''){
					echo '<div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Institution Name" style="cursor: default;">&nbsp;</a></div><a href="'.base_url().'organizations/view/'.$arrKol['org_id'].'">'.$arrKol['name'].'</a>';
				}
                                else{
                                    echo '<div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Institution Name" style="cursor: default;">&nbsp;</a></div><a href="'.base_url().'organizations/view/'.$arrKol['org_id'].'">'.$arrKol['private_practice'].'</a>';
                                }?></div></td>
			</tr>
		</table>
	</div>
	<!--<div class="clear">&nbsp;</div>	-->
	<table class="microViewTbl">
		<tr>
			<td colspan="4">
				<div class="kolAddress sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" title="Address" style="cursor: default;">&nbsp;</a></div>
				<?php
					if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
						echo $arrKol['address1'].", ";
					if(!empty($arrKol['address2']) && isset($arrKol['address2']))
						echo $arrKol['address2'].", ";
					if(!empty($arrKol['city']) && isset($arrKol['city']))
						echo $arrKol['city'].", ";
					if(!empty($arrKol['state']) && isset($arrKol['state'])){
						if($arrKol['country']=='United States')
							echo $arrKol['state_code']." ";
						else
							echo $arrKol['state']." ";
					}
					if((!empty($arrKol['postal_code']) && isset($arrKol['postal_code'])))
						echo " ".$arrKol['postal_code'].", ";
					if(!empty($arrKol['country']) && isset($arrKol['country']))
						echo $arrKol['country']." ";
				?>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<div class="sprite_iconSet contactNumber"><a href="#" class="tooltipLink" rel='tooltip' title="Phone No." style="cursor: default;">&nbsp;</a></div>
				<?php if($arrKol['primary_phone']!=''){
					 echo '<a class="linkClickToCall" href="callto:'.$arrKol['primary_phone'].'" >'.$arrKol['primary_phone'].'</a>';
				}?>
			</td>
			<td colspan="2">
				<div class="sprite_iconSet faxNumber"><a href="#" class="tooltipLink" rel='tooltip' title="Fax No." style="cursor: default;">&nbsp;</a></div>
				<?php if($arrKol['fax']!=''){
					echo '<a class="linkClickToCall" href="callto:'.$arrKol['fax'].'" >'.$arrKol['fax'].'</a>';
				}?>
			</td>
		</tr>
		<tr>
			<td colspan="4">
				<div class="sprite_iconSet emailId"><a href="#" class="tooltipLink" rel='tooltip' title="Email ID" style="cursor: default;">&nbsp;</a></div><a id="emailHolder" href="mailto:<?php echo $arrKol['primary_email'];?>" ><?php echo $arrKol['primary_email'];?></a>
			</td>
		</tr>
		<?php if($type==null){?>
			<tr>
				<th><span class="addrHeading">Affiliations</span></th>
				<th><span class="addrHeading">Events</span></th>
				<th><span class="addrHeading">Publications</span></th>
 				<?php if(HIDE_CLINICAL_TRIALS){?><th><span class="addrHeading">Trials</span></th> <?php }?>
			</tr>
			<tr>
				<td class="alignCenter"><?php echo $noOfAffilitions;?></td>
				<td class="alignCenter"><?php echo $noOfEvents;?></td>
				<td class="alignCenter"><?php echo $noOfPublications;?></td>
				  <?php if(HIDE_CLINICAL_TRIALS){?><td class="alignCenter"><?php echo $noOfTrials;?></td><?php }?>
			</tr>
		<?php }?>
	</table>
</div>
<!--  End of Micro View -->
