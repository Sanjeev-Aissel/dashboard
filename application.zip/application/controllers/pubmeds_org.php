<?php
/**
*Controller for organization pubmed operations
*@author Ramesh B
*@since Otsuka 1.0.11
*@package application.controllers	
*@created on 30-03-2013
*/

class Pubmeds_org extends Controller{

	var $maxScriptTime		= 86400;
	var $logFileName		= '';
	var $startTime			= '';
	var $logFile			= '';
	var $logText			= '';
	var $pmidBatchSize		= 10;
	var $sleepTime			= 2;
	var $safeTime			= 10;
	var $logLastPmidFile 	= '';
	
	var $logFileNamePmidSkipped		= '';
	var $logFilePmidSkipped			= '';
	var $observerEmailId	= ANALYST_EMAIL_ID;
	
	//Constructore
	function Pubmeds_org(){
		parent::Controller();
		$this->load->model('pubmed_org');
		$this->load->model('pubmed');
		$this->load->model('organization');
		$this->logFilePath	= $this->config->item('app_folder_path').'system/logs/pubmed';
		
		$observerEmail =  $this->input->post("observer_email");
		if($observerEmail != null && $observerEmail != '')
			$this->observerEmailId = $observerEmail;
		if($this->session->userdata('logged_in') == 1)
			$this->observerEmailId = $this->session->userdata('email');
	}
	
	/**
	 * Display the page to Add Publications manually
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return HTML
	 * @created on 30-03-2013
	 */
	function add_publication($orgId){
		$arrPublicationDetails = array(	'id'                =>	'',
										'journal_name'		=>	'',
										'article_title'		=>	'',
										'created_date'	 	=> 	'',
										'abstract_text'		=> 	'',
										'link'	 			=> 	'');
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id'] = '';
		$arrPublicationDetails['no_of_authors'] = 1;
		
		$data['publication']=$arrPublicationDetails;
		$data['arrAuthors']=$manualAuthor;
		$data['orgId'] = $orgId;
		$this->load->view('organizations/add_publications',$data);
	}
	
	/**
	 * Display the page to Add Publications manually
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return HTML
	 * @created on 30-03-2013
	 */
	function add_client_publication($orgId){
		$arrPublicationDetails = array(	'id'                =>	'',
										'journal_name'		=>	'',
										'article_title'		=>	'',
										'created_date'	 	=> 	'',
										'abstract_text'		=> 	'',
										'link'	 			=> 	'');
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id'] = '';
		$arrPublicationDetails['no_of_authors'] = 1;
		
		$data['publication']=$arrPublicationDetails;
		$data['arrAuthors']=$manualAuthor;
		$data['orgId'] = $orgId;
		$this->load->view('organizations/add_publications',$data);
	}
	
	/**
	 * Saves the Manual Publication Detail to DB 
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return HTML
	 * @created on 30-03-2013
	 */
	function save_publication_manual(){
		// Getting the POST details of Publication
		$arrPublicationDetails = array(	
										'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
										'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
										'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
										'link'	 			=> 	$this->input->post('link'));
		
		//Save journal name
		$journalName = ucwords(trim($this->input->post('journal_name')));
		if($journalName != ''){
			$arrPublicationDetails['journal_id'] = 	$this->pubmed->savejournalName($journalName);
		}
		
		$orgId			=	$this->input->post('org_id');	
		//Generate Pmid manually 
		$arrPublicationDetails['pmid']= $this->pubmed->getManualPmid();
		$arrPublicationDetails['is_manual']= 1;
		//Save Publication data
		$pubId=$this->pubmed_org->savePublicationsManualAndFlags($arrPublicationDetails , $orgId);
		$this->update->insertUpdateEntry(ORG_PUBLICATION_ADD,$pubId, MODULE_ORG_PUBLICATION, $orgId);
		//pr($pubId);
		$isSaved = false;
		if($pubId){
			$isSaved  = true;
		}
		
		//For Authors
		$lastName  =	ucwords(trim($this->input->post('last_name')));
		$foreName  =	ucwords(trim($this->input->post('fore_name')));
		$initials  =	ucwords(trim($this->input->post('initials')));
		
		//parse and save 'publication-authors'
		$firstAuthor = array();
		if($lastName != '' || $foreName !='' || $initials !=''){
			$firstAuthor = $this->parse_authors_manually($lastName,$foreName,$initials);
		}
		$arrAuthors = array();
		$secondAuthors = array();
		$arrSecondAuthors = array();
		$i=2;
		$noOfAuthors=$this->input->post('no_of_authors');
		for($i=2;$i<=$noOfAuthors;$i++){
			$lastName  =	ucwords(trim($this->input->post('last_name'.$i)));
			$foreName  =	ucwords(trim($this->input->post('fore_name'.$i)));
			$initials  =	ucwords(trim($this->input->post('initials'.$i)));
			
			//parse and save 'publication-authors'
			if($lastName != '' || $foreName !='' || $initials !=''){
				$secondAuthors = $this->parse_authors_manually($lastName,$foreName,$initials);
				$arrSecondAuthors[] = $secondAuthors;
			}
		}
		foreach ($firstAuthor as $author){
			$arrAuthors[] = $author;
		}
		foreach ($arrSecondAuthors as $arrSecondAuthor){
			foreach ($arrSecondAuthor as $author){
				$arrAuthors[] = $author;
			}
		}
		//Save array of Authors
		if(sizeof($arrAuthors)>=1){
			$this->save_pub_authors($arrAuthors, $pubId);
		}
		//Calculate Authorship position and save
		//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,null);
		//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $pubId;
			$arrResult['msg']			= "Successfully saved the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		
		//	echo json_encode($arrResult);
		$currentMethod	= $this->input->post('methodName');
		
		if($currentMethod == 'add_client_publication'){
			//For client appplication
			redirect('organizations/view_publications/'.$orgId);
		}else{
			//For analyst appplication
			//Ajax Saving is Done But Listing is not hapening automatically
			//Currently Redircting to Ajax tab 
			//redirect('kols/edit_kol/'.$this->session->userdata('kolId').'#ui-tabs-5');
			$isClientView = false;
			redirect('organizations/edit_organization/'.$orgId.'/publications/');
		}
	}
	
	/**
	 * Updates the Manual Publication Detail to DB 
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return HTML
	 * @created on 30-03-2013
	 */
	function update_publication_manual(){
		
		// Getting the POST details of Publication
		$arrPublicationDetails = array(	'id'                =>	$this->input->post('id'),
										'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
										'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
										'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
										'link'	 			=> 	$this->input->post('link'));
			
		// Create an array to return the result
		$arrResult = array();
		$orgId			=	$this->input->post('org_id');	
		
		$isSaved=$this->pubmed->updatePublicationManual($arrPublicationDetails);
		$this->update->insertUpdateEntry(ORG_PUBLICATION_UPDATE, $arrPublicationDetails['id'], MODULE_ORG_PUBLICATION, $orgId);
		//Get journal name
		$arrPublicationDetails['journal_name'] = ucwords(trim($this->input->post('journal_name')));
		//get Author name
		$arrPublicationDetails['last_name']  =	ucwords(trim($this->input->post('last_name')));
		$arrPublicationDetails['fore_name']  =	ucwords(trim($this->input->post('fore_name')));
		$arrPublicationDetails['initials']   =	ucwords(trim($this->input->post('initials')));
		$arrPublicationDetails['authId']	 = 	$this->input->post('authId');
		
		//update journal 
		$isSaved = 	$this->pubmed->updatePublicationJournalManual($arrPublicationDetails);
		
		//update Authors
		if($arrPublicationDetails['authId'] !=''){
			$isSaved = 	$this->pubmed->updatePublicationAuthorsManual($arrPublicationDetails);
		}
		$i=2;
		$noOfAuthors=$this->input->post('no_of_authors');
		for($i=2;$i<=$noOfAuthors;$i++){
			$arrAuthDetails['id']           = 	$arrPublicationDetails['id'];
			$arrAuthDetails['last_name'] 	=	ucwords(trim($this->input->post('last_name'.$i)));
			$arrAuthDetails['fore_name'] 	=	ucwords(trim($this->input->post('fore_name'.$i)));
			$arrAuthDetails['initials']		=	ucwords(trim($this->input->post('initials'.$i)));
			$arrAuthDetails['authId']	   	= 	$this->input->post('authId'.$i);
			
			if($arrAuthDetails['authId'] !=''){
				//update Authors
				$isSaved = 	$this->pubmed->updatePublicationAuthorsManual($arrAuthDetails);
			}
		}
		
		//Calculate Authorship position and save
		$pubId = $arrPublicationDetails['id'];
		//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,null);
		//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $arrPublicationDetails['id'];
			$arrResult['msg']			= "Successfully Updated the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Updating";
		}
		//echo json_encode($arrResult);
		$isClientView = false;
		
		$currentMethod	= $this->input->post('methodName');
		//echo $currentMethod;
		if($currentMethod == 'edit_publication_manual'){
			//For client appplication
			redirect('organizations/view_publications/'.$orgId);
		}else{
			redirect('organizations/edit_organization/'.$orgId.'/publications/');
		}
	}
	
	/**
	 * Populates the $pubId Data to the Manual form
	 * @param $pubId, $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return HTML
	 * @created on 30-03-2013
	 */
	function edit_publication_manual($pubId,$orgId){
		$data['orgId'] = $orgId;
	
		$publication=$this->pubmed->getPublicationDetail($pubId);
		
		$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
		$publication['created_date']=sql_date_to_app_date($publication['created_date']);
		$arrAuthors =$this->pubmed->listPublicationAuthors($pubId);
		$manualAuthor = array();
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id']='';
		$i=0;
		foreach ($arrAuthors as $author){
			$i++;
			if($i == 2)
				break;
			$manualAuthor = $author;
		}
		$publication['no_of_authors'] = (sizeof($arrAuthors) !=0) ? sizeof($arrAuthors):1;
		$data['publication']=$publication;
		$data['arrAuthors']=$manualAuthor;
		$data['arrMultipleAuthors']=$arrAuthors;
		$this->load->view('organizations/add_publications',$data);
	}
	
	/**
	 * Retrives all the publications fro given kolid and the type
	 * @param $type, $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return JSON
	 * @created on 30-03-2013
	 */
	function list_publication_details_analyst($type,$orgId){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPublications 	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed_org->listPublicationDetailsForAnalyst($orgId,$type)){			
			foreach($arrPublicationsResults as $arrPublicationsResult){
				$arrPublication['id']			= $arrPublicationsResult['asoc_id'];
				$arrPublication['pub_id']		= $arrPublicationsResult['id'];
				$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
				//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
					$arrPublication['pmid']		= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				else
					$arrPublication['pmid']		= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
				$arrPublication['journal_name']	= $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
				//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
				$arrPublication['article_title']= '<a target="_new" href=\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'>'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
				$arrPublication['date']			= $arrPublicationsResult['created_date'];
				$arrPublication['authors']		= $this->get_pub_authors($arrPublicationsResult['id']);
				//$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
				//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$orgId,null);
				$arrPublication['subject']		= '';
				$arrPublications[]				= $arrPublication;
			}
			$count				= sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages 	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPublications;  
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/**
	 * Retrives publication authors for given pubid
	 * @param  $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function get_pub_authors($pubId){		
		$authNames='';
		$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
		foreach($arrAuthors as $author){
			$authName=$author['last_name']." ".$author['initials'];
			if($authNames==''){
				$authNames=$authName;
			} else{
			$authNames=$authNames.",".$authName;
			}
		}		
		return $authNames;	
	}
	
	
	/**
	 * Updates the given publication as deleted for the given organizaion id
	 * @param  $id
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function delete_publication($id){		
		$orgId	=	$this->input->post('org_id');	
		$isDeleted=$this->pubmed_org->updatePublicationAsDeleted($id);
		//$this->update->deleteUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $id, MODULE_KOL_PUBLICATION);
		return true;
	}
	
	/**
	 * Updates the given publications as deleted for the given organizaion id
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function delete_publications(){
		$selectedRows =$this->input->post('pub_id');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){			
			$isDeleted=$this->pubmed_org->updatePublicationAsDeleted($id);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_DELETE, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		return true;
	}
	
	/**
	 * Updates the given publications as verified for the given organizaion id
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgPublication=array();			
			$orgPublication['is_verified']=1;
			$orgPublication['is_deleted']=0;
			$isDeleted=$this->pubmed_org->updatePublicationAsVerified($id,$orgPublication);
			$this->update->insertUpdateEntry(ORG_PUBLICATION_VERIFY, $id, MODULE_ORG_PUBLICATION, $orgId);			
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Updates the given publications as unverified for the given organizaion id
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function un_verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		//pr($selectedRows);
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgPublication=array();			
			$orgPublication['is_verified']=0;
			$orgPublication['is_deleted']=0;
			$isDeleted=$this->pubmed_org->updatePublicationAsVerified($id,$orgPublication);
			$this->update->insertUpdateEntry(ORG_PUBLICATION_UNVERIFY, $id, MODULE_ORG_PUBLICATION, $orgId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	
	/**
	 * Publications parsing from pubmed script for organizations
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function process_pubmeds($indvisOrgId = null){
		//Analyst App to be accessed by only Aissel users. 
		//$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;	
		// Open the LogFile to write		
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "------------------------------Processing Started on: " . date("d-m-Y H:i:s") . "------------------------------------\r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
 		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
		
		$this->logFileNamePmidSkipped	=$this->logFilePath . "/skipped/" . "pmids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
		
		ini_set("max_execution_time",$this->maxScriptTime);
		//$this->maxScriptTime = ini_get("max_execution_time");

		//Process the last crawled PMID
		$lastPmid = file_get_contents($this->logFilePath . "/last_pmid.txt");
		if(isset($lastPmid) && $lastPmid != '') {
			echo "Processing last PMID : ".$lastPmid."<br>";
			flush(); 
			$this->logText	= "Processing last PMID : ".$lastPmid."\r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_id' => $lastPmid,
					'transaction_name'=>'Processing last PMID'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$this->recrawl_pmid($lastPmid);
		}
		//$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
		
		$this->logText	= "Processing Organizations with status Recrawl..  \r\n";
		fwrite($this->logFile, $this->logText);
		$this->processPubmedRecrawlOrgs();
		$this->logText	= "Recrawl Status Organizations processing completed..  \r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Processing Organizations with status Recrawl'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
		
		//get the PubmedUnprocessed org's
		if($indvisOrgId != null)
			$arrOrgDetails[] = $this->organization->editOrganization($indvisOrgId);
		else
			$arrOrgDetails=$this->pubmed_org->getPubmedUnprocessedOrgs();
		if(sizeof($arrOrgDetails)<1){
			$this->logText	= "There are No Unprocessed Organization ids, Terminating Process..  \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Get the PubmedUnprocessed Orgs'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$this->send_status_mail($this->logText);
			die("Sorry! There are No Unprocessed Organization ids, Terminating Process..");
		}
		$this->logText	= "Following are the Unprocessed Organization ids  \r\n";		
		fwrite($this->logFile, $this->logText);
		foreach($arrOrgDetails as $arrOrgDetail){
			$this->logText	= $arrOrgDetail['id']."  \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Following are the Unprocessed Organization ids'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
		}		
		$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
		fwrite($this->logFile, $this->logText);	
		//Start of loop trought each organization, generate name combinations, gather PMID's, get publications, parse and save data			
		foreach($arrOrgDetails as $arrOrgDetail){
			$orgStartTime=microtime(true);			
			$this->logText	= "\r\nStarting pubmed processing for OrgId ".$arrOrgDetail['id']." \r\n";
			fwrite($this->logFile, $this->logText);		
			
			$orgId=$arrOrgDetail['id'];
			$arrNameCombinations = $this->pubmed_org->getOrgNameCombinations($orgId);
			$arrNameCombinations[]=$arrOrgDetail['name'];
			
			$this->logText	= "Org Name: ".$arrOrgDetail['name']."  \r\n";
			fwrite($this->logFile, $this->logText);
			
			$this->logText	= "Following are the Name combinations genarated  \r\n";
			fwrite($this->logFile, $this->logText);
			foreach($arrNameCombinations as $nameCombination){
				$this->logText	= $nameCombination."  \r\n";
				fwrite($this->logFile, $this->logText);
			}		
			
			
			//Get the list of PubMed ID's for given organizaton name
			$this->logText	= "\r\nStarting getting pmid's  \r\n";
			fwrite($this->logFile, $this->logText);
			$arrPMIDs=array();
			$gathPMIDTime=microtime(true);
			$yearRange = "(2011[Date - Publication] %3A 3000[Date - Publication])";
				foreach($arrNameCombinations as $orgName){
					//Notes about url
					//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results			
					//$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=3000&usehistory=y&retmode=xml&term=(".str_replace(" ", "%20", $orgName)."[affiliation]) AND ".$yearRange;
					//Documentation link http://www.ncbi.nlm.nih.gov/books/NBK25499/
					//http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&reldate=100&datetype=pdat&retmax=100&usehistory=y&term=Advocate%20Christ%20Medical%20Center%20[affiliation]
					//$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&reldate=356&datetype=pdat&retmax=3000&usehistory=y&term=".str_replace(" ", "%20", $orgName)."[affiliation";
					$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&mindate=2011/01/01&maxdate=2050/12/31&datetype=pdat&retmax=5000&usehistory=y&term=".str_replace(" ", "%20", $orgName)."[affiliation";
		
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
				
					$this->logText	= "Url Created ".$url."\r\n";
					fwrite($this->logFile, $this->logText);					
									
					$xml = new DOMDocument();
					
					if(!$xml->loadXML($response['response'])){
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);	
						
						$response = $this ->retrieve_page_get($url);
						//Try once again if the response of the status is false	
						if($response['status'] == false){
							//give 2 second delay
							sleep($this->sleepTime);
							$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
							//Log Activity
							$arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true);
							fwrite($this->logFile, $this->logText);
							//try once again
							$response = $this ->retrieve_page_get($url);
						}
						// Skipp this and log the details if still respons is false
						if($response['status'] == false){
							//log the details
							$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
							//Log Activity
							$arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true);
							fwrite($this->logFile, $this->logText);
							
							$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
							fwrite($this->logFilePmidSkipped, $this->logText);
							//continue to next step
							continue;
						}
						
						if(!$xml->loadXML($response['response'])){
							//log the details and continue
							$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
							//Log Activity
							$arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true);
							fwrite($this->logFile, $this->logText);	
							
							$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
							fwrite($this->logFilePmidSkipped, $this->logText);
							continue;
							//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						}										
					}
					
					$idListObj = $xml->getElementsByTagName('IdList')->item(0);
					$idList=$idListObj->getElementsByTagName('Id');
					foreach($idList as $idObj){
						$arrPMIDs[]=$idObj->nodeValue;
					}	
			}			
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			$timeTaken=microtime(true)-$gathPMIDTime;
			$this->logText	= "Time taken to gather PMIDs: ".(microtime(true)-$gathPMIDTime)."\r\n";
			fwrite($this->logFile, $this->logText);
										
			$arrUniquePMIDs = array_unique($arrPMIDs);	
			$arrUniquePMIDs=array_values($arrUniquePMIDs);	
			$this->logText	= "\r\nTotal No of PMIDs found after removing duplicates: ".sizeof($arrUniquePMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);					
			//End of getting the PubMed ID's
			
			// Reconnect the Database, to ensure that the DB connection is alive
	        // On Jan 26, 2012, we faced an issue where the Publications were not getting crawled
	        // MySQL idel timeout is 15-20 seconds
	        $this->db->close();
	        $this->db->initialize();
			//Check for already existing publication's and associate them with org
			$arrFilteredPMIDs=$this->pubmed_org->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $orgId,$arrOrgDetail);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);

				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}

				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Restarting the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						$this->send_status_mail($this->logText);
						redirect(base_url()."pubmeds_org/process_pubmeds");										
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $orgId);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
					//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsjing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully</br>";
			$arrOrgDetail['is_pubmed_processed']=1;
			$this->pubmed_org->updatePubmedProcessedOrg($arrOrgDetail);	
			$this->logText	= "Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Pubmed Processing',
					'miscellaneous1'=>$url
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$orgStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			/*$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($orgId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);*/
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			$this->send_status_mail("Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully ");
			
		}		
		$this->send_status_mail("Pubmed Processing Ended..");
		// End of loop trought each org	
	}	
	
	
	/**
	 * Parses the publication details from XML Object and returns publication details in an array
	 * @param $publication, XML Object
	 * @return Array
	 */	
	/**
	 * Parses the publication details from XML Object and returns publication details in an array
	 * @param $publication, XML Object
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_details($publication){
		$pubDetails=array();
		
		$pmid='';
		$pmIdVersion='';
		$dateCreated=array();
		$dateCompleted=array();
		$dateRevised=array();
		$pubModel='NA';
		$issnNumber='NA';
		$issnType='NA';
		$citedMedium='NA';
		$volume='NA';
		$pubDate=array();
		$journalName='';
		$isoAbbreviation='NA';
		$articleTitle='NA';
		$abstractText='NA';
		$pagination='NA';
		$affiliation='NA';
		$authListComplete='';
		$language='NA';
		$articleDate=array();
		$citationSubset='NA';
		$numberOfReferences='NA';
		$otherID='';
		$status='NA';		
		$link='';
		$isDeleted=0;		
		
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
	
		//$journalName=$medlineCitation->getElementsByTagName('Title')->item(0)->nodeValue;		
		//$articleName=$medlineCitation->getElementsByTagName('ArticleTitle')->item(0)->nodeValue;	
		$pmidObj=$medlineCitation->getElementsByTagName('PMID')->item(0);
		if($pmidObj!=null){
		$pmid=$pmidObj->nodeValue;
		if($pmidObj->hasAttributes()){			
			$pmIdVersion=$pmidObj->attributes->item(0)->value;
			}	
		}
		
		//get the date created
		
		$dateCreatedObj=$medlineCitation->getElementsByTagName('DateCreated')->item(0);	
		if($dateCreatedObj!=null){
			$dateCreated['day']=$dateCreatedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCreated['month']=$dateCreatedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCreated['year']=$dateCreatedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date completed
		
		$dateCompletedObj=$medlineCitation->getElementsByTagName('DateCompleted')->item(0);	
		if($dateCompletedObj!=null){
			$dateCompleted['day']=$dateCompletedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCompleted['month']=$dateCompletedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCompleted['year']=$dateCompletedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date revised
		
		$dateRevisedObj=$medlineCitation->getElementsByTagName('DateRevised')->item(0);	
		if($dateRevisedObj!=null){
			$dateRevised['day']=$dateRevisedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateRevised['month']=$dateRevisedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateRevised['year']=$dateRevisedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		
		// Start Parsing article related data
		$articleObj=$medlineCitation->getElementsByTagName('Article')->item(0);
		if($articleObj!=null){
			if($articleObj->hasAttributes()){			
				$pubModel=$articleObj->attributes->item(0)->value;
				}
			$issnObj=$articleObj->getElementsByTagName('ISSN')->item(0);	
			if($issnObj!=null){	
			$issnNumber=$issnObj->nodeValue;
			if($issnObj->hasAttributes()){			
				$issnType=$issnObj->attributes->item(0)->value;
				}
			}
			$journalIssueObj=$articleObj->getElementsByTagName('JournalIssue')->item(0);
			if($journalIssueObj!=null){
				if($journalIssueObj->hasAttributes()){			
					$citedMedium=$journalIssueObj->attributes->item(0)->value;
					//echo " citedMedium:".$citedMedium;   		 
					}
				$volumeObj=$journalIssueObj->getElementsByTagName('Volume')->item(0);
				if($volumeObj!=null)
					$volume=$volumeObj->nodeValue;
				//get the PubDate
				
				$pubDateObj=$journalIssueObj->getElementsByTagName('PubDate')->item(0);
				if($pubDateObj!=null){
					$dayObj=$pubDateObj->getElementsByTagName('Day')->item(0);
					$pubDate['day']='';
					if($dayObj!=null)
						$pubDate['day']=$dayObj->nodeValue;
					$monthObj=$pubDateObj->getElementsByTagName('Month')->item(0);
					$pubDate['month']='';
					if($monthObj!=null)
						$pubDate['month']=$monthObj->nodeValue;
					$yearObj=$pubDateObj->getElementsByTagName('Year')->item(0);
					$pubDate['year']='';
					if($yearObj!=null)
						$pubDate['year']=$yearObj->nodeValue;
				}
			}			
			$journalNameObj=$articleObj->getElementsByTagName('Title')->item(0);
			if($journalNameObj!=null)
				$journalName=$journalNameObj->nodeValue;
			$isoAbbreviationObj=$articleObj->getElementsByTagName('ISOAbbreviation')->item(0);
			if($isoAbbreviationObj!=null)
				$isoAbbreviation=$isoAbbreviationObj->nodeValue;
			$articleTitleObj=$articleObj->getElementsByTagName('ArticleTitle')->item(0);
			if($articleTitleObj!=null)
				$articleTitle=$articleTitleObj->nodeValue;			
			//get the Abstract text
			$abstractTextObj=$articleObj->getElementsByTagName('AbstractText')->item(0);
			if($abstractTextObj!=null)
				$abstractText=$abstractTextObj->nodeValue;					
			$paginationObj=$articleObj->getElementsByTagName('MedlinePgn')->item(0);
			if($paginationObj!=null)
				$pagination=$paginationObj->nodeValue;					
			$affiliationObj=$articleObj->getElementsByTagName('Affiliation')->item(0);
			if($affiliationObj!=null)
				$affiliation=$affiliationObj->nodeValue;				
			$authorListObj=$articleObj->getElementsByTagName('AuthorList')->item(0);
			if($authorListObj1=null){
				if($authorListObj->hasAttributes()){			
					$authListComplete=$authorListObj->attributes->item(0)->value;
					//echo $authListComplete;   		 
				}
			}
			$languageObj=$articleObj->getElementsByTagName('Language')->item(0);
			if($languageObj!=null)
				$language=$languageObj->nodeValue;	

			$articleDateObj=$articleObj->getElementsByTagName('ArticleDate')->item(0);
			if($articleDateObj!=null){
					$dayObj=$articleDateObj->getElementsByTagName('Day')->item(0);
					$articleDate['day']='';
					if($dayObj!=null)
						$articleDate['day']=$dayObj->nodeValue;
					$monthObj=$articleDateObj->getElementsByTagName('Month')->item(0);
					$articleDate['month']='';
					if($monthObj!=null)
						$articleDate['month']=$monthObj->nodeValue;
					$yearObj=$articleDateObj->getElementsByTagName('Year')->item(0);
					$articleDate['year']='';
					if($yearObj!=null)
						$articleDate['year']=$yearObj->nodeValue;
			}
		}
		// End Parsing article related data
		$citationSubsetObj=$articleObj->getElementsByTagName('CitationSubset')->item(0);
			if($citationSubsetObj!=null)
				$citationSubset=$citationSubsetObj->nodeValue;
		$numberOfReferencesObj=$articleObj->getElementsByTagName('NumberOfReferences')->item(0);
			if($numberOfReferencesObj!=null)
				$numberOfReferences=$numberOfReferencesObj->nodeValue;	
		$otherIDObj=$articleObj->getElementsByTagName('OtherID')->item(0);
			if($otherIDObj!=null)
				$otherID=$otherIDObj->nodeValue;			
		$link="http://www.ncbi.nlm.nih.gov/pubmed/".$pmid;
		$statusObj=$articleObj->getElementsByTagName('PublicationStatus')->item(0);
			if($statusObj!=null)
				$status=$statusObj->nodeValue;		
		
		//Prepare array represinting Publication details	
		$pubDetails['pmid']=$pmid;
		//echo "</br>PMID: ".$pmid."</br>";
		$pubDetails['pmid_version']=$pmIdVersion;
		$pubDetails['created_date']=$this->array_to_date($dateCreated);
		$pubDetails['completed_date']=$this->array_to_date($dateCompleted);
		$pubDetails['revised_date']=$this->array_to_date($dateRevised);
		$pubDetails['pub_model']=$pubModel;
		$pubDetails['issn_number']=$issnNumber;
		$pubDetails['issn_type']=$issnType;
		$pubDetails['cited_medium']=$citedMedium;
		$pubDetails['volume']=$volume;
		//save the JournalName and get it's id
		//echo "</br>Journal Name: ".$journalName."</br>";
		$pubDetails['journal_id']=$this->pubmed->savejournalName($journalName);
		$pubDetails['iso_abbreviation']=$isoAbbreviation;
		$pubDetails['pub_date']=$this->array_to_date($pubDate);
		$pubDetails['article_title']=$articleTitle;
		$pubDetails['abstract_text']=$abstractText;
		$pubDetails['pagination']=$pagination;
		$pubDetails['affiliation']=$affiliation;
		$pubDetails['auth_list_complete']=$authListComplete;
		$pubDetails['language']=$language;
		$pubDetails['article_date']=$this->array_to_date($articleDate);
		$pubDetails['citation_subset']=$citationSubset;
		$pubDetails['Num_of_references']=$numberOfReferences;
		$pubDetails['other_id']=$otherID;
		$pubDetails['status']=$status;
		$pubDetails['link']=$link;		
		$pubDetails['is_deleted']=$isDeleted;	
		//End of preparing array 
		
		return $pubDetails;
	}
	
	/**
	 * Saves the Publication and returns the id of it
	 * @param Array $pubDetails
	 * @param Integer $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Integer
	 * @created on 30-03-2013
	 */
	function save_publications($pubDetails, $orgId, $isVerified = 0){					
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to OrgId :'.$orgId.'</br>';		
		//prepare the org-to-publication association object
		$orgPublication=array();
		$orgPublication['org_id']=$orgId;
		$orgPublication['pub_id']=$pubId;
		$orgPublication['is_deleted']=0;	
		$orgPublication['is_verified']= $isVerified;
										
		//save the org-to-publication record
		$isSaved=$this->pubmed_org->saveOrgPublication($orgPublication);
		//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $pubId, MODULE_KOL_PUBLICATION, $orgId);
		//return the publication Id	
		return $pubId;
	}
	
	
	/**
	 * Parses the publication Authors details from XML Object and returns Authors details in an array
	 * @param XML Object $publication
	 * @param Integer $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_authors($publication){		
		$arrAuthors=array();	
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$authors=$medlineCitation->getElementsByTagName('Author');
		if($authors!=null){
			foreach($authors as $authorObj){
				if($authorObj!=null){
					$author=array();
					$lastName='Not Available';
					$foreName='Not Available';
					$initials='Not Available';
					$suffix='Not Available';
					$is_name_valid='';
					
					$lastNameObj=$authorObj->getElementsByTagName('LastName')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$foreNameObj=$authorObj->getElementsByTagName('ForeName')->item(0);
					if($foreNameObj!=null)
						$foreName=$foreNameObj->nodeValue;
					$initialsObj=$authorObj->getElementsByTagName('Initials')->item(0);
					if($initialsObj!=null)
						$initials=$initialsObj->nodeValue;
					$suffixObj=$authorObj->getElementsByTagName('Suffix')->item(0);
					if($suffixObj!=null)
						$suffix=$suffixObj->nodeValue;
					if($authorObj->hasAttributes()){			
						$is_name_valid=$authorObj->attributes->item(0)->value;
					}
					$author['last_name']=$lastName;
					$author['fore_name']=$foreName;
					$author['initials']=$initials;
					$author['suffix']=$suffix;
					$author['is_name_valid']=$is_name_valid;
					$arrAuthors[]=$author;	
				}	
			}	
		}
		return $arrAuthors;
	}
	
	/**
	 * Saves the array of authers one by one
	 * @param Array $arrAuthors
	 * @param Integer $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_authors($arrAuthors, $pubId){
		$position=1;
		//Insert batch of authors,  i.e bulk insert
		//$this->db->insert_batch('pubmed_authors', $arrAuthors);
		$query= array(); 
		foreach( $arrAuthors as $row ) {
		    $query[] = '("'.mysql_real_escape_string($row['last_name']).'", "'.$row['fore_name'].'", "'.$row['initials'].'", "'.$row['suffix'].'", "'.$row['is_name_valid'].'")';
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_authors");
			$result = $result->first_row();
			$authId=$result->id;
			$authId = $authId - (sizeof($arrAuthors)-1);
			$arrPubAuthors = array();
			foreach($arrAuthors as $author){
				$pubAuthor = array();			
				$pubAuthor['pub_id']=$pubId;
				$pubAuthor['author_id']=$authId;
				$pubAuthor['position']=$position;
				$pubAuthor['alias_id']=$authId;
				$position++;
				$authId++;
				$arrPubAuthors[] = $pubAuthor;
			}
	
			//Insert batch of  pub authors,  i.e bulk insert
			//$this->db->insert_batch('publications_authors', $arrPubAuthors);
			$query= array(); 
			foreach( $arrPubAuthors as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['author_id'].', '.$row['position'].', '.$row['alias_id'].')';
			}
			$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES '.implode(',', $query));
			
		}
	}
	
	/**
	 * Parses the publication MeshTerms  from XML Object and returns MeshTerms in an array
	 * @param XML Object $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_meshterms($publication){
		$arrMeshTerms=array();	
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0); 
		$meshTerms=$medlineCitation->getElementsByTagName('MeshHeading'); 
		foreach($meshTerms as $meshTermObj){
			if($meshTermObj!=null){
				$meshTerm=array();
				$discriptNameObj=$meshTermObj->getElementsByTagName('DescriptorName')->item(0);
				if($discriptNameObj!=null){
					$discriptName=$discriptNameObj->nodeValue;
					if($discriptNameObj->hasAttributes()){			
						$isMajor=$discriptNameObj->attributes->item(0)->value;												   		 
					}
					$meshTerm['term_name']=$discriptName;
					$meshTerm['is_major']=$isMajor;
				}
				
				$arrQualifier=array();
				$qualifierNames=$meshTermObj->getElementsByTagName('QualifierName');				
				foreach($qualifierNames as $qualifierNameObj){
					$isMajor="";
					$arrQualifierNames[]=$qualifierNameObj->nodeValue;				
					if($qualifierNameObj!=null){
						$qualifier=array();					
						$qualifierName=$qualifierNameObj->nodeValue;
						if($qualifierNameObj->hasAttributes()){			
							$isMajor=$qualifierNameObj->attributes->item(0)->value;												   		 
						}
						$qualifier['term_name']=$qualifierName;
						$qualifier['is_major']=$isMajor;
						$arrQualifier[]=$qualifier;
					}														
				}	
				$meshTerm['arr_qualifier']=$arrQualifier;	
				$arrMeshTerms[]=$meshTerm;		
			}			
		}
		return $arrMeshTerms;
	}
	
	/**
	 * saves the array of MeshTerms one by one
	 * @param $arrMeshTerms
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_meshterms($arrMeshTerms, $pubId){
		$query= array();
		foreach($arrMeshTerms as $meshTerm){
			if($meshTerm!=null){
				$termId=0;
				$term=array();
				$term['term_name']=$meshTerm['term_name'];
				$term['parent_id']=$termId;
				// save parent MeshTerm into pubmed_meshTerm
				$termId=$this->pubmed->savePubmedMeshTerm($term);
				
				$pubTerm=array();
				$pubTerm['pub_id']=$pubId;
				$pubTerm['term_id']=$termId;
				$pubTerm['is_major']=($meshTerm['is_major']=='Y') ? 1:0 ;
				$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';
				
				$arrQualifier=array();
				$arrQualifier=$meshTerm['arr_qualifier'];
				$parentId=$termId;
				foreach($arrQualifier as $qualifier){										
					$term=array();
					$term['term_name']=$qualifier['term_name'];
					$term['parent_id']=$parentId;
					// save parent MeshTerm into pubmed_meshTerm
					$termId=$this->pubmed->savePubmedMeshTerm($term);
					
					$pubTerm=array();
					$pubTerm['pub_id']=$pubId;
					$pubTerm['term_id']=$termId;
					$pubTerm['is_major']=($qualifier['is_major']=='Y') ? 1:0 ;
					$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';					
				}				
			}		
		}
		
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_mesh_terms (pub_id, term_id, is_major) VALUES '.implode(',', $query));
		
		
	}
	
	/**
	 * Parses the publication Substance details from XML Object and returns Substances in an array
	 * @param XML Object $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_substances($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrSubstances=array();	
		$substances=$medlineCitation->getElementsByTagName('Chemical'); 
		if($substances!=null){
			foreach($substances as $substanceObj){
				if($substanceObj!=null){
					$substance=array();
					$regNumObj=$substanceObj->getElementsByTagName('RegistryNumber')->item(0);
					if($regNumObj!=null)
						$regNum=$regNumObj->nodeValue;
					$substanceNameObj=$substanceObj->getElementsByTagName('NameOfSubstance')->item(0);
					if($substanceNameObj!=null)
						$substanceName=$substanceNameObj->nodeValue;
					$substance['reg_num']=$regNum;
					$substance['name']=	$substanceName;
					$arrSubstances[]=$substance;	
				}	
			}
		}
		return $arrSubstances;
	}
	
	/**
	 * saves the array of Substances one by one
	 * @param $arrSubstances
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_substances($arrSubstances, $pubId){
		$query= array();
		foreach($arrSubstances as $substance){
			if($substance!=null){
				$substanceId=$this->pubmed->savePubmedSubstance($substance);
				
				$pubSubstance=array();
				$pubSubstance['pub_id']=$pubId;
				$pubSubstance['substance_id']=$substanceId;
				
				$query[] = '('.$pubSubstance['pub_id'].', '.$pubSubstance['substance_id'].')';
			}
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_substances (pub_id, substance_id) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * Parses the Publication types from XML Object and returns Publication types in an array
	 * @param XML Object $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_types($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrPubTypes=array();	
		$publicationTypes=$medlineCitation->getElementsByTagName('PublicationType'); 
		if($publicationTypes!=null){
			foreach($publicationTypes as $publicationType){				
				if($publicationType!=null){
					$pubType=array();
					$pubType['type']=$publicationType->nodeValue;	
					$arrPubTypes[]=$pubType;	
				}	
			}	
		}
		return $arrPubTypes;
	}
	
	/**
	 * saves the array of Publication types one by one
	 * @param Array $arrPubTypes
	 * @param Integer $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_types($arrPubTypes, $pubId){
		$query= array();
		foreach($arrPubTypes as $type){
			if($type!=null){
				$typeId=$this->pubmed->savePubmedPubType($type);
				
				$pubType=array();
				$pubType['pub_id']=$pubId;
				$pubType['pub_type_id']=$typeId;
				
				$query[] = '('.$pubType['pub_id'].', '.$pubType['pub_type_id'].')';
			}			
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publications_types (pub_id, pub_type_id) VALUES '.implode(',', $query));
				
	}
	
	/**
	 * Parses the Comments and Corrections from XML Object and returns Comments and Corrections in an array
	 * @param XML Object $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_CC($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrCC=array();
		$arrCCObj=$medlineCitation->getElementsByTagName('CommentsCorrections'); 
		if($arrCCObj!=null){
			foreach($arrCCObj as $ccObj){
				if($ccObj!=null){
					$cc=array();
					$reftype='';
					$refSource='';
					$ccPMID='';
					$ccPMIDVersion='';
					if($ccObj->hasAttributes()){			
						$reftype=$ccObj->attributes->item(0)->value;												   		 
					}
					$refSourceObj=$ccObj->getElementsByTagName('RefSource')->item(0); 
					if($refSourceObj!=null)
						$refSource=$refSourceObj->nodeValue;
					$ccPMIDObj=$ccObj->getElementsByTagName('PMID')->item(0); 
					if($ccPMIDObj!=null){
						$ccPMID=$ccPMIDObj->nodeValue;
						if($ccPMIDObj->hasAttributes()){			
							$ccPMIDVersion=$ccPMIDObj->attributes->item(0)->value;												   		 
						}
					}
					$cc['ref_type']=$reftype;
					$cc['ref_source']=$refSource;
					$cc['cc_pmid']=$ccPMID;
					$cc['cc_pmid_version']=$ccPMIDVersion;
					$arrCC[]=$cc;
				}
			}
		}
		return $arrCC;
	}
	
	/**
	 * saves the array of Comments and Corrections one by one
	 * @param $arrCC
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_CC($arrCC, $pubId){
		$query= array(); 
		foreach( $arrCC as $row ) {
			if($row!=null){
		   		$query[] = '("'.mysql_real_escape_string($row['ref_type']).'", "'.$row['ref_source'].'", "'.$row['cc_pmid'].'", "'.$row['cc_pmid_version'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_cc (ref_type, ref_source, cc_pmid, cc_pmid_version) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_cc");
			$result = $result->first_row();
			$ccId=$result->id;
			$ccId = $ccId - (sizeof($arrCC)-1);
			
			$arrPubCCs = array();
			foreach($arrCC as $cc){
				if($cc!=null){
					$pubCC=array();
					$pubCC['pub_id']=$pubId;
					$pubCC['cc_id']=$ccId;
					$arrPubCCs[] = $pubCC;
					$ccId++;
				}			
			}
			$query= array();
			foreach( $arrPubCCs as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['cc_id'].')';
			}
			$this->db->query('INSERT INTO publications_cc (pub_id, cc_id) VALUES '.implode(',', $query));
			
		}		
	}
	
	/**
	 * 
	 * @param unknown_type $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_history($publication){
		$arrHistory=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$historyObj=$pubmedData->getElementsByTagName('History')->item(0);
		if($historyObj!=null){
			$histories=$historyObj->getElementsByTagName('PubMedPubDate');
			if($histories!=null){
				foreach($histories as $historyObj){
					if($historyObj!=null){
						$pubHistory=array();
						$status='';
						$arrDateTime=array();
						if($historyObj->hasAttributes()){			
							$status=$historyObj->attributes->item(0)->value;												   		 
						}
						$yearObj=$historyObj->getElementsByTagName('Year')->item(0);
						if($yearObj!=null)
							$arrDateTime['year']=$yearObj->nodeValue;
						$monthObj=$historyObj->getElementsByTagName('Month')->item(0);
						if($monthObj!=null)
							$arrDateTime['month']=$monthObj->nodeValue;
						$dayObj=$historyObj->getElementsByTagName('Day')->item(0);
						if($dayObj!=null)
							$arrDateTime['day']=$dayObj->nodeValue;
						$hourObj=$historyObj->getElementsByTagName('Hour')->item(0);
						if($hourObj!=null)
							$arrDateTime['hour']=$hourObj->nodeValue;
						$minuteObj=$historyObj->getElementsByTagName('Minute')->item(0);
						if($minuteObj!=null)
							$arrDateTime['minute']=$minuteObj->nodeValue;
							
						$pubHistory['status']=$status;
						$pubHistory['date']=$this->array_to_dattime($arrDateTime);
						$arrHistory[]=$pubHistory;
					}
				}
			}
		}
		return $arrHistory;
	}
	
	/**
	 * 
	 * @param $arrHistory
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function save_pub_history($arrHistory, $pubId){
		$query= array(); 
		foreach($arrHistory as $pubHistory){
			if($pubHistory!=null){	
				$query[] = '("'.mysql_real_escape_string($pubId).'", "'.$pubHistory['status'].'", "'.$pubHistory['date'].'")';
			}			
		}
		$this->db->query('INSERT INTO publication_history (pub_id, status, date) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * 
	 * @param $publication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function parse_pub_article_ids($publication){
		$arrPubArticleIds=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$articleIds=$pubmedData->getElementsByTagName('ArticleId');
		foreach($articleIds as $articleIdObj){
			if($articleIdObj!=null){
				$PubArticleId=array();
				$type='';
				$idValue='';
				if($articleIdObj->hasAttributes()){			
					$type=$articleIdObj->attributes->item(0)->value;												   		 
				}
				$idValue=$articleIdObj->nodeValue;
				$PubArticleId['type']=$type;
				$PubArticleId['id_value']=$idValue;
				$arrPubArticleIds[]=$PubArticleId;
			}
		}
		return $arrPubArticleIds;
	}
				
	/**
	 * 
	 * @param $arrPubArticleIds
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */		
	function save_pub_article_ids($arrPubArticleIds, $pubId){
		$query= array(); 
		foreach( $arrPubArticleIds as $row ) {
			if($row!=null){
		   		$query[] = '("'.mysql_real_escape_string($row['type']).'", "'.$row['id_value'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_article_ids (type, id_value) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_article_ids");
			$result = $result->first_row();
			$id=$result->id;
			$id = $id - (sizeof($arrPubArticleIds)-1);
		
			$arrPublicationArticleIds =array();
			foreach($arrPubArticleIds as $articleId){
				if($articleId!=null){
					$PubArticleId=array();
					$PubArticleId['pub_id']=$pubId;
					$PubArticleId['pub_article_id']=$id;
					$id++;
					
					$arrPublicationArticleIds[] = $PubArticleId;
				}
			}
			$query= array();
			foreach( $arrPublicationArticleIds as $row ) {
				if($row!=null){
			   		$query[] = '('.$row['pub_id'].', '.$row['pub_article_id'].')';
				}
			}
			$this->db->query('INSERT INTO publication_article_ids (pub_id, pub_article_id) VALUES '.implode(',', $query));
			
		}
	}
	
	/**
	 * coverts the date in array format to sql date
	 * @param $arrayDate
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return String
	 * @created on 30-03-2013
	 */
	function array_to_date($arrayDate){	
		if(isset($arrayDate['month']) && $arrayDate['month']!=null)	
			$arrayDate['month']=$this->month_to_integer($arrayDate['month']);
		$date='';
		if($arrayDate!=null){
			$date=$arrayDate['year']."-".$arrayDate['month']."-".$arrayDate['day'];			
		}			
		return $date;
	}	
	
	/**
	 * coverts the datetime in array format to sql datetime
	 * @param $arrayDate
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return String
	 * @created on 30-03-2013
	 */
	function array_to_dattime($arrDateTime){
		$date='';
		if($arrDateTime!=null){
			$date=$arrDateTime['year']."-".$arrDateTime['month']."-".$arrDateTime['day']." ".$arrDateTime['day'].":".$arrDateTime['day'].":00";			
		}	
		return $date;
	}
	
	/**
	 * coverts given 3 charecter string month to integer month
	 * @param $month
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Integer
	 * @created on 30-03-2013
	 */
	function month_to_integer($month){		
		if($month=='Jan')
			return 01;		
		if($month=='feb')
			return 02;
		if($month=='mar')
			return 03;
		if($month=='apr')
			return 04;
		if($month=='may')
			return 05;	
		if($month=='jun')
			return 06;
		if($month=='jul')
			return 07;
		if($month=='aug')
			return 08;
		if($month=='sep')
			return 09;
		if($month=='oct')
			return 10;
		if($month=='nov')
			return 11;
		if($month=='dec')
			return 12;		
			
		return (int)$month;
	}
	
	/**
	 * Publicatons crawlign script for organizations with recrawl status
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function processPubmedRecrawlOrgs(){
		ini_set("max_execution_time",$this->maxScriptTime);
		//Get all the KOLs having the pubmed status 'Recrawl'
		$arrOrgs = $this->pubmed_org->getPubmedRecrawlOrgs();
		
		//Loop trough each KOL
		foreach($arrOrgs as $arrOrgDetail){
			$orgId = $arrOrgDetail['id'];
			$this->logText	= "\r\nStarting pubmed processing for OrgId ".$orgId." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Get the PMIDs for this KOL
			$arrPMIDs = $this->pubmed_org->getPMIDs($orgId);
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Check for already existing publication's and associate them with org
			$arrFilteredPMIDs=$this->pubmed_org->checkAndAssociateAlreadyExistPubs($arrPMIDs, $orgId,$arrOrgDetail,1);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);
								
				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}

				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Restarting the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						$this->send_status_mail($this->logText);
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						redirect(base_url()."pubmeds_org/process_pubmeds");									
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $orgId, 1);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						fwrite($this->logFile, $this->logText);
						$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmid : ".$pubDetails['pmid']."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//log the details
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logLastPmidFile,$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
					//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsjing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully</br>";
			$arrOrgDetail['is_pubmed_processed']=1;
			$this->pubmed_org->updatePubmedProcessedOrg($arrOrgDetail);	
			$this->logText	= "Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$orgStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			/*$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($orgId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);*/
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			$this->send_status_mail("Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully");
		}
	}
	
	/**
	 * Publicatons crawlign script for given pmids for the organization
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return 
	 * @created on 30-03-2013
	 */
	function process_pmids($orgId){
		ini_set("max_execution_time",$this->maxScriptTime);
		$arrPMIDs = null;
		$returnData = array();
		$arrPMIDStatuses = array();
		if($arrPMIDs == null){
			$arrPMIDs = array();
			$arrPMIDs = $this->input->post('pmids');
		}
		$arrOrgDetail=$this->organization->editOrganization($orgId);
		$arrFilteredPMIDs=$this->pubmed_org->checkAndAssociateAlreadyExistPubs($arrPMIDs, $orgId,$arrOrgDetail);
		$associatedPmids = array_diff($arrPMIDs, $arrFilteredPMIDs);
		foreach ($associatedPmids as $pmid){
			$arrPMIDStatuses[$pmid] = 'exist';
		}
		$this->startTime	= microtime(true);
		$pmidsList = implode(',',$arrFilteredPMIDs);
		if($pmidsList != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmidsList;
			if($pmidsList!='')
				$response = $this ->retrieve_page_get($url);
			//Try once again if the response of the status is false	
			if($response['status'] == false){
				//give 2 second delay
				sleep($this->sleepTime);
				$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
				fwrite($this->logFile, $this->logText);
				//try once again
				$response = $this ->retrieve_page_get($url);
			}
			// Skipp this and log the details if still respons is false
			if($response['status'] == false){
				//log the details
				$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
				fwrite($this->logFile, $this->logText);
				
				$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
				fwrite($this->logFilePmidSkipped, $this->logText);
				//continue to next step
				continue;
			}
				
			$xml = new DOMDocument();
			if(!$xml->loadXML($response['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
				fwrite($this->logFile, $this->logText);	
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				if(!$xml->loadXML($response['response'])){
					//log the details and continue
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);	
					
					$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					continue;
					//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
				}										
			}
	
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				if($remTime<$this->safeTime){
					$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}					
				$pubStartTime=microtime(true);	
				//parse and save publication details
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId=$this->save_publications($pubDetails, $orgId);
				if($pubId!=null){
					//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
					//fwrite($this->logFile, $this->logText);	
				}else{
					$arrPMIDStatuses[$pubDetails['pmid']] = 'error';
					$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
					fwrite($this->logFile, $this->logText);
					continue;
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
				//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
				
				$arrPMIDStatuses[$pubDetails['pmid']] = 'done';
			}
			sleep($this->sleepTime);
		}
		//$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($orgId);
		$returnData['status'] = true;
		$returnData['pmidstatuses'] = $arrPMIDStatuses;
		echo json_encode($returnData);
	}
	
	/**
	 * Gets the content from the given url
	 * @param $url
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return data Object
	 * @created on 30-03-2013
	 */
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.15'){
			$aContext = array(
			    'http' => array(
			        'proxy' => 'tcp://192.168.1.90:808',
			        'request_fulluri' => true,
			    ),
			);		
			$cxContext = stream_context_create($aContext);
			
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$data = array();
			$res = null;
			$data['status'] = false;
			if(!$res = file_get_contents($url)){
				//$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				//fwrite($this->logFile, $this->logText);	
				//die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
				$data['status'] = false;											
			}else{
				$data['status'] = true;
			}			
			if(!$res){	
				//echo 'Error in connecting to url'.$url;
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
			
			$data['response'] = $res;
			return $data;
		}
	}
	
	/**
	 * Updates organizations pubmed status to given status
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return data Object
	 * @created on 30-03-2013
	 */
	function update_org_pubmed_status(){
		$status = $this->input->post('status');
		$arrOrgIds = $this->input->post('orgIds');
		
		foreach($arrOrgIds as $orgId){
			$isUpdated = $this->pubmed_org->changeOrgPubmedStatus($orgId, $status);
		}
		
		if($isUpdated){
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Organizations Pubmed Status to '.$status,
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => $arrOrgIds,
					'transaction_id' =>  $arrOrgIds,
					'transaction_table_id' => ORGANIZATIONS,
					'transaction_name' => 'Update Organizations Pubmed Status to '.$status,
					'parent_object_id' =>  $arrOrgIds
			);
			$this->config->set_item('log_details', $arrLogDetails);
			echo "true";
		}
		else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Organizations Pubmed Status to '.$status,
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => $arrOrgIds,
					'transaction_id' =>  $arrOrgIds,
					'transaction_table_id' => ORGANIZATIONS,
					'transaction_name' => 'Update Organizations Pubmed Status to '.$status,
					'parent_object_id' =>  $arrOrgIds
			);
			$this->config->set_item('log_details', $arrLogDetails);
			echo "false";
		}
	}
	
	
	//Delete the associations of the PMId and recrawl the details and save the associations
	function recrawl_pmid($pmid){
		if($pmid != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmid;
			$response = $this ->retrieve_page_get($url);
			//Try once again if the response of the status is false	
			if($response['status'] == false){
				//give 2 second delay
				sleep($this->sleepTime);
				$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
				fwrite($this->logFile, $this->logText);
				//try once again
				$response = $this ->retrieve_page_get($url);
			}
			// Skipp this and log the details if still respons is false
			if($response['status'] == false){
				//log the details
				$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
				fwrite($this->logFile, $this->logText);
				
				$this->logText = "Recralw : PMID : ".$pmid."\r\n";
				fwrite($this->logFilePmidSkipped, $this->logText);
				//continue to next step
				continue;
			}
				
			$xml = new DOMDocument();
			if(!$xml->loadXML($response['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
				fwrite($this->logFile, $this->logText);	
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				if(!$xml->loadXML($response['response'])){
					//log the details and continue
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);	
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					continue;
					//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
				}										
			}
			
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				$pubId=$this->pubmed->checkPubExist($pmid);
				if($pubId ==null || $pubId == ''){
					//die("Publication with PMID:".$pmid."  not exist.\r\n");	
					$this->logText	= "Publication with PMID:".$pmid."  not exist. \r\n";
					fwrite($this->logFile, $this->logText);										
					continue;
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				$this->logText	= "PMID : ".$pmid."	PubID :".$pubId." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
				$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
					
				//Delete all the initiall associations first
				$this->pubmed->deletePublicationAssociationDetails($pubId);
				
				//pr($arrAuthors);
				//$arrAuthors = array_slice($arrAuthors,0, 2);
				//pr($arrAuthors);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				//$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
			}
			
		}
	}
	
	/**
	 * getting publication _substances details of orgainzation by passing id to model
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 2.0
	 * @param $orgId
	 * @return json data- $data
	 */
	function list_publications_by_year_range($fromYear,$toYear,$orgId){
		
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPublications	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed_org->listPublicationsByYearRange($orgId,$fromYear,$toYear)){	
			//echo $this->db->last_query();		
			foreach($arrPublicationsResults as $arrPublicationsResult){
				//$arrPublication['micro']='<a href=\''.'#'.'\' onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></a>';
				$arrPublication['micro']			= '<label onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
				$arrPublication['is_manual']		= $arrPublicationsResult['is_manual'];
				$arrPublication['client_id']		= $arrPublicationsResult['client_id'];
				$arrPublication['id']				= $arrPublicationsResult['id'];
				$arrPublication['pmid']				= '<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
				$arrPublication['pmid_as_id']				= $arrPublicationsResult['pmid'];			
				$arrPublication['journal_name']		= $arrPublicationsResult['journal_name'];
				//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
				////if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
					//$arrPublication['article_title']= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				//else{
				//	if($arrPublicationsResult['link'] != null && $arrPublicationsResult['link'] != "")
						//$arrPublication['article_title']='<a href=\''.$arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				//else
					//arrPublication['article_title']= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				//}
				$arrPublication['link'] = $arrPublicationsResult['link'];
				$arrPublication['article_title'] = $arrPublicationsResult['article_title'];
				
				$arrPublication['affiliation']		= $arrPublicationsResult['affiliation'];
				$arrPublication['date']				= sql_date_to_app_date($arrPublicationsResult['created_date']);
				//$arrPublication['authors']=$this->get_pub_authors($arrPublication['id']);
				//$arrPublication['auth_pos']			= $arrPublicationsResult['auth_pos'];
				//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$kolId,null);
				//$arrPublication['subject']='';
				$arrPublication['user_id']			= $arrPublicationsResult['user_id'];
				$arrPublication['kp_id']			= $arrPublicationsResult['kp_id'];
				$arrPublications[]					= $arrPublication;
			}
			$count				= sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPublications;  
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/**
	 * getting publication _substances details of orgainzation by passing id to model
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 2.0
	 * @param $orgId
	 * @return json data- $data
	 */
	function view_pub_major_meshterm_chart($orgId=null, $fromYear, $toYear){
		$keyWord = $this->input->post('keyWord');
			
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrMajorMeshterm 	= $this->pubmed_org->getPubMajorMeshTermChart($orgId, $fromYear, $toYear,$keyWord);
		$meshTerms			= array();
		$count				= array();
		$arrIds				=array();
		$arrParentIds		=array();
		foreach($arrMajorMeshterm as $meshterm){
			$termName		= '';
			$parentId		= $meshterm['parent_id'];
			if($parentId!=0 && $parentId!=null){
				$parentName	= $this->pubmed->getMeshTermName($parentId);
				$termName	= $parentName."/".$meshterm['mesh_term'];
			}else{
				$termName	= $meshterm['mesh_term'];
			}
			$meshTerms[]	= ucwords($termName);
			$count[]		= (int)$meshterm['count'];
			$arrIds[]		= $meshterm['id'];
			$arrParentIds[]	= $meshterm['parent_id'];
		}
		$data[]				= $meshTerms;
		$data[]				= $count;
		$data[]				= $arrIds;
		$data[]				= $arrParentIds;
		echo json_encode($data);
	}
	
	/**
	 * getting publication _substances details of orgainzation by passing id to model
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 2.0
	 * @param $orgId
	 * @return json data- $data
	 * 
	 */
	function view_pub_substances_chart($orgId=null, $fromYear, $toYear){
		$keyWord = $this->input->post('keyWord');
			
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrSubstances = $this->pubmed_org->getPubSubstancesChart($orgId, $fromYear, $toYear,$keyWord);
		//pr($arrSubstances);
		$substances=array();
		$count=array();
		$arrIds=array();
		foreach($arrSubstances as $substance){
			$substances[]=ucwords($substance['name']);
			$count[]=(int)$substance['count'];
			$arrIds[] = $substance['id'];
		}
		$data[]=$substances;
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
		//echo json_encode($arrSubstances);
	}
	
	/**
	 * getting publication journals details of orgainzation by passing id to model
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 2.0
	 * @param $orgId
	 * @return json data- $data
	 * 
	 */
	function view_pub_journals_chart($orgId,$fromYear,$toYear){
		$keyWord = $this->input->post('keyWord');
			
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrJournals= $this->pubmed_org->getPubJournalsChart($orgId,$fromYear,$toYear,$keyWord);
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['name'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];			
		}
		$data[]=$name;	
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	
	/**
	 * pass the post data to model and get publication of Passed data
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 2.0
	 * @param $orgId
	 * @return json data- $data
	 * 
	 */
	function search_publicatios_by_parameters($orgId){
		$page			= (int)$this->input->post('page'); // get the requested page 
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$substance		= $this->input->post('substances');
		$author			= $this->input->post('author');
		$meshTerm		= $this->input->post('meshTerm');
		$keyWord		= $this->input->post('keywords');
		$articleName	= $this->input->post('article');
		$fromYear		= $this->input->post('fromYear');
		$toYear			= $this->input->post('toYear');
		
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrResult		= $this->pubmed_org->searchPublicationsByParameters($substance,$author,$meshTerm,$keyWord,$articleName,$orgId,$fromYear,$toYear);
		$arrPublications= array();
		foreach($arrResult as $arrPublicationsResult){
			//$arrPublication['micro']='<a href=\''.'#'.'\' onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></a>';
			$arrPublication['micro']		= '<label onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
			$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
			$arrPublication['id']			= $arrPublicationsResult['id'];
			//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
			$arrPublication['journal_name']	= $arrPublicationsResult['journal_name'];
			//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
			//$arrPublication['article_title']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
			if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0){
//				$arrPublication['article_title']= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['pmid_as_id']=$arrPublicationsResult['pmid'];
			}else{
//				$arrPublication['article_title']= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['pmid_as_id']=$arrPublicationsResult['pmid'];
			}
			$arrPublication['article_title'] = $arrPublicationsResult['article_title'];
			$arrPublication['pmid_as_id'] = $arrPublicationsResult['pmid'];
			$arrPublication['link'] = $arrPublicationsResult['link'];
			$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
			$arrPublication['date']			= sql_date_to_app_date($arrPublicationsResult['created_date']);
			$arrPublications[]				= $arrPublication;
		}
		$count=sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records'] = $count;
			$data['total']   = $total_pages;
			$data['page']    = $page;				
			$data['rows']    = $arrPublications; 
		echo json_encode($data);
	}
	
	function view_publication_chart($orgId=null, $fromYear, $toYear){
		
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		
		$arrPublications 	= $this->pubmed_org->getPublicationChart($orgId, $fromYear, $toYear,$keyWord);
		$years 				= array();
		$count				= array();
		$yearMapping		= array();
		foreach($arrPublications as $publication){
			$years[]		= $publication['year'];
			$count[]		= (int)$publication['count'];
			$yearMapping[substr($publication['year'],2)] = $publication['year'];
		}
		$data[]				= array_reverse($years);
		$data[]				= array_reverse($count);
		$data[]				= $yearMapping;
		echo json_encode($data);
	}
	
	function list_key_authors($orgId=null,$affilition=null){
		$affilition = $this->input->post('affilition');
		$this->load->model("kol",'kol');
		$arrKols  = $this->kol->getKolNames();
		$this->load->model("Common_helpers",'common_helpers');
		$nameCombinations = $this->common_helpers->getNameCombinationArray($arrKols);
			
		$page			= (int)$this->input->post('page'); // get the requested page 
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrDetails = $this->pubmed_org->getFistAuthors($orgId,$affilition,null);
		
		foreach($arrDetails as $row){
			
			$detail =array();
			$detail['id'] = $row['id'];
			
			if($row['last_name']!='' && $row['fore_name']!='')
				$authorName =$row['fore_name']." ".$row['last_name'];
			else if($row['fore_name']=='')
				$authorName =$row['initials']." ".$row['last_name'];
			else if($row['last_name']=='')
				$authorName =$row['fore_name']." ".$row['initials'];
			$detail['name'] = $authorName;
			$detail['num_pub'] = $row['num_pubs'];
			
			
			$kolId = $this->common_helpers->getMatchingKolId($row['last_name'].$row['fore_name'],$nameCombinations,true);
				if($kolId){
					$detail['kol_id'] = $kolId;
					$detail['is_kol'] = 'Yes';
				}else{
					$detail['is_kol'] = 'No';
				}
			
			//$arrMajorMeshterm 	= $this->pubmed_org->getPubMajorMeshTerms($orgId,$row['last_name'],$row['fore_name'],$row['initials']);
			//pr($arrMajorMeshterm);
			//$meshTerms		    = array();
			//$count				= array();
			/*
			foreach($arrMajorMeshterm as $meshterm){
				$termName										= '';
				$parentId										= $meshterm['parent_id'];
				if($parentId!=0 && $parentId!=null){
					$parentName									= $this->pubmed->getMeshTermName($parentId);
					$termName									= $parentName."/".$meshterm['term_name'];
				}else{
					$termName									= $meshterm['term_name'];
				}
				$meshTerms[]									= ucwords($termName);
			}*/
			//pr($meshTerms);
			$detail['parent_key_words'] = 	 $row['key_words'];
			$detail['key_words'] = explode(':',$row['key_words']);
			
			$detail['key_words1'] = 	  explode(':',$row['all_key_words']);
			
			foreach($detail['key_words'] as $row1){
				
				$termName = explode('/',$row1);
				$key = array_search($termName[1],$detail['key_words1']);
				unset($detail['key_words1'][$key]);
				
			}
			$arrKeyWords = array_merge($detail['key_words'],$detail['key_words1']);
			$arrKeyWords = implode(', ',$arrKeyWords);
			$detail['key_words'] = $arrKeyWords;
			
			$arrKeyAuthors[] = $detail;
		}
		//pr($detail['key_words']);
		
		//pr($arrKeyAuthors);
		$count=sizeof($arrKeyAuthors);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records'] = $count;
			$data['total']   = $total_pages;
			$data['page']    = $page;				
			$data['rows']    = $arrKeyAuthors; 
		echo json_encode($data);
	}
	
	function list_key_investigators($orgId=null){
		//Get the kol names with concatination of firstname,middlename,and last name
		$arrKols  = $this->pubmed_org->getKolNamesWithConcat();
		$arrKeyInvestigators = array();
		$page			= (int)$this->input->post('page'); // get the requested page 
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrDetails = $this->pubmed_org->getKeyInvestigators($orgId,null);
		foreach($arrDetails as $row){
			$detail =array();
			$detail['id'] = $row['id'];
			$detail['name'] = $row['last_name'];
			
			$nameAfterExplode = explode(' ',$detail['name']);
			$nameAfterImplode = implode('',$nameAfterExplode);
			$kolId = array_search($nameAfterImplode,$arrKols);
				if($kolId){
					$detail['kol_id'] = $kolId;
					$detail['is_kol'] = 'Yes';
				}else{
					$detail['is_kol'] = 'No';
				}
			$detail['trial_count'] = $row['trial_count'];
			
		
			//$arrKeyWords 	= $this->pubmed_org->getKeywords($orgId,$detail['name']);
			//pr($arrKeyWords);
			//pr($meshTerms);
			$detail['key_words'] = 	 $row['key_words'];
			$arrKeyInvestigators[] = $detail;
		}
		
	//	pr($arrKeyAuthors);
		$count=sizeof($arrKeyInvestigators);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records'] = $count;
			$data['total']   = $total_pages;
			$data['page']    = $page;				
			$data['rows']    = $arrKeyInvestigators; 
		echo json_encode($data);
	}
	
	function save_name_combinations(){
		$nameCombinationText = $this->input->post('name_combinations');
		$kolId = $this->input->post('org_id');
		$nameCombinations = explode(",",$nameCombinationText);
		foreach ($nameCombinations as $name){
			$name = trim($name);
			if($name != ''){
				$rowData = array();
				$rowData['org_id'] = $kolId;
				$rowData['name'] = $name; 
				$isSaved = $this->pubmed_org->saveNameCombination($rowData);
			}
		}
	}
	
	function get_name_combinations($orgId){
		$arrNameCombinations = $this->pubmed_org->getOrgNameCombinations($orgId);
		$data = array();
		$data['arrNameCombinations'] = $arrNameCombinations;
		$data['orgId'] = $orgId;
		$this->load->view('publications/org_name_combinations',$data);
	}
	
	function delete_name_combinations(){
		$name = $this->input->post('name_combination');
		$orgId = $this->input->post('org_id');
		$isDeleted = $this->pubmed_org->deleteNameCombination($name,$orgId);
	}
	
	function view_publications($id,$orgId,$fromYear,$endYear,$affiliation){
		$arrFnameAndIitials = $this->pubmed_org->getFnameAndInitials($id);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrPublicationDetails = $this->pubmed_org->getPublicationDetails($arrFnameAndIitials,$orgId,$fromYear,$endYear,$keyWord,$affiliation);
		$arrValues = array();
		foreach($arrPublicationDetails as $arrPubDetail){
			$arrPubDetail['authcount'] = sizeof($this->pubmed->listPublicationAuthors($arrPubDetail['id']));
			$arrValues[] =  $arrPubDetail;
		}
		
		$data['arrPublications']			= $arrValues;
		$data['filterType']					= 'Publications By Authors';
		$data['filterValue']				= $arrFnameAndIitials['last_name'].' '.$arrFnameAndIitials['fore_name'];
		$data['fromYear']					= $startYear;
		$data['toYear']						= $endYear;
		$this->load->view('publications/view_publications_by_parameters',$data);
		
	}
	
	function get_unprocessed_co_authors_page($orgId){
		//echo "ss";
		////$arrKolName = $this->kol->getKolName($kolId);
		//echo $this->db->last_query();
		//Get all the co-authors of given kol id.
		$arrCoAuthos=$this->pubmed_org->getOrgCoAuthors($orgId);
		
		//echo $this->db->last_query();
		//TODO Change the name of the variables and write the description about their usage
		//To Hold all the Processed co-authors, all the co- authors of kol having alias id
		$arrProcessedCoAuths=array();
		// To hold all the un processed co-authoers, $arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		$arrUnProcessedCoAuths=array();
		// To hold all the currently asigned alias authors
		$arrPresentAliasCoAuthos=array();
		//To hold all the possible alias co-authors for un processed co-authors, $arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		$arrPossibleAliasCoAuthors=array();
		
		
		$arrProcessedCoAuths=$this->pubmed_org->getOrgProcessedCoAuthors($orgId);
		
		//echo $this->db->last_query();
		//TODO What this loop does, write it
		//Prepare array of unprocessed co-authors, loop trough each kol co-authors, 
		//check is it has a alias id, if not then it is still un processed, i.e all the kol co-authors which are un processed.
		//$arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		foreach($arrCoAuthos as $key=>$value){
			if ( !array_key_exists($key, $arrProcessedCoAuths) ){
				//based on the name avilability, construct a proper name
				if($value['last_name']!='' && $value['fore_name']!='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
				else if($value['fore_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['initials']]=$value;
				else if($value['last_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['fore_name'])." ".$value['initials']]=$value;
			}
		}
		
		//pr($arrUnProcessedCoAuths);
		$arrPresentAliasCoAuthos = $this->pubmed_org->getAliasCoAuthors($orgId);
		//TODO What this loop does, write it
		//Prepare array of possible alias co-authors for un processed co-authors
		//$arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		//taking key as last name and first name in order to sort
		foreach($arrUnProcessedCoAuths as $key => $value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}		
		//TODO What this loop does, write it
		foreach($arrPresentAliasCoAuthos as $key=>$value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}
		/*
		 * TODO Move all the logic of getting the UnProcessed and Alias Co-Authors to 'Model' in 2 different functions.
		 * 		Just with 2 function calls, the data should be returned from the MODEL functions
		 */
		ksort($arrPossibleAliasCoAuthors,SORT_STRING);
		//Filter the unprocessed co authors, find the similar names and exclude the name with no  similar names
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths);
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths,$arrPossibleAliasCoAuthors);
		ksort($arrUnProcessedCoAuths);
		$data['arrUnProcessedCoAuths']=$arrUnProcessedCoAuths;
		$data['arrAliasCoAuthos']=$arrPossibleAliasCoAuthors;
		$this->load->view('organizations/publications/unprocessed_co_auths',$data);
	}
	
	function get_processed_co_authors_page($orgId){
		$arrOrgProcessedCoAuths=$this->pubmed_org->getOrgProcessedCoAuthors($orgId);
		$data['arrOrgProcessedCoAuths']=$arrOrgProcessedCoAuths;
		$this->load->view('organizations/publications/processed_co_auths',$data);
	}
	function associate_co_authors($orgId){
		/**
		 * TODO Write the brief description about what happens, in single line.
		 * 		Move the logic to MODEL in seperate function. Just need to pass IDs and get the TRUE/FALSE
		 */
		//$arrCoAuthsIds are the id's of co authors which are needs to be replaced(associated to) by the co auther name of $aliasId
		//With each $arrCoAuthsIds, there will be as many co author entries as the number of publications co-authered with the same name, we have to get the authoer id's of those entries also
		//these id's will be stored in the '$matchingAuths' array, for all these co auther we have to update it's alias as $aliasId
		$arrCoAuthsIds	=$this->input->post('co_auths_ids');
		$aliasId		=$this->input->post('alias_id');
		
		$coAuthorDetails=$this->pubmed_org->getCoAuthorById($aliasId);
		$matchingAuths=$this->pubmed_org->getMatchingCoAuthors($arrCoAuthsIds,$orgId);
		$aliasDeails['alias_id']=$coAuthorDetails['id'];
		$aliasDeails['alias_last_name']=$coAuthorDetails['last_name'];
		$aliasDeails['alias_initials']=$coAuthorDetails['initials'];
		$aliasDeails['alias_fore_name']=$coAuthorDetails['fore_name'];
		//foreach($arrCoAuthsIds as $authId)
			//$matchingAuths[$authId]=$authId;
		$matchingAuths=array_keys($matchingAuths);
		$isProcessed=$this->pubmed_org->associateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}
	
	/**
	 * Gets co Author id and disassociate it with other co author by setting all the alias details as null
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Json
	 * @created 08-04-11
	 */
	function disassociate_co_author($orgId){
		$authorId[]		=$this->input->post('co_author_id');
		$matchingAuths=$this->pubmed_org->getMatchingCoAuthors($authorId,$orgId);
		$matchingAuths=array_keys($matchingAuths);
		//Disassociatein is same as associating the co auther with null values
		$aliasDeails['alias_id']=null;
		$aliasDeails['alias_last_name']=null;
		$aliasDeails['alias_initials']=null;
		$aliasDeails['alias_fore_name']=null;
		$isProcessed=$this->pubmed_org->disassociateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}	
	
	function view_publications_by_substances($substanceName, $org_id, $fromYear, $toYear, $reportFilters = ''){
		$filters = array();
		//$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$filters['keyword']= $this->session->userdata('orgKeyWords');
		$arrPublications = $this->pubmed_org->getSubstancesPublications($substanceName, $org_id, $fromYear, $toYear, $filters);
		$substanceName = $this->pubmed->getSubstanceNameById($substanceName);	
		
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Substances';
		$data['filterValue']				= $substanceName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($org_id != 0){
			//$koldetails = $this->kol->getKolName($kol_id);
			//$data['first_name']		= $koldetails['first_name'];
			//$data['middle_name']	= $koldetails['middle_name'];
			//$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
	
	/**
	 * Returns the list of Publication details of Particular Journal Name,KOl_Id,Time Range
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 23/2/11
	 */
	function view_publications_by_journals($journalName,$org_id, $fromYear,$toYear, $reportFilters = ''){
		$filters = array();
		//$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$filters['keyword']= $this->session->userdata('orgKeyWords');
		$arrJournalPublications = $this->pubmed_org->getPublicationsByJournals($journalName,$org_id, $fromYear,$toYear,$filters);
		$journalName = $this->pubmed->getJournalNameById($journalName);
		$data['arrPublications']	= $arrJournalPublications;
		$data['filterType']					= 'Publications By Journals';
		$data['filterValue']				= $journalName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($org_id != 0){
			//$koldetails = $this->kol->getKolName($kol_id);
			//$data['first_name']		= $koldetails['first_name'];
			//$data['middle_name']	= $koldetails['middle_name'];
			//$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
	
	
	/**
	 * Returns the list of publications belongs to perticular MeshTerm KOl_Id,Time Range,
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 22/2/11
	 */
	function view_publications_by_keywords($org_id, $fromYear,$toYear,$parentId=null,$termId=null, $reportFilters = ''){
		$filters = array();
		//$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$completeTerm = '';
		if($parentId != 0)
			$completeTerm .= $this->pubmed->getMeshTermName($parentId)."/";	
		$completeTerm .= $this->pubmed->getMeshTermName($termId);
		
		$filters['keyword']= $this->session->userdata('orgKeyWords');
		$arrMeshTermPublications = $this->pubmed_org->getMajorMeshtermPublications($parentId,$termId,$org_id, $fromYear, $toYear, $filters);	
		$data['filterType'] 	='Publications by Keywords';
		$data['filterValue']	= $completeTerm;
		$data['fromYear']		= $fromYear;
		$data['toYear']			= $toYear;
		$data['arrPublications']= $arrMeshTermPublications;
		if($kol_id != 0){
		$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	
	} 
	
	/**
	 * Display the publication details for passed year
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 */
	function view_publications_by_year($org_id, $year, $reportFilters = ''){
		$filters = array();
		//$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$filters['keyword']= $this->session->userdata('orgKeyWords');
		$arrPublications = $this->pubmed_org->getYearPublications($org_id, $year, $filters);	
	
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Year';
		$data['filterValue']				= $year;
		$data['fromYear']					= '';
		$data['toYear']						= '';
		if($kol_id != 0){
			//$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
	
	function get_org_authors($orgId,$startYear,$endYear){
		
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrDetails = $this->pubmed_org->getFistAuthorsForChart($orgId,$startYear,$endYear,$keyWord);
		foreach($arrDetails as $row){
			
			
			
			if($row['last_name']!='' && $row['fore_name']!='')
				$authorName =$row['last_name']." ".$row['fore_name'];
			else if($row['fore_name']=='')
				$authorName =$row['last_name']." ".$row['initials'];
			else if($row['last_name']=='')
				$authorName =$row['fore_name']." ".$row['initials'];
			//$detail['name'] = $authorName;
			//$detail['num_pub'] = $row['num_pubs'];
			
			
			
			$name[] = $authorName;
			$count[]= (int)$row['num_pubs'];
			$arrIds[]=$row['id'];			
		
		
		}
		$data[]=$name;	
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
		
			
	}
	
	function parse_authors_manually($lastName,$foreName,$initials){
		$arrAuthors = array();
		$author 	= array();
		
		$author['last_name']= ($lastName != '') ? $lastName:$lastName;
		$author['fore_name']= ($foreName != '') ? $foreName:$foreName;
		$author['initials']	= ($initials != '') ? $initials:$initials;
		$author['suffix']	= 'Not Available';
		$author['is_name_valid']	= 0;
		$arrAuthors[]=$author;	
		
		return $arrAuthors;
	}
	
	function delete_client_publication($id){
		if($this->pubmed_org->deleteClientPublication($id)){
			echo true;
		}else{
			echo false;
		}
	}
	
	private function send_status_mail($message, $mailId = null){
		$config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html';

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear(true);
		
		if($mailId == null)
			$mailId = $this->observerEmailId;
			
        $this->email->subject($this->logFileName);
        $this->email->from(USER,"Pub Crawling");
		$this->email->message($message);
        $this->email->to($mailId);
        $this->email->attach($this->logFileName,'attachment');
		$this->email->attach($this->logFileNamePmidSkipped,'attachment');
        $this->email->send();
	}
	
	function view_pub_type_chart($orgId,$fromYear,$toYear){
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('orgKeyWords',$keyWord);
		$keyWord = $this->session->userdata('orgKeyWords');
		$arrJournals= $this->pubmed_org->getPubTypeData($orgId,$fromYear,$toYear,$keyWord);
		//echo $this->db->last_query();
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['type'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];			
		}
		$data[]=$name;	
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	
	function view_publications_by_type($typeId,$org_id, $fromYear,$toYear, $reportFilters = ''){
		$filters = array();
		//$filters = $this->filters_to_array($reportFilters);
		$filters['keyword']= $this->session->userdata('orgKeyWords');
		$arrJournalPublications = $this->pubmed_org->getPublicationsByType($typeId,$org_id, $fromYear,$toYear,$filters);
		
		//$journalName = $this->pubmed->getJournalNameById($journalName);
		$data['arrPublications']	= $arrJournalPublications;
		$data['filterType']					= 'Publications By Type';
		$data['filterValue']				= $arrJournalPublications[0]['type'];
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
}
