<?php
/**
*Model for Clinical Trial operations
*
*@package application.models
*@author Ambarish N
*@since
*@created on 10-01-11
*/

class Clinical_trial extends Model{

	//Constructore
	function Clinical_trial(){
		parent::Model();
	}
	
	 /*
      * Returns list of Clinical_trial-unprocessed kol in date Asecending order
      */
     function getClinicalTrialsUnprocessedKols(){
     	$arrKolDetails=array();
     	$this->db->where('(is_clinical_trial_processed = 0 or is_clinical_trial_processed is null)','',false);
     	$this->db->where('kols.status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrKolDetailResult=$this->db->get('kols');
	    foreach($arrKolDetailResult->result_array() as $arrKol){
	    			$arrKolDetails[]= $arrKol;
	    		}
	    return $arrKolDetails;
     }	
     
     /**
      * 
      * @param $ctId
      * @return unknown_type
      */
     function checkClinicalTrialExist($nctId){
     	$ctId='';
     	$this->db->where('ct_id',$nctId);
		$arrCts=$this->db->get('clinical_trials');	
    	 if($arrCts->num_rows()!=0){
			$ctObj=$arrCts->first_row();
			$ctId=$ctObj->id;
		} else {
			
		}
			return $ctId;
     }
     
	/**
	 * Saves the Clinical Trials and returns the id of last inserted record
	 * @param  $ctDetails Aray, which contains Clinical Trials details
	 * @return Integer, Clinical Trials Id
	 */
	function saveClinicalTrials($ctDetails){
		$ctId='';
		if($this->db->insert('clinical_trials',$ctDetails)){
			$ctId=$this->db->insert_id();	      		
		}else{	      		
		    return false;
		}	
		return $ctId;
	}

	//save the kol-to-Clinical Trials record
	function saveKolClinicalTrials($kolClinicalTrials){
	    $clientId = $this->session->userdata('client_id');
	    $userId = $this->session->userdata('user_id');
	    $dataType = 'User Added';
	    if($clientId == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
	    $kolClinicalTrials['data_type_indicator']	= $dataType;
		$kolClinicalTrials['client_id']	= $this->session->userdata('client_id');
		//$kolClinicalTrials['client_id']	= INTERNAL_CLIENT_ID;
		//$kolClinicalTrials['user_id']	= INTERNAL_USER_ID;
		$kolClinicalTrials['user_id']	= $this->session->userdata('user_id');
		$this->db->insert('kol_clinical_trials',$kolClinicalTrials);
		$lastInsertId = $this->db->insert_id();
		if($lastInsertId > 0){
			//Add Log activity
			$arrLogDetails = array(
			        'controller' => 'kols',
					'type' => ADD_RECORD,
					'description' => 'New Clinical Trails',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolClinicalTrials['kol_id'],
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => KOL_CLINICAL_TRIALS,
					'transaction_name' => 'New Clinical Trails',
					'parent_object_id' => $kolClinicalTrials['kol_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			if(!IS_IPAD_REQUEST){
			 log_user_activity ( null, true );
			}
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
			        'controller' => 'kols',
					'type' => ADD_RECORD,
					'description' => 'New Clinical Trails',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolClinicalTrials['kol_id'],
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => KOL_CLINICAL_TRIALS,
					'transaction_name' => 'New Clinical Trails',
					'parent_object_id' => $kolClinicalTrials['kol_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			if(!IS_IPAD_REQUEST){
			    log_user_activity ( null, true );
			}
		     return false;
		}
	}    

	/**
	 * Saves the Sponser record and returns the id of last inserted record
	 * @param  Array $sponser, which contains the Sponser details
	 * @return Integer $sponserId
	 */
	function saveSponser($sponser){
		$sponserId='';
		if(!isset($sponser['type'])){
		  $sponser['type'] = "lead sponsor";
		}
		$this->db->select('id');		
		$this->db->where('type',$sponser['type']);		
		$this->db->where('agency',$sponser['agency']);		
		if(isset($sponser['agency_class'])){
		    $this->db->where('agency_class',$sponser['agency_class']);
		}
		$resultSet	= $this->db->get('cts_sponsers');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$sponserId	= $ctObj->id;	
		}else if($this->db->insert('cts_sponsers',$sponser)){
			$sponserId	= $this->db->insert_id();	      		
		}else{	      		
		    return false;
		}	
		return $sponserId;
	}
	
	/**
	 * Saves the record to associate the Sponser to Clinical Trial
	 * @param Array $ctSponcer, Array containing the Clinical Trial to Sponsers association
	 * @return boolean
	 */
	function saveCtSponser($ctSponcer){
	    $sponserId='';
		$this->db->select('id');
		$this->db->where('cts_id',$ctSponcer['cts_id']);
		$this->db->where('sponser_id',$ctSponcer['sponser_id']);
		$resultSet	= $this->db->get('ct_sponsers');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$sponserId	= $ctObj->id;	
		}else if($this->db->insert('ct_sponsers',$ctSponcer)){
			$sponserId = $this->db->insert_id();
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add sponser to clinical trails',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $sponserId,
					'transaction_table_id' => CT_SPONSERS,
					'transaction_name' => 'Add sponser to clinical trails',
					'parent_object_id' => $sponserId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			
		}else{	
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add sponser to clinical trails',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $sponserId,
					'transaction_table_id' => CT_SPONSERS,
					'transaction_name' => 'Add sponser to clinical trails',
					'parent_object_id' => $sponserId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
		}	
		return $sponserId;
	}	
	
	/**
	 * Saves the Intervention record and returns the id of last inserted record
	 * @param  Array $intervention, which contains the Intervention details
	 * @return Integer $interventionId
	 */
	function saveIntervention($intervention){
		$interventionId=false;
		$this->db->select('id');
		$this->db->where('name',$intervention['name']);
		$resultSet	= $this->db->get('cts_interventions');
		if($resultSet->num_rows()!=0){
			$ctObj			= $resultSet->first_row();
			$interventionId	= $ctObj->id;	
		}else if($this->db->insert('cts_interventions',$intervention)){
			$interventionId=$this->db->insert_id();	      		
		}else{	      		
		    
		}	
		return $interventionId;
	}
	
	/**
	 * Saves the record to associate the Intervention to Clinical Trial
	 * @param Array $ctIntervention, Array containing the Clinical Trial to Intervention association
	 * @return boolean
	 */
	function saveCtIntervention($ctIntervention){
		$this->db->select('id');
		$this->db->where('cts_id',$ctIntervention['cts_id']);
		$this->db->where('intervention_id',$ctIntervention['intervention_id']);
		$resultSet	= $this->db->get('ct_interventions');
		if($resultSet->num_rows()!=0){
			return true;	
		}else if($this->db->insert('ct_interventions',$ctIntervention)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Intervention to clinical trails',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_INTERVENTIONS,
					'transaction_name' => 'Add Intervention to clinical trails',
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;	      		
		}else{	
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Intervention to clinical trails',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_INTERVENTIONS,
					'transaction_name' => 'Add Intervention to clinical trails',
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
		    return false;
		}	
	}	

	function getKeywordIdByKeyword($keyword){
		$this->db->select('id');
		$this->db->where('name',$keyword);
		$resultSet	= $this->db->get('cts_keywords');
		if($resultSet->num_rows()!=0){
			$ctKeywordObj	= $resultSet->first_row();
			return $ctKeywordObj->id;	
		}
		return false;
	}
	/**
	 * Saves the Keyword record and returns the id of last inserted record
	 * @param  Array $keyword, which contains the Keyword details
	 * @return Integer $keywordId
	 */
	function saveKeyword($keyword){
		$keywordId='';
		$this->db->select('id');
		$this->db->where('name',$keyword['name']);
		$resultSet	= $this->db->get('cts_keywords');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$keywordId	= $ctObj->id;	
		}else if($this->db->insert('cts_keywords',$keyword)){
			$keywordId=$this->db->insert_id();	      		
		}else{	      		
		    
		}	
		return $keywordId;
	}
	
	/**
	 * Saves the record to associate the Keyword to Clinical Trial
	 * @param Array $ctKeyword, Array containing the Clinical Trial to Keyword association
	 * @return boolean
	 */
	function saveCtKeyword($ctKeyword){
		$this->db->select('id');
		$this->db->where('cts_id',$ctKeyword['cts_id']);
		$this->db->where('keyword_id',$ctKeyword['keyword_id']);
		$resultSet	= $this->db->get('ct_keywords');
		
		if($resultSet->num_rows()!=0){
			return true;	
		}else if($this->db->insert('ct_keywords',$ctKeyword)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Keyword to Clinical Trial',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_KEYWORDS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;	      		
		}else{	
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Keyword to Clinical Trial',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_KEYWORDS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
		    return false;
		}	
	}
	
	function getMeshTermIdByMeshTerm($meshterm){
		$this->db->select('id');
		$this->db->where('term_name',$meshterm);
		$resultSet	= $this->db->get('cts_mesh_terms');
		if($resultSet->num_rows()!=0){
			$ctKeywordObj	= $resultSet->first_row();
			return $ctKeywordObj->id;	
		}
		return false;
	}
	/**
	 * Saves the Meshterms record and returns the id of last inserted record
	 * @param  Array $meshterms, which contains the Meshterms details
	 * @return Integer $meshtermId
	 */
	function saveMeshterms($meshterms){
		$meshtermId	= '';
		$this->db->select('id');
		$this->db->where('term_name',$meshterms['term_name']);
		$this->db->where('type',$meshterms['type']);
		$resultSet	= $this->db->get('cts_mesh_terms');	
    	if($resultSet->num_rows()>0){
			$ctObj=$resultSet->first_row();
			$meshtermId	= $ctObj->id;
		}else {
			if($this->db->insert('cts_mesh_terms',$meshterms)){
				$meshtermId	= $this->db->insert_id();	      		
			}
		}
		return $meshtermId;
	}
	
	/**
	 * Saves the record to associate the Meshterms to Clinical Trial
	 * @param Array $ctMeshterms, Array containing the Clinical Trial to $ctMeshterms association
	 * @return boolean
	 */
	function saveCtMeshterms($ctMeshterms){
		$this->db->select('id');
		$this->db->where('cts_id',$ctMeshterms['cts_id']);
		$this->db->where('term_id',$ctMeshterms['term_id']);
		$resultSet	= $this->db->get('ct_mesh_terms');
		if($resultSet->num_rows()!=0){
			return true;	
		}else if($this->db->insert('ct_mesh_terms',$ctMeshterms)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Meshterms to Clinical Trial',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_MESH_TERMS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;	      		
		}else{	
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Meshterms to Clinical Trial',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_MESH_TERMS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
		    return false;
		}	
	}	
	
	/**
	 * saves journalName and returns id of that, if the name already exist it will returns the id of that name
	 * @param string $journalName
	 * @return Integer, journalID 
	 */
	function saveStatus($statusName){
		$statusId='';
		$arrStatus['status']=$statusName;
		$this->db->where('status',$statusName);
		$arrStatusResult=$this->db->get('cts_statuses');
		if($arrStatusResult->num_rows()!=0){
			$statusObj=$arrStatusResult->first_row();
			$statusId=$statusObj->id;		
		}
		else {
			if($this->db->insert('cts_statuses',$arrStatus)){
				$statusId=$this->db->insert_id();	      		
	      	}else{	      		
	      		return false;
	      	}
		}
		return $statusId;
	}

	/**
	 * Saves the Investigator record and returns the id of last inserted record
	 * @param $investigator
	 * @return unknown_type
	 */
	function saveInvestigator($investigator){
		$investigatorId='';
		if($this->db->insert('cts_investigators',$investigator)){
			$investigatorId=$this->db->insert_id();	      		
		}else{
		    
		}
		return $investigatorId;
	}
	
	function saveCtInvestigator($ctInvestigator){
		if($this->db->insert('ct_investigators',$ctInvestigator)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Investigator to Clinical Trial',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_INVESTIGATORS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;	      		
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Investigator to Clinical Trial',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_INVESTIGATORS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
		    return false;
		}	
	}
	
	/**
	 * returns the list of Clinical Trials belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 */
	function listClinicalTrialsDetails($kolId,$limit=null,$startFrom=null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
		$this->db->from('clinical_trials');
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->where('kol_id', $kolId);
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		if($limit != null)
			$this->db->limit($limit,$startFrom);
		
		$this->db->where('is_verified', 1);
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get();
		//echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
	
	/**
	 * Deletes the Association between Kol and Clinical Trials
	 * @param $pubId
	 * @return unknown_type
	 */
	function deleteClinicalTrial($ctsId){
		$this->db->where('cts_id', $ctsId);
		if($this->db->delete('kol_clinical_trials')){
			return true;
		}else{
			return false;
		} 
	}
	
	/**
	 * Updates kol as Clinical Trial processed by setting 'is_clinical_trial_processed' to 1
	 * @param  $arrKolDetail
	 * @return unknown_type
	 */
	function updateClinicalTrialProcessedKol($arrKolDetail){
		$kolDetail['is_clinical_trial_processed']=	$arrKolDetail['is_clinical_trial_processed'];	
		$this->db->where('id', $arrKolDetail['id']);		
		$this->db->update('kols', $kolDetail);		
	}
	
	function checkKolCTAssociationExist($kolClinicalTrial){
		$this->db->where('kol_id',$kolClinicalTrial['kol_id']);
		$this->db->where('cts_id',$kolClinicalTrial['cts_id']);
		$arrCTAssoc=$this->db->get('kol_clinical_trials');
		if($arrCTAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	
	function getStatusNameById($statusId){
		$statusName='';		
		$this->db->where('id',$statusId);
		$arrStatuses=$this->db->get('cts_statuses');
		if($arrStatuses->num_rows()!=0){
			$statusObj=$arrStatuses->first_row();
			$statusName=$statusObj->status;		
		}
		else {
			
		}
		return $statusName;
	}
	
	function listCTSponsors($ctId){
		$arrSponsors=array();
		$this->db->select('cts_sponsers.*');
		$this->db->from('cts_sponsers');
		$this->db->join('ct_sponsers', 'ct_sponsers.sponser_id = cts_sponsers.id','left');
		$this->db->where('type', 'lead sponsor');
		$this->db->where('cts_id', $ctId);
		$arrSponsorsResult = $this->db->get();
		foreach($arrSponsorsResult->result_array() as $row){
				$arrSponsors[]=$row;
		}
		return 	$arrSponsors;
	}	
	
	function listCTInterventions($ctId){
		$arrInterventions=array();
		$this->db->select('cts_interventions.*');
		$this->db->from('cts_interventions');
		$this->db->join('ct_interventions', 'ct_interventions.intervention_id = cts_interventions.id','left');
		$this->db->where('cts_id', $ctId);		
		$arrInterventionsResult = $this->db->get();
		foreach($arrInterventionsResult->result_array() as $row){
				$arrInterventions[]=$row;
		}	
		return 	$arrInterventions;
	}
	
	function listCTIKeyWords($ctId){
		$arrKeyWords=array();
		$this->db->select('cts_keywords.*');
		$this->db->from('cts_keywords');
		$this->db->join('ct_keywords', 'ct_keywords.keyword_id = cts_keywords.id','left');
		$this->db->where('cts_id', $ctId);		
		$arrKeyWordsResult = $this->db->get();
		foreach($arrKeyWordsResult->result_array() as $row){
				$arrKeyWords[]=$row;
		}	
		return 	$arrKeyWords;
	}	
	
	function listCTMeshTerms($ctId){
		$arrMeshTerms=array();
		$this->db->select('cts_mesh_terms.*');
		$this->db->from('cts_mesh_terms');
		$this->db->join('ct_mesh_terms', 'ct_mesh_terms.term_id = cts_mesh_terms.id','left');
		$this->db->where('cts_id', $ctId);		
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
				$arrMeshTerms[]=$row;
		}	
		return 	$arrMeshTerms;
	}	
	
	function getClinicalTrial($ctId){
		$clinicalTrial=array();
		$this->db->where('id',$ctId);
		$clinicalTrial=$this->db->get('clinical_trials');
		$clinicalTrial=$clinicalTrial->row_array();
		return 	$clinicalTrial;
	}
	
	function listCTInvestigators($ctId){
		$arrInvestigators=array();
		$this->db->select('cts_investigators.*');
		$this->db->from('cts_investigators');
		$this->db->join('ct_investigators', 'ct_investigators.investigator_id = cts_investigators.id','left');
		$this->db->where('cts_id', $ctId);		
		$arrInvestigatorsResult = $this->db->get();
		foreach($arrInvestigatorsResult->result_array() as $row){
				$arrInvestigators[]=$row;
		}	
		return 	$arrInvestigators;
	}
	
	/**
	 * Get the Trials search details for the passed fields
	 * @author 	Ambarish N
	 * @since	2.4
 	 * @created 07-06-2011
	 * @param unknown_type $keyword
	 * @return unknown_type
	 */
	function getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrTrials = array();
			$this->db->select(array('clinical_trials.id','clinical_trials.trial_name','clinical_trials.condition','cts_interventions.name as interventions','cts_sponsers.agency as sponsors'));
			
			if($keyword !='')
				$this->db->like('trial_name',$keyword);
		//	$this->db->order_by('trial_name');
			
			$this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
			$this->db->join('cts_sponsers','ct_sponsers.sponser_id=cts_sponsers.id', 'left');
			
			$this->db->join('ct_interventions','ct_interventions.cts_id=clinical_trials.id', 'left');
			$this->db->join('cts_interventions','ct_interventions.intervention_id=cts_interventions.id', 'left');
		//	$this->db->group_by('clinical_trials.id');
		
			//Advance search fields
			if($arrAdvSearchFields['interventions'] !=''){
				$this->db->like('name', $arrAdvSearchFields['interventions']);	
			}
			
			if($arrAdvSearchFields['sponsors'] !=''){
				$this->db->like('agency',$arrAdvSearchFields['sponsors']);
			}
			
			if($arrAdvSearchFields['condition'] !=''){
				$this->db->like('condition',$arrAdvSearchFields['condition']);
			}
			
			if($arrAdvSearchFields['investigators'] !='' || $arrFilterFields['investigator']!='' || $groupByCategory=='investigator'){
				$this->db->join('ct_investigators', 'ct_investigators.cts_id = clinical_trials.id','left');
				$this->db->join('cts_investigators', 'ct_investigators.investigator_id = cts_investigators.id','left');
				
				if($arrAdvSearchFields['investigators'] !=''){
					$this->db->like('last_name',$arrAdvSearchFields['investigators']);
				}
			}
			
			if($arrAdvSearchFields['mesh_term'] !='' || $arrFilterFields['meshterm']!='' || $groupByCategory=='meshterm'){	
				$this->db->join('ct_mesh_terms', 'ct_mesh_terms.cts_id = clinical_trials.id','left');
				$this->db->join('cts_mesh_terms', 'ct_mesh_terms.term_id = cts_mesh_terms.id','left');
			
				if($arrAdvSearchFields['mesh_term'] !=''){
					$this->db->like('term_name',$arrAdvSearchFields['mesh_term']);
				}
			}
		
			//Filter fields
			if($arrFilterFields!=null && $arrFilterFields['condition']!='' && isset($arrFilterFields['condition']) && sizeof($arrFilterFields['condition'])>0 && !($doGroupBy==true && $groupByCategory=='condition'))
				$this->db->where_in('clinical_trials.condition', $arrFilterFields['condition']);
			if($arrFilterFields!=null && $arrFilterFields['sponsor']!='' && isset($arrFilterFields['sponsor']) && sizeof($arrFilterFields['sponsor'])>0 && !($doGroupBy==true && $groupByCategory=='sponsor'))
				$this->db->where_in('agency', $arrFilterFields['sponsor']);
			if($arrFilterFields!=null && $arrFilterFields['intervention']!='' && isset($arrFilterFields['intervention']) && sizeof($arrFilterFields['intervention'])>0 && !($doGroupBy==true && $groupByCategory=='intervention'))
				$this->db->where_in('name', $arrFilterFields['intervention']);
			if($arrFilterFields!=null && $arrFilterFields['meshterm']!='' && isset($arrFilterFields['meshterm']) && sizeof($arrFilterFields['meshterm'])>0 && !($doGroupBy==true && $groupByCategory=='meshterm'))
				$this->db->where_in('term_name', $arrFilterFields['meshterm']);
			if($arrFilterFields!=null && $arrFilterFields['investigator']!='' && isset($arrFilterFields['investigator']) && sizeof($arrFilterFields['investigator'])>0 && !($doGroupBy==true && $groupByCategory=='investigator'))
				$this->db->where_in('last_name', $arrFilterFields['investigator']);
			
			if($doCount){
				$arrTrialDetailsResult=$this->db->get('clinical_trials');
				foreach($arrTrialDetailsResult->result_array() as $row){
					$arrTrials[]=$row;
				}	
				return sizeof($arrTrials);
				//$this->db->distinct();
				//$count=$this->db->count_all_results('clinical_trials');
				//return $count;
			}
			else{
				if($doGroupBy){
					if($groupByCategory=='condition'){
						$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
						$this->db->group_by('clinical_trials.condition');
						//$this->db->where('country IS NOT NULL');
					}
					if($groupByCategory=='sponsor'){
						$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
						$this->db->group_by('agency');
						//$this->db->where('country IS NOT NULL');
					}
					if($groupByCategory=='intervention'){
						$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
						$this->db->group_by('name');
					}
					if($groupByCategory=='meshterm'){
						$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count,cts_mesh_terms.term_name as meshterm');
						$this->db->group_by('term_name');
						//$this->db->where('country IS NOT NULL');
					}
					if($groupByCategory=='investigator'){
						$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count,cts_investigators.last_name as investigator');
						$this->db->group_by('last_name');
						//$this->db->where('country IS NOT NULL');
					}
					
					$this->db->order_by('count','desc');
				}
				else
					$this->db->limit($limit, $startFrom);
					
				$arrTrialDetailsResult=$this->db->get('clinical_trials');
				foreach($arrTrialDetailsResult->result_array() as $row){
					$arrTrials[]=$row;
				}	
				return $arrTrials;
			}
		return $arrTrials;
	}
	
	/**
	 * Get the Advance search details with Like option for all fileds if its not empty
	 * @author 	Ambarish N
	 * @since	2.4
 	 * @created 07-06-2011
	 * @param $arrAdvSearchFields
	 * @return unknown_type
	 */
	function getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrTrials = array();
		
		$this->db->join('ct_interventions','ct_interventions.cts_id=clinical_trials.id', 'left');
		$this->db->join('cts_interventions','ct_interventions.intervention_id=cts_interventions.id', 'left');
		
		$this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
		$this->db->join('cts_sponsers','ct_sponsers.sponser_id=cts_sponsers.id', 'left');
		
		if($arrAdvSearchFields['interventions'] !=''){
			$this->db->like('name', $arrAdvSearchFields['interventions']);	
		}
		
		if($arrAdvSearchFields['sponsors'] !=''){
			$this->db->like('agency',$arrAdvSearchFields['sponsors']);
		}
		
		if($arrAdvSearchFields['condition'] !=''){
			$this->db->like('condition',$arrAdvSearchFields['condition']);
		}
		if($arrAdvSearchFields['investigators'] !='' || $arrFilterFields['investigator']!='' || $groupByCategory=='investigator'){
			$this->db->join('ct_investigators', 'ct_investigators.cts_id = clinical_trials.id','left');
			$this->db->join('cts_investigators', 'ct_investigators.investigator_id = cts_investigators.id','left');
			
			if($arrAdvSearchFields['investigators'] !=''){
				$this->db->like('last_name',$arrAdvSearchFields['investigators']);
			}
		}
		
		if($arrAdvSearchFields['mesh_term'] !='' || $arrFilterFields['meshterm']!='' || $groupByCategory=='meshterm'){	
			$this->db->join('ct_mesh_terms', 'ct_mesh_terms.cts_id = clinical_trials.id','left');
			$this->db->join('cts_mesh_terms', 'ct_mesh_terms.term_id = cts_mesh_terms.id','left');
		
			if($arrAdvSearchFields['mesh_term'] !=''){
				$this->db->like('term_name',$arrAdvSearchFields['mesh_term']);
			}
		}
		if(!$doCount)
			$this->db->select(array('clinical_trials.id','clinical_trials.trial_name','clinical_trials.condition','cts_interventions.name as interventions','cts_sponsers.agency as sponsors'));

		//	$this->db->order_by('trial_name');
		if(!$doGroupBy)
			$this->db->group_by('clinical_trials.ct_id');
	
		//Filter fields
		if($arrFilterFields!=null && $arrFilterFields['condition']!='' && isset($arrFilterFields['condition']) && sizeof($arrFilterFields['condition'])>0 && !($doGroupBy==true && $groupByCategory=='condition'))
			$this->db->where_in('clinical_trials.condition', $arrFilterFields['condition']);
		if($arrFilterFields!=null && $arrFilterFields['sponsor']!='' && isset($arrFilterFields['sponsor']) && sizeof($arrFilterFields['sponsor'])>0 && !($doGroupBy==true && $groupByCategory=='sponsor'))
			$this->db->where_in('agency', $arrFilterFields['sponsor']);
		if($arrFilterFields!=null && $arrFilterFields['intervention']!='' && isset($arrFilterFields['intervention']) && sizeof($arrFilterFields['intervention'])>0 && !($doGroupBy==true && $groupByCategory=='intervention'))
			$this->db->where_in('name', $arrFilterFields['intervention']);
		if($arrFilterFields!=null && $arrFilterFields['meshterm']!='' && isset($arrFilterFields['meshterm']) && sizeof($arrFilterFields['meshterm'])>0 && !($doGroupBy==true && $groupByCategory=='meshterm'))
			$this->db->where_in('term_name', $arrFilterFields['meshterm']);
		if($arrFilterFields!=null && $arrFilterFields['investigator']!='' && isset($arrFilterFields['investigator']) && sizeof($arrFilterFields['investigator'])>0 && !($doGroupBy==true && $groupByCategory=='investigator'))
			$this->db->where_in('last_name', $arrFilterFields['investigator']);
		
		if($doCount){
			$arrTrialDetailsResult=$this->db->get('clinical_trials');
			
			foreach($arrTrialDetailsResult->result_array() as $row){
					$arrTrials[]=$row;
				}	
				return sizeof($arrTrials);
//			$resultRow=$arrTrialDetailsResult->row();
//			$count=$resultRow->count;
//			
//			return $count;
				//$this->db->distinct();
				//$count=$this->db->count_all_results('clinical_trials');
				//return $count;
		}
		else{
			if($doGroupBy){
				if($groupByCategory=='condition'){
					$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
					$this->db->group_by('clinical_trials.condition');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='sponsor'){
					$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
					$this->db->group_by('agency');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='intervention'){
					$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count');
					$this->db->group_by('name');
				}
				if($groupByCategory=='meshterm'){
					$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count,cts_mesh_terms.term_name as meshterm');
					$this->db->group_by('term_name');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='investigator'){
					$this->db->select('COUNT(DISTINCT clinical_trials.ct_id) as count,cts_investigators.last_name as investigator');
					$this->db->group_by('last_name');
					//$this->db->where('country IS NOT NULL');
				}
				$this->db->order_by('count','desc');
			}
			else
				$this->db->limit($limit, $startFrom);
			$arrTrialDetailsResult=$this->db->get('clinical_trials');
			//echo $this->db->last_query();
			foreach($arrTrialDetailsResult->result_array() as $row){
					$arrTrials[]=$row;
			}	
			return $arrTrials;
		}
	}
	
	/**
	 * Get the Basic Filter details. Using Like option with Anding for all fileds if its not empty
	 * 
	 * @param $arrFilterSearchFields
	 * @return unknown_type
	 */
	function getFilterSearchMatchingTrials($arrFilterSearchFields,$limit,$startFrom,$doCount){
		$arrTrials = array();
		
		if($arrFilterSearchFields['keyword'] !=''){
			$this->db->like('trial_name', $arrFilterSearchFields['keyword']);	
		}
		
		if($arrFilterSearchFields['interventions'] !=''){
			$this->db->like('name', $arrFilterSearchFields['interventions']);	
		}
		
		if($arrFilterSearchFields['sponsors'] !=''){
			$this->db->like('agency',$arrFilterSearchFields['sponsors']);
		}
		
		if($arrFilterSearchFields['condition'] !=''){
			$this->db->like('condition',$arrFilterSearchFields['condition']);
		}
		
		if($arrFilterSearchFields['investigators'] !=''){
			$this->db->join('ct_investigators', 'ct_investigators.cts_id = clinical_trials.id','left');
			$this->db->join('cts_investigators', 'ct_investigators.investigator_id = cts_investigators.id','left');
			
			$this->db->like('last_name',$arrFilterSearchFields['investigators']);
		}
		
			
		if($arrFilterSearchFields['mesh_term'] !=''){
			$this->db->join('ct_mesh_terms', 'ct_mesh_terms.cts_id = clinical_trials.id','left');
			$this->db->join('cts_mesh_terms', 'ct_mesh_terms.term_id = cts_mesh_terms.id','left');
			
			$this->db->like('term_name',$arrFilterSearchFields['mesh_term']);
		}
		
		$this->db->select(array('clinical_trials.id','clinical_trials.trial_name','clinical_trials.condition','cts_interventions.name as interventions','cts_sponsers.agency as sponsors'));
		
		$this->db->join('ct_interventions','ct_interventions.cts_id=clinical_trials.id', 'left');
		$this->db->join('cts_interventions','ct_interventions.intervention_id=cts_interventions.id', 'left');
		
		$this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
		$this->db->join('cts_sponsers','ct_sponsers.sponser_id=cts_sponsers.id', 'left');
		$this->db->order_by('trial_name');
		$this->db->group_by('trial_name');
		if($doCount){
			$arrTrialDetailsResult=$this->db->get('clinical_trials');
			foreach($arrTrialDetailsResult->result_array() as $row){
				$arrTrials[]=$row;
			}	
			return sizeof($arrTrials);
			/*
			$this->db->distinct();
			$count=$this->db->count_all_results('clinical_trials');
			return $count;
			*/
		}
		else{
			$this->db->limit($limit, $startFrom);
			$arrTrialDetailsResult=$this->db->get('clinical_trials');
			foreach($arrTrialDetailsResult->result_array() as $row){
				$arrTrials[]=$row;
			}	
			return $arrTrials;
		}
	}
	
	function getCTInterventionsName($interventionName){
		$arrInterventions=array();
		$this->db->select('name');
		$this->db->from('cts_interventions');
		$this->db->like('name', $interventionName);
		$arrInterventionsResult = $this->db->get();
		foreach($arrInterventionsResult->result_array() as $row){
				$arrInterventions[]=$row['name'];
		}	
		return 	$arrInterventions;
	}
	
	function getCTConditionName($conditionName){
		$arrCondition=array();
		$this->db->select('condition');
		$this->db->from('clinical_trials');
		$this->db->like('condition', $conditionName);
		$arrConditionResult = $this->db->get();
		foreach($arrConditionResult->result_array() as $row){
				$arrCondition[]=$row['condition'];
		}	
		return 	$arrCondition;
	}
	
	function getCTInvestigatorsName($investigatorsName){
		$arrInvestigators=array();
		$this->db->select('last_name');
		$this->db->from('cts_investigators');
		$this->db->like('last_name', $investigatorsName);
		$arrInvestigatorsResult = $this->db->get();
		foreach($arrInvestigatorsResult->result_array() as $row){
				$arrInvestigators[]=$row['last_name'];
		}	
		return 	$arrInvestigators;
	}
	
	function getCTMeshTermsName($meshTermName){
		$arrMeshTerms=array();
		$this->db->select('term_name');
		$this->db->from('cts_mesh_terms');
		$this->db->like('term_name', $meshTermName);
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
				$arrMeshTerms[]=$row['term_name'];
		}	
		return 	$arrMeshTerms;
	}
	
	function getCTSponsorsName($sponsorsName){
		$arrSponsorsName=array();
		$this->db->select('agency');
		$this->db->from('cts_sponsers');
		$this->db->like('agency', $sponsorsName);
		$arrSponsorsNameResult = $this->db->get();
		foreach($arrSponsorsNameResult->result_array() as $row){
				$arrSponsorsName[]=$row['agency'];
		}	
		return 	$arrSponsorsName;
	}
	
	/**
	 * Retrives the all the Trials Or Count of Trials which matches the given parameters, for each parameter it does AND operation, 
	 * if the parameter is an 'Array' it does or with in that 
	 * @author 	Ramesh B
	 * @Created on: 10-03-11
	 * @since	1.5.1
	 * @return Array
	 */
	function getTrialsByParam($fromYear, $toYear,$arrKolIds=0,$arrCountries=0,$arrSpecialties=0,$groupBy=0,$arrListNamesIds=0,$arrStates=0,$arrProfileType='',$viewType, $arrGlobalRegionIds = 0, $analystSelectedClientId = 0){  
		$arrTrials=array();
		$isKolsJoined=false;
		$isPubsJoined=false;
		//Adding where condition for KOL Id's if Exist
		if(is_array($arrKolIds)){
			$this->db->where_in('kol_clinical_trials.kol_id',$arrKolIds);
		}else if($arrKolIds!=0){
			$this->db->where('kol_clinical_trials.kol_id',$arrKolIds);
		}
		
		//Adding where condition for Gobal Region's if Exist
		if (is_array($arrGlobalRegionIds)) {
			$this->db->join('kols', 'kols.id=kol_clinical_trials.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join('kols', 'kols.id=kol_clinical_trials.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->join('countries','kols.country_id=countries.countryId','left');			
			$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
		}
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries)){
			if(!$isKolsJoined)
			$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.country_id',$arrCountries);
		}else if($arrCountries!=0){
			if(!$isKolsJoined)
			$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.country_id',$arrCountries);
		}
		
		if(is_array($arrStates)){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.state_id',$arrStates);
		}else if($arrStates!=0){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.state_id',$arrStates);
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialties)){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.specialty',$arrSpecialties);
		}else if($arrSpecialties!=0){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.specialty',$arrSpecialties);
		}
		
		if($fromYear!=0 && $toYear!=0){
			if(!$isPubsJoined)
				$this->db->join('clinical_trials','clinical_trials.id=kol_clinical_trials.cts_id','left');
			$isPubsJoined=true;
			$wherBetween="(SUBSTR(clinical_trials.start_date, -4) BETWEEN $fromYear AND $toYear OR SUBSTR(clinical_trials.start_date, -4)='' or SUBSTR(clinical_trials.start_date, -4) is null)";
			$this->db->where($wherBetween);
		}
		
		//Adding Group by based param $groupBy
		if((string)$groupBy=="year"){
			$this->db->select('SUBSTR(clinical_trials.start_date, -4) AS year, COUNT(SUBSTR(clinical_trials.start_date, -4)) AS count');
			$this->db->group_by('YEAR(clinical_trials.created_date)');
			//echo $groupBy;
		}else if((string)$groupBy=='kolId'){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_clinical_trials.kol_id','left');
			$isKolsJoined=true;
			$this->db->select('kols.id as kol_id,kols.salutation,kols.last_name,kols.middle_name,kols.first_name, COUNT(kol_clinical_trials.kol_id) AS count');
			$this->db->group_by('kol_clinical_trials.kol_id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else {
			if(!$isPubsJoined)
				$this->db->join('clinical_trials','clinical_trials.id=kol_clinical_trials.cts_id','left');
			$isPubsJoined=true;
			$this->db->select('publications.*');
			//echo 'No Grouping';
		}
		
		if($arrListNamesIds!='' && $arrListNamesIds!=0){
	 		$userId   =$this->session->userdata('user_id');
	 		$clientId =$this->session->userdata('client_id');
	 		$this->db->join('list_kols','list_kols.kol_id=kol_clinical_trials.kol_id','left');
	 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
	 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
	 		$this->db->where_in('list_names.id',$arrListNamesIds);
	 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
	 	}
	 	if ($arrProfileType != ''){
	 	    if($arrProfileType == DISCOVERY){
	 	        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
	 	    }else{
	 	        $this->db->where('kols.profile_type', $arrProfileType);
	 	        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
	 	    }
	 	    //             $this->db->where('kols.profile_type', $arrProfileType);
	 	}else{
	 	    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
	 	}
	 	$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		if(isset($viewType) && sizeof($viewType) > 0){
			$this->db->where_in('kols.id',$viewType);
		}
	 	//$this->db->where('kols.status',COMPLETED);
	 	$this->db->where('kol_clinical_trials.is_verified',1);
	 	
	 	if($analystSelectedClientId != null || $analystSelectedClientId > 0){
        		$client_id = $analystSelectedClientId;
        	}else{
        		$client_id = $this->session->userdata('client_id');
        }
	 	if($client_id !== INTERNAL_CLIENT_ID){
	 		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
	 		$this->db->where('kols_client_visibility.client_id', $client_id);
	 	}
	 	 
		$arrTrialsResults=$this->db->get('kol_clinical_trials');
		foreach($arrTrialsResults->result_array() as $row){
			$arrTrials[]=$row;
		}
		//echo $this->db->last_query();exit;
		return $arrTrials;
	}
	
	
   	/**
	 * Updates the Manual Clinical Trial Detail Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updateClinicalTrialManual($arrClinicalTrial){
		$this->db->where('id',$arrClinicalTrial['id']);
		if($this->db->update('clinical_trials',$arrClinicalTrial)){
			return true;
		}else{
			return false;
		}
	}
	
	
	 /**
	 * Updates the Manual Clinical Trial Particular Sponcers Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updateCtSponcers($arrClinicalTrial){
		if($this->db->query("update clinical_trials 
							LEFT JOIN ct_sponsers ON clinical_trials.id=ct_sponsers.cts_id
							LEFT JOIN cts_sponsers ON cts_sponsers.id=ct_sponsers.sponser_id
							set cts_sponsers.agency='".$arrClinicalTrial['agency']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_sponsers.id=".$arrClinicalTrial['sponsorId'])){
			return true;
		}else{
			return false;
		}
	}
	
	function updateCtKeyword($existingKeywordId,$arrAssociateKeyword){
		if($this->db->query("update ct_keywords 
							set keyword_id='".$arrAssociateKeyword['keyword_id']."'
							WHERE cts_id=".$arrAssociateKeyword['cts_id']." and keyword_id=".$existingKeywordId)){
			return true;
		}else{
			return false;
		}
		
	}
	
	function UpdateCtMeshterms($existingTermId,$arrAssociateMeshTerm){
		if($this->db->query("update ct_mesh_terms 
							set term_id='".$arrAssociateMeshTerm['term_id']."'
							WHERE cts_id=".$arrAssociateMeshTerm['cts_id']." and term_id=".$existingTermId)){
			return true;
		}else{
			return false;
		}
	}
	
	 /**
	 * Updates the Manual Clinical Trial Particular Intervention Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updateCtIntervention($arrClinicalTrial){
		if($this->db->query("update clinical_trials 
							LEFT JOIN ct_interventions ON clinical_trials.id=ct_interventions.cts_id
							LEFT JOIN cts_interventions ON cts_interventions.id=ct_interventions.intervention_id
							set cts_interventions.name='".$arrClinicalTrial['name']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_interventions.id=".$arrClinicalTrial['interventionId'])){
			return true;
		}else{
			return false;
		}
	}
	
	 /**
	 * Updates the Manual Clinical Trial Particular Investigator Data  
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updateCtInvestigator($arrClinicalTrial){
		if($this->db->query("update clinical_trials 
							LEFT JOIN ct_investigators ON clinical_trials.id=ct_investigators.cts_id
							LEFT JOIN cts_investigators ON cts_investigators.id=ct_investigators.investigator_id
							set cts_investigators.last_name='".$arrClinicalTrial['last_name']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_investigators.id=".$arrClinicalTrial['investigatorId'])){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Generates 'CT_ID' automaticaly Based on max 'autoIncrementId' plus 0ne
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function getManualCtid(){
		$ctid='';
		$this->db->select('max(id) as ctId');
		$returndPmid=$this->db->get('clinical_trials');
		if($returndPmid->num_rows() == 0){
			$ctid = 'MANCT1';
		}else{
			foreach($returndPmid->result_array() as $arrRow){
				$ctid = 'MANCT'.($arrRow['ctId'] + 1);
			}
		}
		return $ctid;
	}
	
	/**
	 * Saves the array of Sponsers one by one
	 * @param Array $arrSponsers
	 * @param Integer $ctId
	 * @return boolean
	 */
	function saveSponsers($arrSponsers, $ctId){
		$isSaved=false;	
		foreach($arrSponsers as $sponser){
			if(!isset($sponser['type']) || empty($sponser['type'])){
				$sponser['type']	= 'lead sponsor';
			}
			$sponserId=$this->saveSponser($sponser);
			
			$ctSponcer=array();
			$ctSponcer['cts_id']=$ctId;
			$ctSponcer['sponser_id']=$sponserId;
			
			$isSaved=$this->saveCtSponser($ctSponcer);
		}
		return $isSaved;
	}
	
	function saveInvestigators($arrInvestigators, $ctId){
		$isSaved=false;	
		foreach($arrInvestigators as $investigator){			
			$investigatorId=$this->saveInvestigator($investigator);
			
			$ctInvestigator=array();
			$ctInvestigator['cts_id']=$ctId;
			$ctInvestigator['investigator_id']=$investigatorId;
			
			$isSaved=$this->saveCtInvestigator($ctInvestigator);
		}
		return $isSaved;
	}
	
		/**
	 * Saves the Clinical Trials and returns the id of it
	 * @param Array $ctDetails
	 * @param Integer $kolId
	 * @return Integer $ctId
	 */
	function saveClinicalTrialsManualAndFlags($ctDetails, $kolId){					
		//save the Clinical Trials and get the Clinical Trials id
		$ctId=$this->saveClinicalTrials($ctDetails);		
		//prepare the kol-to-Clinical Trials association object
		$kolClinicalTrials=array();
		$kolClinicalTrials['kol_id']=$kolId;
		$kolClinicalTrials['cts_id']=$ctId;
	//	$client_id = $this->session->userdata('client_id');	
	//	$kolClinicalTrials['user_id'] = $this->session->userdata('user_id');	
		//For manual saving Cliend id is logged client id and its verified
	//	if(isset($client_id) && $client_id != ''){
	//		$kolClinicalTrials['client_id'] = $client_id;
	//	}else{
			$kolClinicalTrials['is_deleted']='0';
			$kolClinicalTrials['is_verified']='1';
			$kolClinicalTrials['client_id'] = INTERNAL_CLIENT_ID;
			$kolClinicalTrials['user_id'] = INTERNAL_USER_ID;
	//	}
		//save the kol-to-Clinical Trials record
	//	if(!$this->checkKolCTAssociationExist($kolClinicalTrials))
			$isSaved=$this->saveKolClinicalTrials($kolClinicalTrials);
		//return the Clinical Trials Id	
		return $ctId;
	}	
	
	/**
	 * Saves the array of Intervention one by one
	 * 
	 * @param Array $arrIntervention
	 * @param Integer $ctId
	 * @return boolean
	 */
	function saveInterventions($arrIntervention, $ctId){
		$isSaved=false;	
		foreach($arrIntervention as $intervention){			
			$interventionId=$this->saveIntervention($intervention);
			
			$ctIntervention=array();
			$ctIntervention['cts_id']=$ctId;
			$ctIntervention['intervention_id']=$interventionId;
			
			$isSaved=$this->saveCtIntervention($ctIntervention);
		}
		return $isSaved;
	}
	
	/**
	 * Check whether the Clinical trial with CTID exist or not if exist it removes it from array and 
	 * get's the Clinical Trial Id of that and associates it with kol
	 * @param $arrUniqueCTIDs
	 * @param $kolId
	 * @return unknown_type
	 */
	function checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId){
		$arrCount=sizeof($arrUniqueCTIDs);
		for($i=0;$i<$arrCount; $i++){
			$nctId=$arrUniqueCTIDs[$i];
			$ctId=$this->checkClinicalTrialExist($nctId);
			if($ctId!=''){
				$kolClinicalTrial=array();
				$kolClinicalTrial['kol_id']=$kolId;
				$kolClinicalTrial['cts_id']=$ctId;
				//	$kolClinicalTrial['is_deleted']=0;
				//Save the association only if it is not exist	
				if(!$this->checkKolCTAssociationExist($kolClinicalTrial)){		
					$isSaved=$this->saveKolClinicalTrials($kolClinicalTrial);
				}
				unset($arrUniqueCTIDs[$i]);
			}
		}
		$arrUniqueCTIDs=array_values($arrUniqueCTIDs);
		//pr($arrUniqueCTIDs);
		return $arrUniqueCTIDs;
	}
	
	/**
	 * Deletes the Association between Kol and Clinical Trial for the passed KOL id
	 * @author 	Ambarish N
	 * @since	2.6
	 * @return 
	 * @created July-19-2011
	 * 
	 * @param $kolId
	 * @return unknown_type
	 */
	function deleteTrialsByKolId($kolId){
		if(is_array($kolId)){
			$this->db->where_in('kol_id',$kolId);	
		}else{
			$this->db->where('kol_id',$kolId);	
		}
		if($this->db->delete('kol_clinical_trials')){
			return true;
		}else{
			return false;
		} 
	}
	
	/**
	 * Returns the Co-Trialled Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	3.6
	 * @return Array
	 * @created 20-12-2011
	 */
	function getCoTrialledKols($arrKolIds=null){
		//Old Querry
		$arrKols=array();
		$this->db->select("trial2.kol_id, COUNT(kol_clinical_trials.cts_id) as count");
		$this->db->join('kol_clinical_trials as trial2','kol_clinical_trials.cts_id=trial2.cts_id','inner');
		$this->db->join('kols','trial2.kol_id = kols.id','left');
		$this->db->where('kol_clinical_trials.kol_id',$arrKolIds);
		$this->db->where('trial2.kol_id !=',$arrKolIds);
// 		$this->db->where('kols.status',COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}		
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->group_by('trial2.kol_id');
		$results=$this->db->get('kol_clinical_trials');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;
				
		/*$arrKols=array();
		$this->db->select("kol_clinical_trials.kol_id as parent_kol,trial2.kol_id, COUNT(trial2.kol_id) as count");
		$this->db->join('kol_clinical_trials as trial2','kol_clinical_trials.cts_id=trial2.cts_id','inner');
		$this->db->where('kol_clinical_trials.kol_id != trial2.kol_id');
		if($arrKolIds != null)	
			$this->db->where_in('kol_clinical_trials.kol_id',$arrKolIds);	
		$this->db->group_by('kol_clinical_trials.kol_id,trial2.kol_id');
		$results=$this->db->get('kol_clinical_trials');
		foreach($results->result_array() as $row){
			$arrKols[$row['parent_kol']][]=$row;
		}
		return $arrKols;*/
	}
	
	/**
	 * Chamges the kol pubmed processing status to given status
	 * @author 	Ramesh B 
	 * @since	1.0.7
	 * @return boolean
	 * @created 06-12-2012
	 */
	function changeKolTrialStatus($kolId, $status){
		$arrKolDetails = array();
		$arrKolDetails['is_clinical_trial_processed'] = $status;
		$this->db->where('id',$kolId);
		if($this->db->update('kols',$arrKolDetails)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update TrialStatus of the KTL',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update TrialStatus of the KTL',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return false;
		}
	}
	
	function saveCTID($pmid,$kolId){
		$arrData =array();
		$arrData['ctid'] = $pmid;
		$arrData['kol_id'] = $kolId;
		if($this->db->insert('kol_ctids',$arrData)){
			return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
     function getCTIDs($kolId){
     	$arrCTIDs = array();
     	$this->db->select('ctid');
     	$this->db->where('kol_id',$kolId);
     	$arrResults = $this->db->get('kol_ctids');
     	foreach($arrResults->result_array() as $row){
     		$arrCTIDs[] = $row['ctid'];
     	}
     	
     	return $arrCTIDs;
     }
     
     function deleteInvestigatorsAssoc($ctId,$arrInvestigatorsToExclude){
     	$this->db->where('cts_id',$ctId);
     	$this->db->where_not_in('investigator_id',$arrInvestigatorsToExclude);
     	if($this->db->delete('ct_investigators')){
			return true;
		}else{
			return false;
		} 
     }
     function deleteInterventionsAssoc($ctId,$arrInterventionToExclude){
         $this->db->where('cts_id',$ctId);
         $this->db->where_not_in('intervention_id',$arrInterventionToExclude);
         if($this->db->delete('ct_interventions')){
             return true;
         }else{
             return false;
         }
     }
     function deleteSponsersAssoc($ctId,$arrSponserToExclude){
         $this->db->where('cts_id',$ctId);
         $this->db->where_not_in('sponser_id',$arrSponserToExclude);
         if($this->db->delete('ct_sponsers')){
             return true;
         }else{
             return false;
         }
     }
     function deleteKeywordsAssoc($ctId,$arrKeywordsToExclude){
         $this->db->where('cts_id',$ctId);
         $this->db->where_not_in('keyword_id',$arrKeywordsToExclude);
         if($this->db->delete('ct_keywords')){
             return true;
         }else{
             return false;
         }
     }
     function deleteTermsAssoc($ctId,$arrTermsToExclude){
         $this->db->where('cts_id',$ctId);
         $this->db->where_not_in('term_id',$arrTermsToExclude);
         if($this->db->delete('ct_mesh_terms')){
             return true;
         }else{
             return false;
         }
     }
	function getAllInvestigatorIds(){
		$arrIds=array();
		$this->db->select('cts_investigators.id');
		$arrInvestigatorsResult = $this->db->get('cts_investigators');
		foreach($arrInvestigatorsResult->result_array() as $row){
				$arrIds[]=$row['id'];
		}	
		return 	$arrIds;
	}
	
	function getInvestigatorDetailsById($id){
		$rowData = array();
		$this->db->select('cts_investigators.*');
		$this->db->where('id',$id);
		$arrInvestigatorsResult = $this->db->get('cts_investigators');
		foreach($arrInvestigatorsResult->result_array() as $row){
			$rowData=$row;
		}	
		return 	$rowData;
	}
	
	function getInvestigatorTrialId($investigatorId){
		$trialId = '';
		$this->db->select('cts_id');
		$this->db->where('investigator_id',$investigatorId);
		$this->db->limit(1);
		$arrInvestigatorsResult = $this->db->get('ct_investigators');
		foreach($arrInvestigatorsResult->result_array() as $row){
			$trialId=$row['cts_id'];
		}	
		return 	$trialId;
	}
	
	function deleteInvestigator($investigatorId){
		$this->db->where('id',$investigatorId);
     	if($this->db->delete('cts_investigators')){
			return true;
		}else{
			return false;
		} 
	}
	
	function deleteInvestigatorAssociation($investigatorId,$ctsId){
		$this->db->where('cts_id',$ctsId);
     	$this->db->where('investigator_id',$investigatorId);
     	if($this->db->delete('ct_investigators')){
			return true;
		}else{
			return false;
		} 
	}
	
	
	function updateTrialAsVerified($id,$kolTrial){
		$this->db->where('id', $id);
     	if($this->db->update('kol_clinical_trials',$kolTrial)){
			return true;
		}else{
			return false;
		} 
	}
	
	/**
	 * Returns the list of Clinical Trials by type
	 * @param $kolId
	 * @return unknown_type
	 */
	function listClinicalTrialsDetailsByType($kolId,$type = null,$ctsId = null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id','client_users.is_analyst','client_users.first_name','client_users.last_name','kol_clinical_trials.data_type_indicator'));
		$this->db->from('clinical_trials');
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->join('client_users', 'client_users.id = kol_clinical_trials.user_id','left');
		$this->db->where('kol_id', $kolId);
		
		//used for getting data for editing
		if($ctsId != 0){
			$this->db->where('clinical_trials.id', $ctsId);
		}
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
			
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get();
		//pr($this->db->last_query());exit;
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
	
	function deleteMeshTermOfTrialAssociation($id){
		$this->db->where('cts_id',$id);
		$this->db->delete('ct_mesh_terms');
		
	}
	
	function deleteKeywordsOfTrialAssociation($id){
		$this->db->where('cts_id',$id);
		$this->db->delete('ct_keywords');
		
	}
	
	function deleteInterventionsOfTrialAssociation($id){
		$this->db->where('cts_id',$id);
		$this->db->delete('ct_interventions');
		
	}
	
	function deleteSponsersOfTrialAssociation($id){

		$this->db->where('cts_id',$id);
		$this->db->delete('ct_sponsers');
	}
	function updateAlreadyExistClinicalTrials($arrDataToUpdate){
		$nctId	= $arrDataToUpdate['ct_id'];
		if($nctId!=''){
			$this->db->where('ct_id', $nctId);
			unset($arrDataToUpdate['ct_id']);
	     	if($this->db->update('clinical_trials',$arrDataToUpdate)){
				return true;
			}else{
				return false;
			}
		}
		return false;
	}
		
 
	function deleteClientClinicalTrial($ctsId){
		$this->db->select('kol_id');
		$this->db->where('cts_id',$ctsId);
		$queryRes = $this->db->get('kol_clinical_trials');
		$row = $queryRes->row();
		if (isset($row))
		{
			if($row->kol_id > 0){
				$transactionName = 'Delete Clinical trails';
				$kol_org_type = 'Kol';
				$kols_or_org_id = $row->kol_id;
				$parentObjectId = $row->kol_id;
			}
		}
		$this->db->where('cts_id', $ctsId);
		if($this->db->delete('kol_clinical_trials')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $ctsId,
					'transaction_table_id' => KOL_CLINICAL_TRIALS,
					'transaction_name' =>$transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_FAIL,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $ctsId,
					'transaction_table_id' => KOL_CLINICAL_TRIALS,
					'transaction_name' => $transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		} 
	}
	
	function getKolAllProjectCtids($kolId){
		$arrData = array();
		$this->db->select('ctid,project_id');
		$this->db->where('kol_id',$kolId);
		$res = $this->db->get('kol_ctids');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['project_id']][] = $row['ctid'];
			}
		}
		return $arrData;
	}

function getUnprocessedTrials($processedOrUnprocessed){
		$arrClinicalTrials=array();
		$this->db->distinct("clinical_trials.id");
		$this->db->select('clinical_trials.*');
		$this->db->join("kol_clinical_trials","kol_clinical_trials.cts_id=clinical_trials.id","left");
		$this->db->where('kol_clinical_trials.is_verified', 1);
		$this->db->from('clinical_trials');
		if($processedOrUnprocessed == 0)
			$this->db->where('is_industry_trial', $processedOrUnprocessed);
		else if($processedOrUnprocessed == 1)
			$this->db->where('is_industry_trial !=', 0);
//		$this->db->limit(100);
//		$this->db->where('kol_clinical_trials.kol_id', 711);		
		$arrClinicalTrialsResult = $this->db->get();
//		echo $this->db->last_query();
//		exit;
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
	
	function updateTrialIndustries($arrData){
		foreach ($arrData as $row){
			$this->db->where("id",$row["id"]);
			$this->db->set("is_industry_trial",$row["is_industry_trial"]);
			$this->db->update("clinical_trials");
//			echo $this->db->last_query();
		}
		return true;
	}
	
        
        /**
        * Displaying the clinicalTrial details limited to 5 only for mobile ui
        * @package application.models
        * @author Shruti Purushan
        * @since
        * @created on  17-04-2015
        */
//        function listClinicalTrialsDetailsByTypeRecent5($kolId,$type = null){
//		$roleId=$this->session->userdata('user_role_id');
//		$clientId=$this->session->userdata('client_id');
//		$arrClinicalTrials=array();
//		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
//		$this->db->from('clinical_trials');
//		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
//		$this->db->where('kol_id', $kolId);
//		
//		if($clientId!=INTERNAL_CLIENT_ID){
//			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
//		}
//		
//		if($type == null || $type == 'verified'){
//			$this->db->where('is_verified', 1);
//		}elseif ($type == 'unverified'){
//			$this->db->where('is_verified', 0);
//		}elseif ($type == 'deleted'){
//			$this->db->where('is_deleted', 1);
//		}
//                $this->db->order_by('clinical_trials.end_date','desc');       
//		$this->db->order_by('clinical_trials.start_date','desc');
//               
//                         $this->db->limit(5,0);	
//		//$this->db->where('kol_clinical_trials.is_deleted', 0);
//		$arrClinicalTrialsResult = $this->db->get();
//		
//		foreach($arrClinicalTrialsResult->result_array() as $row){
//				$arrClinicalTrials[]=$row;
//		}	
//		return 	$arrClinicalTrials;
//	}
        
        /*
         * Displaying 15 clinicalTrial details for mobile ui
         */
//	function listClinicalTrialsDetailsByTypeRecent15($kolId,$type = null){
//		$roleId=$this->session->userdata('user_role_id');
//		$clientId=$this->session->userdata('client_id');
//		$arrClinicalTrials=array();
//		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
//		$this->db->from('clinical_trials');
//		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
//		$this->db->where('kol_id', $kolId);
//		
//		if($clientId!=INTERNAL_CLIENT_ID){
//			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
//		}
//		
//		if($type == null || $type == 'verified'){
//			$this->db->where('is_verified', 1);
//		}elseif ($type == 'unverified'){
//			$this->db->where('is_verified', 0);
//		}elseif ($type == 'deleted'){
//			$this->db->where('is_deleted', 1);
//		}
//                $this->db->order_by('clinical_trials.end_date','desc');       
//		$this->db->order_by('clinical_trials.start_date','desc');
//               
//                         $this->db->limit(15,0);	
//		//$this->db->where('kol_clinical_trials.is_deleted', 0);
//		$arrClinicalTrialsResult = $this->db->get();
//		//echo $this->db->last_query();
//		foreach($arrClinicalTrialsResult->result_array() as $row){
//				$arrClinicalTrials[]=$row;
//		}	
//		return 	$arrClinicalTrials;
//	}
        
        /*
         * Displaying only 15 details at a time for lazy loading in mobile ui
         */
        function listClinicalTrialsDetailsByTypeRecent15LoadMore($kolId,$type = null,$offset){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
		$this->db->from('clinical_trials');
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->where('kol_id', $kolId);
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
                $this->db->order_by('clinical_trials.end_date','desc');       
		$this->db->order_by('clinical_trials.start_date','desc');
               
                         $this->db->limit(15,$offset);	
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get();
		//echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
        
        /*
         * To get the count of clinical_trials
         */
        function totalTrials($kolId){
            $this->db->select("count(*) as count");
            $this->db->where("kol_id",$kolId);
            $result = $this->db->get("kol_clinical_trials");
            foreach( $result->result_array() as $row){
                $total = $row["count"];
            }        
            return $total;
        }
        
        function listClinicalTrialsDetailsByTypeForIpad($kolId,$type = null,$trailDetails){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
                $this->db->select('clinical_trials.*,cts_statuses.status,group_concat(distinct cts_interventions.name) as intervention_name,group_concat(distinct cts_sponsers.agency) as sponsor,kol_clinical_trials.kol_id',false);
		//$this->db->from('clinical_trials');
                $this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id=clinical_trials.id','left');
		$this->db->join('cts_statuses', 'cts_statuses.id = clinical_trials.status_id','left');
                $this->db->join('ct_interventions','ct_interventions.cts_id = clinical_trials.id','left');
                $this->db->join('cts_interventions','cts_interventions.id = ct_interventions.intervention_id','left');
                $this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
                $this->db->join('cts_sponsers','cts_sponsers.id = ct_sponsers.sponser_id','left');
		$this->db->where('kol_clinical_trials.kol_id', $kolId);
              
//		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
//		$this->db->from('clinical_trials');
//		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
//		$this->db->where('kol_id', $kolId);
//		echo $this->db->last_query();
		
		 
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
//                pr($trailDetails['start']);
                if($trailDetails['start']>=0){
                    $this->db->limit($trailDetails['limit'],$trailDetails['start']);
                }
                if($trailDetails['ct_id'] !=''){
			$this->db->like('clinical_trials.ct_id',$trailDetails['ct_id']);
		}
                if($trailDetails['trial_name'] !=''){
			$this->db->like('clinical_trials.trial_name',$trailDetails['trial_name']);
		}
                if($trailDetails['condition'] !=''){
			$this->db->like('clinical_trials.condition',$trailDetails['condition']);
		}
                if($trailDetails['phase'] !=''){
			$this->db->like('clinical_trials.phase',$trailDetails['phase']);
		}
                if($trailDetails['status'] !=''){
			$this->db->like('cts_statuses.status',$trailDetails['status']);
		}
                if($trailDetails['sponsors'] !=''){
			$this->db->like('cts_sponsers.agency',$trailDetails['sponsors']);
		}
                if($trailDetails['interventions'] !=''){
			$this->db->like('cts_interventions.name',$trailDetails['interventions']);
		}
                $this->db->group_by('clinical_trials.id');
                $this->db->order_by($trailDetails['sidx'],$trailDetails['sord']);	
                $this->db->order_by('clinical_trials.end_date','desc');       
		$this->db->order_by('clinical_trials.start_date','desc');	
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get('clinical_trials');
//		 echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}
                
		return 	$arrClinicalTrials;
	}
        function listClinicalTrialsDetailsByTypeRecent15($kolId,$type = null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
                $this->db->select('clinical_trials.*,cts_statuses.status,group_concat(distinct cts_interventions.name) as intervention_name,group_concat(distinct cts_sponsers.agency) as sponsor,kol_clinical_trials.kol_id',false);
		//$this->db->from('clinical_trials');
                $this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id=clinical_trials.id','left');
		$this->db->join('cts_statuses', 'cts_statuses.id = clinical_trials.status_id','left');
                $this->db->join('ct_interventions','ct_interventions.cts_id = clinical_trials.id','left');
                $this->db->join('cts_interventions','cts_interventions.id = ct_interventions.intervention_id','left');
                $this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
                $this->db->join('cts_sponsers','cts_sponsers.id = ct_sponsers.sponser_id','left');
		$this->db->where('kol_clinical_trials.kol_id', $kolId);
              
//		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
//		$this->db->from('clinical_trials');
//		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
//		$this->db->where('kol_id', $kolId);
//		echo $this->db->last_query();
		
		 
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
//                pr($trailDetails['start']);
              
                $this->db->group_by('clinical_trials.id');
                $this->db->limit(15,0);	
                $this->db->order_by('clinical_trials.end_date','desc');       
		$this->db->order_by('clinical_trials.start_date','desc');	
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get('clinical_trials');
//		 echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}
                
		return 	$arrClinicalTrials;
	}
        function listClinicalTrialsDetailsByTypeRecent5($kolId,$type = null){
                //$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
                $this->db->select('clinical_trials.*,cts_statuses.status,group_concat(distinct cts_interventions.name) as intervention_name,group_concat(distinct cts_sponsers.agency) as sponsor,kol_clinical_trials.kol_id',false);
		//$this->db->from('clinical_trials');
                $this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id=clinical_trials.id','left');
		$this->db->join('cts_statuses', 'cts_statuses.id = clinical_trials.status_id','left');
                $this->db->join('ct_interventions','ct_interventions.cts_id = clinical_trials.id','left');
                $this->db->join('cts_interventions','cts_interventions.id = ct_interventions.intervention_id','left');
                $this->db->join('ct_sponsers', 'ct_sponsers.cts_id = clinical_trials.id','left');
                $this->db->join('cts_sponsers','cts_sponsers.id = ct_sponsers.sponser_id','left');
		$this->db->where('kol_clinical_trials.kol_id', $kolId);
              
//		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
//		$this->db->from('clinical_trials');
//		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
//		$this->db->where('kol_id', $kolId);
//		echo $this->db->last_query();
		
		 
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
//                pr($trailDetails['start']);
              
                $this->db->group_by('clinical_trials.id');
                $this->db->limit(5,0);	
                $this->db->order_by('clinical_trials.end_date','desc');       
		$this->db->order_by('clinical_trials.start_date','desc');	
		//$this->db->where('kol_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get('clinical_trials');
//		 echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}
                
		return 	$arrClinicalTrials;	
	}
} 