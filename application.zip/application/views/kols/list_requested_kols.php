<?php
/**
 * Contains fucntion to list Requested Kols
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.views.kols
 * @created 13-6-2012
 */
 
?>

	
	<style type="text/css">
		#listKols a{
			text-decoration:underline;
			text-align:left;
			float:left;
		}
		.ui-widget-content a {
			color:#000099;
		}
		.icon {
			 padding-top: 6px;
		}
		.buttons {
			float: right;
			margin-top: 6px;
		}
		tr.selectedRow {
		    background-color: #D8DFEA !important;
		}
		#contents{
			padding:10px 50px;
		}
		
		#contents table{
			font-size:125%;
			border-collapse:collapse;
		/*	border:1px solid #ccc; */
		}
		
		#contents table, td, th{
		/*	border:1px solid #ccc; */
		}
		
		h1{
			color:#2E6E9E;
			font-size:170%;
			margin-bottom:10px;
			margin-top:15px;
			text-align:left;
		}
		
		#linkHeaders{
			float:left;
			text-align:right;
		}
		p.addLink{
			margin:0px;
			text-align: right;
		}
		p.addLink a{
			text-decoration:none;
			text-align:right;
			font-size:95%;
			clear:both;
		}
		
		div#listKolsTbl{
/* Commented By Laxman
			margin:0 0 0 10px;
*/
			padding:0;
			width:100%;		
		}
	</style>
	
	<script type="text/javascript">

		function updateStatus(){
			var status = $('#status').val();
			
			var kolId = new Array();
			$.each($('input[name="exportId[]"]:checked'),function(){
				kolId.push($(this).val());
			});

			if(kolId==''){
				jAlert("Please select at least one KTL");
				return false;
			}

			if(status==''){
				jAlert("Please select status");
				return false;
			}
				var data ={};
				data['kolId'] = kolId;
				data['status'] = status;
				$('.msgBox').removeClass('success');
				$('.msgBox').addClass('notice');
				$('.msgBox').show();

				$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			$.ajax({
				url:'<?php echo base_url()?>requested_kols/update_request_status_analyst',
				data:data,
				type:'post',
				dataType:'json',
				success:function(){
					if(status=='Completed'){
						$.each(kolId,function(key,value){
							$('#KOL_'+value).remove();
							});
					}else{
						$.each(kolId,function(key,value){
						$('#KOL_'+value).find('td').eq(7).html(status);
						});
					}
					$('.msgBox').text("Updated Successfully");
					
					$('.msgBox').fadeOut(1000);
					
				}
			});
	
			}
	
	
	
	</script>
	

					<?php $userRoleId = $this->session->userdata('user_role_id');?>
					<div class="msgBox"></div>
					<div><label>Set Status:</label>
						<select name="updatestats" id="status">
						<option value="">Select</option>
							<option value="<?php echo New1?>">New</option>
							<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo APPROVED?>">Approved</option>
							<?php }?>
							<option value="<?php echo PROFILING?>">Profiling</option>
							<option value="<?php echo REVIEW?>">Review</option>
								<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo COMPLETED?>">Completed</option>
							<?php }?>
						</select>
						<button onclick="updateStatus()">save</button>
					</div>
					<div id="listKols">
					<div id="listKolsTbl">
						<table class="listResultSet">
							<caption>List of Requested KOL profiles</caption>
							<thead>
								<tr>
									<th>ID</th>
									<th>Select</th>
									<th>Name</th>
									<th>Specialty</th>
									<th>Request For</th>
									<th>Organizations</th>
									<th>Created By</th>
									
									<th>Status</th>
								</tr>
							</thead>
							<?php 
								$slNo	= 1;
								foreach($arrKol as $kol){
									echo '<tr id=KOL_'.$kol['id'].'>';
									echo '<td>' .$slNo. '</td>';
										echo "<td class='export'>
												<input type='checkbox' name='exportId[]' value='$kol[id]'>
											</td>";
									if($kol['salutation']<='4'&& $kol['salutation']!='0'){
										$name	= $arrSalutations[$kol['salutation']] . ' ';
									}else{
										$name='';
									}
									/*$name	.= $kol['first_name'] . ' ';
									$name	.= $kol['middle_name'] . ' ';
									$name	.= $kol['last_name'];*/
									$name = $this->common_helpers->get_name_format($kol['first_name'], $kol['middle_name'], $kol['last_name']);
									echo '<td><a href="'.base_url().'kols/edit_kol/'.$kol['kol_id'].'">' .$name. '</a></td>';
									if($kol['specialty']!='0'){
										echo '<td>' .$arrSpecialties[$kol['specialty']]. '</td>';
									}else{
										echo '<td> &nbsp; </td>';
									}
									if($kol['request_for'] == REQUEST_TYPE_PROFILE)
						       			$kol['request_for'] = 'Profile';
						       		else
						       			$kol['request_for'] = 'Upgrading';
       			
									echo '<td>' .$kol['request_for']. '</td>';
									echo '<td>' .$kol['name']. '</td>';
									
									echo '<td>' .$kol['user_full_name']. '</td>';
						
								
									echo '<td>' .$kol['status']. '</td>';
									echo '</tr>';
									
									$slNo++;
								}
							
							?>
						</table>
							
						
					</div>
				</div>
			<!--
			</div>
			-->		
			
			<!--  End of TABS div for the Horizontal Navigation -->
			

			<!-- Container for the 'Kol's Export' modal box -->
			<div id="exportKolsDialog">	
				<div id="exportKolsContainer" class="microProfileDialogBox">
					<div class="profileContent" id="exportKolsProfileContent"></div>
				</div>
			</div>
			<!--End of  Container for the 'Kol's Export' modal box -->	





