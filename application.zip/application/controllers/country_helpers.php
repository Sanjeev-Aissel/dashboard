<?php

/**
 * class for city, states, countries help
 * @author Ramesh B
 * @since
 * @package application.controllers	
 * @created on 
 */
//class City_state_country extends controller{
class Country_helpers extends Controller{
	
	/*
	 * Constructore
	 */
	function Country_helpers(){
		
		parent::Controller();
		$this->load->Model('Country_helper');
		
	}
	
	/*
	 * function to list all the available countries
	 */
	function list_countries(){

		$arrCountry=$this->Country_helper->listCountries();
		
	}
	
	/*
	 * function to list all the available states
	 */
	function list_states(){
	
		$arrState=$this->Country_helper->listStates();
	
	}
	
	/*
	 * function to get states belongs to county 
	 * takes 'country_id' as parameter
	 */
	function get_states_by_countryid(){
	
		
		$countryId=$this->input->post('country_id');
		
		$arrState=$this->Country_helper->getStatesByCountryId($countryId);
		
		echo json_encode($arrState);
	}
	
	/*
	 * function to list all the available cities
	 */
	function list_cities(){
	
		$arrCity=$this->Country_helper->listCities();
		
	}
	
	/*
	 * function to get cities belongs to state
	 * takes 'state_id' as parameter
	 */
	function get_cities_by_stateid(){
	
		$state_id=$this->input->post('state_id');
		$arrCity=$this->Country_helper->getCitiesByStateId($state_id);
		echo json_encode($arrCity);
	}
	
	/*
	 * fumction to get the state_id and 
	 */
	function get_state_country_by_cityid(){
		
				
	
	}
	
	/**
	 * Searches for the "Country name" and Returns the list of Country names matched
	 * 
	 * 
	 * @param String 	$countryName
	 * @return unknown_type
	 */
	function get_country_names($countryName){
		$countryName	= utf8_urldecode($this->input->post($countryName));
		$arrCountryNames = $this->Country_helper->getCountryNames($countryName);
		$arrSuggestCountryNames	= array();
		if(sizeof($arrCountryNames)==0){
			$arrSuggestCountryNames[0]			= 'No results found for '.$countryName;
		}else{
			$flag	= 1;
			foreach($arrCountryNames as $id=>$name){
				if($flag){
					$arrSuggestCountryNames[]='<div class="autocompleteHeading">Countries</div><div class="dataSet"><label name="'.$id.'" class="countries" style="display:block">'.$name."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestCountryNames[]='<div class="dataSet"><label name="'.$id.'" class="countries" style="display:block">'.$name."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $countryName;
		$arrReturnData['suggestions']	= $arrSuggestCountryNames;
		echo json_encode($arrReturnData);
		
	}	

/**
	 * Searches for the "State name" and Returns the list of Country names matched
	 * 
	 * 
	 * @param String 	$stateName
	 * @return unknown_type
	 */
	function get_state_names($isGeneric,$stateName){
		$stateName		= utf8_urldecode($this->input->post('keyword'));
		
		if($isGeneric==1){
		    $isGeneric = true;
		}else{
		    $isGeneric = false;
		}
		//$arrStateNames	= $this->Country_helper->getStateNames($stateName);
		$arrStateNames	= $this->Country_helper->getStateNamesForAutoComplete($stateName,$isGeneric);
		if((sizeof($arrStateNames))<1){
			$arrStateNames1[]		= '<div style="padding-left:5px;">No results found for '.$stateName.'</div><div><label name="No results found for '.$stateName.'" class="stateName" style="display:block"></label><label></label><span style="display:none" class="autocompleteStateId"></span></div>';
		}else{
			foreach($arrStateNames as $key=>$row){
				$arrStateNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="stateName" style="display:block">'.$row[0].'</label><label>'.$row[1].'</label><span style="display:none" class="autocompleteStateId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $stateName;
		$arrReturnData['suggestions']	= $arrStateNames1;
		echo json_encode($arrReturnData);
		
	}
	
	/**
	 * Searches for the "Country name" and Returns the list of Country names matched
	 * 
	 * 
	 * @param String 	$countryName
	 * @return unknown_type
	 */
	function get_org_country_names($countryName){
		$countryName	= utf8_urldecode($this->input->post($countryName));
		$arrCountryNames = $this->Country_helper->getOrgCountryNames($countryName);
		if(sizeof($arrCountryNames)==0){
			$arrCountryNames[0]			= 'No results found for '.$countryName;
		}
		$arrReturnData['query'] = $countryName;
		$arrReturnData['suggestions']	= $arrCountryNames;
		echo json_encode($arrReturnData);
		
	}	
	
	/**
	 * Searches for the "State name" and Returns the list of Country names matched
	 * 
	 * 
	 * @param String 	$stateName
	 * @return unknown_type
	 */
	function get_org_state_names($stateName){
		$stateName		= utf8_urldecode($this->input->post($stateName));
		//$arrStateNames	= $this->Country_helper->getStateNames($stateName);
		$arrStateNames	= $this->Country_helper->getOrgStateNamesForAutoComplete($stateName);
		if((sizeof($arrStateNames))<1){
			$arrStateNames1[]		= '<div style="padding-left:5px;">No results found for '.$stateName.'</div><div><label name="No results found for '.$stateName.'" class="stateName" style="display:block"></label><label></label><span style="display:none" class="autocompleteStateId"></span></div>';
		}else{
			foreach($arrStateNames as $key=>$row){
				$arrStateNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="stateName" style="display:block">'.$row[0].'</label><label>'.$row[1].'</label><span style="display:none" class="autocompleteStateId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $stateName;
		$arrReturnData['suggestions']	= $arrStateNames1;
		echo json_encode($arrReturnData);
		
	}
	
	function get_cities_by_stateid_new(){
	
		$state_id=$this->input->post('state_id');
		$arrCity=$this->Country_helper->getCitiesByStateIdNew($state_id);
		echo json_encode($arrCity);
	}

	function get_state_names_by_country_id($stateName){
		$stateName		= utf8_urldecode($this->input->post($stateName));
		$countryId	= $this->input->post('country_name');
		$arrStateNames	= $this->Country_helper->getStateNamesBYCountryIdForAutoComplete($stateName,$countryId);
//		echo $this->db->last_query();
//		exit;
		if((sizeof($arrStateNames))<1){
			$arrStateNames1[]		= '<div style="padding-left:5px;">No results found for '.$stateName.'</div><div><label name="No results found for '.$stateName.'" class="stateName" style="display:block"></label><label></label><span style="display:none" class="autocompleteStateId"></span></div>';
		}else{
			foreach($arrStateNames as $key=>$row){
				$arrStateNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="stateName" style="display:block">'.$row[0].'</label><label>'.$row[1].'</label><span style="display:none" class="autocompleteStateId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $stateName;
		$arrReturnData['suggestions']	= $arrStateNames1;
		echo json_encode($arrReturnData);
		
	}
	
	function get_city_names_by_state_id_and_country_id($cityName){
		$cityName		= utf8_urldecode($this->input->post($cityName));
		$countryId	= $this->input->post('country_name');
		$stateId	= $this->input->post('state_name');
		$arrCityNames	= $this->Country_helper->getCityNamesByStateIdAndCountryId($cityName,$stateId,$countryId);
		if((sizeof($arrCityNames))<1){
			$arrCityNames1[]		= '<div style="padding-left:5px;">No results found for '.$cityName.'</div><div><label name="No results found for '.$cityName.'" class="cityName" style="display:block"></label><label></label><span style="display:none" class="autocompleteCityId"></span></div>';
		}else{
			foreach($arrCityNames as $key=>$row){
				$arrCityNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="cityName" style="display:block">'.$row[0].'</label><label>'.$row[1].'</label><span style="display:none" class="autocompleteCityId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $cityName;
		$arrReturnData['suggestions']	= $arrCityNames1;
		echo json_encode($arrReturnData);
		
	}

	function get_zip_code_details($zipCode = ''){
		$data = array();
		if($zipCode != ""){
			$details = $this->Country_helper->getZipCodeDetails($zipCode);
			if($details != ''){
				$data['status'] = 1;
				$cityId = $this->Country_helper->getCityIdByDetails($details);
				$details['city_id'] = $cityId;
				$data['details'] = $details;
			}else
				$data['status'] = 0;
		}else
			$data['status'] = 0;
			
		echo json_encode($data);
	}
	
	function get_city_names($isGeneric,$cityName){
		$cityName		= utf8_urldecode($this->input->post($cityName));
		
		if($isGeneric==1){
		    $isGeneric = true;
		}else{
		    $cityName		= $this->input->post('keyword');
		    $isGeneric = false;
		}
		//$arrCityNames	= $this->Country_helper->getStateNames($cityName);
		$arrCityNames	= $this->Country_helper->getCityNamesForAutoComplete($cityName,$isGeneric);
		if((sizeof($arrCityNames))<1){
			$arrCityNames1[]		= '<div style="padding-left:5px;">No results found for '.$cityName.'</div><div><label name="No results found for '.$cityName.'" class="cityName" style="display:block"></label><label></label><span style="display:none" class="autocompleteCityId"></span></div>';
		}else{
			foreach($arrCityNames as $key=>$row){
				$arrCityNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="cityName" style="display:block">'.$row[0].'</label><label>'.$row[1].', '.$row[2].'</label><span style="display:none" class="autocompleteCityId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $cityName;
		$arrReturnData['suggestions']	= $arrCityNames1;
		echo json_encode($arrReturnData);
		
	}
}
