<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>

<script type="text/javascript">
    var filters;
            var mainFilter = 0;
            var mainFilterId = '';
            var mainCateogry = '';
            if (!js_files_loaded){
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
    }
</script>
<style type="text/css">
    .hasDatepicker{
        /*width: 141px !important;
        margin-left: 36px !important;*/
    }
    .selectBoxMsl
    {
        width: 165px;
    }
    #timeLineSliderContainer {
        padding-left: 10px;
        padding-right: 8px;
    }
    #timeLineSlider{
        margin-right:10px;
    }
    #searchLeftBar li.category{
        border-top: 0px;
    }
    #searchLeftBar{
        /*	margin-top:-40px; */
    }
    <?php
    if (IS_IPAD_REQUEST == 1) {
        echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
    }
    ?> 
    .chzn-container-multi .chzn-choices{
        padding-left: 0px !important;
    }
    .chzn-container{
        font-size: 12px;
    }
    .chzn-container-single .chzn-single{
        border-radius: 2px;
        height: 18px;
        padding: 0 0 0 5px;		
    }
    .chzn-container-single .chzn-single span{
        margin-top: -3px;
    }
    .chzn-container .chzn-results{
        padding-left: 0px !important;
        margin: 0px;
    }
    #profileType_chzn .chzn-single span{
        /*margin-top: 0px;*/
    }
    #savedFilterValue_chzn .chzn-drop .chzn-search input{
        border-radius: 2px;
    }
    .highlighted{
        background: #5A86B8 !important;
        color: white;
    }
    .chzn-container-single .chzn-search input{
        padding: 2px 20px 2px 4px;
    }
    .chzn-search li input[type="text"]{
        border-radius: 2px !important;
    }
    div.actionIcon{
        float: right;
    }
    .chzn-container-single .chzn-single div{
        top: -3px !important;
    }
    /*	.chzn-container .chzn-results li{
                    padding: 3px 4px !important;
                    line-height: 12px !important;
            }
    */
    .chzn-drop{
        min-width: 106px !important;
    }
    .ui-widget-content, #timeLineSliderContainer p, #yearRange {
        background: inherit;
    }
    #searchFiltersElements ul li.search-field{
		padding-bottom: 0px;
	    padding-left: 10px;
	    padding-top: 0px;
	}
	#categoriesContainer table{
		margin-bottom: 0 !important;
	}
	.chzn-container-multi .chzn-choices .search-field input{
		color: #444444 !important;
	}
</style>
<?php
$arrfilterdata = $this->session->userdata('filterContent');
$selectedKolId = $arrfilterdata['selected_kol_id'];
if (!empty($selectedKolId) && $selectedKolId != 0) {
    foreach ($arrKolDetails as $key => $rowData) {
        if ($key == $selectedKolId) {
            $selectedKol[$key] = $rowData['name'];
        }
    }
} else {
    $selectedKol = $arrfilterdata['arrKolNames']; //$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
}
if ($arrfilterdata['profileType'] != '') {
    $profileType = $arrfilterdata['profileType'];
}
if ($arrfilterdata['savedFilterId'] != '') {
    $savedFilterId = $arrfilterdata['savedFilterId'];
}
if (!empty($arrfilterdata['arrSpecialities'])) {
    if (!is_array($arrfilterdata['arrSpecialities'])) {
        $arrfilterdata['arrSpecialities'] = explode(',', $arrfilterdata['arrSpecialities']);
    }
    $selectedSpecialty = $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
} else {
    $selectedSpecialty = array();
}
if (sizeof($arrfilterdata['arrCountries']) > 0) {
    if (!is_array($arrfilterdata['arrCountries'])) {
        $arrfilterdata['arrCountries'] = explode(',', $arrfilterdata['arrCountries']);
    }
    $selectedCountry = $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
} else {
    $selectedCountry = array();
}
//$selectedState		= $arrfilterdata['arrStates'];
if (!empty($arrfilterdata['arrStates'])) {
    if (!is_array($arrfilterdata['arrStates'])) {
        $arrfilterdata['arrStates'] = explode(',', $arrfilterdata['arrStates']);
    }
    $selectedState = $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
} else {
    $selectedState = array();
}
if (sizeof($arrfilterdata['arrListNames']) > 0) {
    if (!is_array($arrfilterdata['arrListNames'])) {
        $arrfilterdata['arrListNames'] = explode(',', $arrfilterdata['arrListNames']);
    }
    $CI = & get_instance();
    $CI->load->model("My_list_kol");
    //$selectedListName	= $arrfilterdata['arrListNames'];
    $selectedListName = $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
} else {
    $selectedListName = array();
}
?>
<script type="text/javascript">
    
            var todayDate = "<?php echo date("m/d/Y");?>";
		var monthFirstDate = "<?php echo date("m/01/Y");?>";
     $(document).ready(function (){
    $('.chosenMultipleSelect').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectTherap').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectAgent').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectSphere').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectSource_type').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectProduct').chosen({
    allow_single_deselect: true
    });
            $('.chosenMultipleSelectTopic').chosen({
    allow_single_deselect: true
    });
    $('.chosenMultipleSelectManager').chosen({
         allow_single_deselect: true
     });
	$('.chosenMultipleSelectTeams').chosen({
		allow_single_deselect: true
	});
            });
              
    $(document).ready(function(){
    // Trigger the Autocompleter for 'education' field of  Event'
//    a = $('#msl').autocomplete(MslNameAutoCompleteOptions);
//		// Trigger the Autocompleter for 'country' field of  Event'
//            a = $('#product').autocomplete(productNameAutoCompleteOptions);
//
//		// Trigger the Autocompleter for 'country' field of  Event'
//            a = $('#topic').autocomplete(topicNameAutoCompleteOptions);
//
//		a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
//
//		// Trigger the Autocompleter for 'list' field of  Event'
//            a = $('#source').autocomplete(sourceNameAutoCompleteOptions);
            // Binding the function for slidechange event 
//		$( "#timeLineSlider" ).bind( "slidechange", filterChart);

    });
            $(document).ready(function (){
            $("#resetBttnContainer").remove();
    $('#from').datepicker({
     dateFormat: 'mm/dd/yy'
    });
    
     $('#from').val(monthFirstDate);
            $('#to').datepicker({
     dateFormat: 'mm/dd/yy'
    });
    
     $('#to').val(todayDate);
     
        filter('this','0');
            initializeCustomToolTips();
    });
            var options, a;
            // Autocomplet Options for the 'role' field 
            var MslNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_msl_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.msl').html();
                            var selId = $(event).children('.msl').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#msl').val(selText);
                            $('#mslId').val(selId);
                            filter(this, 'msl');
                            $('#mslId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var productNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_product_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.products').html();
                            var selId = $(event).children('.products').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#product').val(selText);
                            $('#productId').val(selText);
                            filter(this, 'product');
                            $('#productId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var topicNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_topic_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var stateId = $(event).children('.topics').html();
                            var selText = $(event).children('.topics').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#topic').val(selText);
                            $('#topicId').val(selText);
                            filter(this, 'topics');
                            $('#topicId').val("");
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }
            };
            var kolNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var kolId = $(event).children('.id1').html();
                            //var selText = $(event).children('.kolName').html();
                            var selText = $(event).children('.kolName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#kolName').val(selText);
                            $('#kolIdForReport').val(kolId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var sourceNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_source_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.source').html();
                            var selId = $(event).children('.source').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#source').val(selText);
                            $('#sourceId').val(selText);
                            filter(this, 'source');
                            $('#sourceId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            /*		
             $(document).ready(function(){
             
             // Trigger the Autocompleter for 'education' field of  Event'
             a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'country' field of  Event'
             a = $('#country').autocomplete(countryNameAutoCompleteOptions);
             
             a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'list' field of  Event'
             a = $('#listName').autocomplete(listNameAutoCompleteOptions);
             
             // Binding the function for slidechange event 
             $( "#timeLineSlider" ).bind( "slidechange", filterChart);
             
             });
             */
            //Initiallize the Timeline slider
<?php $date = date('Y'); ?>
    //	var minYear=<?php echo ($date - 35); ?>;
    var minYear =<?php echo ($date - 60); ?>;
            var maxYear =<?php echo $date; ?>;
            var startDate = '<?php
if (isset($startDate))
    echo $startDate;
else
    echo 0;
?>';
            var endDate = '<?php
if (isset($endDate))
    echo $endDate;
else
    echo 0;
?>';
            var rangeValue1 = minYear;
            var rangeValue2 = maxYear;
            if (startDate != null && startDate != 0)
            rangeValue1 = startDate;
            if (endDate != null && endDate != 0)
            rangeValue2 = endDate;
            /*			
             $(function() {
             $( "#timeLineSlider" ).slider({
             range: true,
             min: minYear,
             max: maxYear,
             values: [ rangeValue1, rangeValue2 ],
             step:1,
             slide: function( event, ui ) {
             $( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
             }
             });
             
             $( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
             });
             
             
             
             
             
             // Hide or Show the Category checkbox's 
             function toggleCategory(toggleFlag,thisEle){
             //	jAlert("Ds");
             if($(thisEle).parent().attr('id')=='categotySpecialty'){
             $('#specialtyCheckBox').slideToggle();	
             
             }else if($(thisEle).parent().attr('id')=='categotyCountry'){
             $('#countryCheckBox').slideToggle();	
             }else if($(thisEle).parent().attr('id')=='categotyLists'){
             
             $('#listCheckBox').slideToggle();
             }else{
             $('#kolsCheckBox').slideToggle();
             }
             
             }
             
             $(document).ready(function(){
             $('#kolName').css({color:"gray"});
             $('#specialty').css({color:"gray"});
             $('#country').css({color:"gray"});
             $('#listName').css({color:"gray"});
             
             
             $('#kolName').focus(function(){
             
             var name=$('#kolName').val();
             if(name=='Enter KOL Name'){
             $('#kolName').val(" ");
             }
             });
             
             $('#kolName').blur(function() {
             var name=$('#kolName').val();
             if(name==' '){
             $('#kolName').val('Enter KOL Name');
             }
             });
             
             $('#specialty').focus(function(){
             
             var name=$('#specialty').val();
             if(name=='Enter Specialty'){
             $('#specialty').val(" ");
             }
             });
             
             $('#specialty').blur(function() {
             var name=$('#specialty').val();
             if(name==' '){
             $('#specialty').val('Enter Specialty');
             }
             });
             
             $('#country').focus(function(){
             
             var name=$('#country').val();
             if(name=='Enter Country'){
             $('#country').val(" ");
             }
             });
             
             $('#country').blur(function() {
             var name=$('#country').val();
             if(name==' '){
             $('#kolName').val('Enter Country');
             }
             });
             
             $('#listName').focus(function(){
             
             var name=$('#listName').val();
             if(name=='Enter List Name'){
             $('#listName').val(" ");
             }
             });
             
             $('#listName').blur(function() {
             var name=$('#listName').val();
             if(name==' '){
             $('#listName').val('Enter List Name');
             }
             });
             });
             */
            if (js_files_loaded){

    // Hide or Show the Category checkbox's 
    function toggleCategory(toggleFlag, thisEle){
    //	jAlert("Ds");
    /*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
     $('#specialtyCheckBox').slideToggle();	
     
     }else if($(thisEle).parent().attr('id')=='categotyCountry'){
     $('#countryCheckBox').slideToggle();	
     }else if($(thisEle).parent().attr('id')=='categotyLists'){
     $('#listCheckBox').slideToggle();
     }else{
     $('#kolsCheckBox').slideToggle();
     }
     */
    $(thisEle).next().slideToggle('slow');
            $(thisEle).toggleClass('expanded');
            $(thisEle).toggleClass('collapsed');
    }



    $(document).ready(function(){
    $('#kolName').css({color:"gray"});
            $('#specialty').css({color:"gray"});
            $('#country').css({color:"gray"});
            $('#state').css({color:"gray"});
            $('#listName').css({color:"gray"});
            $('#kolName').focus(function(){

    //	var name=$('#kolName').val();
    //	if(name=='Enter KOL Name'){
    $('#kolName').val(" ");
            //	}
    });
            $('#kolName').blur(function() {
    //	var name=$('#kolName').val();
    //	if(name==' '){
    $('#kolName').val('Enter KOL Name');
            //	}
    });
            $('#specialty').focus(function(){

    //	var name=$('#specialty').val();
    //	if(name=='Enter Specialty'){
    $('#specialty').val(" ");
            //	}
    });
            $('#specialty').blur(function() {
    //	var name=$('#specialty').val();
    //	if(name==' '){
    $('#specialty').val('Enter Specialty');
            //	}
    });
            $('#country').focus(function(){

    //	var name=$('#country').val();
    //	if(name=='Enter Country'){
    $('#country').val(" ");
            //	}
    });
            $('#country').blur(function() {
    //	var name=$('#country').val();
    //	if(name==' '){
    $('#country').val('Enter Country');
            //	}
    });
            $('#state').focus(function(){

    //	var name=$('#state').val();
    //	if(name=='Enter State'){
    $('#state').val(" ");
            //	}
    });
            $('#state').blur(function() {
    //	var name=$('#state').val();
    //	if(name==' '){
    $('#state').val('Enter State');
            //	}
    });
            $('#listName').focus(function(){

    //	var name=$('#listName').val();
    //	if(name=='Enter List Name'){
    $('#listName').val(" ");
            //	}
    });
            $('#listName').blur(function() {
    //	var name=$('#listName').val();
    //	if(name==' '){
    $('#listName').val('Enter List Name');
            //	}
    });
    });
            /*
             $('#rightSideBarSliderShow').click(function() {
             $('#searchLeftBar').show(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
             });
             $("#rightSideBarSliderHide").show();
             $("#rightSideBarSliderShow").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             
             $('#rightSideBarSliderHide').click(function() {
             $('#searchLeftBar').hide(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
             $("#rightSideBarSliderShow").show(500);
             });
             $("#rightSideBarSliderHide").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             */
    }
    $(document).ready(function(){
//        $("#msl").click(function(){
//              alert("kjkj");
//       filter(this,'msl');
//    });

//	$("#savedFilterValue").chosen().change(function(){
//		activeCustmFilters(this);
//	});
//	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
//		displaySelectedChart(this);
//	});
//	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
//		if($("#savedFilterValue").val()){
//			activeCustmFilters($("#savedFilterValue").val());
//			return true;
//			}
////		doSearchFilter1(-1,this);
//		displaySelectedChart(this);
//	});
    });
            function filter(thisEle, category){
            filters = {};
            var data={};
                    mainCategory = category;
                    if (mainFilter == 0){
            mainFilterId = $(thisEle).children().val();
                    mainFilter = 1;
            }
            if ($(thisEle).children().attr('checked') == "checked"){

            if (mainFilterId == $(thisEle).children().val()){
            mainFilterId = '';
                    mainFilter = 1;
                    mainCategory = '';
            }

            $(thisEle).css('background-color', '#fff')
                    $(thisEle).children().removeAttr("checked");
            }
            else{
            $(thisEle).css('background-color', '#D3DFED')
                    $(thisEle).children().attr("checked", "checked");
            }
//           if($(thisEle).children().attr('checked') == "checked"){
//              $(thisEle).css('background-color', '#fff')
//               $(thisEle).children().removeAttr("checked");
//           }
//           else{
//              $(thisEle).css('background-color', '#D3DFED')
//                $(thisEle).children().attr("checked","checked");
//           }
            var mslData = new Array();
            if($("#msl_user").val() != null){
                    mslData = $("#msl_user").val();
            }
            var teamData = new Array();
            if($("#teams").val() != null){
                    teamData = $("#teams").val();
            }
            var thrpData = new Array();
            if($("#thrp_name").val() != null){
                    thrpData = $("#thrp_name").val();
            }
            var agentData = new Array();
            if($("#agent").val() != null){
                    agentData = $("#agent").val();
            }
            var sphereData = new Array();
            if($("#sphere_influencers").val() != null){
                    sphereData = $("#sphere_influencers").val();
            }
            var sourceData = new Array();
            if($("#source_type").val() != null){
                    sourceData = $("#source_type").val();
            }
            var productData = new Array();
            if($("#product").val() != null){
                    productData = $("#product").val();
            }
            var topicsData = new Array();
            if($("#topics").val() != null){
                    topicsData = $("#topics").val();
            }
             var managerData = new Array();
           if($("#managers").val() != ''){
            
                   managerData = $("#managers").val();
           }
            var   sd = $("#from").val()
           if(sd!=''){        
                   var sdSplits = sd.split("/");            
                   data['from'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];        
           }        
           var ed = $("#to").val();        
           if(ed!=''){            
                   var edSplits = ed.split("/");            
                   data['to'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];        
           }
           
             var fromDate = new Date( $("#from").val());
            var toDate = new Date($("#to").val());
            if(sd != '' && ed != ''){
                if (toDate < fromDate){
                    jAlert(" 'To Date' Should be greater than 'From Date' ");
                    return false;
                }
            }
            //var data = $("form").serialize();
            data['msl']=mslData;
            data['thrp_name']=thrpData;
            data['agent']=agentData;
            data['sphere_influencers']=sphereData;
            data['source_type']=sourceData;
            data['topics']=topicsData;
            data['product']=productData;
            data['team_name']=teamData;
            data['manager_id']=managerData;
                    filters = data;
                    $("#applyFilter").val("Cancel");
	$("#applyFilter").attr("onclick","cancelLastRequest()");
                    if($("#test li.current").attr("name") == 'tab0'){
                    	list_medical_insight_grid();
                    }
					if($("#test li.current").attr("name") == 'tab1'){
						loadtherapeuticareachart();
	                    loadtherapeuticareaBarChart();
                    }
                    
//                    get_filter_content(category);
            }

    function get_filter_content(category){
//        alert(filters);

    $.ajax({
    url:base_url + "reports/medical_report_filter/" + category,
            type: "Post",
            dataType:'json',
            data:filters,
            async:false,
            success:function(returnData){
//            if (returnData.noFilter)
//                    category = '';
//                               alert(mainCategory);if (returnData.noFilter || mainCategory != "therp" ){
                    // if (returnData.noFilter || mainCategory != "therp"){

                    $("#therpData").empty();
                    // }
                    //    if (returnData.noFilter || mainCategory != "msl"){
                    $("#mslData").empty();
                    // }
                    //   if (returnData.noFilter || mainCategory != "agent"){
                    $("#agentData").empty();
                    // }
                    //  if (returnData.noFilter || mainCategory != "sphere"){
                    $("#sphereData").empty();
                    //  }
                    // if (returnData.noFilter || mainCategory != "source"){
                    $("#sourceData").empty();
                    //   }
                    //    if (returnData.noFilter || mainCategory != "product"){
                    $("#productData").empty();
                    //   }
//            if (returnData.noFilter || mainCategory != "topics"){
                    $("#topicData").empty();
//            }
                    mainCategory = '';
                    for (var result in returnData){
//            if (returnData[result] != ''){
//            for (var innerResult in returnData[result]){
//            if (result == "therp"){
//
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0];
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    if (state == "true"){
//            var htmlTherp;
//                    htmlTherp += '<tr class="allTherpys" style="background-color:#D3DFED">';
//                    htmlTherp += '<td onclick="filter(this,\'therp\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="thrp_name[]" checked="checked" id="mslName"  value="' + name + '"  "/>' + name + '</td>';
//                    htmlTherp += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlTherp += '</tr>'; }
//            else{
//            htmlTherp += '<tr class="allTherpys">';
//                    htmlTherp += '<td onclick="filter(this,\'therp\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="thrp_name[]"  id="mslName"  value="' + name + '"  "/>' + name + '</td>';
//                    htmlTherp += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlTherp += '</tr>';
//            }
//            // alert(htmlTherp);
//            }
//            if (result == "msl"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1] + " " + data[2];
//                    var id = data[3];
//                    var count = data[4];
//                    var htmlMsl;
//                    if (state == "true"){
//            htmlMsl += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlMsl += '<td onclick="filter(this,\'msl\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="msl[]" checked="checked" id="mslName"  value="' + id + '"  "/>' + name + '</td>';
//                    htmlMsl += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlMsl += '</tr>'; }
//            else{
//            htmlMsl += '<tr class="allTherpys">';
//                    htmlMsl += '<td onclick="filter(this,\'msl\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="msl[]"  id="mslName"  value="' + id + '"  "/>' + name + '</td>';
//                    htmlMsl += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlMsl += '</tr>';
//            }
//            }
//            if (result == "agent"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    var htmlStatus;
//                    if (state == "true"){
//            htmlStatus += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlStatus += '<td onclick="filter(this,\'agent\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="agent[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlStatus += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlStatus += '</tr>'; }
//            else{
//            htmlStatus += '<tr class="allTherpys">';
//                    htmlStatus += '<td onclick="filter(this,\'agent\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="agent[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlStatus += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlStatus += '</tr>';
//            }
//            }
//            if (result == "sphere"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    var htmlSphere;
//                    if (state == "true"){
//            htmlSphere += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlSphere += '<td onclick="filter(this,\'sphere\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="sphere_influencers[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlSphere += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlSphere += '</tr>'; }
//            else{
//            htmlSphere += '<tr class="allTherpys">';
//                    htmlSphere += '<td onclick="filter(this,\'sphere\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="sphere_influencers[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlSphere += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlSphere += '</tr>';
//            }
//            }
//            if (result == "source"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    var htmlSource;
//                    if (state == "true"){
//            htmlSource += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlSource += '<td onclick="filter(this,\'source\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="source_type[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlSource += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlSource += '</tr>'; }
//            else{
//            htmlSource += '<tr class="allTherpys">';
//                    htmlSource += '<td onclick="filter(this,\'source\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="source_type[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlSource += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlSource += '</tr>';
//            }
//            }
//            if (result == "product"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    var htmlProduct;
//                    if (state == "true"){
//            htmlProduct += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlProduct += '<td onclick="filter(this,\'product\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="product[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlProduct += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlProduct += '</tr>'; }
//            else{
//            htmlProduct += '<tr class="allTherpys">';
//                    htmlProduct += '<td onclick="filter(this,\'product\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="product[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlProduct += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlProduct += '</tr>';
//            }
//            }
//            if (result == "topics"){
//            var data = returnData[result][innerResult].split("_");
//                    var state = data[0]
//                    var name = data[1];
//                    var id = data[2];
//                    var count = data[3];
//                    var htmlTopic;
//                    if (state == "true"){
//            htmlTopic += '<tr class="allTherpys"  style="background-color:#D3DFED">';
//                    htmlTopic += '<td onclick="filter(this,\'topics\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="topics[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlTopic += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlTopic += '</tr>'; }
//            else{
//            htmlTopic += '<tr class="allTherpys">';
//                    htmlTopic += '<td onclick="filter(this,\'topics\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="topics[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
//                    htmlTopic += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
//                    htmlTopic += '</tr>';
//            }
//            }
//            }
//            }

            }
//                
//            if (mainCategory != "therp"){
//
//
//            $("#therpData").append(htmlTherp);
//            }
//            if (mainCategory != "msl"){
//
//            $("#mslData").append(htmlMsl);
//            }
//            if (mainCategory != "agent"){
//
//            $("#agentData").append(htmlStatus);
//            }
//            if (mainCategory != "sphere"){
//
//            $("#sphereData").append(htmlSphere);
//            }
//            if (mainCategory != "source"){
//
//            $("#sourceData").append(htmlSource);
//            }
//            if (mainCategory != "product"){
//
//            $("#productData").append(htmlProduct);
//            }
//            if (mainCategory != "topics"){
//
//            $("#topicData").append(htmlTopic);
//            }

            }





    });
//    list_medical_insight_grid();
     $(".gridWrapper").children().addClass('gridHeight');
           if(tabReportClick==0){
              $("#coachingsList").css("display","block");
			$("#summaryChartContainerTherapeuticArea").css("display","none");
			$("#barChartContainer").css("display","none");
            }
            else{
            $("#coachingsList").css("display","none");
			$("#summaryChartContainerTherapeuticArea").css("display","block");
			$("#barChartContainer").css("display","block");
            }
    }
function resetFilters(){
$("select").find('option').removeAttr("selected");
$("input").val('');
$("input").text('');
$('.search-choice').remove();
     filter(null,"source");
      if(tabReportClick==0){
              $("#coachingsList").css("display","block");
			$("#summaryChartContainerTherapeuticArea").css("display","none");
			$("#barChartContainer").css("display","none");
            }
            else{
                $("#coachingsList").css("display","none");
			$("#summaryChartContainerTherapeuticArea").css("display","block");
			$("#barChartContainer").css("display","block");
            }
      $("#hideSideBarButton").val("Hide Sidebar");
   }

jqgridIds.push("listMirfResultSet","test");
var gridMinWidth = 600;
var gridMaxWidth = 880;
function toggleIreportSidebar(ele){
	if ($(ele).attr('value') == "Hide Sidebar") {
		resizeMaxGridWidth();
		$("#subContainer").before('<input type="button" class="toggle-button" id="showSideBarButton" onclick="toggleIreportSidebar(this);"  value="Show Sidebar" style="float: right;">');
		$("#rightSideBar").hide();
    } else {
    	resizeMinGridWidth();
    	$("#showSideBarButton").remove();
    	$("#rightSideBar").show();
    }
}

function resizeMinGridWidth(){
	jqgridMinWidth = gridMinWidth;
	$.each(jqgridIds,function(index,value){
		$('#'+value).setGridWidth(gridMinWidth,false);
	});
	$(".tabsContent").css("width","630px");
	$(".tabsContainer").css("width","630px");
}

function resizeMaxGridWidth(){
	jqgridMinWidth = gridMaxWidth;
	$.each(jqgridIds,function(index,value){
		$('#'+value).setGridWidth(gridMaxWidth,false);
		$('#'+value).css("width",gridMaxWidth+"px");
	});
	$(".tabsContent").css("width","880px");
	$(".tabsContainer").css("width","880px");
}
            </script>
<style type="text/css">
    <?php      if(IS_IPAD_REQUEST){ ?>
		form label {
	        font-weight: normal !important;
	        text-align: right;
		}
		.chzn-container-multi .chzn-choices .search-field .default {
		    height: 25px !important;
		    border-radius: 2px !important;
		}
                .search-field{
                     height: 25px !important;
                }
		.chzn-container-multi .chzn-choices {
		    border-radius: 4px;
		}
	    .postalerror{
	    	display: block !important;
	    	text-align: left !important;
	    	color: green !important;
	    }
	    .alignRight{
	    	vertical-align: top !important;
	    }
	    .chosenMultipleSelect,.chosenMultipleSelectTeams {
	    	width: 230px;
	    }
	    label.categoryName{
	    	border-bottom: 0 !important;
                font-size: 11px;
                color: #444444;
	    }
	    #categoriesContainer .category{
	    	margin-top: 15px;
	    }
	    #from, #to{
			width: 80px;
			border: 1px solid #aaaaaa !important;
			margin-right: 10px;
			font-size: 12px;
			height: 20px;
		}
		.filtersButton{
			margin-left: 16px;
		}
		.filtersButton label{
			font-size: 12px !important;
		}
		#applyFilter{
			font-size: 12px !important;
		}
		.ui-widget-content{
			background: white;
		}
	<?php }else{ ?>
    select.chosenMultipleSelect,select.chosenMultipleSelectTherap,select.chosenMultipleSelectAgent,select.chosenMultipleSelectSphere,select.chosenMultipleSelectSource_type,select.chosenMultipleSelectProduct,select.chosenMultipleSelectTopic,select.chosenMultipleSelectTeams,select.chosenMultipleSelectManager{
        width:280px;
    }
    .microView .ui-dialog-content {
        background-color: white;
    }
    .users{
        list-style-type: none;
        margin:0;
        padding:0

    }
    .users li{
        float:left;
    }
    .editIcon{
        margin-left: 3px;
    }
    #rightSideBarContainer {
	    width: 311px;
	}
	#rightSideBar::before {
	    border-top: 1px solid #bbbbbb !important;
	    height: 0 !important;
	    margin-left: 0 !important;
	}
	#rightSideBarWrapper {
	    border-left: 1px solid #bbbbbb;
	    /*overflow: hidden;*/
	}
	#categoriesContainer .category{
	    padding: 5px 0px 0 15px;
	}
	#from, #to{
		width: 80px;
	}
        <?php } ?> 
</style>


<div id="searchFiltersContainer">
    <div id="searchFiltersElements">
        <form action="<?php echo base_url() ?>kols/" name="searchFilterForm" method="post" id="searchFilterForm">
            <ul id="categoriesContainer">
            	<li id="categotyChannels" class="category"> </li>
                <?php if(IS_IPAD_REQUEST == 1){?>
									<div class="row">
										<div class="col-md-12 text-right">
											<input type="button" id="hideSideBarButton" class="toggle-button" onclick="toggleIreportSidebar(this);" value="Hide Sidebar">
										</div>
				 
										<div class="col-md-12 text-center">
											<input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" class="toggle-button applyFilter" onclick="filter('this','0');">
											<button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="resetFilters();">Reset</button>
                						</div>
                					</div>
                					<br>
                					<div class="row">
                						<div class="col-md-12 text-center">
											<label class="dateText">From </label>
											<input type="text" name="from" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="from">
											<label class="dateText">To </label>
											<input type="text" name="to" value="<?php if($toDate != ''){echo $toDate;}?>" id="to">
										</div>
									</div>
									
							<?php }else{?>
                    <table style='  margin-left: 7px;' id="dateFilter">
                    			<tr>
										<td colspan="2" style="text-align: center;">
                                                                                    <input type="button" name="applyFilter" value="Apply Filters" id="applyFilter"  onclick="filter('this','0');">
											  <button type="button" name="applyFilter" class="toggle-button applyFilter" id="applyFilter" onclick="resetFilters();">Reset</button>
										</td>
									</tr>
								<tr>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;"  >From </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="from" value="" id="from">
										</div>
									</td>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;" >To </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="to" value="" id="to">
										</div>
									</td>
								</tr>
							</table>
                                                        <?php }?>	
							<li class="category"></li>
                <li id="categotyCountry" class="category">

                    <label class="categoryName">MSL/MML Name</label>

                    <table id="mslData">
                        <select name="msl[]" id="msl_user" multiple="multiple" class="chosenMultipleSelect" data-placeholder="Select Users" >
                            <option value=""></option>
                            <?php
                            foreach ($arrClientUsers as $key => $arrRow) {
                                $selected = '';
                                ?>
                                <option value="<?php echo $arrRow['id'] ?>" ><?php echo $arrRow['first_name'] . ' ' . $arrRow['last_name'] ?></option>;
                            <?php }
                            ?>

                        </select>


                    </table>
                </li>
                <li id="Team" class="category">
                    <label class="categoryName">Team Name</label>
                    <div id="TeamCheck">
                        <table id="mslData">
							<select name="team_name[]" id="teams" multiple="multiple" class="chosenMultipleSelectTeams" data-placeholder="Select Teams">
	            				<option value=""></option>
		            			<?php 
					                foreach($arrTeam as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['group_id']?>"><?php echo $arrRow['group_name']?></option>;
		                		<?php }?>
				        	</select>
                        </table>
                    </div>
                </li> 
                <?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
                <li id="Manager" class="category">
                    <label class="categoryName">Manager Name</label>
                    <div id="ManagerCheck">
                        <table id="mslData">
							<select name="manager_name" id="managers"  class="chosenMultipleSelectManager" data-placeholder="Select Manager">
	            				<option value=""></option>
		            			<?php 
					                foreach($arrManager as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name']?>&nbsp;<?php echo $arrRow['last_name']?></option>;
		                		<?php }?>
				        	</select>
                        </table>
                    </div>
                </li>
                <?php } ?>
                <li id="categotyCountry" class="category">

                    <label class="categoryName">Therapeutic Area</label>

                    <table id="therpData">
                        <select name="thrp_name[]" id="thrp_name"  multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectTherap" data-placeholder="Select Therapeutic Area">
                            <option value=""></option>
                            <?php
                            foreach ($arrSpecialties as $key => $row) {
                                $selected = '';
                                ?>
                                <option value="<?php echo $row['name']; ?>"  <?php if (array_key_exists($arrRow['id'], $assignedUsers)) echo "selected='selected'"; ?>><?php echo $row['name']; ?></option>;
                            <?php }
                            ?>

                        </select>




                    </table>
                </li>
<!--	              <li id="categotyCountry" class="category">
                    <label class="categoryName">Investigational Agent</label>
                    <table id="agentData">
                        <select name="agent[]" id="agent" multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectAgent" data-placeholder="Select Investigational Agent" >
                            <option value=""></option>
							<?php
//							foreach ($investigationalAgent as $key => $row) {
//							    $selected = '';
							    ?>
                                <option value="<?php // echo $row['name']; ?>" ><?php // echo $row['name']; ?></option>;
                            <?php // }
                            ?>
                        </select>
                    </table>

	                </li>-->
<!--	                <li id="categotyCountry" class="category">
                    <label class="categoryName">Sphere of Influence</label>
                    <table id="sphereData">
                        <select name="sphere_influencers[]" id="sphere_influencers"  multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectSphere" data-placeholder="Select Sphere of Influence" >
                            <option value=""></option>
							<?php
//							foreach ($sphereOfInfluence as $key => $row) {
//							    $selected = '';
							    ?>
                                <option value="<?php // echo $row['name']; ?>" ><?php // echo $row['name']; ?></option>;
                            <?php // }
                            ?>
                        </select>
                    </table>
                </li>-->
                <li id="categotyCountry" class="category">
                    <label class="categoryName">Source Type</label>
                    <table id="sourceData">
                        <select name="source_type[]" id="source_type"  multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectSource_type" data-placeholder="Select Source Type" >
                            <option value=""></option>
							<?php
							foreach ($sourceType as $key => $row) {
							    $selected = '';
							    ?>
                                <option value="<?php echo $row['name']; ?>" ><?php echo $row['name']; ?></option>;
                            <?php }
                            ?>
                        </select>
                    </table>
                </li>
                <li id="categotyCountry" class="category">
                    <label class="categoryName">Product</label>
                    <table id="productData">
                        <select name="product[]" id="product"  multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectProduct" data-placeholder="Select Product">
                            <option value=""></option>
							<?php
							foreach ($product as $key => $row) {
							    $selected = '';
							    ?>
                                <option value="<?php echo $row['name']; ?>" ><?php echo $row['name']; ?></option>;
                            <?php }
                            ?>
                        </select>
                    </table>
                </li> 
                <li id="categotyCountry" class="category">
                    <label class="categoryName">Key Insight Topics</label>
                    <table id="topicData">
                        <select name="topics[]" id="topics"  multiple="multiple" class="chosenMultipleSelect chosenMultipleSelectTopic" data-placeholder="Select Key Insight Topics" >
                            <option value=""></option>
							<?php
							foreach ($keyInsightTopic as $key => $row) {
							    $selected = '';
							    ?>
                                <option value="<?php echo $row['name']; ?>" ><?php echo $row['name']; ?></option>;
                            <?php }
                            ?>
                        </select>
                       </table>
                </li>  
               
            </ul>
        </form>
    </div>
</div>
