<?php
/**
 * Model for Campaigns operations
 * 
 * @package application.models
 * @author Vinod H
 * @since 6.2.2
 * @created on  28-03-16
 */

class Campaign extends model{
	
	function Campaign(){
		parent::model();
	}
     /**
	 *  Insert Campaign details into DB
	 *	@param $arrCampagin
	 *  @return true/false
	 */
	function saveCampaign($arrCampaign){
		if($this->db->insert('campaigns',$arrCampaign)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Save Campaign Deatils',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $this->db->insert_id(),
					'transaction_table_id' => CAMPAIGNS,
					'transaction_name' => "Save Campaign Deatils",
					'parent_object_id' => $this->db->insert_id()
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			return $this->db->insert_id();
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Save Campaign Deatils',
					'status' => STATUS_FAIL,
					'transaction_id' => $this->db->insert_id(),
					'transaction_table_id' => CAMPAIGNS,
					'transaction_name' => "Save Campaign Deatils",
					'parent_object_id' => $this->db->insert_id()
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			return false;
		}
	}
	
	function saveCampaignKols($arrCampaignKols){
		if($arrCampaignKols['kol_id']>0){
			if($this->db->insert('campaign_kols',$arrCampaignKols)){
				$arrData['kol_id'] = $arrCampaignKols['kol_id'];
				$arrData['client_id'] = GUEST_CLIENT_ID;
				$arrData['is_visible'] = '1';
				$this->db->insert('kols_client_visibility', $arrData);
				
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	/**
	 * Get Campaign name from 'campaign' Table
	 * @param $arrData
	 * @return boolean
	 */
	function isValidCampaign($arrData){
		$this->db->select('*');
		$this->db->where_not_in('id', $arrData['id']);
		$this->db->where('short_code', $arrData['shortcode']);
		$rowCampaignsField	=  $this->db->get('campaigns');
		if($rowCampaignsField->num_rows() > 0)
			return true;
		else
			return false;
	}

	/**
	* Get Campaign details
	* @param int $limit
	* @param int $start
	* @param string $sidx
	* @param string $sord
	* @return array - $arrCampaignDetails - Returns
	*/
	function getProcessedCampaigns($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where){	
		if(isset($where['name'])){
			$this->db->like('name',$where['name']);
		}
		if(isset($where['short_code'])){
			$this->db->like('short_code',$where['short_code']);
		}
		if(isset($where['description'])){
			$this->db->like('description',$where['description']);
		}
		if($doCount){
			$count = $this->db->count_all_results('campaigns');
			return $count;
		}else{
			if($sidx!='' && $sord!=''){
				switch($sidx){
					case 'name' : $this->db->order_by("name",$sord);
					break;
					case 'short_code' :$this->db->order_by("short_code",$sord);
					break;
				}
				//$this->db->order_by($sidx,$sord);
			}	
		}	
		$arrCampaignDetails = $this->db->get('campaigns',$limit,$startFrom);
		return $arrCampaignDetails;
	}

	/**
	 * Get Campaign name or Campaign short_code from 'campaign' Table
	 * @param $str
	 * @return row
	 */
	function getCampaignsField($str){
		$this->db->select('*');
		//$this->db->where(array('name'=>$str,'is_enable'=>0));
		$this->db->where(array('short_code'=>$str,'is_enable'=>1));
		$rowCampaignsField	=  $this->db->get('campaigns');
		return $rowCampaignsField;
	}
	/**
	 * Get All Project details
	 * @return array - $arrProjects - Returns
	 */
	function getAllProjects(){
		$this->db->select('id,name');
		$arrProjects = $this->db->get('projects');
		return $arrProjects->result();
	}
	/**
	 * Get Campaign Kols by campaign id
	 * @param $campId as Int
	 * @return array - $arrCampaignDetails - Returns
	 */
	function getCampaignKolsIds($campId){
		$arrCampaignKolsIds = $this->db->get_where('campaign_kols',array('campaign_id'=>$campId));
		return $arrCampaignKolsIds->result_array();
	}
	
	/**
	 * Insert kolIds to 
	 * @param int $arrUserKol
	 * @return boolean
	 */
	function saveUserCampaignKolIds($arrUserKol){
		if($this->db->insert('user_kols',$arrUserKol)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Edit Campaign details
	 * @param int $id
	 * @return array - $arrCampaignDetail
	 */
	function editCampaign($id){
		$arrCampaignDetail = $this->db->get_where('campaigns',array('id'=>$id));
		return $arrCampaignDetail->result_array();
	}
	/**
	 * Upadate Campaign details
	 * @param
	 * @return array - $arrCampaignDetail
	 */
	function updateCampaign($arrCampaign)	{
		$id	=	$arrCampaign['id'];
		$this->db->where('id',$id);
		$arrCampaignDetail	=	$this->db->update('campaigns',$arrCampaign);
		//Add Log activity
		$arrLogDetails = array(
				'type' => EDIT_RECORD,
				'description' => 'Update Campaign Deatils',
				'status' => STATUS_SUCCESS,
				'transaction_id' => $id,
				'transaction_table_id' => CAMPAIGNS,
				'transaction_name' => "Update Campaign Deatils",
				'parent_object_id' => $id
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		return $arrCampaignDetail;
	}
	/**
	 * Delete Campaign details
	 * @param
	 * @return array - $arrCampaignDetail
	 */
	function deleteCampaignKols($arrCampaign)	{
		$campaignId	=	$arrCampaign['campaign_id'];
		$kolId	=	$arrCampaign['kol_id'];
		$this->db->where('campaign_id',$campaignId);
		$this->db->where_in('kol_id',$kolId);
		$arrCampaignDetail	=	$this->db->delete('campaign_kols');
		return $arrCampaignDetail;
	}
}