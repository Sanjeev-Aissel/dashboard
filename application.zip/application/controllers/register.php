<?php
/**
 * Controller for Campaign operations
 * @author Vinod H
 * @since 6.2.2
 * @package application.controllers	
 * @created on 28-03-2016
 * 
 */
class Register extends controller {
	/**
	 * Register function.
	 * @access public
	 */
	function Register(){
		parent::Controller();
		$this->load->model('campaign');
		$this->load->model('Login_model');
		$this->load->model('common_helpers');
		$this->load->library('SimpleLoginSecure');
		$this->load->model('Client_User');
	}
	
	/**
	 * campaign function.
	 * @access public
	 * @param $campaign_short_code (default: false)
	 * @return void
	 */
	public function campaign($campaign = '') {
		$mobile = mobile_device_detect();
		$isMobileDevice	= false;
		if(isset($mobile[1]) && $mobile[1] != 'Apple iPad'){
			$isMobileDevice	 = true;
			redirect(MOBILE_URL_SEGMENT.'/register/'.$campaign);
		}
		if($this->session->userdata('logged_in')) {
			if($isMobileDevice){
				redirect(base_url().MOBILE_URL_SEGMENT.'/kols/list_kols_client_view');
			}else{
			// Redirect to the 'KOL Profile' application
				redirect('/kols/list_kols_client_view');
			}
		}
		$campaign	= trim($campaign);
		$resCampaigns = $this->campaign->getCampaignsField($campaign);
		if($resCampaigns->num_rows() == 0){
			redirect(base_url().'login','refresh');
		}else{
			$rowCampaigns = $resCampaigns->row();
			$data['campaign_name'] = $rowCampaigns->name;
			$data['campaign_id'] = $rowCampaigns->id;
			$data['campaign_short_code'] = $rowCampaigns->short_code;
			$data['campaign_project_id'] = $rowCampaigns->identification_id;
			$this->load->view('campaigns/register_form',$data);
		}
	}
	/**
	* To save the user details
	*/	 
	public function save_user_registration_details(){
	$mobile = mobile_device_detect();
		$isMobileDevice	= false;
		if(isset($mobile[1]) && $mobile[1] != 'Apple iPad'){
			$isMobileDevice	 = true;
		}
		$this->db->where('email', trim($this->input->post('email')));
		$query = $this->db->get('client_users');
		
		if ($query->num_rows() > 0){ //user_email already exists
			$this->session->set_flashdata('emailError', 'Email ID already exists');
			if($isMobileDevice){
				redirect(MOBILE_URL_SEGMENT.'/register/'.$this->input->post('campaign_short_code') , 'refresh');
			}else{
			redirect(base_url().'register/'.$this->input->post('campaign_short_code') , 'refresh');
			}
		}else{	//echo 'Hi';
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);	
		$arrUserDetails['first_name']			= trim($this->input->post('first_name'));
		$arrUserDetails['last_name']			= trim($this->input->post('last_name'));
		$arrUserDetails['title']		 		= trim($this->input->post('title'));
		$arrUserDetails['phone'] 				= trim($this->input->post('phone'));
		$arrUserDetails['company_name']         = trim($this->input->post('company_name'));
		$arrUserDetails['email'] 				= trim($this->input->post('email'));
		$arrUserDetails['password']				= $hasher->HashPassword($this->input->post('password'));
		$arrUserDetails['country']				= trim($this->input->post('country'));
		$arrUserDetails['user_name']			= trim($this->input->post('user_name'));
		$arrUserDetails['user_role_id']			= ROLE_USER;
		$arrUserDetails['client_id']            = GUEST_CLIENT_ID; // client id for campaign
		$project_id			= $this->input->post('campaign_project_id');
		$campaign_id			= $this->input->post('campaign_id');
		
		if(empty($arrUserDetails['user_name'])){
			$arrUserDetails['user_name']	= $arrUserDetails['email'];
		}
		if(empty($arrUserDetails['last_name'])){
			$fullName	= explode(' ',$arrUserDetails['first_name']);
			$arrUserDetails['first_name']	= $fullName[0];
			unset($fullName[0]);
			$arrUserDetails['last_name']	= implode(' ',$fullName); 
		}
		if($this->Client_User->saveUserRegistrationDetails($arrUserDetails)){
			$user_id = $this->db->insert_id();
			$this->load->model('identification');
			$userProjects['user_id'] = $user_id;
			$userProjects['project_id'] = $project_id;
			if($userProjects['project_id'] != 0){
				$this->identification->saveUserProject($userProjects);
			}
			if($campaign_id != 0){
				$arrUserKol['user_id'] = $user_id;
				$arrCampaignKols = $this->campaign->getCampaignKolsIds($campaign_id);
				
				foreach($arrCampaignKols as $row){
					$arrUserKol['kol_id'] = $row['kol_id'];
					$this->campaign->saveUserCampaignKolIds($arrUserKol);
				} 
			}
			$arrUserDetails['confirmpw']	= $this->input->post('password');
			$kolProArray = array();
            $kolProArray['project_id'] = $project_id;
            $kolProArray['client_id'] = $arrUserDetails['client_id'];
			$kol_project_visibility = $this->identification->saveKolsProjectVisibility($kolProArray);
			$this->send_email($arrUserDetails);
			//$this->load->view('client_users/show_success_message',$arrUserDetails);
			if($this->simpleloginsecure->login($arrUserDetails['user_name'], $this->input->post('password'))) {
				//Save the user analytics like user id, login and logout time etc.
				$arrUserAnalytics	= array();
				$arrUserAnalytics['is_login_failed']	= 0;
				$arrUserAnalytics['user_id']	= $user_id;
				$arrUserAnalytics['username']	= $arrUserDetails['user_name'];
// 				$userAnalyticsId=$this->Login_model->saveUserAnalytics($arrUserAnalytics);
// 				$this->session->set_userdata('user_analytics_id',$userAnalyticsId);
				if($isMobileDevice){
					redirect(base_url().MOBILE_URL_SEGMENT.'/kols/list_kols_client_view');
				}else{
					redirect(base_url().'kols/list_kols_client_view');
				}
			}
			
		}else{
			$data['campaign_name'] = $this->input->post('campaign_name');
			$data['campaign_id'] = $campaign_id;
			$data['campaign_short_code'] = $this->input->post('campaign_short_code');
			$data['campaign_project_id'] = $project_id;
			$arrUserDetails['project_id']	 = $project_id;
			$arrUserDetails['campaign_id']	 = $campaign_id;
			$arrUserDetails['error'] ="User Name is already exists. Please provide Different User Name.";
			if($isMobileDevice){
				$this->load->view(MOBILE_APP_FOLDER.'/campaigns/register',$arrUserDetails);
			}else{
				$this->campaign($arrUserDetails);
			}
		}
	}
}
	function send_email($arrUserDetails){
		$config['protocol'] = PROTOCOL;
		$config['smtp_host']= HOST;
		$config['smtp_port']= PORT;
		$config['smtp_user']= USER;
		$config['smtp_pass']= PASS;
		$config['mailtype']	= 'html';
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_newline("\r\n");
		$this->email->from(USER,'Aissel Support Team');
		$this->email->to($arrUserDetails['email']);
		$data	= array('data'=>$arrUserDetails);
		$html 	= $this->load->view('client_users/welcome_email',$data,true);
		$this->email->message($html);
		$this->email->subject("Welcome to Aissel KOLM");
		if($this->email->send()){
			$emailData['status'] 	= 'Your message has been sent';
		}else{
			$emailData['status'] 	= 'Mail not sent';
		}
		//echo json_encode($emailData);
		return $emailData;
	}
}