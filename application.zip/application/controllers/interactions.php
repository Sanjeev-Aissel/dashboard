<?php

/**
 * This class contains the methods to Interactions module activites 
 * 
 * @author Ramesh B
 * @since  1.5	
 * @package application.controllers	
 * @created on  28-02-11
 * 
 */
class Interactions extends Controller {

    function Interactions() {
        parent::Controller();
        $this->load->model('interaction');
        $this->load->model('kol');
        $this->load->model('common_helpers');
        $this->load->model('calendar');
        $this->load->model('client_user');
        $this->load->model('payment');
        $this->load->model('planning');
        $this->load->model("specialty");
        $this->load->model("client_user");
        $this->loggedUserId	= $this->session->userdata('user_id');
    }

    /**
     * This function Prepares data required for Interaction Form and redirects to the Interaction page
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return 
     */
    function add_interaction($kolId = null, $interactionFor = "kol") {
        $this->load->model('organization');
        $data['interactionFor'] = $interactionFor;
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        $data['kolSpecialty'] = '';
        $arrObjectives = array();
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');
        $arrObjectives = array();
        $arrObjectivesResults = $this->planning->getPlannedObjectives($userId, $clientId);
        foreach ($arrObjectivesResults as $row)
            $arrObjectives[$row['id']] = $row['name'];
        //	$data['arrObjectives']=$this->interaction->getAllObjectivesOfClient($clientId);
        if ($interactionFor == 'org'){
            $data['arrKolDetails'] = $this->organization->getOrgNames();
            $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId,'org');
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId,'org');
        }
            
        else{
            $data['arrKolDetails'] = $this->kol->getKolNames();
            $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
        }
      
        $data['plans'] = $this->planning->getPlanNames();
        $data['arrTopics'] = $this->interaction->getAllTopicsOfClient($clientId);
// 		$data['arrTopics']		= $this->interaction->getAllTopics();
        $data['arrType'] = $this->interaction->getAllTypesOfClient();
        //	$data['arrBrands']		= $this->interaction->getAllBrandsOfClient($clientId);
        //	$data['arrBrands']=$this->interaction->getAllBrandsOfClient($clientId);
        //	$data['arrRoles']		= $this->interaction->getAllRolesOfClient($clientId);
        //	$data['arrCategories']	= $this->interaction->getAllCategoriesOfClient($clientId);
        $data['arrSpecialties'] = $this->specialty->getAllSpecialties('all');
        
// 		$data['arrProduct']		= $this->interaction->getAllProductsOfClient($clientId);
        $data['arrProduct'] = $this->common_helpers->getUserProducts();
        //send the kol specialty also it the interaction if for kol specific
        //$data['arrUsers']		= $this->kol->getAllNonProfiledKols();
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $data['arrClientUsers'] = $this->interaction->getCleintUSers();
        $locationType = $this->interaction->getInteractionLocationTypes();
        $arrInteractionLocationTypesTemp = array();
        foreach ($locationType as $key => $value) {
            $arrInteractionLocationTypesTemp[$value['id']] = ($value['name']);
        }
        $data['locationType'] = $arrInteractionLocationTypesTemp;
        if ($kolId != null) {
            if ($interactionFor == 'org') {
                $kolDetails[] = $this->organization->editOrganization($kolId);
//				pr($kolDetails);
                $data['last_interaction'] = $this->interaction->getOrgLastInteractionById($kolId);
                
                $data['kolSpecialty'] = $kolDetails[0]['specialty'];
                $data['kolId'] = $kolId;
                $data['kolSpecialty1'] = $data['arrSpecialties'][$data['kolSpecialty']];
                // pr($data['kolSpecialty1']);
                $kolDetails1[] = $this->organization->getOrgDetailsById($kolId);

                $arrPrimaryContact = array();
                $arrPrimaryContact[0] = array(
                    'id' => -1,
                    'location' => 'Primary',
                    'address' => $kolDetails1[0][0]['address'],
                    'country' => $kolDetails1[0][0]['Country'],
                    'state' => $kolDetails1[0][0]['Region'],
                    'city' => $kolDetails1[0][0]['City']
                );
//				$arrSecondaryContact	= $this->kol->listAdditionalContacts($kolId);
                $data['kolLocations'] = ($arrPrimaryContact);
                $data['org_name'] = $this->organization->getOrgNameByOrgId($kolId);
//                                pr($data['kolLocations']);
            } else {
                $kolDetails = $this->kol->getKolDetailsById($kolId);
                $data['last_interaction'] = $this->interaction->getKolLastInteractionById($kolId);
                $data['kolSpecialty'] = $kolDetails[0]['specialty'];
                $data['kolId'] = $kolId;
                $data['kolSpecialty1'] = $data['arrSpecialties'][$data['kolSpecialty']];
                $data['kolTitle'] = $kolDetails[0]['title'];
                $arrPrimaryContact = array();
                $arrPrimaryContact[0] = array(
                    'id' => -1,
                    'location' => 'Primary',
                    'address' => $kolDetails[0]['address1'] . ' ' . $kolDetails[0]['address2'],
                    'country' => $kolDetails[0]['Country'],
                    'state' => $kolDetails[0]['Region'],
                    'city' => $kolDetails[0]['City']
                );
                $arrSecondaryContact = $this->kol->listAdditionalContacts($kolId);
                $data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
                //	pr($kolDetails);
            }
        }
        if($interactionFor=='org'){
            $kols_or_org_type = 'Organization';
        }else{
            $kols_or_org_type = 'Kol';
        }
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => VIEW_RECORD,
            'description' => 'ADD Interaction',
            'status' => STATUS_SUCCESS,
            'kols_or_org_type' => $kols_or_org_type,
            'kols_or_org_id' => $kolId,
            'transaction_id' => '',
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => "ADD Interaction",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        //log_user_activity($arrLogDetails, true);
        $data['interactionDetails'] = null;
        $data['kolId1'] = $kolId;
        $this->load->model('Country_helper');
        $data['arrStates'] = $this->Country_helper->getStatesByCountryId();
        if (!IS_AJAX) {
            if ($kolId == null) {
                $data['contentPage'] = "interactions/interaction_form";
            } else {
                $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                $data['arrSalutations'] = $arrSalutations;
                $data['arrKol'] = $kolDetails[0];
                $data['subContentPage'] = 'interaction';
                $data['contentPage'] = "interactions/interaction_form_within_kol";
            }
            $this->load->view('layouts/client_view', $data);
        } else {
            if ($kolId == null) {
                $this->load->view("interactions/interaction_form", $data);
            } else {
// 				pr($data);
				$data['hideSidebar'] = 1;
                $this->load->view("interactions/interaction_form_within_kol", $data);
// 				$this->load->view("interactions/kol_interaction",$data);
            }
        }
    }

    /**
     * Saves/Updates the Interaction details for kol
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return 
     */
    function save_interaction() {
		//pr($_POST);exit;
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
    	if($this->input->post("date") == ''){
    		//Add Log activity
	        $formData = $_POST;
	        $formData = json_encode($formData);
	        $arrLogDetails = array(
	        	'type' => ADD_RECORD,
	            'description' => 'New Interaction',
	            'status' => STATUS_SUCCESS,
	            'transaction_id' => '',
	            'transaction_table_id' => INTERACTIONS,
	            'transaction_name' => "New Interaction",
	            'form_data' => $formData,
	            'parent_object_id' => ''
	        );	
	        $this->config->set_item('log_details', $arrLogDetails);
	        
	        $interactionFor = $this->input->post('interaction_for');
	        $isRequestFrom = $this->input->post('is_from');
	        $kolId = $this->input->post('kol_id');
	        $orgId = $this->input->post('org_within_id');
    		if ($isRequestFrom == 'kol') {
	            if ($interactionFor == 'org'){
	                if (IS_IPAD_REQUEST)
	                    redirect(IPAD_URL_SEGMENT . '/organizations/view_interactions/' . $orgId);
	                else
	                    redirect('organizations/view_interactions/' . $orgId . '/interaction_report');
	            }
	            else {
	                if (IS_IPAD_REQUEST) {
	                    redirect(IPAD_URL_SEGMENT . '/kols/interaction_report/' . $kolId);
	                } else {
	                    redirect('kols/view/' . $kolId . '/interaction_report');
	                }
	            }
	        } else {
	            redirect("interactions/list_interactions");
	        }
    	}
        $arrKols = $this->payment->getAllKolsName1();
        $interactionFor = $this->input->post('interaction_for');
        $kolNames = '';
        $seperator = '';
        //Prepare a interaction details array fro post data
        $arrInteractionDetails = array();
        $calendarEventId = 0;
        $callFrom = 0;
        $id = $this->input->post('interaction_id');
        $isRequestFrom = $this->input->post('is_from');
        if ($id != null && $id != '')
            $arrInteractionDetails['id'] = $id;
        //	$arrInteractionDetails['objective_id']		=	$this->input->post('objective_id');
        //$arrInteractionDetails['kol_id']			=	$this->input->post('kol_id');
        //$kolName  									= 	trim($this->input->post('kol_name'));
        $quality_interaction = $this->input->post('quality_interaction');
        if ($quality_interaction != null)
            $arrInteractionDetails['quality_interaction'] = 1;
        else
            $arrInteractionDetails['quality_interaction'] = 0;

        
        //-- Prparing array for No fo attendis
        $noOfkolfiles = $this->input->post('noOfKols');
        $arrName['kol_name'] = trim($this->input->post('kol_name'));
        $arrName['kol_id'] = trim($this->input->post('kol_id'));
        $arrName['status'] = $this->input->post('status');
        //	$arrName['category_id'] = $this->input->post('category');
        //	$arrName['role_id']		= $this->input->post('role');
        $arrName['note'] = $this->input->post('attendee_note');
        $arrKolId[] = $arrName;
        if ($interactionFor == 'org'){
        	$arrInteractionDetails['is_org_interaction'] = 1;
        	$arrKolId = array();
        }
        
        if ($noOfkolfiles >= 1) {
            for ($i = 1; $i <= $noOfkolfiles; $i++) {
                if ($this->input->post('kol_name' . $i) != '') {
                    $arrName1['kol_name'] = trim($this->input->post('kol_name' . $i));
                    $kolNames .= $seperator . $arrName1['kol_name'];
                    $seperator = ', ';
                    //	$arrName1['category_id']	= $this->input->post('category'.$i);
                    //	$arrName1['role_id']		= $this->input->post('role'.$i);
                    $arrName1['kol_id'] = trim($this->input->post('kol_id_auto' . $i));
                    $arrName1['note'] = $this->input->post('attendee_note' . $i);
                    if ($interactionFor == 'org'){
                    	if($this->input->post('attendee_types' . $i) !=''){
                    		$arrName1['attendeeType'] = $this->input->post('attendee_types' . $i);
                    	}else{
                    		$arrName1['attendeeType'] = $this->input->post('attendee_type' . $i);
                    	}
                    }
                    $arrName1['status'] = $this->input->post('status' . $i);
                    //$arrName1['last_interaction']	= $this->input->post('last_interaction'.$i);

                    if ($arrName1['kol_id'] == '') {

                        $arrName1['kol_id'] = array_search($arrName1['kol_name'], $arrKols);
                    }

                    //$arrName1['kol_id'] = array_search($arrName1['kol_name'],$arrKols);
                    if ($arrName1['kol_id'] == '') {
                        $kolName = $arrName1['kol_name'];
                        $kolSaved = '';
                        $checkCamma = strpos($kolName, ',');
                        $kolDetail = array();
                        if ($checkCamma != '') {

                            $kolNameExplodeBy = explode(',', $kolName);
                            //pr($kolNameExplodeBy);
                            if (sizeOf($kolNameExplodeBy) == 1) {
                                $kolDetail['first_name'] = $kolNameExplodeBy[0];
                            }
                            if (sizeOf($kolNameExplodeBy) == 2) {
                                $kolDetail['last_name'] = $kolNameExplodeBy[0];
                                $kolDetail['first_name'] = $kolNameExplodeBy[1];
                            }
                            if (sizeOf($kolNameExplodeBy) == 3) {
                                $kolDetail['last_name'] = $kolNameExplodeBy[0];
                                $kolDetail['first_name'] = $kolNameExplodeBy[1];
                                $kolDetail['middle_name'] = $kolNameExplodeBy[2];
                            }

                            $checkKolname = $kolDetail['first_name'] . " " . $kolDetail['middle_name'] . " " . $kolDetail['last_name'];
                            $kolId = array_search($checkKolname, $arrKols);
                            if ($kolId == '') {
                                $kolDetail['created_by'] = $this->session->userdata('user_id');
                                $kolDetail['status'] = PRENEW;
                                $arrName1['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
                            } else {
                                $arrName1['kol_id'] = $kolId;
                            }
                            $kolSaved = 'Saved';
                        }
                        if ($kolSaved != 'Saved') {

                            $splitByspace = explode(" ", $kolName);

                            if (sizeOf($splitByspace) == 2) {

                                $kolDetail['first_name'] = $splitByspace[0];
                                $kolDetail['last_name'] = $splitByspace[1];
                            }

                            if (sizeOf($splitByspace) == 3) {

                                $kolDetail['first_name'] = $splitByspace[0];
                                $kolDetail['middle_name'] = $splitByspace[1];
                                $kolDetail['last_name'] = $splitByspace[2];
                            }

                            if (sizeOf($splitByspace) > 3) {
                                $kolDetail['first_name'] = $splitByspace[0];
                                $kolDetail['middle_name'] = $splitByspace[1];
                                $kolDetail['last_name'] = $splitByspace[2] . " " . $splitByspace[3];
                            }
                            $kolDetail['created_by'] = $this->session->userdata('user_id');
                            $kolDetail['status'] = PRENEW;

                            $arrName1['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
                        }


                        //echo $this->db->last_query();
                    }

                    $arrKolId[] = $arrName1;
                }
            }
        }
        //-- end Of Preparing arr for No fo attnedis
        //Preparing Array for Topics
        $noOfObjectives = $this->input->post('noOfObjectives');
        $topicDeatil['product_id'] = $this->input->post('product');
        $topicDeatil['interaction_type'] = $this->input->post('objective');
        $topicDeatil['topic_id'] = $this->input->post('topic');
        $topicDeatil['sub_topic_id'] = $this->input->post('subtopic');
        $arrTopicDetail[] = $topicDeatil;
        if ($noOfObjectives >= 1) {
            for ($j = 1; $j <= $noOfObjectives; $j++) {
                if ($this->input->post('topic' . $j) != '') {
                    $topicDeatil1['product_id'] = $this->input->post('product' . $j);
                    $topicDeatil1['interaction_type'] = $this->input->post('objective' . $j);
                    $topicDeatil1['topic_id'] = $this->input->post('topic' . $j);
                    $topicDeatil1['sub_topic_id'] = $this->input->post('subtopic' . $j);
                    $arrTopicDetail[] = $topicDeatil1;
                }
            }
        }
        //End of preparing array
        //Preparing Array for Other attendees
        $arrOtherAttendees = array();
        $noOfNonProfiledKols = $this->input->post('noOfNonProfiledKols');
        $otherAttendees = array();
        $otherAttendees['non_profiled_kol'] = $this->input->post('non_profiled_kol');
        $otherAttendees['non_profifled_specialty'] = $this->input->post('non_profifled_specialty');
        $otherAttendees['non_profiled_comment'] = $this->input->post('non_profiled_comment');
        $arrOtherAttendees[] = $otherAttendees;
        if ($noOfNonProfiledKols >= 1) {
            for ($j = 1; $j <= $noOfNonProfiledKols; $j++) {
                if ($this->input->post('non_profiled_kol' . $j) != '') {
                    $otherAttendees['non_profiled_kol'] = $this->input->post('non_profiled_kol' . $j);
                    $otherAttendees['non_profifled_specialty'] = $this->input->post('non_profifled_specialty' . $j);
                    $otherAttendees['non_profiled_comment'] = $this->input->post('non_profiled_comment' . $j);
                    $arrOtherAttendees[] = $otherAttendees;
                }
            }
        }
        //pr($arrOtherAttendees);
        //End of preparing array

        $kolId1 = $this->input->post('kol_id');
        if (isset($kolId1) && $kolId1 != '') {
            $callFrom = 1;
            $kolId = $this->input->post('kol_id');
        }
        $arrInteractionDetails['save_later'] = $this->input->post('save_later');
        $arrInteractionDetails['total_attendies'] = $this->input->post('total_attendies');
        $arrInteractionDetails['date'] = app_date_to_sql_date($this->input->post('date'));
        $arrInteractionDetails['fromtime'] = NULL;//$this->input->post('timefmhr') . ":" . $this->input->post('timefmmin') . " " . $this->input->post('timefmap');
        //	$arrInteractionDetails['totime']			= $this->input->post('timetohr').":".$this->input->post('timetomin')." ".$this->input->post('timetoap');
        $arrInteractionDetails['mode'] = $this->input->post('mode');
          $arrInteractionDetails['plan_name'] = $this->input->post('plan_name');
        $arrInteractionDetails['location_category'] = $this->input->post('location_category');
        //	$arrInteractionDetails['location']			= $this->input->post('int_location');
        $arrInteractionDetails['follow_up_on'] = app_date_to_sql_date($this->input->post('follow_up_on'));
        if (empty($arrInteractionDetails['follow_up_on'])) {
            $arrInteractionDetails['reminder'] = 0;
        } else {
            $arrInteractionDetails['reminder'] = 1;
        }
        $arrInteractionDetails['grouping'] = $this->input->post('grouping');
        $arrInteractionDetails['notes'] = $this->input->post('notes');
        $arrInteractionDetails['location_type'] = $this->input->post('selectedLocation');
        if ($interactionFor == 'org') {
        	$orgId = $this->input->post('org_within_id');
        	if ($arrInteractionDetails['location_type'] == -1) {
	        	$OrgContactDetails = $this->interaction->getOrgLocaionDetailsById($orgId);
	        	$arrInteractionDetails['location'] = 'Primary';
	        	$arrInteractionDetails['address'] = $OrgContactDetails[0]['address'];
	        	$arrInteractionDetails['city_id'] = $OrgContactDetails[0]['city_id'];
	        	$arrInteractionDetails['state_id'] = $OrgContactDetails[0]['state_id'];
	        	$arrInteractionDetails['country_id'] = $OrgContactDetails[0]['country_id'];
	        	$arrInteractionDetails['postal_code'] = $OrgContactDetails[0]['postal_code'];
        	}else {
	            $arrInteractionDetails['location'] = 'Other';
	            $arrInteractionDetails['address'] = $this->input->post('address1');
	            $arrInteractionDetails['address2'] = $this->input->post('address2');
	            $arrInteractionDetails['city_id'] = $this->input->post('city');
	            $arrInteractionDetails['state_id'] = $this->input->post('state');
	            $arrInteractionDetails['postal_code'] = $this->input->post('postal_code');
	            $arrInteractionDetails['country_id'] = $this->input->post('country_id');
	        }
        }else{
	        if ($arrInteractionDetails['location_type'] == -1) {
	            $kolContactDetails = $this->kol->getKolDetailsById($kolId);
	            $arrInteractionDetails['location'] = 'Primary';
	            $arrInteractionDetails['address'] = $kolContactDetails[0]['address1'];
	            $arrInteractionDetails['address2'] = $kolContactDetails[0]['address2'];
	            $arrInteractionDetails['city_id'] = $kolContactDetails[0]['city_id'];
	            $arrInteractionDetails['state_id'] = $kolContactDetails[0]['state_id'];
	            $arrInteractionDetails['country_id'] = $kolContactDetails[0]['country_id'];
	            $arrInteractionDetails['postal_code'] = $kolContactDetails[0]['postal_code'];
	        } else if ($arrInteractionDetails['location_type'] > 0) {
	            $arrKolLocations = $this->kol->getAdditionalContactByType($kolId, $arrInteractionDetails['location_type']);
	            $arrInteractionDetails['location'] = $arrKolLocations[0]['location'];
	            $arrInteractionDetails['address'] = $arrKolLocations[0]['address'];
	            $arrInteractionDetails['city_id'] = $arrKolLocations[0]['city_id'];
	            $arrInteractionDetails['state_id'] = $arrKolLocations[0]['state_id'];
	            $arrInteractionDetails['country_id'] = $arrKolLocations[0]['country_id'];
	            $arrInteractionDetails['postal_code'] = '';
	        } else {
	            $arrInteractionDetails['location'] = 'Other';
	            $arrInteractionDetails['address'] = $this->input->post('address1');
	            $arrInteractionDetails['address2'] = $this->input->post('address2');
	            $arrInteractionDetails['city_id'] = $this->input->post('city');
	            $arrInteractionDetails['state_id'] = $this->input->post('state');
	            $arrInteractionDetails['postal_code'] = $this->input->post('postal_code');
	            $arrInteractionDetails['country_id'] = $this->input->post('country_id');
	        }
        }
        $arrInteractionDetails['calendar_event_id'] = $this->input->post('calendar_event_id');
        //$arrKolDetails							= $this->kol->getKolDetailsById($arrInteractionDetails['kol_id']);
        //$arrInteractionDetails['therapeutic_area']= $arrKolDetails[0]['specialty'];
        $arrInteractionDetails['fromtime'] = $this->common_helpers->convert12HourTo24HoureFormat($arrInteractionDetails['fromtime']);
        //$arrInteractionDetails['totime']			= $this->common_helpers->convert12HourTo24HoureFormat($arrInteractionDetails['totime']);


        $interactionId = "";
        //Interaction calendar event details
        $returnData = array();
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $arrEventDetails = array();
        //	$arrKolName							=$this->kol->getKolName($arrInteractionDetails['kol_id']);
        $arrEventDetails['subject'] = "Follow up Meeting: " . $kolNames;
        $arrEventDetails['starttime'] = $arrInteractionDetails['follow_up_on'];
        $arrEventDetails['endtime'] = $arrInteractionDetails['follow_up_on'];
        $arrEventDetails['isalldayevent'] = true;
        $arrEventDetails['description'] = 'Interaction Description: ' . $arrInteractionDetails['notes'];
        $arrEventDetails['location'] = $arrInteractionDetails['location'];
        $arrEventDetails['color'] = "9";
        $arrEventDetails['client_id'] = $clientId;
        $arrEventDetails['event_type'] = EVENT_TYPE_INTERACTION;

        $intarnalUsers = $this->input->post('users');
       
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
//         pr($_POST);exit;
        //Update the interaction if the id is already present else save a new interaction record
        if ($id != null && $id != '') {
            //Add/Update the calender event if reminder is checked
            if ($arrInteractionDetails['reminder'] == true) {
                if ($arrInteractionDetails['calendar_event_id'] != 0) {
                    //Update the calender event
                    $arrEventDetails['id'] = $arrInteractionDetails['calendar_event_id'];
                    $arrEventDetails['modified_by'] = $userId;
                    $arrEventDetails['modified_on'] = date("Y-m-d H:i:s");
                    $this->calendar->updateEvent($arrEventDetails);
                    $calendarEventId = $arrEventDetails['id'];
                } else {
                    //Add the calender event
                    $arrInteractionDetails['calendar_event_id'] = $calendarEventId;
                    $arrEventDetails['created_by'] = $userId;
                    $arrEventDetails['created_on'] = date("Y-m-d H:i:s");
                    $calendarEventId = $this->calendar->addEvent($arrEventDetails);
                }
            } else {
                //If reminder is unchecked and interaction has any calender event then delete that
                if ($arrInteractionDetails['calendar_event_id'] != 0) {
                    $this->calendar->deleteEvent($arrInteractionDetails['calendar_event_id']);
                    $calendarEventId = 0;
                }
            }
            $arrInteractionDetails['calendar_event_id'] = $calendarEventId;
            $arrInteractionDetails['modified_by'] = $this->session->userdata('user_id');
            $arrInteractionDetails['modified_on'] = date('Y-m-d H:i:s');
            $arrInteractionDetails['mirf_case_num'] = strtoupper($this->input->post('mirf_case_num'));
            $arrInteractionDetails['territory_id'] = $this->input->post('territory');
            //$arrInteractionDetails['employee_id'] = $this->input->post('employee_id');
            $arrInteractionDetails['employee_id'] = $userId;
//             $arrInteractionDetails['data_type_indicator'] = $dataType;
            $isSaved = $this->interaction->updateInteraction($arrInteractionDetails);

            $interactionId = $arrInteractionDetails['id'];

            $this->interaction->deleteInteractionAttendis($arrInteractionDetails['id']);
            $this->interaction->deleteInteractionOtherAttendis($arrInteractionDetails['id']);
// 			$this->interaction->deleteInteractionTopicDetail($arrInteractionDetails['id']);
            $this->interaction->deleteInteractionDiscussionTopicDetail($arrInteractionDetails['id']);
            $this->interaction->deleteInteractionUsers($arrInteractionDetails['id']);
            
            foreach ($arrKolId as $kolAndCatdetail) {
            	$kolAndCatdetailData = array();
                unset($kolAndCatdetail['kol_name']);
                $kolAndCatdetailData['interaction_id'] = $arrInteractionDetails['id'];
                if ($interactionFor == 'org') {
//                 	$kolAndCatdetail['org_id'] = $kolAndCatdetail['kol_id'];
                	if($kolAndCatdetail['attendeeType']=='key_type'){
                		$kolAndCatdetailData['key_id'] = $kolAndCatdetail['kol_id'];
                		$kolAndCatdetailData['org_id'] = $this->input->post('org_within_id');
                	}else{
                		$kolAndCatdetailData['org_id'] = $this->input->post('org_within_id');
                    	$kolAndCatdetailData['kol_id'] = $kolAndCatdetail['kol_id'];
                	}
                    unset($kolAndCatdetail['kol_id']);
                }else{
                	$kolAndCatdetailData['kol_id'] = $kolAndCatdetail['kol_id'];
                	$kolAndCatdetailData['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kolAndCatdetail['kol_id']);
                }
                $this->interaction->saveInteractionAttendis($kolAndCatdetailData);
// 				echo $this->db->last_query();
                $this->update->insertUpdateEntry(INTERACTION_UPDATE, $arrInteractionDetails['id'], MODULE_INTERACTION, $kolAndCatdetail['kol_id']);
            }
//             pr($arrKolId);exit;
            foreach ($arrOtherAttendees as $arrOtherAttendeesDetails) {
                $arrOtherAttendeesDetails1 = array();
                $arrOtherAttendeesDetails1['interaction_id'] = $interactionId;
                $arrOtherAttendeesDetails1['name'] = $arrOtherAttendeesDetails['non_profiled_kol'];
                $arrOtherAttendeesDetails1['comments'] = $arrOtherAttendeesDetails['non_profiled_comment'];
                $arrOtherAttendeesDetails1['specialty_id'] = $arrOtherAttendeesDetails['non_profifled_specialty'];
                $this->interaction->saveOtherAttendis($arrOtherAttendeesDetails1);
            }

            foreach ($arrTopicDetail as $topicDeatl) {
                $topicDeatl['interaction_id'] = $arrInteractionDetails['id'];
                $this->interaction->saveInteractionTopicDetail($topicDeatl);
            }
            if (!empty($intarnalUsers) && (sizeof($intarnalUsers) > 0))
                foreach ($intarnalUsers as $user) {
                    $users['user_id'] = $user;
                    $users['interaction_id'] = $arrInteractionDetails['id'];
                    $this->interaction->saveInteractionInternalUsers($users);
                }
        } else {
            //Save the calender event if reminder is checked
            if ($arrInteractionDetails['reminder'] == true) {
                $arrEventDetails['created_by'] = $userId;
                $arrEventDetails['created_on'] = date("Y-m-d H:i:s");

                $calendarEventId = $this->calendar->addEvent($arrEventDetails);
            }
            $arrInteractionDetails['calendar_event_id'] = $calendarEventId;
            $arrInteractionDetails['created_by'] = $this->session->userdata('user_id');
            $arrInteractionDetails['created_on'] = date('Y-m-d H:i:s');
            $arrInteractionDetails['mirf_case_num'] = strtoupper($this->input->post('mirf_case_num'));
            $arrInteractionDetails['territory_id'] = $this->input->post('territory');
            $arrInteractionDetails['employee_id'] = $userId;
            $arrInteractionDetails['data_type_indicator'] = $dataType;
            //$arrInteractionDetails['employee_id'] = $this->input->post('employee_id');
            $genericId = $this->common_helpers->getGenericId("Interactions Name");
            $arrInteractionDetails['generic_id'] = $genericId;
            $arrInteractionDetails['client_id'] = $this->session->userdata('client_id');
            $interactionId = $this->interaction->saveInteraction($arrInteractionDetails);
			
            foreach ($arrKolId as $kolAndCatdetail) {
            	$kolAndCatdetailData = array();
                unset($kolAndCatdetail['kol_name']);
                $kolAndCatdetailData['interaction_id'] = $interactionId;
//                 $kolAndCatdetail['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kolAndCatdetail['kol_id']);
                if ($interactionFor == 'org') {
//                     $kolAndCatdetail['org_id'] = $kolAndCatdetail['kol_id'];
                	if($kolAndCatdetail['attendeeType']=='key_type'){
                		$kolAndCatdetailData['key_id'] = $kolAndCatdetail['kol_id'];
                		$kolAndCatdetailData['org_id'] = $this->input->post('org_within_id');
                	}else{
                    	$kolAndCatdetailData['kol_id'] = $kolAndCatdetail['kol_id'];
                    	$kolAndCatdetailData['org_id'] = $this->input->post('org_within_id');
                	}
                    unset($kolAndCatdetail['kol_id']);
                }else{
                	$kolAndCatdetailData['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kolAndCatdetail['kol_id']);
                	$kolAndCatdetailData['kol_id'] = $kolAndCatdetail['kol_id'];
                }
                
                $this->interaction->saveInteractionAttendis($kolAndCatdetailData);
                $this->update->insertUpdateEntry(INTERACTION_ADD, $interactionId, MODULE_INTERACTION, $kolAndCatdetail['kol_id']);
            }
            foreach ($arrOtherAttendees as $arrOtherAttendeesDetails) {
                $arrOtherAttendeesDetails1 = array();
                $arrOtherAttendeesDetails1['interaction_id'] = $interactionId;
                $arrOtherAttendeesDetails1['name'] = $arrOtherAttendeesDetails['non_profiled_kol'];
                $arrOtherAttendeesDetails1['specialty_id'] = $arrOtherAttendeesDetails['non_profifled_specialty'];
                $arrOtherAttendeesDetails1['comments'] = $arrOtherAttendeesDetails['non_profiled_comment'];
                $this->interaction->saveOtherAttendis($arrOtherAttendeesDetails1);
            }

            foreach ($arrTopicDetail as $topicDeatl) {
                $topicDeatl['interaction_id'] = $interactionId;
                $this->interaction->saveInteractionTopicDetail($topicDeatl);
            }
            if (!empty($intarnalUsers) && (sizeof($intarnalUsers) > 0))
                foreach ($intarnalUsers as $user) {
                    $users['user_id'] = $user;
                    $users['interaction_id'] = $interactionId;
                    $this->interaction->saveInteractionInternalUsers($users);
                    //echo $this->db->last_query();
                }
        }
        //exit;
        //Interactions documents path
        $target_path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "/documents/kol_interactions_documents";
        $i = 1;
        //Max no of files to be uploaded
        $noOfFiles = $this->input->post('no_of_files');

        //Loop trough each uploaded file name
        for ($i = 1; $i <= $noOfFiles; $i++) {
            //Proceed only if the uploaded file name is not blank			
            if ($_FILES["int_ref_file" . $i]['name'] != null && $_FILES["int_ref_file" . $i]['name'] != "") {
                //Get the file information, use for file validations like allowed file type, file size etc
                $path_info = pathinfo($_FILES["int_ref_file" . $i]['name']);
                $path_info['size'] = $_FILES["int_ref_file" . $i]['size'];
                //Generate a randome name
                $newFileName = random_string('unique', 20) . "." . $path_info['extension'];
                $overview_file_target_path = $target_path . "/" . $newFileName;
                //Move uploaded file in to interactions document location
                if (move_uploaded_file($_FILES['int_ref_file' . $i]['tmp_name'], $overview_file_target_path)) {
                    $arrDocDetails = array();
                    $arrDocDetails['interaction_id'] = $interactionId;
                    $arrDocDetails['name'] = $this->input->post('doc_name' . $i);
                    if(empty($arrDocDetails['name'])){
                        $arrDocDetails['name'] = 'File'. $i;
                    }
                    $arrDocDetails['description'] = $this->input->post('description' . $i);
                    if(empty($arrDocDetails['description'])){
                        $arrDocDetails['description'] = 'File'. $i;
                    }
                    $arrDocDetails['doc_path'] = $newFileName;
                    $arrDocDetails['created_by'] = $this->session->userdata('user_id');
                    $arrDocDetails['created_on'] = date('Y-m-d H:i:s');

                    $this->interaction->saveInteractionDocument($arrDocDetails);
                } else {
                    echo "Error";
                }
            }
        }
        if($interactionFor=='org'){
            $kols_or_org_type = 'Organization';
            $kols_or_org_id = $this->input->post('org_within_id');
            $description = 'New Org Interaction';
        }else{
            $kols_or_org_type = 'Kol';
            $kols_or_org_id = $this->input->post('kol_id');
            $description = 'New Interaction';
        }
        //Add Log activity
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => ADD_RECORD,
            'description' => $description,
            'status' => STATUS_SUCCESS,
            'kols_or_org_type' => $kols_or_org_type,
            'kols_or_org_id' => $kols_or_org_id,
            'transaction_id' => $interactionId,
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => $description,
            'form_data' => $formData,
            'parent_object_id' => $kols_or_org_id
        );

        if ($id != null && $id != '') {
            $arrLogDetails['type'] = EDIT_RECORD;
            $arrLogDetails['transaction_id'] = $interactionId;
            if($interactionFor=='org'){
                $arrLogDetails['description'] = 'Update Org Interaction';
                $arrLogDetails['transaction_name'] = 'Update Org Interaction';
            }else{
                $arrLogDetails['description'] = 'Update Interaction';
                $arrLogDetails['transaction_name'] = 'Update Interaction';
            }
            
            /* $mirfDetails = $this->interaction->getMirfByInteraction($interactionId);
            if(isset($mirfDetails['id']))
            	$data['isMirfUpdate'] = true; */
        }else{
        	$interactionUniqueId = $this->interaction->getInteractionDetails($interactionId);
        	$this->send_added_interaction_report($kols_or_org_id, $interactionFor, $interactionUniqueId['generic_id']);
        }

        $this->config->set_item('log_details', $arrLogDetails);
        //exit;
        //
        	$data['interactionId']   = $interactionId;   
			if ($interactionFor == 'org'){
					$this->load->model('organization');
	                $kolDetails[] = $this->organization->editOrganization($kolId);
	                 $data['arrOrganization'] = $kolDetails[0];
	                 $data['orgId'] 	= $kolId;
	                 $data['kolId'] 	= $kolId;
			}else{
					$kolDetails = $this->kol->getKolDetailsById($kolId);
					$data['arrKol'] = $kolDetails[0];
					$data['arrSalutations'] = $arrSalutations;
	                $data['arrKol'] = $kolDetails[0];
	                $data['kolId'] 	= $kolId;
	                $data['subContentPage'] = 'interaction';
			}
			//send_added_interaction_report($id, $interactionFor, $interactionId);
	        $data['interactionFor'] = $interactionFor;
	        $data['orgInteractionId'] = $this->input->post('org_within_id');
	        $data['contentPage'] = "interactions/interaction_success";
	        if(IS_IPAD_REQUEST)
	        	$this->load->view(IPAD_APP_FOLDER.'/layouts/bootstrap_layout', $data);
	        else
	        	$this->load->view('layouts/client_view', $data);
        //If the action is from within profile
        /*if ($isRequestFrom == 'kol') {
            if ($interactionFor == 'org')
                if (IS_IPAD_REQUEST)
                    redirect(IPAD_URL_SEGMENT . '/organizations/view_interactions/' . $kolId);
                else
                    redirect('organizations/view_interactions/' . $kolId . '/interaction_report');
            else {
                if (IS_IPAD_REQUEST) {
                    redirect(IPAD_URL_SEGMENT . '/kols/interaction_report/' . $kolId);
                } else {
                    redirect('kols/view/' . $kolId . '/interaction_report');
                }
            }
        } else {
            redirect("interactions/list_interactions");
        }*/
    }

    /**
     * Gets the all the Interactions of the user client and returns in to list page
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return 
     */
    function list_interactions($subContentPage = '') {
        $kolId = $this->session->userdata('kolId');
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');
        $arrYearRange = $this->interaction->getInteractionsYearsRange($clientId, $userId);
        if ($arrYearRange['max_year'] == '')
            $arrYearRange['max_year'] = date("Y");
        if ($arrYearRange['min_year'] == '')
            $arrYearRange['min_year'] = (int) $arrYearRange['max_year'] - 25;

        $data['arrYearRange'] = $arrYearRange;
        //	if($kolId==-1 || empty($kolId)){
        $data['contentPage'] = 'interactions/list_interactions';
        $data['subContentPage'] = $subContentPage;
        $this->load->view('layouts/client_view', $data);
        //}else{
        //		$this->load->view('interactions/list_interactions', $data);
        //}
    }

    /**
     * Gets the interaction details of a given interaction id and repopulate dtails in the Interaction form
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return 
     */
    function edit_interaction($interactionId, $kolId = null) {
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        $data['kolId1'] = null;
        if ($this->session->userdata('user_role_id') == ROLE_USER) {
            $userId = $this->session->userdata('user_id');
        }
        $arrTopics = $this->interaction->getInteractionDiscussionTopics($interactionId);
        
        $interactionDetails = $this->interaction->getInteractionDetails($interactionId);
       
        if ($interactionDetails['is_org_interaction'] == 1){
            $data['interactionFor'] = 'org';
            $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId,'org');
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId,'org');
        }
        else{
              $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
            
        }
        $interactionDetails['territory_name'] = '';
// 		if($interactionDetails['territory_id'] != '' OR $interactionDetails['territory_id'] != 0)
// 			$interactionDetails['territory_name'] = $this->interaction->getTerritoryNameById($interactionDetails['territory_id']);

        $otherAttendisData = $this->interaction->getOtherAttendisDataById($interactionId);
        $interactionDetails['otherAttendisData'] = $otherAttendisData;
        $interactionDetails['attendies'] = $this->interaction->getInteractionAttendis($interactionId);
        foreach ($arrTopics as $row) {
            //pr($row);
            $arrDiscussion[] = $this->prepare_discussion_topic_data($row);
        }
 		//pr($arrDiscussion);
       // exit;
        $data['arrDiscussion'] = $arrDiscussion;
        foreach ($arrTopics as $row) {
            $row['topics'] = $this->interaction->getTpicByProduct($interactionDetails['grouping'], $row['product_id'], $row['objective_id']);
            $arr[] = $row;
        }
        $interactionDetails['arrSelectedTopics'] = $arr;
        $interactionDetails['noOfKols'] = sizeOf($interactionDetails['attendies']) - 1;
        $interactionDetails['noOfObjectives'] = sizeOf($interactionDetails['arrSelectedTopics']) - 1;
        $arrUserDetails = $this->client_user->editUser($interactionDetails['created_by']);
        $interactionDetails['user_name'] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
        $interactionDetails['fromtime'] = $this->common_helpers->convert24HourTo12HoureFormat($interactionDetails['fromtime']);
        $interactionDetails['totime'] = $this->common_helpers->convert24HourTo12HoureFormat($interactionDetails['totime']);
        if ($interactionDetails['fromtime'] == "")
            $interactionDetails['fromtime'] = "00:00:00";
        if ($interactionDetails['totime'] == "")
            $interactionDetails['totime'] = "00:00:00";

        $data['arrClientUsers'] = $this->interaction->getCleintUSers();
        $data['plans'] = $this->planning->getPlanNames();
        $data['plan_id']=$interactionDetails['plan_name'];
        
        if( $data['interactionFor'] == 'org'){
        	$arrIds = "";
        	foreach($interactionDetails['attendies'] as $aRow)
        		$arrIds[] = $aRow['org_id'];
        	$this->load->model('organization');
        	$data['arrOrgDetails'] = $this->organization->getOrgNames($arrIds);
        }else{
        	$arrIds = "";
        	foreach($interactionDetails['attendies'] as $aRow)
        		$arrIds[] = $aRow['kol_id'];
        	$data['arrKolDetails'] = $this->kol->getKolNames($arrIds);
        }
        //$data['arrBrands']=$this->interaction->getAllBrandsOfClient($clientId);
        //	$data['arrRoles']		= $this->interaction->getAllRolesOfClient($clientId);
        //	$data['arrCategories']	= $this->interaction->getAllCategoriesOfClient($clientId);
        $data['arrSpecialties'] = $this->specialty->getAllSpecialties();
        $data['arrDocs'] = $this->interaction->getInteractionDocs($interactionId);
// 		$data['arrTopics']		= $this->get_topic_by_product('','',$interactionDetails['type_id']);
        $data['arrProduct'] = $this->common_helpers->getUserProducts();
        $data['arrType'] = $this->interaction->getAllTypesOfClient();
        //$data['arrUsers'] = $this->kol->getAllNonProfiledKols();
        $data['internalUsers'] = $this->interaction->getInternalUsers($interactionId);
        $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId,$aRow['org_id']);
        $locationType = $this->interaction->getInteractionLocationTypes();
        $arrInteractionLocationTypesTemp = array();
        foreach ($locationType as $key => $value) {
            $arrInteractionLocationTypesTemp[$value['id']] = ($value['name']);
        }
        $data['locationType'] = $arrInteractionLocationTypesTemp;
// 		$data['arrType']		= $this->interaction->getAllTypesOfClient();
        //$data['last_interaction']	= $this->interaction->getKolLastInteractionById($kolId);
        //don't show last interaction date in edit mode
        $data['last_interaction'] = '';
        
        if ($interactionDetails['location_type'] == -1) {
            $interactionDetails['location'] = '';
            $interactionDetails['state_id'] = '';
            $interactionDetails['city_id'] = '';
            $interactionDetails['postal_code'] = '';
            $interactionDetails['address'] = '';
            $interactionDetails['address2'] = '';
            $interactionDetails['country_id'] = '';
        }
        $data['interactionDetails'] = $interactionDetails;
        if( $data['interactionFor'] == 'org'){
            $OrgContactDetails = $this->kol->getOrgDetailsById($kolId);
        	$arrPrimaryContact = array();
        	$arrPrimaryContact[0] = array(
        			'id' => -1,
        			'location' => 'Primary',
            	    'address' => $OrgContactDetails[0]['address'],
            	    'state' => $OrgContactDetails[0]['Region'],
            	    'city' => $OrgContactDetails[0]['City'],
            	    'country' => $OrgContactDetails[0]['Country']
        			
        	);
        	$data['kolLocations'] = array_merge($arrPrimaryContact);
        }else{
	        if (!empty($kolId)) {
	            $kolContactDetails = $this->kol->getKolDetailsById($kolId);
	            $arrPrimaryContact = array();
	            $arrPrimaryContact[0] = array(
	                'id' => -1,
	                'location' => 'Primary',
	                'address' => $kolContactDetails[0]['address1'] . ' ' . $kolContactDetails[0]['address2'],
	                'state' => $kolContactDetails[0]['Region'],
	                'city' => $kolContactDetails[0]['City'],
	                'country' => $kolContactDetails[0]['Country']
	            );
	            $arrSecondaryContact = $this->kol->listAdditionalContacts($kolId);
	            $data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
	        } else {
	            //	pr($interactionDetails);
	            $kolContactDetails = $this->kol->getKolDetailsById($interactionDetails['attendies'][0]['kol_id']);
	          
	            $arrPrimaryContact = array();
	            $arrPrimaryContact[0] = array(
	                'id' => -1,
	                'location' => 'Primary',
	                'address' => $kolContactDetails[0]['address1'] . ' ' . $kolContactDetails[0]['address2'],
	                'state' => $kolContactDetails[0]['Region'],
	                'city' => $kolContactDetails[0]['City'],
	                'country' => $kolContactDetails[0]['Country'],
	            );
	            $arrSecondaryContact = $this->kol->listAdditionalContacts($interactionDetails['attendies'][0]['id']);
	            $data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
	        }
        }
        //	$userid = $this->session->userdata['user_id'];
        //	$usre1 = $data['arrUsers'][$userid];
        //$data['arrUsers']
        //unset($data['arrUsers'][$userid]);
        //	$data['arrUsers'][$userid]=$usre1;
        //	$arr1[$userid]=$usre1;
        //$data['arrUsers1'] = array_reverse($data['arrUsers']);
        //	foreach($data['arrUsers'] as $key=>$value){
        //		$arr1[$key] = $value;
        //	}
        //pr($arr1);
        //	$data['arrUsers']=$arr1;
        /* 	
          $arrObjectives=array();
          $arrObjectivesResults		=	$this->planning->getPlannedObjectives($userId,$clientId);
          foreach($arrObjectivesResults as $row)
          $arrObjectives[$row['id']]=$row['name'];
          //send the kol specialty also it the interaction if for kol specific
          if($kolId!=null){
          $kolDetails=$this->kol->getKolDetailsById($kolId);
          $data['kolSpecialty']=$kolDetails[0]['specialty'];
          }
          if(isset($interactionDetails['kol_id'])){
          $data['kolId'] = $interactionDetails['kol_id'];
          }
          $data['arrObjectives']=$arrObjectives;
         */
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
        	'type' => EDIT_RECORD,
            'description' => 'Edit Interaction',
            'status' => STATUS_SUCCESS,
            'transaction_id' => $interactionId,
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => "Edit Interaction",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        log_user_activity($arrLogDetails, true);

        $this->load->model('Country_helper');
        $data['arrCountry'] = $this->Country_helper->listCountries();
        if ($interactionDetails['location_type'] != -1) {
    		if($interactionDetails['country_id'] != '')
            	$data['arrStates'] = $this->Country_helper->getStatesByCountryId($interactionDetails['country_id']);
            else
            	$data['arrStates'] = $this->Country_helper->getStatesByCountryId($interactionDetails['country_id']);
        
            if (isset($interactionDetails['city_id']) && $interactionDetails['city_id'] != '') {
                $data['arrCities'] = $this->Country_helper->getCitiesByStateId($interactionDetails['state_id']);
            }
        }
        
        if ($kolId != null) {
            $data['kolId1'] = $kolId;
        }
        if ($kolId == null) {
            $this->load->view("interactions/interaction_form", $data);
        } else {
        	$data['hideSidebar'] = 1;
        	$data['editInteraction'] = 'Edit Interaction';
            $this->load->view("interactions/interaction_form_within_kol", $data);
        }
    }

    function prepare_discussion_topic_data($row) {
    	$arrType = $this->get_type_by_product($row['product_id'],true);
        $arr = array();
        $arr['arrProducts'] = $this->common_helpers->getUserProducts();
        $arr['arrTypes'] = $arrType;//$this->interaction->getAllTypesOfClient();
        $arr['arrTopics'] = $this->interaction->getTopicByType($row['interaction_type'], $row['product_id']);
        $arr['arrSubTopics'] = $this->interaction->getSubTopics($row['product_id'], $row['interaction_type'], $row['topic_id']);
        $arr['row'] = $row;
        return $arr;
    }

    /**
     * Gets the interaction details of a given interaction id seds thease data into Interaction microview profile page
     * @author 	Ramesh B
     * @Created on: 04-03-11
     * @since	1.5
     * @return 
     */
    function view_micro_interaction($interactionId, $isAjax, $calEventId = null) {

        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        if ($calEventId == null) {
            $interactionDetails = $this->interaction->getInteractionDetails($interactionId);
            //$data['arrDocs']	= $this->interaction->getInteractionDocs($interactionId);
        } else {
            $interactionDetails = $this->interaction->getInteractionByCalEventId($calEventId);
            $interactionId = $interactionDetails['id'];
        }
//		$interactionDetails['internal_users']	= $this->interaction->getInteractionsInternalUsers($interactionId);

		
        $interactionDetails['internal_users'] = $this->interaction->getInteractionsInternalUsers($interactionId);
        $interactionDetails['other_attendees'] = $this->interaction->getOtherAttendisDataById($interactionId);
        $interactionDetails['generic_id'] = $interactionDetails['generic_id'];
        $interactionDetails['created_by_name'] = $this->common_helpers->getUserName($interactionDetails['created_by']);
//                pr($interactionDetails['other_attendees']);
        //	$interactionDetails['salutation']	= $arrSalutations[$interactionDetails['salutation']];
        
        $data['docs'] = $this->interaction->getInteractionDocs($interactionId);
        
        
        $data['interactionDetails'] = $interactionDetails;
        $data['plans'] = $this->planning->getPlanNames();
        $data['plan_id']=$interactionDetails['plan_name'];
        $data['arrHistories'] = $this->find_history($interactionId);
//         pr($data);exit;
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_VIEW,
            'description' => 'View interaction',
            'status' => 'success',
            'transaction_id' => $interactionId,
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => "View interaction",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        log_user_activity($arrLogDetails, true);
        if ($isAjax != "") {
        	$data['backLink'] = 1;
            if($isAjax=='plan'){
                $data['fromPlan']=true;
            }
            $data['contentPage'] = 'interactions/view_interaction_micro_profile';
            $this->load->view('layouts/client_view', $data);
        }

        if ($isAjax == "") {
 			            
            $this->load->view('interactions/view_interaction_micro_profile', $data);
        }
        
    }
	function download_interaction_document($fileName){
		$this->load->helper('download');
		$data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_interactions_documents/".$fileName);
		$name = $fileName;
		force_download($name, $data);
	}
    /**
     * Deletes the document with the given document id
     * @author 	Ramesh B
     * @Created on: 05-03-11
     * @since	1.5
     * @return 
     */
    function delete_document($documentId) {
        $fileName = $this->interaction->deleteDocuments($documentId);
        if ($fileName != false) {
            unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "/documents/kol_interactions_documents/" . $fileName);
            echo true;
        } else {
            echo false;
        }
    }

    /**
     * Deletes the Interaction with the given Interaction id
     * @author 	Ramesh B
     * @Created on: 07-03-11
     * @since	1.5
     * @return 
     */
    function delete_interaction($interactionId) {
        //Delete the calender event if it has
        $arrInteractionDetails = $this->interaction->getInteractionDetails($interactionId);
        if ($arrInteractionDetails['calendar_event_id'] != 0)
            $this->calendar->deleteEvent($arrInteractionDetails['calendar_event_id']);
        //Delete interaction documents
        $arrinteractionDocs = $this->interaction->getInteractionDocs($interactionId);
        if (sizeof($arrinteractionDocs) >= 1) {
            foreach ($arrinteractionDocs as $interactionDoc) {
                //Deletes the doccument and returns its file name
                $fileName = $this->interaction->deleteDocuments($interactionDoc['id']);
                if ($fileName != '') {
                    unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_interactions_documents/" . $fileName);
                }
            }
        }

        //Delete Interaction record
        $isDeleated = $this->interaction->deleteInteraction($interactionId);
        $this->update->deleteUpdateEntry(INTERACTION_ADD, $interactionId, MODULE_INTERACTION);
        $this->update->deleteUpdateEntry(INTERACTION_UPDATE, $interactionId, MODULE_INTERACTION);

        //Delete Interation about(Objective,tpoic,product,Brand);
        $this->interaction->deleteInteractionTopicDetail($interactionId);

        //Delete Interation Attendies
        $this->interaction->deleteInteractionAttendis($interactionId);

        //Delete Interation Usres
        $this->interaction->deleteInteractionUsers($interactionId);
$formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_DELETE,
            'description' => 'Delete interaction',
            'status' => 'success',
            'transaction_id' => $interactionId,
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => "delete_interaction",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);
       
        log_user_activity($arrLogDetails, true);
        //$this->update->insertUpdateEntry(INTERACTION_DELETE,$interactionId, MODULE_INTERACTION, $arrInteractionDetails['kol_id']);
        echo $isDeleated;
    }

    function delete_interaction_within_kol($interactionId, $kolId) {

        $no = $this->interaction->checkNoOfKolsAssoWithInteaction($interactionId);
        echo $no;
        if ($no == 1) {
            $isDeleted = $this->delete_interaction($interactionId);
            $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_DELETE,
            'description' => 'Delete interaction',
            'status' => 'success',
            'transaction_id' => $interactionId,
            'transaction_table_id' => INTERACTIONS,
            'transaction_name' => "delete_interaction",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);
       
        log_user_activity($arrLogDetails, true);
            
        } else {

            $this->interaction->deleteKolAssociation($interactionId, $kolId);
        }
    }

    /**
     * Prepares the JSON data for Interactions count By Interaction type chart 
     * @author 	Ramesh B
     * @Created on: 09-03-11
     * @since	1.5.1
     * @return JSON
     */
    function get_interactions_by_type() {
        $clientId = $this->session->userdata('client_id');
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $groupBy = ($this->input->post('group_by') == null) ? 0 : $this->input->post('group_by');
        $arrKolIds = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrInteractions = $this->interaction->getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds, 0, 0, 0, $groupBy);

        $data = array();
        foreach ($arrInteractions as $interaction) {
            $Intr = array();
            $Intr[0] = $interaction['type'];
            $Intr[1] = (int) $interaction['count'];
            $data[] = $Intr;
        }
        echo json_encode($data);
    }

    /**
     * Prepares the JSON data for top 10 kols by interactions count chart
     * @author 	Ramesh B
     * @Created on: 09-03-11
     * @since	1.5.1
     * @return JSON
     */
    function get_interactions_by_year() {
        $clientId = $this->session->userdata('client_id');
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $groupBy = ($this->input->post('group_by') == null) ? 0 : $this->input->post('group_by');
        $arrKolIds = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        //echo $groupBy;

        $arrInteractions = $this->interaction->getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds, 0, 0, 0, $groupBy = 'month');
        $arrKolNames = array();
        $arrCounts = array();
        $i = 20;
        foreach ($arrInteractions as $interaction) {
            if ($i == 0)
                break;
            $arrKolNames[] = $interaction['year'] . '-' . $this->common_helpers->getMonthName($interaction['month'], true);
            $arrCounts[] = (int) $interaction['count'];
            $i--;
        }
        $data[] = $arrKolNames;
        $data[] = $arrCounts;
        echo json_encode($data);
    }

    /**
     * Gets the interactions belogs to perticular client user with in the perticular date range. 
     * and prepares a json data and returns.
     * @author 	Ramesh B
     * @Created on: 22-08-11
     * @since	3.0
     * @return JSON
     */
    function list_interactions_by_date_range($startDate = null, $endDate = null, $kolId = null) {
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);

        $page = $_REQUEST['page']; // get the requested page
        $limit = $_REQUEST['rows']; // get how many rows we want
        $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
        $sord = $_REQUEST['sord']; // get the direction
        if (!$sidx)
            $sidx = 1;

        //if ($page > $total_pages) $page=$total_pages;
        //$start = $limit*$page - $limit; // do not put $limit*($page - 1)
        //if ($start < 0) $start = 0;
       
        if ($_REQUEST['filters']) {
            $filterData = $_REQUEST['filters'];
            $arrFilter = array();
            $arrFilter = json_decode(stripslashes($filterData));
            $field = 'field';
            $op = 'op';
            $data = 'data';
            $groupOp = 'groupOp';
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $whereResultArray = array();
            foreach ($searchField as $key => $val) {
                $whereResultArray[$val] = $searchString[$key];
            }
            $searchGroupOperator = $searchGroupOperator[0];
            $searchResults = array();
        }
//pr($arrFilter);
        $arrInteractions = array();
        $data = array();
        $arrFilters['end_date'] = $this->input->post('ed');
        $arrFilters['start_date'] = $this->input->post('sd');
        if($arrFilters['end_date'] != '')
        $arrFilters['end_date'] = date("Y-m-d",strtotime($arrFilters['end_date']));
        if($arrFilters['start_date'] != '')
        $arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
       //$arrFilters['objective_id'] = $this->input->post('type');
       //$arrFilters['product_id'] = $this->input->post('product');
       //$arrFilters['topic_id'] = $this->input->post('topic');
       //$arrFilters['mode'] = $this->input->post('mode');
       //$arrFilters['grouping'] = $this->input->post('grouping');
       //$arrFilters['user_id'] = $this->input->post('user_id');
        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
       
        
        if($arrMode != 'null' && !empty($arrMode)){
        if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
        if($arrUserId != 'null' && !empty($arrUserId)){
        	if(!is_array($arrUserId)){
        		$arrUserId = explode(",", $arrUserId);
        	}
        }
        
        $arrFilters['objective_id'] = $arrType;
        $arrFilters['product_id'] = $arrProduct;
        $arrFilters['topic_id'] = $arrTopic; 
        $arrFilters['mode'] = $arrMode;
        $arrFilters['grouping'] = $arrGrouping;
        $arrFilters['user_id'] = $arrUserId;
        $arrFilters['org_id'] = $this->input->post('org_id');
        $arrFilters['manager_id'] = $this->input->post('manager_id');
        $arrFilters['plan_id'] = $this->input->post('plan_id');
        if ($kolId == null){
            $kolId = $this->common_helpers->getKolidOrUniqueId($this->input->post('kol_id'));
        }   
        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');

        $arrFilters['interactionFor'] = $this->input->post('interaction_for');
        if($arrFilters['interactionFor'] == 'org'){
        	$kolId = $this->input->post('kol_id');
        	$arrFilters['org_id'] = $kolId;
        }
        $arrInteractions = array();

        $count = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit = 'all', $start, true, $sidx, $sord, $whereResultArray);

        $limit = $_REQUEST['rows']; // get how many rows we want

        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        if ($page > $total_pages)
            $page = $total_pages;
        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        if ($start < 0)
            $start = 0;

        $arrInteractionsResults = array();
        $data = array();
        $arrInteractions = array();
        if ($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit, $start, false, $sidx, $sord, $whereResultArray)) {			
            foreach ($arrInteractionsResults as $arrInteractionResult) {
//                            echo $arrInteractionResult['mirf_id'];
                $arrTypes = array();
                $arrProduct = array();
                $arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
                if ($arrInteraction['date'] == "00/00/0000")
                    $arrInteraction['date'] = '';
                $arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
                $arrInteraction['id'] = $arrInteractionResult['id'];
                $arrInteraction['int_id'] = $arrInteractionResult['id'];
                $arrInteraction['generic_id'] = $arrInteractionResult['generic_id'];
                /* foreach($arrInteractionResult['topic_name'] as $row){

                  $arrProduct['product'][] = $row['product_name'];
                  $arrTypes['type'][] = $row['objective_name'];


                  }

                  $arrInteraction['objective_name']	= implode(', ',array_unique($arrTypes['type']));
                  $arrInteraction['product_name']		= implode(', ',array_unique($arrProduct['product'])); */
                $arrInteraction['is_org_interaction'] = $arrInteractionResult['orgInteractionAction'];
                $arrInteraction['objective_name'] = $arrInteractionResult['type'];
                $arrInteraction['product_name'] = $arrInteractionResult['product'];
                $arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
                if ($arrInteraction['follow_up_on'] == "00/00/0000")
                    $arrInteraction['follow_up_on'] = '';
                //	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
                $arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
                //$arrUserDetails						= $this->client_user->editUser($arrInteractionResult['created_by']);
                $arrInteraction['recorded_by'] = $arrInteractionResult['first_name'] . " " . $arrInteractionResult['last_name'];
                $arrInteraction['recorded_by_name'] = $arrInteractionResult['first_name'] . " " . $arrInteractionResult['last_name'];
//                                $arrInteraction['mirf_add'] = $this->common_helpers->isActionAllowed('mirf','add',$arrInteraction);
                $arrInteraction['msl_id'] = $arrInteractionResult['employee_id'];
                $isMirfAllowed = $this->common_helpers->isActionAllowed('mirf', 'add', $arrInteractionResult);
                if ($isMirfAllowed) {
                    if ($arrInteractionResult['mirf_id'] != null && $arrInteractionResult['mirf_id'] != '')
                    {                      
                      $arrInteraction['mirf'] = "";
                    }
                    else
                        $arrInteraction['mirf'] = "Add";
                }else {
                    $arrInteraction['mirf'] = "";
                }
                $arrInteraction['mirfAllowed'] = $isMirfAllowed;
                $arrInteraction['mirf_id'] = $arrInteractionResult['mirf_id'];
                $arrInteraction['save_later'] = $arrInteractionResult['save_later'];
                if(isset($arrFilters['org_id']) && $arrFilters['org_id']!=''){
                    $arrInteraction['eAllowed'] = $this->common_helpers->isActionAllowed('org_interaction', 'edit', $arrInteractionResult);
                }else{
                    $arrInteraction['eAllowed'] = $this->common_helpers->isActionAllowed('interaction', 'edit', $arrInteractionResult);
                }
                if ($arrInteractionResult['quality_interaction'] == 1)
                    $arrInteraction['quality_interaction'] = 'Yes';
                else
                    $arrInteraction['quality_interaction'] = 'No';

                $arrInteraction['dAllowed'] = $this->common_helpers->isActionAllowed('interaction', 'delete', $arrInteractionResult);
//				$arrInteraction['save_later']	= $arrInteraction['eAllowed'];
				$arrInteraction['emp_name'] = $arrInteractionResult['emp_first_name'] . " " . $arrInteractionResult['emp_last_name'];
				$arrInteraction['client_id'] = $arrInteractionResult['client_id'];
				$arrInteraction['data_type_indicator'] = $arrInteractionResult['data_type_indicator'];
                $arrInteractions[] = $arrInteraction;
            }

            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrInteractions;
        }else{
            $data['records'] = 0;
        }
        echo json_encode($data);
    }

    function list_events_by_date_range($startDate = null, $endDate = null, $kolId = null) {
        $page = (int) $this->input->post('page'); // get the requested page 
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid     	
        $arrInteractions = array();
        $data = array();
        $arrFilters['end_date'] = $this->input->post('end');
        $arrFilters['start_date'] = $this->input->post('start');
        
        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
        
        
        if($arrMode != 'null' && !empty($arrMode)){
            if(!is_array($arrMode)){
                $arrMode = explode(",", $arrMode);
            }
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
            if(!is_array($arrGrouping)){
                $arrGrouping = explode(",", $arrGrouping);
            }
        }
        
        if($arrType != 'null' && !empty($arrType)){
            if(!is_array($arrType)){
                $arrType = explode(",", $arrType);
            }
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
            if(!is_array($arrProduct)){
                $arrProduct = explode(",", $arrProduct);
            }
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
            if(!is_array($arrTopic)){
                $arrTopic = explode(",", $arrTopic);
            }
        }
        
        if($arrUserId != 'null' && !empty($arrUserId)){
            if(!is_array($arrUserId)){
                $arrUserId = explode(",", $arrUserId);
            }
        }
        
       
        $arrFilters['objective_id'] = $arrType;
        $arrFilters['product_id'] = $arrProduct;
        $arrFilters['topic_id'] = $arrTopic;
        $arrFilters['mode'] = $arrMode;
        $arrFilters['grouping'] = $arrGrouping;
        $arrFilters['user_id'] = $arrUserId;
        
        if ($kolId == null){
            $kolId = $this->common_helpers->getKolidOrUniqueId($this->input->post('kol_id'));
        }
        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');
            
        $arrFilters['interactionFor'] = $this->input->post('interaction_for');
        if($arrFilters['interactionFor'] == 'org'){
            $kolId = $this->input->post('kol_id');
            $arrFilters['org_id'] = $kolId;
        }
        $arrInteractions = array();
        if ($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, null, null)) {
            //pr($arrInteractionsResults);
            foreach ($arrInteractionsResults as $arrInteractionResult) {
                $arrTypes = array();
                $arrProduct = array();
                $arrInteraction['generic_id'] = '';
                $arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
                if ($arrInteraction['date'] == "00/00/0000")
                    $arrInteraction['date'] = '';
                $arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
                $arrInteraction['id'] = $arrInteractionResult['id'];
                $arrInteractionResult['generic_id'] = trim($arrInteractionResult['generic_id']);
                if (!empty($arrInteractionResult['generic_id']))
                    $arrInteraction['generic_id'] = $arrInteractionResult['generic_id'];
                /* foreach($arrInteractionResult['topic_name'] as $row){

                  $arrProduct['product'][] = $row['product_name'];
                  $arrTypes['type'][] = $row['objective_name'];


                  }

                  $arrInteraction['objective_name']	= implode(', ',array_unique($arrTypes['type']));
                  $arrInteraction['product_name']		= implode(', ',array_unique($arrProduct['product'])); */
                $arrInteraction['objective_name'] = $arrInteractionResult['type'];
                $arrInteraction['product_name'] = $arrInteractionResult['product'];
                $arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
                if ($arrInteraction['follow_up_on'] == "00/00/0000")
                    $arrInteraction['follow_up_on'] = '';
                //	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
                $arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
                //$arrUserDetails						= $this->client_user->editUser($arrInteractionResult['created_by']);
                $arrInteraction['recorded_by'] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
                //$arrInteraction['mirf'] = $this->common_helpers->isActionAllowed('mirf','add',$arrInteractionResult);
                $isMirfAllowed = $this->common_helpers->isActionAllowed('mirf', 'add', $arrInteractionResult);
                if ($isMirfAllowed) {
                    if ($arrInteractionResult['mirf_id'] != null && $arrInteractionResult['mirf_id'] != '')
                        $arrInteraction['mirf'] = "Edit";
                    else
                        $arrInteraction['mirf'] = "Add";
                }else {
                    $arrInteraction['mirf'] = "";
                }
                $arrInteraction['mirfAllowed'] = $isMirfAllowed;
                $arrInteraction['mirf_id'] = $arrInteractionResult['mirf_id'];
                $arrInteraction['save_later'] = $arrInteractionResult['save_later'];
                //$arrInteraction['eAllowed']	= $this->common_helpers->isActionAllowed('interaction','edit',$arrInteractionResult);
                //$arrInteraction['dAllowed']	= $this->common_helpers->isActionAllowed('interaction','delete',$arrInteractionResult);

                $arrInteraction['title'] = preg_replace('#<a.*?>([^>]*)</a>#i', '$1', $arrInteractionResult['kol_name']);
                $arrInteraction['allDay'] = true;
                $arrInteractions[] = $arrInteraction;
            }
        }

        echo json_encode($arrInteractions);
    }

    function download_doc($documentId) {
        $docs = $this->interaction->getInteractionDocs(null, $documentId);

        $fileName = $docs[0]['doc_path'];
        $this->load->helper('download');
        // Read the contents of the file
        $data = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_interactions_documents/" . $fileName);
        $explodeFileName = explode('.', $docs[0]['doc_path']);
        //pr($explodeFileName);
        $fileName1 = $docs[0]['name'];
        $fileName1 = $fileName1 . "." . $explodeFileName[1];
        force_download($fileName1, $data);
    }

    function get_brands_by_product($productId) {
        $arrPrducts['arrProducts'] = $this->interaction->getBrandsByProduct($productId);
        echo json_encode($arrPrducts);
    }

    function get_all_kol_names_for_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0) {
       /* if($kolName!="keyword"){
            $currentkolName  = $kolName;
            $kolName   = $restrictByRegion;
            $restrictByRegion  = $currentkolName;
        }*/
        $kolName = utf8_urldecode($this->input->post('keyword'));
        $arrKolNames1 = array();
        $arrKolNames = $this->interaction->getAllKolNamesForAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);
        $arrOrgNames = $this->kol->getOrganizationNamesWithStateCity($kolName);
        //pr($arrKolNames);
        $flag = 1;
        foreach ($arrKolNames['customers'] as $key => $row) {
            if ($flag) {
                $arrKolNames1[] = "<div class='autocompleteHeading'>My Contacts</div><div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><span style='display:none' class='id1'>$key</span></div>";
                $flag = 0;
            } else {
                $arrKolNames1[] = "<div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><label style='color: red;display:block'>" . $row['do_not_call_flag'] . "</label><span style='display:none' class='id1'>$key</span></div>";
            }
        }
        foreach ($arrOrgNames['customers'] as $key => $row) {
            if (!$flag) {
                $arrKolNames1[] = "<div class='autocompleteHeading'>My Customers</div><div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><span style='display:none' class='id1'>$key</span></div>";
                $flag = 1;
            } else {
                $arrKolNames1[] = "<div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><label style='color: red;display:block'>" . $row['do_not_call_flag'] . "</label><span style='display:none' class='id1'>$key</span></div>";
            }
        } 
        $arr['query'] = $kolName;
        $arr['suggestions'] = $arrKolNames1;
        echo json_encode($arr);
    }
    
    function get_all_kol_org_names_for_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0,$id,$kolName) {
    	$kolName = utf8_urldecode($this->input->post($kolName));
    	$arrKolNames1 = array();
//     	echo $kolName;exit;
    	$arrKolNames = $this->interaction->getAllKolNamesForAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);
    	$arrKeyNames = $this->interaction->getAllKeyPeoplesForAutocomplete($kolName,$id);
    	$flag = 1;
    	foreach ($arrKolNames['customers'] as $key => $row) {
            if ($flag) {
                $arrKolNames1[] = "<div class='autocompleteHeading'>KTL's</div><div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><span style='display:none' class='id1'>$key</span></div>";
                $flag = 0;
            } else {
                $arrKolNames1[] = "<div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><label style='color: red;display:block'>" . $row['do_not_call_flag'] . "</label><span style='display:none' class='id1'>$key</span></div>";
            }
        }
        $flag = 1;
    	foreach($arrKeyNames as $arrKeyPeople){
    		$arrKeyPeople['role_id'] = $arrKeyPeople['role'];
    		$arrKeyPeople['name'] = $arrKeyPeople['first_name'] . ' ' . $arrKeyPeople['middle_name'] . ' ' . $arrKeyPeople['last_name'];
    		if($arrKeyPeople['salutation'] !='0'){
    			$arrKeyPeople['salutation'] = $arrSalutations[$arrKeyPeople['salutation']];
    		}
    		if ($flag) {
    			$arrKolNames1[] = '<div class="autocompleteHeading">Key People</div><div class="dataSet"><label name="' . $arrKeyPeople['id'] . '" type="key" class="organizations" style="display:block">' .$arrKeyPeople['name']. "</label><p class='orgName'>".$arrKeyPeople['department']."</p></div>";
    			$flag = 0;
    		} else {
    			$arrKolNames1[] = '<div class="dataSet"><label name="' . $arrKeyPeople['id'] . '" type="key" class="organizations" style="display:block">' . $arrKeyPeople['name'] . "</label><p class='orgName'>".$arrKeyPeople['department']."</p></div>";
    		}
    	}
    	$arr['query'] = $kolName;
    	$arr['suggestions'] = $arrKolNames1;
    	echo json_encode($arr);
    }

    /**
     * Gets the interactions details and exporting data to excel format
     * 
     * @author 	Vinayak
     * @Created on: 25-9-2012
     * @since	5.3
     * @return 
     */
    function export_interaction_details($kolId = null) {
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');

        $arrFilters = $this->input->post('filters');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        $whereResultArray = array();
        $whereResultArray = $arrFilters;
        if (isset($arrFilters['filters'])) {
        	$searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
        	$searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
        	$searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
        	$searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            
            foreach ($searchField as $key => $val) {
                $whereResultArray[$val] = $searchString[$key];
            }
        }
        $sidx = $arrFilters['sidx'];
        $sord = $arrFilters['sord'];
        $whereResultArray['sidx'] = $sidx;
        $whereResultArray['sord'] = $sord;
        $whereResultArray['interactionFor'] = $arrFilters['interaction_for'];
        $whereResultArray['end_date'] = $whereResultArray['ed'];
        $whereResultArray['start_date'] = $whereResultArray['sd'];
        
        
        if ($kolId == null)
            $kolId = $arrFilters['kol_id'];
        $arrInteractions = array();
        if($kolId > 0){
        	$secName = lang("KOL").' / Org Name';
        }else{
        	$secName = lang("KOL").' / Org Name';
        }
        if($this->input->post('org_name') >0 ){
        	$secName = 'Organization Name';
        }
        if($secName!='Organization Name'){
            $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        }
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        //$arrInteractions[0] = array('HCP Name', 'Recorded By', 'Date', 'Interaction Channel', 'Interaction Category', 'Specialty', 'Interaction Type', lang("Overview.Product"), 'Topic', 'Sub Topic', 'Location Type', 'Mirf Case Number', 'Territory Id','Recorded On','Employee Name','Interaction ID','Team','Month','MDM ID');
        $arrInteractions[0] = array('Interaction ID',$secName,'Specialty','Interaction Date','Interaction Month','Interaction Type','Interaction Category','Discussion Type',lang("Overview.Product"),'Topic','Location Type','Employee Name','Division','Total Attendees Added by User','Recorded By','Recorded On');
        $interactionIds = $this->input->post('interaction_ids');
        $arrInteractionIds = explode(',', $interactionIds);
        
         $whereResultArray['objective_id'] = $whereResultArray['type'];
        $whereResultArray['product_id'] = $whereResultArray['product'];
        $whereResultArray['topic_id'] = $whereResultArray['topic'];
        $whereResultArray['is_export'] = true;
//        pr($whereResultArray);
//        exit;
        //if ($arrInteractionsResults = $this->interaction->exprtInteractionDeatils($clientId, $kolId, $userId, $startDate, $endDate, '', '', '', $whereResultArray)) {
        if($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $whereResultArray, $limit = '', $start, true, $sidx, $sord, $whereResultArray)){
//      
/*                      pr("-------------------------------------------------------------------------------");
echo $this->db->last_query();
                            pr($arrInteractionsResults);
                            $arr = array();*/
                            /*foreach($arrInteractionsResults as $row){
                            	$arr[$row['map_id']] = $row;
                            }
                            $arrInteractionsResults = $arr;*/
                           /* pr($arr);
                            exit();*/
            foreach ($arrInteractionsResults as $arrInteractionResult) {
            	
					$arrInteraction[0] = $arrInteractionResult['generic_id'];
					/* if($arrInteractionResult['mdm_id'] == '' || $arrInteractionResult['mdm_id'] == '\N')
						 $arrInteractionResult['mdm_id'] = '';
					$arrInteraction[1] = $arrInteractionResult['mdm_id']; */
	            	if ($arrInteractionResult['org_id'] != null && $arrInteractionResult['org_id'] != '') {
	            		$arrInteraction[1] = $arrInteractionResult['org_name'];
	                }else {
	                    $arrInteraction[1] = $this->common_helpers->get_name_format($arrInteractionResult['kol_first_name'], $arrInteractionResult['kol_middle_name'], $arrInteractionResult['kol_last_name']);
	                }
					$arrInteraction[2] = $arrInteractionResult['specialty'];
	            	$arrInteraction[3] = sql_date_to_app_date($arrInteractionResult['date']);
	                if ($arrInteraction[3] == "00/00/0000") {
	                    $arrInteraction[3] = '';
	                }
					$arrInteraction[4] = date("M-Y",strtotime($arrInteractionResult['date']));
					$arrInteraction[5] = $arrInteractionResult['mode_name'];
					$arrInteraction[6] = $arrInteractionResult['grouping_name'];
					$arrInteraction[7] = $arrInteractionResult['type'];
					$arrInteraction[8] = $arrInteractionResult['product'];
					$arrInteraction[9] = $arrInteractionResult['topic'];
                	//$arrInteraction[11] = $arrInteractionResult['sub_topic'];
					$arrInteraction[10] = $arrInteractionResult['interaction_location_type_name'];
					//$arrInteraction[13] = $arrInteractionResult['mirf_case_num'];
					//$arrInteraction[14] = $arrInteractionResult['territory_id'];
					$arrInteraction[11] = $arrInteractionResult['emp_first_name']." ".$arrInteractionResult['emp_last_name'];
					$arrInteraction[12] = $this->common_helpers->getUserTeamName($arrInteractionResult['employee_id']);
					$arrInteraction[13] = $arrInteractionResult['total_attendies'];
					$arrUserDetails = $this->client_user->editUser($arrInteractionResult['created_by']);
					$arrInteraction[14] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
					$arrInteraction[15] = date("m-d-Y",strtotime($arrInteractionResult['created_on']));
					$arrInteractions[] = $arrInteraction;
					
			/*		
            if ($arrInteractionResult['org_id'] != null && $arrInteractionResult['org_id'] != '') {
            		$arrInteraction[0] = $arrInteractionResult['org_name'];
                }else {
                    $arrInteraction[0] = $this->common_helpers->get_name_format($arrInteractionResult['kol_first_name'], $arrInteractionResult['kol_middle_name'], $arrInteractionResult['kol_last_name']);
                }
                
                $arrInteraction[2] = sql_date_to_app_date($arrInteractionResult['date']);
                if ($arrInteraction[2] == "00/00/0000") {
                    $arrInteraction[2] = '';
                }
                $arrInteraction[3] = $arrInteractionResult['mode_name'];
                $arrInteraction[4] = $arrInteractionResult['grouping_name'];
                */
//				$arrInteraction[5]=sql_date_to_app_date($arrInteractionResult['follow_up_on']);
//				if($arrInteraction[5]=="00/00/0000")
//					$arrInteraction[5]='';
                //	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
                /* if($arrInteractionResult['quality_interaction'] == 0)
                  $arrInteraction[5]      =       "No";
                  else
                  $arrInteraction[5]      =       "Yes"; */

                $specialties = explode(', ', $arrInteractionResult['area_name']);
                $temp = "";
                foreach ($specialties as $value) {
                    if (!empty($value)) {
                        if ($temp == "")
                            $temp = $value;
                        else
                            $temp = $temp . ", " . $value;
                    }
                }
//                                pr("----");
//                                pr($temp);
//                                pr($arrInteractionResult['area_name']);
//                                pr("****");
/*
                $arrInteraction[5] = $arrInteractionResult['specialty'];
                $arrInteraction[6] = $arrInteractionResult['type'];
                $arrInteraction[7] = $arrInteractionResult['product'];
                $arrInteraction[8] = $arrInteractionResult['topic'];
                $arrInteraction[9] = $arrInteractionResult['sub_topic'];
//				$arrInteraction[10]	=	$arrInteractionResult['location'];
                $arrInteraction[10] = $arrInteractionResult['interaction_location_type_name'];
                $arrInteraction[11] = $arrInteractionResult['mirf_case_num'];
                $arrInteraction[12] = $arrInteractionResult['territory_id'];
                $arrInteraction[13] = date("m-d-Y",strtotime($arrInteractionResult['created_on']));
                $arrInteraction[14] = $arrInteractionResult['emp_first_name']." ".$arrInteractionResult['emp_last_name'];
                $arrInteraction[15] = $arrInteractionResult['generic_id'];
                $arrInteraction[16] = $this->common_helpers->getUserTeamName($arrInteractionResult['employee_id']);
                $arrInteraction[17] = date("M-Y",strtotime($arrInteractionResult['created_on']));
                $arrInteraction[18] = $arrInteractionResult['mdm_id'];
                $arrUserDetails = $this->client_user->editUser($arrInteractionResult['created_by']);
                $arrInteraction[1] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
                $arrInteractions[] = $arrInteraction;
                */
            }

//                                exit();
        }
//		pr($arrInteractions);
//                exit();
        $this->load->plugin('phpxls/writer');
        if (IS_IPAD_REQUEST) {
        	$fileName = "Interactions";
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $workbook = new Spreadsheet_Excel_Writer($path);
        } else {
            $workbook = new Spreadsheet_Excel_Writer();
        }

        $format_und = & $workbook->addFormat();
        $format_und->setBottom(2); //thick
        $format_und->setBold();
        $format_und->setColor('black');
        $format_und->setFontFamily('Calibri');
        $format_und->setAlign('centre');
        $format_und->setSize(12);

        $format_reg = & $workbook->addFormat();
        //	$format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);

        $excelFilters = $this->input->post('filters1');
        $filters = array();
        if ($excelFilters != '')
            $arrFilters = explode(",", $excelFilters);
        $filterHeaders[0] = 'Filter Name';
        $filterHeaders[1] = 'Filter Value';
        $filters[] = $filterHeaders;
        foreach ($arrFilters as $filter) {
            if ($filter != '' && trim($filter) != "Sub Topic : Select") {
                $filterRow = array();
                $filterRowElements = explode(":", $filter);
                $filterName = trim($filterRowElements[0]);
                if ($filterName == "mode_name")
                    $filterName = "interaction_channel";
                if ($filterName == "objective_name")
                    $filterName = "interaction_type";
                $filterRow[0] = '';
                $filterNameElements = explode("_", $filterName);
                foreach ($filterNameElements as $value) {
                    $filterRow[0] .= ucfirst($value) . " ";
                }
                $filterRow[1] = trim($filterRowElements[1]);
                if (trim($filterRow[0]) != "Mirf")
                    $filters[] = $filterRow;
            }
        }

        $arr = array(
            'Interaction Details' => $arrInteractions,
            'Filters' => $filters
        );

        foreach ($arr as $wbname => $rows) {

            $rowcount = count($rows);
            $colcount = count($rows[0]);

            $worksheet = & $workbook->addWorksheet($wbname);
            //Setting the column width for 'COMPANY OVERVIEW' Sheet
            if ($wbname == 'Interaction Details') {
                $worksheet->setColumn(0, 0, 40); //setColumn(startcol,endcol,float)
                $worksheet->setColumn(1, 1, 40.00);
                $worksheet->setColumn(2, 2, 20.00);
                $worksheet->setColumn(3, 3, 25.00);
                $worksheet->setColumn(4, 4, 25.00);
                $worksheet->setColumn(5, 5, 30.00);
                $worksheet->setColumn(6, 6, 30.00);
                $worksheet->setColumn(7, 7, 40.00);
                $worksheet->setColumn(8, 8, 40.00);
                $worksheet->setColumn(9, 9, 30.00);
                $worksheet->setColumn(10, 10, 30.00);
                $worksheet->setColumn(11, 11, 30.00);
                $worksheet->setColumn(12, 12, 30.00);
                $worksheet->setColumn(13, 13, 30.00);
                $worksheet->setColumn(14, 14, 30.00);
                $worksheet->setColumn(15, 15, 30.00);
                $worksheet->setColumn(16, 16, 30.00);
                $worksheet->setColumn(17, 17, 30.00);
                $worksheet->setColumn(18, 18, 30.00);
                $worksheet->setColumn(19, 19, 30.00);
                $worksheet->setColumn(20, 20, 30.00);
            }
            if ($wbname == 'Filters') {
                $worksheet->setColumn(0, 0, 25);
                $worksheet->setColumn(1, 1, 25);
            }

            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;

                    if ($j == 0) {
                        $fmt = & $format_und;
                    }
                    if (isset($rows[$j][$i])) {
                        $data = $rows[$j][$i];
                        $worksheet->write($j, $i, $data, $fmt);
                    }
                }
            }
        }
 
        $userId = $this->session->userdata('user_id');
        $userName = $this->client_user->getUserNameById($userId);
        $fileName = $userName . "_interactions";
        //if($kolId != null){
        //	$kolDetails = $this->kol->getKolName($kolId);
        //	$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
        //	$fileName = $userName."_".$kolName."_interactions";
        //}
        $fileName = "interactions_" . date('m/d/y');
        //for downloading the file
        if (!IS_IPAD_REQUEST) {
            $workbook->send($fileName . '.xls');
            $workbook->close();
        } else {
            $workbook->close();
            return $path;
        }
    }

    function get_product_by_type($typeId) {
        $arrPrducts['arrProducts'] = $this->interaction->getProductByType($typeId);
        echo json_encode($arrPrducts);
    }

    function get_topic_by_product($groupId, $productId, $typeId) {
        $arrPrducts['arrTopics'] = $this->interaction->getTpicByProduct($groupId, $productId, $typeId);
        echo json_encode($arrPrducts);
    }

    /**
     * Prepares the JSON data for Interactions count By Interaction Mode chart 
     * @author 	Ramesh B
     * @Created on: 05-10-12
     * @since	5.4
     * @return JSON
     */
    function get_interactions_by_mode() {
        $clientId = $this->session->userdata('client_id');
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $groupBy = ($this->input->post('group_by') == null) ? 0 : $this->input->post('group_by');
        $arrKolIds = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrInteractions = $this->interaction->getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds, 0, 0, 0, "mode");

        $data = array();
        foreach ($arrInteractions as $interaction) {
            $Intr = array();
            $Intr[0] = $interaction['mode'];
            $Intr[1] = (int) $interaction['count'];
            $data[] = $Intr;
        }
        echo json_encode($data);
    }

    /**
     * Prepares the JSON data for Interactions count By Interaction Grouping chart 
     * @author 	Ramesh B
     * @Created on: 05-10-12
     * @since	5.4
     * @return JSON
     */
    function get_interactions_by_grouping() {
        $clientId = $this->session->userdata('client_id');
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $groupBy = ($this->input->post('group_by') == null) ? 0 : $this->input->post('group_by');
        $arrKolIds = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrInteractions = $this->interaction->getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds, 0, 0, 0, "grouping");

        $data = array();
        foreach ($arrInteractions as $interaction) {
            $Intr = array();
            $Intr[0] = $interaction['grouping'];
            $Intr[1] = (int) $interaction['count'];
            $data[] = $Intr;
        }
        echo json_encode($data);
    }

    /**
     * Prepares the JSON data for Interactions count By Interaction topic chart 
     * @author 	Ramesh B
     * @Created on: 05-10-12
     * @since	5.4
     * @return JSON
     */
    function get_interactions_by_topic() {
        $clientId = $this->session->userdata('client_id');
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $groupBy = ($this->input->post('group_by') == null) ? 0 : $this->input->post('group_by');
        $arrKolIds = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrInteractions = $this->interaction->getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds, 0, 0, 0, "topic");

        $data = array();
        $arrCategories = array();
        $arrData = array();
        foreach ($arrInteractions as $interaction) {
            /* $Intr=array();
              $Intr[0]=$interaction['topic'];
              $Intr[1]=(int)$interaction['count'];
              $data[]=$Intr; */
            $arrCategories[] = $interaction['topic'];
            $arrData[] = (int) $interaction['count'];
        }
        $data[0] = $arrCategories;
        $data[1] = $arrData;
        echo json_encode($data);
    }

    function view_numeric_report($subContentPage = '') {

        $clientId = $this->session->userdata('client_id');
        $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
        $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
        $data['arrTopics'] = $this->interaction->getAllTopicsOfClient($clientId);
        $data['arrType'] = $this->interaction->getAllTypesOfClient();
        $data['arrProduct'] = $this->common_helpers->getUserProducts();
        $data['arrUsers']		= $this->client_user->getClientUsers($clientId);
        $data['arrDiscussionType'] = $this->interaction->getDiscussionTypeByProductIds($data['arrProduct']);
        $data['arrDiscussionTopic'] = $this->interaction->getTopicsByDiscussionTypesAndProductIds($data['arrProduct'],$data['arrDiscussionType']);
       // $data['arrUsers'] = $this->client_user->getClientUsers($clientId);
    	$managerId = $this->session->userdata("user_id");
        $filterData['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
        foreach ($filterData['arrManager'] as $row){
        	$data['arrManager'][$row['id']] = $row['first_name']." ".$row['last_name'];
        }
        $data['managerName'] = $this->interaction->getManagerName();
        $this->load->model('user_setting');
        $userId = $this->loggedUserId;
        $filterData = $this->user_setting->getDataFromAppSettings($userId,'interaction_filter_date');
        if($filterData > 0){
        	$data['fromFilterData'] = $filterData-1;
        }else{
        	$data['fromFilterData'] = 0;
        }
        $data['contentPage'] = 'interactions/view_numeric_report';
        $data['subContentPage'] = $subContentPage;
        //Add Log activity
        $arrLogDetails = array(
        		'type' => VIEW_RECORD,
        		'description' => "Visited view numeric report Page",
        		'status' => STATUS_SUCCESS,
        		'transaction_name' => "Viewed view numeric report"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Interactions numeric count report
     * @author 	Ramesh B
     * @Created on: 12-10-12
     * @since	
     * @return 
     */
    function interactions_numeric_report() {
        $arrFilters = array();
        $startDate = '2012-09-03';
        $endDate = '2012-09-03';
        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrSubtopic = $this->input->post('subtopic');
        $arrUserId = $this->input->post('user_id');
    	if($arrMode != 'null' && !empty($arrMode)){
        	if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
        if(!is_array($arrUserId)){
        	$arrUserId	= str_replace('null',null,$arrUserId);
        	$arrUserId = explode(",", $arrUserId);
        	//unset($arrUserId[array_search('null', $arrUserId)]);
        }
        	
		$arrFilters['sd'] = $this->input->post('sd');
        $arrFilters['ed'] = $this->input->post('ed');
        $kol_id = $this->input->post('kol_id');
        $arrFilters['interaction_for'] = $this->input->post('interaction_for');
        if($arrFilters['interaction_for']!='org'){
            $arrFilters['kol_id'] = $this->common_helpers->getKolidOrUniqueId($kol_id);
        }else{
            $arrFilters['kol_id'] = $kol_id;
        }
        /* $arrFilters['mode'] = $this->input->post('mode');
        $arrFilters['grouping'] = $this->input->post('grouping');
        $arrFilters['type'] = $this->input->post('type');
        $arrFilters['product'] = $this->input->post('product');
        $arrFilters['topic'] = $this->input->post('topic');
        $arrFilters['subtopic'] = $this->input->post('subtopic');*/
        
        $arrFilters['mode'] = $arrMode;
        $arrFilters['grouping'] = $arrGrouping;
        $arrFilters['type'] = $arrType;
        $arrFilters['product'] = $arrProduct;
        $arrFilters['topic'] = $arrTopic;
        $arrFilters['subtopic'] = $arrSubtopic;    
        $arrFilters['user_id'] = $arrUserId;
        $arrFilters['org_id'] = $this->input->post('org_id');
        $userId = 0;
        if($arrFilters['kol_id'] == ''){
	        if ($this->session->userdata('user_role_id') == ROLE_USER)
	        	$arrFilters['user_id'][] = $this->session->userdata('user_id');
        }
        
        

        
        
        $arrTypeResults = $this->interaction->getModeNumericReportData($arrFilters, 'type');
        
        $arrModeResults = $this->interaction->getModeNumericReportData($arrFilters, 'mode');

        $arrGroupingResults = $this->interaction->getModeNumericReportData($arrFilters, 'grouping');

        $arrProductResults = $this->interaction->getModeNumericReportData($arrFilters, 'product');

        $arrTopicResults = $this->interaction->getModeNumericReportData($arrFilters, 'topic');

        //$arrSubTopicResults = $this->interaction->getModeNumericReportData($arrFilters, 'subtopic');
        if($arrFilters['interaction_for'] == 'org'){
        	$arrFilters['mode'] = $this->input->post('mode');
        	$arrFilters['grouping'] = $this->input->post('grouping');
        	$arrFilters['type'] = $this->input->post('type');
        	$arrFilters['product'] = $this->input->post('product');
        	//         pr($arrFilters['product']);exit;
        	$arrFilters['topic'] = $this->input->post('topic');
        	$arrFilters['subtopic'] = $this->input->post('subtopic');
        	$arrFilters['user_id'] = $this->input->post('user_id');
        	$arrFilters['interaction_for'] = $this->input->post('interaction_for');
        }else{
	        $arrFilters['mode'] = implode(":",$this->input->post('mode'));
	        $arrFilters['grouping'] = implode(":",$this->input->post('grouping'));
	        $arrFilters['type'] = implode(":",$this->input->post('type'));
	        $arrFilters['product'] = implode("",$this->input->post('product'));
	//         pr($arrFilters['product']);exit;
	        $arrFilters['topic'] = implode(":",$this->input->post('topic'));
	        $arrFilters['subtopic'] = implode(":",$this->input->post('subtopic'));
	        $arrFilters['user_id'] = implode(":",$this->input->post('user_id'));
	        $arrFilters['interaction_for'] = $this->input->post('interaction_for');
        }
        $urlFilterSuffix = '';
        foreach ($arrFilters as $key => $value) {
			if ($value != '') {
                $urlFilterSuffix .= $key . "=" . $value . ",";
            }
        }
        $urlFilterSuffix = substr($urlFilterSuffix, 0, -1);
        $data['arrModeResults'] = $arrModeResults;
        $data['arrGroupingResults'] = $arrGroupingResults;
        $data['arrTypeResults'] = $arrTypeResults;
        $data['arrProductResults'] = $arrProductResults;
        $data['arrTopicResults'] = $arrTopicResults;
//         $data['arrSubTopicResults'] = $arrSubTopicResults;
        $data['urlFilterSuffix'] = $urlFilterSuffix;
        $data['interaction_for'] = $this->input->post('interaction_for');
        //Add Log activity
        $arrLogDetails = array(
        		'type' => VIEW_RECORD,
        		'description' => "Visited numeric report page",
        		'status' => STATUS_SUCCESS,
        		'kols_or_org_type' => 'Organization',
        		'transaction_name' => "View numeric report page"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $this->load->view('interactions/numeric_report', $data);
    }

    function view_drilldown_list($type, $id, $seg, $filters = '') {
        $filterData = "";
        $interactionFrom = "";
        $filters .= ",Date Range=" . strtoupper($seg);
        if ($filters != '') {
            $clientId = $this->session->userdata('client_id');
            $arrGroupings1 = $this->interaction->getAllGroupings($clientId);
            foreach ($arrGroupings1 as $key => $row) {
                $arrGroupings[$row['id']] = $row;
            }
            $arrModes = $this->interaction->getAllModesOfClient($clientId);
            $arrType = $this->interaction->getAllTypesOfClient();
            $filtersSplit = explode(',', $filters);
//             pr($filtersSplit);
            foreach ($filtersSplit as $filter) {
                $filterSplit = explode('=', $filter);
                $filterName = $filterSplit[0];
                $filterValue = $filterSplit[1];
                $arrFilterValue = explode(':', $filterSplit[1]);
                if ($filterName == 'sd') {
                    $filterName = 'Start Date';
                    $filterValue = sql_date_to_app_date($filterValue);
                }
                if ($filterName == 'ed') {
                    $filterName = 'End Date';
                    $filterValue = sql_date_to_app_date($filterValue);
                }
                if ($filterName == 'Date Range') {
                    if($filterValue == 'GP')
                        $filterValue = 'Given Period';
                        $filterValue = UCWORDS($filterValue);
                }
                if ($filterName == 'kol_id') {
                    $pos = strpos($filters, "interaction_for=org");
                    if ($pos === false) {
                    	$interactionFrom = 'ktl';
                        $arrSalutations = array(0 => '', 1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                        $filterName = 'KTL Name';
                        $kolDetails = $this->kol->getKolName($filterValue);
                        $fullName = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $kolDetails['unique_id'] . '">' . $arrSalutations[$kolDetails['salutation']] . " " . $kolDetails['first_name'] . ' ' . $kolDetails['middle_name'] . ' ' . $kolDetails['last_name'] . '</a>';
                    } else {
                    	$interactionFrom = 'Org';
                        $this->load->model('organization');
                        $filterName = 'Org Name';
                        $orgDetails = $this->organization->editOrganization($filterValue);
                        $fullName = '<a target="_NEW" href="' . base_url() . 'organizations/view/' . $orgDetails['id'] . '">' . $orgDetails['name'] . '</a>';
                    }
                    $filterValue = $fullName;
                }
                if ($filterName == 'mode') {
                    $filterName = 'Interaction Type';
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]= $arrModes[$row]['name'];
                    }
                    $filterValue = implode(', ',array_filter($value)); 
                }
                if ($filterName == 'grouping') {
                    $filterName = 'Interaction Category';                    
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]= $arrGroupings[$row]['name'];
                    }
                    $filterValue = implode(', ',array_filter($value));
                }
                if ($filterName == 'type') {
                    $filterName = 'Discussion Type';
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]= $arrType[$row]['name'];
                    }
                    $filterValue = implode(', ',array_filter($value));
                }
                if ($filterName == 'product') {
                    $filterName = 'Product';
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]=$this->interaction->getProductById($row);
                    }
                    $filterValue = implode(', ',array_filter($value));
                    
                }
                if ($filterName == 'topic') {
                    $filterName = 'Topic';
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]=$this->interaction->getTopicById($row);
                    }
                    $filterValue = implode(', ',array_filter($value));
                    
                }
                if ($filterName == 'subtopic') {
                    $filterName = 'Topic';
                    $value = array();
                    foreach($arrFilterValue as $row){
                        $value[]=$this->interaction->getTopicById($row);
                    }
                    $filterValue = implode(', ',array_filter($value));
                }               
                if ($filterName == 'user_id') {
                    $filterName = 'Employee Name';
                    $filterValue = $this->client_user->getUserNameById($filterValue);
                }
                if ($filterName != 'interaction_for'){
                    $filterData .= "<li><label>" . $filterName . " :</label>" . $filterValue . "</li>";
                }
            }
        }

        $data = array();
        $data['interaction_from'] = $interactionFrom;
        $data['filterData'] = $filterData;
//        $this->load->view('interactions/drilldown_list', $data);
        
        $data['contentPage'] = 'interactions/drilldown_list';
        $this->load->view('layouts/client_view', $data);
    }

    function interactions_drilldown_list($type, $id, $seg, $filters = '') {
        $arrFilters = array();
        $arrFilters['sd'] = '';
        $arrFilters['ed'] = '';
        $arrFilters['mode'] = '';
        $arrFilters['grouping'] = '';
        $arrFilters['type'] = '';
        $arrFilters['product'] = '';
        $arrFilters['topic'] = '';
        if ($filters != '') {
            $filtersSplit = explode(',', $filters);
            foreach ($filtersSplit as $filter) {
                $filterSplit = explode('=', $filter);
                $arrFilters[$filterSplit[0]] = explode(':',$filterSplit[1]);
            }
        }
        if($arrFilters['type'][0]=='Select'){
            $arrFilters['type'] ='';
        }
        /*if ($this->session->userdata('user_role_id') == ROLE_USER)
        	$arrFilters['user_id'] = $this->session->userdata('user_id');*/
        
        $arrInteractionsResults = $this->interaction->listInteractionsByDrilldown($type, $id, $seg, $arrFilters);
        //echo '<br>Total : '.sizeof($arrInteractions).'<br>';
//         pr($this->db->last_query());exit;

        $page = (int) $this->input->post('page'); // get the requested page 
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid     	
        $arrInteractions = array();
        $data = array();


        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');

        $arrInteractions = array();
        foreach ($arrInteractionsResults as $arrInteractionResult) {
            $arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
            if ($arrInteraction['date'] == "00/00/0000")
                $arrInteraction['date'] = '';
            $arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
            $arrInteraction['id'] = $arrInteractionResult['id'];
            $arrInteraction['objective_name'] = $arrInteractionResult['objective_name'];
            $arrInteraction['product_name'] = $arrInteractionResult['product_name'];
            $arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
            if ($arrInteraction['follow_up_on'] == "00/00/0000")
                $arrInteraction['follow_up_on'] = '';
            //	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
            $arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
            $arrUserDetails = $this->client_user->editUser($arrInteractionResult['created_by']);
            $arrInteraction['recorded_by'] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
            $arrInteractions[] = $arrInteraction;
        }

        $count = sizeof($arrInteractions);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrInteractions;

        echo json_encode($data);
    }

    function export_numeric_report($type, $filters = '') {
        $arrFilters = array();
        $arrFilters['sd'] = '';
        $arrFilters['ed'] = '';
        $arrFilters['mode'] = '';
        $arrFilters['grouping'] = '';
        $arrFilters['type'] = '';
        $arrFilters['product'] = '';
        $arrFilters['topic'] = '';
        $arrFilters['kol_id'] = '';
        $arrFilters['user_id'] = $arrUserId;
        $arrFilters['org_id'] = '';
        $userId = 0;
        $arrFilters['interaction_for'] = $this->input->post('interaction_for');
        if ($filters != '') {
            $filtersSplit = explode(',', $filters);
            foreach ($filtersSplit as $filter) {
                $filterSplit = explode('=', $filter);
              //  $arrFilters[$filterSplit[0]] = $filterSplit[1];
                $arrFilters[$filterSplit[0]] = explode(':',$filterSplit[1]);
            }
        }
        if($arrFilters['kol_id'][0] == ''){
        	if ($this->session->userdata('user_role_id') == ROLE_USER)
        		$arrFilters['user_id'][] = $this->session->userdata('user_id');
        }
        $arrResults = array();

        $nameExtension;
        if ($type == 'mode') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'mode');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = "Interaction Type (All)";
            $nameExtension = "Interaction Type";
        }
        if ($type == 'grouping') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'grouping');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = "Category (All)";
            $nameExtension = "Category";
        }
        if ($type == 'type') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'type');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = "Discussion Type (All)";
            $nameExtension = "Discussion Type";
        }
        if ($type == 'product') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'product');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = lang("Overview.Product")." (All)";
            $nameExtension = lang("Overview.Product");
        }
        if ($type == 'topic') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'topic');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = "Topic (All)";
            $nameExtension = "Topic";
        }
        /*if ($type == 'subtopic') {
            $arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'subtopic');
            krsort($arrResults);
            $arrResults[sizeof($arrResults) - 1]['name'] = "Subtopic(All)";
            $nameExtension = "Subtopic";
        }*/

        $this->load->plugin('phpxls/writer');
        $workbook = new Spreadsheet_Excel_Writer();

        $format_und = & $workbook->addFormat();
        //$format_und->setBottom(2);//thick
        $format_und->setBold();
        $format_und->setColor('black');
        $format_und->setFontFamily('Calibri');
        //$format_und->setAlign('centre');
        $format_und->setSize(12);

        $format_reg = & $workbook->addFormat();
        //	$format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);

        $format_header_column = & $workbook->addFormat();
        $format_header_column->setBold();
        $format_header_column->setColor('black');
        $format_header_column->setFontFamily('Calibri');
        $format_header_column->setSize(12);
        //$format_header_column->setBgColor("grey");

        $arrData = array();
        if ($filters != '') {
            $clientId = $this->session->userdata('client_id');
            $arrGroupings = $this->interaction->getAllGroupings($clientId);
            $arrModes = $this->interaction->getAllModesOfClient($clientId);
            $arrType = $this->interaction->getAllTypesOfClient();

            $filtersSplit = explode(',', $filters);
            foreach ($filtersSplit as $filter) {
                $filterSplit = explode('=', $filter);
                $filterName = $filterSplit[0];
                $filterValue = $filterSplit[1];
                if ($filterName == 'sd') {
                    $filterName = 'Start Date';
                    $filterValue = sql_date_to_app_date($filterValue);
                }
                if ($filterName == 'ed') {
                    $filterName = 'End Date';
                    $filterValue = sql_date_to_app_date($filterValue);
                }
                if ($filterName == 'mode') {
                    $filterName = 'Interaction Channel';
                    $filterValue = $arrModes[$filterValue]['name'];
                }
                if ($filterName == 'grouping') {
                    $filterName = 'Interaction Category';
                    $filterValue = $arrGroupings[$filterValue]['name'];
                    ;
                }
                if ($filterName == 'type') {
                    $filterName = 'Type';
                    $filterValue = $arrType[$filterValue]['name'];
                    ;
                }
                if ($filterName == 'product') {
                    $filterName = 'Product';
                    $filterValue = $this->interaction->getProductById($filterValue);
                }
                if ($filterName == 'topic') {
                    $filterName = 'Topic';
                    $filterValue = $this->interaction->getTopicById($filterValue);
                }
                if ($filterName == 'kol_id') {
                    $arrSalutations = array(0 => '', 1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                    $filterName = lang("KOL").' Name';
                    $kolDetails = $this->kol->getKolName($filterValue);
                    $fullName = $arrSalutations[$kolDetails['salutation']] . " " . $kolDetails['first_name'] . ' ' . $kolDetails['middle_name'] . ' ' . $kolDetails['last_name'];
                    $filterValue = $fullName;
                }
                if ($filterName == 'user_id') {
                    $filterName = 'Employee Name';
                    $filterValue = $this->client_user->getUserNameById($filterValue);
                }
                $row[0] = $filterName . " : " . $filterValue;
                $row[1] = '';
                $row[2] = '';
                $row[3] = '';
                $row[4] = '';
                $row[5] = '';
                $row[6] = '';
                $arrData[] = $row;
            }
        }

        $arrData = array();
        $headerColumn = sizeof($arrData);
        $arrData[] = array('', 'Given Period', 'Q1', 'Q2', 'Q3', 'Q4', 'YTD');
        foreach ($arrResults as $row) {
            $rowData = array();
            $rowData[0] = $row['name'];
            $rowData[1] = $row['gp'];
            $rowData[2] = $row['q1'];
            $rowData[3] = $row['q2'];
            $rowData[4] = $row['q3'];
            $rowData[5] = $row['q4'];
            $rowData[6] = $row['ytd'];
            $arrData[] = $rowData;
        }

        $arr = array(
            'Interaction Details' => $arrData
        );

        foreach ($arr as $wbname => $rows) {

            $rowcount = count($rows);
            $colcount = count($rows[0]);

            $worksheet = & $workbook->addWorksheet($wbname);
            //Setting the column width for 'COMPANY OVERVIEW' Sheet
            if ($wbname == 'Interaction Details') {
                $worksheet->setColumn(0, 0, 50); //setColumn(startcol,endcol,float)
                $worksheet->setColumn(1, 1, 20);
                $worksheet->setColumn(2, 2, 20);
                $worksheet->setColumn(3, 3, 20);
                $worksheet->setColumn(4, 4, 20);
                $worksheet->setColumn(5, 5, 20);
                $worksheet->setColumn(6, 6, 20);
            }
            $filtI = 0;
            foreach ($filtersSplit as $filter) {
                //$worksheet->setMerge(0, 0, $filtI, 6);
                $filtI++;
            }
            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;

                    if ($j == $headerColumn) {
                        $fmt = & $format_header_column;
                    }
                    if ($j > $headerColumn && $i == 0)
                        $fmt = & $format_und;

                    if (isset($rows[$j][$i])) {
                        $data = $rows[$j][$i];
                        $worksheet->write($j, $i, $data, $fmt);
                    }
                }
            }
        }

//		$fileName = $arrResults[0]['name'];
        $fileName = "Interaction Reports - " . $nameExtension;
        //for downloading the file
        $workbook->send($fileName . '.xls');
        $workbook->close();
    }

    /*
     * To show all interaction charts
     */

    function view_reports() {
        $data['contentPage'] = 'interactions/view_reports';
        $this->load->view('layouts/client_view', $data);
    }

    function interactions_chart_report() {
        $arrData['start_date'] = $this->input->post('sd');
        $arrData['end_date'] = $this->input->post('ed');
        $arrData['grouping'] = $this->input->post('grouping');
        $arrData['mode'] = $this->input->post('mode');
        $arrData['objective_id'] = $this->input->post('type');
        $arrData['product_id'] = $this->input->post('product');
        $arrData['topic_id'] = $this->input->post('topic');
        $arrData['kol_id'] = $this->input->post('kol_id');
        $arrData['user_id'] = $this->input->post('user_id');
        $arrData['client_id'] = $this->session->userdata('client_id');

        $arrTopic = $this->interaction->interacionByTopic($arrData);
        $arrChannel = $this->interaction->interacionByChannel($arrData);
        $arrResult = $this->interaction->interactionByMonth($arrData);
        $arrEmp = $this->interaction->interacionByEmployee($arrData);
        $interacionByMonths = array();
        $arrMonths = array(1 => 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');

        foreach ($arrTopic as $key => $row) {
            $arrTopicData = array();
            $arrTopicData[] = $row['name'];
            $arrTopicData[] = (int) $row['count'];
            $interacionByTopic[] = $arrTopicData;
        }

        foreach ($arrChannel as $key => $row) {
            $arrChannelData = array();
            $arrChannelData[] = $row['name'];
            $arrChannelData[] = (int) $row['count'];
            $interacionByChannel[] = $arrChannelData;
        }
        foreach ($arr['interacionByMonth'] as $key => $row) {
            $arrIntByMonthData[$row['month']][$row['name']] = (int) $row['count'];
        }
        foreach ($arrIntByMonthData as $month => $arrRow) {
            $interacionByMonths[] = $arrMonths[$month];
            $arrMonthProductsData['name'] = array_keys($arrRow);

            foreach ($arrRow as $product => $count) {
                $arrMonthData['name'] = $product;
                $arrMonthData['data'] = $count;
                $interacionByMonth[] = $arrMonthData;
            }
        }
        $arr1 = $arrResult[0];
        $arrYear = $arrResult[1];
        $arrResult[1] = $arrYear;

        $arrUniuue = array_unique($arrYear);
        foreach ($arrUniuue as $value1) {
            foreach ($arr1 as $ky => $value) {

                if ($value1 == $value['month']) {
                    $arr3[$value['name']]['data'][$value1][] = (int) $value['count'];
                }
            }
        }
        foreach ($arr3 as $key => $value) {
            //pr($value);
            foreach ($value['data'] as $ky1 => $val1) {

                $arr3[$key]['data'][$ky1] = $val1[0];
            }
        }

        foreach ($arr3 as $key => $val) {

            foreach ($arrUniuue as $row) {

                if (array_key_exists($row, $val['data'])) {
                    
                } else {
                    $arr3[$key]['data'][$row] = 0;
                }
            }
            ksort($arr3[$key]['data']);
        }

        foreach ($arr3 as $key => $value) {

            foreach ($value['data'] as $row) {
                $arr8[$key]['data'][] = $row;
            }
        }


        foreach ($arr8 as $key3 => $value3) {

            $arr = array();
            $arr['name'] = $key3;
            $arr['data'] = $value3['data'];
            $arr9[] = $arr;
        }
        foreach ($arrUniuue as $key => $month) {
            $arrMonthNames[] = $arrMonths[$month];
        }
        foreach ($arrEmp as $key => $row) {
            $arrEmployeeData = array();
            $arrEmployeeData[] = $row['username'];
            $arrEmployeeData[] = (int) $row['count'];
            $interacionByEmployee[] = $arrEmployeeData;
        }

        $data['status'] = true;
        $data['arrByTopic'] = $interacionByTopic;
        $data['arrByChannel'] = $interacionByChannel;
        $data['arrByMonth'] = $arr9;
        $data['arrMonths'] = $arrMonthNames;
        $data['arrByEmployee'] = $interacionByEmployee;

        echo json_encode($data);
    }

    function interactions_by_topic() {
        $arrData['start_date'] = $this->input->post('sd');
        $arrData['end_date'] = $this->input->post('ed');

        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
         
        
        if($arrMode != 'null' && !empty($arrMode)){
        	if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
        //if($arrUserId != 'null'){
        	if(!is_array($arrUserId)){
        		$arrUserId	= str_replace('null',null,$arrUserId);
        		$arrUserId = explode(",", $arrUserId);
        		//unset($arrUserId[array_search('null', $arrUserId)]);
        	}
        //}
       	

        $arrData['grouping'] = $arrGrouping;
        $arrData['mode'] = $arrMode;
        $arrData['objective_id'] = $arrType;
        $arrData['product_id'] = $arrProduct;
        $arrData['topic_id'] = $arrTopic;
        $arrData['user_id'] = $arrUserId;
        $kol_id = $this->input->post('kol_id');
        $arrData['interaction_for'] = $this->input->post('interaction_for');
        if($arrData['interaction_for']!='org'){
            $arrData['kol_id'] = $this->common_helpers->getKolidOrUniqueId($kol_id);
        }else{
            $arrData['kol_id'] = $kol_id;
        }
        $arrData['client_id'] = $this->session->userdata('client_id');
        $arrData['org_id'] = $this->input->post('org_id');
        if($arrData['kol_id'] == ''){
	        if ($this->session->userdata('user_role_id') == ROLE_USER){
	        	$arrData['user_id'][] = $this->session->userdata('user_id');
	        }
        }
        $arrTopic = $this->interaction->interacionByTopic($arrData);

//            pr("hi");
//            exit();
        foreach ($arrTopic as $key => $row) {
            $arrTopicData = array();
            $arrTopicData[] = $row['name'];
            $arrTopicData[] = (int) $row['count'];
            $interacionByTopic[] = $arrTopicData;
        }
        if (sizeof($interacionByTopic) > 0) {
            $data['status'] = true;
            $data['arrByTopic'] = $interacionByTopic;
        } else {
            $arrTopicData = array();
            $arrTopicData[] = 'No Data';
            $arrTopicData[] = 0;
            $interacionByTopic[] = $arrTopicData;
            $data['arrByTopic'] = $interacionByTopic;
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function interactions_by_channel() {
        $arrData['start_date'] = $this->input->post('sd');
        $arrData['end_date'] = $this->input->post('ed');
        
        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
         
        
        if($arrMode != 'null' && !empty($arrMode)){
        	if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
    	if(!is_array($arrUserId)){
        		$arrUserId	= str_replace('null',null,$arrUserId);
        		$arrUserId = explode(",", $arrUserId);
        		//unset($arrUserId[array_search('null', $arrUserId)]);
        	}
        
        
        $arrData['grouping'] = $arrGrouping;
        $arrData['mode'] = $arrMode;
        $arrData['objective_id'] = $arrType;
        $arrData['product_id'] = $arrProduct;
        $arrData['topic_id'] = $arrTopic;
        $arrData['user_id'] = $arrUserId;
        $kol_id = $this->input->post('kol_id');
        $arrData['interaction_for'] = $this->input->post('interaction_for');
        if($arrData['interaction_for']!='org'){
            $arrData['kol_id'] = $this->common_helpers->getKolidOrUniqueId($kol_id);
        }else{
            $arrData['kol_id'] = $kol_id;
        }
        $arrData['client_id'] = $this->session->userdata('client_id');
        $arrData['org_id'] = $this->input->post('org_id');
    	if($arrData['kol_id'] == ''){
	        if ($this->session->userdata('user_role_id') == ROLE_USER){
	        	$arrData['user_id'][] = $this->session->userdata('user_id');
	        }
        }
        $arrChannel = $this->interaction->interacionByChannel($arrData);

        foreach ($arrChannel as $key => $row) {
            $arrChannelData = array();
            $arrChannelData[] = $row['name'];
            $arrChannelData[] = (int) $row['count'];
            $interacionByChannel[] = $arrChannelData;
        }

        if (sizeof($interacionByChannel) > 0) {
            $data['status'] = true;
            $data['arrByChannel'] = $interacionByChannel;
        } else {
            $arrChannelData = array();
            $arrChannelData[] = 'No Data';
            $arrChannelData[] = 0;
            $interacionByChannel[] = $arrChannelData;
            $data['arrByChannel'] = $interacionByChannel;
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function interactions_by_employee() {
        $arrData['start_date'] = $this->input->post('sd');
        $arrData['end_date'] = $this->input->post('ed');
        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
         
        
        if($arrMode != 'null' && !empty($arrMode)){
        	if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
    	if(!is_array($arrUserId)){
        		$arrUserId	= str_replace('null',null,$arrUserId);
        		$arrUserId = explode(",", $arrUserId);
        		//unset($arrUserId[array_search('null', $arrUserId)]);
        	}
        
        
        $arrData['grouping'] = $arrGrouping;
        $arrData['mode'] = $arrMode;
        $arrData['objective_id'] = $arrType;
        $arrData['product_id'] = $arrProduct;
        $arrData['topic_id'] = $arrTopic;
        $arrData['user_id'] = $arrUserId;
        $kol_id = $this->input->post('kol_id');
        $arrData['interaction_for'] = $this->input->post('interaction_for');
        if($arrData['interaction_for']!='org'){
            $arrData['kol_id'] = $this->common_helpers->getKolidOrUniqueId($kol_id);
        }else{
            $arrData['kol_id'] = $kol_id;
        }
        $arrData['client_id'] = $this->session->userdata('client_id');
        $arrData['org_id'] = $this->input->post('org_id');
    	if($arrData['kol_id'] == ''){
	        if ($this->session->userdata('user_role_id') == ROLE_USER){
	        	$arrData['user_id'][] = $this->session->userdata('user_id');
	        }
        }
        $arrEmp = $this->interaction->interacionByEmployee($arrData);

        foreach ($arrEmp as $key => $row) {
            $arrEmployeeData = array();
            $arrEmployeeData[] = $row['username'];
            $arrEmployeeData[] = (int) $row['count'];
            $interacionByEmployee[] = $arrEmployeeData;
        }

        if (sizeof($interacionByEmployee) > 0) {
            $data['status'] = true;
            $data['arrByEmployee'] = $interacionByEmployee;
        } else {
            $arrEmployeeData = array();
            $arrEmployeeData[] = 'No Data';
            $arrEmployeeData[] = 0;
            $interacionByEmployee[] = $arrEmployeeData;
            $data['arrByEmployee'] = $interacionByEmployee;
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function interactions_by_month() {
        $arrData['start_date'] = $this->input->post('sd');
        $arrData['end_date'] = $this->input->post('ed');

        $arrMode = $this->input->post('mode');
        $arrGrouping = $this->input->post('grouping');
        $arrType = $this->input->post('type');
        if($arrType == 'Select'){
            $arrType = '';
        }
        $arrProduct = $this->input->post('product');
        $arrTopic = $this->input->post('topic');
        $arrUserId = $this->input->post('user_id');
        
        if($arrMode != 'null' && !empty($arrMode)){
        	if(!is_array($arrMode)){
        		$arrMode = explode(",", $arrMode);
        	}
        }
        
        if($arrGrouping != 'null' && !empty($arrGrouping)){
        	if(!is_array($arrGrouping)){
        		$arrGrouping = explode(",", $arrGrouping);
        	}
        }
        
        if($arrType != 'null' && !empty($arrType)){
        	if(!is_array($arrType)){
        		$arrType = explode(",", $arrType);
        	}
        }
        
        if($arrProduct != 'null' && !empty($arrProduct)){
        	if(!is_array($arrProduct)){
        		$arrProduct = explode(",", $arrProduct);
        	}
        }
        
        if($arrTopic != 'null' && !empty($arrTopic)){
        	if(!is_array($arrTopic)){
        		$arrTopic = explode(",", $arrTopic);
        	}
        }
        
    	if(!is_array($arrUserId)){
        		$arrUserId	= str_replace('null',null,$arrUserId);
        		$arrUserId = explode(",", $arrUserId);
        		//unset($arrUserId[array_search('null', $arrUserId)]);
        	}	
        
        
        $arrData['grouping'] = $arrGrouping;
        $arrData['mode'] = $arrMode;
        $arrData['objective_id'] = $arrType;
        $arrData['product_id'] = $arrProduct;
        $arrData['topic_id'] = $arrTopic;
        $arrData['user_id'] = $arrUserId;
        $kol_id = $this->input->post('kol_id');
        $arrData['interaction_for'] = $this->input->post('interaction_for');
        if($arrData['interaction_for']!='org'){
            $arrData['kol_id'] = $this->common_helpers->getKolidOrUniqueId($kol_id);
        }else{
            $arrData['kol_id'] = $kol_id;
        }
        $arrData['client_id'] = $this->session->userdata('client_id');
        $arrData['org_id'] = $this->input->post('org_id');
    	if($arrData['kol_id'] == ''){
	        if ($this->session->userdata('user_role_id') == ROLE_USER){
	        	$arrData['user_id'][] = $this->session->userdata('user_id');
	        }
        }
        $arrResult = $this->interaction->interactionByMonth($arrData);
        $arrData['get_count'] = true;
        $arrTotalCountResult = $this->interaction->interactionByMonth($arrData);
        $interacionByMonths = array();
        $arrMonths = array(1 => 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');


        foreach ($arr['interacionByMonth'] as $key => $row) {
            $arrIntByMonthData[$row['month']][$row['name']] = (int) $row['count'];
        }
        foreach ($arrIntByMonthData as $month => $arrRow) {
            $interacionByMonths[] = $arrMonths[$month];
            $arrMonthProductsData['name'] = array_keys($arrRow);

            foreach ($arrRow as $product => $count) {
                $arrMonthData['name'] = $product;
                $arrMonthData['data'] = $count;
                $interacionByMonth[] = $arrMonthData;
            }
        }
        $arr1 = $arrResult[0];
        $arrYear = $arrResult[1];
        $arrResult[1] = $arrYear;

        $arrUniuue = array_unique($arrYear);
        foreach ($arrUniuue as $value1) {
            foreach ($arr1 as $ky => $value) {

                if ($value1 == $value['month_year']) {
                    $arr3[$value['name']]['data'][$value1][] = (int) $value['count'];
                }
            }
        }
        foreach ($arr3 as $key => $value) {
            foreach ($value['data'] as $ky1 => $val1) {

                $arr3[$key]['data'][$ky1] = $val1[0];
            }
        }

        foreach ($arr3 as $key => $val) {

            foreach ($arrUniuue as $row) {

                if (array_key_exists($row, $val['data'])) {
                    
                } else {

                    $arr3[$key]['data'][$row] = 0;
                }
            }
            ksort($arr3[$key]['data']);
        }

        foreach ($arr3 as $key => $value) {

            foreach ($value['data'] as $row) {
                $arr8[$key]['data'][] = $row;
            }
        }

        //pr($arr8);
        foreach ($arr8 as $key3 => $value3) {

            $arr = array();
            $arr['name'] = $key3;
            $arr['data'] = $value3['data'];
            $arr9[] = $arr;
        }
        //	pr($arr9);
        foreach ($arrUniuue as $key => $month) {
            //$arrMonthYear		= explode('_',$month);
            $year = substr($month, -4, 4);
            $month1 = str_replace($year, '', $month);
            //	echo $month1;
            $arrMonthNames[] = $arrMonths[$month1] . " '" . $year;
        }
        $data = array();

        if (sizeof($arrMonthNames) > 0) {
            $data['status'] = true;
            $data['arrByMonth'] = $arr9;
            $data['arrMonths'] = $arrMonthNames;
        } else {
            $arr = array();
            $arr['name'] = array("No Data");
            $arr['data'] = array(0);
            $arr9[] = $arr;
            $arrMonthNames = array("Month Year");
            $data['status'] = false;
            $data['arrByMonth'] = $arr9;
            $data['arrMonths'] = $arrMonthNames;
        }
        echo json_encode($data);
    }

    function getLocationDetails($kolId) {
        $kolContactDetails = $this->kol->getKolDetailsById($kolId);
        $arrPrimaryContact = array();
        $arrPrimaryContact[0] = array(
            'id' => -1,
            'location' => 'Primary',
            'address' => $kolContactDetails[0]['address1'] . ' ' . $kolContactDetails[0]['address2'],
            'state' => $kolContactDetails[0]['Region'],
            'city' => $kolContactDetails[0]['City'],
            'country' => $kolContactDetails[0]['Country'],
        );
        $arrSecondaryContact = $this->kol->listAdditionalContacts($kolId);
        $data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
        echo json_encode($data);
    }

    /**
     * This function Prepares data required for MIRF Form and redirects to the MIRF page
     * @author 	Shruti Purushan
     * @Created on: 29-09-2015
     * @return
     */
    function add_mirf($interactionId,$contactId="",$cType = "") {
      
        $mirfDetails = $this->interaction->getMirfByInteraction($interactionId);
        $this->load->model('Specialty');
        $specialtyName = $this->Specialty->getAllSpecialties();
        if (isset($mirfDetails['id'])) {
            $id = $mirfDetails['id'];
            $data['created_by'] = $this->session->userdata('user_id');
            $data['mirfDetails'][] = $mirfDetails;
            $stateName = $data['mirfDetails'][0]['state'];
            $stateID = $this->Country_helper->getStateNamesByStateIdAndCountryId($stateName, 254);
            $data['arrCities'] = $this->Country_helper->getCitiesByStateIdNew($stateID);
            $kolId = $data['mirfDetails'][0]['kol_id'];

            $data['kolDetails'] = $this->kol->getKolDetailsById($kolId);

            $userId = $data['mirfDetails'][0]['client_id'];
            $data['clientUser'] = $this->client_user->getUserdetail($userId);
            $productDetails = $this->interaction->getProductDetails($id);

            $productName = $this->interaction->getProductNames();

            $arrTemp = array();
            foreach ($productName as $key => $value) {
                //foreach ($value as $key1 => $value1) {
                //  echo $key1 ."=>". $value1."<br/>";
                $arrTemp[$value['id']] = strtoupper($value['name']);
                //}
            }
            //               pr($arrTemp);
            $selectedProductIds = array();

            foreach ($productDetails as $key => $value) {


                $selectedProductIds[] = $value['product_id'];



                foreach ($value as $key1 => $value1) {
                    //                    echo $key1.$value1."<br/>";

                    if ($key1 == 'other_product_name')
                        $otherProductValue = $value1;
                }
            }
            $data['userTerritory'] = $this->client_user->getUserTerritoryById($data['mirfDetails'][0]['created_by']);
            $data['productArray'] = $arrTemp;
            $data['selectedProductIds'] = $selectedProductIds;
            $data['otherProductValue'] = $otherProductValue;
            $data['productDetails'] = $productDetails;
        }else {
            $data['userTerritory'] = $this->client_user->getUserTerritoryById($this->session->userdata('user_id'));
            $arrInteractionsResults = $this->interaction->getInteractionDetails($interactionId);
            $data['arrInteractionsResults'] = $arrInteractionsResults;
            $kolId = $data['arrInteractionsResults']['attendees']['kol_ids'][0];
            $data['kolDetails'] = $this->kol->getKolDetailsById($kolId);
            if (isset($data['kolDetails'][0]['state_id']))
                $data['arrCities'] = $this->Country_helper->getCitiesByStateId($data['kolDetails'][0]['state_id']);

            $data['created_by'] = $this->session->userdata('user_id');
            $productName = $this->interaction->getProductNames();
            $arrTemp = array();
            foreach ($productName as $key => $value) {
                //foreach ($value as $key1 => $value1) {
                //  echo $key1 ."=>". $value1."<br/>";
                $arrTemp[$value['id']] = strtoupper($value['name']);
                //}
            }
//			               pr($arrTemp);
            $data['productArray'] = $arrTemp;
        }
        $arrInteractionsResults = $this->interaction->getInteractionDetails($interactionId);
        //$arrInteractionsProduct=$this->interaction->getProductIdByInteractionId($interactionId);
        $selectedProductIdsFromInteraction = array();

        foreach ($arrInteractionsProduct as $key => $value) {


            $selectedProductIdsFromInteraction[] = $value['product_id'];
        }
//                pr($selectedProductIdsFromInteraction);
        $data['arrInteractionsResults'] = $arrInteractionsResults;
        $getAllActiveDegrees = $this->kol->getAllActiveDegrees();
        $arrgetAllActiveDegrees = array();
        foreach ($getAllActiveDegrees as $key => $value) {
            $arrgetAllActiveDegrees[$value['id']] = ($value['degree']);
        }
        $data['arrgetAllActiveDegrees'] = $arrgetAllActiveDegrees; 
        $data['specialtyName'] = $specialtyName;
        $data['arrInteractionsProduct'] = $selectedProductIdsFromInteraction;
        $data['arrStates'] = $this->Country_helper->getStatesByCountryId(254);
        $kolId = $data['arrInteractionsResults']['attendees']['kol_ids'][0];
//                $data['kolDetails']			= $this->kol->getKolDetailsById($kolId);
        $data['contentPage'] = 'interactions/add_mirf';
        
        //Set where to redirect
        $prevUrl = $_SERVER['HTTP_REFERER'];
		preg_match_all('!\d+!', $prevUrl, $matches);
		$addFromId = $matches[0][0];
        $addFrom = "interactions";
		if (strpos($prevUrl, 'kols') !== false) {
		    $addFrom = "kols";
		}
    	if (strpos($prevUrl, 'organizations') !== false) {
		    $addFrom = "organizations";
		}
    	if (strpos($prevUrl, 'save_interaction') !== false) {
    		$addFromId = $contactId;
    		if($arrInteractionsResults['is_org_interaction'] == 1)
		    	$addFrom = "organizations";
		    else
		    	$addFrom = "kols";
		}
		$data['addFrom'] = $addFrom;
		$data['addFromId'] = $addFromId;
        $this->load->view('layouts/client_view', $data);
    }

    function edit_mirf($id) {
        $data['created_by'] = $this->session->userdata('user_id');
        $data['mirfDetails'] = $this->interaction->editMirf($id);

        $kolId = $data['mirfDetails'][0]['kol_id'];
        $data['kolDetails'] = $this->kol->getKolDetailsById($kolId);
        $productDetails = $this->interaction->getProductDetails($id);
        $productName = $this->interaction->getProductNames();
        //             $selectedProducts=array();
        $arrTemp = array();
        foreach ($productName as $key => $value) {
            //foreach ($value as $key1 => $value1) {
            //  echo $key1 ."=>". $value1."<br/>";
            $arrTemp[$value['id']] = strtoupper($value['name']);
            //}
        }
        //               pr($arrTemp);
        $selectedProductIds = array();

        foreach ($productDetails as $key => $value) {


            $selectedProductIds[] = $value['product_id'];



            foreach ($value as $key1 => $value1) {
                //                    echo $key1.$value1."<br/>";

                if ($key1 == 'other_product_name')
                    $otherProductValue = $value1;
            }
        }

        $data['productArray'] = $arrTemp;
        $data['selectedProductIds'] = $selectedProductIds;
        $data['otherProductValue'] = $otherProductValue;
        $data['productDetails'] = $productDetails;
        $arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, null, null);
        $data['arrInteractionsResults'] = $arrInteractionsResults;
        $data['contentPage'] = 'interactions/add_mirf';
        $this->load->view('layouts/client_view', $data);
    }

    function save_mirf_form() {
        $mirf_id = $this->input->post('mirf_id');
        $previousUrl = $this->input->post('previousUrl');
        $redirectionalKolId = $this->input->post('redirectionalKolId');
        $orgMirf = $this->input->post('orgMirf');
        $addFrom = $this->input->post('add_from');
        $addFromId = $this->input->post('add_from_id');
        if ($mirf_id == null || $mirf_id == '') {
            $arrData = array();
            $data = array();
            $date_of_request = strtotime($this->input->post('date_of_request'));
            $date = date("Y-m-d", $date_of_request);
            $arrData['date_of_request'] = $date;
            $arrData['kol_id'] = $this->input->post('contact_id');
            $data['product'] = $this->input->post('product');

            $data['first_product_value'] = $this->input->post('first_product_value');
            $data['is_single_use_vial'] = $this->input->post('is_single_use_vial');
            $data['is_dual_chamber_syringe'] = $this->input->post('is_dual_chamber_syringe');
            $data['is_non_kit_specific_enquiry'] = $this->input->post('is_non_kit_specific_enquiry');
            $data['other_product_name'] = $this->input->post('otherProduct');
            //                    $data['interaction_mirf_id'] =$this->input->post('mirf_id');
            $arrData['interaction_id'] = $this->input->post('interaction_id');
            $arrData['degree'] = $this->input->post('degree');
            $arrData['specialty'] = $this->input->post('specialty');
            $arrData['licence'] = $this->input->post('licence');
            $arrData['institution'] = $this->input->post('institution');
            $arrData['address'] = $this->input->post('address');
            $arrData['city'] = $this->input->post('city');
            $arrData['state'] = $this->input->post('state');
            $arrData['zip_code'] = $this->input->post('zip_code');
            $arrData['telephone'] = $this->input->post('telephone');
            $arrData['email_id'] = $this->input->post('email_id');
            $arrData['email'] = $this->input->post('email');
            $arrData['mail'] = $this->input->post('mail');
            $arrData['fax_id'] = $this->input->post('fax_id');
            $arrData['fax'] = $this->input->post('fax');
            $arrData['answer_provided'] = $this->input->post('answer_provided');
            $arrData['mir_questions'] = $this->input->post('mir_questions');
            $arrData['msl_info'] = $this->input->post('msl_info');
            $arrData['client_id'] = $this->input->post('client_id');
            $arrData['hcp_signature'] = $this->input->post('hcp_signature');
            $genericId = $this->common_helpers->getGenericId("U O Q");
            $arrData['generic_id'] = $genericId;
            $savedMirfID = $this->interaction->saveMirf($arrData, $data);
            //Update interaction "save_later = 0" 
            $arrIntDetails = array();
            $arrIntDetails['id'] = $arrData['interaction_id'];
            $arrIntDetails['save_later'] = 0;
            $this->interaction->updateInteraction($arrIntDetails);
            //Add Log activity
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_ADD,
                'description' => 'Add Mirf',
                'status' => 'success',
                'transaction_id' => $savedMirfID,
                'transaction_table_id' => INTERACTION_MIRF_PRODUCTS,
                'transaction_name' => "AddMirf",
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
        } else {
            $arrData = array();
            $data = array();
            $date_of_request = strtotime($this->input->post('date_of_request'));
            $date = date("Y-m-d", $date_of_request);
            $arrData['date_of_request'] = $date;
            $arrData['kol_id'] = $this->input->post('contact_id');
            $arrData['id'] = $this->input->post('mirf_id');
            $data['product'] = $this->input->post('product');
            $data['first_product_value'] = $this->input->post('first_product_value');
            $data['is_single_use_vial'] = $this->input->post('is_single_use_vial');
            $data['is_dual_chamber_syringe'] = $this->input->post('is_dual_chamber_syringe');
            $data['is_non_kit_specific_enquiry'] = $this->input->post('is_non_kit_specific_enquiry');
            $data['other_product_name'] = $this->input->post('otherProduct');
            $data['interaction_mirf_id'] = $this->input->post('mirf_id');
            $arrData['interaction_id'] = $this->input->post('interaction_id');
            $arrData['degree'] = $this->input->post('degree');
            $arrData['specialty'] = $this->input->post('specialty');
            $arrData['licence'] = $this->input->post('licence');
            $arrData['institution'] = $this->input->post('institution');
            $arrData['address'] = $this->input->post('address');
            $arrData['city'] = $this->input->post('city');
            $arrData['state'] = $this->input->post('state');
            $arrData['zip_code'] = $this->input->post('zip_code');
            $arrData['telephone'] = $this->input->post('telephone');
            $arrData['email_id'] = $this->input->post('email_id');
            $arrData['email'] = $this->input->post('email');
            $arrData['mail'] = $this->input->post('mail');
            $arrData['fax_id'] = $this->input->post('fax_id');
            $arrData['fax'] = $this->input->post('fax');
            $arrData['answer_provided'] = $this->input->post('answer_provided');
            $arrData['mir_questions'] = $this->input->post('mir_questions');
            $arrData['msl_info'] = $this->input->post('msl_info');
            $arrData['client_id'] = $this->input->post('client_id');
            $arrData['hcp_signature'] = $this->input->post('hcp_signature');
            $this->interaction->updateMirf($arrData, $data);
            $savedMirfID = $arrData['id'];
            //Update interaction "save_later = 0" 
            $arrIntDetails = array();
            $arrIntDetails['id'] = $arrData['interaction_id'];
            $arrIntDetails['save_later'] = 0;
            $this->interaction->updateInteraction($arrIntDetails);
            
            //Add Log activity
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Update Mirf',
                'status' => 'success',
                'transaction_id' => $savedMirfID,
                'transaction_table_id' => INTERACTION_MIRF_PRODUCTS,
                'transaction_name' => "UpdateMirf",
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
        }
        
        if($addFrom == "kols")
        	redirect(base_url()."kols/view/".$addFromId."/interaction_report");
        if($addFrom == "organizations")
        	redirect(base_url()."organizations/view_interactions/".$addFromId."/interaction");
        
        	redirect($previousUrl); 
    }

    function list_mirf() {
        $data['contentPage'] = 'interactions/list_mirf';
        $this->load->view('layouts/client_view', $data);
    }

    function list_mirf_grid() {
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
        $arrMirf = $this->interaction->listMirf($arrParams);
        foreach ($arrMirf as $key => $value) {
//                    $productDetails             = $this->interaction->getProductDetails($value['id']);
//                    pr($productDetails); exit;
          $firstproductnames = "";
            $firstRowProduct=$this->interaction->getProductNamesForFirstRow($value['id']);
          foreach ($firstRowProduct as $key1 => $value1) {
              if($value1['is_single_use_vial']==1)
                     $firstproductnames .=' <br/> Abilify Maintena: Single-Use Vial';
                if($value1['is_dual_chamber_syringe']==1)
                     $firstproductnames .='<br/> Abilify Maintena: Dual Chamber Syringe ';
                if($value1['is_non_kit_specific_enquiry']==1)
                     $firstproductnames .='<br/> Abilify Maintena: Non-kit Specific Inquiry ';
          } 
        $arrProduct = $this->interaction->getProductNamesForSelectedIds($value['id']);
        $productnames = "";

        foreach ($arrProduct as $key1 => $value1) {
            if (in_array("PsychU", $value1) || in_array("Abilify Maintena", $value1)) {
//                $productnames .=$value1['other_product_name'];
            } else { 
                if($value1['name']!="")
                
                $productnames .=$value1['name'] . ", "; 
                $productnames .=$value1['other_product_name']; 
            } 
        }
        $productnames = rtrim($productnames, ', ');
        $productnames.=$firstproductnames; 
            $arrMirf[$key]['products'] = $productnames;
        }
        foreach ($arrMirf as $row) {
            $row['eAllowed'] = $this->common_helpers->isActionAllowed('mirf', 'edit', $arrMirf);
            $row['dAllowed'] = $this->common_helpers->isActionAllowed('mirf', 'delete', $arrMirf);
            $arrMirfResult[] = $row;
        }
        $count = sizeof($arrMirf);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrMirfResult;
        echo json_encode($data);
    }

    function view_mirf($interactionID) {
      
        $mirfId = $this->interaction->getMirfIdFromInteractionId($interactionID);
        foreach ($mirfId as $key => $value) {
            $id = $value;
        }
        $aarData = $this->interaction->listMirf($id);
        $productDetails = $this->interaction->getProductDetails($id);
        $productName = $this->interaction->getProductNames();
        $arrTemp = array();
        foreach ($productName as $key => $value) {
            $arrTemp[$value['id']] = strtoupper($value['name']);
        }
        $selectedProductIds = array();
        foreach ($productDetails as $key => $value) {
            $selectedProductIds[] = $value['product_id'];
            foreach ($value as $key1 => $value1) {
                if ($key1 == 'other_product_name')
                    $otherProductValue = $value1;
            }
        }
        $data['userTerritory'] = $this->client_user->getUserTerritoryById($aarData[0]['created_by']);
        $data['productArray'] = $arrTemp;
        $data['selectedProductIds'] = $selectedProductIds;
        $data['otherProductValue'] = $otherProductValue;
        $data['productDetails'] = $productDetails;
        $data['arrData'] = $aarData[0];
        $savedMirfID = $id;
        //Add Log activity
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_VIEW,
            'description' => 'View Mirf',
            'status' => 'success',
            'transaction_id' => $savedMirfID,
            'transaction_table_id' => INTERACTION_MIRF_PRODUCTS,
            'transaction_name' => "ViewMirf",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);
        log_user_activity(null, true);
        //exit;
        $data['contentPage'] = 'interactions/view_mirf';
        $this->load->view('layouts/client_view', $data);
    }

    function delete_mirf($id) {
        $this->interaction->deleteMirfProduct($id);
        $this->interaction->deleteMirf($id);
    }

    function search_territories() {
        $this->load->view('interactions/territory_search_result', $arrData);
    }

    function load_territories() {
        $page = (int) $_REQUEST['page']; // get the requested page
        $limit = (int) $_REQUEST['rows']; // get how many rows we want
        $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
        $sord = $_REQUEST['sord']; // get the direction
        $filterData = $_REQUEST['filters'];

        $arrResult = $this->interaction->getTerritoryData();
        $count = count($arrResult);
        $data = array();
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        if ($page > $total_pages)
            $page = $total_pages;
        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        if ($start < 0)
            $start = 0;
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrResult;
//		pr($data);
        ob_start('ob_gzhandler');
        echo json_encode($data);
    }

    function get_kol_other_details($kolId = null) {
        //echo "ddd";
        if ($kolId == null || $kolId == '') {
            $kolName = $this->input->post('kol_name');
            //	$value1=str_replace(" ","",$kolName);
            $kolId = $this->kol->getKolId($kolName);
        }
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetails = $this->kol->getKolDetailsById($kolId);	
        $data['specialtyId'] = $arrKolDetails[0]['specialty'];
        $data['title'] = $arrKolDetails[0]['title'];
        $data['specialtyName'] = $this->specialty->getSpecialtyById($data['specialtyId']);
        $data['last_interaction'] = $this->interaction->getKolLastInteractionById($kolId);
        //pr($data);
        //exit;
        echo json_encode($data);
    }

    function get_org_other_details($kolId = null) {
        //echo "ddd";
        if ($kolId == null || $kolId == '') {
            $kolName = $this->input->post('kol_name');
            //	$value1=str_replace(" ","",$kolName);
            $kolId = $this->kol->getKolId($kolName);
        }

        $arrKolDetails = $this->kol->getKolDetailsById($kolId);
        $data['specialtyId'] = $arrKolDetails[0]['specialty'];
        $data['specialtyName'] = $this->specialty->getSpecialtyById($data['specialtyId']);
        $data['last_interaction'] = $this->interaction->getOrgLastInteractionById($kolId);
        //pr($data);
        //exit;
        echo json_encode($data);
    }
    
    function get_key_people_details($keyId = null) {
    	
    	$arrKolDetails = $this->interaction->getKepPeopleTitle($keyId);
    	$data['title'] = $arrKolDetails[0]['title'];
    	//pr($data);
    	//exit;
    	echo json_encode($data);
    }

    function get_topic_by_type($typeId = "", $productId = "") {
        $arrPrducts['arrTopics'] = $this->interaction->getTopicByType($typeId, $productId);
        echo json_encode($arrPrducts);
    }

    function get_sub_topics($productId, $typeId, $topicId) {
        $arrData = $this->interaction->getSubTopics($productId, $typeId, $topicId);
        if (count($arrData) > 0)
            $data['arrSubTopics'] = $arrData;
        else
            $data['arrSubTopics'] = array();
        echo json_encode($data);
    }

    function parse_signature_image() {
        $data_uri = $this->input->post('signature_data');
        $data_pieces = explode(",", $data_uri);
        $encoded_image = $data_pieces[1];
        $decoded_image = base64_decode($encoded_image);
        $imageName = random_string('unique', 20) . ".png";
        $target_path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "/images/mirf_signatures/" . $imageName;
        file_put_contents($target_path, $decoded_image);
        $data['status'] = true;
        $data['image_name'] = $imageName;
        $data['image_url'] = base_url() . "/images/mirf_signatures/" . $imageName;
        echo json_encode($data);
    }

    function find_history($interactionId) {
        $arrHistories = array();
        if ($interactionId != '') {
            $arrLogs = array();
            $this->db->where('transaction_id', $interactionId);
            $this->db->where('transaction_table_id', INTERACTIONS);
            $this->db->where('transaction_name', 'Update Interaction');
            $this->db->where_in('type', array(LOG_UPDATE, LOG_ADD));
            $this->db->order_by('id', 'desc');
            $res = $this->db->get('log_activities');
            if (is_object($res) && $res->num_rows() > 0) {
                $arrLogs = $res->result_array();
            }
            foreach ($arrLogs as $key => $log) {
                if ($key == (count($arrLogs) - 1))
                    continue;
                $history = array();
                $intLatest = json_decode($log['form_data'], true);
                $intPrev = json_decode($arrLogs[$key + 1]['form_data'], true);
                //pr($intLatest);
                //pr($intPrev);
                $changes = array_diff_assoc($intLatest, $intPrev);
                //pr($changes);
                //pr('.....................');
                $history['created_on'] = $log['created_on'];
                $history['created_by'] = $this->client_user->getUserNameById($log['created_by']);
                $history['changes'] = array();
                foreach ($changes as $key => $value) {
                    $changeText = "";
                    switch ($key) {
                        case 'territory' : $changeText .="Territory : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'mode' : $changeText .="Mode : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'grouping' : $changeText .="Grouping : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'mirf_case_num' : $changeText .="MIRF Case Number : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'date' : $changeText .="Date : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'total_attendies' : $changeText .="Total Attendies : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'timefmhr' :
                        case 'timefmmin':
                        case 'timefmap':$changeText .="Time : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case 'notes' : $changeText .="Notes : " . $intPrev[$key] . " to " . $intLatest[$key];
                            break;
                        case (preg_match('/product.*/', $key) ? true : false) :
                        case (preg_match('/objective.*/', $key) ? true : false) :
                        case (preg_match('/topic.*/', $key) ? true : false) :
                        case (preg_match('/subtopic.*/', $key) ? true : false) : if (isset($intPrev[$key]))
                                $changeText .="Change in Discussion Topic";
                            else
                                $changeText .="New Discussion Topic";
                            break;
                        case (preg_match('/non_profiled_kol.*/', $key) ? true : false) :
                        case (preg_match('/non_profifled_specialty.*/', $key) ? true : false) : if (isset($intPrev[$key]))
                                $changeText .="Change in Non-Profiled Attendees";
                            else
                                $changeText .="New Non-Profiled Attendee";
                            break;
                        case (preg_match('/kol_name.*/', $key) ? true : false) :
                        case (preg_match('/status.*/', $key) ? true : false) :
                        case (preg_match('/therapeutic_area.*/', $key) ? true : false) : if (isset($intPrev[$key]))
                                $changeText .="Change in Attendees";
                            else
                                $changeText .="New Attendee";
                            break;
                    }
                    $history['changes'][] = $changeText;
                }
                $history['changes'] = array_unique($history['changes']);
                $arrHistories[] = $history;
            }
            //pr($arrHistories);
        }
        return $arrHistories;
    }

    function export_pdf($id) {

        $aarData = $this->interaction->listMirf($id);
        $productDetails = $this->interaction->getProductDetails($id);
        $productName = $this->interaction->getProductNames();
        $arrTemp = array();
        foreach ($productName as $key => $value) {
            $arrTemp[$value['id']] = strtoupper($value['name']);
        }
        $selectedProductIds = array();
        foreach ($productDetails as $key => $value) {
            $selectedProductIds[] = $value['product_id'];
            foreach ($value as $key1 => $value1) {
                if ($key1 == 'other_product_name')
                    $otherProductValue = $value1;
            }
        } 
        $firstRowProduct=$this->interaction->getProductNamesForFirstRow($id);
          foreach ($firstRowProduct as $key1 => $value1) {
              if($value1['is_single_use_vial']==1)
                     $firstproductnames .=' <br/> Abilify Maintena: Single-Use Vial';
                if($value1['is_dual_chamber_syringe']==1)
                     $firstproductnames .='<br/> Abilify Maintena: Dual Chamber Syringe ';
                if($value1['is_non_kit_specific_enquiry']==1)
                     $firstproductnames .='<br/> Abilify Maintena: Non-kit Specific Inquiry ';
          } 
        $arrProduct = $this->interaction->getProductNamesForSelectedIds($id);
        $productnames = "";

        foreach ($arrProduct as $key1 => $value1) {
            if (in_array("PsychU", $value1) || in_array("Abilify Maintena", $value1)) {
//                $productnames .=$value1['other_product_name'];
            } else { 
                if($value1['name']!="")
                
                $productnames .=$value1['name'] . ", "; 
                $productnames .=$value1['other_product_name']; 
            } 
        }
        $productnames = rtrim($productnames, ', ');
        $productnames.=$firstproductnames; 
        $data['productArray'] = $arrTemp;
        $data['selectedProductIds'] = $selectedProductIds;
        $data['otherProductValue'] = $otherProductValue;
        $data['productDetails'] = $productDetails;
        $aarData[0]['productName'] = $productnames;
        $data['arrData'] = $aarData[0];
        $content = $this->load->view('interactions/pdf_view_mirf', $data, TRUE);

        ini_set('memory_limit', "800M");
        $this->load->plugin('export_pdf');
        $filename = 'Unsolicited Off-Label Question';
        pdf_create($content, $filename);
    }

    function getIdByUsername($fname, $lname) {

        $userid = $this->client_user->getUserIdByName($fname, $lname);
        echo json_encode($userid);
    }

    function send_email_for_export_interaction() {
        $currentMethod = $this->uri->segment(3);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        // $this->email->to("shrutip@aissel.com");
        $loggedInUserName = $this->session->userdata('user_full_name');

        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of Interactions report data from '.PRODUCT_NAME.'.';

        $loggedInUserEmail = $this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.":Interactions");
        $path = $this->export_interaction_details();


        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
        } else {
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
    }
    
    function send_added_interaction_report($id, $type, $interation_id){
    	$user_email	= array();
    	$emailIds = '';
    	$seperator = '';
    	$arrReturnResult	= $this->interaction->getAssignedUsersForType($id, $type);
    	$type_name	= $arrReturnResult['type_name'];
    	$user_email	= $arrReturnResult['user_details'];
    	foreach($user_email as $row){
    			$emailIds .= $seperator.$row;
    			$seperator = ',';
		}
    	$to = $user_email;
    	$config['protocol'] = PROTOCOL;
    	$config['smtp_host'] = HOST;
    	$config['smtp_port'] = PORT;
    	$config['smtp_user'] = USER;
    	$config['smtp_pass'] = PASS;
    	$config['mailtype'] = 'html';
    	$this->load->library('email', $config);
    	$this->email->set_newline("\r\n");
    	$this->email->initialize($config);
    	$this->email->clear();
    	$this->email->set_newline("\r\n");
    	$this->email->from(USER, SENDER);
    	$messageBody = 'Hi, <br/><br/> This is a notification about an interaction('.$interation_id.') that has been recorded with '.$type_name;
    	if($type == 'org'){
    	    $kol_or_org_type = 'Organization';
    		$messageBody .= '<br/><br/>Please <a href="'.base_url().'organizations/view_interactions/'.$id.'/interaction_report">click here</a> to view the interaction.';
    	}else{
    	    $kol_or_org_type = 'Kol';
    		$messageBody .= '<br/><br/>Please <a href="'.base_url().'kols/view/'.$id.'/interaction_report">click here</a> to view the interaction.';
    	}
    	$messageBody .= '<br/><br/>Regards,<br/>Aissel Support Team';
    	$this->email->to($to);
    	$this->email->message($messageBody);
    	$this->email->subject("New Interaction : ".$type_name);
    	$this->email->set_crlf("\r\n");
    	if ($this->email->send()){
    		//Record log Activity
    		$arrLogDetails = array(
		        'type' => LOG_ACTIVITY_EMAIL,
				'description' => 'Interaction Added Report',
		        'status' => STATUS_SUCCESS,
		        'kols_or_org_type' => $kol_or_org_type,
		        'kols_or_org_id' => $id,
				'transaction_id' => $interation_id,
		        'transaction_table_id' => INTERACTIONS,
    		    'transaction_name' => "New Added Interaction Sent",
		        'parent_object_id' => $id,
				'miscellaneous2' => $type." To- ".$emailIds
    		);
    		$this->config->set_item('log_details', $arrLogDetails);
    		log_user_activity(null, true);
    		return true;
    	} else {
    	    //Record log Activity
    	    $arrLogDetails = array(
    	        'type' => LOG_ACTIVITY_EMAIL,
    	        'description' => 'Interaction Added Report',
    	        'status' => STATUS_FAIL,
    	        'kols_or_org_type' => $kol_or_org_type,
    	        'kols_or_org_id' => $id,
    	        'transaction_id' => $interation_id,
    	        'transaction_table_id' => INTERACTIONS,
    	        'transaction_name' => "New Added Interaction Sent",
    	        'parent_object_id' => $id,
    	        'miscellaneous2' => $type." To- ".$emailIds
    	    );
    	    $this->config->set_item('log_details', $arrLogDetails);
    	    log_user_activity(null, true);
    		return false;
    	}
    }
    
    function get_type_by_product($productid, $isFromEditInteraction = false) {
        $arrTypeName = $this->interaction->getTypeByProduct($productid);
        if($isFromEditInteraction){
        	return $arrTypeName;
        }else{
        	echo json_encode($arrTypeName);
        }
    }
    
    function unlock_interactions_by_id($kolId,$interId,$flag,$interGenericId,$msl){
      
    	$data = array();
    	if($this->interaction->unlockInteractionsById($interId,$flag)){
            if($flag == 1){
                $status=$this->unlock_interaction_email($kolId,$interGenericId,$msl);
            }
            $_POST['interactionId']=$interGenericId;
    		$form_data = json_encode($_POST);
    		$data['status'] = true;
			if($flag == 1){
				$trnasName = "Unlock";	
			}else{
				$trnasName = "Lock";
			}
	        $arrLogDetails = array(
	            'module' => 'interactions',
	            'type' => LOG_UPDATE,
	            'description' => 'Update Interaction',
	            'status' => 'success',
	            'transaction_id' => $interId,
	            'transaction_table_id' => INTERACTIONS,
	            'transaction_name' => $trnasName,
	            'form_data' => $form_data,
	            'parent_object_id' => $kolId
	        );
	        $this->config->set_item('log_details', $arrLogDetails);
	        log_user_activity(null, true);
    	}else{
    		$data['status'] = false;
    	}
    	echo json_encode($data);
    }
    
    function add_lock_unlock(){
    	$this->load->view("interactions/add_lock_unlock");
    }
    
    function delete_interactions_by_id($interId){
    	$data = array();	
    	if($this->interaction->deleteInteractionsById($interId)){
    		$data['status'] = true;
    	}else{
    		$data['status'] = false;
    	}
    	echo json_encode($data);
    }
    
     function mirf_export(){
         $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
           $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $fromDate=date("Y-m-d 12:04:12",strtotime('monday last week'));
        $toDate=date("Y-m-d H:i:s",strtotime("sunday last week"));
        
     $this->db->select(" client_users.first_name as mslF,client_users.last_name as mslL,kols.first_name,kols.last_name,interactions.mirf_case_num,interactions.date,interactions.generic_id,interactions.created_on",false);
         $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id=interactions.id', 'left');
     $this->db->join('kols', 'kols.id=interactions_attendees.kol_id', 'left');
        $this->db->where("interactions.created_on >='" . $fromDate . "'");
           $this->db->where("interactions.created_on <='" . $toDate . "'");
           $this->db->where("interactions.mirf_case_num !=''");
           $this->db->group_by("interactions.id");
           $arrResult = $this->db->get('interactions');
//           echo $this->db->last_query();
    foreach ($arrResult->result_array() as $val) {
       $arrInteractions[] =$val;
    }
 

       
        //New Worksheet
         $fileName = 'MSL Weekly MIRF Report';
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('MSL Weekly MIRF Report');
        //Add header
        $objWorksheet->setCellValue('A1', 'MSL/MML Name')
                ->setCellValue('B1', 'KTL Name')
                ->setCellValue('C1', '	MIRF Case #')
                ->setCellValue('D1', 'Interaction ID')
                ->setCellValue('E1', 'Interaction Date')
                ->setCellValue('F1', 'Creation Date');
        $i = 2;
        foreach ($arrInteractions as $rows) {
          
            $objWorksheet->setCellValue('A' . $i, $rows['mslF']." ".$rows['mslL'])
                    ->setCellValue('B' . $i, $rows['first_name']." ".$rows['last_name'])
                    ->setCellValue('C' . $i, $rows['mirf_case_num'])
                    ->setCellValue('D' . $i, $rows['date'])
                    ->setCellValue('E' . $i, $rows['generic_id'])
                    ->setCellValue('F' . $i, $rows['created_on']);
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);




        // remove first sheet

        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );

        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'F') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        
        $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
        $objWriter->save($path);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody='Hi  ' .$loggedInUserName . ', <br/><br/> Attached is the export of MSL Weekly MIRF Report from '.PRODUCT_NAME.'.';
        //$loggedInUserEmail=$this->session->userdata('email');
//        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        
        $this->email->to("shrutip@aissel.com");
        $this->email->subject(PRODUCT_NAME.":MSL Weekly MIRF Report");
        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
//           link($path);
            
        } else {
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
  
    }
    
    
   
     function interaction_lock_unlock_export(){
          $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
           $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
          $fromDate=date("Y-m-d 12:04:12",strtotime('monday last week'));
        $toDate=date("Y-m-d H:i:s",strtotime("sunday last week"));
        $this->db->select("client_users.first_name as mslF,client_users.last_name as mslL,transaction_id,form_data,log_activities.created_on",false);
         $this->db->join('client_users', 'client_users.id = log_activities.created_by', 'left');
       
      $this->db->where("log_activities.created_on >='" . $fromDate . "'");
        $this->db->where("log_activities.created_on <='" . $toDate . "'");
            $this->db->where("log_activities.transaction_name ='Unlock' OR log_activities.transaction_name ='Lock'");
           $this->db->group_by("log_activities.id");
           $arrResult = $this->db->get('log_activities');
              foreach ($arrResult->result_array() as $val) {
       $arrInteractions[] =$val;
    }
   
             //New Worksheet
         $fileName = 'Interaction  Update Tracking Report';
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//        $objWorksheet->setTitle('Interaction  Update Tracking Report');
//        //Add header
        $objWorksheet->setCellValue('A1', 'Date Request Received')
                ->setCellValue('B1', 'Name of Requester')
                ->setCellValue('C1', 'Change(s) Requested')
                ->setCellValue('D1', 'Date Interaction Unlocked')
                ->setCellValue('E1', 'DateRequester Informed')
                ->setCellValue('F1', 'INC#')
                ->setCellValue('G1', 'Notes')
                ->setCellValue('H1', 'Aissel Ticket ID');
        $i = 2;
         
        foreach ($arrInteractions as $rows) {
      

       $arrFilters=$rows['form_data'];
    
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
            $objWorksheet->setCellValue('A' . $i, $arrFilters['date_of_request'])
                    ->setCellValue('B' . $i, $rows['mslF']." ".$rows['mslL'])
                    ->setCellValue('C' . $i, $arrFilters['description'])
                    ->setCellValue('D' . $i, $rows['created_on'])
                    ->setCellValue('E' . $i, $rows['created_on'])
                    ->setCellValue('F' . $i, $arrFilters['interactionId'])
                      ->setCellValue('G' . $i, "")
                      ->setCellValue('H' . $i, $arrFilters['ticket_id'])
                    ;
            $i++;
        } 
        $objPHPExcel->addSheet($objWorksheet);




        // remove first sheet

        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );

        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'H') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        
        $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
        $objWriter->save($path);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
      	$messageBody='Hi  ' .$loggedInUserName . ', <br/><br/> Attached is the export of Weekly Interaction Unlock Report from '.PRODUCT_NAME.'.';
        //$loggedInUserEmail=$this->session->userdata('email');
//        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        
        $this->email->to("shrutip@aissel.com");
        $this->email->subject(PRODUCT_NAME.":Weekly Interaction Unlock Report");
        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
//           link($path);
            
        } else {
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
       
 
    }
    
    function unlock_interaction_email($kolId,$interGenericId,$msl){
        $arrUsers=$this->Client_User->editUser($msl);
        $emailId=$arrUsers['email'];
        $emailTo=$arrUsers['first_name'];
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
//         $this->email->to("shrutip@aissel.com");
        $messageBody = 'Hi  ' . $emailTo . ', <br/><br/> Interaction ID '.$interGenericId.' has been unlocked for editing. <br/><br/> <a target="_NEW" href="' . base_url() . 'kols/view/' . $kolId . '/interaction_report">Click here</a> to view the interactions.';

      
        $this->email->to($emailId);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.": Interaction Id [$interGenericId] Unlock Alert");
       
       
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
          
        } else {
            $emailData['status'] = 'Mail not sent';
        }
        return $emailData['status'];
         
    }
    
    function get_attendees($restrictByRegion=0,$restrictOptInVisbility=0) {
        
        $kolName = trim($_POST['q']);
        $kolDetailsArray = $this->interaction->getAllAttendeesAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);
        $arrkolDetails = array();
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        foreach($kolDetailsArray as $kol) {
            $kol['kol_name'] = $this->common_helpers->get_name_format ( $kol ['first_name'], $kol ['middle_name'], $kol ['last_name'] );
            if($kol['specialty']) {
                $kol['specialty'] = $this->kol->getSpecialtyById($kol['specialty']);
            } else {
                 $kol['specialty'] = "";
            }
            $kol['salutation'] = $arrSalutations[$kol['salutation']];
            $arrkolDetails[] = $kol;
        }
        echo json_encode($arrkolDetails);
    }
    
    function get_all_topics_to_repopulate(){
    	$data['arrProduct'] = $this->common_helpers->getUserProducts();
    	$data['arrDiscussionType'] = $this->interaction->getDiscussionTypeByProductIds($data['arrProduct']);
    	$data['arrDiscussionTopic'] = $this->interaction->getTopicsByDiscussionTypesAndProductIds($data['arrProduct'],$data['arrDiscussionType']);
    	echo json_encode($data['arrDiscussionTopic']);
    }
    
    function get_topic_by_type_only($typeId){
    	$data['arrTopics'] = $this->interaction->getTopicsByDiscussionTypeId($typeId);
    	echo json_encode($data['arrTopics']);
    }
    function add_product_topic_discussionType($type){
        $data = array();
        if($type=='product'){
            $data['status'] = $this->interaction->saveProductOrDiscussionTypeOrTopic($this->input->post('name'),"products");
        }else if($type=='dtype'){
            $data['status'] = $this->interaction->saveProductOrDiscussionTypeOrTopic($this->input->post('name'),"interaction_types");
        }else if($type=='topic'){
            $data['status'] = $this->interaction->saveProductOrDiscussionTypeOrTopic($this->input->post('name'),"interaction_topics");
        }
        echo json_encode($data);
    }
    function update_created_date(){
    	$arrInteractionId = $this->interaction->updateCreatedDate();
    	if($arrInteractionId == true)
    			echo 'Created Date for Interactions Modified Successfully!';	
     		else
     			echo 'No Interactions avaliable to modify';
    }
}
