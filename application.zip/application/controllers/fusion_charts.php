<?php
/**
 * This is Controller file for 'Fusion_charts'
 * 
 * @author Ambarish
 * @since	v.1.5.1
 * @package application.controllers	
 * @created on  22-03-11
 * 
 */

class Fusion_charts extends Controller{
	
	private $loggedUserId	= null;
	//Constructor
	function Fusion_charts(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('pubmed');
		$this->load->model('country_helper');
		$this->load->model('clinical_trial');
		$this->load->model('my_list_kol');
	}
	
	
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."/login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}
	
	/**
	 * Generates the chart for Affiliations Group by Organization Types accept the data from post method
	 * @return unknown_type
	 */
	function chart_for_organization_post(){
		$fromYear 			= ($this->input->post('from_year')==null) ? 0:$this->input->post('from_year');
		$toYear				= ($this->input->post('to_year')==null) ? 0:$this->input->post('to_year');
		$arrKolNames			= ($this->input->post('kol_id')==null) ? 0:$this->input->post('kol_id');
		$arrSpecialities	= ($this->input->post('specialty')==null) ? 0:$this->input->post('specialty');
		$arrCountries		= ($this->input->post('country')==null) ? 0:$this->input->post('country');
		$arrEngTypes 		= ($this->input->post('engType')=='') ? '':$this->input->post('engType');
		if($arrSpecialities!='0' && $arrSpecialities!=''){
			foreach($arrSpecialities as $key=>$value)
			$arrSpecialityIds[]=$this->kol->getSpecialtyId($value);
		}else{
			$arrSpecialityIds=$arrSpecialities;
		}
		
		if($arrCountries!='0' && $arrCountries!=''){
			foreach($arrCountries as $key=>$value)
			$arrCountriesIds[]=$this->country_helper->getConcountryId($value);
		}else{
			$arrCountriesIds=$arrCountries;
		}
		
		if($arrKolNames!='0' && $arrKolNames!=''){
			foreach($arrKolNames as $key=>$kolName){
				//$kolName1=str_replace(" ","",$kolName);
				$arrKolIds[]=$this->kol->getKolId($kolName);
			}
		}else{
			$arrKolIds=$arrKolNames;
		}
		
		$arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear,$arrKolIds,$arrEngTypes,$arrOrgType='',$arrCountriesIds,$arrSpecialityIds,$selectType='kol_memberships.type');
		$arrOrgCounts=array();
		foreach($arrAffiliations as $row){
			$arr=array();
			$arr['label']=ucwords($row['type']);
			$arr['value']=(int)$row['count'];
			$arr['link']="JavaScript:showEngegementFusionChart('".$row['type']."','".$fromYear."','".$toYear."','".$arrKolIds."','".$arrSpecialities."','".$arrCountries."')";
			$arrOrgCounts[]=$arr;
		}
	//	pr($arrOrgCounts);
		echo json_encode($arrOrgCounts);
	}
	
	/**
	 * Generates the chart for Affiliations Group by Engagement Types accept the data from post method
	 * @return unknown_type
	 */
	function chart_for_engagement_post(){
		$fromYear 			= ($this->input->post('from_year')==null) ? 0:$this->input->post('from_year');
		$toYear				= ($this->input->post('to_year')==null) ? 0:$this->input->post('to_year');
		$arrKolIds			= ($this->input->post('kol_id')==null) ? 0:$this->input->post('kol_id');
		$arrSpecialities	= ($this->input->post('specialty')==null) ? 0:$this->input->post('specialty');
		$arrCountries		= ($this->input->post('country')==null) ? 0:$this->input->post('country');
		$arrEngTypes 		= ($this->input->post('engType')=='') ? '':$this->input->post('engType');
		$arrOrgType = $this->input->post('orgType');
		if($arrCountries!='0' && $arrCountries!=''){
			$arrCountries=$this->country_helper->getConcountryId($arrCountries);
		}
		if($arrSpecialities!='0' && $arrSpecialities!=''){
			$arrSpecialities=$this->kol->getSpecialtyId($arrSpecialities);
		}
		
		$arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear,$arrKolIds,$arrEngTypes='',$arrOrgType,$arrCountries,$arrSpecialities,$selectType='engagement_types.engagement_type');
		$arrEngagementCounts=array();
		foreach($arrAffiliations as $row){
			$arr=array();
			if($row['engagement_type']!=''){
				$arr['label']=$row['engagement_type'];
				$arr['value']=(int)$row['count'];
				$arrEngagementCounts[]=$arr;
			}
		}
	//	pr($arrEngagementCounts);
		echo json_encode($arrEngagementCounts);
	}
	
	/**
	 * Counts the number kols based on specialty
	 * 
	 * @return unknown_type
	 */
	function get_kol_count_by_specialty_fusion_chart(){
		
		$arrKolIds=array();
		$fromYear 			= $this->input->post('from_year');
		$toYear				= $this->input->post('to_year');
		$arrKolNames		= ($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id');
		$arrSpecialities	= ($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty');
		$arrCountries		= ($this->input->post('country')==(null || '')) ? 0:$this->input->post('country');
		$arrListNames		= ($this->input->post('listName')==(null || '')) ? 0:$this->input->post('listName');
		
		if($arrSpecialities!='0' && $arrSpecialities!=''){
			foreach($arrSpecialities as $key=>$value)
			$arrSpecialityIds[]=$this->kol->getSpecialtyId($value);
		}else{
			$arrSpecialityIds=$arrSpecialities;
		}
		
		if($arrCountries!='0' && $arrCountries!=''){
			foreach($arrCountries as $key=>$value)
			$arrCountriesIds[]=$this->country_helper->getConcountryId($value);
		}else{
			$arrCountriesIds=$arrCountries;
		}
		
		if($arrKolNames!='0' && $arrKolNames!=''){
			foreach($arrKolNames as $key=>$kolName){
				//$kolName1=str_replace(" ","",$kolName);
				$arrKolIds[]=$this->kol->getKolId($kolName);
			}
		}else{
			$arrKolIds=$arrKolNames;
		}
		
		if($arrListNames!='0' && $arrListNames!=''){
			foreach($arrListNames as $key=>$value)
			$arrListNamesIds[]=$this->my_list_kol->getListNameId($value);
		}else{
			$arrListNamesIds=$arrListNames;
		}
		
		//$arrKolCount=$this->kol->getKolCountBySpecialty();
		$arrKolCount=$this->kol->getKolsByParam($fromYear=0, $toYear=0,$arrKolIds,$arrCountriesIds,$arrSpecialityIds,$groupBy='specialty',$arrListNamesIds);
		//pr($arrKolCount);
		$arrKolCounts=array();
		foreach($arrKolCount as $row){
			$arr=array();
			$arr['label']=$row['name'];
			$arr['value']=(int)$row['count'];
			$arrKolCounts[]=$arr;
		}
		echo json_encode($arrKolCounts);
	}
	
	
	/**
	 * Prepares the JSON data for top 20 MeshTerms count chart
	 * @author 	Ramesh B
	 * @Created on: 14-03-11
	 * @since	1.5.1
	 * @return Array
	 */
	function view_pub_major_meshterm_fusion_chart(){
		$arrCountriesIds=array();
		$fromYear 			= $this->input->post('from_year');
		$toYear				= $this->input->post('to_year');
		$arrKolNames		= ($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id');
		$arrSpecialities	= ($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty');
		$arrCountries		= ($this->input->post('country')==(null || '')) ? 0:$this->input->post('country');
		if($arrSpecialities!=0 && $arrSpecialities!=''){
			foreach($arrSpecialities as $key=>$value)
			$arrSpecialityIds[]=$this->kol->getSpecialtyId($value);
		}else{
			$arrSpecialityIds=$arrSpecialities;
		}
		
		if($arrCountries!=0 && $arrCountries!=''){
			foreach($arrCountries as $key=>$value)
			$arrCountriesIds[]=$this->country_helper->getConcountryId($value);
		}else{
			$arrCountriesIds=$arrCountries;
		}
		
		if($arrKolNames!=0 && $arrKolNames!=''){
			foreach($arrKolNames as $key=>$kolName){
				//$kolName1=str_replace(" ","",$kolName);
				$arrKolIds[]=$this->kol->getKolId($kolName);
			}
		}else{
			$arrKolIds=$arrKolNames;
		}
		$arrMajorMeshterm = $this->pubmed->getPublicationsByParam($fromYear, $toYear,$arrKolIds,$arrCountriesIds,$arrSpecialityIds,$groupBy='keyword');
		//pr($arrMajorMeshterm);
		$data = array();
		$count=array();
		$i=20;
		foreach($arrMajorMeshterm as $meshterm){
			$meshTermData = array();
			if($i<=0)break;
			$termName='';
			$parentId=$meshterm['parent_id'];
			if($parentId!=0 && $parentId!=null){
				$parentName=$this->pubmed->getMeshTermName($parentId);
				$termName=$parentName."/".$meshterm['mesh_term'];
			}else{
				$termName=$meshterm['mesh_term'];
			}
			$meshTermData['label']=ucwords($termName);
			$meshTermData['value']=(int)$meshterm['count'];
			$data[]= $meshTermData;
			$i--;
		}
		echo json_encode($data);
	}
	
	//Reference chart Depricated
	//Method to Create a Child graph from the controler Links
	function get_kol_count_by_specialty_fusion_chart_second(){
		$fromYear 			= $this->input->post('from_year');
		$toYear				= $this->input->post('to_year');
		$arrKolIds			= ($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id');
		$arrSpecialties	= ($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty');
		$arrCountries		= ($this->input->post('country')==(null || '')) ? 0:$this->input->post('country');
		if($arrCountries!='0' && $arrCountries!=''){
			$arrCountries=$this->country_helper->getConcountryId($arrCountries);
		}
		if($arrSpecialties!='0' && $arrSpecialties!=''){
			$arrSpecialties=$this->kol->getSpecialtyId($arrSpecialties);
		}
		//$arrKolCount=$this->kol->getKolCountBySpecialty();
		$arrKolCount=$this->kol->getKolsByParam($fromYear=0, $toYear=0,$arrKolIds,$arrCountries,$arrSpecialties,$groupBy='specialty');
		//pr($arrKolCount);
		$arrKolCounts=array();
		$values=array();
		$chartDetails = array(	'caption' 		=> 	'child of speciality chart',
								'xaxisname'		=>	'Count',
								'yaxisname' 	=> 	'speciality');
		$arrKolCounts['chart']= $chartDetails;
		foreach($arrKolCount as $row){
			$arr=array();
			$arr['label']=$row['name'];
			$arr['value']=(int)$row['count'];
			$values[]=$arr;
		}
		$arrKolCounts['data']=$values;
		echo json_encode($arrKolCounts);
	}
	
}