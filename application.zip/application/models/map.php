<?php
/**
 * This is Model file of 'Map'
 * 
 * @package application.models
 * @author Ambarish
 * @since 2.2.1
 * @created on  13-05-11
 */

class Map extends Model{
	//Constructor 	
	function Map(){
		parent::Model();
		$this->load->model("Event_helper");
		$this->load->model("common_helpers");
	}
	/**
	 * Which returns the all kols data for the g.map.  without any conditions
	 * @author Ambarish
	 * @Created on: May-18-11
	 * @since 2.2.1
	 * @return unknown_type
	 */
	function getKolsForMap(){
		$this->db->select(array('kols.id','concat(kols.first_name," ",kols.middle_name," ",kols.last_name) as kolName','cities.city','cities.Latitude','cities.Longitude','kols.profile_image','kols.address1','kols.address2','countries.Country','regions.Region','kols.postal_code','specialties.specialty'));
		$this->db->join('countries', 'kols.country_id = countries.CountryId', 'left');
		$this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
		$this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
		$this->db->join('specialties','specialties.id=kols.specialty','left');
		$this->db->where_not_in('kols.city_id','0');
		$this->db->order_by('kols.city_id','desc');
		
		$arrKols = array();
		$lat = array();
		$lng = array(); 
		$arrKolsResult	=	$this->db->get('kols');
		foreach($arrKolsResult->result_array() as $row){
			 $prev_lat = end($lat);
	    	 $prev_lng = end($lng);
	    	 $latvalue = $row['Latitude'];
	    	 $longvalue = $row['Longitude'];
	    	 if(($row['Latitude'] == $prev_lat) && ($row['Longitude'] == $prev_lng)) {
				$random_num_lat = .00065 * mt_rand(1, 10);
				$random_num_lng = .00065 * mt_rand(1, 10);
				$row['Latitude']=$row['Latitude']+ $random_num_lat;
				$row['Longitude']=$row['Longitude'] + $random_num_lng;
	    	 }else{
	    	 	$row['Latitude']=$row['Latitude'];
				$row['Longitude']=$row['Longitude'];
	    	 }
	   		$lat[] = $latvalue;
	   		$lng[] = $longvalue; 
			$arrKols[]=$row;
		}	
     	return $arrKols;
	}
	
	/**
	 * Which returns the all kols data for the g.map. Based on the passed parametrs condition
	 * @author Ambarish
	 * @Created on: May-18-11
	 * @since 2.2.1
	 * 
	 * @param $name
	 * @param $arrFilterFields
	 * @param $limit
	 * @param $startFrom
	 * @param $doCount
	 * @param $doGroupBy
	 * @param $groupByCategory
	 * @return unknown_type
	 */
	function getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrKols=array();
		$lat = array();
		$lng = array(); 
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		if(!$doCount)
			$this->db->select(array('kols.id','concat(kols.first_name," ",kols.middle_name," ",kols.last_name) as kolName','cities.city','cities.Latitude','cities.Longitude','kols.profile_image','kols.address1','kols.address2','countries.Country','regions.Region as state','kols.postal_code','specialties.specialty'));
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
		$this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
		$this->db->order_by('kols.city_id','desc');
		if($arrFilterFields!=null && $arrFilterFields['education']!=null && isset($arrFilterFields['education']) && sizeof($arrFilterFields['education'])>0 && !($doGroupBy==true && $groupByCategory=='education')){
			$this->db->distinct();
			$this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
			$this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
			$this->db->where_in('institutions.name',$arrFilterFields['education']);
			$this->db->where('kol_educations.type','education');
		}
		if($arrFilterFields!=null && $arrFilterFields['event_id']!=null && isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id'])>0 && !($doGroupBy==true && $groupByCategory=='event')){
			$this->db->distinct();
			$this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
			$this->db->join('events', 'kol_events.event_id = events.id', 'left');
			$this->db->where_in('events.name',$arrFilterFields['event_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0 && !($doGroupBy==true && $groupByCategory=='list')){
			$this->db->distinct();
			$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
			$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
			//$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
			$this->db->where_in('list_names.id',$arrFilterFields['list_id']);
		}
		$name=$arrKeywords[0];
		//$where="(first_name LIKE '".$name."%' OR last_name LIKE '".$name."%' OR middle_name LIKE '".$name."%')";
		$where='(first_name LIKE "'.$name.'%" OR last_name LIKE "'.$name.'%" OR middle_name LIKE "'.$name.'%")';
		//$this->db->like('first_name', $name, 'after');
		//$this->db->or_like('middle_name', $name, 'after');
		//$this->db->or_like('last_name', $name, 'after');
		$this->db->where($where);
		//pr($arrFilterFields);
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0 && !($doGroupBy==true && $groupByCategory=='country'))
			$this->db->where_in('countries.country', $arrFilterFields['country']);
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0 && !($doGroupBy==true && $groupByCategory=='state'))
			$this->db->where_in('regions.RegionId', $arrFilterFields['state']);
		if($arrFilterFields!=null && $arrFilterFields['organization']!='' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization'])>0 && !($doGroupBy==true && $groupByCategory=='organization'))
			$this->db->where_in('organizations.name', $arrFilterFields['organization']);
		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0 && !($doGroupBy==true && $groupByCategory=='specialty'))
			$this->db->where_in('specialties.specialty', $arrFilterFields['specialty']);
		if($doCount){
			/*
			$this->db->distinct();
			$count=$this->db->count_all_results('kols');
			*/
			$this->db->select('COUNT(DISTINCT kols.id) AS count');
			$this->db->where('kols.status',COMPLETED);
			$arrKolDetailsResult=$this->db->get('kols');
			$resultRow=$arrKolDetailsResult->row();
			$count=$resultRow->count;
			//echo $this->db->last_query();
			return $count;
		}
		else
		{
			if($doGroupBy){
				if($groupByCategory=='country'){
					$this->db->select('COUNT(DISTINCT kols.id) as count');
					$this->db->group_by('country_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='state'){
					$this->db->select('COUNT(DISTINCT kols.id) as count');
					$this->db->group_by('state_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='specialty'){
						$this->db->select('COUNT(DISTINCT kols.id) as count');
						$this->db->group_by('specialty');
						//$this->db->where('specialties.specialty IS NOT NULL');
				}
				if($groupByCategory=='organization'){
						$this->db->select('COUNT(DISTINCT kols.id) as count');
						$this->db->group_by('organizations.id');
						//$this->db->where('name IS NOT NULL');
				}
				if($groupByCategory=='education'){
						$this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name');
						$this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
						$this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
						$this->db->where('kol_educations.type','education');
						$this->db->where('institutions.name IS NOT NULL');
						$this->db->group_by('kol_educations.institute_id');
				}
				if($groupByCategory=='event'){
						$this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name');
						$this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
						$this->db->join('events', 'kol_events.event_id = events.id', 'left');
						$this->db->where('events.name IS NOT NULL');
						$this->db->group_by('kol_events.event_id');
				}
				if($groupByCategory=='list'){
						$this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(kols.id) AS count');
						$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
						$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
						$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
						$this->db->where('list_categories.client_id',$client_id);
						$where="(list_categories.user_id=$user_id OR list_categories.is_public=1)";
						$this->db->where($where);
						$this->db->group_by('list_kols.list_name_id');
				}
				$this->db->order_by('count','desc');
			}
			else{
				//$this->db->limit($limit, $startFrom);
			}
			$this->db->where('kols.status',COMPLETED);
			$arrKolDetailsResult	=	$this->db->get('kols');
			foreach($arrKolDetailsResult->result_array() as $row){
				 $prev_lat = end($lat);
		    	 $prev_lng = end($lng);
		    	 $latvalue = $row['Latitude'];
		    	 $longvalue = $row['Longitude'];
		    	 if(($row['Latitude'] == $prev_lat) && ($row['Longitude'] == $prev_lng)) {
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$row['Latitude']=$row['Latitude']+ $random_num_lat;
					$row['Longitude']=$row['Longitude'] + $random_num_lng;
		    	 }else{
		    	 	$row['Latitude']=$row['Latitude'];
					$row['Longitude']=$row['Longitude'];
		    	 }
		   		$lat[] = $latvalue;
		   		$lng[] = $longvalue; 
				$arrKols[]=$row;
			}
		//echo $this->db->last_query();		
			return $arrKols;
		}
	}
	
	function getOrganizationDetails($orgName){
		$arrDetail = array();
		$this->db->select('organizations.id,organizations.name,cities.city,countries.country,regions.region,cities.Longitude,cities.Latitude,organizations.postal_code,organizations.address');
		$this->db->join('countries','countries.countryId = organizations.country_id','left');
		$this->db->join('regions','regions.regionId = organizations.state_id','left');
		$this->db->join('cities','cities.cityId = organizations.city_id','left');
		$this->db->where('organizations.status',COMPLETED);
		//$this->db->where('organizations.name',$orgName);
		
		$arrDetails = $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrDetails->result_array() as $row){
			$arrDetail[] = $row;
		}
		return $arrDetail;
	}
	function getsubOrgDetais($orgId){
		$arrDetail = array();
		$this->db->select('organizations.id,organizations.name,cities.city,countries.country,regions.region,cities.Longitude,cities.Latitude,organizations.postal_code,organizations.address');
		$this->db->join('affiliates_partnerships','affiliates_partnerships.sub_org_id= organizations.id','left');
		$this->db->join('countries','countries.countryId = affiliates_partnerships.country_id','left');
		$this->db->join('regions','regions.regionId = affiliates_partnerships.state_id','left');
		$this->db->join('cities','cities.cityId = affiliates_partnerships.city_id','left');
		$this->db->where('organizations.status',COMPLETED);
		$this->db->where('affiliates_partnerships.org_id',$orgId);
		$arrDetails = $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrDetails->result_array() as $row){
			$arrDetail[] = $row;
		}
		
		
		return $arrDetail;
	}
	
	
	
	/**
	 * Returns the Co-Authored Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */	
	function getCoAuthoredKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		/*$arrKols=array();
		$this->db->select("pub2.kol_id, COUNT(pub2.kol_id) as count");
		$this->db->join('kol_publications as pub2','kol_publications.pub_id=pub2.pub_id','left');
		$this->db->join('kols','pub2.kol_id = kols.id','left');
		//$where="kol_publications.kol_id='$arrKolIds' AND pub2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_publications.kol_id',$arrKolIds);
		$this->db->where('pub2.kol_id !=',$arrKolIds);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('pub2.is_deleted',0);
		$this->db->where('pub2.is_verified',1);
		$this->db->where('kols.status',COMPLETED);
				
		$this->db->group_by('pub2.kol_id');
		$results=$this->db->get('kol_publications');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kol_publications.kol_id as parent_kol,pub2.kol_id, COUNT(pub2.kol_id) as count");
		$this->db->join('kol_publications as pub2','kol_publications.pub_id=pub2.pub_id','left');
		$this->db->join('kols as kols1','kol_publications.kol_id = kols1.id','left');
		$this->db->join('kols as kols2','pub2.kol_id = kols2.id','left');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		$this->db->where('kol_publications.kol_id != pub2.kol_id');
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($arrKolIds != null)	
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);

		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
			$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
		}
		$this->db->group_by('kol_publications.kol_id,pub2.kol_id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols2.id', 'left');
			$this->db->join('kols_client_visibility KCV2', 'KCV2.kol_id = kols1.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		
		$results=$this->db->get('kol_publications');
		//echo $this->db->last_query();exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	/**
	 * Returns the Co-Trialled Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	3.6
	 * @return Array
	 * @created 20-12-2011
	 */
	function getCoTrialledKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		/*$arrKols=array();
		$this->db->select("trial2.kol_id, COUNT(DISTINCT trial2.kol_id) as count");
		$this->db->join('kol_clinical_trials as trial2','kol_clinical_trials.cts_id=trial2.cts_id','inner');
		$this->db->join('kols','trial2.kol_id = kols.id','left');
		$this->db->where('kol_clinical_trials.kol_id',$arrKolIds);
		$this->db->where('trial2.kol_id !=',$arrKolIds);
		$this->db->where('kols.status',COMPLETED);
				
		$this->db->group_by('trial2.kol_id');
		$results=$this->db->get('kol_clinical_trials');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kol_clinical_trials.kol_id as parent_kol,trial2.kol_id, COUNT(trial2.kol_id) as count");
		$this->db->join('kol_clinical_trials as trial2','kol_clinical_trials.cts_id=trial2.cts_id','inner');
		$this->db->where('kol_clinical_trials.kol_id != trial2.kol_id');
		$this->db->join('kols as kols1','kol_clinical_trials.kol_id = kols1.id','left');
		$this->db->join('kols as kols2','trial2.kol_id = kols2.id','left');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		if($arrKolIds != null)	
			$this->db->where_in('kol_clinical_trials.kol_id',$arrKolIds);
		
		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['kol_id']!=''){
			$this->db->where('kols1.kol_id',$arrFilterFields['kol_id']);
			$this->db->where('kols2.kol_id',$arrFilterFields['kol_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
			$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
		}	
		$this->db->group_by('kol_clinical_trials.kol_id,trial2.kol_id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols2.id', 'left');
			$this->db->join('kols_client_visibility KCV2', 'KCV2.kol_id = kols1.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		
		$results=$this->db->get('kol_clinical_trials');
		//echo $this->db->last_query(); exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	/**
	 * Returns the Co-Organized Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	3.6
	 * @return Array
	 * @created 20-12-2011
	 */
	function getCoOrganizedKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		/*$arrKols=array();
		$this->db->select("k2.id as kol_id, COUNT(DISTINCT k2.id) as count");
		$this->db->join('kols as k2','kols.org_id=k2.org_id','inner');
		$this->db->where('kols.id',$arrKolIds);
		$this->db->where('k2.id !=',$arrKolIds);
		$this->db->where('kols.status',COMPLETED);
		$this->db->where('k2.status',COMPLETED);
		$this->db->where('kols.org_id !=','');
		$this->db->group_by('k2.id');
		$results=$this->db->get('kols');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kols1.id as parent_kol,kols2.id as kol_id, COUNT(kols2.id) as count");
		$this->db->join('kols as kols2','kols1.org_id=kols2.org_id','inner');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		$this->db->where('kols1.id != kols2.id');
		if($arrKolIds != null)	
			$this->db->where_in('kols1.id',$arrKolIds);

		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
			$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
		}
		$this->db->group_by('kols1.id,kols2.id');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols1.id', 'left');
			$this->db->join('kols_client_visibility as KCV2', 'KCV2.kol_id = kols2.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		$results=$this->db->get('kols as kols1');
		//echo $this->db->last_query();exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	/**
	 * Returns the Co-Educated Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	3.6
	 * @return Array
	 * @created 20-12-2011
	 */
	function getCoEducatedKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		/*$arrKols=array();
		$this->db->select("edu2.kol_id, COUNT(DISTINCT edu2.kol_id) as count");
		$this->db->join('kol_educations as edu2','kol_educations.institute_id=edu2.institute_id','inner');
		$this->db->join('kols','edu2.kol_id = kols.id','left');
		$this->db->where('kol_educations.kol_id',$arrKolIds);
		$this->db->where('edu2.kol_id !=',$arrKolIds);
		$this->db->where('edu2.institute_id !=',0);
		$this->db->where('kol_educations.type','education');
		$this->db->where('edu2.type','education');
		$this->db->where('kols.status',COMPLETED);		
		$this->db->group_by('edu2.kol_id');
		$results=$this->db->get('kol_educations');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kol_educations.kol_id as parent_kol,edu2.kol_id, COUNT(edu2.kol_id) as count");
		$this->db->join('kol_educations as edu2','kol_educations.institute_id=edu2.institute_id','inner');
		$this->db->join('kols as kols1','kol_educations.kol_id = kols1.id','left');
		$this->db->join('kols as kols2','edu2.kol_id = kols2.id','left');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		$this->db->where('kol_educations.kol_id != edu2.kol_id');
		$this->db->where('kol_educations.type','education');
		$this->db->where('edu2.type','education');
		
		if($arrKolIds != null)	
			$this->db->where_in('kol_educations.kol_id',$arrKolIds);

		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
			$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
		}
		$this->db->group_by('kol_educations.kol_id,edu2.kol_id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols2.id', 'left');
			$this->db->join('kols_client_visibility KCV2', 'KCV2.kol_id = kols1.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		
		$results=$this->db->get('kol_educations');
		//echo $this->db->last_query();exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	/**
	 * Returns the Co-Evented Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function getCoEventedKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		$arrKols=array();
		/*$this->db->select("e2.kol_id, COUNT(DISTINCT e2.event_id) as count");
		$this->db->join('kol_events as e2','kol_events.event_id=e2.event_id','left');
		$this->db->join('kols','e2.kol_id = kols.id','left');
		//$where="kol_events.kol_id='$arrKolIds' AND e2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_events.kol_id',$arrKolIds);
		$this->db->where('e2.kol_id !=',$arrKolIds);
		$this->db->where('kols.status',COMPLETED);
				
		$this->db->group_by('e2.kol_id');
		$results=$this->db->get('kol_events');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kol_events.kol_id as parent_kol,e2.kol_id, COUNT(DISTINCT e2.event_id) as count");
		$this->db->join('kol_events as e2','kol_events.event_id=e2.event_id','left');
		$this->db->join('kols as kols1','kol_events.kol_id = kols1.id','left');
		$this->db->join('kols as kols2','e2.kol_id = kols2.id','left');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		$this->db->where('kol_events.kol_id != e2.kol_id');
		if($arrKolIds != null)	
			$this->db->where_in('kol_events.kol_id',$arrKolIds);

		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		
		
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		    
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
				$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
				$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
			}
		$this->db->group_by('kol_events.kol_id,e2.kol_id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols2.id', 'left');
			$this->db->join('kols_client_visibility KCV2', 'KCV2.kol_id = kols1.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		
		$results=$this->db->get('kol_events');
		
		//echo $this->db->last_query();exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	
	/**
	 * Returns the Co-Affiliated Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function getCoAffiliatedKols($arrKolIds=null,$arrFilterFields){
		//Old Querry
		/*$arrKols=array();
		$this->db->select("m2.kol_id, COUNT(DISTINCT m2.institute_id) as count");
		$this->db->join('kol_memberships as m2','kol_memberships.institute_id=m2.institute_id','left');
		$this->db->join('kols','m2.kol_id = kols.id','left');
		//$where="kol_memberships.kol_id='$arrKolIds' AND m2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_memberships.kol_id',$arrKolIds);
		$this->db->where('m2.kol_id !=',$arrKolIds);
		$this->db->where('kol_memberships.type',"university");
		$this->db->where('m2.type',"university");
		$this->db->where('kols.status',COMPLETED);
				
		$this->db->group_by('m2.kol_id');
		$results=$this->db->get('kol_memberships');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;*/
				
		$arrKols=array();
		$this->db->select("kol_memberships.kol_id as parent_kol,m2.kol_id, COUNT(m2.kol_id) as count");
		$this->db->join('kol_memberships as m2','kol_memberships.institute_id=m2.institute_id','left');
		$this->db->join('kols as kols1','kol_memberships.kol_id = kols1.id','left');
		$this->db->join('kols as kols2','m2.kol_id = kols2.id','left');
		//$this->db->where('kols1.status',COMPLETED);
		//$this->db->where('kols2.status',COMPLETED);
		$this->db->where('kol_memberships.kol_id != m2.kol_id');
		$this->db->where('kol_memberships.type',"university");
		$this->db->where('m2.type',"university");
		if($arrKolIds != null)	
			$this->db->where_in('kol_memberships.kol_id',$arrKolIds);

		if($arrFilterFields!=null && $arrFilterFields['specialty']!='' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty'])>0) {
			$this->db->join('specialties as spec1', 'spec1.id = kols1.specialty', 'left');
			$this->db->where_in('spec1.id', $arrFilterFields['specialty']);
			$this->db->join('specialties as spec2', 'spec2.id = kols2.specialty', 'left');
			$this->db->where_in('spec2.id', $arrFilterFields['specialty']);
		}
		
		if(($arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0) || ($arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0)){
		    $this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
		    $this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
		}
		
		if($arrFilterFields!=null && $arrFilterFields['country']!='' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country'])>0){
			$this->db->where_in('c1.countryId', $arrFilterFields['country']);
			$this->db->where_in('c2.countryId', $arrFilterFields['country']);
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['state']!='' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state'])>0){
			//$this->db->join('regions as r1', 'r1.regionID = kols1.state_id', 'left');
			//$this->db->where_in('r1.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols1.state_id', $arrFilterFields['state']);
			//$this->db->join('regions as r2', 'r2.regionID = kols2.state_id', 'left');
			//$this->db->where_in('r2.regionID', $arrFilterFields['state']);
			$this->db->where_in('kols2.state_id', $arrFilterFields['state']);
		}
		if($arrFilterFields!=null && $arrFilterFields['list_id']!=null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0){
			$this->db->distinct();
			$this->db->join('list_kols as lk1','lk1.kol_id=kols1.id','left');
			//$this->db->join('list_names as ln1','lk1.list_name_id=ln1.id','left');
			//$this->db->where_in('ln1.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk1.list_name_id',$arrFilterFields['list_id']);
			
			$this->db->join('list_kols as lk2','lk2.kol_id=kols2.id','left');
			//$this->db->join('list_names as ln2','lk2.list_name_id=ln2.id','left');
			//$this->db->where_in('ln2.id',$arrFilterFields['list_id']);
			$this->db->where_in('lk2.list_name_id',$arrFilterFields['list_id']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
// 			$this->db->where('kols1.profile_type',$arrFilterFields['profile_type']);
// 			$this->db->where('kols2.profile_type',$arrFilterFields['profile_type']);
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols1.imported_as = 2 or kols1.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols1.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    }
		    if($arrFilterFields['profile_type'] == DISCOVERY){
		        $this->db->where('(kols2.imported_as = 2 or kols2.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols2.profile_type', $arrFilterFields['profile_type']);
		        $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		    }
		}else{
		    $this->db->where('(kols1.imported_as IS NULL or kols1.imported_as = 2 or kols1.imported_as = 0 or kols1.imported_as = 3)', null, false);
		    $this->db->where('(kols2.imported_as IS NULL or kols2.imported_as = 2 or kols2.imported_as = 0 or kols2.imported_as = 3)', null, false);
		}
		$this->db->where('(kols1.deleted_by is null or kols1.deleted_by=0)','',false);
		$this->db->where('(kols2.deleted_by is null or kols2.deleted_by=0)','',false);
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('kols1.id',$arrFilterFields['viewType']);
			$this->db->where_in('kols2.id',$arrFilterFields['viewType']);
		}
		$this->db->group_by('kol_memberships.kol_id,m2.kol_id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility as KCV1', 'KCV1.kol_id = kols2.id', 'left');
			$this->db->join('kols_client_visibility KCV2', 'KCV2.kol_id = kols1.id', 'left');
			$this->db->where('KCV1.client_id', $client_id);
			$this->db->where('KCV2.client_id', $client_id);
		}
		
		$results=$this->db->get('kol_memberships');
		//echo $this->db->last_query();exit;
		foreach($results->result_array() as $row){
			$arrKols['kol_'.$row['parent_kol']][]=$row['kol_id'];
			$arrCount['kol_'.$row['parent_kol']][$row['kol_id']]=$row['count'];
		}
		$arrData = array();
		$arrData['connections'] = $arrKols;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	function getSurveyNomineesToRespondentConnnecionsMap($surveyId, $filterData){
		$arrResults = array();
		$isQuestionsJoind = false;
		$this->db->select("nom_kol_id,nominees.full_name AS nom_name,nom_address_id as nominee_id,resp_kol_id,respondents.full_name AS resp_name,resp_address_id as respondent_id,COUNT(resp_kol_id) AS num_noms,nom_kols.status as nom_status,resp_kols.status as resp_status");
		$this->db->join('additional_contacts as nominees','survey_answers.nom_address_id = nominees.id','left');
		$this->db->join('additional_contacts as respondents','survey_answers.resp_address_id = respondents.id','left');
		$this->db->join('kols as nom_kols','survey_answers.nom_kol_id = nom_kols.id','left');
		$this->db->join('kols as resp_kols','survey_answers.resp_kol_id = resp_kols.id','left');
		$this->db->where('nom_kols.status',COMPLETED);
		$this->db->where('resp_kols.status',COMPLETED);
		$this->db->where('survey_id',$filterData['survey_id']);
		if(isset($filterData['nomineeId']) && $filterData['nomineeId'] != ''){
			$this->db->where("(nominee_id = ".$filterData['nomineeId']." OR respondent_id = ".$filterData['nomineeId'].")");
		}
		
		//Nominee filters
		if($filterData!=null && $filterData['specialty']!='' && isset($filterData['specialty']) && sizeof($filterData['specialty'])>0){
			$this->db->join('specialties as nom_kols_spec','nom_kols.specialty = nom_kols_spec.id','left');
			$this->db->where_in('nom_kols_spec.id',$filterData['specialty']);
			$this->db->join('specialties as resp_kols_spec','nom_kols.specialty =resp_kols_spec.id','left');
			$this->db->where_in('resp_kols_spec.id',$filterData['specialty']);
		}
		if($filterData!=null && $filterData['state']!='' && isset($filterData['state']) && sizeof($filterData['state'])>0){
			$this->db->where_in('nom_kols.state_id',$filterData['state']);
			$this->db->where_in('resp_kols.state_id',$filterData['state']);
		}
		
		if(isset($filterData['country']) && $filterData['country'] != ''){
			$this->db->join('countries', 'countries.countryId = nom_kols.country_id', 'left');
			$this->db->where_in('countries.countryId',$filterData['country']);
			$this->db->where('survey_answers.country','countries.country');
		}
		if($arrFilterFields!=null && $arrFilterFields['region']!='' && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region'])>0){
			$this->db->join('countries as c1', 'c1.countryId = kols1.country_id', 'left');
			$this->db->where_in('c1.GlobalRegion', $arrFilterFields['region']);
			$this->db->join('countries as c2', 'c1.countryId = kols2.country_id', 'left');
			$this->db->where_in('c2.GlobalRegion', $arrFilterFields['region']);
		}
		if($arrFilterFields!=null && $arrFilterFields['profile_type']!=''){
			$this->db->where('nom_kols.profile_type',$arrFilterFields['profile_type']);
			$this->db->where('resp_kols.profile_type',$arrFilterFields['profile_type']);
		}
		if(isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0){
			$this->db->where_in('nom_kols.id',$arrFilterFields['viewType']);
			$this->db->where_in('resp_kols.id',$arrFilterFields['viewType']);
		}
		$this->db->group_by('nom_kol_id,resp_kol_id');
		$results = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
     			$data = array();
     			$data['kol_id'] = $row['resp_kol_id'];
     			$data['count'] = $row['num_noms'];
     			//if($data['kol_id'] == $filterData['nomineeId'])
     				//$data['kol_id'] = $row['nom_kol_id'];
     			if($row['nom_kol_id'] != 0){
     				$arrResults['kol_'.$data['kol_id']][]=$row['nom_kol_id'];
					$arrCount['kol_'.$data['kol_id']][$row['nom_kol_id']]=$data['count'];
					
					$arrResults['kol_'.$row['nom_kol_id']][]=$data['kol_id'];
					$arrCount['kol_'.$row['nom_kol_id']][$data['kol_id']]=$data['count'];
     			}
			
     		}
     	}
		$arrData = array();
		$arrData['connections'] = $arrResults;
		$arrData['counts'] = $arrCount;
		return $arrData;
	}
	
	
	function mergeConnectionCounts($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols,$arrSurveyKols){
		$arrKols=array();
		if(sizeof($arrPubKols) > 0){
			foreach($arrPubKols as $idString => $row){
				foreach($row as $key => $count){
					$arrKols[$idString][$key]=$count;
				}
			}
		}
		
		if(sizeof($arrEventKols) > 0){
			foreach($arrEventKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		
		if(sizeof($arrAffKols) > 0){
			foreach($arrAffKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		if(sizeof($arrOrgKols) > 0){
			foreach($arrOrgKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		if(sizeof($arrEduKols) > 0){
			foreach($arrEduKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		if(sizeof($arrTrialKols) > 0){
			foreach($arrTrialKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		
		if(sizeof($arrSurveyKols) > 0){
			foreach($arrSurveyKols as $idString => $row){
				foreach($row as $key => $count){
					if (array_key_exists($idString, $arrKols) && array_key_exists($key, $arrKols[$idString])) {
					   $arrKols[$idString][$key]=(int)$arrKols[$idString][$key]+(int)$count;
					} else{
						$arrKols[$idString][$key]=$count;
					}
				}
			}
		}
		
		return $arrKols;
	}
	
	function getKolCoAuthorsToAutorsConnections($kolId){
		$arrCoAutherInfluence=array();
		$this->db->select("pa1.pub_id, pa1.alias_id as parent_auth,pmda1.last_name,pmda1.initials,pmda1.fore_name,pa1.position, pa2.alias_id as alias_id2,pmda2.last_name as last_name2,pmda2.initials as initials2,pmda2.fore_name as fore_name2,pa2.position as position2, count(Distinct pa1.pub_id) as conn, publications.affiliation as aff");
		$this->db->join('publications_authors AS pa2','pa1.pub_id = pa2.pub_id','left');
		$this->db->join('kol_publications','pa1.pub_id = kol_publications.pub_id','left');
		$this->db->join('publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('pubmed_authors AS pmda1','pa1.alias_id=pmda1.id','left');
		$this->db->join('pubmed_authors AS pmda2','pa2.alias_id=pmda2.id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_verified',1);
		//$where="(pmda1.last_name='".$koAuthDetails['last_name']."' AND pmda1.initials='".$koAuthDetails['initials']."' AND pmda1.fore_name='".$koAuthDetails['fore_name']."') AND !(pmda2.last_name='".$koAuthDetails['last_name']."' AND pmda2.initials='".$koAuthDetails['initials']."' AND pmda2.fore_name='".$koAuthDetails['fore_name']."')";
		//$this->db->where($where);
		/*$this->db->where('pmda1.last_name',$koAuthDetails['last_name']);
		$this->db->where('pmda1.initials',$koAuthDetails['initials']);
		$this->db->where('pmda1.fore_name',$koAuthDetails['fore_name']);
		$this->db->where('pmda2.last_name !=',$koAuthDetails['last_name']);
		$this->db->where('pmda2.initials !=',$koAuthDetails['initials']);
		$this->db->where('pmda2.fore_name !=',$koAuthDetails['fore_name']);*/
		$this->db->where('pa1.alias_id !=  pa2.alias_id');
		$this->db->group_by('pa1.alias_id,pa2.alias_id');
		
		$results=$this->db->get('publications_authors as pa1');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrCoAutherInfluence[$row['parent_auth']][$row['alias_id2']]=$row;
		}
		return $arrCoAutherInfluence;
	}
	
}


 