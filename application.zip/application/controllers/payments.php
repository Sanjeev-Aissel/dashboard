<?php
/**
 * This is Controller file of 'Payments'
 * 
 * @author Ambarish
 * @since
 * @package application.controllers	
 * @created on  28-02-11
 */

class Payments extends Controller{
	private $loggedUserId	= null;
	
	//Controller
	function Payments(){
		parent::Controller();
		$this->load->model('payment');
		$this->load->model('common_helpers');
		$this->load->model('client_user');
		$this->load->model('kol');
		$this->load->model('specialty');
		$this->load->model('interaction');
		
		
		//Check for log in
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."/login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}
	
	function show_track(){
		$this->session->set_userdata('kolId', '-1');
		redirect('plannings/show_plans');
	}
	
	/**
	 * Display the 'add payment' view page
	 *  
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 */
	function add_payment($kolId=null){
		$data = array();
		// Initialize the Payment form
		$paymentDetails = array('id' 					=> 	'',
								'kol_name' 				=> 	'',
								'client_id'				=> 	'',
								'type'					=> 	'',
								'interaction_id'		=> 	'',
								'date'					=> 	'',
								'reason'				=>	'',
								'requested_by'			=>	'',
								'paid_by'				=>	'',
								'amount' 				=> 	'',
								'rate'	 				=> 	'',
								'duration'	 			=> 	'',
								'created_by'			=>	'',
								'created_on'			=>	'');
		$paymentDetails['msg'] = '';
		$paymentDetails['budget'] = '';
		$paymentDetails['arrTypesAndAmount']='';
		//Get all DropDown values for Payment
		$dropDownValues 			= 	$this->get_payment_dropdown_values();
		$data['arrPaymentTypes']	=	$dropDownValues['arrPaymentTypes'];
		$data['arrPaymentCurrencies']	=	$dropDownValues['arrPaymentCurrencies'];
		$data['arrInteractionIds']	=	$dropDownValues['arrInteractionIds'];
		$data['arrKol']				=	$dropDownValues['arrKol'];
		$data['arrPaymentPaidBy']	=	$dropDownValues['arrPaymentPaidBy'];
		$data['arrPaymentRequestBy']=	$dropDownValues['arrPaymentRequestBy'];
		//To Show the threshhold_rate and Budget in the Profile lavel only
		if($this->session->userdata('kolId') != '-1'){
			if($this->session->userdata('kolId') !==''){
				$threshholdLimit 	= array();
				$client_id 			= $this->session->userdata('client_id');
				//$threshholdLimit 	=  	$this->payment->getThreshholdValueByKolId($kolId);
				//$paymentDetails['threshhold_rate']	=	$threshholdLimit['threshhold_rate'];
				
				//$paymentLimit               = 	$this->payment->getSumOfPaymentByKolId($kolId,$client_id);
				//$paymentDetails['budget'] 	= 	$threshholdLimit['threshhold_rate'] - $paymentLimit;
			}
			$data['kolId']=$kolId;
		}
		//End of profile level 
		$paymentDetails['arrTypesAndAmount'][0]['type']='';
		$paymentDetails['arrTypesAndAmount'][0]['indAmount']='';
		$data['arrPayment'] = $paymentDetails;
		if($kolId!=NULL){
			$arrKols = $this->payment->getAllKolsName1();
			$data['kol_name'] = $arrKols[$kolId];
		}
		$this->load->view('payments/add_payment',$data);
		
//		$data['contentPage'] 	=	'payments/add_payment';
//		$this->load->view('layouts/client_view',$data);
	}
	
	/**
	 * Saves the Payment Detail to DB 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 */
	function save_payment(){
		$arrKols = $this->payment->getAllKolsName1();
	
		if(isset($_POST) && count($_POST)>0){
			$date	= $this->input->post('date');
			// Getting the POST details of Payment
			$paymentDetails = array(
									'client_id'				=> 	$this->session->userdata('client_id'),
									'date'					=> 	(empty($date)?'':app_date_to_sql_date($date)),
									'reason'				=>	ucwords(trim($this->input->post('reason'))),
									//'amount'				=> 	trim($this->input->post('amount')),
								//	'rate'	 				=> 	trim($this->input->post('rate')),
									//'duration'	 			=> 	trim($this->input->post('duration')),
									'requested_by'           => 	trim($this->input->post('requested_by')),
									'paid_by'               => 	trim($this->input->post('paid_by')),
									'created_by'			=>	$this->loggedUserId,
									'created_on'			=>	date('Y-m-d H:i:s'));
				
			$kolName = 	trim($this->input->post('kol_name'));
			$kolId = $this->input->post('kol_id');
			if(!is_numeric($kolId)){
			    $kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
			}
			$paymentDetails['kol_id'] = $kolId;
			if($paymentDetails['kol_id']==''){
				$paymentDetails['kol_id'] = array_search($kolName,$arrKols);
			}
			
			if($paymentDetails['kol_id']==''){
				//$kolSaved=false;
				$kolSaved='';
				$checkCamma = strpos($kolName,',');
				$kolDetail=array();
				if($checkCamma!=''){
					
					$kolNameExplodeBy = explode(',',$kolName);
					//pr($kolNameExplodeBy);
					if(sizeOf($kolNameExplodeBy)==1){
							$kolDetail['first_name'] = $kolNameExplodeBy[0];
						}
					if(sizeOf($kolNameExplodeBy)==2){
							$kolDetail['last_name'] = $kolNameExplodeBy[0];
							$kolDetail['first_name'] = $kolNameExplodeBy[1];
						}
					if(sizeOf($kolNameExplodeBy)==3){
						$kolDetail['last_name'] = $kolNameExplodeBy[0];
						$kolDetail['first_name'] = $kolNameExplodeBy[1];
						$kolDetail['middle_name'] = $kolNameExplodeBy[2];
					}
					
					$checkKolname = $kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
					$kolId = array_search($checkKolname,$arrKols);
					if($kolId==''){
						$kolDetail['created_by'] = $this->session->userdata('user_id');
						$kolDetail['status'] = PRENEW;
						$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
					}else{
						$paymentDetails['kol_id'] =$kolId;
					}
					$kolSaved = 'Saved';
					
				}
				if($kolSaved!='Saved'){
					$splitByspace = explode(" ",$kolName);
				
					if(sizeOf($splitByspace)==2){
							
						$kolDetail['first_name'] = $splitByspace[0];
							$kolDetail['last_name'] = $splitByspace[1];
					}
					
					if(sizeOf($splitByspace)==3){
					
						$kolDetail['first_name'] = $splitByspace[0];
						$kolDetail['middle_name'] = $splitByspace[1];
						$kolDetail['last_name'] = $splitByspace[2];
						
					}
					
					if(sizeOf($splitByspace)>3){
						$kolDetail['first_name'] = $splitByspace[0];
						$kolDetail['middle_name'] = $splitByspace[1];
						$kolDetail['last_name'] = $splitByspace[2]." ". $splitByspace[3];
					
					}
					$kolDetail['created_by'] = $this->session->userdata('user_id');
					$kolDetail['status'] = PRENEW;
					$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
				}
				
				
				//echo $this->db->last_query();
			}
			$arrResult = array();
			$noOfFields = $this->input->post('no_of_fileds');
			$arrTypesAndAmounts['currency'] = $this->input->post('currency');
			$arrTypesAndAmounts['amount'] = $this->input->post('amount');
			$arrTypesAndAmounts['type'] = $this->input->post('type');
			$arrTypes[]=$arrTypesAndAmounts;
		
			
				for($i=2;$i<=$noOfFields;$i++){
					 if($this->input->post('amount'.$i)!=''){
					$arrTypesAndAmounts1['currency'] = $this->input->post('currency'.$i);
					$arrTypesAndAmounts1['amount'] = $this->input->post('amount'.$i);
					$arrTypesAndAmounts1['type'] = $this->input->post('type'.$i);
					$arrTypes[]=$arrTypesAndAmounts1;
					 }
				}
			
			foreach($arrTypes as $row){
				$arrAmounts[]=$row['amount'];
			}
			$paymentDetails['amount'] = array_sum($arrAmounts);
			//	pr($arr);
			//Get all DropDown values for Payment
			$dropDownValues 			= 	$this->get_payment_dropdown_values();
		//	$data['arrPaymentTypes']	=	$dropDownValues['arrPaymentTypes'];
		//	$data['arrInteractionIds']	=	$dropDownValues['arrInteractionIds'];
		//	$data['arrKol']				=	$dropDownValues['arrKol'];
			if($lastInsertId = $this->payment->savePayment($paymentDetails)){
				$this->payment->saveTypeAndAmount($lastInsertId,$arrTypes);
				$this->update->insertUpdateEntry(PAYMENT_ADD,$lastInsertId, MODULE_PAYMENT, $paymentDetails['kol_id']);
				
				
				$data['saved'] = true;
				$data['arrPayementDetails'] = $paymentDetails;
				$arrLogDetails = array(
						'module' => 'payments',
						'type' => LOG_ADD,
						'description' => 'New Payment',
						'status' => 'success',
						'transaction_id' => $lastInsertId,
						'transaction_table_id' => 30,
						'transaction_name' => "New Payment",
						'form_data' => json_encode($data),
						'parent_object_id' => $paymentDetails['kol_id']
				);
				
				$this->config->set_item('log_details', $arrLogDetails);
			}else{
				$data['saved'] = false;
				//$data['arrPayment'] = $paymentDetails;
				//$this->load->view('payments/add_payment',$data);
			}
			echo json_encode($data);
		}
	}
	
	/**
	* Display the 'list payments' view page
	* 
	* @author Ambarish
	* @since 1.4.5
	* @Created-on 28-02-11
	*/
	function list_payments($subContentPage=''){
//		$kolId	= $this->session->userdata('kolId');
 //  	 	if($kolId== '-1' || empty($kolId)){
		if(!empty($subContentPage)){
			$data['contentPage'] 	=	'payments/list_payments';
			$data['subContentPage']	=	$subContentPage;
			$this->load->view('layouts/client_view',$data);
   	 	}else{
   	 		$this->load->view('payments/list_payments',$data);
   	 	}
   	 	$arrLogDetails = array(
   	 			'module' => 'payments',
   	 			'type' => LOG_LIST,
   	 			'description' => 'List Payments',
   	 			'status' => 'success',
   	 			'transaction_id' => $interactionId,
   	 			'transaction_table_id' => 30,
   	 			'transaction_name' => "List Payments",
   	 			'form_data' => ''
   	 	);
   	 	$this->config->set_item('log_details', $arrLogDetails);
   	 	
   	 	log_user_activity($arrLogDetails, true);
	}
	
	/* 
	* Editing 'Payment' detail
	*  
	* @author Ambarish
	* @since 1.4.5
	* @Created-on 01-03-11
	*/
	function edit_payment($kolId=null, $paymentId = null){
		$data				=	array();
		if($paymentId == null){
		$this->session->set_flashdata('errorMessage', 'Invalid Payment Id');
		redirect('payments/list_payments');
		}
  	 	
    	// Getting the Payment details
      	$arrPaymentDetail = $this->payment->getPaymentById($paymentId);
		
      	$arrPaymentDetail['arrTypesAndAmount'] = $this->payment->getPayementTypeAndAmount($paymentId);
		$no_of_fields = count($arrPaymentDetail['arrTypesAndAmount']);
		$client_id = $this->session->userdata('client_id');
  	 	
		//Get all DropDown values for Payment
		$dropDownValues 			= 	$this->get_payment_dropdown_values();
		$data['arrPaymentTypes']	=	$dropDownValues['arrPaymentTypes'];
		$data['arrInteractionIds']	=	$dropDownValues['arrInteractionIds'];
		$data['arrPaymentCurrencies']	=	$dropDownValues['arrPaymentCurrencies'];
		$data['arrKol']				=	$dropDownValues['arrKol'];
		$data['arrPaymentPaidBy']	=	$dropDownValues['arrPaymentPaidBy'];
		$data['arrPaymentRequestBy']=	$dropDownValues['arrPaymentRequestBy'];
	//	$threshholdLimit 			=  	$arrPaymentDetail['threshhold_rate'];
	//	$paymentLimit               = 	$this->payment->getSumOfPaymentByKolId($arrPaymentDetail['kol_id'],$client_id);
	//	$arrPaymentDetail['budget'] = 	$threshholdLimit - $paymentLimit;
	//	$arrPaymentDetail['msg'] = 	'';
		$arrUserDetails				=	$this->client_user->editUser($arrPaymentDetail['created_by']);
		$arrPaymentDetail['user_name']=$arrUserDetails['user_name'];

		//$arrPaymentDetail['duration']=substr($arrPaymentDetail['duration'],0,5);
  	 	$data['arrPayment']	=	$arrPaymentDetail;
		$data['noOfFields'] =	$no_of_fields;
  	 	// 	$this->load->view('payments/add_payment',$data);
		if($kolId!=null){
			$data['kol_name'] = '';
		}
  	 //	$data['contentPage'] 	=	'payments/add_payment';
		$this->load->view('payments/add_payment',$data);
	}
	
	/**
	 * Updates the Payment Detail to DB 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
	 * 
	 */
	function update_payment($paymentId){
		$arrKols = $this->payment->getAllKolsName1();
		if(isset($_POST) && count($_POST)>0){
			$date	= $this->input->post('date');
			// Getting the POST details of Payment
		$paymentDetails = array(	
									'kol_id' 				=> 	$this->input->post('kol_name'),
									'client_id'				=> 	$this->session->userdata('client_id'),
									'date'					=> 	(empty($date)?'':app_date_to_sql_date($date)),
									'reason'				=>	ucwords(trim($this->input->post('reason'))),
									'requested_by'           => 	trim($this->input->post('requested_by')),
									'paid_by'               => 	trim($this->input->post('paid_by')),
									'modified_by'			=>	$this->loggedUserId,
									'modified_on'			=>	date('Y-m-d H:i:s'));
			//pr($paymentDetails);
				
			// Create an array to return the result
			$arrResult = array();
		
			//$paymentDetails['kol_id'] = array_search($paymentDetails['kol_id'],$arrKols);
			
			$kolName = 	trim($this->input->post('kol_name'));
			
			$paymentDetails['kol_id'] = trim($this->input->post('kol_id'));
			if($paymentDetails['kol_id']==''){
				$paymentDetails['kol_id'] = array_search($kolName,$arrKols);
			}
			
			if($paymentDetails['kol_id']==''){
				//$kolSaved=false;
				$kolSaved='';
				$checkCamma = strpos($kolName,',');
				$kolDetail=array();
				if($checkCamma!=''){
					
					$kolNameExplodeBy = explode(',',$kolName);
					//pr($kolNameExplodeBy);
					if(sizeOf($kolNameExplodeBy)==1){
							$kolDetail['first_name'] = $kolNameExplodeBy[0];
						}
					if(sizeOf($kolNameExplodeBy)==2){
							$kolDetail['last_name'] = $kolNameExplodeBy[0];
							$kolDetail['first_name'] = $kolNameExplodeBy[1];
						}
					if(sizeOf($kolNameExplodeBy)==3){
						$kolDetail['last_name'] = $kolNameExplodeBy[0];
						$kolDetail['first_name'] = $kolNameExplodeBy[1];
						$kolDetail['middle_name'] = $kolNameExplodeBy[2];
					}
					
					$checkKolname = $kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
					$kolId = array_search($checkKolname,$arrKols);
					if($kolId==''){
						$kolDetail['created_by'] = $this->session->userdata('user_id');
						$kolDetail['status'] = PRENEW;
						$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
					}else{
						$paymentDetails['kol_id'] =$kolId;
					}
					$kolSaved = 'Saved';
					
				}
				if($kolSaved!='Saved'){
					$splitByspace = explode(" ",$kolName);
				
					if(sizeOf($splitByspace)==2){
							
						$kolDetail['first_name'] = $splitByspace[0];
							$kolDetail['last_name'] = $splitByspace[1];
					}
					
					if(sizeOf($splitByspace)==3){
					
						$kolDetail['first_name'] = $splitByspace[0];
						$kolDetail['middle_name'] = $splitByspace[1];
						$kolDetail['last_name'] = $splitByspace[2];
						
					}
					
					if(sizeOf($splitByspace)>3){
						$kolDetail['first_name'] = $splitByspace[0];
						$kolDetail['middle_name'] = $splitByspace[1];
						$kolDetail['last_name'] = $splitByspace[2]." ". $splitByspace[3];
					
					}
					$kolDetail['created_by'] = $this->session->userdata('user_id');
					$kolDetail['status'] = PRENEW;
					$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
				}
				
				
				//echo $this->db->last_query();
			}
			
			
			
			
			$arrResult = array();
			$noOfFields = $this->input->post('no_of_fileds');
			$arrTypesAndAmounts['currency'] = $this->input->post('currency');
			$arrTypesAndAmounts['amount'] = $this->input->post('amount');
			$arrTypesAndAmounts['type'] = $this->input->post('type');
			$arrTypes[]=$arrTypesAndAmounts;
			
				for($i=2;$i<=$noOfFields;$i++){
					 if($this->input->post('amount'.$i)!=''){
					 	$arrTypesAndAmounts1['currency'] = $this->input->post('currency'.$i);
						$arrTypesAndAmounts1['amount'] = $this->input->post('amount'.$i);
						$arrTypesAndAmounts1['type'] = $this->input->post('type'.$i);
						$arrTypes[]=$arrTypesAndAmounts1;
				 	}
				}
			foreach($arrTypes as $row){
				$arrAmounts[]=$row['amount'];
			}
			$paymentDetails['amount'] = array_sum($arrAmounts);
			//Get all DropDown values for Payment
			$dropDownValues 			= 	$this->get_payment_dropdown_values();
			$data['arrPaymentTypes']	=	$dropDownValues['arrPaymentTypes'];
			$data['arrInteractionIds']	=	$dropDownValues['arrInteractionIds'];
			$data['arrKol']				=	$dropDownValues['arrKol'];
			$data['arrPaymentPaidBy']	=	$dropDownValues['arrPaymentPaidBy'];
			$data['arrPaymentRequestBy']=	$dropDownValues['arrPaymentRequestBy'];
			$paymentDetails['id']=$paymentId;
				if($this->payment->updatePayment($paymentDetails)){
					$this->payment->updateTypeAndAmount($paymentId,$arrTypes);
					$this->update->insertUpdateEntry(PAYMENT_UPDATE,$paymentDetails['id'], MODULE_PAYMENT, $paymentDetails['kol_id']);
					$data1['saved'] = true;
					$arrLogDetails = array(
							'module' => 'payments',
							'type' => LOG_UPDATE,
							'description' => 'Update Payment',
							'status' => 'success',
							'transaction_id' => $paymentId,
							'transaction_table_id' => PAYMENTS,
							'transaction_name' => "Update Payment",
							'form_data' => json_encode($paymentDetails),
							'parent_object_id' => $paymentDetails['kol_id']
					);
					
					$this->config->set_item('log_details', $arrLogDetails);
					//log_user_activity(null, true);
				}else{
					$data1['saved'] = false;
				}
				echo json_encode($data1);
		}
	}
	
	/**
	 * Display the 'payment' view page
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
	 * 
	 * @param unknown_type $paymentId
	 * @return unknown_type
	 */
	function view_payment($paymentId = null){
		$data				=	array();
		if($paymentId == null){
		$this->session->set_flashdata('errorMessage', 'Invalid Payment Id');
		redirect('payments/list_payments');
		}
  	 	
    	// Getting the Payment details
      	$arrPaymentDetail = $this->payment->getPaymentById($paymentId);
		
  	 	$data['arrPayment']	=	$arrPaymentDetail;
  	 //	$this->load->view('payments/view_payment',$data);
  	 	
  	 	$data['contentPage'] 	=	'payments/view_payment';
		$this->load->view('layouts/client_view',$data);
	}
	
	/**
	 * Delete the Payment Detail of PaymentId
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 * 
	 * @param unknown_type $paymentId
	 * @return unknown_type
	 */
	function delete_payment($paymentId = null){
		$kol_details = $this->payment->getPaymentById($paymentId);
		$isDeleated = $this->payment->deletePaymentById($paymentId);
		//$this->update->insertUpdateEntry(PAYMENT_DELETE,$paymentId, MODULE_PAYMENT);
		$this->update->deleteUpdateEntry(PAYMENT_ADD, $paymentId, MODULE_PAYMENT);
		$this->update->deleteUpdateEntry(PAYMENT_UPDATE, $paymentId, MODULE_PAYMENT);
		$arrLogDetails = array(
				'module' => 'payments',
				'type' => LOG_DELETE,
				'description' => 'Delete Payment',
				'status' => 'success',
				'transaction_id' => $paymentId,
				'transaction_table_id' => 30,
				'transaction_name' => "Delete Payment",
				'form_data' => '',
				'parent_object_id' => $kol_details['kol_id']
		);
		$this->config->set_item('log_details', $arrLogDetails);
		 
		log_user_activity($arrLogDetails, true);
		echo $isDeleated;
	}
	
	/**
	 * To get the all Drop down values for Payment form
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 * 
	 * @return unknown_type
	 */
	function get_payment_dropdown_values(){
		$clientId	=$this->session->userdata('client_id');
		$userId		=$this->session->userdata('user_id');
		$data['arrPaymentPaidBy'] = $this->payment->getAllPaymentsPaidBy();
		$data['arrPaymentRequestBy'] = $this->payment->getAllPaymentsRequestedBy();
		//Get all Payment Types for the Drop down
		$arrPaymentTypes = $this->payment->getAllPaymentTypes();
		$data['arrPaymentTypes']	= $arrPaymentTypes;
		$arrPaymentCurrencies = $this->payment->arrPaymentCurrencies();
		$data['arrPaymentCurrencies']	= $arrPaymentCurrencies;
		//Get all Interaction-Id for the Drop down
		$arrInteractionIds = $this->payment->getAllInteractionIds($clientId,$userId);
		$data['arrInteractionIds']	= $arrInteractionIds;
		
		//Get all kols name and id for the Drop down
		$arrKol = $this->payment->getAllKolsName();
		$data['arrKol']	= $arrKol;
		
		return $data;
	}
	
	/**
	 * Display the 'add Threshhold' page
	 *  
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 */
	function add_threshhold(){
		$data = array();
		// Initialize the Payment form
		$threshholdDetails = array(	'id' 					=> 	'',
									'kol_id' 				=> 	'',
									'threshhold_rate'		=> 	'',
									'created_by'			=>	'',
									'created_on'			=>	'');
		$data['arrThreshhold'] = $threshholdDetails;
		//Get all kols name and id for the Drop down
		$arrKol = $this->payment->getAllKolsName();
		$data['arrKol']	= $arrKol;
		
	//	$data['contentPage'] 	=	'payments/add_threshhold';
	//	$this->load->view('layouts/client_view',$data);
		$this->load->view('payments/add_threshhold',$data);
	}
	
	/**
	 * Display the 'add Threshhold' page
	 *  
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 */
	function save_threshhold(){
		$data = array();
		// Initialize the Payment form
		$threshholdDetails = array(	'id' 					=> 	$this->input->post('id'),
									'kol_id' 				=> 	$this->input->post('kol_id'),
									'threshhold_rate'		=> 	$this->input->post('threshhold_rate'),
									'created_by'			=>	$this->loggedUserId,
									'created_on'			=>	date('Y-m-d H:i:s'));
		
		if($lastInsertId = $this->payment->saveThreshhold($threshholdDetails)){
			$this->update->insertUpdateEntry(PAYMENT_ADD,$lastInsertId, MODULE_PAYMENT, $threshholdDetails('client_id'));
			$data['saved'] = true;
		}else{
			$data['saved'] = false;
		}
		echo json_encode($data);
	}
	
	/**
	 * Updates the Threshhold Detail to DB 
	 *  
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 */
	function update_threshhold(){
		$data = array();
		// Initialize the Payment form
		$threshholdDetails = array(	'id' 					=> 	$this->input->post('id'),
									'kol_id' 				=> 	$this->input->post('kol_id'),
									'threshhold_rate'		=> 	$this->input->post('threshhold_rate'),
									'modified_by'			=>	$this->loggedUserId,
									'modified_on'			=>	date('Y-m-d H:i:s'));
		
		if($lastInsertId = $this->payment->updateThreshhold($threshholdDetails)){
			$data['saved'] = true;
		}else{
			$data['saved'] = false;
		}
		echo json_encode($data);
	}
	
	/**
	 * Returns the Threshhold value for the Kol_id passed
	 * 
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 08-03-11
	 * 
	 * @param unknown_type $kolId
	 * @return unknown_type
	 */
	function get_threshhold($kolId){
		$threshholdLimit = array();
		$threshholdLimit 			=  	$this->payment->getThreshholdValueByKolId($kolId);
		$arrReturnData['threshholdLimit']	= $threshholdLimit;
		
		$paymentLimit               = 	$this->payment->getSumOfPaymentByKolId($kolId,$this->session->userdata('client_id'));
		$arrReturnData['budget'] 	= 	$threshholdLimit['threshhold_rate'] - $paymentLimit;
		echo json_encode($arrReturnData);
	}
	
	/**
	 * Returns the Payment min and max year 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 08-03-11
	 * 
	 * @return arrYearRange
	 */
	function  get_payments_year_range(){
		$data = array();
		$kol_id = $this->session->userdata('kolId');
		$client_id = $this->session->userdata('client_id');
		
		$data['arrYearRange'] = $this->payment->getPaymentMinMaxYear($kol_id,$client_id);
		return $data;
	} 
	
	/**
	 * Prepares the JSON data for top 10 kols by interactions count chart
	 * @author 	Ramesh B
	 * @Created on: 09-03-11
	 * @since	1.5.1
	 * @return JSON
	 */
	function get_payments_by_year(){
		$clientId=$this->session->userdata('client_id');
		$fromYear=$this->input->post('from_year');
		$toYear=$this->input->post('to_year');
		$groupBy=($this->input->post('group_by')==null)? 0:$this->input->post('group_by');
		$arrKolIds=($this->input->post('kol_id')==null) ? 0:$this->input->post('kol_id');
		//echo $groupBy;
		
		$arrPayments=$this->payment->getPaymentsByParam($fromYear,$toYear,$clientId,$arrKolIds,0,0,$groupBy);
		$arrKolNames=array();
		$arrCounts=array();
		$i=20;
		foreach($arrPayments as $payment){
			if($i==0)
				break;
			$arrKolNames[]=$payment['year'];
			$arrCounts[]=(int)$payment['count'];
			$i--;
		}
		$data[]=$arrKolNames;
		$data[]=$arrCounts;
		echo json_encode($data);
	}
	
	/**
	 * Gets the Payments belogs to perticular client user with in the perticular date range. 
	 * and prepares a json data and returns.
	 * @author 	Ramesh B
	 * @Created on: 23-08-11
	 * @since	3.0
	 * @return JSON
	 */
	function list_payments_by_date_range($startDate='',$endDate='',$kolId=null){
		$page			= (int)$this->input->post('page'); // get the requested page 
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPayments	= array();
		$data			= array();
		$clientId		= $this->session->userdata('client_id');
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId			= 0;
		if($this->session->userdata('user_role_id')==ROLE_USER){
			$userId		= $this->session->userdata('user_id');
		}
		$arrPayments	= array();
		$toalAmount = 0;
		$dropDownValues 			= 	$this->get_payment_dropdown_values();
		$arrPaymentCurrencies	=	$dropDownValues['arrPaymentCurrencies'];
		//\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'
		if($kolId == null)
			$kolId = $this->input->post('kol_id');
		if($arrPaymentsResults=$this->payment->listPaymentDetails($clientId,$kolId,$userId,$startDate,$endDate)){
			foreach($arrPaymentsResults as $arrPaymentResult){
				$arrSplitPayments = $this->payment->getPayementTypeAndAmount($arrPaymentResult['id']);
				$totalPayments = sizeof($arrSplitPayments);
				if($totalPayments>1){
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'].' +';
				}else{
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'];
				}
				$arrSplitPayments = $this->payment->getPayementTypeAndAmount($arrPaymentResult['id']);
				$totalPayments = sizeof($arrSplitPayments);
				if($totalPayments>1){
						$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'].' +';
				}else{
						$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'];
				}
				$arrPayment['eAllowed'] = $this->common_helpers->isActionAllowed('payment', 'edit', $arrPaymentResult);
			    $arrPayment['dAllowed'] = $this->common_helpers->isActionAllowed('payment', 'delete', $arrPaymentResult);
				$arrPayment['date']		= sql_date_to_app_date($arrPaymentResult['date']);
			
				if($arrPayment['date']=="00/00/0000"){
					$arrPayment['date']	= '';
				}	
				$arrPayment['id']				= $arrPaymentResult['id'];
				$arrPayment['reason']			= $arrPaymentResult['reason'];
				$arrPayment['created_by_full_name']	= $arrPaymentResult['created_by_full_name'];
				$arrPayment['requested_by']		= $arrPaymentResult['requested_by'];
				$arrPayment['paid_by']			= $arrPaymentResult['paid_by'];
				//$arrPayment['amount']			= $arrPaymentResult['amount'];
				$toalAmount = $toalAmount+$arrPayment['amount'];
				//pr($arrPaymentResult);
				//if($arrPaymentResult['status'] == COMPLETED || $arrPaymentResult['status'] == PRENEW){
//					$arrPayment['kol_name']			= '<a target="_NEW" href=\''.base_url().'kols/view/'.$arrPaymentResult['kol_id'].'\'>'.$arrSalutations[$arrPaymentResult['salutation']]." ".$arrPaymentResult[FIRST_ORDER]." ".$arrPaymentResult[SECOND_ORDER]." ".$arrPaymentResult[THIRD_ORDER].'</a>';
					$arrPayment['kol_name']			= $arrSalutations[$arrPaymentResult['salutation']]." ".$this->common_helpers->get_name_format($arrPaymentResult['first_name'],$arrPaymentResult['middle_name'],$arrPaymentResult['last_name']);
				//}elseif($arrPaymentResult['status']==New1 || $arrPaymentResult['status']==APPROVED){
//					$arrPayment['kol_name']			= '<a target="_NEW" href=\''.base_url().'requested_kols/show_client_requested_kols\'>'.$arrSalutations[$arrPaymentResult['salutation']]." ".$arrPaymentResult[FIRST_ORDER]." ".$arrPaymentResult[SECOND_ORDER]." ".$arrPaymentResult[THIRD_ORDER].'</a>';
				//	$arrPayment['kol_name']			= '<a target="_NEW" href=\''.base_url().'requested_kols/show_client_requested_kols\'>'.$arrSalutations[$arrPaymentResult['salutation']]." ".$this->common_helpers->get_name_format($arrPaymentResult['first_name'],$arrPaymentResult['middle_name'],$arrPaymentResult['last_name']).'</a>';
				//}else{	
				$arrPayment['kol_id'] = $arrPaymentResult['kol_id'];
				$arrPayment['unique_id'] = $arrPaymentResult['unique_id'];
				$arrPayment['kol_name_link'] = $arrPayment['kol_name'];
				//$arrPayment['kol_name_link'] = "<a href='".base_url()."/kols/view/".$arrPayment['unique_id']."' target='_NEW' class='link' title='".$arrPayment['kol_name']."'>".$arrPayment['kol_name']."</a>";
				$arrPayment['status'] = $arrPaymentResult['status'];
				$arrPayment['client_id'] = $arrPaymentResult['client_id'];
				$arrPayment['created_by_full_name'] = $arrPaymentResult['created_by_full_name'];
				$arrPayment['data_type_indicator'] = $arrPaymentResult['data_type_indicator'];
				$arrPayments[]					= $arrPayment;
			}
			$arrUserDetails					= $this->client_user->editUser($arrPaymentResult['created_by']);
		}
			$count	= sizeof($arrPayments);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPayments; 
			$userdata['amount'] = "Total: ".$toalAmount;
			$userdata['paid_by'] = "";
			$data['userdata'] = $userdata; 
		echo json_encode($data);
	}
	
	function view_micro_payment($paymentId){
		$data	= array();
		$group	= array();
		$dropDownValues 			= 	$this->get_payment_dropdown_values();
		$arrPaymentCurrencies = $dropDownValues['arrPaymentCurrencies'];
    	// Getting the Payment details
      	$arrPaymentDetail = $this->payment->getPaymentById($paymentId);
      	$arrTypesAndAmount = $this->payment->getPayementTypeAndAmount($paymentId);
      	foreach ($arrTypesAndAmount as $value) {
      		$group[$value['currency']][] = $value;
      	}
      	foreach ($group as $key=>$value){
      		$arr_amount = array();
      			for($j=0;$j<count($group[$key]);$j++){
      					$arr_amount[]	= $group[$key][$j]['indAmount'];
      			}	
      			$arr_group_amount[$key] = array_sum($arr_amount);
      	}
		$arrPaymentDetail['arrTypesAndAmount'] = $arrTypesAndAmount;
		$arrPaymentDetail['arrGroupTypesAndAmount']	= $arr_group_amount;
		$data['arrPaymentTypes']	=	$dropDownValues['arrPaymentTypes'];
		$data['arrPaymentCurrencies']	=	$arrPaymentCurrencies;
		//$data['arrInteractionIds']	=	$dropDownValues['arrInteractionIds'];
	//	$data['arrKol']				=	$dropDownValues['arrKol'];
		$data['arrPaymentPaidBy']	=	$dropDownValues['arrPaymentPaidBy'];
		$data['arrPaymentRequestBy']=	$dropDownValues['arrPaymentRequestBy'];
		
		$data['arrPayment']	=	$arrPaymentDetail;
  	 	
		$this->load->view('payments/view_payment_micro_profile',$data);
	}
	
	function export_payment_details($kolId=null){
		$paymentIds= $this->input->post('payment_ids');
		$arrPaymentIds = explode(',',$paymentIds);
		$clientId		= $this->session->userdata('client_id');
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId			= 0;
		if($this->session->userdata('user_role_id')==ROLE_USER){
			$userId		= $this->session->userdata('user_id');
		}
		$arrPayments[0] = array('Date','KTL Name','Requested By','Paid By','Amount','Reason');
		if($arrPaymentsResults=$this->payment->exportPaymentDetails($clientId,$kolId,$userId,$startDate,$endDate,$arrPaymentIds)){			
			foreach($arrPaymentsResults as $arrPaymentResult){
				$arrPayment['date']		= sql_date_to_app_date($arrPaymentResult['date']);
			
				if($arrPayment['date']=="00/00/0000"){
					$arrPayment['date']	= '';
				}	
		
				$arrPayment['kol_name']	=$arrSalutations[$arrPaymentResult['salutation']]." ".$arrPaymentResult['first_name']." ".$arrPaymentResult['middle_name']." ".$arrPaymentResult['last_name'];
				$arrPayment['requested_by']		= $this->payment->getPaymentRequestedBy($arrPaymentResult['requested_by']);
				$arrPayment['paid_by']			= $this->payment->getPaymentPaidBy($arrPaymentResult['paid_by']);
				$arrPayment['amount']			= $arrPaymentResult['amount'];
				$toalAmount = $toalAmount+(int)$arrPayment['amount'];
				$arrPayment['reason']			= $arrPaymentResult['reason'];
				$arrUserDetails					= $this->client_user->editUser($arrPaymentResult['created_by']);
				$arrPayments[]					= $arrPayment;
			}
			//pr($arrPayments);
		}
		$arrPaymentDetails=array();
		foreach($arrPayments as $key=>$value){
			$arr1=array();
			foreach($value as $row){
				
				$arr1[]=$row;
			}
			$arrPaymentDetails[]=$arr1;
		}
	
	$this->load->plugin('phpxls/writer');
	$workbook = new Spreadsheet_Excel_Writer();
		
			$format_und =& $workbook->addFormat();
			$format_und->setBottom(2);//thick
			$format_und->setBold();
			$format_und->setColor('black');
			$format_und->setFontFamily('Calibri');
			$format_und->setAlign('centre');
			$format_und->setSize(12);
			
		$format_reg =& $workbook->addFormat();
	//	$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		$filterHeaders[0] = 'Filter Name';
		$filterHeaders[1] = 'Filter Value';
		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != ''){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
		
		
			$arr = array(
			      	'Payments' => $arrPaymentDetails,
					'Filters' => $filters
			      );
			
	      	foreach($arr as $wbname=>$rows)
			{
						    
				$rowcount = count($rows);
			    $colcount = count($rows[0]);
			
				$worksheet =& $workbook->addWorksheet($wbname);
				//Setting the column width for 'COMPANY OVERVIEW' Sheet
				if($wbname=='Payments'){
				    $worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				    $worksheet->setColumn(1,1,40.00);
				    $worksheet->setColumn(2,2, 20.00);
				  	$worksheet->setColumn(3,3, 25.00);
				    $worksheet->setColumn(4,4, 15.00);
				    $worksheet->setColumn(5,5, 25.00);
					$worksheet->setColumn(6,6, 25.00);
					$worksheet->setColumn(7,7, 25.00);
					$worksheet->setColumn(8,8, 25.00);
			     
				  
				}
				if($wbname == 'Filters'){
					$worksheet->setColumn(0,0,25);
				    $worksheet->setColumn(1,1,25);
				}
				//Setting the column width for 'SOCIAL MEDIA' Sheet
				
			 
			
			    for( $j=0; $j<$rowcount; $j++ )
			    {
			        for($i=0; $i<$colcount;$i++)
			        {
			          $fmt  =& $format_reg;
			          
			            if ($j==0){
			                $fmt =& $format_und;
		                    
			            }
			            if (isset($rows[$j][$i]))
			            {
			                $data=$rows[$j][$i];
							  $worksheet->write($j, $i, $data, $fmt);
			            }
			        }
			    }
			}
			
			$userId=$this->session->userdata('user_id');
			$userName = $this->client_user->getUserNameById($userId);
			$fileName = $userName."_payments";
			if($kolId != null){
				$kolDetails = $this->kol->getKolName($kolId);
				$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
				$fileName = $userName."_".$kolName."_payments";
			}
			//for downloading the file
			$workbook->send($fileName.'.xls');
			$workbook->close();
	}
	function get_kol_other_details($kolId = null) {
		//echo "ddd";
		if ($kolId == null || $kolId == '') {
			$kolName = $this->input->post('kol_name');
			//	$value1=str_replace(" ","",$kolName);
			$kolId = $this->kol->getKolId($kolName);
		}
	
		$arrKolDetails = $this->kol->getKolDetailsById($kolId);
		$data['specialtyId'] = $arrKolDetails[0]['specialty'];
		$data['title'] = $arrKolDetails[0]['title'];
		$data['specialtyName'] = $this->specialty->getSpecialtyById($data['specialtyId']);
		$data['last_interaction'] = $this->interaction->getKolLastInteractionById($kolId);
		//pr($data);
		//exit;
		echo json_encode($data);
	}
}