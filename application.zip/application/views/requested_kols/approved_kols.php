<?php 
/**
 * 
 *  View page contains List of Approved KOls
 * @author Vinayak
 * @since 4.2
 * @package application.view.requested_kols
 * @created 13-6-2012
 */
?>
<p>Hello,</p><p>

<b><?php echo $clientName;?></b> User has submitted new Profile content curation requests for further processing.</p>

	
<br />
<table>
	<?php foreach($arrKols as $row){?>

	<tr>
		<td align="right"><label style="font-weight: bold;">KTL Name: </label></td>
		<td style="color:gray"> <?php echo $row['first_name']." ".$row['middle_name']." ".$row['last_name'];?></td>
	</tr>
<?php }?>
</table>


<br />
<p>Thanks,</p>
<p><?php echo PRODUCT_NAME; ?> Support</p>