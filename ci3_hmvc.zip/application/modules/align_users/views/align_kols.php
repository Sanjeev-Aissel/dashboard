<?php
	$arrKolIds	= explode(',',$arrKols);
?>
<script>
var ids	= '<?php echo $arrKols;?>';
function saveKolsAlignment(){
	$.ajax({
		url:'<?php echo base_url()?>align_users/align_users/save_kol_alignment',
		data:$('#alignKols').serialize(),
		type:'post',
		dataType:'json',
		success:function(returnData){
			cancelAlignmentBox();
			location.reload();
		}
	});
}
function deleteKolAlignment(){
	$.ajax({
		url:'<?php echo base_url()?>align_users/align_users/remove_kol_alignment',
		data:$('#unassignMeForm').serialize(),
		type:'post',
		dataType:'json',
		success:function(returnData){
			cancelAlignmentBox();
			location.reload();
		}
	});
}
function cancelAlignmentBox(){
	$("#listContainer").dialog("close");
}
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
	var contactviewType	= Number($('#viewType').val());
	if(contactviewType==1){
		$('#alignKols').css('display','none');
	}else{
		$('#unassignMeForm').css('display','none');
	}
});
</script>
<div id="alignmentOfUsersWrapper">
	<form action="<?php echo base_url();?>align_users/align_users/save_kol_alignment" method="post" id="alignKols" name="alignKolsForm" onsubmit="saveKolsAlignment(); return false;">
		<input type="hidden" name="kol_id" id="kolIds" value="<?php echo $arrKols?>" />
		<p><label>Select user(s) to assign</label></p>
		<select name="users[]" id="users" multiple="multiple" class="form-control chosenMultipleSelect" data-placeholder="Select Users">
			<option value=""></option>
			<?php foreach($arrUsers as $key=>$arrRow){
					$selected	= '';?>
					<option value="<?php echo $arrRow['id'];?>" <?php if(array_key_exists($arrRow['id'],$assignedUsers)) echo "selected='selected'";?>>
						<?php echo $arrRow['first_name'].' '.$arrRow['last_name'];?>
					</option>
			<?php }	?>
		</select>
		<p style="color:red">Only KOL's of your division will be assigned.</p><br/>
		<div class="form-group row" style="text-align: center;">
           	<input type="button" name="cancel" value="Cancel" onclick="cancelAlignmentBox();return false;" />
			<input type="submit" name="submit" value="Assign" />
		</div>
	</form>
	<form action="<?php echo base_url();?>align_users/align_users/remove_kol_alignment" method="post" id="unassignMeForm" name="unassignKolsForm" onsubmit="deleteKolAlignment(); return false;">
		<p>Unassign me from selected <?php echo sizeof($arrKolIds);?> KTL(s)</p><br />
		<input type="hidden" name="kol_id" value="<?php echo $arrKols?>" />
		<div class="form-group row" style="text-align: center;">
           	<input type="button" name="cancel" value="Cancel" onclick="cancelAlignmentBox();return false;" />
			<input type="submit" name="submit" id="unassignMeButton" value="Unassign Me" />
		</div>
	</form>
</div>
