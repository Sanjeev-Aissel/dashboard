<?php
/**
 * This class contains the methods to Planning module activites 
 * @pakage 
 * @author Vinayak
 * @since 3.1	
 * @created  10-09-11
 */
class Plannings extends MX_Controller{	
	//Constructor
	function __construct()
	{
		parent::__construct();
		$this->load->model('planning');
		$this->load->model('kols/kol');
		$this->load->model('clients/client');
		$this->load->model('interactions/interaction');
		$this->load->model('helpers/common_helper');
		$this->load->model('payments/payment');
		$this->loggedUser = $this->session->userdata['user_name'];
	}
	
	function index(){
		echo "asdad";
	}
	/*
	 * To load View page that cintains List Of Plans
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  10-09-11
	 * 
	 */
	function show_plans($subContentPage=''){
		$this->session->set_userdata('kolId', '-1');
		$data['contentPage'] 	=	'list_plans';
		$data['subContentPage']	=	$subContentPage;
	//	$data['maxYear']	=	$this->planning->getMaxYearPlanning();
		/* $arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => 'List Plannings',
				'status' => STATUS_SUCCESS,
				'transaction_name' => "List Plannings",
		);
		$this->config->set_item('log_details', $arrLogDetails);		 */
		$this->load->view(CLIENT_LAYOUT, $data);
	
	}
	
	/*
	 * To load View page that to add the Objective
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  10-09-11
	 * 
	 */
	function add_objective(){
		$data['arrObjectives'] = ' ';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add objective Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'transaction_name' => "View add objective Payments"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('plannings/add_objective',$data);
	}
	
	/*
	 * To send the Objective details to model for saving
	 *  
	 * @author Vinayak
 	 * @since  3.1
 	 * @created  10-09-11
	 * 
	 */
	function save_objective(){		
		$arrObjective['name'] 			= trim($this->input->post('name'));
		$arrObjective['description'] 	= trim($this->input->post('description'));
		$arrObjective['created_by']	 	= $this->session->userdata('user_id');
		$arrObjective['created_on'] 	= date("Y-m-d H:i:s");	
		$arrObjective['client_id'] 	    = $this->session->userdata('client_id');
		$clientId			=	$this->session->userdata('client_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
		    $arrObjective['data_type_indicator'] = 'Aissel Analyst';
		}
		if($lastInsertId = $this->planning->saveObjective($arrObjective)){
			//$this->update->insertUpdateEntry(PLAN_ADD,$lastInsertId['id'], MODULE_PLANNING, $arrObjective['kol_id']);			
			$data['lastInsertId'] = $lastInsertId;
			$data['saved'] = true;
			$data['data'] = $arrObjective;
			$data['mesg'] = 'Data is Saved Successfully';
			$arrLogDetails = array(
					'type' => ADD_RECORD,
			        'description' => 'New Objective',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
			        'transaction_id' => $lastInsertId,
			        'transaction_table_id' => OBJECTIVES,
			        'transaction_name' => 'New Objective',
			        'form_data' => json_encode($arrObjective),
			        'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$data['saved'] = false;
			$data['mesg'] = 'Sorry! The Objective Name is Already Present in Database';
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'New Objective',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => OBJECTIVES,
					'transaction_name' => 'New Objective',
					'form_data' => json_encode($arrObjective),
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}
		echo json_encode($data);
	}
	
	/*
	 * To get the Objective details from model and send it to view page to list 'Objective details'
	 *  
	 * @author Vinayak
 	 * @since  3.1
 	 * @created  10-09-11
	 * 
	 */
	function list_objective_details(){
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrResult	= $this->planning->listObjectiveDetails();
		$count=sizeof($arrResult);				
		if( $count >0 ){ 
			$total_pages = ceil($count/$limit); 
		}else{ 
			$total_pages = 0; 
		} 
		$data['records'] = $count;
		$data['total']   = $total_pages;
		$data['page']    = $page;		
		$data['rows']    = $arrResult;
		echo json_encode($data);
				
	}
	
	/*
	 * To get the Objective details from model by passing objective id and pass the details to view page
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  10-09-11
 	 * @param $objectiveId
	 * 
	 */
	function edit_objective($objectiveId){
		
		$arrObjectives = $this->planning->getObejctiveDetailsForEditing($objectiveId);
		$data['arrObjectives'] = $arrObjectives;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add objective Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'transaction_name' => "View add objective Payments"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('plannings/add_objective',$data);
	}
	
	/*
	 * To send the Objective details to  model for updating
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  10-09-11
 	 * @param 
	 * 
	 */
	function update_objective(){
		$arrObjective['id'] 			= $this->input->post('id');
		$arrObjective['name'] 			= $this->input->post('name');
		$arrObjective['description'] 	= $this->input->post('description');
		$arrObjective['modified_by']	 	= $this->session->userdata('modified_by');
		$arrObjective['modified_on'] 	= date("Y-m-d H:i:s");	
		if($this->planning->updateObjective($arrObjective)){
			//$this->update->insertUpdateEntry(PLAN_UPDATE,$arrObjective['id'], MODULE_PLANNING, $arrObjective['kol_id']);
			$data['lastInsertId'] = $arrObjective['id'] ;
			$data['saved'] = true;
			$data['data'] = $arrObjective;
			$data['mesg'] = 'Data is Updated Successfully';
			$arrLogDetails = array(
			        'type' => EDIT_RECORD,
			        'description' => 'Update Objective',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
			        'transaction_id' => $arrObjective['id'],
			        'transaction_table_id' => OBJECTIVES,
			        'transaction_name' => 'Update Objective',
			        'form_data' => json_encode($arrObjective),
			        'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			
		}else{
			$data['saved'] = false;
			$data['mesg'] = 'Sorry! The Objective Name is Already Present in Database';
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Objective',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $arrObjective['id'],
					'transaction_table_id' => OBJECTIVES,
					'transaction_name' => 'Update Objective',
					'form_data' => json_encode($arrObjective),
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		
		}
		echo json_encode($data);
		
	}
	
	/*
	 * To get the Plan details from model and send it to view page to list 'Plan details'
	 *  
	 * @author Vinayak
 	 * @since  3.1
 	 * @created  12-09-11
	 * 
	 */
	function list_plans($startDate,$endDate=2018){
		$arrResult1 = array();
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid  
		$arrResult	= $this->planning->listPlansNew($startDate,$endDate);
		
		//$arr['records']=sizeof($arrResult);
		$count=sizeof($arrResult);				
		if( $count >0 ){ 
			$total_pages = ceil($count/$limit); 
		}else{ 
			$total_pages = 0; 
		} 
		$data['records'] = $count;
		$data['total']   = $total_pages;
		$data['page']    = $page;		
		$data['rows']     = $arrResult;
		echo json_encode($data);
	}
	
	/*
	 * Delete objective by passing objective Id to model
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * 
	 */
	function delete_objective($objectiveId){
		$data['status'] = $this->planning->deleteObjective($objectiveId);
		echo json_encode($data);
		//$this->update->insertUpdateEntry(PLAN_DELETE,$objectiveId['id'], MODULE_PLANNING, $objectiveId['kol_id']);
	}
	
	/**
	 * If Add then Prepares the data for adding plan and passes it to add_palns page
	 * If Edit then Fetchs the plan details of given plan id and prepares all data for editing the plan and sends it to edit_plan page
	 * @author Ramesh B
	 * @since 3.1
	 * @param  planId
	 * @return 
	 * @created 12-09-2011
	 */
	function add_plans($planId=null){
		$arrObjectives	= array();
		$arrKols		= array();
		$arrUsers		= array();
		$clientId		= $this->session->userdata('client_id');
		
		$arrObjectivesResults		=	$this->planning->listObjectiveDetails();
		foreach($arrObjectivesResults as $row)
			$arrObjectives[$row['id']]=$row['name'];
		
		$arrKolsResults		=	$this->kol->getKolNames("",1);
		foreach($arrKolsResults as $row){
			$arrKols[$row['id']]=$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
//			$arrKols[$row['id']]=$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
		}
		$arrUserResults		=	$this->client_User->getUsers($clientId);
		foreach($arrUserResults as $row){
			$arrUsers[$row['id']]=$row['first_name']." ".$row['last_name'];
//			$arrUsers[$row['id']]=$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
		}
		$data['arrObjectives']=$arrObjectives;
		$data['arrKols']=$arrKols;
		$data['arrUsers']=$arrUsers;
		
		if($planId!=null){
			$arrPlanDetails=array();
			$arrPlans = $this->planning->getPlanDetail($planId,true);
//                        pr($arrPlans);
//                        exit;
                        $arrObj=$this->planning->getObj($planId);
                        $data['planDetails'] = $arrPlans;
                        $data['noOfRows']=count($data['planDetails']);
                        $data['arrObj'] = $arrObj;
                        $data['plan_id']=$planId;
                         $data['contentPage'] 	=	'plannings/add_plan_new';

                        $this->load->view('layouts/client_view', $data);
			
		}else{
			$this->load->view('plannings/add_plan_new',$data);
		}
	}
	
	/**
	 * Saves the all the plans, returns true after saving
	 * @author Ramesh B
	 * @since 3.1
	 * @return boolean
	 * @created 12-09-2011
	 */
	function save_plans(){	
		$arrDuplicates		=	array();
		$arrSavedPlans		=	array();	
		$objectiveId		=	$this->input->post('objective_id');
		$numberOfPlans		=	(int)$this->input->post('number_of_plans');
		$loginUserId		=	$this->session->userdata('user_id');
		$clientId			=	$this->session->userdata('client_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
		    $dataType = 'Aissel Analyst';
		}
                $planId=$this->input->post('plan_id');
                
                if($planId!=''){
                    $planDetails = $this->planning->getPlanDetailsById($planId);
                    $this->planning->deletePlanDetails($planId);
                }
                $planName=$this->input->post('plan_name');
                $arrPlanDetails['plan_name']=$this->input->post('plan_name');
                $old_date_timestamp = strtotime($this->input->post('plan_start'));
                $new_date_start = date('Y-m-d ', $old_date_timestamp);
                $old_date_timestamp = strtotime($this->input->post('plan_end'));
                $new_date_end = date('Y-m-d ', $old_date_timestamp);
                $arrPlanDetails['plan_start']=$new_date_start;;
                $arrPlanDetails['plan_end']=$new_date_end;	
                $arrPlanDetails['plan_description']=$this->input->post('plan_desc');
                $arrPlanDetails['created_at'] = date("Y-m-d H:i:s");
		if($this->planning->checkForDuplicatePlan($planName,$clientId)==true){
					//Save plan
					if($planId!=''){
					    foreach($planDetails as $row){
					        $arrPlanDetails['data_type_indicator']=$row['data_type_indicator'];
					        $arrPlanDetails['client_id']=$row['client_id'];
					        $arrPlanDetails['created_by']=$row['created_by'];
					        $arrPlanDetails['created_at'] = $row['created_at'];
					    }
						$lastInsertedPlanId	= $this->planning->savePlan($arrPlanDetails);
						$planId = $this->planning->updatePlanId($planId, $lastInsertedPlanId);
						$log_type =  EDIT_RECORD;
						$log_description =  'Update Planning';
						$transaction_name =  "Update Planning";
					}else{
					    $arrPlanDetails['data_type_indicator']=$dataType;
					    $arrPlanDetails['client_id']=$clientId;
					    $arrPlanDetails['created_by']=$loginUserId;
						$planId	= $this->planning->savePlan($arrPlanDetails);
						$log_type =  ADD_RECORD;
						$log_description =  'New Planning';
						$transaction_name =  "New Planning";
						
						$kolIDSEmail=array();
						for($i=1; $i<=$numberOfPlans;$i++){
						    foreach($this->input->post('kol_id_'.$i) as $values)
						        $kolIDSEmail[]=$values;
						}
						
						//New Record added email
						$arrReturnResult	= $this->planning->getAssignedUsersForType($kolIDSEmail);
						$user_email	= array_unique($arrReturnResult['user_details']);
						$type_name	= $arrReturnResult['type_name'];
						
						$urlLink = '<a href="'.base_url().'plannings/view_plan/'.$planId.'">click here</a>';
						$arrConfig = $this->common_helpers->getMailConfig(USER,PASS);
						$arrInfo = array (
						    'FROM' => USER,
						    'FROM_NAME' => SENDER,
						    'TO' => $user_email,
						    'CC' => array(""),
						    'SUBJECT' => "New Plan : $planName",
						    'MAIL_BODY' => '<html>
									<head>
										<style>
											table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
											td, th { border: 1px solid #CCC; height: 30px; }
											th { background: #F3F3F3; font-weight: bold; }
											td { background: #FAFAFA; text-align: center;}
										</style>
									</head>
									<body>
										<div>
											Hi, <br/><br/> This is a notification about a plan "'.$planName.'" for which KTLs assigned to you have been added.<br><br>
                                            Please '.$urlLink.' to view the plan.<br/><br/>
											<br>Regards,<br>Aissel Support Team<br>
										</div>
									</body>
								</html>'
						);
						$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
					}
					
                                        foreach($this->input->post('objective_id') as $id){
                                            $arrObj=array();
                                            $arrObj['plan_id']=$planId;
                                            $arrObj['objective_id']=$id;
                                            $this->planning->savePlanObjective($arrObj);
                                        }
					//$this->update->insertUpdateEntry(PLAN_ADD,$arrPlanDetails['id'], MODULE_PLANNING, $arrPlanDetails['kol_id']);
                                        $arrLogDetails = array(
                                        		'type' => $log_type,
                                        		'description' => $log_description,
                                        		'status' => STATUS_SUCCESS,
                                        		'transaction_id' => $planId,
                                        		'transaction_table_id' => PLANS,
                                        		'transaction_name' => $transaction_name,
                                        		'form_data' => json_encode($arrPlanDetails),
                                        		'parent_object_id' => ''
                                        );
                                        
                                        $this->config->set_item('log_details', $arrLogDetails);
//					$arrSavedPlans[]=$i;
                    }else{
					echo json_encode(array("duplicate"=>true));
                                        return;
                    }
                    
                 $arrPlanDetails=array();  
		// based on the number of plans, get the details of each plan and save
		for($i=1; $i<=$numberOfPlans;$i++){
			//Save only if it is not cancelled
			//if($this->input->post('plan_cancel_'.$i)!=null){
				$arrPlanDetails		=	array();
				//$arrPlanDetails['objective_id']		=	$objectiveId;
				$arrPlanDetails['user_id']			=	$this->input->post('user_id_'.$i);
				$arrPlanDetails['status']   =$this->input->post('status_'.$i);
                                $arrPlanDetails['plan_id']=$planId;
				$kolName							=  	$this->input->post('kol_name_'.$i);
			//	$value1=str_replace(" ","",$kolName);
				//$kolId=$this->kol->getKolId($kolName);
                                $kolIDS=array();
                                foreach($this->input->post('kol_id_'.$i) as $values)
                                        $kolIDS[]=$values;
				$arrPlanDetails['kol_id']			=	$kolId;
				$arrPlanDetails['created_at'] = date("Y-m-d H:i:s");
                                $this->planning->savePlanProfiles($arrPlanDetails,$kolIDS);
				
			//}
		}

//		$data['duplicatesCount']	=sizeof($arrDuplicates);
//		$data['duplicatePlans']		=$arrDuplicates;
//		$data['savedPlans']			=$arrSavedPlans;
		echo json_encode(array("success"=>true));
	}
	
	/**
	 * Updates the given plan details
	 * @author Ramesh B
	 * @since 3.1
	 * @return boolean
	 * @created 13-09-2011
	 */
	function update_plan(){
		$data=array();
		$loginUserId		=	$this->session->userdata('user_id');
		$clientId			=	$this->session->userdata('client_id');
		$arrPlanDetails		=	array();
		$arrPlanDetails['id']				=	trim($this->input->post('plan_id'));
		$arrPlanDetails['objective_id']		=	trim($this->input->post('objective_id'));
		$arrPlanDetails['user_id']			=	trim($this->input->post('user_id'));

		$kolName							=  	$this->input->post('kol_id');
		//$value1=str_replace(" ","",$kolName);
		$kolId=$this->kol->getKolId($kolName);
		
		$arrPlanDetails['kol_id']			=	$kolId;
				
		$arrPlanDetails['targets']			=	trim($this->input->post('targets'));
		//Plan date will come as mm-yyyy we have to split it and save as yyyy-mm-01
		$planDateInput						=	trim($this->input->post('month'));
		$planDateInputDetails				=	explode("/",$planDateInput);
		$planDate							=	$planDateInputDetails[1]."-".$planDateInputDetails[0]."-01";
		$arrPlanDetails['plan_date']		=	$planDate;
		$arrPlanDetails['modified_by']		=	$loginUserId;
		$arrPlanDetails['modified_on']		=	date('Y-m-d H:i:s');
		
		if(!$this->planning->checkForDuplicatePlan($arrPlanDetails['objective_id'],$arrPlanDetails['user_id'],$arrPlanDetails['kol_id'],$clientId,$planDate,$arrPlanDetails['id'])){
			//Save plan
			if($this->planning->updatePlan($arrPlanDetails)){
				//$this->update->insertUpdateEntry(PLAN_UPDATE,$arrDocDetails['id'], MODULE_PLANNING, $arrDocDetails['kol_id']);
				$data['isSaved']=true;
				$data['kolId']=$kolId;
				//Add Log activity
				$arrLogDetails = array(
						'type' => EDIT_RECORD,
						'description' => 'Update plan',
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $kolId,
						'transaction_id' =>  $arrPlanDetails['id'],
						'transaction_table_id' => PLANS,
						'transaction_name' => 'Update plan',
						'form_data' => json_encode($arrPlanDetails),
						'parent_object_id' => $kolId
				);
				$this->config->set_item('log_details', $arrLogDetails);
			}
			else 
				$data['isSaved']=false;
				//Add Log activity
				$arrLogDetails = array(
						'type' => EDIT_RECORD,
						'description' => 'Update plan',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $kolId,
						'transaction_id' =>  $arrPlanDetails['id'],
						'transaction_table_id' => PLANS,
						'transaction_name' => 'Update plan',
						'form_data' => json_encode($arrPlanDetails),
						'parent_object_id' => $kolId
				);
				$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$data['isDuplicate']=true;
		}
		
		echo json_encode($data);
	}
	
	
	/**
	 * Deletes the plan for given plan Id
	 * @author Ramesh B
	 * @since 3.1
	 * @param  planId
	 * @return boolean
	 * @created 13-09-2011
	 */
	function delete_plan($planId){
		if($this->planning->deletePlan($planId)){
			//$this->update->insertUpdateEntry(PLAN_DELETE,$planId['id'], MODULE_PLANNING, $planId['kol_id']);
			echo true;
		}else{
			echo false;
		}
	}
	
	/**
	 * To get Plan details and their releted interactions by passing planId
	 * @author Vinayak
	 * @since 3.1
	 * @param  planId
	 * @return 
	 * @created 14-09-2011
	 */
	function view_plan($planId){
		$arrPlans = $this->planning->getPlanDetail($planId);
                $arrObj=$this->planning->getObj($planId);
		//pr($arrInteractionsDeialls);
		$data['planDetails'] = $arrPlans;
                $data['arrObj'] = $arrObj;
                $data['contentPage'] 	=	'plannings/view_plan_new';
                $arrLogDetails = array(
                		'type' =>VIEW_RECORD,
                		'description' => 'View Planning',
                		'status' => 'success',
                		'transaction_id' => $planId,
                		'transaction_table_id' => PLANS,
                		'transaction_name' => "View Planning"
                );
                
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
		$this->load->view('layouts/client_view', $data);
		
	}
	
	/**
	 * Prepares the Engagement paln report data for the given month ranges and returns it to 
	 * the 'view_reports' page
	 * @author Vinayak
	 * @since 3.1
	 * @param  planId
	 * @return 
	 * @created 17-09-2011
	 */
	function show_engagement_plan_report($startDate=null,$endDate=null){
		$clientId			=	$this->session->userdata('client_id');
		$endDateInteraction	= 	$endDate;
		if($startDate==null || $endDate==null){
			$startDate			=	date('Y-m').'-01';
			$endDate			=	date('Y-m').'-01';
			//For interactions, end date should be the last day of the given 'endDate' month
			$endDateInteraction	=	$this->common_helpers->MM_YYYY_To_YYYY_MM_MonthLastDay(date('m-Y'));
		}else{
			$startDate			=	$this->common_helpers->MM_YYYY_To_YYYY_MM_MonthFirstDay($startDate);
			$endDate			=	$this->common_helpers->MM_YYYY_To_YYYY_MM_MonthFirstDay($endDate);
			//For interactions, end date should be the last day of the given 'endDate' month
			$endDateInteraction	=	$this->common_helpers->MM_YYYY_To_YYYY_MM_MonthLastDay($endDateInteraction);
		}
		$arrUsersInteractedKols		=	array();
		//Get Users targets per kol 
		$arrUsersTargetsPerKol	=	$this->planning->getAllUserTargetsPerKOL($clientId,$startDate,$endDate);
		
		//Prepare users total targets
		$arrUserTargetsTotal	=	array();
		foreach($arrUsersTargetsPerKol as $userId => $targetDetails){
			$arrUserTargetsTotal[$userId]=0;
			foreach($targetDetails as $kolId => $target){
				$arrUsersInteractedKols[$userId][]=$kolId;
				$arrUserTargetsTotal[$userId]+=(int)$target;
			}
		}
		
		//Get Users achieved interactions per kol 
		$arrUsersInteractionsPerKolCount	=	$this->interaction->getAllUserAchievedInteractionsPerKOL($clientId,$startDate,$endDateInteraction);
		
		//Prepare users total achieved interactions
		$arrUsersInteractionsTotalCount	=	array();
		foreach($arrUsersInteractionsPerKolCount as $userId => $achievedDetails){
			$arrUsersInteractionsTotalCount[$userId]=0;
			foreach($achievedDetails as $kolId => $achieved){
				$arrUsersInteractedKols[$userId][]=$kolId;
				$arrUsersInteractionsTotalCount[$userId]+=(int)$achieved;
			}
		}
		
		//Prepare a combined array
		$arrReportData=array();
		foreach($arrUsersInteractedKols as $userId => $arrKols){
			//Total Target
			if(array_key_exists($userId,$arrUserTargetsTotal))
				$arrReportData[$userId][0]['target']=$arrUserTargetsTotal[$userId];
			else
				$arrReportData[$userId][0]['target']=0;
			//Total achieved
			if(array_key_exists($userId,$arrUsersInteractionsTotalCount))
				$arrReportData[$userId][0]['achieved']=$arrUsersInteractionsTotalCount[$userId];
			else
				$arrReportData[$userId][0]['achieved']=0;
			//Per KOL 
			foreach($arrKols as $kolId){
				//KOL Target
				if(isset($arrUsersTargetsPerKol[$userId]) && array_key_exists($kolId,$arrUsersTargetsPerKol[$userId]))
					$arrReportData[$userId][$kolId]['target']=$arrUsersTargetsPerKol[$userId][$kolId];
				else
					$arrReportData[$userId][$kolId]['target']=0;
				//KOL achived
				if(isset($arrUsersInteractionsPerKolCount[$userId]) && array_key_exists($kolId,$arrUsersInteractionsPerKolCount[$userId]))
					$arrReportData[$userId][$kolId]['achieved']=$arrUsersInteractionsPerKolCount[$userId][$kolId];
				else
					$arrReportData[$userId][$kolId]['achieved']=0;
			}
		}
		
		$arrKolsNames=array();
		$arrUsers=array();
		//Get All KOLs names
		$arrKolsResults		=	$this->kol->getKolNames();
		foreach($arrKolsResults as $row)
			$arrKolsNames[$row['id']]= $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
		//Get All Users names
		$arrUserResults		=	$this->client_User->getUsers($clientId);
		foreach($arrUserResults as $row)
			$arrUsers[$row['id']]	= $row['first_name'].' '.$row['last_name'];
		
//		pr($arrUsersTargetsPerKol);
//		pr($arrUserTargetsTotal);
//		pr($arrUsersInteractionsPerKolCount);
//		pr($arrUsersInteractionsTotalCount);
//		pr($arrReportData);
		$data['arrReportData']	=$arrReportData;
		$data['arrKolsNames']	=$arrKolsNames;
		$data['arrUsers']		=$arrUsers;
		
		$this->load->view('plannings/view_reports',$data);
	}
	
	
	function validating_existing_kol($kolName){
		$arrKols = $this->payment->getAllKolsName1();
		$kolId = array_search($kolName,$arrKols);
		if($kolId==null || $kolId=="" || $kolId==0){
			$data['status'] = false;
		}else{
			$data['status'] = true;
		}
		//$result = $this->planning->isEnteredKOLNameExists($kolText);
		// The Reverse of the RESULT will be sent
		// If the Duplicate User Exists, then it is as good as VALIDATION HAS FAILED. Hence send FALSE
		// If the Duplicate User doesn't exist, then it is as good as VALIDATION IS PASSED. ie, Proceed to SAVE. Hence send TRUE
		echo json_encode($data);
	}
	
	
	function get_all_kol_names($restrictByRegion=0) {
		$arrKols = $this->payment->getAllKolsName1($restrictByRegion);
// 		pr($this->db->last_query());
// 		pr($arrKols);exit;
		echo json_encode($arrKols);
	}
	
	function list_topic_details(){
		$page 	= $_REQUEST['page']; // get the requested page 
		$limit 	= $_REQUEST['rows']; // get how many rows we want to have into the grid    
		$arrResult = $this->planning->listTopicDetails();
		$count=sizeof($arrResult);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
		
		$data['records'] = $count;
		$data['total']   = $total_pages;
		$data['page']    = $page;		
		$data['rows']    = $arrResult;
		
		echo json_encode($data);
	}
	
	
	
	/**
	 * To load View page that to add the Topic
	 *  
	 * @author Vineet KAdkol
 	 * @since  3.1	
 	 * @created  22-09-2012
	 */
	function add_topic($id = null){
		$data['arrTopics'] = ' ';
		if($id != null)
			$data['arrTopics'] = $this->planning->getTopic($id);
		$this->load->view('topics/add_topic',$data);
	}
	
	
	/**
	 * To load View page that to save the Topic details
	 *  
	 * @author Vineet KAdkol
 	 * @since  3.1	
 	 * @created  22-09-2012
	 */
	function save_topic(){
		$arrTopic['name'] 			= trim($this->input->post('name'));
		$arrTopic['created_by']	 	= $this->session->userdata('user_id');
		$arrTopic['created_on'] 	= date("Y-m-d H:i:s");	
		$arrTopic['client_id'] 	    = $this->session->userdata('client_id');
		
		if($lastInsertId = $this->planning->saveTopic($arrTopic)){
			//$this->update->insertUpdateEntry(PLAN_ADD,$lastInsertId['id'], MODULE_PLANNING, $arrObjective['kol_id']);			
			$data['lastInsertId'] = $lastInsertId;
			$data['saved'] = true;
			$data['data'] = $arrTopic;
			$data['mesg'] = 'Data is Saved Successfully';
		}else{
			$data['saved'] = false;
			$data['mesg'] = 'Sorry! The Topic Name is Already Present in Database';
		}
		echo json_encode($data);
	}
	
	
	function update_topic(){
		$arrTopic['id'] 			= $this->input->post('id');
		$arrTopic['name'] 			= $this->input->post('name');
		$arrTopic['modified_by']	= $this->session->userdata('modified_by');
		$arrTopic['modified_on'] 	= date("Y-m-d H:i:s");	
		$arrTopic['client_id'] 	    = $this->session->userdata('client_id');
		
		if($this->planning->updateTopic($arrTopic)){
			//$this->update->insertUpdateEntry(PLAN_UPDATE,$arrObjective['id'], MODULE_PLANNING, $arrObjective['kol_id']);
			$data['lastInsertId'] = $arrTopic['id'] ;
			$data['saved'] = true;
			$data['data'] = $arrTopic;
			$data['mesg'] = 'Data is Updated Successfully';
		}else{
			$data['saved'] = false;
			$data['mesg'] = 'Sorry! The Topic Name is Already Present in Database';
		}
		echo json_encode($data);
	}
	
	function delete_topic($id){
		$isDeleted = $this->planning->deleteTopic($id);
		echo $isDeleted;
	}
}