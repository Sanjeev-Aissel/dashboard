<script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>
<style>
#message{
	color: #FF0000;
	font-size: 14px;
	margin-left: 211px;
	margin-top: 17px;
}

div.actionIconsContainer{
	width: 150px;
}

.editOnTop{
	float:right;
	margin-bottom: 10px; 
}

</style>
		<script>
			var startFrm ='<?php echo $startFrom?>';
			var count = '<?php echo $count?>';
			
			if((count-startFrm)<=10){
				$('#hide').hide();
			}else{
				$('#hide').show();
			}
			var ids='<?php echo $interactionIds?>';
			if(ids!=''){
				$('#ids').val(ids);
			}
		
		</script>
		
		<?php 
		//	if(empty($arrInteractionsResults)){
		///	//	echo "No interactions found for the criteria selected by you";
			//}
		?>
		<?php $i=1;
		
			if($startFrom > 0)
			$i = $startFrom+1;
		?>
		
		<?php if($count==0){?>
		<div id="message"><?php echo $mes;?></div>
		<?php }?>
		<?php foreach($arrInteractionsResults as $row){?>
		<div onclick="expand(<?php echo $row['id']?>,this)" class="expand" id="<?php echo $i?>">
		<table class="orgIntarcationTable" id="orgIntarcationTable_<?php echo $row['id']?>" onmouseover="showAction(<?php echo $row['id']?>);" onmouseout="hideAction(<?php echo $row['id']?>)">
		<tr id="interactionid_<?php echo $row['id']?>">
			<td width="15%" class="alignTop" >
				
				<button class="<?php if($row['mode_name']=='Face to Face') echo "facetoFace" ; elseif($row['mode_name']=='Web') echo 'web'; else echo 'phone'?>"><?php echo $row['mode_name']?></button>
			</td>
			<td width="85%">
				<table style="margin-bottom: 0; width:105%">
					<tr>
						<td width="90%">
							<p class="about"><label class="bold">Posted by:</label>  <?php echo $row['first_name']." ". $row['last_name'];?> <b>&nbsp;on&nbsp;</b><span style="margin-left:3px"><?php echo $row['date'] ?></span></p>
							<p class="about"><label class="bold">Attendees: </label><?php echo $row['kol_name'];?></p>
						<table class="topicTable">
								<?php foreach($row['topic_name'] as $key=>$topics){?>
								<tr <?php if($key>0){?> class="hide" <?php }?>>
									
									<td width="30%"><span class="space"><label class="topicDetail bold">Topic:</label>  <?php echo $topics['topic_name'];?></span></td>
									<td  width="30%"><span class="space"><label class="topicDetail bold">Type:</label> <?php echo $topics['objective_name'];?></span></td>
									<td  width="30%"><span class="space"><label class="topicDetail bold">Product:</label>  <?php echo $topics['product_name'];?></span></td>
									
								</tr>
							
							
							<?php }?>
							</table>
						</td>
					<td width="15%" style="vertical-align: top;">
						
						<?php if($row['save_later'] == 1){ ?>
							<div class='actionIconsContainer tooltip-demo tooltop-left editOnTop' style="margin-left: 27px;" id="show_<?php echo $row['id']?>"><div class='actionIcon editIcon' onclick="editInteraction(<?php echo $row['id']?>); return false;"></div></div>
						<?php }else{?>
							<!-- <div class='actionIconsContainer tooltip-demo tooltop-left' style="margin-left: 27px;" id="show_<?php echo $row['id']?>"><div class='actionIcon deleteIcon' onclick="deleteListViewInteraction(<?php echo $row['id']?>,event)"; return false;"><a href="#" class="tooltipLink" rel='tooltip' title="Delete"></a></div></div> -->
						<?php }?>
						  <div class='actionIconsContainer tooltip-demo tooltop-left' style="margin-left: 27px;" id="show_<?php echo $row['id']?>"><div class='' ><a href="<?php echo base_url();?>interactions/add_mirf/<?php echo $row['id'];?>"><div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off-Label Question'>UOQ</span></div></a></div></div>
					</td>
					</tr>
					<tr id="expand_<?php echo $row['id']?>" style="display:none">
						<td colspan="3">
						
							<p class="about">
								<label >Loaction:</label> <?php echo $row['location']; 
									if( $row['location']!='' && ($row['city']!='')){
										echo ", ";	
									}
									if($row['city']!='') 
										echo $row['city']; 
										
								if( $row['region']!='' && ($row['city']!='' || $row['location']!='')){
										echo ", ";	
									}	
									if($row['region']!='')
										echo $row['region'];
																																			 
							 ?> </p>
							<p class="about"><label>Address:</label>  <?php echo $row['address']?></p>
							<p class="notes"><label>Notes:</label>  <?php echo $row['notes']?></p>
						</td>
					</tr>
				
				</table>
				
				
			</td>
			<td>
				
			</td>
		
		</tr>
		
			</table>
			</div>
		
		<?php $i++;}?>
		
	
	

