<style>
.navbar-global {
  background-color: indigo;
}

.navbar-global .navbar-brand {
  color: white;
}

.navbar-global .navbar-user > li > a
{
  color: white;
}

.navbar-primary {
  background-color: #ccc;
  bottom: 0px;
  left: 0px;
  position: absolute;
  top: 88px;
  width: 200px;
  z-index: 8;
  overflow: hidden;
  -webkit-transition: all 0.1s ease-in-out;
  -moz-transition: all 0.1s ease-in-out;
  transition: all 0.1s ease-in-out;
}

.navbar-primary.collapsed {
  width: 60px;
}

.navbar-primary.collapsed .glyphicon {
  font-size: 22px;
}

.navbar-primary.collapsed .nav-label {
  display: none;
}

.btn-expand-collapse {
    position: absolute;
    display: block;
    left: 0px;
    bottom:0;
    width: 100%;
    padding: 8px 0;
    border-top:solid 1px #666;
    color: grey;
    font-size: 20px;
    text-align: center;
}

.btn-expand-collapse:hover,
.btn-expand-collapse:focus {
    background-color: #222;
    color: white;
}

.btn-expand-collapse:active {
    background-color: #111;
}

.navbar-primary-menu,
.navbar-primary-menu li {
  margin:0; padding:0;
  list-style: none;
}

.navbar-primary-menu li a {
  display: block;
  padding: 10px 18px;
  text-align: left;
  border-bottom:solid 1px #e7e7e7;
  color: #333;
}

.navbar-primary-menu li a:hover {
  background-color: #fff;
  text-decoration: none;
  color: #000;
}

.navbar-primary-menu li a .glyphicon {
  margin-right: 6px;
}

.navbar-primary-menu li a:hover .glyphicon {
  color: #4285F4;
}

.main-content {
  margin-left: 200px;
  padding: 20px;
}

.collapsed + .main-content {
  margin-left: 60px;
}
.nav-tabs { 
	border-bottom: 2px solid #DDD; 
}
.nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { 
	border-width: 0;
}
.nav-tabs > li > a { 
	border: none; 
	color: #666; 
}
.nav-tabs > li.active > a, .nav-tabs > li > a:hover {
	border: none; 
	color: #4285F4 !important; 
	background: transparent; 
}
.nav-tabs > li > a::after { 
	content: ""; 
	background: #4285F4; 
	height: 2px; 
	position: absolute; 
	width: 100%; 
	left: 0px; 
	bottom: -1px; 
	transition: all 250ms ease 0s; 
	transform: scale(0); 
}
.nav-tabs > li.active > a::after, .nav-tabs > li:hover > a::after {
 	transform: scale(1); 
}
.tab-nav > li > a::after { 
	background: #21527d none repeat scroll 0% 0%; 
	color: #fff; 
}
.tab-pane {
	padding: 15px 0; 
}
.tab-content{
	padding:20px
}
</style>
<script>
$('.btn-expand-collapse').click(function(e) {
	$('.navbar-primary').toggleClass('collapsed');
});
</script>
<nav class="navbar-primary">
  <ul class="navbar-primary-menu">
    <li>
      <a href="#"><span class="glyphicon glyphicon-user"></span><span class="nav-label">Overview</span></a>
      <a href="#"><span class="glyphicon glyphicon-th-list"></span><span class="nav-label">Details</span></a>
      <a href="#"><span class="glyphicon glyphicon-book"></span><span class="nav-label">Education</span></a>
      <a href="#"><span class="glyphicon glyphicon-move"></span><span class="nav-label">Alliliations</span></a>
      <a href="#"><span class="glyphicon glyphicon-calendar"></span><span class="nav-label">Events</span></a>
      <a href="#"><span class="glyphicon glyphicon-bullhorn"></span><span class="nav-label">Social Media</span></a>
      <a href="#"><span class="glyphicon glyphicon-list-alt"></span><span class="nav-label">Publications</span></a>
      <a href="#"><span class="glyphicon glyphicon-object-align-bottom"></span><span class="nav-label">Clinical Trials</span></a>
    </li>
  </ul>
</nav>
<div class="main-content">
	<div class="row">
		<div class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">Prof Info</a></li>
                  <li role="Overview"><a href="#contact_info" aria-controls="contact_info" role="tab" data-toggle="tab">Contact Info</a></li>
                  <li role="Overview"><a href="#biography" aria-controls="biography" role="tab" data-toggle="tab">Biography</a></li>
                  <li role="Overview"><a href="#references" aria-controls="references" role="tab" data-toggle="tab">References</a></li>
               </ul>
		<!-- End Nav tabs -->
        <!-- Start Tab panels -->
               <div class="tab-content">
                  <div role="tabpanel" class="tab-pane active" id="prof_info">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Panel title</h3> </div> 
                  			<div class="panel-body"> Panel content </div> 
                  		</div>
                  </div>
                  <div role="tabpanel" class="tab-pane" id="contact_info">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Panel title</h3> </div> 
                  			<div class="panel-body"> Panel content </div> 
                  		</div>		
                  </div>
                  <div role="tabpanel" class="tab-pane" id="biography">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Panel title</h3> </div> 
                  			<div class="panel-body"> Panel content </div> 
                  		</div>
                  </div>
                  <div role="tabpanel" class="tab-pane" id="references">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Panel title</h3> </div> 
                  			<div class="panel-body"> Panel content </div> 
                  		</div>
                  </div>
               </div>
        <!-- End Tab panels -->       
        </div>
	</div>
</div>