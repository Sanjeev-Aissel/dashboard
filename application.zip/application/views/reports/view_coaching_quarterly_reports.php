<?php
/**
 * File to 'view' all Reports for client view  
 *
 * @author: Ambarish N
 * @created on: 15-01-11
 */

$autoSearchOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>

<?php
    // prepare array of JS files to insert into queue

    $queued_js_scripts = array(
    'i18n/grid.locale-en','jquery.jqGrid.min.onlyforreports',
                            //    'highcharts 2.1.0',
                            //    'highchartsTheme',
                                'highcharts2_2_2/highcharts_New_4.1',
//                                'highcharts2_2_2/modules/exporting3.0.5',
                                  'highcharts2_2_2/modules/data',
                                'jquery.autocomplete',
                                'jquery/jquery-ui-1.8.16.slider',
                                'jquery/jquery.ui.touch-punch.min'
                                );
    // add the JS files into queue i.e Append to the existing queue
    $this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!--<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/data.js"></script>-->
<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/chosen.jquery.js"></script>

<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<style type="text/css">
/*	#totalOrganizationChart{
		margin-left: 160px;	
	}	
	#pubsChart {
		width: 580px;
	}
	#meshTermsChart {
		width: 400px;
	}
	#substancesChart{
		width: 500px;
	}
	#pubJournalsChart{
		width: 600px;
	}

	#kolsByCountryChart{
		margin-left: -5px !important;
	}
	
	#kolsBySpecialtyChart{
		margin-left: -5px !important;
	}
*/
	#kolsByEventTypeChart {
	     margin: auto;
	}
	#kolsPubChart{
	/*	margin-left: 280px !important; 
		position: absolute;
		min-height: 420px;
    	min-width: 580px;*/
	}
	
	#kolsActivitiesChart{
	/*	margin-left:265px; 
		position: absolute;*/
		min-width: 600px;
		min-height: 420px;
	}
	#kolsActivitiesChart .highcharts-container{
		margin:auto;
	}
	#gbox_listKolsByActivityReportResultSet{
		margin:auto;
	}
	#eventsByTimeline{
	/*	position: absolute !important;*/
		min-width: 700px;
		min-height: 420px;
	}
	#eventsByTimeline .highcharts-container{
		margin: auto;
	} 
	 
	.pieCharts div{
		margin: auto;
	}
	
	#contents{
		text-align:center;
	}
	
	#eventsByActivityContainer fieldset {
		width:98%;
		padding:2px;
	/*	margin-left:360px; */ 
	}
	
	#eventsByActivityContainer fieldset legend{
		margin: 0 46%;
	}
	#searchLeftBar{
		display: inline;
		float: left;
	}
	
	#timeLineSliderContainer{
		display: block;
		padding-top: 25px;
	}
	
	#kolId{
		width:150px;
	}
	/*
	#scatTable{
		width:auto;
	}*/
	.span-4 {
		width:170px;
	}
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
		border-top:1px dotted #999999;
		overflow:visible;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url("<?php echo base_url();?>images/sprite_facetsearch_v7.png") no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:10px !important;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.highcharts-axis text{
		fill:#000000 !important;
		color:#000000;
	}
	
	th.ui-th-column div{
        white-space:normal !important;
        height:auto !important;
        padding:1px;
    }
    #lui_kolsProfileScore{
    	width:0;
    }
/*    #profileScoreGridContainer{
    	margin-left:133px;
    	width:800px;
    }

    .gridWrapper{
    	overflow: scroll !important;
    }
  */
    .myclass td{
    	color:blue !important;
    }
    
	 .professionalExp1{
	 	color:#2222BB;
	 }
	 .researchColumn1{
	 	color:#DD2222;
	 }
	 
	 .eventsColumn1{
	 	color:brown;
	 }
	
	 #profileScoreGridContainer label.facet-toggle {
	    background: url("<?php echo base_url()?>images/kolm-sprite-image.png") no-repeat scroll -8px -91px transparent;
	}
	 #profileScoreGridContainer label.collapsed {
	    background-position: -28px -91px;
	}
	
	 #profileScoreGridContainer label.facet-toggle {
	    cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    position: relative;
	    right: 0;
	    text-indent: -99999px;
	    top: 14px;
	    width: 11px;
	    margin-left: 19px;
	}
	#profileScoreGridContainer label{
		font-weight:normal;
	}
	
/*	#eventsByActivityContainer #gridContainer{
		overflow: auto !important;
	}
*/ 
	#refinedByContainer{
		border:0px;
	}
	#kolsActivitiesChart, #gridContainer{
		width: 850px !important;
	}
</style>
	
	<script type="text/javascript">
var tabReportClick=0;
	var activityTitle = "<?php echo lang("Reports.ActivityTitle");?>";
	var kolNameHeader = "<?php echo lang("track.KOLName");?>";
	var eventsHeader = "<?php echo lang("Mykols.Events");?>";
	var affiliationsHeader = "<?php echo lang("Mykols.Affiliations");?>";
	var publicationsHeader = "<?php echo lang("Mykols.Publications");?>";
	var trialsHeader = "<?php echo lang("MyLists.Trials");?>";
	var totalHeader = "<?php echo lang("MyLists.Total");?>";
	var section = "overAllReport";
        jqgridIds	= new Array('listCoachingsResultSet');
	var ie ='';
	jqgridIds	= new Array('kolsProfileScore','listKolsByActivityReportResultSet');
	jqgridMinWidth	= 881;
	jqgridMaxWidth	= 1181;
	if(isiPad===true){
		jqgridMinWidth	= jqgridWidthForiPad;
	}
function showAction(id){

	

	$('#show_'+id).show();

}



function hideAction(id){

	

	$('#show_'+id).hide();

}


$(document).ready(function(){
//     list_coaching_grid();
//list_kols_grid();



		$("#list").click(function(){
                
			loadChart();
	
		});
               
		$('.tabsWrapper ul.tabsContainer li').click(function (){
			var currentTab	= $(this).attr('name');
			$('.tabsWrapper ul.tabsContainer li').removeClass('current');
			$('.tabsWrapper .tabsContent div.tabContent').hide();
			$(this).addClass('current');
			$('.tabsWrapper .tabsContent div.'+currentTab).show();
		});
              
   
	<?php 
    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			if(preg_match('/MSIE/i',$u_agent)){
			
			
    	?>
    	ie = true;	
        <?php }?>
	
	<?php if(isset($specialty)){
	?>
	var specialtyId = '<?php echo $specialty ?>';
	var kolIdForProfileScore = '<?php echo $kolIdForProfileScore ?>';
	showKolsIndividualCounts(specialtyId,kolIdForProfileScore);
	<?php }?>

	
});
	var reportSection='<?php echo $reportSection;?>';
	var options, a;
	
	// Autocomplet Options for the 'role' field 
  	var SpecialtyNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
			onSelect : function(event, ui) {specialtyBox('form')}, 
			<?php echo $autoSearchOptions;?>
		};	

	// Autocomplet Options for the 'country' field
	var countryNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
			onSelect : function(event, ui) {countryBox('form')},
			<?php echo $autoSearchOptions;?>
		};	
	// Autocomplet Options for the 'state' field
	var stateNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
			onSelect : function(event, ui) {stateBox('form')},
			<?php echo $autoSearchOptions;?>
		};

	$(document).ready(function(){
             $("#kolName").remove();
             $(".filterSearchIcon").remove();
             //$("h3").remove();
		var addKolsCustomFilters={
			title: "Add Custom Filters",
			modal: true,
			autoOpen: false,
			width: 400,
			height: 400,
			position: ['center', modalBoxTopPosition],
			dialogClass: "microView",
			draggable:false,
			open: function(){
	
			}
		};
		$( "#addKolsCustomFilters" ).dialog(addKolsCustomFilters);
	});
	$(document).ready(function(){
		$("#chartType").chosen({disable_search_threshold: 10});
		$("#specialtyForProfileScore").chosen();
		});
	function getSavedFilters(){
		$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addKolsCustomFilters').dialog("open");
		$('#addKolsCustomFiltersContainer').load(base_url+'kols/get_saved_filters/');
	}
	var sfId = '';
	<?php if($arrFilterById['id'] != ''){?>
		sfId = parseInt(<?php echo $arrFilterById['id'];?>);
	<?php }?>
	$(document).ready(function(){
			<?php if($arrFilterById['id'] != ''){?>
				var sfId = parseInt(<?php echo $arrFilterById['id'];?>);
			<?php }?>
		});
	function displaySelectedChart1(){
			if(sfId != ''){
				activeCustmFilters(sfId);
			}else{
				//displaySelectedChart(); 
			}
		}
                
                
   function getChartData(){
       $("#filerMessage").empty();
       $.ajax({
				url:'<?php echo base_url()?>/reports/get_quarterly_data/',
				dataType:'html',
                                type:"post",
                                data:filters,
				success:function(returndata){
                                    if(returndata=="no data"){
                                        $("#numericReportContainer").empty();
                                         $("#filerMessage").append("<center>No Results Found.</center>");
                                     }
                                     else{
                                        $("#datatable").empty();
					$("#datatable").append(returndata);
                                        loadChart();
                                     }
                                        
				}
                });
       
    }


                function loadChart() {
            
//                    $('#numericReportContainer').highcharts({
//        chart: {
//            type: 'column'
//        },
//        title: {
//            text: 'Customer Engagement Form'
//        },
//        xAxis: {
//            categories: name
//        },
//        credits: {
//            enabled: false
//        },
//        series: data
//    });


$('#numericReportContainer').highcharts({
     
        data: {
            table: 'datatable'
        },
        chart: {
            type: 'column'
        },
                    credits: {
      enabled: false
  },
        title: {
            text: 'Customer Engagement Form Quarterly Report'
        },
        yAxis: {
            allowDecimals: false,
            title: {
                text: 'Score'
            }
        },
        xAxis: {
            allowDecimals: false,
            title: {
                text: 'Time Range'
            }
        },
        tooltip: {
            formatter: function () {
                //return '<b>' + this.series.name + '</b><br/>' + this.point.y
                return "Score:"+this.point.y; 
            },
 
        
            }
    });
  $('.highcharts-legend').remove();             
}



  function export_excel(){



			

			var excelFilters = '';



			

		

				$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

					if($(this).val() != ''){

						var filterName = $(this).attr('name');
                                                if(filterName=="username")
                                                    filterName="MSL/MML Name";
                                                if(filterName=="specialty")
                                                    filterName="Therapeutic Area";
                                                if(filterName=="status")
                                                    filterName="Engagement Status";
                                                if(filterName=="kol_id")
                                                    filterName="HCP Name(s)";
                                                
						var filterValue = $(this).val();

						excelFilters += filterName+" : "+filterValue+",";

					}
//                                        alert(excelFilters);

				});

				//$("#excel-filters").val(excelFilters);

				var selectedOPtion = $(".ui-pg-selbox").val();

				$(".ui-pg-selbox option:last").attr('selected','selected');

		    	$('.ui-pg-selbox').trigger('change');

		    	if($("#gridKolsListingResultSet").html() != null )

		    		var arrIds = jQuery("#gridKolsListingResultSet").jqGrid('getDataIDs');

		    	else

		    		var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//		    if($('#orgIntaerctionContainer').css('display')!='block'){
//
//	    	
//
//	    		$('#ids').val(arrIds);
//
//	    	}



	    	
             
	    	$("#refineFilters").val(filters);

                
                $('#ids').val(arrIds);
	    	$("#excel-filters").val(excelFilters);

	    //	return false;
//
	    	$('#export').submit();

	    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

	    	$('.ui-pg-selbox').trigger('change');

		}
                
	 </script>
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
<style>/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.refinedBySideBar{
		position: absolute; 
		right: 0px;
		z-index: 100;
	}
	#chartType{
		margin:0px;
	}
	#chartType_chzn{
		vertical-align: top;
	}
<?php 
	if($reportSection == 'segmentation'){
		echo '#chartSelect{display:none;}';
		//echo '.expandRightSideBar{margin-left: -7px !important;}';
	}else{
		echo '#chartSelect{display:block;}';
	}
	if($reportSection == 'activity'){
		echo '#timeLineSliderContainer{display:none;}';
	}
	if($reportSection == 'rating'){
		echo '#dashboardTable{display:none;}';
	}
?>
</style>
<div id="container">
	 <div id="interactionsContainer" <?php if($reportFlag==1){?> style="display:none" <?php }?>>
		<div class="tabsWrapper" id="test">
			<ul class="tabsContainer">
				<li class="current" name="tab0"><a id="list" href="#">Report</a></li>
				<!--<li name="tab1"><a id="report" href="#">Chart</a></li>-->
			</ul>
			<div class="tabsContent">
				<div class="tab0 tabContent" style="display:block;">
<!--					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;top: -27px;">
						<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
					</div>-->
                                  
					<div id="gridKolsListing">
			<div class="gridWrapper">
				<div id="gridKolsListingPagintaion"></div>
                                <table id="gridKolsListingResultSet"><span id="filerMessage">Please select filter for report.</span></table>
			</div>
		</div>
				</div>
				<div class="tab1 tabContent" style="display:block;">
					<div id="numericReportContainer"></div>
                                        <table hidden id="datatable">
   
</table>
                                        <div id="barChartContainer" style="margin: 0 auto; width:350px;">
   
               </div>
				</div>
                            
				<div class="tab2 tabContent">
                             
					<div id="pageChartContainer">
						<table id="chartTable" class="tableSections">
							<tr class="tableHeader">
								<th class="rightBorder">Interactions By Topic</th>
								<th>Interactions By Channel</th>
							</tr>
							<tr>
								<td class="rightBorder">
									<div class="eachChart">
										<div id="interactionsByTopic"></div>
									</div>
								</td>
								<td>
									<div class="eachChart">
										<div id="interactionByChannel"></div>
									</div>
								</td>
							</tr>
							<tr class="tableHeader">
								<th class="rightBorder">Interactions By Employees</th>
								<th>Interactions By Month</th>
							</tr>
							<tr>
								<td class="rightBorder">
									<div class="eachChart">
										<div id="interactionsByEmployee"></div>
									</div>
								</td>
								<td>
									<div class="eachChart">
										<div id="interactionsByMonth"></div>
									</div>
								</td>
							</tr>
						</table>
					</div>
				</div>
                <div  style="display:block;" class="tab3 tabContent">
					<div class="calenderContent" id="calenderContent">&nbsp;<div id='calendarId'></div></div>
				</div>
			</div>
		</div>
	</div>
	<form action="<?php echo base_url()?>reports/export_coaching_report/" method='post' id="export">
        <input type="hidden" id="ids" name="coaching" value=""></input>
        <input type="hidden" name="filters" id="excel-filters" />
        <input type="hidden" name="filter" id="refineFilters" />
    </form>
	<!-- Container for List Maodel box  -->
	<div id="categoryModalBox">
		<div class="addListContent" ></div>
	</div>
	
	<!-- Container to add Custom filters -->
	<div id="addKolsCustomFilters1"></div>
	<div id="addKolsCustomFilters" class="addCustomFilters">
		<div id="addKolsCustomFiltersContainer" class="profileContent"></div>
	</div>
</div>
	<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array(
	'i18n/grid.locale-en','jquery.jqGrid.min.onlyforreports',
							//	'highcharts 2.1.0',
							//	'highchartsTheme',
								'highcharts2_2_2/highcharts3.0.5',
								'highcharts2_2_2/modules/exporting3.0.5',
								'jquery.autocomplete',
								'jquery/jquery-ui-1.8.16.slider',
								'jquery/jquery.ui.touch-punch.min',
								'kol.publications.chart');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>

