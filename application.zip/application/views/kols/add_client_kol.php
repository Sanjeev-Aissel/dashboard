<?php 
/**
 * Contains Form file to add Neqw Kol request
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.requsted_kols
 * @created 13-6-2012
 */

/** Start of the FreshDesk SSO Section */
//With Trailing slashes
$userName	= $this->session->userdata('user_full_name');
$userMailId = $this->session->userdata('email');


?>
 <!-- 2nd Plugin for Validation 
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>-->
<style type="text/css">
.requestedKols label {
	font-size: 11px;
}

.requestedKols input[type="text"] {
	width: 174px;
}

.requestedKols select {
	width: 182px;
}

input.error {
	background-position: 10px center;
	background-repeat: no-repeat;
}

label.error {
	padding: 2px 0px !important;
	color: red !important;
	background: none !important;
	border-color:none !important;
	border: none !important;
}

select.error {
	border: 1px solid red !important;
}

screen.css  error,.notice,.success {
	border: red;
	margin-bottom: 1em;
	padding: 0.8em;
}
#requestKol{
	letter-spacing: 1px;
}

</style>
<script type="text/javascript">
var validationRules	=  {
		
		specialty: {
			required:true
		},
		first_name: {
			required:true
		},
		
		last_name: {
			required:true
		},
		country_id: {
			required:true
		},
		primary_phone: {
			 maxlength: 16,
			 minlength:6,
			  phoneUS: true
		}
		
	};

var validationMessages = {
		specialty: {
			required: "Required"
						
		},
		country_id: {
			required: "Required"
						
		},
		first_name: {
			required: "Required"
						
		},
		last_name: {
			required: "Required"
						
		}
		
};
	$('#requestKol').click(function(){
		if(!$("#requestKolForm").validate().form()){
			return false;
		}

		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN)
			jAlert("The KOL Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
		else
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		
		$('.msgBox').removeClass('success');
		$('.msgBox').addClass('notice');
		$('.msgBox').show();
		$('.msgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/save_profile_request',
			type:'post',
			dataType:'json',
			data:$('#requestKolForm').serialize(),
			success:function(returnData){
				if(returnData.saved==true){
					var datarow = {
							id:returnData.arrKol.id,
							created_by		:	returnData.arrKol.created_by,
							kol_id:returnData.arrKol.kol_id,
							micro:"<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+returnData.kol_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>",
							status:returnData.arrKol.status,
							kol_name:returnData.arrKol.kol_name,
							request_for:returnData.arrKol.request_for,
							name:returnData.arrKol.org_name,
							user_full_name:	returnData.arrKol.user_full_name
						};
					//if the operation is from the client requested kols page then add to grid otherwise just show the message
					<?php $refUrl = $_SERVER['HTTP_REFERER']; $arrSegs = explode("/",$refUrl);
						if($arrSegs[sizeof($arrSegs)-1] == '')
							unset($arrSegs[sizeof($arrSegs)-1]); 
						if($arrSegs[sizeof($arrSegs)-1] != 'show_client_requested_kols') {?>
							//do nothing
					<?php }else { ?>
						if(!returnData.is_manager)
							var su=jQuery("#myPendingApprovalsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow);
						else
							datarow.approved_by =  datarow.user_full_name;
						var dt=jQuery("#allProfileRequestsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow); 
					<?php }?>
						
					$('.msgBox').text(returnData.msg);
					$('.msgBox').fadeOut(1500);
					setTimeout(closeDialog,1500);
				}else{
					$('.msgBox').text(returnData.msg);
					$('.msgBox').fadeOut(2500);
				}
			}
		});
	});

	$("#checkDuplicates").click(function(){
		if(!$("#requestKolForm").validate().form()){
			return false;
		}
		
		$('.msgBox').removeClass('success');
		$('.msgBox').addClass('notice');
		$('.msgBox').show();
		$('.msgBox').html("Please wait while we check if the name already exists in the database. <img src='<?php echo base_url()?>images/ajax_loader_black.gif' />");

		$.ajax({
			url:'<?php echo base_url()?>requested_kols/check_similar_names',
			type:'post',
			dataType:'json',
			data:$('#requestKolForm').serialize(),
			success:function(returnData){
				if(returnData.hasDuplicates){
					$('.msgBox').text("Similar Names found");
					$('.msgBox').fadeOut(1500);
					$("#similarNames").html(returnData.duplicates);
					var currentName = $("#first_name").val();
					if($("#middle_name").val() != '')
						currentName = currentName+" "+$("#middle_name").val();
					if($("#last_name").val() != '')
						currentName = currentName+" "+$("#last_name").val();
					$("#requestName label").html(currentName);
					$("#addNewKol").dialog('option','width',750);
					$("#addNewKol").dialog('option','position',['center', 80]);
					$("#requestKolForm").fadeOut(1500,function(){
						$("#addNewKol").dialog('option','position',['center', 80]);
					});
				}else{
					$('.msgBox').text("No duplicates found");
					$('#requestKol').click();
				}
			}
		});
		
	});

	function closeDialog(){
		$("#addNewKol").dialog('option','width',550);
		$("#addNewKol").dialog('option','position',['center', 80]);
		$("#addNewKol").dialog("close");
	}	

	/**
	* Returns the list of States of the Selected Country ID
	*/
	function getStatesByCountryId(){
		
		// Show the Loading Image
		$("#loadingStates").show();
		
		var countryId=$('#country_id').val();
		var params = "country_id="+countryId;	
		$("#state_id").html("<option value=''>-- Select State --</option>");
		$("#city_id").html("<option value=''>-- Select City --</option>");
		var states = document.getElementById('state_id');
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {					
					var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);				
					});
				
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});		
	}

	/**
	* Returns the list of Cities of the Selected State
	*/
	function getCitiesByStateId(){
		// Show the Loading Image
		$("#loadingCities").show();
		
		var stateId=$('#state_id').val();
		$("#city_id").html("<option value=''>-- Select City</option>");	
		var cities = document.getElementById('city_id');
		var params = "state_id="+stateId;	
		
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {	
							
				var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);				
				});
                                $("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				
			},
			complete: function(){
				$("#loadingCities").hide();
			}		
		});		
		
	}

	$(function(){
		$("#requestKolForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
		    phone_number = phone_number.replace(/\s+/g, ""); 
			return this.optional(element) || phone_number.length > 9 &&
				phone_number.match(/\(?[0-9]{2,}\)?(-?)\(?[0-9]{3,}?\)?(-?)[0-9]{4,}/);
		}, "Please specify a valid phone number");

		getStatesByCountryId();;
	});

	function showBasicDetails(){
		var val = $('input:radio[name=profile_type]:checked').val();
		window.open("http://aisselkolm.freshdesk.com/solution/categories/43378/folders/70608/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile- [^]");
	}

	function saveDupliecte(){
		$('#requestKol').click();
	}

	function startOver(){
		$("#addNewKol").dialog('option','width',550);
		$("#addNewKol").dialog('option','position',['center', 80]);
		$("#requestKolForm").fadeIn(1500);
		$("#similarNames").html("");
	}
</script>


<div class="msgBox"></div>
			
<div id="similarNames">
	
</div>
				
<form action="save_client_requested_kol" method="post" id="requestKolForm" name="persnoalForm">
	<div style="margin-left:75px">
		<input type="radio" name="profile_type" value="Full Profile" checked="checked">Full Profile</input>
		<input type="radio" name="profile_type" value="Basic Plus">Basic Plus </input>
		<input type="radio" name="profile_type" value="Basic">Basic</input>
		<a href="<?php echo getSSOUrl($userName, $userMailId);?>&redirect_to=/solution/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile-" target="_NEW">Compare</a>
	</div>
	<table class="requestedKols">
		
		<tbody>
		<tr>
			<td class="alignRight">
			
				
			
			</td>
			<td class="alignRight1">
				
			</td>
			<td class="alignRight1">
			
			</td>
		</tr>
		<tr>
		
			<td class="alignRight">
				<label for="salutation">Salutation :</label>
			</td>
			<td>
				<select name="salutation" >
					<option value="0">--- Select ---</option>
						<?php 
						foreach($arrSalutations as $key => $value){
						echo '<option value="'.$key.'">'.$value.'</option>';
						}
					?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="alignRight"><label for="">First Name <span class="required">*</span>:</label></td>
			<td>
				<input type="text" name="first_name" id="first_name" value="" maxlength="50" class="required"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="middle_name">Middle Name :</label>
			</td>
			<td>
				<input type="text" name="middle_name" id="middle_name" value=""  maxlength="50"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="last_name">Last Name<span class="required">*</span> :</label>
			</td>
			<td>
				<input type="text" name="last_name" id="last_name" value=""  maxlength="50" class="required"></input>
			</td>
		</tr>
		
		
		<tr>
			<td class="alignRight">
				<label for="specialty">Specialty<span class="required">*</span> :</label>
			</td>
			<td>
				<select name="specialty" id="specialty" class="required">
					<option value="">--- Select ---</option>
						<?php 
						foreach($arrSpecialties as $key => $value){
						echo '<option value="'.$key.'">'.$value.'</option>';
						}
					?>
				</select>
			</td>
		</tr>
		
		<tr>
			<td class="alignRight">
				<label for="orgName">Organization Name :</label>
			
			</td>
			<td>
				<input type="text" name="org_id" id="orgName" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="title">Title :</label>
			
			</td>
			<td>
				<input type="text" name="title" id="title" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="division">Department Name :</label>
			
			</td>
			<td>
				<input type="text" name="division" id="division" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="address1">Address:</label>
			
			</td>
			<td>
				<input type="text" name="address1" id="address1" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="fax">Fax :</label>
			
			</td>
			<td>
				<input type="text" name="fax" id="fax" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="primaryPhone">Phone:</label>
			
			</td>
			<td>
				<input type="text" name="primary_phone" id="primaryPhone" value=""></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="primaryEmail">Email:</label>
			
			</td>
			<td>
				<input type="text" name="primary_email" id="primaryEmail" value="" class="email"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="countryId1">Country<span class="required">*</span> :</label>
			</td>
			<td>
				<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required">
					<option value="">-- Select --</option>
					<?php foreach( $arrCountry as $country ){ ?>
					<option value="<?php echo $country['country_id'];?>" <?php if($country['country_id']==254){?> selected="selected" <?php }?>>
					<?php echo $country['country_name'];?>
					</option>
					<?php }?>
				</select>
		<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
			</td>
		</tr>
		<tr>
			<td class="alignRight">									
				<label for="stateId1">State / Province :</label>
			</td>
			<td>
				<select name="state_id" id="state_id" onchange="getCitiesByStateId();">		
					<option>Select state</option>
				</select>
				<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="cityId1">City :</label>
			</td>
			<td>
				<select name="city_id" id="city_id">
					<option >Select city</option>		
				</select>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="npiNum">NPI Number :</label>
			</td>
			<td>
				<input type="text" name="npi_num" id="npiNum" value="" ></input>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<div class="formButtons">	
					<input type="button" value="Submit" name="submit" id="requestKol" style="display: none;"></input>
				</div>
				<div class="formButtons">	
					<input type="button" value="Add" name="submit" id="checkDuplicates"></input>
				</div>
			</td>
		</tr>
  </tbody>
  </tabel>
	    
</form>
               
		<!-- End of Personal and Professional Information -->