<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>assets/js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>assets/js/jquery.validate1.9.min.js"></script>
<script type="text/javascript">
function loadGridDetails(type){
	$.ajax({
		type: "post",
		dataType:"json",
		data: {
			'type':type
		},
		url: base_url+'master_data/load_grid_types',
		success: function(returnData){
			load_generic_grid(returnData,type);
		}		
	});
}
function load_generic_grid(arrJsonData,type){
	var sortname = '';
    var sortorder = "asc";
    var columnNamesForGrid = [];
    var columnDataForGrid = [];
    switch(type){
    case 'Specialties':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Specialities"));
        sortname = 'specialty';
        columnNamesForGrid = ['Id','Specialty','Keys_Merged','Action'];
        columnDataForGrid	= [
            {name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
            {name:'specialty',index:'specialty',width:60, search:true},
            {name:'keys_merged',index:'keys_merged',width:20, search:true},
            {name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}
        ];
    break;
    case 'Organization_Types':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Organization Type"));
	     sortname = 'type';
	     columnNamesForGrid	= ['Id','Organization_Types','Keys_Merged','Action'];
	     columnDataForGrid	= [
		     {name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
		     {name:'type',index:'type',width:60, search:true},
		     {name:'keys_merged',index:'keys_merged',width:20, search:true},
		     {name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}
		 ];
   	break;
    case 'Engagement_Types':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Engagement Type"));
	     sortname = 'engagement_type';
	     columnNamesForGrid	= ['Id','Engagement_Types','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'engagement_type',index:'engagement_type',width:60, search:true},	   		
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Event_Topics':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Event Topics"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Event_Org_Types':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Event Organizer Type"));
	     sortname = 'type';
	     columnNamesForGrid	= ['Id','Type','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'type',index:'type',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Event_Roles':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Event Roles"));
	     sortname = 'role';
	     columnNamesForGrid	= ['Id','Role','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'role',index:'role',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action', index:'action', align:'center', search:false, resizable:false, width:5,sortable:false}    			
 	   	];
   	break;
    case 'Titles':
    	$("#genericContainer").dialog(getModalLayout("Merge Titles"));
	     sortname = 'title';
	     sortorder = sortorder;
	     columnNamesForGrid	= ['Id','Title','Abbrevation','Client ID', 'Status','Keys_Merged','Actions'];
 		columnDataForGrid	= [
 			{name:'id', index:'id', hidden:true, search:false},
				{name:'title', index:'title', search:true, firstsortorder:'asc'},
		   		{name:'abbr', index:'abbr', search:true},
		   		{name:'client_id', index:'client_id', hidden:true, search:true},
				{name:'is_active', index:'is_active', search:false, formatter: function (cellvalue, options, rowObject) {
					var arrStatus = ["Inactive","Active"];
	   				return arrStatus[cellvalue];
	   			}},
	   			{name:'keys_merged',index:'keys_merged', search:true},
				{name:'action', index:'action', align:'center', search:false, resizable:false, width:25,sortable:false}   			
 	   	];
   	break;
    case 'Product':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Product"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},	   		
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Phone_Type':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Phone Type"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Email_Type':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Email Type"));
	     sortname = 'type';
	     columnNamesForGrid	= ['Id','Type','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'type',index:'type',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Discussion_Type':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Discussion Type"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Topics':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Topics"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Interaction_Type':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Interaction Type"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Interaction_Location':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Interaction Location"));
	     sortname = 'name';
	     columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
 		columnDataForGrid	= [
 			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
 	   		{name:'name',index:'name',width:60, search:true},
 	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
 			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
 	   	];
   	break;
    case 'Requested_By':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Requested By"));
	     sortname = 'requested_by';
    		columnNamesForGrid	= ['Id','Requested_by','Keys_Merged','Action'];
    		columnDataForGrid	= [
    			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
    	   		{name:'requested_by',index:'requested_by',width:60, search:true},
    	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
    			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
    	   	];
    break;
    case 'Paid_By':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Paid By"));
	     sortname = 'paid_by';
    		columnNamesForGrid	= ['Id','Paid_by','Keys_Merged','Action'];
    		columnDataForGrid	= [
    			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
    	   		{name:'paid_by',index:'paid_by',width:60, search:true},	
    	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},   		
    			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
    	   	];
    break;
    case 'Payment_Type':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Payment Type"));
	     sortname = 'name';
    		columnNamesForGrid	= ['Id','Name','Keys_Merged','Action'];
    		columnDataForGrid	= [
    			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
    	   		{name:'name',index:'name',width:60, search:true},
    	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	   		
    			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
    	   	];
    break;
    case 'Payment_Currency':
    	$("#genericContainer").dialog(getModalLayout("Add/Edit Payment Currency"));
	     sortname = 'currency_name';
    		columnNamesForGrid	= ['Id','Currency Name','Keys_Merged','Action'];
    		columnDataForGrid	= [
    			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
    	   		{name:'currency_name',index:'currency_name',width:60, search:true},	
    	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},   		
    			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
    	   	];
    break;
 case 'conf_event_types':
	$("#genericContainer").dialog(getModalLayout("Add/Edit Event Type"));
	     sortname = 'event_type';
		columnNamesForGrid	= ['Id','Event Type','Keys_Merged','Action'];
		columnDataForGrid	= [
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'event_type',index:'event_type',width:60, search:true},
	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	
			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
	   	];
break;
case 'event_sponsor_types':
	$("#genericContainer").dialog(getModalLayout("Add/Edit Sponsor Type"));
	     sortname = 'type';
		columnNamesForGrid	= ['Id','Sponsor Type','Keys_Merged','Action'];
		columnDataForGrid	= [
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'type',index:'type',width:60, search:true},
	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	
			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
	   	];
break;
case 'conf_session_types':
	$("#genericContainer").dialog(getModalLayout("Add/Edit Session Type"));
	     sortname = 'type';
		columnNamesForGrid	= ['Id','Session Type','Keys_Merged','Action'];
		columnDataForGrid	= [
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'session_type',index:'session_type',width:60, search:true},
	   		{name:'keys_merged',index:'keys_merged',width:20, search:true},	
			{name:'action',index:'action',width:5, align:'center',search:false, resizable:false,sortable:false}    			
	   	];
break;				
    }  
    var data = {
            "page": "1",
            "rows":arrJsonData
    };
    $('#gridListing').html('');
    $('#gridListing').html('<div class="gridWrapper"><div id="gridListingPagintaion"></div><table id="gridListingResultSet"></table><div>');
    var grid = $("#gridListingResultSet");
    grid.jqGrid({
    	colNames:columnNamesForGrid,
    	colModel:columnDataForGrid,  
        pager: '#gridListingPagintaion',
        datatype: "jsonstring",
        datastr: data,
        jsonReader: { repeatitems: false },
        rowNum: 10,
    	rownumbers: true,
        viewrecords: true,
        multiselect:true,
        caption:type,
        sortname:sortname,
	    sortorder:sortorder,
        height: "auto",
        autowidth: true,
        ignoreCase: true,
        rowList:paginationValues
    });
	grid.jqGrid('navGrid','#gridListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});

	switch(type){
	case 'Specialties':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge-Specialties",buttonicon : "ui-icon-circle-check", title:"Merge-Specialties",
			onClickButton:function (){
				var selectedSpec	= $(this).getGridParam('selarrrow');
				if(selectedSpec.length>0){
					mergeSpecialtiesById(selectedSpec);
				}else{
					jAlert('Please select at least one Specialty');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedSpecialties(s);
				}else{
					jAlert('Please select at least one Specialty');
				}
			}
		});
	break;
	case 'Organization_Types':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge-Organization-Type",buttonicon : "ui-icon-circle-check", title:"Merge-Organization-Type",
			onClickButton:function (){
				var selectedOrgType	= $(this).getGridParam('selarrrow');
				if(selectedOrgType.length>0){
					mergeOrgTypesById(selectedOrgType);
				}else{
					jAlert('Please select at least one Organization Type');
				}
			}
		});	
	break;
	case 'Engagement_Types':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge-Engagement-Type",buttonicon : "ui-icon-circle-check", title:"Merge-Engagement-Type",
			onClickButton:function (){
				var selectedEngType	= $(this).getGridParam('selarrrow');
				if(selectedEngType.length>0){
					mergeEngTypesById(selectedEngType);
				}else{
					jAlert('Please select at least one Engagement Type');
				}
			}
		});	
	break;
	case 'Event_Topics':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge-Event-Topics",buttonicon : "ui-icon-circle-check", title:"Merge-Event-Topics",
			onClickButton:function (){
				var selectedEventTopic	= $(this).getGridParam('selarrrow');
				if(selectedEventTopic.length>0){
					mergeEventTopicsById(selectedEventTopic);
				}else{
					jAlert('Please select at least one Event Topic');
				}
			}
		});	
	break;
	case 'Event_Org_Types':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Event Organizer Types",buttonicon : "ui-icon-circle-check", title:"Merge Event Organizer Types",
			onClickButton:function (){
				var selectedEventOrgType = $(this).getGridParam('selarrrow');
				if(selectedEventOrgType.length>0){
					mergeEventOrgTypesById(selectedEventOrgType);
				}else{
					jAlert('Please select at least one Event Organizer Type');
				}
			}
		});	
	break;
	case 'Event_Roles':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Event Roles",buttonicon : "ui-icon-circle-check", title:"Merge Event Roles",
			onClickButton:function (){
				var selectedEventRole = $(this).getGridParam('selarrrow');
				if(selectedEventRole.length>0){
					mergeEventRolesById(selectedEventRole);
				}else{
					jAlert('Please select at least one Event ROle');
				}
			}
		});	
	break;
	case 'Titles':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Titles",buttonicon : "ui-icon-circle-check", title:"Merge Titles",
			onClickButton:function (){
				var selectedTitle = $(this).getGridParam('selarrrow');
				if(selectedTitle.length>0){
					mergeTitlesById(selectedTitle);
				}else{
					jAlert('Please select at least one Title');
				}
			}
		});	
	break;
	case 'Phone_Type':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Phone Type",buttonicon : "ui-icon-circle-check", title:"Merge Phone Type",
			onClickButton:function (){
				var selectedPhoneType = $(this).getGridParam('selarrrow');
				if(selectedPhoneType.length>0){
					mergePhoneTypeById(selectedPhoneType);
				}else{
					jAlert('Please select at least one Phone Type');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedPhones(s);
				}else{
					jAlert('Please select at least one Phone Type');
				}
			}
		});		
	break;
	case 'Email_Type':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Email Type",buttonicon : "ui-icon-circle-check", title:"Merge Email Type",
			onClickButton:function (){
				var selectedEmailType = $(this).getGridParam('selarrrow');
				if(selectedEmailType.length>0){
					mergeEmailTypeById(selectedEmailType);
				}else{
					jAlert('Please select at least one Email Type');
				}
			}
		});	
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedEmails(s);
				}else{
					jAlert('Please select at least one Email Type');
				}
			}
		});
	break;
	case 'Product':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Product",buttonicon : "ui-icon-circle-check", title:"Merge Product",
			onClickButton:function (){
				var selectedProduct = $(this).getGridParam('selarrrow');
				if(selectedProduct.length>0){
					mergeProductById(selectedProduct);
				}else{
					jAlert('Please select at least one Product');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedProducts(s);
				}else{
					jAlert('Please select at least one Product');
				}
			}
		});		
	break;
	case 'Discussion_Type':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Discussion Type",buttonicon : "ui-icon-circle-check", title:"Merge Discussion Type",
			onClickButton:function (){
				var selectedDiscussionType = $(this).getGridParam('selarrrow');
				if(selectedDiscussionType.length>0){
					mergeDiscussionTypeById(selectedDiscussionType);
				}else{
					jAlert('Please select at least one Discussion Type');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedDiscussion(s);
				}else{
					jAlert('Please select at least one Discussion Type');
				}
			}
		});	
	break;
	case 'Topics':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Interaction Topic",buttonicon : "ui-icon-circle-check", title:"Merge Interaction Topic",
			onClickButton:function (){
				var selectedTopics = $(this).getGridParam('selarrrow');
				if(selectedTopics.length>0){
					mergeTopicsById(selectedTopics);
				}else{
					jAlert('Please select at least one Interaction Topic');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedTopics(s);
				}else{
					jAlert('Please select at least one Interaction Topic');
				}
			}
		});	
	break;
	case 'Interaction_Type':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Interaction Type",buttonicon : "ui-icon-circle-check", title:"Merge Interaction Type",
			onClickButton:function (){
				var selectedIntTypes = $(this).getGridParam('selarrrow');
				if(selectedIntTypes.length>0){
					mergeInteractionTypeById(selectedIntTypes);
				}else{
					jAlert('Please select at least one Interaction Type');
				}
			}
		});	
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedModes(s);
				}else{
					jAlert('Please select at least one Interaction Mode');
				}
			}
		});	
	break;
	case 'Interaction_Location':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Interaction Location",buttonicon : "ui-icon-circle-check", title:"Merge Interaction Location",
			onClickButton:function (){
				var selectedIntLocations = $(this).getGridParam('selarrrow');
				if(selectedIntLocations.length>0){
					mergeInteractionLocationById(selectedIntLocations);
				}else{
					jAlert('Please select at least one Interaction Location');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedLocations(s);
				}else{
					jAlert('Please select at least one Interaction Location');
				}
			}
		});	
	break;
	case 'Requested_By':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Payments Requested By",buttonicon : "ui-icon-circle-check", title:"Merge Payment Requested By",
			onClickButton:function (){
				var selectedRequestedBy = $(this).getGridParam('selarrrow');
				if(selectedRequestedBy.length>0){
					mergeRequestedById(selectedRequestedBy);
				}else{
					jAlert('Please select at least one Payment Requested By');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToRequestedBy(s);
				}else{
					jAlert('Please select at least one Payment Requested By');
				}
			}
		});	
	break;
	case 'Paid_By':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Payments Paid By",buttonicon : "ui-icon-circle-check", title:"Merge Payment Paid By",
			onClickButton:function (){
				var selectedPaiddBy = $(this).getGridParam('selarrrow');
				if(selectedPaiddBy.length>0){
					mergePaidById(selectedPaiddBy);
				}else{
					jAlert('Please select at least one Payment Paid By');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToPaidBy(s);
				}else{
					jAlert('Please select at least one Payment Type');
				}
			}
		});	
	break;
	case 'Payment_Type':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Payment Type",buttonicon : "ui-icon-circle-check", title:"Merge Payment Type",
			onClickButton:function (){
				var selectedType = $(this).getGridParam('selarrrow');
				if(selectedType.length>0){
					mergePaymentTypeId(selectedType);
				}else{
					jAlert('Please select at least one Payment Type');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToPaymentType(s);
				}else{
					jAlert('Please select at least one Payment Type');
				}
			}
		});	
	break;
	case 'Payment_Currency':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Payment Currency",buttonicon : "ui-icon-circle-check", title:"Merge Payment Currency",
			onClickButton:function (){
				var selectedPaymentCurrency = $(this).getGridParam('selarrrow');
				if(selectedPaymentCurrency.length>0){
					mergePaymentCurrencyId(selectedPaymentCurrency);
				}else{
					jAlert('Please select at least one Payment Currency');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
			onClickButton:function (){
				var s	= $(this).getGridParam('selarrrow');
				if(s.length>0){
					addClientsToPaymentCurrency(s);
				}else{
					jAlert('Please select at least one Payment Currency');
				}
			}
		});	
	break;
case 'event_sponsor_types':
		grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Sponsor Type",buttonicon : "ui-icon-circle-check", title:"Merge Sponsor Type",
			onClickButton:function (){
				var selectedSponsorType = $(this).getGridParam('selarrrow');
				if(selectedSponsorType.length>0){
					mergeSponsorTypeId(selectedSponsorType);
				}else{
					jAlert('Please select at least one Sponsor Type');
				}
			}
		});
	break;
case 'conf_session_types':
	grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Session Type",buttonicon : "ui-icon-circle-check", title:"Merge Session Type",
		onClickButton:function (){
			var selectedSessionType = $(this).getGridParam('selarrrow');
			if(selectedSessionType.length>0){
				mergeSessionTypeId(selectedSessionType);
			}else{
				jAlert('Please select at least one Session Type');
			}
		}
	});
break;
case 'conf_event_types':
	grid.jqGrid('navButtonAdd',"#gridListingPagintaion",{caption:"Merge Event Types",buttonicon : "ui-icon-circle-check", title:"Merge Event Types",
		onClickButton:function (){
			var selectedEventTypes = $(this).getGridParam('selarrrow');
			if(selectedEventTypes.length>0){
				mergeEventTypesById(selectedEventTypes);
			}else{
				jAlert('Please select at least one Event Types');
			}
		}
	});	
break;
	}	
}
var type = "<?php echo $arrTypes;?>";
$(document).ready(function(){
	loadGridDetails(type);
});
function editSpecialties(id,specialty){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_specialty'?>',function(){
		$("#hiddenId").val(id);
		$("#specialty").val(specialty);
	});
	return false;
}

function addSpecialtiesClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_specialty_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeSpecialtiesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_specialty_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addProductsClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_product_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addPhoneTypeClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_phonetype_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addEmailTypeClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_emailtype_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addDiscussionTypeClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_discussiontype_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addTopicsClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_topics_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addModesClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_modes_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addLocationTypeClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_locationtype_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}

function editOrgTypes(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_organization_type'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}

function addClientsToRequestedSpecialties(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_specialty_clients'?>/'+s);
	return false;
}

function editEngType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_engagement_type'?>',function(){
		$("#hiddenId").val(id);
		$("#engagementtype").val(type);
	});
	return false;	
}
function saveSpecialty(){
	var specialty = $('#specialty').val();
	if(specialty ==''){
		jAlert("please add specialty");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/specialties';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/specialties';
						smartCRUD(id,specialty,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/specialties';
					smartCRUD(id,specialty,url,false);
				}		 		
			}
		 });
	}else{		
		var url = 'master_data/save_master_data/specialties';
		smartCRUD(id,specialty,url,false);
		}	
}

function deleteSelectedSpecialties(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/specialties';
		checkAssociationSpec(id,url);
		}
}
function checkAssociationSpec(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This specialty is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){					
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/specialties';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
	 	 		smartCRUD(id,'',url,true);
	 	 	} 
			});
		 	}
		}
	 });
	}
function smartCRUD(id,specialty,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialty+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function addRequestedByClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_requestedby_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addPaidByClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_paidby_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addPaymentTypeByClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_paymenttype_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function addPaymentCurrencyByClients(id){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_paymentcurrency_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function saveClients(){	
	var type = "<?php echo $arrTypes;?>";
	var specialty = $('#hiddenSid').val();
	var clientIds = $('#clientId').val();
	var clientId = new Array();
	if(clientIds == null){
		jAlert("Associate atleast one client");
		return;
	}
	for(i=0;i<clientIds.length;i++){
		clientId.push(clientIds[i]);
	}
	switch(type){
	case 'Specialties':	
	var url = 'master_data/save_client_specialty/specialty_client_association';
	break;
	case 'Product':	
		var url = 'master_data/save_client_specialty/products_client_visibility';
	break;
	case 'Phone_Type':	
		var url = 'master_data/save_client_specialty/phone_type_client_visibility';
	break;
	case 'Email_Type':	
		var url = 'master_data/save_client_specialty/emails_client_visibility';
	break;
	case 'Discussion_Type':	
		var url = 'master_data/save_client_specialty/interaction_types_client_visibility';
	break;
	case 'Topics':	
		var url = 'master_data/save_client_specialty/interactions_topics_client_visibility';
	break;
	case 'Interaction_Type':	
		var url = 'master_data/save_client_specialty/interactions_modes_client_visibility';
	break;
	case 'Interaction_Location':	
		var url = 'master_data/save_client_specialty/interaction_location_types_client_visibility';
	break;
	case 'Requested_By':	
		var url = 'master_data/save_client_specialty/payments_requested_by_client_visibility';
	break;
	case 'Paid_By':	
		var url = 'master_data/save_client_specialty/payments_paid_by_client_visibility';
	break;
	case 'Payment_Type':	
		var url = 'master_data/save_client_specialty/payment_types_client_visibility';
	break;
	case 'Payment_Currency':	
		var url = 'master_data/save_client_specialty/payments_currency_client_visibility';
	break;
	}	
	smartCRUD(clientId.toString(),specialty,url,false);		
}
function mergeSpecialties(){
	var specialty = $('#hiddenSid').val();	
	var specialtyId = $('#specialtyId').val();
	if(specialtyId == null){
		jAlert("please select specialty");	
		return false;	
		}
	var url = 'master_data/merge_specialty';
	mergeSpecialtiesAssociateKols(specialty,specialtyId,url,false);	
}
function mergeSpecialtiesAssociateKols(specialty,specialtyId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialty+"&id="+specialtyId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function saveMultipleClients(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("please select client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/specialty_client_association';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function saveMultipleSpecialtiesClients(specialties,clientIds,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialties+"&id="+clientIds,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function saveOrganizationType(){
	var orgType = $('#type').val();
	if(orgType == ''){
		jAlert("Please Add Organization Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id > 0){
		var url = 'master_data/check_master_association/organization_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/organization_types';
						organizationType(id,orgType,url,false);
						}						
					});		
		 		}
				else if(returnData == 0){
					var url = 'master_data/save_master_data/organization_types';
					organizationType(id,orgType,url,false);
					}		 		
				}
		 });
	}else{			
		var url = 'master_data/save_master_data/organization_types';
		organizationType(id,orgType,url,false);
	}
}

function organizationType(id,orgType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"orgType="+orgType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedOrgTypes(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/organization_types';
		checkAssociationOrgTypes(id,url);
		}
}
function checkAssociationOrgTypes(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This organization types is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/organization_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					organizationType(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function saveEngagementType(){
	var engType = $('#engagementtype').val();
	if(engType == ''){
		jAlert("Please Add Engagement Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/engagement_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/engagement_types';
						engagementType(id,engType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/engagement_types';
					engagementType(id,engType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/engagement_types';
			engagementType(id,engType,url,false);
	}
}
function engagementType(id,engType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"engType="+engType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEngType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/engagement_types';
		checkAssociationEngTypes(id,url);
		}
}
function checkAssociationEngTypes(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This engagement types is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/engagement_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					engagementType(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function editEventTopic(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_event_topics'?>',function(){
		$("#hiddenId").val(id);
		$("#eventtopics").val(type);
	});
	return false;	
}
function saveEventTopics(){
	var topic = $('#eventtopics').val();
	if(topic == ''){
		jAlert("Please Add Event Topic");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/event_topics';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/event_topics';
						eventTopic(id,topic,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/event_topics';
					eventTopic(id,topic,url,false);
				}		 		
			}
		 });
		
		}else{			
			var url = 'master_data/save_master_data/event_topics';
			eventTopic(id,topic,url,false);
	}			
}
function eventTopic(id,topic,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"topic="+topic+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEventTopics(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/event_topics';
		checkAssociationEventTopics(id,url);
		}
}
function checkAssociationEventTopics(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This event topics is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/event_topics';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					eventTopic(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function editEventOrgType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_event_organizer_types'?>',function(){
		$("#hiddenId").val(id);
		$("#eventorgtypes").val(type);
	});
	return false;	
}
function saveEventOrgTypes(){
	var eventOrgType = $('#eventorgtypes').val();
	if(eventOrgType == ''){
		jAlert("Please Add Event Organizer Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/event_organizer_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/event_organizer_types';
						eventOrgTypes(id,eventOrgType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/event_organizer_types';
					eventOrgTypes(id,eventOrgType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/event_organizer_types';
			eventOrgTypes(id,eventOrgType,url,false);
	}
}
function eventOrgTypes(id,eventOrgType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventOrgType="+eventOrgType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEventOrgTypes(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/event_organizer_types';
		checkAssociationEventOrgTypes(id,url);
		}
}
function checkAssociationEventOrgTypes(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This event organizer types is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/event_organizer_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					eventOrgTypes(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function editEventRole(id,role){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_event_role'?>',function(){
		$("#hiddenId").val(id);
		$("#eventroles").val(role);
	});
	return false;	
}
function saveEventRole(){
	var role = $('#eventroles').val();
	if(role == ''){
		jAlert("Please Add Event Role");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/event_roles';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/event_roles';
						eventRole(id,role,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/event_roles';
					eventRole(id,role,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/event_roles';
			eventRole(id,role,url,false);
	}
}
function eventRole(id,role,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"role="+role+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEventRole(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/event_roles';
		checkAssociationEventRole(id,url);
		}
}
function checkAssociationEventRole(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This event roles is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/event_roles';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					eventRole(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergeOrgTypesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_orgtype_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeOrgTypes(){
	var orgType = $('#hiddenSid').val();	
	var orgtypeId = $('#orgtypeId').val();
	if(orgtypeId == null){
		jAlert("Please select Organiztion Type");	
		return false;	
		}
	var url = 'master_data/merge_orgtype';
	mergeOrganizationTypes(orgType,orgtypeId,url,false);	
}
function mergeOrganizationTypes(orgType,orgtypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"orgtype="+orgType+"&id="+orgtypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function mergeEngTypesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_engtype_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEngTypes(){
	var engType = $('#hiddenSid').val();	
	var engtypeId = $('#engtypeId').val();
	if(engtypeId == null){
		jAlert("Please Select Engagement Type");	
		return false;	
		}
	var url = 'master_data/merge_engtype';
	mergeEngagementTypes(engType,engtypeId,url,false);	
}
function mergeEngagementTypes(engType,engtypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"engtype="+engType+"&id="+engtypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function mergeEventTopicsById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_eventtopic_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEventTopics(){
	var eventTopic = $('#hiddenSid').val();	
	var eventTopicId = $('#eventtopicId').val();

	if(eventTopicId == null){
		jAlert("Please Select Event Topic");	
		return false;	
		}
	var url = 'master_data/merge_event_topic';
	mergeEvtTopics(eventTopic,eventTopicId,url,false);	
}
function mergeEvtTopics(eventTopic,eventTopicId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventtopic="+eventTopic+"&id="+eventTopicId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function mergeEventOrgTypesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_eventorganizer_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEventOrgTypes(){
	var eventOrgType = $('#hiddenSid').val();	
	var eventOrgTypeId = $('#eventorgtypesId').val();

	if(eventOrgTypeId == null){
		jAlert("Please Select Event Organizer Type");	
		return false;	
		}
	var url = 'master_data/merge_event_organizer_type';
	mergeEventOrganizerType(eventOrgType,eventOrgTypeId,url,false);	
}
function mergeEventOrganizerType(eventOrgType,eventOrgTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventorgtype="+eventOrgType+"&id="+eventOrgTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function mergeEventRolesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_eventrole_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEventRoles(){
	var eventRole = $('#hiddenSid').val();	
	var eventRoleId = $('#eventrolesId').val();

	if(eventRoleId == null){
		jAlert("Please Select Event Role");	
		return false;	
		}
	var url = 'master_data/merge_event_roles';
	mergeEvntRoles(eventRole,eventRoleId,url,false);	
}
function mergeEvntRoles(eventRole,eventRoleId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventrole="+eventRole+"&id="+eventRoleId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
var arrayClientIds = new Array();

//Stack to store associated client ids
function updateClientIds(thisPtr){
	arrayClientIds = [];
	$("input:checkbox[name="+thisPtr.name+"]:checked").each(function(){
		arrayClientIds.push($(this).val());
	});
	arrayClientIds = $.unique(arrayClientIds).sort();
	activateSave();
}

// On complete loading of document, loading the grid
//Prepare Dialogue box layout
function getModalLayout(headerTitle, openMode = false){
	var modalBoxLayout = {
		title: headerTitle,
		autoOpen: openMode,
		modal: true,
		width: 360,
		resizable: false,
	}
	return modalBoxLayout;
};

//Function to Transform cases to upper
function transformCase(thisPtr,toCase){
	switch(toCase.toUpperCase()){
	case "UPPER":
		thisPtr.value = thisPtr.value.toUpperCase();
		break;
	case "LOWER":
		thisPtr.value = thisPtr.value.toLowerCase();
		break;
	case "UCWORDS":
		thisPtr.value = thisPtr.value.toLowerCase().replace(/\b[a-z]/g, function(letter) { return letter.toUpperCase(); });
		break;
	}
	activateSave();
	return;
}

//Function to Activate Save Button
function activateSave(){
	$('#infoMsg').html("");
	$('#saveBtn').attr("disabled",false);
}

//Function to Deactivate Save Button
function deactivateSave(){
	$('#saveBtn').attr("disabled",true);
}

//Function to Activate / Deactivate Delete Button
function confirmDel(thisPtr){
	if(thisPtr.checked){
		$('#delBtn').attr("disabled",false);
	} else {
		$('#delBtn').attr("disabled",true);
	}
	return;
}

//AJAX function to Handle CRUD
function smartAjaxCRUD(clientData, handlerUrl){
	$("#loadingStates").show();
	var respObj = false;	
	$.ajax({
		url: handlerUrl,
		data: clientData,
		async:false,
		type:'POST',
		success: function(serverResp){
			respObj = serverResp;
		},
		complete: function(){
			$("#loadingStates").hide();
		}
	});
	return respObj;
}

//Function to get Title Details for id passed as a param
function getClientIds(titleId){
	url = '<?php echo base_url()?>master_data/getClientIdsToAJAX';
	data = "titleId="+titleId;
	var response = smartAjaxCRUD(data,url);
	return response.toString();
}

//Function to get Title Details for id passed as a param
function getTitleDetailsByID(id){
	url = '<?php echo base_url()?>master_data/get_title_by_id';
	data = "id="+id;
	var respJSON = smartAjaxCRUD(data,url);
	return JSON.parse(respJSON);
}

//Function to get Client Details (if 'id' matches : matched records, else : all records)
function getClientDetails(id){
	url = '<?php echo base_url()?>master_data/getClientDetails';
	data = "id="+id;
	var response = smartAjaxCRUD(data,url);
	return JSON.parse(response);
}

//Function to open Add form
function addTitle(){
	openDialog(0);
	$('#id').val('');
	$('#title').val('');
	$('#abbrevation').val('');
	$('#status').val('1');
	arrayClientIds = [];
	$.each(getClientDetails(null), function(key, value) {
		$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
	})
	activateSave();
	return;
}

//Function to open Edit form
function editTitle(id){
	var response = getTitleDetailsByID(id)["0"];
	if(!response){
		console.log("Server Not Responding : Titles cannot be pulled");
		return;
	}
	var clientsIds = getClientIds(id);
	arrayClientIds = [];
	if(clientsIds){
		var existing = clientsIds.split(',');
		for(i=0;i<existing.length;i++){
			arrayClientIds.push(existing[i]);
		}
	}
	openDialog(1);
	$('#id').val(response.id);
	$('#title').val(response.title);
	$('#abbrevation').val(response.abbr);
	$('#status').val(response.is_active);
	var isChecked = '';
	$.each(getClientDetails(null), function(key, value) {
		isChecked = arrayClientIds.indexOf(value.id) >= 0 ? "checked" : "";
		$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+" "+isChecked+">"+value.name+"</label>");
	})
	return;
}

/*  Function to open Delete Confirmation Dialog
 *	id - Record id to be deleted
 *	isAction : TRUE / FALSE => Submit the record to delete / Just open the confirmation	 */
function deleteTitle(id,isAction){
	if(!isAction){
		var response = getTitleDetailsByID(id)["0"];
		if(!response){
			$('#genericContent').html("Server Error : Not Responding");
			return;
		}
		openDialog(2);
		$('#id').val(response.id);
		$('#title').html(response.title);
		$('#abbrevation').html(response.abbr);
		$('#status').html(response.is_active == 1 ? "Active" : "Inactive");
		return;
	}
	var id = $('#id').val().trim();	
	if(id != 0){
		var url = 'master_data/check_master_association/titles';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('This title is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){						
					});			
		 	} else {
		 		var url = '<?php echo base_url()?>master_data/deleteTitle';
		 		data = "id="+id;		 		
		 		var respMsg = smartAjaxCRUD(data, url);
		 		$('#genericContent').html(respMsg+"<br><br>Please Wait...");
		 		setTimeout(function(){closeModal();},2000);
		 		loadGridDetails(type);
			 	}
				 	
			}
		 });
		}
}

// Function to Save the Title Details
function saveTitle(){
	var id = $('#id').val().trim();
	var title = $('#title').val().trim();
	var abbrevation = $('#abbrevation').val().trim();
	var status = $('#status').val();
	if(title == ""){
		$('#title').focus();
		return;
	}
	if(abbrevation == ""){
		$('#abbrevation').focus();
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/titles';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
							var data = "id="+id+"&title="+title+"&abbrevation="+abbrevation.toUpperCase()+"&status="+status+"&clientIds="+arrayClientIds.toString();
							var url = '<?php echo base_url()?>master_data/smartMergeTitle';
							var respMsg = smartAjaxCRUD(data, url);
							if(id == ''){
								$('#title').val('');
								$('#abbrevation').val('');
								$('#status').val('1');
								$('#multiClientIds').html("");
								arrayClientIds = [];
								$.each(getClientDetails(null), function(key, value) {
									$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
								})
							}
							deactivateSave();
							$('#infoMsg').html(respMsg);
							loadGridDetails(type);
						}						
					});		
		 		}else if(returnData == 0){
		 			var data = "id="+id+"&title="+title+"&abbrevation="+abbrevation.toUpperCase()+"&status="+status+"&clientIds="+arrayClientIds.toString();
					var url = '<?php echo base_url()?>master_data/smartMergeTitle';
					var respMsg = smartAjaxCRUD(data, url);
					if(id == ''){
						$('#title').val('');
						$('#abbrevation').val('');
						$('#status').val('1');
						$('#multiClientIds').html("");
						arrayClientIds = [];
						$.each(getClientDetails(null), function(key, value) {
							$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
						})
					}
					deactivateSave();
					$('#infoMsg').html(respMsg);
					loadGridDetails(type);
				}		 		
			}
		 });
		}else{			
			var data = "id="+id+"&title="+title+"&abbrevation="+abbrevation.toUpperCase()+"&status="+status+"&clientIds="+arrayClientIds.toString();
			var url = '<?php echo base_url()?>master_data/smartMergeTitle';
			var respMsg = smartAjaxCRUD(data, url);
			if(id == ''){
				$('#title').val('');
				$('#abbrevation').val('');
				$('#status').val('1');
				$('#multiClientIds').html("");
				arrayClientIds = [];
				$.each(getClientDetails(null), function(key, value) {
					$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
				})
			}
			deactivateSave();
			$('#infoMsg').html(respMsg);
			loadGridDetails(type);
	}
}

//Function to prepare Add / Edit / Delete Dialogs
function openDialog(dialogID){
	//Add / Edit Title Template
	var addTitleTemplate = "<input type='hidden' id='id' readonly>"+
	"<table style='width:100%'>"+
	"<tr>"+
		"<td><label>Title </label></td>"+
		"<td><input type='text' size='40' id='title' onkeyup=transformCase(this,'UCWORDS'); placeholder='Title'></td>"+
	"</tr>"+
	"<tr>"+
		"<td><label>Abbrevation </label></td>"+
		"<td><input type='text' size='40' id='abbrevation' onkeyup=transformCase(this,'UPPER'); placeholder='Abbrevation'></td>"+
	"</tr>"+
	"<tr><td><label>Clients</label></td><td><div class='multiselect' id='multiClientIds'></div></td>"+
	"<tr>"+
		"<td><label>Status </label></td>"+
		"<td><select id='status' onchange='activateSave();'>"+
			"<option value='1'>Active</option>"+
			"<option value='0'>Inactive</option>"+
		"</select>"+
		"&nbsp;&nbsp;&nbsp;<input type='button' id='saveBtn' value='Save' onclick='saveTitle();' disabled>"+
		"&nbsp;&nbsp;<input type='button' value='Close' onclick='closeModal();'></td>"+
	"</tr></table><span id='infoMsg'></span>";
	//End of Add / Edit Title Template
	//Delete Title Template
	var deleteTitleTemplate = "<input type='hidden' id='id' readonly>"+
	"<table style='width:100%'>"+
	"<tr colspan='2'>"+
		"<td><label>Title : </label><span id='title'></span> ( <span id='abbrevation'></span> )</td>"+
	"</tr>"+
	"<tr colspan='2'>"+
		"<td><label>Status : </label><span id='status'></span></td>"+
	"</tr>"+
	"<tr colspan='2'>"+
		"<td style='text-align:right;'><input type='checkbox' onchange='confirmDel(this);'> I Confirm"+
		"&nbsp;&nbsp;<input type='button' id='delBtn' value='Delete' onclick='deleteTitle(null,true);' disabled>"+
		"&nbsp;&nbsp;<input type='button' value='Cancel' onclick='closeModal();'></td>"+
	"</tr></table><span id='infoMsg'></span>";
	//Delete Title Template
	var arrDialogTitles = ["Add Title","Edit Title","Delete Title"];
	var arrDialogTemplates = [addTitleTemplate, addTitleTemplate, deleteTitleTemplate];
	$('#genericContent').html(arrDialogTemplates[dialogID]);
	$('#genericContainer').dialog(getModalLayout(arrDialogTitles[dialogID],true));
}
function mergeTitlesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_title_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeTitles(){
	var title = $('#hiddenSid').val();	
	var titleId = $('#titlesId').val();

	if(titleId == null){
		jAlert("Please Select Title");	
		return false;	
		}
	var url = 'master_data/merge_titles';
	mergeTitlesFun(title,titleId,url,false);	
}
function mergeTitlesFun(title,titleId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"title="+title+"&id="+titleId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}

function editProduct(id,name){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_product'?>',function(){
		$("#hiddenId").val(id);
		$("#name").val(name);
	});
	return false;	
}
function saveProduct(){
	var product = $('#name').val();
	var id = $('#hiddenId').val();
	if(product == ''){
		jAlert("Please Add Product");	
		return false;	
		}
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/products';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/products';
						productSave(id,product,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/products';
					productSave(id,product,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/products';
			productSave(id,product,url,false);
	}
}
function productSave(id,product,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"product="+product+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedProduct(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/products';
		checkAssociationProduct(id,url);
		}
}
function checkAssociationProduct(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This product is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/products';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					productSave(id,'',url,true);
	 	 	}
			});
		 	} 	
		}
	 });
	}
function closeModal(){
	$("#genericContainer").dialog("close");
}
function mergeProductById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_product_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeProduct(){
	var product = $('#hiddenSid').val();	
	var productId = $('#productsId').val();
	if(productId == null){
		jAlert("Please select Product");	
		return false;	
		}
	var url = 'master_data/merge_product';
	mergeProducts(product,productId,url,false);	
}
function mergeProducts(product,productId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"product="+product+"&id="+productId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedProducts(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_product_clients'?>/'+s);
	return false;
}
function saveMultipleClientsProduct(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/products_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editPhoneType(id,name){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_phone_type'?>',function(){
		$("#hiddenId").val(id);
		$("#name").val(name);
	});
	return false;	
}
function savePhoneType(){
	var phoneType = $('#name').val();
	if(phoneType == ''){
		jAlert("Please Add Phone Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/phone_type';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/phone_type';
						phoneTypeSave(id,phoneType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/phone_type';
					phoneTypeSave(id,phoneType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/phone_type';
			phoneTypeSave(id,phoneType,url,false);
	}
}
function phoneTypeSave(id,phoneType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"phoneType="+phoneType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedPhoneType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/phone_type';
		checkAssociationPhoneType(id,url);
		}
}
function checkAssociationPhoneType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This phone type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/phone_type';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					phoneTypeSave(id,'',url,true);
	 	 	} 
			});
		 	}  	
		}
	 });
	}
function mergePhoneTypeById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_phonetype_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergePhoneType(){
	var phonetype = $('#hiddenSid').val();	
	var phonetypeId = $('#phonetypesId').val();
	if(phonetypeId == null){
		jAlert("Please Select Phone Type");	
		return false;	
		}
	var url = 'master_data/merge_phone_type';
	mergePhoneTypes(phonetype,phonetypeId,url,false);	
}
function mergePhoneTypes(phonetype,phonetypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"phonetype="+phonetype+"&id="+phonetypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedPhones(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_phone_clients'?>/'+s);
	return false;
}
function saveMultipleClientsPhoneType(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/phone_type_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editEmailType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_email_type'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveEmailType(){
	var emailType = $('#type').val();
	if(emailType == ''){
		jAlert("Please Add Email Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/emails';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/emails';
						emailTypeSave(id,emailType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/emails';
					emailTypeSave(id,emailType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/emails';
			emailTypeSave(id,emailType,url,false);
	}	
}
function emailTypeSave(id,emailType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"emailType="+emailType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEmailType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/emails';
		checkAssociationEmail(id,url);
		}
}
function checkAssociationEmail(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This email type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){					
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/emails';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					emailTypeSave(id,'',url,true);
	 	 	}
			});
		 	} 			 	
		}
	 });
	}
function mergeEmailTypeById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_emailtype_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEmailType(){
	var emailType = $('#hiddenSid').val();	
	var emailTypeId = $('#emailTypesId').val();
	if(emailTypeId == null){
		jAlert("Please Select Email Type");	
		return false;	
		}
	var url = 'master_data/merge_email_type';
	mergeEmailTypes(emailType,emailTypeId,url,false);	
}
function mergeEmailTypes(emailType,emailTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"emailType="+emailType+"&id="+emailTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedEmails(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_email_clients'?>/'+s);
	return false;
}
function saveMultipleClientsEmail(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/emails_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editDiscussionType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_discussion_type'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveDiscussionType(){
	var discussionType = $('#type').val();
	if(discussionType == ''){
		jAlert("Please Add Discussion Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;
	if(id != 0){
		var url = 'master_data/check_master_association/interaction_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/interaction_types';
						discussionTypeSave(id,discussionType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/interaction_types';
					discussionTypeSave(id,discussionType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/interaction_types';
			discussionTypeSave(id,discussionType,url,false);
	}
}
function discussionTypeSave(id,discussionType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"discussionType="+discussionType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedDiscussionType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/interaction_types';
		checkAssociationDis(id,url);
		}
}
function checkAssociationDis(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This discussion type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){					
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/interaction_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					discussionTypeSave(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}

function mergeDiscussionTypeById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_discussion_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeDiscussionType(){
	var discussionType = $('#hiddenSid').val();	
	var discussionTypeId = $('#discussionTypesId').val();
	if(discussionTypeId == null){
		jAlert("Please Select Discussion Type");	
		return false;	
		}
	var url = 'master_data/merge_discussion_type';
	mergeDiscussionTypes(discussionType,discussionTypeId,url,false);	
}
function mergeDiscussionTypes(discussionType,discussionTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"discussionType="+discussionType+"&id="+discussionTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedDiscussion(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_discussion_clients'?>/'+s);
	return false;
}
function saveMultipleClientsDiscussion(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/interaction_types_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editTopics(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_topics'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveTopics(){
	var topic = $('#type').val();
	if(topic == ''){
		jAlert("Please Add Topic");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/interactions_topics';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/interactions_topics';
						topicSave(id,topic,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/interactions_topics';
					topicSave(id,topic,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/interactions_topics';
			topicSave(id,topic,url,false);
	}
}
function topicSave(id,topic,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"topic="+topic+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedTopic(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/interactions_topics';
		checkAssociationTopic(id,url);
		}
}
function checkAssociationTopic(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This Topic is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){					
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/interactions_topics';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					topicSave(id,'',url,true);
	 	 	} 
			});
		 	}
		}
	 });
	}

function mergeTopicsById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_topics_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeTopic(){
	var topic = $('#hiddenSid').val();	
	var topicId = $('#topicsId').val();
	if(topicId == null){
		jAlert("Please Select Topic");	
		return false;	
		}
	var url = 'master_data/merge_topics';
	mergeTopics(topic,topicId,url,false);	
}
function mergeTopics(topic,topicId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"topic="+topic+"&id="+topicId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedTopics(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_topic_clients'?>/'+s);
	return false;
}
function saveMultipleClientsTopics(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/interactions_topics_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editInteractionType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_interaction_type'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveInteractionType(){
	var interactionType = $('#type').val();
	if(interactionType == ''){
		jAlert("Please Add Interaction Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/interactions_modes';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/interactions_modes';
						interactionTypeSave(id,interactionType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/interactions_modes';
					interactionTypeSave(id,interactionType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/interactions_modes';
			interactionTypeSave(id,interactionType,url,false);
	}		
}
function interactionTypeSave(id,interactionType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"interactionType="+interactionType+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedInteractionType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/interactions_modes';
		checkAssociationIncType(id,url);
		}
}
function checkAssociationIncType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This interaction type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/interactions_modes';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					interactionTypeSave(id,'',url,true);
	 	 	} 
			});
		 	}  	
		}
	 });
	}
function mergeInteractionTypeById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_interaction_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeInteractionType(){
	var interactionType = $('#hiddenSid').val();	
	var interactionTypeId = $('#interactionTypesId').val();
	if(interactionTypeId == null){
		jAlert("Please Select Interaction Type");	
		return false;	
		}
	var url = 'master_data/merge_interaction_type';
	mergeInteractionTypes(interactionType,interactionTypeId,url,false);	
}
function mergeInteractionTypes(interactionType,interactionTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"interactionType="+interactionType+"&id="+interactionTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedModes(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_mode_clients'?>/'+s);
	return false;
}
function saveMultipleClientsModes(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/interactions_modes_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
function editInteractionLocation(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_interaction_location'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveInteractionLocation(){
	var interactionLocation = $('#type').val();
	if(interactionLocation == ''){
		jAlert("Please Add Interaction Location");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/interaction_location_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/interaction_location_types';
						interactionLocationSave(id,interactionLocation,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/interaction_location_types';
					interactionLocationSave(id,interactionLocation,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/interaction_location_types';
			interactionLocationSave(id,interactionLocation,url,false);
	}	
}
function interactionLocationSave(id,interactionLocation,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"interactionLocation="+interactionLocation+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedInteractionLocation(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/interaction_location_types';
		checkAssociationIncLoc(id,url);
		}
}
function checkAssociationIncLoc(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This interaction location type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/interaction_location_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					interactionLocationSave(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergeInteractionLocationById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_interaction_location_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeInteractionLocation(){
	var interactionLocation = $('#hiddenSid').val();	
	var interactionLocationId = $('#interactionLocationsId').val();
	if(interactionLocationId == null){
		jAlert("Please Select Interaction Location");	
		return false;	
		}
	var url = 'master_data/merge_interaction_location';
	mergeInteractionLocations(interactionLocation,interactionLocationId,url,false);	
}
function mergeInteractionLocations(interactionLocation,interactionLocationId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"interactionLocation="+interactionLocation+"&id="+interactionLocationId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedLocations(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_location_clients'?>/'+s);
	return false;
}
function saveMultipleClientsLocations(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/interaction_location_types_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
}
//-----Requested by----------------------------

function editRequestedBy(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_requested_by'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveRequestedBy(){
	var requestedBy = $('#type').val();
	if(requestedBy ==''){
		jAlert("please add payment requested by");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/payments_requested_by';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/payments_requested_by';
						requestedBySave(id,requestedBy,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/payments_requested_by';
					requestedBySave(id,requestedBy,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/payments_requested_by';
			requestedBySave(id,requestedBy,url,false);
	}	
	
	
}
function requestedBySave(id,requestedBy,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"requestedBy="+requestedBy+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedRequestedBy(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/payments_requested_by';
		checkAssociationRequestedBy(id,url);
		}
}
function checkAssociationRequestedBy(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This payments requested by is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/payments_requested_by';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					requestedBySave(id,'',url,true);
	 	 	} 
			});
		 	}  	
		}
	 });
	}
function mergeRequestedById(id){	
	//console.log(id);exit;
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_requested_by_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeRequestedBy(){
	var requestedBy = $('#hiddenSid').val();	
	var requestedById = $('#requestedById').val();
	if(requestedById == null){
		jAlert("Please Select Payment Requested By");	
		return false;	
		}
	//alert(requestedById);
	var url = 'master_data/merge_requested_by';
	mergePaymentRequestedBy(requestedBy,requestedById,url,false);	
}
function mergePaymentRequestedBy(requestedBy,requestedById,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"requestedBy="+requestedBy+"&id="+requestedById,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToRequestedBy(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_requestedby_clients'?>/'+s);
	return false;
}
function saveMultipleClientsRequestedBy(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/payments_requested_by_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
	//console.log(clientIds);
}
//----Paid By-----------

function editPaidBy(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_paid_by'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function savePaidBy(){
	var paidBy = $('#type').val();
	if(paidBy == ''){
		jAlert("Please Add Payment Paid By");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/payments_paid_by';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/payments_paid_by';
						paidBySave(id,paidBy,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/payments_paid_by';
					paidBySave(id,paidBy,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/payments_paid_by';
			paidBySave(id,paidBy,url,false);
	}	
}
function paidBySave(id,paidBy,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"paidBy="+paidBy+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedPaidBy(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/payments_paid_by';
		checkAssociationPaidBy(id,url);
		}
}
function checkAssociationPaidBy(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This payments paid by is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/payments_paid_by';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					paidBySave(id,'',url,true);
	 	 	} 
			});
		 	}  	
		}
	 });
	}
function mergePaidById(id){	
	//console.log(id);exit;
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_paid_by_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergePaidBy(){
	var paidBy = $('#hiddenSid').val();	
	var paidById = $('#paidById').val();
	if(paidById == null){
		jAlert("Please Select Payment Paid By");	
		return false;	
		}
	//alert(requestedById);
	var url = 'master_data/merge_paid_by';
	mergePaymentPaidBy(paidBy,paidById,url,false);	
}
function mergePaymentPaidBy(paidBy,paidById,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"paidBy="+paidBy+"&id="+paidById,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToPaidBy(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_paidby_clients'?>/'+s);
	return false;
}
function saveMultipleClientsPaidBy(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/payments_paid_by_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
	//console.log(clientIds);
}
//-----Payment Type-------
function editPaymentType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_payment_type'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function savePaymentType(){
	var paymentType = $('#type').val();
	if(paymentType == ''){
		jAlert("Please Add Payment Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/payment_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/payment_types';
						paymentTypeSave(id,paymentType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/payment_types';
					paymentTypeSave(id,paymentType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/payment_types';
			paymentTypeSave(id,paymentType,url,false);
	}	
}
function paymentTypeSave(id,paymentType,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"paymentType="+paymentType+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedPaymentType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/payment_types';
		checkAssociationPaymentType(id,url);
		}
}
function checkAssociationPaymentType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This payment types is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/payment_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					paymentTypeSave(id,'',url,true);
	 	 	} 
			});
		 	}  	
		}
	 });
	}
function mergePaymentTypeId(id){	
	//console.log(id);exit;
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergePaymentType(){
	var paymentType = $('#hiddenSid').val();	
	var paymentTypeId = $('#paymentTypeId').val();
	if(paymentTypeId == null){
		jAlert("Please Select Payment Type");	
		return false;	
		}
	var url = 'master_data/merge_payment_type';
	mergePaymentTypes(paymentType,paymentTypeId,url,false);	
}
function mergePaymentTypes(paymentType,paymentTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"paymentType="+paymentType+"&id="+paymentTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToPaymentType(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_type_clients'?>/'+s);
	return false;
}
function saveMultipleClientsPaymentType(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/payment_types_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
	//console.log(clientIds);
}
//---Payment currency--------------
function editPaymentCurrency(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_payment_currency'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function savePaymentCurrency(){
	var paymentCurrency = $('#type').val();
	var currencySymbol =  $('#symbol').val();
	if(paymentCurrency == ''){
		jAlert("Please Add Payment Currency");	
		return false;	
		}
	if(currencySymbol == ''){
		jAlert("Please Add Currency Symbol");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/payments_currency';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/payments_currency';
						paymentCurrencySave(id,paymentCurrency,currencySymbol,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/payments_currency';
					paymentCurrencySave(id,paymentCurrency,currencySymbol,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/payments_currency';
			paymentCurrencySave(id,paymentCurrency,currencySymbol,url,false);
	}	
}
function paymentCurrencySave(id,paymentCurrency,currencySymbol,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"paymentCurrency="+paymentCurrency+"&currencySymbol="+currencySymbol+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedPaymentCurrency(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/payments_currency';
		checkAssociationPaymentCurrency(id,url);
		}
}
function checkAssociationPaymentCurrency(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This payments currency is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/payments_currency';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					paymentCurrencySave(id,'','',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergePaymentCurrencyId(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_payment_currency_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergePaymentCurrency(){
	var currency = $('#hiddenSid').val();	
	var currencyId = $('#currencyId').val();
	if(currencyId == null){
		jAlert("Please Select Payment Currency");	
		return false;	
		}
	var url = 'master_data/merge_payment_currency';
	mergePaymentCurrencys(currency,currencyId,url,false);	
}
function mergePaymentCurrencys(currency,currencyId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"currency="+currency+"&id="+currencyId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
function addClientsToPaymentCurrency(s){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/add_miltiple_currency_clients'?>/'+s);
	return false;
}
function saveMultipleClientsPaymentCurrency(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	if(clientIds == null){
		jAlert("Please Select Client");	
		return false;	
		}
	var url = 'master_data/save_multiple_clients/payments_currency_client_visibility';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
	//console.log(clientIds);
}
//-----------Event Type------------------------
function editEventType(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_event_types'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveEventTypes(){
	var eventType = $('#type').val();
	if(eventType == ''){
		jAlert("Please Add Event Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/conf_event_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/conf_event_types';
						eventTypesSave(id,eventType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/conf_event_types';
					eventTypesSave(id,eventType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/conf_event_types';
			eventTypesSave(id,eventType,url,false);
	}	
}
function eventTypesSave(id,eventType,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventType="+eventType+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedEventType(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/conf_event_types';
		checkAssociationEventType(id,url);
		}
}
function checkAssociationEventType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This event type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/conf_event_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					eventTypesSave(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergeEventTypesById(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_event_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeEventTypes(){
	var eventType = $('#hiddenSid').val();	
	var eventTypeId = $('#eventTypeId').val();
	if(eventTypeId == null){
		jAlert("Please Select Event Type");	
		return false;	
		}
	var url = 'master_data/merge_event_type';
	mergeEventType(eventType,eventTypeId,url,false);	
}
function mergeEventType(eventType,eventTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"eventType="+eventType+"&id="+eventTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
//----------Sponsor Type----------
function editSponsorTypes(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_sponsor_types'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveSponsorTypes(){
	var sponsorType = $('#type').val();
	if(sponsorType == ''){
		jAlert("Please Add Sponsor Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/event_sponsor_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/event_sponsor_types';
						sponsorTypesSave(id,sponsorType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/event_sponsor_types';
					sponsorTypesSave(id,sponsorType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/event_sponsor_types';
			sponsorTypesSave(id,sponsorType,url,false);
	}	
}
function sponsorTypesSave(id,sponsorType,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"sponsorType="+sponsorType+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedSponsorTypes(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/event_sponsor_types';
		checkAssociationSponsorType(id,url);
		}
}
function checkAssociationSponsorType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This sponsor type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/event_sponsor_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					sponsorTypesSave(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergeSponsorTypeId(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_sponsor_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeSponsorTypes(){
	var sponsorType = $('#hiddenSid').val();	
	var sponsorTypeId = $('#sponsorTypeId').val();
	if(sponsorTypeId == null){
		jAlert("Please Select Sponsor Type");	
		return false;	
		}
	var url = 'master_data/merge_sponsor_type';
	mergeSponsorType(sponsorType,sponsorTypeId,url,false);	
}
function mergeSponsorType(sponsorType,sponsorTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"sponsorType="+sponsorType+"&id="+sponsorTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
//----------Session Type----------
function editSessionTypes(id,type){
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/edit_session_types'?>',function(){
		$("#hiddenId").val(id);
		$("#type").val(type);
	});
	return false;	
}
function saveSessionTypes(){
	var sessionType = $('#type').val();
	if(sessionType == ''){
		jAlert("Please Add Session Type");	
		return false;	
		}
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;	
	if(id != 0){
		var url = 'master_data/check_master_association/conf_session_types';
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>'+url,
			data:"id="+id,
			success:function(returnData){
				if(returnData > 0){
					jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
						if(event){
						var url = 'master_data/save_master_data/conf_session_types';
						sessionTypesSave(id,sessionType,url,false);
						}						
					});		
		 		}else if(returnData == 0){
					var url = 'master_data/save_master_data/conf_session_types';
					sessionTypesSave(id,sessionType,url,false);
				}		 		
			}
		 });
		}else{			
			var url = 'master_data/save_master_data/conf_session_types';
			sessionTypesSave(id,sessionType,url,false);
	}	
}
function sessionTypesSave(id,sessionType,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"sessionType="+sessionType+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });
}
function deleteSelectedSessionTypes(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	if(id != 0){
		var url = 'master_data/check_master_association/conf_session_types';
		checkAssociationSessionType(id,url);
		}
}
function checkAssociationSessionType(id,url){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+url,
		data:"id="+id,
		success:function(returnData){
			if(returnData > 0){
				jConfirm('This session type is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){
				});		
	 	} else {
	 		var url = 'master_data/delete_master_data/conf_session_types';	
	 	 	jConfirm('Are you sure to proceed with Delete ?','Please Confirm',function(event){
				if(event){	
					sessionTypesSave(id,'',url,true);
	 	 	} 
			});
		 	} 	
		}
	 });
	}
function mergeSessionTypeId(id){	
	$("#genericContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#genericContainer").dialog("open");
	$("#genericContent").load('<?php echo base_url().'master_data/merge_session_type_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeSessionTypes(){
	var sessionType = $('#hiddenSid').val();	
	var sessionTypeId = $('#sessionTypeId').val();
	if(sessionTypeId == null){
		jAlert("Please Select Session Type");	
		return false;	
		}
	var url = 'master_data/merge_session_type';
	mergeSessionType(sessionType,sessionTypeId,url,false);	
}
function mergeSessionType(sessionType,sessionTypeId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"sessionType="+sessionType+"&id="+sessionTypeId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				jAlert(returnData);
			}
			loadGridDetails(type);
	 	},
	 	error:function(){
		 	jAlert("already exist");
		}
	 });		
}
//--------------------------------
function loadURL(){
	var page = $('#selectedPage').val();
	var newURL = "<?php echo base_url();?>master_data/view_types/"+page;;
	/* Remove the below when Regions is implemented as common view */
	if(page == "Regions"){
		newURL = "<?php echo base_url();?>master_data/list_region";
	}
	/* Remove the above part when Regions is implemented as common view */
 	window.location = newURL;
}
$(document).ready(function(){
	var modalBoxAddOpts = {
			title: "",
			modal: true,
			autoOpen: false,
			height:500,
			width: 600,
			dialogClass: "microView",
			position: ['center', 160],
			open: function() {
			}
	};
	$("#exportKolsContainer").dialog(modalBoxAddOpts);
});
function exportMasterData(){
	$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#exportKolsContainer").dialog("open");
	$("#exportKolsProfileContent").load('<?php echo base_url();?>master_data/export_page');	
}
function importMasterData(){
	var newURL = "<?php echo base_url();?>master_data/import_page";
	window.location = newURL;
}
</script>
<style>
.ui-jqgrid .ui-jqgrid-btable {
	table-layout: auto;
}

.ui-jqgrid .ui-jqgrid-htable {
	table-layout: auto;
}

.multiselect {
	width: 22.2em;
	height: 6em;
	border: solid 1px #c0c0c0;
	overflow: auto;
}

.multiselect label {
	display: block;
}
</style>
<div class="container-fluid" style="margin-top:20px;">
	<div class="col-md-6">
		<div class="extraOptions">	
	<?php $type = $arrTypes;?>
		<label>Select Category : </label> <select
			name="master_data_controller" id="selectedPage" onchange="loadURL();">
			<option value="Regions"
				<?php echo $type=="Regions" ? "selected" : "";?>>Regions</option>
			<option value="Titles"
				<?php echo $type=="Titles" ? "selected" : "";?>>Titles</option>
			<option value="Topics"
				<?php echo $type=="Topics" ? "selected" : "";?>>Topics</option>
			<option value="Product"
				<?php echo $type=="Product" ? "selected" : "";?>>Product</option>
			<option value="Email_Type"
				<?php echo $type=="Email_Type" ? "selected" : "";?>>Email Type</option>
			<option value="Phone_Type"
				<?php echo $type=="Phone_Type" ? "selected" : "";?>>Phone Type</option>
			<option value="Specialties"
				<?php echo $type=="Specialties" ? "selected" : ""; ?>>Specialities</option>
			<option value="Event_Roles"
				<?php echo $type=="Event_Roles" ? "selected" : "";?>>Event Roles</option>
			<option value="Event_Topics"
				<?php echo $type=="Event_Topics" ? "selected" : "";?>>Event Topics</option>
			<option value="Event_Org_Types"
				<?php echo $type=="Event_Org_Types" ? "selected" : "";?>>Event Org
				types</option>
			<option value="Discussion_Type"
				<?php echo $type=="Discussion_Type" ? "selected" : "";?>>Discussion
				Type</option>
			<option value="Interaction_Type"
				<?php echo $type=="Interaction_Type" ? "selected" : "";?>>Interaction
				Type</option>
			<option value="Interaction_Location"
				<?php echo $type=="Interaction_Location" ? "selected" : "";?>>Interaction
				Location</option>
			<option value="Engagement_Types"
				<?php echo $type=="Engagement_Types" ? "selected" : "";?>>Engagement
				Types</option>
			<option value="Organization_Types"
				<?php echo $type=="Organization_Types" ? "selected" : "";?>>Organization
				Types</option>
			<option value="Requested_By"
				<?php echo $type=="Requested_By" ? "selected" : "";?>>Requested By</option>
			<option value="Paid_By"
				<?php echo $type=="Paid_By" ? "selected" : "";?>>Paid By</option>
			<option value="Payment_Type"
				<?php echo $type=="Payment_Type" ? "selected" : "";?>>Payment Type</option>
			<option value="Payment_Currency"
				<?php echo $type=="Payment_Currency" ? "selected" : "";?>>Payment
				Currency</option>
			<option value="conf_event_types"
				<?php echo $type=="conf_event_types" ? "selected" : "";?>>Event
				Type</option>
			<option value="event_sponsor_types"
				<?php echo $type=="event_sponsor_types" ? "selected" : "";?>>Sponsor
				Type</option>
			<option value="conf_session_types"
				<?php echo $type=="conf_session_types" ? "selected" : "";?>>Session
				Type</option>
		</select>

	<?php
	switch ($type) {
		case 'Specialties' :
			$onclickHandler = "editSpecialties()";
			$hyperlinkLabel = "Add Specialty";
			break;
		case 'Organization_Types' :
			$onclickHandler = "editOrgTypes()";
			$hyperlinkLabel = "Add Organization Type";
			break;
		case 'Engagement_Types' :
			$onclickHandler = "editEngType()";
			$hyperlinkLabel = "Add Engagement Type";
			break;
		case 'Event_Topics' :
			$onclickHandler = "editEventTopic()";
			$hyperlinkLabel = "Add Event Topic";
			break;
		case 'Event_Org_Types' :
			$onclickHandler = "editEventOrgType()";
			$hyperlinkLabel = "Add Event Organizer Type";
			break;
		case 'Event_Roles' :
			$onclickHandler = "editEventRole()";
			$hyperlinkLabel = "Add Event Role";
			break;
		case 'Titles' :
			$onclickHandler = "addTitle()";
			$hyperlinkLabel = "Add Titles";
			break;
		case 'Phone_Type' :
			$onclickHandler = "editPhoneType()";
			$hyperlinkLabel = "Add Phone Type";
			break;
		case 'Product' :
			$onclickHandler = "editProduct()";
			$hyperlinkLabel = "Add Product";
			break;
		case 'Email_Type' :
			$onclickHandler = "editEmailType()";
			$hyperlinkLabel = "Add Email Type";
			break;
		case 'Discussion_Type' :
			$onclickHandler = "editDiscussionType()";
			$hyperlinkLabel = "Add Discussion Type";
			break;
		case 'Topics' :
			$onclickHandler = "editTopics()";
			$hyperlinkLabel = "Add Topics";
			break;
		case 'Interaction_Type' :
			$onclickHandler = "editInteractionType()";
			$hyperlinkLabel = "Add Interaction Type";
			break;
		case 'Interaction_Location' :
			$onclickHandler = "editInteractionLocation()";
			$hyperlinkLabel = "Add Interaction Location";
			break;
		case 'Requested_By' :
			$onclickHandler = "editRequestedBy()";
			$hyperlinkLabel = "Add Requested By";
			break;
		case 'Paid_By' :
			$onclickHandler = "editPaidBy()";
			$hyperlinkLabel = "Add Paid By";
			break;
		case 'Payment_Type' :
			$onclickHandler = "editPaymentType()";
			$hyperlinkLabel = "Add Payment Type";
			break;
		case 'Payment_Currency' :
			$onclickHandler = "editPaymentCurrency()";
			$hyperlinkLabel = "Add Payment Currency";
			break;
		case 'conf_event_types' :
			$onclickHandler = "editEventType()";
			$hyperlinkLabel = "Add Event Type";
			break;
		case 'event_sponsor_types' :
			$onclickHandler = "editSponsorTypes()";
			$hyperlinkLabel = "Add Sponsor Type";
			break;
		case 'conf_session_types' :
			$onclickHandler = "editSessionTypes()";
			$hyperlinkLabel = "Add Session Type";
			break;					
	}
	?>
	<a class="addLink" style="cursor: pointer;"
			onclick="<?php echo $onclickHandler; ?>"> <img
			src="<?php echo base_url();?>images/bullet_add.png" border="0"
			style="height: 30px; vertical-align: middle;" /><?php echo $hyperlinkLabel; ?></a>
			</div>
	</div>
	<div class="col-md-6" style="text-align: right;">
		<p align="right" style="float: right;">
			<input type="button"  value="Import" id="masterImportButton"
					onclick="importMasterData()" />
			<input type="button" value="Export" id="masterExportButton"
					onclick="exportMasterData()" />
		</p>
	</div>
	<div class="col-md-12">
		<div id="gridListing">
			<div class="gridWrapper">
				<div id="gridListingPagintaion"></div>
				<table id="gridListingResultSet"></table>
			</div>
		</div>
		<!-- Container for the modal box -->
		<div id="genericContainer">
			<span id="genericContent"></span>
		</div>
		<!-- End of Container for the modal box' -->
		<div id="exportKolsDialog">	
				<div id="exportKolsContainer" class="microProfileDialogBox">
					<div class="profileContent" id="exportKolsProfileContent"></div>
				</div>
		</div>
	</div>
</div>