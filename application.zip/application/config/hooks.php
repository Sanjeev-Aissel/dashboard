<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/general/hooks.html
|
*/



/* End of file hooks.php */
/* Location: ./system/application/config/hooks.php */

/* Test Hook 

$hook['post_controller_constructor'] = array(

							'class' => 'getSystem',
							
							'function' => 'check',
							
							'filename' => 'getsystem.php',
							
							'filepath' => 'hooks'
							
						   );
						   
*/	

/* Hook to check for user login
 */

$hook['post_controller_constructor'][] = array(	'class' 	=> 'custom_post_controller_hooks',
												'function'	=> 'userLoginCheck',
												'filename'	=> 'custom_post_controller_hooks.php',
												'filepath'	=> 'hooks'
						   					);	
						   
/* Hook to detect the the user agent and the browser of the request and redirect the request 
 * to  appropriate controller, 
 */

$hook['post_controller_constructor'][] = array(	'class' 	=> 'custom_post_controller_hooks',
												'function'	=> 'mobile_app_redirect',
												'filename'	=> 'custom_post_controller_hooks.php',
												'filepath'	=> 'hooks'
						   					);
						   					
/* Hook to Enable or disable profilere
 * to  appropriate controller, 
 */

$hook['post_controller_constructor'][] = array(	'class' 	=> 'custom_post_controller_hooks',
												'function'	=> 'enable_profiler',
												'filename'	=> 'custom_post_controller_hooks.php',
												'filepath'	=> 'hooks'
						   					);
/*$hook['post_controller_constructor'][] = array(	'class' 	=> 'custom_post_controller_hooks',
												'function'	=> 'permission',
												'filename'	=> 'custom_post_controller_hooks.php',
												'filepath'	=> 'hooks'
   );*/
						   					
$hook['post_controller'][] = array('class' 	=> 'custom_user_permission',
												'function'	=> 'log_activity',
												'filename'	=> 'custom_user_permission_controller_hook.php',
												'filepath'	=> 'hooks'
						   					);