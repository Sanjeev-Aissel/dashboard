<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<?php echo $html_form;?>
<script>
var selected_menu_id='<?php echo $secondary_menu_id;?>';
$(document).ready(function() {
  get_sec_menu();
  <?php foreach ($unassignedModules as $disabled_module_id){?>
  	var module_id='<?php echo $disabled_module_id;?>';
    $("#module_id option[value="+module_id+"]").attr("disabled", "disabled");
  	<?php }?>

	$("#client_module_association").validate({
		rules: {
			module_id: "required",
			menu_name: "required",
			url: "required",
		},
		messages: {
			module_id: {
				required: "No modules to assign",
			},
			menu_name: {
				required: "Please enter Menu Name",
			},
			url: {
				required: "Please provide url",
			}
		}
	});		
});
</script>