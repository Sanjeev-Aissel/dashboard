<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Custom_post_controller_hooks{
	var $CI;
	var $lang;
	function __construct() {
		$this->CI = & get_instance ();
// 		print_r($this->CI->session->userdata);
	}
	function checkUserLogin()
	{
		if(!$this->CI->session->userdata('logged_in'))
		{
			if(!$this->checkForAllowedUrlsWithoutLogin())
			{
				if(!IS_AJAX) {
					$currentURI = $this->CI->uri->uri_string();
					$this->CI->session->set_userdata("back_url",$currentURI);
					redirect('logins');
				}
				redirect('logins');
			}
		}else{
			$user_id = $this->CI->session->userdata('user_id');
			$arrApproverIds = $this->CI->common_helper->checkApproverId();
			define('APPROVER_IDS',implode(",",$arrApproverIds));
			if(in_array($user_id,$arrApproverIds)){
				define('IS_APPROVER',true);
			}else{
				define('IS_APPROVER',false);
			}
		}
	}
	function checkForAllowedUrlsWithoutLogin()
	{
		$segment1=$this->CI->uri->segment(1);
		$segment2=$this->CI->uri->segment(2);
		$arrAllowedUrls=array();
		$arrAllowedUrls[]=array('logins','');
		$isAllowed=false;
		foreach($arrAllowedUrls as $row)
		{
			if($row[1] == '')
			{
				if($segment1==$row[0])
					$isAllowed=true;
			}else{
				if($segment1==$row[0] && $segment2==$row[1])
					$isAllowed=true;
			}
		}
		return $isAllowed;
	}
	function getUserRolesPermissions()
	{
		if($this->CI->session->userdata('logged_in'))
		{
// 			print_r(APPPATH.'views/permission/'.$this->CI->session->userdata('role_id').'.txt');
			$json = file_get_contents(APPPATH.'views/permission/'.$this->CI->session->userdata('role_id').'.txt');
			$arrPermissions=json_decode($json,true);
			$this->CI->config->set_item('role_permissions', $arrPermissions);
		}
	}
}
?>