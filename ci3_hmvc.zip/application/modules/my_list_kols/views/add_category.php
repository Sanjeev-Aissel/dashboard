<?php echo $html_form; ?>
<span id="responseMessageOfAddCategory"></span>
<script type="text/javascript">
var validationRules	=  {
	category: {
		required:true
     }
};
var validationMessages = {
	category: {
		required:"Category name is required"
	}
};
$(document).ready(function(){
	$("#addCategoryForm").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>