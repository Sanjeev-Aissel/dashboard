<style>
	caption {
	    padding: 8px 8px;
	    text-align: left;
	    border-color: #2E6E9E;
	    color: #FFF;
	    background-color: #2E6E9E;
	    margin-top: 20px;
	    font-size: 15px;
	}
	.table>caption+thead>tr>th{
		font-size:13px;
	}
	.table>tbody>tr>th, .table>tbody>tr>td{
		font-size:12px !important;
		padding:5px !important;
	}
	button.btn.btn-primary {
	    vertical-align: top;
	}
	.checkbox, .radio{
		margin-top:0px  !important;
		margin-bottom:0px  !important;
	}
	.checkbox input[type=checkbox]{
		margin-left:0px  !important;
	}
</style>
<script type="text/javascript">

		function updateStatus(){
			var status = $('#status').val();
			
			var kolId = new Array();
			$.each($('input[name="exportId[]"]:checked'),function(){
				kolId.push($(this).val());
			});

			if(kolId==''){
				jAlert("Please select at least one KTL");
				return false;
			}

			if(status==''){
				jAlert("Please select status");
				return false;
			}
				var data ={};
				data['kolId'] = kolId;
				data['status'] = status;
				$('.msgBox').removeClass('success');
				$('.msgBox').addClass('notice');
				$('.msgBox').show();

				$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			$.ajax({
				url:'<?php echo base_url()?>requested_kols/update_request_status_analyst',
				data:data,
				type:'post',
				dataType:'json',
				success:function(){
					if(status=='Completed'){
						$.each(kolId,function(key,value){
							$('#KOL_'+value).remove();
							});
					}else{
						$.each(kolId,function(key,value){
						$('#KOL_'+value).find('td').eq(7).html(status);
						});
					}
					$('.msgBox').text("Updated Successfully");
					
					$('.msgBox').fadeOut(1000);
					
				}
			});
	
			}
	
	
	
	</script>
<div class="container-fluid" style="margin-top:20px;">
<?php $userRoleId = $this->session->userdata('user_role_id');?>
	<div class="col-md-12">
		<div class="msgBox"></div>
	</div>
	<div class="col-md-12">
		<p style="display: inline">Set Status:</p>
		<select name="updatestats" id="status" class="form-control"  style="width:12%;display: inline">
						<option value="">Select</option>
							<option value="<?php echo New1?>">New</option>
							<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo APPROVED?>">Approved</option>
							<?php }?>
							<option value="<?php echo PROFILING?>">Profiling</option>
							<option value="<?php echo REVIEW?>">Review</option>
								<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo COMPLETED?>">Completed</option>
							<?php }?>
						</select>
		<button onclick="updateStatus()" class="btn btn-primary" style="">save</button>				
	</div>
	<div id="tbl" class="col-md-12">
		<div id="listKolsTbl" class="table-responsive">
		  <table class="listResultSet table ">
			  <caption>List of Requested KOL profiles</caption>
			  <thead>
			    <tr>
			      	<th>ID</th>
					<th>Select</th>
					<th>Name</th>
					<th>Specialty</th>
					<th>Request For</th>
					<th>Organizations</th>
					<th>Created By</th>
					<th>Status</th>
			    </tr>
			  </thead>
			  <tbody>
	    <?php 
								$slNo	= 1;
								foreach($arrKol as $kol){
									echo '<tr id=KOL_'.$kol['id'].'>';
									echo '<th>' .$slNo. '</th>';
										echo "<td class='export'>
												<input type='checkbox' name='exportId[]' value='$kol[id]'>
											</td>";
									if($kol['salutation']<='4'&& $kol['salutation']!='0'){
										$name	= $arrSalutations[$kol['salutation']] . ' ';
									}else{
										$name='';
									}
									/*$name	.= $kol['first_name'] . ' ';
									$name	.= $kol['middle_name'] . ' ';
									$name	.= $kol['last_name'];*/
									$name = $this->common_helper->get_name_format($kol['first_name'], $kol['middle_name'], $kol['last_name']);
									echo '<td><a href="'.base_url().'kols/edit_kol/'.$kol['kol_id'].'">' .$name. '</a></td>';
									if($kol['specialty']!='0'){
										echo '<td>' .$arrSpecialties[$kol['specialty']]. '</td>';
									}else{
										echo '<td> &nbsp; </td>';
									}
									if($kol['request_for'] == REQUEST_TYPE_PROFILE)
						       			$kol['request_for'] = 'Profile';
						       		else
						       			$kol['request_for'] = 'Upgrading';
       			
									echo '<td>' .$kol['request_for']. '</td>';
									echo '<td>' .$kol['name']. '</td>';
									
									echo '<td>' .$kol['user_full_name']. '</td>';
						
								
									echo '<td>' .$kol['status']. '</td>';
									echo '</tr>';
									
									$slNo++;
								}
							
							?>
			  </tbody>
			</table>
	</div>
	</div>
</div>
<!-- Container for the 'Kol's Export' modal box -->
			<div id="exportKolsDialog">	
				<div id="exportKolsContainer" class="microProfileDialogBox">
					<div class="profileContent" id="exportKolsProfileContent"></div>
				</div>
			</div>
			<!--End of  Container for the 'Kol's Export' modal box -->	
