<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
/*    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }*/
    /*	#medContainer{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        /*text-align: center;*/
    }
    table{
 font-size:14px;   
}
	th{
         height:40px;   
        }
        td{
         margin-top:-15px;  
        }
    table caption{
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
    }
    /*	table {
            border: 1px solid #DDDDDD;
        }*/
    
    tr.tableHeader th{
		background-color:#C4D8EF;
		/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -274px transparent;*/
		color: #4D7BD6;
	}
    table th{
       
    }
    tr.tableSubHeader th{
        background-color:#eee;
    }
    .oddRow {
        background-color: #F5F5F5;
    }
    div.deleteIcon{
        float: none;
    }
    .type, .product, .topic{
        width:100%;
    }
    
</style>
<!--<button value="Back To List Field Compliance Monitoring" onclick="window.history.back();">Back To List Field Compliance Monitoring</button>-->
<div id="medContainer">
   <fieldset style="border-color:#4D7BD6;">
		<legend style="color:#4D7BD6;">Compliance Monitoring</legend>
    <table >
          <tr class="">
            <th>Compliance ID:</th>
            <td colspan="2"><?php  echo $arrData['generic_id'] ?></td>
        </tr>
        <tr class="oddRow">
            <th>01)</th><th style="text-align: left">Name of FMA </th>
            <td colspan="2"><?php echo $arrData['monitored_by_name']; ?></td>
        </tr>
         <tr class="evenRow">
            <th>02)</th><th style="text-align: left">Name of Monitor</th>
            <td colspan="2"><?php  foreach ($managers as $key => $valueE) {
                                if ($valueE['id']==$managerId) {
                                   echo $valueE['first_name'].$valueE['last_name'];
                                
            } }?></td>
        </tr>
        <tr class="evenRow" >
            <th>03)</th><th align="left">Date of Visit:</th>
            <td colspan="2"><?php  echo $arrData['date']; ?></td>
        </tr>
        <tr class="oddRow">
            <th>04)</th><th align="left">Location(s) of interactions observed during visit:</th>
            <td colspan="2">
                <?php 
                $arrLocationData = explode(', ', $arrData['location']);
                $separator = '';
                foreach ($arrLocationData as $key => $value) {
                    echo $separator . $arrLocations[$value];
                    $separator = ', ';
                }
                ?>
            </td>
        </tr>
     
       
          <tr class="evenRow">
            <th>05)</th>
            
                <th style="text-align: left"><?php echo lang("KTL");?>(s) in Attendance</th>
                <td colspan="2"><?php
                    foreach ($arrKOLs as $key => $arrRow) {
                        echo $arrRow['first_name'] . ' ' . $arrRow['middle_name'] . ' ' . $arrRow['last_name'] . '<br />';
                    }
                    ?></td>
            
              
               
               
          
        </tr>
        
              <tr class="evenRow">
            <th></th>
            
                <th style="text-align: left">HCO(s) in Attendance</th>
                <td colspan="2"><?php
                    foreach ($arrOrgs as $key => $arrRow) {
                        echo $arrRow['name'] . '<br />';
                    }
                    ?></td>
            
              
              
               
          
        </tr>
           <tr class="oddRow">
            <th></th><th style="text-align: left">Location</th>
            <td colspan="2"><?php  foreach ($arrStates as $key => $arrRow) {
                        if($arrRow["state_id"]==$arrData["state_id"])
                            echo "<b>State:</b>&nbsp;".$arrRow["state_name"];
                    }
                    foreach ($arrCity as $key => $arrRow) {
                        if($arrRow["city_id"]==$arrData["city_id"])
                            echo "<b>&nbsp;&nbsp;City:</b>&nbsp;".$arrRow["city_name"];
                    }
                    ?> </td>
        </tr>
        <tr class="oddRow">
            <th>06)</th><th align="left">Interaction Grouping:</th>
            <td colspan="2"><?php echo $arrData['interaction_mode']; ?></td>
        </tr>
        <tr class="evenRow">
            <th>07)</th><th align="left">Purpose of Visit:</th>
            <td colspan="2"></td>
        </tr>
        <tr class="evenRow">
            <th></th>
            <td colspan="3">
                <table style="margin-top:5px;">
                  
                    <tr class="tableSubHeader">
                        <th style="width:100px;">Product</th><th style="width:100px;">Type</th><th style="width:100px;">Topic</th><th></th>
                    <?php 
                    foreach ($arrTopics as $key => $value) {
                       
                            ?>

                            <tr>
                                 <td><?php foreach($arrProductInt as $products ){
                                    if($products["id"]==$value['product_id'])
                                        echo $products['name']; 
                                
                                    
                                    
                                } ?></td>
                                <td><?php foreach($arrTypeInt as $types ){
                                    if($types["id"]==$value['type_id'])
                                        echo $types['name']; 
                                
                                    
                                    
                                }
                                
                                
                                ?></td>
                              
                                <td><?php  foreach($arrTopicInt as $intTopics ){
                                    if($intTopics["id"]==$value['topic_id'])
                                        echo $intTopics['name']; 
                                
                                    
                                    
                                }  ?></td>
                                <td></td>
                            </tr>
                        <?php
                        
                    }
                    ?>
                    </tr>
                    <?php
                    foreach ($arrTopics['is_additional_topic'] as $key => $value) {
                        if ($value == 0) {
                            ?>

                            <tr>
                                <td><?php echo $arrTopics['types'][$key]; ?></td>
                                <td><?php echo $arrTopics['product_names'][$key]; ?></td>
                                <td><?php echo $arrTopics['topic_names'][$key]; ?></td>
                                <td></td>
                            </tr>
                        <?php
                        }
                    }
                    ?>
                </table>
<!--                <table style="margin-top:5px;">
                    
                    <tr class="tableSubHeader">
                        <th style="width:25%;">Type</th><th style="width:25%;">Product</th><th style="width:50%;">Topic</th><th></th>
                    </tr>
                    <?php
                    foreach ($arrTopics['is_additional_topic'] as $key => $value) {
                        if ($value == 1) {
                            ?>

                            <tr>
                                <td><?php echo $arrTopics['types'][$key]; ?></td>
                                <td><?php echo $arrTopics['product_names'][$key]; ?></td>
                                <td><?php echo $arrTopics['topic_names'][$key]; ?></td>
                                <td></td>
                            </tr>
                        <?php
                        }
                    }
                    ?>
                </table>-->
            </td>
        </tr>
        <tr class="oddRow">
            <th>08)</th><th align="left">Off-Label Inquiry:</th>
            <td><?php echo ucfirst($arrData['off_label_inquiry']); ?></td>
            <td></td>
        </tr>
        <tr class="oddRow toggleOffLabelInquiry">
            <th></th><th align="left">a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; was the inquiry unsolicited?</th>
            <td><?php echo ucfirst($arrData['inquiry_unsolicited']); ?></td>
            <td></td>
        </tr>
        <tr class="oddRow toggleOffLabelInquiry">
            <th></th><th align="left">b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Was MSL/MML Response consistent with
                company policy?</th>
            <td><?php echo ucfirst($arrData['response_consistancy']); ?></td>
            <td></td>
        </tr>
        <tr class="evenRow">
            <th>09)</th><th align="left">Did you identify any compliance violations?</th>
            <td><?php echo ucfirst($arrData['compliance_violation']); ?></td>
            <td></td>
        </tr>
        <?php if($arrData['violation_description']!=''){?>
        <tr class="oddRow toggleViolationDescription">
            <th>10)</th><th align="left" colspan="3">If the answer to question 09 is "yes", please explain
                and ensure the Director or Vice President informs the
                Chief Compliance Officer within two (2) business days.</th>
        </tr>
        <tr class="oddRow toggleViolationDescription"><th></th>
            <td colspan="3" >
<?php echo $arrData['violation_description']; ?>
            </td>
        </tr> <?php }?>
        <tr class="oddRow toggleViolationDescription"><th></th><th>Recorded By:&nbsp;&nbsp;&nbsp;<?php echo $arrData['created_user']; ?></th>
<th>Recorded On:&nbsp;&nbsp;&nbsp;<?php echo $arrData['compliance_violated_by_date']; ?></th>        </tr>
    </table>

</div>
