<style type="text/css">
	#submitBtn{
		display: none;
		margin-right: 80px;
	}
	.imgContainer {
		border: 1px solid #CCCCCC;
	    border-radius: 2px;
	    cursor: pointer;
	    float: right;
	    height: 90px;
	    margin-right: 150px;
	    margin-top: 0;
	    padding: 5px;
	    width: 90px;
	}
	.imgContainer .imgUploadLink{
		background-color: #CCD9EA;
	    color: #0000FF;
	    cursor: pointer;
	    display: block;
	    font-weight: normal;
	    margin-top: 0;
	    position: relative;
	    text-align: center;
	    text-decoration: none;
	    top: -23px;
	}
	#imgFile{
		display: none;
	}
	#userEditedData .imgContainer .error{
		position: absolute;
	}
	#prevImage{
		height: 90;
		width: 90;
	}
</style>
<script type="text/javascript">
var validationRules	=  {
		data_1: {
			required:true
		},
		data_2: {
			required:true
		},
		data_4: {
			required:true,
			phoneUS: true,
			maxlength: 16,
			minlength:6
		},
		imageUpload: {
			accept: "png|jpe?g|gif"
			}
	};

	var validationMessages = {
			data_1: {
				required: "Required"
			},
			data_2: {
				required: "Required"
			},
			data_4: {
				required: "Enter the valid phone number"
			}
	};
		
	$(document).ready(function(){
		$("#userEditedData").validate({
			rules: validationRules,
			messages: validationMessages
		});
		jQuery.validator.setDefaults({
	        ignore: []
	    });
		jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
		    phone_number = phone_number.replace(/\s+/g, ""); 
			return this.optional(element) || phone_number.length > 9 &&
				phone_number.match(/\(?[0-9]{2,}\)?(-?)\(?[0-9]{3,}?\)?(-?)[0-9]{4,}/);
		}, "Please specify a valid phone number");		
		});
	function editUserData(){
			$("#submitBtn").css("display","block");
			$("#imgFile").css("display","block");
			$("#editBtn").hide();
			var i = 1;
			$("tr.inlineEditable td").each(function(){
					$(this).html("<input type='text' name='data_"+i+"' value='"+$(this).text()+"' size='30'></input>");
					i++;
				});
//			$(".imgContainer").append("<label class='imgUploadLink' href='#' onclick='uploadImage();'>Upload image</label>");
		}
	function cancelEdit() {
		$("#editBtn").show();
		$("#submitBtn").css("display","none");
		$("#actionBtnIcon").replaceWith('<label id="actionBtnIcon" onclick="editUserData();" class="link" style="width: 60px; float: right;"><div class="actionIcon editIcon"></div>Edit</label>');
		call_selected_setting("user_profile");
	}

	function updateUserData(){
		if(!$("#userEditedData").validate().form()){
			return false;
		}else{
			$("#userEditedData").submit();
		}
	}

	function uploadImage(){
			$( "#imgFile" ).trigger( "click" );
		}


	function readURL(input) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        $('#prevImage').attr('src', e.target.result);
	       }
	        reader.readAsDataURL(input.files[0]);
	       }
	    }
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>User Profile</h3></div>
	</div>
	<div id="editBtn">
		<label id="actionBtnIcon" onclick="editUserData();" class="link" style="width: 60px; float: right;"><div class="actionIcon editIconWithButton"></div>Edit</label>
	</div>
</div>
<div class="pageWrapper">
	<form name="userEditedData" id="userEditedData" action="<?php echo base_url();?>user_settings/update_user_data" method="post"  enctype="multipart/form-data">
		<div class="imgContainer">
			<?php if($arrUserDetails['mem_pic'] != ''){?>
			<input type="hidden" name="prevImage" value="<?php echo $arrUserDetails['mem_pic'];?>"></input>
			<img id="prevImage" height="90" width="90" src="<?php echo base_url()?>images/user_profile_images/<?php echo $arrUserDetails['mem_pic'];?>"></img>
			<input type='file' name='imageUpload' id='imgFile' onchange="readURL(this);" value="<?php echo $arrUserDetails['mem_pic'];?>">
			<?php }else{?>
			<img id="prevImage" height="90" width="90" src="<?php echo base_url()?>images/user_profile_images/male_doc_full.png"></img>
			<input type='file' name='imageUpload' id='imgFile' onchange="readURL(this);" value="">
			<?php  }?>
		</div>
		<table class="userDetails" style="width: 60%; margin: 20px auto auto;">
			<tr>
				<th>Username:</th>
				<td><?php echo $arrUserDetails['user_name'];?></td>
			</tr>
			<tr>
				<th>E-mail:</th>
				<td><?php echo $arrUserDetails['email'];?></td>
			</tr>
			<tr>
				<th>Company name:</th>
				<td><?php echo $arrUserDetails['company_name'];?></td>
			</tr>
			<tr>
				<th>User groups:</th>
				<td><?php echo $arrUserDetails['group_name'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>First name:</th>
				<td><?php echo $arrUserDetails['first_name'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>Last name:</th>
				<td><?php echo $arrUserDetails['last_name'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>Title:</th>
				<td><?php echo $arrUserDetails['title'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>Phone:</th>
				<td><?php echo $arrUserDetails['phone'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>Department:</th>
				<td><?php echo $arrUserDetails['department'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>Address:</th>
				<td><?php echo $arrUserDetails['address'];?></td>
			</tr>
			<tr class="inlineEditable">
				<th>About me:</th>
				<td><?php echo $arrUserDetails['about'];?></td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<div id="submitBtn">
						<input type="button" name="fg" onclick="cancelEdit();"  value="Cancel">
						<input type="button" onclick="updateUserData();" value="Submit">
					</div>
				</td>
			</tr>
		</table>
	</form>
</div>
