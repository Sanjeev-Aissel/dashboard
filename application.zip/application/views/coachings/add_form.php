<?php
/*
 * Controller for the new module 'KOL Rating' 
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v3.7 Abbott 1.0
 * Created on	: 17-03-2012
 *  
 */

	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.datepicket',
							'chosen.jquery'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

	$optionValues	= '
						<option value="">Select Scale</option>
						<option value="1">Not Met</option>
						<option value="2">Partially Met</option>
						<option value="3">Fully Met</option>
						<option value="4">Exceeds</option>
                                                <option value="0" >N/A</option>
                                               
					';
        $scoreValues	= '
						<option value="">Select Scale</option>
						<option value="1">Not Met</option>
						<option value="2">Partially Met</option>
						<option value="3">Fully Met</option>
						<option value="4">Exceeds</option>
                                                <option value="0" >N/A</option>
                                               
					';
?>
  <script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>
<?php 

$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
?>
  
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
        select{
         width:234px;   
        }
    
/*	#addCoaching{
		width: 805px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
	}
*/
	legend {
	    color: #ececec;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		background:#ececec;
		color: #4D7BD6;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	select.chosenMultipleSelect, select{
		width:200px;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.scoreContainer{
		color:#000;
	}
	
	#addCoaching .add-icon{
        background-image: url("<?php echo base_url();?>images/add_active.png");
        background-repeat: no-repeat;
	    background-size: 20px auto;
	    cursor: pointer;
	    display: inline-block;
	    height: 27px;
	    vertical-align: middle;
	    width: 25px;
            background-size: 21px;
               background-repeat: no-repeat;
    }
    #addCoaching .remove-icon{
    	background-image: url("<?php echo base_url();?>images/delete_active.png");
    	background-repeat: no-repeat;
	    background-size: 20px auto;
	    cursor: pointer;
	    display: inline-block;
	    height: 27px;
	    vertical-align: middle;
	    width: 25px;
              background-size: 21px;
    }
    .spanImp{
    color:#FF0000;    
    }

/*box-shadow: 0 0 4px #d1d1d1   inset;


border: 1px solid #ececec  ;*/


input[type="text"], input[type="password"], select {
  border: 1px solid #d3d3d3  ;
}
</style>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
	var totalScore	= 0;
	var arrPlanScore = new Array();
	var totalPlanScore	= 0;
	var arrOpenScore = new Array();
	var totalOpenScore	= 0;
	var arrMedScore = new Array();
	var totalMedScore	= 0;
	var arrWrapScore = new Array();
	var totalWrapScore	= 0;
        var count = 0;
        var autosearchId;
	function validateSelect(){
		var doSubmitForm    = true;
		$('#coachingForm select').each(function (index){
			var value    = $(this).attr('value');
			switch(value){
				case 'Select Username':
			    case 'Select Specialty':
			    case 'Select Scale':
			    case '': 
			    $(this).parent().parent().css('color','red');
			    $(this).css('border-color','red');
			    doSubmitForm    = false;
			    break;
			    default:
					$(this).parent().parent().css('color','#333');
		            $(this).css('border-color','#333');
				    break;
		        }
		 });
		 if(doSubmitForm){
		 	$('#coachingForm').submit();
		 }
	}
        
        function validate(){
    jQuery.extend(jQuery.validator.messages, {
    required: "Required.",
    remote: "Please fix this field.",
    email: "Please enter a valid email address.",
    url: "Please enter a valid URL.",
    date: "Please enter a valid date.",
    dateISO: "Please enter a valid date (ISO).",
    number: "Please enter a valid number.",
    digits: "Please enter only digits.",
    creditcard: "Please enter a valid credit card number.",
    equalTo: "Please enter the same value again.",
    accept: "Please enter a value with a valid extension.",
    maxlength: jQuery.validator.format("Please enter no more than {0} characters."),
    minlength: jQuery.validator.format("Please enter at least {0} characters."),
    rangelength: jQuery.validator.format("Please enter a value between {0} and {1} characters long."),
    range: jQuery.validator.format("Please enter a value between {0} and {1}."),
    max: jQuery.validator.format("Please enter a value less than or equal to {0}."),
    min: jQuery.validator.format("Please enter a value greater than or equal to {0}.")
});
//            $.validator.setDefaults({ ignore: ":hidden:not(select)" });
            if($("#coachingForm").validate().form()){
                    var isAnyHCPManual = false;
         
            $("#kolSearch .autocompleteInputBox").each(function(){
                if($(this).val() != ''){
					var thisId = $(this).attr('id');
					if($("."+thisId+"_hidden").length){
						
					}else
						isAnyHCPManual = true;
                }
            });
           
            
          
             if(isAnyHCPManual){
             jAlert("Please select KTL  from Auto Suggestions");
             return false;
            }

          
                $("#coachingForm").submit();
            }
            else{
                return false;
            }
        }
//	function calTopicScore(thisEle,index,topic){
//		var currValue	= 0;
//		var length		= 0;
//		var total		= 0;
//		switch(topic){
//			case 'plan':
//                           
//				if(arrPlanScore[index]>=0){
//					totalPlanScore -= parseInt(arrPlanScore[index]);
//					arrPlanScore[index]	= 0;;
//				}
//				currValue	= parseInt($(thisEle).attr('value'));
//                              var  isnan=isNaN(parseInt($(thisEle).attr('value')));
////                                alert(currValue);
//				if(currValue>=0){
//					arrPlanScore[index]	= currValue;
//					totalPlanScore += parseInt(arrPlanScore[index]);
//				}
//				length	= 0;
//				$.each(arrPlanScore,function(i,value){
//                                   
//                                            if(i>0 && typeof value !== "undefined"){
//                                            length++; 	}
//                                       
//					
//				});
//                                if(isnan)
//                                    length=length-1;
//				total	= parseFloat(totalPlanScore/(length));
//				if(!(total>=0)){
//					total	= 0;
//				}
//				$('#planScore').html(total.toFixed(2));
//				$('#scoreforplan').val(total.toFixed(2));
////                                alert("index:"+index+",arrindexvalue:"+arrPlanScore[index]);
//                                
//			break;
//			case 'open':
//				if(arrOpenScore[index]>0){
//					totalOpenScore -= parseInt(arrOpenScore[index]);
//					arrOpenScore[index]	= 0;
//				}
//				currValue	= parseInt($(thisEle).attr('value'));
//                                  var  isnan=isNaN(parseInt($(thisEle).attr('value')));
//				if(currValue>=0){
//					arrOpenScore[index]	= currValue;
//					totalOpenScore += parseInt(arrOpenScore[index]);
//				}
//				length	= 0;
//				$.each(arrOpenScore,function(i,value){
//					if(i>0 && typeof value !== "undefined")
//						length++;	
//					
//				});
//                                if(isnan)
//                                    length=length-1;
//				total	= parseFloat(totalOpenScore/(length));
//				if(!(total>=0)){
//					total	= 0;
//				}
//				$('#openScore').html(total.toFixed(2));
//				$('#scoreforopen').val(total.toFixed(2));
//			break;
//			case 'med':
//				if(arrMedScore[index]>0){
//					totalMedScore -= parseInt(arrMedScore[index]);
//					arrMedScore[index]	= 0;
//				}
//				currValue	= parseInt($(thisEle).attr('value'));
//                                  var  isnan=isNaN(parseInt($(thisEle).attr('value')));
//				if(currValue>=0){
//					arrMedScore[index]	= currValue;
//					totalMedScore += parseInt(arrMedScore[index]);
//				}
//				length	= 0;
//				$.each(arrMedScore,function(i,value){
//                                           if(i>0 && typeof value !== "undefined")
//						length++;	
//					
//				});
//                                if(isnan)
//                                    length=length-1;
//				total	= parseFloat(totalMedScore/(length));
//				if(!(total>=0)){
//					total	= 0;
//				}
//				$('#medScore').html(total.toFixed(2));
//				$('#scoreformed').val(total.toFixed(2));
//			break;
//			case 'wrap':
//				if(arrWrapScore[index]>0){
//					totalWrapScore -= parseInt(arrWrapScore[index]);
//					arrWrapScore[index]	= 0;
//				}
//                              
//				currValue	= parseInt($(thisEle).attr('value'));
//                                
//                                  var  isnan=isNaN(parseInt($(thisEle).attr('value')));
//                                  
//				if(currValue>=0){
//					arrWrapScore[index]	= currValue;
//					totalWrapScore += parseInt(arrWrapScore[index]);
//				}
//				length	= 0;
//				$.each(arrWrapScore,function(i,value){
//					if(i>0 && typeof value !== "undefined")
//						length++;	
//					
//				});
//                                if(isnan)
//                                    length=length-1;
//				total	= parseFloat(totalWrapScore/(length));
//				if(!(total>=0)){
//					total	= 0;
//				}
//				$('#wrapScore').html(total.toFixed(2));
//				$('#scoreforwrap').val(total.toFixed(2));
//			break;
//		}
//		totalScore	= (parseFloat($('#planScore').html())+parseFloat($('#openScore').html())+parseFloat($('#medScore').html())+parseFloat($('#wrapScore').html()));
//		$('#totalScore').html(totalScore);
//		$('#scorefortotal').val(totalScore);
//	}
	function cancelCoachingForm(){
		 window.location=base_url+'coachings/list_coachings';
	}
        
        function removeMoreKols(id,thisEle){
            $(id).remove();
            $(thisEle).remove();
            $("."+id+"br").remove();
            $("."+id).remove();
             $("." + id+"_hidden").remove();
        }
        function addMoreKols(){
            count=count+1;
            $("#kolSearch").append("<br class='kolName"+count+"br'/><input id='kolName"+count+"'  class='required autocompleteInputBox kolName"+count+"' autocomplete='off' type='text' placeholder='Search HCP' /><a class='remove-icon' onclick=\"removeMoreKols('kolName"+count+"',this)\"></a>")
        }
//        $("#kol_id").on('click',function(){
//        
//        $('#kol_id').autocomplete(kolAutoCompleteOptions);
//    });
    var kolAutoCompleteOptions = {
    
       serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete',
        <?php echo $autoSearchOptions; ?>,
       onSelect: function(event, ui) { 
       var selText = $(event).children('.kolName').html(); 
       
       var id = $(event).children('.id1').html();
//       /alert(id);
    
       selText=selText.replace(/\&amp;/g,'&');
        $('#'+autosearchId).val(selText);
         $("."+autosearchId+"_hidden").remove();
        $('#contact_id').val(id);
        $("#kolSearch").append("<input type='hidden' class='"+autosearchId+"_hidden'  name=kol[] value='"+id+"'>");
        }
       };
	$(document).ready(function(){
		$('#date').datepicker({
			dateFormat: 'mm/dd/yy'
		});
//		$('.').chosen({allow_single_deselect: true});
//		$('.chosenMultipleSelect').chosen({
//			no_results_text: "KOL not found with the name ",
//			placeholder_text : "Click to Select KOL Name(s)",
//			allow_single_deselect: true
//		});
                $("input").live('click',function(){
         
                var id=$(this).attr("id");
                autosearchId=id;
               
               
                $('#'+id).autocomplete(kolAutoCompleteOptions);
      });
	});

	function checkPreviousEntry(thisEle){
          
           
		var userId = $(thisEle).val();
              var flag=0;
             
        $.ajax({
			url:base_url+"coachings/is_coaching_exist_for_user/"+userId,
			dataType:'json',
                        async:false,
			success:function(returnData){
                            
				if(returnData.coaching_id != 0){
                                        
           jConfirm('An entry for the selected user was found.Are you sure you want to reload the page with exisiting details?', 'Confirmation Dialog', function(r) {
            if(r==true)
            {flag=1;
                       window.location = base_url+"/coachings/add_coaching/"+userId;
            }
});
					
                }
                else{
                  
        }
                
                
                 
                      
       		}
	    });
    }
    
</script>

<div id="addCoaching">

	<div id="addFormWrapper">
		<h5 class="heading">New Field Coaching</h5>
	</div>
<form action="<?php echo base_url();?>coachings/save_coaching" method="post" name="msl_coaching_form" id="coachingForm">
	<table style="margin-top:5px;">
		<caption style="font-weight: bold;">General Information</caption>
		<tr>
			<th class="alignRight">MSL Name <span class="spanImp">*&nbsp;</span>:</th>
			<td><select name="usernames" class="  required alignment"  onchange="checkPreviousEntry(this);">
				<option  value="">Select User</option>
                                
				<?php    if(count($interactionDetails)==0){foreach($arrClientUsers as $key=>$row){
                                    if($row['id']==$interactionDetails["user_id"])
					echo '<option selected value="'.$row['id'].'">'.$row['first_name'].' '.$row['last_name'].'</option>';
                                    else
                                        echo '<option  value="'.$row['id'].'">'.$row['first_name'].' '.$row['last_name'].'</option>';
                                }}
                                else{
                                    foreach($arrClientUsers as $key=>$row){
                                   
                                        echo '<option  value="'.$row['id'].'">'.$row['first_name'].' '.$row['last_name'].'</option>';
                                }
                                }
                                    ?> 
			</select></td>
			<td>&nbsp;</td>
			<th class="alignRight">Date<span class="spanImp">*&nbsp;</span>:</th>
			<td><input type="text" class='required alignment' name="date" value="<?php echo date('m/d/Y');?>" id="date" /></td>
		</tr>
		<tr>
			<th class="alignRight">Therapeutic Area<span class="spanImp">*&nbsp;</span>:</th>
			<td><select name="specialty" class=" required alignment">
				<option value="">Select Therapeutic Area</option>
				<?php foreach($arrSpecialties as $key=>$row){
					echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
				}?>
			</select></td>
			<td>&nbsp;</td>
			<th class="alignRight" style="  
  margin-top: 9px;
  /* margin-right: 1px; */
  float:right;
  margin-left: -5px;"><?php echo lang("HCP");?> Name(s)<span class="spanImp">*&nbsp;</span>:</th>
                        <td id="kolSearch">
                            <?php  if(count($interactionDetails)==0){?>
                            <input id='kolName'  class='autocompleteInputBox required alignment' autocomplete='off' type='text' placeholder='Search <?php echo lang("HCP"); ?>' /><a class='add-icon' onclick="addMoreKols()"></a><span id="moreKol"></span>
                       
                            <?php } ?>

                            <?php 
                                                                       

							if(count($interactionDetails)>0){
                                                            
                                                               
                                                                echo "<input id='kolName'  class='required autocompleteInputBox' autocomplete='off' value='".preg_replace('#<a.*?>([^>]*)</a>#i', '$1', $interactionDetails['kol_name'])."' type='text' placeholder='Search HCP' /><a class='add-icon' onclick=\"addMoreKols()\"></a><span id=\"moreKol\"></span>";
                                                                echo "<input type='hidden' class='kolName_hidden'  name=kol[] value='".$interactionDetails['kol_id']."'>"; 
                                                                
                                                              
                                                       
							}
						?>
                        </td>
		</tr>
		<tr>
			<th class="alignRight">Engagement Status<span class="spanImp">*&nbsp;</span>:</th>
			<td><select  name="status" class="required alignment">
                                <option value="" >Select Engagement Status</option>
				<?php  foreach($arrEngagement as $values){
					echo '<option value="'.$values['status'].'">'.$values['status'].'</option>';
				}?>
			</select></td>
			<td>&nbsp;</td>

		</tr>
	</table>

	<fieldset style=" border: 1px solid #d3d3d3  ;">
		<legend style="color:#000;">Evaluation Details</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter">Weight</th><th class="alignCenter">Topic</th><th class="alignCenter" style="width: 160px;">Evaluation (use scale below)</th>
			</tr>
			<tr class="tableSubHeader">
				<th>25%</th>
				<th>Planning and Preparation<span class="spanImp">*&nbsp;</span></th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Has a firm understanding of KDMs, their role within health system and their sphere of influence</td>
				<td>
					<select name="plan_topic1" class="required" onchange="calTopicScore(this,'1','plan');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Has a detailed understanding of KDM needs and drivers of decision making</td>
				<td>
					<select name="plan_topic2" class="required" onchange="calTopicScore(this,'2','plan');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Clearly identifies objective(s) prior to meeting</td>
				<td>
					<select name="plan_topic3" class="required" onchange="calTopicScore(this,'3','plan');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified available tools, resources and support needed for use with KDM</td>
				<td>
					<select name="plan_topic4" class="required" onchange="calTopicScore(this,'4','plan');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified and prepared for potential KDM questions that may arise during interaction</td>
				<td>
					<select name="plan_topic5" class="required" onchange="calTopicScore(this,'5','plan');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
                        
			<tr class="scoreContainer">
                            <th ></th><th>Over All Score</th>
				<td><select name="scoreforplan" class="required" onchange="">
						<?php echo $scoreValues;?>
					</select></td>
				
			</tr>
			<tr class="tableSubHeader">
				<th>10%</th>
				<th>Rapport Building Dialogue<span class="spanImp">*&nbsp;</span></th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively connected/reconnected with KDM to establish constructive environment for engagement</td>
				<td>
					<select name="open_topic1" class="required" onchange="calTopicScore(this,'1','open');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Effectively set the tone and communicated objective(s) of interaction</td>
				<td>
					<select name="open_topic2" class="required" onchange="calTopicScore(this,'2','open');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr class="scoreContainer">
				
                            <th ></th><th>Over All Score</th>
				<td><select name="scoreforopen" class="required" onchange="">
						<?php echo $scoreValues;?>
					</select></td>
			</tr>
			<tr class="tableSubHeader">
				<th>50%</th>
				<th>Medical Dialogue<span class="spanImp">*&nbsp;</span></th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively listened to KDM and understood their issues, concerns, and medical needs within health system</td>
				<td>
					<select name="med_topic1" class="required" onchange="calTopicScore(this,'1','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified the barriers for care delivery through effective engagement and dialogue with KDM</td>
				<td>
					<select name="med_topic2" class="required" onchange="calTopicScore(this,'2','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Asked questions to gain better understanding of health care system and landscape including patient flow and other KDM influencers</td>
				<td>
					<select name="med_topic3" class="required" onchange="calTopicScore(this,'3','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Discussed and shared ideas with KDM that appropriately addressed barriers to care delivery within health system through evidence application</td>
				<td>
					<select name="med_topic4" class="required" onchange="calTopicScore(this,'4','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Competently shared product and disease state information including appropriate use of FMA resources and tools</td>
				<td>
					<select name="med_topic5" class="required" onchange="calTopicScore(this,'5','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Responded appropriately to unsolicited KDM requests for information including use of FMA resources and tools</td>
				<td>
					<select name="med_topic6" class="required" onchange="calTopicScore(this,'6','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
                          <tr>
				<td></td>
				<td>Respectfully challenged KDM when faced with positions that go against evidence based data and its appropriate application</td>
				<td>
					<select name="med_topic7" class="required" onchange="calTopicScore(this,'7','med');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr class="scoreContainer">
                             <th ></th><th>Over All Score</th>
				<td><select name="scoreformed" class="required" onchange="">
						<?php echo $scoreValues;?>
					</select></td>
				
			</tr>
			<tr class="tableSubHeader">
				<th>15%</th>
				<th>Next Steps<span class="spanImp">*&nbsp;</span></th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Reviewed action items including questions that need follow-up at conclusion of interaction</td>
				<td>
					<select name="wrap_topic1" class="required" onchange="calTopicScore(this,'1','wrap');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified and reported medical insights gleaned from interaction within 5 business days</td>
				<td>
					<select name="wrap_topic2" class="required" onchange="calTopicScore(this,'2','wrap');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Took appropriate steps to secure a follow up appointment to address action items including scheduling of educational presentations and/or collaborative opportunities</td>
				<td>
					<select name="wrap_topic3" class="required" onchange="calTopicScore(this,'3','wrap');">
						<?php echo $optionValues;?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Completed MIRF including documenting unsolicited customer requests for off-label information consistent with company policies</td>
				<td>
					<select name="wrap_topic4" class="required" onchange="calTopicScore(this,'4','wrap');">
						<?php echo "<option value='' >Select Scale</option>"; 
                                                echo "<option value='2'>Yes</option>";
                                                
                                                echo "<option value='1' >No</option>";
                                                echo "<option value='0'>N/A</option>";
                                                
                                                ?>
					</select>
				</td>
			</tr>
			<tr class="scoreContainer">
                            <th ></th><th>Over All Score</th>
				<td><select name="scoreforwrap" class="required" onchange="">
						<?php echo $scoreValues;?>
					</select></td>
				
			</tr>
			<tr hidden class="tableSubHeader scoreContainer">
				<td><input type="hidden" name="scorefortotal" id="scorefortotal"></input></td>
				<th class="alignRight">Total Score</th>
				<th><div id="totalScore">0</div></th>
        
			</tr>
                        <tr>
                        <th style="width:80px !important;" >Evaluated By:</th>
			<td><?php echo $this->session->userdata('user_full_name');?></td>
                        </tr>
                        <tr>
                        <th style="width:80px !important;" >Comment:</th>
                        <td><textarea style="width:600px" name="comment" rows="2" col="200"></textarea></td>
                        </tr>
		</table>
	</fieldset>
        </form>
	<center>
		  <input type="submit" id="submit"   onclick="validate(); "  value="<?php echo SUBMIT_BUTTON_LABEL ?>"/>
		<input type="button" value="Cancel" onclick="cancelCoachingForm();" />
	</center>
        
        <fieldset style="border: 1px solid #d3d3d3  ;">
		<legend style="color:#000;">Anchor</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter">Rank</th><th style='width:150px;'>Values</th><th >Description</th>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Planning and Description</th>
			</tr>
			<tr>
				<td>1.</td>
				<td >Not Met</td>
				<td>
				Demonstrated little to no planning.	
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated planning was done to some degree but did not fully meet criteria and insufficient to have effective engagement with the KDM.	
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Fully met the criteria of successfully planning for a KDM meeting including appropriate research and preparation to facilitate an effective interaction.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully prepared for interaction with KDM, but also conducted additional research and preparation on the KDM’s broader interests and areas of specialty. This may extend to include other experts and key issues and findings in the field beyond the KDM.	
				</td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Rapport Building Dialogue</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not demonstrate an effective medical dialogue nor appropriately captured insights. Failed to listen and was focused on own agenda without regard to what was being said or shared. Additionally, did not ask appropriate questions to gain better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not appropriately challenge KDM where appropriate nor use available resources.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated some effort but insufficient to engage <?php echo lang("HCP");?> in an effective medical dialogue. Acknowledged views of KDM but was more focused on own agenda with only some or little regard to what was being said or shared. Made some attempt to ask questions but insufficient to gain a better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not adequately challenge KDM or fully communicate relevant disease and product information using available resources.
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Completely met the criteria for successful medical dialogue including highlighted evidenced based data and appropriate use of MSL resources to share disease and product information. Demonstrated active listening skills, asked appropriate probing questions to better understand patient flow and healthcare system to help identify issues and challenges that stand in the way of optimized care delivery. Insights gained from dialogue were sufficiently refined as applicable to <?php echo PRODUCT_NAME;?>. Appropriately and respectfully challenged KDM if their comment(s) or position(s) was/were not supported by available evidence.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully meets the criteria for successful medical dialogue but also demonstrated superior listening and probing skills to develop a thorough understanding of the KDMs issues, concerns and needs. Additionally, consistently sought opportunities to collaborate with KDM to develop health management, quality improvement, care coordination tools as well as other collaborative projects related to optimized care delivery.
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Next Steps</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not complete/adjourn the meeting by providing follow-up or action items.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
Did not appropriately complete/adjourn the meeting by providing follow-up or action items in sufficient detail. Did not secure follow-up appointment nor submit medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
Completely met the criteria for successful completion/adjournment of meeting including review of follow-up and actions items, identified the plan for determining a future interaction and submitted key medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
Not only fully meets the criteria for successful completion/adjournment of meeting, but conducted a detailed review of all follow-up and actions items, identified the plan for determining a future interaction and submitted critical medical insights shortly after meeting.				</td>
			</tr>
			
		</table>
	</fieldset>
 
</div>
