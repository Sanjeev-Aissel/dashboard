<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code{
    	width: 192px;
    }
    #org_type{
    	width: 207px;
    }
</style>
<script type="text/javascript">
    var validationRules = {
    	
    	staff_title: {
            required: true
        },
        staff_name: {
            required: true
        }
    };
    var validationMessages = {
    	staff_title: {
            required: "Required"
        },
        staff_name: {
            required: "Required"
        }
    };
    $(function () {
    	$("#saveKolStaffForm").validate({
            debug: true,
            onkeyup: true,
            rules: validationRules,
            messages: validationMessages
        });
        
    	jQuery.validator.addMethod("staffemail", function (value, element) {
        	if(value!=''){
	            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	            return regex.test(value);
        	}else {            	
                return true;
            }
        }, "Invalid email"); 
        
    	jQuery.validator.addMethod("additionl_phnumber", function (value, element) {   
    		var  phoneVal= $('.additionalPhoneType').find("option:selected").val();  
            if (value != "") {
               	if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")||(phoneVal=="Office Phone")){
                    var regex =/^(?=.*[0-9])[-+0-9]+$/;     
                    if(regex.test(value)){                	
                    	var number = value.replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing                	                	
                    	if(number.length>15){
                    		phoneMsg ="Max 15 Digit";
                        	return false;
                    	}	
                    	phoneMsg = '' ;               	
                    	return true;                	    	
                    }else{
                    	phoneMsg ="Invalid Phone Number";	               		
                     	return false;
                    }               	
               	}else{  
               		if(phoneVal==''){            		
               			//phoneMsg = 'Select Phone Type';
               			$('#phone_type_staff').text("Select Phone Type");		
                   		return false;
                   	}
               		phoneMsg = '' ;
                   	return true;
                }
            } else {            	
                return true;
            }
            
        }, function(params, element) {
        	  return phoneMsg;
        });
    	
    });
    $('#saveKolStaff').click(function () {
        if (!$("#saveKolStaffForm").validate().form()) {
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $id = '<?php if($displayContent) echo $getSavedDetails['id'];?>';
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_staff/'+$id,
            type: 'post',
            dataType: 'json',
            data: $('#saveKolStaffForm').serialize(),
            beforeSend: function(){
    			$("#saveKolStaff").attr("disabled", "disabled");
            },
            success: function (returnData) {
                if (returnData.status == true) {
                    $('.msgBox').html('<?php echo lang("KOL"); ?> Staff saved successfully');
                    $('.msgBox').fadeOut(1500);
                    setTimeout(ReloadGrid, 2000);
                } else {
                    $('.msgBox').html('Error saving <?php echo lang("KOL"); ?> Staff');
                    $('.msgBox').fadeOut(1500);
                }
            }
        });
    });
    function ReloadGrid() {
    	$('#saveKolStaff').removeAttr("disabled");
        $("#addStaffForKols").dialog("close");
        getStaffsData();
    }
    $(document).ready(function () {
	    $("#phoneTypeStaff").change(function () {
	        var phType = $('#phone_type option:selected').val();
	        if(phType > 0){
		        $('#phone_type_staff').text('');
	        }
	    });
    });
</script>
<div class="msgBox"></div>

<div id="similarNames">

</div>
<h4 style="border-bottom: 1px solid #bbbbbb;">Staff</h4>

<form action="save_kol_staff" method="post" id="saveKolStaffForm" name="saveKolStaffForm">
    <table class="requestedKols">
        <tbody>
            <tr>
                <td style="width: 50%;">
                    <table style="te">
						<tr>
							<td class="alignRight"><label for="staff_title">Title<span class="required">*</span> :</label></td>
							<td>
								<select name="staff_title" id="staff_title" class="required" >
						            <option value="">--Select--</option>
						             <?php foreach ($arrStaffTitle as $key=>$title){?>
						            <option value="<?php echo $key?>" <?php if(isset($getSavedDetails['title']) && $getSavedDetails['title']==$key) echo "selected='selected'";?>><?php echo $title;?></option>
						            <?php }?>
						            
						        </select>
							</td>
						</tr>
						<tr>
                            <td class="alignRight"><label for="staff_name">Name<span class="required">*</span> :</label></td>
                            <td>
								<input type="text" name='staff_name' id='staff_name' class="required" value="<?php if(isset($getSavedDetails['name'])) echo $getSavedDetails['name'];?>"/>
                            </td>
                        </tr>
						<tr>
                            <td class="alignRight"><label for = "phone_type">Phone Type:</label></td>
							<td>
								<select name="phone_type" id="phoneTypeStaff" class="additionalPhoneType">
									<option value="">--Select--</option>
						            <?php foreach ($arrPhoneType as $key=>$type){?>
						            <option value="<?php echo $key?>" <?php if(isset($getSavedDetails['type']) && $getSavedDetails['type']==$key) echo "selected='selected'";?>><?php echo $type;?></option>
						            <?php }?>
								</select>
								<span id="phone_type_staff" style="color:red"></span>
							</td>
                        </tr>
                        
                    </table>
                </td>

                <td>
                    <table>
                        <tr>
                            <td class="alignRight">
                                <label for="staff_location">Location :</label>
                            </td>
                            <td>
                                <select name="staff_location" id="staff_location" style="max-width: 200px;">
						             <option value="">--Select--</option>
						            <?php foreach ($arrLocations as $key=>$location){?>
						            <option value="<?php echo $key?>" <?php if(isset($getSavedDetails['location_id']) && $getSavedDetails['location_id']==$key) echo "selected='selected'";?>><?php echo $location;?></option>
						            <?php }?>
						        </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="email">Email:</label>
                            </td>
                            <td>
                                <input type="text" name='email' class="staffemail" id='email' value="<?php if(isset($getSavedDetails['email'])) echo $getSavedDetails['email'];?>"/>
                            </td>
                        </tr>
						<tr>
                            <td class="alignRight">
                                <label for="staff_phone">Phone Number:</label>
                            </td>
                            <td>
                                <input type="text" name='staff_phone' id='staff_phone' class="additionl_phnumber" value="<?php if(isset($getSavedDetails['number'])) echo $getSavedDetails['number'];?>" maxlength="15"/>
						        <input type="hidden" name="contact_type" value="kol"/>
						        <input type="hidden" name="contact" value="<?php echo $kolId; ?>"/>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <!-- End of Personal and Professional Information -->
        </tbody>
    </table>
<table>
	<tbody>
	    <tr>
	        <td colspan="2">
	            <div class="formButtons">	
                   		<input type="button" value="Save" name="submit" id="saveKolStaff"></input>
	            </div>
	        </td>
	    </tr>
	</tbody>
</table>

</form>