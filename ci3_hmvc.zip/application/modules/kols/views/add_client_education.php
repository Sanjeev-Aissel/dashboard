<?php
	$autoSearchOptions = "width:255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
  <ul class="nav nav-tabs">
    <li class="active" id="trainingNav"><a data-toggle="tab" href="#trainingTabId" >Training</a></li>
    <li id="honorsNav"><a data-toggle="tab" href="#honorsTabId" >Honors and Awards</a></li>
  </ul>
  <div class="tab-content" style="margin-top: 2%;">
	<!--Add Training details-->
	<div id="trainingTabId" class="tab-pane fade in active">
		<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
		<?php 
		$arrType = array();
		$arrType['training']= 'Training'; 
		$arrType['education']= 'Education';
		$arrType['board_certification']= 'Board Cerification';
		?>
		<form action="save_education_detail" method="post" id="trainingForm" name="trainingForm" class="validateForm ">
			<input type="hidden" name="id" id="trainId" value="<?php if(isset($eduData)) echo $eduData['id'] ?>"/>
			<input type="hidden" name="kol_id" id="kolTrainId" value="<?php echo $kolId?>"/>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Type:</label>
				<div class="col-sm-3">
		    		<select class="form-control" name="type" id ="trainingType">
						<?php foreach ($arrType as $key=>$title){?>
							<option value="<?php echo $key?>" <?php if(isset($type) && $type==$key) echo "selected='selected'";?>><?php echo $title;?></option>
						<?php }?>
					</select>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Institution Name:<span class="required">*</span></label>
				<div class="col-sm-9">
		    		<input type="hidden" name="institute_id" id="trainInstituteId" value="<?php if(isset($eduData)) echo $eduData['institutionsId'] ?>"/>
					<input type="text" name="institute_name" value="<?php if(isset($eduData)) echo $eduData['name'] ?>" id="trainInstituteName" class="required form-control autocompleteInputBox"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label trainingDegree">Degree:</label>
				<div class="col-sm-3 trainingDegree">
		    		<input class="form-control" type="text" name="degree" value="<?php if(isset($eduData)) echo $eduData['degree'] ?>" id="trainDegree"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Specialty:</label>
				<div class="col-sm-3">
					<input class="form-control"  type="text" name="specialty" value="<?php if(isset($eduData)) echo $eduData['specialty'] ?>" id="trainSpecialty"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Start Year:</label>
				<div class="col-sm-3">
		    		<input class="form-control" type="text" name="start_date" value="<?php if(isset($eduData)) echo $eduData['start_date'] ?>" id="trainStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">End Year:</label>
				<div class="col-sm-3">
					<input class="form-control" type="text" name="end_date" value="<?php if(isset($eduData)) echo $eduData['end_date'] ?>" id="trainEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" />
					<div id="trainDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">URL:</label>
				<div class="col-sm-9">
		    		<input class="form-control"  type="text" name="url1" value="<?php if(isset($eduData)) echo $eduData['url1'] ?>" id="trainUrl1" class="url"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
				<div class="col-sm-9">
		    		<input class="btn btn-default" type="button" value="Save" name="submit" id="saveTraining" onclick="saveTrainingDetail();return false;">
		    	</div>
			</div>
		</form>	
	</div>
    <div id="honorsTabId" class="tab-pane fade">
		<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
		<form action="save_education_detail" method="post" id="awardForm" name="awardForm" class="validateForm">
			<input type="hidden" name="type" value="honors_awards"/>
			<input type="hidden" name="id" id="awardId" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['id'] ?>"/>
			<input type="hidden" name="kol_id" id="awardId" value="<?php echo $kolId?>"/>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Name:<span class="required">*</span></label>
				<div class="col-sm-9">
				<input type="text" name="honor_name" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['honor_name'] ?>" id="awardHonorName" class="required form-control"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Start Year:</label>
				<div class="col-sm-3">
		    		<input class="form-control" type="text" name="start_date" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['start_date'] ?>" id="awardStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">End Year:</label>
				<div class="col-sm-3">
					<input class="form-control" type="text" name="end_date" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['end_date'] ?>" id="awardEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"/>
					<div id="awardDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">URL:</label>
				<div class="col-sm-9">
		    		<input class="form-control"  type="text" name="url1" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['url1'] ?>" id="awardUrl1" class="url"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
				<div class="col-sm-9">
		    		<input class="btn btn-default" type="button" value="Save" name="submit" id="saveAward" onclick="saveHonorNAwards();return false;">
		    	</div>
			</div>
		</form>
	</div>
  </div>
  <script>
  var type='<?php echo $type;?>';
  var a;
// Autocomplet Options for the 'Institute Name' field searches From the lookuptable
  var eduInstituteNameAutoCompleteOptions = {
  		serviceUrl: '<?php echo base_url();?>kols/kols/get_institute_names',<?php echo $autoSearchOptions;?>,
  		onSelect : function(event, ui) {
  			var selText = $(event).children('.educations').html();
  			var selId = $(event).children('.educations').attr('name');
  			selText=selText.replace(/\&amp;/g,'&');
  			$('#eduInstituteName').val(selText);
  			$('#trainInstituteName').val(selText);
  			$('#boardInstituteName').val(selText);
  			$('#eduInstituteId').val(selId);
  			$('#institute_id').val(selId);
  			if(event.length>20){
  				if(event.substring(0,21)=="No results found for "){
  					$('#eduInstituteName').val('');
  					$('#trainInstituteName').val('');
  					$('#boardInstituteName').val('');
  					return false;
  				}
  			}
  		}
  	};
  $(document).ready(function(){
	  	if(type == 'honors'){
			$('#honorsNav').addClass('active');
			$('#trainingNav').removeClass('active');
			
// 			$("#trainingTabId").hide();
//         	$("#honorsTabId").show();
		}else{
			$('#honorsNav').removeClass('active');
			$('#trainingNav').addClass('active');
			
// 			$("#trainingTabId").show();
//         	$("#honorsTabId").hide();
		}
		
	  a = $('#trainInstituteName').autocomplete(eduInstituteNameAutoCompleteOptions);
		$("#trainingType").change(function(){
	        $(this).find("option:selected").each(function(){
	            var optionValue = $(this).attr("value");
	            console.log(optionValue);
	            if(optionValue == 'board_certification'){
	                $(".trainingDegree").hide();
	            } else{
	            	$(".trainingDegree").show();
	            }
	        });
	    }).change();
		$("#trainingForm").validate({
			rules: {
				institute_name: "required"
			},
			messages: {
				module_id: {
					institute_name: "This field is required",
				}
			}
		});	
		$("#awardForm").validate({
			rules: {
				honor_name: "required"
			},
			messages: {
				module_id: {
					honor_name: "This field is required",
				}
			}
		});
  });
</script>