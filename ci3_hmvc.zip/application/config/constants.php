<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') OR define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  OR define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') OR define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   OR define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  OR define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           OR define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     OR define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       OR define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE')  OR define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   OR define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              OR define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            OR define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       OR define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        OR define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          OR define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         OR define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   OR define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  OR define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') OR define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     OR define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       OR define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      OR define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      OR define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

/*
 * Product Name, Version etc For release support reference
 */
define('PRODUCT_NAME','KOLM');
define('PRODUCT_VERSION','KOLM 1.0');
define('KOLM_VERSION','KOLM V7.0');
define('APP_PRODUCT_INFO_HEADER',PRODUCT_NAME);
define('APP_PRODUCT_INFO_FOOTER',KOLM_VERSION.' ('.PRODUCT_NAME.')');
define('COPYRIGHT','2017');

// file/folder paths 
defined('ASSETS') 			   OR define('ASSETS','assets/');
defined('MODULES_ASSETS')	   OR define('MODULES_ASSETS','assets/modules/');
defined('APPLICATION_IMAGES')  OR define('APPLICATION_IMAGES','images/');
defined('CLIENT_LAYOUT') 	   OR define('CLIENT_LAYOUT','layouts/client/client_layout');
defined('ANALYST_LAYOUT') 	   OR define('ANALYST_LAYOUT','logins/analyst_layout');
defined('CUSTOM_APP_CACHE')	   OR define('CUSTOM_APP_CACHE','custom_application_cache_files/');

defined('INTERNAL_CLIENT_ID')  OR define('INTERNAL_CLIENT_ID','1');
defined('INTERNAL_CLIENT_NAME')OR define('INTERNAL_CLIENT_NAME','Aissel');
defined('ANALYST_HEADER') 	   OR define('ANALYST_HEADER','logins/analyst_header');
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');

define('PROTOCOL', 'mail'); //
define('HOST', 'smtp.gmail.com'); //
define('PORT', 465); //
define('USER', 'soumyashet95@gmail.com');//
define('PASS', 'password044');//


defined('BLOCK_ON_NO_OF_FAILED_ATTEMPTS')   OR define('BLOCK_ON_NO_OF_FAILED_ATTEMPTS',5);
defined('ACTIVATED_USER') 					OR define('ACTIVATED_USER','0');
defined('DEACTIVATED_USER') 				OR define('DEACTIVATED_USER','1');
defined('RESTRICT_NO_OF_PASSWORDS_TO_REUSE')OR define('RESTRICT_NO_OF_PASSWORDS_TO_REUSE','1');

/* Name constant configuaration
 */
define('FIRST_ORDER','first_name');
define('SECOND_ORDER','middle_name');
define('THIRD_ORDER','last_name');
// Constants for Allign Kols/Orgs
define('MY_RECORDS',1);
define('ALL_RECORDS',2);

define('PAGINATION_VALUES','10,50,100,150');

define("CHART_COLOR_CODES",'["#537FB2","#E77368","#FBCC42","#7DCAA7","#F79820","#C3C4C6","#23885B","#0487C9","#D97000"]');
define('APP_DATE_FORMAT', 'MM/DD/YYYYY');

//Kol user conatct type default value
define('DEFAULT_ASSIGN_TYPE',2);

/*
 |--------------------------------------------------------------------------
 | Constants used for Json Store
 |--------------------------------------------------------------------------
 ||
 */
define('JSON_STORE_DASHBOARD', 100);
define('JSON_STORE_ACTIVITY', 101);
define('JSON_STORE_ACTIVITY_REPORT', 102);
define('JSON_STORE_PUBLICATIONS_BY_YEAR', 103);
define('JSON_STORE_PUBLICATIONS_BY_KEYWORDS', 104);
define('JSON_STORE_PUBLICATIONS_BY_SUBSTANCES', 105);
define('JSON_STORE_PUBLICATIONS_BY_JOURNALS', 106);
define('JSON_STORE_PUBLICATIONS_BY_TYPE', 107);

define('ROLE_MANAGER', '2');
define('ROLE_USER', '1');
/*
 |--------------------------------------------------------------------------
 | Constants used For Email
 |--------------------------------------------------------------------------
 ||
 */
define('NOTIFICATION_SENDER', 'Notifications');
define('NOTIFICATION_PROTOCOL', 'smtp');
define('NOTIFICATION_HOST', 'mail.aisselkolm.com');
define('NOTIFICATION_PORT', 25);
define('NOTIFICATION_USER', 'alerts@aisselkolm.com');
define('NOTIFICATION_PASS', 'alerts@aisselkolm.com');

define('OPTINOUT_SENDER', 'Hills');
define('OPTINOUT_PROTOCOL', 'smtp');
define('OPTINOUT_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('OPTINOUT_PORT', 465);
define('OPTINOUT_USER', 'contentservice@aissel.com');
define('OPTINOUT_PASS', 'content@aissel');

define('PROFILE_REQUEST_SENDER', 'noreply@aissel.com');
define('PROFILE_REQUEST_PROTOCOL', 'smtp');
define('PROFILE_REQUEST_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('PROFILE_REQUEST_PORT', 465);
define('PROFILE_REQUEST_USER', 'contentservice@aissel.com');
define('PROFILE_REQUEST_PASS', 'content@aissel');

define('SUPPORT_SENDER', 'noreply@aisselkolm.com');
define('SUPPORT_PROTOCOL', 'smtp');
define('SUPPORT_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('SUPPORT_PORT', 465);
define('SUPPORT_USER', 'vinodh@aissel.com');
define('SUPPORT_PASS', 'Aissel123');

define('SENDER', 'noreply@aissel.com');
define('PROTOCOL', 'smtp');
define('HOST', 'ssl://smtp.bizmail.yahoo.com');
define('PORT', 465);
define('USER', 'contentservice@aissel.com');
define('PASS', 'content@aissel');

/*
 |--------------------------------------------------------------------------
 | Constants used For Staus
 |--------------------------------------------------------------------------
 ||
 */
define('COMPLETED', 'Completed');
define('REVIEW', 'Review');
define('New1', 'New');
define('APPROVED', 'Approved');
define('PROFILING', 'Profiling');
define('PRENEW', 'Not Requested');
define('REJECT','Rejected');
define('RE_REQUEST','Re-request');
define('REQUESTED','Requested');
define('CREATED','Created');
define('UPDATED','Updated');
define('RESPONDED','Responded');

define('STATUS_COMPLETED', 100);
define('STATUS_REVIEW', 101);
define('STATUS_NEW', 102);
define('STATUS_APPROVED', 103);
define('STATUS_PROFILING', 104);
define('STATUS_REJECTED', 105);
define('STATUS_REQUESTED', 106);
define('STATUS_CREATED', 107);
define('STATUS_UPDATED', 108);
define('STATUS_RESPONDED', 109);

define('REQUEST_TYPE_PROFILE', 100);
define('REQUEST_TYPE_UPGRADE', 101);
