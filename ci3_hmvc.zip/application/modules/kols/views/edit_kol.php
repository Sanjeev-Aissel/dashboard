<?php
/**
* Description:
*
*  @package application.views.kols
*  @author:Developer
*
*  @created on:Dec 13, 2010
*
*/
function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList; 
}
?>
<style>
.navbar-global {
  background-color: indigo;
}

.navbar-global .navbar-brand {
  color: white;
}

.navbar-global .navbar-user > li > a
{
  color: white;
}

.navbar-primary {
  background-color: #ccc;
  bottom: 0px;
  left: 0px;
  position: absolute;
  top: 88px;
  width: 200px;
  z-index: 8;
  overflow: hidden;
  -webkit-transition: all 0.1s ease-in-out;
  -moz-transition: all 0.1s ease-in-out;
  transition: all 0.1s ease-in-out;
}

.navbar-primary.collapsed {
  width: 60px;
}

.navbar-primary.collapsed .glyphicon {
  font-size: 22px;
}

.navbar-primary.collapsed .nav-label {
  display: none;
}

.btn-expand-collapse {
    position: absolute;
    display: block;
    left: 0px;
    bottom:0;
    width: 100%;
    padding: 8px 0;
    border-top:solid 1px #666;
    color: grey;
    font-size: 20px;
    text-align: center;
}

.btn-expand-collapse:hover,
.btn-expand-collapse:focus {
    background-color: #222;
    color: white;
}

.btn-expand-collapse:active {
    background-color: #111;
}

.navbar-primary-menu,
.navbar-primary-menu li {
  margin:0; padding:0;
  list-style: none;
}

.navbar-primary-menu li a {
  display: block;
  padding: 10px 18px;
  text-align: left;
  border-bottom:solid 1px #e7e7e7;
  color: #333;
}

.navbar-primary-menu li a:hover {
  background-color: #fff;
  text-decoration: none;
  color: #000;
}

.navbar-primary-menu li a .glyphicon {
  margin-right: 6px;
}

.navbar-primary-menu li a:hover .glyphicon {
  color: #4285F4;
}

.main-content {
  margin-left: 200px;
  padding: 5px 20px;
}

.collapsed + .main-content {
  margin-left: 60px;
}
.nav-tabs { 
	border-bottom: 2px solid #DDD; 
}
.nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { 
	border-width: 0;
}
.nav-tabs > li > a { 
	border: none; 
	color: #666; 
}
.nav-tabs > li.active > a, .nav-tabs > li > a:hover {
	border: none; 
	color: #4285F4 !important; 
	background: transparent; 
}
.nav-tabs > li > a::after { 
	content: ""; 
	background: #4285F4; 
	height: 2px; 
	position: absolute; 
	width: 100%; 
	left: 0px; 
	bottom: -1px; 
	transition: all 250ms ease 0s; 
	transform: scale(0); 
}
.nav-tabs > li.active > a::after, .nav-tabs > li:hover > a::after {
 	transform: scale(1); 
}
.tab-nav > li > a::after { 
	background: #21527d none repeat scroll 0% 0%; 
	color: #fff; 
}
.tab-pane {
	padding: 10px 0; 
}
.tab-content{
	padding:10px 20px;
}
img.add-org {
    position: absolute;
    left: 23pc;
    top: 23px;
}
.form-group {
    margin-bottom: 5px;
}
.imageUpload {
    margin-top: 35px;
}
.alert {
    padding: 10px  !important;
    margin-bottom: 0px !important;
    }
.close {
    top: 0px  !important;
    right: 0px  !important;
    font-size:18px;
}  
input#saveContact {
    position: absolute;
    top: 22px;
}  
</style>
<script src="<?php echo base_url();?>assets/js/imgAreaSelect.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript">
		//Validation rules for Overviewform
		var validationRules	=  {
			gender: {
				required:true	
			},
			specialty: {
				required:true
			},
			first_name: {
				required:true
			},
			last_name: {
				required:true
			},
			salutation: {
				required:true
			},
			license:{
				alphaNumeric:true
			}			
		};
		//Validation messages for Overviewform
		var validationMessages = {
				gender: {
					required: "Required"
				},
				specialty: {
					required: "Required"
				},
				first_name: {
					required: "Required"
				},
				last_name: {
					required: "Required"
				},
				salutation: {
					required: "Required"
				}
			
		};
		//Validation rules for Contact Info form
		var validationRulesForContact = {
				country_id: {
					required:true
				},
				primary_phone: {
					required:true,
					phoneUS: true
				},
				fax:{
					phoneUS: true
				},
				city_id:{
					required:true
				},
				address1:{
					required:true
				},
				postal_code:{
					alphaNumeric:true
				}
				
				
			};
		//Validation Messages for Contact Info form
		var validationMessagesForContact = {
				country_id: {
					required: "Required"
				},
				primary_phone: {
					required: "Required"
				},
				city_id: {
					required: "Required"
				},
				address1:{
					required: "Required"
				}
			
		};
		// WYSIWYG editor initialition
    	var rtfEditorOptions = {
            	controls:{
    				insertImage:{visible: false},
    				insertTable:{visible: false}
            	},
            	initialContent:'',
            	autoGrow:true,
            	formWidth:600,
            	formHeight:250
    	};

		var uploadImageDialogOpts = {
				title: "Upload Image",
				modal: true,
				autoOpen: false,
				height: 550,
				width: 600,
				open: function() {
					//display correct dialog content
					//$("#uploadImage").load("/application/new_company");
				}
		};
			
		var organizationProfileDialogOpts = {
				title: "Create Organization Profile",
				modal: true,
				autoOpen: false,
				height: 400,
				width: 800,
				open: function() {
					//display correct dialog content
					//$("#organizationProfile").load("/application/new_company");
				}
		};    	    

		var options, a;
			
		// Autocomplete Options for the 'Organization Name' field
	  	var organizationAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
				width: 255,
				delimiter: /(,|;)\s*/,
				deferRequestBy: 200, //miliseconds
				noCache: true, //set to true, to disable caching
				minChars: 3
		};	

					
		$(document).ready(function(){
				$.validator.addMethod("alphaNumeric", function(value, element) {
			        return this.optional(element) || /^[a-z0-9\-]+$/i.test(value);
			    }, "This Field must contain only letters, numbers, or dashes.");

				//RTF is disabled as per client request
	    		//Rtf editor for 'Biography' fields
	    		//$('#biographyDummy').css("display", "none").wysiwyg(rtfEditorOptions);
	    		//$('#biographyDummy2').css("display", "none").wysiwyg(rtfEditorOptions);
	    		//$('#biography').wysiwyg(rtfEditorOptions);
	    	
	    		//Rtf editor for 'researchInterests' fields
	    		//$("#researchInterests").wysiwyg(rtfEditorOptions);
	    	
	    		//Rtf editor for 'notes' fields
	    		//$("#notes").wysiwyg(rtfEditorOptions);	
	    						
				//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
				$('div[id^="AutocompleteContainter_"]').remove();
								
				jQuery("#JQBlistContactsResultSet").jqGrid({
					
				   	url:'<?php echo base_url();?>kols/list_contacts',
					datatype: "json",
				   	colNames:['Id','Related To','Phone','email','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'related_to',index:'related_to', width:280,editable:true},
				   		{name:'phone',index:'phone',width:260,editable:true},
				   		{name:'email',index:'email',width:280,editable:true},
				   		{name:'act',width:60,search:false}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	loadonce:true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",		   
				   	pager: '#listContactsPager',
				   	mtype: "POST",
				   	sortname: 'id',
				    viewrecords: true,
				    sortorder: "desc",
				    gridComplete: function(){
					    var ids = jQuery("#JQBlistContactsResultSet").jqGrid('getDataIDs'); 
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];				    	
						    	be = "<a href='#' onclick=\"editContact('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
						    	be += "&nbsp; | &nbsp;";
						    	be += "<a href='#' onclick=\"deleteContact('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";

						    	jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	},
			    	loadComplete: function() {
			    	    	$("option[value=100000000]").text('All');
			    		},
				    jsonReader: { repeatitems : false, id: "0" }, 
				    editurl:"<?php echo base_url();?>kols/update_contact",		   
				    caption:"Contact Details"		    
				});
				jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','#listContactsPager',{edit:false,add:false,del:false,search:false,refresh:false});	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistContactsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistOthersResultSet").height(25).jqGrid('filterGrid',"JQBlistOthersResultSet",{gridModel:true,gridToolbar:true});
				
				jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
				jQuery("#JQBlistContactsResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:200, maxHeight:550});
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistContactsResultSet").jqGrid('navButtonAdd',"#listContactsPager",{caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}
						
					} 
				}); 
								
		// Trigger the Autocompleter for 'Organization Name' field
    	a = $('#org_id').autocomplete(organizationAutoCompleteOptions);
				
		$("#savePersonalInfo").click(function(){
			updateKolOverview();
		});

		$("#saveContactInfo").click(function(){
			updateKolContact();
		});
		$("#saveBiographyInfo").click(function(){
			$('#researchInterests').addClass('required');
			updateKolOverview();
		});
		$("#saveReferenceInfo").click(function(){
			updateKolOverview();
		});

		$('.msgBoxs').ajaxStart(function(){
			$(this).show();
			$(this).fadeIn("fast");
			$(this).removeClass('success');
			$(this).addClass('notice');
			$(this).html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
		});
		
		$('.msgBoxs').ajaxComplete(function(){
			$(this).fadeOut(1300);
		});

		$("#uploadImage").dialog(uploadImageDialogOpts);
			
		$("#uploadImageLink").click(
				function (){
					$("#uploadImage").dialog("open");
					return false;
		});

		$("#organizationProfile").dialog(organizationProfileDialogOpts);
			
		$("#organizationProfileLink").click(
				function (){
					$("#organizationProfile").dialog("open");
					return false;
		});				


		/**
		* Save the 'Contact Details'
		*/
		$("#saveContact").click(function(){				
			id = $("#contactId").val();
			var data={};
			data['id']=id;
			data['related_to']	=	$("#contactRelatedTo").val();
			data['phone']		=	$("#contactPhone").val();
			data['email']		=	$("#contactEmail").val();
			data['kol_id']		=	$("#visibilityId").val();

			$('div.contactMsgBox').removeClass('success');
			$('div.contactMsgBox').addClass('notice');
			$('div.contactMsgBox').show();
			$('div.contactMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
										
			
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_contact';
			}else{
				formAction = '<?php echo base_url();?>kols/update_contact';
			}					
		
			 $.post(formAction, data,
					 function(returnData){
			     		if(returnData.saved == true){
							// Clear the existing form details
							$("#contactRelatedTo").val("");
							$("#contactPhone").val("");
							$("#contactEmail").val("");
							
							// If we are updating
							$("tr.ui-state-highlight").removeClass('ui-state-highlight');
							if(id == ''){									
								var datarow = {
												id:returnData.lastInsertId,
												related_to:returnData.data.related_to,
												phone:returnData.data.phone,
												email:returnData.data.email
												
											}; 
								var su=jQuery("#JQBlistContactsResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
								
								}else{
										//jQuery("#JQBlistGovernmentResultSet").trigger("reloadGrid");
										jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',returnData.data.id,{
																id:returnData.lastInsertId,
																related_to:returnData.data.related_to,
																phone:returnData.data.phone,
																email:returnData.data.email
																				}); 
										$("tr#"+returnData.data.id).addClass('ui-state-highlight');
									}
							
							
							
							
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveContact").val("Add");

								// Re-Set the Hidden Eduction Id value
								$("#contactId").val("");									
							}
							$('div.contactMsgBox').fadeOut(1500);
							$(".contactMsgBox").hide();
				     	}else{
							// Display Error Message
					     }
					},"json");
			});
		});
		//- End of Document.Ready function
		
		function autoResizeGrid(){
			$("#JQBlistContactsResultSet").fluidGrid({ example:".gridContainer", offset:-10 });
			return false;
		}

		/**
		* Edit the 'Contact Details'
		*/
		function editContact(id){
				var rd=jQuery("#JQBlistContactsResultSet").jqGrid('getRowData',id); 
						
				// Get the values from TR - Table Row, which is under editing
				related_to 		= rd.related_to;
				phone			= rd.phone;
				email			= rd.email;
				

				// Add the values to the form
				$("#contactRelatedTo").val(related_to);
				$("#contactPhone").val(phone);
				$("#contactEmail").val(email);

				// Modify the text of 'Button' from 'Add' to 'Update'
				$("#saveContact").val("Update");

				// Set the Hidden Eduction Id value
				$("#contactId").val(id);
				
		

			// Remove the row from the Table
			$("#contact_"+id).remove();
		}

		/**
		* Delete the 'Contact Details'
		*/
		function deleteContact(id){								
			var formAction = '<?php echo base_url();?>kols/delete_contact/'+id;
			jQuery("#JQBlistContactsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    		
		}		 

			
		function updateKolOverview(){
			
			if(!$("#overviewForm").validate().form()){
				
				return false;
			}
			formAction = '<?php echo base_url();?>kols/update_kol';
			$(' div.msgBox').removeClass('success');
			$('div.msgBox').addClass('notice');
			$('div.msgBox').show();
			$('div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			$.ajax({
				type: "post",
				data: $("#overviewForm").serialize(),
				url: formAction,
				success: function(returnData){
					if(returnData){
						$('div.msgBox').addClass('success');
						$('div.msgBox').text('Updated the data successfully');
					}
				},
				complete: function(){
					$('div.msgBox').fadeOut(1300);
					$(".msgBox").hide();
					$('.formError').hide();
				}
				
			});
		};	

		function updateKolContact(){
				
				if(!$("#contactForm").validate().form()){
					
					return false;
				}
				formAction = '<?php echo base_url();?>kols/update_kol_contact';
				$(' div.msgBox').removeClass('success');
				$('div.msgBox').addClass('notice');
				$('div.msgBox').show();
				$('div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
				$.ajax({
					type: "post",
					data: $("#contactForm").serialize(),
					url: formAction,
					success: function(returnData){
						if(returnData){
							$('div.msgBox').addClass('success');
							$('div.msgBox').text('Updated the data successfully');
						}
					},
					complete: function(){
						$('div.msgBox').fadeOut(1300);
						$(".msgBox").hide();
						$('.formError').hide();
					}
					
				});
		};	

		/**
		* Validate the text for 'Numeric Only'
		*/
		function allowNumericOnly1(src) {
			if(!src.value.match(/^\+?\d*$/)) {
				//src.value=src.value.replace(/\+?[^0-9]/g,'');
			}
		}

		function allowNumericOnly1(src) {
			if(!src.value.match(/^\+?\d*$/)) {
				src.value=src.value.replace(/\+?[^0-9]/g,'');
			}
		}

		jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
			phone_number = phone_number.replace(/\s+/g, "");
			return this.optional(element) || phone_number.length > 9 &&
			phone_number.match(/^\+?\d*$/);
			}, "Please specify a valid phone number");


			
		$(function(){
			
			$("#overviewForm").validate({
				debug:true,
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#contactForm").validate({
				debug:true,
				onkeyup:true,
				rules: validationRulesForContact,
				messages: validationMessagesForContact
			});
		});	
		function resetProfileImage(){
			$.ajax({
				type: "post",
				data: 'kol_id=<?php echo $arrKol['id']?>',
				url: '<?php echo base_url();?>kols/reset_profile_image',
				success: function(returnData){
					if(returnData){
						$('#imageStatusInfo').addClass('success');
						$('#imageStatusInfo').text(returnData);
					}
				},
				complete: function(){
					$('#imageStatusInfo').fadeOut(2300);
				}
			});
		}
		
		$(function() {
			$(".verticalTabs").tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
			$(".verticalTabs ul").removeClass( "ui-corner-all");
			$(".verticalTabs ul").addClass( "ui-corner-tr ui-corner-br");
			$(".verticalTabs li").removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
	
			// Add the Custom Class to control View
			$(".verticalTabs > div").addClass( "verticalTabDataWrapper" );
	
			// As the CustomClass is getting added to some other un-intentional elements, remove that class from them
			$("#kolShortDetails").removeClass("verticalTabDataWrapper");
			$(".profileImage").removeClass("verticalTabDataWrapper");
		});


		$(function() {
			// Initiate the 'Ternary Navigation
			$("#kolOverviewTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );

			// Remove the Surrounding Border
			$("#kolOverviewTernaryNav" ).removeClass("ui-widget-content");

			// Remove the Round Corner
			$("#kolOverviewTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
			
			$("#kolOverviewTernaryNav li").removeClass( "ui-corner-top" );

			// Add the Custom Class to control View
			$("#kolOverviewTernaryNav > div").addClass( "span-18 last" );

			//Validation to check first letter alphet only
		
		});

		function makeFirstLetterCapltal(value,thisObject){
			var upper = value.charAt(0).toUpperCase();
			var valueWithFirstLetterCap =  value.replace(value[0],upper);
			$(thisObject).val(valueWithFirstLetterCap);
		}
		function uploadShow(){
			$(".imageUpload").toggle();
			}		
</script>
<?php $this->load->view('kols/secondary_menu');?>
<div class="main-content">
	<div class="row">
		<div class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">Prof Info</a></li>
                  <li role="Overview"><a href="#contact_info" aria-controls="contact_info" role="tab" data-toggle="tab">Contact Info</a></li>
                  <li role="Overview"><a href="#biography" aria-controls="biography" role="tab" data-toggle="tab">Biography</a></li>
                  <li role="Overview"><a href="#references" aria-controls="references" role="tab" data-toggle="tab">References</a></li>
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
               <div>
               	<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrKol['first_name'].' '.$arrKol['middle_name'].' '.$arrKol['last_name']; ?></h5>
               </div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="prof_info">
                  		<div class="col-md-3" style="padding-left:0px !important;">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title">Profile Picture</h3> </div> 
	                  			<div class="panel-body" style="min-height:577px;"> 
	                  				<div class="row"  style="text-align: center;">
										<img alt="Image" width="100" height="100" src="http://localhost/ci3_hmvc/images/user_doctor.jpg">
										<div onclick="uploadShow();" class="upload-btn">Image Upload</div>
									</div>	
									<div class="imageUpload"">
										<form class="">
											<div class="form-group">
												<input type="file" class="form-control" data-icon="false">
											</div>
											<div style="text-align:center">
												<input type="button" class="btn btn-danger btn-sm" value="Upload">
												<input type="button" class="btn btn-primary btn-sm" value="Set default Image">
											</div>
										</form>	
									</div>	
	                  			</div> 
	                  		</div>	
                  		</div>
                  		<div class="col-md-9">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title">Personal and Professional Information</h3> </div> 
	                  			<div id="editKolForm" class="panel-body">
	                  			<form action="update_kol" method="post" id="overviewForm" class="validateForm form-horizontal col-md-12" name="personalForm">
	                  			<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
	                  			<div class="form-group">
									<div class="col-md-4">
										<label class="control-label">Profile Type <span class="required">*</span> :</label>
										<select name="profile_type" id="profile_type" class="form-control required">
											<option value="Full Profile" <?php if($arrKol['profile_type']=="Full Profile"){?>selected <?php }?>>Full Profile</option>
											<option value="Basic Plus" <?php if($arrKol['profile_type']=="Basic Plus"){?>selected <?php }?>>Basic Plus</option>
											<option value="Basic" <?php if($arrKol['profile_type']=="Basic"){?>selected <?php }?>>Basic</option>
											<option value="User Added" <?php if($arrKol['profile_type']=="User Added"){?>selected <?php }?>>User Added</option>
											<option value="Legacy" <?php if($arrKol['profile_type']=="Legacy"){?>selected <?php }?>>Legacy</option>
						    			</select>
									</div>
									<div class="col-md-8">
										<div class="msgBoxContainer alert alert-success fade in alert-dismissible" style="margin-top:18px;display:none;">
										    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										    <span class="msgBox">This alert box indicates a successful or positive action.</span>
										</div>
									</div>
								</div>
	                  			<div class="form-group">
									<div class="col-md-6">
										<label class="control-label">Salutation <span class="required">*</span> :</label>
										<select name="salutation" id="salutation" class="form-control required">
											<option value="">--- Select ---</option>
												<?php 
												foreach($arrSalutations as $key => $value){
													if($key == $arrKol['salutation'])
														echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
													else
														echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
						    			</select>
									</div>
									<div class="col-md-6">
										<label class="control-label">Gender <span class="required">*</span> :</label>
										<select name="gender" id="gender" class="form-control required">
											<option value="">--- Select ---</option>
											<option value="Male" <?php if($arrKol['gender'] == 'Male') echo 'selected="selected"'?>>Male</option>
											<option value="Female" <?php if($arrKol['gender'] == 'Female') echo 'selected="selected"'?>>Female</option>
								    	</select>
									</div>
								</div>
								<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">First Name <span class="required">*</span> :</label>
											<input type="text" name="first_name" id="first_name" value="<?php echo $arrKol['first_name'];?>" maxlength="50" class="form-control required gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
										</div>
										<div class="col-md-6">
											<label class="control-label">Middle Name :</label>
													<input type="text" name="middle_name" id="middle_name" value="<?php echo $arrKol['middle_name'];?>"  maxlength="50" class="form-control gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">last Name <span class="required">*</span> :</label>
											<input type="text" name="last_name" id="last_name" value="<?php echo $arrKol['last_name'];?>"  maxlength="50" class="form-control required gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
										</div>
										<div class="col-md-6">
											<label class="control-label">Suffix :</label>
											<input type="text" name="suffix" id="suffix" value="<?php echo $arrKol['suffix'];?>" maxlength="50" class="form-control"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">Specialty <span class="required">*</span> :</label>
											<select name="specialty" id="specialty" class="form-control required" style=">
														<option value="">--- Select ---</option>
														<?php 
														foreach($arrSpecialties as $key => $value){
														if($key == $arrKol['specialty'])
															echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
														else
															echo '<option value="'.$key.'">'.$value.'</option>';
														}
														?>
													</select>
										</div>
										<div class="col-md-6">
											<label class="control-label">Sub-specialty :</label>
											<input type="text" name="sub_specialty" id="sub_specialty" value="<?php echo $arrKol['sub_specialty'];?>" class="form-control"></input>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">Organization Name: <span class="required">*</span> :</label>
											<div class="input-group">
												<input class="form-control required" type="text" name="org_id" id="org_id" value="<?php echo $arrKol['org_id'];?>">
												<span class="input-group-addon danger"><a href="<?php echo base_url()?>organizations/add_organization/about"><span class="glyphicon glyphicon-plus-sign"></span></a></span>
											</div>
										</div>
										<div class="col-md-6">
											<label class="control-label">Division :</label>
											<input type="text" name="division" id="contactDivision" value="<?php echo $arrKol['division'];?>" class="form-control"></input>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">Title :</label>
											<input type="text" name="title" id="title" value="<?php echo $arrKol['title_name'];?>"  class="form-control"></input>
										</div>
										<div class="col-md-6">
											<label class="control-label">License# :</label>
											<input type="text" name="license" id="license" value="<?php echo $arrKol['license'];?>" class="form-control"></input>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">NPI Number :</label>
											<input type="text" name="npi_num" id="npiNum" value="<?php echo $arrKol['npi_num'];?>" class="form-control"></input>
										</div>
									</div>
									<div style="text-align: center;">
										<input type="button" value="Save" name="submit" id="savePersonalInfo" class="btn btn-primary pull-center"/>
									</div>
	                  			</div> 
	                  		</div>	
                  		</div>
                  </div>
                  <div role="tabpanel" class="tab-pane" id="biography">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Biography and Clinical Research Interests</h3> </div> 
                  			<div class="panel-body">
                  				<div class="form-group">
									<div class="col-md-12">
										<label class="control-label">Biography :</label>
										<textarea  class="textArea form-control" name="biography" id="biography" class="required"><?php echo $arrKol['biography'];?></textarea>
									</div>
									<div class="col-md-12">
										<label class="control-label">Clinical Research Interests <span class="required">*</span> :</label>
										<textarea class="textArea form-control" name="research_interests" id="researchInterests"><?php echo $arrKol['research_interests'];?></textarea>
									</div>
								</div>    
								<div class="clearfix"></div>
								<div style="margin-top:20px;">	
									<input type="button" value="Save" name="submit" id="saveBiographyInfo" class="btn btn-primary"></input>
								</div>
                  			</div> 
                  		</div>
	                  </div>
	              <div role="tabpanel" class="tab-pane" id="references">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Reference Information</h3> </div> 
                  			<div class="panel-body">
								<div class="form-group">
									<div class="col-md-12">
										<label class="control-label">Notes :</label>
										<textarea class="textArea form-control" rows="8" cols="50" name="notes" id="notes"><?php echo $arrKol['notes'];?></textarea>
									</div>
									<div class="col-md-12">
										<label class="control-label">Url <span class="required">*</span> :</label>
										<textarea class="textArea form-control" rows="8" cols="50" name="url" id="url"><?php echo $arrKol['url'];?></textarea>
									</div>
									<input type="button" value="Save" name="submit" id="saveReferenceInfo" class="btn btn-primary"></input>
								</div>  
							</div> 
                  		</div>
                  		</form>
	               </div>
	              <div role="tabpanel" class="tab-pane" id="contact_info">
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Contact Information</h3> </div> 
                  			<div class="panel-body">
								<form action="update_kol" method="post" id="contactForm" class="validateForm form-horizontal" name="contactForm">
									<div class="form-group">
										<div class="col-md-4">
											<label class="control-label">Primary Email <span class="required">*</span> :</label>
											<input type="text" name="primary_email" id="primary_email" value="<?php echo $arrKol['primary_email'];?>" class="form-control email"></input>
										</div>
										<div class="col-md-4">
											<label class="control-label">Primary Phone <span class="required">*</span> :</label>
											<input type="text" name="primary_phone" id="primary_phone" value="<?php echo $arrKol['primary_phone'];?>" onkeyup="allowNumericOnly1(this)" class="form-control required gray"></input>
										</div>
										<div class="col-md-4">
											<label class="control-label">Fax :</label>
											<input type="text" name="fax" id="fax" value="<?php echo $arrKol['fax'];?>" onkeyup="allowNumericOnly(this)" class="form-control"></input>
										</div>
									</div>
									<div class="clearfix"></div>
									<div class="form-group">
										<div class="col-md-6">
											<label class="control-label">Address 1 <span class="required">*</span> :</label>
											<input type="text" name="address1" id="address1" value="<?php echo $arrKol['address1'];?>" class="form-control required gray"></input>
										</div>
										<div class="col-md-6">
											<label class="control-label">Address 2 :</label>
													<input type="text" name="address2" id="address2" value="<?php echo $arrKol['address2'];?>" class="form-control gray"></input>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-4">
											<label class="control-label">Country <span class="required">*</span> :</label>
											<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="form-control required">
																<option value="">-- Select --</option>
																<?php 
																foreach( $arrCountry as $country){
																	if($country['country_id'] == $arrKol['country_id'])
																		echo '<option value="'.$country['country_id'].'" selected="selected">'.$country['country_name'].'</option>';
																	else
																		echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
																}
																?>
															</select>
										</div>
										<div class="col-md-4">
											<label class="control-label">State <span class="required">*</span> :</label>
											<select name="state_id" id="state_id" onchange="getCitiesByStateId();" class="form-control">		
																<option value="">-- Select State --</option>
																<?php 
																foreach( $arrStates as $state){
																	if($state['state_id'] == $arrKol['state_id'])
																		echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
																	else
																		echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
																}
																?>
											</select>
											<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
										</div>
										<div class="col-md-4">
											<label class="control-label">City <span class="required">*</span> :</label>
											<select name="city_id" id="city_id" class="form-control required">
																<option value="">-- Select City --</option>
																<?php 
																foreach( $arrCities as $city){
																	if($city['city_id'] == $arrKol['city_id'])
																		echo '<option value="'.$city['city_id'].'" selected="selected">'.$city['city_name'].'</option>';
																	else
																		echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
																}
																?>												
											</select>
											<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-4">
											<label class="control-label">Postal Code :</label>
											<input type="text" name="postal_code" id="postal_code" value="<?php echo $arrKol['postal_code'];?>" class="form-control"></input>
										</div>
										<div class="col-md-4">
											<label class="control-label">Latitude <span class="required">*</span> :</label>
											<input type="text" name="latitude" id="latitude" value="<?php echo $latitude;?>" class="form-control"></input>
										</div>
										<div class="col-md-4">
											<label class="control-label">Longitude :</label>
											<input type="text" name="longitude" id="longitude" value="<?php echo $longitude;?>" class="form-control"></input>
										</div>
									</div>
									<div style="float:right;">
										<a onclick="getLatLong();" style="cursor: pointer;">Get Lat & Long</a>
										<img src="<?php echo base_url()?>images/ajax_loader_black.gif" id="latLongLoader"/>
									</div>
									<div style="text-align: center;">
										<input type="button" value="Save" name="submit" id="saveContactInfo" class="btn btn-primary"></input>
									</div>
								</form>
							</div> 
                  		</div>	
                  		<div class="panel panel-default"> 
                  			<div class="panel-heading"> <h3 class="panel-title">Add Additional Contact Details</h3> </div> 
                  			<div class="panel-body">
                  				<div class="form-group">
								<div class="col-md-4">
									<label class="control-label">Related To <span class="required">*</span> :</label>
									<input type="text" name="related_to" value="" id="contactRelatedTo" class="form-control"></input>
								</div>
								<div class="col-md-3">
									<label class="control-label">Phone No :</label>
									<input type="text" name="phone" value="" id="contactPhone" onkeyup="allowNumericOnly1(this)" title="enter" class="form-control gray"></input>
								</div>
								<div class="col-md-4">
									<label class="control-label">Email :</label>
									<input type="text" name="email" value="" id="contactEmail" class="form-control email"></input>
								</div>
								<div class="col-md-1">
									<input type="button" value="Add" name="submit" id="saveContact" class="btn btn-primary">
								</div>
							</div>
                  			</div> 
                  		</div>	
	              </div>
        <!-- End Tab panels -->      
               </div>     
        </div>
	</div>
</div>
