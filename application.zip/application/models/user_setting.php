<?php
/**
 * This is Model file for 'User setting'
 * 
 * @author Vivekanand N
 * @since
 * @package application.models	 
 * @created on 03-12-2013
 */

class User_setting extends Model{

	//Constructor
	function User_setting(){
		parent::Model();
	}
	
	function getUserdetail($id){
		$arrUser = array();
		$this->db->where('client_users.id',$id);
		$this->db->select("client_users.*,GROUP_CONCAT(`groups`.`group_name` SEPARATOR ', ' ) AS group_name",false);
		$this->db->join("user_groups","user_groups.user_id = client_users.id","left");
		$this->db->join("groups","groups.group_id = user_groups.group_id","left");
		$arrUserResult = $this->db->get('client_users');
//		echo $this->db->last_query();
		foreach($arrUserResult->result_array() as $row){
				$arrUser = $row;
		}
//		pr($arrUser);
		return $arrUser;
	}
	
	function updateUserData($arrData) {
		$this->db->where("id",$arrData['id']);
		if($this->db->update("client_users",$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function getAllUsers($clientId) {
		$arrUsers	= array();
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->select("client_users.client_id,clients.name AS client_name,client_users.id,client_users.first_name,client_users.last_name,client_users.title,client_users.department,client_users.mem_pic, managers.id as m_id,managers.first_name as m_fname, managers.last_name as m_lname");
		$this->db->join('client_users as managers','managers.id = client_users.manager_id');
		$this->db->join('clients','clients.id = client_users.client_id');
		$this->db->order_by('clients.id,client_users.manager_id, client_users.first_name, client_users.last_name');
		$arrUserResult = $this->db->get('client_users');
		//echo $this->db->last_query();
		foreach($arrUserResult->result_array() as $row){
				$arrUsers[] = $row;
		}
		return $arrUsers;
	}
	
	function addGroup($arrData){
		if($this->db->insert("groups",$arrData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function saveUserGroup($arrData){
		foreach ($arrData as $rowData){
			$this->db->insert("user_groups",$rowData);
		}
		return true;
	}
	
	function getAllUsersGroups($id,$type){
//		pr($this->session->userdata);
		$userRoleId = $this->session->userdata('user_role_id');
		$clientId = $this->session->userdata('client_id');
		$arrUsersGroup = array();
		$this->db->select("groups.group_id,groups.created_by,groups.group_name,user_groups.user_id,user_groups.id,client_users.first_name,client_users.last_name");
		$this->db->join("user_groups","groups.group_id = user_groups.group_id","left");
		$this->db->join("client_users","client_users.id = user_groups.user_id","left");
//		$this->db->where("groups.created_by",$id);
//		$this->db->where("client_users.user_role_id",$userRoleId);
        $this->db->where("groups.group_type",$type);
		if($clientId != INTERNAL_CLIENT_ID)
			$this->db->where("client_users.client_id",$clientId);
//		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->order_by('groups.created_on',desc);
		$arrUserResult = $this->db->get('groups');
//		echo $this->db->last_query();
		foreach($arrUserResult->result_array() as $row){
				$arrUsersGroup[] = $row;
		}
//		pr($arrUsersGroup);
		return $arrUsersGroup;
	}
	
	function getUserGroupById($id,$groupId,$type){
		$arrUsersGroup = array();
		$this->db->select("groups.group_id,groups.created_by,groups.group_name,user_groups.user_id,user_groups.id,client_users.first_name,client_users.last_name");
		$this->db->join("user_groups","groups.group_id = user_groups.group_id","left");
		$this->db->join("client_users","client_users.id = user_groups.user_id","left");
//		$this->db->where("groups.created_by",$id);
		$this->db->where("groups.group_id",$groupId);
		$this->db->where("groups.group_type",$type);
		$arrUserResult = $this->db->get('groups');
//		echo $this->db->last_query();
		foreach($arrUserResult->result_array() as $row){
				$arrUsersGroup[] = $row;
		}
		//echo $this->db->last_query();
//		pr($arrUsersGroup);
		return $arrUsersGroup;
	}
        
        function getUserIdsFromGroupIds($groupIds) {
            $arrUsersGroup = array();
            $this->db->select("distinct user_groups.user_id", false);
            $this->db->where_in("user_groups.group_id",$groupIds);
            $arrUserResult = $this->db->get('user_groups');
            foreach($arrUserResult->result_array() as $row){
		$arrUsersGroup[] = $row['user_id'];
            }
            return $arrUsersGroup;
        }
	
	function updateGroup($arrData) {
		$this->db->where("group_id",$arrData['group_id']);
		if($this->db->update("groups",$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function updateUserGroup($groupId,$arrData){
		$this->db->where("group_id",$groupId);
		if($this->db->delete("user_groups")){
			foreach ($arrData as $rowData){
				$this->db->insert("user_groups",$rowData);
			}
			return true;
		}else{
			return false;
		}
	}
	
	function deleteUserGroupById($groupId){
		$this->db->where('group_id',$groupId);
		if($this->db->delete('groups')){
			return true;
		}else{
			return false;
		}
	}
	
	function updatePassword($arrData) {
		$this->db->where("id",$arrData['id']);
		if($this->db->update("client_users",$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function getAllClientsAndSupportEmailIds() {
		$arrData = array();
		$this->db->select("id,name,support_email_id");
		$result = $this->db->get("clients");
		foreach($result->result_array() as $row){
			$arrData[] = $row;	
		}
		return $arrData;
	}
	
	function updateSupportEmailAddress($arrData){
		$this->db->where("id",$arrData['id']);
		if($this->db->update("clients",$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function getNameFormat($clientId){
		$this->db->where("id",$clientId);
		$result = $this->db->get("client_users");
		foreach($result->result_array() as $row){
			$nameFormatId = $row['name_order'];
		}
		return $nameFormatId;
	}
	
	function saveNameFormatOld($arrData){
		$this->db->where('id',$arrData['id']);
		if($this->db->update('clients',$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function saveNameFormat($arrData){
		$this->db->where('client_id',$arrData['client_id']);
		if($this->db->update('client_users',$arrData)){
			return true;
		}else{
			return false;
		}
	}
	
	function checkDuplicatGroupName($groupName){
		$this->db->where('group_name',$groupName);
		$result = $this->db->get('groups');
		if($result->num_rows > 0){
			return false;
		}else{
			return true;		
		}
	}
	
	function checkDuplicatGroupNameByGroupId($id,$groupName){
		$this->db->where('group_name',$groupName);
		$this->db->where_not_in('group_id',$id);
		$result = $this->db->get('groups');
		if($result->num_rows > 0){
			return false;
		}else{
			return true;		
		}
	}
	
	function getUniqueGroupNames(){
		$arrData = array();
		$clientId = $this->session->userdata('client_id');
		$this->db->where("client_users.client_id",$clientId);
		$this->db->join("user_groups","groups.group_id = user_groups.group_id","left");
		$this->db->join("client_users","client_users.id = user_groups.user_id","left");
		$this->db->group_by("user_groups.group_id");
		$this->db->where("groups.group_type","Team");
		$result = $this->db->get('groups');
		if($result->num_rows > 0){
			$arrData = $result->result_array();
		}
		return $arrData;
	}
	function getTeams(){
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select("groups.group_id,groups.group_name");
	    //$this->db->join("user_groups","groups.group_id = user_groups.group_id","left");
	    //$this->db->join("client_users","client_users.id = user_groups.user_id","left");
	    //$this->db->where("client_users.client_id",$clientId);
	    $this->db->where("groups.group_type","Team");
	    $result = $this->db->get('groups');
	    return $result->result_array();
	}
	
	function getApplicationSettings($userId){
		$this->db->select("app_setting_types.id,app_setting_types.name,app_setting_types.lable_name,app_setting_type_values.id as app_setting_value_id,app_setting_type_values.type_value,app_setting_type_values.type_lable");
		$this->db->join("app_setting_types","app_setting_types.id = app_setting_type_values.app_setting_type_id","left");
		
		if(isset($userId) && $userId > 0){
			$this->db->select("user_app_settings.app_setting_value_id as user_app_value");
			$this->db->join("user_app_settings","user_app_settings.app_setting_type_id = app_setting_types.id","left");
			$this->db->where("user_app_settings.user_id",$userId);
		}
		$resultSet = $this->db->get("app_setting_type_values");
		return $resultSet->result_array();
	}
	
	function add_application_settings($arrData){
			$queryCheck = $this->db->get_where("user_app_settings",array("user_id"=>$arrData['user_id'],"app_setting_type_id"=>$arrData['app_setting_type_id']));
			if($queryCheck->num_rows()>0){
				$rowData = $queryCheck->row();
				$this->db->where("id",$rowData->id);
				$this->db->update('user_app_settings', array("app_setting_value_id"=>$arrData['app_setting_value_id']));
			}else{
				$query = $this->db->insert("user_app_settings",$arrData);
			}
	}
	
	function getAppSettingsSavedData($userId){
		$this->db->select("id");
		$this->db->where("user_id",$userId);
		$query = $this->db->get("user_app_settings");
		if($query->num_rows > 0){
			return true;
		}else{
			return false;		
		}
	}
	
	function getDataFromAppSettings($userId,$name){
		$value = '';
		$this->db->select("app_setting_type_values.type_value");
		$this->db->join("app_setting_types","app_setting_types.id = user_app_settings.app_setting_type_id","left");
		$this->db->join("app_setting_type_values","app_setting_type_values.id = user_app_settings.app_setting_value_id","left");
		$this->db->where("user_app_settings.user_id",$userId);
		$this->db->where("app_setting_types.name",$name);
		$query = $this->db->get("user_app_settings");
		if($query->num_rows > 0){
			$row = $query->row();
			return $value = $row->type_value;
		}else{
			return $value;
		}
	}
	function saveUpdateOptInOut($arr)
	{
	    $get = $this->db->get_where("optin_optout_settings",array("client_id"=>$arr['client_id'],"region"=>$arr['region']));
	    if($get->num_rows()==0){
	       $this->db->insert("optin_optout_settings",$arr);
	    }else{
	        $this->db->update("optin_optout_settings",$arr,array("client_id"=>$arr['client_id'],"region"=>$arr['region']));
	    }	    
	}
	
	function saveUpdateIdProfile($arr)
	{
	    $get = $this->db->get_where("id_profile_settings",array("client_id"=>$arr['client_id'],"region"=>$arr['region']));
	    if($get->num_rows()==0){
	        $this->db->insert("id_profile_settings",$arr);
	    }else{
	        $this->db->update("id_profile_settings",$arr,array("client_id"=>$arr['client_id'],"region"=>$arr['region']));
	    }
	}
	
	function getOptInOutByRegion($region){
	    $client_id = $this->session->userdata('client_id');
	    $get = $this->db->get_where("optin_optout_settings",array("client_id"=>$client_id,"region"=>$region));
	    if($get->num_rows()>0){
	       return $get->row_array();
	    }else{
	        return false;
	    }
	}
	
	function getIdProfileByRegion($region){
	    $client_id = $this->session->userdata('client_id');
	    $get = $this->db->get_where("id_profile_settings",array("client_id"=>$client_id,"region"=>$region));
	    if($get->num_rows()>0){
	        return $get->row_array();
	    }else{
	        return false;
	    }
	}
	function getRegionsFromGroups($id,$type){
		$userRoleId = $this->session->userdata('user_role_id');
		$clientId = $this->session->userdata('client_id');
		$arrUsersGroup = array();
		$this->db->select("groups.group_id,groups.created_by,groups.group_name");
        $this->db->where("groups.group_type",$type);
        $this->db->where("groups.group_name in (select distinct GlobalRegion from countries)","",false);
		$arrUserResult = $this->db->get('groups');
		foreach($arrUserResult->result_array() as $row){
				$arrUsersGroup[] = $row;
		}
		return $arrUsersGroup;
	}
	function getUsersToOptInOptOut(){
		$clientId	= $this->session->userdata('client_id');
		$this->db->select('user_groups.user_id');
		$this->db->join('user_groups', 'groups.group_id = user_groups.group_id', 'left');
		$this->db->where('groups.group_type', 'group');
		$this->db->where('groups.group_name', 'OIOOPermission');
		if ($clientId !== INTERNAL_CLIENT_ID){
			$this->db->join('client_users', 'user_groups.user_id = client_users.id', 'left');
			$this->db->where('client_users.client_id', $clientId);
		}
		$arrResult = $this->db->get('groups');
		foreach ($arrResult->result_array() as $arrUsersIds) {
			$arrUsers[] = $arrUsersIds['user_id'];
		}
		return $arrUsers;
	}
	function getEnableRegionForIdTab(){
	    $arrNames = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('id_profile_settings.*,groups.group_name');
	    $this->db->join('groups','groups.group_id = id_profile_settings.region','left');
	    $this->db->where('id_profile_settings.isEnabled',1);
// 	    $this->db->where('id_profile_settings.client_id',$clientId);
	    $arrResult = $this->db->get('id_profile_settings');
	    foreach($arrResult->result_array() as $row){
	        $arrNames[] = $row['group_name'];
	    }
	    return $arrNames;
	}
}