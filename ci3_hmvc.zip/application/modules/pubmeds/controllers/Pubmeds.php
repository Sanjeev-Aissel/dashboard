<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class pubmeds extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('pubmed');
		$this->load->model('kols/kol');
		$this->load->model('helpers/common_helper');
	}
	function search_publicatios_by_parameters($kolId){
		$page			= (int)$this->input->post('page'); // get the requested page
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$substance		= $this->input->post('substances');
		$author			= $this->input->post('author');
		$meshTerm		= $this->input->post('meshTerm');
		$keyWord		= $this->input->post('keywords');
		$articleName	= $this->input->post('article');
		$fromYear		= $this->input->post('fromYear');
		$toYear			= $this->input->post('toYear');
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrResult		= $this->pubmed->searchPublicationsByParameters($substance,$author,$meshTerm,$keyWord,$articleName,$kolId,$fromYear,$toYear);
// 		echo $this->db->last_query();
		$arrPublications= array();
		foreach($arrResult as $arrPublicationsResult){
// 			$arrPublication['micro']		= '<label onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="'.base_url().'images/user3.png" /></label>';
			$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
			$arrPublication['id']			= $arrPublicationsResult['id'];
			$arrPublication['kol_pub_id']			= $arrPublicationsResult['kol_pub_id'];
			$arrPublication['kol_id']			= $arrPublicationsResult['kol_id'];
			$arrPublication['journal_name']	= $arrPublicationsResult['journal_name'];
			if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0){
				$arrPublication['linkForArticle'] = 'pmid';
			}else{
				$arrPublication['linkForArticle'] = 'link';
			}
			$arrPublication['article_title'] = $arrPublicationsResult['article_title'];
			$arrPublication['pmid1'] = $arrPublicationsResult['pmid'];
			$arrPublication['link'] = $arrPublicationsResult['link'];
			$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
			$arrPublication['date']			= sql_date_to_app_date($arrPublicationsResult['created_date']);
			$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
			$arrPublication['client_id']=$arrPublicationsResult['client_id'];
			$arrPublication['user_id']=$arrPublicationsResult['user_id'];
			$arrPublication['is_analyst']=$arrPublicationsResult['is_analyst'];
			$arrPublication['first_name']=$arrPublicationsResult['first_name'];
			$arrPublication['last_name']=$arrPublicationsResult['last_name'];
			$arrPublication['data_type_indicator'] = $arrPublicationsResult['data_type_indicator'];
			$arrPublication['eAllowed'] =  $this->common_helper->isActionAllowed('kol_details', 'edit', $arrPublication);
			$arrPublications[]				= $arrPublication;
		}
		$count=sizeof($arrPublications);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
		$data['records'] = $count;
		$data['total']   = $total_pages;
		$data['page']    = $page;
		$data['rows']    = $arrPublications;
		echo json_encode($data);
	}
	function get_kol_auth_pos_chart_data($kolId,$start,$end){
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		
		$arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		
		$arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
		$arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
		$arrLastAuthPubsCount		=	0;
		$arrMiddleAuthPubsCount		=	0;
		foreach($arrLastAuthPubs as $lastAuthPub){
			if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
				$arrLastAuthPubsCount++;
		}
		foreach($arrMiddleAuthPubs as $middleAuthPub){
			if($middleAuthPub['auth_pos']!=$middleAuthPub['max_pos'])
				$arrMiddleAuthPubsCount++;
		}
		$arrSectors=array(
				array("First Authorship",(int)$arrFirstAuthPubsCount),
				array("Single Authorship",(int)$arrSingleAuthPubsCount),
				array("Middle Authorship",(int)$arrMiddleAuthPubsCount),
				array("Last Authorship",(int)$arrLastAuthPubsCount),
		);
		$arrSectorsData=array();
		foreach($arrSectors as $sector){
			if($sector[1]!=0)
				$arrSectorsData[]=$sector;
		}
		echo json_encode($arrSectorsData);
	}
	function view_pub_journals_chart($kolId,$fromYear,$toYear){
		$keyWord = $this->input->post('keyWord');
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrJournals= $this->pubmed->getPubJournalsChart($kolId,$fromYear,$toYear,$keyWord);
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['name'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];
		}
		$data[]=$name;
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	function view_pub_type_chart($kolId,$fromYear,$toYear){
		$keyWord = $this->input->post('keyWord');
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrJournals= $this->pubmed->getPubTypeData($kolId,$fromYear,$toYear,$keyWord);
// 		echo $this->db->last_query();exit;
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['type'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];
		}
		$data[]=$name;
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	function delete_publication($id){
		$kolId	=	$this->input->post('kol_id');
		$isDeleted=$this->pubmed->updatePublicationAsDeleted($id);
// 		$this->update->deleteUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $id, MODULE_KOL_PUBLICATION);
		return true;
	}
	function deleteAuthorOfPublication($kolId,$pubId,$autId){
		$res = $this->pubmed->delete_author_publication($pubId,$autId);
		$data['status'] = "failure";
		if($res){
			$data['status'] = "success";
			$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,array());
			$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
		}
		echo json_encode($data);
	}
	function add_publication($kolId=null,$pubId=null){
		$publication=array();
		$data['arrMultipleAuthors']=array();
		if($pubId!=null){
			$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00')
				$publication['pub_date']='';
			else
				$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
			$publication['created_date']=sql_date_to_app_date($publication['created_date']);
			$arrMultipleAuthors=$this->pubmed->listPublicationAuthors($pubId);
// 			pr($pubId);
// 			echo $this->db->last_query();
// 			pr($arrMultipleAuthors);exit;
			$data['arrMultipleAuthors']=$arrMultipleAuthors;
		}
		$data['kolId']=$kolId;
		$data['publication']=$publication;
		$data['contentPage'] 	= 'add_publications';
		$data['contentData']	=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function update_publication_manual(){
		$arrAuthId  =	$this->input->post('authId');
		$arrLastName  =	$this->input->post('last_name');
		$arrForeName  =	$this->input->post('fore_name');
		$arrInitials  =	$this->input->post('initials');
		// Getting the POST details of Publication
		$arrPublicationDetails = array(	'id'                =>	$this->input->post('id'),
				'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
				'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
				'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
				'link'	 			=> 	$this->input->post('link'));
// 		pr($arrPublicationDetails);
		// Create an array to return the result
		$arrResult = array();
		$kolId			=	$this->input->post('kol_id');
		$pubId = $arrPublicationDetails['id'];
		$isSaved=$this->pubmed->updatePublicationManual($arrPublicationDetails);
		//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UPDATE, $arrPublicationDetails['id'], MODULE_KOL_PUBLICATION, $kolId);
		//Get journal name
		$arrPublicationDetails['journal_name'] = ucwords(trim($this->input->post('journal_name')));
		//get Author name
		$arrPublicationDetails['last_name']  =	$arrLastName[0];
		$arrPublicationDetails['fore_name']  =	$arrForeName[0];
		$arrPublicationDetails['initials']   =	$arrInitials[0];
		$arrPublicationDetails['authId']	 = 	$arrAuthId[0];
		$isSaved = 	$this->pubmed->updatePublicationJournalManual($arrPublicationDetails);
		$noOfAuthors=$this->input->post('no_of_authors');
		$beforenoOfAuthors=$this->input->post('before_no_of_authors');
		$this->db->delete("publications_authors",array("pub_id"=>$pubId));
		$position = 1;
		for($i=0;$i<=$noOfAuthors;$i++){
			$lastName  =	$arrLastName[$i];
			$foreName  =	$arrForeName[$i];
			$initials  =	$arrInitials[$i];
			$arrSecondAuthors = array();
			if($lastName != '' || $foreName !='' || $initials !=''){
				$secondAuthors = $this->parse_authors_manually($lastName,$foreName,$initials);
				$arrSecondAuthors[] = $secondAuthors;
			}
			$arrAuthors = array();
			foreach ($arrSecondAuthors as $arrSecondAuthor){
				foreach ($arrSecondAuthor as $author){
					$arrAuthors[] = $author;
				}
			}
			if(sizeof($arrAuthors)>=1){
				$this->update_pub_authors($arrAuthors, $pubId, '',$position);
			}
			$position++;
		}
		$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,null);
		$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
		$arrResult = array();
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $arrPublicationDetails['id'];
			$arrResult['msg']			= "Successfully Updated the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Updating";
		}
		echo json_encode($arrResult);
// 		$isClientView = false;
// 		//redirect('pubmeds/view_publications/'.$kolId);
// 		$kolId = $this->kol->getUniqueIdByKolId($kolId);
// 		redirect('kols/view_publications/'.$kolId);
	}
	function parse_authors_manually($lastName,$foreName,$initials){
		$arrAuthors = array();
		$author 	= array();
		$author['last_name']= ($lastName != '') ? $lastName:$lastName;
		$author['fore_name']= ($foreName != '') ? $foreName:$foreName;
		$author['initials']	= ($initials != '') ? $initials:$initials;
		$author['suffix']	= 'Not Available';
		$author['is_name_valid']	= 0;
		$arrAuthors[]=$author;
		return $arrAuthors;
	}
	function update_pub_authors($arrAuthors, $pubId, $authId,$position){
		$query1 = $this->db->query("select id from publications_authors where pub_id='".$pubId."' and author_id='".$authId."'");
		$result1 = $query1->first_row();
		$publications_authors_id = $result1->id;
		$query2 = $this->db->query("select id from pubmed_authors where id='".$authId."'");
		$result2 = $query2->first_row();
		$pubmed_authors_id = $result2->id;
		if($publications_authors_id=='' && $pubmed_authors_id==''){
			if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES ("'.$arrAuthors[0]['last_name'].'","'.$arrAuthors[0]['fore_name'].'","'.$arrAuthors[0]['initials'].'","'.$arrAuthors[0]['suffix'].'","'.$arrAuthors[0]['is_name_valid'].'")')){
				$authId = $this->db->insert_id();
				$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES ("'.$pubId.'","'.$authId.'","'.$position.'","'.$authId.'")');
			}
		}
	}
	function save_publication_manual($ipad=0){
		$arrLastName  =	$this->input->post('last_name');
		$arrForeName  =	$this->input->post('fore_name');
		$arrInitials  =	$this->input->post('initials');
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		// Getting the POST details of Publication
		$arrPublicationDetails = array(
				'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
				'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
				'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
				'link'	 			=> 	$this->input->post('link'));
		//Save journal name
		$journalName = ucwords(trim($this->input->post('journal_name')));
		if($journalName != ''){
			$arrPublicationDetails['journal_id'] = 	$this->pubmed->savejournalName($journalName);
		}
		$kolId			=	$this->input->post('kol_id');
		//Generate Pmid manually
		$arrPublicationDetails['pmid']= $this->pubmed->getManualPmid();
		$arrPublicationDetails['is_manual']= 1;
		$arrPublicationDetails['data_type_indicator']= $dataType;
		//Save Publication data
// 		pr($arrPublicationDetails);exit;
		$pubId=$this->pubmed->savePublicationsManualAndFlags($arrPublicationDetails , $kolId);
		$isSaved = false;
		if($pubId){
			$isSaved  = true;
		}

		$firstAuthor = array();
		if($arrLastName[0] != '' || $arrForeName[0] !='' || $arrInitials[0] !=''){
			$firstAuthor = $this->parse_authors_manually($arrLastName[0],$arrForeName[0],$arrInitials[0]);
		}
		$arrAuthors = array();
		$secondAuthors = array();
		$arrSecondAuthors = array();
		//$i=2;
		$noOfAuthors=sizeof($arrLastName);
		for($i=1;$i<=$noOfAuthors;$i++){
			$lastName  =	$arrLastName[$i];
			$foreName  =	$arrForeName[$i];
			$initials  =	$arrInitials[$i];
			
			//parse and save 'publication-authors'
			if($lastName != '' || $foreName !='' || $initials !=''){
				$secondAuthors = $this->parse_authors_manually($lastName,$foreName,$initials);
				$arrSecondAuthors[] = $secondAuthors;
			}
		}
		foreach ($firstAuthor as $author){
			$arrAuthors[] = $author;
		}
		foreach ($arrSecondAuthors as $arrSecondAuthor){
			foreach ($arrSecondAuthor as $author){
				$arrAuthors[] = $author;
			}
		}
		//Save array of Authors
		if(sizeof($arrAuthors)>=1){
			$this->save_pub_authors($arrAuthors, $pubId);
		}
		//Calculate Authorship position and save
		$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,null);
		$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $pubId;
			$arrResult['msg']			= "Successfully saved the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		
			echo json_encode($arrResult);
// 		$currentMethod	= $this->input->post('methodName');
// 		$kolId = $this->kol->getUniqueIdByKolId($kolId);
// 		if($currentMethod == 'add_client_publication'){
// 			//For client appplication
// 			//redirect('kols/view_publications/'.$this->session->userdata('kolId'));
// 			if($ipad){
// 				$data['kolId']=$kolId;
// 				$data['status']='success';
// 				echo json_encode($data);
// 			}else{
// 				redirect('kols/view_publications/'.$kolId);
// 			}
// 		}else{
// 			//For analyst appplication
// 			//Ajax Saving is Done But Listing is not hapening automatically
// 			//Currently Redircting to Ajax tab
// 			//redirect('kols/edit_kol/'.$this->session->userdata('kolId').'#ui-tabs-5');
// 			$isClientView = false;
// 			if($ipad){
// 				$data['kolId']=$kolId;
// 				$data['status']='success';
// 				echo json_encode($data);
// 			}else{
// 				redirect('pubmeds/view_publications/'.$kolId);
// 			}
// 		}
		
	}
	function save_pub_authors($arrAuthors, $pubId){
		$position=1;
		//Insert batch of authors,  i.e bulk insert
		//$this->db->insert_batch('pubmed_authors', $arrAuthors);
		$query= array();
		
		foreach( $arrAuthors as $row ) {
			$query[] = '("'.$row['last_name'].'", "'.$row['fore_name'].'", "'.$row['initials'].'", "'.$row['suffix'].'", "'.$row['is_name_valid'].'")';
		}
		//pr($query);
		//pr(implode(',', $query));
		if(sizeof($query) == 0)
			return;
			if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES '.implode(',', $query))){
				
				$result = $this->db->query("select max(id) as id from pubmed_authors");
				$result = $result->first_row();
				$authId=$result->id;
				$authId = $authId - (sizeof($arrAuthors)-1);
				$arrPubAuthors = array();
				foreach($arrAuthors as $author){
					$pubAuthor = array();
					$pubAuthor['pub_id']=$pubId;
					$pubAuthor['author_id']=$authId;
					$pubAuthor['position']=$position;
					$pubAuthor['alias_id']=$authId;
					$position++;
					$authId++;
					$arrPubAuthors[] = $pubAuthor;
				}
				
				//Insert batch of  pub authors,  i.e bulk insert
				//$this->db->insert_batch('publications_authors', $arrPubAuthors);
				$query= array();
				foreach( $arrPubAuthors as $row ) {
					$query[] = '('.$row['pub_id'].', '.$row['author_id'].', '.$row['position'].', '.$row['alias_id'].')';
				}
				//pr($query);exit;
				$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES '.implode(',', $query));
			}
	}
	function view_micro_pub($pubId){
		$publication=$this->pubmed->getPublicationDetail($pubId);
		$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
		if($publication['pub_date']=='0000-00-00')
			$publication['pub_date']='';
			else
				$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
				$publication['created_date']=sql_date_to_app_date($publication['created_date']);
				$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
				$arrMeshTerms=array();
				$arrMeshTermsResults=$this->pubmed->listPublicationMeshTerms($pubId);
				foreach($arrMeshTermsResults as $meshTerm){
					$parentId=$meshTerm['parent_id'];
					if($parentId!=0 && $parentId!=null){
						$parentName=$this->pubmed->getMeshTermName($parentId);
						$termName=$parentName."/".$meshTerm['term_name'];
					}else{
						$termName=$meshTerm['term_name'];
					}
					if($meshTerm['is_major']==1)
						$termName=$termName."*";
						$arrMeshTerms[]=$termName;
				}
				$data['publication']=$publication;
				$data['arrAuthors']=$arrAuthors;
				$data['arrMeshTerms']=$arrMeshTerms;
				$this->load->view('pubmeds/view_pub_micro_profile',$data);
	}
	function view_publications($kolId, $subContentPage = '') {
		// Getting the KOL details
		$this->load->model('kols/kol');
		$this->load->model('align_users/align_user');
	
		$kolId				= $this->common_helper->getFieldValueByEntityDetails('kols','unique_id',$kolId,'id');
		$arrKolDetail 		= $this->kol->editKol($kolId);
		// If there is no record in the database
		if (!$arrKolDetail) {
			return false;
		}
		$module_name		='pubmeds';
		$data['module_id']	=$this->common_helper->getModuleIdByModuleName($module_name);
	
		$arrContentdata['arrKol'] 			=$arrKolDetail;
		$arrContentdata['arrYearRange'] 	=$this->pubmed->getKolPubsYearsRange($kolId);
		$arrContentdata['subContentPage'] 	=$subContentPage;
	
		$data['contentData']				=$arrContentdata;
		$data['contentPage'] 				='list_publications_client_view';
	
		$arr_option_data['kol_id']			=$arrKolDetail['id'];
		$arr_option_data['assignedUsers'] 	=$this->align_user->getAssignedUsers($kolId);
	
		$data['options_page']				='kols/export_options_within_kol';
		$data['options_data']				=$arr_option_data;
	
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function view_publication_chart($kolId = null, $fromYear, $toYear) {
		$arrPublications = $this->pubmed->getPublicationChart($kolId, $fromYear, $toYear);
		$years = array();
		$count = array();
		$yearMapping = array();
		foreach ($arrPublications as $publication) {
			if($publication['year']>0){
				$years[] = $publication['year'];
				$count[] = (int) $publication['count'];
				$yearMapping[substr($publication['year'], 2)] = $publication['year'];
			}
		}
		$data[] = array_reverse($years);
		$data[] = array_reverse($count);
		$data[] = $yearMapping;
		echo json_encode($data);
	}
	function view_pub_top_concepts($kolId=null, $fromYear, $toYear){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$keyWord = $this->input->post('keyWord');
		$startFrom = $this->input->post('startFrom');
		$category = $this->input->post('category');
		$this->session->set_userdata('kolKeyWords',$keyWord);
	
		$arrMajorMeshterm 	= $this->pubmed->getTopConceptDataForChart($kolId, $fromYear, $toYear,$keyWord,'all');
		// 		echo $this->db->last_query();
		$topConceptData = $this->prepareTopConcepts($arrMajorMeshterm,$startFrom,$category);
		$data = array();
		$meshCatCounter=0;
		$data['arrData'] = $topConceptData;
		echo json_encode($data);
		exit;//required
	}
	function prepareTopConcepts($arrTopConceptsData, $startFrom = '', $category = '') {
		$arrRetData = array();
		$arr = array();
		foreach ($arrTopConceptsData as $row) {
			if ($row['tree_id'] != '') {
				$treeId = explode(",", $row['tree_id']);
				foreach ($treeId as $key => $id) {
					$arr[$id[0]][$row['name']] = $row;
				}
			}
		}
	
		if (isset($arr['E'])) {
			foreach ($arr['E'] as $row) {
				$treeId = explode(",", $row['tree_id']);
				foreach ($treeId as $key => $id) {
					$arr[substr($id, 0, 3)][$row['name']] = $row;
				}
			}
		}
		unset($arr['E']);
		$authDetails = array();
		$arrRetData = array();
		foreach ($arr as $key => $row) {
			$authDetails[$key] = array_values($row);
		}
		if ($startFrom == '')
			$startFrom = 0;
				
			$interArr = array();
			if ($category != '') {
				$interArr[$category] = $authDetails[$category];
				$authDetails = $interArr;
			}
			//		pr($authDetails);
			//		exit;
			foreach ($authDetails as $key => $row) {
				switch ($key) {
					case 'C' : $tCount = $authDetails['C'][0]['count'];
					$arrResults = $authDetails['C'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_C';
					//								$data['pmidsCount'] = $arr['C'];
					$data['title'] = 'Diseases';
					$data['category'] = 'C';
					$arrRetData['C'] = $data;
					break;
					case 'D' : $tCount = $authDetails['D'][0]['count'];
					$arrResults = $authDetails['D'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_D';
					//								$data['pmidsCount'] = $arr['D'];
					$data['title'] = 'Chemicals and Drugs';
					$data['category'] = 'D';
					$arrRetData['D'] = $data;
					break;
					case 'E01' : $tCount = $authDetails['E01'][0]['count'];
					$arrResults = $authDetails['E01'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_E1';
					//								$data['pmidsCount'] = $arr['E1'];
					$data['title'] = 'Dentistry';
					$data['category'] = 'E01';
					$arrRetData['E01'] = $data;
					break;
					case 'E02' : $tCount = $authDetails['E02'][0]['count'];
					$arrResults = $authDetails['E02'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_E2';
					//								$data['pmidsCount'] = $arr['E2'];
					$data['title'] = 'Investigative & Diagnostic';
					$data['category'] = 'E02';
					$arrRetData['E02'] = $data;
					break;
					case 'E06' : $tCount = $authDetails['E06'][0]['count'];
					$arrResults = $authDetails['E06'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_E3';
					//								$data['pmidsCount'] = $arr['E3'];
					$data['title'] = 'Devices';
					$data['category'] = 'E06';
					$arrRetData['E06'] = $data;
					break;
					case 'E07' : $tCount = $authDetails['E07'][0]['count'];
					$arrResults = $authDetails['E07'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_E4';
					//								$data['pmidsCount'] = $arr['E4'];
					$data['title'] = 'Procedures';
					$data['category'] = 'E07';
					$arrRetData['E07'] = $data;
					break;
					case 'F' : $tCount = $authDetails['F'][0]['count'];
					$arrResults = $authDetails['F'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_F';
					//								$data['pmidsCount'] = $arr['F'];
					$data['title'] = 'Psychiatry and Psychology';
					$data['category'] = 'F';
					$arrRetData['F'] = $data;
					break;
					case 'H' : $tCount = $authDetails['H'][0]['count'];
					$arrResults = $authDetails['H'];
					$data = array();
					$topCount = $tCount;
					$count = count($arrResults);
					$data['topCount'] = $topCount;
					$arrSlice = array_slice($arrResults, $startFrom, 20);
					$data['categoryData'] = $arrSlice;
					$data['next'] = $startFrom + 20;
					$data['prev'] = $startFrom - 20;
					$data['total'] = $count;
					$data['reportSection'] = 'category_H';
					//								$data['pmidsCount'] = $arr['H'];
					$data['title'] = 'Disciplines and Specialties';
					$data['category'] = 'H';
					$arrRetData['H'] = $data;
					break;
				}
			}
			//			pr($arrRetData);
			//			exit;
			//		$this->sortaasort($arrRetData,'pmidsCount');
			return $arrRetData; //array_values($arrRetData);
	}
	
	/*-------------Start of Publications functions(Analyst Application)-------------*/
	/**
	 * Show the page of Show Publications details
	 * @author Sanjeev K
	 * @since 28 March 2018
	 * @version KOLM-HMVC Version 1.0
	 * @desc Prepares the data required to display the Publication page and redirects to 'view_publications'
	 */
	function view_publications_analyst($kolId){
	
		$data['isClientView']	= false;
	
		// Get the KOL details
		$arrKolDetail 	= $this->kol->editKol($kolId);
		$data['arrKol']	= $arrKolDetail;
	
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
	
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		//$this->load->view('publications/list_publications', $data);
		$data['contentPage'] = 'pubmeds/list_publications';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	
	}
	function get_pub_authors($pubId){
		$authNames='';
		$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
		foreach($arrAuthors as $author){
			$authName=$author['last_name']." ".$author['initials'];
			if($authNames==''){
				$authNames=$authName;
			} else{
				$authNames=$authNames.",".$authName;
			}
		}
		return $authNames;
	}
	/**
	 * returns the list of publications belongs to perticular kolId
	 * @return unknown_type
	 */
	function list_publication_details_analyst($type,$kolId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrPublications 	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed->listPublicationDetailsForAnalyst($kolId,$type)){
			foreach($arrPublicationsResults as $arrPublicationsResult){
				$arrPublication['id']			= $arrPublicationsResult['asoc_id'];
				$arrPublication['pub_id']		= $arrPublicationsResult['id'];
				$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
				//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
					$arrPublication['pmid']		= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
					else
						$arrPublication['pmid']		= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
						$arrPublication['journal_name']	= $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
						//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
						$arrPublication['article_title']= '<a target="_new" href=\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'>'.$arrPublicationsResult['article_title'].'</a>';
						$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
						$arrPublication['date']			= $arrPublicationsResult['created_date'];
						$arrPublication['authors']		= $this->get_pub_authors($arrPublicationsResult['id']);
						$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
						//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$kolId,null);
						$arrPublication['subject']		= '';
						$arrPublications[]				= $arrPublication;
			}
			$count				= sizeof($arrPublications);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages 	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrPublications;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	function add_publication_analyst($kolId=null,$pubId=null){
		$publication=array();
		$data['arrMultipleAuthors']=array();
		if($pubId!=null){
			$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00')
				$publication['pub_date']='';
				else
					$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
					$publication['created_date']=sql_date_to_app_date($publication['created_date']);
					$arrMultipleAuthors=$this->pubmed->listPublicationAuthors($pubId);
					// 			pr($pubId);
					// 			echo $this->db->last_query();
					// 			pr($arrMultipleAuthors);exit;
					$data['arrMultipleAuthors']=$arrMultipleAuthors;
		}
		$data['kolId']=$kolId;
		$data['publication']=$publication;
		$data['contentData']	=$data;
		$this->load->view('pubmeds/add_publications',$data);
	}
	/**
	 * Deletes the publications, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.5.1
	 * @created on 21/3/2011
	 */
	function un_verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		//pr($selectedRows);
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolPublication=array();
			$kolPublication['is_verified']=0;
			$kolPublication['is_deleted']=0;
			$isDeleted=$this->pubmed->updatePublicationAsVerified($id,$kolPublication);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	/*-------------End of Publications functions(Analyst Application)-------------*/
}
?>