<?php
$conrractKolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<form action=""   enctype="multipart/form-data" method="post" id="contractForm" name="contractForm" class="validateForm">
<input type="hidden" name="id" id="contractName" value="<?php if($arrContract!=null) echo $arrContract['id']; else echo '';?>"/>
		<div class="form-group row">
			<label class="col-sm-4"></label>
			<div class="col-sm-8">
				<div id="responseBox"></div>
   		  	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-4 align_right">KTL:<span class="required">*</span></label>
			<div class="col-sm-8">
			    <input type="hidden" name="kol_id" id="kolId" value="<?php if($arrContract!=null) echo $arrContract['kol_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
				<input type="text" name="kol_name" id="kolName" value="<?php if($arrContract!=null) echo $arrContract['kol_name']; else echo '';if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox form-control" <?php if(isset($kol_name) || isset($kolId)){?> readonly="readonly" <?php }?>/>
	    	</div>
		</div>
		<div class="form-group row" >
			<label class="col-sm-4 align_right">Contract Name:<span class="required">*</span></label>
			<div class="col-sm-8">
				  <input type="text"  class="form-control required" name="contract_name" id="contractName" value="<?php if($arrContract!=null) echo $arrContract['contract_name']; else echo '';?>"/>
	    	</div>
		</div>
		<div class="form-group row" >
			<label class="col-sm-4 align_right">Start Date:<span class="required">*</span></label>
			<div class="col-sm-8">
				  <input type="text"  class="form-control required" name="start_date" id="startDate" value="<?php if($arrContract!=null) echo $arrContract['start_date'];?>"/>
	    	</div>
		</div>
		<div class="form-group row" >
			<label class="col-sm-4 align_right">End Date:<span class="required">*</span></label>
			<div class="col-sm-8">
				<input type="text"  class="form-control required" name="end_date" id="endDate" value="<?php if($arrContract!=null) echo $arrContract['end_date'];?>"/>
	    	</div>
		</div>
		<div class="form-group row" >
			<label class="col-sm-4 align_right">Description:<span class="required">*</span></label>
			<div class="col-sm-8">
				  <textarea  name="contract_description" id="contractDesc" class="form-control required"><?php if($arrContract!=null) echo $arrContract['contract_description'];?></textarea>
	    	</div>
		</div>
		<div class="form-group row" >
			<label class="col-sm-4 align_right">Upload Doc:</label>
			<div class="col-sm-8">
				  <input type="file" class="form-control" name="contract_file" id="contractFile" value="" size="40" accept=".pdf,.JPG,.PNG,.pdf,.PDF,.xlr,.xls,xlsx,.ppt,.pptx,.txt,.gif,.jpg,.jpeg,.png,.doc,.docx"/>
	    	</div>
		</div>
		<?php if($arrContract!=null){
				if($arrContract['contract_file']!=''){?>
		<div class="form-group row" >
				<label id="deleteLink"><a href="#" onclick="deleteFile('<?php echo $arrContract['contract_file'];?>','<?php echo $arrContract['id']?>')">
					<img src="<?php echo base_url()?>assets/images/file-download.png" /> Remove File
				</a>
				</label>
		</div>
		<?php }}?>
		<div class="form-group row">
				<label class="col-sm-4 align_right"></label>
		   		<div class="col-sm-8">
		   			<input type="submit" value="Save" name="submit" onclick="saveContract();" class="btn custom-btn">
		             <input type="button" value="Cancel" name="submit" onclick="close_dialog();return false;" class="btn custom-btn">
		        </div> 
		</div>
	</form>
<script type="text/javascript">
var kolId='<?php echo $kolId; ?>';
var contract_type ='<?php echo $contract_type;?>';
var contractKolAutoCompleteOptions = '';
var contractKolAutoCompleteOptions = {    	    
	serviceUrl: '<?php echo base_url();?>kols/kols/get_kol_names_for_all_autocomplete/1',
	<?php echo $conrractKolAutoCompleteOptions;?>,
	onSelect: function(event, ui) { 
		var kolId = $(event).children('.id1').html();
		var selText = $(event).children('.kolName').html();
		selText=selText.replace(/\&amp;/g,'&');
		$('#kolName').val(selText);
		$('#kolId').val(kolId);
	 },
};
var validationRules	=  {
		kol_name: {
			required:true			
		}		
	};
	var validationMessages = {
			kol_name: {
			number: "required"
		}
	};
$(document).ready(function(){
	$("#contractForm").validate({
		onkeyup:false,
		rules: validationRules,
		messages: validationMessages
	});
	 $("#startDate").datepicker({
		 dateFormat: 'mm/dd/yy',
	      onSelect: function(selected) {
	        $("#endDate").datepicker("option","minDate",selected);
	        $("#startDate").removeClass("error");
			$("#startDate").next().remove();
	      }
	  });
	  $("#endDate").datepicker({
		  dateFormat: 'mm/dd/yy',
	      onSelect: function(selected) {
	        $("#startDate").datepicker("option","maxDate",selected);
	        $("#endDate").removeClass("error");
			$("#endDate").next().remove();
	      }
	  }); 
	var contractKolAutoComplete	= $('#kolName').autocomplete(contractKolAutoCompleteOptions);
});
</script>