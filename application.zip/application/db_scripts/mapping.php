<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function complianceMapping() {
        $result = $this->db->query("select * from coaching where skill_group_id=7888100000000001 limit 50 ");
        foreach ($result->result_array() as $values) {
            //email 
            $resultEmail = $this->db->query("select email_address from employee "
                    . "left join coaching on coaching.employee_id=employee.employee_id "
                    . "where coaching.employee_id=" . $values['employee_id'] . "");
            $mail = $resultEmail->row_array();

            //created_by
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();

            //location, monitored_by ,off_label_inquiry	inquiry_unsolicited	response_consistancy	compliance_violation	compliance_violated_by	compliance_violated_by_title	violation_description
            //state_id	city_id	fma	compliance_violated_by_date	kol_id/org_id

            $resultDetails = $this->db->query("select * from coaching_comment where coaching_id=" . $values['coaching_id'] . "");

            foreach ($resultDetails->result_array() as $key => $data) {
                if ($data['comment_field_code'] == 'ILOC') {
                    $location = $data['comments'];
                    $arrComplianceLocations = array(
                        'MC', 'NMC', 'Advisory Board', 'OM', 'ONM', 'CONG', 'SPPR', 'Investigator Meeting', 'OTH'
                    );   // Investigator and advisory board no short hand found in db
                    $location = array_search($location, $arrComplianceLocations);
                }
                if ($data['comment_field_code'] == 'MNAM') {

                    $fmaName = $data['comments'];
                    $fmaName = explode(" ", $fmaName);
                    $resultFma = $this->db->query("select id from client_users where first_name='" . mysql_real_escape_string($fmaName[0]) . "' and last_name='" . mysql_real_escape_string($fmaName[1]) . "'");
                    $fma = $resultFma->row_array();
                }
                if ($data['comment_field_code'] == 'HCID') {
                    $kolId[$key] = $data['comments'];
                }
                if ($data['comment_field_code'] == 'OFLY') {
                    if ($data['comments'] == 0)
                        $off = "yes";
                }
                if ($data['comment_field_code'] == 'OFLN') {
                    if ($data['comments'] == 0)
                        $off = "no";
                }
                if ($data['comment_field_code'] == 'UNSY') {
                    if ($data['comments'] == 0)
                        $inquiry = "yes";
                }
                if ($data['comment_field_code'] == 'UNSN') {
                    if ($data['comments'] == 0)
                        $inquiry = "no";
                }

                if ($data['comment_field_code'] == 'RESY') {
                    if ($data['comments'] == 0)
                        $response = "yes";
                }
                if ($data['comment_field_code'] == 'RESN') {
                    if ($data['comments'] == 0)
                        $response = "no";
                }

                if ($data['comment_field_code'] == 'CCMY') {
                    if ($data['comments'] == 0)
                        $complianceVoilation = "yes";
                }
                if ($data['comment_field_code'] == 'CCMN') {
                    if ($data['comments'] == 0)
                        $complianceVoilation = "no";
                }
                if ($data['comment_field_code'] == 'STTL')
                    $title = $data['comments'];
                if ($data['comment_field_code'] == 'SDAT')
                    $voilationDate = $data['comments'];
                if ($data['comment_field_code'] == 'STAT')
                    $state = $data['comments'];
                if ($data['comment_field_code'] == 'CITY')
                    $city = $data['comments'];
                if ($data['comment_field_code'] == 'CEXP')
                    $description = $data['comments'];

                if ($data['comment_field_code'] == 'VNAM') {
                    $id = $data['comments'];

                    //email 
                    $resultEmail = $this->db->query("select email_address from employee "
                            . "left join coaching on coaching.employee_id=employee.employee_id "
                            . "where coaching.employee_id=" . $id . "");
                    $mail = $resultEmail->row_array();

                    //manger id
                    $managerIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
                    $managerId = $managerIds->row_array();
                }
                $old_startdate_timestamp = strtotime($voilationDate);
                $date = date('Y-m-d', $old_startdate_timestamp);
                $old_startdate_timestamp_create = strtotime($values['create_date']);
                $create_date = date('Y-m-d', $old_startdate_timestamp_create);
                if ($values['interaction_category'] == "ONEO")
                    $iC = 1;
                else
                    $iC = 2;
                $dataInsert = array(
                    "date" => $create_date,
                    "location" => $location,
                    "monitored_by" => $fma,
                    "interaction_type" => $iC,
                    "off_label_inquiry" => $off,
                    "inquiry_unsolicited" => $inquiry,
                    "response_consistancy" => $response,
                    "compliance_violation" => $complianceVoilation,
                    "compliance_violated_by" => '',
                    "compliance_violated_by_title" => $title,
                    "compliance_violated_by_date" => $date,
                    "violation_description" => $description,
                    "contact_type" => '',
                    "signature" => '',
                    "created_by" => $userId['id'],
                    "created_on" => '',
                    "state_id" => $state,
                    "city_id" => $city,
                    "fma" => $managerId['id']
                        );
                // pr($dataInsert);
                $this->db->insert("compliance_monitoring", $dataInsert);
                $lastId = $this->db->insert_id();
                //  get type
                foreach ($kolId as $id) {
                    $resultType = $this->db->query("select customer_type from customer "
                            . "where customer_id=" . $id . "");
                    $type = $resultType->row_array();
                    // get organization or kol id from kols table
                    $resultId = $this->db->query("select id from kols "
                            . "where customer_id=" . $id . "");
                    $kolOrOrgId = $resultId->row_array();
                    $this->db->query("SET FOREIGN_KEY_CHECKS=0");
                    $dataInsert = array("compliance_monitoring_id" => $lastId, "kol_id" => $kolOrOrgId["id"]);
                    if ($type["customer_type"] == "PRES") {
                        $this->db->insert("compliance_monitoring_kols", $dataInsert);
                    } else {
                        $this->db->insert("compliance_monitoring_organizations", $dataInsert);
                    }
                }
            }
        }
    }
    
    
    
    /**
     * coaching
     */
      function mapping() {
        $result = $this->db->query("select * from coaching where skill_group_id=7888300000000050");
        foreach ($result->result_array() as $values) {
            //email 
            $resultEmail = $this->db->query("select email_address from employee "
                    . "left join coaching on coaching.employee_id=employee.employee_id "
                    . "where coaching.employee_id=" . $values['employee_id'] . "");
            $mail = $resultEmail->row_array();

            //username
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();

            //speciality, engagement staus, therp area, hcid
            $resultDetails = $this->db->query("select * from coaching_comment where coaching_id=" . $values['coaching_id'] . "");
            foreach ($resultDetails->result_array() as $data) {
                if ($data['comment_field_name'] == 'evaluator_emp_id')
                    $managerId = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_thera_area')
                    $theparea = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_hcp') {
                    $hcp = $data['comments'];
                    $name = explode(",", $hcp);
                    $kolId = array();
                    foreach ($name as $key => $kol) {
                        $kolName = explode(" ", $kol);
                        $hcpIds = $this->db->query("select id from kols where first_name='" . mysql_real_escape_string($kolName[0]) . "' and last_name='" . mysql_real_escape_string($kolName[1]) . "'");
                        $hcpId = $hcpIds->row_array();
                        if ($hcpId['id'] != '')
                            $kolId[$key] = $hcpId['id'];
                    }
                }
                if (count($kolId) > 0)
                    $kolIds = trim(implode(',', $kolId));

                if ($data['comment_field_name'] == 'vc_fcr_top_eng_status')
                    $engStatus = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_comments')
                    $comment = $data['comments'];
            }
            //therp id from kol database
            $resultThep = $this->db->query("select id from theraputic_areas where name='" . $theparea . "' ");
            $theparea = $resultThep->row_array();

            //manager id from kol database(evaluator)
            $resultEmailManager = $this->db->query("select email_address from employee where employee_id=" . $managerId . " ");
            $managerEmail = $resultEmailManager->row_array();
            $managerIds = $this->db->query("select id from client_users where email='" . strtolower($managerEmail['email_address']) . "'");
            $mangerId = $managerIds->row_array();

            //question plans
            $resultP1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000002 ");
            $p1 = $resultP1->row_array();
            $resultP1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p1['skill_rating_id'] . "");
            $p1 = $resultP1->row_array();

            $resultP2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000003 ");
            $p2 = $resultP2->row_array();
            $resultP2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p2['skill_rating_id'] . "");
            $p2 = $resultP2->row_array();
            $resultP3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000004 ");
            $p3 = $resultP3->row_array();
            $resultP3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p3['skill_rating_id'] . "");
            $p3 = $resultP3->row_array();
            $resultP4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000005 ");
            $p4 = $resultP4->row_array();
            $resultP4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p4['skill_rating_id'] . "");
            $p4 = $resultP4->row_array();
            $resultP5 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000006 ");
            $p5 = $resultP5->row_array();
            $resultP5 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p5['skill_rating_id'] . "");
            $p5 = $resultP5->row_array();
            $resultPS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000007 ");
            $pS = $resultPS->row_array();
            $resultPS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $pS['skill_rating_id'] . "");
            $pS = $resultPS->row_array();

            //question report
            $resultR1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000008 ");
            $r1 = $resultR1->row_array();
            if (count($r1) > 0) {
                $resultR1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $r1['skill_rating_id'] . "");
                $r1 = $resultR1->row_array();
            }



            $resultR2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000009 ");
            $r2 = $resultR2->row_array();
            if (count($r1) > 0) {
                $resultR2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $r2['skill_rating_id'] . "");
                $r2 = $resultR2->row_array();
            }
            $resultRS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000010 ");
            $rS = $resultRS->row_array();
            if (count($r1) > 0) {
                $resultRS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $rS['skill_rating_id'] . "");
                $rS = $resultRS->row_array();
            }



            //medical dialogue

            $resultM1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000013 ");
            $m1 = $resultM1->row_array();
            $resultM1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m1['skill_rating_id'] . "");
            $m1 = $resultM1->row_array();

            $resultM2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000014 ");
            $m2 = $resultM2->row_array();
            $resultM2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m2['skill_rating_id'] . "");
            $m2 = $resultM2->row_array();
            $resultM3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000015 ");
            $m3 = $resultM3->row_array();
            $resultM3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m3['skill_rating_id'] . "");
            $m3 = $resultM3->row_array();
            $resultM4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000016 ");
            $m4 = $resultM4->row_array();
            $resultM4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m4['skill_rating_id'] . "");
            $m4 = $resultM4->row_array();
            $resultM5 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000017 ");
            $m5 = $resultM5->row_array();
            $resultM5 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m5['skill_rating_id'] . "");
            $m5 = $resultM5->row_array();

            $resultM6 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000018 ");
            $m6 = $resultM6->row_array();
            $resultM6 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m6['skill_rating_id'] . "");
            $m6 = $resultM6->row_array();

            $resultM7 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000019 ");
            $m7 = $resultM7->row_array();
            $resultM7 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m7['skill_rating_id'] . "");
            $m7 = $resultM7->row_array();

            $resultMS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000020 ");
            $mS = $resultMS->row_array();
            $resultMS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $mS['skill_rating_id'] . "");
            $mS = $resultMS->row_array();

            //Next steps
            $resultN1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000022 ");
            $n1 = $resultN1->row_array();
            $resultN1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n1['skill_rating_id'] . "");
            $n1 = $resultN1->row_array();

            $resultN2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000023");
            $n2 = $resultN2->row_array();
            $resultN2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n2['skill_rating_id'] . "");
            $n2 = $resultN2->row_array();
            $resultN3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000024");
            $n3 = $resultN3->row_array();
            $resultN3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n3['skill_rating_id'] . "");
            $n3 = $resultN3->row_array();
            $resultN4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000025");
            $n4 = $resultN4->row_array();
            $resultN4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n4['skill_rating_id'] . "");
            $n4 = $resultN4->row_array();
            $resultNS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000026");
            $nS = $resultNS->row_array();
            $resultNS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $nS['skill_rating_id'] . "");
            $nS = $resultNS->row_array();
            if ($nS['rating_short_description'] == 5)
                $nS['rating_short_description'] = 2;
            if ($nS['rating_short_description'] == 6)
                $nS['rating_short_description'] = 1;
            if ($nS['rating_short_description'] == 7)
                $nS['rating_short_description'] = 0;

            if ($pS['rating_short_description'] == 7)
                $pS['rating_short_description'] = 0;
            if ($mS['rating_short_description'] == 7)
                $pS['rating_short_description'] = 0;
            if ($rS['rating_short_description'] == 7)
                $rS['rating_short_description'] = 0;

            //planning
            if ($p1['rating_short_description'] == 7)
                $p1['rating_short_description'] = 0;
            if ($p2['rating_short_description'] == 7)
                $p2['rating_short_description'] = 0;
            if ($p3['rating_short_description'] == 7)
                $p3['rating_short_description'] = 0;
            if ($p4['rating_short_description'] == 7)
                $p4['rating_short_description'] = 0;
            if ($p5['rating_short_description'] == 7)
                $p5['rating_short_description'] = 0;

            //open
            if ($r1['rating_short_description'] == 7)
                $r1['rating_short_description'] = 0;
            if ($r2['rating_short_description'] == 7)
                $r2['rating_short_description'] = 0;

            //med
            if ($m1['rating_short_description'] == 7)
                $m1['rating_short_description'] = 0;
            if ($m2['rating_short_description'] == 7)
                $m2['rating_short_description'] = 0;
            if ($m3['rating_short_description'] == 7)
                $m3['rating_short_description'] = 0;
            if ($m4['rating_short_description'] == 7)
                $m4['rating_short_description'] = 0;
            if ($m5['rating_short_description'] == 7)
                $m5['rating_short_description'] = 0;
            if ($m6['rating_short_description'] == 7)
                $m6['rating_short_description'] = 0;
            if ($m7['rating_short_description'] == 7)
                $m7['rating_short_description'] = 0;

            //wrap
            if ($n1['rating_short_description'] == 7)
                $n1['rating_short_description'] = 0;
            if ($n2['rating_short_description'] == 7)
                $n2['rating_short_description'] = 0;
            if ($n3['rating_short_description'] == 7)
                $n3['rating_short_description'] = 0;
            if ($n4['rating_short_description'] == 7)
                $n4['rating_short_description'] = 0;



            $old_startdate_timestamp_create = strtotime($values['create_date']);
            $create_date = date('Y-m-d', $old_startdate_timestamp_create);
            //get engagement status from table
            $resultEng = $this->db->query("select status from engagement_status where id='" . $engStatus . "' ");
            $engStatus = $resultEng->row_array();

            $dataInsert = array(
                "username" => $userId['id'],
                "specialty" => $theparea['id'],
                "status" => $engStatus['status'],
                "date" => $create_date,
                "kol_id" => $hcpId['id'],
                "evaluated_by" => $mangerId['id'],
                "plan_topic1" => $p1['rating_short_description'],
                "plan_topic2" => $p2['rating_short_description'],
                "plan_topic3" => $p3['rating_short_description'],
                "plan_topic4" => $p4['rating_short_description'],
                "plan_topic5" => $p5['rating_short_description'],
                "open_topic1" => $r1['rating_short_description'],
                "open_topic2" => $r2['rating_short_description'],
                "med_topic1" => $m1['rating_short_description'],
                "med_topic2" => $m2['rating_short_description'],
                "med_topic3" => $m3['rating_short_description'],
                "med_topic4" => $m4['rating_short_description'],
                "med_topic5" => $m5['rating_short_description'],
                "med_topic6" => $m6['rating_short_description'],
                "med_topic7" => $m7['rating_short_description'],
                "wrap_topic1" => $n1['rating_short_description'],
                "wrap_topic2" => $n2['rating_short_description'],
                "wrap_topic3" => $n3['rating_short_description'],
                "wrap_topic4" => $n4['rating_short_description'],
                "planscore" => $pS['rating_short_description'],
                "openscore" => $rS['rating_short_description'],
                "medscore" => $mS['rating_short_description'],
                "wrapscore" => $nS['rating_short_description'],
                "comment" => $comment,
                "hcname" => $hcp
                    );

            $this->db->insert("coachings", $dataInsert);
        }
    }
    
    
    
    function interactionMapping(){
               ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
              $result = $this->db->query("select * from event order by event_id desc limit 2   ");
                foreach ($result->result_array() as $values) {
            //email 
            $resultEmail = $this->db->query("select email_address from employee "
                    . "left join event on event.creator_employee_id=employee.employee_id "
                    . "where event.creator_employee_id=" . $values['creator_employee_id'] . "");
            $mail = $resultEmail->row_array();

            //created_by
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();
            if(count($userId)==0)
                $userId['id']=0;
          
            //email 
            $resultEmailEmployee = $this->db->query("select email_address from employee "
                    . "left join event on event.employee_id=employee.employee_id "
                    . "where event.employee_id=" . $values['creator_employee_id'] . "");
            $mailEmployee = $resultEmailEmployee->row_array();
            
            //employee_id
            $empIds = $this->db->query("select id from client_users where email='" . strtolower($mailEmployee['email_address']) . "'");
            $empId = $empIds->row_array();
            
            //teritory_id
             $resultAlignment = $this->db->query("select alignment.alignment_id from alignment "
                    . "left join event on alignment.alignment_id=event.alignment_id "
                    . "where event.alignment_id=" . $values['alignment_id'] . "");
            $teritoryId = $resultAlignment->row_array();
          
            if($values['interaction_channel']=="INPR")
                $channel=1;
               if($values['interaction_channel']=="PHON")
                $channel=2;
             if($values['interaction_channel']=="WEB")
                $channel=3;
             
               if($values['interaction_channel']=="EML")
                $channel=4;
               
               
               if($values['category']=="ONEO")
                $category=1;
               else
                   $category=2;
             /*
            * ------------------attendees-----------------------------------------
            */
            $events = $this->db->query("select * from event_attendee where event_id='" . $values['event_id']. "' ");
            $eventAtendee = $events->row_array();
            
            //kol_id
            $orgId=0;
            $kolIds = $this->db->query("select id from kols where customer_id='" . $eventAtendee['customer_id']. "'");
            $kolId = $kolIds->row_array();
            if($eventAtendee['customer_type']=='PRES')
                $kolId=$kolId['id'];
            else
                $orgId=$kolId['id'];
            if($eventAtendee['customer_type']=='')
                $kolId='';
            //status
            if($eventAtendee['status']=="ATTD")
                $status="Attended";
            if($eventAtendee['status']=="INVT")
                $status="invited";
            if($eventAtendee['status']=="ACPT")
                $status="Accepted";
            
            $statusChangeDate=$eventAtendee["status_change_date"];
            if($statusChangeDate=='')
                $statusChangeDate=0;
            
             $old_startdate_timestamp = strtotime($values['entry_date']);
            $date = date('Y-m-d', $old_startdate_timestamp);
           
            $dataInsert=array(
                  "client_id"=>'',
                  "date"=>$date,
                  "fromtime"=>'',
                  "mode"=>$channel,
                  "location"=>'',
                  "reminder"=>'',
                  "notes"=>'',
                  "created_by"=>$userId["id"],
                  "created_on"=>'',
                  "modified_by"=>$statusChangeDate,
                    "modified_on"=>'',
                    "calendar_event_id"=>'',
                  "totime"=>'',
                  "total_attendies"=>$values["total_attendee_count"],
                  "grouping"=>$category,
                  "address"=>'',
                  "country_id"=>'',
                  "city_id"=>'',
                  "state_id"=>'',"totime"=>'',
                  "postal_code"=>'',
                  "location_type"=>'',
                  "mirf_case_num"=>$values['clm_id'],
                  "territory_id"=>$teritoryId['alignment_id'],
                  "employee_id"=>$empId['id'],
                  "save_later"=>'',
                 "is_org_interaction"=>''
                 
                  ) ;
        $this->db->insert("interactions",$dataInsert); 
           $lastId= $this->db->insert_id();
          
           
           /*
            * Insert into interactions_attendees
            */
           $this->db->query("SET FOREIGN_KEY_CHECKS=0");
           $dataInsert=array(
                  "interaction_id"=>$lastId,
               
                  "kol_id"=>$kolId,
                  "org_id"=>$orgId,
                  "specialty_id"=>NULL,
                  "category_id"=>0,
                  "role_id"=>0,
                  "note"=>0,
                  "status"=>$status
                  ) ;
             $this->db->insert("interactions_attendees",$dataInsert); 
             /*
            * Insert into non_attendees
            */
           $contacts = $this->db->query("select * from event_contact where event_id='" . $values['event_id']. "'");
            $eventContact = $contacts->row_array();
           
 $dataInsert=array(
                  "interaction_id"=>$lastId,
               
                  "name"=>$eventContact['name'],
                  "specialty_id"=>'',
                 
                  ) ;
             $this->db->insert("interactions_other_attendees",$dataInsert); 
             
             
             /**
              * product topic subtopic
              * 
              * 
              * 
              */
           
             $topics = $this->db->query("SELECT
		*
FROM
	iprofile_crm.event_dynamic where table_id=7888500000001957  and event_id='" . $values['event_id']. "'");
            $eventTopic = $topics->row_array();
             $productIds = $this->db->query("SELECT id from products where otsuka_id='" . $eventTopic['text_1'] . "'");
           $productId = $productIds->row_array();
      if($eventTopic['code_1']=="OORE")
                $type=1;
            if($eventTopic['code_1']=="OOPP")
                $type=2;
                    if($eventTopic['code_1']=="OOPN")
                $type=3;
                   if($eventTopic['code_1']=="OINT")
                $type= 4  ; 
                   if($type=='')
                       $type=0;
                $dataInsert=array(
                  "interaction_id"=>$lastId,
               
                  "product_id"=>$productId['id'],
                  "interaction_type"=>$type,
                  "topic_id"=>0,
                 
                  "sub_topic_id"=>0
                  
                  ) ;
                    
             $this->db->insert("interactions_discussion_topic_mapped_data",$dataInsert); 
        }
        
        }
        