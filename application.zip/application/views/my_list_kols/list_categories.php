<?php

/**
 * File to 'List' Categories details
 * 
 * @package application.views.my_list_kols
 * @author: Vinayak
 * @since :2.0
 * @created : 11-4-11
 *  
 */


// prepare array of JS files to insert into queue
	$queued_js_scripts = array('my_lists/list_categories','jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

?>

<style type="text/css">
/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 144px 50%;
	    background-repeat: repeat-y;
	}
	#categoryAddLink{
		text-align:right;
	}
	#categoryAddLink a{
		/*color:#6FA7D1;
		font-size:115%;
		text-decoration:none;
		text-align:right;*/
	}
	#categoryAddLink a img{
		vertical-align: -10px;
	}	

	div.manageListContainer{
		width: 54%;
		float: left;
	}	

	#listAddLink{
		float:right;
		text-align:right;
	}
	
	#listAddLink a{
		text-decoration: none;
	}
	
	#listAddLink a img{
		vertical-align: -10px;
	}		
	
	.recentlYdisplayedRow{
		background-color:#EAEDFF;
	}
	.editingRow{
		background-color:#dfe;
	}
	.listUserResultSet thead th{
		-moz-background-clip:border;
		-moz-background-inline-policy:continuous;
		-moz-background-origin:padding;
	/*	background:#D8DFEA none repeat scroll 0 0; */
	}
	.rightBorder tr{
  		 border-color:red;
	}
	table#rowmarker{
		position:absolute;
		top:150px;
		width:495px;
	}
	
/*         Commented by Laxman
	#categoryContainer {
		margin-left: 45px;
	}
*/
/*			Added by Laxman			*/
	#onclickresult{
		margin-right:10px;
	}
	#CategoryList tr td{
		vertical-align: top;
	} 
	#CategoryNamesList{
	/*	width:510px;
		width:430px;
	*/
	}
	#CategoryArrowMark{
		padding:0px 0px 0px 0px;
		margin:0px 0px 0px 0px;
	}
	tr.selectedRow{
		background-color:#D8DFEA !important;
	}
	#categoryNames .ListResultset tr td label {
	    font-weight: normal;
	}
	div#contentHolder .profileContent {
		margin-top:0px;
	}
	div#contentHolder {
		width:395px;
		width:350px;
	}
	div#contentHolder .profileContent{
		min-height: 105px;
	}
	
	.error{
		padding:0px;	
	} 
</style>

<div id="manageListContainer" class="span-20 last">
	<div id="categoryContainer" class="manageListContainer">
		<div id="categoryAddLink">
	
			<div class="addLink">
<!--				<label class="link" onclick="addCategory();" id="addButton"><div class="actionIcon addIcon"></div>Add Category</label>-->
				<a href="#" class="NewBlueButton NewAddIcon" onclick="addCategory();" id="addButton">Add Category</a>
			</div>
		</div>
			<table id="CategoryList">
				<tr>
					<td style="padding:0px;margin:0px;">
						<div id="categoryNames">
								<table id="CategoryNamesList" class="ListResultset listUserResultSet">
								   <thead>
										<tr valign="top" bgcolor="#D8DFEA">
											<th><?php echo lang("MyLists.CategoryName");?></th>
											<th colspan="2" style="text-align:center;"><?php echo lang("Overview.Action");?></th>
									   </tr>
								   </thead>
								   <?php 
									$slNo=1;
									$arrRow;
									//$i=0;
									foreach($arrCategories as $row){
										 $rowId	= "U_" . $row['id'];
									?>
									     <tr id="<?php echo $rowId;?>" class="rightBorder">
									    
										<!--	<td><label onclick="displayList('<?php echo $row['id']?>',event)" ><?php echo $row['category'] ?></label></td> -->
										<td><label onclick="displayList('<?php echo $row['id']?>',event)" style="font-weight:normal;display:block;"><?php echo $row['category'] ?></label></td>
											
										<?php 
											if($row['user_id']==$this->session->userdata('user_id')){
												$slno = $slNo-1;
												echo '<td class="actionContainer"><div class="actionIcon editIcon tooltip-demo tooltop-top"><a class="tooltipLink" rel="tooltip" title="Edit" href="#" onclick="editCategory('.$row['id'].');"></a></div></td>';
												echo '<td class="actionContainer"><div class="actionIcon deleteIcon tooltip-demo tooltop-top"><a class="tooltipLink" rel="tooltip" title="Delete" href="#" onclick="deleteCategory('.$row['id'].');"></a></div></td>';
												//$arrRow[$i]='<div class="arrowImage" id="onclickresultimg'.$i.'" style="display:none;"> <img height="30px" width="35px" src="'.base_url().'images/arrow-right.gif" /></div>';
												//$i++;
											}
										?>
										<?php  $slNo++;?>
										</tr>
									<?php }?>
							</table>
						</div>
					
					</td>
					<!--<td id="CategoryArrowMark"  style="padding:0px;margin:0px;">
						<table>
							<thead>
								<tr><td> &nbsp; </td></tr>
							</thead>
						<?php 
					//		for($j=0;$j<$i;$j++){
					//				echo '<tr><td style="height:30px;padding:0px 0px 0px 0px;margin:0px 0px 0px 0px;">'.$arrRow[$j].'</td></tr>';							
					//		}
						?>
						</table>
					</td>
				--></tr>
			</table>
		<!-- End of category names contaner  -->
	</div>
	<!-- End of category Container  --><!--
	
	<div id="listContainer" class="manageListContainer" style="valign:middle;padding:0px;marin-left:0px;">
		<div id="listNamesLoading" class="loadingImageContainer" style="display: none;">
			<center><img src="<?php echo base_url()?>images/ajax-loader-round.gif" /></center>
		</div>
		<table id="rowmarker" style="margin-top:25px;">
			<tr>
			
				<td><div id="onclickresult"><div id="listNames"><div style="height: 100px;">&nbsp</div></div></div></td>
			</tr>
			
		</table>
	</div>
	--><!-- End of  list container -->
</div>
<!-- End of manage list container -->
		
		<input type="hidden" id="slno" name="slno" value="<?php echo $slNo;?>" />
		<input type="hidden" id="edit_slno" name="edit_slno" value="<?php echo $slNo;?>" />		
		
		<!-- Container for the 'Add category' modal box -->
		<div id="dailog2">	
			<div id="categoryAddContainer" class="microProfileDialogBox">
				<div class="profileContent" id="categoryAddProfileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Add category' modal box -->
		
		<!-- Container for the 'Add List_name' modal box -->
		<div id="listName1">	
			<div id="listNameAddContainer" class="microProfileDialogBox">
				<div class="profileContent" id="listNameAddProfileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'edit List' modal box -->
		<!--
		 <div id="tt1" style="position: absolute; z-index: 999; visibility: hidden;
		            border: 3px solid #000080; background-color: #4000C0; color: #FFFF00">
		            Hello, every body.
		            
	            <img src="<?php echo base_url();?>images/bullet_add.png" border="0" />
        </div>
	-->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div style="height: 20px;display: none;">
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeLists();" class="ui-icon ui-icon-closethick">close</span></a>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeLists();"/>
		--></div>
		<div class="profileContent" style="clear:both;">
			<div id="listContainer" class="manageListContainer" style="valign:middle;padding:0px;marin-left:0px;">
				<div id="listNamesLoading" class="loadingImageContainer" style="display: none;">
					<center><img src="<?php echo base_url()?>images/ajax-loader-round.gif" /></center>
				</div>
				<div id="listNames"></div>
			</div>
		</div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;">
		<div id="arrowImg" class="arrowMarkM"></div>
		<!--<img id="arrowImg" src="<?php echo base_url();?>images/arrow-right.png" width="30" height="50"/>
	--></div>
