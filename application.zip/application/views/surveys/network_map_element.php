<?php
/*
 * Page to show survey network map
 *  
 * @Author		: Ramesh B
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 15-05-2013
 *  
 */
?>
<?php
	//jit.forecedirected&rgraph_mix
	// prepare array of JS files to insert into queue
	//$queued_js_scripts =array('jit-modified','prefuse-fd');
	$queued_js_scripts =array('jit.forecedirected&rgraph_mix_modified','prefuse-fd');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {getOrganizationInfluenceData();}";
?>
<script src="<?php echo base_url();?>/js/maps/d3js.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<!--[if (IE)]>
	<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/excanvas.js"></script>
<![endif]-->
<style>

	#mapContainer .link {
		fill: none;
		stroke: #666;
		stroke-width: 1px;
	}
	
	#licensing {
		fill: #444;
	}
	
	#mapContainer .link.resolved {
		stroke-dasharray: 0,2 1;
	}
	
	#mapContainer circle {
		fill: #ccc;
		stroke: #333;
		stroke-width: 0px;
	}
	
	#mapContainer text {
		font: 10px sans-serif;
		pointer-events: none;
		text-shadow: 0 1px 0 #fff, 1px 0 0 #fff, 0 -1px 0 #fff, -1px 0 0 #fff;
		display: none;
	}
	
	#mapContainer .link {
		fill: none;
		stroke: #666;
		stroke-width: 1px;
	}
	
	#licensing {
		fill: #444;
	}
	
	#mapContainer .link.resolved {
		stroke-dasharray: 0,2 1;
	}
	
	#mapContainer circle {
		fill: #ccc;
		stroke: #333;
		stroke-width: 0px;
	}
	
	#mapContainer text {
		font: 10px sans-serif;
		pointer-events: none;
		text-shadow: 0 1px 0 #fff, 1px 0 0 #fff, 0 -1px 0 #fff, -1px 0 0 #fff;
		display: none;
	}
	
		#addNewKol .link {
		fill: none;
		stroke: #666;
		stroke-width: 1px;
	}
	
	#licensing {
		fill: #444;
	}
	
	#addNewKol .link.resolved {
		stroke-dasharray: 0,2 1;
	}
	
	#addNewKol circle {
		fill: #ccc;
		stroke: #333;
		stroke-width: 0px;
	}
	
	#addNewKol text {
		font: 10px sans-serif;
		pointer-events: none;
		text-shadow: 0 1px 0 #fff, 1px 0 0 #fff, 0 -1px 0 #fff, -1px 0 0 #fff;
		display: none;
	}
</style>
<script type="text/javascript">
var baseUrl='<?php echo base_url();?>';
var rdGraphObj;
var fdGraphObj;
var fd;
var currentJson;
var currentView='view2';
var isMicroviewLoading = false;
var showToolTip = false;
var showMicroview = true;

//Don't show node tooltip on iPad as it is leading to extra click to view the connections
<?php $mobile = mobile_device_detect(); 
	if(isset($mobile[1])){?>
	showToolTip = false;
<?php } else {?>
	showToolTip = true;
<?php }?>

var isIE8 = false;
<?php 
	$isIE8 = 0;
	$u_agent = $_SERVER['HTTP_USER_AGENT']; 
	if(preg_match('/MSIE [1-8]/i',$u_agent))
		$isIE8 = 1;
?>
var isIE8 = <?php echo $isIE8;?>;
var labelType, useGradients, nativeTextSupport, animate;

$(document).ready(function(){
	// Settings for the Dialog Box
	var kolMicroProfileDialogOpts = {
			title: "Profile Snapshot",
			modal: true,
			autoOpen: false,
			width:310,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};

	$("#kolMicroProfile").dialog(kolMicroProfileDialogOpts);

	var kolInfluenceOptions = {
			title: "Kol Influence",
			modal: true,
			autoOpen: false,
			width: 614,
			dialogClass: "microView",
			position: [250],
			resizable:false,
			open: function() {
				//display correct dialog content
			},
			close: function(){
			}
	};
	$('#kolInfluenceContainer').dialog(kolInfluenceOptions);

	$("#micro-hide-icon").click(function(){
		animateMicroviewBoxHide();
	})

	var addNewKol = {
		title: "Add KOL",
		modal: true,
		autoOpen: false,
		width: 550,
		draggable:false,
		position: ['center', 80],
		dialogClass: "microView",
		open: function() {
			//display correct dialog content
		}
	};
	
	$("#addNewKol").dialog(addNewKol);
	$('#addNewKol').on('dialogclose', function(event) {
		$("#indivisual-influence").html('');
		$("#view2Infovis").html('');
	     //custom logic fired after dialog is closed.  
	});
	/*$('.chosenSelect').chosen({allow_single_deselect: true});
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});*/

	//$("#listSurveysResultSet .jqgrow td::nth-child(4)").live('click',function(){
	//	var id = $(this).parent().attr("id");
	//	showIndivisualSurveyMap(id);
	//});

	//Add a div in left side bar to hold the connection list
	$("#sideBarWrapper").append("<div id='connection-list'></div>");

	$(".mv-on").click(function(){
		$(this).toggleClass('mv-off');
		if($(this).hasClass('mv-off'))
			showMicroview = false
		else
			showMicroview = true;
	});
	
});


function viewOrgMicroProfile(orgId, e){
	isMicroviewLoading = true;
	//animateMicroviewBoxHide();
	$("#microview-container").html("<div class='microViewLoading'>Loading...</div>");
	$('#microview-container').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'100%',cursor:'default'}});		
	$("#microview-container").load(baseUrl+'organizations/get_microview/'+orgId,{},
		function(){	$('#microview-container').unblock();
		isMicroviewLoading = false;
		var idElements=orgId.split("-");
		if(idElements[0] == 'org')
			$("#microview-container").css("height","100px");
		if(idElements[0] != 'org' && idElements[0] != 'kol')
			$("#microview-container").css("height","100px");
		animateMicroviewBoxShow();
		//$("#kolMicroProfileContent .microViewTbl").append("<tr><td colspan='4'><a href='#' id='micro-hide-icon'></a></td></tr>");
		//$("#kolMicroProfileContent").append("<a href='#' id='micro-hide-icon'></a>");
		var microviewHeight = $('#microview-container')[0].scrollHeight;
		//$("#microviewWrapper").append("<a href='#' id='micro-hide-icon'></a>");
		$('#micro-hide-icon').parent().animate({top: microviewHeight-5}, 1000, function() {$('#micro-hide-icon').css('display','block');});
	}
	);
	return false;
}

function animateMicroviewBoxShow(){
	$('#micro-hide-icon').css('display','none');
	var microviewHeight = $('#microview-container')[0].scrollHeight;
	$('#microview-container').animate({height: microviewHeight}, 1000, function() {	
		$('#micro-hide-icon').css('display','block');
	});
}

function animateMicroviewBoxHide(){
	$('#micro-hide-icon').css('display','none');
	$('#microview-container').animate({height: 50}, 100, function() { 	
		if(!isMicroviewLoading)
			$("#microview-container").html("<div id='microview-lable'> <span>KOL Microview</span> <br>(Click on Name)</div>");
	});		
}

(function() {
  var ua = navigator.userAgent,
      iStuff = ua.match(/iPhone/i) || ua.match(/iPad/i),
      typeOfCanvas = typeof HTMLCanvasElement,
      nativeCanvasSupport = (typeOfCanvas == 'object' || typeOfCanvas == 'function'),
      textSupport = nativeCanvasSupport 
        && (typeof document.createElement('canvas').getContext('2d').fillText == 'function');
  //I'm setting this based on the fact that ExCanvas provides text support for IE
  //and that as of today iPhone/iPad current text support is lame
  labelType = (!nativeCanvasSupport || (textSupport && !iStuff))? 'Native' : 'HTML';
  nativeTextSupport = labelType == 'Native';
  useGradients = nativeCanvasSupport;
  animate = !(iStuff || !nativeCanvasSupport);
})();


//Loads the organization influence map data 
function getSurveyInfluenceData(){
	$('#queryOptContainer1').html('');
	$("#map-log").html("");
	//$('html, body').animate({scrollTop:$('#view2Infovis').position().top}, 'slow');
	
	if($('#chartFooter').css('display')=='block'){
		$('#chartFooter').slideToggle('slow');
	}
	if($('#surveyGeoMap').css('display')=='block'){
		$('#surveyGeoMap').slideToggle('slow');
	}
	
	if(!$('#queryOptContainer').html() != '')
		$('#queryOptContainer').prepend($('#queryContainer').html());

	if($('#surveyNetworkMap').css('display')!='block'){
		$('#surveyNetworkMap').slideToggle('slow');
	}
	animateMicroviewBoxHide();
	$('#mapContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	var orgName=$("#organization").val();
	var actionUrl='';
	actionUrl=baseUrl+'surveys/get_survey_influence_data/';
	//Ajax request to load influence map json data
	var surveyId	= $('#survey').val();
	if(filterType == 'custom')
		var data	= $('#customQueryForm').serialize();
	else
		var data	= $('#preDefinedQuery').find('form').serialize();
	data		+= '&survey_id='+surveyId;
	//data['org_name'] = orgName;
	$.ajax({
		type: "post",
		dataType:"json",
		data:data,
		url: actionUrl,
		success: function(json){
			currentJson=json;
			rdGraphObj=null;
			$("#indivisual-influence").html('');
			$("#view2Infovis").html('');
			if(json.length != 0)
			 	surveysView(json,'view2Infovis','#FFFFFF');
			else{
				$("#map-log").show();
				$("#map-log").html("No Connections Found");
			}
		},
		complete: function(){
			//hide loading image
			$('.loadingIndicator').hide();
			$('#mapContainer').unblock();

			//Show refine by 
			$("#rightSideBarSlider").show();
		}
	});
}


//Initializes the RGraph with the given json and other parameters
function surveysView(json,divId,circleColor, lineDistance){
	if(lineDistance == null)
		lineDistance = 130;

    var fd = new $jit.ForceDirected({
        //id of the visualization container
        injectInto: divId,
        //Enable zooming and panning
        //by scrolling and DnD
        'background': {
          'CanvasStyles': {
            'strokeStyle': circleColor,
            'shadowBlur': 50,
            'shadowColor': '#ccc'
          }
        },
        Navigation: {
          enable: true,
          //Enable panning events only if we're dragging the empty
          //canvas (and not a node).
          panning: 'avoid nodes',
          zooming: 10 //zoom speed. higher is more sensible
        },
        // Change node and edge styles such as
        // color and width.
        // These properties are also set per node
        // with dollar prefixed data-properties in the
        // JSON structure.
       //Set Edge and Node colors.
        Node: {
        	overridable:true
        },
        Edge: {
            overridable:true,
            type:"double_arrow",
            color: '#4F81BD',
            lineWidth:0.8
        },
        //Add Tips
        Tips: {
          enable: showToolTip,
          onShow: function(tip, node) {
            //count connections
            var count = 0;
            node.eachAdjacency(function() { count++; });
            //display node info in tooltip
            tip.innerHTML = "<div class=\"tip-title\">" + node.name + "</div>"
              + "<div class=\"tip-text\"><b>connections:</b> " + count + "</div>";
          }
        },
        // Add node events
        Events: {
          enable: true,
          type: 'Native',
          //Change cursor style when hovering a node
          onMouseEnter: function() {
            fd.canvas.getElement().style.cursor = 'move';
          },
          onMouseLeave: function() {
            fd.canvas.getElement().style.cursor = '';
          },
          //Update node positions when dragged
          onDragMove: function(node, eventInfo, e) {
              var pos = eventInfo.getPos();
              node.pos.setc(pos.x, pos.y);
              fd.plot();
          },
          //Implement the same handler for touchscreens
          onTouchMove: function(node, eventInfo, e) {
            $jit.util.event.stop(e); //stop default touchmove event
            this.onDragMove(node, eventInfo, e);
          }
        },
        //Number of iterations for the FD algorithm
        iterations: 100,
        //Edge length
        levelDistance: 180,
        // Add text to the labels. This method is only triggered
        // on label creation and only for DOM labels (not native canvas ones).
        onCreateLabel: function(domElement, node){
          domElement.innerHTML = node.name;
          var style = domElement.style;
          style.fontSize = "0.8em";
          style.color = "#000000";

          domElement.onclick = function(e) {
          	//set final styles
		        fd.graph.eachNode(function(n) {
		          if(n.id != node.id) delete n.selected;
		        	  n.setData('dim', 3, 'end');
		          n.eachAdjacency(function(adj) {
		            adj.setDataset('end', {
		            	lineWidth: 0.7,
		            	color: '#4F81BD'
		            });
		          });
		        });
		        
		        if(!node.selected) {
	        		fd.graph.eachNode(function(n) {
			          if(n.id != node.id) delete n.selected;
			        	  n.setData('dim', 3, 'end');
			          n.eachAdjacency(function(adj) {
			            adj.setDataset('end', {
			            	lineWidth: 0.7,
			            	color: '#A3D5FF'
			            });
			          });
			        });
			        
		          node.selected = true;
		          node.setData('dim', 4, 'end');
		          node.eachAdjacency(function(adj) {
			       	adj.nodeTo.setData('dim', 4, 'end');
		            adj.setDataset('end', {
		              lineWidth: 1.5,
		              color:'#FF5555'
		            });
		          });

		        } else {
		          delete node.selected;
		        }

		        if(node.selected) {
			        if(showMicroview)
		        	viewOrgMicroProfile(node.id,e);
		        	
		    		$("div.node").addClass('not-connected');
		        	$("#"+node.id).removeClass('not-connected');
		        	$("#"+node.id).addClass('connected');
		        	node.eachAdjacency(function(adj) {
		        		$("#"+adj.nodeTo.id).removeClass('not-connected');
		        		$("#"+adj.nodeTo.id).addClass('connected');
		        	});
		        }else{
		        	$("div.node").removeClass('not-connected');
		        	$("div.node").removeClass('connected');
		        	$("#connection-list").html("");
			    }  
		        
		        //trigger animation to final styles
		        fd.fx.animate({
		          modes: ['node-property:dim:color',
		                  'edge-property:lineWidth:color'],
		          duration: 100
		        });

				//Prepare a connection list and show
		        /*var html = "<label>connections:</label><ul>";
		        node.eachAdjacency(function(adj){
		          if(adj.getData('alpha')) 
		        	  html +="<li cc-id='"+adj.nodeTo.id+"'>"+adj.nodeTo.name+"</li>";
		        });
		        html +="</ul>";
		        $("#connection-list").html(html);*/
          }
          //end name click event
        },
        // Change node styles when DOM labels are placed
        // or moved.
        onPlaceLabel: function(domElement, node){
          var style = domElement.style;
          var left = parseInt(style.left);
          var top = parseInt(style.top);
          var w = domElement.offsetWidth;
          style.left = (left - w / 2) + 'px';
          style.top = (top + 10) + 'px';
          style.display = '';
        }
      });
      // load JSON data.
      fd.loadJSON(json);
      // compute positions incrementally and animate.
      fd.computeFastIncremental({
			iter: 5,
			property: 'end',
			onStep: function(perc){
	    	  $('#map-log').show();
	          $('#map-log').html(perc + '% loaded...');
			},
   			onComplete: function(){
				$('#map-log').hide();
     			fd.animate({
        			modes: ['linear'],
        			transition: $jit.Trans.Elastic.easeOut,
        			duration: 0
      			});
			//Log.write('Graph complete');
    		}
  	  	});
      /*fd.computeIncremental({
        iter: 5,
        property: 'end',
        onStep: function(perc){
    	  $('#map-log').show();
          $('#map-log').html(perc + '% loaded...');
        },
        onComplete: function(){
        	$('#map-log').hide();
          fd.animate({
            modes: ['linear'],
            transition: $jit.Trans.Elastic.easeOut,
            duration: 1000
          });
        }
      });*/
    if(rdGraphObj == null)
    	rdGraphObj=fd;

    //custome edge
    $jit.ForceDirected.Plot.EdgeTypes.implement({
        'double_arrow': {
            'render': function(adj, canvas) {
                var from = adj.nodeFrom.pos.getc(true),
                    to = adj.nodeTo.pos.getc(true),
                    dim = adj.getData('dim'),
                    ctx = canvas.getCtx(),
                    vect = new $jit.Complex(to.x - from.x, to.y - from.y);
                vect.$scale(dim / vect.norm());
                //Needed for drawing the first arrow
                var intermediatePoint = new $jit.Complex(to.x - vect.x,
    to.y - vect.y),
                    normal = new $jit.Complex(-vect.y / 2, vect.x / 2),
                    v1 = intermediatePoint.add(normal),
                    v2 = intermediatePoint.$add(normal.$scale(-1));

                var vect2 = new $jit.Complex(to.x - from.x, to.y -
    from.y);
                vect2.$scale(dim / vect2.norm());
                //Needed for drawing the second arrow
                var intermediatePoint2 = new $jit.Complex(from.x +
    vect2.x, from.y + vect2.y),
                    normal = new $jit.Complex(-vect2.y / 2, vect2.x / 2),
                    v12 = intermediatePoint2.add(normal),
                    v22 = intermediatePoint2.$add(normal.$scale(-1));

                //Drawing the double arrow on the canvas, first the line,    then the ends
                ctx.beginPath();
                ctx.moveTo(from.x, from.y);
                ctx.lineTo(to.x, to.y);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(v1.x, v1.y);
                ctx.lineTo(v2.x, v2.y);
                ctx.lineTo(to.x, to.y);
                ctx.closePath();
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(v12.x, v12.y);
                ctx.lineTo(v22.x, v22.y);
                ctx.lineTo(from.x, from.y);
                ctx.closePath();
                ctx.fill();
            }
        }
    }); 
}

function showIndivisualSurveyMap(idString){
	animateMicroviewBoxHide();
	$(".addNewKolContent").show();
	$("#addNewKol").dialog('option','width',680);
	$("#addNewKol").dialog('option','position',['center', 80]);
	
	$(".addNewKolContent").html("<div id='indivisual-influence'><div class='microViewLoading'>Loading...</div></div>");
	$("#addNewKol").dialog("open");
	
	var actionUrl='';
	actionUrl=baseUrl+'surveys/get_indivisual_survey_influence_data/'+idString;
	//Ajax request to load influence map json data
	var surveyId	= $('#survey').val();
	var data	= $('#searchFiltersContainer').find('form').serialize();
	data		+= '&survey_id='+surveyId;
	data		+= '&inf_org='+infOrgName;
	if(infCity!='')
		data		+= '&inf_city='+infCity;
	if(infState!='')
		data		+= '&inf_state='+infState;
	if(infCountry!='')
		data		+= '&inf_country='+infCountry;
	if(infPostal!='')
		data		+= '&inf_postal='+infPostal;
	
	$.ajax({
		type: "post",
		dataType:"json",
		data:data,
		url: actionUrl,
		success: function(json){
//		alert(json.toSource());
			currentJson=json.data;
			 rdGraphObj=null;
			$("#indivisual-influence").html('');
			$("#view2Infovis").html('');
//			$('#ids').val(json.ids);
			//view2(json);
			 loadIndivisualSurveyMap(json.data,'indivisual-influence','#FFFFFF');
			 showListViewOfInfluencer(json.gridData,idString);
			 showMap();
		},
		complete: function(){
			 $("#indivisual-influence .microViewLoading").remove();
		}
	});
	return false;
}

function loadIndivisualSurveyMap(json,divId,lineColor){
	//custome edge
   $jit.RGraph.Plot.EdgeTypes.implement({
        'double_arrow': {
            'render': function(adj, canvas) {
                var from = adj.nodeFrom.pos.getc(true),
                    to = adj.nodeTo.pos.getc(true),
                    dim = adj.getData('dim'),
                    ctx = canvas.getCtx(),
                    vect = new $jit.Complex(to.x - from.x, to.y - from.y);
                vect.$scale(dim / vect.norm());
                //Needed for drawing the first arrow
                var intermediatePoint = new $jit.Complex(to.x - vect.x,
    to.y - vect.y),
                    normal = new $jit.Complex(-vect.y / 2, vect.x / 2),
                    v1 = intermediatePoint.add(normal),
                    v2 = intermediatePoint.$add(normal.$scale(-1));

                var vect2 = new $jit.Complex(to.x - from.x, to.y -
    from.y);
                vect2.$scale(dim / vect2.norm());
                //Needed for drawing the second arrow
                var intermediatePoint2 = new $jit.Complex(from.x +
    vect2.x, from.y + vect2.y),
                    normal = new $jit.Complex(-vect2.y / 2, vect2.x / 2),
                    v12 = intermediatePoint2.add(normal),
                    v22 = intermediatePoint2.$add(normal.$scale(-1));

                //Drawing the double arrow on the canvas, first the line,    then the ends
                ctx.beginPath();
                ctx.moveTo(from.x, from.y);
                ctx.lineTo(to.x, to.y);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(v1.x, v1.y);
                ctx.lineTo(v2.x, v2.y);
                ctx.lineTo(to.x, to.y);
                ctx.closePath();
                //ctx.fillStyle = "orange";
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(v12.x, v12.y);
                ctx.lineTo(v22.x, v22.y);
                ctx.lineTo(from.x, from.y);
                ctx.closePath();
                //ctx.fillStyle = "orange";
                ctx.fill();
            }
        }
    });
	    
	 var rgraph = new $jit.RGraph({
	      'injectInto': divId,
	      //Optional: Add a background canvas
	      //that draws some concentric circles.
	      'background': {
	        'CanvasStyles': {
	          'strokeStyle': lineColor,
	          'shadowBlur': 50,
	          'shadowColor': '#ccc'
	        }
	      },
	      //Add navigation capabilities:
	      //zooming by scrolling and panning.
	      Navigation: {
	        enable: true,
	        panning: true,
	        zooming: 10
	      },
	        //Nodes and Edges parameters
	        //can be overridden if defined in 
	        //the JSON input data.
	        //This way we can define different node
	        //types individually.
	        Node: {
	            'overridable': true,
	            'dim' : 5
	        },
	        Edge: {
	            'overridable': true,
	            'color': '#4F81BD',
	            'dim':15
	        },
	        //Set polar interpolation.
	        //Default's linear.
	        interpolation: 'linear',
	        //Change the transition effect from linear
	        //to elastic.
	        transition: $jit.Trans.Elastic.easeOut,
	        //Change other animation parameters.
	        duration:1500,
	        fps: 30,
	        //Change father-child distance.
	        levelDistance: 200,
	        //This method is called right before plotting
	        //an edge. This method is useful to change edge styles
	        //individually.
	        onBeforePlotLine: function(adj){
	            //Add some random lineWidth to each edge.
	            if (!adj.data.$lineWidth) 
	                adj.data.$lineWidth = Math.random() * 5 + 1;
	        },
	        
	        onBeforeCompute: function(node){
	           
	        },
	        //Add node click handler and some styles.
	        //This method is called only once for each node/label crated.
	        onCreateLabel: function(domElement, node){
	            domElement.innerHTML = node.name;
	            domElement.onclick = function () {
	               var idString = node.id;
	               var idElements = idString.split('-');
	               var nodeId = idElements[1];
	               //showIndivisualSurveyMap(nodeId);
	            };
	            var style = domElement.style;
	            style.cursor = 'pointer';
	        },
	        //This method is called when rendering/moving a label.
	        //This is method is useful to make some last minute changes
	        //to node labels like adding some position offset.
	        onPlaceLabel: function(domElement, node){
	            var style = domElement.style;
	            var left = parseInt(style.left);
	            var w = domElement.offsetWidth;
	            style.left = (left - w / 2) + 'px';
	        }
	    });
	    //load graph. here '0' indcates the 0th position node will be placed at the center
	    rgraph.loadJSON(json, 0);
	    
	    //compute positions and plot
	    rgraph.refresh();
	    //end
	    rgraph.controller.onBeforeCompute(rgraph.graph.getNode(rgraph.root));

}

function closeInfMicroview(){
	$("#microviewContainer").hide();	
}
</script>

<style>

	#mapContainer{
		float: right;
	    position: relative;
	    width: 100%;
	}
	#log {
		position: absolute;
		left: 280px !important; 
		display: none;
	}

	#view1Infovis,#view2Infovis {
	    position:relative;
	    width:790px;
	    height:600px;
	    margin:auto;
	    overflow:hidden;
	}
	span.name {
		color: #555 !important;
		cursor: pointer;
	}
	span.name:HOVER{
		font-weight: bold;
		font-size: 15px;
		color: black !important;
	}

	#ui-dialog-title-kolInfluenceContainer{
		display: block;
		text-align: center;
		color: #626262;
	}
	.node{
		margin-top: -7px;
		cursor: pointer;
	}
	
	.microView .ui-dialog-titlebar{
		position:relative !important;
		right:inherit;
		width:auto !important;
	}
	.microView .ui-dialog-title{
		width:auto !important;
	}

	div.filterSearchIcon{
		display: inline-block;
	    float: none;
	   	margin-bottom: -2px;
   	 	margin-right: -20px;
	    position: relative;
	}
	#microviewWrapper #collapseWrapper{
		position: absolute;
	    top: 48px !important;
	    right: 110px;
	    z-index: 1000;
	}
	#collapseWrapper #micro-hide-icon{
		display: none;
	}
	#micro-hide-icon{
    	background-image: url("<?php echo base_url()?>images/hide_up.png");
	    background-repeat: no-repeat;
	    cursor: pointer;
	    display: block;
	    height: 27px;
	    margin-left: 193px;
	    margin-top: -12px;
	    position: relative;
	    width: 34px;
    }
    #microviewWrapper{
		position: absolute;
	    right: -8px;
	    top: -20px;
	}
	#microview-container{
		position: absolute;
	    top: 0px;
	    right: 0px;
	    z-index: 2;
	    width:260px;
	    height: 50px;
	    min-height: 50px;
	    border: 1px solid;
	    border-bottom-width: 2px;
	    background-color: white;
	    margin-right: 11px;
	    overflow: hidden;
	}
	#microview-container td,#microview-container th{
		border-width: 0px !important;
	}
	
	#microview-lable{
		text-align: center;
	}
	#microview-lable span{
		font-weight: bold;
	}
	.tip{
		background-color: white;
	    border: 2px solid green;
	    border-radius: 7px 7px 7px 7px;
	    color: black;
	    padding: 3px;
	}
	.not-connected{
		color:#aaaaaa !important;
	}
	.connected{
		font-size: 11px !important;
		z-index: 1;
	}
	#map-log{
		color: black;
	    font-size: 16px;
	    height: 20px;
	    position: absolute;
	    right: 45%;
	    top: 20%;
	}
	
	/* Connection list CSS*/
	#connection-list{
		width:100%;
		min-height: 200px;
	}
	#connection-list ul{
		border-top: 1px solid #AAAAAA;
	    list-style: none outside none;
	    margin: 0;
	    padding: 0;
	}
	#connection-list li{
		border-bottom: 1px solid #AAAAAA;
	    padding-bottom: 3px;
	    padding-top: 3px
	}
	#connection-list li:hover{
		background-color: #EEEEEE;
    	cursor: pointer;
	}
	.mv-on{
		background-image: url("<?php echo base_url()?>images/mv-on.PNG");
	    background-repeat: no-repeat;
	    cursor: pointer;
	    height: 26px;
	    overflow: hidden;
	    position: absolute;
	    right: 15px;
	    top: -42px;
	    width: 55px;
	    z-index: 2;
	}
	.mv-off{
		background-image: url("<?php echo base_url()?>images/mv-off.PNG") !important;
	}
	.ie8-error{
		background-image: url("<?php echo base_url()?>images/caution_mark.png");
	   	background-position: 15px 50%;
	    background-repeat: no-repeat;
	    background-size: 55px auto;
	    font-size: 13px !important;
	    height: 42px !important;
	    left: 0 !important;
	    margin: auto;
	    padding-left: 73px;
	    padding-right: 10px;
	    top: 15% !important;
	    width: 100%;
	}
	#microview-container{
	 height: 64px;
	}
	#name-container{
		margin-bottom:1px;	
	}
	.microView .ui-dialog-content{
		background: white !important;
	}
	#microviewContainer{
		min-height: 80px;
		width:200px;
		border: 1px solid #bbbbbb;
		position: absolute;
		right: 5px;
		top: 5px;
		padding: 5px;
		background: white;
	}
	.close-microview{
		position: absolute;
	    right: 4px;
	    top: -2px;
	    color: blue;
	    font-weight: bold;
	    cursor: pointer;
	}
</style>
<input type="button" value="In" onclick="triggerZoomIn();"></input>
<input type="button" value="Out" onclick="triggerZoomOut();"></input>
<input type="button" value="Names toggle" onclick="toggleNames();"></input>
<input type="button" value="Cancel" onclick="kill();"></input>
<div id="mapContainer">
		<div id="chart" style="margin: auto;border: 1px solid #bbbbbb;width: 100%;height: 700px;">
		
		</div>
		<div id="microviewContainer" style="display: none;">
		
		</div>
</div>
	<input type="hidden" value="" name="ids" id="ids"></input>
<!-- KOL Influence Map container -->
 <div id="kolInfluenceContainer" class="microProfileDialogBox">
 	<div id="kolInfluence" class="profileContent"></div>
 </div>
 
<div id="addNewKol" class="microProfileDialogBox">
 <button class="ui-btn ui-btn-inline customActionButton"   id="mapView" onclick="showMap()" >Map View</button>
	<button class="ui-btn ui-btn-inline" onclick="showGrid()"  id="listView">List View</button>
	<div class="addNewKolContent profileContent"></div>
	 <div class="gridWrapper" id="gridContainerOfInd">
		<div id="indInfluencerList"></div>
		<!-- <table id="indInfluencerListResultSet"></table> -->
	</div>
	<div id="influNote"><lable style="font-weight: bold;">Note:</lable> Only the top 20 Respondents are displayed in the map. To view the complete list please click on the List View Button.</div>
</div>
	