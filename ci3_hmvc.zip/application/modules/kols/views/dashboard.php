<link href="<?php echo base_url().ASSETS;?>/c3js/c3.css" rel="stylesheet" type="text/css">
<?php
$queued_js_scripts = array('c3js/c3.min',
			'c3js/d3.c3.min',
			'jit/jit'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
#view1Infovis {
    position: relative;
    width: 400px;
    height: 320px;
    margin: auto;
    overflow: hidden;
}
</style>
<script type="text/javascript">
var kolId 		= '<?php echo $arrKol['kols_client_visibility_id']?>';
var clientKOLs	= '<?php echo $clientKols;?>';
var specialtyId = 	'<?php echo $arrKol['specialty'];?>';
var is_profile_rating_enabled= '<?php echo $this->common_helper->check_module("profile_ratings");?>';
$(document).ready(function (){
	loadDashboardCharts();
});
function loadDashboardCharts(){
    $.ajax({
        type: "post",
        url: base_url + 'kols/kols/get_dashboard_charts_data/' + kolId,
        dataType: 'json',
        success: function (returnData) {
            //Affliations charts
        	var bindToId='affiliationsChartByOrgType';
            var affByOrgTypeData = returnData.affByOrgTypeData;
            draw_pie_chart(affByOrgTypeData,bindToId);            

            var affByEngTypeData = returnData.affByEngTypeData;
           	bindToId='affiliationsChartByEngType';
           	draw_pie_chart(affByEngTypeData,bindToId); 
           	
	        var eventsByTopicData = returnData.eventsByTopicData;
	     	bindToId='eventsChartByTopic';
	     	draw_pie_chart(eventsByTopicData,bindToId);   
	     	      
            var pubsAuthPosData = returnData.pubsAuthPosData;
	     	bindToId='pubAuthPosChart';
	     	draw_pie_chart(pubsAuthPosData,bindToId); 
	     	
            //Events Charts
            var eventsTimelineData 			= returnData.eventsTimelineData;
            if((eventsTimelineData.length)>0){
	            var eventTimelineCategories 	= eventsTimelineData[0];
	            var data 						= eventsTimelineData[1];
	            var data2 						= eventsTimelineData[1];                       
	            var eventsTimelineDataValues 	= [];
	            var eventsTimelineDataGroups 	= [];
	            $.each(data2,function (key, value) {  	
	            	eventsTimelineDataValues[key]=data2[key].data;
	            	eventsTimelineDataGroups[key]=data2[key].name;
	            	eventsTimelineDataValues[key].unshift(data2[key].name);            	
	            });
	            data2 				= eventsTimelineDataValues;
	            var groups 			= eventsTimelineDataGroups;
	            var conferenceData 	= eventsTimelineData[2];
	            var grData 			= eventsTimelineData[3];
	            var amData 			= eventsTimelineData[4];
	            var cmeData 		= eventsTimelineData[5];
	            var webcastData 	= eventsTimelineData[6];
	            var webinarData 	= eventsTimelineData[7];
	            var podcastData 	= eventsTimelineData[8];
	            getEventsTimelineOptions(eventTimelineCategories, data, data2,groups, conferenceData, grData, amData, cmeData, webcastData, webinarData, podcastData);
            }
            //Publications Charts
            var pubsByTimeData = returnData.pubsByTimeData;
            if((pubsByTimeData.length)>0){
	            pubsCategories = pubsByTimeData[0];
	            pubsCountData = pubsByTimeData[1];            
	            getPubsByYearChartOptions(pubsCategories, pubsCountData);
            }
            //Influence Map
            var influenceData = returnData.influenceData;
            drowInfluenceMap(influenceData);
        }
    });
    //Profile Score chart request
    if(is_profile_rating_enabled){
	    $("#kolProfileScoreChart #inner").load(base_url + 'profile_ratings/profile_ratings/show_profile_score_chart/' + kolId + '/' + specialtyId + '/true', {}, function () {
	    });
    }
    var is_interaction_module_enabled='<?php echo $this->common_helper->check_module("interactions");?>';
	if(is_interaction_module_enabled){
		interactionCharts();
	}
}
function interactionCharts(){
    var data = {'kol_id':kolId};
	$.ajax({
	url: base_url+'interactions/interactions/interactions_by_topic',
	dataType: 'json',
	data:data,
	type:'post',
	success: function(returnDataTopic) {
		var interByTopic 	= returnDataTopic.arrByTopic;
    	var bindToId='interactionsByTopic';
        draw_pie_chart(interByTopic,bindToId);  
	}
	});
	$.ajax({
		url: base_url+'interactions/interactions/interactions_by_channel',
		dataType: 'json',
		data:data,
		type:'post',
		success: function(returnDataChannel) {
			if(!(returnDataChannel.status)){
				$('#interationCharts').attr('style','display:none;');
			}
			var interByChannel 	= returnDataChannel.arrByChannel;
	    	var bindToId='interactionByChannel';
	        draw_pie_chart(interByChannel,bindToId);
		}
	});
}
function getEventsTimelineOptions(eventTimelineCategories, data,data2,group, conferenceData, grData, amData, cmeData, webcastData, webinarData, podcastData) {
	eventTimelineCategories.unshift("x");
	////  console.log(JSON.stringify(data2));   
	  data2.unshift(eventTimelineCategories); 
	  var chart = c3.generate({
	    	bindto: '#eventsByTimeline',
	    	data: {
	    	 x : 'x',
	            columns: data2,        	
	            groups: [group],
	            type: 'bar'
	        },
	        size: {
		    	  width:450
		    },
	        axis: {
	            x: {
	                type: 'category',multiline:false, // this needed to load string x value
	                tick: {
	                	rotate: 75,
	            	   	multiline: false
	           	    },
	           	    label: {
	              	        text: 'Year',
	              	        position: 'outer-center',
	              	     }	
	            },
	            y:{
	            	label: {
	          	        text: 'Events By Year',
	          	        position: 'outer-middle',
	          	     }
	            }
	        },
	        color: {
		    	  pattern: chartColors
	        }
	   });
// 	  removeFloatingTicks('#eventsByTimeline');
	  setTimeout(function(){ 
	  	$('#eventsByTimeline svg').attr('width','515')
	  }, 300);
	}
function getPubsByYearChartOptions(a, b) {
	var year=new Array();
	$.each( a, function( index, value ){		
		if(value!=false || value!=''){
	    	year.push(value + '-01-01');
		}
	});
   a = year;
    a.unshift("x");
    b.unshift("Publications"); 
    var chart = c3.generate({
    	bindto: '#pubsChartByYear',
    	data: {
    	 x : 'x',
            columns: [a,b],        	
            groups: [['publications']],
            type: 'area'
        },
        size:{
        	width:450
        },
        axis: {
            x: {
                type: 'timeseries',multiline:false, // this needed to load string x value
                tick: {
           	     count:5,
           	     format: '%Y'
           	    },
           	    label: {
              	        text: 'Year',
              	        position: 'outer-center',
              	     }	
            },
            y:{
	        	/*tick: {	        	  
	        	  count:4,
	        	  format: d3.format('.0f')
	        	},	*/        	
            	label: {
          	        text: 'Articles Published',
          	        position: 'outer-middle',
          	     }
            }
        },
        color: {
	    	  pattern: chartColors
        }
   });
//     removeFloatingTicks('#pubsChartByYear');
    setTimeout(function(){ 
    	$('#pubsChartByYear svg').attr('width','515')
    }, 300);
    
}
function drowInfluenceMap(json) {
    var currentJson = json.connectionData;
    var totalNodes = currentJson.children.length;
    var startYear = 0;
    var endYear = totalNodes;
    var arrChildrens = [];
    var arrAllChildrens = currentJson.children;
    var arrOfIds = [];
    var i;
    var arrClientKOLs	= [];
    var arrKOLsAssignedToClient	= [];
//    console.log(clientKOLs);
    arrClientKOLs	= clientKOLs.split(',');
    for(var i=0;i<arrClientKOLs.length;i++){
    	arrKOLsAssignedToClient.push(arrClientKOLs[i]);
    }
  //  console.log(arrKOLsAssignedToClient);
    if (endYear >= arrAllChildrens.length)
        endYear = arrAllChildrens.length;
    for (i = startYear; i < endYear; i++){
        var a = arrKOLsAssignedToClient.indexOf(arrAllChildrens[i].id.toString());
        if(a==undefined || a==-1){
         }else{
	        arrOfIds.push(arrAllChildrens[i].id);
	        arrChildrens.push(arrAllChildrens[i]);
    	}
    }
  //  console.log(arrAllChildrens);
    for (var i = 0; i < arrChildrens.length; i++) {
        var children = arrChildrens[i];
        var shubChildrens = [];
        $.each(children.children, function (key, object) {
	            if (in_array(arrOfIds, object.id)){
                shubChildrens.push(object);
	            }
        });
        arrChildrens[i].children = shubChildrens;
    }
  //  console.log(arrChildrens);
    parentNode = {
        id: currentJson.id,
        name: currentJson.name,
        data: {
            $lineWidth: '0.1',
            $color: '#fff',
            $dim: 0
        },
        children:arrChildrens
    };
    coAuthorsGraph(parentNode,'view1Infovis','#FFFFFF');
}
function coAuthorsGraph(json, divId, circleColor, authsWithAff) {
    //init RGraph
    rgraph = new $jit.RGraph({
        //Where to append the visualization
        injectInto: divId,
        //Optional: create a background canvas that plots
        //concentric circles.
        background: {
            CanvasStyles: {
                strokeStyle: circleColor
            }
        },
        //Add navigation capabilities:
        //zooming by scrolling and panning.
        Navigation: {
            enable: true,
            panning: true,
            zooming: 10
        },
        //Set Node and Edge styles.
        Node: {
            overridable: true,
            color: '#ddeeff',
            dim: 0
        },
        Edge: {
            overridable: true,
            color: '#06f',
            lineWidth: 0.5
        },
        //Edge length
        levelDistance: 130,
        onBeforeCompute: function (node) {
            //Log.write("centering " + node.name + "...");
            //Add the relation list in the right column.
            //This list is taken from the data property of each JSON node.
            //$jit.id('inner-details').innerHTML = node.data.relation;
        },
        onAfterCompute: function () {
            //Log.write("done");
        },
        //Add the name of the node in the correponding label
        //and a click handler to move the graph.
        //This method is called once, on label creation.
        onCreateLabel: function (domElement, node) {
            var nameContainer = document.createElement('span'),
                    closeButton = document.createElement('span'),
                    style = nameContainer.style;
            nameContainer.className = 'name';

            var nodeId = node.id;
            if (isNaN(nodeId))
                nodeId = nodeId.split("-")[1];
            var kolNameWithLink = "<a href='" + base_url + "kols/kols/view/" + nodeId + "' target='_new'>" + node.name + "</a>";
            nameContainer.innerHTML = kolNameWithLink;
            closeButton.className = 'microIcon';

            //closeButton.innerHTML="";
            domElement.appendChild(nameContainer);
            domElement.appendChild(closeButton);
            style.fontSize = "12px";
            style.color = "#ddd";
        },
        //Change some label dom properties.
        //This method is called each time a label is plotted.
        onPlaceLabel: function (domElement, node) {
            var style = domElement.style;
            style.display = '';
            style.cursor = 'pointer';

            if (node._depth <= 1) {
                style.fontSize = "12px";
                style.color = "#000";

            } else if (node._depth == 2) {
                style.fontSize = "12px";
                style.color = "#000";

            } else {
                style.display = 'none';
            }

            var left = parseInt(style.left);
            var w = domElement.offsetWidth;
            style.left = (left - w / 2) + 'px';
        },
        onBeforePlotLine: function (adj) {
            //alert(adj.nodeFrom.data.toSource());
            if (adj.nodeFrom.data.nocn == 0) {
                adj.data.$lineWidth = adj.nodeFrom.data.nocn;
                adj.data.$color = '#fff';
            }

        }
    });
    //load JSON data
    rgraph.loadJSON(json);
    //trigger small animation
    rgraph.graph.eachNode(function (n) {
        var pos = n.getPos();
        pos.setc(-200, -200);
    });
    rgraph.compute('end');
    rgraph.fx.animate({
        modes: ['polar'],
        duration: 2000
    });
//     end
//     append information about the root relations in the right column
//     $jit.id('inner-details').innerHTML = rgraph.graph.getNode(rgraph.root).data.relation;
}
function draw_pie_chart(returnData,bindToId) {    
    var chart = c3.generate({
    	bindto: '#'+bindToId,
	    data: {
	        columns: returnData,
	        type : 'pie'	       
	    },	    
	    size: {
	    	  width:300
	    },
	    color: {
	    	  pattern: chartColors
    	},
	    legend: {
      	  position: 'right'
	    },
	    pie: {
	        label: {
	            format: function (value, ratio, id) {
	                return d3.format('.0%')(ratio);
	            }
	        }
	    },
	    tooltip: {
	        format: {	            
	            value: function (value, ratio, id) {           
	            	return value+' ('+d3.format('.0%')(ratio)+')';
	            }	            
	        }
	    },
	    legend: {
	        show: false
	    }
	});
    var data=new Array();
	$.each(returnData, function(i, item) {
	   data.push(item[0]);
	});
    d3.select('#'+bindToId).insert('div', '.chart').attr('class', 'legend').selectAll('h5')
    .data(data)
    .enter().append('h5')
    .attr('data-id', function (id) { return id; })
    .html(function (id) { return id; })
    .each(function (id) {
        d3.select(this).style('background-color', chart.color(id));
    })
    .on('mouseover', function (id) {
        chart.focus(id);
    })
    .on('mouseout', function (id) {
        chart.revert();
    })
    .on('click', function (id) {
        chart.toggle(id);
    });
}
</script>
<?php $Kol_unique_id= $this->uri->segment(4);?>
<div class="row row_padding">
<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/calculate_dashboard_data/'.$arrKol['kols_client_visibility_id'];?>" target="_NEW">
	Recalculate dashboard data
</a	>
</div>
<div class="pubChartContainer">
<?php if($this->common_helper->check_module("interactions")){?>
		<div class="row" id="interationCharts">
			<div class="col-sm-6">
				<div class="panel panel-default">
				  <div class="panel-heading">
				  	<h3 class="panel-title">
				  	Interactions By Topic
				  		<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/view_interactions/'.$Kol_unique_id;?>" target="_NEW">
							Interactions
						</a	>
					</h3>
				  </div>
				  <div class="panel-body">
					<div id="interactionsByTopic"></div>
				  </div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default">
					  <div class="panel-heading">
						<h3 class="panel-title">
							Interactions By Type
							<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/view_interactions/'.$Kol_unique_id;?>" target="_NEW">
								Interactions
							</a>
						</h3>
					  </div>
					  <div class="panel-body">
						<div id="interactionByChannel"></div>
					  </div>
				</div>
			</div>
		</div>
		<?php } ?>
<!-- 		<div class="row"> -->
		<?php if($this->common_helper->check_module("profile_ratings")){?>
			<div class="col-sm-6">
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h3 class="panel-title">
						KTL Rating
						<a type="button" class="btn custom-btn" style="float:right;" href="#" target="_NEW">
							Profile Score Report
						</a>
					</h3>
				  </div>
				  <div class="panel-body">
					<div id="kolProfileScoreChart">
						<div id="inner">
							&nbsp;
						</div>
					</div>
				  </div>
				</div>
			</div>
			<?php }?>
			<div class="col-sm-6">
				<div class="panel panel-default">
					  <div class="panel-heading">
						<h3 class="panel-title">
							KTL Network Map
							<a type="button" class="btn custom-btn" style="float:right;" href="#" target="_NEW">
								Network Map
							</a>
						</h3>
					  </div>
					  <div class="panel-body">
						<div id="view1Infovis"></div>
					  </div>
				</div>
			</div>
<!-- 		</div> -->
<!-- 		<div class="row"> -->
			<div class="col-sm-6">
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h3 class="panel-title">
						Affiliations By Organization Type
						<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/view_affiliations/'.$Kol_unique_id.'/all';?>" target="_NEW">
							Affiliations
						</a>
					</h3>
				  </div>
				  <div class="panel-body">
					<div id="affiliationsChartByOrgType"></div>
				  </div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default">
					  <div class="panel-heading">
						<h3 class="panel-title">
							Affiliations By Engagement Type
							<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/view_affiliations/'.$Kol_unique_id.'/all';?>" target="_NEW">
								Affiliations
							</a>
						</h3>
					  </div>
					  <div class="panel-body">
						<div id="affiliationsChartByEngType"></div>
					  </div>
				</div>
			</div>
<!-- 		</div> -->
		<?php if($this->common_helper->check_module("events")){ ?>
<!-- 		<div class="row"> -->
			<div class="col-sm-6">
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h3 class="panel-title">
						Events By Year
						<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'events/events/view_events/'.$Kol_unique_id.'/conference';?>" target="_NEW">
							Events
						</a>
					</h3>
				  </div>
				  <div class="panel-body">
					<div id="eventsByTimeline"></div>
				  </div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default">
					  <div class="panel-heading">
						<h3 class="panel-title">
							Events By Topic
							<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'events/events/view_events/'.$Kol_unique_id.'/conference';?>" target="_NEW">
								Events
							</a>
						</h3>
					  </div>
					  <div class="panel-body">
						<div id="eventsChartByTopic"></div>
					  </div>
				</div>
			</div>
<!-- 		</div> -->
		<?php } ?>
		<?php if($this->common_helper->check_module("pubmeds")){ ?>
<!-- 		<div class="row"> -->
			<div class="col-sm-6">
				<div class="panel panel-default">
				  <div class="panel-heading">
						<h3 class="panel-title">
							Publications by Year
							<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'pubmeds/pubmeds/view_publications/'.$Kol_unique_id.'/search';?>" target="_NEW">Publications</a>
						</h3>
				  </div>
				  <div class="panel-body">
					<div id="pubsChartByYear"></div>
				  </div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default">
					  <div class="panel-heading">
						<h3 class="panel-title">
							Publications by Authorship Position
							<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'pubmeds/pubmeds/view_publications/'.$Kol_unique_id.'/search';?>" target="_NEW">Publications</a>
						</h3>
					  </div>
					  <div class="panel-body">
						<div id="pubAuthPosChart"></div>
					  </div>
				</div>
			</div>
<!-- 		</div> -->
		<?php } ?>
</div>