<?php
/**
 *
 * @author Laxman K
 * @since
 * @created on
 *
 */
?>
<style>
	.sectionHeading{
		font-weight: bold;
		color: #3366CC;
	}
</style>
Hi <?php echo $data['first_name'].' '.$data['last_name'];?>!<br /><br /><br />
<p><strong>Welcome To Aissel KOLM!!! You are all set with your new FREE KOLM account.</strong></p>
<p>KOLM is an easy-to-use application designed around helping you to know your customers well. You can access the detailed profiles, get comparative scoring of your KOLs, view network maps and track your KOL communications online. We hope you enjoying your new account. We would love to hear your feedback, please drop us an email.</p>
<p>Below are the details to access the online application. Please remember to bookmark the link for easy access in the future.</p>
<p>Username: <?php echo $data['email'];?></p>
<p>Link to access the application: <a href="<?php echo base_url();?>"><?php echo base_url();?></a></p> 
<p>If you need further assistance to get started or you have any queries, please feel to write to us at: support@aissel.com</p>

<div>
	Thanks,<br />
	Aissel Support Team
</div>

	
