<?php
/*
 *  View page to Add Users
 * 	@autor Vinayak Malladad
 * 	@since 1.5
 * 
 * 
 */
?>
	<style type="text/css">
	
	.userTable{
	  <?php if($userRoleId == ROLE_ADMIN){?>
		margin-left:240px;
	  <?php } else { ?>
                margin-left:40px;
          <?php } ?>
	}
        .formButtons{
              <?php if($userRoleId == ROLE_ADMIN){?>
                text-align: left;
              <?php } ?>
        }
	.userTable .labelForfields{
		float:left;
		font-size:16px;
		margin-right:38px;
		text-align:right;
		width:100px;
		font-family:lucida Grande;
                <?php if (!IS_IPAD_REQUEST) { ?>
                    margin-top:-2px;
                <?php } else { ?>
                     margin-top:5px;
                <?php } ?>
	}
	  
                
	.userTable input[type="text"],input[type="password"]{
		margin-left:-29px;
		margin-top:0;
		<?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
	
	}
	
	.userTable select{
		margin-left:-29px;
		margin-top:0;
                <?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
		
	}
	.userTable input[type="button"]{
              <?php if($userRoleId != ROLE_ADMIN){?>
		margin-right:48px;
                
              <?php } else { ?>
                margin-left: 58px;
              <?php } ?>
                width:70px;
		text-align:center;
		
	}
	 span.require {
    color: #F00;
}
	
	.userTable label.error {
		background:none repeat scroll 0 0 transparent;
		border:0 none;
		color:red;
		font-weight:normal;
		margin:0;
		padding:0;
		text-align:center;
	}
	select.error{
		padding:0px;
	}
        <?php if (IS_IPAD_REQUEST) { ?>
        .ipadCSS{
            
    /* display: block; */
    width: 100%;
    height: 30px;
    padding:0px !important; 
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;

        }
        <?php } ?>
	</style>
	<script>
	var validationRules	=  {
			City: {
				required:true
			},
			CountryID: {
				required:true
			},
			state_id: {
				required:true
			}
		};
		var validationMessages = {
		City: {
			required: "xax"
		},
		CountryID: {
			required: "xax"
		},
		state_id: {
			required: "xax"
		}
		};
		function closeDialog(){
			$("#userContainer").dialog("close");
		}
	</script>
<!-- <h1>Add New User</h1> -->
	<div class="clientUserMsgBox"></div>
<form action="#"   method="post" name="saveCityform" id="saveCityform"  class="validateForm" style="width:450px">
<input type="hidden" name="CityId" id="CityId" value="<?php if(isset($Citydetails->CityId)){ echo $Citydetails->CityId; }?>"></input>
		<table class="anaylystForm clientTbl userTable">
		    <tr>
				<td>
					<div class="labelForfields">Country:<span class="require">*</span></div>
					<select  name="CountryID" id="CountryID"  class="required ipadCSS" onchange="getStatesByCountryId();">
						<option value="">-- Select Country--</option>
						<?php
						$selected = '';
						foreach( $arrCountry as $country ){
							$selected = '';
							if($Citydetails->CountryID===$country['country_id']){
								$selected	= ' selected="selected"';
							}
						?>
						<option value="<?php echo $country['country_id'];?>"  <?php echo $selected;?>>
								<?php echo $country['country_name'];?>
							</option>
						<?php }?>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">State:<span class="require">*</span></div>
						<select name="state_id" id="state_id"  class="required ipadCSS">
						<option value="">-- Select State --</option>
						<?php
						$selected = '';
						foreach ($arrStates as $state) {
							$selected = '';
							if($Citydetails->RegionID===$state['state_id']){
								$selected = 'selected="selected"';
							}
							?>
							<option value="<?php echo $state['state_id']; ?>" <?php echo $selected;?>>
							<?php echo $state['state_name']; ?>
							</option>
							<?php } ?>
						</select>
						<img id="loadingStates" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">City Name<span class="require">*</span></div>
                    :<input type='text' name="City" id="City" class="required ipadCSS" placeholder='City name'  value="<?php if(isset($Citydetails->City)){ echo $Citydetails->City; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Latitude</div>
                    :<input type='text' name="Latitude" placeholder='Latitude' value="<?php if(isset($Citydetails->Latitude)){ echo $Citydetails->Latitude; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Longitude</div>
                    :<input type='text' name="Longitude" placeholder='Longitude' value="<?php if(isset($Citydetails->Longitude)){ echo $Citydetails->Longitude; }?>"/>
				</td>
			</tr>	
			<tr>
				<td>
					<div class="labelForfields">Time Zone</div>
                    :<input type='text' name="TimeZone" placeholder='Time Zone' value="<?php if(isset($Citydetails->TimeZone)){ echo $Citydetails->TimeZone; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Code</div>
                    :<input type='text' name="Code" placeholder='Code' value="<?php if(isset($Citydetails->Code)){ echo $Citydetails->Code; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="">
                     <input type="button" value="Save" name="submit" onclick="saveCityDetails();" ></input>
                     <input type="button" value="Cancel" onclick=closeDialog()></input>
                     </div>
				</td>
			</tr>
	</table>
<!-- End of Table -->
</form>