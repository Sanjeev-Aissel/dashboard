<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	'jquery.validate',
								'jquery.autocomplete',
								'search/kol_results'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!--  Autocomplete Plugin -->
<!--	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
-->
<!-- 2nd Plugin for Validation -->
<!--	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
-->

<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	/*
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	*/
	.displayModelBox{
		float:left;
		text-align:right;
		background-color:#000099;
		-moz-border-radius-bottomleft:5px;
		-moz-border-radius-bottomright:5px;
		-moz-border-radius-topleft:5px;
		-moz-border-radius-topright:5px;
		cursor: pointer;
		color: white;
		font-weight: bold;
		font-size:11px;
	}
	.record_name{
		font-weight:bold;
		letter-spacing:1.5px
	}
	
	#kolsByCountryChart,#kolsBySpecialtyChart{
		padding: 0px;
		margin: 0px;
	}
	
	#searchResultsContainer {
		margin-left:7px;
		margin-right:10px;
		margin-top: 0px;
	}
	
	#searchResultsContainer table,table.listResultSet{
		border-left:1px solid #ccc;
		border-top:1px solid #ccc;
		border-left:1px solid #eee;
		border-top:1px solid #eee;
		border-bottom:1px solid #EEEEEE;	
		width:100%;
		border: 0px;
	}
	
	#searchResultsContainer table tbody tr.ui-widget-content{
		border:1px solid #ccc;
		border:1px solid #eee;
		border: 0px;
	}
	
	#searchResultsContainer table th,table.listResultSet th{
		text-align:center;	
		background: #22A1ED;
		color:#FFFFFF;
		background: none;
		color:#777;
		border: 0px;
	}
	
	#searchResultsContainer table td, #searchResultsContainer table th,table.listResultSet th,table.listResultSet td{
		font-size:12px;
		color:#626262;
		padding:6px 2px 6px 3px;
		vertical-align:top;
		white-space:normal;
		border-right:1px solid #ccc;
		border-bottom:1px solid #ccc;
		border-right:1px solid #eee;
		border-bottom:0px solid #eee;
		border: 0px;
		border-bottom: 1px solid #dddddd;
	}
	#kolsByCountryChartContainer,#kolsBySpecialtyChartContainer{
		margin-bottom:10px;	
	}

	.span-4{
		width:172px;
	}
	#searchLeftBar{
		float:left;
	}
	#kolsBySpecialtyChartContainer {
		margin-top:0px;
	}
	.expandRightSideBar{
		display: block !important;
	}
</style>

<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/refinedByFilter.css" />


<script type="text/javascript">

/*
	var kolsByCountryChart; // global
  	var kolsBySpecialtyChart;

	function doSearchFilter(startIndex){
		//close the microview if it is opened
		closeKolProfile();
		
		//show loading image
		//$('.loadingIndicator').show();
		$('#searchResultsContainer').block({ message: '.',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
			}
		});
	}

	//uncheck all the checkbox and reload the filtered results
	function resetFilters(){
		if($("#searchType").val()=='advanced'){
			$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
				$(this).removeAttr('checked');
			});
			$.each($("#categoriesContainer input[type='text']"), function() {
				$(this).val('');
			});
			$('#keywords').val('');
			$('#firstName').val('');
			$('#middleName').val('');
			$('#lastName').val('');
			$('#subSpecialty').val('');
			$('#title').val('');
			$('#postalCode').val('');
			doSearchFilter1(-1);
		}else{
			$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
				$(this).removeAttr('checked');
			});
			$.each($("#categoriesContainer input[type='text']"), function() {
				$(this).val('');
			});

			$('#keyword').val('');
			doSearchFilter1(-1);
		}
	}

	function doSearchFilter1(startIndex,thisEle){
		//close the microview if it is opened
		closeKolProfile();
		
		var expandedCategories = new Array();
		$('.expanded').each(function(){
			var parentId=$(this).parent().attr('id');
			expandedCategories.push(parentId);
		});
		var collapsedCategories = new Array();
		$('.collapsed').each(function(){
			var parentId=$(this).parent().attr('id');
			collapsedCategories.push(parentId);
		});
		//show loading image
		//$('.loadingIndicator').show();

		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		//If 'All' is selected uncheck other checkbox of that category, 
		//Else uncheck the checkbox representing 'All', do the same for all categories
		if(thisEle!=null){
			if($(thisEle).val()=='country'){
				$('.countryElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='countryElement')
					$('#allCountries').removeAttr('checked');
			}
	
			if($(thisEle).val()=='specialty'){
				$('.specialtyElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='specialtyElement')
					$('#allSpecialties').removeAttr('checked');
			}
	
			if($(thisEle).val()=='organization'){
				$('.orgElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='orgElement')
					$('#allOrgs').removeAttr('checked');
			}
	
			if($(thisEle).val()=='education'){
				$('.eduElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='eduElement')
					$('#allEdus').removeAttr('checked');
			}
	
			if($(thisEle).val()=='event'){
				$('.eventElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='eventElement')
					$('#allEvents').removeAttr('checked');
			}
	
			if($(thisEle).val()=='list'){
				$('.listElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='listElement')
					$('#allLists').removeAttr('checked');
			}
		}
		//End of toggling 'All' and 'Others'
		
		//Get Selected check box value for each Category separatly
		var countryValues = new Array();
		$.each($("input[name='country_ids[]']:checked"), function() {
			countryValues.push($(this).val());
		});
		var specialtyValues = new Array();
		$.each($("input[name='specialty_ids[]']:checked"), function() {
			specialtyValues.push($(this).val());
		});
		var orgValues = new Array();
		$.each($("input[name='org_ids[]']:checked"), function() {
			orgValues.push($(this).val());
		});
		var eduValues = new Array();
		$.each($("input[name='edu_ids[]']:checked"), function() {
			eduValues.push($(this).val());
		});
		var eventValues = new Array();
		$.each($("input[name='event_ids[]']:checked"), function() {
			eventValues.push($(this).val());
		});
		var listValues = new Array();
		$.each($("input[name='list_ids[]']:checked"), function() {
			listValues.push($(this).val());
		});

		var kolValues = new Array();
		$.each($("input[name='kol_name[]']:checked"), function() {
			kolValues.push($(this).val());
		});

		//End of Selecting Checkbox value for each Category separatly
		
		//Make all check boxes disabled while Loading
		$("#searchFiltersElements input[type='checkbox']").each(function(){
			$(this).attr({'disabled': true});
		});
		
		if($('#country').val()=='Enter Country'){
			$('#country').val('');
		}

		if($('#specialty').val()=='Enter Specialty'){
			$('#specialty').val('');
		}

		if($('#listName').val()=='Enter List'){
			$('#listName').val('');
		}

		if($('#education').val()=='Enter Education'){
			$('#education').val('');
		}

		if($('#eventName').val()=='Enter Event'){
			$('#eventName').val('');
		}

		if($('#organization').val()=='Enter Organization'){
			$('#organization').val('');
		}

		if($('#kolName').val()=='Enter KOL Name'){
			$('#kolName').val('');
		}


		
		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		data=data+"&countries="+countryValues;
		data=data+"&specialties="+specialtyValues;
		data=data+"&organizations="+orgValues;
		data=data+"&educations="+eduValues;
		data=data+"&events="+eventValues;
		data=data+"&lists="+listValues;
		data=data+"&kols="+kolValues;
		//Send Request to reload the filtered search results
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
			}
		});
		//Send Request to reload the filtered 'Filter CheckBox's'
		var reloadUrl='reload_filters';
		if($("#searchType").val()=='advanced')
			reloadUrl='reload_adv_filters';
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: '<?php echo base_url();?>kols/'+reloadUrl,
			success: function(returnData){
				$("#searchFiltersContainer").html(returnData);
			},
			complete: function(){
				 var keyword=$('#keywords').val();
			       if(keyword!='')
			    	   $('#categotyKols').hide();
		    	   
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
				//Expanding and collapseing the categoties
				$.each(expandedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('collapsed');
					$('#'+value+' label.facet-toggle').addClass('expanded');
					$('#searchLeftBar #'+value+' ul').show(); 
				});	
				$.each(collapsedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('expanded');
					$('#'+value+' label.facet-toggle').addClass('collapsed');
					$('#searchLeftBar #'+value+' ul').hide(); 
				});
			}
		});
	}


	checked=false;
	function checkedAll (list) {
		
		var aa= document.getElementById('list');
		//jAlert(aa.toSource.value());
		 if (checked == false)
	          {
	           checked = true;
	          }
	        else
	          {
	          checked = false;
	          }
			for (var i =0; i < aa.elements.length; i++) 
		{
	
			 aa.elements[i].checked = checked;
		}
	
	  }
	
	function displayModelBox(){
		$("#categoryModalBox .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#categoryModalBox").dialog("open");
		var values = new Array();
		$.each($("input[name='list[]']:checked"), function() {
		  values.push($(this).val());
		 
		});
		$(".addListContent").load('<?php echo base_url()?>my_list_kols/add_list/'+values);
		return false;	
	}
	
	$(document).ready(function(){
		var categoryAddOpts = {
				title: "Add Payment",
				modal: true,
				autoOpen: false,
				width: 500,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};

		// Settings for the Dialog Box
		var kolMicroProfileDialogOpts = {
				title: "Profile Snapshot",
				modal: true,
				autoOpen: false,
				width:310,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};

		
		$("#categoryModalBox").dialog(categoryAddOpts);

		$("#kolMicroProfile").dialog(kolMicroProfileDialogOpts);

	});

	//
	// Opens the Modal Box with the Micro Profile content of KOL
	// @param: kolId
	//
	function viewKolMicroProfile_old(kolId, e){
		$( "#kolMicroProfile" ).dialog({ position: [775,e.clientY-130] });
		$("#kolMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#kolMicroProfile").dialog("open");
		$(".profileContent").load('<?php echo base_url().'kols/view_kol_micro/'?>'+kolId,{},
				function(){
					//$( "#kolMicroProfile" ).dialog({ width: 'auto' });
					//if(scrollHeight>100)
						//window.scrollTo(0,e.clientY-100);
			});
		
		return false;
	}

	//
	// Opens the Modal Box with the Micro Profile content of KOL
	// @param: kolId
	//
	function viewKolMicroProfile(kolId, e){
		var elmt=document.getElementById("kol"+kolId);	
		var pos = getElementAbsolutePos(elmt);
		var xPos=pos.x+410;
		var yPos=pos.y-35;
		//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
		//$("#callOutTest").show();
		$("#arraouHolder").css({'position': 'absolute','top':yPos,'left':xPos+45});
		$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+56});
		$("#arraouHolder").show();
		$("#contentHolder").show();

		$(".profileContent").html("");
		//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
		$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		
		$(".profileContent").load('<?php echo base_url().'kols/view_kol_micro/'?>'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
		
		return false;
	}

	function closeKolProfile(){
		$("#arraouHolder").hide();
		$(".profileContent").html("");
		$("#contentHolder").hide();
	}

	
	//Function to select all page results, 
	var allPageSelected=false;
	var allPageKolIds=[];
	function selectAllPageResults(startIndex,thisEle){
		//Check all the first page results
		var chekAllPageEle= document.getElementById('checkAllPage');
				
		var aa= document.getElementById('list');
		if(chekAllPageEle.checked==true)
			allPageSelected=true;
		else
			allPageSelected=false;
		
		 if (allPageSelected == true)
	          {
	           checked = true;
	          }
	     else
	          {
	          checked = false;
	          }
		 for (var i =0; i < aa.elements.length; i++) {	
			 aa.elements[i].checked = checked;
		 }
		
		//Get Selected check box value for each Category separatly
		var countryValues = new Array();
		$.each($("input[name='country_ids[]']:checked"), function() {
			countryValues.push($(this).val());
		});
		var specialtyValues = new Array();
		$.each($("input[name='specialty_ids[]']:checked"), function() {
			specialtyValues.push($(this).val());
		});
		var orgValues = new Array();
		$.each($("input[name='org_ids[]']:checked"), function() {
			orgValues.push($(this).val());
		});
		var eduValues = new Array();
		$.each($("input[name='edu_ids[]']:checked"), function() {
			eduValues.push($(this).val());
		});
		var eventValues = new Array();
		$.each($("input[name='event_ids[]']:checked"), function() {
			eventValues.push($(this).val());
		});
		var listValues = new Array();
		$.each($("input[name='list_ids[]']:checked"), function() {
			listValues.push($(this).val());
		});

		var kolValues = new Array();
		$.each($("input[name='kol_name[]']:checked"), function() {
			kolValues.push($(this).val());
		});


		//End of Selecting Checkbox value for each Category separatly
		
				
		if($('#country').val()=='Enter Country'){
			$('#country').val('');
		}

		if($('#specialty').val()=='Enter Specialty'){
			$('#specialty').val('');
		}

		if($('#listName').val()=='Enter List'){
			$('#listName').val('');
		}

		if($('#education').val()=='Enter Education'){
			$('#education').val('');
		}

		if($('#eventName').val()=='Enter Event'){
			$('#eventName').val('');
		}

		if($('#organization').val()=='Enter Organization'){
			$('#organization').val('');
		}

		if($('#kolName').val()=='Enter KOL Name'){
			$('#kolName').val('');
		}


		var kolsCount=$("#kolsCount").val();
		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		data=data+"&countries="+countryValues;
		data=data+"&specialties="+specialtyValues;
		data=data+"&organizations="+orgValues;
		data=data+"&educations="+eduValues;
		data=data+"&events="+eventValues;
		data=data+"&lists="+listValues;
		data=data+"&kols="+kolValues;
		data=data+"&kols_count="+kolsCount;
		//Send Request to reload the filtered search results
		if(allPageSelected==true){
			$.ajax({
				type: "post",
				dataType:"json",
				data: data,
				url: formAction,
				success: function(returnData){
					 allPageKolIds=returnData;
				},
				complete: function(){
					$('#country').val('Enter Country');
					$('#specialty').val('Enter Specialty');
					$('#listName').val('Enter List');
					$('#education').val('Enter Education');
					$('#eventName').val('Enter Event');
					$('#organization').val('Enter Organization');
					$('#kolName').val('Enter KOL Name');
				}
			});
		}else{
			allPageKolIds=[];
		}
	}
*/

// added by vivek for saved queries
var viewType	= 'tabular';
$(document).ready(function(){
	var addKolsCustomFilters={
		title: "Add Custom Filters",
		modal: true,
		autoOpen: false,
		width: 400,
		height: 400,
		dialogClass: "microView",
		draggable:false,
		open: function(){

		}
	};
	$( "#addKolsCustomFilters" ).dialog(addKolsCustomFilters);
});
function addFilters(){
	$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#addKolsCustomFilters').dialog("open");
	$('#addKolsCustomFiltersContainer').load(base_url+'kols/add_kol_saved_filters/');
}

function getSavedFilters(){
	$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#addKolsCustomFilters').dialog("open");
	$('#addKolsCustomFiltersContainer').load(base_url+'kols/get_saved_filters/');
}
</script>
<div id="searchContainer">
	<div id="searchTopMenus"></div>
	<div class="myKolLists1">
		<!--<div id="searchLeftBar" class="span-5" style="float:left;">
			<h3>Refine By</h3>
			<div id="searchFiltersContainer">
					<?php //echo $this->load->view($filterPage,$filterData);?>
			</div>
		</div>
		-->
		<div id="searchResultsContainer" class="maxWidth"  style="float:left;">
			<?php echo $this->load->view($kolResultsPage,$kolResultsData);?>
		</div>
<!-- 	<div id="refinedByWrapper" class="rightRefinedByFilter">
			<div id="refinedByContainer">
				<div id="rightSideBarSlider" class="expandRightSideBar tooltip-demo tooltop-left"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
				<div id="searchLeftBar" style="display: none;">
					<h3>
						<div class="funnelIcon sprite_iconSet"></div>Refine By
						<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
					</h3>
					<div id="searchFiltersContainer">
						<?php //echo $this->load->view($filterPage,$filterData);?>
					</div>
				</div>
			</div>
		</div>	
	-->	
	</div>
	<div class="clear">&nbsp;</div>

	<!-- Container for the 'Kol Micro Profile' modal box -->
	<div id="dailog1" style="display:none;">	
		<div id="kolMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!-- End of the Container for the 'Kol Micro Profile' modal box -->
	
	<div id="categoryModalBox">
		<div class="addListContent profileContent"></div>
	</div>
	
	<!-- Container for the 'Kol Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();"/>
		--></div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><img id="arrowImg" src="<?php echo base_url();?>images/arrowmark.png" width="15" height="30"/></div>
</div>
<div id="addKolsCustomFilters1"></div>
<div id="addKolsCustomFilters" class="addCustomFilters">
	<div id="addKolsCustomFiltersContainer" class="profileContent"></div>
</div>