CREATE TABLE IF NOT EXISTS `list_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `is_public` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_uk` (`category`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `list_kols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_name_id` int(11) DEFAULT NULL,
  `kol_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_name_id_uk` (`list_name_id`,`kol_id`),
  KEY `fk_kol_id` (`kol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `list_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_name_uk` (`list_name`,`category_id`,`user_id`),
  KEY `fk_category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

ALTER TABLE `list_kols`
  ADD CONSTRAINT `fk_list_name_id` FOREIGN KEY (`list_name_id`) REFERENCES `list_names` (`id`) ON DELETE CASCADE;
ALTER TABLE `list_names`
  ADD CONSTRAINT `fk_category_id` FOREIGN KEY (`category_id`) REFERENCES `list_categories` (`id`) ON DELETE CASCADE;
