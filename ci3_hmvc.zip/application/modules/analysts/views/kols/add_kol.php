<?php
/**
*Description:
*
*Created by:Developer
*
*Created on:Dec 13, 2010
*/?>
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />

		<style type="text/css">
			#contents{
				text-align:left;
				font-size:110%;
				padding-left:150px;
			}
			
			#contents label{
				float:left;
				width:150px;
				text-align:right;
				padding-right:6px;
				padding-top:2px;
			}
			
			h1{
				color:#2E6E9E;
				font-size:170%;
				margin-bottom:10px;
				margin-top:15px;
			}
			.well{
    			padding: 5px 15px;
			}
		</style>
<div class="container" style="margin-top:20px;">
	<div class="col-md-8 col-md-offset-2">
		<div class="panel panel-default"> 
			 <div class="panel-heading"> <h3 class="panel-title">Add New KOL for Processing</h3> </div> 
			 <div id="editKolForm" class="panel-body">
			 	<div class="well">Note: This is a temporary interface for the Demo. Later this will be replaced by the Import Job</div>
			     <form action="save_kol" method="post" id="persnoalForm" name="persnoalForm" class="validateForm form-horizontal">      
			            <div class="form-group">
							<div class="col-md-4">
								<label class="control-label">Profile Type <span class="required">*</span> :</label>
								<select name="profile_type" id="profile_type" class="form-control required">
									<option value="Basic">Basic</option>
									<option value="Basic Plus">Basic Plus</option>
									<option value="Full Profile" checked>Full Profile</option>
				    			</select>
				    			<a href="http://support.aisselkolm.com/solution/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile-" target="_NEW">Compare</a>
							</div>
						</div>
		                <div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Salutation :</label>
								<select name="type_id" id="orgType" class="form-control required">
								<option value="0">--- Select ---</option>
											<?php 
												foreach($arrSalutations as $key => $value){
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
							    		</select>
						    	</select>
							</div>
							
							<div class="col-md-6">
								<label class="control-label">Gender  :</label>
								<select name="gender" id="gender" class="form-control required">
								     		<option value="Male">Male</option>
								     		<option value="Female">Female</option>
								    	</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">First Name :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
							<div class="col-md-6">
								<label class="control-label">Middle Name :</label>
								<input type="text"  name="website" id="orgWebsite" class="url form-control gray">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Last Name :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
							<div class="col-md-6">
								<label class="control-label">Suffix :</label>
								<input type="text"  name="website" id="orgWebsite" class="url form-control gray">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Specialty :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Organization Name :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
								<div class="col-md-6">
								<label class="control-label">NPI Num :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
						</div>
						<div style="text-align: center;">
							<button type="button" name="submit" id="saveAbout" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-save"></span> Save</button>
						</div>
			        </form>
			  </div> 
		</div>
	</div>
</div>
					<!-- End of Personal and Professional Information -->		