<?php
$lang['Home'] = "Home";
$lang['MyKols'] = "Contacts";
$lang['Organizations'] = "Organizations";
$lang['Track'] = "Track";
$lang['MyLists'] = "My Lists";
$lang['NetworkMaps'] = "Network Maps";
$lang['Reports'] = "Reports";
$lang['Calendar'] = "Calendar";
$lang['More'] = "More";
$lang['Surveys'] = "Surveys";
$lang['ProfileRequest'] = "Profile Request";
$lang['OrgProfileRequest'] = "Org Profile Request";
$lang['RecentActivity'] = "Recent Activity";
$lang['IdReport'] = "Identify";
$lang['Notifications'] = "Notifications";

// Secondary Navigations of My KOLS
$lang['Mykols.Overview'] = "Overview";
$lang['Mykols.Affiliations'] = "Affiliations";
$lang['Mykols.Events'] = "Events";
$lang['Mykols.Publications'] = "Publications";
$lang['Mykols.Clinicaltrials'] = "Clinical Trials";
$lang['Mykols.Media'] = "Media";
$lang['Mykols.SocialMedia'] = "Social Media";
$lang['Mykols.Locations'] = "Locations";
$lang['Mykols.Notes'] = "Notes";

// Turnary Navigations of My KOLS

$lang['all'] = "All";
$lang['Mykols.Biography'] = "Profile Summary";
$lang['Mykols.Dashboard'] = "Dashboard";
$lang['Mykols.PersonalInfo'] = "Personal Info";
$lang['Mykols.Assessment'] = "Assessment";
$lang['Mykols.Details'] = "Details";
$lang['Mykols.Interactions'] = "Interactions";
$lang['Mykols.Payments'] = "Payments";
$lang['Mykols.Contracts'] = "Contracts";
$lang['Mykols.Reports'] = "Reports";
$lang['Mykols.UnivHospital'] = "Univ / Hospital";
$lang['Mykols.Associations'] = "Associations";
$lang['Mykols.Industry'] = "Industry";
$lang['Mykols.GovtAgency'] = "Govt. Agency";
$lang['Mykols.Others'] = "Others";
$lang['Mykols.ReportsOrg'] = "Reports Org";
$lang['Mykols.ReportsEng'] = "Reports Eng";
$lang['Mykols.SessionType'] = "Session Type";
$lang['Mykols.Topics'] = "Topics";
$lang['Mykols.Role'] = "Role";
$lang['Mykols.PubsSearch'] = "Pubs Search";
$lang['Mykols.PubsbyTime'] = "Pubs by Time";
$lang['Mykols.Coauthors'] = "Co-authors";
$lang['Mykols.AuthPosition'] = "Auth Position";
$lang['Mykols.Keywords'] = "Overview";
$lang['Mykols.Substances'] = "Substances";
$lang['Mykols.Journals'] = "Journals";
$lang['Mykols.Lists'] = "Lists";
$lang['Mykols.NPINUMBER'] = "NPI NUMBER";
$lang['Mykols.SelectAll'] = "Select All";
$lang['Mykols.KOLRating'] = "KTL Rating";
$lang['Mykols.KOLNetworkMap'] = "KTL Network Map";
$lang['Mykols.AffiliationsByOrganizationType'] = "Affiliations By Organization Type";
$lang['Mykols.AffiliationsByEngagementType'] = "Affiliations By Engagement Type";
$lang['Mykols.EventsByYear'] = "Events By Year";
$lang['Mykols.EventsByTopic'] = "Events By Topic";
$lang['Mykols.PublicationsByYear'] = "Publications by Year";
$lang['Mykols.PublicationsByAuthorshipPosition'] = "Publications by Authorship Position";
$lang['Mykols.Category'] = "Category";
$lang['Mykols.Criteria'] = "Criteria";
$lang['Mykols.Rating'] = "Rating";
$lang['Mykols.MonthFrom'] = "Month From";
$lang['Mykols.To'] = "To";

// Turnary Navigations of Organizations
$lang['Organizations.KeyPeople'] ="Key People";
$lang['Organizations.KeyAuthors'] = "Key Authors";
$lang['Organizations.Publications'] = "Publications";
$lang['Organizations.OrgNetwork'] = "Org Network";
$lang['Organizations.ClinicalTrials'] = "Clinical Trials";

// Turnary Navigations of Track

$lang['Track.Plans'] ="Plans";
$lang['Track.Topics'] ="Topics";
$lang['Track.Objectives'] ="Objectives";
$lang['Track.CreatePlan'] ="Create Plan";
$lang['Track.MSL_Coaching'] ="Customer Engagement Form";

// Secondary Navigations of My Organizations
$lang['Org.Overview'] = "Overview";
$lang['Org.associatedpeople'] = "Assoc people";
$lang['Org.About'] = "About";
$lang['Org.SocialMedia'] = "Social Media";

// Secondary Navigations of Track
$lang['Track.Planning'] = "Plan";
$lang['Track.Interactions'] = "Interactions";
$lang['Track.Payments'] = "Payments";
$lang['Track.Eventsreport'] = "Events Report";
$lang['Track.Contracts'] = "Contracts";

$lang['Track.EventsReport'] = "Events Report";
$lang['Track.MedicalInsight'] = "Medical Insight";
$lang['Track.ComplianceForm'] = "Field Compliance Monitoring";
$lang['Track.Reports'] = "Reports";

// Secondary Navigations of My KOLS
$lang['NetworkMaps.KOL_Network'] = "KTL Network";
$lang['NetworkMaps.KOLGeoNetwork'] = "KTL Geo Network";
$lang['NetworkMaps.OrgNetwork'] = "Org Network";
$lang['NetworkMaps.InfluenceNetwork'] = "Influence Network";
$lang['NetworkMaps.InfluenceGeoMap'] = "Influence Geo Map";

// Secondary Navigations of Lists
$lang['Mylists.Lists'] = "Lists";
$lang['Mylists.Managelist'] = "Manage List";

// Secondary Navigations of Network Maps
$lang['Network.Geomap'] = "Geo Map";
$lang['Network.Influencemap'] = "Influence Map";

// Secondary Navigations of Reports
$lang['Report.Activity'] = "Activity";
$lang['Report.Affiliations'] = "Affiliations";
$lang['Report.Events'] = "Events";
$lang['Report.Publications'] = "Publications";
$lang['Report.Segmentation'] = "Segmentation";
$lang['Report.Useranalytics'] = "User Analytics";
$lang['Report.Ktlanalytics'] = "KTL Analytics";
$lang['Report.Summary'] = "Audit Summary";
$lang['Report.ProfileScore'] = "Profile Score";
$lang['Report.Assessment'] = "Assessment";
$lang['Report.MSLActivity'] = "MSL Activity";
$lang['Report.UserAccess'] = "User Access";
$lang['Report.CustomerSeen'] = "Customer Seen";
$lang['Report.InstitutionSeen'] = "Institution Seen";
$lang['Report.UOQ'] = "UOQ Report";
$lang['Report.SpeakerEvaluations'] = "Speaker Evaluation";


//Over View Page
$lang['Overview.License'] = "License";
$lang['Overview.Address'] = "Address";
$lang['Overview.Phone']   = "Phone";
$lang['Overview.CompanyHQ'] = "Company HQ";
$lang['Overview.Fax'] 	  = "Fax";
$lang['Overview.Email']   = "Email";
$lang['Overview.Activities']   = "Activities";
$lang['Overview.Biography'] 	  = "Profile Summary";
$lang['Overview.ClinicalResearchInterests']   = "Clinical Research Interests";
$lang['Overview.KeyRegionalOffices']   = "Key Regional Offices";
$lang['Overview.Website']   = "Website";
$lang['Overview.Founded']   = "Founded";


$lang['Overview.PersonalInfo'] 	  	= "Personal Info";
$lang['Overview.Interaction'] 		= "Interaction";
$lang['Overview.Payments'] 			= "Payments";
$lang['Overview.Dashboard'] 	  	= "Dashboard";
$lang['Overview.Assessment']   		= "Assessment";

$lang['Overview.Trials'] = "Trials";
$lang['Overview.Affiliations'] = "Affiliations";
$lang['Overview.Events'] = "Events";
$lang['Overview.Publications'] = "Publications";
$lang['Ipad.Training'] = "Training";
$lang['Ipad.Add Influencers'] = "Add Influencers";
$lang['Ipad.Add Interactions'] = "Add Interactions";

//For Grid
$lang['Overview.ADDITIONAL_CONTACT'] = "ADDITIONAL CONTACT";
$lang['Overview.EDUCATION'] = "EDUCATION";
$lang['Overview.TRAINING'] = "TRAINING";
$lang['Overview.BOARDCERTIFICATION'] = "BOARD CERTIFICATION";
$lang['Overview.HONORSANDAWARDS'] = "HONORS AND AWARDS";

$lang['Overview.Type'] 		  = "Type";
$lang['Overview.Address'] 		  = "Address";
$lang['Overview.Phone'] 		  = "Phone";
$lang['Overview.InstitutionName'] = "Institution Name";
$lang['Overview.Degree'] 		  = "Degree";
$lang['Overview.Specialty'] = "Specialty";
$lang['Overview.TimeFrame'] = "Time Frame";
$lang['Overview.Action'] = "Action";

$lang['Overview.HonorName'] = "Honor Name";

$lang['Overview.addEducation'] = "Add Education";
$lang['Overview.Date'] = "Date";
$lang['Overview.RecordedBy'] = "RecordedBy";
$lang['Overview.Channel'] = "Channel";
$lang['Overview.Product'] = "Indication";
$lang['Overview.requestedBy'] = "Requested By";
$lang['Overview.paidBy'] = "Paid By";
$lang['Overview.amount'] = "Amount";
$lang['Overview.title'] = "Title";
$lang['Overview.allAffiliations'] = "ALL AFFILIATIONS";
$lang['Overview.OrganizationName'] = "Organization Name";
$lang['Overview.Department'] = "Department";
$lang['Overview.TimeFrame'] = "Time Frame";
$lang['Overview.OrgType'] = " Org Type";
$lang['Overview.engType'] = " Eng Type";
$lang['Overview.UNIVERSITYHOSPITAL'] = "UNIVERSITY / HOSPITAL";
$lang['Overview.ASSOCIATION'] = "ASSOCIATION";
$lang['Overview.INDUSTRY'] = "INDUSTRY";
$lang['Overview.GOVERNMENT'] = "GOVERNMENT";
$lang['Overview.OTHERS'] = "OTHERS";
$lang['Overview.AllEvents'] = "All Events";
$lang['Overview.EventName'] = "Event Name";
$lang['Overview.Topic'] = "Topic";
$lang['Overview.ArticleTitle'] = "Article Title";
$lang['Overview.JournalName'] = "Journal Name";
$lang['Overview.PUBLICATIONS'] = "PUBLICATIONS";
$lang['Overview.TRIALS'] = "TRIALS";
$lang['Overview.TrialName'] = "Trial Name";
$lang['Overview.Status'] = "Status";
$lang['Overview.Sponsers'] = "Sponsors";
$lang['Overview.Condition'] = "Condition";
$lang['Overview.Intervention'] = "Intervention";
$lang['Overview.Phase'] = "Phase";

// Secondary Navigations of Surveys
$lang['Surveys.ActiveSurveys'] = "Active Surveys";
$lang['Surveys.AllSurveys'] = "All Surveys";
$lang['Surveys.Reports'] = "Reports";
$lang['Surveys.InfluenceMap'] = "Influence Map";
$lang['Surveys.InfluenceGeoMap'] = "Influence Geomap";

// Home tab overview page

$lang['Home.Summary'] = "Summary";
$lang['Home.TotalKols'] = "Total KTLs";
$lang['Home.TotalOrganizations'] = "Total Organizations";
$lang['Home.Top5Specialties'] = "Top 5 Specialties";
$lang['Home.RecentActivity'] = "Recent Activity";
$lang['Home.MedicalNews'] = "Medical News";
$lang['Home.WorldPharma'] = "World Pharma";
$lang['Home.BioSpace'] = "BioSpace";
$lang['Home.Pharmaceutical'] = "Pharmaceutical";
$lang['Home.PharmaTimes'] = "Pharma Times";
$lang['Home.PharmaTech'] = "Pharma Tech";
$lang['Home.AHAJournals'] = "AHA Journals";
$lang['Home.ShowAll'] = "Show All";

// Organization profile overview page

$lang['Organizations.CompanyBackground'] = "Company Background";
$lang['Organizations.MissionVisionValues'] = "Mission, Vision & Values";
$lang['Organizations.MEDICALSERVICES'] = "MEDICAL SERVICES";
$lang['Organizations.KEYPRODUCTS'] = "KEY PRODUCTS";
$lang['Organizations.MERGERSandACQUISITIONS'] = "MERGERS & ACQUISITIONS";
$lang['Organizations.TOPCLIENTS'] = "TOP CLIENTS";
$lang['Organizations.FACTS'] = "FACTS";
$lang['Organizations.Beds'] = "Beds";
$lang['Organizations.Inpatients'] = "Inpatients";
$lang['Organizations.Births'] = "Births";
$lang['Organizations.Outpatients'] = "Outpatients";
$lang['Organizations.EmergencyDepartment'] = "Emergency Department";
$lang['Organizations.Surgeries'] = "Surgeries";
$lang['Organizations.Hospitals'] = "Hospitals";
$lang['Organizations.Physicians'] = "Physicians";
$lang['Organizations.PhysiciansEmployed'] = "Physicians Employed";
$lang['Organizations.PhysiciansAffiliated'] = "Physicians Affiliated";
$lang['Organizations.PharmacyBenefitManagement'] = "Pharmacy Benefit Management";
$lang['Organizations.SpecialtyPharmacy'] = "Specialty Pharmacy";
$lang['Organizations.NCQAStatus'] = "NCQA Status";
$lang['Organizations.MedicareRating'] = "Medicare Rating";
$lang['Organizations.ClaimsAndEMRData'] = "Claims & EMR Data";
$lang['Organizations.DataProcessing'] = "Data Processing";
$lang['Organizations.ENROLLMENT'] = "ENROLLMENT";
$lang['Organizations.EnrollmentType'] = "Enrollment Type";
$lang['Organizations.FORMULARY'] = "FORMULARY";
$lang['Organizations.DrugName'] = "Drug Name";
$lang['Organizations.DrugTier'] = "Drug Tier";
$lang['Organizations.PACriteria'] = "PA Criteria";
$lang['Organizations.DISEASEMANAGEMENT'] = "DISEASEMANAGEMENT";
$lang['Organizations.DiseaseName'] = "DiseaseName";
$lang['Organizations.DiseaseManagementPlatform'] = "Disease Management Platform";
$lang['Organizations.Identification'] = "Identification";
$lang['Organizations.Intervention'] = "Intervention";
$lang['Organizations.Measurment'] = "Measurment";
$lang['Organizations.CollaborationRating'] = "Collaboration Rating";
$lang['Organizations.Category'] = "Category";
$lang['Organizations.Rating'] = "Rating";
$lang['Organizations.AFFILIATESandPARTNERSHIPS'] = "AFFILIATES & PARTNERSHIPS";
$lang['Organizations.Notes'] = "Notes";
$lang['Organizations.KeyPeople'] = "Key People";
$lang['Organizations.KeyAuthors'] = "Key Authors";
$lang['Organizations.KeyInvestigators'] = "Key Investigators";
$lang['Organizations.KEYPEOPLE'] = "KEY PEOPLE";
$lang['Organizations.KEYAUTHORS'] = "KEY AUTHORS";
$lang['Organizations.KEYINVESTIGATORS'] = "KEY INVESTIGATORS";
$lang['Organizations.Name'] = "Name";
$lang['Organizations.Department'] = "Department";
$lang['Organizations.TopKeywords'] = "Top Keywords";
$lang['Organizations.Articles'] = "Articles";

// Track grid titles and lables
$lang['track.KOLName'] = "KTL Name";
$lang['track.AssignedTo'] = "Assigned To";
$lang['track.Target'] = "Target";
$lang['track.Achieved'] = "Achieved";
$lang['track.Description'] = "Description";
$lang['track.RecordedBy'] = "Recorded By";
$lang['track.Presenters'] = "Presenter(s)";
$lang['track.Topics'] = "Topic(s)";
$lang['track.MeetingType'] = "Meeting Type";
$lang['track.Attendees'] = "Attendees";
$lang['track.Region'] = "Region";
$lang['track.Contracts'] = "Contracts";
$lang['track.ContractName'] = "Contract Name";
$lang['track.StartDate'] = "Start Date";
$lang['track.EndDate'] = "End Date";
$lang['track.Download'] = "Download";
$lang['track.EvaluatedBy'] = "Evaluated By";
$lang['track.MSLcoachings'] = "MSL Coachings";
$lang['track.kolNames'] = "KTL Name(s)";
$lang['track.Status'] = "Status";
$lang['track.Username'] = "Username";
$lang['track.Specialty'] = "Speciality";
$lang['MyLists.CategoryName'] = "Category Name";
$lang['MyLists.Name'] = "Name";
$lang['MyLists.Country'] = "Country";

// Reports grid titles and lables
$lang['Reports.ActivityTitle'] = "KTLs By Activity Report";
$lang['MyLists.Trials'] = "Trials";
$lang['MyLists.Total'] = "Total";

// Survey grid titles and lables
$lang['Surveys.Name'] = "Name";
$lang['Surveys.CreatedBy'] = "Created By";
$lang['Surveys.Status'] = "Status";
$lang['Surveys.RespondentTitle'] = "Respondents of survey";
$lang['Surveys.Respondent'] = "Respondent";
$lang['Surveys.Organization'] = "Organization";
$lang['Surveys.City'] = "City";
$lang['Surveys.State'] = "State";

// Profile request grid titles and lables
$lang['ProfileRequest.Approver'] = "Approver / Rejector";
$lang['ProfileRequest.RequestType'] = "Request Type";
$lang['ProfileRequest.PendingApprovals'] = "My Pending Approvals";
$lang['ProfileRequest.ProfileRequests'] = "All Profile Requests";


// Log Activities grid titles and lables
$lang['LogActivities.LogActivities'] = "All Log Activities";


// Organization request grid titles and labels
$lang['OrgProfileRequest.OrganizationRequests'] = "All Organization Requests";
$lang['events'] = "EVENTS";
$lang['organizer'] = "Organizer";



// Identification related Constatnts
$lang['Identification.TopSpeakers'] = "Top Speakers";
$lang['Identification.TopResearches'] = "Top Researchers";
$lang['Identification.RankingReport'] = "Ranking Report";
$lang['Identification.Graph'] = "Chart";
$lang['Identification.Trends'] = "Trends";


$lang['noOfProfiles'] = "Number of profiles";


// Refined by labels
$lang['Refinedby.Refinedby'] = "Refine By";
$lang['Refinedby.Reset'] = "Reset";
$lang['Refinedby.Assigned'] = "Assigned";
$lang['Refinedby.SavedFilters'] = "Saved Filters";
$lang['Refinedby.ProfileType'] = "Profile Type";
$lang['Refinedby.KOLName'] = "KOL Name";
$lang['Refinedby.Specialty'] = "Specialty";
$lang['Refinedby.Country'] = "Country";
$lang['Refinedby.Region'] = "Region";
$lang['Refinedby.State'] = "State";
$lang['Refinedby.List'] = "List";
$lang['Refinedby.City'] = "City";
$lang['Refinedby.Organization'] = "Organization";
$lang['Refinedby.Education'] = "Education";
$lang['Refinedby.Event'] = "Event";
$lang['Refinedby.OrganizationName'] = "Organization Name";
$lang['Refinedby.OrgType'] = "Org Type";
$lang['Refinedby.PostalCode'] = "Postal Code";
$lang['Refinedby.InfluencerType'] = "Influencer Type";
$lang['Refinedby.InfluencerName'] = "Influencer Name";
$lang['Refinedby.Respondent'] = "Respondent";
$lang['Refinedby.MSL'] = "MSL";
$lang['Refinedby.Survey'] = "Survey";
$lang['Refinedby.Project'] = "Project";
$lang['Refinedby.Industry'] = "Industry";

// Identify Tab
$lang['Identify.Journals'] = "Journals";
$lang['Identify.Institutions'] = "Institutions";
$lang['Identify.Events'] = "Events";
$lang['Identify.Trials'] = "Trials";
$lang['Identify.Guidelines'] = "Guidelines";
$lang['Identify.PrioritySettings'] = "Priority Settings";
$lang['Identify.GridId'] = "Id";
$lang['Identify.GridName'] = "Name";
$lang['Identify.GridRank'] = "Rank";
$lang['Identify.GridScore'] = "Score";
$lang['Identify.GridTotal'] = "Total";
$lang['Identify.GridSpeaking'] = "Speaking";
$lang['Identify.OrganizingCommittee'] = "Organizing Committee";
$lang['Identify.GridIndustry'] = "Industry";
$lang['Identify.GridAssociations'] = "Associations";
$lang['Identify.GridEditorialBoards'] = "EditorialBoards";
$lang['Identify.GridExpertcenter'] = "Expert center";
$lang['Identify.GridAllPubs'] = "All Pubs";
$lang['Identify.GridLeadAuthor'] = "Lead Author";
$lang['Identify.GridMiddleAuthor'] = "Middle Author";
$lang['Identify.GridSingleAuthor'] = "Single Author";
$lang['Identify.GridFirstAuthor'] = "First Author";
$lang['Identify.GridLastAuthor'] = "Last Author";
$lang['Identify.GridClinicalTrials'] = "Clinical Trials";
$lang['Identify.GridGuidelines'] = "Guidelines";
$lang['Identify.GridCongressesConferences'] = "Congresses & Conferences";
$lang['Identify.GridAffiliations'] = "Affiliations";
$lang['Identify.GridPublications'] = "Publications";
$lang['Identify.GridKOLRanking'] = "KTL Ranking";

// Media Tab
$lang['MediaTab.Inthenews'] = "In the news";
$lang['MediaTab.People'] = "People";
$lang['MediaTab.Diseases'] = "Diseases";
$lang['MediaTab.Product'] = "Product";
$lang['MediaTab.Technology'] = "Technology";
$lang['MediaTab.Organization'] = "Organization";
$lang['MediaTab.Companies'] = "Companies";
$lang['MediaTab.Source'] = "Source";

// Others
$lang['Header.ShowMeHow'] = "Show me how";
$lang['Header.SearchKols'] = "Search KOLs";
$lang['Header.HideSideBar'] = "Hide Sidebar";
$lang['ResultsRefinedBy'] = "Results Refined By";
$lang['ResetAllFilters'] = "Reset all filters";
$lang['Identify.Keywords'] = "Keywords";
$lang['Identify.Resultsfilteredby'] = "Results filtered by";
$lang['From'] = "From";
$lang['To'] = "To";
$lang['Ignoredtopicslist'] = "Ignored topics list";
$lang['ShowMore'] = "Show more";
$lang['Showing'] = "Showing";
$lang['of'] = "of";
$lang['Header.ShowSideBar'] = "Show Sidebar";

//all Kol and Kols
$lang['Contacts.Kol'] = "KOL";
$lang['Contracts.KolName'] = "KTL Name";
$lang['Contracts.OrgName'] = "Organization Name";
$lang['Identification.KolRanking'] = "KOL Ranking";
$lang['Identification.Trends'] = "KTL Trends";
$lang['Reports.KolsByActivity'] = "KTLs By Activity";
$lang['Reports.KolsByCountry'] = "KTLs By Country";
$lang['Reports.KolsBySpecialty'] = "KTLs By Specialty";
$lang['Reports.KolsByPublications'] = "KTLs By Publications";

// HCP
$lang['HCP'] = "KTL";
$lang['KOL'] = "KTL";
$lang['kol'] = "KTL";

//Opt In - Opt Out Email Content
$lang['OptInOutEmail.LandingSubject'] = "";
$lang['OptInOutEmail.LandingContent'] = "Welcome! You are invited to join the Hill’s Pet Nutrition Key Thought Leader Community.  Please follow the link below to find out more about this opportunity.";
$lang['OptInOutEmail.LandingMissionCaption']= "OUR MISSION";
$lang['OptInOutEmail.LandingMissionContent']= "To help enrich and lengthen the special relationships between people and their pets.";
$lang['OptInOutEmail.OptinSubject'] = "Hill’s Key Thought Leader Community enroll notice";
$lang['OptInOutEmail.OptinBody'] = "Thank you for choosing to participate in the Hill’s Key Thought Leader Community.  We hope you enjoy being part of the community and we look forward to discussing our mutual interests in companion animal nutrition.  Should you at any time decide you do not want to continue your participation in this community, please notify your Hill’s Pet Nutrition representative and we will change your status to inactive.";
$lang['OptInOutEmail.OptoutSubject'] = "Hill’s Key Thought Leader Community decline notice";
$lang['OptInOutEmail.OptoutBody'] = "Thank you for considering your participation in the Hill’s Key Thought Leader Community.   At this time we will note in our system that you have chosen to not participate in this community.  We will miss your valuable input and the chance to discuss our mutual interests in companion animal nutrition.  Should you at any time decide you want to reconsider your participation in this community please notify your Hill’s Pet Nutrition representative and we will send you a new invitation.";

//Opt In - Opt Out Success Message
$lang['OptInOutMsg.Optin'] ="Thank you.";
$lang['OptInOutMsg.Optout'] ="We appreciate the time you have taken to consider being part of the Hill’s Key Thought Leader Community.  At this time we acknowledge your decision to not be part of the Hill’s Key Thought Leader Community.  You will receive an email confirming your decision to not have your information included in this group.";

//Opt In - Opt Out Page Lang
$lang['OptInOut.Caption'] = "Hill’s Key Thought Leader Community";
$lang['OptInOut.BodyCaption'] = "Welcome";
$lang['OptInOut.KOlName'] = "Dear ";
$lang['OptInOut.BodyContent'] = "<div>
        	  						<br>
        	  							Your veterinary colleagues at Hill’s Pet Nutrition are proud to support our profession and we believe that one of the key ingredients for success has been our valuable partnerships with key thought leaders (KTLs) like you. In the spirit of continuous improvement, we are working to enhance efficiency of communication with you.  To facilitate this process, we would like to store and manage information about our partner KTLs in a secure, centralized database. We want to ensure that your personal information is handled with the utmost level of care and security.    All data that will be collected is freely available online, and will include:  Name, work phone number, work email, work address, affiliations (primary workplace and organizations), department, previous education, previous training, board certification, specialties, speaking engagements, publications, professional social media feeds.  
                                        We will handle your personal information in accordance with our <a href='".base_url()."client_users/change_language/english' target='_blank' data-toggle='tooltip' title='privacy policy'>privacy policy</a>. 
        	  						<br>
        	  							&nbsp;
        	  						<br>
        	  							Because you have been identified as a valuable partner, we are planning to include your information in our KTL database.  Potential benefits for you include being invited to participate in unique opportunities with Hill’s, such as:
        	  						<br>
        	  						<br>
        	  							<ul>
        	  								<li>Roundtable discussions</li>
        	  								<li>Speaking engagements</li>
        	  								<li>Expert panels</li>
        	  								<li>Focus groups about new products</li>
        	  								<li>Collaborative research</li>
        	  								<li>Increased access to Hill’s nutritional information</li>
                                            <li>Interfacing with Hill’s scientists, nutritionists, and veterinary professionals</li>
            
        	  							</ul>
        	  						<br>
        								Please follow the web link below to access and read the Data Processing Consent Form, and if in agreement, complete the survey to opt in or opt out of the data base.  If you have any questions/feedback, please do not hesitate to contact your Hill’s Representative.
        							<br>
        							<br>
        							<br>
        							<strong><em>DATA PROCESSING CONSENT INFORMATION FOR VETERINARY PROFESSIONALS</em><br>&nbsp;</strong>
          						</div>";
//$lang['OptInOut.OptInText'] = "I have read the Data Processing Consent Information and agree to be part of the Hill’s KTL Community";
//$lang['OptInOut.OptOutText'] = "I have read the Data Processing Consent Information and do not agree to be part of the Hill’s KTL Community";
$lang['OptInOut.OptInText'] = "I agree to be included in the Hill’s KTL community.  I understand that I may withdraw my consent at any time.  I have received the <a href='".base_url()."client_users/change_language/english' target='_blank' data-toggle='tooltip' title='Privacy Notice'>Privacy Notice</a>.";
$lang['OptInOut.OptOutText'] = 'I do not wish to be included in the Hill’s KTL community.';
$lang['OptInOut.PrivacyPolicy'] = 'Privacy Policy';
$lang['OptInOut.TermOfServices'] = 'Terms of Service';
$lang['OptInOut.Next'] = "NEXT";

//Opt In Form Page Lang
$lang['OptInForm.BodyCaption'] = "Welcome to the Hill's KTL Database!";
$lang['OptInForm.BodyContent'] = "Thank you for agreeing to be part of the Hill’s Key Thought Leader Community.  Please fill out the information in the form below so we can initiate your content in our community. In addition, you will receive an email confirming your agreement to join this group.  We look forward to hearing from you and discussing our mutual interests in companion animal nutrition.";
$lang['OptInForm.Salutation'] = "Salutation";
$lang['OptInForm.FirstName'] = "First Name";
$lang['OptInForm.LastName'] = "Last Name";
$lang['OptInForm.Title'] = "Professional Title";
$lang['OptInForm.WorkPlaceValue'] = "Work Place Title";
$lang['OptInForm.City'] = "City";
$lang['OptInForm.State'] = "State/Province (Optional)";
$lang['OptInForm.ZipCode'] = "Zip or Postal Code";
$lang['OptInForm.Country'] = "Country";
$lang['OptInForm.PhoneNo'] = "Best Contact Phone Number";
$lang['OptInForm.Email'] = "Best Contact email";
$lang['OptInForm.ConfirmEmail'] = "Please re-enter your email so we can confirm its accuracy";
$lang['OptInForm.Note'] = "Notes";
$lang['OptInForm.Attachment'] = "If you would like to upload a professional biography or CV you can do so here";
$lang['OptInForm.Browse'] = "Browse";
$lang['OptInForm.Remove'] = "Remove";
$lang['OptInForm.UploadMore'] = "Upload More";
$lang['OptInForm.Back'] = "Back";
$lang['OptInForm.Submit'] = "Submit";
$lang['OptInForm.ValidationMessage'] = "This question is required";
$lang['OptInForm.ValidationEmail'] = "Please enter a valid email";
$lang['OptInForm.ValidationPhone'] = "Please enter a valid number";
$lang['OptInForm.ValidationConfirmEmail'] = "Please enter the same email";

$lang['PrivacyPolicy.Title'] = "COLGATE-PALMOLIVE COMPANY/HILL'S PET NUTRITION PRIVACY POLICY";
$lang['PrivacyPolicy.Content'] = '
                            Colgate-Palmolive Company respects your privacy and values the relationship we have with you.  Therefore, we handle your personal data responsibly, and we want you to be familiar with how we collect, use, and disclose your data.  This Privacy Policy describes our practices in connection with your data (as defined below) that we collect in the following ways:
  							</br><br/>
  							<ul>
  								<li>On Websites operated by us, from which you are accessing this Privacy Policy (our “<strong>Websites</strong>”),</li>
  								<li>Through software applications made available by us for use on or through computers and mobile devices (our “<strong>Apps</strong>”),</li>
  								<li>On Social Media Pages and apps that link to this Privacy Policy (collectively, our “<strong>Social Media Pages</strong>”),</li>
  								<li>From HTML-formatted email messages that we send to you that link to this Privacy Policy, and</li>
  								<li>In offline interactions you have with us.</li>
  							</ul>
  							<br/>
  							This Privacy Policy also describes our practices in connection with data that we collect about professionals such as dental and veterinary professionals, and students and health care experts (“<strong>Professionals</strong>”), in order to provide them with professionally-oriented services (“<strong>Professional Services</strong>”).
  							<br/><br/>
                            In this Privacy Policy, we refer to our Websites, our Apps, our Social Media Pages, our email messages, our offline activities and our Professional Services collectively as the “<strong>Services</strong>”.
                            <br/> <br/>
                            For information regarding our Connected Toothbrush, please see our <a href="https://shop.colgate.com/pages/privacy" target="_blank">Connected Toothbrush Privacy Policy</a>.
                            <br/><br/>';
$lang['PrivacyPolicy.Link1'] = 'PERSONAL DATA';
$lang['PrivacyPolicy.LinkContent1'] = '“<strong>Personal Data</strong>” is data that identifies you as an individual or relates to an identifiable individual. <a class="readmore" id="1">[+]</a>
                                        <div id="rm1" style="display:none">
                                        	<br/>
                                        	Personal data includes:
                                               <ul>
                                               <li>Name</li>
                                               <li>Postal address (including billing and shipping addresses)</li>
                                                <li>Telephone number</li>
                                                <li>Email address </li>
                                                <li>Credit and debit card number</li>
                                                <li>Profile picture or other photographs of you</li>
                                                <li>Social media account ID </li>
                                                <li>Adverse Event information about you</li>
                                                <li>Other information such as age, country, or the names of your pets when it is linked to you</li>
                                                <li>Your Interests (such as topics about which you request data or otherwise indicate interest)</li>
                                                </ul>
                                        </div>';
$lang['PrivacyPolicy.Link2'] = 'COLLECTION OF PERSONAL DATA';
$lang['PrivacyPolicy.LinkContent2'] = '
                                        We and our service providers collect Personal Data in a variety of ways, including:<br/><br/>
                                        <ul>
                                        <li><strong>Through the Services</strong> <a class="readmore" id="2">[+]</a><br/>
                                            <div id="rm2" style="display:none">
                                                We collect Personal Data through the Services, for example, when you sign up for a newsletter, register an account, create a profile, or make a purchase.
                                            </div>
                                        </li>
                                        <li><strong>Offline </strong> <a class="readmore" id="3">[+]</a><br/>
                                            <div id="rm3" style="display:none">
                                                We collect Personal Data from you offline, for example:
                                                <ul>
                                                <li>When you place an order over the phone, contact Consumer Affairs or reach out to us with any other inquiry;</li>
                                                <li>When you visit our booth at a tradeshow or visit our facilities;</li>
                                                <li>When you participate in our programs or activities or provide data at industry events;</li>
                                                <li>When you participate in an offline sweepstakes or promotion;</li>
                                                <li>When you or someone on your behalf reports an adverse event with respect to one of our products.</li>
                                                
                                                </ul>
                                            </div>
                                        </li>
                                        <li><strong>From Other Sources</strong> <a class="readmore" id="4">[+]</a><br/>
                                            <div id="rm4" style="display:none">
                                                We receive your Personal Data from other sources, for example:
                                                <ul>
                                                <li>Publicly available databases and sources;</li>
                                                <li>Data companies;</li>
                                                <li>Joint marketing partners;</li>
                                                <li>Third parties who report adverse events regarding a product to us.</li>
                                                </ul>
                                                If you connect your social media account to any account offered by us, you will share certain Personal Data from your social media account with us, such as your name, email address, photos, list of social media contacts, and any other data that may be (or that you make) accessible to us when you connect your social media account to any account offered by us.
                                            </div>
                                        </li>
                                        </ul>
                                        In many instances, we need to collect Personal Data in order to provide the requested Services to you.  If you do not provide the Personal Data requested, we may not be able to provide the Services.  If you disclose any Personal Data relating to other people to us or to our service providers in connection with the Services, you represent that you have the authority to do so and to permit us to use the Personal Data in accordance with this Privacy Policy.';
$lang['PrivacyPolicy.Link3'] = 'USE OF PERSONAL DATA';
$lang['PrivacyPolicy.LinkContent3'] = 'We and our service providers use Personal Data for legitimate business purposes when we interact with consumers, the public, professionals and our customers.<br/><br/>
                                        <strong>Interacting with Consumers and the Public</strong> <br/>
                                       		<br/>We use Personal Data when interacting with Consumers and the Public for the following purposes including:
                                        <ul>
                                        	<li><strong>Providing the Services and fulfilling your requests.</strong><a class="readmore" id="5">[+]</a><br/>
                                        		<div id="rm5" style="display:none">
                                            		<ul>
                                            			<li>To provide the Services to you, such as arranging access to an account you set up with us.</li>
                                                        <li>To respond to your inquiries and fulfill your requests, when you contact us via one of our online contact forms, by telephone or otherwise, for example, when you send us questions, suggestions, compliments, or complaints.
                                                        	<ul>
                                                        		<li>To the extent you elect to share personal information, for instance about your skin or oral health, we will use that information consistent with the notice we provide to you at that time and with your consent.</li>
                                                        	</ul>
                                                    	</li>
                                                        <li>To send administrative information to you, such as changes to our terms, conditions, and policies.</li> 
                                                        <li>To allow you to send messages to another person, through referrals or “send to a friend” features.</li>
                                                        <li>To facilitate social sharing functionality, if you choose to use such functionality.</li>
                                                        <li>To provide you with customer service.</li>
                                            		</ul>
                                        		</div>
                                    		</li>
                                        	<li><strong>Providing you with information about our products and/or other marketing materials.</strong><a class="readmore" id="6">[+]</a><br/>
                                        		<div id="rm6" style="display:none">
                                            		<ul>
                                            			<li>To send you marketing related emails, with information about our services, products, and other news about us.</li>
                                            		</ul>
                                        		</div>
                                    		</li>
                                        	<li><strong>Analysis of Personal Data for business reporting and providing personalized services.</strong><a class="readmore" id="7">[+]</a><br/>
                                        		<div id="rm7" style="display:none">
                                        			<ul>
                                        				<li>To analyze or predict your preferences in order to prepare aggregated trend reports on how our digital content is used.</li>
                                                        <li>To better understand you, so that we can personalize our interactions with you and provide you with information and/or offers tailored to your interests.</li>
                                                        <li>To better understand your preferences so that we can deliver content via our Services that we believe will be relevant and interesting to you.</li>
                                                    </ul>
                                            	</div>
											</li>
                                			<li><strong>Allowing you to participate in sweepstakes, contests, or other promotions.</strong><a class="readmore" id="8">[+]</a><br/>
                                				<div id="rm8" style="display:none">
                                    				<ul>
                                    					<li>We may offer you the opportunity to participate in a sweepstakes, contest, or other promotion.</li>  
    													<li>Some of these promotions have additional rules containing information about how we will use and disclose your Personal Data.</li>
                                    				</ul>
                                				</div>
                                			</li>
                                			<li><strong>Allowing you to participate in the Colgate Bright Smiles, Bright Futures® program.</strong><a class="readmore" id="9">[+]</a><br/>
                                				<div id="rm9" style="display:none"> 
                                    				<ul>
                                    					<li>To administer the program.</li>  
    													<li>To ensure that the samples are being used appropriately.</li>
                                    				</ul>
                                				</div>
                                			</li>
                                			<li><strong>Aggregating and/or anonymizing Personal Data.</strong> <a class="readmore" id="10">[+]</a><br/>
                                				<div id="rm10" style="display:none">
                                    				<ul>
                                                		<li>We may aggregate and/or anonymize Personal Data so that it will no longer be considered Personal Data.  We do so to generate other data for our use, which we may use and disclose for any purpose.</li>
                                                	</ul> 
                                            	</div>
                                            </li>
                                            <li><strong>Accomplishing our business purposes.</strong> <a class="readmore" id="11">[+]</a>
                                            	<div id="rm11" style="display:none">
                                                	<ul>
                                                    	<li>For audits, to verify that our internal processes function as intended and are compliant with legal, regulatory, or contractual requirements.</li>
                                                        <li>For fraud and security monitoring purposes, for example, to detect and prevent cyberattacks or attempts to commit identity theft.</li>
                                                        <li>For developing new products and services.</li>
                                                        <li>For enhancing, improving, or modifying our current products and services. </li>
                                                        <li>To manage and report adverse event reporting relating to our products.</li>
                                                        <li>For identifying usage trends, for example, understanding which parts of our Services are of most interest to users.</li>
                                                        <li>For determining the effectiveness of our promotional campaigns, so that we can adapt our campaigns to the needs and interests of our users.</li>  
                                                        <li>For operating and expanding our business activities.</li>
                                                	</ul>
                                            	</div>
                                        	</li>
                                        </ul>
                                        We engage in these activities to manage our relationship with you, to comply with a legal obligation, in some circumstances when we have your consent and/or because we have a legitimate business interest.';
$lang['PrivacyPolicy.Link4'] = 'INTERACTING WITH PROFESSIONALS';
$lang['PrivacyPolicy.LinkContent4'] = 'In addition, we and our service providers collect and use information regarding Professionals.<a class="readmore" id="12">[+]</a><br/>
                                        <div id="rm12" style="display:none">
                                        <br/>
                                            Such information includes:
                                            <ul>
                                                <li>Your Preferred language</li>
                                                <li>Professional biography and education</li>
                                                <li>Webstore account number and ID</li>
                                                <li>Data related to your licensures, specialties, affiliations, publications, credentials, and other achievements</li>
                                                <li>Data related to your use and purchase of our products, your interactions with us, and services for those to whom you provide care</li>
                                            </ul>
                                            We use Personal Data about Professionals for the following purposes (in addition to the purposes listed under Consumers and the Public), including:
                                            <br/>
                                            <ul>
                                            	<li><strong>Fulfilling requests related to our Professional Services.</strong> <a class="readmore" id="13">[+]</a>
                                            		<div id="rm13" style="display: none;">
                                                    	<ul>
                                                        	<li>To pay for services or reimburse expenses.</li>
                                                        	<li>To assist in planning trips related to our business or conferences.</li>
                                                        	<li>To provide you with the products and samples you have requested.</li>
                                                        	<li>To identify and engage with Professionals as scientific experts or professional leaders.</li>
                                                        	<li>To enforce the contractual terms and conditions governing our relationship with Professionals.</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li><strong>Engaging with Professionals</strong><a class="readmore" id="14">[+]</a>
                                                	<div id="rm14" style="display: none;">
                                                        <ul>
                                                            <li>To interact with you based on your professional expertise and opinion by digital or other means.</li>
                                                            <li>To involve you in programs/panels of professionals.</li>
                                                            <li>To reach out to you for your professional expertise, for example, in the context of surveys relating to products or services offered by us or an affiliate.</li>
                                                            <li>To collaborate with you on events, publications, or advisory meetings.</li>
                                                            <li>To seek your views on products and services promoted by us, an affiliate, or business partner for development and improvement purposes.</li>
                                                        </ul>
                                                    </div>
                                                </li>	
                                                <li><strong>Allowing Professionals to participate in special programs, events or promotions.</strong> <a class="readmore" id="15">[+]</a>
                                                    <div id="rm15" style="display: none;">
                                                        <ul>
                                                        	<li>In these cases, we may use Professionals’ Personal Data in additional ways as disclosed as part of these special programs, activities, events, or promotions.</li>  
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li><strong>Allowing Professionals to create a webstore.</strong><a class="readmore" id="16">[+]</a>
                                                	<div id="rm16" style="display: none;">
                                                	<ul>
                                                		<li>We give Professionals the opportunity to create a webstore to help them provide optimal patient services and convenient access to our products.</li>
                                            		</ul>
                                            		</div>
                                                </li>	  
                                                <li><strong>Accomplishing our business purposes.</strong><a class="readmore" id="17">[+]</a>
                                                    <div id="rm17" style="display: none;">
                                                        <ul>
                                                            <li>To comply with anti-corruption and transparency obligations.</li>
                                                            <li>To track and respond to concerns and meet our regulatory monitoring and reporting obligations, including those related to product complaints, product/patient safety, and background checks.</li>
                                                            <li>To better understand how our products and services affect Professionals and their patients.</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                            </ul>
                                            We engage in these activities to manage our relationship with you, to comply with a legal obligation, in some circumstances when we have your consent, for scientific purposes and/or because we have a legitimate business interest.
                                    	</div><br/>
                                    	<strong>Interacting with Customers</strong><br/><br/>
										
                                        We use Personal Data about Customers for the following purposes (in addition to the purposes listed under Consumers and the Public), including:
                                        
                                        <ul>
                                        	<li><strong>Providing the Services and fulfilling your requests.</strong><a class="readmore" id="18">[+]</a>
                                        		<div id="rm18" style="display: none;">
                                            		<ul>
                                            			<li>To complete your transactions with us.</li>
                                            		</ul>
                                        		</div>
                                        	</li>
											<li><strong>Accomplishing our business purposes.</strong><a class="readmore" id="19">[+]</a>
												<div id="rm19" style="display: none;">
    												<ul>
                                                    	<li>To comply with anti-corruption and transparency obligations.</li>
                                                    	<li>To track and respond to concerns and meet our regulatory monitoring and reporting obligations, including those related to product complaints, product/patient safety, and background checks.</li>
                                                    	<li>To better understand how our products and services affect Professionals and those for whom they care.</li>
                                                    </ul>
                                                </div>
                                        	</li>
                                        	<li><strong>Accomplishing our business purposes.</strong><a class="readmore" id="20">[+]</a>
                                        		<div id="rm20" style="display: none;">
                                            		<ul>
                                            		<li>To comply with anti-corruption and transparency obligations.</li>
                                            		<li>To track and respond to concerns and meet our regulatory monitoring and reporting obligations, including those related to product complaints, product/patient safety, and background checks.</li>
                                            		<li>To better understand how our products and services affect Professionals and those for whom they care.</li>
                                            		</ul>
                                        		</div>
                                        	</li>
                                        </ul>
                                        We engage in these activities to manage our relationship with you, to comply with a legal obligation, in some circumstances when we have your consent and/or because we have a legitimate business interest.';
$lang['PrivacyPolicy.Link5'] = 'DISCLOSURE OF PERSONAL DATA';
$lang['PrivacyPolicy.LinkContent5'] = 'We disclose Personal Data:<br/>
                                            <ul>
                                            <li><strong>To our subsidiaries and affiliates for the purposes described in this Privacy Policy.</strong> <a class="readmore" id="21">[+]</a>
                                            	<div id="rm21" style="display: none;">
                                                	<ul>
                                                    	<li>You can consult the list and location of our subsidiaries or affiliates <a href="https://www.sec.gov/Archives/edgar/data/21665/000002166518000006/exhibit2112312017.htm" target="_blank">here</a></li>  
                                                    	<li>The Colgate-Palmolive subsidiary or affiliate that has collected your Personal Data will be responsible for Personal Data about you that is transferred and used.</li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li><strong>To our third party service providers, to facilitate services they provide to us.</strong><a class="readmore" id="22">[+]</a>
                                            	<div id="rm22" style="display: none;">
                                                    <ul>
                                                    	<li>These can include providers of services such as website hosting, data analysis, payment processing, order fulfillment, information technology and related infrastructure provision, customer service, email delivery, auditing, and other services.</li> 
                                                    </ul>
                                                </div>
                                            </li>
                                            <li><strong>To third parties, to permit them to send you marketing communications, consistent with your choices.</strong></li>
                                            
                                            <li><strong>To third-party sponsors of sweepstakes, contests, and similar promotions, consistent with your choices. </strong></li>
                                            
                                            <li><strong>In connection with providing our Professional Services, to other companies with which we collaborate regarding particular products or services.</strong> <a class="readmore" id="23">[+]</a>
                                            	<div id="rm23" style="display: none;">
                                                    <ul>
                                                    	<li>These can include our co-promotion partners for products that we jointly develop and/or market.</li>
                                                    </ul>
                                                </div>
                                            </li>
											</ul>
                                            By using the Services, you may also elect to disclose Personal Data. <a class="readmore" id="24">[+]</a>
                                            <div id="rm24" style="display: none;">
                                                <ul>
                                                    <li>You may disclose Personal Data on message boards, chat, profile pages, blogs, and other services to which you are able to post data and content (including, without limitation, our Social Media Pages).  Please note that any Personal Data you post or disclose through these services will become public and may be available to other users and the general public.</li>
                                                    <li>You may also disclose Personal Data through your social sharing activity.  When you connect your Services account with your social media account, you may share data with your friends associated with your social media account, with other users, and with your social media account provider.  By doing so, you authorize us to facilitate this sharing of data, and you understand that the use of shared data will be governed by the social media provider’s privacy policy.</li>
                                                </ul> 
                                            </div><br/><br/>
                                            <strong>Other Uses and Disclosures</strong><br/><br/>

                                            We also use and disclose your Personal Data as necessary or appropriate:
                                            <ul>
                                                <li><strong>To comply with applicable law and regulations.</strong> </li>
                                                <li><strong>To cooperate with public and government authorities.</strong></li>
                                                <li><strong>To cooperate with law enforcement.</strong> </li>
                                                <li><strong>In connection with a sale, reorganization, joint venture or other business transaction, where we have a legitimate interest in disclosing or transferring your Personal Data to a third party.</strong></li>
                                                <li><strong>For other legal reasons, such as enforcing our terms and conditions or protecting our rights, privacy, safety, or property, and/or that of our subsidiaries or affiliates, you, or others.</strong></li> 
                                            </ul>
                                            These uses and disclosures of your personal data can occur outside your country of residence.';
$lang['PrivacyPolicy.Link6'] = 'OTHER DATA';
$lang['PrivacyPolicy.LinkContent6'] = '“<strong>Other Data</strong>” is any data that does not reveal your specific identity or does not directly relate to an identifiable individual:<br/><br/>
                                        <ul>
                                            <li>Browser and device data</li>
                                            <li>App usage data</li>
                                            <li>Data collected through cookies, pixel tags, and other technologies</li>
                                            <li>Demographic and other data provided by you that does not reveal your specific identity</li> 
                                            <li>Data that has been aggregated in a manner such that it no longer reveals your specific identity</li>
                                        </ul> 
                                        Some Other Data will be considered Personal Data in some countries. If we are required to treat Other Data as Personal Data under applicable law, then we will use and disclose it for the purposes for which we use and disclose Personal Data, as detailed in this Privacy Policy.<br/><br/>
                                        <strong>Collection of Other Data</strong><br/><br/> 
                                        We and our service providers may collect Other Data in a variety of ways, including:<br/><br/> 
                                        <ul>  
                                            <li><strong>Through your browser or device</strong> <a class="readmore" id="25">[+]</a>
                                            	<div id="rm25" style="display: none;">
                                                    <ul>
                                                    	<li>Certain data is collected by most browsers or automatically through your device, such as your Media Access Control (MAC) address, computer type (Windows or Mac), screen resolution, operating system name and version, device manufacturer and model, language, Internet browser type and version, and the name and version of the Services (such as the App) you are using.</li>
                                                    </ul>
                                                </div>
                                            </li>  
                                            <li><strong>Through your use of an App</strong> <a class="readmore" id="26">[+]</a>
                                            	<div id="rm26" style="display: none;">
                                                	<ul>
                                                		<li>When you download and use an App, we and our service providers may track and collect App usage data, such as the date and time the App on your device accesses our servers and what data and files have been downloaded to the App based on your device number.</li>
                                                	</ul>
                                            	</div>
                                            </li>
                                            
                                            <li><strong>Using cookies</strong> <a class="readmore" id="27">[+]</a>
                                            	<div id="rm27" style="display: none;">
                                                    <ul>
                                                        <li>Cookies are pieces of data stored directly on the computer that you are using.  Cookies allow us to collect data such as browser type, time spent on the Services, pages visited, referring websites, and other traffic data.  For more information about cookies, please see our Cookies Policy.</li>
                                                        <li>We do not currently respond to browser do-not-track signals.  If you do not want data collected through the use of cookies, most browsers allow you to automatically decline cookies or be given the choice of declining or accepting a particular cookie (or cookies) from a particular website.  You may also wish to refer to <a href="http://www.allaboutcookies.org" target="_blank">http://www.allaboutcookies.org</a>  If, however, you do not accept cookies, you may experience some inconvenience in your use of the Services.  You also may not receive advertising or other offers from us that are relevant to your interests and needs.</li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li><strong>Using pixel tags, and other similar technologies</strong> <a class="readmore" id="28">[+]</a>
                                            	<div id="rm28" style="display: none;">
                                                	<ul>
                                                		<li>Pixel tags (also known as web beacons and clear GIFs) may be used to, among other things, track the actions of users of the Services (including email recipients), measure the performance of our marketing campaigns, and compile statistics about usage of the Services and response rates.</li>
                                                	</ul>
                                            	</div>
                                            </li>  
                                            <li><strong>Analytics</strong>  <a class="readmore" id="29">[+]</a>
                                            	<div id="rm29" style="display: none;">
                                                	<ul>
                                                		<li>We use Google Analytics which uses cookies and similar technologies to collect and analyze data about use of the Services and report on activities and trends.  This service may also collect data regarding the use of other websites, apps, and online resources.  You can learn about Google’s practices by going to <a href="http://www.google.com/policies/privacy/partners/" target="_blank">www.google.com/policies/privacy/partners/</a>, and opt out of them by downloading the Google Analytics opt-out browser add-on, available at <a href="https://tools.google.com/dlpage/gaoptout" target="_blank">https://tools.google.com/dlpage/gaoptout</a>. </li>
                                                    </ul>
                                                </div>
                                            <li><strong>Using Adobe Flash technology (including Flash Local Shared Objects (“Flash LSOs”)) and other similar technologies</strong>  <a class="readmore" id="30">[+]</a>
                                            	<div id="rm30" style="display: none;">
                                                	<ul>
                                                		<li>We may use Flash LSOs and other technologies to, among other things, collect and store data about your use of the Services.  If you do not want Flash LSOs stored on your computer, you can adjust the settings of your Flash player to block Flash LSO storage using the tools contained in the <a href="http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager07.html" target="_blank">Website Storage Settings Panel</a>.  You can also go to the <a href="http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager03.html" target="_blank">Global Storage Settings Panel</a> and follow the instructions.  Please note that setting the Flash Player to restrict or limit acceptance of Flash LSOs may reduce or impede the functionality of some Flash applications.</li>
                                                	</ul>
                                            	</div>
                                            </li>  
                                            <li><strong>IP Address</strong>  <a class="readmore" id="35">[+]</a>
                                            	<div id="rm35" style="display: none;">
                                                	<ul>
                                                		<li>Your IP address is automatically assigned to your computer by your Internet Service Provider.  An IP address may be identified and logged automatically in our server log files whenever a user accesses the Services, along with the time of the visit and the page(s) visited.  Collecting IP addresses is standard practice and is done automatically by many websites, applications, and other services.  We use IP addresses for purposes such as calculating usage levels, diagnosing server problems, and administering the Services.  We may also derive your approximate location from your IP address.</li>
                                                	</ul>
                                            	</div>
                                            </li> 
                                            <li><strong>Physical Location</strong> <a class="readmore" id="31">[+]</a>
                                            	<div id="rm31" style="display: none;">
                                                	<ul>
                                                		<li>We may collect the physical location of your device by, for example, using satellite, cell phone tower, or Wi-Fi signals.  We may use your device’s physical location to provide you with personalized location-based services and content.  In some instances, you may be permitted to allow or deny such uses of your device’s location, but, if you do, we may not be able to provide you with the applicable personalized services and content.</li>
                                                	</ul>
                                            	</div>
                                            </li>
                                        </ul>
                                        <strong>Uses and Disclosures of Other Data</strong><br/><br/> 

                                        We may use and disclose Other Data for any purpose, except where we are required to do otherwise under applicable law.  In some instances, we may combine Other Data with Personal Data.  If we do, we will treat the combined data as Personal Data as long as it is combined.';
$lang['PrivacyPolicy.Link7'] = 'SECURITY';
$lang['PrivacyPolicy.LinkContent7'] = 'We seek to use reasonable organizational, technical, and administrative measures to protect Personal Data within our organization.  Unfortunately, no data transmission or storage system can be guaranteed to be 100% secure.  If you have reason to believe that your interaction with us is no longer secure, please immediately notify us by contacting <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>.';
$lang['PrivacyPolicy.Link8'] = 'CHOICES AND ACCESS';
$lang['PrivacyPolicy.LinkContent8'] = '<strong>Your choices regarding our use and disclosure of your Personal Data</strong><br/><br/>
                                        We give you choices regarding our use and disclosure of your Personal Data for marketing purposes.<br/><br/>  
                                        You may opt-out from:  <br/><br/>
                                        <ul>
                                        	<li><strong>Receiving electronic communications from us:</strong>  If you no longer want to receive marketing-related emails, texts or SMS messages from us, you may opt-out by following the instructions contained in each such message or by contacting  <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>.</li> 
                                        	<li><strong>Receiving marketing communications related to our Professional Services:</strong>  If you use our Professional Services and no longer want to receive marketing communications from us, you may opt-out by contacting  <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>. In your request, please provide your name and address where you no longer wish to be contacted.</li>
                                        	<li><strong>Our sharing of your Personal Data with subsidiaries or affiliates for their direct marketing purposes:</strong>  If you would prefer that we discontinue sharing your Personal Data on a going-forward basis with our subsidiaries or affiliates for their direct marketing purposes, you may opt-out of this sharing by contacting  <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>.</li>
                                        	<li><strong>Our sharing of your Personal Data with unaffiliated third parties for their direct marketing purposes:</strong>  If you would prefer that we discontinue sharing your Personal Data on a going-forward basis with unaffiliated third parties for their direct marketing purposes, you may opt-out of this sharing by contacting <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>.</li>
                                        </ul>
                                        We will try to comply with your request(s) as soon as reasonably practicable.  Please note that if you opt-out of receiving marketing-related communications from us, we may still send you important administrative messages, from which you cannot opt-out.
                                        <br/><br/>
                                        <strong>How you can access, change, or delete your Personal Data</strong> 
                                        <br/><br/>
                                        If you would like to review, correct, update, suppress, restrict, or delete Personal Data that you have previously provided to us, object to the processing of your data, or if you would like to request to receive an electronic copy of your Personal Data for purposes of transmitting it to another company (to the extent this right to data portability is provided to you by applicable law), you may contact us sharing by contacting <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a>. We will respond to your request consistent with applicable law. <a class="readmore" id="32">[+]</a>
                                        	
                                        	<div id="rm32" style="display: none;">
                                        		<br/>
                                        		<ul>
                                        			<li>
                                        				For your protection, we may only implement requests with respect to the Personal Data associated with the particular email address that you use to send us your request, and we may need to verify your identity before implementing your request.  We will try to comply with your request as soon as reasonably practicable. 
                                        			</li>
                                        			<li>
                                        				Please note that we may need to retain certain data for recordkeeping purposes and/or to complete any transactions that you began prior to requesting a change or deletion (e.g., when you make a purchase or enter a promotion, you may not be able to change or delete the Personal Data provided until after the completion of such purchase or promotion), or to be able to honor opt-out requests.
                                        			</li>
                                        		</ul>
                                        	</div>
                                        ';
$lang['PrivacyPolicy.Link9'] = 'RETENTION PERIOD';
$lang['PrivacyPolicy.LinkContent9'] = 'We retain Personal Data for as long as needed or permitted in light of the purpose(s) for which it was obtained and consistent with applicable law and Company policy.  <a class="readmore" id="36">[+]</a>
                                        <div id="rm36" style="display: none;">
    										<br/>
                                            The criteria used to determine our retention periods include:
                                            <br/><br/>  
                                            <ul>
                                                <li>The length of time we provide the Services to you (for example, for as long as you have an account with us or keep using the Services);</li> 
                                                <li>The length of time we have an ongoing relationship with you;</li>
                                                <li>Whether there is a legal obligation to which we are subject (for example, certain laws require us to keep records of your transactions for a certain period of time before we can delete them); and</li>  
                                                <li>Whether retention is advisable in light of our legal position (such as in regard to applicable statutes of limitations, litigation, government investigations or regulatory considerations).</li>
                                            </ul>
                                        </div>';
$lang['PrivacyPolicy.Link10'] = 'THIRD PARTY SERVICES';
$lang['PrivacyPolicy.LinkContent10'] = 'This Privacy Policy does not address, and we are not responsible for, the privacy, data, or other practices of any third parties, including any third party operating any website or service to which the Services link.  The inclusion of a link on the Services does not imply endorsement of the linked site or service by us or by our subsidiaries or affiliates. 
                                        <br/><br/>
										In addition, we are not responsible for the data collection, use, disclosure, or security policies or practices of other organizations or any other app developer, app provider, social media platform provider, operating system provider, wireless service provider, or device manufacturer, including with respect to any Personal Data you disclose to other organizations through or in connection with the Apps or our Social Media Pages.';
$lang['PrivacyPolicy.Link11'] = 'OUR ADVERTISING';
$lang['PrivacyPolicy.LinkContent11'] = 'We use third-party advertising companies to serve advertisements regarding goods and services that may be of interest to you when you access and use the Services and other websites or online services. <a class="readmore" id="33">[+]</a>
                                        <div id="rm33" style="display: none;">
                                        		<br/>
												Such advertisements are served based on your access to and use of our Services and other websites or online services on any of your devices, as well as on data received from third parties. Third-party advertising companies make this possible by placing or recognizing a unique cookie on your browser (including through the use of pixel tags).  They also use these technologies, along with data they collect about your online use, to recognize you across the devices you use, such as a mobile phone and a laptop.  If you would like more information about this practice, and to learn how to opt out of it in desktop and mobile browsers on the particular device on which you are accessing this Privacy Policy, please visit <a href="http://optout.aboutads.info/#/" target="_blank">http://optout.aboutads.info/#/</a> and <a href="http://optout.networkadvertising.org/#/" target="_blank">http://optout.networkadvertising.org/#/</a>.
										</div>';
$lang['PrivacyPolicy.Link12'] = 'MINORS';
$lang['PrivacyPolicy.LinkContent12'] = 'Unless otherwise indicated, the Services are not directed to minors as defined by applicable law.  For example, in the US, minors are individuals under the age of 13, and in the EEA, we honor Member State laws, and we do not knowingly collect Personal Data from minors.  If you provide us with Personal Data of minors, you represent that you have the appropriate authority to do so and that you can demonstrate such authority to us upon request.';
$lang['PrivacyPolicy.Link13'] = 'JURISDICTION AND CROSS-BORDER TRANSFERS';
$lang['PrivacyPolicy.LinkContent13'] = 'Your Personal Data may be stored and processed in any country where we have facilities or in which we engage service providers, and, by using the Services, you understand that your Personal Data will be transferred to countries outside of your country of residence, to business which may have data protection rules that are different from those of your country.  In certain circumstances, courts, law enforcement agencies, regulatory agencies, or security authorities in those other countries may be entitled to access your Personal Data. <a class="readmore" id="34">[+]</a>
                                          <div id="rm34" style="display: none;">
                                          	Some of the non-EEA countries are recognized by the European Commission as providing an adequate level of data protection according to EEA standards (the full list of these countries is available <a href="https://ec.europa.eu/info/law/law-topic/data-protection/data-transfers-outside-eu/adequacy-protection-personal-data-non-eu-countries_en" target="_blank">here</a>.  For transfers from the EEA to countries not considered adequate by the European Commission, we have put in place adequate measures, such as standard contractual clauses adopted by the European Commission, to protect your Personal Data.  You may obtain a copy of these measures by clicking <a href="https://ec.europa.eu/info/law/law-topic/data-protection/data-transfers-outside-eu/model-contracts-transfer-personal-data-third-countries_en" target="_blank">here</a>.
                                          </div> ';
$lang['PrivacyPolicy.Link14'] = 'SENSITIVE PERSONAL DATA';
$lang['PrivacyPolicy.LinkContent14'] = 'Unless we specifically request it, we ask that you not send us, and you not disclose, any sensitive Personal Data (e.g., social security numbers, data related to racial or ethnic origin, political opinions, religion or other beliefs, biometrics or genetic characteristics, criminal background, or trade union membership) on or through the Services or otherwise to us. ';
$lang['PrivacyPolicy.Link15'] = 'THIRD-PARTY PAYMENT SERVICE';
$lang['PrivacyPolicy.LinkContent15'] = 'We may use a third-party payment service to process payments made through the Services.  If you wish to make a payment through the Services, your Personal Data will be collected by such third party and not by us, and will be subject to the third party’s privacy policy, rather than this Privacy Policy.  We have no control over, and are not responsible for, this third party’s collection, use and disclosure of your Personal Data.';
$lang['PrivacyPolicy.Link16'] = 'UPDATES TO THIS PRIVACY POLICY';
$lang['PrivacyPolicy.LinkContent16'] = 'The “<i>LAST UPDATED</i>” legend at the top of this Privacy Policy indicates when this Privacy Policy was last revised.  Any changes will become effective when we post the revised Privacy Policy on the Services.  Your use of the Services following these changes means that you accept the revised Privacy Policy. ';
$lang['PrivacyPolicy.Link17'] = 'CONTACTING US';
$lang['PrivacyPolicy.LinkContent17'] = 'Click <a href="https://www.sec.gov/Archives/edgar/data/21665/000002166518000006/exhibit2112312017.htm" target="_blank">here</a> to identify the controller responsible for collection, use, and disclosure of your Personal Data under this Privacy Policy.<br/><br/>  
                                        If you have any questions about this Privacy Policy, please contact <a type="button" class="consumerBtn" data-toggle="modal" data-target=".consumer_affairs">Consumer Affairs</a> or:
                                        <br/><br/>
                                        Colgate-Palmolive Company<br/>
                                        300 Park Avenue<br/>
                                        New York, NY 10022<br/>
                                        United States of America<br/>';
$lang['PrivacyPolicy.Link18'] = 'ADDITIONAL INFORMATION FOR INDIVIUDALS IN THE EUROPEAN ECONOMIC AREA (“EEA”)';
$lang['PrivacyPolicy.LinkContent18'] = 'You may lodge a complaint with a data protection authority for your country or region or where an alleged infringement of applicable data protection law has occurred.  A list of data protection authorities is available at <a href="http://ec.europa.eu/newsroom/article29/item-detail.cfm?item_id=612080" target="_blank">http://ec.europa.eu/newsroom/article29/item-detail.cfm?item_id=612080</a>.';
$lang['PrivacyPolicy.Date'] = 'LAST UPDATED: 25-May-2018';
