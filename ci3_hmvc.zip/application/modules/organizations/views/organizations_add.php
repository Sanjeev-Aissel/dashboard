<?php //
/**
 * Element page to add organization details
 * 
 * @package application.organization.add
 * @author Sanjeev K
 * @created: 09-02-2018
 */

$specialtyAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
//$currentController = $this->uri->segment(1);
//$currentMethod = $this->uri->segment(2);
//$contentPage = $this->uri->segment(3);
?>
<script src="<?php echo base_url(); ?>assets/js/chosen.jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url(); ?>assets/css/chosen.css" media="screen" rel="stylesheet">
<script>
$(document).ready(function(){
	// Setup form validation on the #register-form element
    $("#add_org").validate({
        // Specify the validation rules
        rules: {
            name: "required",
            institution_type: "required",
            specialty: "required",
            address1: "required",
            country_id: "required",
            email: {
      email: true
    },
    phone_number_primary: {
        phnumber : true
    }
        },
        
        // Specify the validation error messages
        messages: {
            name: "Required",
            institution_type: "Required",
            specialty: "Required",
            address1: "Required",
            country_id: "Required",
            email:"Invalid Email"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

    var phoneMsg = '';
    jQuery.validator.addMethod("phnumber", function (value, element) {      
    	  	                            
        if (value != "") {
        	var  phoneVal= document.getElementById("phone_type_primary").value;
           	if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")||(phoneVal=="Office Phone")){
                var regex =/^(?=.*[0-9])[-+0-9]+$/;     
                if(regex.test(value)){                	
                	var number = value.replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing                	                	
                	if(number.length>15){
                		phoneMsg ="Max 15 Digit";
                    	return false;
                	}	
                	phoneMsg = '' ;               	
                	return true;                	    	
                }else{
                	phoneMsg ="Invalid Phone Number";	               		
                 	return false;
                }               	
           	}else{  
           		if(phoneVal==''){            		
           			//phoneMsg = 'Select Phone Type';
           			$('#phone_type_loc').text("Select Phone Type");		
               		return false;
               	}
           		phoneMsg = '' ;
               	return true;
            }
        } else {            	
            return true;
        }
        
    }, function(params, element) {
    	  return phoneMsg;
    });
});
</script>
<style>
.form-horizontal .control-label {
    color: #626262;
}
.error {
   /*  background: #FBE3E4; */
    color: red;
    border-color: #FBC2C4;
}
</style>
<div class="container">
	<div class="row">
				<form id="add_org" class="form-horizontal" action="<?php echo base_url(); ?>organizations/save_org" role="form" method="post">
				<input type="hidden" name="id" value="<?php if(isset($orgDetails[0]['id'])) echo $orgDetails[0]['id']; else echo ''; ?>">
				<h4 class="page-header"><?php if(isset($orgDetails[0]['name'])) echo 'Edit'; else echo 'New';?> Organization</h4>
					<div class="form-group">
						<label class="col-sm-2 control-label">Organization Name <span class="error">*</span> :</label>
						<div class="col-sm-4">
							<input type="text"  name="name" id="name" class="form-control autocompleteInputBox" value="<?php if(isset($orgDetails[0]['name'])) echo $orgDetails[0]['name']; else echo ''; ?>" <?php echo $disabled ?> placeholder="Organization Name">
						</div>
						<label class="col-sm-2 control-label">Organization Type <span class="error">*</span> :</label>
						<div class="col-sm-4">
							<select  id="institution_type" class="form-control" name="institution_type" <?php echo $disabled ?>>
								<option value="">Select Institution</option>
                            <option <?php if (($orgDetails[0]['institution_type']) == "University/Hospital") echo "selected" ?> value="University/Hospital">University/Hospital</option>
                            <option <?php if (($orgDetails[0]['institution_type']) == "Association") echo "selected" ?> value="Association">Association</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Research :</label>
						<div class="col-sm-4">
							<select id="research" class="form-control" name="research" <?php echo $disabled ?>>
								<option value="">Select Research</option>
                            	<option <?php if (($orgDetails[0]['research']) == "Yes") echo "selected" ?> value="Yes">Yes</option>
                            	<option <?php if (($orgDetails[0]['research']) == "No") echo "selected" ?> value="No">No</option>
                        </select>
						</div>
						<label class="col-sm-2 control-label">CEO Name :</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="ceo_name" id="ceo_name" value="<?php if(isset($orgDetails[0]['ceo_name'])) echo $orgDetails[0]['ceo_name']; else echo ''; ?>" <?php echo $disabled ?> placeholder="CEO Name">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email Address :</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="email" id="email" value="<?php if(isset($orgDetails[0]['email'])) echo $orgDetails[0]['email']; else echo ''; ?>" <?php echo $disabled ?> placeholder="Email Address">
						</div>
						<label class="col-sm-2 control-label">Fax Number :</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="fax" id="fax" value="<?php if(isset($orgDetails[0]['fax'])) echo $orgDetails[0]['fax']; else echo ''; ?>" <?php echo $disabled ?> placeholder="Fax Number">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label" for="form-styles">Summary :</label>
						<div class="col-sm-10">
								<textarea class="form-control" name="background" id="orgBackground" rows="5" <?php echo $disabled ?>><?php echo $orgDetails[0]['background']; ?></textarea>
						</div>
					</div>
					<h4 class="page-header">Location</h4>
					<div class="form-group">
						<label class="col-sm-2 control-label">Address 1 <span class="error">*</span> :</label>
						<div class="col-sm-4">
							<input type="text" class="form-control required"  name="address1" id="address1"
                            <?php
                            if (isset($locationData)) {
                                echo "value='" . $locationData['address1'] . "'";
                            } else {
                                echo "value=''";
                            }
                            ?>
                                   maxlength="50" <?php echo $disabled ?> placeholder="Address">
							 <input type="hidden" name="org_location_id" id="org_location_id" value="<?php if(isset($locationData['id']) && $locationData['id'] >0) echo $locationData['id'];?>" />
						</div>
						<label class="col-sm-2 control-label">Address 2 :</label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="address2" id="address2"
                            <?php
                            if (isset($locationData)) {
                                echo "value='" . $locationData['address2'] . "'";
                            } else {
                                echo "value=''";
                            }
                            ?>
                                   maxlength="50" <?php echo $disabled ?> placeholder="Address">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Country <span class="error">*</span> :</label>
						<div class="col-sm-2">
							<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required form-control" <?php echo $disabled ?>>
								<option value="">Select Country</option>
								 <?php 
                                //$selectedCountryId	= $arrFirstCountry;
                                if(isset($locationData['country_id']) && $locationData['country_id']>0){
                                	$selectedCountryId	= $locationData['country_id'];
                                }
                                foreach ($arrCountries as $country) { ?>
                                    <option value="<?php echo $country['country_id']; ?>"
                                    <?php
                                    if ($selectedCountryId == $country['country_id'])
                                        echo "selected";
                                    ?>
                                    >
                                    <?php echo $country['country_name']; ?>
                                    </option>
                                <?php } ?>
							</select>
							<img id="loadingStates" src="<?php echo base_url() ?>assets/images/ajax-loader.gif" style="display:none"/>
						</div>
						<label class="col-sm-2 control-label">State / Province :</label>
						<div class="col-sm-2">
							<select  name="state_id" id="state_id" class="form-control" onchange="getCitiesByStateId();" <?php echo $disabled ?>>
								<option value="">Select State</option>
								<?php foreach ($arrStates as $state) { ?>
                                    <option value="<?php echo $state['state_id']; ?>" 
                                    <?php
                                    if (isset($locationData['state_id'])) {
                                        if ($state['state_id'] == $locationData['state_id']) {
                                            echo 'selected';
                                        }
                                    }
                                    ?>>
                                                <?php echo $state['state_name']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                            <img id="loadingCities" src="<?php echo base_url() ?>assets/images/ajax-loader.gif" style="display:none"/>
						</div>
						<label class="col-sm-2 control-label">City :</label>
						<div class="col-sm-2">
							<select name="city_id" id="city_id" class="form-control" <?php echo $disabled ?>>
								<option value="">Select City</option>
								<?php foreach ($arrCities as $city) { ?>
                                    <option value="<?php echo $city['city_id']; ?>" 
                                    <?php
                                    if (isset($locationData)) {
                                        if ($city['city_id'] == $locationData['city_id']) {
                                            echo 'selected';
                                        }
                                    }
                                    ?>>
                                                <?php echo $city['city_name']; ?>
                                    </option>
                                <?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Postal Code :</label>
						<div class="col-sm-2">
							<input type="text" name="postal_code" id="postal_code" class='form-control'
                            <?php
                            if (isset($locationData)) {
                                if ($locationData['postal_code'] != "") {
                                    echo 'value="' . $locationData['postal_code'] . '"';
                                }
                            }
                            ?>
                                  <?php echo $disabled ?> placeholder="Postal Code">
						</div>
						<label class="col-sm-2 control-label">Phone Number :</label>
						<div class="col-sm-2">
							<input type="text" name="phone_number_primary" maxlength="15" id="phone_number_primary" class='form-control'
                                <?php
                                if (isset($locationData)) {
                                    if ($locationData['phone_number_primary'] != "") {
                                        echo 'value="' . $locationData['phone_number_primary'] . '"';
                                    }
                                }
                                ?>
                                      <?php echo $disabled ?> placeholder="Phone Number">
						</div>
						<label class="col-sm-2 control-label">Phone Type :</label>
						<div class="col-sm-2">
							<select name="phone_type_primary" id="phone_type_primary" class="form-control" <?php echo $disabled ?>>
								<option value="">Select</option>
								<?php foreach ($arrPhoneType as $key=>$type){?>
						            	<option value="<?php echo $key?>" <?php if(isset($locationData['phone_type_primary']) && $locationData['phone_type_primary']==$key) echo "selected='selected'";?>><?php echo $type;?></option>
						            <?php }?>
							</select>
							 <div style="display:none;"><input type="checkbox" name="is_primary" value="1" checked="checked" <?php echo $disabled ?>/></div>
						</div>
					</div>
					<div class="clearfix"></div>
					<div class="form-group">
						<div class="col-sm-offset-5  col-sm-2">
							<button type="submit" name="submit" class="btn btn-primary btn-label-left">
							<span><i class="fa fa-clock-o"></i></span>
								Save
							</button>
							<button type="cancel" class="btn btn-default btn-label-left">
							<span><i class="fa fa-clock-o txt-danger"></i></span>
								Cancel
							</button>
						</div>
					</div>
				</form>
	</div>
</div>