<?php 
/**
 	* @Description : Contains fucntion required for Listing Log Activities
 	* @Author : Vinayak, Kishan Ravindra (00001111)
 	* @Since : 4.2
 	* @Package : application.view
 	* @Created : 13-6-2012
 	* @Refactored : 01-08-2017
**/
//$queued_js_scripts = array('kols/view_affiliations','highcharts 2.1.0','highchartsTheme','i18n/grid.locale-en','jquery.jqGrid.min','jquery.validate');
	$queued_js_scripts = array('i18n/grid.locale-en',
							   'jquery.jqGrid.min',
							   'jquery/jquery.validate1.9.min',
							   'jquery/jquery-ui-1.8.16.slider',
							   'jquery/jquery-ui-1.8.16.datepicket',
							   'CalendarControl');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
 ?>
 	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<script type="text/javascript">
	var urlFilters = null;
	<?php if(isset($urlString)){?>
	urlFilters = <?php echo $urlString ?>;
	<?php }?>
	
	var alllogActivities = "<?php echo lang("LogActivities.LogActivities");?>";
	jqgridIds	= new Array('allLogActivitesResultSet');
	jqgridMinWidth	= 1010;
	jqgridMaxWidth	= 1305;
		
	function allLogActivites(){
		var arrFilters = getFilterData();
		var fromDate = arrFilters[0];
		var toDate = arrFilters[1];
		var clientId = arrFilters[2];
		$("#allLogActivitesGridContainer").html("");
		$("#allLogActivitesGridContainer").html('<table id="allLogActivitesResultSet"></table><div id="allLogActivitesPager"></div>');
		jQuery("#allLogActivitesResultSet").jqGrid({
		   	url:'<?php echo base_url()?>client_user_log_activities/list_client_log_activities/'+fromDate+"/"+toDate+"/"+clientId,
			datatype: "json",
		 	colNames:["Id", "Username", "Email", "Created On", "OS", "Browser", "Status", "City", "State", "Country", "Page Visited"],
		   	colModel:[
						{name:'id',index:'id',search:false, width:25},
						{name:'username',index:'username',search:false},
						{name:'email',index:'email'},
						{name:'created_on',index:'created_on',search:false},
						{name:'os',index:'os', resizable:false, align: 'center'},
						{name:'browser',index:'browser', align: 'center'},
						{name:'status',index:'status', resizable:false,title: false, align: 'center',search:false},
						{name:'cityName',index:'cityName',search:false},
						{name:'regionName',index:'regionName',search:false},
						{name:'countryName',index:'countryName',search:false},
						{name:'page_visited',index:'page_visited',search:false, width:250},
		   	],
		   	rowNum:10,
		   	rownumbers: true,
			multiselect: false,
		   	autowidth: true, 
		   	loadonce:false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",	
		   	width:"100%",
		   	resizable:true,
		   	shrinkToFit: true,
		   	pager: '#allLogActivitesPager',
		   	mtype: "POST",
		   	sortname: 'id',
		    viewrecords: true,
		    sortorder: "desc",
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:alllogActivities,
		   	rowList:paginationValues,
		});
		jQuery("#allLogActivitesResultSet").jqGrid('navGrid','#allLogActivitesPager',{edit:false,add:false,del:false,search:false,refresh:false});
		jQuery("#allLogActivitesResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
			$(".ui-search-toolbar input[type='text']").each(function(){
				if($(this).val() == 'Search')
					$(this).val("");
		    });
		}});
	}

	$(document).ready(function(){
		allLogActivites();
	});

	// @Author : Kishan Ravindra (00001111)
	// @Description : Exports Log Activities in Excel Format
	function clearFilters(){
		$('#clientsCombo').val("<?php echo $this->session->userData('client_id'); ?>");
		$('#monthlyreport').val("<?php echo date('m/d/Y');?>");
		$('#monthto').val("<?php echo date('m/d/Y');?>");
		$('#monthto').attr("disabled",true);
		allLogActivites();
	}

	//SYNCHRONOUS - AJAX function to Handle CRUD
	function smartCRUD(clientData, handlerUrl){
		var respObj = false;
		$.ajax({
			url: handlerUrl,
			data: clientData,
			async:false,
			type:'POST',
			success: function(serverResp){
				respObj = serverResp;
			}
		});
		return respObj;
	}
	
	//Function to get Client Details (if 'id' matches : matched records, else : all records)
	function getClientDetails(id){
		url = '<?php echo base_url()?>master_data_controller/getClientDetails';
		data = "id="+id;
		var response = smartCRUD(data,url);
		return JSON.parse(response);
	}

	//Initializing Filter Components
	$(function(){
		var isSelected = "";
		$.each(getClientDetails(null), function(key, value) {
			isSelected = value.id == <?php echo $this->session->userData('client_id'); ?> ? "selected" : "";
			$('#clientsCombo').append("<option value="+value.id+" "+isSelected+">"+value.name+"</option>");
		});
		
		$('#monthlyreport').datepicker({
			changeMonth: true,
			changeYear: true,
			maxDate: new Date(),
			onSelect: function(){
				activateToDate(this);
			}
		});
		$('#monthto').datepicker({
			changeMonth: true,
			changeYear: true,
			maxDate: new Date()
		});
	});

	//Activates To Date Component
	function activateToDate(thisPtr){
		$('#monthto').attr("disabled",false);
		$('#monthto').datepicker("option","minDate", thisPtr.value);
		$('#monthto').val("<?php echo date('m/d/Y');?>");
	}

	//Captures all Filters Data and returns in valid format
	function getFilterData(){
		var fromDate = $("#monthlyreport").val();
		var toDate = $("#monthto").val();
		var clientId = $('#clientsCombo').val();
		var isValidPattern = /^(\d{2})[/](\d{2})[/](\d{4})$/;
		fromDate = fromDate.search(isValidPattern) >= 0 ? fromDate.split("/")[2]+"-"+fromDate.split("/")[0]+"-"+fromDate.split("/")[1] : 0;
		toDate =  toDate.search(isValidPattern) >= 0 ? toDate.split("/")[2]+"-"+toDate.split("/")[0]+"-"+toDate.split("/")[1] : 0;
		var arrFilters = new Array();
		arrFilters.push(fromDate);
		arrFilters.push(toDate);
		arrFilters.push(clientId);
		return arrFilters;
	}
	
	function export_logs_to_excel(){
		$('#progressContent').html("Processing, Please Wait...");
		$('#progressContainer').dialog(getModalLayout('Process Status'));
		var arrFilters = getFilterData();
		var fromDate = arrFilters[0];
		var toDate = arrFilters[1];
		var clientId = arrFilters[2];
		var handlerURL = '<?php echo base_url()?>client_user_log_activities/export_log_activities/'+fromDate+'/'+toDate+'/'+clientId;
		$.ajax({
			success: function(serverResp){
				window.location.href = handlerURL;
				setTimeout(function(){ $('#progressContent').html("You are safe to close the dialog now. File will be the downloaded shortly."); },3000);
			},
			error: function(){
				$('#progressContent').html("Failed to Handle the Request");
			}
		});
	}

	function getModalLayout(headerTitle){
		var modalBoxLayout = {
			title: headerTitle,
			modal: true,
			position: ['center', 90],
			resizable: false,
		}
		return modalBoxLayout;
	};
	
	</script>
	<div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
		<div class="exportOptionsContainer">
			<ul class="pageRightOptions">
				<li>
					<label for=clientsCombo>Client :</label>
					<select name="clientsCombo" id="clientsCombo">
						<option value=''>All Clients</option>
					</select>&nbsp;
				</li>
				<li>
					<label for=monthlyreport>Month From :</label>
					<input type="text" name="monthlyreport" value="<?php echo date('m/d/Y');?>" id="monthlyreport" placeholder="Click to select" readonly/>
					<label for=monthlyreport>To:</label>
					<input type="text" name="monthto" value="<?php echo date('m/d/Y');?>" id="monthto" placeholder="Click to select" readonly disabled/>
					<input type="button" value="Apply Filter" id="filterbutton" onclick="allLogActivites()" />
					<input type="button" value="Reset Filters" id="filterbutton" onclick="clearFilters()" />
				</li>
				<li>
					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_logs_to_excel();">
						<a href="#" rel="tooltip" data-original-title="Export Log Activity Details into Excel format">&nbsp;</a>
					</div>
				</li>
			</ul>
		</div>
	</div>
	<div>
		<div class="gridWrapper" id="allLogActivitesGridContainer">
			<table id="allLogActivitesResultSet"></table>
			<div id="allLogActivitesPager"></div>
		</div>		
	</div>
	<!-- Container for the modal box -->
	<div id="progressContainer">	
		<span id="progressContent"></span>
	</div>
	<!-- End of Container for the modal box' -->