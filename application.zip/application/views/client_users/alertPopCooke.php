<?php
/*	Alert Pop for cooke data confirm
 *  @author Vinod H
 *
 */
?>
<script type="text/javascript" src="http://localhost/pfizer/js/jquery/jquery.validate1.9.min.js"></script>	
<style>
.button-bar{
    text-align: center;
}
.button-bar input[type=submit]{
    font-size: 20px;  
}

}
ul li{
	overflow: hidden;
    clear: left;
    position: relative;
	padding: .5em .2em;
}
.input-radio{
	left: -10000px;
	position: absolute;
    margin: 0;
	top: .7em;
	vertical-align: middle;
}
ul {
    list-style: none;
    margin: 0;
    padding: 0;
    list-style: none;
}
</style>
<!-- jQuery Core File -->
	
<script type="text/javascript">
	$(document).ready(function(){
		$('.ui-dialog-titlebar-close').remove();
        $('#alertSave').click(function(){
    		var agreeValue = $('input[name=agree]:checked').val();
    		if(agreeValue == undefined){
    			jAlert('Please select Agree / Not Agree');
    			return false;
    		}else{
    			if(agreeValue == 'agree'){
    				$.ajax({
			            url: '<?php echo base_url() ?>client_users/saveCookeConfirmation',
			            type: 'post',
			            dataType: 'json',
			            beforeSend: function(){
			            	$('.msgBox').removeClass('success');
			                $('.msgBox').addClass('notice');
			                $('.msgBox').show();
			                $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
			            },
			            success: function (returnData) {
				            if(returnData.status == true){
					            $('.msgBox').html('Cooke data saved successfully');
	                            $('.msgBox').fadeOut(1500);
	                            $("#alertPopForCooke").dialog("close");
				            }else{
				            	$('.msgBox').html('Error in saving cookie data');
	                            $('.msgBox').fadeOut(1500);
				            }
			            }
			    	});
			    	return false;
				}else{
					window.location	= "<?php echo base_url().'login/logout'; ?>";
				}
    		}
        });
	});
	
</script>
<div class="row">
<div class="msgBox"></div>
<h1>Cooke Session Data Confirmation</h1>
<p>
Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
</p>
<br/>
<ul>
<li>
	<label>
	<input type="radio" name='agree' value="agree"><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i> 
	<span>Agree</span>
</li><br/>
<li>
	<label>
	<input type="radio" name='agree' value="not_agree"><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i> 
	<span>Not Agree</span>
</li>
</ul>
<div class="button-bar">
	<input type="submit" data-toggle="tooltip" title="Next" id="alertSave" value="Next">
</div>
</div>

