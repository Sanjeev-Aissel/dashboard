<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('i18n/grid.locale-en',
    'jquery.jqGrid.min'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>css/themes/ui.jqgrid.css" />
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#coachingsList{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    .buttonsWarpper{
        float: right;
        width: 266px;
    }
    .gridWrapper {
        width: 100%;
    }
  

<?php if(IS_IPAD_REQUEST == 1){ ?>
		.tabsContainer li{
			font-size: 12px;
		}
        #load_listCustomerResultSet{
            display:none !important;
        }
         .tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
        <?php } else { ?>
           .excelExportIcon {
    float: right;
    margin-right: 20px;
}
 <?php } ?>
</style>
<script type="text/javascript">
    var action = "<?php echo lang("Overview.Action"); ?>";
    jqgridIds = new Array('kolsProfileScore','listKolsByActivityReportResultSet');

    var lastRequestXHR;
    function cancelLastRequest(){
            lastRequestXHR.abort();
            $("#applyFilter").val("Apply Filters");
            $("#applyFilter").attr("onclick","reloaReport();");
    }
    function listRecordsPerPage(maxRecords, increament) {
        var rowList = new Array();
        for (i = increament; i <= maxRecords; i += increament) {
            rowList.push(i);
        }
        return rowList;
    }

    /** 
     * Show/Hide the Search Tool Bar in the JQGrid
     */
    function toggleSearchToolbar() {
        if (jQuery(".ui-search-toolbar").css("display") == "none") {
            jQuery(".ui-search-toolbar").css("display", "");
        } else {
            jQuery(".ui-search-toolbar").css("display", "none");
        }
    }
    ;

    function filterCurrentReport(data) {
        list_customer_grid(data);
    }

    function list_customer_grid(data) {
//            alert(JSON.stringify(data));
        var ele = document.getElementById('customerSeenList');
        var gridWidth = ele.clientWidth -15;
        jqgridMinWidth = gridWidth;
        $('#customerSeenList').html('');
        $('#target_kols').html('');
        $('#customerSeenList').html('<div class="gridWrapper"><div id="listCustomer"></div><table id="listCustomerResultSet"></table><div>');
        jQuery("#listCustomerResultSet").jqGrid({
            url: '<?php echo base_url(); ?>reports/list_customer_grid',
            datatype: "json",
            colNames: ['Id', '', 'MSL/MML Name', 'Team Name','All Seen Target', 'Target', 'Seen', 'Not Seen', 'One-Off', '', '', '','',''],
            colModel: [
                {name: 'id', index: 'id', hidden: true, search: false, resizable: false, resizable:false},
                {name: 'is_activated', index: 'is_activated', hidden: true, search: true, width: 50},
                {name: 'username', index: 'username', search: true, width: 100},
                {name: 'group_name', index: 'group_name', width: 80, search: true},
                {name: 'overAllSeenTarget',index: 'overAllSeenTarget', search: false, width: 80, sorttype:'int'},
                {name: 'target',index: 'target', search: false, width: 50, sorttype:'int'},
                {name: 'targetseen', index: 'targetseen', width: 50, search: false,sorttype:'int'},
                {name: 'notseen', index: 'notseen', search: false, width: 80, sorttype:'int'},
                {name: 'OneOff', index: 'OneOff', search: false, width: 80, sorttype:'int'},
                {name: 'target_kols', index: 'target_kols', hidden: true, search: false, resizable: false, sorttype:'int'},
                {name: 'allseen_kols', index: 'allseen_kols', hidden: true, search: false, resizable: false, sorttype:'int'},
                {name: 'targetseen_kols', index: 'targetseen_kols', hidden: true, search: false, resizable:false,sorttype:'int'},
                {name: 'overAllSeenTargetkols', index: 'overAllSeenTargetkols', hidden: true, search: false, resizable:false,sorttype:'int'},
                {name: 'allseenOverAll_kols', index: 'allseenOverAll_kols', hidden: true, search: false, resizable:false,sorttype:'int'},
            ],
            postData: data,
            rowNum: 10,
            multiselect: false,
            rownumbers: true,
            autowidth: false,
            width: gridWidth,
            loadonce: true,
            ignoreCase: true,
            hiddengrid: false,
            height: "auto",
            pager: '#listCustomer',
            mtype: "POST",
            sortname: 'username',
            viewrecords: true,
            sortorder: "desc",
            shrinkToFit: true,
            jsonReader: {repeatitems: false, id: "0"},
            caption: "Customer Seen",
            loadBeforeSend: function (xhr) { 
	    	lastRequestXHR = xhr; 
	    },
            gridComplete: function () {
                $("#applyFilter").val("Apply Filters");
	    	$("#applyFilter").attr("onclick","reloaReport();");
                //Get array of id'f from jqgrid			   
                var arrIds = jQuery("#listCustomerResultSet").jqGrid('getDataIDs');
                var rowData = '';
                // Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row

                for (var i = 0; i < arrIds.length; i++) {
                    var id = arrIds[i];
                    var rowData = jQuery('#listCustomerResultSet').jqGrid('getRowData', id);
                    var targetseen = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'targetseen');
                    var target = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'target');
                    var OneOff = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'OneOff');
                    var notseen = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'notseen');
                    var overAllSeenTarget = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'overAllSeenTarget');
                    if (target != 0) {
                     var   target_kols_link =  "<a href='#' class='link' onclick='getAllKols("+id+","+"1"+");return false;'  >" +
							            target + "</a>";
                      jQuery("#listCustomerResultSet").jqGrid('setRowData', arrIds[i], {target: target_kols_link});
                    }
                    if (targetseen != 0) {
                       var target_kols_link =  "<a href='#' class='link' onclick='getAllKols("+id+","+"2"+");return false;'  >" +
							            targetseen + "</a>";
                      jQuery("#listCustomerResultSet").jqGrid('setRowData', arrIds[i], {targetseen: target_kols_link});
                    }
                    if (OneOff != 0) {
                       var target_kols_link =  "<a href='#' class='link' onclick='getAllKols("+id+","+"3"+");return false;'  >" +
							            OneOff + "</a>";
                      jQuery("#listCustomerResultSet").jqGrid('setRowData', arrIds[i], {OneOff: target_kols_link});
                    }
                    if (notseen != 0) {
                       var target_kols_link =  "<a href='#' class='link' onclick='getAllKols("+id+","+"4"+");return false;'  >" +
							            notseen + "</a>";
                      jQuery("#listCustomerResultSet").jqGrid('setRowData', arrIds[i], {notseen: target_kols_link});
                    }
                    if (overAllSeenTarget != 0) {
                       var target_kols_link =  "<a href='#' class='link' onclick='getAllKols("+id+","+"5"+");return false;'  >" +
							            overAllSeenTarget + "</a>";
                      jQuery("#listCustomerResultSet").jqGrid('setRowData', arrIds[i], {overAllSeenTarget: target_kols_link});
                    }
                }
                var postParams = $('#listCustomerResultSet').getGridParam("postData");
                //alert(postParams.toSource());
                postParams = JSON.stringify(postParams);
                $("#filterDataCustomer").val(postParams);
                jQuery("#listCustomerResultSet").jqGrid('navGrid', 'hideCol', "id");
                //Initialize the tooltips
                initializeCustomToolTips();

            },
            rowList: paginationValues
        });
        jQuery("#listCustomerResultSet").jqGrid('navGrid', '#listCustomer', {edit: false, add: false, del: false, search: false, refresh: false});
        //Toolbar search bar below the Table Headers
        jQuery("#listCustomerResultSet").jqGrid('filterToolbar', {stringResult: true, searchOnEnter: false, defaultSearch: "cn"});
        //Toggle Toolbar Search 
        jQuery("#listCustomerResultSet").jqGrid('navButtonAdd', "#listCustomer", {caption: "Search", buttonicon: "ui-icon-search", title: "Toggle Search",
            onClickButton: toggleSearchToolbar
        });
        <?php if (!IS_IPAD_REQUEST) { ?>
        var buttonsText = "<div class='title-bar-actions'>";
            buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel_customer_seen();return false;' >	<a rel='tooltip' href='#' title='Export Customer Seen Details into Excel format'>&nbsp;</a>	</div>";
            buttonsText += "</div>";
        <?php } else { ?>
        var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
            buttonsText += '<input type="button" value="Export excel as email" onclick="export_excel_customer_seen();" class="toggle-button" style="margin-top:-3px;">';
            buttonsText += "</div>";
        <?php } ?>        
	$("#customerSeenList .ui-jqgrid-titlebar").append(buttonsText);
        jqgridIds	= new Array('listCustomerResultSet');	
    }

    $(document).ready(function () {
//		list_customer_grid();
    });

    function getAllKols(id,selectedCol) {
        var selectedGridColName;
        $('html, body').animate({
            scrollTop: $("#target_kols").offset().top
        }, 1000);
        var target_kols = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'target_kols');
        var targetseen_kols = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'targetseen_kols');
        var allseen_kols = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'allseen_kols');
        var username = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'username');
        var group_name = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'group_name');
        var overAllSeenTargetkols = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'overAllSeenTargetkols');
        var allseenOverAll_kols = jQuery('#listCustomerResultSet').jqGrid('getCell', id, 'allseenOverAll_kols');
        var data = {};
        if(selectedCol==1){
            data['kolIds'] = target_kols;
            selectedGridColName="Target";
        }
        if(selectedCol==2){
            data['kolIds'] = targetseen_kols;
            selectedGridColName="Seen";
        }
        if(selectedCol==3)
        { 
            data['overAllSeenTargetkols'] = overAllSeenTargetkols; 
            data['allseenOverAll_kols'] = allseenOverAll_kols; 
            selectedGridColName="One-off";
        }
        if(selectedCol==4)
        { 
            data['target_kols'] = target_kols;
            data['overAllSeenTargetkols'] = overAllSeenTargetkols; 
            selectedGridColName="Not Seen";
        }
        if(selectedCol==5){
            data['kolIds'] = overAllSeenTargetkols;
            selectedGridColName="OverAll Seen";
        }
        var caption=""+" "+username+", "+group_name+", "+selectedGridColName;
        var ele = document.getElementById('target_kols');
        var gridWidth = ele.clientWidth -15;
        jqgridMinWidth = gridWidth;
        $('#target_kols').html('');
        $('#target_kols').html('<div class="gridWrapper"><div id="listCustomertarget_kols"></div><table id="listCustomertarget_kolsResultSet"></table><div>');
        jQuery("#listCustomertarget_kolsResultSet").jqGrid({
            url: '<?php echo base_url(); ?>reports/get_target_kols',
            datatype: "json",
            colNames: ['Id', '<?php echo lang("HCP");?> Name', 'Specialty', 'State', 'City', 'Phone'],
            colModel: [
                {name: 'id', index: 'id', hidden: true, search: false, resizable: false, resizable:false},
                {name: 'kolname', index: 'kolname', search: true, width: 100},
                {name: 'specialty_name', index: 'specialty_name', search: true, width: 100},
                {name: 'Region', index: 'Region', width: 50, search: true},
                {name: 'City', index: 'City', width: 50, search: true},
                {name: 'primary_phone', index: 'primary_phone', width: 50, search: true},
            ],
            postData: data,
            rowNum: 10,
            multiselect: false,
            rownumbers: true,
            autowidth: false,
            width: gridWidth,
            loadonce: true,
            ignoreCase: true,
            hiddengrid: false,
            height: "auto",
            pager: '#listCustomertarget_kols',
            mtype: "POST",
            sortname: 'username',
            viewrecords: true,
            sortorder: "desc",
            shrinkToFit: true,
            jsonReader: {repeatitems: false, id: "0"},
            caption: caption,
            gridComplete: function () {
 var postParams = $('#listCustomertarget_kolsResultSet').getGridParam("postData");
                //alert(postParams.toSource());
                postParams = JSON.stringify(postParams);
                $("#filterData").val(postParams);
            },
            rowList: paginationValues
        });
        jQuery("#listCustomertarget_kolsResultSet").jqGrid('navGrid', '#listCustomertarget_kols', {edit: false, add: false, del: false, search: false, refresh: false});
        //Toolbar search bar below the Table Headers
        jQuery("#listCustomertarget_kolsResultSet").jqGrid('filterToolbar', {stringResult: true, searchOnEnter: false, defaultSearch: "cn"});
        //Toggle Toolbar Search 
        jQuery("#listCustomertarget_kolsResultSet").jqGrid('navButtonAdd', "#listCustomertarget_kols", {caption: "Search", buttonicon: "ui-icon-search", title: "Toggle Search",
            onClickButton: toggleSearchToolbar
        });
                        //Add action button in the title bar
        <?php if (!IS_IPAD_REQUEST) { ?>
	var buttonsText = "<div class='title-bar-actions'>";
		buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel();return false;' >	<a rel='tooltip' href='#' title='Export OL Detail into Excel format'>&nbsp;</a>	</div>";
		buttonsText += "</div>";
         <?php } else { ?>
            var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
                buttonsText += '<input type="button" value="Export excel as email" onclick="export_excel();" class="toggle-button" style="margin-top:-3px;">';
                buttonsText += "</div>";
    <?php } ?> 
	$("#target_kols .ui-jqgrid-titlebar").append(buttonsText);
    }
    function export_excel(){
            

            var excelFilters = '';


            

        

                $(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

                    if($(this).val() != ''){

                        var filterName = $(this).attr('name');

                        var filterValue = $(this).val();

                        excelFilters += filterName+" : "+filterValue+",";

                    }
//                                        alert(excelFilters);

                });

                //$("#excel-filters").val(excelFilters);

                var selectedOPtion = $(".ui-pg-selbox").val();

                $(".ui-pg-selbox option:last").attr('selected','selected');

                $('.ui-pg-selbox').trigger('change');

                if($("#listCustomertarget_kolsResultSet").html() != null )

                    var arrIds = jQuery("#listCustomertarget_kolsResultSet").jqGrid('getDataIDs');

                else

                    var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//            if($('#orgIntaerctionContainer').css('display')!='block'){
//
//            
//
//                $('#ids').val(arrIds);
//
//            }


            


        
               $('#ids').val(arrIds);
            $("#excel-filters").val(excelFilters);

        //    return false;

             <?php if (!IS_IPAD_REQUEST) { ?>
                     $('#export').submit();
            <?php } else { ?>
                      var data= $("#export").serialize();
                           sendMail(data,"customerSeenKols");
            <?php } ?>


            $(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

            $('.ui-pg-selbox').trigger('change');

        }
        
        
        function export_excel_customer_seen(){


            

            var excelFilters = '';


            

        

                $(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

                    if($(this).val() != ''){

                        var filterName = $(this).attr('name');

                        var filterValue = $(this).val();

                        excelFilters += filterName+" : "+filterValue+",";

                    }
//                                        alert(excelFilters);

                });

                //$("#excel-filters").val(excelFilters);

                var selectedOPtion = $(".ui-pg-selbox").val();

                $(".ui-pg-selbox option:last").attr('selected','selected');

                $('.ui-pg-selbox').trigger('change');

                if($("#listCustomerResultSet").html() != null )

                    var arrIds = jQuery("#listCustomerResultSet").jqGrid('getDataIDs');

                else

                    var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//            if($('#orgIntaerctionContainer').css('display')!='block'){
//
//            
//
//                $('#ids').val(arrIds);
//
//            }


            


        
               $('#ids_customer').val(arrIds);
            $("#excel-filters").val(excelFilters);

        //    return false;

           
            <?php if (!IS_IPAD_REQUEST) { ?>
                     $('#exportCustomerSeen').submit();
            <?php } else { ?>
                      var data= $("#exportCustomerSeen").serialize();
                           sendMail(data,"customerSeen");
            <?php } ?>
            $(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

            $('.ui-pg-selbox').trigger('change');

        }
         function sendMail(data,gridType){
             var formUrl;
             if(gridType=="customerSeen"){
                            formUrl="<?php echo base_url()?>reports/send_email_for_export_reports/Customer_Seen";
                        } else {
                            formUrl= "<?php echo base_url()?>reports/send_email_for_export_reports/Customer_Seen_kol";
                        }
        alert("Excel has been mailed successfully.");
      $.ajax({
                           url:formUrl,
                            dataType: "json",
                            data: data,
                            type: "POST",
                            success: function (responseText) {
                           
                            },
                            complete: function () {
                           
                            }
                    });               
    }
</script>
<form action="<?php echo base_url()?>reports/customer_seen_kol_export/" method='post' id="export">
		<input type="hidden" id="ids" name="customer_seen_kol" value=""></input>
                <input type="hidden" id="filterData" name="filter" value=""></input>
                <!--<input type="hidden" name="filters" value="" id="excel-filters" />-->
	</form>
<form action="<?php echo base_url()?>reports/customer_seen_export/" method='post' id="exportCustomerSeen">
		<input type="hidden" id="ids_customer" name="customer_seen" value=""></input>
                <input type="hidden" id="filterDataCustomer" name="filter" value=""></input>
                <!--<input type="hidden" name="filters" value="" id="excel-filters" />-->
	</form>
<?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a>
	</div>
<?php }?>
<div id="container">

    <div class="tabsWrapper" id="test">
        <ul class="tabsContainer">
            <li class="current" name="tab0"><a id="list" href="#">Report</a></li>
            <!--<li name="tab1"><a id="chart" href="#">chart</a></li>-->
        </ul>
        <div class="tabsContent">
            <div class="tab0 tabContent" style="display:block;">
                <!--					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;top: -27px;">
                                                                <a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
                                                        </div>-->
                <div id="customerSeenList" class="clear">Please select filter for report</div>
                <br/>
                 
                <div id="target_kols" class="clear"></div>
            </div>



        </div>
    </div>

    <!--    <div id="mirfList" class="clear">Select Filters for report</div>-->

</div>
