<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
      
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#medContainer{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    table caption{
        background:#ececec;
    }
    /*	table {
            border: 1px solid #DDDDDD;
        }*/
    table th{
        vertical-align: top;
    }
    tr.tableSubHeader th{
        background-color:#ececec;
    }
    . {
        background-color: #ececec;
    }
    div.deleteIcon{
        float: none;
    }
    .type, .product, .topic{
        width:100%;
    }
</style>
<script>

function back(){
    
        window.location = base_url+"/coachings/list_compliance/";
}

</script>

<button value="Back To List Field Compliance Monitoring" onclick="back();">Back To List Field Compliance Monitoring</button>
<div class="pdfExportIcon sprite_iconSet" style="float:right" >
   
                            <form action="" id="coachingPdf" method="post">
                                <a rel="tooltip" href="<?php echo base_url();?>coachings/export_pdf_compliance/<?php echo $id; ?>" data-original-title="Export View into PDF format">&nbsp;</a>
                            </form>
                        </div>
<div id="medContainer">
	<div id="addFormWrapper">	
    	<h5 class="heading">Compliance Monitoring</h5>
    </div>
    <table>
        <tr class="">
            <th></th><th>Compliance ID: </th>
            <td colspan="2"><?php  echo $arrData['generic_id'] ?></td>
        </tr>
        <tr class="">
            <th>01)</th><th>Name of FMA: </th>
            <td colspan="2"><?php  echo $arrData['monitored_by_name']; ?></td>
        </tr>
          <tr class="evenRow">
            <th>02)</th><th>Name of Monitor:</th>
            <td colspan="2"><?php 
                                   echo $arrData['manager_name'];
                                
           ?></td>
        </tr>
        <tr class="evenRow">
            <th>03)</th><th style="width:315px;">Date of Visit:</th>
            <td colspan="2"><?php echo $arrData['date']; ?></td>
        </tr>
        <tr class="">
            <th>04)</th><th>Location(s) of interactions observed during visit</th>
            <td colspan="2">
                <?php
                $arrLocationData = explode(', ', $arrData['location']);
                $separator = '';
                foreach ($arrLocationData as $key => $value) {
                    echo $separator . $arrLocations[$value];
                    $separator = ', ';
                }
                ?>
            </td>
        </tr>
      
        
        <tr class="evenRow">
            <th>05)</th>
            
                <th><?php echo lang("HCP");?>(s) in Attendance:</th>
                <td colspan="2"><?php
                    foreach ($arrKOLs as $key => $arrRow) {
                        //echo $arrRow['first_name'] . ' ' . $arrRow['middle_name'] . ' ' . $arrRow['last_name'] . '<br />';
                        echo $this->common_helpers->get_name_format($arrRow['first_name'],$arrRow['middle_name'],$arrRow['last_name']). '<br />';
                    }
                    ?></td>
            
              
               
               
          
        </tr>
              <tr class="evenRow">
            <th></th>
            
                <th>ORG(s) in Attendance:</th>
                <td colspan="2"><?php
                    foreach ($arrOrgs as $key => $arrRow) {
                        echo $arrRow['name'] . '<br />';
                    }
                    ?></td>
            
              
              
               
          
        </tr>
        <tr class="">
            <th></th><th>Location:</th>
            <td colspan="2"><?php  foreach ($arrStates as $key => $arrRow) {
                        if($arrRow["state_id"]==$arrData["state_id"])
                            echo "<b>State:</b>&nbsp;".$arrRow["state_name"];
                    }
                    foreach ($arrCity as $key => $arrRow) {
                        if($arrRow["city_id"]==$arrData["city_id"])
                            echo "<b>&nbsp;&nbsp;City:</b>&nbsp;".$arrRow["city_name"];
                    }
                    ?> </td>
        </tr>
        <tr class="">
            <th>06)</th><th>Interaction Category:</th>
            <td colspan="2"><?php echo $arrData['interaction_mode']; ?></td>
        </tr>
        <tr class="evenRow">
            <th>07)</th><th>Purpose of Visit</th>
            <td colspan="2"></td>
        </tr>
        <tr class="evenRow">
            <th></th>
            <td colspan="3">
                <table style="margin-top:5px;">
                    <caption style="font-weight: bold;">Primary Purpose of Visit: </caption>
                    <tr class="tableSubHeader">
                        <th style="width:25%;">Product</th><th style="width:25%;">Type</th><th style="width:50%;">Topic</th><th></th>
                    </tr>
                    <?php 
                    foreach ($arrTopics as $key => $value) {
                       
                            ?>

                            <tr>
                                 <td><?php foreach($arrProductInt as $products ){
                                    if($products["id"]==$value['product_id'])
                                        echo $products['name']; 
                                
                                    
                                    
                                } ?></td>
                                <td><?php foreach($arrTypeInt as $types ){
                                    if($types["id"]==$value['type_id'])
                                        echo $types['name']; 
                                
                                    
                                    
                                }
                                
                                
                                ?></td>
                              
                                <td><?php  foreach($arrTopicInt as $intTopics ){
                                    if($intTopics["id"]==$value['topic_id'])
                                        echo $intTopics['name']; 
                                
                                    
                                    
                                }  ?></td>
                                <td></td>
                            </tr>
                        <?php
                        
                    }
                    ?>
                </table>
<!--                <table style="margin-top:5px;">
                    <caption style="font-weight: bold;">Additional Topic(s): </caption>
                    <tr class="tableSubHeader">
                        <th style="width:25%;">Type</th><th style="width:25%;">Product</th><th style="width:50%;">Topic</th><th></th>
                    </tr>
                    <?php
                    foreach ($arrTopics['is_additional_topic'] as $key => $value) {
                        if ($value == 1) {
                            ?>

                            <tr>
                                <td><?php echo $arrTopics['types'][$key]; ?></td>
                                <td><?php echo $arrTopics['product_names'][$key]; ?></td>
                                <td><?php echo $arrTopics['topic_names'][$key]; ?></td>
                                <td></td>
                            </tr>
                        <?php
                        }
                    }
                    ?>
                </table>-->
            </td>
        </tr>
        <tr class="">
            <th>08)</th><th>Off-Label Inquiry:</th>
            <td><?php echo ucfirst($arrData['off_label_inquiry']); ?></td>
            <td></td>
        </tr>
        <tr class=" toggleOffLabelInquiry">
            <th></th><th>a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; was the inquiry unsolicited?:</th>
            <td><?php echo ucfirst($arrData['inquiry_unsolicited']); ?></td>
            <td></td>
        </tr>
        <tr class=" toggleOffLabelInquiry">
            <th></th><th>b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Was MSL/MML Response consistent with
                company policy?:</th>
            <td><?php echo ucfirst($arrData['response_consistancy']); ?></td>
            <td></td>
        </tr>
        <tr class="evenRow">
            <th>09)</th><th>Did you identify any compliance violations?:</th>
            <td><?php echo ucfirst($arrData['compliance_violation']); ?></td>
            <td></td>
        </tr>
            <?php if($arrData['violation_description']!=''){?>
        <tr class=" toggleViolationDescription">
            <th>10)</th><th colspan="3">If the answer to question 09 is "yes", please explain
                and ensure the Director or Vice President informs the
                Chief Compliance Officer within two (2) business days.</th>
        </tr>
        <tr class=" toggleViolationDescription"><th></th>
            <td colspan="3" >
<?php echo $arrData['violation_description']; ?>
            </td>
            </tr><?php }?>
        <tr class=" toggleViolationDescription"><th></th>
        	<td><label>Recorded By:</label>&nbsp;&nbsp;&nbsp;<?php echo $arrData['created_user']; ?></td>
           	<td><label>Recorded On:</label>&nbsp;&nbsp;&nbsp;<?php echo $arrData['compliance_violated_by_date']; ?></td>
        </tr>
    </table>

</div>
