<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css">
<?php echo $this->load->view('elements/favicon');?>
<link rel="stylesheet" href="<?php echo base_url();?>css/jquery.alerts.css">
<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
<script src="<?php echo base_url();?>js/jquery.alerts.js"></script>
<script   src="https://code.jquery.com/jquery-3.2.1.min.js"   integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="   crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">

<style type="text/css">
	.container-fluid{
		border: 1px solid;
		width: 100%;
	}
	#header{
		height: 50px;
		border-bottom: 1px solid;
	}
	#content{
		min-height: 500px;
		border-bottom: 1px solid;
	}
	#footer{
		height: 50px;
		border-bottom: 1px solid;
	}
	#leftSideBar{
		border-right: 1px solid;
		height: 100%;
		min-height: 400px;
	}
	#rightSideBar{
		border-left: 1px solid;
	}
	body{
	margin-top: 50px;
		font-family: Arial;
    font-size: 14px;
    font-weight: 400;
    color: #000000;
    background-color: rgba(206,206,206,1.00);
	}
	.wrapper{
		font-family: Arial;
	    font-weight: 400;
	    font-size: 14px;
	    background-color: rgba(240,240,240,1.00);
	}
	.header{
		color: #f0f0d7;
    	background-color: rgba(0,61,165,1.00);
    	position: static;
    	padding: 0;
	}
	.header img{
		 vertical-align: middle;
		 max-width: 13%;
    	 display: block;
    	 margin: 0 auto;
	}
	.header h1{
		font-family: Montserrat, sans-serif;
	    font-weight: 400;
	    font-size: 36px;
	    padding: 30px;
    	margin: 0;
    	text-align: center;
	}
	.content{
		width: 100%;
		padding: 1.5em 30px 2em;
    	margin: auto;
	}
	.content_title{
	    overflow: hidden;
        text-align: center;
        font-size: 24px;
        border-bottom: 1px solid #d8d8d8;
	    border-top-color: rgba(240,240,240,1.00);
	    border-right-color: #000000;
	}
	.content_title .instructions{
		margin: 0.5em 0;
	    line-height: 1.4;
	    overflow: hidden;
	}
	.content_body, .footer{
		border-bottom: 1px solid #d8d8d8;
	    border-top-color: rgba(240,240,240,1.00);
	    border-right-color: #000000;
	    margin: 1em 0;
	    line-height: 1;
	    font-family: Arial;
	    font-weight: 400;
	    font-size: 14px;
	    display: block;
	    white-space: normal;
	    line-height: 1.4;
	    text-align:justify;
	}
	.content_options{
		padding: .3em 1em 1em 1.5em;
	    overflow: hidden;
	    margin: 0;
	}
	.content_options ul {
	    list-style: none;
	    margin: 0;
	    padding: 0;
	    list-style: none;
	}
	.content_options ul li{
		overflow: hidden;
	    clear: left;
	    position: relative;
    	padding: .5em .2em;
    }
    .input-radio{
    	left: -10000px;
    	position: absolute;
        margin: 0;
    	top: .7em;
    	vertical-align: middle;
    }
    input{
    	font-family: inherit;
	    font-size: inherit;
	    line-height: inherit;
	    font: inherit;
	    color: inherit;
    }
    label.btn span {
  		font-size: 12px ;
	}

	label input[type="radio"] ~ i.fa.fa-circle-o{
	    color: #c8c8c8;    display: inline;
	}
	label input[type="radio"] ~ i.fa.fa-dot-circle-o{
	    display: none;
	}
	label input[type="radio"]:checked ~ i.fa.fa-circle-o{
	    display: none;
	}
	label input[type="radio"]:checked ~ i.fa.fa-dot-circle-o{
	    color: #7AA3CC;    display: inline;
	}
	label:hover input[type="radio"] ~ i.fa {
	color: #7AA3CC;
	}
	input[type=radio] {
	    display: none;
	}
    label {
		display: inline-block;
		margin-bottom: 0;
		font-size: 14px;
		font-weight: normal;
		line-height: 2em;
		text-align: left;
		white-space: nowrap;
		vertical-align: top;
		cursor: pointer;
		background-color: none;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
		-o-user-select: none;
		user-select: none;
	}
	.fa-2x {
	    font-size: 1.3em;
	    color:#000 !important;
	}
	.button-bar{
		direction: rtl;
    	text-align: center;
	}
	.button-bar input[type=submit]{
		font-size: 15px;
	    line-height: 1.4;
	    direction: ltr;
	    font-family: inherit;
	    color: #ffffff;
	    background-color: #e4002b;
	    margin-left: 10px;
	    border: none;
	    font-weight: 400;
	    border-radius: 4px;
	    padding: 10px 15px;
	    -webkit-font-smoothing: subpixel-antialiased;
	    -webkit-transition: border .25s linear,color .25s linear,background-color .25s linear;
	    transition: border .25s linear,color .25s linear,background-color .25s linear;
        cursor: pointer;
	}
	#lang-form {
	    display: block;
	}
	#lang-form, #sg-snc-thanks {
	    margin: 0 auto;
	    overflow: hidden;
	    width: 50%;
	}
	.navbar-right{
	   margin-right:0px;
	}
	.navbar-default .navbar-nav>.active>a, .navbar-default .navbar-nav>.active>a:focus, .navbar-default .navbar-nav>.active>a:hover{
	    color: #000;
        background-color: #cac8c8;
	}
	.navbar-default{
	   background-color: #000000;
	}
	.navbar-default .navbar-nav>li>a {
        color: #fff;
    }
    .navbar-default .navbar-nav>li>a:focus, .navbar-default .navbar-nav>li>a:hover{
	   color:#cecece;
	}
	label{
       white-space: unset;
    }
	@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {
        .container{
            width:100% !important;
            padding-right: 0px !important;
            padding-left: 0px !important;
        }
        .header img {
            max-width: 40%;
        }
        .header h1{
            font-size: 60px;
        }
        .content_title{
            font-size: 34px;
        }
        .content_body{
            font-size: 30px;
        }
        label{
            white-space: unset;
            font-size: 30px;
        }
        .footer div{
            font-size: 25px;
        }
        .footer{
            border-bottom: none;
            border-top: 1px solid #d8d8d8;
        }
        .content_options{
            padding:0px;
        }
        .button-bar input[type=submit]{
            font-size: 40px;  
        }
        .navbar-default{
            font-size:30px;
            font-weignt:600;
        }
        .language{
           margin-top:6px !important;
    	   height: 40px;
    	   font-size: 30px;
    	}
    	.language option{
    	   color:#000;
    	   font-size:11px;
    	}
	}
	@media only screen and (min-device-width : 768px) and (max-device-width : 1024px) {
        .container{
            padding-right: 0px !important;
            padding-left: 0px !important;
        }
        .header img {
            max-width: 20%;
        }
        .header h1{
            font-size: 30px;
        }
        .content_title{
            font-size: 22px;
        }
        .content_body{
            font-size: 18px;
        }
        label{
            white-space: unset;
            font-size: 18px;
        }
        .content_options{
            padding:0px;
        }
        .button-bar input[type=submit]{
            font-size: 20px;  
        }
        .navbar-default{
            font-size:18px;
            font-weignt:600;
        }
	}
	.loader{
	  position:fixed;
      top:0px;
      right:0px;
      width:100%;
      height:100%;
      background-color:#666;
      background-image:url('../../../images/ajax-loader-round.gif');
      background-repeat:no-repeat;
      background-position:center;
      z-index:10000000;
      opacity: 0.4;
	}
	.language{
	   margin-top: 8px;
       color: #fff;
       border-color: #fff;
       border: 1px solid #fff;
       border-radius: 0px;
       background-color: #000000;
       padding:0px;
	}
	.language option{
	background-color: #fff;
	   color:#000;
	}
	.language:focus {
        border-color: #fff;
        webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgb(0, 0, 0);
        box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgb(0, 0, 0);
    }
    .footer{
        text-align:center;
    }
    .footer div{
        padding: 13px 0px;
    }
    .readmore{
        font-weight: bold;
        cursor: pointer;
    }
</style>
<script>
	$(document).ready(function(){
	    $('.language').on('change', function() {
			  window.location	= "<?php echo base_url().'client_users/change_language/';?>"+this.value;
		});
		$('.readmore').on("click",function(){
				var id = $(this).attr('id');
			    var status    = $('#rm'+id).toggle().toggleClass("expandedSubSection").hasClass("expandedSubSection");
			    if(status){
			    	$('#'+id).text('[-]');
			    }else{
			    	$('#'+id).text('[+]');
			    }
		});
	});
</script>
</head>
	<body>
		<div class="loader" style="display:none"></div>
		<nav class="navbar navbar-default navbar-fixed-top __web-inspector-hide-shortcut__">
          <div class="container">
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav navbar-right">
              	<li><a href="#" style="pointer-events: none;">Language: </a></li>
                <li>
                	<select class="form-control language">
                		<?php foreach($languages as $row){?>
                			<option value="<?php echo $row['lang_value']?>" <?php if($lang==$row['lang_value']) { echo "selected";}?>><?php echo $row['lang_name']?></option>
                		<?php }?>
                	</select>
				</li>
              </ul>
            </div><!--/.nav-collapse -->
          </div>
        </nav>
		<div class="container">
  			<div class="wrapper">
  				<div class="header">
  					<h1><?php echo lang('PrivacyPolicy.Title');?></h1>
  				</div>
  				<div class="content">
  					<!-- <div class="content_title">
  						<div class="instructions">
  							<strong><?php echo lang('OptInOut.BodyCaption');?></strong>
  						</div>
  					</div> -->
  					<div class="content_body">
  							<?php echo lang('PrivacyPolicy.Content');?>
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                      <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                          <?php echo lang('PrivacyPolicy.Link1');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent1');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          <?php echo lang('PrivacyPolicy.Link2');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent2');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                          <?php echo lang('PrivacyPolicy.Link3');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent3');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFour">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                          <?php echo lang('PrivacyPolicy.Link4');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                      <div class="panel-body">
                                      	 <?php echo lang('PrivacyPolicy.LinkContent4');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFive">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                          <?php echo lang('PrivacyPolicy.Link5');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
                                      <div class="panel-body">
                                         <?php echo lang('PrivacyPolicy.LinkContent5');?>	 
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSix">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                          <?php echo lang('PrivacyPolicy.Link6');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
                                      <div class="panel-body">
                                         <?php echo lang('PrivacyPolicy.LinkContent6');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSeven">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                          <?php echo lang('PrivacyPolicy.Link7');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSeven">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent7');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingEight">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                          <?php echo lang('PrivacyPolicy.Link8');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseEight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEight">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent8');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingNine">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                          <?php echo lang('PrivacyPolicy.Link9');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseNine" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingNine">
                                      <div class="panel-body">
                                        	<?php echo lang('PrivacyPolicy.LinkContent9');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                          <?php echo lang('PrivacyPolicy.Link10');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseTen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTen">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent10');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingEleven">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                                          <?php echo lang('PrivacyPolicy.Link11');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseEleven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEleven">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent11');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwelve">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                                          <?php echo lang('PrivacyPolicy.Link12');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseTwelve" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwelve">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent12');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingThirteen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">
                                          <?php echo lang('PrivacyPolicy.Link13');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseThirteen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThirteen">
                                      <div class="panel-body">
                                          <?php echo lang('PrivacyPolicy.LinkContent13');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFourteen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFourteen" aria-expanded="false" aria-controls="collapseFourteen">
                                          <?php echo lang('PrivacyPolicy.Link14');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseFourteen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFourteen">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent14');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFifteen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFifteen" aria-expanded="false" aria-controls="collapseFifteen">
                                          <?php echo lang('PrivacyPolicy.Link15');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseFifteen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFifteen">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent15');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSixteen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSixteen" aria-expanded="false" aria-controls="collapseSixteen">
                                          <?php echo lang('PrivacyPolicy.Link16');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseSixteen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSixteen">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent16');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSeventeen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeventeen" aria-expanded="false" aria-controls="collapseSeventeen">
                                          <?php echo lang('PrivacyPolicy.Link17');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseSeventeen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSeventeen">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent17');?>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingEighteen">
                                      <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEighteen" aria-expanded="false" aria-controls="collapseEighteen">
                                          <?php echo lang('PrivacyPolicy.Link18');?>
                                        </a>
                                      </h4>
                                    </div>
                                    <div id="collapseEighteen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEighteen">
                                      <div class="panel-body">
                                        <?php echo lang('PrivacyPolicy.LinkContent18');?>
                                      </div>
                                    </div>
                                  </div>
                                </div>
  						<div class="content_options">
  							
	  					</div>
  					</div>
  				</div>
  				
  			</div>
		</div>
	</body>
</html>