<style>
#pass_form {
    margin:10px;
}
label {
    font-family:verdana;
    font-size:10px;
}
input {
    padding:2px;
    color:gray;
}
#passstrength {
    color:red;
    font-family:verdana;
    font-weight:bold;
}
#rightSideBarEnableDisable, #rightSideBar{
    display:none !important;
}
.invalid {
	background:url(<?php echo base_url()?>images/invalid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#ec3f41;
}
.valid {
	background:url(<?php echo base_url()?>images/valid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#3a7d34;
}
#match_fail{
	color: red;
	text-align: left;
	margin: 0;
	padding: 0;
	margin-top: 5px;
	margin-bottom: 5px;
	display: none;
}
</style>
<script type="text/javascript">


/*

var passValidationRule = {
		current_pasword : {
			required : true			
		},
			new_pasword : {
			required : true,
			minlength: 8,
	        maxlength: <?php echo MAX_LENGTH_INPUT;?>,
	        validation:true
		},
		confirm_password : {
			required : true,
			minlength: 8,
	        maxlength: <?php echo MAX_LENGTH_INPUT;?>,
	        equalTo : "#newPswd"
	}	
};
var passValidationMessage = {
			new_pasword : {
				required : "Required minimum 8 and maximum <?php echo MAX_LENGTH_INPUT;?> character" 
			}
	};
function updatePasswordData(){
	jConfirm('Confirm to change the password','Please Confirm',function(r){
		if(r){
		$("#passwordEditedData").validate({
			rules: passValidationRule,
			messages: passValidationMessage
		});
		if(!$("#passwordEditedData").validate().form()){
			return false;
		}else{
					var data = $("#passwordEditedData").serialize();
					$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$.ajax({
						url:base_url+"user_settings/updatePassword",
						data:data,
						type:"post",
						dataType:"json",
						success:function(returnData){
							if(returnData.status){
								window.location=base_url+"login/logout";
								$("#newPswd").val("");
								$("#cnfPswd").val("");	
								$("#settingsContentHolder").unblock();						
							}else{
								alert(returnData.text);
								$("#settingsContentHolder").unblock();
							}
						}
				});
			}
		}
	});
}
	$(document).ready(function(){
		jQuery.validator.addMethod("validation", function(value, element) {
			
			var value1=value;
		  return this.optional(element) || (/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*]{6,}$/).test(value1);
		}, "should contain at least one digit,one lower case,one upper case,one special charecter"); 

		$('#newPswd').keyup(function(e) {
		     var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
		     var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
		     var enoughRegex = new RegExp("(?=.{6,}).*", "g");
		     if (false == enoughRegex.test($(this).val())) {
		             $('#passstrength').html('More Characters');
		     } else if (strongRegex.test($(this).val())) {
		             $('#passstrength').className = 'ok';
		             $('#passstrength').html('Strong!');
		     } else if (mediumRegex.test($(this).val())) {
		             $('#passstrength').className = 'alert';
		             $('#passstrength').html('Medium!');
		     } else {
		             $('#passstrength').className = 'error';
		             $('#passstrength').html('Weak!');
		     }
		     return true;
		});
				

	});

*/

	$(document).ready(function() {
		
		//you have to use keyup, because keydown will not catch the currently entered value
		$('#password').live("keyup", function(event) {
			
			var count = 0;
			// set password variable
			var pswd = $(this).val();
			
			//validate the length
			if ( pswd.length < 8 ) {
				$('#length').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			} else {
				$('#length').removeClass('invalid').addClass('valid');
				count = count+1;
			}
			
			//validate letter
			if ( pswd.match(/[a-z]/) ) {
				$('#letter').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#letter').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			}
			
			//validate uppercase letter
			if ( pswd.match(/[A-Z]/) ) {
				$('#capital').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#capital').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			}
			
			//validate number
			if ( pswd.match(/\d/) ) {
				$('#number').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#number').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
				
			}

			//validate symbol
			if ( pswd.match(/[-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/) ) {
				$('#symbol').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#symbol').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			}
			if(count == 5){
				$('#passstrength').css('color','green');
				$('#passstrength').text('Strong!!');
				$('#form_submit').prop('disabled',false); 
			}else{
				$('#passstrength').css('color','red');
				$('#passstrength').text('Weak!!');
				$('#form_submit').prop('disabled',true); 
			}
		});

		
	}); 
	
$("#form_submit").click(function(){
	var password = $('.newPassword').val();
	var confPassword = $('#confPassword').val();
	if(password == confPassword){
		updatePasswordData();
	}else{
		$('#match_fail').show();
		$('#match_fail').text('Passwords do not match!!');
	}
});

function updatePasswordData(){
	var base_url= "<?php echo base_url() ?>";
	var data = $("#passwordEditedData").serialize();
	$.ajax({
		url:base_url+"user_settings/updatePassword",
		data:data,
		type:"post",
		dataType:"json",
		success:function(returnData){
			if(returnData.status == true){
				window.location=base_url+"login/logout";
				$("#newPswd").val("");
				$("#cnfPswd").val("");	
				$("#settingsContentHolder").unblock();						
			}else if(returnData.status == 'invalid_no_of_pwd'){
				$('#match_fail').show();
				$('#match_fail').text(returnData.text);
			}else if(returnData.status == 'invalid_current_pwd'){
				$('#match_fail').show();
				$('#match_fail').text(returnData.text);
			}else{
				alert(returnData.text);
				$("#settingsContentHolder").unblock();
			}
		}
	});
}
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Change Password</h3></div>
	</div>
</div>
<div style="width: 100%; margin: auto;">
<div style="width: 49%; min-height: 200px;float: left;display: inline;">
	<form id="passwordEditedData" action="" method="post">
		
		<table class="userDetails" style="width: 85%;">
			<tr>
				<th>Current Password :</th>
				<td><input id="currentPswd" type="password" name="current_pasword" ></input></td>
			</tr>
			<tr>
				<th>New Password :</th>
				<td><input type="password" name="new_pasword" id="password" class="newPassword"></input></td>
			</tr>
			
			<tr>
				<th>Confirm Password :</th>
				<td><input type="password" name="confirm_password"  id="confPassword" ></input></td>
			</tr>
			<tr>
				<th>Password Strength:</th>
				<td> <span id="passstrength"></span></td>
			</tr>
			<tr>
				<th>&nbsp;</th>
				<td><p id="match_fail"></p></td>
			</tr>
		</table>
	</form>
	<table class="userDetails">
		<tr>
			<td colspan="2">
				<div id="submitBtn" style="margin-left: 130px;">
					<button id="form_submit" disabled="disabled">Change Password</button>
				</div>
			</td>
		</tr>
	</table>
</div>
	<div style="width: 49%; min-height: 200px;float: left;display: inline;">
			<div class="ui-grid-solo" id="login_form_wrapper">
      			<h4>Password must meet the following requirements:</h4>
	            <ul style="padding: 0; margin: 0; list-style: none;">
					<li id="letter" class="invalid">At least <strong>one small letter</strong></li>
					<li id="capital" class="invalid">At least <strong>one capital letter</strong></li>
					<li id="number" class="invalid">At least <strong>one number</strong></li>
					<li id="symbol" class="invalid">At least <strong>one symbol</strong></li>
					<li id="length" class="invalid">Be at least <strong>8 characters</strong></li>
				</ul>
      		</div>
		</div>
</div>