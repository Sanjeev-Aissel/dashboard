<?php
/*
 * To display searched names
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 07-05-2013
 *  
 */
$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
?>
<style type="text/css">
	#searchedNames{
		min-height: 250px !important;
	}
	.ui-pg-input{ width: 80px; }
</style> 
<script type="text/javascript">
     var userId;
	function closeModalBox(){
		$("#searchedNames").dialog("close");
	}

	function add_territory(id,territory_name,first_name,last_name){
            
//    $.ajax({
//        type: "post",
//        dataType: "json",
//        url: base_url + 'interactions/getIdByUsername/'+first_name+'/'+last_name+'/',
//        success: function (returnData) {
////            alert(returnData);
//             userId=returnData;
//              
//        }
//    });
		$("#territory").val(territory_name);
		$("#territory_id").val(id);
                  $("#employee_id").val(id);
                  $("#employee_id_disabled").val(id);
                <?php  if($currentMethod=="view_interactions") ?>
		$("#searchedNames").dialog("close");
                <?php if($currentMethod=="ipad" || $currentMethod=="i") ?>
                    $("#modalBoxTeritory").modal('toggle');
	}
	
	function listSearchResults(){
		var ele=document.getElementById('gridContainer1');
		var gridWidth=ele;
		$('#gridContainer1').html('');
	    $('#gridContainer1').html('<div id="listNamesPage"></div><table id="listNamesResultSetData"></table>');
		jQuery("#listNamesResultSetData").jqGrid({
			url:base_url+'interactions/load_territories/',
			datatype: "json",
			colNames:['','First name','Last name','Territory Name','External Id','External Id 1'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'first_name',index:'first_name',search:true,width:180},
		   		{name:'last_name',index:'last_name',width:180,search:true,},
		   		//{name:'territory_name',index:'territory_name',width:60,search:true,},
		   		{name:'territory',index:'territory',
					formatter: function (cellvalue, options, rowObject) {
					        return "<a href='#' class='link' onclick='add_territory("+rowObject.id+",\""+rowObject.territory+"\""+",\""+rowObject.first_name+"\""+",\""+rowObject.last_name+"\");return false;' title='" + $.jgrid.stripHtml(cellvalue) + "'>" + $.jgrid.htmlEncode(cellvalue) + "</a>";
								
			    	},
		   		},
		   		{name:'external_id',index:'external_id',width:90,search:true, hidden:true},
		   		{name:'external_id_1',index:'external_id_1',width:90,search:true, hidden:true}
		   	],
		  	//postData:{"name":"<?php echo $name;?>","orgname":"<?php echo $orgname;?>","country":"<?php echo $country;?>","state":"<?php echo $state;?>","city":"<?php echo $city;?>","postal":"<?php echo $postal;?>"},
		   	rowNum:10,
		   	//multiselect: true,
		   	rownumWidth:"60",
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	gridview: true,
		   	pager: '#listNamesPage',
		   	mtype: "POST",
		   	sortname: 'first_name',
		   	sortorder: "asc",
		    viewrecords: true,
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Search Result",
		    grouping: false, 
	   		rowList:paginationValues
		});
		jQuery("#listNamesResultSetData").jqGrid('navGrid','#listNamesPage',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		jQuery("#listNamesResultSetData").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
		
		//Toggle Toolbar Search
		jQuery("#listNamesResultSetData").jqGrid('navButtonAdd',"#listNamesPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}
			}
		});
		jQuery("#listNamesResultSetData").jqGrid('setGridWidth',gridWidth);
		initilizeGridSearchPlaceholder();
	}
	$(document).ready(function (){
		listSearchResults();
	});
</script>
<div>
	<br />
	<div class="gridWrapper" id="gridContainer1">
		<div id="listNamesPage"></div>
		<table id="listNamesResultSetData"></table>
	</div>
	<br />
	<!-- 
	<div style="text-align: center;">
		<input type="button" value="Add as answer(s)" onclick="addSelectedRecords();" />
		<input type="button" value="Cancel" onclick="closeModalBox();" />
	</div>
	<br /> -->
</div>