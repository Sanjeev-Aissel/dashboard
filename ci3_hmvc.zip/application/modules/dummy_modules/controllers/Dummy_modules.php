<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dummy_modules extends MX_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("logins/login");
	}
	public function contacts()
	{
		$data['contentPage'] = 'contacts';
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	public function identify()
	{
		$data['contentPage'] = 'identify';
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	public function organization()
	{
		$data['contentPage'] = 'organization';
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	public function track()
	{
		$data['contentPage'] = 'track';
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	public function home()
	{
		$data['contentPage'] = 'home';
		$this->load->view(CLIENT_LAYOUT,$data);
	}		
	public function welcome()
	{
		$data['contentPage'] = 'welcome_message';
		$this->load->view(CLIENT_LAYOUT,$data);
	}		
}