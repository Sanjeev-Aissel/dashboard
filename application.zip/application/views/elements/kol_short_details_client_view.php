<?php
/**
 * Used to display the short information of the KOL Profile
 */
?>
	<?php 
		if($arrKol['salutation'] != 0)
			$salutation	= $arrSalutations[$arrKol['salutation']];
		else
			$salutation = "";
		$firstName	= $arrKol['first_name'];
		$middleName	= $arrKol['middle_name'];
		$lastName	= $arrKol['last_name'];
		
		$fullName	= $firstName;
		if(!empty($middleName))
			$fullName	.= ' '. $middleName;
		if(!empty($lastName))
			$fullName	.= ' '. $lastName;
		
		if($arrKol['gender']=="Male"){
			$imgName="male_doc_full.png";
		}else if($arrKol['gender']=="Female"){
			$imgName="female_doc_full.png";
		}else{
			$imgName="user_doctor.jpg";
		}
	?>
	<div id="kolShortDetails">
		<div class="profileImage">
			<?php 
				if($arrKol['profile_image'] != ''){
					echo '<img alt="Image"  src="'. base_url(). 'images/kol_images/resized/'. $arrKol['profile_image'].'"/>';
				}else{?>
						<img alt="Image" width="100" src="<?php echo base_url();?>images/<?php echo $imgName;?>" />
					<?php 
				}
			?>
		</div>
		<p class="profileName"><?php echo $salutation . ' ' . $fullName ?></p>
	</div>