<?php
/**
 * File to 'add' Social Media details
 *
 * @author: Ramesh B
 * @created on: 10-01-11
 * @package application.views.clinicals
 */
function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}
?>	
	<style type="text/css">
		#clinicalTrailAddLink label{
			color:#6FA7D1;
			font-size:115%;
			font-size:12px;
			text-decoration:none;
			text-align:left;
			padding-left:660px;
		}
		#clinicalTrailAddLink label img{
			vertical-align: -10px;
		}
		#contentWrapper.span-24 {
		    background-image: url("<?php echo base_url();?>images/verticlesep.jpg");
		    background-position: 168px 50%;
		    background-repeat: repeat-y;
		}
	</style>
	
	<script type="text/javascript" language="javascript">
	var kolId = '<?php echo $arrKol['id']?>'; 
	$(document).ready(function(){

		// Settings for the Add Clinical Trial Dialog Box
		var clinicalTrialAddOpts = {
				title: "ADD CLINICAL TRIAL",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView",
				position: ['center', 80],
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#clinicalTrailAddContainer").dialog(clinicalTrialAddOpts);
		
		listUnverifiedClinicalTrials();

		// Initiate the 'Ternary Navigation
		$("#kolEventsTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );
	
		// Remove the Surrounding Border
		$("#kolEventsTernaryNav" ).removeClass("ui-widget-content");
	
		// Remove the Round Corner
		$("#kolEventsTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
		
		$("#kolEventsTernaryNav li").removeClass( "ui-corner-top" );
	
		// Add the Custom Class to control View
		$("#kolEventsTernaryNav > div").addClass( "span-20 last" );

		$(".ternaryNav li a").click(function(){
			loadSelectedTab();
		});

		
		/*
		* To Move Selcted records into Verifeid publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#verify").click(function(){
			$("#delmodJQBlistClinicalTrialResultSet").remove();
			var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');	
			action = '<?php echo base_url();?>clinical_trials/verified_clinical_trials';
			var data = {};
			data['trial_ids' ] = sr;
			data['kol_id' ] = kolId;
			jQuery.jgrid.del = {
				    caption: "verify",
				    msg: "Move selected record(s) into Verified List?",
				    bSubmit: "Verify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    top:400,
				    left:500,
				    url:action,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").delGridRow( sr, {} );
			//$(".dData").click();
			//$(".ui-icon-closethick").click();			
		});
	
			/*
			* To Move Selcted records into Deleted ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteUnVerifiedRecords").click(function(){
				//Get all the selected id's from jqGrid manually
				/*
				var pubValues = new Array();
				$("input.cbox:checked").each(function(){
					var idName=this.id;
					var mySplitResult = idName.split("_");
					
					pubValues.push(mySplitResult[2]);
				});
				*/
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials/deleted_clinical_trials';
				var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = kolId;
				
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};				
				jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").delGridRow( sr, {} );
			});

			
			
			/*
			* To Move Selcted records into Unvarifeid ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#unVerify").click(function(){
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');	
				action = '<?php echo base_url();?>clinical_trials/un_verified_clinical_trials';
				var data = {};
				data['trial_ids' ] = sr;
				data['kol_id' ] = kolId;
				
				jQuery.jgrid.del = {
					    caption: "Unverify ",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:action,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move Selcted records into Deleted ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteVerifiedRecords").click(function(){
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials/deleted_clinical_trials';
				var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verified ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToVerify").click(function(){
				$("#delmodJQBlistDeletedClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials/verified_clinical_trials';
				var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Verify",
					    msg: "Move selected record(s) into Verified List?",
					    bSubmit: "Verify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};

				jQuery("#JQBlistDeletedClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verify ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToUnVerify").click(function(){
				$("#delmodJQBlistDeletedClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials/un_verified_clinical_trials';
				var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Unverify",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistDeletedClinicalTrialsResultSet").delGridRow( sr, {} );
			});
			
						
	});

	function listVerifiedClinicalTrials(){
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials/list_clinical_trials_details/<?php echo $arrKol['id']?>/verified',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'trial_id',index:'trial_id',hidden:true},
		   		{name:'act',resizable:true,width:130 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	var ctId = ret.trial_id;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+ctId+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+ctId+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials/delete_clinical_trials';
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','#listClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}

	function listUnverifiedClinicalTrials(){
		/*
		*jqgrid for Clinical Trials table
		*/
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials/list_clinical_trials_details/<?php echo $arrKol['id']?>/unverified',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listUnverifiedClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials/delete_clinical_trials';
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navGrid','#listUnverifiedClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistUnverifiedClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistUnverifiedClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}

	function listDeletedClinicalTrials(){
		/*
		*jqgrid for Clinical Trials table
		*/
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials/list_clinical_trials_details/<?php echo $arrKol['id']?>/deleted',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listDeletedClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials/delete_clinical_trials';
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navGrid','#listDeletedClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistDeletedClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistDeletedClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}
	
	/**
	* Delete the 'Education Details'
	*/
	function deleteClinicalTrial(id){								
		var formAction = '<?php echo base_url();?>clinical_trials/delete_clinical_trial/'+id;			
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
			  
	}	
	function addClinicalTrail(){
		$("#clinicalTrailAddProfileContent").val("");
		$(".ctprofileContent").val("");
		$(".ctprofileContent").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$("#clinicalTrailAddContainer").dialog("open");
		$("#clinicalTrailAddProfileContent").load('<?php echo base_url()?>clinical_trials/add_clinical_trial/<?php echo$arrKol['id']?>');
		return false;	
	}
	function editClinicalTrail(id){
		kolId = '<?php echo $arrKol['id']?>';
		$("#clinicalTrailAddProfileContent").val("");
		$(".ctprofileContent").val("");
		$(".ctprofileContent").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$("#clinicalTrailAddContainer").dialog("open");
		$("#clinicalTrailAddProfileContent").load("<?php echo base_url().'clinical_trials/edit_clinical_trial_manual/'?>"+id+"/"+kolId);
		return false;	
	}
	function processCTIds(){
		var ids	= $.trim($('#crawlCtIds').val());
		if(ids!=""){
			var formAction = '<?php echo base_url()?>clinical_trials/processCTIDs/<?php echo $arrKol['id']?>';
			$.ajax({
				url:formAction,
				type:'post',
				dataType:'json',
				data:'ctids='+ids,
				success:function(returnData){
					if(returnData.status=='success'){
						$("#clinicalTrailAddContainer").dialog("close");
					}else{
						$('.msgBox').text(returnData.msg);
						$('.msgBox').fadeOut(2500);
					}
				}
			
				});
		}else{
			jAlert('Enter at least one Clinical trial ID');
		}
	}
	function crawlCTIDs(){
		$("#clinicalTrailAddProfileContent").val("");
		$(".ctprofileContent").val("");
		$(".ctprofileContent").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$("#clinicalTrailAddContainer").dialog("open");
		var data = '<h4>Add Clinical Trial IDs for Crawling</h4><div><center>Enter CT ID(s) : <input type="text" id="crawlCtIds" /> comma(,) separated<br /><button onclick="processCTIds()">Save and Crawl</button></center></div>';
		$("#clinicalTrailAddProfileContent").html(data);
		return false;	
	}

		/*
		* To load Seleted tab when clicked
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		function loadSelectedTab(){
			$("#JQBlistClinicalTrialsResultSet").setGridParam({loadonce:false});
			var select    = $("#kolEventsTernaryNav").tabs("option","selected");
			switch(select){
				case 0	:	// As the 'reload' method didn't work for the 'jqgrid', the Table will be removed and will be appended again
							// The method to list the ClinicalTrialss will be called once again with the new Year Range values
					
							// Remove the whole JQGrid List content
							$("#unverifiedGridContainer").html("");

							$("#unverifiedGridContainer").html('<table id="JQBlistUnverifiedClinicalTrialsResultSet"></table><div id="listUnverifiedClinicalTrialsPage"></div>');

							listUnverifiedClinicalTrials();
							break;
							
				case 1	: 	$("#verifiedGridContainer").html("");

							$("#verifiedGridContainer").html('<table id="JQBlistClinicalTrialsResultSet"></table><div id="listClinicalTrialsPage"></div>');

							listVerifiedClinicalTrials();
							break;
				
				case 2	:	$("#deletedGridContainer").html("");

							$("#deletedGridContainer").html('<table id="JQBlistDeletedClinicalTrialsResultSet"></table><div id="listDeletedClinicalTrialsPage"></div>');
	
							listDeletedClinicalTrials();
							break;
				default :	listUnverifiedClinicalTrials();
	
			}
			$("#JQBlistClinicalTrialsResultSet").setGridParam({loadonce:true});
		}
			
	</script>
			

							
			<div id="kolOverviewTernaryNav" class="verticalTabDataWrapper ui-tabs ui-widget ui-corner-all ui-tabs-vertical ui-helper-clearfix">
				<div id="clinicalTrailAddLink">
					<label onclick="crawlCTIDs();" style="float:left;"><img height="26" src="<?php echo base_url();?>images/bullet_add.png" border="0" />Add CTIDs</label>
					<label onclick="addClinicalTrail();" style="padding-left:5px;"><img height="26" src="<?php echo base_url();?>images/bullet_add.png" border="0" />Add New Clinical Trial</label>
				</div>
				<div id="kolEventsTernaryNav" class="leftBar">	
					<?php if(!$isClientView): ?>
					<?php $this->load->view('elements/kol_short_details');?>
					<ul class="span-4 ternaryNav verticalTabsContainer ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-tr ui-corner-br">
							<li><a href="#unVerified">Unverified</a></li>
						    <li><a href="#verified">Verified</a></li>
						    <li><a href="#deleted">Deleted</a></li>
						</ul>
					<?php endif;?>
				</div>
		
				
				<div id="listtrials"  class="span-19 last" style="margin-left: 20px;">
					<div id="unVerified">
				  		<button id="verify" class="button">Verify</button>	 <button id="deleteUnVerifiedRecords" class="button">Delete</button>
				  		<div class="gridWrapper" id="unverifiedGridContainer">
							<table id="JQBlistUnverifiedClinicalTrialsResultSet"></table>
							<div id="listUnverifiedClinicalTrialsPage"></div>
						</div>	
					</div>
					<div id="verified">
						<button id="unVerify" class="button">Unverify</button>  <button id="deleteVerifiedRecords" class="button">Delete</button>
						<div class="gridWrapper" id="verifiedGridContainer">
							<table id="JQBlistClinicalTrialsResultSet"></table>
							<div id="listClinicalTrialsPage"></div>
						</div>	
					</div>
					<div id="deleted">
						<button id="deleteToVerify" class="button">Verify</button>  <button id="deleteToUnVerify" class="button">Unverify</button>
						<div class="gridWrapper" id="deletedGridContainer">
							<table id="JQBlistDeletedClinicalTrialsResultSet"></table>
							<div id="listDeletedClinicalTrialsPage"></div>
						</div>	
					</div>
				</div>
			</div>		
			
			<!-- Container for the 'Add Clinical Trail' modal box -->
			<div id="clinicalTrailDailog">
				<div id="clinicalTrailAddContainer" class="microProfileDialogBox">
					<div class="profileContent" id="clinicalTrailAddProfileContent"></div>
				</div>
			</div>
			<!--End of  Container for the 'Add Clinical Trail' modal box -->	
			