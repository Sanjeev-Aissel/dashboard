<?php
/*
 * Page to show survey network map
 *  
 * @Author		: Vinatak
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 15-05-2013
 *  
 */
?>
<?php
	//jit.forecedirected&rgraph_mix
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery.autocomplete',
							'chosen.jquery',
							'surveys/geo_map',
							'jquery/jquery.validate1.9.min',
							'maps/map'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {getOrganizationInfluenceData();}";
	
	?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">


<!--[if (IE)]>
	<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/excanvas.js"></script>
<![endif]-->
<script type="text/javascript">
<?php 
$mobile = mobile_device_detect();

if(isset($mobile[1])){?>
 var agent ='<?php echo $mobile[1]?>';
	
<?php }else{?>
var agent ='';
<?php }?>

var baseUrl='<?php echo base_url();?>';
var rdGraphObj;
var fdGraphObj;
var fd;
var currentJson;
var currentView='view2';
var isMicroviewLoading = false;

var labelType, useGradients, nativeTextSupport, animate;

$(document).ready(function(){

	$('.chosenSelect').chosen({allow_single_deselect: true});
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
	$("#survey_chzn").live('click',function(){
		moveFromCurrentStep(4);
	});
	$("#PDQnomineeType_chzn").live('click',function(){
		hideHint(5);
	});
	$("#PDQnomineeSpecialty_chzn").live('click',function(){
		hideHint(5);
	});
	$("#PDQnomineeState_chzn").live('click',function(){
		hideHint(5);
	});
	$("#survey").chosen().change(function() {
		loadOptions();
	});
});

function loadOptions(){
	var surveyId	= $('#survey').val();
	var chartType	= $('#chartType').val();
	if(surveyId!=0){
		load_custom_query_options(surveyId);
	}else{
		$("#preQuery .chosenSelect").val('').trigger('liszt:updated');$("#customQuery .chosenSelect").val('').trigger('liszt:updated');
	}
}

function loadSurveyNetMap(){
	animateMicroviewBoxHide();
	$('#mapContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	var actionUrl='';
	actionUrl=baseUrl+'surveys/get_survey_influence_data/';
	//Ajax request to load influence map json data
	var surveyId	= $('#survey').val();
	var data	= $('#preQuery').serialize();
	data		+= '&survey_id='+surveyId;
	$.ajax({
		type: "post",
		dataType:"json",
		data:data,
		url: actionUrl,
		success: function(json){
			currentJson=json;
			rdGraphObj=null;
			$("#view2Infovis").html('');
			 surveysView(json,'view2Infovis','#FFFFFF');
		},
		complete: function(){
			//hide loading image
			$('.loadingIndicator').hide();
			$('#mapContainer').unblock();
		}
	});
}


</script>

<style>
	select.chosenSelect, select.chosenMultipleSelect{
		width:200px;
	}
	.chzn-container{
		font-size: 12px;
		margin-bottom: 3px;
		width:150px;
	}
	#filterOptions td, #filterOptions th{
		padding-bottom: 10px !important;
	}
	#preDefinedQuery .chzn-container{
		width: 150px !important;
	}
	#filterOptions label{
		vertical-align: super;
	}
	#mapsContent{
		float: left;
	}
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:11px;
		
	}
	#kolImage{
		vertical-align: bottom;
	}
	
	#myMap{
	position:relative; 
	width:790px; 
	height:450px;
	}
		
	div.filterSearchIcon {
	    display: inline-block;
	    float: none;
	    margin-bottom: -2px;
	    margin-right: -20px;
	    position: relative;
	}
	div.filterSearchIcon {
	    background: url("../images/kolm-sprite-image.png") repeat scroll -52px -3px transparent;
	    float: left;
	    height: 16px;
	    margin-left: 1px;
	    margin-top: 5px;
	    position: absolute;
	    width: 16px;
	}
	#organization {
	    padding-left: 15px;
	    width: 278px;
	}
	
	#orgSelectArea{
		 margin-left: 143px;
	
	}
	
	#mapsContent1{
	padding-left: 0x !important;
	}
	
	#imageContenet{
	float:left;
	margin-right: 4px;
	margin-top:3px;
	}
	.MapPushpinBase img{
	
	 margin-top: 31px;
	 margin-left: 8px;
	 left: -2px !important;
	}
	
	
	.kolInfo{
		min-height:46px;
		margin-top:-6px;
	}
	
	.Infobox{
		height: 82px !important;
	    top: 59px !important;
	    width: 239px !important;
	}
	.infobox-stalk{
		height:30px !important;
		top: 82px !important;
	}

select.chosenSelect, select.chosenMultipleSelect{
	width:200px;
}
.chzn-container{
	font-size: 12px;
	margin-bottom: 3px;
	width:150px;
}
#filterOptions td, #filterOptions th{
	padding-bottom: 10px !important;
}
#preDefinedQuery .chzn-container{
	margin-right: 10px;
    width: 150px !important;
}
#filterOptions label{
	vertical-align: super;
}
#preDefinedQuery{
	border-top: 1px solid #E9E9E9;
    margin-top: 3px;
    padding-top: 3px;
}
#preDefinedQuery button{
	vertical-align: super;
}
#mapContainer{
	border-top: 1px solid #E9E9E9;
}
#filterOptions{
	 position: relative;
}
#tooltip-survey{
	 left: 260px;
    position: absolute;
    top: 6px;
}
#tooltip-reload{
	 position: absolute;
    right: 30px;
    top: 46px;
}
.tooltip.in {
    opacity: 1.00 !important;
}

	.NavBar_modeSelectorControlContainer{
		display: none;
	}
	.NavBar_compassControlContainer{
		display: none;
	}
	.NavBar_zoomControlContainer .NavBar_zoomDrop{
		display: none;
	}
	.NavBar_zoomControlContainer{
		background: none repeat scroll 0 0 #FAF7F5;
	    height: 30px;
	    left: 5px;
	    position: absolute;
	    top: 351px;
	    transform: rotate(270deg);
	    width: 52px;
	}
	.MicrosoftMap .OverlaysBR-logoAware{
		display: none;
	}
	#mapsContent1{
	    margin: auto;
	}
	.disableNavigation{
		opacity: 0.30;
		-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)"; /* IE 8 */
		filter: alpha(opacity=30); /* older IEs */
		margin: 2px 3px 2px 2px;
	}
	.NavBar_zoomControlContainer .NavBar_zoomIn{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg); 
	}
	.NavBar_zoomControlContainer .NavBar_zoomOut{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg);
	}
</style>
<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/folders/210925' target='_new'>View Additional Help</a>"; ?>
<div id="container">
<div>
	<div id="filterOptions">
		<label>Survey : </label>
		<select id="survey" name="survey" class="chosenSelect">
			<option value="0">Select Survey</option>
			<?php foreach($arrCompletedSurveys as $key=>$arrRow){
				echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
			}?>
		</select>
		<span id="tooltip-survey" class="map-info tooltop-bottom">
			<a href="#" class="tooltipLink" rel='tooltip' data-original-title="<span class='tttext'>Select the survey first for which you want to generate the influence map.<?php echo $helpLink;?></span>">&nbsp;</a>
		</span>
		
			<div id="preDefinedQuery">
				<table>
					<tr>
						<td>
							<form action="#" onsubmit="return false;" name="preQuery" id="preQuery">
								<div>
								<label>Top </label>
								<select id="PDQnomineeType" name="nominee_type" class="chosenSelect nominee_type" data-placeholder="Select Type">
									<option value=""></option>
									<?php 
										foreach($arrTypes as $id=>$name){
											echo '<option value="'.$id.'">'.$name.'</option>';
										}
									?>
								</select>
								<label>Influencers of  </label>
								<select id="PDQnomineeSpecialty" name="nominee_specialty" class="chosenSelect nominee_specialty" data-placeholder="Select Therapeutic Area">
									<option value=""></option>
								</select>
								<label>in the state of </label>
								<select id="PDQnomineeState" name="nominee_state[]" class="chosenSelect nominee_state" data-placeholder="Select State">
									<option value=""></option>
								</select>
								<input onclick="getOrganizationMapData(); return false;" type="button" value="Go" style='vertical-align:top;' />
								<!-- button onclick="getOrganizationMapData(); return false;" style='vertical-align:top;height: 23px;'>Go</button-->
								<span class="map-info tooltop-bottom helpToolTip" style="vertical-align: super;"><a href="#" class="tooltipLink" rel='tooltip' data-original-title="<span class='tttext'>You can generate the map based on influencer type, therapeutic area and/or the state. You can select one or all of the 3 options. Not selecting any option from the drop down will consider all results by default.<br>Each dot is an individual. Click on any name to highlight connections & click again to unselect.<br> <b>Respondent</b> – individuals who have nominated others; indicated by arrows pointing towards them.<br> <b>Influencer</b> – Individuals who have been nominated by others; indicated by arrows pointing away. <br>E.g. A ----------- >B  = A influences B<?php echo $helpLink;?></span>">&nbsp;</a></span>
								</div>
							</form>
						</td>
					</tr>
				</table>
			</div>
	</div>
	<div id="geoNetworkMap">
		<div id="mapsContent1" class="span-20 last">			
			<div id='myMap' style=""></div>
		</div>
	
	</div> 
</div>
<div id="addNewKol" class="microProfileDialogBox">
	<div class="addNewKolContent profileContent"></div>
</div>
</div>
<style>
#contentWrapper.span-23 {
    background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
    background-position: 135px 50%;
    background-repeat: repeat-y;
}
</style>