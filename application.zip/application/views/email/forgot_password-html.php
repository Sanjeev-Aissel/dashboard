
Hi <?php echo $userName?>,

We have received a request to reset your <?php echo PRODUCT_VERSION;?> Application password. If you did not make this request, simply ignore this email. If you did make this request, just click the link below and follow the instructions:

<?php echo base_url()?>login/reset_password/<?php echo $userId ?>/<?php echo $key ?>

If the above URL does not work, try copying and pasting it into your browser. You'll need to click the link within 24 hours after receiving this email else the link will expire. If you have not requested for a password reset, simply ignore this email and your current password will be maintained.

If you continue to have problem please feel free to contact us at support@aissel.com

Thanks,
<?php echo PRODUCT_VERSION;?> Support

