<?php
/**
 * Controller for Organization requests handling
 * 
 * @author Ramesh B
 * @since otsuka 1.0.9
 * @package application.controllers	
 * @created 28 Dec 2012
 */
 
class requested_orgs extends Controller{
 	
 	private $loggedUserId	= null;
 	private $isApprover	= false;
 	
 	//Constructor
	function requested_orgs(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model("Country_helper");
		$this->load->model('common_helpers');
		$this->load->model('Client_User');
		$this->load->model("requested_org");
		$this->load->model("requested_kol");	
		$this->load->model('organization');
		$this->loggedUserId = $this->session->userdata('user_id');
		//$this->isApprover	= IS_APPROVER;
	}

	function show_client_requested_orgs($urlString = null){
		if($urlString != null)
			$data['urlString'] = json_encode($this->filters_to_array($urlString));
			
		$data['contentPage'] = 'kols/client_requested_orgs';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited client requested orgs Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View client requested orgs Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	}
	
	function add_client_org(){
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrCountry']=$this->Country_helper->listCountries();
		$this->load->view('organizations/add_client_org',$data);
	}
	
	function save_org_request(){
		$this->isApprover	= IS_APPROVER;
		//Prepare KOL details
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
    	$arrOrg['name']	 	=	ucwords(trim($this->input->post('name')));
      	$arrOrg['country_id']     	=	$this->input->post('country_id');
      	$arrOrg['state_id']     	=	$this->input->post('state_id');
      	$arrOrg['city_id']     	=	$this->input->post('city_id');
      	$arrOrg['created_by']	 = 	$this->loggedUserId;
		$arrOrg['created_on']	 =	date("Y-m-d H:i:s");
		$arrOrg['status']		 =	New1;
		//$arrOrg['profile_type']		 =	FULL;
		if($this->isApprover){
			$arrOrg['status']		 =	APPROVED;
			$data['hidden'] = true;
		}else{
		    $data['hidden'] = false;
		}
			
		$orgId = $this->input->post('org_id');
		if($orgId != '' && $orgId != 0){
			$updateData['id'] 			=  $orgId;  
	       	$updateData['cin_num'] 		=  $orgId;
	       	$updateData['status'] 		=  $arrOrg['status']; 
			$this->organization->updateOrganization($updateData);
		}
        if($arrOrg['name'] !=''){
        	$arrSimilarNames = $this->organization->checkSimilarOrganizations($name);
			$orgId	= $this->organization->saveOrganization($arrOrg);
	        if($orgId){
				//Update pin as kolid
				$updateData['id'] 			=  $orgId;  
	       		$updateData['cin_num'] 		=  $orgId; 
	       		if(sizeof($arrSimilarNames) > 0){
	       			
	       		} 
	       		$this->organization->updateOrganization($updateData);
			}
		}
		
		//Save Profile Request
		$userRequest = array();
		$userRequest['org_id'] = $orgId;
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}

		$isSaved = $this->requested_org->save($userRequest);
		$arrLogDetails = array(
		    'type' => ADD_RECORD,
		    'description' => 'New Organization Profile Request',
		    'status' => STATUS_SUCCESS,
		    'kols_or_org_type' => 'Organization',
		    'kols_or_org_id' => $orgId,
		    'transaction_id' =>  $isSaved,
		    'transaction_table_id' => USER_ORG_REQUESTS,
		    'transaction_name' => "Organization Profile Requested",
		    'parent_object_id' =>   $orgId
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
			
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['org_id'] = $userRequest['org_id'];
		$rowData['org_name'] = $this->input->post('name');
		$rowData['status'] = $userRequest['status'];
		$rowData['state'] = $this->Country_helper->getStateById($arrOrg['state_id']);
		$rowData['city'] = $this->Country_helper->getCityeById($arrOrg['city_id']);
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		$data['arrOrg'] = $rowData;
		
		//Send mails
		$arrOrg['id'] = $orgId;
		$mailSent = $this->send_user_request_mails($arrOrg);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
       	echo json_encode($data);
	}
	
	function send_user_request_mails($arrOrg){
		$this->isApprover	= IS_APPROVER;
		$orgId = $arrOrg['id'];
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		//$config['mailtype'] = 'html';
	
		$this->email->set_newline("\r\n");
		$this->email->set_crlf( "\r\n" );
		$clientId = $this->session->userdata('client_id');
          
		//send mail to Analyst Managers if the request is from Client manager
		if($this->isApprover){
			$arr =array();
			$arr[$orgId] = $this->organization->editOrganization($orgId);
			
			$clientId = $this->session->userdata('client_id');
			$clientName = $this->Client_User->getClientName($clientId);
			$data1['clientName'] = $clientName;
			$data1['arrOrgs'] = $arr;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
	
           	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
           	foreach($analystMangerEmailId as $email=>$ids){
           		$emailIds[]=$ids['email'];
           	}
			//pr($analystMangerEmailId);
			$analystMangerEmailIds = implode(',',$emailIds);
			$this->email->subject('New Organization Profiling Request');
          	$userNAme = $this->session->userdata('user_name');
            $this->email->from($config['smtp_user'],$userNAme);
            $data1['arrOrg'] = $arrOrg;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			
          	$this->email->message($html);
          	$this->email->to($analystMangerEmailIds);
          	if($this->email->send()){
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_SUCCESS,
          	        'transaction_name'=>"Organization Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  true;
          	}else{
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_FAIL,
          	        'transaction_name'=>"Organization Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  false;
          	}
		}else{
			//Send mail to  Client manager
			$userId = $this->session->userdata('user_id');
			$managerEmailId = $this->Client_User->getUserManagerEmailId($userId);
        	$approverIds	= explode(',',APPROVER_IDS); 
			$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
			//$clientMangerEmailIds[]	= $managerEmailId;
			$userNAme = $this->session->userdata('user_name');
          	$this->email->from($config['smtp_user'],$userNAme);
			$this->email->subject('New Organization Profiling Request');
			$baseUrl = base_url().'requested_kols/show_client_requested_kols';
			$data1['arrOrg'] = $arrOrg;
			$data1['requestAction'] = 'USER_REQUEST_MANAGER';
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			$this->email->message($html);
          	$this->email->to($clientMangerEmailIds);
          	$this->email->cc($managerEmailId);
          	$this->email->send();
          	
          	//Send mail to  User
          	$userEmail = $this->session->userdata('email');
          	$userRoleId = $this->session->userdata('user_role_id');
          	$this->email->subject('New Organization Profiling Request');
          	$this->email->from($config['smtp_user'],$userNAme);
          	$data1['arrOrg'] = $arrOrg;
			$data1['requestAction'] = 'USER_REQUEST_USER';
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			$this->email->message($html);
          	$this->email->to($userEmail);
          	if($this->email->send()){
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_SUCCESS,
          	        'transaction_name'=>"Organization Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$userEmail
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  true;
          	}else{
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_FAIL,
          	        'transaction_name'=>"Organization Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$userEmail
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  false;
          	}
		}
		
		return true;
	}
	
	function check_similar_names(){
		$arrData = array();
		$name 	=	trim($this->input->post('name'));
		$arrOrgs = $this->organization->checkSimilarOrganizations($name);
		if(sizeof($arrOrgs) > 0){
			$arrData['similarOrgs'] = $arrOrgs;
			$data['duplicates'] = $this->load->view('organizations/show_similar_names',$arrData,true);
			$data['hasDuplicates'] = true;
		}else{
			$data['hasDuplicates'] = false;
		}
		echo json_encode($data);
	}
	
	function list_my_pending_approvals(){
	    $page		= (int)$this->input->post('page'); // get the requested page
	    $limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$userId = $this->session->userdata('user_id');
		$arrData = $this->requested_org->listMyPendingApprovals($userId);
		$requestedOrgs = array();
		$data = array();
		foreach($arrData as $row){
			$row['org_name'] = $row['org_name'];
       		$row['dAllowed'] = $this->common_helpers->isActionAllowed('org_profile_request', 'delete', $row);
       		if( $row['is_re_request'] == 1 && $row['status'] == New1)
       			$row['status'] = RE_REQUEST;
       		
       		/* if($row['profile_type'] == '')
       			$row['profile_type'] = 'Basic';
       		if($row['profile_type'] == 'Basic Plus')
       			$row['profile_type'] = 'Basic+';
       		if($row['profile_type'] == 'Full Profile')
       			$row['profile_type'] = 'Full';
       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
       			$row['request_for'] = 'Profile - '.ucwords($row['profile_type']);
       		else
       			$row['request_for'] = 'Upgrade - '.ucwords($row['profile_type']);
       		 */
       		if($row['requested_on'] != '')	
       			$row['requested_on'] = date("m-d-Y",strtotime($row['requested_on']));
       		if($row['rej_or_appr_on'] != '')
       			$row['rej_or_appr_on'] = date("m-d-Y",strtotime($row['rej_or_appr_on']));
       		$row['approve_allow'] = $this->common_helpers->isActionAllowed('org_profile_request','approve',array("org_id"=>$row['org_id']));
			$requestedOrgs[] = $row;
		}
		$total_pages  = 0;
		$count				= sizeof($requestedOrgs);				
		if( $count >0 ){ 
			$total_pages	= ceil($count/$limit);
		}
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $requestedOrgs;
		echo json_encode($data);
	}
	
	function list_all_profile_requests(){
	    $page		= (int)$this->input->post('page'); // get the requested page
	    $limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrData = $this->requested_org->listAll();
		$requestedOrgs = array();
		$data = array();
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		foreach($arrData as $row){
			$row['kol_name'] = $arrSalutations[$row['salutation']]." ".$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
       		$row['specialty'] = $arrSpecialties[$row['specialty']];
       		$row['user_full_name'] = $row['user_first_name']." ".$row['user_last_name'];
       		//Add reject reason as title text
       		//if($row['status'] == REJECT)
       			//$row['status'] = "<span class='reject-reason' title='".$row['comments']."'>".$row['status']."</span>";
       		$row['approved_by']= $row['approver_first_name']." ".$row['approver_last_name'];
       		if($row['status'] == New1){
       			$row['approved_by']='';
       		}
       		if($row['profile_type'] == '')
       			$row['profile_type'] = 'Basic';
       		if($row['profile_type'] == 'Basic Plus')
       			$row['profile_type'] = 'Basic+';
       		if($row['profile_type'] == 'Full Profile')
       			$row['profile_type'] = 'Full';
       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
       			$row['request_for'] = 'Profile - '.ucwords($row['profile_type']);
       		else
       			$row['request_for'] = 'Upgrade - '.ucwords($row['profile_type']);
       			
       		if ($row ['requested_on'] != '') {
       			$row ['requested_on'] = date ( "m-d-Y", strtotime ( $row ['requested_on'] ) );
       		}
       		if ($row ['rej_or_appr_on'] != '') {
       			$row ['rej_or_appr_on'] = date ( "m-d-Y", strtotime ( $row ['rej_or_appr_on'] ) );
       		}
			$requestedOrgs[] = $row;
		}
	    $total_pages  = 0;
		$count				= sizeof($requestedOrgs);				
		if( $count >0 ){ 
			$total_pages	= ceil($count/$limit);
		}
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $requestedOrgs;  
		//pr($arrOrgDetailResult1);
		echo json_encode($data);
	}
	
	function approve(){
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arrIds = $this->input->post('arrIds');
		foreach($arrIds as $id){
			$rowData = array();
			$arrRequestData = $this->requested_org->get($id);
			$arrOrg = $this->organization->editOrganization($arrRequestData['org_id']);
			//Update user request
			$rowData['id'] = $id;
			$rowData['status'] = APPROVED;
			$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
			$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			$isUpdated = $this->requested_org->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => 'Organization Profile Request update to '.APPROVED,
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Organization',
			    'kols_or_org_id' => $arrRequestData['org_id'],
			    'transaction_id' =>  $id,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => 'Organization Profile Request update to '.APPROVED,
			    'parent_object_id' =>   $arrRequestData['org_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			//Update Organization status
			$orgDetails = array();
			$orgDetails['id'] = $arrRequestData['org_id'];
			$orgDetails['status'] = APPROVED;
			$this->organization->updateOrganization($orgDetails);
			
			//Send mail to user
			$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
			$this->email->subject("Organization Profiling Request - Approved");
			$userNAme = $this->session->userdata('user_name');
			$this->email->from($config['smtp_user'],$userNAme); 	
			$data1['requestAction'] = MANAGER_APPROVE_USER;
			$data1['arrOrg']=	$arrOrg;
			$data1['arrRequestData']=	$arrRequestData;
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			$this->email->message($html);
			$this->email->to($userEmailId);
// 			$isMailSent = $this->email->send();
			if($this->email->send()){
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => LOG_ACTIVITY_EMAIL,
			        'status' => STATUS_SUCCESS,
			        'transaction_name'=>"Organization Profile Request Email Sent",
			        'miscellaneous2'=>"To-".$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    log_user_activity(null,true);
			    $status	=  true;
			}else{
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => LOG_ACTIVITY_EMAIL,
			        'status' => STATUS_FAIL,
			        'transaction_name'=>"Organization Profile Request Email Sent",
			        'miscellaneous2'=>"To-".$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    log_user_activity(null,true);
			    $status	=  false;
			}
			
			//send mail to Analyst Manager
	       	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	       	foreach($analystMangerEmailId as $email=>$ids){
	       		$emailIds[]=$ids['email'];
	        }
			$analystMangerEmailIds = implode(',',$emailIds);
			$this->email->subject('Organization Profiling Request - Approved');
		    $userNAme = $this->session->userdata('user_name');
		    $this->email->from($config['smtp_user'],$userNAme);
			$data1['requestAction'] = MANAGER_APPROVE_ANALYST;
			$data1['arrOrg']=	$arrOrg;
			$data1['arrRequestData']=	$arrRequestData;
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			$this->email->message($html);
	        $this->email->to($analystMangerEmailIds);
// 	        $isMailSent = $this->email->send();
	        if($this->email->send()){
	            //Log Activity
	            $arrLogDetails = array(
	                'description'=>$html,
	                'type' => LOG_ACTIVITY_EMAIL,
	                'status' => STATUS_SUCCESS,
	                'transaction_name'=>"Organization Profile Request Email Sent",
	                'miscellaneous2'=>"To-".$analystMangerEmailIds
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            log_user_activity(null,true);
	            $status	=  true;
	        }else{
	            //Log Activity
	            $arrLogDetails = array(
	                'description'=>$html,
	                'type' => LOG_ACTIVITY_EMAIL,
	                'status' => STATUS_FAIL,
	                'transaction_name'=>"Organization Profile Request Email Sent",
	                'miscellaneous2'=>"To-".$analystMangerEmailIds
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            log_user_activity(null,true);
	            $status	=  false;
	        }
		}
		
		$data = array();
		$data['status'] = true;
		$data['approved_by'] = $this->session->userdata('user_full_name');
		echo json_encode($data);
	}
	
	function reject(){
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arrIds = $this->input->post('arrIds');
		$comments = $this->input->post('comments');
		foreach($arrIds as $id){
			//Update request
			$rowData = array();
			$arrRequestData = $this->requested_org->get($id);
			$arrOrg = $this->organization->editOrganization($arrRequestData['org_id']);
			$rowData['id'] = $id;
			$rowData['status'] = REJECT;
			$rowData['comments'] = $comments;
			$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
			$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			$isUpdated = $this->requested_org->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => 'Organization Profile Request update to '.REJECT,
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Organization',
			    'kols_or_org_id' => $arrRequestData['org_id'],
			    'transaction_id' =>  $id,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => 'Organization Profile Request update to '.REJECT,
			    'parent_object_id' =>   $arrRequestData['org_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			//Update KOL status
			$orgDetails = array();
			$orgDetails['id'] = $arrRequestData['org_id'];
			$orgDetails['status'] = REJECT;
			$this->organization->updateOrganization($orgDetails);
			
			//Send mail
			$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
			$data1['arrOrg']=	$arrOrg;
			$data1['arrRequestData']=	$arrRequestData;
			$data1['comments'] = $comments;
			$this->email->subject("Organization Profiling Request - Rejected");
			$userNAme = $this->session->userdata('user_name');
			$this->email->from($config['smtp_user'],$userNAme); 	
			$data1['requestAction'] = MANAGER_REJECT_USER;
			$html = $this->load->view('organizations/prepare_email_content',$data1,true);
			$this->email->message($html);
			$this->email->to($userEmailId);
// 			$this->email->send();
			if($this->email->send()){
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => LOG_ACTIVITY_EMAIL,
			        'status' => STATUS_SUCCESS,
			        'transaction_name'=>"Organization Profile Request Email Sent",
			        'miscellaneous2'=>"To-".$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    log_user_activity(null,true);
			    $status	=  true;
			}else{
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => LOG_ACTIVITY_EMAIL,
			        'status' => STATUS_FAIL,
			        'transaction_name'=>"Organization Profile Request Email Sent",
			        'miscellaneous2'=>"To-".$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    log_user_activity(null,true);
			    $status	=  false;
			}
		
		}
		$data = array();
		$data['status'] = true;
		$data['approved_by'] = $this->session->userdata('user_full_name');
		echo json_encode($data);
	}
	
	function delete($id){
		$arrRequestData = $this->requested_org->get($id);
		//Delete request
		$isUpdated = $this->requested_org->delete($id);
		//Delete KOL
		//$this->kol->deleteOrg($arrRequestData['org_id']);
		echo $isUpdated;
	}
	
	function upgrade_request_page(){
		echo $this->load->view('requested_kols/upgrade_request_page');
	}
	
	function update_request_status_analyst(){
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arr['status'] = $this->input->post('status');
		$arr['orgId'] = $this->input->post('orgId');

		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		if($arr['status']==COMPLETED){
			$status = STATUS_COMPLETED;
		}
		
		if($arr['status']==APPROVED){
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
		}
		
		if($arr['status'] == PROFILING)
			$status = STATUS_PROFILING;
		if($arr['status'] == REVIEW)
			$status = STATUS_REVIEW;
		if($arr['status'] == New1)
			$status = STATUS_NEW;
		
		foreach($arr['orgId'] as $id){
			//Update request
			$rowData = array();
			$arrRequestData = $this->requested_org->get($id);
			$arrOrg = $this->organization->editOrganization($arrRequestData['org_id']);
			$rowData['id'] = $id;
			$rowData['status'] = $arr['status'];
			if($arr['status'] == APPROVED || $arr['status'] == REJECT){			
				$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
				$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			}
			$isUpdated = $this->requested_org->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => 'Organization Profile Request update to '.$arr['status'],
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Organization',
			    'kols_or_org_id' => $arrRequestData['org_id'],
			    'transaction_id' =>  $id,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => 'Organization Profile Request update to '.$arr['status'],
			    'parent_object_id' =>   $arrRequestData['org_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			//Update KOL status
			$orgDetails = array();
			$orgDetails['id'] = $arrRequestData['org_id'];
			$orgDetails['status'] = $arr['status'];
			$this->organization->updateOrganization($orgDetails);
			
			if($arr['status'] == APPROVED || $arr['status'] == REJECT || $arr['status'] == COMPLETED){
				//Send mail
				$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
				$data1['arrOrg']=	$arrOrg;
				$data1['arrRequestData']=	$arrRequestData;
				$userNAme = $this->session->userdata('user_name');
				$this->email->from($config['smtp_user'],$userNAme);
				if($arr['status'] == APPROVED){
					$this->email->subject('Organization Profiling Request - Approved');
					$data1['requestAction'] = ANALYST_APPROVE_USER;
				}else if($arr['status'] == REJECT){
					$this->email->subject("Organization Profiling Request - Rejected");
					$data1['requestAction'] = ANALYST_REJECT_USER;
				}else if($arr['status'] == COMPLETED){
					$this->email->subject('Organization Profiling Request - Completed');
					$data1['requestAction'] = ANALYST_COMPLETE_USER;
				}
				$html = $this->load->view('organizations/prepare_email_content',$data1,true);
				$this->email->message($html);
				$this->email->to($userEmailId);
// 				$this->email->send();
				if($this->email->send()){
				    //Log Activity
				    $arrLogDetails = array(
				        'description'=>$html,
				        'type' => LOG_ACTIVITY_EMAIL,
				        'status' => STATUS_SUCCESS,
				        'transaction_name'=>"Organization Profile Request Email Sent",
				        'miscellaneous2'=>"To-".$userEmailId
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity(null,true);
				    $status	=  true;
				}else{
				    //Log Activity
				    $arrLogDetails = array(
				        'description'=>$html,
				        'type' => LOG_ACTIVITY_EMAIL,
				        'status' => STATUS_FAIL,
				        'transaction_name'=>"Organization Profile Request Email Sent",
				        'miscellaneous2'=>"To-".$userEmailId
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity(null,true);
				    $status	=  false;
				}
			}
			
			$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $orgId,$status);
		}
	}
	
	function re_request(){
		$this->isApprover	= IS_APPROVER;
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$orgId = $this->input->post("org_id");
		$arrOrg = $this->organization->editOrganization($orgId);
		//Save Profile Request
		$userRequest = array();
		$userRequest['org_id'] = $orgId;
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		$userRequest['is_re_request'] = 1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}
		$isSaved = $this->requested_org->save($userRequest);
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
		
		//Update KOL status
		/*$orgDetails = array();
		$orgDetails['id'] = $userRequest['org_id'];
		$orgDetails['status'] = $userRequest['status'];
		$this->organization->updateOrganization($orgDetails);*/
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['org_id'] = $userRequest['org_id'];
		$rowData['org_name'] = $this->organization->getOrgNameByOrgId($arrOrg['id']);
		$rowData['status'] = $userRequest['status'];
		$rowData['state'] = $this->Country_helper->getStateById($arrOrg['state_id']);
		$rowData['city'] = $this->Country_helper->getCityeById($arrOrg['city_id']);
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		$data['arrOrg'] = $rowData;
		
		//Send mails
		$mailSent = $this->send_user_request_mails($arrOrg);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
       	echo json_encode($data);
	}
	
	function export_org_detail_old(){
		$type = $this->input->post('type');
		$arrOrgIds = $this->input->post('exportIds');
		
		$arrOrgIds = explode(',',$arrOrgIds);
		//pr($arrOrgIds);
		$arrOrgDeatil = $this->requested_org->getUserRequestDetails($arrOrgIds);
		//pr($arrOrgDeatil);
		//echo $this->db->last_query();
		//pr($arrOrgDeatil);
		if($type==1){
			$arrDetails[0] = array('Status','Name','City','State','Created By');
			
			foreach($arrOrgDeatil as $row){
				
				if($row['request_for'] == REQUEST_TYPE_PROFILE)
       				$row['request_for'] = 'Profile';
       			else
       				$row['request_for'] = 'Upgrade';
				$arrDetail[0] = $row['status'];
				$arrDetail[1] = $row['org_name'];
				$arrDetail[2] = $row['city'];
				$arrDetail[3] = $row['state'];
				$arrDetail[4] = $row['user_first_name']." ".$row['user_last_name'];
				$arrDetails[]=$arrDetail;
			}
		}else{
			
		$arrDetails[0] = array('Status','Name','Approver','City','State','Created By');
			
			foreach($arrOrgDeatil as $row){
				$arrDetail[0] = $row['status'];
				$arrDetail[1] = $row['org_name'];
				$arrDetail[2] = $row['approver_first_name']." ".$row['approver_last_name'];
				if($row['status'] == New1){
	       			$arrDetail[2] = '';
	       		}
				$arrDetail[3] = $row['city'];
				$arrDetail[4] = $row['state'];
				$arrDetail[5] = $row['user_first_name']." ".$row['user_last_name'];
				$arrDetails[]=$arrDetail;
			}
		}
		//pr($arrDetails);
		
		$this->load->plugin('phpxls/writer');
		$workbook = new Spreadsheet_Excel_Writer();
		
		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
		$format_und->setAlign('centre');
		$format_und->setSize(12);
			
		$format_reg =& $workbook->addFormat();
	//	$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
	//	$excelFilters = 'Appoved By:Vinayak';
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		$filterHeaders[0] = 'Filter Name';
		$filterHeaders[1] = 'Filter Value';
		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != '' && $filter != 'Search'){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
		//pr($filters);
		$arr = array(
		      	'Profiles Requested' => $arrDetails,
				'Filters'=>$filters
		      );

		foreach($arr as $wbname=>$rows)
		{
		    
			$rowcount = count($rows);
			$colcount = count($rows[0]);
			
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='Profiles Requested'){
				$worksheet->setColumn(0,0, 20);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 40.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,4, 30.00);
				$worksheet->setColumn(5,5, 30.00);
				
			}
			if($wbname == 'Filters'){
				$worksheet->setColumn(0,0,25);
			    $worksheet->setColumn(1,1,25);
			}

			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
			          
					if ($j==0){
						$fmt =& $format_und;
					                    
					}
					if (isset($rows[$j][$i]))
					{
						$data=$rows[$j][$i];
						$worksheet->write($j, $i, $data, $fmt);
					}
				}
			}
		}
		
		//for downloading the file
		if($type=='1'){
			$fileName ='MyPendingApprovals';
		}else{
			$fileName ='AllOrgRequests';
			
		}
		
		$workbook->send($fileName.'.xls');
		$workbook->close();
	}
	
	function list_requested_orgs(){
		$this->common_helpers->checkUsers();
		$arrKolDetailResult = $this->requested_org->listAll();
		$data			=	array();
		$data['arrOrg']	=	$arrKolDetailResult;
		$data['contentPage'] 	=	'organizations/list_requested_orgs';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List of Requested Organizations Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List of Requested Organizations Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/**
	 * 
	 * @author 	Ramesh B 
	 * @since	
	 * @return 
	 * @created 15 Jan 2014
	 */
	function filters_to_array($reportFilters){
		$filters = array();
		if($reportFilters != ''){
			$reportFiltersElements = explode(':',$reportFilters);
			foreach ($reportFiltersElements as $filterElement){
				$filterElements = explode('=',$filterElement);
				$filterName = $filterElements[0];
				$filterValues = array();
				if(isset($filterElements[1]) && $filterElements[1] != ''){
					$arrFilterValues = explode(',',$filterElements[1]);
					$filterValues = $arrFilterValues;
				}
				if(sizeof($filterValues) > 0)
					$filters[$filterName] = $filterValues;
			}
		}
		return $filters;
	}
	
	function export_org_detail(){
		$this->load->plugin('php_excel/Classes/PHPExcel.php');
		$clientId = $this->session->userdata('client_id');
		$type = $this->input->post('type');
		$arrOrgIds = $this->input->post('exportIds');
		
		$arrOrgIds = explode(',',$arrOrgIds);
		//pr($arrOrgIds);
		$arrOrgDeatil = $this->requested_org->getUserRequestDetails($arrOrgIds);
//		pr($arrKolDeatil);
//		exit();
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Profile Requested');
		//Add header
		if($type==1){
			$objWorksheet->setCellValue('A1', 'Status')
						->setCellValue('B1', 'Name')
						->setCellValue('C1', 'City')
						->setCellValue('D1', 'State')
						->setCellValue('E1', 'Created By')
						->setCellValue('F1', 'Requested On')
						->setCellValue('G1', 'Approved / Rejected On');
				$i	=	2;
				foreach($arrOrgDeatil as $row){
					if($row['request_for'] == REQUEST_TYPE_PROFILE)
	       				$row['request_for'] = 'Profile';
	       			else
	       				$row['request_for'] = 'Upgrade';
	       			
	       			$rej_app_on='';
	       			if(trim($row['rej_or_appr_on'])!=''){	
	       			 $rej_app_on = date("m-d-Y",strtotime($row['rej_or_appr_on']));
	       			}
					$objWorksheet->setCellValue('A'.$i, $row['status'])
								->setCellValue('B'.$i, $row['org_name'])
								->setCellValue('C'.$i, $row['city'])
								->setCellValue('D'.$i, $row['state'])
								->setCellValue('E'.$i, $row['user_first_name']." ".$row['user_last_name'])
								->setCellValue('F'.$i, date("m-d-Y",strtotime($row['requested_on'])))
								->setCellValue('G'.$i, $rej_app_on);
					$i++;
				}
		}else{
			$arrDetails[0] = array('Status','Name','Approver','City','State','Created By');
				
				foreach($arrOrgDeatil as $row){
					$arrDetail[0] = $row['status'];
					$arrDetail[1] = $row['org_name'];
					$arrDetail[2] = $row['approver_first_name']." ".$row['approver_last_name'];
					if($row['status'] == New1){
		       			$arrDetail[2] = '';
		       		}
					$arrDetail[3] = $row['city'];
					$arrDetail[4] = $row['state'];
					$arrDetail[5] = $row['user_first_name']." ".$row['user_last_name'];
					$arrDetails[]=$arrDetail;
				}
				$objWorksheet->setCellValue('A1', 'Status')
						->setCellValue('B1', 'Name')
						->setCellValue('C1', lang("ProfileRequest.Approver"))
						->setCellValue('D1', 'City')
						->setCellValue('E1', 'State')
						->setCellValue('F1', 'Created By')
						->setCellValue('G1', 'Requested On')
						->setCellValue('H1', 'Approved / Rejected On');
				$i	=	2;
				foreach($arrOrgDeatil as $row){
					$objWorksheet->setCellValue('A'.$i, $row['status'])
								->setCellValue('B'.$i, $row['org_name']);
								if($row['status'] == New1){
					       			$objWorksheet->setCellValue('C'.$i, '');
					       		}else{
					       			$objWorksheet->setCellValue('C'.$i, $row['approver_first_name']." ".$row['approver_last_name']);
					       		}
					       		$rej_app_on='';
					       		if(trim($row['rej_or_appr_on'])!=''){
					       		    $rej_app_on = date("m-d-Y",strtotime($row['rej_or_appr_on']));
					       		}
					$objWorksheet->setCellValue('D'.$i, $row['city'])
								->setCellValue('E'.$i, $row['state'])
								->setCellValue('F'.$i, $row['user_first_name']." ".$row['user_last_name'])
								->setCellValue('G'.$i, date("m-d-Y",strtotime($row['requested_on'])))
								->setCellValue('H'.$i, $rej_app_on);
					$i++;
				}
		}
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		foreach ($arrFilters as $filter){
			if($filter != '' && $filter != 'Search'){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('Filters');
			$objWorksheet->setCellValue('A1', 'Filter Name')
								->setCellValue('B1', 'Filter Value');
			$i	=	2;
			foreach($filters as $row){
				$objWorksheet->setCellValue('A'.$i, $row[0])
							->setCellValue('B'.$i, $row[1]);
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
			$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
		if($type==1){
			foreach(range('A','G') as $columnID) {
			    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
			}
        	$objPHPExcel->getSheet(0)->getStyle('A1:G1')->applyFromArray($arrStyles); 
		}else{
			foreach(range('A','H') as $columnID) {
			    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
			}
        	$objPHPExcel->getSheet(0)->getStyle('A1:H1')->applyFromArray($arrStyles); 
		}
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(1)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		if($type=='1'){
			$fileName ='MyPendingApprovals';
		}else{
			$fileName ='AllProfileRequests';
			
		}
		
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=$fileName.xlsx");
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	
}