<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.buttonsWarpper{
		float: right;
		width: 266px;
	}
	.gridWrapper {
	    width: 100%;
	}
        #rightSideBarEnableDisable{
            display:none;
        }
        .excelExportIcon {
    float: right;
    margin-right: 20px;
}
<?php if(IS_IPAD_REQUEST == 1){ ?>
		.tabsContainer li{
			font-size: 12px;
		}
        #load_listMirfResultSet{
            display:none !important;
        }
         .tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
        <?php } ?>
</style>
<script type="text/javascript">
	var action = "<?php echo lang("Overview.Action");?>";
	jqgridIds	= new Array('listMirfResultSet');
	function editMirf(id){
		 window.location=base_url+'interactions/edit_mirf/'+id;
	}
        var lastRequestXHR;
        function cancelLastRequest(){
                lastRequestXHR.abort();
                $("#applyFilter").val("Apply Filters");
                $("#applyFilter").attr("onclick","reloaReport();");
        }
	function viewMirf(id){
                $('#test').hide();
                $('#rightSideBarWrapper').toggle();
		$("#viewMirfContainer").show();
		$("#viewMirfContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#viewMirfContainer").load(base_url+'reports/view_mirf_base/'+id);
        }
	function deleteMirf(id){
		var	formAction = base_url+'interactions/delete_mirf/'+id;
		jQuery("#listMirfResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
		$("#delmodlistMirfResultSet").center();
	}
	
	function listRecordsPerPage(maxRecords,increament){
		var rowList=new Array();
	 	for(i=increament;i<=maxRecords;i+=increament){
	 		rowList.push(i);
	 	} 	
	 	return rowList;
	}
	
	/** 
	* Show/Hide the Search Tool Bar in the JQGrid
	*/
	function toggleSearchToolbar(){ 			
		if(jQuery(".ui-search-toolbar").css("display")=="none") {
			jQuery(".ui-search-toolbar").css("display","");
		} else {
			jQuery(".ui-search-toolbar").css("display","none");
		}
	};

	function filterCurrentReport(data){
		list_mirf_grid(data);
	}
	
	function list_mirf_grid(data){
//            alert(JSON.stringify(data));
// var postData = {};
		var ele=document.getElementById('mirfList');
		var gridWidth=ele.clientWidth - 15;
		jqgridMinWidth = gridWidth;
			$('#mirfList').html('');
		    $('#mirfList').html('<div class="gridWrapper"><div id="listMirfPage"></div><table id="listMirfResultSet"></table><div>');
		    jQuery("#listMirfResultSet").jqGrid({
				url:'<?php echo base_url();?>interactions/list_mirf_grid',
				datatype: "json",
				colNames:['Id','','Date of Request','Products','<?php echo lang("HCP"); ?> Name','Institution','City','State','Zip Code','','','Interaction Id','UOQ Id','MSL/MML Name','',''],
			   	colModel:[
					{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
					{name:'micro',width:41, search:false,align:'left'},
                                        {name:'date_of_request',index:'date_of_request',search:true,width:120},
                                        {name:'products',index:'products',width:110, search:true,width:100},
                                        {name:'kol_id',index:'kol_id',width:100, search:true},
//			   		{name:'specialty',index:'specialty',width:110, search:true},
			   		{name:'institution',index:'institution',search:true,width:100, resizable:false},
//			   		{name:'address',index:'address',search:true,width:60, resizable:false},
                                        {name:'city',index:'city',search:true,width:60, resizable:false},
                                        {name:'state',index:'state',search:true,width:60, resizable:false},
                                        {name:'zip_code',index:'zip_code',search:true,width:60, resizable:false},
                                        {name:'interactionGeneric',index:'interactionGeneric', hidden:true,search:true,width:60, resizable:false},
                                        {name:'interaction_id',index:'interaction_id', hidden:true,search:true,width:60, resizable:false},
                                        {name:'interaction',search:false,width:100},
//                                            formatter: function (cellvalue, options, rowObject) {  
//                                                return "<a href='<?php echo base_url() ?>interactions/view_micro_interaction/"+rowObject.interaction_id+"/1"+"' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>Interaction</a>";
//                                                            //   return ;
//                                        },firstsortorder:'asc'},
                                        {name:'generic_id',index:'generic_id',search:true,width:100, resizable:false},
					{name:'client_id',index:'client_id',width:110,search:true, align:'center',resizable:false},
                                        {name:'eAllowed',index:'eAllowed', hidden:true},
			   		{name:'dAllowed',index:'dAllowed', hidden:true},
//					{name:'act',width:50, hidden:false,align:'center',search:false}	
			   	],
			   	postData:data,
			   	rowNum:10,
			   	multiselect: false,
			   	rownumbers: true,
			   	autowidth: false,
			   	width:gridWidth,
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#listMirfPage',
			   	mtype: "POST",
			   	sortname: 'name',
			    viewrecords: true,
			    sortorder: "desc",
			    shrinkToFit:false,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:"Unsolicited Off-Label Question",
                            loadBeforeSend: function (xhr) { 
                                lastRequestXHR = xhr; 
                            },
			    gridComplete: function(){
                                $("#applyFilter").val("Apply Filters");
	    	$("#applyFilter").attr("onclick","reloaReport();");
					//Get array of id'f from jqgrid			   
			    	var arrIds = jQuery("#listMirfResultSet").jqGrid('getDataIDs'); 
                                var rowData = '';
//                                var interactionId = '';
			    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
			    	var roleId = '<?php echo $this->session->userdata('user_role_id')?>';
			    	var role = '<?php echo ROLE_MANAGER ?>';
			    	for(var i=0;i < arrIds.length;i++){ 
				    	var id = arrIds[i];
                                        var rowData = jQuery('#listMirfResultSet').jqGrid ('getRowData', id);
                                        var interaction_id = jQuery('#listMirfResultSet').jqGrid ('getCell', id, 'interaction_id');
                                        var int_generic_id = jQuery('#listMirfResultSet').jqGrid ('getCell', id, 'interactionGeneric');
//                                         alert(generic_id);
//                                          interactionId = "<a data-ajax='false' href='<?php echo base_url() ?>interactions/view_micro_interaction/" + interaction_id> + rowData.interaction_id + "</a>";
                                          
                                          
//                                         jQuery("#listMirfResultSet").jqGrid('setRowData', arrIds[i], {interaction_id: interactionId});
				    	//Edit and Delete labels 	
			    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
                                        var actionLink;
                                        if((rowData.eAllowed == 'true')){
					    	  actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMirf('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";
					}
                                        if((rowData.dAllowed == 'true')){
					    	 actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteMirf('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                                        } 
//                                        if(roleId==role){
//				    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMirf('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteMirf('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
			    		jQuery("#listMirfResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
//				    	}
			    		//Microview label	
				    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";
			    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewMirf('"+id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View UOQ\">&nbsp;</a></div></label>";
				    	jQuery("#listMirfResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
                                        interactionLink ="<label><div class='tooltip-demo tooltop-right' onclick=\"viewInteractionMicroProfile('"+interaction_id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">"+int_generic_id+"</a></div></label>";  
//                                                "<a href='#"+"' onclick=\"viewInteractionMicroProfile('"+interaction_id+"'); class='link'>"+"int_generic_id"+"</a>";
				    	jQuery("#listMirfResultSet").jqGrid('setRowData',arrIds[i],{interaction:interactionLink}); 
				    	} 
			    	jQuery("#listMirfResultSet").jqGrid('navGrid','hideCol',"id");
			    	//Initialize the tooltips
			    	initializeCustomToolTips();
                                  var postParams = $('#listMirfResultSet').getGridParam("postData");
                //alert(postParams.toSource());
                postParams = JSON.stringify(postParams);
                $("#filterData").val(postParams);
                                 

			    },
			    
				rowList:paginationValues
			});
		    jQuery("#listMirfResultSet").jqGrid('navGrid','#listMirfPage',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#listMirfResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
			//Toggle Toolbar Search 
			jQuery("#listMirfResultSet").jqGrid('navButtonAdd',"#listMirfPage",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
				onClickButton:toggleSearchToolbar
			});
                                            //Add action button in the title bar
                    <?php if (!IS_IPAD_REQUEST) { ?>
                    var buttonsText = "<div class='title-bar-actions'>";
                            buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel();return false;' >	<a rel='tooltip' href='#' title='Export UOQ Detail into Excel format'>&nbsp;</a>	</div>";
                            buttonsText += "</div>";
                     <?php } else { ?>
                    var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
                        buttonsText += '<input type="button" value="Export excel as email" onclick="export_excel();" class="toggle-button" style="margin-top:-3px;">';
                        buttonsText += "</div>";
                    <?php } ?>      
                    $("#mirfList .ui-jqgrid-titlebar").append(buttonsText); 
		}

	$(document).ready(function(){
		//list_mirf_grid();
	});
        function hideViewMirf(){
                $('#rightSideBarWrapper').toggle();
		$('#test').show();
		$("#viewMirfContainer").hide();
                $("#viewInteractionContainer").hide();
	}
            
        function viewInteractionMicroProfile(interactionId){
		$('.tooltip').hide();
                $('#rightSideBarWrapper').toggle();
		$('#test').hide();
		$("#viewInteractionContainer").show();
		$("#interaction-details").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url(); ?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#interaction-details").load(base_url+'interactions/view_micro_interaction/'+interactionId);
	}
        
        function export_excel(){


            

            var excelFilters = '';


            

        

                $(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

                    if($(this).val() != ''){

                        var filterName = $(this).attr('name');

                        var filterValue = $(this).val();

                        excelFilters += filterName+" : "+filterValue+",";

                    }
//                                        alert(excelFilters);

                });

                //$("#excel-filters").val(excelFilters);

                var selectedOPtion = $(".ui-pg-selbox").val();

                $(".ui-pg-selbox option:last").attr('selected','selected');

                $('.ui-pg-selbox').trigger('change');

                if($("#listMirfResultSet").html() != null )

                    var arrIds = jQuery("#listMirfResultSet").jqGrid('getDataIDs');

                else

                    var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//            if($('#orgIntaerctionContainer').css('display')!='block'){
//
//            
//
//                $('#ids').val(arrIds);
//
//            }


            

            

        
               $('#ids').val(arrIds);
            $("#excel-filters").val(excelFilters);

        //    return false;

            <?php if (!IS_IPAD_REQUEST) { ?>
            $('#export').submit();
            <?php } else { ?>
                      var data= $("#export").serialize();
                           sendMail(data);
            <?php } ?>

            $(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

            $('.ui-pg-selbox').trigger('change');

        }
        function sendMail(data){
        alert("Excel has been mailed successfully.");
      $.ajax({
         
                    url: "<?php echo base_url()?>reports/send_email_for_export_reports/UOQ",
                            dataType: "json",
                            data: data,
                            type: "POST",
                            success: function (responseText) {
                           
                            },
                            complete: function () {
                           
                            }
                    });               
    }

</script>
<form action="<?php echo base_url()?>reports/export_uoq/" method='post' id="export">
		<input type="hidden" id="ids" name="list_mirf" value=""></input>
                <input type="hidden" id="filterData" name="filter" value=""></input>
                <!--<input type="hidden" name="filters" value="" id="excel-filters" />-->
	</form>
<?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a>
	</div>
<?php }?>
<div id="container">
   
		<div class="tabsWrapper" id="test">
			<ul class="tabsContainer">
				<li class="current" name="tab0"><a id="list" href="#">Report</a></li>
				<!--<li name="tab1"><a id="chart" href="#">chart</a></li>-->
			</ul>
			<div class="tabsContent">
				<div class="tab0 tabContent" style="display:block;">
<!--					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;top: -27px;">
						<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
					</div>-->
                                    <div id="mirfList" class="clear">Please select filter for report</div>
				</div>
				
				
               
			</div>
		</div>
      <div id="viewMirfContainer"></div>
      <div id="viewInteractionContainer" style="display: none;">
	<div id="interaction-details">&nbsp;</div>
</div>
     
</div>
