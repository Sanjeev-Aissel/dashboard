<?php
if($profileType=='country'){
//To show row list in jqgrid
	function listRecordsPerPage($maxRecords=1000,$increament=10){
		$rowList="";
		for($i=100;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 
	
		$page						= 1; // get the requested page 
		$limit						= 10;
		$count					= sizeof($arrEvents);				
		if( $count >0 ){ 
			$total_pages 		= ceil($count/$limit); 
		}else{ 
			$total_pages 		= 0; 
		} 
		$data['records'] 		= $count;
		$data['total']   		= $total_pages;
		$data['page']           = $page;				
		$data['rows']    		= $arrKols;  
?>

	<style type="text/css">
		#kolsListingContainer{
			margin:10px;
		}
		
		#kolsListingContainer h2, #eventsListingContainer h3{
			text-align:left;
			font-weight:normal;
		}
		
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			padding: 0px;
			padding-left:4px;
		}
		.ui-widget-header {
		    background-image: none;
		}
		.ui-jqgrid .ui-jqgrid-title {
		    font-size: 13px;
		    padding-left: 1px;
		}
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			border-bottom:1px solid #EEEEEE;
		}
		h2 {
		    color: #626262;
		    font-family: lucida grande,tahoma,verdana,helvetica,arial !important;
		    font-size: 12px;
		    font-weight: bold !important;
		}
		.gridWrapper .ui-jqgrid tr.ui-search-toolbar th div {
		    text-align: left;
		}
	</style>
	
	
<script type="text/javascript">

	var paginationValues		= new Array();
	<?php 
		$paginationValues	= explode(',',PAGINATION_VALUES);
		foreach($paginationValues as $key=>$value){
	?>
		paginationValues.push('<?php echo $value;?>');
	<?php
		}
	?>
	var arrExcludeColumnsInExcelExport = new Array(); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id');
	$(document).ready(function(){
		var data = <?php echo json_encode($data);?>;
		jQuery("#JQBlistKolResultSet").jqGrid({
		  
			datatype: "jsonstring",
	        datastr: data,
		   	colNames:['Id','<?php echo lang('KOL');?>','Specialty','Country','State','City'],
		   	colModel:[
		   	    {name: 'id', index: 'id', hidden: true},
		   	    {name:'name',index:'name',search:true},
		   		{name:'specialty',index:'specialty'},
		   		{name:'country',index:'country'},
		   		{name:'state',index:'state'},
		   		{name:'city',index:'city'}			   		
		   	],
		   	rowNum:10,
		   	rownumbers: true,
		   	//autowidth: true, 
			
			gridComplete: function(){ 
	    		jQuery("#JQBlistKolResultSet").jqGrid('navGrid','hideCol',"id"); 
	    		var ALL = '<?php echo $count?>' ;
	    		$.each($('.ui-pg-selbox'),function(){
	    			$(this).children('option:last').val(ALL).text('All');
	    		});	    		
    	        var ids = jQuery("#JQBlistKolResultSet").jqGrid('getDataIDs');
    	       /* var be	= '';
    	        for (var i = 0; i < ids.length; i++) {
    	        	be = '';
    	            var rowData = jQuery("#JQBlistEventResultSet").jqGrid('getRowData', ids[i]);
    	            var cl = rowData.id;
    	            var val =jQuery("#JQBlistEventResultSet").jqGrid('getCell',ids[i],'attended_kols');
    	            be = "<a href='#' onclick=getKols('"+cl+"')>"+val+"</a>";
                    jQuery("#JQBlistEventResultSet").jqGrid('setRowData', ids[i], {attended_kols: be});
    	        } */
	    	}, 
		   	loadonce:true,
		   	multiselect: false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	width: 800,  
		   	pager: '#listlistKolPage',		   	
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
			rowList:paginationValues,
		    jsonReader: { repeatitems : false, id: "0" },
		    //toolbar: "top",
		    caption:'<?php echo lang('KOL');?>s',
		    rowList:paginationValues
	   	
		});
	
		jQuery("#JQBlistKolResultSet").jqGrid('navGrid','#listlistKolPage',{edit:false,add:false,del:false,search:false,refresh:false});
		
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistKolResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistKolResultSet").jqGrid('navButtonAdd',"#listlistKolPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

			// Set the JSON data
			//var data = <?php echo json_encode($arrEvents);?>;
			//jQuery("#JQBlistEventResultSet").jqGrid('addRowData',2,data);
			
			//Place holder to Jqgrid Search Column
			$(".ui-search-toolbar input[type='text']").each(function(){
				$(this).attr("placeholder","Search");
		    });
			
			<?php 
	    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
				if(preg_match('/MSIE/i',$u_agent)){
	    	?>
	    	$('.ui-search-toolbar input[placeholder]').each(function(){
	    		$(this).after("<span class='jq-placeholder'>"+$(this).attr('placeholder')+"</span>"); 
	            var input = $(this);       
	            $(input).focus(function(){
	                $(this).next().hide();
	            });
	            $(input).blur(function(){
	                 if (input.val() == '') {
	                	 $(this).next().show();
	                 }
	            });
	        });

	        $(".jq-placeholder").live("click",function(){
	        	$(this).hide();
	        	$(this).prev().focus();
		    });
	        <?php }?>
		
	});
	//- End of DOCUMENT.READY function
	var base_url = "<?php echo base_url(); ?>";
</script>

</head>
<body>
<?php // pr($data); ?>
    <div style="position: relative;z-index: 999;float: right;margin-right: -25px">
		<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-top: -30px;" onclick="exportExcel('#JQBlistKolResultSet','<?php echo lang('KOL')?>');">
        	<a href="#" rel="tooltip" data-original-title="Export <?php echo lang('KOL')?>s Details into Excel format">&nbsp;</a>
        </div>
	</div>
    <div class="clear"></div>
    <div id="kolsListingContainer">
    		<div id="searchResultsContainer">			
    			<div class="gridWrapper" id="gridContainer">
    							<div id="listlistKolPage"></div>
    							<table id="JQBlistKolResultSet"></table>
    			</div>	
    		</div>
    	
    </div>
<?php } 
if($profileType=='publication'){
    function listRecordsPerPage($maxRecords=1000,$increament=100){
        $rowList="";
        for($i=100;$i<=$maxRecords;$i+=$increament){
            $rowList.=$i.",";
        }
        $rowList=substr($rowList,0,-1);
        return $rowList;
    }
?>
<style type="text/css">
		#publicationsListingContainer{
			margin:10px;
		}
		
		#publicationsListingContainer h2, #publicationsListingContainer h3{
			text-align:left;
			font-weight:normal;
		}
		
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			padding: 0px;
			padding-left:4px;
		}
		.ui-widget-header {
		    background-image: none;
		}
		.ui-jqgrid .ui-jqgrid-title {
		    font-size: 13px;
		    padding-left: 1px;
		}
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			border-bottom:1px solid #EEEEEE;
		}
		h2 {
		    color: #626262;
		    font-family: lucida grande,tahoma,verdana,helvetica,arial !important;
		    font-size: 12px;
		    font-weight: bold !important;
		}
		.gridWrapper .ui-jqgrid tr.ui-search-toolbar th div {
		    text-align: left;
		}
		.microView{
          position: fixed !important;;
          top: 5px !important;  
          height:435px !important;        
        }
        .microView .profileContent{
            height: 425px;
        }
	</style>
	
		<?php 
			
			$i=0;
			// Create the Required ARRAY, using the PHP
			
			foreach($arrPublications as $row){
				if($row['link'] == '')
					$row['link']=base_url().'pubmeds/view_publication/'.$row['id'];
				//$articleTitle	= '<a onClick="viewPubMicroProfile('.$row["id"].')">';
				//$articleTitle	.= '<img class="micro_view_icon" src="'.base_url().'images/user3.png" />';
				//$articleTitle	.= '</a>';
				$articleTitle	= htmlspecialchars($row['article_title']);
				$snapshot_view	= "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewPubMicroProfile('".$row['id']."');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Publication Snapshot\">&nbsp;</a></div></label>";
				//$snapshot_view	= "<label onclick=\"viewPubMicroProfile('".$row['id']."');\" ><img class='micro_view_icon'  title='MicroView' src='".base_url()."images/user3.png'></label>";
				if($row['pmid'] == null)
					$row['pmid'] = '';
				$arrData[] =  array(
									//'snapshot_view'=>$snapshot_view,
									'article_title' => $articleTitle,
									'journal_name'	=> $row["journal_name"],
									'created_date'	=> sql_date_to_app_date($row['created_date']),
									'auth_position'	=> $row['auth_pos'],
									'id'=>$row['id'],
									'pmid'=>$row['pmid'],
				                    'authcount'=>$row['authcount']
									);
			
			}
			
		$page						= 1; // get the requested page 
		$limit						= 10;
		$count					= sizeof($arrData);				
		if( $count >0 ){ 
			$total_pages 		= ceil($count/$limit); 
		}else{ 
			$total_pages 		= 0; 
		} 
		$data['records'] 		= $count;
		$data['total']   		= $total_pages;
		$data['page']    = $page;				
		$data['rows']    		= $arrData;  
			//- End of creating the required ARRAY
		?>	
	
<script type="text/javascript">
	var publicationsTitle = "<?php echo lang("Overview.PUBLICATIONS");?>";
	var articleTitleHeader = "<?php echo lang("Overview.ArticleTitle");?>";
	var journalNameHeader = "<?php echo lang("Overview.JournalName");?>";
	var dateHeader = "<?php echo lang("Overview.Date");?>";
	var authPositionHeader = "<?php echo lang("Mykols.AuthPosition");?>";
	var profileRequestConfirmMessage = 'Do you want to submit this request for a Full Profile to be built for this Contact?';
	var ROLE_MANAGER 	= '<?php echo ROLE_MANAGER?>';
	var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
	var ROLE_USER		= '<?php echo ROLE_USER?>';
	var arrExcludeColumnsInExcelExport = new Array('snapshot_view'); 
	$(document).ready(function(){
		// Settings for the Dialog Box
		var pubMicroProfileDialogOpts = {
				title: "Publication Snapshot",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		var data = <?php echo json_encode($data);?>;
		$("#pubMicroProfile").dialog(pubMicroProfileDialogOpts);	
		jQuery("#JQBlistPublicationResultSet").jqGrid({
			url:base_url+'pubmeds/list_publication_by_kol/'+<?php echo $kolId?>,
			datatype: "json",
			<?php if(isset($first_name)){?>
		   	colNames:['','',articleTitleHeader,journalNameHeader,dateHeader,authPositionHeader,'Number of Authors'],
		   	<?php } else {?>
		   	colNames:['','',articleTitleHeader,journalNameHeader,dateHeader,'Number of Authors'],
		   	<?php }?>
		   	colModel:[
				{name:'id',index:'id',width:8,search:false,hidden:true},
		   	    {name:'snapshot_view',index:'snapshot_view',width:15,search:false},
		   		{name:'article_title',index:'article_title',width:200,

		   	     formatter: function (cellvalue, options, rowObject) {
		
		   	    	if(rowObject.pmid != ''){
						var id= rowObject.id;
				        return "<a href='http://www.ncbi.nlm.nih.gov/pubmed/"+rowObject.pmid+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				            $.jgrid.htmlEncode(cellvalue) + "</a>";
					}else{
					var id= rowObject.id;
				        return "<a href='"+base_url+"/pubmeds/view_publication/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
			            $.jgrid.htmlEncode(cellvalue) + "</a>";
					}
					
		    	},firstsortorder:'asc'},
		   		{name:'journal_name',index:'journal_name',width:150},
		   		{name:'created_date',index:'created_date',width:40,sorttype: 'date',formatoptions: {newformat:'m/d/Y'}, datefmt: 'M-D-Y'},
		   		<?php if(isset($first_name)){?>
		   			{name:'auth_position',index:'count',width:30,sorttype:'int',search:false},
		   		<?php }?>
		   		{name:'authcount',index:'authcount',width:50,search:false,
			   		formatter: function (cellvalue, options, rowObject) {
		
		   	    	if(rowObject.authcount >0){
						var id= rowObject.id;
				        return "<a href='#/' onclick=getKols('"+rowObject.id+"')>"+rowObject.authcount+"</a>";
					}else{
						return rowObject.authcount;
					}
					
		    	},firstsortorder:'desc'}
		   	],
		   	rowNum:10,
		   	gridComplete: function(){ 
		    var ids = jQuery("#JQBlistPublicationResultSet").jqGrid('getDataIDs'); 
		    	for(var i=0;i < ids.length;i++){ 
				   	var cl = ids[i];	
			    	var ret = jQuery("#JQBlistPublicationResultSet").jqGrid('getRowData', cl);	
			    	val = ret.is_manual;	
			    	var clientId =	'<?php echo $this->session->userdata('client_id')?>';
			    	if(ret.client_id == clientId ){								    	
			    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></label>";
			    		jQuery("#JQBlistPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 	
			    	}		    	
			    //	be = "<label onclick=\"viewPubMicroProfile('"+cl+"');\" ><img class='micro_view_icon'  title='MicroView' src='<?php echo base_url()?>images/user3.png'></label>";
			    //	jQuery("#JQBlistPublicationResultSet").jqGrid('setRowData',ids[i],{micro:be}); 

			    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewPubMicroProfile('"+ret.id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Publication Snapshot\">&nbsp;</a></div></label>";
			    	jQuery("#JQBlistPublicationResultSet").jqGrid('setRowData',ids[i],{snapshot_view:microviewLink}); 
			    	} 
		    	jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
		    	// tooltip demo
		    	<?php $mobile = mobile_device_detect(); 
				if(!isset($mobile[1])){	?>			
					initializeCustomToolTips();
				<?php }?>
		    	}, 
		    	
		   	rownumbers: true,
		   	autowidth: true, 
			rowNum:10,
		   	loadonce:false,
		   	multiselect: false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	width: 800,  
		   	pager: '#listlistPublicationPage',		   
		   	mtype: "POST",
		   	sortname: 'created_date',
		    viewrecords: true,
		    sortorder: "desc",
			rowList:paginationValues,
		    jsonReader: { repeatitems : false, id: "0" },
		    //toolbar: "top",
		    caption:publicationsTitle,
		    gridview: true			
	   	
		});
	
		jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid','#listlistPublicationPage',{edit:false,add:false,del:false,search:false,refresh:false});
		
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistPublicationResultSet").jqGrid('navButtonAdd',"#listlistPublicationPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		var ALL = '<?php echo $count?>' ;
		$.each($('.ui-pg-selbox'),function(){
		$(this).children('option:last').val(ALL).text('All');
		});
			// Set the JSON data
			//var data = <?php echo json_encode($data);?>;
			//jAlert(data.toSource());
			//jQuery("#JQBlistPublicationResultSet").jqGrid('addRowData',2,data);

		//Place holder to Jqgrid Search Column
		$(".ui-search-toolbar input[type='text']").each(function(){
			$(this).attr("placeholder","Search");
	    });

    	<?php 
    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			if(preg_match('/MSIE/i',$u_agent)){
    	?>
    	$('.ui-search-toolbar input[placeholder]').each(function(){
    		$(this).after("<span class='jq-placeholder'>"+$(this).attr('placeholder')+"</span>"); 
            var input = $(this);       
            $(input).focus(function(){
                $(this).next().hide();
            });
            $(input).blur(function(){
                 if (input.val() == '') {
                	 $(this).next().show();
                 }
            });
        });

        $(".jq-placeholder").live("click",function(){
        	$(this).hide();
        	$(this).prev().focus();
	    });
        <?php } ?>       
    	var showKolsContainerOptions = {
				title: "<?php echo lang("HCP");?>",
				modal: true,
				autoOpen: false,
				width: 800,
				minHeight:400,
				dialogClass: "microView",
				position: ['center', '100'],
				open: function() {
					//display correct dialog content
				}
		};
		$('#showKols').dialog(showKolsContainerOptions); 
        
		
	});
	//- End of DOCUMENT.READY function
	
	/**
	* Opens the Modal Box with the Micro Profile content of KOL
	* @param: kolId
	*/
	function viewPubMicroProfile(pubId){
		$('.tooltip').remove();
		$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#pubMicroProfile").dialog("open");
		$(".profileContent").load('<?php echo base_url().'pubmeds/view_micro_pub/'?>'+pubId);
		return false;
	}

	function initializeCustomToolTips(){
		
		$('.tooltip-demo.tooltop-top').tooltip({
	      selector: "a[rel=tooltip]", placement:'top'
	    });
	    $('.tooltip-demo.tooltop-bottom').tooltip({
	      selector: "a[rel=tooltip]", placement:'bottom'
	    });
	    $('.tooltip-demo.tooltop-right').tooltip({
	      selector: "a[rel=tooltip]", placement:'right'
	    });
	    $('.tooltip-demo.tooltop-left').tooltip({
	      selector: "a[rel=tooltip]", placement:'left'
	    });

	}
	function getKols(pubId){
		$("#showKols .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#showKols").dialog("open");
		$('#showKolsContainer').load('<?php echo base_url().'pubmeds/get_auth_by_pub_id/'?>'+pubId);
		return false;
	} 
function addNewKolProfile(KolId,thisEle){
		
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		jConfirm(profileRequestConfirmMessage,"Confirm message",function (r){
			if(r){
				requestProfile(KolId,thisEle);
				return false;
			}else{
				return false;
			}
		});
	}

	function requestProfile(KolId,thisEle){
		var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
					$(thisEle).remove();
					//jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
					//window.location = '<?php echo base_url()?>requested_kols/show_client_requested_kols';
					//notRequesetdKOls();
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
	}
	function exportExcel(kolId,filename){
		//alert(kolId); alert(filename); return false;
		$.ajax({
            url: "<?php echo base_url()?>pubmeds/export_list_publication_by_kol_details/"+kolId+"/"+filename,
            dataType: "json",
                   // data: data,
                    type: "POST",
                    success: function (responseText) {
                       if(responseText.status == true){
                       	
                       }
                    },
      }); 
		
	}
</script>

</head>
<body>

<div class="clear"></div>
<div id="publicationsListingContainer">
		<h2> 
		<?php if(isset($first_name)){?>
			[ <?php echo $first_name." ".$middle_name." ".$last_name;?> ]
		<?php }?>
		</h2>
		<?php if($fromYear!='' && $toYear!='' ){?>
			<h2>Year Range : <?php echo $fromYear;?> - <?php echo $toYear;?></h2>
		<?php }?>
		
        <div style="position: relative;z-index: 999;float: right;margin-right: -25px;margin-top: 27px;">
			<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-top: -30px;" onclick="exportExcel('<?php echo $kolId;?>','publications');">
            	<a href="#" rel="tooltip" data-original-title="Export Publications Details into Excel format">&nbsp;</a>
            </div>
		</div>
		<div id="searchResultsContainer">
		
			<div class="gridWrapper" id="gridContainer">
							<div id="listlistPublicationPage"></div>
							<table id="JQBlistPublicationResultSet"></table>
			</div>	
		</div>
		
		<!-- Container for the 'Publication Micro Profile' modal box -->
		<div id="dailog1">	
			<div id="pubMicroProfile" class="microProfileDialogBox">
				<div class="profileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Publication Micro Profile' modal box -->
	
		<p style="text-align: right;margin-top: 10px;width: 98%;">Publications are obtained from PubMed.gov. Click on the links to go to PubmMed.</p>
</div>
<div id="showKols" class="microProfileDialogBox">
	<div id="showKolsContainer"  class="profileContent"></div>
</div>
<?php } ?>