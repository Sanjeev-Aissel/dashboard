
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery-ui-1.8.16/ui/jquery.ui.accordion',
    'jquery/jquery.validate1.9.min');

// add the JS files into queue i.e Append to the existing queue
$prevjs = $this->config->item('js_files_to_load');
if ($prevjs == null)
    $prevjs = array();
$this->config->set_item('js_files_to_load', array_merge($prevjs, $queued_js_scripts));
?>
<style>
	.hiddenRow{
		display: none;
	}
	.oneMoreRow{
		display: none;
	}
</style>
<h3>Staff</h3>

<div id="staffSection">
	<form action="<?php echo base_url()?>kols/save_staff" name="staffFrom" id="staffFrom" method="post">
		<table>
		  	<tr>
			    <th>Title</th>
			    <th>Name</th>
			    <th>Phone</th>
		  	</tr>
		  	<?php foreach($staffs as $key => $staff){?>
			<tr rsl="<?php echo $key;?>" class="hiddenRow">
				<td>
					<input type="hidden" name="staffs[<?php echo $key?>][id]" value="<?php echo $staff['id'];?>" />
					<input type="hidden" name="staffs[<?php echo $key?>][update]" value="0" />
					<select name="staffs[<?php echo $key?>][title]" class="required">
						<option value="Administrative Assistant" <?php if($staff['title'] == 'Administrative Assistant') echo "selected = 'selected'"?>>Administrative Assistant</option>
					</select>
				</td>
				<td>
					<input type="text" name="staffs[<?php echo $key?>][name]" value="<?php echo $staff['name'];?>" class="required" />
				</td>
				<td>
					<input type="text" name="staffs[<?php echo $key?>][phone_number]" value="<?php echo $staff['phone_number'];?>" class="required" />
				</td>
				<td>
					<a id="#" onclick="cancelEdit(this,'staffs'); return false;">Cancel</a>
				</td>
			</tr>
			<tr rsl="<?php echo $key;?>" >
				<td>
					<?php echo $staff['title'];?>
			 	</td>
			 	<td>
					<?php echo $staff['name'];?>
			 	</td>
			 	<td>
					<?php echo $staff['phone_number'];?>
			 	</td>
			 	<td>
					<a id="#" onclick="editRow(this,'staffs'); return false;">Edit</a>|delete
				</td>		
			</tr>
			<?php }$key=1000;?>
			<tr rsl="<?php echo $key;?>" class="">
				<td>
					<select name="staffs[<?php echo $key?>][title]" class="required">
						<option value="Administrative Assistant" >Administrative Assistant</option>
					</select>
				</td>
				<td>
					<input type="text" name="staffs[<?php echo $key?>][name]" value=""  class="required"/>
				</td>
				<td>
					<input type="text" name="staffs[<?php echo $key?>][phone_number]" value=""  class="required"/>
				</td>
				<td>
					<a href="#" onclick="removeRow(this); return false;">remove</a>
				</td>
			</tr>
		</table>
		<a href="#" onclick="addMoreRow(this); return false;">addmore</a>
		<input type="button" value="Save" onclick="saveStaff();return false;">
	</form>
	<div class="oneMoreRow">
		<table>
			<td>
				<select name="staffs[replace_value][title]" class="required">
					<option value="Administrative Assistant" >Administrative Assistant</option>
				</select>
			</td>
			<td>
				<input type="text" name="staffs[replace_value][name]" value=""  class="required"/>
			</td>
			<td>
				<input type="text" name="staffs[replace_value][phone_number]" value=""  class="required"/>
			</td>
			<td>
				<a href="#" onclick="removeRow(this); return false;">remove</a>
			</td>
		</table>
	</div>
</div>

<script type="text/javascript">
	function editRow(thisEle,moduleText){
		$(thisEle).parent().parent().hide();
		$(thisEle).parent().parent().prev().show();
		var id = $(thisEle).parent().parent().attr('rsl');
		$("input[name='"+moduleText+"["+id+"][update]']").val('1');
	}

	function cancelEdit(thisEle,moduleText){
		$(thisEle).parent().parent().next().show();
		$(thisEle).parent().parent().hide();
		var id = $(thisEle).parent().parent().attr('rsl');
		$("input[name='"+moduleText+"["+id+"][update]']").val('0');
	}

	function saveStaff(){
		if (!$("#staffFrom").validate().form()) {
            return false;
        }
		$("#staffFrom").submit();
        return true;
		/*var data = $("#staffFrom").serialize();
		$.ajax({
			url:base_url+"kols/save_staff",
			data:data,
			dataType:"JSON",
			type:"POST",
			success:function(returnData){
				
			}
			
		});*/
	}

	function addMoreRow(thisEle){
		var rowText = $(thisEle).parent().next().children('table').children('tbody').children('tr').html();
		var lastRsl = $(thisEle).prev().children('tbody').children().last().attr('rsl');
		lastRsl++;
		rowText = rowText.replace("replace_value",lastRsl);
		rowText= "<tr rsl='"+lastRsl+"'>"+rowText+"</tr>";
		$(thisEle).prev().children('tbody').append(rowText);
		
	}

	function removeRow(thisEle){
		$(thisEle).parent().parent().remove();
	}
</script>

