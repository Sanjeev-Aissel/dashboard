<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contracts extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('contract');
		$this->load->model('helpers/common_helper');
	}
	function list_kol_contracts($kolId=null){
		// Getting the KOL details
		$this->load->model('kols/kol');
		if($kolId!=null){
			$kolId					= $this->common_helper->getKolClientVisiblityId($kolId);
			$arrKolDetail 			= $this->kol->editKol($kolId);
			// If there is no record in the database
			if (!$arrKolDetail) {
				return false;
			}
			$data['arrKol'] 		= $arrKolDetail;
		}
		$module_name			='contracts';
		$data['module_id']		=$this->common_helper->getModuleIdByModuleName($module_name);

		$data['contentPage'] 	='list_kol_contracts';
		$data['contentData']	=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function list_contracts($kolID='',$contractType){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrInteractions	= array();
		$data				= array();
		if(!is_numeric($kolID)){
			$contractType = 'track';
		}
		$arrContractsResult = $this->contract->listContracts($kolID,$contractType);
		$arrContracts=array();
		foreach($arrContractsResult as $row){
			if($row['kol_id']>0){
				$row['contract_type'] = 'kol';
			}else{
				$row['contract_type'] = 'org';
			}
			$row['eAllowed'] = $this->common_helper->isActionAllowed('contract', 'edit', $row);
			$row['dAllowed'] = $this->common_helper->isActionAllowed('contract', 'delete', $row);
			if($row['end_date']!='0000-00-00'){
				$todays_date = date("Y-m-d");
				$today = strtotime($todays_date);
				$expiration_date = strtotime($row['end_date']);
				if ($expiration_date >= $today) {
					$row['is_expired'] ='Not expired';
				} else  {
					$row['is_expired'] ='Expired';
				}
			}
			$row['start_date']=$this->common_helper->convertDateToMM_DD_YYYY($row['start_date']);
			if($row['start_date']=='00/00/0000'){
				$row['start_date']='';
			}
			$row['end_date']=$this->common_helper->convertDateToMM_DD_YYYY($row['end_date']);
			if($row['end_date']=='00/00/0000'){
				$row['end_date']=' ';
			}
			if($row["contract_file"]!=null){
				$url='#';
				if($this->common_helper->isActionAllowed('contract', 'download', $row)){
					$url = base_url().'contracts/contracts/file_download/'.$row["id"];
				}
				$row['contract_file']='<a class="tooltipLink" rel="tooltip" title="Download Contract" href="'.$url.'"><div class="actionIcon downloadIcon tooltip-demo tooltop-left"></div></a>';
			}
			$arrContracts[]=$row;
		}
		$count=sizeof($arrContracts);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrContracts;
		echo json_encode($data);
	}
	function delete_contract($contractId){
		if($this->contract->deteleteContract($contractId)){
			$arr['mes']=true;
		}else{
			$arr['mes']=false;
		}
		echo json_encode($arr);
	}
	function file_download($contractId){
		$arrContracts = $this->contract->getContractDetailsById($contractId);
		$this->load->helper('download');
// 	$data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/contract_documents/".$arrContracts['contract_file']);
		$data =  file_get_contents(APPPATH."documents/contract_documents/".$arrContracts['contract_file']);
		$name = $arrContracts['doc_name'];
		force_download($name, $data);
	}
	function add_contract($contractType,$kolId='',$contractId=null){
		$data['arrContract']='';
		if($contractId!=null){
			$arrContracts = $this->contract->getContractDetailsById($contractId);
			$arrContracts['start_date']=$this->common_helper->convertDateToMM_DD_YYYY($arrContracts['start_date']);
			if($arrContracts['start_date']=='00/00/0000'){
				$row['start_date']='';
			}			
			$arrContracts['end_date']=$this->common_helper->convertDateToMM_DD_YYYY($arrContracts['end_date']);
			if($arrContracts['end_date']=='00/00/0000'){
				$arrContracts['end_date']=' ';
			}
			$data['arrContract'] = $arrContracts;
		}
		if(is_numeric($kolId)!=''){
			if($contractType=='kol'){
				$data['kolId'] = $kolId;
				$arrKols = $this->contract->getAllKolsName1();
				$data['kol_name'] = $arrKols[$kolId];
				$data['contract_type'] = $contractType;
				$kols_or_org_type = 'Kol';
				$kols_or_org_id = $kolId;
			}else{
				$data['kolId'] = $kolId;
				$arrKols = $this->contract->getAllOrgName1();
				$data['kol_name'] = $arrKols[$kolId];
				$data['contract_type'] = $contractType;
				$kols_or_org_type = 'Organization';
				$kols_or_org_id = $kolId;
			}
		}else{
			$data['contract_type'] = 'track';
			$kols_or_org_type = '';
			$kols_or_org_id = 0;
		}
		$this->load->view('add_contract',$data);
	}
	function delete_file($fileName,$contractId){
		$arrContract['contract_file'] 	= '';
		$arrContract['id']	 	=$contractId;
		if($this->contract->updateContract($arrContract)){
			unlink(APPPATH."documents/contract_documents/".$fileName);
			$data['saved']=true;
		}else{
			$data['saved']=false;
		}
		echo json_encode($data);
		
	}
	function save_contract1(){
		$clientId = $this->session->userdata('client_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$kolId = $this->input->post('kol_id');
		if(!empty($kolId)){
			if(!is_numeric($kolId)){
				$kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
			}
			$arrContract['kol_id'] = $kolId;
		}else{
			$arrContract['kol_id'] = 0;
		}
		$arrContract['id'] 						= $this->input->post('id');
		$arrContract['contract_name'] 			= $this->input->post('contract_name');
		$arrContract['kol_name'] 				= $this->input->post('kol_name');
		$arrContract['org_id'] 					= $this->input->post('org_id');
		$arrContract['start_date'] 				= app_date_to_sql_date($this->input->post('start_date'));
		$arrContract['end_date'] 				= app_date_to_sql_date($this->input->post('end_date'));
		$arrContract['contract_description']	= $this->input->post('contract_description');
		$arrContract['client_id']  				= $clientId;
		$arrContract['data_type_indicator']		= $dataType;
		if($_FILES["contract_file"]['name']!=''){
			$target_path 				= APPPATH."documents/contract_documents/";
			$path_info 					= pathinfo($_FILES["contract_file"]['name']);
			$newFileName				= random_string('unique', 20).".".$path_info['extension'];
			$overview_file_target_path	= $target_path ."/". $newFileName;
			move_uploaded_file($_FILES['contract_file']['tmp_name'],$overview_file_target_path);
			$arrContract['contract_file']	= $newFileName;
			$arrContract['doc_name'] 		= $_FILES["contract_file"]['name'];
		}
		if($arrContract['id']>0){
			$arrContract['modified_by']=$this->session->userdata('user_id');
			$arrContract['modified_on']=date("Y-m-d H:i:s");
			$contract_id=$this->common_helper->updateEntity('contracts',$arrContract,array('id'=>$arrContract['id']));
		}else{
			$arrContract['created_by']=$this->session->userdata('user_id');
			$arrContract['created_on']=date("Y-m-d H:i:s");
			$contract_id=$this->common_helper->insertEntity('contracts',$arrContract);
		}
		if($contract_id>0){
			$returnData['saved']	=true;
			$returnData['msg']		="Contract Details are successfully updated";
		}else{
			$returnData['saved']	=false;
			$returnData['msg']		="Contract in updating the event details,Please try again.";
		}
		//New Recorded Email
// 		$arrReturnResult	= $this->contract->getAssignedUsersForType($kols_or_org_id,$kol_org_type);
// 		$user_email	= $arrReturnResult['user_details'];
// 		$type_name	= $arrReturnResult['type_name'];
		// 		$arrConfig = $this->common_helpers->getMailConfig(USER,PASS);
		// 		$arrInfo = array (
		// 				'FROM' => USER,
		// 				'FROM_NAME' => SENDER,
		// 				'TO' => $user_email,
		// 				'CC' => array(""),
		// 				'SUBJECT' => "New Contract : $type_name",
		// 				'MAIL_BODY' => "<html>
		// 				<head>
		// 				<style>
		// 				table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
		// 				td, th { border: 1px solid #CCC; height: 30px; }
		// 				th { background: #F3F3F3; font-weight: bold; }
		// 				td { background: #FAFAFA; text-align: center;}
		// 				</style>
		// 				</head>
		// 				<body>
		// 				<div>
		// 				Hi, <br/><br/> This is a notification about a contract that has been recorded with $type_name.<br><br>
		// 				Please $urlLink to view the contract.<br/><br/>
		// 				<br>Regards,<br>Aissel Support Team<br>
		// 				</div>
		// 				</body>
		// 				</html>"
		// 		);
		// 		$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
		echo json_encode($returnData);
	}
}
?>