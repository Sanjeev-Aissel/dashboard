
<?php
/**
 * File to 'List' Clinical trails for client view page
 *
 * @author: Ambarish N
 * @created on: 1-02-11
 * @package application.views.clinicals
 */
function listRecordsPerPageCt($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}

	$queued_js_scripts = array('chosen.jquery','kols/list_clinical_trials_client_view','i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min','jquery/jquery-ui-1.8.16.datepicket','CalendarControl','jqgridExportToExcel');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>	
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
		
<style type="text/css">#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}

	.analystForm input[type="text"], .analystForm select {
/*		width:250px;*/
	}
	.analystForm input[type="text"], .analystForm select, .analystForm textarea {
/*		margin:0;
		padding:2px;
*/
	}
	.validateForm label {
		color:DimGray;
	/*	display:block;*/
		font-size:12px;
		padding-right:8px;
		text-align:left;
	}
	.analystForm label{
		width:64%;
	}
	#CalendarControlIFrame{
		display: none;
	}
	.exportOptionsContainer ul:first-child li .addIcon {
    	background-position: -150px -165px;
	}
	div.editIcon{
		margin-left: 10px;
	}
</style>		
<script type="text/javascript" language="javascript">
	var kolId=<?php echo $arrKol['id'];?>;
	var base_url='<?php echo base_url()?>'; 

	var clientId='<?php echo $this->session->userdata('client_id')?>';
    var userId='<?php echo $this->session->userdata('user_id')?>';
    var userRoleId='<?php echo $this->session->userdata('user_role_id')?>';
	var ROLE_MANAGER ='<?php echo ROLE_MANAGER?>';
	var ROLE_ADMIN ='<?php echo ROLE_ADMIN?>';
	var ROLE_USER ='<?php echo ROLE_USER?>';
	var INTERNAL_CLIENT_ID ='<?php echo INTERNAL_CLIENT_ID?>';

	var trialTitle = "<?php echo lang("Overview.TRIALS");?>";
	var trialName = "<?php echo lang("Overview.TrialName");?>";
	var status = "<?php echo lang("Overview.Status");?>";
	var sponsors = "<?php echo lang("Overview.Sponsers");?>";
	var condition = "<?php echo lang("Overview.Condition");?>";
	var intervention = "<?php echo lang("Overview.Intervention");?>";
	var phase = "<?php echo lang("Overview.Phase");?>";
	jqgridIds	= new Array('JQBlistClinicalTrialsResultSet');
	var arrExcludeColumnsInExcelExport = new Array('act'); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','ClientID','User Id','is_analyst','first_name','last_name');	

</script>
		<div id="kolOverviewTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<?php //$this->load->view('elements/kol_short_details_client_view');?>
				<li><a href="#trials">Trials</a></li>
			</ul>-->
			<?php $data['kol_id']=$arrKol['id'];?>
			<?php if($add_trial==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
				<div class="exportOptionsContainer">
					<ul class="pageRightOptions">
						<li><label class="link" onclick="addClinicalTrail();"><a rel="tooltip" title="Add New Clinical Trial" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add New Clinical Trial</a></label></li>
						<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistClinicalTrialsResultSet','clinical_trails');">
                        	<a href="#" rel="tooltip" data-original-title="Export Clinical Trails Details into Excel format">&nbsp;</a>
                        </div></li>
					</ul>
				</div>
			<?php } ?>
				<div id="trials" class="clear">
					<div class="gridWrapper clear" id="clinicalGridContainer">
							<table id="JQBlistClinicalTrialsResultSet"></table>
							<div id="listlistClinicalTrialsPage"></div>
					</div>
				</div>
				<?php 
					$kolModifiedDate = explode(" ",$kolModifiedDateTime);
					$date = date_create($kolModifiedDate['0']);
				?>
				<p style="text-align: right;margin-top: 10px;width: 98%;">Last updated on: <?php echo date_format($date,"d-M-Y");?>. Clinical Trials are obtained from ClinicalTrials.gov. Click on the links to go to CT.</p>
		</div>		
		
		<!-- Container for the 'Add Clinical Trail' modal box -->
		<div id="clinicalTrailDailog">	
			<div id="clinicalTrailAddContainer" class="microProfileDialogBox">
				<div class="profileContent" id="clinicalTrailAddProfileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Add Clinical Trail' modal box -->		
			
		
		<!-- JQGrid Plugins -->
		<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
		<!-- Container for the 'Clinical Trial Micro Profile' modal box -->
			<div id="dailog1">	
				<div id="trialMicroProfile" class="microProfileDialogBox">
					<div class="profileContent"></div>
				</div>
			</div>
		<!--End of  Container for the 'Clinical Trial Micro Profile' modal box -->
								