<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// $route['helpers'] = 'country_helpers';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
?>