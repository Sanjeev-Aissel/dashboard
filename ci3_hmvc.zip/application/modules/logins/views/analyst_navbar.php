<?php 
	$data				= array();
	$current_tab		='';
	$current_tab		=ltrim($_SERVER['PATH_INFO'], '/');
	$data				=explode('/',$current_tab);
	$current_module		=$data[0] ;
	$current_controller	=$data[1] ;
	$current_method		=$data[2] ;
	$CI = & get_instance();
?>
<style>
.sub-nav-tab-active{
    text-decoration-line: underline;
    font-weight: 900;
}
.sub-nav-tab-active a{
    color: #000 !important;
}
.navbar {
  margin-bottom:0px;
}
.navbar-default {
  background-color: #f8f8f8;
  border-color: #e7e7e7;
    border-left: none;
    border-right: none;
}
.navbar-brand {
    padding:0px;
}
.navbar-logo{
width:70%;
}   
#subnav {
 min-height: 36px;
}
#subnav li a {
    padding-top:7px;
    padding-bottom:7px;
}
.navbar-nav {
    height: 27px;
}
</style>
<script>
$(document).ready(function(){
	getClientListing();
});
function getClientListing(){
	 var clients = document.getElementById("client_id");
	 var session_analyst_client_id ="<?php echo $CI->session->userdata('analyst_client'); ?>";
	 $.ajax({
		url: "<?php echo base_url() ?>clients/get_client_ajax",
        dataType: "json",
        type: "POST",
        success: function (responseText) {
           $.each(responseText, function (key, value) {
        	  /*  var newClient = document.createElement('option');
        	   newClient.text = value.name;
        	   newClient.value = value.id;
			   if(value.id == session_analyst_client_id){	
        	   	var prev = clients.options[clients.selectedIndex];
			   }
               clients.add(newClient, prev); */
               if(value.id == session_analyst_client_id){	
        	   	$('#client_id').append($("<option></option>").attr("value",value.id).text(value.name).attr('selected','selected')); 
               }else{
            	$('#client_id').append($("<option></option>").attr("value",value.id).text(value.name));
               }
              }); 
           
        },
        complete: function () {

            }
		});
	
}
function select_analyst_client(){
	var clientId = $('#client_id').val();
	var params = "client_id=" + clientId;
	$.ajax({
	        url: base_url+'clients/clients/select_analysis_client',
	        dataType: "json",
	        data: params,
	        type: "POST",
	        success: function (responseText) {
	        	window.location = base_url+'analysts/kols/list_kols';
	        }
	    });
}
</script>
<nav class="navbar navbar-default" role="navigation" style="background-color: #fff;">
   <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand "> <img src="<?php echo base_url().APPLICATION_IMAGES;?>logo/kolm_logo_beta.png" class="navbar-logo" alt="LOGO"></a>
   </div>
   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
   <?php
   if($this->session->userdata('is_analyst') == 1 && $this->session->userdata('analyst_type') == 0){ ?>
      	<li <?php if(($current_module=='configurations') && ($current_controller=='configurations')){?>class="active"<?php }?>><a href="<?php echo base_url()?>configurations/configurations/client_modules">Configurations</a></li>
      	<li <?php if(($current_module=='clients') && ($current_controller=='clients')){?>class="active"<?php }?>><a href="<?php echo base_url()?>clients/clients/list_clients">Clients</a></li>
      	<li <?php if(($current_module=='helpers') && ($current_controller=='helpers')){?>class="active"<?php }?>><a href="<?php echo base_url()?>helpers/helpers">Helpers</a></li>
      	<?php } ?>
      	<li <?php if($current_controller=='analysts'){?>class="active"<?php }?>><a href="<?php echo base_url()?>analysts/kols/list_kols">Analyst Application</a></li>
      	<li <?php if($current_controller=='imports'){?>class="active"<?php }?>><a href="<?php echo base_url()?>imports/kols_import">Import</a></li>
     </ul>
      <ul class="nav navbar-nav navbar-right">
         <li style="margin: 20% -30%;">
				<span class="glyphicon glyphicon-user"></span>&nbsp;
				<?php echo $this->session->userdata('user_full_name');?>&nbsp;<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="display:inline;padding:0px;">
				<span class="glyphicon glyphicon-cog"></span></a>
					<ul class="dropdown-menu">
			            <li><a href="#">Action</a></li>
			            <li><a href="#">Another action</a></li>
			            <li><a href="#">Something else here</a></li>
			            <li role="separator" class="divider"></li>
			            <li>
			            	<a href="<?php echo base_url().$this->session->userdata('landing_page');?>">Application</a>
			            </li>
			            <li role="separator" class="divider"></li>
			            <li><a href="<?php echo base_url();?>logins/logins/logout">Logout</a></li>
			          </ul>
			</li>	
      </ul>
   </div>
</nav>
<?php if(($current_module=='configurations') && ($current_controller=='configurations')){?>
<nav id="subnav" class="navbar navbar-default" role="navigation">
      <ul class="nav navbar-nav">
         <li <?php if($current_module=='configurations' && $current_controller=='configurations' && $current_method=='client_modules'){?>class="sub-nav-tab-active"<?php }?> ><a href="<?php echo base_url()?>configurations/configurations/client_modules">Modules</a></li>
         <li <?php if($current_module=='configurations' && $current_controller=='configurations' && $current_method=='client_menus'){?>class="sub-nav-tab-active"<?php }?>><a href="<?php echo base_url()?>configurations/configurations/client_menus">Menus</a></li>
         <li <?php if($current_module=='configurations' && $current_controller=='configurations' && ($current_method=='getpermission' || $current_method=='client_roles')){?>class="sub-nav-tab-active"<?php }?>><a href="<?php echo base_url()?>configurations/configurations/client_roles">Roles</a></li>
      </ul>
</nav>
<?php }?>
<?php if(($current_module=='clients') && ($current_controller=='clients')){?>
<nav id="subnav" class="navbar navbar-default" role="navigation">
      <ul class="nav navbar-nav">
         <li <?php if($current_module=='clients' && $current_controller=='clients' && ($current_method=='list_clients' || $current_method=='add_client')){?>class="sub-nav-tab-active"<?php }?> ><a href="<?php echo base_url()?>clients/clients/list_clients">Clients</a></li>
         <li <?php if($current_module=='clients' && $current_controller=='clients' && ($current_method=='list_users' || $current_method=='add_user')){?>class="sub-nav-tab-active"<?php }?>><a href="<?php echo base_url()?>clients/clients/list_users">Client-Users</a></li>
      </ul>
</nav>
<?php }?>
<?php 
if($current_module=='analysts'){?>
<nav id="subnav" class="navbar navbar-default" role="navigation">
      <div class="col-md-10">
      <ul class="nav navbar-nav">
          <li class="dropdown active">
			   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Kols <span class="caret"></span></a>
			  <ul class="dropdown-menu" role="menu">				          
			  	<li><a href="<?php echo base_url()?>analysts/kols/list_kols">List Kols</a></li>
			    <li><a href="<?php echo base_url()?>requested_kols/list_requested_kols">Requested Kols</a></li>
				<li><a href="<?php echo base_url()?>requested_kols/list_pre_requested_kols">My Customers</a></li>
				<li><a href="<?php echo base_url()?>clinical_trials/list_unprocessed_trials">Industry Trials</a></li>
				<li><a href="#">ID Projects</a></li>
				<li><a href="<?php echo base_url()?>kols/list_kols_based_on_client">Kols Visibility</a></li>
			  </ul>
			</li> <!-- .dropdown -->
         <li class="dropdown">
         		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Organizations <span class="caret"></span></a>
         		<ul class="dropdown-menu" role="menu">				          
         			<li><a href="<?php echo base_url()?>analysts/organizations/list_organizations">List Orgs</a></li>
				    <li><a href="<?php echo base_url()?>analysts/organizations/list_requested_orgs">Requested Orgs</a></li>
					<li><a href="<?php echo base_url()?>analysts/organizations/list_orgs_based_on_client">Orgs Visibility</a></li>
					<li><a href="<?php echo base_url()?>analysts/organizations/list_parent_org_associations">Parent Org Association</a></li>
			  	</ul>
         </li>
         <li><a href="<?php echo base_url()?>clients/list_clients">Client Users</a></li>
         <li><a href="<?php echo base_url()?>clients/list_clients">Identify</a></li>
         <li><a href="<?php echo base_url()?>clients/list_clients">Associate</a></li>
         <li><a href="<?php echo base_url()?>clients/list_clients">Media</a></li>
         <li><a href="<?php echo base_url()?>clients/list_clients">Opt-in/Opt-out</a></li>
      </ul>
      </div>
      <div class="col-md-2">
      	<label class="" style="margin-top:8px;">Select Client:</label>
		<select name="client_id" id="client_id" class="form-control required" onchange="select_analyst_client();" style="width:130px;display:inline;margin-top:2px;">
						<option value="">Select</option>
      	</select>
      </div>
</nav>
<?php }?>
<?php if($current_module=='imports' || $current_module=='master_data'){?>
<nav id="subnav" class="navbar navbar-default" role="navigation">
      <div class="col-md-10">
      <ul class="nav navbar-nav">
      <li class="dropdown">
			   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Kols <span class="caret"></span></a>
			  	<ul class="dropdown-menu" role="menu">				          
				    <li><a href="<?php echo base_url()?>imports/kols_import">Kols Import</a></li>
					<li><a href="<?php echo base_url()?>imports/list_imported_kols">List Kols</a></li>
			  </ul>
			</li> <!-- .dropdown -->
      <li class="dropdown">
			   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Organizations <span class="caret"></span></a>
			  	<ul class="dropdown-menu" role="menu">				          
				    <li><a href="<?php echo base_url()?>imports/organizations_import">Organizations Import</a></li>
					<li><a href="">List Organizations</a></li>
			  </ul>
			</li> <!-- .dropdown -->
	  <li><a href="<?php echo base_url()?>master_data/view_types">Master Data</a></li>   		
      </ul>
      </div>
       <div class="col-md-2">
      	<p style="display: inline" class="">Select Client:</p>
		<select name="client_id" id="client_id" class="form-control required" onchange="select_analyst_client();" style="width:140px;display:inline">
						<option value="">Select</option>
      	</select>
      </div>
</nav>
<?php }?>