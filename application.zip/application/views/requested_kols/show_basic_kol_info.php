<?php

/**
 * this is html file to show Contents for 'Privacy and Terms & service'
 * @package application.views.client_users
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 * 
 */

?>
<table width="80%" border="0" align="center">
  <tr>
  <td><img src="<?php echo base_url();?>images/kolm_logo_beta.png" alt="Aissel solutions" /></td>
    <td style="color:#38537C;width: 100%; text-align: center;" valign="bottom">
		<h2 style="margin:0;">KOLM</h2>
	</td>
  </tr>
  <tr><td colspan="2"><hr style="background:#2283AE;" /></td></tr>


  <tr><td></td></tr>
  <tr>
    <td colspan="2" align="center">
		<div style="background: none repeat scroll 0 0 #EFEFEF;padding:5px 0px 25px 0px;">
			<h4 style="padding: 0pt 54px; text-align: left;">
				
			</h4>
			<textarea readonly cols="100" rows="20" style="width:85%;">Profile Type=Basic
Professional Info, Contact Info, Biography

Profile Type=Basic plus
BasicType andpublications, Clinical Trials

Profile Type=Full
Basic plus Type and Education, Affiliations, Events,Social Media
			
			
			</textarea>

		</div>
	</td>
  </tr>




<?php if($pageType=='terms'){?>
  <tr><td colspan="2"><h3 style="margin:0; padding-left:0px;color:#A6A3A6;">Terms of Service</h3></td></tr>
  <tr>
    <td colspan="2" align="center">
		<div style="background: none repeat scroll 0 0 #EFEFEF;padding:5px 0px 25px 0px;">
			<h4 style="padding: 0pt 54px; text-align: left;">Successfull registration of your account with KOLM is considered as you are agreed and accepted the terms and conditions of KOLM.</h4>
			<textarea readonly cols="100" rows="20" style="width:85%;">
Kolmtrial.com is completely owned and is a copyright of Aissel Solutions (�we,� �us,� �our,� and �Aissel�).

kolmtrial.com is a completely free of charge trial service of Aissel�s KOLM software. You are not charged anything for using any features, webpages, mobile access or any service through kolmtrial.com. Nothing in this Agreement creates an obligation for you to enter into any other agreement with Aissel Solutions. Nothing in this Agreement shall be construed to constitute an agency, partnership, joint venture, or other similar relationship between you and us.

You agree that by registering on kolmtrial.com or by using kolmtrial.com, you enter into a legally binding agreement with Aissel Solutions. By clicking on �register,� you acknowledge that you have read and understood the terms and conditions of this Agreement and that you agree to be bound by all of its provisions.

You promise to use the Service only for purposes, and in a manner, permitted by (a) these Terms and (b) any applicable law, regulation or generally accepted practices or guidelines in the relevant jurisdictions. In addition, you hereby assure us that you will not export directly or indirectly technical data to any country for which a validated license is required under United States law without first obtaining a validated license.

We DO NOT provide any warranties or endorsements on any person, product, brand, and/or company that are reported in our profiling, mapping or any other services. We collect content that is publicly available, parse it and report it. You may not hold us responsible on the usage of any content reported by us in any manner.

We collect information on scientific publications from National Library of Medicine and do not own any of this content. Some material in the NLM databases is from copyrighted publications of the respective copyright claimants. You are solely responsible for fair usage of such content and compliance to any such copyright restrictions. Further, we do not claim any ownership rights in the text, files, images, photos, video, sounds, musical works, works of authorship, or any other materials (collectively, "Content") that are reported through our software.

You may not: use the Service in a manner that would cause you or us to violate any applicable local, state, national or international law, including any rules and regulations of any securities exchange, any rules, regulations, requirements, procedures or policies in force from time to time relating to the Service, and any export or re-export laws, rules and regulations; interfere with or disrupt the Service or take any steps to interfere with or in any manner compromise any security measures with respect to the Service or any data transmitted, processed or stored on or through the Service, or interferes with or disrupts the Service (or the servers and networks which are connected to the Service).

You promise not to access (or attempt to access) the Service by any means other than through the interface(s) that are provided by us. Without limiting the generality of the foregoing, you specifically promise not to access (or attempt to access) any of the Service through any automated means (including use of scripts or crawlers) other than customary indexing of content by search engines.  Similarly, you promise that you will not provide any third party access to material on the Service (or facilitate their attempt to access) by any means other than through the interface that is provided by us. 

Indemnification
You indemnify us and hold us harmless for all damages, losses and costs (including, but not limited to, reasonable attorneys� fees and costs) related to all third party claims, charges, and investigations, caused by (1) your failure to comply with this Agreement, including, without limitation, your submission of content that violates third party rights or applicable laws, (2) any content you submit to the Services, and (3) any activity in which you engage on or through Aissel.

Proprietary Rights. �
We (or our licensors) own all legal right, title and interest in and to the Service, including any intellectual property rights which subsist in the Service (whether those rights happen to be registered or not, and wherever in the world those rights may exist). �The Service may contain information which is designated confidential by us and you shall not disclose such information without our prior written consent.
You may not (and you may not permit anyone else, on your behalf of otherwise, to) copy, modify, create a derivative work of, reverse engineer, decompile or otherwise attempt to extract the source code of the software used to provide the Service or any part thereof, unless this is expressly permitted or required by law, or unless you have been specifically told that you may do so by us, in writing.
In general, the Service is provided in a manner which does not result in your downloading or using any of our software (�Software�). �In the event that we do, however, provide you with Software (such as a plug-in or similar item), we grant you a personal, non-transferable and non-exclusive right and license to use the object code of its Software on the single computer to which it is provided in connection with your access to the Service; provided that you do not (and do not allow any third party to) copy, modify, create a derivative work of, reverse engineer, reverse assemble or otherwise attempt to discover any source code, sell, assign, sublicense, grant a security interest in or otherwise transfer any right in the Software. You may not modify the Software in any manner or form, or to use modified versions of the Software, including (without limitation) for the purpose of obtaining unauthorized access to the Service. You may not rent, lease, loan, sell, distribute or create derivative works based on the Software, in whole or in part.

			</textarea>
		</div>
	</td>
  </tr>
<?php }?>
 <tr><td colspan="2"><hr style="background:#2283AE;" /></td></tr>
  <tr>
    <td align="right" colspan="2"><div><input type="button" value="Close" onclick="javascript:window.close();" /> </div></td>
  </tr>
</table>