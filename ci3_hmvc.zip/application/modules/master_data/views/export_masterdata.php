<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
.chosenMultipleSelect{
	width: 35%;
}
.show {
	display: block;
}

.hide {
	display: none;
}

.microView .ui-dialog-content {
	background-color: white;
}

.users {
	list-style-type: none;
	margin: 0;
	padding: 0
}

.users li {
	float: left;
}

.editIcon {
	margin-left: 3px;
}
#exportTable td{
	padding-bottom: 5px !important;
}
#exportTable td,input[type="checkbox"]{
	vertical-align: top !important;
	margin: 0;
}
#exportTable label {
		background-color:#FFFFFF;
		padding-left:3px;
		width:90px;
		font-weight: normal;
}
	#selectionBox img{
	 margin-left: 32%;
	}

</style>
<script type="text/javascript">
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
});
function validateExportForm(thisEle){
	if($(thisEle).val() =="Export"){
			var clientIds = $('#cltId').val();
			var clientId = new Array();
			if(clientIds == null){
				jAlert("Associate atleast one client");
				return;
			}
			var values = new Array();
			$.each($("input[name='export_opts[]']:checked"), function() {
			  values.push($(this).val());
			});
			if(values == ""){
				jAlert("Please select atleast one checkbox to export");
				return false;	
			}
			var action ="<?php echo base_url()?>master_data_controller/export_multiple_master_data";
			$('#masterExportForm').attr('action',action);
			$('#masterExportForm').submit();			
		}		
}
checked=false;
function selectAll(){
	var aa= document.getElementById('masterExportForm');
	 if(checked == false){
           checked = true;
	 }else{
          checked = false;
	 }
	 
	for (var i =0; i < aa.elements.length; i++){
		aa.elements[i].checked = checked;
	}
}
</script>
<div class="importMasterData">
	<form
		action="<?php echo base_url();?>master_data_controller/export_multiple_master_data"
		name="masterExportForm" id="masterExportForm" method="post"
		enctype="multipart/form-data">
		<div id="selectionBox">
			<p>
				<img  width="15" alt="Excel" src="<?php echo base_url().'images/icon_excel.png'?>" />&nbsp;&nbsp;<label>Please select what you want to export?</label>
			</p><br />
		<table id="exportTable" border="0">
			<tr>
				<td colspan="3"><label style="display: inline-block;vertical-align: top;">Associate Clients:</label>
				<select name="clientIds[]" multiple="multiple" id="cltId"
					class="chosenMultipleSelect" data-placeholder="Select Clients">
						<option disabled="disabled" value="">Select Clients</option>					
			            <?php foreach($arrClients as $clients){ ?>
			            <option value="<?php echo $clients['id'];?>"
							<?php if(in_array($clients['id'],$arrSelected)){ echo "selected = selected";} ?>><?php echo $clients['name']; ?></option>
			            <?php } ?>
            		</select>
            	</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="all_categories" value="all" onclick='selectAll();'/><label>All Categories</label>
				</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="titles" class="exportOpts"/><label>Titles</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="interactions_topics" class="exportOpts"/><label>Topics</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="products" class="exportOpts"/><label>Products</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="emails" class="exportOpts"/><label>Email Type</label>			
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="phone_type" class="exportOpts"/><label>Phone Type</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="specialties" class="exportOpts"/><label>Specialities</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="event_roles" class="exportOpts"/><label>Event Roles</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="event_topics" class="exportOpts"/><label>Event Topics</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="event_organizer_types" class="exportOpts"/><label>Event Org types</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="interaction_types" class="exportOpts"/><label>Discussion Type</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="interactions_modes" class="exportOpts"/><label>Interaction Type</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="interaction_location_types" class="exportOpts"/><label>Interaction Location</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="engagement_types" class="exportOpts"/><label>Engagement Types</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="organization_types" class="exportOpts"/><label>Organization Types</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="payments_requested_by" class="exportOpts"/><label>Requested By</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="payments_paid_by" class="exportOpts"/><label>Paid By</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="payment_types" class="exportOpts"/><label>Payment Type</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="payments_currency" class="exportOpts"/><label>Payment Currency</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="cities" class="exportOpts"/><label>Cities</label>
				</td>				
				<td>
					<input type="checkbox" name="export_opts[]" value="event_type" class="exportOpts"/><label>Event Type</label>
				</td>
				<td>
					<input type="checkbox" name="export_opts[]" value="sponsor_type" class="exportOpts"/><label>Sponsor Type</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="export_opts[]" value="session_type" class="exportOpts"/><label>Session Type</label>
				</td>
			</tr>	
			<tr>
				<td colspan="3" style="text-align:center;"><input type="button" value="Export" id="masterExportButton"
			onclick="validateExportForm(this)" /></td>
			</tr>
			</table>
		</div>
	</form>
</div>	