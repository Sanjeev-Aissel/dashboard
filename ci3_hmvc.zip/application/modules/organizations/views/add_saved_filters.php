<script type="text/javascript">
	$(document).ready(function(){
		});
	function addName(thisEle) {
		var id = thisEle.options[thisEle.selectedIndex].value;
		var name = thisEle.options[thisEle.selectedIndex].text;
		if(id != "addNew" && id != ''){
			$("#existNameId").val(id);
			$("#filterNewName").val(name);
			$("#btn").attr('value','Update');
			$("#btn").attr('onclick','updateFilters()');
		}else{
			$("#existNameId").val("");
			$("#filterNewName").val("");
			$("#btn").attr('value','Save');
			$("#btn").attr('onclick','saveFilters()');
			}
	}

	$("#filterNewName").keypress(function(){
		var thisVal = $(this).val();
		$("#btn").attr('onclick','saveFilters()');
		$("#btn").attr('value','Save');
		});
</script>
<div class="formHeader">
	<h5>Save Query</h5>
</div>
<div>
	<form id="deleteSavedFilterForm" method="post">
	<table>
		<tbody>
			<tr>
				<td><label for="filterName">Enter new name :</label></td>
				<td><input type="hidden" name="existNameId" id="existNameId" value=""/><input type="text" name="filterNewName" id="filterNewName" maxlength="64"/></td></tr>
			<tr>
				<td colspan="2">
				<div class="formButtons">
					<input type="button" value="Save" name="submit" id="btn" onclick="saveFilters();">
				</div>
				</td>
			</tr>
		</tbody>
	</table>
	</form>
</div>
