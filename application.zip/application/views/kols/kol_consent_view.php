<style>
p{
	white-space: normal;
	font-family: "Times New Roman", serif, sanserif, helvetica;
}
.header1{
	width: 93% !important;
	margin-left: 0px !important;
	background: #fff !important;
	border-bottom: 1px solid #f1f1f1;
}
.custom_btn{
	background-color: #2b9af3;
    border: 1px solid #2b9af3;
    box-shadow: 1px 1px 4px #000;
    color: #fff;
    padding-top: 5px;
    padding-bottom: 5px;
    width: 100px;
    text-align: center;
    margin-right: 5px;
    cursor: pointer;
}
.custom_btn:hover{
	opacity: 0.8;
}
.kolNameForConsent{
	vertical-align: middle;
	font-size:18px !important;
}
#consent_form_holder{
	border: 1px solid #eceaea;
    width: 400px;
    padding: 15px;
    margin: 0 auto;
    margin-top: 40px;
}
</style>

<title><?php echo PRODUCT_VERSION;?></title>
<?php echo $this->load->view('elements/favicon');?>
<?php 
pr($html); 
if($html != 'Invalid Request'){
	if($consent_status < 1){
?>
<hr/>
<div id="consent_form_holder">
<form action="<?php echo base_url();?>kols/update_kol_consent" id="consent_form" method="post" enctype="multipart/form-data">
	<input type="hidden" name="kol_id" value="<?php echo $kol_id;?>"/>
	<input type="hidden" name="unique_id" value="<?php echo $unique_id;?>"/>
	<input type="hidden" name="flag" id="flag" value=""/>
	<p>Notes</p>
	<textarea name="consent_notes" id="consent_notes" style="width: 100%;height: 170px;"></textarea>
	
	<p style="padding-bottom: 12px;padding-top: 12px;">
		<input type="file" name="consent_attachment" id="consent_attachment"/>
	</p>
	
	<p style="padding-bottom: 12px;">
		<input type="checkbox" name="consent_agree" id="consent_agree"> I agree
	</p>
	
	<input type="button" value="Approve" id="consent_approve" class="custom_btn"/>
	<input type="button" value="Deny" id="consent_deny" class="custom_btn"/>
	
</form>
</div>
<?php } }?>

<script type="text/javascript" src="<?php echo base_url();?>js/jquery-v1.11.3.min.js"></script>
<script>
$(document).ready(function(){
	$("#consent_approve").click(function(){
		if($("#consent_agree").prop('checked') == false){
			alert('Please agree');
		}else{
			$("#consent_form").submit();
		}
	});	

	$("#consent_deny").click(function(){
		$("#flag").val('');
		var confirmVal = confirm("Sure!");
		if (confirmVal == true) {
			$("#flag").val('deny');   
			$("#consent_form").submit();
		}
	});	
});
</script>