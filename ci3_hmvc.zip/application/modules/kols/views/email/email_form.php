<style>
#emailTable label {
	display: inline;
	float: right;
}
#emailTable td {
	padding:5px;
	border:0px ;
}
.formatContent {
	margin-left: 10px;
}
#emailTable #to {
	height: 23px;
}
.emailErrorMessage,.errorMessage,.fromErrorMessage {
	color: red;
}
.mandetary {
	color: red;
}
#emailTable #note {
	height: 98px;
}
.microView .ui-dialog-content {
	background-color: white !important;
}
</style>
<script>
	function validateEmail(field) {
		var regex=/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i;
		return (regex.test(field)) ? true : false;
	}
	function validateMultipleEmailsCommaSeparated(value) {
			var result = value.split(",");
			for(var i = 0;i < result.length;i++)
			if(!validateEmail(result[i]))
			return false;
			return true;
	}
	$('#sendEmail').click(function(){
		var email=$('#to').val();
		var from = $('#from').val();
		var to   =  $('#to').val();
		if(from==''){
			$('.fromErrorMessage').html("Required field can not be left blank");
			return false;
		}else{
			$('.fromErrorMessage').html("");
		}
		if(to==''){
			$('.errorMessage').html("Required field can not be left blank");
			return false;
		}else{
			$('.errorMessage').html("");
		}
		if(validateMultipleEmailsCommaSeparated(email)){
			$('.errorMessage').html("");
			$('div.uniMsgBox').removeClass('success');
			$('div.uniMsgBox').addClass('notice');
			$('div.uniMsgBox').show();
			$('div.uniMsgBox').html('Sending... <img src="'+base_url+'assets/images/ajax_loader_black.gif" />');
			$.ajax({
				url:"<?php echo base_url();?>kols/kols/send_email",
				data:$('#emailForm').serialize(),
				dataType:'json',
				type:'post',
				success:function(returnData){
					
						$('div.uniMsgBox').html(returnData.status);
						$('div.uniMsgBox').fadeOut(1500);
						setTimeout(closeEmailDialog,2000);
					
				},
				complete:function(returnData){
					}
			});
		}else{
			$('.errorMessage').html("Enter Valid Email Address");
			return false;
		}
	});
	function closeEmailDialog(){
		$('#addEmail').dialog("close");
	}
</script>
<div class="uniMsgBox"></div>
<form action="<?php echo base_url();?>kols/kols/send_email" method="post" name="emailForm" id="emailForm">
	<input type="hidden" name="kolId" value="<?php echo $kolId?>"/>
			<div class="formatContent">
				<label>Attach profile as:</label>
				<input type="radio" name="format" checked="checked" value="html"/><label>HTML</label>
				<input type="radio" name="format" value="Pdf"/><label>PDF</label>
				<input type="radio" name="format"  value="Excel"/><label>EXCEL</label>
			</div>
	<table id="emailTable" class="table">
		<tr>
			<td width="25%">
				<label>From Name:<span class="mandetary">*</span></label>
			</td>
			<td>
				<input type="text" id="from" name="from" value="Soumya(Testing)" class="form-control"/>
				<div class="fromErrorMessage"></div>
			</td>
		</tr>
		<tr>
			<td>
				<label>Email:</label>
			</td>
			<td>
				<input type="text" name="email" id="email" value="soumyas@aissel.com" class="form-control"/>
				<div class="emailErrorMessage"></div>
			</td>
		</tr>
		<tr>
			<td>
				<label>To:<span class="mandetary">*</span></label>
			</td>
			<td>
				<textarea id="to" name="to" class="form-control">soumyas@aissel.com</textarea>
				<div class="errorMessage"></div>
			</td>
		</tr>
		<tr>
			<td>
				<label>Note:</label>
			</td>
			<td>
				<textarea id="note" name="note" class="form-control">Hello,
	Please find the profile of Dr. <?php echo $kolName;?>  attached here with.

Warm Regards,
<?php echo PRODUCT_VERSION; ?> Support

				</textarea>
			</td>
		</tr>
		<tr>
			<td></td>
			<td class="alignCenter">
			<input class="btn btn-default" type="button" id="sendEmail" value="Send"/>
			</td>
		</tr>
	</table>
</form>