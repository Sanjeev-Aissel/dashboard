<?php
/**
 * Model file for the 'Events Drop down'
 * 
 * @package application.models
 * @author Ambarish
 * @since
 * @created on  9-12-10
 */

class Event_helper extends CI_Model{

	/**
	 * Returns all the Conference Event Types
	 * @return array	- ID, and Event Type
	 */
	function getAllConferenceEventTypes(){
		$arrEventTypes	= array();
		$this->db->order_by('event_type','asc');
		$arrEventTypesResult = $this->db->get('conf_event_types');
		$otherId	= 0;
		foreach($arrEventTypesResult->result_array() as $arrEventType){
			//$arrEventTypes[$arrEventType['id']]	= $arrEventType['event_type'];
			
			//check if the event type is 'Other' and add it last in the list
			if($arrEventType['event_type'] == 'Other'){
				//$arrEventTypes1[$arrEventType['id']]	= $arrEventType['event_type'];
				$otherId	= $arrEventType['id'];
			}else{
				$arrEventTypes2[$arrEventType['id']]	= $arrEventType['event_type'];
			}
		}
		//$arrEventTypes = array_merge($arrEventTypes1,$arrEventTypes2);
		$arrEventTypes	= $arrEventTypes2;
		if($otherId>0){
			$arrEventTypes[$otherId]	= 'Other';
		}
		
		
		return $arrEventTypes;
	}
	
	/**
	 * Returns the name of the specified Conference Event Type ID
	 * @return array -eventType
	 */
	function getConferenceEventTypeById($eventTypeId){
		$eventType='';
		if($eventTypeId != ''){
			$this->db->where('id', $eventTypeId);
			$this->db->select('event_type');	
		
			$eventType	= $this->db->get('conf_event_types');
			foreach($eventType->result_array() as $row){
				$eventType = $row['event_type'];
			}		
			return $eventType;
		}else
			return $eventType;
	}	
	

	/**
	 * Returns all the Conference Session Types
	 * @return array	- ID, and Event Type
	 */
	function getAllConferenceSessionTypes(){
		$arrSessionTypes	= array();
		$this->db->order_by('session_type','asc');	
		$arrSessionTypesResult = $this->db->get('conf_session_types');
		foreach($arrSessionTypesResult->result_array() as $arrSessionType){
			$arrSessionTypes[$arrSessionType['id']]	= $arrSessionType['session_type'];
		}
		return $arrSessionTypes;
	}
	
	/**
	 * Returns the name of the specified Conference Session Type ID
	 */
	function getConferenceSessionTypeById($sessionTypeId){
		$sessionType='';
		if($sessionTypeId !=''){
			$this->db->where('id', $sessionTypeId);
			$this->db->select('session_type');
			
			$sessionType	= $this->db->get('conf_session_types');
			foreach($sessionType->result_array() as $row){
				$sessionType = $row['session_type'];
			}
			return $sessionType;
		}
		else
		 return $sessionType;
	}		
	

	/**
	 * Returns all the Online Event Types
	 * @return array	- ID, and Event Type
	 */
	function getAllOnlineEventTypes(){
		$arrEventTypes	= array();
		
		$arrEventTypesResult = $this->db->get('online_event_types');
		foreach($arrEventTypesResult->result_array() as $arrEventType){
			$arrEventTypes[$arrEventType['id']]	= $arrEventType['event_type'];
		}
		return $arrEventTypes;
	}
	
	/**
	 * Returns the name of the specified Online Event Type ID
	 *  @return array	- OnlineEventType 'Name'
	 */
	function getOnlineEventTypeById($eventTypeId){
		$arrEventType='';
		if($eventTypeId != ''){
			$this->db->where('id', $eventTypeId);
			$this->db->select('event_type');
			$eventTypeResult	= $this->db->get('online_event_types');
			foreach($eventTypeResult->result_array() as $row){
				$arrEventType = $row['event_type'];
			}
			return $arrEventType;
		}else
			return $arrEventType;
	}
		
	/**
	 * Return Event_type 'id' by spacifing 'event_type'
	 * @return array	- ID
	 */	
	function getEventTypeId($eventName=''){
		$arrEventID = array();
		$this->db->where('event_type',$eventName);
		$this->db->select('id');
		$arrEventIdResult = $this->db->get('online_event_types');
		foreach($arrEventIdResult->result_array() as $row){
			$arrEventID = $row['id'];
		}
		return $arrEventID;
	}
	
	/**
	 * Return Event_type 'id' by spacifing 'event_type'
	 * @return array	- ID
	 */		
	function getConfEventTypeId($eventName=''){
		$arrEventID = 0;
		$this->db->where('event_type',$eventName);
		$this->db->select('id');
		$arrEventIdResult = $this->db->get('conf_event_types');
		foreach($arrEventIdResult->result_array() as $row){
			return $row['id'];
		}
		return $arrEventID;
	}

	/**
	 * Return Session_type 'id' by spacifing 'Session_type'
	 * @return array	- ID
	 */		
	function getConfSessionTypeId($sessionName=''){
		$arrSessionID = array();
		$this->db->where('session_type',$sessionName);
		$this->db->select('id');
		$arrSessionIdResult = $this->db->get('conf_session_types');
		foreach($arrSessionIdResult->result_array() as $row){
			$arrSessionID = $row['id'];
		}
		return $arrSessionID;
	}
	
	function getSponsorTypes(){
		$arrSponsorTypes	= array();
		
		$arrSponsorTypesResult = $this->db->get('event_sponsor_types');
		foreach($arrSponsorTypesResult->result_array() as $arrSponsorType){
			$arrSponsorTypes[$arrSponsorType['id']]	= $arrSponsorType['type'];
		}
		return $arrSponsorTypes;
	}

	function getOrganizerTypes(){
		$arrOrganizerTypes	= array();
		
		$arrOrganizerTypesResult = $this->db->get('event_organizer_types');
		foreach($arrOrganizerTypesResult->result_array() as $arrOrganizerType){
			$arrOrganizerTypes[$arrOrganizerType['id']]	= $arrOrganizerType['type'];
		}
		return $arrOrganizerTypes;
	}
	
	function getOrganizerIdByType($type){
		$this->db->select('id');
		$this->db->where('type',$type);
		$arrResult = $this->db->get('event_organizer_types');
		$row = $arrResult->result_array();
		//echo  $row[0]['id'];
		return $row[0]['id'];
	}
}