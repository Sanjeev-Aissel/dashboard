<?php
/**
 * Element page to add the mirf  form details
 * 
 * @package application.views.interaction
 * @author Shruti Purushan
 * @created: 29-09-15
 */
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket',
    'chosen.jquery', 'signature_pad'
);
//pr($_SERVER['HTTP_REFERER']););
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
$interactionKolAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
if ($currentMethod == "add_mirf") {
    $interactionId = $this->uri->segment(3);
}

$userName = $this->session->userdata('user_full_name');
$userId = $this->session->userdata('user_id');
//$userTerritory = $this->session->userdata('user_territory');
$firstName = $kolDetails[0]['first_name'];
$middleName = " " . $kolDetails[0]['middle_name'];
$lastName = " " . $kolDetails[0]['last_name'];
$kolName = $firstName . $middleName . $lastName;
$clientUser = $clientUser['first_name'] . ' ' . $clientUser['last_name'];
$previousUrl = $_SERVER['HTTP_REFERER'];

$mirfWithin=0;
$link = $_SERVER['HTTP_REFERER'];
    $link_array = explode('/',$link);
     $page = end($link_array);
     if($page=="interaction_report")
         $mirfWithin=1;
?>
<!--<script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>-->
<script src="<?php echo base_url(); ?>js/jquery/jquery.validate1.9.min.js"></script>
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    #medContainer{
        padding-left: 15px;
        padding-right: 15px;
        padding-bottom: 15px;
    }
    table caption{
        background :#ececec ; 
        box-shadow: 0 0 4px #d1d1d1  inset;
        border: 1px solid #ececec ;
    }
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    /*table {
    border: 1px solid #DDDDDD;
}*/
    .validation
    {
        color: red;
        margin-left: 74px;
        margin-top: -10px;

    }
    .chzn-container-single .chzn-default {
        color: #555 !important;
    }
    label {
        /*float: left;*/
    }
    .item {
        float: left;
        width:200px;
    }
    .inputTypeWidth{
        width:220px;
    }
    .selectTypeWidth{
        width:228px;
    }
    th{
        width:220px;
    }
    input[type="text"], input[type="password"], select {
        height: 22px;
        border: 1px solid #999 !important;
        color: #999;
        -webkit-border-radius: 2px;
        -moz-border-radius: 2px;
        border-radius: 2px;
        margin: 2px;
        padding: 0px 3px;
        margin-top: 0px;
    }
    span.error {
        /* background-image: url(../images/error_medium.gif); */
        background-position: 10px center;
        background-repeat: no-repeat;
        padding: initial !important;
        border:0em !important;
    }
    .error, .notice, .success {
        padding: .8em;
        background:transparent !important;
        margin-bottom: 0em !important;
        color: red;
    }

    .m-signature-pad {
        position: absolute;
        font-size: 10px;
        width: 600px;
        height: 200px;
        top: 50%;
        left: 50%;
        margin-left: -350px;
        margin-top: -200px;
        border: 1px solid #e8e8e8;
        background-color: #fff;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.27), 0 0 40px rgba(0, 0, 0, 0.08) inset;
        border-radius: 4px;
    }

    .m-signature-pad:before, .m-signature-pad:after {
        position: absolute;
        z-index: -1;
        content: "";
        width: 40%;
        height: 10px;
        left: 20px;
        bottom: 10px;
        background: transparent;
        -webkit-transform: skew(-3deg) rotate(-3deg);
        -moz-transform: skew(-3deg) rotate(-3deg);
        -ms-transform: skew(-3deg) rotate(-3deg);
        -o-transform: skew(-3deg) rotate(-3deg);
        transform: skew(-3deg) rotate(-3deg);
        box-shadow: 0 8px 12px rgba(0, 0, 0, 0.4);
    }

    .m-signature-pad:after {
        left: auto;
        right: 20px;
        -webkit-transform: skew(3deg) rotate(3deg);
        -moz-transform: skew(3deg) rotate(3deg);
        -ms-transform: skew(3deg) rotate(3deg);
        -o-transform: skew(3deg) rotate(3deg);
        transform: skew(3deg) rotate(3deg);
    }

    .m-signature-pad--body {
        position: absolute;
        left: 20px;
        right: 20px;
        top: 20px;
        bottom: 60px;
        border: 1px solid #f4f4f4;
    }

    .m-signature-pad--body
    canvas {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        border-radius: 4px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.02) inset;
    }

    .m-signature-pad--footer {
        position: absolute;
        left: 20px;
        right: 20px;
        bottom: 20px;
        height: 40px;
    }

    .m-signature-pad--footer
    .description {
        color: #C3C3C3;
        text-align: center;
        font-size: 1.2em;
        margin-top: 1.8em;
    }

    .m-signature-pad--footer
    .button {
        position: absolute;
        bottom: 0;
    }

    .m-signature-pad--footer
    .button.clear {
        left: 0;
    }

    .m-signature-pad--footer
    .button.save {
        right: 0;
    }

    @media screen and (max-width: 1024px) {
        .m-signature-pad {
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: auto;
            height: auto;
            min-width: 250px;
            min-height: 140px;
            margin: 5%;
        }
        #github {
            display: none;
        }
    }

    @media screen and (min-device-width: 768px) and (max-device-width: 1024px) {
        .m-signature-pad {
            margin: 10%;
        }
    }

    @media screen and (max-height: 320px) {
        .m-signature-pad--body {
            left: 0;
            right: 0;
            top: 0;
            bottom: 32px;
        }
        .m-signature-pad--footer {
            left: 20px;
            right: 20px;
            bottom: 4px;
            height: 28px;
        }
        .m-signature-pad--footer
        .description {
            font-size: 1em;
            margin-top: 1em;
        }
    }
    .textLabel{
        background-color:#C3C3C3 !important;
    }
    #headerContentCss{
        background :#fff !important ; 
        box-shadow: 0 0 4px #d1d1d1  inset;
        border: 1px solid #ececec ;
    }
    #mirfForm{
        border: 1px solid #ddd !important;
        padding-bottom: 15px;
    }
    input[type="text"], input[type="password"], select {
        border: 1px solid #d3d3d3 ;
    }
    #searchKeyword,#searchKeyword2{
        margin-left: 22px;
        margin-top: -46px;
        border: 0px !important;
    }
    .dateDiv{
        border-style: solid;
        border-bottom:1px solid #d3d3d3 ;
    }
    .disabledDiv{
        background: #ececec;
        box-shadow: 0 0 4px #d1d1d1 inset;
        border: 1px solid #ececec;
        margin-bottom: 0px;
        color:#a8a8a8 !important;
    }
    .spanSign{
        color:#a8a8a8;
    }
    .input-disabled{background-color:#EBEBE4 !important;
    }
    .error, .notice, .success{
        padding: 2px !important;
    }
    .errormsg{
        display:block !important;
    }
    #msl_info,#mir_questions{
        border: 1px solid #999 !important;
    }
    <?php if($mirfWithin == 1){?>
    	#contentWrapper.span-23 {
		background-image:none;
	}
    <?php }?>
</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
    var result;
    $(document).ready(function () {

        $('#date_of_request').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        var contractKolAutoComplete = $('#kol_id').autocomplete(kolAutoCompleteOptions);


        $("#kol_id").on('click', function () {
            $('#contact_id').val("");
            //alert( $('#contact_id').val());
//            
            $('#kol_id').autocomplete(kolAutoCompleteOptions);
        });


        //Signature Pad dialogBox config
        var signaturePadDialogConf = {
            title: "Add KOL",
            modal: true,
            autoOpen: false,
            width: 710,
            height: 550,
            draggable: false,
            position: ['center', 80],
            dialogClass: "microView",
            open: function () {
                //display correct dialog content
            }
        };

        $("#signaturePadDialoge").dialog(signaturePadDialogConf);

    });



    var kolAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete',
<?php echo $interactionKolAutoCompleteOptions; ?>,
                onSelect: function (event, ui) {

                    var selText = $(event).children('.kolName').html();
                    var id = $(event).children('.id1').html();
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#kol_id').val(selText);
                    $('#contact_id').val(id);
                    getKolDetails(id);
                }

    };

    function getKolDetails(id) {
        $.ajax({
            url: '<?php echo base_url() ?>kols/getKolDetails/' + id,
            type: 'POST',
            dataType: 'JSON',
            success: function (returnData) {
                for (var result in returnData) {
                    $("#specialty").val(returnData[result].specialty_name);
                    $("#degree").val(returnData[result].degree);
                    $("#licence").val(returnData[result].license);
                    $("#address").val(returnData[result].address1);
                    $("#institution").val(returnData[result].name);
                    $("#state").val(returnData[result].state);
//$("#city").val(returnData[result].city);

                    $("#zip_code").val(returnData[result].postal_code);
                    $("#telephone").val(returnData[result].primary_phone);
                    if(returnData[result].state != 0)
                    	getCitiesByStateId($("#state"),returnData[result].city);
                }
            }
        });



    }
    function saveMirf() {
        $('#contact_id').parent().children("label.error").remove();
        if ($('#contact_id').val() == "") {
            $('#contact_id').parent().append('<label  for="contact_id" id="errorLabel" generated="true" class="error">Select from Auto Suggestions</label>');
            $('#errorLabel').addClass('errormsg');
        }
        // Setup form validation on the #register-form element
        $("#mirfForm").validate({
//            $.each($('.selectedKolId '),function(){

//		});
            // Specify the validation rules
            rules: {
                date_of_request: "required",
                kol_id: "required",
                degree: "required",
                specialty: "required",
                //licence: "required",
                city: "required",
                state: "required",
                zip_code: "required",
                telephone: "required",
                institution: "required",
                address: "required",
                agree: "required",
                contact_id: "required",
                msl_info: "required",
                mir_questions:"required",
                'product[]':"required",
            },
            // Specify the validation error messages
            messages: {
                date_of_request: "Required",
                kol_id: "Required",
                degree: "Required",
                specialty: "Required",
                //licence: "Required",
                city: "Required",
                state: "Required",
                zip_code: "Required",
                telephone: "Required",
                institution: "Required",
                address: "Required",
                contact_id: "Required",
                msl_info: "Required",
                 mir_questions:"Required",
                'product[]': "Required"
            },
            submitHandler: function (form) {
                if ($('#contact_id').val() != "") {
                    form.submit();
                }
            }
        });
    }
//    });
    /**
     * Returns the list of Cities of the Selected State
     */
    function getCitiesByStateId(state,city) {
        // Show the Loading Image

        $("#loadingCities").show();
        var stateId = $(state).find('option:selected').attr('id');
        $("#city").html("<option value=''>-- Select City</option>");
        var cities = document.getElementById('city');
        var params = "state_id=" + stateId;
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                $.each(responseText, function (key, value) {

                    var newCity = document.createElement('option');
                    newCity.text = value.city_name;
                    newCity.value = value.city_name;
                    var prev = cities.options[cities.selectedIndex];
                    cities.add(newCity, prev);
                });
                $("#city option[value='']").remove();
                $("#city").prepend("<option value=''>-- Select City --</option>");
				if(city != null && city != 0)
                	$("#city").val(city);
				else
					$("#city").val("");
            },
            complete: function () {
                $("#loadingCities").hide();
            }
        });
    }
    $(function ()
    {
        $('.ch input[type=checkbox]').not('.par').click(function () {
            $('.par').prop('checked', true);
        });
        $('input[type="checkbox"]').click(function () {
            var x = document.getElementById("is_single_use_vial").name;
            var y = document.getElementById("is_dual_chamber_syringe").name;
            var z = document.getElementById("is_non_kit_specific_enquiry").name;
            if (($("#is_single_use_vial").prop("checked") == false) && ($("#is_dual_chamber_syringe").prop("checked") == false) && ($("#is_non_kit_specific_enquiry").prop("checked") == false)) {
                $('.par').prop('checked', false);

            }
        });

    });

    //Signature related js
    var signaturePad;
    function openSignaturePad() {
        $(".signaturePadDialoge").html("");
        $(".signaturePadDialoge").html('<div id="signature-pad" class="m-signature-pad"> <div class="m-signature-pad--body"> <canvas></canvas> </div> <div class="m-signature-pad--footer"> <div class="description">Sign above</div>  <button class="button clear" data-action="clear">Clear</button>  <button class="button save" data-action="save">Save</button> </div></div>');
        $("#signaturePadDialoge").dialog("open");

        var wrapper = document.getElementById("signature-pad"),
                clearButton = wrapper.querySelector("[data-action=clear]"),
                saveButton = wrapper.querySelector("[data-action=save]"),
                canvas = wrapper.querySelector("canvas"),
                signaturePad;

        function resizeCanvas() {
            // When zoomed out to less than 100%, for some very strange reason,
            // some browsers report devicePixelRatio as less than 1
            // and only part of the canvas is cleared then.
            var ratio = Math.max(window.devicePixelRatio || 1, 1);
            canvas.width = canvas.offsetWidth * ratio;
            canvas.height = canvas.offsetHeight * ratio;
            canvas.getContext("2d").scale(ratio, ratio);
        }

        window.onresize = resizeCanvas;
        resizeCanvas();

        signaturePad = new SignaturePad(canvas);

        clearButton.addEventListener("click", function (event) {
            signaturePad.clear();
        });

        saveButton.addEventListener("click", function (event) {
            if (signaturePad.isEmpty()) {
                alert("Please provide signature first.");
            } else {
                //window.open(signaturePad.toDataURL());
                var data = {};
                data['signature_data'] = signaturePad.toDataURL();
                $.ajax({
                    url: base_url + "interactions/parse_signature_image",
                    data: data,
                    type: "POST",
                    dataType: 'json',
                    success: function (returnData) {
                        //alert(returnData.image_name);
                        imageUrl = returnData.image_url;
                        $("#signatureImage").attr('src', imageUrl);
                        $("#mirfForm input[name='hcp_signature']").val(returnData.image_name);
                        $("#signaturePadDialoge").dialog("close");
                    }
                });
            }
        });

        //$(".signaturePadDialoge").load(base_url+'requested_kols/upgrade_request_page');
        return false;
    }



</script>
<button value="Back To Interactions" onclick="window.history.back();">Back To Interactions</button><br/><br/>
<div id="medContainer">
    <table><caption id="headerContentCss" style="font-weight: bold; text-align: center;">Unsolicited Off-Label Question</caption></table>
<?php
$productArray = array_flip($productArray);
?>
    <form id="mirfForm" action="<?php echo base_url(); ?>interactions/save_mirf_form" method="post">
        <input type="hidden" name="previousUrl" value="<?php echo $_SERVER['HTTP_REFERER']; ?>"> 
        <input type="hidden" name="add_from" value="<?php echo $addFrom; ?>">
        <input type="hidden" name="add_from_id" value="<?php echo $addFromId; ?>">
      
       
    <?php if (isset($mirfDetails)) { ?>
            <input type="hidden" name="mirf_id" value="<?php echo $mirfDetails[0]["id"]; ?>">
            <input type="hidden" name="interaction_id" value="<?php echo $mirfDetails[0]["interaction_id"]; ?>">
        <?php } else { ?>
            <input type="hidden" name="interaction_id" value="<?php echo $interactionId; ?>"> 
<?php } ?>
        <table>
            <caption style="font-weight: bold;">&nbsp;</caption>
            <tr class="dateDiv">
                <th class="alignRight">Date of the Request:<span class="error">*</span></th>
                <td><input type="text" name="date_of_request" id="date_of_request" value="<?php if (isset($mirfDetails[0]['date_of_request']))
                {
                    $originalDate = $mirfDetails[0]['date_of_request'];
$newDate = date("m/d/Y", strtotime($originalDate));
                    echo $newDate;
                }
else{
    $originalDate = $arrInteractionsResults['date'];
$newDate = date("m/d/Y", strtotime($originalDate));
    echo $newDate;
}
?>">
                </td>
                <td>&nbsp;</td>
            </tr>
            <tr  class="ch">
                <th class="alignRight">Product:<span class="error">*</span>&nbsp;</th>
         


                <td>
                    <label><input type="checkbox" style="display:none;" id="productFirst" class="par" name="product[]" value="<?php echo $productArray['ABILIFY MAINTENA']; ?> " <?php if (isset($mirfDetails) && in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds)) echo "checked = 'checked'"; ?>>ABILIFY MAINTENA (aripiprazole)</label>
                    <input type="checkbox"  style="display:none;" class="par" name="first_product_value"  id="first_product_value" value='1'/>
                </td>
                <td class="alignLeft">
                    <label><input type="checkbox" class="childCheckBox" id='is_single_use_vial' name="is_single_use_vial" value="1" <?php if (isset($mirfDetails) && in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_single_use_vial'] == 1) echo "checked = 'checked'"; ?>>Single-Use Vial</label> 
                </td>
                <td class="alignLeft">
                    <label><input type="checkbox" class="childCheckBox" id='is_dual_chamber_syringe' name="is_dual_chamber_syringe" value="1" <?php if (isset($mirfDetails) && in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_dual_chamber_syringe'] == 1) echo "checked = 'checked'"; ?>>Dual Chamber Syringe</label> 
                </td>
                <td class="alignLeft">
                    <label><input type="checkbox" class="childCheckBox" id='is_non_kit_specific_enquiry' name="is_non_kit_specific_enquiry" value="1" <?php if (isset($mirfDetails) && in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_non_kit_specific_enquiry'] == 1) echo "checked = 'checked'"; ?>>Non-kit Specific Inquiry</label> 
                </td>
            </tr>

            <tr>
                <th class="alignRight">  
                    <label><input type="checkbox" id="product" name="product[]" style="opacity:0;"/></label></th>
                <td>
                    <label><input type="checkbox" id="product" name="product[]" value="<?php echo $productArray['ABILIFY']; ?> " <?php
if ((isset($mirfDetails) && in_array($productArray['ABILIFY'], $selectedProductIds)) || (in_array($productArray['ABILIFY'], $arrInteractionsProduct)))
    echo "checked = 'checked'";
?>>ABILIFY (aripiprazole)</label>
                </td>
                <td colspan="3" class="alignLeft">
                    <label><input type="checkbox" id="product" name="product[]" value="<?php echo $productArray['NUEDEXTA']; ?> " <?php if ((isset($mirfDetails) && in_array($productArray['NUEDEXTA'], $selectedProductIds)) || (in_array($productArray['NUEDEXTA'], $arrInteractionsProduct))) echo "checked = 'checked'"; ?>>NUEDEXTA (dextromethorphan hydrobromide and quinidine sulfate)</label>


                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td><label><input type="checkbox" id="product" name="product[]" value="<?php echo $productArray['REXULTI']; ?> " <?php if ((isset($mirfDetails) && in_array($productArray['REXULTI'], $selectedProductIds)) || (in_array($productArray['REXULTI'], $arrInteractionsProduct))) echo "checked = 'checked'"; ?>>REXULTI (brexpiprazole)</label>

                </td>
                <td class="alignLeft">
                    <label><input type="checkbox" id="product" name="product[]" value="<?php echo $productArray['SAMSCA']; ?> " <?php if ((isset($mirfDetails) && in_array($productArray['SAMSCA'], $selectedProductIds)) || (in_array($productArray['SAMSCA'], $arrInteractionsProduct))) echo "checked = 'checked'"; ?>>SAMSCA (tolvaptan)</label>

                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td> <label><input type="checkbox" id="product" name="product[]" value="<?php echo $productArray['SPRYCEL']; ?> " <?php if ((isset($mirfDetails) && in_array($productArray['SPRYCEL'], $selectedProductIds)) || (in_array($productArray['SPRYCEL'], $arrInteractionsProduct))) echo "checked = 'checked'"; ?>>SPRYCEL (dasatinib)</label>
                </td>
                <td class="alignLeft">
                    <label><input type="checkbox" id="product" name="product[]" value="0" <?php if (isset($mirfDetails) && ($otherProductValue !== "")) echo "checked = 'checked'"; ?> >Other:</label>
                    <input class=" alignLeft"  type="text"  name="otherProduct" id="otherProduct"  value="<?php if (isset($mirfDetails))
                                      echo $otherProductValue;
                                  else
                                      echo ' ';
?>">
                </td>
            </tr>
        </table>
        <table style="margin-top:5px;">
            <caption style="font-weight: bold;"><?php echo lang("HCP"); ?> REQUESTOR INFORMATION</caption>
            <tr>    
                <th class="alignRight">NAME:<span class="error">*</span></th>
                <td><?php
                    $kol_id = $kolDetails[0]['id'];
                    $salu = $kolDetails[0]['salutation'];

                    if ($salu == '0') {
                        $kol_name = $this->common_helpers->get_name_format($kolDetails[0]['first_name'], $kolDetails[0]['middle_name'], $kolDetails[0]['last_name']);
//                        $kol_name = $kolDetails[0]['first_name'] . ' ' . $kolDetails[0]['middle_name'] . ' ' . $kolDetails[0]['last_name'];
                    } else {
                        $kol_name = $this->common_helpers->get_name_format($kolDetails[0]['first_name'], $kolDetails[0]['middle_name'], $kolDetails[0]['last_name']);
                        //$kol_name = $kolDetails[0]['salutation'] . ' ' . $kolDetails[0]['first_name'] . ' ' . $kolDetails[0]['middle_name'] . ' ' . $kolDetails[0]['last_name'];
                    }
                    ?>
                    <input class="inputTypeWidth autocompleteInputBox" autocomplete="off" type="text" name="kol_id" id="kol_id" value="<?php
                    if (isset($mirfDetails))
                        echo $kolName;
                    elseif ($kol_name != "") {
                        echo $kol_name;
                    }
                    ?>">
                    <input type="hidden" name="contact_id"  class="selectedKolId" id="contact_id" value='<?php
                    if (isset($mirfDetails))
                        echo $mirfDetails[0]['kol_id'];
                    elseif ($kol_id != "") {
                        echo $kol_id;
                    } else {
                        echo '';
                    }
                    ?>'>
                </td>
                <th class="alignRight">DEGREE:<span class="error">*</span></th>
                <td>
                    <select name="degree" class="selectTypeWidth" id="degree">
                        <option value="">Select Degree</option>
                        <?php
                        foreach ($arrgetAllActiveDegrees as $key => $val) {
                            $selected = '';
                            if ($key == $kolDetails[0]['degree_id'])
                                echo '<option  id="' . $key . '" value="' . $val . '" selected="selected">' . $val . '</option>';
                            if ($val == $mirfDetails[0]['degree']) {
                                echo '<option  id="' . $key . '" value="' . $val . '" selected="selected">' . $val . '</option>';
                            } else {
                                echo '<option id="' . $key . '" value="' . $val . '">' . $val . '</option>';
                            }
                            ?>
        <!--                                <option id="<?php echo $key; ?>" value="<?php echo $val; ?>">
    <?php //echo $val;  ?>
                                   </option>-->
                    <?php } ?>
                    </select>

<!--<input class="inputTypeWidth" type="text" name="degree" id="degree" value="<?php if (isset($mirfDetails[0]['degree']))
                        echo $mirfDetails[0]['degree'];
                    else
                        echo '';
                    ?>">-->
                </td>
            </tr>
            <tr>
                <th class="alignRight">SPECIALTY (if applicable):<span class="error">*</span></th>
                <td><?php $specialties = $arrInteractionsResults['attendees']['specialties'][0]; ?>
<!--                    <input class="inputTypeWidth" type="text" name="specialty" id="specialty" value="<?php
                    if (isset($mirfDetails[0]['specialty']))
//    echo $mirfDetails[0]['specialty'];
//elseif ($specialties != "") {
//    echo $specialties;
//} else
//    echo '';
                        
                        ?>">-->
                    <select name="specialty" class="selectTypeWidth" id="specialty">
                        <option value="">Select Specialty</option>
                        <?php
                        foreach ($specialtyName as $key => $value) {
                            $selected = '';
                            if ($value == $mirfDetails[0]['specialty']) {
                                echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                            } elseif ($specialties != "") {
//                                                         echo $specialties;
                                if ($value == $specialties) {
                                    echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                                } else {
                                    echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                                }
                            } else {
                                echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                            }

                            //   else{
                        }
                        ?></select>

                </td>
                <th class="alignRight">STATE LIC#:</th>
                <td>
                    <input class="inputTypeWidth" type="text" name="licence" id="licence" value="<?php
                        if (isset($mirfDetails[0]['licence']))
                            echo $mirfDetails[0]['licence'];
                        elseif ($kolDetails[0]['license'] != "") {
                            echo $kolDetails[0]['license'];
                        } else
                            echo '';
                        ?>">
                </td>
            </tr>
            <tr>    
                <th class="alignRight">INSTITUTION/OFFICE:<span class="error">*</span></th>
                <td>
                    <textarea rows="3" name="institution" id="institution" style="width:215px !important; border: 1px solid #999 !important;"><?php
                        if (isset($mirfDetails[0]['institution']))
                            echo $mirfDetails[0]['institution'];
                        elseif ($kolDetails[0]['org_id'] != "") {
                            echo $kolDetails[0]['org_id'];
                        } else
                            echo '';
                        ?></textarea>

                </td>
                <th class="alignRight">ADDRESS:<span class="error">*</span></th>
                <td>
                    <textarea rows="3"  name="address" id="address" style="width:215px !important; border: 1px solid #999 !important;"><?php
                        if (isset($mirfDetails[0]['address']))
                            echo $mirfDetails[0]['address'];
                        elseif ($kolDetails[0]['address1'] != "") {
                            echo $kolDetails[0]['address1'] . ' ' . $kolDetails[0]['address2'];
                        } else
                            echo '';
                        ?></textarea>

                </td>
            </tr>
            <tr>

                <th class="alignRight">STATE:<span class="error">*</span></th>
                <td>
                    <select class="selectTypeWidth" name="state" id="state" onchange="getCitiesByStateId(this);">		
                        <option value="">Select state</option>
                        <?php foreach ($arrStates as $state) { ?>
                            <option id="<?php echo $state['state_id']; ?>" value="<?php echo $state['state_name']; ?>" 
                                        <?php
                                        if (isset($mirfDetails[0]['state'])) {
                                            if ($state['state_name'] == $mirfDetails[0]['state'])
                                                echo 'selected';
                                        }
                                        elseif ($state['state_id'] == $kolDetails[0]['state_id']) {
                                            echo 'selected';
                                        }
                                        ?>>
                        <?php echo $state['state_name']; ?>
                            </option>
                    <?php } ?>
                    </select>
                    <img id="loadingCities" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>

<!--                         <input class="inputTypeWidth" type="text" name="state" id="state" value="<?php
                    if (isset($mirfDetails[0]['state']))
                        echo $mirfDetails[0]['state'];
                    elseif ($arrInteractionsResults['state'] != "") {
                        echo $arrInteractionsResults['state'];
                    } else
                        echo '';
                    ?>">-->
                </td>
                <th class="alignRight">CITY:<span class="error">*</span></th>
                <td>
                    <select class="selectTypeWidth" name="city" id="city">
                        <option value="">Select city</option>
                        <?php
                        foreach ($arrCities as $city) {
                            echo '<option id="' . $city['city_id'] . '" value="' . $city['city_name'] . '" ';
                            if (isset($mirfDetails[0]['city'])) {
                                if ($city['city_name'] == $mirfDetails[0]['city'])
                                    echo 'selected';
                            }
                            elseif ($city['city_id'] == $kolDetails[0]['city_id']) {
                                echo 'selected';
                            }
                            echo '>' . $city['city_name'] . '</option>';
                        }
                        ?>
                    </select>
<!--                         <input class="inputTypeWidth" type="text" name="city" id="city" value="<?php
                        if (isset($mirfDetails[0]['city']))
                            echo $mirfDetails[0]['city'];
                        elseif ($arrInteractionsResults['city'] != "") {
                            echo $arrInteractionsResults['city'];
                        } else
                            echo '';
                        ?>">-->
                </td>
            </tr>
            <tr>
                <th class="alignRight">ZIP CODE:<span class="error">*</span></th>
                <td>
                    <input class="inputTypeWidth" type="text" name="zip_code" id="zip_code" value="<?php
                    if (isset($mirfDetails[0]['zip_code']))
                        echo $mirfDetails[0]['zip_code'];
                    elseif ($kolDetails[0]['postal_code'] != "") {
                        echo $kolDetails[0]['postal_code'];
                    } else
                        echo '';
                    ?>">
                </td>
                <th class="alignRight">TELEPHONE #:<span class="error">*</span></th>
                <td>
                    <input class="inputTypeWidth" type="text" name="telephone" id="telephone" value="<?php
                    if (isset($mirfDetails[0]['telephone']))
                        echo $mirfDetails[0]['telephone'];
                    elseif ($kolDetails[0]['primary_phone'] != "") {
                        echo $kolDetails[0]['primary_phone'];
                    } else
                        echo '';
                    ?>">
                </td>
            </tr>
        </table>
        <table style="margin-top:5px;" class="disabledDiv">
            <tr >
                <th class="alignRight">DELIVERY:</th>
                <td colspan="1">
                    <label><input type="checkbox" disabled="disabled" name="email_id" value="1"  <?php if (isset($mirfDetails[0]['email_id']) && ($mirfDetails[0]['email_id']) != 0) echo "checked = 'checked'"; ?>>Email</label>

                    <!--                                </td>
                                                    <td colspan="0" class="alignRight">-->
                    &nbsp;  &nbsp; <label for="male">E-mail address:</label>
                    <!--				</td>
                                                    <td colspan="5" >-->
                    <input class="inputTypeWidth input-disabled" disabled type="text" name="email" value="<?php if (isset($mirfDetails[0]['email']) && ($mirfDetails[0]['email']) != 0)
                        echo $mirfDetails[0]['email'];
                    else
                        echo '';
                    ?>">
                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td>
                    <label><input type="checkbox" disabled="disabled" id="b" name="mail" value="1"  <?php if (isset($mirfDetails[0]['mail']) && ($mirfDetails[0]['mail']) != 0) echo "checked = 'checked'"; ?>>Mail</label>


                    <!--                                </td>
                                                    <td class="alignRight"> -->
                    &nbsp;  &nbsp;  <label><input type="checkbox" id="b" disabled="disabled"  name="fax_id" value="1"
<?php if (isset($mirfDetails[0]['fax_id']) && ($mirfDetails[0]['fax_id']) != 0) echo "checked = 'checked'"; ?>>Fax / Fax #:</label>

                    <!--				</td>
                                                    <td>-->
                    <input class="inputTypeWidth input-disabled" disabled type="text" name="fax" value="<?php if (isset($mirfDetails[0]['fax']) && ($mirfDetails[0]['fax']) != 0)
    echo $mirfDetails[0]['fax'];
else
    echo '';
?>">
                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td colspan="5">
                    <label><input type="checkbox" id="b" disabled="disabled" name="answer_provided" value="1" <?php if (isset($mirfDetails[0]['answer_provided']) && ($mirfDetails[0]['answer_provided']) != 0) echo "checked = 'checked'"; ?>>Answer Provided– no response from Medical Information required. (Please document response)</label>

                </td>
            </tr>

        </table>
        <table style="margin-top:5px;" class="textLabel">
            <hr/><center> <label  style="font-weight: bold; text-align: center;" >Adverse events MUST NOT be reported on this form. </label><br/></center> 
            <center> <label style="font-weight: bold; text-align: center;"> Adverse Events/Product Complaints MUST be reported to 1-800-438-9927.</label></center> 

        </table>
        <table style="margin-top:5px;">
            <caption style="font-weight: bold;">MEDICAL INFORMATION REQUEST(s) – <?php echo lang("HCP"); ?> QUESTION <span class="spanSign"> AND SIGNATURE REQUIRED</span></caption>
            <tr><th class="alignRight"><?php echo lang("HCP"); ?> QUESTION:<span class="error">*</span></th> <td>   
                    <textarea rows="3" id="mir_questions"  name="mir_questions" style="width:97%;"><?php if (isset($mirfDetails[0]['mir_questions']))
                           echo $mirfDetails[0]['mir_questions'];
                       else
                           echo '';
?></textarea></td>
            </tr>
            <tr style="display: none;"><th class="alignRight"><?php echo lang("HCP"); ?> SIGNATURE:</th> <td> 
                    <a href="#" onclick="openSignaturePad();
                            return false;">Click here</a> 
                    <img id="signatureImage" width="500" height="200" <?php if (isset($mirfDetails[0]['hcp_signature'])) echo "src='" . base_url() . "images/mirf_signatures/" . $mirfDetails[0]['hcp_signature'] . "'"; ?>></img> 
                    <input type="hidden" name="hcp_signature" value="<?php if (isset($mirfDetails[0]['hcp_signature']))
                           echo $mirfDetails[0]['hcp_signature'];
                       else
                           echo '';
?>" style="width:97%;"></input></td>
            </tr>
        </table>
        <table style="margin-top:5px;" class="disabledDiv">
            <hr/><tr><th colspan="5">Your signature below confirms that your request(s) and/or question(s) was (were) not prompted or solicited by anyone at
                    Otsuka America Pharmaceutical, Inc., and that the wording above accurately states your request(s) and/or question(s).</th>
            </tr> <tr> <th>
                    <?php echo lang("HCP"); ?> SIGNATURE (REQUIRED): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;X <span style="width:97%;">__________________________________________________________________________________________________________________________</span>
                </th>
        </table>
        <table style="margin-top:5px;">
            <caption style="font-weight: bold;">MSL INFORMATION</caption>
            <tr><th colspan="5">If Answer Provided is selected above, provide a brief description of the answer provided and resources utilized for each question.</th></tr>
            <tr><th class="alignRight">MSL Response:<span class="error">*</span></th> <td>   
                    <textarea rows="3" id="msl_info" name="msl_info" style="width:97%;" ><?php if (isset($mirfDetails[0]['msl_info']))
                           echo $mirfDetails[0]['msl_info'];
                       else
                           echo '';
?></textarea></td>
            </tr>
        </table>
        <table style="margin-top:5px;">
            <tr>
                <th class="alignRight">MSL/MML NAME:<span class="error">*</span></th>
                <td><input type="hidden" class="inputTypeWidth" name="client_id" value="<?php echo $userId; ?>" />  
                    <input type="text" class="inputTypeWidth" name="<?php echo $userId; ?>" value="<?php if (isset($mirfDetails[0]['client_id']))
                           echo $clientUser;
                       else
                           echo $userName;
?>
                           " /> </td>
                <td>&nbsp;</td>
                <th class="alignRight">TERRITORY:</th>
                <td> <input type="text" class="inputTypeWidth" name="<?php echo $userTerritory; ?>" 
                            value="<?php if (isset($mirfDetails[0]['client_territory']))
                           echo $mirfDetails[0]['client_territory'];
                       else
                           echo $userTerritory;
?>
                            "/></td>
            </tr>
        </table>
        <center>
            <input type="submit" onclick="saveMirf();" id="mirfSave" name="submit" value="<?php echo SUBMIT_BUTTON_LABEL ?>" />
            <input type="button" value="Cancel" onclick="window.location.href = '<?php echo $previousUrl; ?>'"  />
        </center>
    </form>

    <table style="margin-top:5px;">

        <tr><th colspan="5">PLEASE FAX/E-MAIL THIS REQUEST FOR INFORMATION TO: 301-212-8634 / <a href="mailto:faxmedicalinformation@otsuka-us.com">faxmedicalinformation@otsuka-us.com</a></th></tr>

    </table>
</div>
<div id="signaturePadDialoge" class="microProfileDialogBox">
    <div class="signaturePadDialoge profileContent"></div>
</div>