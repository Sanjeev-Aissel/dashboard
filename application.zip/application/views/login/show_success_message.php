<?php
/**
 * View -Password Cinfirmamtion page
 * @author Vinayaj
 * @since 0tsuka_1.0.7
 * @package application.view.login	
 * @created on 20-12-2012
 */
?>

<style type="text/css">
	.message{
		margin: 7% 4% auto;	
	}
	b{
	
	} 
 
	.header{
	border-bottom: 1px solid #D7D9DA;
    color: #0070BD;
    font-family: trebuchet ms;
    font-size: 28px;
    margin: 1px 4% auto;
    padding: 18px 5px 5px 0;
    width: 495px;
	}
</style>
<div class="header">
	
	 Password Reset Successful
	
</div>
<div class="message">
	Your password has been successfully changed. <a href="<?php echo base_url()?>login" >Click Here</a> to Login
</div>