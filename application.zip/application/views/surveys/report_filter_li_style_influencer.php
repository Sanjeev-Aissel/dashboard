<?php
/**
 * this is html file to hold the Report filter sections
 * 
 * @Author		: Laxman K
 * @since 		: KOLM v6.0.9 Otsuka 2.2
 * Created on	: 22-07-2014
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {}";
//pr($arrFiltersData);
?>
<?php 
 if($activeTab=='individualMap'){
$surveys = array('id'=>'All','name'=>'All');
//array_push($arrSurveys,$surveys);
 }
 

?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/refinedByFilter.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>surveys/" name="searchFilterForm" method="post" id="searchFilterFormInfluencer">
		<ul id="categoriesContainer1">
			<li class="category">
				<div style="margin-top: 10px;">
					<div></div><label class="categoryName sectionInlineHeading">Question</label>
					<div  id="questionsDropDown">
						<select id="surveyInfluencer" name="survey" class="chosenSelect dropdownInlineWithHeading" style="width: 200px;">
							<option value="All">All Questions</option>
							<?php  foreach($arrSurveys as $key=>$arrRow){
								$selected	= '';
								
								if(isset($arrSelections['survey_id']) && $arrSelections['survey_id']==$arrRow['id']){
										
									$selected	= ' selected="selected"';
									echo '<option value="'.$arrRow['id'].'"'.$selected.'>'.$arrRow['name'].'</option>';
								}else{
									echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
								}
								
								
							}?>
						</select>
					</div>
				</div>
				<div style="margin-top: 10px;">
					<div></div><label class="categoryName sectionInlineHeading">Influencer Type</label>
					<div >
						<select id="influencerTypeForTable" name="influencer_type" class="chosenSelect dropdownInlineWithHeading" style="width: 200px;">
							<option value="0">All Types</option>
							<?php foreach($arrTypes as $key=>$value){
								$selected	= '';
								if(isset($arrSelections['nominee']['type']) && $arrSelections['nominee']['type']==$key){
									$selected	= ' selected="selected"';
								}
								echo '<option value="'.$key.'"'.$selected.'>'.$value.'</option>';
							}?>
						</select>
					</div>
				</div>
			</li>
			
			</ul>
			<ul id="categoriesContainer">
			
			<!--  
			<li id="categoryCountry" class="category">
				<div></div><label class="categoryName">Country</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
					<table class="clear">
						 CheckBox representing All for this Category 
						<?php
							/* pr($arrFiltersData['countries']);
							pr ($arrSelections['nominee']['country']);*/
							$i=0;
							$total	= 0;
							foreach($arrFiltersData['countries'] as $index=>$arrRow){
								$total	+= $arrRow['count'];
							}
							$selected	= "";
							if(!is_array($arrSelections['nominee']['country'])){
								$selected	= 'checked="checked"';
							}
							$arrFiltersSelected	= array_flip($arrSelections['nominee']['country']);
						?>
						<tr class="allCountries">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="country_ids[]" id="allCountries"  value="All Countries" <?php echo $selected;?> />All Countries</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $total."(".round(($total/$total)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($total)) echo round(($total/$total)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if(isset($arrFiltersData['countries'])) echo $total; else echo 0;?></td>
						</tr>
						 Sart of Displaying checkbox for each value in thi category (currently limited to 4)
								and also make chekbox checked if it is already selected in the previous filtering	
						<?php 
						 	foreach($arrFiltersData['countries'] as $index=>$arrRow){
						 		$unique	= str_replace(" ","_",$index);
						 		$key	= $arrRow['name'];
						 		$value	= $arrRow['count'];
						 		$selected	= "";
						 		if(isset($arrFiltersSelected[$key])){
						 			$selected	= 'checked="checked"';
						 			unset($arrFiltersSelected[$key]);
						 		}
						 		if(!empty($key) || $key!=""){
						 		/* if(empty($key) || $key==""){
						 			$key	= "Others";
						 		} */
						 	?>
						 	<tr class="country<?php echo $unique;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $unique;?>" value="<?php echo $key;?>" <?php echo $selected;?>	/>&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php echo $value;?></td>
						 	</tr>
						<?php $i++; if($i>3) break; }}
							foreach($arrFiltersSelected as $key=>$value){
							$value	= $arrFiltersData['countries'][$key];
							if($value<1){
								$value	= 0;
							}
							?>
							<tr class="country<?php echo str_replace(" ","_",$key);?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(" ","_",$key);?>" value="<?php echo $key;?>" checked="checked" />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php echo $value;?></td>
						 	</tr>
						<?php }
						?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="country" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
				</div>
			</li>
			-->
			
			<li id="categoryUser" class="category">
				<div></div><label class="categoryName">MSL</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
					<table class="clear">
						<!-- CheckBox representing All for this Category -->
						<?php
							$i=0;
							$total	= 0;
							foreach($arrFiltersData['users'] as $index=>$arrRow){
								$total	+= $arrRow['count'];
							}
							$selected	= "";
							if(!is_array($arrSelections['users']['user'])){
								$selected	= 'checked="checked"';
							}
							$arrFiltersSelected	= array_flip($arrSelections['users']['user']);
						?>
						<tr class="allUsers">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="user_ids[]" id="allUsers"  value="All Users" <?php echo $selected;?> />All Account Managers</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $total."(".round(($total/$total)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($total)) echo round(($total/$total)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td></td>
						</tr>
						<?php 
						 	foreach($arrFiltersData['users']  as $index=>$arrRow){
						 		$unique	= str_replace(" ","_",$index);
						 		$key	= $arrRow['name'];
						 		$value	= $arrRow['count'];
						 		$selected	= "";
						 		if(isset($arrFiltersSelected[$key])){
						 			$selected	= 'checked="checked"';
						 			unset($arrFiltersSelected[$key]);
						 		}
						 		if(!empty($key) || $key!=""){
						 		/* if(empty($key) || $key==""){
						 			$key	= "Others";
						 		} */
						 	?>
						 	<tr class="user<?php echo $unique;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="user_ids[]" class="userElement hideCheckbox" id="user<?php echo $unique;?>" value="<?php echo $key;?>" <?php echo $selected;?> />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php $i++; if($i>3) break; }}
						foreach($arrFiltersSelected as $key=>$value){
							$name	= $value['name'];
							$value	= 0;?>
							<tr class="user<?php echo str_replace(" ","_",$key);?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="user_ids[]" class="userElement hideCheckbox" id="user<?php echo str_replace(" ","_",$key);?>" value="<?php echo $key;?>" checked="checked" />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php }	?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="user" class="autocompleteInputBox" id="user" value="Enter Account Manager" title=""/><input type="hidden" name="user_id" id="userId" value="" />
				</div>
			</li>
			<li id="categoryState" class="category">
				<div></div><label class="categoryName">State</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
					<table class="clear">
						<!-- CheckBox representing All for this Category -->
						<?php
							$i=0;
							$total	= 0;
							foreach($arrFiltersData['states'] as $index=>$arrRow){
								$total	+= $arrRow['count'];
							}
							$selected	= "";
							if(!is_array($arrSelections['nominee']['state'])){
								$selected	= 'checked="checked"';
							}
							$arrFiltersSelected	= array_flip($arrSelections['nominee']['state']);
						?>
						<tr class="allStates">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="state_ids[]" id="allStates"  value="All States" <?php echo $selected;?> />All States</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $total."(".round(($total/$total)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($total)) echo round(($total/$total)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td></td>
						</tr>
						<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
								and also make chekbox checked if it is already selected in the previous filtering	-->
						<?php 
						 	foreach($arrFiltersData['states'] as $index=>$arrRow){
						 		$unique	= str_replace(" ","_",$index);
						 		$key	= $arrRow['name'];
						 		$value	= $arrRow['count'];
						 		$selected	= "";
						 		if(isset($arrFiltersSelected[$key])){
						 			$selected	= 'checked="checked"';
						 			unset($arrFiltersSelected[$key]);
						 		}
						 		if(!empty($key) || $key!=""){
						 		/* if(empty($key) || $key==""){
						 			$key	= "Others";
						 		} */
						 	?>
						 	<tr class="state<?php echo $unique;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $unique;?>" value="<?php echo $key;?>" <?php echo $selected;?> />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php $i++; if($i>3) break; }}
							foreach($arrFiltersSelected as $key=>$value){
							$value	= $arrFiltersData['states'][$key]['count'];
							if($value<1){
								$value	= 0;
							}
							?>
							<tr class="state<?php echo str_replace(" ","_",$key);?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo str_replace(" ","_",$key);?>" value="<?php echo $key;?>" checked="checked" />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php }
						?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="state" class="autocompleteInputBox" id="state" value="Enter State" title=""/><input type="hidden" name="state_id" id="stateId" value="" />
				</div>
			</li>
			<li id="categoryCity" class="category">
				<div></div><label class="categoryName">City</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
					<table class="clear">
						<!-- CheckBox representing All for this Category -->
						<?php
							$i=0;
							$total	= 0;
							foreach($arrFiltersData['cities'] as $index=>$arrRow){
								$total	+= $arrRow['count'];
							}
							$selected	= "";
							if(!is_array($arrSelections['nominee']['city'])){
								$selected	= 'checked="checked"';
							}
							$arrFiltersSelected	= array_flip($arrSelections['nominee']['city']);
						?>
						<tr class="allCities">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="city_ids[]" id="allCities"  value="All Cities" <?php echo $selected;?> />All Cities</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $total."(".round(($total/$total)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($total)) echo round(($total/$total)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td></td>
						</tr>
						<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
								and also make chekbox checked if it is already selected in the previous filtering	-->
						<?php 
						 	foreach($arrFiltersData['cities'] as $index=>$arrRow){
						 		$unique	= str_replace(" ","_",$index);
						 		$key	= $arrRow['name'];
						 		$value	= $arrRow['count'];
						 		$selected	= "";
						 		if(isset($arrFiltersSelected[$key])){
						 			$selected	= 'checked="checked"';
						 			unset($arrFiltersSelected[$key]);
						 		}
						 		if(!empty($key) || $key!=""){
						 		/* if(empty($key) || $key==""){
						 			$key	= "Others";
						 		} */
						 	?>
						 	<tr class="city<?php echo $unique;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $unique;?>" value="<?php echo $key;?>" <?php echo $selected;?> />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php $i++; if($i>3) break; }}
							foreach($arrFiltersSelected as $key=>$value){
							$value	= $arrFiltersData['cities'][$key]['count'];
							if($value<1){
								$value	= 0;
							}
							?>
							<tr class="city<?php echo str_replace(" ","_",$key);?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo str_replace(" ","_",$key);?>" value="<?php echo $key;?>" checked="checked" />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php }
						?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="city" class="autocompleteInputBox" id="city" value="Enter City" title=""/><input type="hidden" name="city_id" id="cityId" value="" />
				</div>
			</li>
			<li id="categoryPostalCode" class="category">
				<div></div><label class="categoryName">Postal Code</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
					<table class="clear">
						<!-- CheckBox representing All for this Category -->
						<?php
							$i=0;
							$total	= 0;
							foreach($arrFiltersData['postalcodes'] as $index=>$arrRow){
								$total	+= $arrRow['count'];
							}
							$selected	= "";
							if(!is_array($arrSelections['nominee']['postal'])){
								$selected	= 'checked="checked"';
							}
							$arrFiltersSelected	= array_flip($arrSelections['nominee']['postal']);
						?>
						<tr class="allPostalcodes">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="postalcode_ids[]" id="allPostalcodes"  value="All Postalcodes" <?php echo $selected;?> />All Postal Codes</td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $total."(".round(($total/$total)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($total)) echo round(($total/$total)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td></td>
						</tr>
						<?php 
						 	foreach($arrFiltersData['postalcodes']  as $index=>$arrRow){
						 		$unique	= str_replace(" ","_",$index);
						 		$key	= $arrRow['name'];
						 		$value	= $arrRow['count'];
						 		$selected	= "";
						 		if(isset($arrFiltersSelected[$key])){
						 			$selected	= 'checked="checked"';
						 			unset($arrFiltersSelected[$key]);
						 		}
						 		if(!empty($key) || $key!=""){
						 		/* if(empty($key) || $key==""){
						 			$key	= "Others";
						 		} */
						 	?>
						 	<tr class="postalcode<?php echo $unique;?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="postalcode_ids[]" class="postalcodeElement hideCheckbox" id="postalcode<?php echo $unique;?>" value="<?php echo $key;?>" <?php echo $selected;?> />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php $i++; if($i>3) break; }}
						foreach($arrFiltersSelected as $key=>$value){
							$value	= $arrFiltersData['postalcodes'][$key]['count'];
							if($value<1){
								$value	= 0;
							}
							?>
							<tr class="postalcode<?php echo str_replace(" ","_",$key);?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="postalcode_ids[]" class="postalcodeElement hideCheckbox" id="postalcode<?php echo str_replace(" ","_",$key);?>" value="<?php echo $key;?>" checked="checked" />&nbsp;
						 			<?php echo $key;?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $value."(".round(($value/$total)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($total)) echo round(($value/$total)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
						 		<td><?php if($activeTab!='individualMap'){ echo $value;}?></td>
						 	</tr>
						<?php }	?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="postalcode" class="autocompleteInputBox" id="postalcode" value="Enter Postal Code" title=""/><input type="hidden" name="postalcode_id" id="postalcodeId" value="" />
				</div>
			</li>
		
			
		</ul>
	</form>
</div>
<style type="text/css">
	#searchFiltersElements ul {
		margin-right: 0px;
		padding-left: 5px;
		list-style: none;
	}
	#searchFiltersElements li.category{
		padding: 1px;
		position: relative;
	}
	#searchFiltersElements .dropdownInlineWithHeading{
		width:195px;
	}
	#searchFiltersElements label.sectionInlineHeading{
		float: left;
		border-bottom: 0px;
		min-width: 90px;
		text-align: left;
		margin-right: 2px;
	}
	#searchLeftBar{
		color:#626262;
	}
	#searchLeftBar h3 {
	    display: inline;
    }
    #searchLeftBar li.category::after {
	    border-top: 1px solid #bbbbbb;
	    content: "";
	    display: block;
	    height: 1px;
	    margin: 15px 0 0 -11px;
	}
</style>
<script type="text/javascript">
	var surveyIdTemp	= '<?php echo $arrSelections['survey_id'];?>';
	if(surveyIdTemp == 'undefined')
		surveyIdTemp = 'All';
	var isCitySelected	= <?php if($arrSelections['nominee']['city']==""){echo "0";}else{echo "1";}?>;
	var isPostalcodeSelected	= <?php if($arrSelections['nominee']['postal']==""){echo "0";}else{echo "1";}?>;
	var isRespondentSelected	= <?php if($arrSelections['respondents']['respondent']==""){echo "0";}else{echo "1";}?>;
	var isMSLSelected	= <?php if($arrSelections['users']['user']==""){echo "0";}else{echo "1";}?>;
	var influencerNamesAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/influencer/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.uid').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#influencerName').val(selText);
			var section	= $('#influencerName').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="influencer'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="influencer_ids[]" id="'+selText+'"  value="'+id+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="influencer'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="influencer_ids[]" id="'+selText+'"  value="'+id+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#influencerName').autocomplete(influencerNamesAutoCompleteOptions);
	$('#influencerName').focus(function(){
		$('#influencerName').val("");
	});
	$('#influencerName').blur(function(){
		var name	= $('#influencerName').val();
		if(name==""){
			$('#influencerName').val('Enter Influencer Name');
		}
	});
	var countryAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/country/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.id1').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#country').val(selText);
			var section	= $('#country').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="country'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="country_ids[]" id="country'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="country'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="country_ids[]" id="country'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#country').autocomplete(countryAutoCompleteOptions);
	$('#country').focus(function(){
		$('#country').val("");
	});
	$('#country').blur(function(){
		var name	= $('#country').val();
		if(name==""){
			$('#country').val('Enter Country');
		}
	});
	var stateAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/state/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.id1').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#state').val(selText);
			var section	= $('#state').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="state'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="state_ids[]" id="state'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="state'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="state_ids[]" id="state'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#state').autocomplete(stateAutoCompleteOptions);
	$('#state').focus(function(){
		$('#state').val("");
	});
	$('#state').blur(function(){
		var name	= $('#state').val();
		if(name==""){
			$('#state').val('Enter State');
		}
	});
	var cityAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/city/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.id1').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#city').val(selText);
			var section	= $('#city').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="city'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="city_ids[]" id="city'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="city'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="city_ids[]" id="city'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#city').autocomplete(cityAutoCompleteOptions);
	$('#city').focus(function(){
		$('#city').val("");
	});
	$('#city').blur(function(){
		var name	= $('#city').val();
		if(name==""){
			$('#city').val('Enter City');
		}
	});
	var postalcodeAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/postalcode/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.id1').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#postalcode').val(selText);
			var section	= $('#postalcode').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="postalcode'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="postalcode_ids[]" id="postalcode'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="postalcode'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="postalcode_ids[]" id="postalcode'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#postalcode').autocomplete(postalcodeAutoCompleteOptions);
	$('#postalcode').focus(function(){
		$('#postalcode').val("");
	});
	$('#postalcode').blur(function(){
		var name	= $('#postalcode').val();
		if(name==""){
			$('#postalcode').val('Enter Postal Code');
		}
	});
	var respondentAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/respondent/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.uid').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#respondent').val(selText);
			var section	= $('#respondent').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="respondent'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="respondent_ids[]" id="respondent'+selText+'" value="'+id+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="respondent'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="respondent_ids[]" id="respondent'+selText+'" value="'+id+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#respondent').autocomplete(respondentAutoCompleteOptions);
	$('#respondent').focus(function(){
		$('#respondent').val("");
	});
	$('#respondent').blur(function(){
		var name	= $('#respondent').val();
		if(name==""){
			$('#respondent').val('Enter Respondent');
		}
	});
	var userAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_suggestions_for_autocomplete_refineby/user/'+surveyIdTemp,
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var id = $(event).children('.id1').html();
			var selText = $(event).children('.suggestion').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#user').val(selText);
			var section	= $('#user').parent();
			var appendRow	= '';
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					appendRow	= '<tr class="user'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="user_ids[]" id="user'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
					appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
					appendRow	+= '<td>1</td>';
					$(section).find('table').append(appendRow);
					reload_filters_influencer();
				}
			}else{
				appendRow	= '<tr class="user'+selText+'"><td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="user_ids[]" id="user'+selText+'" value="'+selText+'" checked="checked" />'+selText+'</td>';
				appendRow	+= '<td class="histoGram"><div class="filterBar"><div class="progress" title="1(100%)"><div class="bar" style="width: 100%;"></div></div></div></td>';
				appendRow	+= '<td>1</td>';
				$(section).find('table').append(appendRow);
				reload_filters_influencer();
			}
		}
	};
	a= $('#user').autocomplete(userAutoCompleteOptions);
	$('#user').focus(function(){
		$('#user').val("");
	});
	$('#user').blur(function(){
		var name	= $('#user').val();
		if(name==""){
			$('#user').val('Enter MSL Name');
		}
	});
	function resetFilters(){
		$('#categoriesContainer input:checked').removeAttr('checked');
		$('#influencerTypeForTable').removeAttr('checked');
		$("#influencerTypeForTable").val('0').trigger('liszt:updated');
		$('#surveyInfluencer').removeAttr('checked');
		$("#surveyInfluencer").val('0').trigger('liszt:updated');
		reload_filters_influencer();
	}
	$(document).ready(function (){
		if(isCitySelected<1){
			$('#categoryCity').find('label.facet-toggle').trigger('click');
		}
		if(isPostalcodeSelected<1){
			$('#categoryPostalCode').find('label.facet-toggle').trigger('click');
		}
		if(isRespondentSelected<1){
			$('#categoryRespondent').find('label.facet-toggle').trigger('click');
		}
		//if(isMSLSelected<1){
			//$('#categoryUser').find('label.facet-toggle').trigger('click');
		//}
		$('.chosenSelect').chosen({allow_single_deselect: true});
		$('.chosenMultipleSelect').chosen({
			allow_single_deselect: true
		});
		$('#categoriesContainer input:checked').each(function (index){
			$(this).parent().parent().css('background-color','#D3DFED');
		});
		var activeTab	= $('.tabsWrapper ul.tabsContainer').find("li.current").attr("name");
		$('#searchFiltersElements ul li table tr').click(function (){
			
			if(activeTab=='individualMap'){
				if($('#influencerRespondentName').val()==''){
					alert("Enter Physician Name");
					return false;
				}
			}
			if($('#'+$(this).attr('class')).attr('checked')=="checked"){
				$(this).css('background-color','#ffffff');
				$('#'+$(this).attr('class')).removeAttr('checked');
				
				reload_filters_influencer();
			}else{
				var selectedValue	= $('#'+$(this).attr('class')).val();
				switch(selectedValue){
					case 'All Influencers':
					case 'All Countries':
					case 'All States':
					case 'All Cities':
					case 'All Postalcodes':
					case 'All Respondents':
					case 'All Users':
						var filterSection	= $('#'+$(this).attr('class')).parent().parent().parent();
						$(filterSection).find('input:checked').removeAttr('checked');
						break;
					default:
						$('#'+$(this).attr('class')).attr('checked','checked');
					break;
				}
				$(this).css('background-color','#D3DFED');
				
				reload_filters_influencer();
			}
		});
		$("#surveyInfluencer").chosen().change(function() {
			//surveyId	= $('#survey').val();
			if(activeTab=='individualMap'){
				if($('#influencerRespondentName').val()==''){
					alert("Enter Physician Name");
					return false;
				}
			}
			reload_filters_influencer();
		});
		$("#influencerTypeForTable").chosen().change(function() {
			if(activeTab=='individualMap'){
				if($('#influencerRespondentName').val()==''){
					alert("Enter Physician Name");
					return false;
				}
			}
			reload_filters_influencer();
		});
	});
</script>
