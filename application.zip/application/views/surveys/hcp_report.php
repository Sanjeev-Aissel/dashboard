<?php
/*
 * for Sales report
 * @author Laxman K
 * @since 6.0.9 iMap v1.0
 * Created on	: 22-12-2014
 *  
 */
	$queued_js_scripts =array(	'i18n/grid.locale-en',
							'jquery.jqGrid.min'
						);
	// add the JS files into queue i.e Append to the existing queue
	$prevjs = $this->config->item('js_files_to_load');
	if($prevjs == null)
		$prevjs = array();
	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.reportTypeButton:disabled{
		background:gray;
	}
</style>
<script>
var activeReportType	= '';
function exportGridToExcel(){
	var surveyId	= $('#surveyId').val();
	//window.location	= '<?php echo base_url();?>surveys/export_hcpreport_to_excel/'+surveyId;
	window.location	= '<?php echo base_url();?>surveys/export_hcpreport_to_excel_new/'+surveyId;
}

function listHCPData(){
	$("#HCPgridContainer").html("");
	$("#HCPgridContainer").html('<div id="listSurveysHCPPage"></div><table id="listSurveysHCPResultSet"></table>');
	activeReportType	= 'hcp report';
	var surveyId	= $('#surveyId').val();
	var ele=document.getElementById('surveysHCPList');
	var gridWidth=ele.clientWidth;
	gridWidth-=5;
	jQuery("#listSurveysHCPResultSet").jqGrid({
		url:base_url+'surveys/hcp_report_grid/'+surveyId,
		datatype: "json",
	   	colNames:['Id','Source','Survey Name','Manager','User Name','Territory Id','Territory','District','Region','Type','Respondent Name','Respondent Organization','Respondent Specialty','Respondent State','Respondent City','Influencer Type','Influencer Name','Influencer Organization','Influencer Specialty','Influencer State','Influencer City','Zero Influencer','Created On'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'source',index:'source'},
			{name:'survey_name',index:'survey_name'},
			{name:'manager_name',index:'manager_name'},
			{name:'user_name',index:'user_name', resizable:true},
			{name:'territory_id',index:'territory_id', resizable:true},
			{name:'territory_name',index:'territory_name', resizable:false},
			{name:'district',index:'district', resizable:false},
	   		{name:'region',index:'region', resizable:false},
	   		{name:'type',index:'type', resizable:false},
	   		{name:'resp_name',index:'resp_name', resizable:false},
	   		{name:'resp_org',index:'resp_org', resizable:false},
	   		{name:'resp_specialty',index:'resp_specialty', resizable:false},
	   		{name:'resp_state',index:'resp_state', resizable:false},
	   		{name:'resp_city',index:'resp_city', resizable:false},
	   		{name:'influencer_type',index:'influencer_type', resizable:false},
	   		{name:'influencer_name',index:'influencer_name', resizable:false},
	   		{name:'influencer_org',index:'influencer_name', resizable:false},
	   		{name:'influencer_specialty',index:'influencer_name', resizable:false},
	   		{name:'influencer_state',index:'influencer_state', resizable:false},
	   		{name:'influencer_city',index:'influencer_city', resizable:false},
	   		{name:'zero_influencers',index:'zero_influencer', resizable:false},
	   		{name:'created_on',index:'created_on', resizable:false}
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#listSurveysHCPPage',
	   	mtype: "POST",
	   	sortname: 'user_name',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:false,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:'HCP Completion Report',
	    grouping: false, 
		gridComplete: function(){},
   		rowList:paginationValues
	});
	jQuery("#listSurveysHCPResultSet").jqGrid('navGrid','#listSurveysHCPPage',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#listSurveysHCPResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	//Toggle Toolbar Search
	jQuery("#listSurveysHCPResultSet").jqGrid('navButtonAdd',"#listSurveysHCPPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}
		}
	});
	jQuery("#listSurveysHCPResultSet").jqGrid('navButtonAdd',"#listSurveysHCPPage",{
	    id:'ExportToExcel',
	    caption:'Export To Excel',
	    title:'Export To Excel',
	    onClickButton : exportGridToExcel,
	    buttonicon: 'ui-icon-print'
	});
	jQuery("#listSurveysHCPResultSet").jqGrid('setGridWidth',gridWidth);
}
$(document).ready(function(){
	listHCPData();
});
</script>
<div id="container">
	<div id="surveyContainer">
		Survey: <select id="surveyId" name="survey_id" onchange="listHCPData();">
			<option value="999">Select</option>
			<?php foreach($arrSurveys as $key=>$row){
				echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
			}?>
		</select>
		<div id="surveysHCPList" class="reportDataWrapper">
			<div class="gridWrapper" id="HCPgridContainer">
				<div id="listSurveysHCPPage"></div>
				<table id="listSurveysHCPResultSet"></table>
			</div>
		</div>
	</div>
</div>