<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
<style>
.box-container {
    margin-top: 20px;
}
.inline{
	display: inline;
}
p.inline.title {
    font-weight: bold;
}
.ui-jqgrid .ui-jqgrid-pager .ui-pg-div span.ui-icon {
    margin: -1px 2px !important;
}
table.ui-pg-table {
    font-size: 11px;
}
.listingType{
	list-style: none;
}
</style>
<script>
$(document).ready(function(){
	list_organizations_grid();
		// Settings for the Organization Import Dialog Box
		var modalBoxAddOpts = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 600,
				dialogClass: "microView",
				position: ['center', 90],
				open: function() {
					//display correct dialog content
				}
		};

		$("#importOrgContainer").dialog(modalBoxAddOpts);
	});
function deleteSelectedOrg(selectedOrgs){
	if(confirm("Are you sure you want to delete selected Organizations.?")){
		$.ajax({
			url:'<?php echo base_url()?>organizations/delete_organizations/'+selectedOrgs,
			type:'post',
			dataType:"json",
			success:function(returnMsg){
				list_organizations_grid();
				}
		});
	}else{
		return false;
	}
}
function list_organizations_grid(){
	var lastsel2;
		$('#gridOrgListing').html('');
	    $('#gridOrgListing').html('<div class="gridWrapper"><div id="gridOrgListingPagintaion"></div><table id="gridOrgListingResultSet"></table><div>');
	    grid = $("#gridOrgListingResultSet"),
        getUniqueNames = function(columnName) {
            var texts = grid.jqGrid('getCol',columnName), uniqueTexts = [],
                textsLength = texts.length, text, textsMap = {}, i;
         //   alert(texts.toSource());
            for (i=0;i<textsLength;i++) {
                text = texts[i];
                if (text !== undefined && textsMap[text] === undefined) {
                    // to test whether the texts is unique we place it in the map.
                    textsMap[text] = true;
                    uniqueTexts.push(text);
                }
            }
            return uniqueTexts;
        },
        buildSearchSelect = function(uniqueNames) {
            var values=":All";
            $.each (uniqueNames, function() {
                values += ";" + this + ":" + this;
            });
            return values;
        },
        grid.jqGrid({
			url:'<?php echo base_url();?>analysts/organizations/list_organizations_grid',
			datatype: "json",
			colNames:['Id','Name','Type','Founded','Pubmed ?', 'Trial ?','Profile Type','Created By','Status','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
				{name:'name',index:'name',search:true,
		   			formatter: function (cellvalue, options, rowObject) {
//		   				alert(rowObject.is_imported);
		   				if(rowObject.is_imported == parseInt(1)){
			   				 return "<a href='"+base_url+"/organizations/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
					         $.jgrid.htmlEncode(cellvalue) + "</a> <span class='highlightImported'> (xls)<span>";
			   			}
					        return "<a href='"+base_url+"/organizations/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				            $.jgrid.htmlEncode(cellvalue) + "</a>";
		    	},firstsortorder:'asc'},
		   		{name:'type',index:'type',width:100, search:true},
		   		{name:'founded',index:'founded',search:true,width:50, resizable:false, align:"center"},
		   		{name:'is_pubmed_processed',index:'is_pubmed_processed',search:true,width:50, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
		   		{name:'is_clinical_trial_processed',index:'is_clinical_trial_processed',width:30,search:true},
				{name:'profile_type',index:'profile_type',width:50,search:true, resizable:false},
				{name:'created_by',index:'created_by',width:80,search:true},
				{name:'status',index:'status',width:80,search:true},
				{name:'action',index:'action',width:35, align:'center',search:false, resizable:false}
				
		   	],
		   	onSelectRow: function(id){
			   	
            if(id && id!==lastsel2){
              grid.restoreRow(lastsel2);
              grid.editRow(id,true);
              lastsel2=id;
            }
           },
           onCellSelect: function(id){
   				var option=$("option[value='0']", $('#'+id+'_pubmed_processed'));
   				option.attr("disabled","disabled");
           },
           
           editurl: '<?php echo base_url();?>pubmeds/chnage_kol_pubmed_status',
		   	rowNum:10,
		   	multiselect: true,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#gridOrgListingPagintaion',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "asc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Organization Profiles",
//		    width: "100%",
		    gridComplete: function(){	
		    },
			rowList:paginationValues
		});
        grid.jqGrid('navGrid','#gridOrgListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		//setSearchSelect('pubmed_processed');
		grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
		grid.jqGrid('navButtonAdd',"#gridOrgListingPagintaion",{caption:"Delete",buttonicon : "ui-icon-trash", title:"Delete Select Row(s)",
			onClickButton:function (){
				var selectedOrgs	= $(this).getGridParam('selarrrow');
				if(selectedOrgs.length>0){
					deleteSelectedOrg(selectedOrgs);
				}else{
					alert('Please select atleast one Organization');
				}
			}
		});
		//Toggle Toolbar Search 
		grid.jqGrid('navButtonAdd',"#gridOrgListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
			onClickButton:toggleSearchToolbar
		});
	}

function toggleSearchToolbar(){ 			
	if(jQuery(".ui-search-toolbar").css("display")=="none") {
		jQuery(".ui-search-toolbar").css("display","");
	} else {
		jQuery(".ui-search-toolbar").css("display","none");
	}
};

function deleteOrganization() {
	var orgIds	= grid.getGridParam('selarrrow');
	deleteSelectedOrg(orgIds);
}

function deleteOrganization1(){
	var values = new Array();
	$.each($("input[name='orgId[]']:checked"), function() {
	  values.push($(this).val());
	});
	if(values == ""){
		alert("Please select atleast one Organization");
		return false;	
	}

	if(values!=''){
		if(confirm("Are you sure you want to delete selected Organization's?")){
			$.each($("input[name='orgId[]']:checked"), function() {
				var orgId = ($(this).val());
				$("#ORG_"+orgId).remove();
			});
			$('.organizationMsgBox').fadeIn("slow");
			$('.organizationMsgBox').removeClass('error');
			$('.organizationMsgBox').removeClass('success');
			$('.organizationMsgBox').text("");
			$('.organizationMsgBox').addClass('success');
			$('.organizationMsgBox').text("Wait");
			$.ajax({
				url:'<?php echo base_url()?>organizations/delete_organizations/'+values,
				type:'post',
				dataType:"json",
				success:function(returnMsg){
					if(returnMsg);
					$('.organizationMsgBox').removeClass('success');
					$('.organizationMsgBox').text("");
					$('.organizationMsgBox').addClass('error');
					$('.organizationMsgBox').text("Deleted Successfully");
					}
				});
			$('.organizationMsgBox').fadeOut(10000);
		}else{
			return false;
		}
	}
}

function checkedAll (thisEle) {
	if($(thisEle).attr("checked")==true){
		$.each($('input[name="orgId[]"]'),function(){
			$('input[name="orgId[]"]').attr("checked","checked");
		});
	}else{
			$.each($('input[name="orgId[]"]'),function(){
			$('input[name="orgId[]"]').removeAttr("checked");
		});
	}
  }

function importOrganization(){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#importOrgContainer").dialog("open");
	$("#importOrgProfileContent").load('<?php echo base_url()?>organizations/view_import_page');
	
	return false;	
}

function updateOrgStatus(){
	var values = new Array();
	var orgIds	= grid.getGridParam('selarrrow');
	
	if(orgIds == ""){
		alert("Please select atleast one Organization");
		return false;	
	}
	var data={};
	data['orgIds']= orgIds;
	data['status']= $('#status').val();
	if(data['status']==''){
		alert("Select Status");
		return false;
	}
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	$.ajax({
		url:'<?php echo base_url()?>organizations/update_org_status',
		type:'post',
		data:data,
		dataType:'json',
		success:function(rerurnData){
			if(rerurnData.status==true){
				$.each(orgIds,function(key,value){
					$('#'+value).find('td').eq(10).html(data['status']);
				});
			$('.msgBox').fadeOut(1500);
			}else{
				$('.msgBox').text("not Updated");
			}
		}
	});
		
	return false;

}

function updatePubmedStatus(){
	var status = $('#pubmed_status').val();
	var orgIds	= grid.getGridParam('selarrrow');
	if(orgIds == ""){
		alert("Please select atleast one Organization");
		return false;	
	}
	
	var data={};
	data['orgIds']= orgIds;
	data['status']= status;
	if(data['status']==''){
		alert("Select Status");
		return false;
	}
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>pubmeds_org/update_org_pubmed_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			if(status == 0)
				status = "No";
			if(status == 1)
				status = "Yes";
			if(status == 2)
				status = "Recrawl";
			$.each(orgIds,function(key,value){
				$('#'+value).find('td').eq(6).html(status);
			});
			$('.msgBox').text("Updated Successfully");
			$('.msgBox').fadeOut(1000);
		}
	});
}

function updateTrialStatus(){
	var status = $('#trial_status').val();
	var orgIds	= grid.getGridParam('selarrrow');
	if(orgIds == ""){
		alert("Please select atleast one Organization");
		return false;	
	}
	
	var data={};
	data['orgIds']= orgIds;
	data['status']= status;
	if(data['status']==''){
		alert("Select Status");
		return false;
	}
	
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>clinical_trials_org/update_org_trial_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			if(status == 0)
				status = "No";
			if(status == 1)
				status = "Yes";
			$.each(orgIds,function(key,value){
				$('#'+value).find('td').eq(7).html(status);
			});
			$('.msgBox').text("Updated Successfully");
			$('.msgBox').fadeOut(1000);
		}
	});
}
	
</script>
<div class="box-container">
		<div class="col-md-12"> 
		<?php $userRoleId = $this->session->userdata('user_role_id');?>
				<div class="inline">
					<p class="inline title">Set Status:</p>
						<select name="status" id="status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="Requested">Requested</option>
							<option value="<?php echo New1;?>">New</option>
							<option value="<?php echo PROFILING;?>">Profiling</option>
							<option value="<?php echo COMPLETED;?>">Completed</option>
						</select>
					<button onclick="updateOrgStatus()" class="btn btn-default"><span class="blue glyphicon glyphicon-save"></span> Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Pubmed Status:</p>
						<select id="pubmed_status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
							<option value="2">Recrawl</option>
						</select>
					<button onclick="updatePubmedStatus()" class="btn btn-default"><span class="blue glyphicon glyphicon-save"></span> Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Trial Status:</p>
						<select id="trial_status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
						</select>
					<button onclick="updateTrialStatus()" class="btn btn-default"><span class="blue glyphicon glyphicon-save"></span> Save</button>
				</div>
		</div>
		<div class="col-md-12"> 
			<div class="col-md-12">
				<button class="btn btn-default pull-right" name="submit"  onclick="deleteOrganization();"><span class="blue glyphicon glyphicon-import"></span> Import</button>
				<button class="btn btn-default pull-right" name="submit"  onclick="deleteOrganization();"><span class="red glyphicon glyphicon-trash"></span> Delete</button>
				<a href="<?php echo base_url(); ?>analysts/organizations/add_organization" class="btn btn-default pull-right clearfix"><span class="green glyphicon glyphicon-plus-sign"></span> Add New Organization Profile</a>
			</div>
			<div class="clearfix" style="margin:10px 0px;"></div>
			<div>
				<div id="gridOrgListing">
					<div class="gridWrapper">
						<div id="gridOrgListingPagintaion"></div>
						<table id="gridOrgListingResultSet"></table>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-md-12"> 
				<div class="col-md-4">
					<ul class="listingType">
							<li><a target="_new" href="<?php echo base_url();?>analysts/pubmeds/process_pubmeds_org">process pubmeds</a></li>
							<li><a target="_new" href="<?php echo base_url();?>analysts/clinical_trials/process_clinical_trials_org">process trials</a></li>
							<li><a target="_new" href="<?php echo base_url();?>analysts/clinical_trials/process_ctids_only_orgs">process CTIDs Only</a></li>
							<li><a target="_new" href="<?php echo base_url();?>analysts/organizations/list_import_files">List Org Import Files</a></li>
					</ul>
				</div>
				<div class="col-md-4">
				<ul  class="listingType"></ul>
			</div>
			<div class="col-md-4" style="margin-top:12px;"> 
				<button class="btn btn-default pull-right" name="submit"  onclick="deleteOrganization();"><span class="red glyphicon glyphicon-trash"></span> Delete</button>
			</div>	
		</div>
</div>
<!-- Container for the 'Kol's Export' modal box -->
	<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>