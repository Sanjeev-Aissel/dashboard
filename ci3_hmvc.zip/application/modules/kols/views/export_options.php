<style>
.export-options {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}
.export-options li {
    float: left;
    margin-left: 0px;
}
.export-options li a {
    display: block;
    text-align: center;
    text-decoration: none;
}
</style>
<div class="col-sm-9">
<ul class="export-options">
<?php if($this->common_helper->check_module("my_list_kols")){?>
   <li>
      <div class="createListIcon sprite_iconSet" onclick="displayModelBox();">
         <a rel="tooltip" title="Create List" href="#">&nbsp;</a>
      </div>
   </li>
<?php }?>
<?php if($this->common_helper->check_module("align_users")){?>
	<li>
   		<div class="alignToUsersIcon sprite_iconSet" onclick="alignUsers();">
   			<a rel="tooltip" href="#" data-original-title="Assign Profiles">&nbsp;</a>
   		</div>
	</li>
<?php }?>
   <li>															
		<div class="excelExportIcon sprite_iconSet" >
			<a rel="tooltip" onclick="showKolExportBox();return false;" title="Export profiles into Excel format">&nbsp;</a>
		</div>
   </li>
   <li>
      <div class="pdfExportIcon sprite_iconSet" onclick="exportPdfProfile();" style="margin-left: 2px;">
           <form action="<?php echo base_url();?>kols/kols/export_pdf" id="kolPdfExport" method="post">
               <a rel="tooltip" href="#" title="Export profile into PDF format">&nbsp;</a>
           </form>
      </div>
   </li>
   <li>
      <div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBoxInOvearllPage();return false;">
         <a rel="tooltip" href="#" title="Email Profile">&nbsp;</a>
      </div>
   </li>
</ul>
</div>
<div class="col-sm-3">
	<?php if($this->common_helper->check_module("interactions")){?>
	<a type="button" class="btn custom-btn" style="float:right;" href="<?php echo base_url().'kols/kols/add_kol';?>" title="Add Interaction">
	Add KTL/Contact
	</a	>
	<?php }?>
	<a type="button" class="btn custom-btn" style="float:right;" onclick="hide_right_side_div();return false;" href="#" title="Request">
	Hide/Show Sidebar
	</a	>
</div>	
<div id="listContainer" class="microViewLoading">
	<div class="modalListContent"></div>
</div>