 <?php
/**
 * Common layout for Kolm Analyst application. 
 *
 * @author: Kunal Anegundi
 * @created on: 21-06-11
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">

<head>
	<meta charset="UTF-8" />
	<title>Key Opinion Leader Management</title>

	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" rel="shortcut icon"/>
	
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	
	<!-- jQuery Core File -->
	<script type="text/javascript" src="<?php echo base_url()?>js/tooltip/jquery.js"></script>
	
	<!-- jQuery UI File -->
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.alerts.js" ></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/jquery.alerts.css" />
	<!-- JQGrid Plugins -->
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min_3.8.js" type="text/javascript"></script>
	
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>

	<!--  Autocomplete Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
	
	<!-- 2nd Plugin for Validation -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	
	
	<!-- jQuery DateTimePicker Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-ui-timepicker-addon 0.9.3.js"></script>
	
	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/analyst_layout.css" />
	
	<!-- Deprecated Custom CSS file -->
	<!--  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/default_layout.css" />-->
	
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/default_ie_only.css" rel="stylesheet" />
	<![endif]-->
	<!-- added by laxman   -->
	<!--[if IE 8]>
		<link type="text/css" href="<?php echo base_url()?>css/ie8_only_analyst.css" rel="stylesheet" />
	<![endif]-->
	
	<!-- javascript functions to calulate the absoluteposition of the given element -->
	<script type="text/javascript" src="<?php echo base_url()?>js/absolute_position_functions.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/chosen.jquery.js"></script>
	
<?php 
	if (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== false) {
		// Chrome user agent string contains both 'Chrome' and 'Safari'
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== false) {
			// include CHROME CSS';
		} else {
?>
			<link type="text/css" href="<?php echo base_url()?>css/safari5_1_analyst_only.css" rel="stylesheet" />
<?php 	}
	}
?>
	<!-- jQuery Block UI Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.blockUI.js"></script>
	<script type="text/javascript">
		var baseUrl = '<?php echo base_url();?>';
		var base_url = baseUrl;
		var paginationValues		= new Array();
		<?php 
			$paginationValues	= explode(',',PAGINATION_VALUES);
			foreach($paginationValues as $key=>$value){
		?>
			paginationValues.push('<?php echo $value;?>');
		<?php
			}
		?>
		/**
		* Returns the list of States of the Selected Country ID
		*/
		function getStatesByCountryId(){
			// Show the Loading Image
			$("#loadingStates").show();
			
			var countryId=$('#country_id').val();
			var params = "country_id="+countryId;	
			$("#state_id").html("<option value=''>-- Select State --</option>");
			$("#city_id").html("<option value=''>-- Select City --</option>");
			var states = document.getElementById('state_id');
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {					
						var newState = document.createElement('option');
						newState.text = value.state_name;
						newState.value = value.state_id;
						 var prev = states.options[states.selectedIndex];
						 states.add(newState, prev);				
						});
					
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
				},
				complete: function(){
					$("#loadingStates").hide();
				}
			});		
		}
	
		/**
		* Returns the list of Cities of the Selected State
		*/
		function getCitiesByStateId(){
			// Show the Loading Image
			$("#loadingCities").show();
			
			var stateId=$('#state_id').val();
			$("#city_id").html("<option value=''>-- Select City</option>");	
			var cities = document.getElementById('city_id');
			var params = "state_id="+stateId;	
			
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {	
								
					var newCity = document.createElement('option');
					newCity.text = value.city_name;
					newCity.value = value.city_id;
					 var prev = cities.options[cities.selectedIndex];
					 cities.add(newCity, prev);				
					});		
					$("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				},
				complete: function(){
					$("#loadingCities").hide();
				}		
			});		
			
		}
	</script>
	
</head>
<body>
<style>
	#contentWrapper.span-24, .span-24, #wrapper{
		width:1080px;
		width:1336px;
	}
</style>
<!-- Start of the WRAPPER div -->
<div id="wrapper" class="container">
	<!-- Start of HEADER div -->
	<?php //echo $this->load->view('elements/kolm_header_analyst_view',$data);?>
	<?php echo $this->load->view('elements/kolm_header_analyst_view');?>
	<!-- End of HEADER div -->
	
	
	<!--  Star of Content Wrapper Div -->
	<div id="contentWrapper" class="span-24">
		
		<div id="contents">
			<?php 
				// To avoid the notice, if there is no variable set, set it as blank
				if(!isset($data)) $data = "";
			?>
			
			<?php echo $this->load->view($contentPage, $data);?>
		</div>
		<!-- End of Contents Div -->
				
	</div>
	<!--  End of Content Wrapper Div -->
	
	<div id="footer">
		Copyright &copy; <?php echo COPYRIGHT;?> &nbsp; &nbsp; &nbsp; Powered by Aissel 
	</div>
	
</div>
<!-- End of the WRAPPER div -->				
</body>
</html>