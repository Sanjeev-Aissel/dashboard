<script src="<?php echo base_url().MODULES_ASSETS;?>clients/js/client.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>clients/css/client.css" rel="stylesheet">
<div style="margin:10px 0px;display: flow-root;">
	<div class="pull-right">
		<a class="btn btn-default" href="<?php echo base_url();?>clients/clients/add_client">Add-Client</a>
	</div>
</div>
<div id="clientGridWrapper" class="gridWrapper">
	<table id="clientListingResultSet"></table>
	<div id="clientListingPagination"></div>
</div>
<script>
$(document).ready(function(){
	list_clients_jqgrid();
});
</script>