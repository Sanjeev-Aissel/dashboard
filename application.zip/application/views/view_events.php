<?php
/**
 * File to 'add' events details
 *
 * @author: Ambarish
 * @created on: 9-12-10
 */
function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}

	//$queued_js_scripts = array('kols/view_events','highcharts 2.1.0','highchartsTheme','i18n/grid.locale-en','jquery.jqGrid.min','jquery.validate','jquery/jquery-ui-1.8.16.slider');
	$queued_js_scripts = array('chosen.jquery','kols/view_events','maps/map','highcharts2_2_2/highcharts3.0.5','highcharts2_2_2/modules/exporting3.0.5','i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min','jquery/jquery-ui-1.8.16.datepicket','jquery/jquery-ui-1.8.16.slider','jquery/jquery.ui.touch-punch.min','jqgridExportToExcel');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPwPj8G34QTdXihJzvRY4UJN2piezVAFY"></script>	
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />

	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
	    	<!-- Load c3.css -->
    <link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">
    
    <!-- Load d3.js and c3.js -->
    <script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
    <script src="<?php echo base_url();?>c3js/c3.min.js"></script> 
<style type="text/css">

	#eventMap{
	position:relative; 
	/*width:440px;*/ 
	height:390px;
	}
	
	.MapPushpinBase img {
    left: -2px !important;
    margin-left: 8px;
    margin-top: 31px;
}
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	div.toggleBtnWrapper {
		margin-bottom:50px;
		margin-top:-32px;
		text-align:left;
	}
	.c3-shape{
	   cursor: default !important;
	}

/*
	#eventsChartBySessionType, #roleChartBySessionType, #eventsChartByRole, #sessionChartByRole{
		display:inline;
		float:left;
		overflow: hidden;	
	}*/
	.alignCharts > div {
	    margin: auto;
	}
	#toggleConfGrouping{
		 /*margin-top:34px;*/
	}
	
	#eventsChart{
		width: 580px;
		margin-left: 100px;
	}
	
	#eventsChartByTopic {
     /*margin-left: 15px;*/
	}
	.addLink label {
		margin-top: -70px;
	}
/*	#confGridContainer {
	    width:786px;
	}
*/
	.NavBar_compassControlContainer,.NavBar_modeSelectorControlContainer,.NavBar_zoomControlContainer{
		display:none !important;
	}
	.firstColumn{
		border-bottom: 1px solid #EEEEEE;
	    border-right: 1px solid #EEEEEE
    }
    
    .secondColumn {
		border-bottom: 1px solid #EEEEEE;
	}
	.pubChartContainer .tableSections td {
	    padding: 0;
	 /*   width: 50%; */
	}	
	table.tableSections tr.tableHeader th:nth-child(2n+1), table.tableSections td:nth-child(2n+1) {
	    border-right: 1px solid #EEEEEE;
	}
	#mapsContent1{
		/*margin: 0 22px;*/
		margin-left: 0px;
		padding-left: 15px;
   		padding-right: 15px;
	}
	.exportOptionsContainer ul:first-child li .addIcon {
    	background-position: -150px -165px;
	}
	#eventsChartByTimeline, #eventsChartBySessionType,#eventsChartBySponsorType,#eventsChartByTopic,#eventsChartByRole{
	   text-align:center;
	}
	.rangeList li{
		margin-left: 15px;
	}
	div.editIcon {
	    margin-left: 10px;
	    margin-right: 2px;
	}
	div.editIcon:HOVER{
		margin-left: 10px;
		margin-right: 2px;
	}
	input.ui-pg-input{
	width:15px;
	}
</style>

<script type="text/javascript">
	var kolId = '<?php echo $arrKol['id']?>';
	var base_url='<?php echo base_url()?>';
	var customMarker = '<?php echo base_url()?>images/image1.png'; 
	var clientId='<?php echo $this->session->userdata('client_id')?>';
	var userId='<?php echo $this->session->userdata('user_id')?>';
	var userRoleId='<?php echo $this->session->userdata('user_role_id')?>';
	var ROLE_MANAGER ='<?php echo ROLE_MANAGER?>';
	var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
	var ROLE_USER ='<?php echo ROLE_USER?>';
	var INTERNAL_CLIENT_ID ='<?php echo INTERNAL_CLIENT_ID?>';
	var subContentPage	= '<?php echo $subContentPage;?>';
	
	var allEvents ="<?php echo lang('Overview.AllEvents')?>";
	var eventName = "<?php echo lang("Overview.EventName");?>";
	var sessionType = "<?php echo lang("Mykols.SessionType");?>";
	var topic = "<?php echo lang("Overview.Topic");?>";
	var role = "<?php echo lang("Mykols.Role");?>";
	var action = "<?php echo lang("Overview.Action");?>";
	jqgridIds	= new Array('JQBlistConferenceResultSet');
	/*
	* Common Time slider for All events Chart
	*
	*
	*/
	//Initiallize the Timeline slider
	<?php if($arrYearRange['min_year']!=''){?>
		var minYear=<?php echo $arrYearRange['min_year'];}?>;
	<?php if($arrYearRange['max_year']!=''){?>
		var maxYear=<?php echo $arrYearRange['max_year'];}?>;
		if(minYear==maxYear){
			minYear-=10;
		}
		var arrExcludeColumnsInExcelExport = new Array('micro','act'); 
		var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by','is_analyst','first_name','last_name');	
</script>
		<div id="kolOverviewTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<?php $this->load->view('elements/kol_short_details_client_view');?>
				<li><a href="#conference">Conference</a></li>
				<li><a href="#online">Online</a></li>
				<li><a href="#eventType">Event Type</a></li>
				<li><a href="#sessionType">Session Type</a></li>
				<li><a href="#topic">Topics</a></li>
				<li><a href="#role">Role</a></li>
			</ul>
			-->
			<div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
				<div class="exportOptionsContainer">
					<ul class="pageRightOptions rangeList">
						<?php if($subContentPage!='map'){?>
						<li>
							<?php 	if($arrYearRange['min_year'] && $arrYearRange['max_year']!='')
										echo '<label>Year Range:</label>';
							?>
							<input type="text" readonly="readonly" id="amount" style="border:0; color:#f6931f; font-weight:bold;vertical-align: middle;background-color:#fff;width: 90px;" />
						</li>
						
						<li>
							<div style="min-width:100px;" id="timeLineSlider" class="timeLineSlider"></div>
						</li>
						<?php if($subContentPage=='' or $subContentPage=='conference'){?>
<!--								<li><input type="button" onClick="toggleEventGrouping('JQBlistConferenceResultSet', 'toggleConfGrouping');" value="Remove Group By Event Type" name="toggleConfGrouping" id="toggleConfGrouping" /></li>-->
						<?php }?>
						<!--li><label class="link" onclick="showEventModalBox();"><div class="actionIcon addIcon"></div>Add New Event</label></li-->
						<?php }?>
						<?php if($subContentPage=='' or $subContentPage=='conference'){?>
								<li><input type="button" onClick="toggleEventGrouping('JQBlistConferenceResultSet', 'toggleConfGrouping');" value="Remove Group By Event Type" name="toggleConfGrouping" id="toggleConfGrouping" /></li>
						<?php }?>
						<?php $data['kol_id']=$arrKol['id'];?>
						<?php if($add_event==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)){?>						
								<li><label class="link" onclick="showEventModalBox();"><a rel="tooltip" title="Add New Event" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add New Event</a></label></li>
						<?php }?>
						<?php if($subContentPage=='' or $subContentPage=='conference'){?>
    						<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistConferenceResultSet','events');">
                            	<a href="#" rel="tooltip" data-original-title="Export Events Details into Excel format">&nbsp;</a>
                            </div></li>
						<?php }?>
					</ul>
				</div>
				<!-- <div class="exportOptionsContainer">
					<ul class="pageRightOptions">
						<?php if($subContentPage=='' or $subContentPage=='conference'){?>
								<li><input type="button" onClick="toggleEventGrouping('JQBlistConferenceResultSet', 'toggleConfGrouping');" value="Remove Group By Event Type" name="toggleConfGrouping" id="toggleConfGrouping" /></li>
						<?php }?>
						<?php if($add_event==1){?>
								<li><label class="link" onclick="showEventModalBox();"><div class="actionIcon addIcon"></div>Add New Event</label></li>
						<?php }?>
					</ul>
				</div> -->
			</div>
			<div class="clear">
			<?php 
				switch($subContentPage){
						case 'online':
			?>
								<!-- Add Online Event Details -->
								<div id="online">
									<div class="gridWrapper" id="onGridContainer">
										<table id="JQBlistOnlineResultSet"></table>
										<div id="listOnlinePage"></div>
									</div>
									<!--End of List Online Events -->
								</div>
								<!-- End of Add Online Event Details -->
			<?php 
							break;
						case 'event_type':
			?>
							<div id="eventType">	
								<div class="kolCharts">
									<div class="pieCharts">
										<div id="eventsChart">
											
										</div>
									</div>
									
									
								</div>
							</div>
			<?php 
							break;
						case 'session_type':
			?>
							<div class="pubChartContainer">
							<table class="tableSections">
								<tr class="tableHeader">
									<th>Events by Timeline</th>
									<th>Events by Map</th>
								</tr>
								<tr>
									<td class="firstColumn">
										<div id="eventsChartByTimeline" class="alignCharts"></div>
									</td>
									<td class="firstColumn">
										<div id="mapsContent1" class="alignCharts">			
											<div id='eventMap' style=""></div>
										</div>
									</td>
									</tr>
								<tr class="tableHeader">
									<th>Events by Sponsors</th>
									<th>Events by Session Type</th>
<!--									<th>Events By Topic</th>-->
								</tr>
								<tr>
									<td class="firstColumn">
										<div id="eventsChartBySponsorType" class="alignCharts"></div>
									</td>
									<td class="firstColumn">
										<div id="eventsChartBySessionType" class="alignCharts"></div>
									</td>
								</tr>
								<tr class="tableHeader">
									<th>Events by Topic</th>
									<th>Events by Role</th>
								</tr>
								<tr>
									<td class="firstColumn" >
										<div id="eventsChartByTopic" class="alignCharts"></div>
									</td>
									<td class="firstColumn">
										<div id="eventsChartByRole" class="alignCharts"></div>
									</td>
								</tr>
								</table>
						</div>
			<?php 
							break;
						case 'topics':
			?>
						<div class="pubChartContainer">
							<table class="tableSections">
								<tr class="tableHeader">
									<th>Events by Topic</th>
									<th>Events by Role</th>
								</tr>
								<tr>
									<td class="firstColumn">
										<div class="pieCharts">
											<div id="eventsChartByTopic"></div>
										</div>
									</td>
									<td class="secondColumn">
										<div class="pieCharts">
											<div id="eventsRoleChartByTopic"><div class="chartHighlightText">Click on Topic</div></div>
										</div>
									</td>
								</tr>
							</table>
						</div>
							<!--<div id="topic">
								<div class="kolCharts">
									<div class="pieCharts">
										<div id="eventsChartByTopic">
									
										</div>
									</div>
									<div class="pieCharts">
										
										<div id="eventsRoleChartByTopic">
										
										</div>
									</div>
								</div>
							</div>
			--><?php 
							break;
						case 'role':
			?>
						<div class="pubChartContainer">
							<table class="tableSections">
								<tr class="tableHeader">
									<th>Events By Role</th>
									<th>Session Type</th>
								</tr>
								<tr>
									<td class="firstColumn">
									<div class="pieCharts">
										<div id="eventsChartByRole"></div>
									</div>
									</td>
									<td class="secondColumn">
									<div class="pieCharts">
										<div id="sessionChartByRole"><div class="chartHighlightText">Click on Role</div></div>
									</div>
									</td>
								</tr>
							</table>
						</div>
							<!--<div id="role">	
								<div class="kolCharts">
									<div class="pieCharts">
										<div id="eventsChartByRole">
											
										</div>
									</div>
									<div class="pieCharts">
										<div id="sessionChartByRole">
											
										</div>
									</div>
										
								</div>
							--></div>
				<?php 
							break;
						case 'map':
			?>
								<div id="mapsContent1" class="">			
									<div id='eventMap' style=""></div>
								</div>
			<?php 
							break;
						default:
			?>
							<!-- Add Conference Event Details -->
							<div id="conference">
								
								<!-- Start of JQGrid based Table to listBoard CertificationResults -->
							
								<div class="gridWrapper" id="confGridContainer">
									<table id="JQBlistConferenceResultSet"></table>
									<div id="listConferencePage"></div>
								</div>
								<!--End of List Conference Events -->
							</div>
							<!-- End of Add Conference Event Details -->
			<?php 
							break;

				}
			?>
			</div>
		</div> 
		
			<!-- Event Modal box container -->
 			<div id="addEvent" class="microProfileDialogBox">
 				<div id="eventContainer" class="profileContent"></div>
 			</div>
 			
 				<!-- Container for the 'Event Micro Profile' modal box -->
				<div id="dailog1">	
					<div id="eventMicroProfile" class="microProfileDialogBox">
						<div class="profileContent"></div>
					</div>
				</div>
				<!--End of  Container for the 'Event Micro Profile' modal box -->
 				
