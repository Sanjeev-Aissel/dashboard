		<ul class='autoBio'>
		<?php if(isset($arrKolDetail['profile_type'])){
		    $arrKol['profile_type'] = $arrKolDetail['profile_type'];
		}?>
			<?php if($arrKol['profile_type'] == 'Full Profile'){?>
				<?php if($biographyTextDetails['arrCarrier']['experience'] > 0){?>
				<li><span><?php if($biographyTextDetails['arrCarrier']['experience'] == 1){ echo $biographyTextDetails['arrCarrier']['experience']." Year of experience";}else if($biographyTextDetails['arrCarrier']['experience'] > 1){ echo $biographyTextDetails['arrCarrier']['experience']." Years of experience";}?> </span></li>
				<?php }?>
			<?php }?>
			<?php if(count($biographyTextDetails['arrCarrier']['education']) > 0){
			foreach($biographyTextDetails['arrCarrier']['education'] as $edu)
						$eduText .= $edu.", ";
			?>
			<li><span>Studied in <?php echo trim($eduText," ,");?></span></li>
			<?php } ?>
			
			<?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 0 ){?>
			<li><span><?php echo $biographyTextDetails['arrCarrier']['affiliations']['university_name'];?> <?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 0){?> and <?php echo $biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'];?> other <?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 1){?>affiliations<?php }else{echo "affiliation";}}?></span></li>
			<?php }else if($biographyTextDetails['arrCarrier']['affiliations']['university_name'] != ''){ ?>
			<li><span> Affiliated with <?php echo $biographyTextDetails['arrCarrier']['affiliations']['university_name']; ?></span></li>
			<?php } ?>
			<?php //pr($biographyTextDetails['speakerEvents']); 
				if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 0){?>
				<li><span>Speaker in <?php if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 1){ echo $biographyTextDetails['arrCarrier']['speaker_events']['count']." sessions";}else{echo $biographyTextDetails['arrCarrier']['speaker_events']['count']." session";}?> in <?php if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 1){ echo "conferences";}else{echo "conference";}?></span></li>
			<?php }?>
			<?php if($biographyTextDetails['arrCarrier']['publications']['count'] > 0){?>
				<li><span><?php echo $biographyTextDetails['arrCarrier']['publications']['count'];?> <?php if($biographyTextDetails['arrCarrier']['publications']['count'] == 1){echo "Publication";}else{echo "Publications";}?><?php if($biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']>0){ if($biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']>1){echo " with ".$biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']." articles as lead author";}else{echo " with ".$biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']." article as lead author";}}?></span></li>
			<?php }?>
			<?php if($biographyTextDetails['arrCarrier']['trails']['no_of_trails'] > 0){?>
				<li><span>Investigator in <?php if($biographyTextDetails['arrCarrier']['trails']['no_of_trails'] > 1){ echo $biographyTextDetails['arrCarrier']['trails']['no_of_trails']." clinical studies";}else{ echo $biographyTextDetails['arrCarrier']['trails']['no_of_trails']." clinical study"; }?></span></li>
			<?php }?>
			<?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'] > 0){?>
				<li><span><?php echo $biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'];?> <?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'] > 1){ echo "interactions";}else{echo "interaction";}?> entered by <?php echo $biographyTextDetails['arrCarrier']['interactions']['interactions_count']?><?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_count'] > 1){ echo " employees";}else{echo " employee";}?> in last 6 months</span></li>
			<?php }?>
		</ul>
		<div class="topTopics">
			<?php if(count($biographyTextDetails['arrTopics']['topic'])>0){
				foreach ($biographyTextDetails['arrTopics']['topic'] as $event){
						$arrTopThreeEvents[] = '<a onclick="listKOLEvents(\'' .addslashes($event["name"]).'\',\'events\')" >' . $event["name"] . '</a>';
				}
				if(count($arrTopThreeEvents) > 0){
					echo "<label>Top Event Topics: </label><span>".implode($arrTopThreeEvents	," | ")."</span>";
				}
			}?>
				<div style="margin-top:0.4em;">
				<?php 
				if(count($biographyTextDetails['arrTopics']['pub_mesh_terms'])>0){
					foreach ($biographyTextDetails['arrTopics']['pub_mesh_terms'] as $pubTerms){
						$arrTopThreePubTerms[] = '<a class="topLinks" onclick="listKOLEvents(\'' .addslashes($pubTerms["name"]).'\',\'pubs\')" >' . $pubTerms["name"] . '</a>';//$event["name"];
					}
					if(count($arrTopThreePubTerms) > 0){
						echo "<label>Top Publication Topics: </label><span>".implode($arrTopThreePubTerms	," | ")."</span>";
					}
				}
				?>
				</div>
		</div>