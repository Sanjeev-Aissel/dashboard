<?php
/*
 * File which provides form for user to enter new assessment rules
 * @Author		: Laxman K
 * @since 		: KOLM v3.7 Abbott 1.0
 * Created on	: 17-03-2012
 */
//	$queued_js_scripts = array('id_project/process_form');
	// add the JS files into queue i.e Append to the existing queue
//	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

//	pr($arrAsmtCategroies);
//	pr($arrAsmtCriteria);

?>
<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>js/kol_ratings/add_assessment_rules.js"></script>
<style type="text/css">
	#assessment select{
		width:242px;
	}
	.asmtOrderNumber{
		width: 65px;
	}
	#tabs ul{
		margin:0px;
	}
	#tabs ul li{
		list-style: none;
		float:left;
		width:100px;
		border:1px solid #000;
		text-align: center;
		cursor: pointer;
		background-color: #CFCFCF;
	}
	#tabsContents{
		border:1px solid;
		padding-left: 40px;
	}
	.individualTabContent{
		display:none;
		margin-top:20px;
	}
	#newIndividualRecords fieldset{
		padding-top:5px;
		padding-bottom:5px;
	}
	.individualTabContent .title{
		float: left;
	    margin: 8px;
	    width: 155px;
	}
	#tabs ul li:hover, .activeTab{
		background-color: #2E6E9E !important;
		color: #fff;
	}
</style>
<div id="newIndividualRecords">
	<fieldset>
		<legend>Add New ( <a href="#" class="expandTabs" id="toggleTabs">Collapse</a> )</legend>
		<div id="tabsContainer">
			<div id="tabs">
				<ul>
					<li name="newAsmtCat">Category</li>
					<li name="newAsmtCriteria">Criteria</li>
					<li name="newAsmtrating">Rating</li>
				</ul>
			</div>
			<div id="tabsContents">
				<div id="newAsmtCat" class="individualTabContent">
					<div class="title">Enter New Category</div> : <input type="text" name="new_asmt_catname" value="" />
				</div>
				<div id="newAsmtCriteria" class="individualTabContent">
					<div class="title">Enter New Criteria</div> : <input type="text" name="new_asmt_criteria" value="" />
				</div>
				<div id="newAsmtrating" class="individualTabContent">
					<div class="title">Enter New Rating</div> : <input type="text" name="new_asmt_rating" value="" /><br  style="clear: both;" />
					<div class="title">Enter New Rating Score</div> : <input type="text" name="new_asmt_ratingscore" value="" />
				</div>
			</div>
		</div>
	</fieldset>
</div>
<div id="assessment">
	<form id="asmt_rule" name="asmt_rule" action="<?php echo base_url();?>kol_ratings/save_assessment_rules" method="post">
		<fieldset>
			<legend>Add New Assessment</legend>
			<table>
				<tr>
					<td>Enter Name</td><td>:</td><td><input type="text" name="asmt_name" /></td>
				</tr>
				<tr>
					<td>Select Country</td><td>:</td><td>
						<select name="country">
							<option value="">Select Country</option>
							<?php 
								$defaultcountry	= '';
								foreach($arrCountries as $key=>$value){
									if($value['country_id']=="254"){
										$defaultcountry	= 'selected=selected';
									}else{
										$defaultcountry	= '';
									}
									echo '<option value="'.$value['country_id'].'" '.$defaultcountry.'>'.$value['country_name'].'</option>';
								}
							?>
						</select>
					</td>
				</tr>
			</table>
		</fieldset>
		<div id="asmtRuleList">
			<table class="asmtRuleList">
				<tr style="background:#2E6E9E;color:#fff;">
					<th>Category</th>
					<th>Criteria</th>
					<th>Rating</th>
					<th>Order No.</th>
					<th>Action</th>
				</tr>
				<tr>
					<td>
						<select id="asmt_category" name="asmt_category[]">
							<option value="">Select Category</option>
							<?php 
								foreach($arrAsmtCategroies as $key => $asmtCatRow){
									echo '<option value="'.$asmtCatRow['id'].'">'.$asmtCatRow['name'].'</option>';
								}
							?>
						</select>
					</td>
					<td>
						<select id="asmt_criteria" name="asmt_criteria[]">
							<option value="">Select Criteria</option>
							<?php 
								foreach($arrAsmtCriteria as $key => $asmtCriteriaRow){
									echo '<option value="'.$asmtCriteriaRow['id'].'">'.$asmtCriteriaRow['criteria'].'</option>';
								}
							?>
						</select>
					</td>
					<td>
						<select id="asmt_rating" name="asmt_rating[]">
							<option value="">Select Rating</option>
							<?php 
								foreach($arrAsmtRatings as $key => $asmtRatingsRow){
									echo '<option value="'.$asmtRatingsRow['id'].'">'.$asmtRatingsRow['rating'].' => '.$asmtRatingsRow['rating_score'].'</option>';
								}
							?>
						</select>
					</td>
					<td>
						<input type="text" class="asmtOrderNumber" name="order_no[]" />
					</td>
					<td><input type="button" class="addOneMore" value="+" onclick="addOneMoreRule()" /></td>
				</tr>
			
			</table>
			<input type="button" value="Save" onclick="validateRule()" />
			<input type="button" value="Add New Rule" onclick="addOneMoreRule()" />
		</div>
		<div id="generatedRatingList">
		
		</div>
	</form>
</div>


