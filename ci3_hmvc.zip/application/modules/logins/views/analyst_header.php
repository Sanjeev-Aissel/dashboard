<html>
<head>
<title>Analyst</title>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/analyst_layout.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jquery_validator/css/screen.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<script  type="text/javascript">
var isiPad = false;
</script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/jquery-3.2.1.slim.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jquery_validator/dist/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/i18n/grid.locale-en.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery.jqGrid.min_3.8.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/chosen.jquery.js"></script>
<!-- (commented due custom validation in other jquery validate)script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/jquery.validate1.9.min.js"></script> -->
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/chosen.jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>datepicker/js/daterangepicker.jQuery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>datepicker/js/date.js"></script>
<style>
		
#snackbar {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left:85%;
    bottom:100px;
    font-size: 17px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom:100px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 100px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom:100px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom:100px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
</style>
<script>
var base_url = "<?php echo base_url(); ?>";
var paginationValues		= new Array();
<?php 
	$paginationValues	= explode(',',PAGINATION_VALUES);
	foreach($paginationValues as $key=>$value){
?>
	paginationValues.push('<?php echo $value;?>');
<?php
	}
?>
/* function data_type_indicator(dataTypeIndicator){	
	$UserAdded=0;		
	if(dataTypeIndicator == '' || dataTypeIndicator == 'Legacy'){
		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Legacy Data' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>L</a></div>";
	}else if(dataTypeIndicator == 'User Added'){
		//return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>U</a></div>";
		return '';
	}else if(dataTypeIndicator == 'Aissel Analyst'){
		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: Aissel Analyst' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>A</a></div>";
	}	
} */
function data_type_indicator(dataTypeIndicator){	
	$UserAdded=0;		
	if(dataTypeIndicator == '' || dataTypeIndicator == 'Legacy'){
    	return '<span class="badge" title="Legacy Data">L</span>';
	}else if(dataTypeIndicator == 'User Added'){
		return '';
	}else if(dataTypeIndicator == 'Aissel Analyst'){
    	return '<span class="badge" title="Added by: Aissel Analyst">A</span>';
	}	
}
</script>
</head>
<body>
<?php
if(isset($showNavBar))
{
 echo $this->load->view('analyst_navbar');
}
echo $this->load->view($contentPage);
?>
<div id="snackbar"></div>
  <!-- Modal -->
  <div class="modal fade" id="analystModelBox" role="dialog">
    <div id="modal-box" class="modal-dialog">
      <!-- Modal content-->
      <div id="content" class="modal-content">
        <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body"></div>
      </div>
    </div>
  </div>
<script>
function myFunction(text) {
    var x = document.getElementById("snackbar");
    $( "#snackbar" ).text(text);
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
</script>