<?php
/**
 * File to 'view' Organization Social media details
 *
 * @author: Ramesh B
 * @created on: 13 may 2013
 */

?>
<style>
	#orgSocialMedia > div{
		border: 5px solid #EEEEEE;
	    float: left;
	    margin-bottom: 11px;
	    margin-left: 5px;
	    width: 383px;
	}
	#orgSocialMedia > div > label{
		float:left;
	}
	#orgSocialMedia > div > h5{
		margin-bottom:5px;
		font-size:16px;
	}
	#orgSocialMedia > div > ul{
		border-top: 1px solid #EBEBEB;
	    list-style: none outside none;
	    margin-left: 20px;
    	margin-right: 20px;
	    padding-left: 0;
	    height: 500px;
	    overflow-y: scroll;
	}
	#orgSocialMedia > div > ul li{
		border-bottom: 1px solid #EBEBEB;
		overflow:hidden;
		position: relative;
		min-height: 50px;
		padding-bottom: 32px;
    	padding-top: 7px;
	}
	
	#orgSocialMedia > div > ul li:HOVER{
		background-color:#eeeeee;
	}
	#orgSocialMedia > div > ul li > p{
		margin-bottom:0px;
		overflow: hidden;
	}
	#orgSocialMedia span.human-time{
		bottom: 10px;
	    color: green;
	    float: right;
	    position: absolute;
	    right: 0;
	}
	#latest-facebook-updates li .storylink{
	    display: block;
	    padding-bottom: 5px;
	}
	#latest-facebook-updates li .storylink a{
		color: #3B5998;
		font-size: 11px;
		font-weight: bold;
	}
	#latest-facebook-updates li > div img{
		float: left;
	    margin-right: 5px;
	   	width: 130px;
	   	cursor:pointer;
	}
	#latest-facebook-updates li >div p{
		margin-bottom:0px;
	}
	#orgSocialMedia > div > ul li > div{
		overflow: hidden;
	}
	.additinal-links{
		bottom: 10px;
	    left: 0;
	    position: absolute;
	    width: 100%;
	}
	.sharesIcon {
	   	background-image: url("<?php echo base_url()?>images/fb-shares.png");
	    background-position: -4px -3px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 13px;
	    margin-bottom: -2px;
	    margin-left: 5px;
	    width: 12px;
	}
	.commentsIcon {
	    background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -14px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 16px;
	    width: 16px;
	}
	.likesIcon {
	   	background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -53px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 12px;
	    width: 14px;
	}
	#latest-youtube-updates ul{
		margin-left: 10px !important;
    	margin-right: 10px !important;
	}
	#latest-youtube-updates li{
		margin-bottom: 10px;
    	padding-bottom: 20px !important;
	}
	#fbImageContainer{
		text-align: center;
	}
	#latest-youtube-updates li a{
		font-weight:bold;
	}
	div.mediaIcon {
	    margin-left: 6px;
    	margin-right: 2px;
	}
	#latest-youtube-updates div.mediaIcon{
		margin-left: 10px;
	}
	#latest-youtube-updates ul li img{
		cursor: pointer;
	}
	#latest-youtube-updates ul li img{
		opacity:0.7;
		margin: 28px auto auto 42px;
	}
	#latest-youtube-updates ul li img:HOVER{
		opacity:1;
	}
/*	.ui-widget-overlay {
	    background: url("images/ui-bg_flat_0_aaaaaa_40x100.png") repeat-x scroll 50% 50% #000000;
	    opacity: 0.75;
	}*/
	.start-from{
		display:none;
	}
	.load-more {
	    color: mediumturquoise;
	    cursor: pointer;
	    font-weight: bold;
	    margin-top: -15px;
	    padding-bottom: 4px;
	    text-align: center;
	}
	#latest-facebook-updates .additinal-links a{
		display: block;
	    height: 100%;
	    width: 100%;
	}
	#latest-youtube-updates{
		width:100% !important;
	}
	#latest-youtube-updates li .video-thumb{
		height: 111px;
	    width: 160px;
	    float:left;
	    margin-right: 5px;
	    background-size: 149px auto; 
	    background-repeat: no-repeat;
	}
	#latest-youtube-updates li a{
		color: #3B5998 !important;
	}
	#latest-youtube-updates .additinal-links{
		margin-left: 165px;
	}
	#latest-youtube-updates .additinal-links a{
		color: green !important;
	    font-size: 11px;
	    font-weight: normal;
	    text-decoration: none;
	}
	#latest-youtube-updates p.author{
		font-style: italic;
	}
	#latest-youtube-updates li .duration{
		background-color: black;
	    color: white;
	    left: 2px;
	    position: absolute;
	}
	div.loading{
		background-image: url("../../../images/ajax-loader-4.gif");
	    background-position: center center;
	    background-repeat: no-repeat;
	}
/*	.microView {
		padding:0px !important;
		border-radius:0px !important;
	}*/
	#fbImageContainer{
		padding:0px !important;
	}
/*	.ui-dialog{
		padding:0px !important;
	}*/
	#fbImageContainer object{
		display: block;
    	overflow: hidden;
	}
	.ui-dialog .ui-dialog-titlebar-close {
		width:17px !important;
	}
	div.facebookIcon {
	    background-position: -140px -88px;
	}
	div.youtubeIcon {
	    background-position: -248px -89px;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		var fbImageOptions = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 'auto',
				draggable:false,
				position: ['center', 'center'],
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				},
				close:function(){
					$("#fbImageContainer").dialog('option','width','auto');
					$("#fbImageContainer").dialog('option','position',['center', 'center']);
				}
			};
		$('#fbImageContainer').dialog(fbImageOptions);


		$("#latest-facebook-updates div > .fb-image").live("click",function(){
			var imgSrc = $(this).attr('src');
			imgSrc = imgSrc.replace("_s","_n"); 
			$("#fbImageContainer").dialog('option','width',750);
			$("#fbImageContainer").dialog('option','position',['center', 20]);
			$("#fbImageContainer").html('<div width="750px">&nbsp;.<img width="750px" alt="" src="'+imgSrc+'"></div>');
			$("#fbImageContainer").dialog("open");
		});

		$("#latest-youtube-updates ul li .video-thumb").live("click",function(){
			var videoSrc = $(this).attr('vsrc');
			var embedHtml = ' <object width="550" height="375">';
				embedHtml +='	<param name="movie" value="'+videoSrc+'"</param>';
				embedHtml +='	<param name="allowFullScreen" value="true"></param>';
				embedHtml +='	<param name="allowScriptAccess" value="always"></param>';
				embedHtml +='	<embed src="'+videoSrc+'"';
				embedHtml +='		type="application/x-shockwave-flash"';
				embedHtml +='		allowfullscreen="true"';
				embedHtml +='		allowscriptaccess="always"';
				embedHtml +='		wmode="opaque"';
				embedHtml +='		width="550" height="375">';
				embedHtml +='	</embed>';
				embedHtml +='</object>';
			$("#fbImageContainer").html(embedHtml);
			$("#fbImageContainer").dialog("open");
		});

		$(".ui-widget-overlay").live("click",function(){
			$(".ui-icon-closethick").click();
		});

		//Load more updates
		$(".load-more").click(function(){
			var thisEle = $(this);
			var categoryId 	= $(this).parent().attr("id");
			var mediaSection= $(this).parent().children("h5").children("a").html();
			var mediaUrl	= $(this).parent().children("h5").children("a").attr('href');
			var startFrom	= $(this).parent().children("ul").children(".start-from").last().html();
			var data = {};
			data['mediaSection']= mediaSection;
			data['mediaUrl'] 	= mediaUrl;
			data['startFrom'] 	= startFrom;
			//Show loading indicator
			$(thisEle).addClass("loading");
			$.ajax({
				type: "post",
				dataType:"text",
				data:data,
				url: base_url+'organizations/load_more_media_updates/',
				success: function(returdData){
					$("#"+categoryId+" ul").append(returdData);
					//hide loading indicator
					$(thisEle).toggleClass("loading");
				}
			});
		});

		$('#orgSocialMedia ul').bind('scroll', function(){
	        if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight){
		        if(!$(this).next().hasClass("loading"))
	       			$(this).next().click();
	        }
		});
                
	});
</script>
<div id="orgSocialMedia">
	<?php if($arrOrganization['facebook'] != ''){?>
		<div id="latest-facebook-updates">
			<label for="orgBlog"><div class="mediaIcon facebookIcon"></div></label>
			<h5><a href="<?php echo $arrOrganization['facebook'];?>" target="_new">Facebook</a></h5>
			<ul>
			<?php 
				$data['mediaUrl'] = $arrOrganization['facebook'];
				$this->load->view("media/facebook_updates",$data);
			?>
			</ul>
			<div class="load-more">&nbsp;</div>
		</div>	
	<?php }?>
		
	<?php if($arrOrganization['twitter'] != ''){?>
	<div id="latest-twitter-updates">
		<label for="orgBlog"><div class="mediaIcon twitterIcon"></div></label>
		<h5><a href="<?php echo $arrOrganization['twitter'];?>" target="_new">Twitter</a> </h5>
		<ul>
			<?php 
				$data['mediaUrl'] = $arrOrganization['twitter'];
				$this->load->view("media/twitter_updates",$data);
			?>
		</ul>
		<div class="load-more">&nbsp;</div>
	</div>
	<?php }?>
	
	
	<?php if($arrOrganization['youtube'] != ''){?>
	<div id="latest-youtube-updates">
		<label for="orgBlog"><div class="mediaIcon youtubeIcon"></div></label>
		<h5><a href="<?php echo $arrOrganization['youtube'];?>" target="_new">YOuTube</a></h5>
		<ul>
			<?php 
				$data['mediaUrl'] = $arrOrganization['youtube'];
				$this->load->view("media/youtube_updates",$data);
			?>
		</ul>
		<div class="load-more">&nbsp;</div>
	</div>
	<?php }?>
	
	<!-- 
	<div id="latest-linkedin-updates">
		<label for="orgBlog"><div class="mediaIcon linkedinIcon"></div></label>
		<a href="<?php echo $arrOrganization['linkedin'];?>" target="_new"><?php echo $arrOrganization['linkedin'];?></a>
	</div>
	<div id="latest-blog-updates">
		<label for="orgBlog"><div class="mediaIcon blogIcon"></div></label>
		<a href="<?php echo $arrOrganization['blog'];?>" target="_new"><?php echo $arrOrganization['blog'];?></a>
	</div>
	 
	 <div>
	 	<div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=386692868111818";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>
	 	<div class="fb-like-box" data-href="<?php echo $arrOrganization['facebook'];?>" data-width="365" data-show-faces="true" data-stream="true" data-show-border="true" data-header="true"></div>
	 </div>
	
	 
	 <div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=386692868111818";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	
	<div class="fb-comments" data-href="http://www.facebook.com/photo.php?fbid=10151522044924713&amp;set=a.311417424712.146304.44705824712&amp;type=1&amp;relevant_count=1" data-width="470" data-num-posts="10"></div>
	  -->
	<div id="fbImageContainer">
	
	</div>
</div>
<!-- End of orgSocialMedia Div -->