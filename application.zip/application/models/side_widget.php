<?php
/**
 * 
 * @author Laxman K
 * @since KOLM CORE v6.0.6
 * @created on 27 DEC 2013
 * 
 */
class Side_widget extends Model{
//	Constructor
	function Side_widget(){
		parent::Model();
	}
	function getKolsOfSimilarTrials($kolId,$limit=10,$startFrom=0){
		$arrKols	= array();
		$arrSalutations				= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$query	= 'SELECT DISTINCT kols.id,kols.first_name,kols.middle_name,kols.last_name, kols.status,kols.salutation FROM kols 
					LEFT JOIN kol_clinical_trials ON kol_clinical_trials.kol_id=kols.id
					WHERE kol_clinical_trials.cts_id IN (
						SELECT DISTINCT (ct_keywords.cts_id) FROM ct_keywords
						LEFT JOIN cts_keywords ON cts_keywords.id=ct_keywords.keyword_id
						WHERE ct_keywords.keyword_id IN (
								SELECT DISTINCT (ct_keywords.keyword_id) FROM cts_keywords
								LEFT JOIN ct_keywords ON ct_keywords.keyword_id=cts_keywords.id
								WHERE ct_keywords.cts_id IN (SELECT DISTINCT (kol_clinical_trials.cts_id) FROM kol_clinical_trials WHERE kol_clinical_trials.kol_id='.$kolId.')
							)
					)';
		if($limit!=0){
			$query	.= " limit $startFrom, $limit";
		}
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['kol_name']		= $arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$arrKols[$row['id']]	= $row;
		}
		return $arrKols;
	}
	function getTopInvestigatorsWithinOrg($orgId,$limit=10,$startFrom=0){
		$arrInvestigators	= array();
		$query	= 'SELECT DISTINCT cts_investigators.last_name, COUNT(ct_investigators.investigator_id) as count FROM cts_investigators
					LEFT JOIN ct_investigators ON ct_investigators.investigator_id=cts_investigators.id
					WHERE ct_investigators.cts_id IN (SELECT DISTINCT org_clinical_trials.cts_id FROM org_clinical_trials WHERE org_id ='.$orgId.')
					AND cts_investigators.last_name IS NOT NULL
					GROUP BY cts_investigators.last_name order by count desc';
		if($limit!=0){
			$query	.= " limit $startFrom, $limit";
		}
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$arrInvestigators[]	= $row;
		}
		return $arrInvestigators;
	}
	function getOrgNameById($orgId) {
		$this->db->select("name");
		$this->db->where("id",$orgId);
		$query = $this->db->get("organizations");
		foreach ($query->result_array() as $row){
			$orgName = $row['name'];
		}
		return $orgName;
	}
	function getTopKolEventAttendeesWithinOrg($orgId,$limit=10,$startFrom=0){
		$arrKols	= array();
		$arrSalutations				= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$orgName	= $this->getOrgNameById($orgId);
		$query	= "SELECT kols.id, kols.first_name, kols.middle_name,kols.last_name,kols.status,kols.salutation,COUNT(kol_events.kol_id) as count FROM kol_events
					LEFT JOIN kols ON kols.id=kol_events.kol_id
					WHERE kol_events.event_id IN (SELECT DISTINCT kol_events.event_id FROM kol_events WHERE kol_events.organizer = '".$orgName."')
					GROUP BY kol_events.kol_id
					ORDER BY COUNT DESC";
		if($limit!=0){
			$query	.= " limit $startFrom, $limit";
		}
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['kol_name']		= $arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$arrKols[$row['id']]	= $row;
		}
		return $arrKols;
	}
	function getTopSimilarAffiliatedKols($kolId,$limit=10,$startFrom=0){
		$arrKols	= array();
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$query	= "SELECT DISTINCT kols.id,kols.first_name, kols.middle_name,kols.last_name,kols.status,kols.salutation, COUNT(kol_memberships.kol_id) AS count FROM kol_memberships
					LEFT JOIN kols ON kols.id=kol_memberships.kol_id 
					WHERE kol_memberships.kol_id!=".$kolId."
					AND kol_memberships.institute_id IN (SELECT DISTINCT kol_memberships.institute_id FROM kol_memberships WHERE kol_id=".$kolId.")
					AND kol_memberships.department IN (SELECT DISTINCT kol_memberships.department FROM kol_memberships WHERE kol_id=".$kolId.")
					GROUP BY kol_memberships.kol_id
					ORDER BY COUNT desc";
		if($limit!=0){
			$query	.= " limit $startFrom, $limit";
		}
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['kol_name']		= $arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$arrKols[$row['id']]	= $row;
		}
		return $arrKols;
	}
	function getPublicationsOfOrg($orgId){
		$arrPubIds	= array();
		$this->db->distinct();
		$this->db->select('org_publications.pub_id as pub_ids');
		$this->db->where('org_publications.org_id',$orgId);
		$resultSet	= $this->db->get('org_publications');
		foreach($resultSet->result_array() as $row){
			$arrPubIds[]	= $row['pub_ids'];
		}
		return $arrPubIds;
	}
	function getMeshTermIdsOfPublications($arrPubIds){
		$arrTermIds	= array();
		$this->db->distinct();
		$this->db->select('publication_mesh_terms.term_id');
		$this->db->where_in('publication_mesh_terms.pub_id',$arrPubIds);
		$resultSet	= $this->db->get('publication_mesh_terms');
		foreach($resultSet->result_array() as $row){
			$arrTermIds[]	= $row['term_id'];
		}
		return $arrTermIds;
	}
	function getPubIdsFromMeshTermIds($arrTermIds){
		$arrPubIds	= array();
		$this->db->distinct();
		$this->db->select('publication_mesh_terms.pub_id as pub_ids');
		$this->db->where_in('publication_mesh_terms.term_id',$arrTermIds);
		$resultSet	= $this->db->get('publication_mesh_terms');
		foreach($resultSet->result_array() as $row){
			$arrPubIds[]	= $row['pub_ids'];
		}
		return $arrPubIds;
	}
	function getSimilarOrgsBasedOnPublications($orgId,$limit=10,$startFrom=0){
		ini_set("max_execution_time",0);
		ini_set('memory_limit', '-1');
		$arrOrgs	= array();
		$arrPubIdsFromTerms	= array();
		$arrPubIds	= $this->getPublicationsOfOrg($orgId);
		if(sizeof($arrPubIds)>1){
			$arrTermIds	= $this->getMeshTermIdsOfPublications($arrPubIds);
			$arrPubIdsFromTerms	= $this->getPubIdsFromMeshTermIds($arrTermIds);
			$this->db->distinct();
			$this->db->select('organizations.id,organizations.name,organizations.status');
			$this->db->join('organizations','organizations.id=org_publications.org_id','left');
			$this->db->where('organizations.id !=',$orgId);
			$this->db->where_in('org_publications.pub_id',$arrPubIdsFromTerms);
			if($limit!=0){
				$this->db->limit($limit,$startFrom);
			}
			$resultSet	= $this->db->get('org_publications');
			foreach($resultSet->result_array() as $row){
				$arrOrgs[$row['id']]	= $row;
			}
		}
		return $arrOrgs;
	}
	function getSimilarKols($kolId,$limit=10,$startFrom=0){
		$arrKols	= array();
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$query	= "SELECT DISTINCT kols.id,kols.first_name, kols.middle_name,kols.last_name,kols.status,kols.salutation FROM kols as kol
					LEFT JOIN kols AS kols ON kols.specialty=kol.specialty
					WHERE kol.id=".$kolId."
					AND (kols.title=kol.title OR kols.division=kol.division)
					AND kols.id != ".$kolId."
					AND kols.status ='Completed'
					GROUP BY kols.id";
		if($limit!=0){
			$query	.= " limit $startFrom, $limit";
		}
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['kol_name']		= $arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$arrKols[$row['id']]	= $row;
		}
		return $arrKols;
	}
}