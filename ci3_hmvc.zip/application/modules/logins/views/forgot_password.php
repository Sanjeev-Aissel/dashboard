<script src="<?php echo base_url().MODULES_ASSETS;?>logins/js/logins.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>logins/css/logins.css" rel="stylesheet">
<div class="container">    
	<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">                    
		<div class="panel panel-info" >
			<div class="panel-heading">
				<div class="panel-title">Forgot Password</div>
			</div>    
			<div style="padding-top:30px" class="panel-body" >
				<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
				<div id="response_message"></div>
				<form action="" method="post" class="validateForm" id="forgot_password_form" class="form-horizontal">
					<div class="form-group">
						<span id = 'infoMsg'></span>
						<label for="name" class="cols-sm-2 control-label">Email ID <font size='3' color='#F00'><b>*</b></font></label>
						<div class="cols-sm-10">
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
								<input type="text" class="form-control" name="email" id="email" value="soumyas@aissel.com" placeholder="Enter your email" autocomplete="off"/>
							</div>
						</div>
					</div>
					<div class="form-group" id="show_loader" style="text-align:center;display:none">
						<img src="<?php echo base_url().ASSETS;?>/images/ajax-loader.gif"></img>
					</div>
					<div class="form-group">
						<button type="button" style="width: 49%; display:inline-block;" onclick="forgotPasswordFn();" class="btn btn-primary btn-sm">SUBMIT</button>
						<button type="button" style="width: 49%; display:inline-block;" onclick="goToUrl(base_url+'logins/logins');" class="btn btn-danger btn-sm">CANCEL</button>
					</div>
				</form>     
			</div>    
		</div>  
	</div> 
</div>
<script>
var base_url = '<?php echo base_url(); ?>';
var validationRules	=  {
		email: {
		 required:true,
		 email: true
     }
};
var validationMessages = {
		email: {
		required:"Enter email-address",
		email:"Enter valid Email-address"
	}
};
$(document).ready(function(){
	$("#forgot_password_form").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>