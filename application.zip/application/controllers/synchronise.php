<?php
/*
 * Controlle to synchronise DB with KOLM App 
 *  
 * @Author		: Laxman K
 * @since 		: Otsuka v1.0.7
 * Created on	: 03-12-2012
 *  
 */
class Synchronise extends Controller{
	private $loggedUserId	= null;
	public $arrDbconfigData	= null;
	public $syncConnId		= null;
	public $dbSyncObj		= null;
	
	// constructor to initialize the data
	function Synchronise(){
		parent::Controller();
		$this->load->model('Sync');
		$this->load->model('common_helpers');
		$this->load->model('client_user');
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}
	function index(){
		$this->common_helpers->checkUsers();
		$this->options();
	}
	function testconnection(){
		$status	= false;
		$this->common_helpers->checkUsers();
		if($this->session->userdata('client_id') == INTERNAL_CLIENT_ID){
			$status	= true;
			$msg	= 'Valid Aissel User<br />';
		}
		$arrResult	= array('msg'=>$msg,'status'=>$status);
		echo json_encode($arrResult);
	}
	function process($kolId=''){
		if(empty($kolId)){
			$kolId	= trim($this->input->post('kolId'));
		}
		$arrKolData	= $this->Sync->getCompleteKOLData($kolId);
		$this->Sync->syncCompleteKOLData($arrKolData);
		echo '<div id="returnData">'.$kolId.'</div>';
	}
	function prepare_json($arrKols){
		$arrkolIds	= explode(',',$arrKols);
		foreach($arrkolIds as $key=>$kolId){
			$arrKolData[$kolId]	= $this->Sync->getCompleteKOLData($kolId);
		}
		$fileName	= 'syncKOLs_'.date("Y-m-d_H-i-s").'.txt';
		$this->load->helper('download');
		$data		= json_encode($arrKolData);
		$data		= preg_replace('/\\\u([0-9a-z]{4})/', '&#x$1;', $data);
		force_download($fileName, $data);
	}
	function options(){
		$this->load->model('kol');
		$data['arrSalutation']	= array(0=>'',1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrKols']		= $this->kol->getKolNames();
		$data['contentPage']	= 'synchronise/sync_options';
		$this->load->view('layouts/analyst_view', $data);
	}
	function syncform(){
		$this->load->view('synchronise/syncform', $data);
	}
	function list_syncs(){
		$this->common_helpers->checkUsers();
		$this->load->helper('directory');
		$arrSyncFiles = directory_map($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/sync_data", 1);
		$data['arrSyncFiles']	= $arrSyncFiles;
		$data['contentPage']	= 'synchronise/list_syncs';
		$this->load->view('layouts/analyst_view', $data);
	}
	function update_db($fileName=''){
		ini_set("max_execution_time",0);
		$msg	= '';
		if(empty($fileName)){
			$fileName	= trim($this->input->post('filename'));
		}
		$data		= utf8_decode(file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/sync_data/".$fileName));
		$arrKolsData= json_decode($data, true);
		foreach($arrKolsData as $kolId=>$arrKolData){
			$currentKolId	= 0;
			foreach($arrKolData['kols'] as $kolId => $arrRow){
				$currentKolId	= $this->Sync->saveOrUpdateKol($arrRow);
				$msg .=  '<div><strong>Updated kol Id '.$kolId.'(Source machine) with '.$currentKolId.'(Destinated machine)</strong></div>';
			}
			if($currentKolId!=0 && $currentKolId){
				$msg .=  '<div><strong>KOL Education count = '.sizeof($arrKolData['kol_educations']).'</strong></div>';
				foreach($arrKolData['kol_educations'] as $eduId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateKolEdu($arrRow)){
						$msg .=  'Updated KOL Education ('.$arrRow['id'].') - '.$arrRow['institution_name'].'<br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Education ('.$arrRow['id'].') - '.$arrRow['institution_name'].'</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Profile Score</strong></div>';
				foreach($arrKolData['kol_activities_count'] as $activityId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateKolProfileScore($arrRow)){
						$msg .=  'Updated KOL Profile Score <br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Profile Score</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Additional Contacts count = '.sizeof($arrKolData['kol_additional_contacts']).'</strong></div>';
				$flag	= false;
				foreach($arrKolData['kol_additional_contacts'] as $additionalCotactsId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateKolAdditionalContacts($arrRow)){
						if(!$flag)$msg .=  'Updated KOL Additional Contacts <br />';
					}else{
						if(!$flag)$msg .=  '<span style="color:red;">Unable to Update KOL Additional Contacts</span><br />';
					}
					$flag	= true;
				}
				$msg .=  '<div><strong>KOL Personal Info</strong></div>';
				foreach($arrKolData['kol_personal_info'] as $personalInfoId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateKolPersonalInfo($arrRow)){
						$msg .=  'Updated KOL Personal Info <br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Personal Info</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Affiliation count = '.sizeof($arrKolData['kol_memberships']).'</strong></div>';
				foreach($arrKolData['kol_memberships'] as $membershipId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateKolMemberships($arrRow)){
						$msg .=  'Updated KOL Affiliation ('.$arrRow['id'].') - '.$arrRow['institution_name'].'<br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Affiliation ('.$arrRow['id'].') - '.$arrRow['institution_name'].'</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Events count = '.sizeof($arrKolData['kol_events']).'</strong></div>';
				foreach($arrKolData['kol_events'] as $eventId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					if($this->Sync->saveOrUpdateEvents($arrRow)){
						$msg .=  'Updated KOL Event ('.$arrRow['id'].') - '.$arrRow['event_name'].'<br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Event ('.$arrRow['id'].') - '.$arrRow['event_name'].'</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Clinical Trials count = '.sizeof($arrKolData['kol_clinical_trials']).'</strong></div>';
				foreach($arrKolData['kol_clinical_trials'] as $trialId => $arrRow){
					$arrRow['kol_id']	= $currentKolId;
					$ctId	= $this->Sync->saveOrUpdateTrials($arrRow);
					if($ctId){
						$this->load->model('clinical_trial','clinical_trial');
						foreach($arrKolData['cts_sponsers'][$trialId] as $sponserId => $arrSponserRow){
							unset($arrSponserRow['id']);
							$sponser	= $this->clinical_trial->saveSponser($arrSponserRow);
							if($sponser){
								$arrCtSponsers['cts_id']	= $ctId;
								$arrCtSponsers['sponser_id']	= $sponser;
								$this->clinical_trial->saveCtSponser($arrCtSponsers);
							}
						}
						foreach($arrKolData['cts_interventions'][$trialId] as $id => $arrCtRow){
							unset($arrCtRow['id']);
							$intervention	= $this->clinical_trial->saveIntervention($arrCtRow);
							if($intervention){
								$arrCtIntervention['cts_id']	= $ctId;
								$arrCtIntervention['intervention_id']	= $intervention;
								$this->clinical_trial->saveCtIntervention($arrCtIntervention);
							}
						}
						foreach($arrKolData['cts_investigators'][$trialId] as $id => $arrCtRow){
							unset($arrCtRow['id']);
							$investigators	= $this->clinical_trial->saveInvestigator($arrCtRow);
							if($investigators){
								$arrCtInvestigators['cts_id']	= $ctId;
								$arrCtInvestigators['investigator_id']	= $investigators;
								$this->clinical_trial->saveCtInvestigator($arrCtInvestigators);
							}
						}
						foreach($arrKolData['cts_keywords'][$trialId] as $id => $arrCtRow){
							unset($arrCtRow['id']);
							$keywords	= $this->clinical_trial->saveKeyword($arrCtRow);
							if($keywords){
								$arrCtKeywords['cts_id']	= $ctId;
								$arrCtKeywords['keyword_id']	= $keywords;
								$this->clinical_trial->saveCtKeyword($arrCtKeywords);
							}
						}
						foreach($arrKolData['cts_mesh_terms'][$trialId] as $id => $arrCtRow){
							unset($arrCtRow['id']);
							$meshterm	= $this->clinical_trial->saveMeshterms($arrCtRow);
							if($meshterm){
								$arrCtMeshterm['cts_id']	= $ctId;
								$arrCtMeshterm['term_id']	= $meshterm;
								$this->clinical_trial->saveCtMeshterms($arrCtMeshterm);
							}
						}
						$msg .=  'Updated KOL Clinical Trial ('.$arrRow['ct_id'].') - '.$arrRow['trial_name'].'<br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Clinical Trial ('.$arrRow['ct_id'].') - '.$arrRow['trial_name'].'</span><br />';
					}
				}
				$msg .=  '<div><strong>KOL Publications count = '.sizeof($arrKolData['kol_publications']).'</strong></div>';
				$arrAliasInfo	= array();
				foreach($arrKolData['kol_publications'] as $pubId => $arrRow){
					$arrRow['kol_id']		= $currentKolId;
					$arrRow['is_deleted']	= 0;
					$arrRow['is_verified']	= 1;
					$publicationId	= $this->Sync->saveOrUpdatePubs($arrRow);
					if($publicationId){
						$this->load->model('pubmed','pubmed');
						foreach($arrKolData['pubmed_article_ids'][$pubId] as $id => $arrPubRow){
							unset($arrPubRow['id']);
							$articleId	= $this->pubmed->savePubmedArticleId($arrPubRow);
							if($articleId){
								$arrPubMeshterm['pub_id']			= $publicationId;
								$arrPubMeshterm['pub_article_id']	= $articleId;
								$this->pubmed->savePublicationArticleId($arrPubMeshterm);
							}
						}
						foreach($arrKolData['pubmed_authors'][$pubId] as $id => $arrPubRow){
							$arrPubAuthor['position']		= $arrPubRow['position'];
							$arrPubAliasRow['last_name']	= $arrPubRow['pubalias_lname'];
							$arrPubAliasRow['fore_name']	= $arrPubRow['pubalias_fname'];
							$arrPubAliasRow['initials']		= $arrPubRow['pubalias_initials'];
							unset($arrPubRow['id']);
							unset($arrPubRow['position']);
							unset($arrPubRow['pub_alias_id']);
							unset($arrPubRow['pubalias_lname']);
							unset($arrPubRow['pubalias_fname']);
							unset($arrPubRow['pubalias_initials']);
							$authorId		= $this->pubmed->savePubmedAuthor($arrPubRow);
							$authorAliasId	= $this->pubmed->savePubmedAuthor($arrPubAliasRow);
							$arrPubAuthor['alias_id']	= $authorAliasId;
							if($authorId){
								$arrPubAuthor['pub_id']		= $publicationId;
								$arrPubAuthor['author_id']	= $authorId;
								$this->pubmed->savePublicationAuthor($arrPubAuthor);
							}
						}
						foreach($arrKolData['pubmed_cc'][$pubId] as $id => $arrPubRow){
							unset($arrPubRow['id']);
							$ccId	= $this->pubmed->savePubmedCC($arrPubRow);
							if($ccId){
								$arrPubCC['pub_id']		= $publicationId;
								$arrPubCC['cc_id']		= $ccId;
								$this->pubmed->savePublicationCC($arrPubCC);
							}
						}
						foreach($arrKolData['pubmed_publications_types'][$pubId] as $id => $arrPubRow){
							unset($arrPubRow['id']);
							$typeId	= $this->pubmed->savePubmedPubType($arrPubRow);
							if($typeId){
								$arrPubType['pub_id']		= $publicationId;
								$arrPubType['pub_type_id']	= $typeId;
								$this->pubmed->savePublicationType($arrPubType);
							}
						}
						foreach($arrKolData['pubmed_mesh_terms'][$pubId] as $id => $arrPubRow){
							$parentTermName			= $arrPubRow['parent_term_name'];
							$arrPubTerm['is_major']	= $arrPubRow['is_major'];
							unset($arrPubRow['id']);
							unset($arrPubRow['is_major']);
							unset($arrPubRow['parent_term_name']);
							if($arrPubRow['parent_id']!=0 || !empty($arrPubRow['parent_id'])){
								$arrParentPubRow['term_name']	= $parentTermName;
								$arrParentPubRow['parent_id']	= 0;
								$arrPubRow['parent_id']	= $this->pubmed->savePubmedMeshTerm($arrParentPubRow);
							}
							$termId	= $this->pubmed->savePubmedMeshTerm($arrPubRow);
							if($termId){
								$arrPubTerm['pub_id']	= $publicationId;
								$arrPubTerm['term_id']	= $termId;
								$this->pubmed->savePublicationMeshTerm($arrPubTerm);
							}
						}
						foreach($arrKolData['pubmed_substances'][$pubId] as $id => $arrPubRow){
							unset($arrPubRow['id']);
							$substanceId	= $this->pubmed->savePubmedSubstance($arrPubRow);
							if($substanceId){
								$arrPubSub['pub_id']		= $publicationId;
								$arrPubSub['substance_id']	= $substanceId;
								$this->pubmed->savePublicationSubstance($arrPubSub);
							}
						}
						$msg .=  'Updated KOL Publication (PMID - '.$arrRow['pmid'].') - '.$arrRow['article_title'].'<br />';
					}else{
						$msg .=  '<span style="color:red;">Unable to Update KOL Publication (PMID - '.$arrRow['pmid'].') - '.$arrRow['article_title'].'</span><br />';
					}
				}
			}
			$msg .= '-----------------------------------------------------------------------------------------<br/><br/>';
		}
		if(empty($msg)){
			$msg	 .= '<span style="color:red;">Unable to update</span>';
		}
		$arrData['detailedInfo']	= $msg;
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	function upload(){
		$arrData['contentPage']	= 'synchronise/upload';
		$this->load->view('layouts/analyst_view', $arrData);
	}
	function uploadfile(){
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/sync_data";
		if($_FILES["dbsyncfile"]['name']!=null && $_FILES["dbsyncfile"]['name']!=""){
				//Get the file information, use for file validations like allowed file type, file size etc
				$path_info = pathinfo($_FILES["dbsyncfile"]['name']);
				$path_info['size']=$_FILES["dbsyncfile"]['size'];
				//Generate a randome name
				$newFileName	= $path_info['filename'].'-'.random_string('unique', 20).".".$path_info['extension'];
				$overview_file_target_path = $target_path ."/". $newFileName; 
				//Move uploaded file in to interactions document location
				if (move_uploaded_file($_FILES['dbsyncfile']['tmp_name'], $overview_file_target_path)){
					redirect(base_url().'synchronise/list_syncs');
				}else{
					echo 'Unable to upload file';
				}
		}
	}
	function delete_file(){
		$filename	= $this->input->post('filename');
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/sync_data";
		unlink($target_path.'/'.$filename);
	}
}
?>