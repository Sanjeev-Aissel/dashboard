<?php
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 2,onSelect : function(event, ui) {}";
   $queued_js_scripts = array('index/client_index','jquery/jquery-ui-1.8.16.datepicket');
    $this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />



	<script src="<?php echo base_url()?>js/jquery/jquery.validate1.9.min.js"></script>
<script>
     $("#datepicker1").click(function(){
            $('#datepicker1').datepicker({ dateFormat: 'mm/dd/yy',maxDate:0 });
            $('#datepicker1').datepicker("show");
        });
        
        $('#datepicker1').focus(function(){
            $('table.ui-datepicker-calendar').show();
        });
    $("#back").hide();
    var err=[];
	function save(){
err=[];
$('span').empty();
		if ($('input[name="action"]').val()=='') {
             // at least one of the radio buttons was checked
              $("#acErr").append(" &nbsp;&nbsp;Please select program topic ");
             err.push(8);
         }
         if (!($('input[name="speaker_stay"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#ssErr").append(" &nbsp;&nbsp;Please select speaker_stay ");
             err.push(9);
         }
         if (!($('input[name="saftey_info"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#siErr").append(" &nbsp;&nbsp;Please select saftey_info ");
             err.push(10);
         }
         if (!($('input[name="mirf"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#miErr").append(" &nbsp;&nbsp;Please select mirf ");
             err.push(11);
         }
         if (!($('input[name="adverse_event"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#aeErr").append(" &nbsp;&nbsp;Please select adverse event ");
             err.push(12);
         }
         if (!($('input[name="adverse_event_report"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#aerErr").append(" &nbsp;&nbsp;Please select adverse event report ");
             err.push(13);
         }
         if (!($('input[name="speaker_articulation"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#saErr").append(" &nbsp;&nbsp;Please select speaker articulation ");
             err.push(14);
         }
        
          if (!($('input[name="topic_presented"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#tpErr").append(" &nbsp;&nbsp;Please select topic presented  ");
             err.push(7);
         }
           if (!($('input[name="mirf_doc"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#mdErr").append(" &nbsp;&nbsp;Please select mirf doc ");
             err.push(16);
         }
         
           if (!($('input[name="guideline"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#guErr").append(" &nbsp;&nbsp;Please select guideline ");
             err.push(17);
         }
         
           if (!($('input[name="scale"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#scErr").append(" &nbsp;&nbsp;Please select scale ");
             err.push(18);
         }
         
           if (!($('input[name="msl_follow_up"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#mfErr").append(" &nbsp;&nbsp;Please select msl follow up ");
             err.push(19);
         }
          if(err.length>2){
             
             return false;
         }
        
		
	$.ajax({
		url:'<?php echo base_url()?>speaker_evaluations/save_evaluation/'+kolId,
		data:$('#speakerForm').serialize(),
		type:'post',
		success:function(returnData){
			//alert("Data saved");
			document.location.reload(true);
			//$('#interactionsContainer').show();
			//$('#addInteractionContainer').hide();

		}
	});
}

	function  hideQuestion(className){
		
		$('.questDetail').hide();
		$('.'+className).show();
	}

function showNext(){
     err=[];
     $('#speakerForm span').empty();
      $('.manidatory').append('*');
	$('.test').each(function(key,value){
		//alert($(this).is(':checked'));
	});
	if(!$("#speakerForm").validate().form()){
            
            err.push(0);
		
	}

        if (!($('input[name="evaluator"]:checked').length)) {
             // at least one of the radio buttons was checked
         
             $("#evErr").append(" &nbsp;&nbsp;Please select evaluator");
             err.push(1);
        }
         if (!($('input[name="speaker_detail"]:checked').length)) {
             // at least one of the radio buttons was checked
            $("#spErr").append(" &nbsp;&nbsp;Please select speaker");
             err.push(2);
        }
        if(!($("[name='speaker_background[]']:checked").length > 0))
           {
             // at least one of the radio buttons was checked
                $("#sbErr").append(" &nbsp;&nbsp;Please select speaker background");
             err.push(3);
         }

         if (!($('input[name="venu_presentation"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#vpErr").append(" &nbsp;&nbsp;Please select venu presentation ");
             err.push(5);
         }
         if (!($('input[name="audio_setup"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#auErr").append(" &nbsp;&nbsp;Please select audio setup ");
             err.push(6);
         }
         if (!($('input[name="venu"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#veErr").append(" &nbsp;&nbsp;Please select venu ");
             err.push(19);
         }
          if (!($('input[name="program_topic"]:checked').length)) {
             // at least one of the radio buttons was checked
              $("#ptErr").append(" &nbsp;&nbsp;Please select program topic ");
             err.push(15);
         }

          if (($('input[name="program_date"]') != '')) {
  			var value = $('input[name="program_date"]').val(); 
  			 var curDate = new Date();
               curDate.setHours(00);
               curDate.setMinutes(00);
               curDate.setSeconds(00);
               var inputDate = new Date(value);
               if(inputDate.toString() == curDate.toString() || inputDate < curDate){

               }else{
              	 $("#pdErr").append(" &nbsp;&nbsp;Future date not allowed");
              	 err.push(16);
               }
  		}
         
         
         if(err.length>0){
             
             return false;
         }
         else
         {
         $("#back").show();
	$('.firstPageContainer').hide();
        $('.secondPage').show();}
         $("html, body").animate({ scrollTop: 0 }, "slow");
    }
function goBack(){
     $("back").hide();
    	$('.firstPageContainer').show();
        $('.secondPage').hide();
    }
function showOrHideQuestion(value,class1,class2){
	
		if(value=='Yes'){
			
			$('.'+class1).show();
			$('.'+class2).hide();
		}else{
			
			$('.'+class1).hide();
			$('.'+class2).show();
		}
	
}

function hideViewEvaluation(){
	$('#interactionsContainer').show();
	$('#addInteractionContainer').html("");
	$("#addInteractionContainer").hide();
}
function getStatesByCountryId() {
	country_name	= $('#country_id').val();
	countryName	= $('#country_id option:selected').text();
	$('#country_name').val(countryName);
    $("#state_id").val("");
    $("#state_name").val("");
    $("#city_id").val("");
    $("#city_name").val("");
}
var country_name= '254';
var state_name	= '';
	var stateNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names_by_country_id/',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var stateId = $(event).children('.autocompleteStateId').html();
			var selText = $(event).children('.stateName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#state_name').val(selText);
					$('#state_id').val(stateId);
					state_name	= stateId;
				}
			}else{
				$('#state_name').val(selText);
				$('#state_id').val(stateId);
				state_name	= stateId;
			}
		}
	};
	a = $('#state_name').autocomplete(stateNameAutoCompleteOptions);
	var cityNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names_by_state_id_and_country_id/',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var stateId = $(event).children('.autocompleteCityId').html();
			var selText = $(event).children('.cityName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#city_name').val(selText);
					$('#city_id').val(stateId);
				}
			}else{
				$('#city_name').val(selText);
				$('#city_id').val(stateId);
			}
		}
	};
	a = $('#city_name').autocomplete(cityNameAutoCompleteOptions);
	
</script>
<style>
    #speakerForm .ui-datepicker-title{
        color:#fff !important;
    }		
    .formContainer span{
        color:#ff0000;
    }
    
    #speakerForm .ui-datepicker-calendar th{
        color:#fff !important;
    }
#speakerForm .fieldContainer{
	margin-top:2px;
	margin-bottom:20px;
}

#speakerForm .inputFiedConatiner{
	margin-left: 6px;
	margin-top: 10px;
}

#speakerForm input[type="text"], #speakerForm select{
	width:293px;
}

#speakerForm .inputLabel{
    margin-left: 2px;
}
#speakerForm .questionHeading{
	border-bottom: 1px solid #cccccc;
    color: #333333;
    display: block;
    font-weight: bold !important;
    margin-bottom: 5px;
    margin-right: 25px;
    padding: 0 0 5px;
}

#speakerForm label{
	font-weight:normal;
}
.formContainer{
	/*margin-left:17px;*/
}


#speakerForm caption {
    background: transparent url("http://localhost/kolm/images/kolm-sprite-image.png") repeat-x scroll -2px -236px;
}
#speakerForm caption {
    border-left: 1px solid #ddd;
    border-right: 1px solid #ddd;
    color: #2d53af;
    font-weight: bold;
    line-height: 25px;
}

#speakerForm h5.heading {
    background: #d8e5f4 none repeat scroll 0 0;
    color: #2d53af;
    margin-bottom: 2px;
    padding: 5px;
}
.formContainer{
     /*margin-left: 10px;*/
  /*border: 1px solid #ccc;*/
  font-size: 12px;
}
.formContainer div{
	margin: 8px 0;
}
#speakerForm .manidatory{
    color:red;
}
#speakerForm{
	margin-left: 20px;
}

#speakerForm .buttonContainer{
text-align: center; margin-bottom: 8px;
}
#speakerForm .buttonContainer input{
height: 33px;
}
.ratingContent tr:nth-child(2n) {
    background: #eeeeee none repeat scroll 0 0;
    padding: 5px;
}
.ratingContent tr th {
	color: #333333;
	text-align: center;
}
.ratingContent tr td:not(:first-child) {
	color: #333333;
	text-align: center;
}
</style>
<div class="formContainer">
   <div>
    	<button onclick="goBack()" id='back'>Previous Questions</button>
    </div>
    <div id="addFormWrapper">
		<h5 class="heading">Speaker Evaluation</h5>
	</div>
	<form id="speakerForm">
	<div class="firstPageContainer" style="">
		
		<div class="fieldContainer">
                     <label class="questionHeading"><span class='manidatory'>*</span>1. Evaluator</label><span id="evErr"></span>
		<div><label><input type='radio' name="evaluator" value="MSL" class="test" <?php if($userDetails['title'] == "MSL") echo "checked='checked'";?>></input>MSL</label></div>
		<div><label><input type='radio' name="evaluator" value="MSL Director" class="test" <?php if($userDetails['title'] == "MSL Director") echo "checked='checked'";?>></input>MSL Director </label></div>
		<div><label><input type='radio' name="evaluator" value="MML" class="test" <?php if($userDetails['title'] == "MML") echo "checked='checked'";?>></input>MML </label></div>
		<div><label><input type='radio' name="evaluator" value="MML Director" class="test" <?php if($userDetails['title'] == "MML Director") echo "checked='checked'";?>></input>MML Director </label></div>
		<div class="inputFiedConatiner">
			<label style="display:block" class="inputLabel">Name:(This field is required)</label>
			<input readonly="readonly" type="text" name="evaluator_name" style="font-weight:bold;color: #333333;" value="<?php echo $userDetails['first_name']." ".$userDetails['last_name']?>" class="required inputField"></input>
		</div>
	
	</div>
	
		<div class="fieldContainer">
			<label class="questionHeading"><span class='manidatory'>*</span>2. Program Date</label>
			<div>
				<label>Date of Program</label>
				<input type="text" name="program_date" id="datepicker1" class="inputField required" style="width:207px;"></input>
				<span id="pdErr"></span>
			</div>
		</div>
		
		<div class="fieldContainer">
		<label class="questionHeading"><span class='manidatory'>*</span>3. Number of Attendees</label>
		<div>
		
			<input type="text" name="no_of_attendees" value="" class="required number"></input>
		
		</div>
		</div>
		<div class="fieldContainer">
			<label class="questionHeading"><span class='manidatory'>*</span>4. Speaker Details</label><span id="spErr"></span>
			<div><label><input type='radio' name="speaker_detail" value="MSL Speaker"></input>MSL Speaker </label></div>
			<div><label><input type='radio' name="speaker_detail" value="External Speaker"></input>External Speaker </label></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="inputLabel">Speaker Name: (This field is required)</label>
				<input readonly="readonly" type="text" name="speaker_name" style="font-weight:bold;color: #333333;" value="<?php echo $this->common_helpers->get_name_format($arrKolDetail['first_name'],$arrKolDetail['middle_name'],$arrKolDetail['last_name']); ?>" class="required inputField"></input>
			</div>
		</div>
		<div class="fieldContainer" id="speaker_background">
                    <label class="questionHeading"><span class='manidatory'>*</span> 5. Speaker background: </label><span id="sbErr"></span>
			<div><label><input type='checkbox' name="speaker_background[]" value="Academic"></input>Academic </label></div>
			<div><label><input type='checkbox' name="speaker_background[]" value="Private Practice/Office"></input>Private Practice/Office </label></div>
			<div><label><input type='checkbox' name="speaker_background[]" value="Hospital/Inpatient"></input>Hospital/Inpatient </label></div>
			<div><label><input type='checkbox' name="speaker_background[]" value="Community Clinic/Outpatient"></input>Community Clinic/Outpatient </label></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="inputLabel">Other (please specify): </label>
				<input type="text" name="speaker_text" value="" class="inputField"></input>
			</div>
		</div>
		<div class="fieldContainer">
			
			<label class="questionHeading">6. Was this a co-moderated program?</label>
			<div><label><input type='radio' name="moderated_program" value="yes"></input>Yes </label></div>
			<div><label><input type='radio' name="moderated_program" value="no"></input>No </label></div>
		</div>
		<div class="fieldContainer">
		
		<label class="questionHeading"><span class='manidatory'>*</span>7. Venue</label><span id="veErr"></span>
		<div><label><input type='radio' name="venu" value="In Office"></input>In Office </label></div>
		<div><label><input type='radio' name="venu" value="Out of Office"></input>Out of Office  </label></div>
		<table>
			<tr>
				<td>
					<div class="inputFiedConatiner">
						<label class="inputLabel">Country: </label>
						<select name="country_id" id="country_id" onchange="getStatesByCountryId();">
							<option value="254">United States</option>
							<option value="43">Canada</option>
						</select>
						<input type="hidden" name="country" id="country_name" value="United States" />
					</div>
				</td>
				<td>
					<div class="inputFiedConatiner">
						<label class="inputLabel">State: </label>
						<input type="hidden" name="state_id" id="state_id" value="" />
						<input type="text" name="state" id="state_name" class="autocompleteInputBox" value="" />
					</div>
				</td>
				<td>
					<div class="inputFiedConatiner">
						<label class="inputLabel">City: </label>
						<input type="text" name="city" id="city_name" class="autocompleteInputBox" value="" />
						<input type="hidden" name="city_id" id="city_id" value="" />
					</div>
				</td>
			</tr>
		</table>
		
		</div>
		<div class="fieldContainer">
		
		<label class="questionHeading"><span class='manidatory'>*</span>8. Was venue appropriate for a promotional educational presentation (low noise level, private room/area, minimal distractions and modest venue)?</label><span id="vpErr"></span>
		<div><label><input type='radio' name="venu_presentation" value="Yes"></input>Yes </label></div>
		<div><label><input type='radio' name="venu_presentation" value="No"></input>No  </label></div>
		<div class="inputFiedConatiner">
			<label style="display:block" class="inputLabel">Comments: </label>
			<input type="text" name="venu_presentation_comments"></input>
		</div>
		</div>
		
		<div class="fieldContainer">
			<label class="questionHeading"><span class='manidatory'>*</span>9. Did audio/visual setup work properly?</label><span id="auErr"></span>
			<div><label><input type='radio' name="audio_setup" value="yes"></input>Yes </label></div>
			<div><label><input type='radio' name="audio_setup" value="no"></input>No  </label></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="inputLabel">Comments: </label>
				<input type="text" name="audio_setup_comments" value=""></input>
			</div>
		</div>	
		
		<div class="fieldContainer">
			<label class="questionHeading"><span class='manidatory'>*</span>10. Program Topic</label><span id="ptErr"></span>
			<div><label><input type='radio' name="program_topic" value="Abilify Maintena" onchange="hideQuestion('abilify')"></input>Abilify Maintena</label></div>
			<div><label><input type='radio' name="program_topic" value="Rexulti" onclick="hideQuestion('rexulti')"></input>Rexulti</label></div>
			<div><label><input type='radio' name="program_topic" value="Nuedexta" onclick="hideQuestion('nuedexta')"></input>Nuedexta</label></div>
			<div><label><input type='radio' name="program_topic" value="Samsca" onclick="hideQuestion('samsca')"></input>Samsca</label></div>
			<!--<div><label><input type='radio' name="program_topic" value="Disease State" onclick="hideQuestion('disease')"></input>Disease State </label></div>-->
			<div><label><input type='radio' name="program_topic" value="PsychU" onclick="hideQuestion('psychU')"></input>PsychU</label></div>
			
		</div>
		<div class="buttonContainer">
		
		<input type="button" onclick="showNext()" value="Next"></input>
		<input type="button" onclick="hideViewEvaluation()" value="Cancel"></input>
		</div>
	</div>
		
		
		<div class="secondPage" style="display:none">
				<div class="fieldContainer">
					<div class="abilify questDetail">	
						<label class="questionHeading">11. Abilify Maintena:</label>
						<div><label><input type='radio' name="abilify_maintena" value="Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia"></input>Beyond Maintenance Therapy: Abilify Maintena as a treatment option for acutely relapsed patients with Schizophrenia</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia"></input>Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Targeted Topics Around Use of Abilify Maintena for Treatment of Acutely Relapse and Maintenance Phase patients with Schizophrenia"></input><label>Targeted Topics Around Use of Abilify Maintena for Treatment of Acutely Relapse and Maintenance Phase patients with Schizophrenia</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Abilify Maintena for Early and Ongoing Treatment of Schizophrenia"></input>Abilify Maintena for Early and Ongoing Treatment of Schizophrenia</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Abilify Maintena: A Treatment Option for Patients with Acutely Relapsed Schizophrenia"></input>Abilify Maintena: A Treatment Option for Patients with Acutely Relapsed Schizophrenia </label></div>
						<div><label><input type='radio' name="abilify_maintena" value="In the Treatment of Acutely Relapsed Patients with Schizophrenia: Workbook"></input>In the Treatment of Acutely Relapsed Patients with Schizophrenia: Workbook</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Working Together to Incorporate Abilify Maintena Into Your Practice"></input>Working Together to Incorporate Abilify Maintena Into Your Practice</label></div>
						<div><label><input type='radio' name="abilify_maintena" value="Coordinating Care for Patients with Schizophrenia Roundtable Program"></input>Coordinating Care for Patients with Schizophrenia Roundtable Program</label></div>
					</div>
				</div>
				<div class="fieldContainer">
					<div class="rexulti questDetail">
						<label class="questionHeading">12. Rexulti:</label>
						<div><label><input type='radio' name="rexulti" value="Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder"></input>Discover Rexulti: Make Way for Possibilities of Schizophrenia Therapy</label></div>
						<div><label><input type='radio' name="rexulti" value="Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder (Primary Care)"></input>Discover Rexulti: Make Way for Possibilities of an Adjunctive Therapy for Major Depressive Disorder </label></div>
						
					</div>
				</div>
				
				<div class="fieldContainer">
					<div class="nuedexta questDetail">
						<label class="questionHeading">13. Nuedexta:</label>
						
						<div><label><input type='radio' name="nuedexta" value="The Diagnosing and Treatment of PBA"></input>The Diagnosing and Treatment of PBA</label></div>
					</div>
				</div>
				
				<div class="fieldContainer">
					<div class="samsca questDetail">
						<label class="questionHeading">14. Samsca:</label>
						<div><label><input type='radio' name="samsca" value="Understanding Hyponatremia: Treating Beyond the primary Diagnosis"></input>Understanding Hyponatremia: Treating Beyond the primary Diagnosis</label></div>
						<div><label><input type='radio' name="samsca" value="Hyponatremia in Heart Failure: Treating Beyond the Initial Diagnosis"></input>Hyponatremia in Heart Failure: Treating Beyond the Initial Diagnosis</label></div>
						<div><label><input type='radio' name="samsca" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment</label></div>
							<div><label><input type='radio' name="samsca" value="Evaluation and Management of Hyponatremia in the Hospital Setting"></input>Evaluation and Management of Hyponatremia in the Hospital Setting</label></div>	
					</div>
				</div>
				
<!--					<div class="fieldContainer">
						<div class="disease questDetail">
							<label class="questionHeading">15. Disease State (Enter Program Topic Below)</label>
							<div><textarea name="disease_state"></textarea>
							</div>
						</div>
					</div>-->
				
                    <div class="fieldContainer">
                        <div class="psychU questDetail">
                            <label class="questionHeading">15. PsychU (Enter Program Topic Below)</label>

                            <div><label><input type='radio' name="psychU" value="Understanding Hyponatremia: Treating Beyond the primary Diagnosis"></input>Early Intervention In Psychosis</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia in Heart Failure: Treating Beyond the Initial Diagnosis"></input>Metabolic Wellness Consideration in Schizophrenia</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Updates in Schizophrenia: Research, Remission and Recovery</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Addressing the Transition of Care For Patients with Schizophrenia: A Case Study Approach</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>An Overview of Treatment Options for Schiziophrenia</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Perspectives In Schizophrenia: Proposed Disease Pathophysiology and Potential Treatment
Implications</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>The Importance of Adherence to Long Term Schizophrenia</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Distinguishing Sedation vs Efficacy in Antipsychotic Treatment</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Recognizing and Responding to Inadequately Treated Major Depressive Disorder (MDD)</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Impact of Major Depressive Disorder on Patients, Caregivers, Payers and Employers</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>The Evolving Psychopharmacology of Major Depressive Disorder</label></div>
                            <div><label><input type='radio' name="psychU" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input>Understanding Psuedobulbar Affect (PBA)</label></div>
                        </div>
                    </div>
                
				<div class="fieldContainer">
				
				<label class="questionHeading"><span class='manidatory'>*</span>16. Were the attendees the appropriate audience for the topic(s) presented?</label><span id="tpErr"></span>
					<div><label><input type='radio' name="topic_presented" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="topic_presented" value="No"></input>No</label></div>
				</div>
				
<!--				<div class="fieldContainer">
				<label class="questionHeading"><span class='manidatory'>*</span>17. What actions were taken to assure only appropriate individuals were in the audience?</label>
				<div><textarea name="action"></textarea>
				</div>
				</div>-->
				
					<?php 
					$arrQuestions = array(1=>'Product / Topic Knowledge',2=>'Effectiveness of delivery',3=>'Ability to answer questions',4=>"Ability to hold the audience's
attention",5=>'Ability to engage audience in discussion',6=>'Provided an impactful presentation',7=>'Ability to present in fair and balanced manner');
				
				?>
				<div class="fieldContainer">
					<label class="questionHeading"><span class='manidatory'>*</span>17. Please rate the speakers based on the following:</label>

					<table class="ratingContent">
						<tr>
							<th>
								
							</th>
							<th>
							5 </br>
							(Outstanding)
							</th>
							<th>
							4 </br>
							(Strong)
							</th>
							<th>
							3 </br>
							(Satisfactory)
							</th>
							<th>
							2 </br>
							(Poor)
							</th>
							<th>
							1 </br>
							(Very Poor)
							</th>
							<th>
							N/A
							</th>
						</tr>
					<?php foreach($arrQuestions as $key=>$row){?>
						<tr>
							<td style="width:28%">
								<label>
								<?php echo  $row;?>
								</label>
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="5">
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="4">
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="3">
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="2">
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="1">
							</td>
							<td>
							<input type='radio' name="speaker_rate_<?php echo $key?>" value="0">
							</td>
						</tr>
					<?php }?>
					
					</table>
					<div>
					
					
					</div>
					
				</div>
				
				<div class="fieldContainer">
				
				<label class="questionHeading"><span class='manidatory'>*</span>18. Did the speaker stay within label during the presentation?</label><span id="ssErr"></span>
				<div><label><input type='radio' name="speaker_stay" value="Yes" onclick="showOrHideQuestion(this.value,'eventContainer','mirfContainer')"></input>Yes</label></div>
				<div><label><input type='radio' name="speaker_stay" value="No" onclick="showOrHideQuestion(this.value,'eventContainer','mirfContainer')"></input>No</label></div>
				</div>
				
				<div class="fieldContainer">
				
				<label class="questionHeading"><span class='manidatory'>*</span>19. Did the speaker minimize or dismiss product safety information?</label><span id="siErr"></span>
				<div><label><input type='radio' name="saftey_info" value="Yes"></input>Yes</label></div>
				<div><label><input type='radio' name="saftey_info" value="No"></input>No</label></div>
				</div>
				
				
				<div class="fieldContainer">
					<div class="mirfContainer" style="display:none">
					<label class="questionHeading"><span class='manidatory'>*</span>20. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label><span id="miErr"></span>
					<div><label><input type='radio' name="mirf" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="mirf" value="No"></input>No</label></div>
					<div class="inputFiedConatiner">
						<label style="display:block">Comments: </label>
						<textarea name="mirf_other"></textarea>
					</div>
				</div>
				
				</div>
				<div class="fieldContainer">
					<div class="eventContainer" style="display:none">
					<label class="questionHeading"><span class='manidatory'>*</span>21. Were any adverse events reported by any attendee during the event?</label><span id="aeErr"></span>
					<div><label><input type='radio' name="adverse_event" value="Yes" onclick="showOrHideQuestion(this.value,'policyContainer','productContainer')"></input>Yes</label></div>
					<div><label><input type='radio' name="adverse_event" value="No" onclick="showOrHideQuestion(this.value,'policyContainer','productContainer')"></input>No</label></div>
					</div>
				</div>
				<div class="fieldContainer">	
					<div class="policyContainer">
					<label class="questionHeading"><span class='manidatory'>*</span>22. Was the adverse event reported as per Otsuka Policy?</label><span id="aerErr"></span>
					<div><label><input type='radio' name="adverse_event_report" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="adverse_event_report" value="No"></input>No</label></div>
					</div>
				</div>
				
				<div class="fieldContainer">	
					<div class="productContainer">
						<label class="questionHeading"><span class='manidatory'>*</span>23. Was the speaker's articulation of their experience with the product on label?</label><span id="saErr"></span>
					<div><label><input type='radio' name="speaker_articulation" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="speaker_articulation" value="No"></input>No</label></div>
					<div>
						<label style="display:block">Comments: </label>
						<textarea name="speaker_articulation_comment"></textarea>
					</div>
					</div>
				</div>
				<div class="fieldContainer">
					<label class="questionHeading"><span class='manidatory'>*</span>24. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label><span id="mdErr"></span>
					<div><label><input type='radio' name="mirf_doc" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="mirf_doc" value="No"></input>No</label></div>
					<div class="inputFiedConatiner">
						<label style="display:block">Other (please specify): </label>
						<textarea name="mirf_comment"></textarea>
					</div>
				</div>
				<div class="fieldContainer">
				
					<label class="questionHeading"><span class='manidatory'>*</span>25. Speaker was compliant based on Otsuka's Regulatory and Compliance Guidelines:</label><span id="guErr"></span>
					<div><label><input type='radio' name="guideline" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="guideline" value="No"></input>No (If Speaker was not complaint based on Otsuka's Regulatory and Compliance Guidleines, it must be reported within 24 hours as required by
Otsuka Policy.)</label></div>
				</div>
				
				<div class="fieldContainer">
				
					<label class="questionHeading"><span class='manidatory'>*</span>26. On a scale of 15(1 = extremely unlikely; 5 = Extremely likely),How likely would you be to recommend this speaker to continue to be utilized by Otsuka?</label><span id="scErr"></span>
					<table>
						<tr>
							<td>
							1.Extremely unlikely
							</td>
							<td>
							2. Not likely
							</td>
							<td>
							3. Somewhat likely
							</td>
							<td>
							4. Likely
							</td>
							<td>
							5. Extremely likely
							</td>
						
						</tr>
						<tr>
							<td>
							<input type='radio' name="scale" value="1"></input>
							</td>
							<td>
							<input type='radio' name="scale" value="2"></input>
							</td>
							<td>
							<input type='radio' name="scale" value="3"></input>
							</td>
							<td>
							<input type='radio' name="scale" value="4"></input>
							</td>
							<td>
							<input type='radio' name="scale" value="5"></input>
							</td>
						
						</tr>
					
					</table>
				</div>
				
					<div class="fieldContainer">
				
					<label class="questionHeading"><span class='manidatory'>*</span>27. Recommend speaker for MSL followup visit for support (if any rating 3 or lower on any category, or identified need for greater than quarterly support):</label><span id="mfErr"></span>
					<div><label><input type='radio' name="msl_follow_up" value="Yes"></input>Yes</label></div>
					<div><label><input type='radio' name="msl_follow_up" value="No"></input>No </label></div>
					<div class="inputFiedConatiner">
						<label style="display:block">Comments: </label>
						<textarea name="msl_follow_up_comment"></textarea>
					</div>
				</div>
				<div class="buttonContainer">
				<input type="button" onclick="save()" value="Save"></input>
				<input type="button" onclick="hideViewEvaluation()" value="Cancel"></input>
				</div>
</div>
		</div>
	</form>


</div>