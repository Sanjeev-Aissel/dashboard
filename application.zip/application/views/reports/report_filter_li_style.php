<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts = array('reports/reports_filter_li_style');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
	}
</script>
<style type="text/css">
	#timeLineSliderContainer {
	    padding-left: 10px;
    	padding-right: 8px;
	}
	#timeLineSlider{
		margin-right:10px;
	}
	#searchLeftBar li.category{
		border-top: 0px;
	}
	#searchLeftBar{
	/*	margin-top:-40px; */
	}
	<?php if(IS_IPAD_REQUEST == 1){
			echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
		}
	?>
	.region{
                background: url('<?php echo base_url(); ?>images/ipad/region_active.svg');
    background-size: 22px auto;
    height: 22px;
    width: 22px;
        }
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px;
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		/*margin-top: 0px;*/
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
	.chzn-container-single .chzn-single div{
		top: -3px !important;
	}
/*	.chzn-container .chzn-results li{
		padding: 3px 4px !important;
		line-height: 12px !important;
	}
*/
	.chzn-drop{
		min-width: 106px !important;
	}
	.ui-widget-content, #timeLineSliderContainer p, #yearRange {
		background: inherit;
	}
</style>
<?php 
		//$arrfilterdata		= $this->session->userdata('filterContent');		
		$selectedKolId		= $arrfilterdata['selected_kol_id'];
		if(!empty($selectedKolId) && $selectedKolId!=0){
			foreach($arrKolDetails as $key=>$rowData){
				if($key==$selectedKolId){
					$selectedKol[$key]	= $rowData['name'];
				}
			}
		}else{
			$selectedKol	= $arrfilterdata['arrKolNames'];//$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
		}
		if($arrfilterdata['profileType'] != ''){
			$profileType = $arrfilterdata['profileType'];
		}
		if($arrfilterdata['savedFilterId']!= ''){
			$savedFilterId = $arrfilterdata['savedFilterId'];
		}
		if(!empty($arrfilterdata['arrGlobalRegions'])){
			if(!is_array($arrfilterdata['arrGlobalRegions'])){
				$arrfilterdata['arrGlobalRegions'] = explode(',',$arrfilterdata['arrGlobalRegions']);
			}
			$selectedRegionTypes=array();
			foreach($arrfilterdata['arrGlobalRegions'] as $values){
				$selectedRegionTypes[$values]=$values;
			}
		}else{
			$selectedRegionTypes	= array();
		}
		if(!empty($arrfilterdata['arrSpecialities'])){
			if(!is_array($arrfilterdata['arrSpecialities'])){
				$arrfilterdata['arrSpecialities'] = explode(',',$arrfilterdata['arrSpecialities']);
			}
			$selectedSpecialty	= $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
		}else{
			$selectedSpecialty = array();
		}
		if(sizeof($arrfilterdata['arrCountries'])>0){
			if(!is_array($arrfilterdata['arrCountries'])){
				$arrfilterdata['arrCountries'] = explode(',',$arrfilterdata['arrCountries']);
			}
			$selectedCountry	= $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
		}else{
			$selectedCountry = array();
		}
		//$selectedState		= $arrfilterdata['arrStates'];
		if(!empty($arrfilterdata['arrStates'])){
			if(!is_array($arrfilterdata['arrStates'])){
				$arrfilterdata['arrStates'] = explode(',',$arrfilterdata['arrStates']);
			}
			$selectedState	= $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
		}else{
			$selectedState = array();
		}
		if(sizeof($arrfilterdata['arrListNames'])>0){
			if(!is_array($arrfilterdata['arrListNames'])){
				$arrfilterdata['arrListNames'] = explode(',',$arrfilterdata['arrListNames']);
			}
			$CI =& get_instance();
			$CI->load->model("My_list_kol");
			//$selectedListName	= $arrfilterdata['arrListNames'];
			$selectedListName	= $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
		}else{
			$selectedListName	= array();
		}
?>
	<script type="text/javascript">

	$(document).ready(function (){
		//$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
		$('#categoriesContainer input:checked').each(function (index){
			$(this).parent().parent().css('background-color','#D3DFED');
		});
	
		$('#searchFiltersElements ul li table tr').click(function (){
			if($('#'+$(this).attr('class')).attr('checked')=="checked"){
				$(this).css('background-color','#ffffff');
				$('#'+$(this).attr('class')).removeAttr('checked');
				displaySelectedChart($('#'+$(this).attr('class')));
			}else{
				$(this).css('background-color','#D3DFED');
				$('#'+$(this).attr('class')).attr('checked','checked');
				displaySelectedChart($('#'+$(this).attr('class')));
			}
			
		});
		initializeCustomToolTips();
	});
			var options, a;

			var regionTypeAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_region',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.regionTypes').html();
						var selId = $(event).children('.regionTypes').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#regionType').val(selText);
						$('#regionTypeId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
				};
			
			// Autocomplet Options for the 'role' field 
		  	var SpecialtyNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.specialties').html();
						var selId = $(event).children('.specialties').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#specialty').val(selText);
						$('#specialtyId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};	
		
			// Autocomplet Options for the 'country' field
			var countryNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.countries').html();
						var selId = $(event).children('.countries').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#country').val(selText);
						$('#countryId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};
			// Autocomplet Options for the 'country' field
			var stateNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var stateId = $(event).children('.autocompleteStateId').html();
						var selText = $(event).children('.stateName').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#state').val(selText);
						$('#stateIdForAutocomplete').val(stateId);
						if(selText.length>20){
							if(selText.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
				};
		
			var kolNameAutoCompleteOptions = {
					<?php 
					if(KOL_CONSENT){?>
					serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/0/1',
					<?php }else{ ?>
					serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
					<?php }?>
					<?php echo $autoSearchOptions;?>,
							onSelect : function(event, ui) {
								var kolId = $(event).children('.id1').html();
								//var selText = $(event).children('.kolName').html();
								var selText = $(event).children('.kolName').attr('name');
								selText=selText.replace(/\&amp;/g,'&');
								$('#kolName').val(selText);
								$('#kolIdForReport').val(kolId);
								if(selText.length>20){
									if(selText.substring(0,21)=="No results found for "){
										return false;
									}else{
										displaySelectedChart(true);
									}
								}else{
								displaySelectedChart(true);
							}
							}
					
				};

			// Autocomplet Options for the 'country' field
			var listNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>my_list_kols/get_list_names_with_category',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.lists').html();
						var selId = $(event).children('.lists').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#listName').val(selText);
						$('#listNameId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};		
	
			$(document).ready(function(){
		
				// Trigger the Autocompleter for 'education' field of  Event'
				a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
		
				// Trigger the Autocompleter for 'country' field of  Event'
				a = $('#country').autocomplete(countryNameAutoCompleteOptions);
		
				a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
		
				// Trigger the Autocompleter for 'list' field of  Event'
				a = $('#listName').autocomplete(listNameAutoCompleteOptions);

				// Binding the function for slidechange event 
				$( "#timeLineSlider" ).bind( "slidechange", filterChart);
		
			});
		
			//Initiallize the Timeline slider
			<?php $date=date('Y');?>
		//	var minYear=<?php echo ($date-35);?>;
			var minYear=<?php echo ($date-60);?>;
			var maxYear=<?php echo $date;?>;
			var startDate='<?php if(isset($startDate))echo $startDate; else echo 0;?>';
			var endDate='<?php if(isset($endDate))echo $endDate; else echo 0;?>';
			var rangeValue1=minYear;
			var rangeValue2=maxYear;
				if(startDate!=null && startDate!=0)
					rangeValue1=startDate;
				if(endDate!=null && endDate!=0)
					rangeValue2=endDate;
/*			
			$(function() {
				$( "#timeLineSlider" ).slider({
					range: true,
					min: minYear,
					max: maxYear,
					values: [ rangeValue1, rangeValue2 ],
					step:1,
					slide: function( event, ui ) {
						$( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
					}
				});
		
				$( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
			});
			

			


			// Hide or Show the Category checkbox's 
			function toggleCategory(toggleFlag,thisEle){
				//	jAlert("Ds");
				if($(thisEle).parent().attr('id')=='categotySpecialty'){
						$('#specialtyCheckBox').slideToggle();	
					
				}else if($(thisEle).parent().attr('id')=='categotyCountry'){
					$('#countryCheckBox').slideToggle();	
				}else if($(thisEle).parent().attr('id')=='categotyLists'){

					$('#listCheckBox').slideToggle();
				}else{
					$('#kolsCheckBox').slideToggle();
				}
				
			}

			$(document).ready(function(){
				$('#kolName').css({color:"gray"});
				$('#specialty').css({color:"gray"});
				$('#country').css({color:"gray"});
				$('#listName').css({color:"gray"});


				$('#kolName').focus(function(){
						
						var name=$('#kolName').val();
						if(name=='Enter KOL Name'){
							$('#kolName').val(" ");
						}
					});

					$('#kolName').blur(function() {
						var name=$('#kolName').val();
						if(name==' '){
							$('#kolName').val('Enter KOL Name');
						}
					});

					$('#specialty').focus(function(){
						
						var name=$('#specialty').val();
						if(name=='Enter Specialty'){
							$('#specialty').val(" ");
						}
					});

					$('#specialty').blur(function() {
						var name=$('#specialty').val();
						if(name==' '){
							$('#specialty').val('Enter Specialty');
						}
					});

					$('#country').focus(function(){
						
						var name=$('#country').val();
						if(name=='Enter Country'){
							$('#country').val(" ");
						}
					});

					$('#country').blur(function() {
						var name=$('#country').val();
						if(name==' '){
							$('#kolName').val('Enter Country');
						}
					});

					$('#listName').focus(function(){
						
						var name=$('#listName').val();
						if(name=='Enter List Name'){
							$('#listName').val(" ");
						}
					});

					$('#listName').blur(function() {
						var name=$('#listName').val();
						if(name==' '){
							$('#listName').val('Enter List Name');
						}
					});
			});
*/
if(js_files_loaded){

	// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
// 				jAlert("Ds");
		/*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
					$('#specialtyCheckBox').slideToggle();	
				
			}else if($(thisEle).parent().attr('id')=='categotyCountry'){
				$('#countryCheckBox').slideToggle();	
			}else if($(thisEle).parent().attr('id')=='categotyLists'){
				$('#listCheckBox').slideToggle();
			}else{
				$('#kolsCheckBox').slideToggle();
			}
		*/
			$(thisEle).next().slideToggle('slow');
			$(thisEle).toggleClass('expanded');
			$(thisEle).toggleClass('collapsed');
		}
		
		$(function() {
			$( "#timeLineSlider" ).slider({
				range: true,
				min: minYear,
				max: maxYear,
				values: [ rangeValue1, rangeValue2 ],
				step:1,
				slide: function( event, ui ) {
					$( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
				}
			});

			$( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
		});
		
	$(document).ready(function(){
		// Trigger the Autocompleter for 'region' field of  Event'
		a = $('#regionType').autocomplete(regionTypeAutoCompleteOptions);
		 		
		// Trigger the Autocompleter for 'education' field of  Event'
		a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'country' field of  Event'
		a = $('#country').autocomplete(countryNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'country' field of  Event'
		a = $('#state').autocomplete(stateNameAutoCompleteOptions);

		a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'list' field of  Event'
		a = $('#listName').autocomplete(listNameAutoCompleteOptions);

		// Binding the function for slidechange event 
		$( "#timeLineSlider" ).bind( "slidechange", filterChart);

	});
	$(document).ready(function(){
		$('#kolName').css({color:"gray"});
		$('#specialty').css({color:"gray"});
		$('#country').css({color:"gray"});
		$('#state').css({color:"gray"});
		$('#listName').css({color:"gray"});


		$('#kolName').focus(function(){
				
			//	var name=$('#kolName').val();
			//	if(name=='Enter KOL Name'){
					$('#kolName').val(" ");
			//	}
			});

			$('#kolName').blur(function() {
			//	var name=$('#kolName').val();
			//	if(name==' '){
					$('#kolName').val('Enter KTL Name');
			//	}
			});
			
			$('#regionType').focus(function(){
			    $('#regionType').val(" ");
			    });
		    
			$('#regionType').blur(function(){
			    $('#regionType').val('Enter Global Region ');
			    });
					    
			$('#specialty').focus(function(){
				
			//	var name=$('#specialty').val();
			//	if(name=='Enter Specialty'){
					$('#specialty').val(" ");
			//	}
			});

			$('#specialty').blur(function() {
			//	var name=$('#specialty').val();
			//	if(name==' '){
					$('#specialty').val('Enter Specialty');
			//	}
			});

			$('#country').focus(function(){
				
			//	var name=$('#country').val();
			//	if(name=='Enter Country'){
					$('#country').val(" ");
			//	}
			});

			$('#country').blur(function() {
			//	var name=$('#country').val();
			//	if(name==' '){
					$('#country').val('Enter Country');
			//	}
			});

			$('#state').focus(function(){
				
			//	var name=$('#state').val();
			//	if(name=='Enter State'){
					$('#state').val(" ");
			//	}
			});

			$('#state').blur(function() {
			//	var name=$('#state').val();
			//	if(name==' '){
					$('#state').val('Enter State');
			//	}
			});

			$('#listName').focus(function(){
				
			//	var name=$('#listName').val();
			//	if(name=='Enter List Name'){
					$('#listName').val(" ");
			//	}
			});

			$('#listName').blur(function() {
			//	var name=$('#listName').val();
			//	if(name==' '){
					$('#listName').val('Enter List Name');
			//	}
			});
	});
	
/*
	$('#rightSideBarSliderShow').click(function() {
		$('#searchLeftBar').show(1000, function() 
			{
				$('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
			});
		$("#rightSideBarSliderHide").show();
		$("#rightSideBarSliderShow").hide();
		
  	//	$('#searchLeftBar').slideToggle('slow', function() {
  	//		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
	//	});
	});

	$('#rightSideBarSliderHide').click(function() {
		$('#searchLeftBar').hide(1000, function() 
			{
				$('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
				$("#rightSideBarSliderShow").show(500);
			});
		$("#rightSideBarSliderHide").hide();
		
  	//	$('#searchLeftBar').slideToggle('slow', function() {
  	//		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
	//	});
	});
*/
}
$(document).ready(function(){
	$("#savedFilterValue").chosen().change(function(){
		activeCustmFilters(this);
	});
	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
		displaySelectedChart(this);
	});
	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
		if($("#savedFilterValue").val()){
			activeCustmFilters($("#savedFilterValue").val());
			return true;
			}
//		doSearchFilter1(-1,this);
		displaySelectedChart(this);
	});
});
	</script>
<!--		<h3>
			<div class="funnelIcon sprite_iconSet"></div>Refine By
			<div id="resetBttnContainer"><label id="resetBttn" onclick="resetFilters();">&nbsp;</label>Reset</div>
		</h3>
-->
		<div id="searchFiltersContainer">
			<div id="searchFiltersElements">
				<div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
					<p><label>Year Range:</label>
						<input type="text" readonly="readonly" id="yearRange" style="border:0; color:#f6931f; font-weight:bold;" />
					</p>
					<div id="timeLineSlider" class="timeLineSlider" title="Slide to Adjust Timeline">
					
					</div>
				</div>
		
					<form action="<?php echo base_url()?>kols/" name="searchFilterForm" method="post" id="searchFilterForm">
						<ul id="categoriesContainer">
							<li class="">
								<div>
									<div class="assigned sprite_iconSet" id="assignedIcon"></div>
									<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
									<div style="">
										<select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
											<option value="1" <?php if($viewType == MY_RECORDS)echo 'selected="selected"';?>>My Contacts</option>
											<option value="2" <?php if($viewType == ALL_RECORDS)echo 'selected="selected"';?>>All Contacts</option>
										</select>
									</div>
								</div>
							</li>
							<li id="customFilters" class="">
								<div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
								<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 5px;">Saved Filters </label>
								<div style="">
									<select id="savedFilterValue" data-placeholder="Choose saved queries..." style="width:150px;" class="chosen-select">
										<option></option>
										<?php foreach($customFilters as $customFilter){ ?>
							 				<option value='<?php echo $customFilter['id'];?>' <?php if($savedFilterId == $customFilter['id']){ echo 'selected="selected"';}?> ><?php echo $customFilter['name'];?></option>
										<?php }?>
									</select>
									<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
										<a data-original-title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
									</div>
								</div>
							</li>
							<li class="">
								<div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
								<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">Profile Type </label>
								<div style="">
									<select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
										<option value="">All Profiles</option>
										<option value="Full Profile" <?php if($profileType == "Full Profile") echo "selected='selected'";?>>Full Profiles</option>
										<!-- <option value="Basic Plus" <?php if($profileType == "Basic Plus") echo "selected='selected'";?>>Basic+ Profiles</option> -->
										<option value="Basic" <?php if($profileType == "Basic") echo "selected='selected'";?>>Basic Profiles</option>
										<option value="User Added" <?php if($profileType == "User Added") echo "selected='selected'";?>>User Added</option>
										<option value="Legacy" <?php if($profileType == "Legacy") echo "selected='selected'";?>>Legacy</option>
									</select>
								</div>
							</li>
							<li id="categotyKols" class="category">
<!--								<div class="kolName sprite_iconSet"></div><label class="categoryName">KOL Name</label>-->
<!--								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>-->
								<div>
								<table>
									<?php
										if(isset($selectedKol) && $selectedKol!=null && $selectedKol!=0){
										    $selectedKol = $this->kol->getKolNameById($selectedKol);pr($kol);
											foreach($selectedKol as $k => $kol){?>
												<tr class="kol<?php echo str_replace(' ','',$kol);?>">
													<td class="textAlignRight">
														<input type="checkbox" name="kol_ids[]" class="kolElement hideCheckbox" id="kol<?php echo str_replace(' ','',$kol);?>" checked="checked" value="<?php echo $k;?>" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $kol;?>
													</td>
													<td class="histoGram"><div class="filterBar">
															<div class="progress" title="1(<?php echo round((1/1)*100);?>%)">
																<div class="bar" style="width: <?php if(isset($kol)) echo round((1/1)*100); else echo 0;?>%;"></div>
															</div>
														</div>
													</td>
													<td>
													<?php 
													//	if($reportSection=='activity'){
															if (array_key_exists($kol, $arrKolDetails)){ 
																if(isset($arrKolDetails[$kol]['count']))
																	echo '('.$arrKolDetails[$kol]['count'].')';
															}
															else{
																if(isset($arrKolDetails[$kol]['count']))
																	echo '('.'0'.')';
															}
													//	}
													?>
													</td>
												</tr>
									<?php } }?>
									</table>
									<div class="filterSearchIcon"></div><input type="text" name="kol_ids1" class="autocompleteInputBox" id="kolName" value="Enter KTL Name" title=""/>
									<input type="hidden" id="kolIdForReport" value="<?php echo $selectedKolId;?>" name="kol_id1"></input>
								</div>
							</li>
				
               		<!-- Start of Global Region -->
                		<li id="categotyRegions" class="category">
							<?php 
								if($reportSection!='activity' || $reportSection!='segmentation'){
									$totalKolsCount	= $totalGlobalRegionCount;
								}
							?>
								<div class="region sprite_iconSet"></div><label class="categoryName">Global Region</label>
									<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
						<table>
							<tr class="allRegionTypes">
								<td class="textAlignRight">
									<input class="hideCheckbox" type="checkbox" name="all_region_types" id="allRegionTypes"  value="regionType" <?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null) echo ''; else echo "checked='checked'"?> onclick="displaySelectedChart(this)"/>All Region
								</td>
								<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php if(isset($totalKolsCount))echo $totalKolsCount."(".round(($totalKolsCount/$totalKolsCount)*100); else echo "0(0";?>%)">
													<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($totalKolsCount/$totalKolsCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
								</td>
								<td>
									<?php 
									//	if($reportSection=='activity'){
											if(isset($totalKolsCount)) echo $totalKolsCount; else echo 0;
									//	}
									?>
								</td>
							</tr>
								<?php 
								$i=0;
								foreach($arrGlobalRegions as $regionCountDetails){
									if($regionCountDetails['GlobalRegion']!=''){
									?>
										 	<tr class="regionType<?php echo $i;?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="regionType_ids[]" class="globalRegionElement hideCheckbox" id="regionType<?php echo $i;?>" value="<?php echo $regionCountDetails['GlobalRegion'];?>" onclick="displaySelectedChart(this)"  
									 					<?php
															if(isset($selectedRegionTypes[$regionCountDetails['GlobalRegion']])){
																unset($selectedRegionTypes[$regionCountDetails['GlobalRegion']]);
																echo 'checked="checked"';
															}
														?>
													/>&nbsp;<?php echo $regionCountDetails['GlobalRegion'];?>
									 			</td>
									 			<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$totalKolsCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($regionCountDetails['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php echo $regionCountDetails['count']; ?></td>
									 		</tr>
								<?php $i++; if($i>3) break; 
									}
								}?>
								<?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null && $selectedRegionTypes!=0){
									foreach($selectedRegionTypes as $typeId=>$regionName){ ?>
									<tr class="regionType<?php echo $typeId;?>">
								 		<td class="textAlignRight">
													<input type="checkbox" name="regionType_ids[]" class="globalRegionElement hideCheckbox" id="regionType<?php echo $typeId;?>" value="<?php echo $typeId;?>" checked="checked" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $regionName;?>
												</td>
												<td class="histoGram">
								 			<div class="filterBar">
												<div class="progress" title="<?php echo $arrRegionCount[$regionName]['count']."(".round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php
											if (array_key_exists($typeId, $arrGlobalRegions)) echo $arrGlobalRegions[$typeId]['count']; else echo 0;
											?></td>
									</tr>
								<?php } }?>
							</table>		
						<div class="filterSearchIcon"></div><input type="text" name="region_type_ids" class="autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" /></div>
                          </li>
                <!-- End of Global Region -->
							<li id="categotySpecialty" class="category">
							<?php 
								if($reportSection!='activity' || $reportSection!='segmentation'){
									$totalKolsCount	= $totalSpecialtyCount;
								}
							?>
								<div class="refineBySecialtyImage sprite_iconSet"></div><label class="categoryName">Specialty</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table>
									<tr class="allSpecialties">
										<td class="textAlignRight">
											<input class="hideCheckbox" type="checkbox" name="all_specialties" id="allSpecialties"  value="specialties" <?php if(isset($selectedSpecialty) && $selectedSpecialty!=null && $selectedSpecialty!=0) echo ''; else echo "checked='checked'"?> onclick="displaySelectedChart(this)"/>All Specialties
										</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php if(isset($totalKolsCount))echo $totalKolsCount."(".round(($totalKolsCount/$totalKolsCount)*100); else echo "0(0";?>%)">
													<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($totalKolsCount/$totalKolsCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td>
											<?php 
											//	if($reportSection=='activity'){
													if(isset($totalKolsCount)) echo $totalKolsCount; else echo 0;
											//	}
											?>
										</td>
									</tr>
										<?php 
										$i=0;
										 	foreach($arrSpacialties as $specialtyCountDetails){ 
										 		if($specialtyCountDetails['specialty']!=''){?>
												 	<tr class="specialty<?php echo $specialtyCountDetails['id'];?>">
											 			<td class="textAlignRight">
											 				<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $specialtyCountDetails['id'];?>" value="<?php echo $specialtyCountDetails['id'];?>" onclick="displaySelectedChart(this)"  
											 					<?php
																	if(isset($selectedSpecialty[$specialtyCountDetails['id']])){
																		unset($selectedSpecialty[$specialtyCountDetails['id']]);
																		echo 'checked="checked"';
																	}
																?>
															/>&nbsp;<?php echo $specialtyCountDetails['specialty'];?>
											 			</td>
											 			<td class="histoGram">
												 			<div class="filterBar">
																<div class="progress" title="<?php echo $specialtyCountDetails['count']."(".round(($specialtyCountDetails['count']/$totalKolsCount)*100)."%)";?>">
																	<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($specialtyCountDetails['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
																</div>
															</div>
														</td>
											 			<td><?php //if($reportSection=='activity' ||$reportSection=='segmentation')
											 						echo $specialtyCountDetails['count'];
											 				?></td>
											 		</tr>
										<?php $i++; if($i>3) break; }}?>
										<?php 
											if(isset($selectedSpecialty) && $selectedSpecialty!=null && $selectedSpecialty!=0){
												foreach($selectedSpecialty as $id=>$spacialty){?>
													<tr class="specialty<?php echo $id;?>">
														<td class="textAlignRight">
															<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $id;?>" checked="checked" value="<?php echo $id?>" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $spacialty;?>
														</td>
														<td class="histoGram">
												 			<div class="filterBar">
																<div class="progress" title="<?php echo $arrSpacialties[$id]['count']."(".round(($arrSpacialties[$id]['count']/$totalKolsCount)*100)."%)";?>">
																	<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($arrSpacialties[$id]['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
																</div>
															</div>
														</td>
														<td>
															<?php 
																//if($reportSection=='activity'){
																	if (array_key_exists($id, $arrSpacialties)) echo $arrSpacialties[$id]['count']; else echo 0;
																//}
															?>
														</td>
													</tr>
										<?php } }?>
									</table>
									<div class="filterSearchIcon"></div><input type="text" name="specialty_ids" class="autocompleteInputBox" id="specialty" value="Enter Specialty" title=""/><input type="hidden" name="specialty_id" id="specialtyId" value="" />
								</div>
							</li>
								
							<li id="categotyCountry" class="category">
							<?php 
								if($reportSection!='activity' || $reportSection!='segmentation'){
									$totalKolsCount	= $totalCountryCount;
								}
							?>
								<div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Country</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table>
									<tr class="allCountries">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if(isset($selectedCountry) && $selectedCountry!=null  && $selectedCountry!=0) echo ''; else echo "checked='checked'"?> onclick="displaySelectedChart(this)"/>All Countries</td>
										<td class="histoGram">
											<div class="filterBar">
												<div class="progress" title="<?php echo $totalKolsCount."(".round(($totalKolsCount/$totalKolsCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($totalKolsCount/$totalKolsCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php //if($reportSection=='activity'){
														if(isset($totalKolsCount)) echo $totalKolsCount; else echo 0;
													// }
												?>
										</td>
									</tr>
										<?php $i=0;
										 	//pr($selectedCountry);pr($arrCountries);
											foreach($arrCountries as $arrCountriesDetails){
												if($arrCountriesDetails['country_name']!=''){?>
												<tr class="country<?php echo $arrCountriesDetails['country_id'];?>">
											 		<td class="textAlignRight">
											 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $arrCountriesDetails['country_id'];?>" value="<?php echo $arrCountriesDetails['country_id'];?>" onclick="displaySelectedChart(this)"
											 				<?php
																if(isset($selectedCountry[$arrCountriesDetails['country_id']])){
																	unset($selectedCountry[$arrCountriesDetails['country_id']]);
																	echo 'checked="checked"';
																}
															?> 
														/>&nbsp;<?php echo $arrCountriesDetails['country_name'];?>
											 		</td>
											 		<td class="histoGram">
											 			<div class="filterBar">
															<div class="progress" title="<?php echo $arrCountriesDetails['count']."(".round(($arrCountriesDetails['count']/$totalKolsCount)*100)."%)";?>">
																<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($arrCountriesDetails['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
															</div>
														</div>
													</td>
											 		<td><?php //if($reportSection=='activity' ||$reportSection=='segmentation')echo $arrCountriesDetails['count'];
											 					echo $arrCountriesDetails['count'];
											 			?></td>
											 	</tr>
										<?php $i++; if($i>3) break; }}?>
										<?php if((isset($selectedCountry))&& ($selectedCountry!=null)&& ($selectedCountry!=0)){
											foreach($selectedCountry as $key=>$countryName){
											?>
											<tr class="country<?php echo $key;?>">
												<td class="textAlignRight">
													<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $key;?>" value="<?php echo $key;?>" checked="checked" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $countryName; ?>
												</td>
												<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $arrCountries[$key]['count']."(".round(($arrCountries[$key]['count']/$totalKolsCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($arrCountries[$key]['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
												<td><?php //if($reportSection=='activity'){
															if (isset($arrCountries[$key])) echo ' '.$arrCountries[$key]['count']; else echo 0;
														// }?>
												</td>
											</tr>
											<?php }}?>
									
										</table>
										<div class="filterSearchIcon"></div><input type="text" name="country_ids" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
									</div>
							</li>
							<li id="categotyState" class="category">
							<?php 
								if($reportSection!='activity' || $reportSection!='segmentation'){
									$totalKolsCount	= $totalStateCount;
//									echo "dd-".$totalKolsCount;
								}
//								echo "dd-".$totalKolsCount;
							?>
								<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName">State</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table>
									<tr class="allStates">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_states" id="allStates"  value="state" <?php if(isset($selectedState) && $selectedState!=null  && $selectedState!=0) echo ''; else echo "checked='checked'"?> onclick="displaySelectedChart(this)"/>All States</td>
										<td class="histoGram">
											<div class="filterBar">
												<div class="progress" title="<?php echo $totalKolsCount."(".round(($totalKolsCount/$totalKolsCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($totalKolsCount/$totalKolsCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php //if($reportSection=='activity'){
														if(isset($totalKolsCount)) echo $totalKolsCount; else echo 0;
													// }
												?>
										</td>
									</tr>
										<?php $i=0;
											foreach($arrStates as $arrStatesDetails){
												if($arrStatesDetails['state_id']>0){?>
												<tr class="state<?php echo $arrStatesDetails['state_id'];?>">
											 		<td class="textAlignRight">
											 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $arrStatesDetails['state_id'];?>" value="<?php echo $arrStatesDetails['state_id'];?>" onclick="displaySelectedChart(this)" 
														<?php
															if(isset($selectedState[$arrStatesDetails['state_id']])){
																unset($selectedState[$arrStatesDetails['state_id']]);
																echo 'checked="checked"';
															}
														?>
														/>&nbsp;<?php echo $arrStatesDetails['state_name'];?>
											 		</td>
											 		<td class="histoGram">
											 			<div class="filterBar">
															<div class="progress" title="<?php echo $arrStatesDetails['count']."(".round(($arrStatesDetails['count']/$totalKolsCount)*100)."%)";?>">
																<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($arrStatesDetails['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
															</div>
														</div>
													</td>
											 		<td><?php //if($reportSection=='activity' ||$reportSection=='segmentation')echo $arrStatesDetails['count'];
											 					echo $arrStatesDetails['count'];
											 			?></td>
											 	</tr>
										<?php $i++; if($i>3) break; }}?>
										<?php if((isset($selectedState))&& ($selectedState!=null)&& ($selectedState!=0)){
											foreach($selectedState as $key=>$stateName){
											?>
											<tr class="state<?php echo str_replace(' ','',str_replace('&','and',$stateName));?>">
												<td class="textAlignRight">
													<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $stateName;?>" value="<?php echo $key;?>" checked="checked" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $arrStates[$key]['state_name']; ?>
												</td>
												<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $arrStates[$key]['count']."(".round(($arrStates[$key]['count']/$totalKolsCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($totalKolsCount)) echo round(($arrStates[$key]['count']/$totalKolsCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
												<td><?php //if($reportSection=='activity'){
															if (array_key_exists($key, $arrStates)) echo ' '.$arrStates[$key]['count']; else echo 0;
														// }?>
												</td>
											</tr>
											<?php }}?>
									
										</table>
										<div class="filterSearchIcon"></div><input type="text" name="state_ids" class="autocompleteInputBox" id="state" value="Enter State" title=""/><input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
									</div>
							</li>
							<li id="categotyLists" class="category">
								<div class="refinedByCreateListIcon sprite_iconSet"></div><label class="categoryName">List</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
									<table>
										<tr class="allLists">
									 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_lists" id="allLists"  value="lists" <?php if(isset($selectedListName) && $selectedListName!=null && $selectedListName!=0) echo ''; else echo "checked='checked'"?> onclick="displaySelectedChart(this)"/>All Lists</td>
									 		<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $totalListCount."(".round(($totalListCount/$totalListCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($totalListCount)) echo round(($totalListCount/$totalListCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
									 		</td>
									 		<td><?php //if($reportSection=='activity'){
											 			if(isset($totalListCount)) echo $totalListCount; else echo 0;
											 		//	}
											 	?>
											 </td>											 
									 	</tr>
									<?php $i=0;
										foreach($arrListName as $arrListNameDetails){
											if($arrListNameDetails['list_name']!=''){?>
												<tr class="list<?php echo $arrListNameDetails['id'];?>">
											 		<td class="textAlignRight">
											 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo $arrListNameDetails['id'];?>" value="<?php echo $arrListNameDetails['id'];?>" onclick="displaySelectedChart(this)" 
														<?php
															if(isset($selectedListName[$arrListNameDetails['id']])){
																unset($selectedListName[$arrListNameDetails['id']]);
																echo 'checked="checked"';
															}
														?> 
														/>&nbsp;<?php echo $arrListNameDetails['list_name'];?>
											 		</td>
											 		<td class="histoGram">
											 			<div class="filterBar">
															<div class="progress" title="<?php echo $arrListNameDetails['count']."(".round(($arrListNameDetails['count']/$totalListCount)*100)."%)";?>">
																<div class="bar" style="width: <?php if(isset($totalListCount)) echo round(($arrListNameDetails['count']/$totalListCount)*100); else echo 0;?>%;"></div>
															</div>
														</div>
											 		</td>
											 		<td><?php //if($reportSection=='activity' ||$reportSection=='segmentation')
											 						echo $arrListNameDetails['count'];
											 			?></td>
											 	</tr>
									<?php $i++; if($i>3) break; }}?>
									<?php if((isset($selectedListName))&& ($selectedListName!=null)&& ($selectedListName!=0)){
											foreach($selectedListName as $key=>$listName){
												//$listName=trim($listName);
									?>
												<tr class="list<?php echo $key;?>">
											 		<td class="textAlignRight">
											 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo $key;?>" value="<?php echo $key;?>" checked="checked" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $listName;?>
											 		</td>
											 		<td class="histoGram">
											 			<div class="filterBar">
															<div class="progress" title="<?php echo $arrListName[$listName]['count']."(".round(($arrListName[$listName]['count']/$totalListCount)*100)."%)";?>">
																<div class="bar" style="width: <?php if(isset($allListCount)) echo round(($arrListName[$listName]['count']/$totalListCount)*100); else echo 0;?>%;"></div>
															</div>
														</div>
													</td>
													<td><?php //if($reportSection=='activity' ||$reportSection=='segmentation'){
																if (array_key_exists($listName, $arrListName)) echo ' '.$arrListName[$listName]['count']; else echo 0;
														//}?>
													</td>
											 	</tr>
										<?php }}?>
									</table>
									<div class="filterSearchIcon"></div><input type="text" name="list_name" class="autocompleteInputBox" id="listName" value="Enter List Name" title=""/><input type="hidden" name="list_name_id" id="listNameId" value="" />
								</div>
							</li>
						</ul>
					</form>
			
			</div>
		</div>