<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class json_stores extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('json_store');
		$this->load->model('helpers/common_helper');
	}
}
?>