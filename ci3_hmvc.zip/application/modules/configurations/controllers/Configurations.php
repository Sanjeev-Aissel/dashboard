<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Configurations extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('configuration');
		$this->load->model('helpers/common_helper');
	}
	function client_modules()
	{
		$data['arrClients'] =  $this->common_helper->getEntityById('clients',array ());
		$data['showNavBar']=true;
		$data['contentPage']='configurations/client_modules';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function load_grid_modules($client_id) {
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'id';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		$arrFilter['client_id']=$client_id;

		if(!$sidx) $sidx =1;
		$count= $this->configuration->getClientModules($start,$limit,$sidx,$sord,$arrFilter,true);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start<0) $start = 0;
		$resultSet = $this->configuration->getClientModules($start,$limit,$sidx,$sord,$arrFilter,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['module_name'] =$row['module_name'];
			$row['module_path'] =  $row['module_path'];
			$row['version'] =  $row['version'];
			$row['author'] = $row['author'];
			$row['assigned'] = $row['assigned'];
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function install_module()
	{
		$form_inputs_details[]=array('type'=>'file','label'=>array('label_name'=>'".zip" files only','required'=>1),'data'=>array('name'=>'module_import','id'=>'moduleImport','class'=>'form-control'));
		$form_details=array('is_multipart'=>1,
				'form_inputs_details'=>$form_inputs_details,
				'form_id'=>'moduleImportForm',
				'submit_function'=>'save_module();',
				'cancel_function'=>'closeModal();'
		);
		$data['html_form']=get_html_form($form_details);///cals helper function to get html content
		$this->load->view('install_module_new',$data);
	}
	function upload_zip_file() {
		$data	= array();
		$data ['message'] ="There was a problem with the upload. Please try again.";
		$data ['status']=false;	
		$module_name = $_FILES ["module_import"]["name"];
		$source		 = $_FILES ["module_import"]["tmp_name"];
		$name		 = explode ( ".", $module_name );
		$zip_path = APPPATH."documents/uploaded_modules/".$module_name;
		if(move_uploaded_file($source,$zip_path)){
			//move zip file to folder "uploaded_modules", unzip file, and delete zip file
				$zip = new ZipArchive ();
				$x = $zip->open($zip_path);
				if($x === true) {
					$zip->extractTo(APPPATH."documents/uploaded_modules/".$name[0]);
					$zip->close();
					
					$folders_in_unzipped_folder = scandir(APPPATH."documents/uploaded_modules/".$name[0]);
					foreach($folders_in_unzipped_folder as $folder){
						if ($folder!='' && $folder!='.' && $folder!='..') {
							$unzip_path = APPPATH."documents/uploaded_modules/".$name[0]."/".$folder;
						}
					}
					chmod($unzip_path,0777);
					unlink($zip_path);					
				}
				//find info.xml file which include module details and update module details to databse
				$xml_path= $unzip_path."/info.xml";
				chmod($xml_path,0777);
// 				pr($xml_path);
				if(file_exists($xml_path)){
					$xml=simplexml_load_file($xml_path) or die("Error: Cannot create object");
					$arrXmlDetails['module_name']=strtolower((string)$xml->name[0]);
					$arrXmlDetails['version']=(string)$xml->version[0];
					$arrXmlDetails['author']=(string)$xml->author[0];
					$arrXmlDetails['description']=(string)$xml->description[0];
					$arrXmlDetails['module_date']=(string)$xml->publish_date[0];
					if($this->configuration->insertOrUpdateModule($arrXmlDetails)){
						//find sql file, if exists, execute the file
						$sql_path=$unzip_path."/db_scripts.sql";
						if(file_exists($sql_path)) {
							$sql = file_get_contents($sql_path);
							$sqls = explode ( ';', $sql );
							array_pop($sqls);
							foreach ($sqls as $statement) {
								$statment = $statement . ";";
								$this->db->query($statement);
							}
						}
						//rename 'assets' folder with module name and move it to module assets folder
						$assests_old_path=$unzip_path.'/assets';
						if(file_exists($assests_old_path)){
							$assests_new_path=$_SERVER ['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path' ).MODULES_ASSETS.$arrXmlDetails['module_name'];
							rename($assests_old_path,$assests_new_path);//move assets folder
						}
						//rename 'module' folder with module name and move it to module folder
						$module_old_path=$unzip_path.'/module';
						$module_new_path=APPPATH.'modules/'.$arrXmlDetails['module_name'];
						rename($module_old_path,$module_new_path);//move module folder
						//move sql file in module
						$module_sql_path=APPPATH."modules/".$arrXmlDetails['module_name']."/db_scripts.sql";
						rename($sql_path,$module_sql_path);
						
						chmod($unzip_path,0777);						
						//move dependant modules to application's module folder
						$dependant_modules_old_path=$unzip_path.'/dependant_modules';
						$dependant_modules_folders = scandir($dependant_modules_old_path);						
						foreach($dependant_modules_folders as $file1){
							if ($file1!='' && $file1!='.' && $file1!='..') {
								$OriginalFile=$dependant_modules_old_path.'/'.$file1;
								$DestinationFile=APPPATH.'modules/'.$file1;
								rename($OriginalFile, $DestinationFile);
							}
						}
						$dependant_assets_old_path=$unzip_path.'/dependant_assets';
						$dependant_assets_folders = scandir($dependant_assets_old_path);
						foreach($dependant_assets_folders as $file2){
							if ($file2!='' && $file2!='.' && $file2!='..') {
								$OriginalFile=$dependant_assets_old_path.'/'.$file2;
								$DestinationFile=$_SERVER ['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path' ).MODULES_ASSETS.$file2;
								rename($OriginalFile, $DestinationFile);
							}
						}
						chmod($_SERVER ['DOCUMENT_ROOT'],0777);
						$data ['status']=true;	
						$data ['message'] ="Module is successfully instaled";
					}
				}else{
					$data ['message'] ="Missing XML file:Incomplete Data to install module,";
				}
				delete_files($unzip_path, true); // delete all files/folders
				rmdir($unzip_path);
		}
		echo json_encode($data);
	}
	function associate_or_disassociate_module() {
		$arrData ["module_id"] 		= $this->input->post('module_ids');
		$arrData ["client_id"] 		= $this->input->post('client_id');
		$arrData ["is_associate"] 	= $this->input->post('is_associate');
		$retdata ['status']			= $this->configuration->associateOrDissociateModuleToClient($arrData);
		echo json_encode($retdata);
	}
	function client_menus()
	{
		$data['showNavBar']=true;
		$data['arrClients'] =  $this->common_helper->getEntityById('clients',array ());
		$data['contentPage']='client_menus';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function list_client_menus($client_id) //to load list of users requests of jqgrid
	{
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'name';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		$arrFilter['client_id']=$client_id;
		if(!$sidx) $sidx =1;
		$count= $this->configuration->listClientMenuesJqgrid($start,$limit,$sidx,$sord,$arrFilter,true);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start<0) $start = 0;
		$resultSet = $this->configuration->listClientMenuesJqgrid($start,$limit,$sidx,$sord,$arrFilter,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['module_name'] =$row['module_name'];
			$row['label1'] = $row['is_landing_page']>0 ? $row['label'].'(Landing Page)':$row['label'];
			$row['is_primary'] =  $row['parent_id']>0 ? 'No':'Yes';
			$row['is_visible'] =  $row['is_visible']>0 ? 'Yes':'No';
			$row['primaryName'] = $row['primaryName'];
			$row['secondaryName'] = $row['secondaryName'];
			if($row['secondaryName']!=null){
				$temp = $row['secondaryName'];
				$row['secondaryName'] = $row['primaryName'];
				$row['primaryName'] = $temp;
			}
			$row['menu_location']="";
			if($row['primaryName']!=null){
				$row['menu_location'].=$row['primaryName'];
			}
			if($row['secondaryName']!=null){
				$row['menu_location'].='-->'.$row['secondaryName'];
			}
			if($row['primaryName']!=null){
				$row['menu_location'].='-->'.$row['label'];
			}
			else{
				$row['menu_location'].=$row['label'];
			}
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function generate_menu($client_id)
	{
		$responce['status']=false;
		$client_name=$this->common_helper->getClientNameByClientId($client_id);
		$client_name=strtolower($client_name);
		//---------------------//primary navigations//---------------------//
		$filePath=APPPATH.'views/custom_application_cache_files/'.$client_name.'/navigations/primary_navigation.php';
		if(!file_exists($filePath))
		{
			if (!is_dir($client_name))
			{
				$folderPath=APPPATH.'views/custom_application_cache_files';
				chmod($folderPath,0777);
				$folderPath=APPPATH.'views/custom_application_cache_files/'.$client_name.'/navigations';
				mkdir($folderPath,0777,true);
			}
		}
		$data=$this->common_helper->menuListing($client_id);
		$page_content=generate_prim_menu($data); //helper function
		$responce['status']=write_file($filePath,$page_content);
		//---------------------sec-navigations//---------------------//
		$secNavFilePath=APPPATH.'views/custom_application_cache_files/'.$client_name.'/navigations/secondary_navigation.php';
		chmod($secNavFilePath,0777);
		$secNavContent=generate_sec_menu($data); //helper function
		$responce['status']=write_file($secNavFilePath,$secNavContent);
		echo json_encode($responce);
	}
	function modal_to_add_menu()
	{
		$client_id=$_POST['client_id'];
		$menu_id=$_POST['menu_id'];
		$data['assignedModules'] =$this->configuration->getModulesList();
		$data['unassignedModules'] =$this->configuration->getUnassignedModulesOfClient($client_id);
		$data['prim_menus'] = $this->configuration->getMenusOfClient($client_id);
		$data['client_id'] =$client_id;
		if($menu_id!=null){
			$menudetails=$this->configuration->getMenuDeatilsByMenuId($menu_id);
		}
		if(isset($menudetails['prim_parent'])){
			if($menudetails['prim_parent']>0){
				$menu_level=3;
				$primary_menu_id=$menudetails['prim_parent'];
				$secondary_menu_id=$menudetails['parent_id'];
			}
			if($menudetails['prim_parent']==0){
				$menu_level=2;
				$primary_menu_id=$menudetails['parent_id'];
				$secondary_menu_id=0;
			}
		}
		else{
			$menu_level=1;
			$primary_menu_id=0;
			$secondary_menu_id=0;
		}
		$is_sec_nav_visible=($menudetails['is_sec_nav_visible']=='')?'1':$menudetails['is_sec_nav_visible'];
		$hidden_fields=array('client_id'=>$client_id,'menu_level'=>1,'menu_id'=>$menudetails['id']);
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'Module','required'=>1),'name'=>'module_id','data'=>array('id'=>'module_id','class'=>'required form-control'),'options'=>$data['assignedModules'],'selected'=>$menudetails['module_id']);
		$form_inputs_details[]=array('type'=>'text',     'label'=>array('label_name'=>'Menu-name','required'=>1),'data'=>array('name'=>'menu_name','id'=>'menu_name','class'=>'form-control','value'=>$menudetails['label']));
		$form_inputs_details[]=array('type'=>'text',     'label'=>array('label_name'=>'URL','required'=>1),'data'=>array('name'=>'url','id'=>'url','class'=>'form-control','value'=>$menudetails['url']));
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'Menu-level','required'=>0),'name'=>'menu_level_disabled','data'=>array('id'=>'menu_level_disabled','class'=>'required form-control','disabled'=>''),'options'=>array('1'=>'Primary','2'=>'Secondary','3'=>'Tertiary'),'selected'=>$menu_level);
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'Primary-menu','required'=>0),'name'=>'primary_menu_id','div_id'=>'select_primary_menu','data'=>array('id'=>'primary_menu_id','class'=>'form-control','onchange'=>'get_sec_menu();'),'options'=>$data['prim_menus'],'selected'=>$primary_menu_id);
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'Secondary-menu','required'=>0),'name'=>'secondary_menu_id','div_id'=>'select_secondary_menu','data'=>array('id'=>'secondary_menu_id','class'=>'form-control','onchange'=>'change_menu_level();'));
		$form_inputs_details[]=array('type'=>'text',     'label'=>array('label_name'=>'Order','required'=>0),    'data'=>array('name'=>'order','id'=>'order','class'=>'form-control','value'=>$menudetails['order']));
		$form_inputs_details[]=array('type'=>'radio',    'label'=>array('label_name'=>'Sub-navigation visibility','required'=>0),'value'=>$is_sec_nav_visible,'options'=>array('Yes'=>'1','No'=>'0'),'data'=>array('name'=>'is_sec_nav_visible','id'=>'is_sec_nav_visible'));
		$form_details=array('form_inputs_details'=>$form_inputs_details,
				'hidden_ids'=>$hidden_fields,
				'form_id'=>'client_module_association',
				'submit_function'=>'save_form();',
				'cancel_function'=>'close_dialog();'
		);
		$data['html_form']=get_html_form($form_details);///cals helper function to get html content
		$data['secondary_menu_id']=$secondary_menu_id;
		$this->load->view('add_menu',$data);
	}
	function mark_as_landing_page()
	{
		$data=$this->configuration->markAsLandingPage($_POST);
		echo json_encode($data);
	}
	function delete_menu_by_id($id)
	{
		$status = $this->configuration->deleteMenuById($id);
		if($status){
			$data['status'] = 1;
		}else{
			$data['status'] = 0;
		}
		echo json_encode($data);
	}	
	function save_menu()
	{
		$parent_id=0;
		$menu_level=0;
		$arrdata['id']	= $this->input->post('menu_id');
		$arrdata['label']	= $this->input->post('menu_name');
		$menu_level=$this->input->post('menu_level');
		if($menu_level==1){
			$parent_id=0;
		}
		else if($menu_level==2){
			$parent_id=$this->input->post('primary_menu_id');
		}
		else
			$parent_id=$this->input->post('secondary_menu_id');
			$arrdata['client_id']	=$this->input->post('client_id');
			$arrdata['module_id']	= $this->input->post('module_id');
			$arrdata['parent_id']	= $parent_id;
			$arrdata['order']		= $this->input->post('order');
			$arrdata['url']			= $this->input->post('url');
			$arrdata['is_sec_nav_visible']= $this->input->post('is_sec_nav_visible');
			$arrdata['is_visible']	=1;
			$data= $this->configuration->insertOrUpdatemenu($arrdata);
			echo json_encode($data);
	}
	function save_menu_visibility_changes()
	{
		$data=$this->configuration->updateMenuVisibility($_POST);
		return $data;
	}
	function get_sec_menu()
	{
		$clientId=$_POST['client_id'];
		$primMenuId=$_POST['primary_menu_id'];
		$data= $this->configuration->getMenusOfClient($clientId,$primMenuId);
		echo json_encode($data);
	}
	function client_roles()
	{
		$data['showNavBar']=true;
		$data ['arrClients']=  $this->common_helper->getEntityById('clients',array ());
		$data['contentPage']='client_roles';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function list_client_roles($client_id)
	{
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'name';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		$arrFilter['client_id']=$client_id;
		if(!$sidx) $sidx =1;
		$count= $this->configuration->listClientRoles($start,$limit,$sidx,$sord,$arrFilter,true);
		
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start<0) $start = 0;
		$resultSet = $this->configuration->listClientRoles($start,$limit,$sidx,$sord,$arrFilter,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['name'] =$row['name'];
			$row['description'] =$row['description'];
			
			if($row['assigned']==1)
				$row['assigned']="<span class='glyphicon glyphicon-stop module_assigned_green_signal'></span>";
			 else
			 	$row['assigned']="<span class='glyphicon glyphicon-stop module_assigned_red_signal'></span>";
		
			
			$row['action'] ='<a class="btn btn-sm btn-default" type="button" href="'.base_url().'configurations/configurations/getpermission/'.$row['id'].'"><i class="glyphicon glyphicon-edit"></i> EDIT</a>';
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function save_permission($role_id=NULL){
		//update db records
		$arrData['id']=$_POST['role_id'];
		$arrData['name']=$_POST['role_name'];
		$arrData['description']=$_POST['role_desc'];
		$id=$this->configuration->insertOrUpdateRole($arrData);
		//save permission values in file
		$permissions=$_POST['modules'];
		foreach($permissions as $key=>$value)
		{
			$permissionElements=explode('_',$value);
			$arrDetails[$permissionElements[0]][$permissionElements[1]]=1;
		}
		$filePath=APPPATH.'views/permission/'.$id.'.txt';
		if(!file_exists($filePath))
		{
			if (!is_dir($client_name))
			{
				$folderPath=APPPATH.'views';
				chmod($folderPath,0777);
				$folderPath=APPPATH.'views/permission/';
				mkdir($folderPath,0777,true);
			}
		}
// 		pr($arrDetails);
		$page_content= json_encode($arrDetails);
		$responce=write_file($filePath,$page_content);

		if($responce==true && $id>0){
			$returnData['status']=True;
			$returnData['message']='permission is successfully updated';
		}else{
			$returnData['status']=false;
			$returnData['message']='Error in setting permissions';
		}
		echo json_encode($returnData);
	}
	function associate_or_disassociate_role() {
		$arrData ["role_ids"] = $this->input->post('role_ids');
		$arrData ["client_id"] = $this->input->post('client_id');
		$arrData ["is_associate"] = $this->input->post('is_associate');
		$retdata['status']= $this->configuration->associateOrDissociateRoleToClient($arrData);
		echo json_encode($retdata);
	}
	function getpermission($role_id=NULL){
		$data['showNavBar']=true;
		$data['role_details']=NULL;
		$data['modules']= $this->common_helper->getEntityById('module_details', array());
		$data['role_actions']= $this->configuration->listRoleActions();
		$data['roles']= $this->configuration->listRoles($role_id);
		if($role_id!=null){
			$arrRoleDetails=$this->common_helper->getEntityById('roles', array ('id' => $role_id));
			$data['role_details']= $arrRoleDetails[0];
			$json = file_get_contents(APPPATH.'views/permission/'.$role_id.'.txt');
			$obj = json_decode($json,true);
			$data['rolesPermDetails']= $obj;
		}
		$data['contentPage']='permision_settings';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function add_module_action() {
		$arrData ['name'] = $this->input->post('action_name');
		$id=$this->common_helper->insertEntity('role_actions',$arrData);
		if($id>0)
			$retdata['status']=true;
		else
			$retdata['status']=false;
		echo json_encode($retdata);
	}
	function check_for_duplicate_name(){
		$retdata['isDuplicate']=$this->common_helper->checkDuplicate($_POST);
		echo json_encode($retdata);
	}
	function modal_to_add_module_action(){
		$this->load->view('add_module_action');
	}
	function delete_by_id() {
		$status = $this->common_helper->deleteById($_POST);
		if($_POST['table']=='roles'){
			$details['table']='client_roles';
			$details['column']='role_id';
			$details['value']=$_POST['id'];
			$this->common_helper->deleteByArrayOfDetails($details);
		}
		if($status){
			$data['status'] = 1;
		}else{
			$data['status'] = 0;
		}
		echo json_encode($data);
	}
	function clone_role(){
		$status=false;
		$source_file_content = file_get_contents(APPPATH.'views/permission/'.$_POST['clone_role_id'].'.php');
		$status =file_put_contents(APPPATH.'views/permission/'.$_POST['role_id'].'.php', $source_file_content);
		echo  $status;
	}
	function role_clone($role_id=NULL){
		$data['showNavBar']=true;
		$data['modules']= $this->common_helper->getEntityById('module_details', array());
		$data['role_actions']= $this->configuration->listRoleActions();
		$arrRoleDetails=$this->common_helper->getEntityById('roles', array ('id' => $role_id));
		$data['role_details']= $arrRoleDetails[0];
		$data['role_details']['id']=0;
		$data['role_details']['name']=$data['role_details']['name'].'_copy';
		$json = file_get_contents(APPPATH.'views/permission/'.$role_id.'.php');
		$obj = json_decode($json,true);
		$data['rolesPermDetails']= $obj;
		$data['contentPage']='permision_settings';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function try_hmvc(){
		echo CONSTANT_TESTING."<br>try_hmvc function in  configuration controller";
		echo modules::run('logins/try_hmvc2');
		echo "<br>try_hmvc function in  configuration controller";
	}
}