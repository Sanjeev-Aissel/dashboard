<?php

/**
 * 
 * @package application.models
 * @author Laxman K
 * @created on  08-03-2016
 */
class Customer_engagement extends model {

    private $activeStatus = 1;
    private $interactonType = array('' => 1, 'one' => 1, 'group' => 2);

    function Customer_engagement() {
        parent::model();
        $this->load->model('Client_User');
    }

    function getAllEngagementQuestions($interactionType = 1) {
        $arrReturnData = array();
        $this->db->select('customer_engagement_questions.id,customer_engagement_questions.question,customer_engagement_questions.question_type_id');
        $this->db->select('customer_engagement_question_type.name as question_type');
        $this->db->join('customer_engagement_question_type', 'customer_engagement_question_type.id=customer_engagement_questions.question_type_id', 'left');
        $this->db->where('customer_engagement_questions.status', $this->activeStatus);
        $this->db->where('customer_engagement_questions.interaction_type', $interactionType);
        $this->db->order_by('customer_engagement_question_type.sort_order', 'asc');
        $arrResultSet = $this->db->get('customer_engagement_questions');
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[$row['question_type_id']][] = $row;
        }
        return $arrReturnData;
    }

    function saveEngagement($arrData) {
        if ($this->db->insert('customer_engagements', $arrData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function insert_batch($tableName, $arrData = array()) {
        foreach ($arrData as $key => $arrRow) {
            $this->db->insert($tableName, $arrRow);
        }
    }

    function listEngagements($id = '', $filterData, $gridParam, $count = NULL, $interactionType = 1,$sd,$ed) {
        if ($id == '') {
            $rules = json_decode($filterData);
            foreach ($rules->rules as $values) {
                if ($values->field == "username")
                    $username = $values->data;
                if ($values->field == "therapeutic_area")
                    $specialty = $values->data;
                if ($values->field == "status")
                    $status = $values->data;
                if ($values->field == "date")
                    $date = $values->data;
                if ($values->field == "kol_id")
                    $kol_id = $values->data;
                if ($values->field == "evaluated_by")
                    $evaluated_by = $values->data;
                if ($values->field == "generic_id")
                    $generic_id = $values->data;
                if ($values->field == "group_name")
                    $group_name = $values->data;
                if ($values->field == "no_of_kols")
                    $no_of_kols = $values->data;
            }
        }

        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $arrCoaching = array();
        if ($count)
            $this->db->select('count(distinct customer_engagements.id) as count');
        else
            $this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,customer_engagements.*,organizations.name ,kols.first_name');
        $this->db->where('customer_engagements.interaction_type', $interactionType);
        $this->db->join('client_users', 'client_users.id=customer_engagements.user_id', 'left');
        $this->db->join('organizations', 'organizations.id=customer_engagements.org_id', 'left');
        $this->db->join('customer_engagement_kols ', 'customer_engagements.id=customer_engagement_kols.customer_engagement_id', 'left');
        $this->db->join('kols', 'kols.id=customer_engagement_kols.kol_id', 'left');
        if (isset($specialty)) {
            $this->db->like('customer_engagements.therapeutic_area', $specialty);
        }
        if (isset($username)) {
            $this->db->like('client_users.first_name', $username);
            $this->db->or_like('client_users.last_name', $username);
        }
        if (isset($status)) {
            $this->db->like('customer_engagements.status', $status);
        }
        if (isset($kol_id)) {
            $this->db->where('(kols.first_name LIKE "%' . $kol_id . '%" OR kols.last_name LIKE "%' . $kol_id . '%")');
        }
        if (isset($evaluated_by)) {
            $this->db->like('client_users.first_name', $evaluated_by);
            $this->db->or_like('client_users.last_name', $evaluated_by);
        }

        if (isset($date)) {
            $this->db->like('customer_engagements.date', $date);
        }

        if (isset($generic_id)) {
            $this->db->like('customer_engagements.generic_id', $generic_id);
        }
        if (!empty($id)) {
            $this->db->where('customer_engagements.id', $id);
        }
        if (!empty($group_name)) {
            $this->db->where('(customer_engagements.group_name LIKE "%' . $group_name . '%" OR organizations.name LIKE "%' . $group_name . '%")');
        }
        if (!empty($no_of_kols)) {
            $this->db->like('customer_engagements.no_of_kols', $no_of_kols);
        }

        //Security : user will see hi own data, manager will see his team data, and super manager will see all data
        if ($userRole == ROLE_USER) {
            $this->db->where('customer_engagements.user_id', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('customer_engagements.user_id', $userIds);
        }
        
          if ($sd != '') {
                    $this->db->where("customer_engagements.date >='" . $sd . "'");
                }
            if ($ed != '') {
                $this->db->where("customer_engagements.date <='" . $ed . "'");
            }

            if ($sd != '' && $ed!= '') {
                $this->db->where("customer_engagements.date >='" . $sd . "' and customer_engagements.date <='" . $ed . "'  ");
            }
        if(!$count)
        $this->db->group_by('customer_engagements.id');
        if ($id == '' && isset($gridParam)) {

//          $this->db->where('coachings.id >=',$gridParam['start']);
            if (!$count)
                $this->db->limit($gridParam["limit"], $gridParam['start']);
            switch ($gridParam['sidx']) {
                case "username":$this->db->order_by('client_users.first_name', $gridParam['sord']);
                    break;
                case "therapeutic_area":$this->db->order_by('customer_engagements.therapeutic_area', $gridParam['sord']);
                    break;
                case "status":$this->db->order_by('customer_engagements.status', $gridParam['sord']);
                    break;
                case "date":$this->db->order_by('customer_engagements.date', $gridParam['sord']);
                    break;
                case "group_name":$this->db->order_by('customer_engagements.group_name', $gridParam['sord']);
                    break;
                case "no_of_kols":$this->db->order_by('customer_engagements.no_of_kols', $gridParam['sord']);
                    break;
            }
        }

        $arrCoachingResultSet = $this->db->get('customer_engagements');
//echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
//            $kol=explode('</a>',$this->kolNameById($row['id']));
            $row['kol_id'] = $this->kolNameById($row['id']);
            if ($row['group_name'] == '')
                $row['group_name'] = $this->common_helpers->getOrgName($row['org_id']);
            $row['created_on'] = sql_date_to_app_date($row['created_on']);
            $row['username'] = $row['ufname'] . ' ' . $row['ulname'];
            $row['status'] = ucwords($row['status']);
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrCoaching[] = $row;
        }
//        pr($arrCoaching);
        return $arrCoaching;
    }

    function editCoaching($engId, $interaction_type) {

        $arrCoaching = array();
        $data = array();
        $this->db->select('customer_engagement_responses.* ');
        $this->db->where('customer_engagement_responses.customer_engagement_id', $engId);

        $arrCoachingResultSetResponses = $this->db->get('customer_engagement_responses');

        $this->db->select('customer_engagement_kols.kol_id ');
        $this->db->where('customer_engagement_kols.customer_engagement_id', $engId);

        $arrCoachingResultSetKols = $this->db->get('customer_engagement_kols');


        $this->db->select('customer_engagements.* ');
        $this->db->where('customer_engagements.id', $engId);
        $this->db->where('customer_engagements.interaction_type', $this->interactonType[$interaction_type]);

        $arrCoachingResultSetBasicDetails = $this->db->get('customer_engagements');


//        echo $this->db->last_query();
        foreach ($arrCoachingResultSetBasicDetails->result_array() as $row) {

            $row['evaluated_by'] = $this->Client_User->getUserNameById($row['created_by']);
            $row['date'] = sql_date_to_app_date($row['date']);
            if ($this->interactonType[$interaction_type] == 2)
                $row['org'] = $this->getOrgs($row['org_id']);
            $arrBasic[] = $row;
        }
        foreach ($arrCoachingResultSetKols->result_array() as $row) {

            $arrKols[] = $row['kol_id'];
        }





        $data['responses'] = $arrCoachingResultSetResponses->result_array();
        $data['kols'] = $arrKols;
        $data['basic'] = $arrBasic;

        return $data;
    }

    function deleteEngagement($engId) {
        $this->db->where("id", $engId);
        $this->db->delete('customer_engagements');

        $this->db->where("customer_engagement_id", $engId);
        $this->db->delete('customer_engagement_responses');

        $this->db->where("customer_engagement_id", $engId);
        $this->db->delete('customer_engagement_kols');
    }

    function getOrgs($id) {
        $this->db->select("organizations.id,organizations.name");
        $this->db->where('customer_engagements.org_id', $id);
        $this->db->join('organizations', 'organizations.id=customer_engagements.org_id', 'left');
        $arrCoachingResultSet = $this->db->get('customer_engagements');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->row_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function kolNameById($engId = '') {
        $data = array();
        $this->db->select('customer_engagement_kols.kol_id ');
        $this->db->where('customer_engagement_kols.customer_engagement_id', $engId);

        $arrCoachingResultSetKols = $this->db->get('customer_engagement_kols');
        $result = $arrCoachingResultSetKols->result_array();
        foreach ($result as $values) {
            $data[] = $values['kol_id'];
        }

        $kolIds = implode(',', $data);
        if ($kolIds == '')
            $kolIds = 0;

        $usernames = '';
//		$query				= "SELECT CONCAT_WS(' ',kols.".FIRST_ORDER.",kols.".SECOND_ORDER.",kols.".THIRD_ORDER.") as username FROM kols WHERE kols.id IN (".$userIds.")";
        $query = "SELECT kols.id,kols.first_name,kols.middle_name,kols.last_name FROM kols WHERE kols.id IN (" . $kolIds . ")";
        $arrKolUsersResultSet = $this->db->query($query);
//        echo $this->db->last_query();
        $separator = '';
        foreach ($arrKolUsersResultSet->result_array() as $usersRow) {

//			$usernames		.= $separator.$usersRow['username'];
            $usernames .= $separator . "<a href='" . base_url() . "kols/view/" . $usersRow['id'] . "' target='_blank' title=''>" . $this->common_helpers->get_name_format($usersRow['first_name'], $usersRow['middle_name'], $usersRow['last_name']) . "</a>";
            $separator = ', ';
        }
        return $usernames;
    }

    function exportCoaching($arrInteractionIds, $filters, $interactionType,$sd='',$ed='') {

        $arrFilterdCoachings = array();

        $arrFilter = json_decode($filters);
        $filtersToPass = json_encode($arrFilter->filters);

        $page = $arrFilter->page;
        $sidx = $arrFilter->sidx;
        $sord = $arrFilter->sord;
        $start = 10 * ($page - 1);

        $gridPageParam = array("page" => $page, "limit" => '', "sidx" => $sidx, "start" => $start, "sord" => $sord);

        $arrCoachings = $this->customer_engagement->listEngagements('', $filtersToPass, $gridPageParam, false, $this->interactonType[$interactionType],$sd,$ed);

      
        if ($interactionType == "one") {
            foreach ($arrCoachings as $key => $value) {
                if (($sd!='' || $ed!='') || (count($arrFilter->filters->rules) > 0 && count($arrCoachings) <= 10)  ) {
                    if (in_array($value["id"], $arrInteractionIds)) {
                        $arrFilterdCoachings[] = array("id" => $value["id"], "generic_id" => $value["generic_id"], "username" => $value["username"], "specialty" => $value["therapeutic_area"], "status" => $value["status"], "date" => $value["date"],"created_on" => $value["created_on"], "kol_id" => $value["kol_id"], "evaluated_by" => $this->common_helpers->getUserName($value["created_by"]));
                    }
                } else
                    $arrFilterdCoachings[] = array("id" => $value["id"], "generic_id" => $value["generic_id"], "username" => $value["username"], "specialty" => $value["therapeutic_area"], "status" => $value["status"], "date" => $value["date"],"created_on" => $value["created_on"], "kol_id" => $value["kol_id"], "evaluated_by" => $this->common_helpers->getUserName($value["created_by"]));
            }
        }
        else {
            foreach ($arrCoachings as $key => $value) {
                if (($sd!='' || $ed!='') || (count($arrFilter->filters->rules) > 0 && count($arrCoachings) <= 10) ) {
                    if (in_array($value["id"], $arrInteractionIds)) {
                        $arrFilterdCoachings[] = array("id" => $value["id"], "generic_id" => $value["generic_id"], "username" => $value["username"], "specialty" => $value["therapeutic_area"], "no_of_kols" => $value["no_of_kols"], "presentation_topic" => $value["presentation_topic"], 'hco' => $value['group_name'], "date" => $value["date"], "evaluated_by" => $this->common_helpers->getUserName($value["created_by"]));
                    }
                } else
                    $arrFilterdCoachings[] = array("id" => $value["id"], "generic_id" => $value["generic_id"], "username" => $value["username"], "specialty" => $value["therapeutic_area"], "no_of_kols" => $value["no_of_kols"], "presentation_topic" => $value["presentation_topic"], 'hco' => $value['group_name'], "date" => $value["date"], "evaluated_by" => $this->common_helpers->getUserName($value["created_by"]));
            }
        }
//        pr($arrFilterdCoachings);
//        exit;
        return $arrFilterdCoachings;
    }

    function getLatestCoachingIdByUser($userId, $interaction_type) {
        $coachingId = 0;
        $this->db->where('user_id', $userId);
        $this->db->where('interaction_type', $interaction_type);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $res = $this->db->get('customer_engagements');
//        echo $this->db->last_query();
        if (is_object($res) && $res->num_rows() > 0) {
            $row = $res->row_array();
            $coachingId = $row['id'];
        }
        return $coachingId;
    }
    
    function categoryFilterEngagement($cat,$filters) {
      
            $this->db->select(' user_id, count(user_id) as userCount,`client_users`.*,customer_engagements.date');
            $this->db->join('client_users', 'client_users.id=customer_engagements.user_id', 'left');
//            if (isset($filters['eng_name']))
//                $this->db->where_in("coachings.status ", $filters['eng_name']);
            if (isset($filters['thrp_name']))
            {
                 $this->db->where_in("customer_engagements.therapeutic_area", $filters['thrp_name']);
            }
                if ($filters['from'] != '') {
                    $this->db->where("customer_engagements.date >='" . $filters['from'] . "'");
                }
            if ($filters['to'] != '') {
                $this->db->where("customer_engagements.date <='" . $filters['to'] . "'");
            }

            if ($filters['to'] != '' && $filters['from'] != '') {
                $this->db->where("customer_engagements.date >='" . $filters['from'] . "' and customer_engagements.date <='" . $filters['to'] . "'  ");
            }
            if (isset($filters['msl_name']))
                $this->db->where_in("customer_engagements.user_id ", $filters['msl_name']);

            $this->db->limit();
            $this->db->group_by('user_id');
            $this->db->order_by('userCount', 'desc');
            $arrMsl = $this->db->get('customer_engagements');
//            echo $this->db->last_query();
        
    }
       function listEngagementReport($filters) {
        if ($filters['msl_auto'] != '') {
            $filters['msl_name'][] = $filters['msl_auto'];
        }
          $users=$this->common_helpers->getManagerAlignedUsers($filters['manager_id']);
        $userId = $this->session->userdata('user_id');
      $userRole = $this->session->userdata('user_role_id');
      $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
      $teamName = $this->common_helpers->getUserTeamName($userId);
      if($userRole == ROLE_USER){
          $this->db->where('client_users.id', $userId);
      }
      if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
          $this->db->where_in('client_users.id', $userIds);
      }
         
         
        $this->db->select('groups.group_name,client_users.is_activated,customer_engagements.id,customer_engagements.created_by as eval,customer_engagements.date,count(distinct customer_engagements.id) as entry_count ,client_users.*,customer_engagements.interaction_type,customer_engagements.user_id');
        $this->db->join('client_users', 'client_users.id=customer_engagements.user_id', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }

        if (isset($filters['msl_name']))
            $this->db->where_in("customer_engagements.user_id ", $filters['msl_name']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("customer_engagements.therapeutic_area", $filters['thrp_name']);
//        if (isset($filters['eng_name']))
//            $this->db->where_in("status", $filters['eng_name']);
        if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("customer_engagements.date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("customer_engagements.date <='" . $filters['to'] . "'");
        }
        if ($filters['to'] != '' && $filters['from'] != '') {
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
          $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
                $this->db->where("customer_engagements.date >='" . $filters['from'] . "' and customer_engagements.date <='" . $filters['to'] . "'  ");
            }
//        if (isset($filters['team_name']))
//            $this->db->where_in("groups.group_id", $filters['team_name']);
        if (isset($filters['type_name']))
            $this->db->where("customer_engagements.interaction_type", $filters['type_name']);
        
         if (isset($filters['manager_id']))
            $this->db->where("customer_engagements.user_id", $users);

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('customer_engagements.interaction_type');
         $this->db->group_by('customer_engagements.user_id');
        $this->db->order_by('entry_count', 'desc');

        $arrCoachingResultSet = $this->db->get('customer_engagements');
//		 echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {

            if ($row['is_activated'] == 1)
                $row['is_activated'] = 'Yes';
            else
                $row['is_activated'] = 'No';
           $row['evaluated_by'] = $this->Client_User->getUserNameById($row['eval']);
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = "<a style='cursor:pointer'  onclick='showFilterdGrid(".$row['user_id'].",".$row['interaction_type'].")'  title=''>" . $row['entry_count'] . "</a>";
            if($row['interaction_type']==1)
                    $row['interaction_type']="1:1";
            else
                    $row['interaction_type']="Group";  
      
            $arrCoaching[] = $row;
        }

        return $arrCoaching;

//                pr($arrCoaching);
    }
     function exportCustomerReport($arrCoachingIds, $filters) {

        $arrFilterdCoachings = array();
        $arrCoachings = $this->listEngagementReport($filters);

        foreach ($arrCoachings as $key => $value) {

            if (in_array($value["id"], $arrCoachingIds)) {
                $arrFilterdCoachings[] = array("id" => $value["id"],'active'=>$value["is_activated"], "username" => $value["username"], "entry_count" => $value["entry_count"], "group_name" => $value["group_name"],'evaluated_by'=>$value['evaluated_by'], "date" => $value["date"],'interaction_type'=>$value["interaction_type"]);
            }
        }

        return $arrFilterdCoachings;
    }  
    
    
    function listEngagementFilterdGrid($mslId,$interactionType,$from,$to){
        $filters=array();
        $filters['from']=$from;
        $filters['to']=$to;
           if ($id == '') {
            $rules = json_decode($filterData);
            foreach ($rules->rules as $values) {
                if ($values->field == "username")
                    $username = $values->data;
                if ($values->field == "therapeutic_area")
                    $specialty = $values->data;
                if ($values->field == "status")
                    $status = $values->data;
                if ($values->field == "date")
                    $date = $values->data;
                if ($values->field == "kol_id")
                    $kol_id = $values->data;
                if ($values->field == "evaluated_by")
                    $evaluated_by = $values->data;
                if ($values->field == "generic_id")
                    $generic_id = $values->data;
                if ($values->field == "group_name")
                    $group_name = $values->data;
                if ($values->field == "no_of_kols")
                    $no_of_kols = $values->data;
            }
        }

        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $arrCoaching = array();
        if ($count)
            $this->db->select('count(distinct customer_engagements.id) as count');
        else
            $this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,customer_engagements.*,organizations.name ,kols.first_name');
        $this->db->where('customer_engagements.interaction_type', $interactionType);
         $this->db->where('customer_engagements.user_id', $mslId);
        $this->db->join('client_users', 'client_users.id=customer_engagements.user_id', 'left');
        $this->db->join('organizations', 'organizations.id=customer_engagements.org_id', 'left');
        $this->db->join('customer_engagement_kols ', 'customer_engagements.id=customer_engagement_kols.customer_engagement_id', 'left');
        $this->db->join('kols', 'kols.id=customer_engagement_kols.kol_id', 'left');
        if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("customer_engagements.date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("customer_engagements.date <='" . $filters['to'] . "'");
        }
        if ($filters['to'] != '' && $filters['from'] != '') {
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
          $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
                $this->db->where("customer_engagements.date >='" . $filters['from'] . "' and customer_engagements.date <='" . $filters['to'] . "'  ");
            }
        if (isset($specialty)) {
            $this->db->like('customer_engagements.therapeutic_area', $specialty);
        }
        if (isset($username)) {
            $this->db->like('client_users.first_name', $username);
            $this->db->or_like('client_users.last_name', $username);
        }
        if (isset($status)) {
            $this->db->like('customer_engagements.status', $status);
        }
        if (isset($kol_id)) {
            $this->db->where('(kols.first_name LIKE "%' . $kol_id . '%" OR kols.last_name LIKE "%' . $kol_id . '%")');
        }
        if (isset($evaluated_by)) {
            $this->db->like('client_users.first_name', $evaluated_by);
            $this->db->or_like('client_users.last_name', $evaluated_by);
        }

        if (isset($date)) {
            $this->db->like('customer_engagements.date', $date);
        }

        if (isset($generic_id)) {
            $this->db->like('customer_engagements.generic_id', $generic_id);
        }
        if (!empty($id)) {
            $this->db->where('customer_engagements.id', $id);
        }
        if (!empty($group_name)) {
            $this->db->where('(customer_engagements.group_name LIKE "%' . $group_name . '%" OR organizations.name LIKE "%' . $group_name . '%")');
        }
        if (!empty($no_of_kols)) {
            $this->db->like('customer_engagements.no_of_kols', $no_of_kols);
        }

        //Security : user will see hi own data, manager will see his team data, and super manager will see all data
        if ($userRole == ROLE_USER) {
            $this->db->where('customer_engagements.user_id', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('customer_engagements.user_id', $userIds);
        }
        if(!$count)
        $this->db->group_by('customer_engagements.id');
        if ($id == '' && isset($gridParam)) {

//          $this->db->where('coachings.id >=',$gridParam['start']);
            if (!$count)
                $this->db->limit($gridParam["limit"], $gridParam['start']);
            switch ($gridParam['sidx']) {
                case "username":$this->db->order_by('client_users.first_name', $gridParam['sord']);
                    break;
                case "therapeutic_area":$this->db->order_by('customer_engagements.therapeutic_area', $gridParam['sord']);
                    break;
                case "status":$this->db->order_by('customer_engagements.status', $gridParam['sord']);
                    break;
                case "date":$this->db->order_by('customer_engagements.date', $gridParam['sord']);
                    break;
                case "group_name":$this->db->order_by('customer_engagements.group_name', $gridParam['sord']);
                    break;
                case "no_of_kols":$this->db->order_by('customer_engagements.no_of_kols', $gridParam['sord']);
                    break;
            }
        }

        $arrCoachingResultSet = $this->db->get('customer_engagements');
//echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
//            $kol=explode('</a>',$this->kolNameById($row['id']));
            $row['kol_id'] = $this->kolNameById($row['id']);
            if ($row['group_name'] == '')
                $row['group_name'] = $this->common_helpers->getOrgName($row['org_id']);
            $row['created_on'] = sql_date_to_app_date($row['created_on']);
            $row['username'] = $row['ufname'] . ' ' . $row['ulname'];
            $row['status'] = ucwords($row['status']);
             $row['evaluatedBy'] = $this->common_helpers->getUserName($row['created_by']);
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrCoaching[] = $row;
        }
//        pr($arrCoaching);
        return $arrCoaching;
    }
    
    function groupAlignmentCheck($managerId){
      
        $this->db->select('id');
        $this->db->where('user_id', $managerId);
         $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');
        $this->db->where('group_type', 'Field Group');
        $result=$this->db->get('user_groups');
      
        if(count($result->result_array())>0)
            return 1;
        else
            return 0;
    }
}
