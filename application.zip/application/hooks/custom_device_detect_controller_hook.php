<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Detect device and redirect accordingly
| -------------------------------------------------------------------------
| Author: Laxman K
| Since : 24-06-2015
*/
class Custom_device_detect{
    var $CI;
    var $moduleName;
    var $controllerName;
    var $methodName;
	function Custom_device_detect(){
    	$this->CI =& get_instance();
    	$this->CI->load->helper('url');
    	$this->moduleName	= $this->CI->uri->segment(1);
    	$this->controllerName	= $this->CI->uri->segment(2);
    	$this->methodName	= $this->CI->uri->segment(3);
    	require_once($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."application/libraries/mobile_device_detect.php");
    }
    function app_redirect_based_on_device(){
    	//Get the Mobile Platform details from the library 'mobile_device_detect'
		$mobile = mobile_device_detect();
//		pr($mobile);	
//		exit;
		//Get the Browser Details from the php native funtion 'get_browser'  using 'browsecap.ini'
		//$browser=get_browser(null, true);

		//Get the Browser Details from 'Browscap.php' file
		//As of now we are not using the functionalities provided by this, remove the comments if u want to use
		// Creates a new Browscap object (loads or creates the cache)
		//$bc = new Browscap($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."system/cache");				
		// Gets information about the current browser's user agent
		//$browser = $bc->getBrowser();
		
		if( ($this->moduleName== 'login' || $this->moduleName == '') && $this->controllerName==''  && $this->methodName==''){
			//echo 'Platform : '.$mobile[1];
			//exit;
			if(isset($mobile[1])){
				if($mobile[1] == 'Apple iPad'){
					redirect(base_url().MOBILE_URL_SEGMENT."login");
				}else{
					redirect(base_url().MOBILE_URL_SEGMENT."login");
				}
			}
		}
    }
}