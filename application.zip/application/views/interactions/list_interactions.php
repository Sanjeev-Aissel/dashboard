<?php

/**

 * This is HTML page which lists all the Interactions of the perticular client

 * 

 * @author Ramesh B

 * @Created on: 01-03-11

 * @since  1.5	

 */



?>

<?php

	// prepare array of JS files to insert into queue

	$queued_js_scripts =array('interactions/list_interactions',

							'i18n/grid.locale-en',

							'jquery.jqGrid.min',

							'jquery/jquery.validate1.9.min',

							'jquery/jquery-ui-1.8.16.slider',

							'jquery/jquery-ui-1.8.16.datepicket',

							'jquery-ui-timepicker-addon 0.9.3',

							'CalendarControl',

							'chosen.jquery'

							);

	// add the JS files into queue i.e Append to the existing queue

	$prevjs = $this->config->item('js_files_to_load');

	if($prevjs == null)

		$prevjs = array();

	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));

?>

	<!-- JQGrid Plugins -->

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />

	<!-- Month Year Selection Calendar plugin -->

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />

	<script type="text/javascript">

		var interactionsTitle = "<?php echo lang("Track.Interactions");?>";

		var date = "<?php echo lang("Overview.Date");?>";

		var action = "<?php echo lang("Overview.Action");?>";

		var type = "<?php echo lang("Overview.Type");?>";

		var recordedBy = "<?php echo lang("track.RecordedBy");?>";

		var channel = "<?php echo lang("Overview.Channel");?>";

		var product = "<?php echo lang("Overview.Product");?>";

		var paymentsTitle = "<?php echo lang("Overview.Payments");?>";

		var requestedBy = "<?php echo lang("Overview.requestedBy");?>";

		var paidBy = "<?php echo lang("Overview.paidBy");?>";

		var amount = "<?php echo lang("Overview.amount");?>";

		jqgridIds	= new Array('listInteractionsResultSet');

		

	</script>

	<style type="text/css">

		/*    Enable Verticle separator between content and side menu list  By Laxman   */

		#contentWrapper.span-23 {

			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");

		    background-position: 135px 50%;

		    background-repeat: repeat-y;

		}

		.ui-tabs-vertical .ui-tabs-nav {

			margin-left: 0px;

		}

		.listResultSet a{

			text-decoration:none;

			text-align:left;

			float:left;

		}

		tr.selectedRow {

		    background-color: #D8DFEA !important;

		}

		.addLink {

			width:auto;

			float: right;

		}

		.addLink label{

			margin-top: -20px;

		}

		.toggleBtnWrapper{

			width: auto;

			margin-top: 1px;

		}

		#interactionsTernaryNav{

			width: 124px;

		}

/*		#interactionsContainer, #addEditInteractionWrapper{

			width: 805px;

			margin-top: -75px;

			margin-top: 0px;

			float: right;

		}*/

		#timeLineSliderContainer{

			margin-bottom: 0px;

		}

		#timeLineSliderContainer p {

			margin-top: 0px;

		}

		#timeLineSliderContainer p input[type="text"]{

			margin: 1px 0px 0px 0px;

		}

		div#contentHolder{

			width: auto !important;

			min-width: 260px;

			max-width: 600px;

		}

		.ui-datepicker-calendar {

		    display: none;

		}

		.buttonsWarpper{

			float: right;

			width: 266px;

		}

		#addInteractionContainer,#editInteractionContainer, #viewInteractionContainer{

			display:none;

			min-height: 400px;

			min-width: 400px

		}

	</style>

	

	<!--[if IE]>

	<style type="text/css">

		.toggleBtnWrapper{

			margin-top: 3px;

		}

	</style>

	<![endif]-->

<div id="container">

	<div id="addEditInteractionWrapper">

		<div id="addInteractionContainer"></div>

		<div id="editInteractionContainer"></div>

		<div id="viewInteractionContainer"></div>

	</div>

	<div id="interactionsContainer">

		<?php //if($this->session->userdata('kolId')==-1){?>

			<div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">

				<div class="exportOptionsContainer">

					<ul class="pageRightOptions">

						<li>

							<label for=monthlyreport>Month From :</label>

							<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />

							<label for=monthlyreport>To:</label>

							<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />

							<input type="button" value="Apply Filter" id="filterbutton" onclick="reloadInteractions()" />

						</li>

						<li>

							<input type="button" onClick="toggleKolGrouping('listInteractionsResultSet', 'toggleKolGrouping');" value="Remove Grouping" name="toggleKolGrouping" id="toggleKolGrouping" />

						</li>

						<!-- <li>

							<label class="link" onclick="addInteraction();"><div class="actionIcon addIcon"></div>Add Interaction</label>

						</li> -->

						<li>

							<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();">

								<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>

							</div>

						</li>

					</ul>

				</div>

			</div>

		<!-- <div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">

				<div class="buttonsWarpper">

					<div class="toggleBtnWrapper">

						<input type="button" onClick="toggleKolGrouping('listInteractionsResultSet', 'toggleKolGrouping');" value="Remove Grouping" name="toggleKolGrouping" id="toggleKolGrouping" />

					</div>

					<div class="addLink">

						<label onclick="addInteraction();" style="margin-right: 28px;"><div class="actionIcon addIcon"></div>Add Interaction</label>

						<div style="margin-top: -20px;float: right;" class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();">

							<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>

						</div>

					</div>

					

				</div>

				<p style="margin-bottom:5px;width:550px;vertical-align: middle;">

					<label for=monthlyreport>Month From :</label>

					<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />

					<label for=monthlyreport>To:</label>

					<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />

					<input type="button" value="Apply Filter" id="filterbutton" onclick="reloadInteractions()" />

				</p>

			</div>

		 -->

		<?php //}?><!--

		<div class="toggleBtnWrapper">

			<input type="button" onClick="toggleKolGrouping('listInteractionsResultSet', 'toggleKolGrouping');" value="Remove Grouping" name="toggleKolGrouping" id="toggleKolGrouping" />

			<div class="addLink"><label onclick="addInteraction();" id="addButton"><div class="actionIcon addIcon"></div>Add Interaction</label></div>

		</div>

		

		-->

			<form action="<?php echo base_url()?>interactions/export_interaction_details" method='post' id="export">

				<input type="hidden" name="interaction_ids" value="" id='ids'></input>

				<input type="hidden" name="filters" id="excel-filters" />

			</form>

		<div id="interactionsList" class="clear">

			<div class="gridWrapper" id="gridContainer">

				<div id="listInteractionsPage"></div>

				<table id="listInteractionsResultSet"></table>

			</div>

			<!-- Container for the 'Interaction Micro Profile' modal box -->

			<div id="dailog1">	

				<div id="interactionMicroProfile" class="microProfileDialogBox">

					<div class="profileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Micro Profile' modal box -->

			<!-- Container for the 'Interaction Add' modal box -->

			<div id="dailog2">	

				<div id="interactionAddContainer" class="microProfileDialogBox">

					<div class="profileContent" id="interactionAddProfileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Addd' modal box -->

			<!-- Container for the 'Interaction Micro Edit' modal box -->

			<div id="dailog3">	

				<div id="interactionEditContainer" class="microProfileDialogBox">

					<div class="profileContent" id="interactinEditProfileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Edit' modal box -->

		</div>

		<div id="interactionsReports">

		

		</div>

		<!-- Container for the 'Micro Profile'  box -->

		<div id="contentHolder" class="callOutTest microView" style="display: none;">

			<div>

				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>

				<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />

			--></div>

			<div class="profileContent"></div>

		</div>

		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>

	</div>

</div>