<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code{
    	width: 192px;
    }
    #org_type{
    	width: 207px;
    }
</style>
<script type="text/javascript">
    var validationRules = {
		state_license_number: {
			required: true
		},
		country_id:{
			required: true
		}
    };
    var validationMessages = {
        state_license_number: {
            required: "Required"
        },
        country_id:{
			required: "Required"
		}
    };
    $('#saveKolStateLicense').click(function () {
        if (!$("#saveKolStateLicenseForm").validate().form()) {
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $id = '<?php if($displayContent) echo $getSavedDetails['id'];?>';
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_state_license/'+$id,
            type: 'post',
            dataType: 'json',
            data: $('#saveKolStateLicenseForm').serialize(),
            beforeSend: function(){
    			$("#saveKolStateLicense").attr("disabled", "disabled");
            },
            success: function (returnData) {
                if (returnData.status == true) {
                    $('.msgBox').html('<?php echo lang("KOL"); ?> State License saved successfully');
                    $('.msgBox').fadeOut(1500);
                    ReloadGrid();
                } else {
                    $('.msgBox').html('Error saving <?php echo lang("KOL"); ?> State License');
                    $('.msgBox').fadeOut(1500);
                }
            }
        });
    });
    function ReloadGrid() {
    	$('#saveKolStateLicense').removeAttr("disabled");
        $("#addStateLicenseForKols").dialog("close");
        getStateLicenceData();
    }
    /**
     * Returns the list of States of the Selected Country ID
     */
    function getStatesByCountryIdLicense() {
        $("#saveKolStateLicenseForm #loadingStates").show();
        var countryId = $('#saveKolStateLicenseForm #country_id').val();
        var params = "country_id=" + countryId;
        $("#saveKolStateLicenseForm #state_id").html("<option value=''>-- Select State --</option>");
        var states = document.getElementById("saveKolStateLicenseForm").elements.namedItem("state_id");
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                $.each(responseText, function (key, value) {
                    var newState = document.createElement('option');
                    newState.text = value.state_name;
                    newState.value = value.state_id;
                    var prev = states.options[states.selectedIndex];
                    states.add(newState, prev);
                });
                
                $("#saveKolStateLicenseForm #state_id option[value='']").remove();
                $("#saveKolStateLicenseForm #state_id").prepend("<option value=''>-- Select State --</option>");
                $("#saveKolStateLicenseForm #state_id").val("");
            },
            complete: function () {
                $("#saveKolStateLicenseForm #loadingStates").hide();
            }
        });
    }

</script>
<div class="msgBox"></div>

<div id="similarNames">

</div>
<h4 style="border-bottom: 1px solid #bbbbbb;">State License</h4>

<form action="save_kol_state_license" method="post" id="saveKolStateLicenseForm" name="saveKolStateLicenseForm">
    <table class="requestedKols">
        <tbody>
            <tr>
                <td style="width: 50%;">
                    <table style="te">
						<tr>
							<td class="alignRight"><label for="state_license_number">Number<span class="required">*</span> :</label></td>
							<td>
								<input type="text" name='state_license_number' class="required" id='state_license_number' value="<?php if(isset($getSavedDetails['state_license'])) echo $getSavedDetails['state_license'];?>"/>
							</td>
						</tr>
                        <tr>
                            <td class="alignRight"><label for="license_is_primary">Is Primary :</label></td>
                            <td>
								<input type="checkbox" name="license_is_primary" id='license_is_primary' <?php if($displayContent && $getSavedDetails['is_primary']=='1') echo "checked class='ui-disabled'";?>/>
       							<input type="hidden" name="contact" value="<?php echo $kolId; ?>"/>
                            </td>
                        </tr>
                    </table>
                </td>

                <td>
                    <table>
                    	<tr>
                            <td class="alignRight">
                                <label for="country_id">Country<span class="required">*</span> :</label>
                            </td>
                            <td>
                            	<select name="country_id" id="country_id" onchange="getStatesByCountryIdLicense();" class="required">
                                        <option value="">-- Select Country --</option>
                                        <?php 
                                        //$selectedCountryId	= $countryID;
                                        if($displayContent && isset($getSavedDetails['country_id']) && $getSavedDetails['country_id']>0){
                                        	$selectedCountryId	= $getSavedDetails['country_id'];
                                        }
                                        foreach ($arrCountries as $country) { ?>
                                            <option value="<?php echo $country['country_id']; ?>"
                                            <?php
                                            if ($selectedCountryId == $country['country_id'])
                                                echo "selected";
                                            ?>
                                            >
                                            <?php echo $country['country_name']; ?>
                                            </option>
                                        <?php } ?>
                                </select>
                                <img id="loadingStates" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="state_id">State :</label>
                            </td>
                            <td>
                                <select name="state_id" id='state_id'>
					            <option value="">--Select--</option>
					            <?php foreach ($arrStates as $state) { ?>
                                        <option value="<?php echo $state['state_id']; ?>" 
                                        <?php
                                        if($displayContent && $getSavedDetails['region'] > 0 && $getSavedDetails['region'] == $state['state_id'])
                                                echo 'selected';
                                        ?>>
                                        <?php echo $state['state_name']; ?>
                                        </option>
						           <?php } ?>
						        </select>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- End of Personal and Professional Information -->
        </tbody>
    </table>
<table>
	<tbody>
	    <tr>
	        <td colspan="2">
	            <div class="formButtons">
            			<input type="button" value="Save" name="submit" id="saveKolStateLicense"></input>
	            </div>
	        </td>
	    </tr>
	</tbody>
</table>

</form>