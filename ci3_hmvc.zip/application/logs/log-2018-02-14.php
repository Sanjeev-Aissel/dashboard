<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-14 15:53:32 --> Config Class Initialized
INFO - 2018-02-14 15:53:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:53:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:53:32 --> Utf8 Class Initialized
INFO - 2018-02-14 15:53:32 --> URI Class Initialized
INFO - 2018-02-14 15:53:32 --> Router Class Initialized
INFO - 2018-02-14 15:53:32 --> Output Class Initialized
INFO - 2018-02-14 15:53:32 --> Security Class Initialized
DEBUG - 2018-02-14 15:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:53:32 --> Input Class Initialized
INFO - 2018-02-14 15:53:32 --> Language Class Initialized
INFO - 2018-02-14 15:53:32 --> Language Class Initialized
INFO - 2018-02-14 15:53:32 --> Config Class Initialized
INFO - 2018-02-14 15:53:32 --> Loader Class Initialized
INFO - 2018-02-14 15:53:32 --> Helper loaded: url_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: file_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: form_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: email_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: html_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: date_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: xml_helper
INFO - 2018-02-14 15:53:32 --> Helper loaded: path_helper
INFO - 2018-02-14 15:53:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:53:32 --> Upload Class Initialized
INFO - 2018-02-14 15:53:32 --> Email Class Initialized
INFO - 2018-02-14 15:53:32 --> Controller Class Initialized
INFO - 2018-02-14 15:53:32 --> Model Class Initialized
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/kols/models/Kol.php
INFO - 2018-02-14 15:53:32 --> Model Class Initialized
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/logins/models/Login.php
INFO - 2018-02-14 15:53:32 --> Model Class Initialized
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/helpers/models/Country_helper.php
INFO - 2018-02-14 15:53:32 --> Model Class Initialized
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/helpers/models/Common_helper.php
INFO - 2018-02-14 15:53:32 --> Model Class Initialized
DEBUG - 2018-02-14 15:53:32 --> Pagination Class Initialized
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/views/layouts/client/settings.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/views/custom_application_cache_files/aissel/navigations/primary_navigation.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/kols/views/export_options.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/views/custom_application_cache_files/aissel/navigations/secondary_navigation.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/kols/views/kols.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/modules/kols/views/right_side_bar.php
DEBUG - 2018-02-14 15:53:32 --> File loaded: /var/www/html/hmvc/application/views/layouts/client/header.php
INFO - 2018-02-14 15:53:32 --> Final output sent to browser
DEBUG - 2018-02-14 15:53:32 --> Total execution time: 0.0694
