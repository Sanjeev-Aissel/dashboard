<?php 
/**
 * 
 * View page contains List of Processed KOls
 * @author Vinayak
 * @since 4.2
 * @package application.view.requested_kols
 * @created 13-6-2012
 */
?>

<p>
Hello,</p><p>

Your profiling requests have been processed, Please click on the link(s) below and login to KOLM to access the profiles.
</p>
<?php   foreach($arrKols as $row){

	?>
<br />
<p><b><?php echo lang("KOL");?> Name : <?php echo $row['first_name']." ".$row['middle_name']." ".$row['last_name'] ?></b></p>
<br />
<a href="<?php echo base_url()?>kols/view/<?php echo $row['kol_id']?>" target="_NEW">View Profile</a>
<?php }?>
<br />
<p>Thanks,</p>
<p>KOLM Support</p>