<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Payments extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('payment');
		$this->load->model('helpers/common_helper');
	}
	function list_payments_by_date_range($startDate='',$endDate='',$kolId=null){
		$page			= (int)$this->input->post('page'); // get the requested page
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrPayments	= array();
		$data			= array();
		$clientId		= $this->session->userdata('client_id');
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId			= 0;
		if($this->session->userdata('user_role_id')==ROLE_USER){
			$userId		= $this->session->userdata('user_id');
		}
		$arrPayments	= array();
		$toalAmount = 0;
		$dropDownValues 		= 	$this->get_payment_dropdown_values();
		$arrPaymentCurrencies	=	$dropDownValues['arrPaymentCurrencies'];
		if($kolId == null)
			$kolId = $this->input->post('kol_id');
		if($arrPaymentsResults=$this->payment->listPaymentDetails($clientId,$kolId,$userId,$startDate,$endDate)){
			foreach($arrPaymentsResults as $arrPaymentResult){
				$arrSplitPayments = $this->payment->getPayementTypeAndAmount($arrPaymentResult['id']);
				$totalPayments = sizeof($arrSplitPayments);
				if($totalPayments>1){
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'].' +';
				}else{
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'];
				}
				$arrSplitPayments = $this->payment->getPayementTypeAndAmount($arrPaymentResult['id']);
				$totalPayments = sizeof($arrSplitPayments);
				if($totalPayments>1){
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'].' +';
				}else{
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'];
				}
				
				$arrPayment['eAllowed'] = $this->common_helper->isActionAllowed('payment', 'edit', $arrPaymentResult);
				$arrPayment['dAllowed'] = $this->common_helper->isActionAllowed('payment', 'delete', $arrPaymentResult);
				$arrPayment['date']		= sql_date_to_app_date($arrPaymentResult['date']);
				
				if($arrPayment['date']=="00/00/0000"){
					$arrPayment['date']	= '';
				}
				
				$arrPayment['id']				= $arrPaymentResult['id'];
				$arrPayment['reason']			= $arrPaymentResult['reason'];
				$arrPayment['created_by_full_name']	= $arrPaymentResult['created_by_full_name'];
				$arrPayment['requested_by']		= $arrPaymentResult['requested_by'];
				$arrPayment['paid_by']			= $arrPaymentResult['paid_by'];
				$toalAmount = $toalAmount+$arrPayment['amount'];
				$arrPayment['kol_name']			= $arrSalutations[$arrPaymentResult['salutation']]." ".$this->common_helper->get_name_format($arrPaymentResult['first_name'],$arrPaymentResult['middle_name'],$arrPaymentResult['last_name']);
				$arrPayment['kol_id'] = $arrPaymentResult['kol_id'];
				$arrPayment['unique_id'] = $arrPaymentResult['unique_id'];
				$arrPayment['kol_name_link'] = $arrPayment['kol_name'];
				$arrPayment['status'] = $arrPaymentResult['status'];
				$arrPayment['client_id'] = $arrPaymentResult['client_id'];
				$arrPayment['created_by_full_name'] = $arrPaymentResult['created_by_full_name'];
				$arrPayment['data_type_indicator'] = $arrPaymentResult['data_type_indicator'];
				$arrPayment['kol_deleted'] = $arrPaymentResult['kol_deleted'];
				$arrPayments[]					= $arrPayment;
			}
		}
		$count	= sizeof($arrPayments);
		if( $count >0 ){
			$total_pages	= ceil($count/$limit);
		}else{
			$total_pages	= 0;
		}
		$data['records']	= $count;
		$data['total']		= $total_pages;
		$data['page']		= $page;
		$data['rows']		= $arrPayments;
		$userdata['amount'] = "Total: ".$toalAmount;
		$userdata['paid_by'] = "";
		$data['userdata'] = $userdata;
		echo json_encode($data);
	}
	function get_payment_dropdown_values(){
		$clientId						= $this->session->userdata('client_id');
		$userId							= $this->session->userdata('user_id');
		$data['arrPaymentPaidBy'] 		= $this->payment->getAllPaymentsPaidBy();
		$data['arrPaymentRequestBy']	= $this->payment->getAllPaymentsRequestedBy();
		//Get all Payment Types for the Drop down
		$data['arrPaymentTypes']		= $this->payment->getAllPaymentTypes();
		$data['arrPaymentCurrencies']	= $this->payment->arrPaymentCurrencies();
		//Get all Interaction-Id for the Drop down
		$data['arrInteractionIds']		= $this->payment->getAllInteractionIds($clientId,$userId);
		//Get all kols name and id for the Drop down
		$arrKol 						= $this->payment->getAllKolsName();
		$data['arrKol']					= $arrKol;
		return $data;
	}
	function delete_payment($paymentId = null){
		$kol_details = $this->payment->getPaymentById($paymentId);
		$isDeleated = $this->payment->deletePaymentById($paymentId);
		echo $isDeleated;
	}
	function add_payment($kolId=null, $paymentId = null,$isFrom = false){
		$data 										= array();
		$data['arrPayment']							= array();
		$no_of_fields=1;
		if($paymentId!= null){
			$arrPaymentDetail 						= $this->payment->getPaymentById($paymentId);
			$arrPaymentDetail['arrTypesAndAmount'] 	= $this->payment->getPayementTypeAndAmount($paymentId);
			$no_of_fields 							= count($arrPaymentDetail['arrTypesAndAmount']);
			//get user details
			$arrUserDetails							= $this->common_helper->getEntityById('client_users',array('id'=>$arrPaymentDetail['created_by']));
			$arrUserDetails							= $arrUserDetails[0];
			$arrPaymentDetail['user_name']			= $arrUserDetails['user_name'];
		}
		//get kol details
		if($kolId!=null){
			$this->load->model('kols/kol');
			$kolId									= $this->common_helper->getKolClientVisiblityId($kolId);
			$arrKolDetails 							= $this->kol->editKol($kolId);
			$arrPaymentDetail['kol_id']				= $arrKolDetails['kols_client_visibility_id'];
			$arrPaymentDetail['kol_name']			=$arrKolDetails['first_name'].' '.$arrKolDetails['middle_name'].' '.$arrKolDetails['last_name'];
			//get speciality details of KOL
			$specialtytDetails						=$this->common_helper->getEntityById('specialties',array('id'=>$arrKolDetails['specialty']));
			$arrPaymentDetail['specialty_id']		=$specialtytDetails[0]['id'];
			$arrPaymentDetail['specialty_name']		=$specialtytDetails[0]['specialty'];
			//get title details of KOL
			$arrTitleDetails						=$this->common_helper->getEntityById('titles',array('id'=>$arrKolDetails['title']));
			$arrPaymentDetail['title_id']			=$arrTitleDetails[0]['id'];
			$arrPaymentDetail['title_name']			=$arrTitleDetails[0]['title'];
		}
		$data['arrPayment']							=$arrPaymentDetail;
		$data['noOfFields'] 						=$no_of_fields;
// 		//Get all DropDown values for Payment
		$dropDownValues 							=$this->get_payment_dropdown_values();
		$data['arrPaymentTypes']					=$dropDownValues['arrPaymentTypes'];
		$data['arrPaymentCurrencies']				=$dropDownValues['arrPaymentCurrencies'];
		$data['arrPaymentPaidBy']					=$dropDownValues['arrPaymentPaidBy'];
		$data['arrPaymentRequestBy']				=$dropDownValues['arrPaymentRequestBy'];
		
		$data['contentPage'] 						='add_payment';
		$data['contentData']						=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function get_kol_other_details($kolId = null,$isAjaxCall=true){
		if ($kolId == null || $kolId == '') {
			$kolName = $this->input->post('kol_name');
			$kolId = $this->kol->getKolId($kolName);
		}
		$arrKolDetails = $this->kol->getKolDetailsById($kolId);
		$data['specialtyId'] = $arrKolDetails[0]['specialty'];
		$data['title'] = $arrKolDetails[0]['title'];
		$data['specialtyName'] = $this->specialty->getSpecialtyById($data['specialtyId']);
		$data['last_interaction'] = $this->interaction->getKolLastInteractionById($kolId);
		if($isAjaxCall)
			echo json_encode($data);
		else 
			return $data;
	}
	function export_payment_details($kolId=null){
		$sheets=array();
		$data=array();
		
		$clientId		= $this->session->userdata('client_id');
		$userId=$this->session->userdata('user_id');
		$paymentIds= $this->input->post('payment_ids');
		$arrPaymentIds = explode(',',$paymentIds);
		
		$sheet['title']					='Payments';
		$arrPayments[0] = array('Date','KTL Name','Requested By','Paid By','Amount','Recorded By');
		if($arrPaymentsResults=$this->payment->exportPaymentDetails($clientId,$kolId,$userId,$startDate,$endDate,$arrPaymentIds)){
			foreach($arrPaymentsResults as $arrPaymentResult){
				$arrPayment['date']		= sql_date_to_app_date($arrPaymentResult['date']);
				if($arrPayment['date']=="00/00/0000"){
					$arrPayment['date']	= '';
				}
				$arrPayment['kol_name']	=$arrSalutations[$arrPaymentResult['salutation']]." ".$arrPaymentResult['first_name']." ".$arrPaymentResult['middle_name']." ".$arrPaymentResult['last_name'];
				$arrPayment['requested_by']		= $this->payment->getPaymentRequestedBy($arrPaymentResult['requested_by']);
				$arrPayment['paid_by']			= $this->payment->getPaymentPaidBy($arrPaymentResult['paid_by']);
				$arrSplitPayments = $this->payment->getPayementTypeAndAmount($arrPaymentResult['id']);
				$totalPayments = sizeof($arrSplitPayments);
				if($totalPayments>1){
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'].' +';
				}else{
					$arrPayment['amount'] = $arrPaymentCurrencies[$arrSplitPayments[0]['currency']]['currency_symbol'].' '.$arrSplitPayments[0]['indAmount'];
				}
				$toalAmount = $toalAmount+(int)$arrPayment['amount'];
				$arrPayment['reason']			= $arrPaymentResult['created_by_full_name'];
				$arrPayments[]					= $arrPayment;
			}
		}
		$sheet['content']				=$arrPayments;
		$sheets[]=$sheet;
		$userName = $this->common_helper->getEntityById('client_users',array('id'=>$userId));
		$userName =$userName[0]['user_name'];
		$fileName = $userName."_".$kolName."_payments.xls";

		$arr_export_details['file_name']	=$fileName;
		$arr_export_details['sheets']		=$sheets;
		export_as_xls($arr_export_details);
	}
	
	function save_payment1(){
		// Getting the POST details of Payment
		$date							=$this->input->post('date');
		$paymentDetails = array(
				'id'					=>	trim($this->input->post('payment_id')),
				'date'					=> 	(empty($date)?'':app_date_to_sql_date($date)),
				'reason'				=>	ucwords(trim($this->input->post('reason'))),
				'requested_by'          => 	trim($this->input->post('requested_by')),
				'paid_by'               => 	trim($this->input->post('paid_by'))
		);
		
		$arrKols = $this->payment->getAllKolsName1();
		
		$kolName = 	trim($this->input->post('kol_name'));
		$kolId = $this->input->post('kol_id');
		if(!is_numeric($kolId)){
			$kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
		}
		$paymentDetails['kol_id'] = $kolId;
		if($paymentDetails['kol_id']==''){
			$paymentDetails['kol_id'] = array_search($kolName,$arrKols);
		}
		if($paymentDetails['kol_id']==''){
			//$kolSaved=false;
			$kolSaved='';
			$checkCamma = strpos($kolName,',');
			$kolDetail=array();
			if($checkCamma!=''){
				$kolNameExplodeBy = explode(',',$kolName);
				//pr($kolNameExplodeBy);
				if(sizeOf($kolNameExplodeBy)==1){
					$kolDetail['first_name'] = $kolNameExplodeBy[0];
				}
				if(sizeOf($kolNameExplodeBy)==2){
					$kolDetail['last_name'] = $kolNameExplodeBy[0];
					$kolDetail['first_name'] = $kolNameExplodeBy[1];
				}
				if(sizeOf($kolNameExplodeBy)==3){
					$kolDetail['last_name'] = $kolNameExplodeBy[0];
					$kolDetail['first_name'] = $kolNameExplodeBy[1];
					$kolDetail['middle_name'] = $kolNameExplodeBy[2];
				}
				$checkKolname = $kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
				$kolId = array_search($checkKolname,$arrKols);
				if($kolId==''){
					$kolDetail['created_by'] = $this->session->userdata('user_id');
					$kolDetail['status'] = PRENEW;
					$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
				}else{
					$paymentDetails['kol_id'] =$kolId;
				}
				$kolSaved = 'Saved';
			}
			if($kolSaved!='Saved'){
				$splitByspace = explode(" ",$kolName);
				if(sizeOf($splitByspace)==2){
					$kolDetail['first_name'] = $splitByspace[0];
					$kolDetail['last_name'] = $splitByspace[1];
				}
				if(sizeOf($splitByspace)==3){
					$kolDetail['first_name'] = $splitByspace[0];
					$kolDetail['middle_name'] = $splitByspace[1];
					$kolDetail['last_name'] = $splitByspace[2];
				}
				if(sizeOf($splitByspace)>3){
					$kolDetail['first_name'] = $splitByspace[0];
					$kolDetail['middle_name'] = $splitByspace[1];
					$kolDetail['last_name'] = $splitByspace[2]." ". $splitByspace[3];
				}
				$kolDetail['created_by'] = $this->session->userdata('user_id');
				$kolDetail['status'] = PRENEW;
				$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
			}
		}
		$arrCurrencies= $this->input->post('currency');
		$arrAmounts= $this->input->post('amount');
		$arrTypes= $this->input->post('type');
		$totalAmount=0;
		foreach ($arrTypes as $key=>$type){
			$arrTypesAndAmounts['currency'] = $arrCurrencies[$key];
			$arrTypesAndAmounts['amount'] 	= $arrAmounts[$key];
			$arrTypesAndAmounts['type'] 	= $type;
			
			$totalAmount+=$arrAmounts[$key];
			$arrPaymentDetails[]=$arrTypesAndAmounts;
		}
		$paymentDetails['amount'] =$totalAmount;
		$payment_id=$this->payment->updatePayment($paymentDetails);
		if($payment_id>0){
			$this->payment->updateTypeAndAmount($payment_id,$arrPaymentDetails);
			//New Added Records trigger mail to asssigned users
// 			$arrReturnResult	= $this->payment->getAssignedUsersForType($paymentDetails['kol_id']);
// 			$user_email	= $arrReturnResult['user_details'];
// 			$type_name	= $arrReturnResult['type_name'];
// 			$urlLink = '<a href="'.base_url().'kols/kols/view/'.$paymentDetails['kol_id'].'/payments">click here</a>';
// 			$arrConfig = $this->common_helpers->getMailConfig(USER,PASS);
// 			$arrInfo = array (
// 					'FROM' => USER,
// 					'FROM_NAME' => SENDER,
// 					'TO' => $user_email,
// 					'CC' => array(""),
// 					'SUBJECT' => "New Payment : $type_name",
// 					'MAIL_BODY' => "<html>
// 					<head>
// 					<style>
// 					table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
// 					td, th { border: 1px solid #CCC; height: 30px; }
// 					th { background: #F3F3F3; font-weight: bold; }
// 					td { background: #FAFAFA; text-align: center;}
// 					</style>
// 					</head>
// 					<body>
// 					<div>
// 					Hi, <br/><br/> This is a notification about a payment that has been recorded with $type_name.<br><br>
// 					Please $urlLink to view the payment.<br/><br/>
// 					<br>Regards,<br>Aissel Support Team<br>
// 					</div>
// 					</body>
// 					</html>"
// 			);
// 			$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
			$data1['saved'] = true;
			$data1['msg'] = "Payments details are successfully updated.";
		}else{
			$data1['saved'] = false;
			$data1['msg'] = "Error in updating Payment details.";
		}
		echo json_encode($data1);
	}
	function list_kol_payments($kolId=null){
		// Getting the KOL details
		$this->load->model('kols/kol');
		if($kolId!=null){
			//if it unique_id
			if(!(is_numeric($kolId))){
				$kolId= $this->common_helper->getKolClientVisiblityId($kolId);
			}
			$arrKolDetail 						= $this->kol->editKol($kolId);
			// If there is no record in the database
			if (!$arrKolDetail) {
				return false;
			}
			$arr_option_data['kol_id']			=$arrKolDetail['kols_client_visibility_id'];
			$arr_option_data['kol_unique_id']	=$arrKolDetail['kols_client_visibility_unique_id'];
			$data['arrKol'] 					= $arrKolDetail;
			
			if($this->common_helper->check_module("align_users")){
				$this->load->model('align_users/align_user');
				$arr_option_data['assignedUsers'] 	=$this->align_user->getAssignedUsers($kolId);
			}
			
			$data['options_page']				='kols/export_options_within_kol';
			$data['options_data']				=$arr_option_data;
		}
		$module_name						='payments';
		$data['module_id']					=$this->common_helper->getModuleIdByModuleName($module_name);
		
		$data['contentPage'] 				='list_kol_payments';
		$data['contentData']				=$data;
		
		$this->load->view(CLIENT_LAYOUT,$data);
	}
}
?>