<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery-ui-1.8.16/ui/jquery.ui.accordion', 'chosen.jquery',
    'jquery/jquery.validate1.9.min','jquery/jquery.maskedinput.min',
    'jQuery.ptTimeSelect/src/jquery.ptTimeSelect');


// add the JS files into queue i.e Append to the existing queue
$prevjs = $this->config->item('js_files_to_load');
if ($prevjs == null)
    $prevjs = array();
$this->config->set_item('js_files_to_load', array_merge($prevjs, $queued_js_scripts));

$currentMethod = $this->uri->segment(4);

?>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />
<link href="<?php echo base_url(); ?>js/jQuery.ptTimeSelect/src/jquery.ptTimeSelect.css" media="screen" rel="stylesheet" />
<style>
    #location th {
        text-align: center !important;;
    }
    .ui-jqgrid-title {
        font-size: 13px;
    }
    #time {
        width: 80px;
    }
    .time_data_view tr td{
        text-align: center;
    }
    .time_data_view {
        margin-top: 27px;
    }
    #bestTime>tbody>tr>th{
        border-left: 1px solid #ddd;
    } 
    #bestTime>tbody>tr>th:last-child{
        border-right: 1px solid #ddd;
    } 

    th>span.required{
        color: red !important;
    }
    .saveIcon {
        /*background: url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat scroll -223px -30px rgba(0, 0, 0, 0) !important;*/
    }
    #detailsContainer table h6, #dispShortDetail caption, .sectionHeaderTitle {
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
        box-shadow: 0 0 4px #d1d1d1 inset;
        font-weight: bold;
        color: #222222;
        padding: 4px 10px 4px 5px;
    }
    #detailsContainer table td{
        vertical-align: top;
    }
    #phoneForm table tr td:last{
        width: 50px;
    }
    #detailsContainer form A span, .add_time_data a span {
        /*background: transparent url("<?php echo base_url(); ?>/images/all_icons.png") repeat scroll 24% 36%;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;*/

        background: url("<?php echo base_url(); ?>/images/add_active.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }
    #detailsContainer form A span:hover, .add_time_data a span:hover{ 
        background: url("<?php echo base_url(); ?>/images/add_inactive.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }


    .add_time_data a span {
        margin-right: 11px;
    }

    #detailsContainer form A:hover > span{
        background: url("<?php echo base_url(); ?>/images/add_inactive.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }
    #detailsContainer form > a.actionIcon {
        margin-top: -15px;
    }
    #dispShortDetail th{
        width: 150px;
        vertical-align: top;
        text-align: right;
    }
    #gridWrapper tr th{
        text-align: center !important;
    }
    #dispShortDetail td{
        vertical-align: top;
    }
    .is_kol_no{
        background-image: url("<?php echo base_url(); ?>images/delete.gif");
        background-repeat: no-repeat;
        display: inline-block;
        width: 20px;
    }
    .is_kol_yes{
        background-image: url("<?php echo base_url(); ?>images/approve.png");
        background-repeat: no-repeat;
        display: inline-block;
        width: 20px;
    }
    #dispShortDetail td img, #detailsContainer td img{
        height: 20px;
        width: 20px;
        cursor: pointer;
        margin-left: 3px;
    }
    .alignRight{
        text-align: right !important;
    }
    #bestTime th {
        text-align: center;
        vertical-align: top;
    }
    .ui-widget-header {
        color: #222222;
        font-weight: bold;
    }
    #best_time td{
        padding:0px !important;
    }

    .time_picker_last {
        left: 1035px !important;
    }

    #disp_phones tr td{
        width: 20%;
    }
    #disp_phones tr th{
        width: 20%;
    }
    #phone_table tr td{
        width: 20%;
    }
    #disp_staffs tr td{
        width: 20%;
    }
    #disp_staffs tr th{
        width: 20%;
    }
    #staff_table tr td{
        width: 20%;
    }
    #disp_emails tr td{
        width: 25%;
    }
    #disp_emails tr th{
        width: 25%;
    }
    #email_table tr td{
        width: 25%;
    }
    #disp_licenses tr td{
        width: 	25%;
    }
    #disp_licenses tr th{
        width: 	25%;
    }
    #license_table tr td{
        width: 	25%;
    }
    #disp_status tr td{
        width: 	20%;
    }
    #disp_status tr th{
        width: 	20%;
    }
    #key_status_table tr td{
        width: 	20%;
    }
     #kol_form .error {
        /* background-image: url(../images/error_medium.gif); */
        background-position: 10px center;
        background-repeat: no-repeat;
        padding: initial !important;
        display: inline;
    }
    #kol_form .error, #kol_form .notice, #kol_form .success {
        padding: .8em;
        background:transparent !important;
        margin-bottom: 0em !important;
    }
    #kol_form table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
        font-weight: bold;
        color: #222222;
    }

    #kol_form td label{
        display: block;
        text-align:right;
        padding-right:6px;
        padding-top:2px;
    }
    #kol_form input[type='text']{
        width: 200px;
    }

    #kol_form select{
        width: 210px;
    }
    .contact_restrictions label {
        display: inline-block !important;
        width: 150px;
    }
    .contact_restrictions td {
        text-align: center;
    }
    .ui-disabled{
		opacity: .3;
	    cursor: default!important;
	    pointer-events: none;
	}
	table{
		margin-bottom:0px;
	}
	table.tabularGrid caption {
	    background: #ececec;
	    color: #111111;
	    padding-top: 0px;
	    box-shadow: 0 0 4px #d1d1d1 inset;
	    font-size: 13px;
	    padding: .3em .2em .2em .3em;
	    line-height:21px;
	}
	table.tabularGrid {
		border:0px;
    	border-bottom: 2px solid #DDDDDD;
	}
	
    <?php
    if($subContentPage=='add'){
        echo '#contentWrapper.span-23{
            background-image:none !important;
        }';
    }
    ?>
</style>

<script type="text/javascript">
var primaryStateId = '';
var primaryCityId = '';
var previous_time = "";
var emailCount=0;var phoneCount=0;
$(function () {
	 var validationRules = {
	            first_name: {
	                required: true
	            },
	            last_name: {
	                required: true
	            },
	            /*
	            prof_suffix: {
	                required: true
	            },
	            */
	            specialty: {
	                required: true
	            },
	            address1: {
	                required: true
	            },
	            country_id: {
	                required: true
	            },
	            /*
	            postal_code: {
	                required: true
	            },
	            
	            city_id: {
	                required: true
	            },*/
	            organization: {
	                required: true
	            },
	            email: {
	                officialemail: true
	            },
	            npi_num: {
	                npinumber: true
	            },
	            phone_number_loc: {
	                phnumber : true
	            }
	        };
	        var validationMessages = {
	            first_name: {
	                required: "Required"
	            },
	            last_name: {
	                required: "Required"
	            },
	            /*
	            prof_suffix: {
	                required: "Required"
	            },
	            */
	            specialty: {
	                required: "Required"
	            },
	            address1: {
	                required: "Required"
	            },
	            country_id: {
	                required: "Required"
	            },
	            /*
	            postal_code: {
	                required: "Required"
	            },
	            city_id: {
	                required: "Required"
	            },*/
	            organization: {
	                required: "Required"
	            },
	            npi_num: {
	                npinumber: "Enter 10-digit NPI number"
	            }
	            
	        };
    $("#kol_form").validate({
        debug: true,
        onkeyup: false,
        rules: validationRules,
        messages: validationMessages
    });

    jQuery.validator.addMethod("officialemail", function (value, element) {
        if (value != "") {
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(value);
        } else {
            return true;
        }
    }, "Invalid email");

    jQuery.validator.addMethod("npinumber", function (value, element) {
        if (value != "") {
            var regex = /^([0-9]){10}$/;
            return regex.test(value);
        } else {
            return true;
        }
    }, "Invalid NPI Number");
       
    var phoneMsg = '';
    jQuery.validator.addMethod("phnumber", function (value, element) {      
    	  	                            
        if (value != "") {
        	var  phoneVal= document.getElementById("phone_type").value;
           	if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")||(phoneVal=="Office Phone")){
                var regex =/^(?=.*[0-9])[-+0-9]+$/;     
                if(regex.test(value)){                	
                	var number = value.replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing                	                	
                	if(number.length>15){
                		phoneMsg ="Max 15 Digit";
                    	return false;
                	}	
                	phoneMsg = '' ;               	
                	return true;                	    	
                }else{
                	phoneMsg ="Invalid Phone Number";	               		
                 	return false;
                }               	
           	}else{  
           		if(phoneVal==''){            		
           			//phoneMsg = 'Select Phone Type';
           			$('#phone_type_loc').text("Select Phone Type");		
               		return false;
               	}
           		phoneMsg = '' ;
               	return true;
            }
        } else {            	
            return true;
        }
        
    }, function(params, element) {
    	  return phoneMsg;
    });     

    $('#products').chosen({
        placeholder_text: 'Click to Select <?php echo lang("Overview.Product");?>' ,
        allow_single_deselect: true
    });
    $('#prof_suffix').chosen({
        placeholder_text: "Click to Select Suffix",
        allow_single_deselect: true
    });

    $('#sub_specialty').chosen({
        placeholder_text: "Click to Select Sub Specialty",
        allow_single_deselect: true
    });
     $('#is_speaker_product').chosen({
        placeholder_text: "Click to Select Speaker Product",
        allow_single_deselect: true
    });

});
    function selectPhone() {
            var  phoneVal= document.getElementById("phone_type").value;
            if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")){
                $("#phone_number").mask("(999) 999-9999", {autoclear: false});
            }
            else if(phoneVal=="Office Phone"){
                $("#phone_number").mask("(999) 999-9999? x99999", {autoclear: false});
            }
            else{
                $("#phone_number").unmask();
            }
    }
   	
    var previous_time = "";
    var temp_current_method = '<?php echo $currentMethod; ?>';
    var staff_row = "";
    var phone_row = "";
    var email_row = "";
    var license_row = "";
    var status_row = "";
    
    
    /**
     * Returns the list of States of the Selected Country ID
     */
    function getStatesByCountryId() {
    	$("#postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingStates").show();
        var countryId = $('#country_id').val();
        var params = "country_id=" + countryId;
        
        var selectedStateId = primaryStateId;
       // alert(selectedStateId +'$$'+primaryStateId);
        $("#state_id").html("<option value=''>-- Select State --</option>");
        $("#city_id").html("<option value=''>-- Select City --</option>");
        var states = document.getElementById('state_id');
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
            	var selectedIndex	= '';
                $.each(responseText, function (key, value) {
                    /* var newState = document.createElement('option');
                    newState.text = value.state_name;
                    newState.value = value.state_id;
                    var prev = states.options[states.selectedIndex];
                    states.add(newState, prev); */
                    selectedIndex	= '';
					if(selectedStateId>0 && selectedStateId===value.state_id){
						selectedIndex	= ' selected="selected"';
					} 
					 $('#state_id').append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
                });
              /*   $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val(""); */
                if(primaryCityId > 0){
                	getCitiesByStateId();
                }
            },
            complete: function () {
                $("#loadingStates").hide();
            }
        });
    }

    /**
     * Returns the list of Cities of the Selected State
     */
    function getCitiesByStateId() {
    	$("#postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingCities").show();        
        $("#city_id").html("<option value=''>-- Select City</option>");
        var cities = document.getElementById('city_id');
        stateId = $("#state_id").val();        
        var params = "state_id=" + stateId;
        if(stateId == ''){
			//$("#loadingCities").hide();
			//return false;
		}
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
            	if(responseText==''){
                    $('#cityDiv').html('');
                    $('#cityDiv').html('<input type="text" name="city_id" id="city_id" class="required" placeholder="Enter City" />');
                }else{
                    $('#cityDiv').html('');
                	$('#cityDiv').html('<select name="city_id" id="city_id" class="required" placeholder="Enter City"><option value="">-- Select City --</option></select>');                   
                	setTimeout(function(){ 	
                		var selectedIndex	= '';
                        $.each(responseText, function (key, value) {                	
                           /* var newCity = document.createElement('option');
                            newCity.text = value.city_name;
                            newCity.value = value.city_id;
                            var prev = cities.options[cities.selectedIndex];
                            cities.add(newCity, prev);*/
                            //$('#city_id').append("<option value='"+value.city_id+"'>"+value.city_name+"</option>");
                        	 selectedIndex	= '';
         					if(primaryCityId>0 && primaryCityId===value.city_id){
         						selectedIndex	= ' selected="selected"';
         					} 
         					 $('#city_id').append('<option value="'+value.city_id+'"'+selectedIndex+'>'+value.city_name+'</option>');
                        });
//                         $("#city_id option[value='']").remove();
//                         $("#city_id").prepend("<option value=''>-- Select City --</option>");
//                         $("#city_id").val("");
                        
                	}, 30);
                }
            },
            complete: function () {
                $("#loadingCities").hide();
            }
        });
    }
    var locationGridOptions = {
        caption: "Locations",
        //url:''+base_url+'kols/list_education_grid_details/honors_awards/'+kolId,
        colNames: ['Id', '', '', 'Institution', 'Address', 'City','State', 'Postal Code', 'Address Type','','', '','', action,'created_by_full_name','client_id','data_type_indicator'],
        colModel: [
            {name: 'id', index: 'id', hidden: true},
            {name: 'micro', resizable: true, width: 20},
            {name: 'is_primary', index: 'is_primary', resizable: true, width: 20},
            {name: 'org_name', index: 'org_name', resizable: true, width: 200},
            {name: 'address', index: 'address', resizable: true, width: 200},
            {name: 'city', index: 'city', resizable: false, width: 80},
            {name: 'state', index: 'state', resizable: false, width: 80},
            {name: 'postal_code', index: 'postal_code', resizable: true, width: 80},
            {name: 'address_type', index: 'address_type', resizable: false, width: 100,hidden:true},
            {name: 'created_by', index: 'created_by', hidden: true},
            {name: 'eAllowed', index: 'eAllowed', hidden: true},
            {name: 'dAllowed', index: 'dAllowed', hidden: true},
            {name: 'is_primary_value', index: 'is_primary_value', hidden: true},
            {name: 'act', resizable: true, width: 70},
            {name:'created_by_full_name',index:'created_by_full_name', hidden:true},
            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
        ],
//        pager: '#listLocationPages',
        sortname: 'address',
        rowNum: 10,
        rownumbers: true,
        rowList: [10, 20],
        gridComplete: function () {
            var ids = jQuery("#JQBlistLocationResultSet").jqGrid('getDataIDs');
            for (var i = 0; i < ids.length; i++) {
                var primaryLable = '';
                var actionLink = '';
                var cl = ids[i];
                var isAnalyst = jQuery("#JQBlistLocationResultSet").jqGrid('getCell',cl,'client_id');
                var createdByName = jQuery("#JQBlistLocationResultSet").jqGrid('getCell',cl,'created_by_full_name');
                var rowData = jQuery("#JQBlistLocationResultSet").jqGrid('getRowData', cl);
                if(isAnalyst != 1 && isAnalyst != ''){                    
                	actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
		    	}else{
		    	//	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
		    		var dataTypeIndicator = jQuery("#JQBlistLocationResultSet").jqGrid('getCell',cl,'data_type_indicator');
		    		actionLink += data_type_indicator(dataTypeIndicator);		    		
		    	}
                var is_prime = '';
                if(rowData.is_primary_value == 1){
                	is_prime = 1;
                }
                if ((rowData.eAllowed == 'true')) {
                    actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"editLocation('" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
                }
                if ((rowData.dAllowed == 'true')) {
                    actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteLocation('" + cl + "','"+is_prime+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
                }
            
                jQuery("#JQBlistLocationResultSet").jqGrid('setRowData', ids[i], {act: actionLink});

                microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewLocationSnapshot('" + cl + "'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Location Snapshot\"></a></div></label>";
                jQuery("#JQBlistLocationResultSet").jqGrid('setRowData', ids[i], {micro: microviewLink});

            }
            jQuery("#JQBlistLocationResultSet").jqGrid('navGrid', 'hideCol', "id");
            //Initialize the tooltips
            initializeCustomToolTips();
        }
    };
    var action = "<?php echo lang("Overview.Action"); ?>";
    var commonJQGridOptions = {
            datatype: "local",
            mtype: "post",
            rowNum: 10,
            autowidth: true,
            width: "100%",
            rownumbers: true,
            loadonce: true,
            ignoreCase: true,
            hiddengrid: false,
            resizeable: true,
            height: "auto",
            viewrecords: true,
            sortorder: "desc",
            jsonReader: {repeatitems: false, id: "0"}

        };
function getLocationDataOnPageLoad(){
	$('#gridWrapperLocation').html('');
 	$('#gridWrapperLocation').html('<table id="JQBlistLocationResultSet"></table>');
	var ele = $('#location').width();
    var gridWidth = ele.clientWidth;
    /*
     *jqgrid for Locations  table
     */
    jQuery("#JQBlistLocationResultSet").jqGrid($.extend(commonJQGridOptions, locationGridOptions));
    jQuery("#JQBlistLocationResultSet").jqGrid('setGridWidth', gridWidth);

    $.ajax({
        url: base_url + 'kols/list_locations/' + kolId,
        type: 'post',
        dataType: 'json',
        success: function (returnData) {

            if (!isCustomerProfile) {
                if (returnData.locations != null) {
                    for (var i = 0; i < returnData.locations.length; i++) {
                        jQuery("#JQBlistLocationResultSet").jqGrid('addRowData', returnData.locations[i]['id'], returnData.locations[i]);
                    }
                }
            }
        },
        complete: function () {
            //$('#load_JQBlistContactsResultSet').css('display','none');
            if (!isCustomerProfile) {
                $('#load_JQBlistLocationResultSet').css('display', 'none');
            }
        }
    });
}
function showSpeakerProduct(thisEle){
    if($(thisEle).val()==1){
        $("#speaker_product").show();
    }
    else
        $("#speaker_product").hide();
        
}
function getPhoneNumberData(){
	/*
     *jqgrid for Phone Number  table
     */
    $('#gridWrapperPhone').html('');
 	$('#gridWrapperPhone').html('<table id="JQBlistPhoneNumberResultSet"></table>');
    jQuery("#JQBlistPhoneNumberResultSet").jqGrid({
	    	url: base_url + 'kols/list_kol_details/phone/' + kolId,
	   		datatype: "json", 
	   		colNames: ['Id', 'Phone Type', 'Locations', 'Phone Number', 'Is Primary','','','', action,'created_by_full_name','client_id','data_type_indicator'],
	   		colModel:[
	   				{name:'id',index:'id', hidden:true, search:false,align:'left'},
	   				{name:'phone_type',index:'phone_type',search:true,align:'left'},
	   		   		{name:'name',index:'name',search:true,align:'left'},
	   		   		{name:'number',index:'number',search:true,align:'left'},
	   				{name:'is_primary',index:'is_primary',search:true,align:'center'},
	   				{name: 'created_by', index: 'created_by', hidden: true},
	   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
	   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
	   				{name: 'act', resizable: true, width: 60},
	   				{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
	   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
	   		   	  ], 
	   		   sortname: 'name',
	           rowNum: 10,
	           mtype: "POST",
	           autowidth: true,
	           rownumbers: true,
	           loadonce:true,    	           		   
    		   sortorder: "desc",
	           height: "auto",
	           rowList: [10, 20],
	           caption:"Phone Numbers",
	           gridComplete: function () {
	               var ids = jQuery("#JQBlistPhoneNumberResultSet").jqGrid('getDataIDs');
	               for (var i = 0; i < ids.length; i++) {
	            	   var actionLink = '';
	                   var cl = ids[i];
	                   var isAnalyst = jQuery("#JQBlistPhoneNumberResultSet").jqGrid('getCell',cl,'client_id');
	                   var createdByName = jQuery("#JQBlistPhoneNumberResultSet").jqGrid('getCell',cl,'created_by_full_name');
	                   var rowData = jQuery("#JQBlistPhoneNumberResultSet").jqGrid('getRowData', cl);
                        if(isAnalyst != 1){                    
                       		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                        }else{
                        //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                        	var dataTypeIndicator = jQuery("#JQBlistPhoneNumberResultSet").jqGrid('getCell',cl,'data_type_indicator');
                        	actionLink += data_type_indicator(dataTypeIndicator);		    		
                        }
	                   var is_prime = '';
	                   if(rowData.is_primary == 'Yes'){
	                   	is_prime = 1;
	                   }
	                   if ((rowData.eAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"addPhoneNumber('edit','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
	                   }
	                   if ((rowData.dAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"addPhoneNumber('delete','" + cl + "','"+is_prime+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
	                   }
	                   jQuery("#JQBlistPhoneNumberResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	                   phoneCount++;
	               }
	               //Initialize the tooltips
	               initializeCustomToolTips();
	           }
		}); 
}
function getStaffsData(){
	/*
     *jqgrid for Staff  table
     */
    $('#gridWrapperStaff').html('');
  	$('#gridWrapperStaff').html('<table id="JQBlistStaffResultSet"></table>');
    jQuery("#JQBlistStaffResultSet").jqGrid({
	       	url: base_url + 'kols/list_kol_details/staff/' + kolId,
	      	datatype: "json", 
	      	colNames: ['Id', 'Title', 'Locations', 'Name','Email', 'Phone Type', 'Phone Number','','','', action,'created_by_full_name','client_id','data_type_indicator'],
	      	colModel:[
	      				{name:'id',index:'id', hidden:true, search:false,align:'left'},
	      				{name:'staff_title',index:'staff_title',search:true,align:'left'},
	      		   		{name:'loc_name',index:'loc_name',search:true,align:'left'},
	      		   		{name:'name',index:'name',search:true,align:'left'},
	      		   		{name:'email',index:'email',search:true,align:'left'},
	      		   		{name:'phone_type',index:'phone_type',search:true,align:'left'},
	      				{name:'phone_number',index:'phone_number',search:true,align:'left',width:'100'},
	      				{name: 'created_by', index: 'created_by', hidden: true},
		   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
		   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
		   	            {name: 'act', resizable: true, width: 80},
		   	         	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
		   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
		   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
	      	], 
	      	sortname: 'name',
	        rowNum: 10,
	        mtype: "POST",
	        autowidth: true,
	        rownumbers: true,
	        height: "auto",
	        rowList: [10, 20],
	        caption:"Staff",
	        loadonce:true,    	           		   
 		  	sortorder: "desc",
	        gridComplete: function () {
	              var ids = jQuery("#JQBlistStaffResultSet").jqGrid('getDataIDs');
	              for (var i = 0; i < ids.length; i++) {
	            	  var actionLink = '';
	                   var cl = ids[i];
	                   var isAnalyst = jQuery("#JQBlistStaffResultSet").jqGrid('getCell',cl,'client_id');
	                   var createdByName = jQuery("#JQBlistStaffResultSet").jqGrid('getCell',cl,'created_by_full_name');
	                   var rowData = jQuery("#JQBlistStaffResultSet").jqGrid('getRowData', cl);
                       if(isAnalyst != 1){                    
                      		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                       }else{
                       //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                       	var dataTypeIndicator = jQuery("#JQBlistStaffResultSet").jqGrid('getCell',cl,'data_type_indicator');
                       	actionLink += data_type_indicator(dataTypeIndicator);		    		
                       }
	                   if ((rowData.eAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"addStaffs('edit','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
	                   }
	                   if ((rowData.dAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"addStaffs('delete','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
	                   }
	                   jQuery("#JQBlistStaffResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	               }
	                  initializeCustomToolTips();
	        }
   });
}
function getEmailsData(){
	/*
     *jqgrid for Emails  table
     */
    $('#gridWrapperEmails').html('');
  	$('#gridWrapperEmails').html('<table id="JQBlistEmailResultSet"></table>');
    jQuery("#JQBlistEmailResultSet").jqGrid({
     	url: base_url + 'kols/list_kol_details/emails/' + kolId,
    		datatype: "json", 
    		colNames: ['Id', 'Email Type', 'Email', 'Is Primary','','','', action,'created_by_full_name','client_id','data_type_indicator'],
    		colModel:[
    				{name:'id',index:'id', hidden:true, search:false,align:'left'},
    				{name:'type',index:'type',search:true,align:'left'},
    		   		{name:'email',index:'email',search:true,align:'left'},
    				{name:'is_primary',index:'is_primary',search:true,align:'center'},
    				{name: 'created_by', index: 'created_by', hidden: true},
	   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
	   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
	   	        	{name: 'act', resizable: true, width: 60},
	   	        	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
	   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
    		   	  ], 
    		   sortname: 'type',
            rowNum: 10,
            mtype: "POST",
            autowidth: true,
            rownumbers: true,
            height: "auto",
            rowList: [10, 20],
            caption:"Emails",
            loadonce:true,    	           		   
 		  	sortorder: "desc",
            gridComplete: function () {
                var ids = jQuery("#JQBlistEmailResultSet").jqGrid('getDataIDs');
                for (var i = 0; i < ids.length; i++) {
                	 var actionLink = '';
	                   var cl = ids[i];
                       var isAnalyst = jQuery("#JQBlistEmailResultSet").jqGrid('getCell',cl,'client_id');
                       var createdByName = jQuery("#JQBlistEmailResultSet").jqGrid('getCell',cl,'created_by_full_name');
                       var rowData = jQuery("#JQBlistEmailResultSet").jqGrid('getRowData', cl);
                     if(isAnalyst != 1){                    
                    		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                     }else{
                     //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                     	var dataTypeIndicator = jQuery("#JQBlistEmailResultSet").jqGrid('getCell',cl,'data_type_indicator');
                     	actionLink += data_type_indicator(dataTypeIndicator);		    		
                     }
	                   var is_prime = '';
	                   if(rowData.is_primary == 'Yes'){
	                   	is_prime = 1;
	                   }
	                   if ((rowData.eAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"addEmails('edit','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
	                   }
	                   if ((rowData.dAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"addEmails('delete','" + cl + "','"+is_prime+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
			           }
	                   jQuery("#JQBlistEmailResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	                   emailCount++;
	               }
                initializeCustomToolTips();
            }
    		});
}
function getStateLicenceData(){
	/*
     *jqgrid for State License  table
     */
    $('#gridWrapperStateLicense').html('');
  	$('#gridWrapperStateLicense').html('<table id="JQBliststateLicenseResultSet"></table>');
    jQuery("#JQBliststateLicenseResultSet").jqGrid({
         	url: base_url + 'kols/list_kol_details/statelicense/' + kolId,
        		datatype: "json", 
        		colNames: ['Id', 'License Number', 'State', 'Is Primary','','','', action,'created_by_full_name','client_id','data_type_indicator'],
        		colModel:[
        				{name:'id',index:'id', hidden:true, search:false,align:'left'},
        				{name:'state_license',index:'state_license',search:true,align:'left'},
        		   		{name:'state_name',index:'state_name',search:true,align:'left'},
        				{name:'is_primary',index:'is_primary',search:true,align:'center'},
        				{name: 'created_by', index: 'created_by', hidden: true},
  	   					{name: 'eAllowed', index: 'eAllowed', hidden: true},
  	   	            	{name: 'dAllowed', index: 'dAllowed', hidden: true},
  	   	         		{name: 'act', resizable: true, width: 60},
      	   	         	{name:'created_by_full_name',index:'created_by_full_name', hidden:true},
    	   	            {name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
    	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
        		   	  ], 
        		  sortname: 'type',
                rowNum: 10,
                mtype: "POST",
                autowidth: true,
                rownumbers: true,
                height: "auto",
                rowList: [10, 20],
                loadonce:true, 
                caption:"State License",
                gridComplete: function () {
                    var ids = jQuery("#JQBliststateLicenseResultSet").jqGrid('getDataIDs');
                    for (var i = 0; i < ids.length; i++) {
                    	var actionLink = '';
                       	var cl = ids[i];
                        var isAnalyst = jQuery("#JQBliststateLicenseResultSet").jqGrid('getCell',cl,'client_id');
                        var createdByName = jQuery("#JQBliststateLicenseResultSet").jqGrid('getCell',cl,'created_by_full_name');
                        var rowData = jQuery("#JQBliststateLicenseResultSet").jqGrid('getRowData', cl);
                      if(isAnalyst != 1){                    
                     		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                      }else{
                      //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                      	var dataTypeIndicator = jQuery("#JQBliststateLicenseResultSet").jqGrid('getCell',cl,'data_type_indicator');
                      	actionLink += data_type_indicator(dataTypeIndicator);		    		
                      }
 	                   var is_prime = '';
	                   if(rowData.is_primary == 'Yes'){
	                   	is_prime = 1;
	                   }
 		                   if ((rowData.eAllowed == 'true')) {
 		                       actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"addLicenses('edit','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
 		                   }
 		                   if ((rowData.dAllowed == 'true')) {
 		                       actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"addLicenses('delete','" + cl + "','"+is_prime+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
 		                   }
 	                   jQuery("#JQBliststateLicenseResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
 	               }
                    initializeCustomToolTips();
                }
        		});
}
function getAssignedData(){
	/*
     *jqgrid for Emails  table
     */
    $('#gridWrapperAssign').html('');
  	$('#gridWrapperAssign').html('<table id="JQBlistAssignResultSet"></table>');
    jQuery("#JQBlistAssignResultSet").jqGrid({
     	url: base_url + 'kols/list_kol_details/assign/' + kolId,
    		datatype: "json", 
    		colNames: ['Id', 'Name','Email', 'Type','','','',action,'client_id','data_type_indicator'],
    		colModel:[
    				{name:'id',index:'id', hidden:true, search:false,align:'left'},
    				{name:'name',index:'name',search:true,align:'left'},
    		   		{name:'email',index:'email',search:true,align:'left'},
    		   		{name:'type',index:'type',search:true,align:'left'},
    		   		{name: 'created_by', index: 'created_by', hidden: true},
	   				{name: 'eAllowed', index: 'eAllowed', hidden: true},
	   	            {name: 'dAllowed', index: 'dAllowed', hidden: true},
	   	        	{name: 'act', resizable: true, width: 60},
	   	        	{name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
    		   	  ], 
    		sortname: 'id',
            rowNum: 10,
            mtype: "POST",
            autowidth: true,
            rownumbers: true,
            height: "auto",
            rowList: [10, 20],
            caption:"Assign Profile",
            loadonce:true,    	           		   
 		  	sortorder: "asc",
            gridComplete: function () {
                var ids = jQuery("#JQBlistAssignResultSet").jqGrid('getDataIDs');
                for (var i = 0; i < ids.length; i++) {
	                   var primaryLable = '';
	                   var cl = ids[i];
	                   var isAnalyst = jQuery("#JQBlistAssignResultSet").jqGrid('getCell',cl,'client_id');
                       var createdByName = jQuery("#JQBlistAssignResultSet").jqGrid('getCell',cl,'name');
	                   var rowData = jQuery("#JQBlistAssignResultSet").jqGrid('getRowData', cl);
	                   var actionLink = '';
	                   if(isAnalyst != 1){                    
                   		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                        }else{
                        //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                        	var dataTypeIndicator = jQuery("#JQBliststateLicenseResultSet").jqGrid('getCell',cl,'data_type_indicator');
                        	actionLink += data_type_indicator(dataTypeIndicator);		    		
                        } 
	                   if ((rowData.eAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"addAssign('edit','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Edit'></a></div></label>";
	                   }
	                   if ((rowData.dAllowed == 'true')) {
	                       actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"addAssign('delete','" + cl + "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title='Delete'></a></div></label>";
			           }
	                   jQuery("#JQBlistAssignResultSet").jqGrid('setRowData', ids[i], {act: actionLink});
	                   emailCount++;
	               }
                initializeCustomToolTips();
            }
    		});
}
<?php if(KOL_CONSENT) { ?>
function getOptData(){
	/*
     *jqgrid for Emails  table
     */
    $('#gridWrapperOptLog').html('');
  	$('#gridWrapperOptLog').html('<table id="JQBlistoptResultSet"></table>');
    jQuery("#JQBlistoptResultSet").jqGrid({
     	url: base_url + 'kols/get_opt_log_details/'+kolId,
    		datatype: "json", 
    		colNames: ['Id', 'Status', 'Date','Active Till'],
    		colModel:[
    				{name:'id',index:'id', hidden:true, search:false,align:'left'},
    				{name:'transaction_name',index:'transaction_name', search:false,align:'left'},
    				{name:'created_on',index:'created_on',search:true,align:'center'},
    				{name:'expire_date',index:'expire_date',search:true,align:'center'}    		   		
    		   	  ], 
    		sortname: 'transaction_name',
            rowNum: 10,
            mtype: "POST",
            autowidth: true,
            rownumbers: true,
            height: "auto",
            rowList: [10, 20],
            caption:"Opt-in/Opt-out",
            loadonce:true,    	           		   
 		  	sortorder: "desc",
            gridComplete: function () {
                initializeCustomToolTips();
            }
   });
}
<?php } ?>
function setDefaultButton(){
	if(kolId!=0){
		$('.addPhoneNumberButton').removeClass('ui-disabled');
		$('.addStaffButton').removeClass('ui-disabled');
		$('.addEmailButton').removeClass('ui-disabled');
		$('.addStateLicenseButton').removeClass('ui-disabled');
		$('.addLocationButton').removeClass('ui-disabled');
		$('.addBestTimeButton').removeClass('ui-disabled');
		$('.addAssignKolButton').removeClass('ui-disabled');
	}else{
		$('.addPhoneNumberButton').addClass('ui-disabled');
		$('.addStaffButton').addClass('ui-disabled');
		$('.addEmailButton').addClass('ui-disabled');
		$('.addStateLicenseButton').addClass('ui-disabled');
		$('.addLocationButton').addClass('ui-disabled');
		$('.addBestTimeButton').addClass('ui-disabled');
		$('.addAssignKolButton').addClass('ui-disabled');
	}
}
var organizationNameAutoCompleteOptions = {
		
        serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names/1',
		<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    //selText = selText.replace(/\&amp;/g, '&');
                    $('#organization').val(selText);
                    $('#org_institution_id').val(selId);
                    $('#org_institution_id').val(selId).trigger('change');
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#organization').val(trim(split(' ', selText)[4]));
                            return false;
                        } else {
                            //doSearchFilter1( - 1);
                        }
                    } else {
                        //doSearchFilter1( - 1);
                    }
                }
    };
    
    $(document).ready(function () {
    	var a='';
    	var changeAutoComplete = 0;
    	var attr = $("#org_type").attr('disabled');
    	if (typeof attr !== typeof undefined && attr !== false) {
    		changeAutoComplete = 1;
    	}
    		$('#org_institution_id').change(function () {
              OrgId = $(this).val();
              $.ajax({
                  url: '<?php echo base_url() ?>organizations/getOrgDetails/' + OrgId,
                  type: 'POST',
                  dataType: 'JSON',
                  success: function (returnData) {
                      for (var result in returnData) {
                          $("#country_id").val(returnData[result].country_id);
                         primaryStateId = returnData[result].state_id;
                         primaryCityId = returnData[result].city_id;
                         $("#state_id").val(returnData[result].state_id);
                          getStatesByCountryId();
                          $("#address1").val(returnData[result].address);
                          $("#address2").val('');
                          $("#postal_code").val(returnData[result].postal_code);
                          if(returnData[result].type_id > 0){
                        	$("#org_type option:selected").removeAttr("selected");
                        	$("#org_type").prop('selectedIndex',returnData[result].type_id);	
        					$("#org_type").prop('disabled', 'disabled');
        					$("#org_type").css('background-color','#ccc');
        					$('#org_type [value="'+returnData[result].type_id+'"]').attr("selected","selected");
        					changeAutoComplete = 1;
                          }else{
                        	$("#org_type option:selected").removeAttr("selected");
                        	$('#org_type [value=""]').attr("selected","selected");
      						$("#org_type").prop('disabled', '');
      						$("#org_type").css('background-color','#fff');
                          }

                      }

                  }
              });
          });
    		$("#organization").keypress(function(){
    		    if(changeAutoComplete == 1){
    		    	$("#org_type").prop('disabled', '');
    				$("#org_type").css('background-color','#fff');
    				$("#org_institution_id").val('');
    			}
    		});
    		a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);
    		$("#postal_code").on("focusout",function(){
            	$("#postal_code").parent().find("label.error").remove();
                var postalEle = $(this);
    			var postalCode = $(this).val();
    			if(postalCode != ''){
    				$("#loadingStates").show();
    				$.ajax({
    		            url: '<?php echo base_url() ?>country_helpers/get_zip_code_details/'+postalCode,
    		            type: 'post',
    		            dataType: 'json',
    		            success: function (returnData) {
    		            	$(postalEle).parent().find("label.error").remove();
    		              if(returnData.status == 1){
    						$("#country_id").val(returnData.details.country_id);
    						$("#loadingStates").show();
    				        var countryId = $('#country_id').val();
    				        var params = "country_id=" + countryId;
    				        $("#state_id").html("<option value=''>-- Select State --</option>");
    				        $("#city_id").html("<option value=''>-- Select City --</option>");
    				        var states = document.getElementById('state_id');
    				        $.ajax({
    				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
    				            dataType: "json",
    				            data: params,
    				            type: "POST",
    				            success: function (responseText) {
    				                $.each(responseText, function (key, value) {
    				                    var newState = document.createElement('option');
    				                    newState.text = value.state_name;
    				                    newState.value = value.state_id;
    				                    var prev = states.options[states.selectedIndex];
    				                    states.add(newState, prev);
    				                });
    				                $("#state_id option[value='']").remove();
    				                $("#state_id").prepend("<option value=''>-- Select State --</option>");
    				                $("#state_id").val("");
    				            },
    				            complete: function () {
    				                $("#loadingStates").hide();
    				                $("#state_id").val(returnData.details.region_id);
    								//$("#city_id").val(returnData.details.city_id);
    								var stateId = $('#state_id').val();
    		                        $("#city_id").html("<option value=''>-- Select City</option>");
    		                        var cities = document.getElementById('city_id');
    		                        var params = "state_id=" + stateId;
    		                        $("#loadingCities").show();
    								 $.ajax({
    		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
    		                            dataType: "json",
    		                            data: params,
    		                            type: "POST",
    		                            success: function (responseText) {
    		                                $.each(responseText, function (key, value) {

    		                                    var newCity = document.createElement('option');
    		                                    newCity.text = value.city_name;
    		                                    newCity.value = value.city_id;
    		                                    var prev = cities.options[cities.selectedIndex];
    		                                    cities.add(newCity, prev);
    		                                });

    		                                $("#city_id").val(returnData.details.city_id);
    		                            },
    		                            complete: function () {
    		                                $("#loadingCities").hide();
    		                            }
    		                        });				                
    				            }
    				        });
    						
    	                        //if(returnData.details.city_id == ''){}
    						 	//	$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
    			          }else{
    			        	  	$('#state_id').prop('selectedIndex',0);
    				          	$('#city_id option[value!=""]').remove();
    				          	$('#country_id').prop('selectedIndex',0);
    						//	$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
    				      }
    		            },
    		            complete: function () {
                            $("#loadingStates").hide();
                        }
    		        });
    			}
            });

    		$("#organization").on("input",function(){
      			var textSTring = $(this).val();
      			if(textSTring == ''){
    				$("#org_institution_id").val('');
      	  		}
            });
    	var count="<?php echo count($arrSelectedSepakerProducts) ?>";
    	var isYes="<?php echo $arrKolData['is_speaker'] ?>";
    	if(count==0 && isYes!=1)
    	    $("#speaker_product").hide();
    	$('#private_practice').change(function() {
            if ($(this).prop('checked')) {
                 $("#organization").removeClass("autocompleteInputBox"); //checked
            }
            else {
              $("#organization").addClass("autocompleteInputBox"); //not checked
            }
        });
    	 
        $(document).on('mouseover', 'td img.edit', function (e) {
            $(this).attr("src", base_url + "images/edit_inactive.png");
        });
        $(document).on('mouseover', 'td img.delete', function (e) {
            $(this).attr("src", base_url + "images/delete_inactive.png");
        });
        $(document).on('mouseover', 'td img.save', function (e) {
            $(this).attr("src", base_url + "images/save_inactive.png");
        });

        $(document).on('mouseout', 'td img.edit', function (e) {
            $(this).attr("src", base_url + "images/edit_active.png");
        });
        $(document).on('mouseout', 'td img.delete', function (e) {
            $(this).attr("src", base_url + "images/delete_active.png");
        });
        $(document).on('mouseout', 'td img.save', function (e) {
            $(this).attr("src", base_url + "images/save_active.png");
        });
        
       getLocationDataOnPageLoad();
       getPhoneNumberData();       
       getStaffsData();
       getEmailsData();
       getStateLicenceData();
       setDefaultButton();
       getAssignedData();	
       <?php if(KOL_CONSENT) { ?>
       getOptData();
       <?php } ?>
       var addNewKol = {
				title: "Add HCP",
				modal: true,
				autoOpen: false,
				width: 600,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#micro").dialog(addNewKol);
		$('table.tabularGrid caption div.collapseSlider').click(function (){
        	if($(this).attr('class')!="collapseSlider"){
        		$(this).parent().parent().find('tr').hide();
        		$(this).find('a').attr('data-original-title','Expand');
	        }else{
    	    	$(this).parent().parent().find('tr').show();
        		$(this).find('a').attr('data-original-title','Collapse');
        	}
	        $(this).toggleClass('expandSlider');
    	});
// 		$('table.tabularGrid caption div.collapseSlider').trigger('click');
		var previousEmail='';
		$(".primaryEmail").focusin(function() {
			previousEmail = $(".primaryEmail").val(); 
		});
		$(".primaryEmail").focusout(function() {
			if($.trim($(".primaryEmail").val())=='' && emailCount>0){				
				jAlert("Primary Email can't be blank");
				$(".primaryEmail").val(previousEmail);
			} 
		});	
		var previousPhone='';
		$("#phone_number_loc").focusin(function() {
			previousPhone = $("#phone_number_loc").val(); 
		});
		$("#phone_number_loc").focusout(function() {
			if($.trim($("#phone_number_loc").val())=='' && phoneCount>0){				
				jAlert("Primary Phone can't be blank");
				$("#phone_number_loc").val(previousPhone);
			} 
		});
		$("#phone_type").change(function () {
	        var phType = $('#phone_type option:selected').val();
	        if(phType > 0){
		        $('#phone_type_loc').text('');
	        }
	    });	
		
    });
    var flag_is_edit = false;
    $(document).on('change', '#detailsContainer input[type=checkbox]', function() {
		if(flag_is_edit){
			jAlert("Cannot edit the Primary record");
			$(this).attr("checked","checked");
		}
	});
    function changeAutoComplete(){
    	var orgType = $('#org_type').find(":selected").text();
    	if(orgType == 'Private Practice'){
        	$('#private_practice').val('1');
			//$('#organization').removeClass('autocompleteInputBox');
        }else{
        	$('#private_practice').val('0');
        	//$('#organization').addClass('autocompleteInputBox');
        }
    }
    function saveBestTime(day) {
        if ($("#time").val() == "")
            $("#time").addClass("error");
        else {
            $.ajax({
                url: "<?php echo base_url() ?>kols/save_best_time/" + kolId + "/" + day,
                dataType: "json",
                data: $("#bestTime tbody tr:nth-child(2)").children().eq(day).find("#time").serialize(),
                type: "POST",
                beforeSend: function(){
        			$("#bestTime tbody tr th .time_data .save").removeAttr("onclick", null);
                },
                success: function (returnData) {
                    if (returnData.status) {
                        var html = '<tr id="time_' + returnData.status + '"><td>' + returnData.time + '</td>';
                        html += '<td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(' + day + ', ' + returnData.status + ');"></td></tr>';
                        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".time_data_view table").append(html);
                        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".add_time_data").show();
                        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".time_data").html("");
                    }
                },
        		complete:function(){
        			$('#bestTime tbody tr th .time_data .save').attr('onclick','saveBestTime(1);return false;');
        		}
            });
        }
    }

    function deleteBestTime(day, id) {
        $.ajax({
            url: "<?php echo base_url() ?>kols/delete_best_time/" + id,
            dataType: "json",
            type: "POST",
            success: function (returnData) {
                $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".time_data_view table tr#time_" + id).remove();
            }
        });
    }

    function cancelBestTime(day) {
        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".add_time_data").show();
        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".time_data").html("");
    }

    function addBestTime(day) {
        cancelBestTime(previous_time);
        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".time_data").append('<input name="time" id="time" value="" class="required"/><img title="Save" alt="Save" class="save actionIcon " src="<?php echo base_url(); ?>images/save_active.png" onclick="saveBestTime(' + day + ');return false;"><img title="Cancel" alt="Cancel" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="cancelBestTime(' + day + ');">');

        $("#time").on("focus", function () {
            $("#time").removeClass("error");
        });
        $('input[name="time"]').ptTimeSelect({onBeforeShow: function (ele, text) {
                $("#ptTimeSelectCntr").removeClass("time_picker_last");
                if (day == 6) {
                    $("#ptTimeSelectCntr").addClass("time_picker_last");
                }
            }});
        $("#bestTime tbody tr:nth-child(2)").children().eq(day).find(".add_time_data").hide();
        if (day == 6) {
            $("#ptTimeSelectCntr").addClass("time_picker_last");
        }
        previous_time = day;
    }
    function checkDuplicatesAndSave(){
    	$("#save_kol").removeAttr("onclick", null);
    	if (!$("#kol_form").validate().form()) {
    		 $('html, body').animate({
                 scrollTop: $("#kol_form .error").first().offset().top-30
             });
    		 $("#kol_form .error").first().focus();
    		 $('#save_kol').attr('onclick','checkDuplicatesAndSave()');
            return false;
        }
  		var specialtySelected = $("#specialty").val();
  		if(specialtySelected != ''){
  			//$("#loadingStates").show();
  			$.ajax({
  	            url: '<?php echo base_url() ?>kols/check_duplicate_ol/2',
  	            type: 'post',
  	            dataType: 'json',
  	          	data: $('#kol_form').serialize(),
  	            success: function (returnData) {
  	              if(returnData.duplicate_found == 1){
    		              //alert(returnData.dupHtml);
    		              $("#micro .profileContent").html(returnData.dupHtml);
    		          		$("#micro").dialog("open");
    		          		$('#save_kol').attr('onclick','checkDuplicatesAndSave()');
    		          		return false;
  	              }else{
  	            	$("#is_duplicate_case").val("0");
  	            	saveKol();
  	  	          }
  	            }
  			});
  		}
    }
    function proceedToAdd1(){
    	$("#micro").dialog("close");
    	$("#is_duplicate_case").val("1");
    }
    function proceedToAdd2(){
    	$("#micro").dialog("close");
    	$("#is_duplicate_case").val("1");
    	saveKol();
    }
    function saveKol() {
        if (!$("#kol_form").validate().form()) {
        	$('html, body').animate({
                scrollTop: $("#kol_form .error").first().offset().top-30
            });
   		 $("#kol_form .error").first().focus();
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_ol',
            type: 'post',
            dataType: 'json',
            data: $('#kol_form').serialize(),
            success: function (returnData) {
                if (returnData.status == true) {
                	kolId = returnData.id;
                	$('#kolIdForSave').val(kolId);
                    $('.msgBox').html('<?php echo lang("HCP");?> data saved successfully');
                    $('.msgBox').fadeOut(1500);
                    loadAdditionalDetails();
                   // window.location = "<?php echo base_url() ?>kols/view/" + returnData.id;
                } else if (returnData.is_duplicate) {
                    $('.msgBox').fadeOut();
                    jConfirm("Duplicate Entry Found. Do you want to proceed and save similar record??", "Please confirm", function (r) {
                        if (r) {
                            $('.msgBox').html('Saving data....');
                            $.ajax({
                                url: '<?php echo base_url() ?>kols/save_ol/1',
                                type: 'post',
                                dataType: 'json',
                                data: $('#kol_form').serialize(),
                                success: function (returnData) {
                                    if (returnData.status) {
                                        kolId = returnData.id;
                                        $('#kolIdForSave').val(kolId);
                                        $('.msgBox').html('<?php echo lang("HCP");?> data saved successfully');
                                        $('.msgBox').fadeOut(1500);
                                        loadAdditionalDetails();
                                        //window.location = "<?php echo base_url() ?>kols/view/" + returnData.id;
                                    } else {
                                        $('.msgBox').html('Error saving <?php echo lang("HCP");?> data');
                                        $('.msgBox').fadeOut(1500);
                                    }
                                }
                            });
                        } else {
                            return false;
                        }
                    });
                } else {

                    $('.msgBox').html('Error saving <?php echo lang("HCP");?> data');
                    $('.msgBox').fadeOut(1500);
                }
            },
            complete: function () {
            	$('#save_kol').attr('onclick','checkDuplicatesAndSave()');
            }
        });
    }
    function loadAdditionalDetails(){
    	getLocationDataOnPageLoad();
    	getPhoneNumberData();
    	getEmailsData();
    	setDefaultButton();
    	getAssignedData();
    }
</script>
<div class="msgBox"></div>
<div id="dispShortDetail">  
 <?php if($subContentPage=='details') {?>
    <table>
        <caption>Short Details</caption>
        <tr>
            <td>
                <table>
                    <tr>
                        <th>First Name :</th>
                        <td><?php echo $arrKolData['first_name']; ?></td>
                    </tr>
                    
                    <tr>
                         <th>Middle Name :</th>
                         <td><?php echo $arrKolData['middle_name']; ?></td>
                    </tr>
                    
                    <tr>
                        <th>Last Name :</th>
                        <td><?php echo $arrKolData['last_name']; ?></td>
                    </tr>
                    <tr>
                        <th>Specialty :</th>
                        <td><?php if($arrKolData['specialty']==0) echo 'Non-medical / Others'; else echo $arrKolData['specialty_name']; ?></td>
                    </tr>
                    <tr>
                         <th>Sub Specialty :</th>
                         <td>
                             <?php
                                echo implode(", ",$arrSubSpecialties); 
                             ?>
                         </td>
                     </tr>
                    <?php //if ($arrKolData['degree'] != "") { ?>
                        <!-- <tr>
                            <th>Degree :</th>
                            <td>
                                <?php
                                //echo $arrKolData['degree'];
                                ?>

                            </td>
                        </tr> -->
                    <?php //} ?>
                    
                </table>
            </td>
            <td>
                <table>
                    <!-- <tr>
                        <th>
                            KOL  :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrKolData['is_kol'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                    </tr> -->
                    	
                    	
                    <tr>
                        <th>Professional Suffix :</th>
                        <td>
                            <?php
                            if ($arrKolData['suffix'] == '1')
                                echo "Do";
                            elseif ($arrKolData['suffix'] == '2')
                                echo "IM";
                            elseif ($arrKolData['suffix'] == '3')
                                echo "PD";
                            elseif ($arrKolData['suffix'] == '4')
                                echo "MD";
                            else
                                echo $arrKolData['suffix'];
                            ?>

                        </td>
                    </tr>
                    <?php //if ($arrKolData['title'] != "") { ?>
                        <tr>
                            <th>Position :</th>
                            <td>
                                <?php
                                echo $arrKolData['title'];
                                ?>

                            </td>
                        </tr>
                    <?php //} ?>
                    <?php /* //if ($arrKolData['additional_role_id'] != "") { ?>
                        <tr>
                            <th>Additional Role :</th>
                            <td>
                                <?php
                                echo $arrAdditionalRoles[$arrKolData['additional_role_id']]['role_name'];
                                ?>

                            </td>
                        </tr>
                    <?php //} */?>
                    <?php //if (count($arrKolProducts) > 0 ) { ?>
                        <tr>
                            <th><?php echo lang("Overview.Product");?> :</th>
                            <td>
                                <?php 
                                $prodString = "";
//                                 pr($arrKolProducts);exit;
                                foreach ($arrKolProducts as $value) {
                                    $prodString .= $value['name'].", ";
                                }
                                echo trim($prodString, ", ");
                                ?>

                            </td>
                        </tr>
                        <tr>
                        	<th>Email :</th>
                        	<td><?php echo $arrKolData['primary_email'];?></td>
                        </tr>
                        <?php if(CRM_LABEL){?>
                        <tr>
                            <th>CRM # :</th>
                            <td>
                                <?php
                                echo $arrKolData['external_profile_id'];
                                ?>

                            </td>
                    	</tr>
                    	
                    	<?php }?>
                    <?php //} ?>
                    <?php /*//if ($arrKolData['patients_range'] != "") { ?>
                        <tr>
                            <th>Range Of Patients Seen :</th>
                            <td>
                                <?php
                                echo $arrKolData['patients_range'];
                                ?>

                            </td>
                        </tr>
                    <?php // } ?>
                    <?php //if ($arrKolData['is_speaker'] != "") { ?>
                        <tr>
                            <th>Speaker :</th>
                            <td>
                                <?php
                                if ($arrKolData['is_speaker'] == "1")
                                    echo "Yes";
                                else
                                    echo "No";
                                ?>

                            </td>
                        </tr>
                         <tr>
                            <th>Speaker Program :</th>
                            <td>
                                <?php
                                if(count($arrSelectedSepakerProducts)>0){
                                $speakerProgram=array();
                               
                                foreach($arrSepakerProducts as $values){
                                    foreach($arrSelectedSepakerProducts as $value){
                                        if($value['product_id']==$values['id'])
                                            $speakerProgram[]= $values['name'];
                                    }
                                }
                                  echo implode(',',$speakerProgram);  
                                }
                                ?>

                            </td>
                        </tr>
                    <?php //} */?>
                    
                    <?php 
                    if ($arrKolData['npi_num'] != "") { ?>
                      <!--   <tr>
                            <th>NPI Number :</th>
                            <td>
                                <?php echo $arrKolData['npi_num']; ?>

                            </td>
                        </tr>  -->
                    <?php }else {?>
                    	
                    <?php }?>
                </table>
            </td>
        </tr>
       <!--  <tr>	
            <td colspan="2">
                <table>
                    <caption>Contact Preferences</caption>
                    <tr>
                        <th>
                            Visit :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['visit'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                        <th>
                            Call :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['call'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                        <th>
                            Fax :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['fax'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Mail :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['mail'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                        <th>
                            Text :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['text'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                        <th>
                            Email :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['email'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                    </tr>
                    <tr>
                    	<th>
                            Video Call :
                        </th>
                        <td>
                            <span class="<?php
                            if ($arrContactData['video_call'] == 0)
                                echo 'is_kol_no';
                            else
                                echo 'is_kol_yes';
                            ?>">&nbsp;</span>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>  -->
     </table>
		<?php }else{
			?>
	<form id="kol_form" name="kol_form" action="save_kol" method="post">	
	<table>	
		<caption>Short Details</caption>
		<input type="hidden" name='profile_type' value="<?php echo $arrKolData['profile_type'];?>"/>
        <input type="hidden" id="kolIdForSave" name="kol_id" value="<?php echo $arrKolData['id']; ?>"/>
		<tr>
            <td style="width: 50%;">
                <table>
<!--                    <tr>
                        <td><label for="compliance_flag">Do Not Call :</label></td>
                        <td><input type="checkbox" name="compliance_flag" id='compliance_flag' 
                    <?php
                    if ($subContentPage=='edit') {
                        if ($arrKolData['compliance_flag'] == "1")
                            echo 'checked';
                    }
                    $disabled = "";
                    $client_id = $this->session->userdata('client_id');
                    if(!$checkKolAssignedToUser && $client_id!=INTERNAL_CLIENT_ID){
                        $disabled = "disabled style='background-color: #ccc;'";
                    }
                    ?>
                                   />
                        </td>
                    </tr>-->
                    <tr>
                        <td><label for = "first_name">First Name<span class = "required">*</span> :</label></td>
                        <td><input type = "text" name = "first_name" id = 'first_name' class = "required" value='<?php echo $arrKolData['first_name'];?>'  <?php echo $disabled?>/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "middle_name">Middle Name :</label></td>
                        <td><input type = "text" name = "middle_name" id = 'middle_name' value='<?php echo $arrKolData['middle_name'];?>'<?php echo $disabled?>/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "last_name">Last Name<span class = "required">*</span> :</label></td>
                        <td><input type = "text" name = "last_name" id = 'last_name' class = "required" value='<?php echo $arrKolData['last_name'];?>' <?php echo $disabled?>/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "specialty">Specialty<span class = "required">*</span> :</label></td>
                        <td>
                        	 <select name = "specialty" id = 'specialty' class = "required" <?php echo $disabled?>>
                                <option value = ""> --Select--</option>
                                <?php
                                foreach ($arrSpecialties as $key => $value) {
                                    ?>
                                    <option value="<?php echo $key; ?>"  <?php
                                    if ($subContentPage=='edit') {
                                        if ($arrKolData['specialty'] == $key)
                                            echo 'selected';
                                    }
                                    ?>><?php echo $value; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "sub_specialty">Sub Specialty:</label></td>
                        <td>
                            <select class="chosenMultipleSelect" multiple="multiple" id="sub_specialty" name="sub_specialty[]" <?php echo $disabled?>>
                                
                                	<?php
                                		foreach ($arrSpecialties as $key => $value) {
                                    ?>
	                                    <option value="<?php echo $key; ?>"
	                                    	<?php 
	                                    	if ($subContentPage=='edit') {
	                                    		if ($arrSubSpecialties[$key] == $value)
	                                    			echo 'selected';
	                                    	}
	                                    	?>
	                                    ><?php echo $value; ?></option>
									<?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                </table>
            </td>
           
            <td style="width: 50%;">
                <table>
                    <tr>
                        <td><label for = "prof_suffix">Professional Suffix :</label></td>
                        <td>
                        	<select class="chosenMultipleSelect" multiple="multiple"  name = "prof_suffix[]" id = 'prof_suffix' <?php echo $disabled?>>
                            
                                <?php                               
                                foreach ($arrProfessionalSuffixes as $suffix) {
                                    ?>
                                    <option value="<?php echo $suffix['suffix']; ?>" 
                                        <?php
                                        if ($subContentPage=='edit') {
                                            $found = array_search($suffix['suffix'], $selectedSuffixes);                                            
                                            if ($found!==false)
                                                echo 'selected';
                                        }
                                        ?>
                                    ><?php echo $suffix['suffix']; ?></option>
                                  
                                <?php } ?>   
                            </select>                            
                        </td>
                    </tr>

                    <tr>
                        <td><label for = "title">Position :</label></td>
                        <td>                        	
                            <select name = "title" id = 'title' <?php echo $disabled?>>
                                <option value = ""> --Select--</option>
                                <?php
                                foreach ($arrTitles as $title) {
                                    ?>
                                    <option value="<?php echo $title['id']; ?>" 
                                    <?php
                                    if ($subContentPage=='edit') {
                                        if ($arrKolData['title_id'] == $title['id'])
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $title['title']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                   <!--  <tr>
                        <td><label for="npi_num">NPI Number :</label></td>
                        <td>
                            <input type="text" name="npi_num" id='npi_num' value='<?php echo $arrKolData['npi_num']; ?>'/>

                        </td>
                    </tr>  -->
                    <?php /*?>
                    <tr>
                        <td><label for="additional_role_id">Additional Role :</label></td>
                        <td>
                            <select name="additional_role_id" id='additional_role_id' <?php echo $disabled?>>
                                <option value="">--Select--</option>
                                <?php
                                foreach ($arrAdditionalRoles as $role) {
                                    ?>
                                    <option value="<?php echo $role['id']; ?>" 
                                    <?php
                                    if ($subContentPage=='edit') {
                                        if ($arrKolData['additional_role_id'] == $role['id'])
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $role['role_name']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <?php */?>
                    <tr>
                        <td><label for="products"><?php echo lang("Overview.Product");?> :</label></td>
                        <td>                   
                            <select class="chosenMultipleSelect" multiple="multiple"  name="products[]" id="products" <?php echo $disabled?>>
                            
                                <?php
                                
                                foreach ($arrProducts as $product) {
                                    ?>
                                    <option value="<?php echo $product['id']; ?>" 
                                    <?php
                                    if ($arrKolProducts) {
                                        foreach ($arrKolProducts as $kolProduct) {
                                            if ($product['id'] == $kolProduct['id'])
                                                echo 'selected';
                                        }
                                    }
                                    ?> 
                                            ><?php echo $product['name']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <?php /*?>
                    <tr>
                        <td><label for="patients_range">Range Of Patients Seen :</label></td>
                        <td>
                            <select name="patients_range" id='patients_range' <?php echo $disabled?>>
                                <option value="">--Select--</option>
                                <option value="0" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['patients_range'] == "0")
                                        echo 'selected';
                                }
                                ?>
                                        >0</option>
                                <option value="1-5" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['patients_range'] == "1-5")
                                        echo 'selected';
                                }
                                ?>
                                        >1-5</option>
                                <option value="6-10" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['patients_range'] == "6-10")
                                        echo 'selected';
                                }
                                ?>
                                        >6-10</option>
                                <option value="11-20" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['patients_range'] == "11-20")
                                        echo 'selected';
                                }
                                ?>
                                        >11-20</option>
                                <option value="25+" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['patients_range'] == "25+")
                                        echo 'selected';
                                }
                                ?>
                                        >25+</option>
                            </select>
                        </td>
                    </tr>
                    
                    
                    <tr>
                        <td><label for="is_speaker">Speaker :</label></td>
                        <td>
                            <select  name="is_speaker" onchange="showSpeakerProduct(this)" id='is_speaker' <?php echo $disabled?>>
                                <option value="">--Select--</option>
                                <option value="1" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['is_speaker'] == "1")
                                        echo "selected";
                                }
                                ?>>Yes</option>
                                <option value="0" <?php
                                if ($subContentPage=='edit') {
                                    if ($arrKolData['is_speaker'] == "0")
                                        echo "selected";
                                }
                                ?>>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr id="speaker_product"  >
                        <td><label for="is_speaker_product">Speaker Program :</label></td>
                        <td>
                            <select  class="chosenMultipleSelect" multiple="multiple"  name="speaker_products[]"   id='is_speaker_product' <?php echo $disabled?>>
                                <?php
                                
                                foreach($arrSepakerProducts as $values){
                                     if ($subContentPage !='edit')
                                        echo "<option value='".$values['id']."'>".$values['name']."</option>";
                                     else{
                                         foreach($arrSelectedSepakerProducts as $value){
                                             if($values['id']==$value['product_id'])
                                                echo "<option selected value='".$values['id']."'>".$values['name']."</option>";
                                             
                                         }
                                          echo "<option value='".$values['id']."'>".$values['name']."</option>";
                                     }
                                     
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <?php */?>
                    <tr>
                        <td><label for="email">Email :</label></td>
                        <td><input type="text" name="email" id="email" class="primaryEmail" value='<?php echo $arrKolData['primary_email'];?>' <?php echo $disabled?>/></td>
                    </tr>
                    <?php if(CRM_LABEL){?>
                	<tr>
                        <td><label for="npi_num">CRM # :</label></td>
                        <td>
                            <input type="text" name="crm_id" id='crm_id' value='<?php echo $arrKolData['external_profile_id']; ?>'/>

                        </td>
                    </tr>
                    <?php }?>
                    <!-- <tr>
                        <td><label for="is_kol"><?php echo lang('Contacts.Kol');?>:</label></td>
                        <td><input type="checkbox" name="is_kol" id="is_kol" <?php
                            if ($subContentPage=='edit') {
                                if ($arrKolData['is_kol'] == "1")
                                    echo "checked";
                            }
                            ?>/></td>
                    </tr> -->
                </table>
            </td>
        </tr>
     <!--    <tr>
            <td colspan="2">
                <table>
                    <caption>Contact Preferences</caption>
                </table>
            </td>
        </tr>
        <!-- <tr class="contact_restrictions">
            <td style="width: 50%">
                <label for="visit">Visit :</label>
                <input type="checkbox" name="visit" id="visit" <?php
                if ($subContentPage=='edit') {
                    if ($arrContactData['visit'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
            <td style="width: 50%">
                <label for="call">Call :</label>
                <input type="checkbox" name="call" id="call" <?php
                if ($subContentPage=='edit') {
                    if ($arrContactData['call'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
        </tr>
        <tr class="contact_restrictions">
            <td style="width: 50%">
                <label for="fax">Fax :</label>
                <input type="checkbox" name="fax" id="fax" <?php
                if ($subContentPage=='edit') {
                    if ($arrContactData['fax'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
            <td style="width: 50%">
                <label for="mail">Mail :</label>
                <input type="checkbox" name="mail" id="mail" <?php
                if ($subContentPage=='edit') {
                    if ($arrContactData['mail'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
        </tr> --l>
        <tr>
        	<td colspan="2">
	        <table>
	        	<tr class="contact_restrictions">
		        	<td>
		        		<label for="visit">Visit :</label>
		                <input type="checkbox" name="visit" id="visit" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['visit'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
		        	<td>
		        		<label for="call">Call :</label>
		                <input type="checkbox" name="call" id="call" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['call'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
		        	<td>
		        		<label for="fax">Fax :</label>
		                <input type="checkbox" name="fax" id="fax" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['fax'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
	        	</tr>
	        	<tr class="contact_restrictions">
		        	<td>
		        		<label for="mail">Mail :</label>
		                <input type="checkbox" name="mail" id="mail" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['mail'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
		        	<td>
		        		<label for="mail">Text :</label>
		                <input type="checkbox" name="cr_text" id="cr_text" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['text'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
		        	<td>
		        		<label for="mail">Email :</label>
		                <input type="checkbox" name="cr_email" id="cr_email" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['email'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
	        	</tr>
	        	<tr class="contact_restrictions">
		        	<td>
		        		<label for="mail">Video Call :</label>
		                <input type="checkbox" name="cr_video_call" id="cr_video_call" <?php
		                if ($subContentPage=='edit') {
		                    if ($arrContactData['video_call'] == "1")
		                        echo "checked";
		                }
		                ?>/>
		        	</td>
	        	</tr>
	        </table>
	      </td>
	    </tr> -->
	    
	    <tr>
	    	<td colspan="2">
		    <table>
		            <caption>Address</caption>
		            <tbody>
		                <tr>
		                    <td style="width: 50%;">
		                        <table style="te">
		                            <tr style="display: none;">
		                                <td class="alignRight">
		                                    <label for="isPrimary">Primary Address:</label>
		                                </td>
		                                <td>
		                                    <input type="checkbox" name="is_primary"  checked <?php echo $disabled?>/>
		                                </td>
		                            </tr>
		                            
		                            <tr>
		                                <td class="alignRight"><label for="org_institution_id">Institution<span class = "required">*</span> :</label></td>
		                                <td>
		                                    <input type="text" name="organization" class="autocompleteInputBox" id="organization" placeholder="Enter Institution" title=""
			                                    <?php  
			                                    
			                                    if ($subContentPage == "edit" && $arrLocationData['org_institution_name'] != "0") {
			                                        echo 'value="' . $arrLocationData['org_institution_name'] . '"';
			                                    }
			                                    else{
			                                        echo 'value="' . $arrLocationData['private_practice'] . '"';
			                                    }
			                                    ?>
                                           <?php echo $disabled?>/>
		                                    <input type="hidden" name="org_institution_id" id="org_institution_id" 
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo 'value="' . $arrLocationData['org_institution_id'] . '"';
		                                    } else {
		                                        echo 'value=""';
		                                    }
		                                    ?>
		                                           />
		                                    <input type="hidden" name="location_id" id="location_id" 
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo 'value="' . $arrLocationData['id'] . '"';
		                                    } else {
		                                        echo 'value=""';
		                                    }
		                                    ?>
		                                           />
		                                </td>
		                            </tr>
		                              <tr>
		                              	<td><label for = "title">Institution Type :</label></td>
				                        <td>
				                        	<input type="hidden" name="private_practice" id="private_practice" value="1"/>                      	
				                            <select name = "org_type" id = 'org_type' class="primaryOrgType" onchange="changeAutoComplete();"
				                            <?php 
					                            if ($subContentPage=='edit') {
					                            	if (!empty($orgTypeId))
					                            		echo "disabled";
					                            		echo " style='background-color: #ccc;'";
					                            }		                            
				                            ?>
				                            <?php echo $disabled?>>
				                                <option value = ""> --Select--</option>
				                                <?php
				                                	foreach ($arrOrganizationTypes as $key => $value) {
				                                ?>
				                                <option value="<?php echo $key; ?>"
				                                <?php 
					                                if ($subContentPage=='edit') {
					                                	if (!empty($orgTypeId) && $orgTypeId == $key)
					                                		echo "selected";
					                                }
				                                ?>
				                                ><?php echo $value; ?></option>
				                                <?php
				                                    }
				                                ?>
				                            </select>
				                        </td>
		                                <!-- <td class="alignRight"><label for="private_practice">Private Practice :</label></td>
		                        		<td><input type="checkbox" name="private_practice" id="private_practice" value="1" <?php
				                            if ($subContentPage=='edit') {
				                                if (!empty($arrLocationData['private_practice']))
				                                    echo "checked";
				                            }
				                            ?>/>
				                        </td> -->
		                            </tr>
		                            <tr>
		                                <td class="alignRight"><label for="address1">Address Line 1<span class="required">*</span>:</label></td>
		                                <td>
		                                    <input type="text" name="address1" id="address1" maxlength="50" class="required" 
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo 'value="' . $arrLocationData['address1'] . '"';
		                                    }
		                                    ?> <?php echo $disabled?>></input>
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="address2">Address Line 2 :</label>
		                                </td>
		                                <td>
		                                    <input type="text" name="address2" id="address2"  maxlength="50"
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo 'value="'.$arrLocationData['address2'].'"';
		                                    }
		                                    ?> <?php echo $disabled?>></input>
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="department">Department :</label>
		                                </td>
		                                <td>
		                                    <input type="text" name="department_loc" id="department_loc" 
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo 'value="'.$arrLocationData['division'].'"';
		                                    }
		                                    ?> <?php echo $disabled?>></input>
		                                </td>
		                            </tr>
		                            <?php /*?><tr>
				                        <td><label for = "title">Title :</label></td>
				                        <td>                        	
				                            <select name = "title_loc" id = 'title_loc' class="primaryTitleLoc" <?php echo $disabled?>>
				                                <option value = ""> --Select--</option>
				                                <?php
				                                foreach ($arrTitles as $title) {
				                                    ?>
				                                    <option value="<?php echo $title['id']; ?>" 
				                                    <?php
				                                    if ($subContentPage=='edit') {
				                                        if ($arrLocationData['title'] == $title['id'])
				                                            echo 'selected';
				                                    }
				                                    ?>
				                                            ><?php echo $title['title']; ?></option>
				                                            <?php
				                                        }
				                                        ?>
				                            </select>
				                        </td>
				                    </tr><?php */?>
		<!--                            <tr>
		                                <td class="alignRight">
		                                    <label for="address3">Address Line 3 :</label>
		                                </td>
		                                <td>
		                                    <input type="text" name="address3" id="address3" maxlength="50"
		                                    <?php
		                                    if ($subContentPage=='edit') {
		                                        echo "value=" . $arrLocationData['address3'];
		                                    }
		                                    ?>></input>
		                                </td>
		                            </tr>-->
		                            <!-- <tr>
		                                <td class="alignRight">
		                                    <label for="validation_status">Validation Status :</label>
		                                </td>
		                                <td>
		                                <label style="text-align: left;"> <?php
		                                    if (isset($locationData)) {
		                                            echo $locationData['validation_status'];
		                                        }  else 
		                                            echo "New"; ?>
		                                </label>
		                                
		        <input type="hidden" name="validation_status" value="<?php
		                                    if (isset($locationData)) {
		                                            echo $locationData['validation_status'];
		                                        }  else 
		                                            echo "New"; ?>"/>
		                                </td>
		                            </tr>-->
		                        </table>
		                    </td>
		
		                    <td style="width: 50%;">
		                        <table>
				
		                            <!-- <tr>
		                                <td class="alignRight">
		                                    <label for="validated_address">Validated Address:</label>
		                                </td>
		                                <td>
		                                    <label style="text-align: left;"><?php
		                                        if ($subContentPage=='edit') {
		                                            if ($arrLocationData['validated_address'] == 1) {
		                                                echo "Yes";
		                                            }
		                                        }
		                                        ?></label>
		                                </td>
		                            </tr> 
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="address_type">Address Type<span class="required">*</span> :</label>
		                                </td>
		                                <td>
		                                    <label style="text-align: left;" id="address_label"><?php if ($subContentPage=='edit' && isset($arrLocationData['address_type'])) echo $arrLocationData['address_type']; else  echo 'Physical'; ?></label>
		                                    <input type="hidden" name="address_type" id="address_type" <?php if ($subContentPage=='edit' && isset($arrLocationData['address_type'])) echo "value=" .$arrLocationData['address_type']; else  echo "value='Physical'"; ?> >
		                                </td>
		                            </tr>-->
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="postal_code">Postal Code :</label>
		                                </td>
		                                <td>
		                                    <input type="text" name="postal_code" id="postal_code"
		                                    <?php
		                                    if ($subContentPage=='edit' && $arrLocationData['postal_code'] != "") {
		                                        echo "value=" . $arrLocationData['postal_code'];
		                                    }
		                                    ?>
		                                          <?php echo $disabled?> />
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="country_id">Country<span class="required">*</span> :</label>
		                                </td>
		                                <td>
		                                    <select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="primaryCountry required" <?php echo $disabled?>>
		                                        <option value="">-- Select Country --</option>
		                                        <?php 
		                                        //$selectedCountryId	= $arrFirstCountry;
		                                        if(isset($arrLocationData['country_id']) && $arrLocationData['country_id']>0){
		                                        	$selectedCountryId	= $arrLocationData['country_id'];
		                                        }
		                                        foreach ($arrCountries as $country) { ?>
		                                            <option value="<?php echo $country['country_id']; ?>"
		                                            <?php
		                                            if ($selectedCountryId == $country['country_id'])
		                                                echo "selected";
		                                            ?>
		                                            >
		                                            <?php echo $country['country_name']; ?>
		                                            </option>
		                                        <?php } ?>
		                                    </select>
		                                    <img id="loadingStates" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">									
		                                    <label for="state_id">State / Province :</label>
		                                </td>
		                                <td>
		                                    <select name="state_id" id="state_id" onchange="getCitiesByStateId();" class="primaryState" <?php echo $disabled?>>		
		                                        <option value="">-- Select State --</option>
		                                        <?php foreach ($arrStates as $state) { ?>
		                                            <option value="<?php echo $state['state_id']; ?>"
		                                            <?php
		                                            if ($arrLocationData['state_id'] == $state['state_id'])
		                                                echo "selected";
		                                            ?>
		                                                    >
		                                                        <?php echo $state['state_name']; ?>
		                                            </option>
		                                        <?php } ?>
		                                    </select>
		                                    <img id="loadingCities" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">
		                                    <label for="city_id">City :</label>
		                                </td>
		                                <td id="cityDiv">
		                                    <select name="city_id" id="city_id" class="primaryCity" <?php echo $disabled?>>
		                                        <option value="">-- Select City --</option>
		                                        <?php
		                                        foreach ($arrCities as $city) {
		                                            echo '<option value="' . $city['city_id'] . '" ';
		                                            if ($arrLocationData['city_id'] == $city['city_id'])
		                                                echo "selected";
		                                            echo '>' . $city['city_name'] . '</option>';
		                                        }
		                                        ?>
		                                    </select>
		                                </td>
		                            </tr>
		                            
		                            <tr>
		                                <td class="alignRight">
		                                    <!--<label for="postal_extension">Postal Extension :</label>-->
		
		                                    <label for="phone_type_loc">Phone Type :</label>
		                                </td>
		                                <td>
		                                    <select name="phone_type_loc" id="phone_type" class="primaryPhoneType" <?php echo $disabled?>>
												<option value="">--Select--</option>
									            <?php foreach ($arrPhoneType as $key=>$type){?>
									            <option value="<?php echo $key?>" <?php if(isset($arrLocationData['phone_type']) && $arrLocationData['phone_type']==$key) echo "selected='selected'";?>><?php echo $type;?></option>
									            <?php }?>
											</select>
											<span id="phone_type_loc" style="color:red"></span>
		                                </td>
		                            </tr>
		                            <tr>
		                                <td class="alignRight">
		                                    <!--<label for="postal_city">Postal City :</label>--><label for="phone_number_loc">Phone Number :</label>
		                                </td>
		                                <td>
		<!--                                    <input type="text" name="postal_city" id="postal_city"
		                                    <?php
		                                    if ($subContentPage=='edit' && $arrLocationData['postal_city'] != "") {
		                                        echo "value=" . $arrLocationData['postal_city'];
		                                    }
		                                    ?>
		                                           />-->                                        
		                                    <input type="text" name="phone_number_loc" maxlength="15" id="phone_number_loc" 
		                                    <?php                                    
		                                    if (isset($arrLocationData)) {
		                                        if ($arrLocationData['phone_number'] != "") {
		                                            echo 'value="' . $arrLocationData['phone_number'] . '"';
		                                        }
		                                    }
		                                    ?>
		                                  <?php echo $disabled?> /> <span id="phoneError"></span>
		
		                                </td>
		                            </tr>
		
		                        </table>
		                    </td>
		                </tr>
		                
		
		                <!-- End of Personal and Professional Information -->
		
		
		            </tbody>
		        </table>
		       </td>
	        </tr>
	        <?php if($checkKolAssignedToUser || $client_id==INTERNAL_CLIENT_ID){ ?>
	        <tr>
                    <td colspan="2" style="text-align: center;">
<!--                        <input type="submit" value="Save" class="blueButton" rel="tooltip" data-original-title="Save KOL" id="save_kol" onclick="saveKol();"/>-->
                        <a class="blueButton" rel="tooltip" href="#" data-original-title="Save <?php echo lang("HCP");?>" id="save_kol" onclick="checkDuplicatesAndSave();">Save</a>
                        <?php
                        if ($subContentPage=='edit') {
                            ?>

                            <a class="blueButton" rel="tooltip" href="<?php echo base_url(); ?>kols/view/<?php echo $arrKolData['id']; ?>" data-original-title="Cancel">Cancel</a>
                            <?php
                        } else {
                            ?>
                            <a class="blueButton" rel="tooltip" href="<?php echo base_url(); ?>kols/list_kols_client_view" data-original-title="Cancel">Cancel</a>
                        <?php } ?>
                    </td>
		                
	        </tr>
	        <?php } ?>
	       </table>
	      </form>
		<?php } ?>
		<table>
        <tr>	
            <td colspan="2">

                <!--  List Location details-->
                <div id="location">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperLocation">
                        <table id="JQBlistLocationResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
                    <?php $arrKol['kol_id']=$arrKol['id'];?>
					<?php //if ($add_location == 1) {
					     if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addLocationButton" style="text-decoration: none;float: right;"onclick="addLocation();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add Location">Add Location</a></div>
                    <?php //}
					     } ?>
                </div>
            </td>
        </tr>
</table>
</div>
<div id="detailsContainer">
	
	<table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="phone">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperPhone">
                        <table id="JQBlistPhoneNumberResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
					<?php //if ($add_location == 1) {
					     if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addPhoneNumberButton" style="text-decoration: none;float: right;"onclick="addPhoneNumber();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add Phone">Add Phone</a></div>
                    <?php //}
					     } ?>
                </div>

            </td>
        </tr>
    </table>
    <table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="staff">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperStaff">
                        <table id="JQBlistStaffResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
					<?php //if ($add_location == 1) {
					    if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addStaffButton" style="text-decoration: none;float: right;" onclick="addStaffs();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add Staff" >Add Staff</a></div>
                    <?php //}
					     } ?>
                </div>

            </td>
        </tr>
    </table>
    <table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="email">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperEmails">
                        <table id="JQBlistEmailResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
					<?php //if ($add_location == 1) {
					     if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addEmailButton" style="text-decoration: none;float: right;" onclick="addEmails();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add Email">Add Email</a></div>
                    <?php //}
					     } ?>
                </div>

            </td>
        </tr>
    </table>
    <table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="stateLicense">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperStateLicense">
                        <table id="JQBliststateLicenseResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
					<?php //if ($add_location == 1) {
					     if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addStateLicenseButton" style="text-decoration: none;float: right;"onclick="addLicenses();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add License">Add License</a></div>
                    <?php //}
					     } ?>
                </div>
            </td>
        </tr>
    </table>
   <?php /*?> <table>
    	<tr>	
            <td colspan="2">
                <table  id="bestTime" class="tabularGrid">
                    <caption class="sectionHeaderTitle">Best Available Time
                    <div id="collapseExpandButton" class="expandSlider collapseSlider">
						<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
					</div>
                    </caption>
                    
                    <tr>
                        <th>
                            Monday
                        </th>
                        <th>
                            Tuesday
                        </th>
                        <th>
                            Wednesday
                        </th>
                        <th>
                            Thursday
                        </th>
                        <th>
                            Friday
                        </th>
                        <th>
                            Saturday
                        </th>
                        <th>
                            Sunday
                        </th>
                    </tr>
                    <tr>
                        <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(0);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">
                            Add Time
                        </a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">
                        <table>
                            <?php
                            foreach ($best_times["Monday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(0, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(1);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">

                        <table>
                            <?php
                            foreach ($best_times["Tuesday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(1, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(2);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">

                        <table>
                            <?php
                            foreach ($best_times["Wednesday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img     title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(2, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(3);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">

                        <table>
                            <?php
                            foreach ($best_times["Thursday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(3, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(4);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">
                        <table>
                            <?php
                            foreach ($best_times["Friday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(4, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>

                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(5);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">

                        <table>
                            <?php
                            foreach ($best_times["Saturday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(5, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
                    <th>
                    <div class="time_data">

                    </div>
                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','add',$arrKol)){ ?>
                    <div class="add_time_data">
                        <a id="addBestTime" class="NewBlueButton NewAddIcon addBestTimeButton" onclick="addBestTime(6);
                                return false;" href="#" rel="tooltip" data-original-title="Add Time">Add Time</a>
                    </div>
                    <?php } ?>
                    <div class="time_data_view">

                        <table>
                            <?php
                            foreach ($best_times["Sunday"] as $best_time) {
//                                pr($best_time);
                                ?>
                                <tr id="time_<?php echo $best_time['id'] ?>">
                                    <td><?php echo $best_time['time']; ?></td>
                                    <?php if($this->common_helpers->isActionAllowed('best_kol_time','delete',$best_time)){ ?>
                                    <td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url(); ?>images/delete_active.png" onclick="deleteBestTime(6, <?php echo $best_time['id']; ?>);"></td>
                                    <?php } ?>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    </th>
        </tr>
    </table>
</td>
</tr>
    </table><?php */?>
    <table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="assignClients">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperAssign">
                        <table id="JQBlistassignResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
					<?php //if ($add_location == 1) {
					     if($this->common_helpers->isActionAllowed('kol_details','add',$arrKol)){ ?>
                        <div style="overflow: hidden;margin-top: 5px;"><a class="NewBlueButton NewAddIcon addAssignKolButton" style="text-decoration: none;float: right;"onclick="addAssign();
                                                                                    return false;" href="#" rel="tooltip" data-original-title="Add Assign">Add Assign</a></div>
                    <?php //}
					     } ?>
                </div>
            </td>
        </tr>
    </table>
    <?php if(KOL_CONSENT && $arrKolData['opt_in_out_status'] == 4) { ?>
    <table>
        <tr>	
            <td colspan="2">
			
                <!--  List Location details-->
                <div id="optLog">
                    <!-- Start of JQGrid based Table to Location Results -->
                    <div class="gridWrapper" id="gridWrapperOptLog">
                        <table id="JQBlistoptResultSet"></table>
                        <!--<div id="listLocationPages"></div>-->
                    </div>
                </div>
            </td>
        </tr>
    </table>
    <?php }?>
</div>
<div id="micro" class="microProfileDialogBox">
		<div class="microViewProfile profileContent"></div>
</div>