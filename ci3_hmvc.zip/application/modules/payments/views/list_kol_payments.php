<script type="text/javascript">
	var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
	var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
	var data={};
	var kolId ="<?php echo (isset($arrKol))?$arrKol['kols_client_visibility_id']:null;?>";
	var kol_unique_id 	= '<?php echo $arrKol['kols_client_visibility_unique_id']?>'; 
	var org_contract = '<?php echo ORGS_CONTRACT;?>';
	var contractType = "kol";
	var subContentPage	= '<?php echo $subContentPage;?>';
	var arrExcludeColumnsInExcelExport = new Array('act'); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by');
	$(document).ready(function(){
		$('#monthlyreport').datepicker({
	        changeYear: true,
	        changeMonth : true,
	        showButtonPanel: true,
	        dateFormat: 'mm/yy',
	        onClose: function(dateText, inst) { 
	            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
	        }
	    });  
		$('#monthto').datepicker({
	        changeYear: true,
	        changeMonth : true,
	        showButtonPanel: true,
	        dateFormat: 'mm/yy',
	        onClose: function(dateText, inst) { 
	            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
	        }
	    }); 
		listPayments();
	});
</script>
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'js/custom_js/jqgridExportToExcel',
			'modules/payments/js/payments',
			'alerts/jquery.alerts',
		'js/jquery.autocomplete',
		'jquery_validator/dist/jquery.validate',
		'datepicker/js/daterangepicker.jQuery'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.ui-datepicker-calendar {
	display: none;
}
.excelExportIcon{
	float: right;
	margin-right: 50px;
	margin-right: 20px !important;
}
.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
	color: #000;
}
</style>
<div id="listPayments">
	<div class="row">
		<div class="pull-right row_padding form-inline">
			<label for=monthlyreport>month from :</label>
			<input type="text" class="form-control" name="monthlyreport" id="monthlyreport" placeholder="click to select" />
			<label for=monthlyreport>to:</label>
			<input type="text" class="form-control" name="monthto" id="monthto" placeholder="click to select"/>
			<button onclick="listPayments();" type="button" class="btn custom-btn" id="filterbutton" >Apply filter</button>
			<?php if($role_permissions[$module_id]["add"]==1){?>
				<a href="<?php echo base_url().'payments/payments/add_payment/'.$arrKol['kols_client_visibility_unique_id'];?>" type="button" class="btn custom-btn" title="Add Affiliation">Add Payment</a>
			<?php }?>
			<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_payments_in_excel();">
				<a href="#" rel="tooltip" data-original-title="Export Payment Details into Excel format">&nbsp;</a>
			</div>
		</div>
	</div>
	<form action="<?php echo base_url()?>payments/payments/export_payment_details" method='post' id="export">
		<input type="hidden" name="payment_ids" value="" id='ids'/>
		<input type="hidden" name="filters"  id="excel-filters"/>
	</form>
	<div class="gridWrapper" id="gridContainer">
		<div id="listPaymentsPage"></div>
		<table id="listPaymentsResultSet"></table>
	</div>
</div>