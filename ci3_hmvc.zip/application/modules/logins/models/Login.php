<?php
class Login extends CI_Model {
	function getUserDetails($username,$isUserName=false) {
		$keyField = $isUserName ? 'user_name' : 'id';
		$arrWhere = array (
				$keyField => $userId
		);
    	$this->db->select('*');
    	$this->db->where($keyField,$username);
    	$this->db->limit(1);
        $query = $this->db->get('client_users');
        $result = $query->result_array();
        return $result[0];
    }
    function getUserDetailsByEmailId($email) {
    	$this->db->select('*');
    	$this->db->where('email',$email);
    	$this->db->limit(1);
    	$query = $this->db->get('client_users');
    	$result = $query->result_array();
    	return $result[0];
    }
    function updateNewPasswordKey($newPasskey, $userId) {
    	$this->db->set('new_password_key', $newPasskey);
    	$this->db->set('new_password_creation', date('Y-m-d H:i:s'));
    	$this->db->where('id', $userId);
    	$this->db->update('client_users');
    }
	function getLandingPageByClientID($client_id){
		$landingUrl="";
		$this->db->select('url');
		$this->db->where('client_id',$client_id);
		$this->db->where('is_landing_page',1);
		$this->db->limit(1);
		$query=$this->db->get('client_menu_visibilities');
		$result = $query->result_array();
		foreach($result as $key=>$value){
			$landingUrl=$value['url'];
		}
		return $landingUrl;
	}
	function menuListing($client_id=null){
		$this->db->select('client_menu_visibilities.*,primary_name.label as primaryName,primary_name.parent_id as prim_parent_id,secondary_name.label as secondaryName,secondary_name.parent_id as sec_parent_id');
		$this->db->join('client_menu_visibilities as primary_name','primary_name.id=client_menu_visibilities.parent_id','left');
		$this->db->join('client_menu_visibilities as secondary_name','secondary_name.id=primary_name.parent_id','left');
		if($client_id!=null){
			$this->db->where('client_menu_visibilities.client_id',$client_id);
		}
		$this->db->where('client_menu_visibilities.is_visible',1);
		$query=$this->db->get('client_menu_visibilities');
		$result = $query->result_array();
		$arrModuleId=array();
		foreach($result as $key=>$value){
			if($value['parent_id']==0){
				$arrModuleId[$value['label']][]=$value['url'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']==0)){
				$arrModuleId[$value['primaryName']][$value['label']][]=$value['url'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']!=0) && ($value['sec_parent_id']==0)){
				$arrModuleId[$value['secondaryName']][$value['primaryName']][$value['label']][]=$value['url'];
			}
		}
		return $arrModuleId;
	}
	function checkExpirekey($arrDetails) {
		$this->db->where('id', $arrDetails['userId']);
		$this->db->where('new_password_key', $arrDetails['newPassKey']);
		$arrRsult = $this->db->get('client_users');
		
		if ($arrRsult->num_rows() == 0) {
			return false;
		}else{
			foreach ($arrRsult->result_array() as $row) {
				$arrDetails1[] = $row;
			}
			$todaysDate = date('Y-m-d H:i:s');
			$creationDate = $arrDetails1[0]['new_password_creation'];
			
			$todaysDate = strtotime($todaysDate);
			$creationDate = strtotime($creationDate);
			$minus = $todaysDate - $creationDate;
			if ($minus > 86400) {
				return false;
			} else {
				return true;
			}
		}
	}
	function getUserRecentPassword($id){
		$this->db->select('password');
		$this->db->where('user_id',$id);
		$this->db->order_by('id','desc');
		$this->db->limit(RESTRICT_NO_OF_PASSWORDS_TO_REUSE);
		$arrUsers = $this->db->get('password_analytics');
		foreach($arrUsers->result_array() as $row){
			$retUsers[] = $row;
		}
		return $retUsers;
	}
	function resetPassword($arrDetails, $userId) {
		$arrDetails['new_password_key'] = NULL;
		$arrDetails['new_password_creation'] = NULL;
		$this->db->where('id', $userId);
		return $this->db->update('client_users', $arrDetails);
	}
	function resetFailedAttempts($userId, $isUserName = false) {
		$keyField = $isUserName ? 'user_name' : 'id';
		$arrWhere = array (
				$keyField => $userId
		);
		$this->common_helper->updateEntity ( 'client_users', array ('failed_attempts' => 0), $arrWhere );
	}
	function updatePassword(){
		$landingUrl=array();
		$this->db->select('user_name');
		$query=$this->db->get('client_users');
		$result = $query->result_array();
		foreach($result as $key=>$value){
			$landingUrl[]=$value['user_name'];
		}
		$hasher = new PasswordHash( PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE );
		$password	= '';
		foreach ($landingUrl as $key=>$value){
			$password	= $hasher->HashPassword ( $value);
 			$this->db->where('user_name', $value);
 			$this->db->update('client_users', array('password'=>$password));
		}
	}
	function checkUserRoleType($userId){
		$this->db->where('manager_id',$userId);
		$query=$this->db->get('client_users');
		 if(($query->num_rows())>0)
		 	return 2; //admin 
		 else 
		 	return 1; //user
	}
}