<?php
/**
 * Controller for Campaign operations
 * @author Vinod H
 * @since 6.2.2
 * @package application.controllers	
 * @created on 28-03-2016
 * 
 */

class Campaigns extends controller{
	
	function Campaigns(){
		parent::Controller();
		$this->load->model('campaign');
		$this->load->model('common_helpers');
	}

	function index(){
		$this->list_campaigns();
	}
	/**
	 * Display 'list_campaigns' view page
	 * @ACL-Discription Display All Campaign Deatil
	 */
	function list_campaigns(){
		//Analyst App to be accessed by only Aissel users.
		$this->common_helpers->checkUsers();
		$data['contentPage'] 	= 'campaigns/list_campaigns';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Display All Campaign Deatil",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List Campaigns Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/**
	 * Display 'add campaign' view page
	 * @ACL-Alias Add Campaign
	 * @ACL-Discription Display Form to Add Campaign Deatil
	 */
	function add_campaign(){
		//Analyst App to be accessed by only Aissel users.
		$this->common_helpers->checkUsers();
		$data['arrProjects']			= $this->campaign->getAllProjects();
		$data['contentPage'] 	= 'campaigns/add_campaign';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Display Form to Add Campaign Deatil",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add Campaigns Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/**

	 * Display 'edit_campaign' view page
	 * @param int $campaignId

	 * @ACL-Alias Edit Campaign

	 * @ACL-Discription Display Form to Edit Campaign Detail

	 */

	function edit_campaign($campaignId){

		//Analyst App to be accessed by only Aissel users.

		$this->common_helpers->checkUsers();
		$arrCampaigns			= $this->campaign->editCampaign($campaignId);

		$data['arrProjects']			= $this->campaign->getAllProjects();
		$data['campaignKols']			= $this->campaign->getCampaignKolsIds($campaignId);
		foreach($arrCampaigns as $row){
			$data['campName'] = $row['name']; 
			$data['campId'] = $row['id'];
			$data['campDescription'] = $row['description'];
			$data['campShortCode'] = $row['short_code'];
			$data['campIdentificationId'] = $row['identification_id'];
		}

		$data['contentPage'] 	= 'campaigns/add_campaign';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Display Form to Edit Campaign Detail",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Edit Campaigns Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);

	}
	/**

	 * Get Campaign short code if exist from 'campaign' Table

	 * @param $arrData

	 * @return boolean

	 */
	function is_already_exist($arrData){
		return $this->campaign->isValidCampaign($arrData);
	}
	
	/**
	 *  Saving Campaign Deatils 
	 *  @return  json
	 */	
	function save_campaign(){
		
		// set validation rules
		// to validate whether the campaign name or campaign short code exist
		$id = $this->input->post('campaign_id');
		$data['msgName'] = '';
		$arrData['id'] = $this->input->post('campaign_id');
		$arrData['name'] = $this->input->post('campaign_name');
		$arrData['shortcode'] = $this->input->post('campaign_short_code');
		$isValid = $this->is_already_exist($arrData);
		if($isValid)
		{
			$data['status']	= 0;
			$data['msgName'] = 'The Campaign Short Code already exists. Please choose another';
		}
		else{
			$arrCampaign['name']			=	$this->input->post('campaign_name');
			$arrCampaign['short_code']		=	$this->input->post('campaign_short_code');
			$arrCampaign['identification_id']		=	$this->input->post('campaign_identification_id');
			$arrCampaign['description']		=	$this->input->post('campaign_description');
			$arrCampaign['modified_by']		=	$this->session->userdata('user_id');
			$arrCampaign['modified_on']		=	date('Y-m-d H:i:s');
			if($id > 0)//If Id than update campaign details
			{
				$arrCampaign['id']		=	$id;

				$arrCampaign['modified_by']		=	$this->session->userdata('user_id');

				$arrCampaign['modified_on']		=	date('Y-m-d H:i:s');

				$this->campaign->updateCampaign($arrCampaign);//Update for campaigns table					
				
				$arrupdatedKol = $this->input->post('kolId');//Selected Kols
				$arrInKol = $this->input->post('kolSameId');//Kols from perticular campaign
				if(!is_array($arrInKol)){
					$arrInKol	= array();
				}
				$arrInsertKols = array_diff($arrupdatedKol,$arrInKol);//list of kols not in  perticular campaign
				$arrDeleteKols = array_diff($arrInKol,$arrupdatedKol);//list of kols in Selected Kols
				$arrInsertKols = array_filter($arrInsertKols);
				$arrDeleteKols	= array_filter($arrDeleteKols);
				if(count($arrDeleteKols) > 0){//If $arrDeleteKols than delete kols for particular campaign
						$arrCampaignKols['kol_id'] = $arrDeleteKols;
						$arrCampaignKols['campaign_id'] = $id;

						$this->campaign->deleteCampaignKols($arrCampaignKols);

				}
				if(count($arrInsertKols) > 0){//If $arrInsertKols than insert kols for particular campaign
					foreach($arrInsertKols as $key=>$row){

						$arrCampaignKols['kol_id'] = $row;

						$arrCampaignKols['campaign_id'] = $id;
						$arrCampaignKols['created_by']		=	$this->session->userdata('user_id');

						$arrCampaignKols['created_on']		=	date('Y-m-d H:i:s');

						$arrCampaignKols['modified_by']		=	$this->session->userdata('user_id');

						$arrCampaignKols['modified_on']		=	date('Y-m-d H:i:s');

						$this->campaign->saveCampaignKols($arrCampaignKols);
// 						echo $this->db->last_query();exit;
					}
				}
				
				$data['status']	= 1;
				
			}else{//If not Id than insert campaign details
				$arrCampaign['created_by']		=	$this->session->userdata('user_id');

				$arrCampaign['created_on']		=	date('Y-m-d H:i:s');

				if($lastInsertId = $this->campaign->saveCampaign($arrCampaign))

				{
				
					//echo json_encode($lastInsertId);

					$arrCampaignKols['campaign_id'] = $lastInsertId;

					$kolsIds = $this->input->post('kolId');

					foreach($kolsIds as $key=>$row){

						$arrCampaignKols['kol_id'] = $row;

						$arrCampaignKols['created_by']		=	$this->session->userdata('user_id');

						$arrCampaignKols['created_on']		=	date('Y-m-d H:i:s');

						$arrCampaignKols['modified_by']		=	$this->session->userdata('user_id');

						$arrCampaignKols['modified_on']		=	date('Y-m-d H:i:s');

						$this->campaign->saveCampaignKols($arrCampaignKols);

					}

				}
				$data['status']	= 1;
			}
			
		}
		echo json_encode($data);
	}
	
	/**

	 *  List Campaign Deatils

	 *  @return  json

	 */
	function list_campaigns_grid(){

		ini_set('memory_limit','-1');

		$page	= $_REQUEST['page']; // get the requested page

		$limit 	= $_REQUEST['rows']; // get how many rows we want

		$sidx 	= $_REQUEST['sidx']; // get index row - i.e. user click to sort

		$sord 	= $_REQUEST['sord']; // get the direction

		if(!$sidx) $sidx =1;

		// connect to the database

		$filterData=$_REQUEST['filters'];
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];
		}
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
		$count	= $this->campaign->getProcessedCampaigns($limit,$start,true,$sidx,$sord,$whereResultArray);

		if( $count >0 )

		{

			$total_pages = ceil($count/$limit);

		}

		else { $total_pages = 0;

		}

		if ($page > $total_pages)

			$page=$total_pages;

		$start = $limit*$page - $limit; // do not put  $limit*($page - 1)

		$arrCampaignDetailResult	= $this->campaign->getProcessedCampaigns($limit,$start,false,$sidx,$sord,$whereResultArray);

		$responce->page = $page;

		$responce->total = $total_pages;

		$responce->records = $count;

		$i = 0;

		foreach($arrCampaignDetailResult->result_array() as $row){

			$responce->rows[$i]['id']=$row['id'];
			$url	= base_url().'register/'.$row['short_code'];
			$id = $row['is_enable'];
			if($row['is_enable']==0){
				$row['is_enable'] = 'Enable';
				$row['color'] = 'Green';
			}
			else{
				$row['is_enable'] = 'Disable';
				$row['color'] = 'Red';
			}
			$row['url']	= '<a href="'.$url.'">'.$url.'</a>';
			$row['action']		= '<div class="actionIcon editIcon"><a href="'.base_url().'campaigns/edit_campaign/'.$row['id'].'" title="Edit">&nbsp;</a></div><div><a href="#" class="del_'.$row['id'].'" id="'.$row['id'].'" onclick="deleteCampaign('.$row['id'].');" style="color:'.$row['color'].';" title="'.$row['is_enable'].'">'.$row['is_enable'].'</a></div>';

			$responce->rows[$i]['cell']=array($row['id'],$row['name'],$row['short_code'],$row['url'],$row['description'],$row['action']);

			$i++;

		}

		echo json_encode($responce);

	}
	/**
	 * Search by the respective fields
	 * @param string $array
	 * @param string $key
	 * @return multitype:|NULL
	 */
	function delete_campaigns($campaignId,$columnValue){		
		$resultRow = $this->db->update('campaigns', array('is_enable'=>$columnValue),array('id' => $campaignId));
		if ($columnValue == 1){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DISABLE,
					'description' => 'Disable Campaigns',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $campaignId,
					'transaction_table_id' => CAMPAIGNS,
					'transaction_name' => "Disable Campaigns",
					'parent_object_id' =>  $campaignId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
		}else {
			//Add Log activity
			$arrLogDetails = array(
					'type' => ENABLE,
					'description' => 'Enable Campaigns',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $campaignId,
					'transaction_table_id' => CAMPAIGNS,
					'transaction_name' => "Enable Campaigns",
					'parent_object_id' =>  $campaignId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
		}
		return $resultRow;
	}
	
}
