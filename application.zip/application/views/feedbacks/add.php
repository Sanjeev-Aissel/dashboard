<?php
/**
 * File Description : feedback form
 * 
 * @author		Laxman K
 * @since		5.0
 * @Created on  Aug 21, 2012
 */
?>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery/jquery.validate1.9.min.js"></script>
<script type="text/javascript">
	var formSubmitted	= false;
		function setFlag(){
			formSubmitted	= true;
		}
		function closemodalbox(){
			$("#feedbackDialogContainer").dialog("close");
		}
		$(document).ready(function(){
			$('#cancelFeedback').click(function(){
				closemodalbox();
			});
			$("#upload_target").load(function(){
				if(formSubmitted){
					$('div.msgBox').text("Your Request has been submitted to the Support Team. We will get back to you shortly.");
					$('div.msgBox').css({color:'#116700'});
					setTimeout(closemodalbox, 4000);
				}
		    });
			var validator = $("#persnoalForm").validate({
					debug: false,
					// The errorPlacement has to take the table layout into account
					errorPlacement: function(error, element) {
						formSubmitted	= false;
						if ( element.is("select") )
							error.appendTo( element.parent());
						else
							error.insertAfter(element);
					}
				});
			//	$('#saveFeedback').click(function(){
			//		$("#persnoalForm").submit();
			//	});
			});
/*	
	 var _validFileExtensions = [".txt",".doc", ".docx", ".xls", ".rtf", ".pdf",".jpg", ".jpeg", ".bmp", ".gif", ".png"];

	 function validate(oForm) {
	     var arrInputs = oForm.getElementsByTagName("input");
	     for (var i = 0; i < arrInputs.length; i++) {
	         var oInput = arrInputs[i];
	         if (oInput.type == "file") {
	             var sFileName = oInput.value;
	             if (sFileName.length > 0) {
	                 var blnValid = false;
	                 for (var j = 0; j < _validFileExtensions.length; j++) {
	                     var sCurExtension = _validFileExtensions[j];
	                     if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
	                         blnValid = true;
	                         break;
	                     }
	                 }

	                 if (!blnValid) {
	                     jAlert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
	                     return false;
	                 }
	             }
	         }
	     }

	     return true;
	 }
	 */
</script>
<style type="text/css">
label.error {
    background: none repeat scroll 0 0 transparent;
    border: 0 none;
    color: red;
    font-weight: normal;
    margin: 0;
    padding: 0;
}
.error {
    background-position: 10px center;
    background-repeat: no-repeat;
    padding: 2px 0;
}
#feedback_box {
    color: #626262;
    font-size: 12px;
}

#feedback_box .block table tr th .feedback_label{
	float:right;
	color: #626262;
    font-size: 11px;
    padding-right:5px;
    padding: 2px;
}

#feedback_box table tr th, #feedback_box table tr td {
    padding:8px 0px;
    margin:0px;
    vertical-align: top;
}
#feedback_box .block input[type="text"]{
	height: 20px;
}
#feedback_box select{
	height: 25px;
	padding: 2px;
}
#feedback_box .block input[type="text"], #feedback_box select, #feedback_box textarea{
	display:block;
	margin: 0px;
}
#subject{
	width: 400px;
}

</style>
<div id="feedback_box">
	<div class="formHeader">
		<h5>Submit a ticket</h5>
		<div class="msgBox">
		</div>
	</div>
	<div class="block" style="display: block;">
		<form onsubmit="setFlag();" action="<?php echo site_url(); ?>feedbacks/save_feedback" method="post" id="persnoalForm" name="persnoalForm" class="validateForm form_place" enctype="multipart/form-data" target="upload_target">
			<table width="98%" align="center">
				<tr>
					<th><label class="feedback_label" for="subject">Subject:<span class="required">*</span></label></th>
					<td>			
						<input type="text" name="subject" id="subject" class="required" size="30" />
					</td>
				</tr>
				<tr>
					<th><label class="feedback_label" for="feedback_type">Type:</label></th>
					<td>
						<select name="feedback_type" id="feedback_type">
							<!--<option value="">--Select Type--</option>
							--><?php foreach($arrFeedbackTypes as $row){?>
								<option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
							<?php }?>
						</select>
					</td>
				</tr>
				<tr>
					<th style="vertical-align:top;"><label class="feedback_label" for="description">Description:<span class="required">*</span></label></th>
					<td>
						<textarea name="description" id="description" class="required"> </textarea>
					</td>
				</tr>			
				<tr>
					<th><label class="feedback_label" for="feedback_file">Attach a file:</label></th>
					<td>
						<input type="file" name="feedback_file" id="feedback_file" />
					</td>
				</tr>
				<tr>
					<td colspan="2" style="text-align:center;">
						<input type="submit" value="Submit" name="submit" id="saveFeedback"></input>	
						<input type="button" value="Cancel" name="cancel" id="cancelFeedback"></input>
					</td>			
				</tr>
			</table>
			<iframe id="upload_target" name="upload_target" src="" style="width:0;height:0;border:0px solid #fff;"></iframe>
		</form>
	</div>
</div>