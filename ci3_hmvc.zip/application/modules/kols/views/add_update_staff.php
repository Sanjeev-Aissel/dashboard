<link  href="<?php echo base_url().MODULES_ASSETS;?>kols/css/kols.css" rel="stylesheet">
<?php echo $html_form;?>
<div id="msgBox">
</div>
<script>
var id = '<?php echo $getSavedDetails['id'];?>';
$(document).ready(function() {
		$("#saveKolEmailForm").validate({
			rules: {
				email_type: "required",
				email: {
		            required: true,
		            officialemail: true
		        }
			},
			messages: {
				email_type: {
					required: "This field is required.",
				},
				email: {
		            required: "Required",
		            officialemail: "Invalid Email"
		        }
			}
		});		
});
</script>