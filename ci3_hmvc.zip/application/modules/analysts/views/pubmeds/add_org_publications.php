<?php
/**
 * File to 'add' Publication details manually for organization
 *
 * @author: Ramesh B
 * @created on: 30-03-2013
 * @package application.views.organizations
 */
?>
<style>
	#pubManualTbl>thead>tr>th{
		font-size: 12px !important;
	}
	.glyphicon {
	    font-size: 14px;
	}
	#pubManualTbl>tbody>tr>td{
	padding:5px !important;
	}
</style>
<script>
	$(function(){
		<?php 
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
				$this->output->set_header("Pragma: no-cache"); 
			?>
	});
	/**
	* Save the new Event Lookup Name
	*/
	function savePublicationManual(){
		if(!$("#pubManualForm").validate().form()){
			return false;
		}
		id = $("#pubManualId").val();
		if(id == ''){
			formAction = '<?php echo base_url();?>pubmeds_org/save_publication_manual';
		}else{
			formAction = '<?php echo base_url();?>pubmeds_org/update_publication_manual';
		}
		
		formData	= $("#pubManualForm").serialize();
		$.ajax({
			type:"post",
			dataType:"json",
			data: formData,
			url:formAction,
			success:function(returnMsg){
				$('div.pubManualMsgBox').fadeIn("fast");
				$('div.pubManualMsgBox').text(returnMsg.msg);
				if(returnMsg.saved){
					$('div.pubManualMsgBox').removeClass('error');
					$('div.pubManualMsgBox').addClass('success');

					// Call the 'CloseDialog' method with delay
					setTimeout(closeDialog, 1500);
				}else{
					$('div.pubManualMsgBox').removeClass('success');
					$('div.pubManualMsgBox').addClass('error');
				}

				$('div.pubManualMsgBox').fadeOut(10000);
			}
		});
	}

	//Validates the pubManualForm
	function savePublicationManualValidate(){

		if(!$("#pubManualForm").validate().form()){
			return false;
		}else
			return true;
	}

	/**
	* Closes the Dialog Box with some time delay
	*/
	function closeDialog(){
		$("#publicationAddContainer").dialog("close");
	}
	
	//Date validation
	function validateDateFormat(e,src) {
		if (!e) var e = window.event
		if (e.keyCode) code = e.keyCode;
		else if (e.which) code = e.which;
	 
	 	if(src.value == null || src.value == "") {
	 		return true;
	 	}
	 
		if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
			jAlert("Please enter the date in mm/dd/yyyy format!");
			src.focus();
		}
	}

	function dateFormat(e,src) {		
		if (!e) var e = window.event
		if (e.keyCode) code = e.keyCode;
		else if (e.which) code = e.which;
		
		if(code != 37 && code != 38 && code != 39 && code != 40) { 
			if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
				src.value=src.value.replace(/[^0-9\/]/g,'');  
			
				if(code!=8 && code!=46) // not backspace or delete
				{	
					src.value=src.value.replace(/[^0-9]/g,'');
					
					if (src.value.length == 2) {
				        src.value += "/";
				    }
				    				
					if (src.value.length > 2) {
						if(src.value.indexOf('/') != 2) {
							src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
						}
					}
					
					if (src.value.length == 5) {
				        src.value += "/";
				    }
				    
					if (src.value.length > 5) {
						if(src.value.lastIndexOf('/') != 5) {
							src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
						}
					}
					
					if(src.value.length >= 10)
					{
						return false;
					}
				}  
			}
		}
		return true;
	}

	//Validation
	var validationRules	=  {
			required:true,
			pubManualUrl: {
				url: true
			}
		};
	
	var validationMessages = {
		required: "Required",
		url: "Please enter a valid URL address"
	};

	//Additional fields to Delete
	function deleteAuthor(id){
		$('#pubAuthorDelete'+id).remove();
	}
	$(document).ready(function(){
		$('.pubManualMsgBox').hide();
		//Adds the another Author input field below the current input field
		$("#addMoreAuthors").click(function(){
			var noOfAuthors=0;
			noOfAuthors=$("#noOfAuthors").val();
			noOfAuthors++;
			var newAuthor="<tr class=\"auths\" id=\"pubAuthorDelete"+noOfAuthors+"\"><td><input type='text' class='form-control' name='last_name[]' id=\"pubAuthorsLastName"+noOfAuthors+"\" /></td><td><input type='text' class='form-control' name='fore_name[]' id=\"pubAuthorsForeName"+noOfAuthors+"\" /></td><td><input type='text' class='form-control' name='initials[]' id=\"pubAuthorsInitials"+noOfAuthors+"\" class=\"smallField\"/></td><td style=\"vertical-align: middle;\"><a href=\"#\" onclick=\"deleteAuthor("+noOfAuthors+");\"><span class=\"glyphicon red glyphicon-remove-circle\"></span></a></td></tr>";
			$("#pubManualTbl").append(newAuthor);
			$("#noOfAuthors").val(noOfAuthors);
		});
		$('#pubCreatedDate').datepicker({
			dateFormat: 'mm/dd/yy',
			onSelect: function(dateText, inst) {
				$('#pubCreatedDate').removeClass('error');
		        $('#pubCreatedDate').next().hide();
		    }
		});
	});
</script>
	<div>
		<form action="<?php echo base_url()?>pubmeds_org/<?php if($publication['id']=='') echo 'save_publication_manual'; else if($publication['id']!='') echo 'update_publication_manual';?>"  method="post" id="pubManualForm" name="pubManualForm" class="validateForm form-horizontal" onsubmit="return savePublicationManualValidate();">
		<input type="hidden" name="id"  value="<?php echo $publication['id'];?>" id="pubManualId"></input>
		<input type="hidden" name="org_id"  value="<?php echo $orgId?>" id="orgId"></input>
		<div class="msgBoxContainer"><div class="pubManualMsgBox"></div></div>
		<div class="form-group">
				<label class="col-sm-2 align_right">Article Name:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text"  class="required form-control" name="article_title" value="<?php echo $publication['article_title'];?>" id="pubArticleTitle" class="required"/>
		    	</div>
		    	<label class="col-sm-2 align_right">Journal Name:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text"  class="required form-control" name="journal_name" value="<?php echo $publication['journal_name'];?>" id="pubJournalName" class="required"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-2 align_right">Date:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text" name="created_date" value="<?php echo $publication['created_date'];?>" id="pubCreatedDate" class="required form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)"/>
		    	</div>
		    	<label class="col-sm-2 align_right">URL:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="link" value="<?php echo $publication['link'];?>" id="pubLink" />
		    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 align_right">Abstract:</label>
			<div class="col-sm-10">
				  <textarea class="form-control" name="abstract_text" id="pubAbstractText" rows="3" cols="30"><?php echo $publication['abstract_text'];?></textarea>
	    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 align_right">Authors:</label>
			<div class="col-sm-10">
				<table class="table" id="pubManualTbl">
					<thead>
					<tr>
						<th width="32%">Last Name:</th>
						<th width="32%">Fore Name:</th>
						<th width="32%">Initials:</th>
						<th width="4%">	
							<div id="addMoreAuthors" title="Add Another Author">
								<a href="javascript:void(0);"><span class="glyphicon glyphicon-plus-sign"></span></a>
							</div>
						</th>
					</tr>
					</thead>
					<tbody>
					<?php if($publication['id']=='' || (isset($arrMultipleAuthors) && sizeof($arrMultipleAuthors)==0)){?>
					<tr id="first_aut" class="auths">
						<td>
								<input type="hidden" name="authId"  value="<?php echo $arrAuthors['id'];?>" id="pubAuthId"></input>
								<input type="hidden" name="before_no_of_authors" id="before_no_of_authors" value="<?php echo $publication['no_of_authors'];?>"/>
								<input type="hidden" name="no_of_authors" id="noOfAuthors" value="<?php echo $publication['no_of_authors'];?>"/>
								<input type="text" class="form-control" name="last_name[]" value="<?php echo $arrAuthors['last_name'];?>" id="pubAuthorsLastName"/>
						</td>
						<td>
								<input type="text" class="form-control" name="fore_name[]" value="<?php echo $arrAuthors['fore_name'];?>" id="pubAuthorsForeName"/>
						</td>
						<td>
								<input type="text" class="form-control" name="initials[]" value="<?php echo $arrAuthors['initials'];?>" id="pubAuthorsInitials" class="smallField"/>
						</td>
						<td style="vertical-align: middle;">
						</td>
					</tr>	
					<?php }?>
					
					<?php if(isset($arrMultipleAuthors) && sizeof($arrMultipleAuthors)>=1){?>
					<input type="hidden" name="before_no_of_authors" id="before_no_of_authors" value="<?php echo sizeof($arrMultipleAuthors);?>"/>
					<input type="hidden" name="no_of_authors" id="noOfAuthors" value="<?php echo sizeof($arrMultipleAuthors);?>"/>
						<?php 
							$i=0;
							foreach($arrMultipleAuthors as $author){?>
								<tr id="pubAuthorDelete<?php echo $i;?>" class="auths">		
									<td>
										<input type="hidden" name="authId[]"  value="<?php echo $author['id'];?>" id="pubAuthId<?php echo $i?>" />
										<input type="text" class="form-control" name="last_name[]" value="<?php echo $author['last_name'];?>" id="pubAuthorsLastName<?php echo $i?>" readonly="readonly"/>
									</td>
									<td>
										<input type="text" class="form-control" name="fore_name[]" value="<?php echo $author['fore_name'];?>" id="pubAuthorsForeName<?php echo $i?>" readonly="readonly"/>
									</td>
									<td>
										<input type="text" class="form-control" name="initials[]" value="<?php echo $author['initials'];?>" id="pubAuthorsInitials<?php echo $i?>" class="smallField" readonly="readonly"/>
									</td>								
	        						<td style="vertical-align: middle;">
	            						<a style="cursor: pointer;" onclick="deleteAuthor('<?php echo $author['id'] ?>','<?php echo $i; ?>');"><span class="glyphicon red glyphicon-remove-circle"></span></a>
	            					</td>	            					
	            				</tr>	
					<?php $i++; }?>					
				<?php 	}?>
				</tbody>
				</table>
	    	</div>
		</div>
		<div class="form-group row" style="text-align: center;">
			<p id="duplicate_error" style="color:red;display:none;">Duplicate author entry</p>
   			<button type="button" name="submit"  id="savePubManual" onclick="savePublicationManualValidate();return false;" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
   			<button type="button" onclick="goBack();return false;" class="btn btn-default"><span class="glyphicon red glyphicon-remove-circle"></span> Cancel</button>
		</div>
	</form>
	</div>