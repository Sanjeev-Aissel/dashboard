<?php
class Align_user extends CI_Model {
	function listUsers($clientId){
		$arrUsers	= array();
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		if($this->session->userdata('role_type')==ROLE_USER){
			$userId	= $this->session->userdata('user_id');
			$this->db->where("client_users.id",$userId);
		}
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->select("client_users.id,client_users.first_name,client_users.last_name");
		$this->db->order_by('client_users.first_name, client_users.last_name');
		$arrUserResult = $this->db->get('client_users');
		foreach($arrUserResult->result_array() as $row){
			$arrUsers[] = $row;
		}
		return $arrUsers;
	}
	function insertOrUpdateAssignClient($arrAssignData){
		$id=$arrAssignData['id'];
		$data['status'] = false;
		$dataType 		= 'User Added';
		$client_id 		=$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrData['user_id'] = $arrAssignData['client'];
		$arrData['kol_id'] 	=  $arrAssignData['kol_id'];
		$arrData['type'] 	= $arrAssignData['client_type'];
		if ($id >0) {
			$arrData['modified_by'] =$user_id;
			$arrData['modified_on'] = date('Y-m-d H:i:s');
			$this->db->where('id',$id);
			if ($this->db->update('user_kols',$arrData)){
				$data['status'] =true;
			}
		}else{
			$arrData['created_by'] = $user_id;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			$arrData['data_type_indicator'] = $dataType;
			$lastAssignId = $this->db->insert('user_kols',$arrData);
			if($lastAssignId){
				$data['status'] = true;
				//$data['id'] = $lastAssignId;
			}
		}
		return $data;
	}
	//Function to fetch all User type
	function getAllClientsType(){
		$this->db->select('id,name');
		$arrResultSet = $this->db->get('kol_user_conatct_type');
		return $arrResultSet->result_array();
	}
	function getAssignedUsers($kolId){
		$kolId	= (int)$kolId;
		$clientId = $this->session->userdata('client_id');
		$this->db->select("user_kols.user_id,CONCAT(first_name,' ',last_name) AS full_name",false);
		$this->db->join('client_users','client_users.id=user_kols.user_id');
		$this->db->where('kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		$arrResult = $this->db->get('user_kols');
// 		echo $this->db->last_query();
		$arrUsers = array();
		foreach($arrResult->result_array() as $row){
			$arrUsers[$row['user_id']] = $row['full_name'];
		}
		return $arrUsers;
	}
	function getAssignedUsers1($kolId){
		$clientId = $this->session->userdata('client_id');
		$this->db->select("user_kols.id,user_kols.user_id,user_kols.data_type_indicator,client_created_by.client_id,CONCAT(client_users.first_name,' ',client_users.last_name) AS name,client_users.email,kol_user_conatct_type.name as type,CONCAT(client_created_by.first_name,' ',client_created_by.last_name) as created_by",false);
		$this->db->join('client_users','client_users.id=user_kols.user_id');
		$this->db->join('client_users as client_created_by','client_created_by.id=user_kols.created_by');
		$this->db->join('kols_client_visibility','kols_client_visibility.id = user_kols.kol_id', 'left');
		$this->db->join('kol_user_conatct_type','kol_user_conatct_type.id=user_kols.type','left');
		$this->db->join('kols','kols.id= kols_client_visibility.kol_id','left');
		$this->db->where('user_kols.kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		$arrResult = $this->db->get('user_kols');
		return $arrResult->result_array();
	}
	function getAllUserKolAlignment(){
		$arrUsersKol	= array();
		$arrUserResult = $this->db->get('user_kols');
		foreach($arrUserResult->result_array() as $row){
			$arrUsersKol[$row['user_id']][$row['kol_id']] = $row;
		}
		return $arrUsersKol;
	}
	function deleteKolAlignment($kolIds,$arrUserIds,$role){
		$this->db->where_in('kol_id',$kolIds);
		if(!($role==ROLE_MANAGER)){
			$userId = $this->session->userdata('user_id');
			$this->db->where('user_id',$userId);
		}else{
			$this->db->where_not_in('user_id',$arrUserIds);
		}
		$this->db->delete('user_kols');
	}
	function saveKolAlignment($kolIds,$arrUsers){
		$this->load->model("kols/kol");
		$separator	= '';
		$isInserted	= false;
// 		$arrUsersKol= $this->getAllUserKolAlignment();
		$bulkInsert = 'insert into user_kols values ';
// 		$group_names = explode(',', $this->session->userdata('group_names'));
		$type = DEFAULT_ASSIGN_TYPE;
		$created_by = $this->session->userdata('user_id');
		$created_on = date("Y-m-d H:i:s");
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		foreach($arrUsers as $key=>$userId){
			$userId	= (int)$userId;
			foreach($kolIds as $index=>$kolId){
				$kolId	= (int)$kolId;
				$client_id = $this->session->userdata('client_id');
// 				if($client_id !== INTERNAL_CLIENT_ID  && $this->session->userdata('user_role_id') != ROLE_MANAGER){
// 					$kolRegion = $this->getKolRegion($kolId);
// 					if(!isset($arrUsersKol[$userId][$kolId]) && in_array($kolRegion, $group_names)){
// 						$bulkInsert .= $separator."(null,$userId,$kolId,'2','$created_by','$created_on','$created_by','$created_on','$dataType')";
// 						$separator	= ',';
// 						$arrUsersKol[$userId][$kolId]	= array('user_id'=>$userId,'kol_id'=>$kolId);
// 						$isInserted	= true;
// 					}
// 				}else{
					if(!isset($arrUsersKol[$userId][$kolId])){
						$bulkInsert .= $separator."(null,$userId,$kolId,'2','$created_by','$created_on','$created_by','$created_on','$dataType')";
						$separator	= ',';
						$arrUsersKol[$userId][$kolId]	= array('user_id'=>$userId,'kol_id'=>$kolId);
						$isInserted	= true;
					}
// 				}
			}
		}
		if($isInserted){
			$this->db->query($bulkInsert);
			return true;
		}
		return false;
	}
}