<?php
/**
 * Contains fucntion to list Requested Kols
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.views.kols
 * @created 13-6-2012
 */
 
?>

	
	<style type="text/css">
		#listKols a{
			text-decoration:underline;
			text-align:left;
			float:left;
		}
		.ui-widget-content a {
			color:#000099;
		}
		.icon {
			 padding-top: 6px;
		}
		.buttons {
			float: right;
			margin-top: 6px;
		}
		tr.selectedRow {
		    background-color: #D8DFEA !important;
		}
		#contents{
			padding:10px 50px;
		}
		
		#contents table{
			font-size:125%;
			border-collapse:collapse;
		/*	border:1px solid #ccc; */
		}
		
		#contents table, td, th{
		/*	border:1px solid #ccc; */
		}
		
		h1{
			color:#2E6E9E;
			font-size:170%;
			margin-bottom:10px;
			margin-top:15px;
			text-align:left;
		}
		
		#linkHeaders{
			float:left;
			text-align:right;
		}
		p.addLink{
			margin:0px;
			text-align: right;
		}
		p.addLink a{
			text-decoration:none;
			text-align:right;
			font-size:95%;
			clear:both;
		}
		
		div#listKolsTbl{
/* Commented By Laxman
			margin:0 0 0 10px;
*/
			padding:0;
			width:100%;		
		}
	</style>
	
	<script type="text/javascript">


	$(document).ready(function(){
		
		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#newKolProfile").dialog(addNewKol);
	
	});
	
	function addNewKolProfile(){
		var Kol = new Array();
		$.each($('input[name="exportId[]"]:checked'),function(){
			Kol.push($(this).val());
		});
		if(Kol==''){
			jAlert("Select At least 1 KOL");
			return false;
		}

		if((Kol.length)>1){
			jAlert("Select only 1 KOL");
			return false;
		}
		
		
		$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load('<?php echo base_url()?>requested_kols/add_client_pre_kol/'+Kol[0]);
		return false;	
	}

</script>
<button onclick="addNewKolProfile()">Request Profile</button>
	
	
	</script>
	

					<?php $userRoleId = $this->session->userdata('user_role_id');?>
					<div class="msgBox"></div>
					
					<div id="listKols">
					<div id="listKolsTbl">
						<table class="listResultSet">
							<caption>List of Requested <?php echo lang('KOL');?> profiles </caption>
							<thead>
								<tr>
									<th>ID</th>
									<th>Select</th>
									<th>Name</th>
									<th>Specialty</th>
									<th>Gender</th>
									<th>Organizations</th>
									<th>Created By</th>
									
									<th>Status</th>
								</tr>
							</thead>
							<?php 
								$slNo	= 1;
								foreach($arrKol as $kol){
									echo '<tr id=KOL_'.$kol['kol_id'].'>';
									echo '<td>' .$slNo. '</td>';
										echo "<td class='export'>
												<input type='checkbox' name='exportId[]' value='$kol[kol_id]'>
											</td>";
									if($kol['salutation']<='4'&& $kol['salutation']!='0'){
										$name	= $arrSalutations[$kol['salutation']] . ' ';
									}else{
										$name='';
									}
									$name	.= $kol['first_name'] . ' ';
									$name	.= $kol['middle_name'] . ' ';
									$name	.= $kol['last_name'];
									
									echo '<td><a href="'.base_url().'kols/edit_kol/'.$kol['kol_id'].'">' .$name. '</a></td>';
									if($kol['specialty']!='0'){
										echo '<td>' .$kol['specialty']. '</td>';
									}else{
										echo '<td> &nbsp; </td>';
									}
									echo '<td>' .$kol['gender']. '</td>';
									echo '<td>' .$kol['name']. '</td>';
									
									echo '<td>' .$kol['user_full_name']. '</td>';
						
								
									echo '<td>' .$kol['status']. '</td>';
									echo '</tr>';
									
									$slNo++;
								}
							
							?>
						</table>
							
						
					</div>
				</div>
			<!--
			</div>
			-->		
			
			<!--  End of TABS div for the Horizontal Navigation -->
			

			<!-- Container for the 'Kol's Export' modal box -->
			<div id="newKolProfile" class="microProfileDialogBox">
		<div class="newProfileContent profileContent"></div>
	</div>
			<!--End of  Container for the 'Kol's Export' modal box -->	





