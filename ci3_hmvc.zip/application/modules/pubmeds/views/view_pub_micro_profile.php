<style>
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    border-top: 0px;
    padding: 3px;
}
</style>
<script>
	$(document).ready(function (){
	var title="<?php if($publication['pmid'] > 0){	echo '<a href=\"http://www.ncbi.nlm.nih.gov/pubmed\" target=\"_new\"><img alt=\"Image\" src=\"'.base_url().'assets/images/pubmed_logo.png\" /></a>';}?>";
	title+='<h4><?php echo $publication['article_title'];?></h4>';
	$('.modal-header .modal-title').html(title);
});
</script>
<div id="pubMicroProfileContent">
	<table class="table">
		<?php if(preg_match('/^\d+$/D',$publication['pmid'])){?>
			<tr>
				<th class="align_right" width="25%">PMID:</th>
				<td><?php echo $publication['pmid']; ?></td>
			</tr>
		<?php }else{?>
			<tr>
				<th class="align_right" width="22%">ID:</th>
				<td><?php echo str_replace("-"," ",$publication['pmid']);?></td>
			</tr>	
		<?php } ?>
		<tr>
			<th class="align_right">Journal Name:</th>
			<td><?php echo $publication['journal_name']; ?></td>
		</tr>
		<tr>
			<th class="align_right">Article Name:</th>
			<td><?php echo $publication['article_title']; ?></td>
		</tr>
		<tr>
			<th class="align_right">Abstract:</th>
			<td><?php echo $publication['abstract_text']; ?></td>
		</tr>	
		<tr>
			<th class="align_right">Date:</th>
			<td><?php echo $publication['created_date']; ?></td>
		</tr>
		<tr>
			<th class="align_right">Authors:</th>
			<td>
				<?php 
					$authorsText= ''; 
					foreach($arrAuthors as $author)
						$authorsText .= $author['last_name']." ".$author['initials'].", ";
					$authorsText=substr($authorsText,0,-2);
					$authorsText .='.';
					echo $authorsText;
				?>
			</td>
		</tr>
	</table>
</div>
<!-- End of leftAdressBar Div -->