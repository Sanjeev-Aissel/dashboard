<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>

<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
/*	#coachingsList{
		width: 800px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
	}*/
	.buttonsWarpper{
		float: right;
		width: 266px;
	}
	.gridWrapper {
	    width: 100%;
	}
</style>
<script type="text/javascript">

	var username = "<?php echo lang("track.Username");?>";
	var specialty = "<?php echo lang("track.Specialty");?>";
	var action = "<?php echo lang("Overview.Action");?>";
	jqgridIds	= new Array('listCoachingsResultSet');

	function addCompliance(){
		 window.location=base_url+'coachings/compliance';
	}
	function editCoaching(id){
		// window.location=base_url+'coachings/edit_coaching/'+id;
	}
	function viewCompliance(id){
		window.location=base_url+'coachings/view_compliance/'+id;
	}
	function deleteCompliance(id){
		var	formAction = base_url+'coachings/delete_compliance/'+id;
		jQuery("#listCoachingsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
		//$("#delmodlistInteractionsResultSet").addClass("gridConfirmFormCenterAlign");
		$("#delmodlistCoachingsResultSet").center();
	}
        
        function editCompliance(id){
            window.location = base_url+'coachings/edit_compliance/'+id;
	}
	
	function listRecordsPerPage(maxRecords,increament){
		var rowList=new Array();
	 	for(i=increament;i<=maxRecords;i+=increament){
	 		rowList.push(i);
	 	} 	
	 	return rowList;
	}
	
	/** 
	* Show/Hide the Search Tool Bar in the JQGrid
	*/
	function toggleSearchToolbar(){ 			
		if(jQuery(".ui-search-toolbar").css("display")=="none") {
			jQuery(".ui-search-toolbar").css("display","");
		} else {
			jQuery(".ui-search-toolbar").css("display","none");
		}
	};
	function list_coaching_grid(){
            var postData={};
		var ele=document.getElementById('coachingsList');
		var gridWidth=ele.clientWidth;
			$('#coachingsList').html('');
		    $('#coachingsList').html('<div class="gridWrapper"><div id="listCoachingsPage"></div><table id="listCoachingsResultSet"></table><div>');
		    jQuery("#listCoachingsResultSet").jqGrid({
				url:'<?php echo base_url();?>coachings/list_compliance_grid',
				datatype: "json",
				colNames:['Id','','Id','Date','Interaction Type','KTLs/HCOs','Name of FMA','Compliance Violated','Monitored By','Created By','','',action],
			   	colModel:[
					{name:'compliance_id',index:'compliance_id', hidden:true, search:false, resizable:false,resizable:false},
					{name:'micro',width:20, search:false,align:'center'},
                                          {name:'generic_id',index:'generic_id',search:true,width:110},
			   		{name:'date',index:'date',width:50, search:true},
			   		{name:'interaction_mode',index:'interaction_mode',width:50, search:true},
			   		{name:'kols',index:'kols',width:130, search:true},
			   		{name:'monitored_by_name',index:'monitored_by_name',width:80,search:true, align:'center',resizable:false},
			   		{name:'compliance_violation',index:'compliance_violation',width:60, search:true},
					{name:'manager_name',index:'manager_name',width:80,search:true, align:'center',resizable:false},
                                        {name:'created_user',index:'created_user',width:80,search:true, align:'center',resizable:false},
                                        {name:'eAllowed',index:'eAllowed', hidden:true},
			   		{name:'dAllowed',index:'dAllowed', hidden:true},
					{name:'act',width:50, hidden:false,align:'center',search:false}	
			   	],
			   	rowNum:10,
                                postData:postData,
			   	multiselect: false,
			   	rownumbers: true,
			   	autowidth: false,
			   	width:gridWidth,
			   	loadonce:false,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#listCoachingsPage',
			   	mtype: "POST",
			   	sortname: 'date',//sort
			    viewrecords: true,
			    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:'Field Compliance Monitoring',
			    gridComplete: function(){
					//Get array of id'f from jqgrid			   
			    	var arrIds = jQuery("#listCoachingsResultSet").jqGrid('getDataIDs'); 
			    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
			    	var roleId = '<?php echo $this->session->userdata('user_role_id')?>';
			    	var role = '<?php echo ROLE_MANAGER ?>';
			    	for(var i=0;i < arrIds.length;i++){
				    	var id = arrIds[i];
				    	var ret = jQuery("#listCoachingsResultSet").jqGrid('getRowData', id);
				    	var complianceId	= ret.compliance_id;
				    	//Edit and Delete labels 
                                        var actionLink='';
				    	if((ret.eAllowed == 'true')){
					    	 actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editCompliance('"+complianceId+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";
					    	
           
				    	}
                                        if((ret.dAllowed == 'true')){
					    	  actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteCompliance('"+complianceId+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                                        }  
//				    	if(roleId==role){
////					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editCoaching('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteCoaching('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
//					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editCompliance('"+complianceId+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\"></a></div></div><div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon deleteIcon' onclick=\"deleteCompliance('"+complianceId+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
				    		jQuery("#listCoachingsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
//				    	}
			    		//Microview label	
				    	
			    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewCompliance('"+complianceId+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Compliance\">&nbsp;</a></div></label>";
				    	jQuery("#listCoachingsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
				    	} 
			    	jQuery("#listCoachingsResultSet").jqGrid('navGrid','hideCol',"id");
			    	//Initialize the tooltips
			    	initializeCustomToolTips();

			    },
			    
				rowList:paginationValues
			});
		    jQuery("#listCoachingsResultSet").jqGrid('navGrid','#listCoachingsPage',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#listCoachingsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
			//Toggle Toolbar Search 
			jQuery("#listCoachingsResultSet").jqGrid('navButtonAdd',"#listCoachingsPage",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
				onClickButton:toggleSearchToolbar
			});
		}

	$(document).ready(function(){
		list_coaching_grid();
	});
 function export_excel(){



			

			var excelFilters = '';


var postParams = $('#listCoachingsResultSet').getGridParam("postData");
			

		

				$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

					if($(this).val() != ''){

						var filterName = $(this).attr('name');
                                                if(filterName=="interaction_mode")
                                                    filterName="Interaction Type";
                                                if(filterName=="kols")
                                                    filterName="<?php echo lang("HCP");?>s/HCOs";
                                                if(filterName=="monitored_by_name")
                                                    filterName="Name of FMA";
                                                if(filterName=="compliance_violation")
                                                    filterName="Compliance Violated";
                                                if(filterName=="manager_name")
                                                    filterName="Monitored By";
                                                 if(filterName=="created_user")
                                                    filterName="Created By";
						var filterValue = $(this).val();

						excelFilters += filterName+" : "+filterValue+",";

					}
//                                        alert(excelFilters);

				});

				//$("#excel-filters").val(excelFilters);

				var selectedOPtion = $(".ui-pg-selbox").val();

				$(".ui-pg-selbox option:last").attr('selected','selected');

		    	$('.ui-pg-selbox').trigger('change');

		    	if($("#listCoachingsResultSet").html() != null )

		    		var arrIds = jQuery("#listCoachingsResultSet").jqGrid('getDataIDs');

		    	else

		    		var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//		    if($('#orgIntaerctionContainer').css('display')!='block'){
//
//	    	
//
//	    		$('#ids').val(arrIds);
//
//	    	}



	    	

	    	

	    
                $('#ids').val(arrIds);
	    	$("#excel-filters").val(excelFilters);

	    //	return false;
   $("#gridFilter").val(JSON.stringify(postParams));
	    	$('#export').submit();

	    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

	    	$('.ui-pg-selbox').trigger('change');

		}
</script>
<div id="container">
	<?php if($this->common_helpers->isActionAllowed('compliance','add')){ ?>
		 	<div class="exportOptionsContainer">
				<ul class="pageRightOptions">
					<li>
<!--						<label class="link" onclick="addCompliance();"><div class="actionIcon addIcon"></div>Add New</label>-->
						<a href="#" class="NewBlueButton NewAddIcon" onclick="addCompliance();">Add New</a>
					</li>
				 <li><div class="tab0 tabContent" style="display:block;">
					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="top: -3px !important;" onclick="export_excel();" style="float:right;  position: relative;
    top: -22px;">

					<a href="#" rel="tooltip" data-original-title="Export Compliance Detail into Excel format">&nbsp;</a>

				</div></li>
                                </ul>
			</div>
	<?php }?>
	<div id="coachingsList" class="clear"></div>
        <form action="<?php echo base_url()?>coachings/export_compliance_details/" method='post' id="export">

			<input type="hidden" id="ids" name="compliance_ids" value=""></input>

			<input type="hidden" name="filters" id="excel-filters" />
      <input type="hidden" name="grid_filter" id="gridFilter" />
			

		</form>
</div>