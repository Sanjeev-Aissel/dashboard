 <?php
/**
 * Common headers for Kol Analyst application. 
 *
 * @author: Kunal Anegundi
 * @created on: 21-06-11
 */

?>
<script type="text/javascript">
	function showSettingDetails(showHide){
		if(showHide)
			$("#userSettings").show();
		else
			$("#userSettings").hide();
	}

	$('#wrapper').click(function(){
		$("#userSettings").hide();
		});

	function triggerAdvSearch(){
		var formAction = $('#advSearchLink').val();
		$("#advSearchAddContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#advSearchAddContainer").dialog({ autoOpen: true, position: "right" }).dialog( "widget" ).css({"position":"fixed","top":"0"}).animate({ top: "8%" }, 1000)
		$("#advSearchAddProfileContent").load('<?php echo base_url().'kols/adv_search_links/'?>');
		//	$("#advSearchAddProfileContent").load(formAction);
		return false;	
	}

	$(document).ready(function(){

		// Settings for the Advance search Dialog Box
		var advanceSearchAddOpts = {
				title: "ADVANCE SEARCH",
				modal: true,
				autoOpen: false,
				width: 600,
				dialogClass: "microView",
				position: ['center', 80],
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#advSearchAddContainer").dialog(advanceSearchAddOpts);
	});
</script>
<?php 
	// Get the URI segment. Helps in setting the link as 'ACTIVE'
	$currentController	= $this->uri->segment(1);
	$currentMethod		= $this->uri->segment(2);
	$param				= $this->uri->segment(3);
	$secondparam		= $this->uri->segment(4);
?>
	<!-- Start of Header Div -->
	<div id="header" class="span-24">
		<div class="headerTopSectionWrapper prepend-20 span-4 last">
		<div id="headerTopSection" class="ui-tabs">
			<div id="settingsLinkContainer">
				<a href="#" id="settingsLink" class="settingsLink" onmouseover="showSettingDetails(true);"><?php echo $this->session->userdata('user_name');?><span class="gbma"/></a>
				<div id="userSettings" style="display: none;" >
				<ul >
				  <li><a href="#" ><label><?php echo $this->session->userdata('user_name');?><span class="gbma"/></label></a></li>
				  <li><a href="#" ><label>Settings &nbsp&nbsp</label><img align="middle" alt="settings" src="<?php echo base_url();?>images/settings_icon.png" /></a></li>
				  <li><a href="<?php echo base_url()?>login/logout" class="logoutLink"><label>Logout &nbsp&nbsp</label><img align="middle"  alt="settings" src="<?php echo base_url();?>images/logout_icon.png" /></a></li>
				</ul>
				</div>
			</div>
		</div>
		</div>
		
		<div id="logo" class="span-3">
			<img alt="Aissel solutions" width="78" height="43" src="<?php echo base_url()?>images/kolm_logo_beta.png" />
		</div>
		<div id="productVersion">
			<?php echo KOLM_VERSION;?>
		</div>

		
		
		<!-- Start of Primary Navigation -->
		<div class="nav-box">
   			<div class="left">
               	<div class="right">
					<ul>
						<li>
							<a href="<?php echo base_url().'kols/analyst_index'?>" 
							<?php if(($currentController == 'kols') && ($currentMethod == 'analyst_index')) {echo "class='first-current'";} else {echo "class='first'";}?>
							>
							<em><b>Home</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>kols/list_kols"
							<?php 
							if((($currentController == 'kols') && ($currentMethod != 'list_requested_kols')) || (($currentController == 'kols') && ($currentMethod != 'analyst_index')) || ($currentController == 'pubmeds'))
								{ echo 'class="current"';}
							?>
							>
							<em><b>Process KOLs</b></em></a>
						</li>
						
						<li>
							<a href="<?php echo base_url();?>organizations/list_organizations"
							<?php 
								if(($currentController == 'organizations' || $currentController == 'requested_orgs')){ echo 'class="current"';}?>
							>
							<em><b>Process Org.</b></em>
							</a>
						</li>
						<li>
							<a href="<?php echo base_url();?>client_users/list_clients"
							<?php 
							if(($currentController == 'client_users' || $currentController == 'client_user_log_activities')&& ($currentMethod == 'list_clients' || $currentMethod == 'show_client_log_activities')){ echo 'class="current"';}?>
							>
							<em><b>Clients</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>client_users/list_users"
							<?php 
							if(($currentController == 'client_users')&& ($currentMethod == 'list_users')){ echo 'class="current"';}?>
							>
							<em><b>Client Users</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>roles/list_roles"
							<?php 
								if(($currentController == 'roles')&& ($currentMethod == 'list_roles')){ echo 'class="current"';}?>
							>
							<em><b>User Roles</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>permissions/show_permissions"
							<?php 
								if(($currentController == 'permissions')&& ($currentMethod == 'show_permissions')){ echo 'class="current"';}?>
							>
							<em><b>Permissions</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>id_projects" 
								<?php if($currentController == 'id_projects') echo 'class="current"';?>> <em><b>Identify</b></em>
								<div class="navPrimSeparator"></div>
							</a>
						</li>
						<li>
							<a href="<?php echo base_url();?>client_users/add_associated_kols"
							<?php 
							if(($currentController == 'client_users')&& ($currentMethod == 'add_associated_kols')){ echo 'class="current"';}?>
							>
							<em><b>Associate KOLs</b></em></a>
						</li>
                                                <li>
							<a href="<?php echo base_url();?>media_intel_extractions/bookmarkSourceGrid"
							<?php 
								if(($currentController == 'media_intel_extractions')){ echo 'class="current"';}?>
							>
							<em><b>Media</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>campaigns/list_campaigns"
							<?php 
								if(($currentController == 'campaigns')&& ($currentMethod == 'list_campaigns') || ($currentController == 'campaigns')&& ($currentMethod == 'add_campaign') || ($currentController == 'campaigns')&& ($currentMethod == 'edit_campaign') ){ echo 'class="current"';}?>
							>
							<em><b>Campaigns</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>kol_consents/list_opt_in_out"
							<?php 
							if(($currentController == 'kol_consents' || $currentController == 'optinout_addhcp_import') && ($currentMethod == 'list_opt_in_out' || $currentMethod == 'add')){ echo 'class="current"';}?>
							>
							<em><b>Opt-in/Opt-out Users</b></em></a>
						</li>
						<li>
							<a href="<?php echo base_url();?>master_data_controller/manage_titles"
							<?php 
							if(($currentController == 'master_data_controller')&& ($currentMethod == 'manage_titles' || $currentMethod == 'list_specialties' || $currentMethod == 'list_region')){ echo 'class="current"';}?>
							>
							<em><b>Master Data</b></em></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End of Primary Navigation -->
		
		<!-- Start of Secondary Navigation -->
		<div class="secondaryNavWrapper prepend-0 span-24">
			<div id="secondaryNav" class="ui-tabs span-24">
				<ul class="ulToHorizNav ui-tabs-nav ui-helper-reset ui-helper-clearfix">
					<?php 
						// If the 'View KOL' is the action
						if((($currentController == 'kols') ||($currentController == 'pubmeds') ||($currentController == 'clinical_trials')) && 
							($currentMethod != 'search_kols') && 
							($currentMethod != 'view_kol_adv_search') &&
							($currentMethod != 'adv_search_kols') &&
							($currentMethod != 'search_events') &&
							($currentMethod != 'view_event_adv_search') &&
							($currentMethod != 'adv_search_events') &&
							($currentMethod != 'analyst_index') &&
							($currentMethod != 'list_kols_client_view')&&
							($currentMethod != 'list_organizations')&&
							($currentMethod != 'edit_organization')&&
							($currentMethod != 'add_organization')&&
							($currentMethod != 'add_kol')&&
							($currentMethod != 'list_kols')&&
							($currentMethod != 'import_kol_profiles')&&
							($currentMethod != 'list_requested_kols') &&
							($currentMethod != 'list_all_uploaded_files')&&
							($currentMethod != 'upload_zip_file')&&
							($currentMethod != 'import_page')&&
							($currentMethod != 'import_multiple_kol_profiles')&&
							($currentMethod != 'list_kols_based_on_client')&&
							($currentMethod != 'manage_titles')&&
							($currentMethod != 'list_unprocessed_trials')&&
							($currentMethod != 'list_specialties')&&
							($currentMethod != 'list_parent_org_associations')
						):
					?>
					<li <?php if($currentMethod == 'edit_kol') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>kols/edit_kol/<?php echo $arrKol['id'];?>" class="mediaLink">Overview</a>
					</li>
					<li <?php if($currentMethod == 'add_education_detail') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>kols/add_education_detail/<?php echo $arrKol['id'];?>" class="educationLink">Education</a>
					</li>
					<li <?php if($currentMethod == 'add_membership') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>kols/add_membership/<?php echo $arrKol['id'];?>" class="educationLink">Affiliations</a>
					</li>
					<li <?php if($currentMethod == 'add_event') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>kols/add_event/<?php echo $arrKol['id'];?>" class="eventsLink">Events</a>
					</li>
					<li <?php if($currentMethod == 'add_social_media') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>kols/add_social_media/<?php echo $arrKol['id'];?>" class="mediaLink">Social Media</a>
					</li>
					<li <?php if($currentMethod == 'view_publications') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>pubmeds/view_publications/<?php echo $arrKol['id'];?>" class="pubsLink">Publications</a>
					</li>
					<li <?php if($currentMethod == 'view_clinical_trials') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>clinical_trials/view_clinical_trials/<?php echo $arrKol['id'];?>" class="trialsLink">Clinical Trials</a>
					</li>
					<?php 
						endif;
						// If the 'View Organization' is the action
						if(($currentController == 'organizations') && ($currentMethod != 'list_organizations' && $currentMethod !='list_import_files' && $currentMethod!='import_page' && $currentMethod !='read_and_import_org_files' && $currentMethod !='read_and_import_payer_files' && $currentMethod !='upload_zip_file' && $currentMethod != 'list_parent_org_associations'  && $currentMethod != 'list_orgs_based_on_client')):
					?>
					<li <?php if($secondparam == '' || $secondparam == 'about') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/about" class="orgOverviewLink" id="orgDetails">About</a>
					</li>
					<li <?php if($secondparam == 'address') echo 'class="active"';?>> 
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/address" class="orgAssocLink" id="orgAddress">Address</a>
					</li>
					<li <?php if($secondparam == 'media') echo 'class="active"';?>> 
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/media" class="orgOverviewLink" id="orgMedia">Social Media</a>
					</li>
					<li <?php if($secondparam == 'keyPeople') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/keyPeople" class="orgOverviewLink" id="orgKeyPeople">Key People</a>
					</li>
					<li <?php if($secondparam == 'publications') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/publications" class="orgOverviewLink" id="orgKeyPeople">Publications</a>
					</li>
					<li <?php if($secondparam == 'trials') echo 'class="active"';?>>
						<a href="<?php echo base_url();?>organizations/<?php if($arrOrganization['id']!='') echo 'edit_organization/'.$arrOrganization['id']; else echo 'add_organization' ;?>/trials" class="orgOverviewLink" id="orgKeyPeople">Trials</a>
					</li>
					<?php 
						endif;
						
						// If the 'ID project' is the action
					if(($currentController == 'id_projects')): ?>
						<li <?php if($currentMethod == ''||$currentMethod == 'process_form_data'||$currentMethod == 'process_form_data_author_name'||$currentMethod == 'process_form_data_author_name') echo 'class="active"';?>><a href="<?php echo base_url()?>id_projects" class="">Query</a></li>
						<li <?php if($currentMethod == 'display_result') echo 'class="active"';?>><a href="<?php echo base_url()?>id_projects/display_result" class="">Projects</a></li>
						<li <?php if($currentMethod == 'authors_pubscount') echo 'class="active"';?>><a href="<?php echo base_url()?>id_projects/authors_pubscount" class="">Authors</a></li>
					<?php 
					endif;
					?>
					<?php 
					if((($currentController == 'kols') || ($currentController == 'requested_kols') || ($currentController == 'identifications'))&&
					($currentMethod != 'search_kols') && 
							($currentMethod != 'view_kol_adv_search') &&
							($currentMethod != 'adv_search_kols') &&
							($currentMethod != 'search_events') &&
							($currentMethod != 'view_event_adv_search') &&
							($currentMethod != 'adv_search_events') &&
							($currentMethod != 'analyst_index') &&
							($currentMethod != 'list_kols_client_view')&&
							($currentMethod != 'list_organizations')&&
							($currentMethod != 'edit_organization')&&
							($currentMethod != 'add_organization')&&
							($currentMethod != 'add_kol')&&
							($currentMethod != 'import_kol_profiles')&&
							($currentMethod != 'edit_kol')&& 
							($currentMethod != 'add_education_detail')&&
							($currentMethod != 'add_membership')&&
							($currentMethod != 'add_event')&&
							($currentMethod != 'manage_titles')&&
							($currentMethod != 'list_specialties')&&
							($currentMethod != 'add_social_media'))
					:?>

					
						<li <?php if($currentMethod == 'list_requested_kols') echo 'class="active"';?>><a href="<?php echo base_url()?>requested_kols/list_requested_kols">Requested Kols</a></li>
						<li <?php if($currentMethod == 'list_pre_requested_kols') echo 'class="active"';?>><a href="<?php echo base_url()?>requested_kols/list_pre_requested_kols">MY Customers</a></li>
						<li <?php if($currentMethod == 'import_page') echo 'class="active"';?>><a href="<?php echo base_url()?>kols/import_page">Imports</a></li>
                        <li <?php if($currentMethod == 'list_unprocessed_trials') echo 'class="active"';?>><a href="<?php echo base_url()?>kols/list_unprocessed_trials">Industry Trials</a></li>
						<li <?php if($currentMethod == 'list_projects') echo 'class="active"';?>><a href="<?php echo base_url()?>identifications/list_projects">ID Projects</a></li>
						<li <?php if($currentMethod == 'list_kols_based_on_client') echo 'class="active"';?>><a href="<?php echo base_url()?>kols/list_kols_based_on_client">KOLs Visibility</a></li>
					
					<?php 
					endif;
					?>
					<?php if($currentController == 'requested_orgs' || ($currentController == 'organizations') && ($currentMethod == 'list_organizations' || $currentMethod == 'import_page' || $currentMethod == 'read_and_import_payer_files' || $currentMethod == 'read_and_import_org_files' || $currentMethod == 'list_parent_org_associations') || $currentMethod == 'list_orgs_based_on_client'){?>
						<li <?php if($currentMethod == 'list_requested_orgs') echo 'class="active"';?>><a href="<?php echo base_url()?>requested_orgs/list_requested_orgs">Requested Orgs</a></li>
					<li <?php if($currentMethod == 'list_requested_kols') echo 'class="active"';?>><a href="<?php echo base_url()?>organizations/import_page">Imports</a></li>
						<?php if(ORGS_VISIBILITY) : ?>
							<li><a href="<?php echo base_url()?>organizations/list_orgs_based_on_client">Orgs Visibility</a></li>
						<?php endif;?>
					<li><a href="<?php echo base_url()?>organizations/list_parent_org_associations">Parent Org Associations</a></li>
					<?php }?>
					
					<?php if($currentController == 'master_data_controller' && ($currentMethod == 'manage_titles' || $currentMethod == 'list_specialties') || $currentMethod == 'list_region'){?>
						<li <?php if($currentMethod == 'manage_titles') echo 'class="active"';?>><a href="<?php echo base_url()?>master_data_controller/manage_titles">Titles</a></li>
						<li <?php if($currentMethod == 'list_specialties') echo 'class="active"';?>><a href="<?php echo base_url()?>master_data_controller/list_specialties">Specialities</a></li>
						<li <?php if($currentMethod == 'list_region') echo 'class="active"';?>><a href="<?php echo base_url()?>master_data_controller/list_region">Regions</a></li>
					<?php }?>
					<?php if(($currentController == 'kol_consents' || $currentController == 'optinout_addhcp_import') && ($currentMethod =='list_opt_in_out' || $currentMethod =='add')){?>
						<li <?php if($currentMethod == 'add') echo 'class="active"';?>><a href="<?php echo base_url()?>optinout_addhcp_import/add">Import Opt-in/Opt-out</a></li>
					<?php }?>
					<?php if(($currentController == 'client_users' || $currentController == 'client_user_log_activities') && ($currentMethod =='list_clients' || $currentMethod =='show_client_log_activities')){?>
						<li <?php if($currentMethod == 'show_client_log_activities') echo 'class="active"';?>><a href="<?php echo base_url()?>client_user_log_activities/show_client_log_activities">Activity Logs</a></li>
					<?php }?>
				</ul>
			</div>
		
		</div>
		<!-- End of Secondary Navigation -->
	</div>
	<!-- End of Header Div -->
	
	<!-- Container for the 'Advance Search' modal box -->
	<div id="advanceDailog">	
		<div id="advSearchAddContainer" class="microProfileDialogBox">
			<div class="profileContent" id="advSearchAddProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Advance Search' modal box -->