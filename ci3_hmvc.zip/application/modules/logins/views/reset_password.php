<style>
.invalid {
	background:url(<?php echo base_url()?>assets/images/invalid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#ec3f41;
}
.valid {
	background:url(<?php echo base_url()?>assets/images/valid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#3a7d34;
}
</style>
<div class="container"> 
	<div id="loginbox" style="margin-top:10%;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
		<div class="panel panel-info" >
			<div class="panel-heading">
				<div class="panel-title">Reset Password </div>
			</div> 
			<div style="padding-top:30px" class="panel-body" > 
				<div style="width: 49%; min-height: 200px;float: left;display: inline;">
					<form action="" id='resetForm' method="post">
						<input type="hidden" name='new_password_key' value="<?php echo $newPassKey ?>"/>
						<div id="response_message"></div>
						<div class="cols-sm-10">
							<div class="progress">
								<div id="passStrength" class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%"><span id='passwordStrength'>Strength</span></div>
							</div>
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
								<input type="password" class="form-control" name="password" id="password"  placeholder="New Password" onkeyup="validatePassword();" autocomplete="off" />
							</div><br>
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
								<input type="password" class="form-control" name="cPassword" id="cPassword"  placeholder="Confirm New Password" onkeyup="validateConfirmPassword();" autocomplete="off"/>
							</div><br>
							<div class="progress" id="confirmPass"  hidden="true">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:100%">Confirm Password Mismatch</div>
							</div>
							<div class="form-group" id="show_loader" style="text-align:center;display:none">
							<img src="<?php echo base_url().ASSETS;?>/images/ajax-loader.gif"></img>
							</div>
							<input type="hidden" id="csrfToken"/>
							<div>
								<button type="submit" style="width: 49%; display:inline-block" class="btn btn-primary btn-sm" onclick="updatePassword();return false;" id="resetPassBtn" disabled>SUBMIT</button>
								<button type="button" style="width: 49%; display:inline-block" class="btn btn-danger btn-sm" onclick="goToUrl(base_url+'logins/logins');">CANCEL</button>
							</div>
						</div>
					</form>
				</div>
				<div style="width: 49%; min-height: 200px;float: left;display: inline;">
					<div class="ui-grid-solo" id="login_form_wrapper"><br><br>
						<h4>Password should contain :</h4>
						<ul style="padding: 0; margin: 0; list-style: none;">
							<li id="length" class="invalid">At least <strong>8 characters</strong></li>
							<li id="number" class="invalid">At least <strong>one number</strong></li>
							<li id="symbol" class="invalid">At least <strong>one symbol</strong></li>
							<li id="letter" class="invalid">At least <strong>one small letter</strong></li>
							<li id="capital" class="invalid">At least <strong>one capital letter</strong></li>
						</ul>
					</div>
				</div>
			</div> 
		</div> 
	</div>
</div>
<script type="text/javascript">
var base_url = '<?php echo base_url(); ?>';
</script>
<script src="<?php echo base_url().MODULES_ASSETS;?>logins/js/logins.js"></script>