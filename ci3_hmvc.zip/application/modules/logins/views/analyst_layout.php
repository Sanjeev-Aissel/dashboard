<html>
<head>
<title>Analyst</title>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jquery_validator/css/screen.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/jquery-3.2.1.slim.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jquery_validator/dist/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/i18n/grid.locale-en.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery.jqGrid.min_3.8.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/chosen.jquery.js"></script>
<script	type="text/javascript" src="<?php echo base_url().ASSETS;?>js/jquery.validate1.9.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/chosen.jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>datepicker/js/daterangepicker.jQuery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>datepicker/js/date.js"></script>
<style>
#snackbar {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left:85%;
    bottom:100px;
    font-size: 17px;
}
#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}
@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom:100px; opacity: 1;}
}
@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 100px; opacity: 1;}
}
@-webkit-keyframes fadeout {
    from {bottom:100px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}
@keyframes fadeout {
    from {bottom:100px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
</style>
</head>
<body>
<?php
if(isset($showNavBar)){
 echo $this->load->view('analyst_navbar');
}
echo $this->load->view($contentPage);
?>
<div id="snackbar"></div>
<script>
var base_url		= "<?php echo base_url()?>";
function showMessageInSnackbar(text) {
    var x = document.getElementById("snackbar");
    $("#snackbar").text(text);
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show",""); }, 3000);
}
</script>