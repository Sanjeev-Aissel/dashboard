<script src="<?php echo base_url().MODULES_ASSETS;?>configurations/js/configuration.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<div style="margin:10px 0px;">
	<p style="display: inline">Select Client:</p>
	<select name="client_id" id="client_id" class="form-control required" onchange="list_menus_jqgrid();" style="width:12%;display: inline">
			<?php foreach($arrClients as $client){	?>
			<option value="<?php echo $client['id'];?>">
					<?php echo $client['name'];?>
				</option>
			<?php }?>
	</select>
	<div style="display:inline;margin-left:12%;">
		<select name="visibility_id" id="visibility_id" class="form-control" style="width:12%;display: inline">
		<option value="">Select Visibility</option>
			<option value="1">Show</option>
			<option value="0">Hide</option>
		</select>
		<a class="btn btn-default" id="visibility" style="margin-bottom: 4px;">Save</a>
	</div>
	<div style="display:inline;margin-left:2%;">
		<a class="btn btn-default" id="landing_page" style="margin-bottom: 4px;">Select as Landing Page</a>
	</div>
	<div class="pull-right">
		<a class="btn btn-default" onclick="add_menu();">Add-Menu</a>
		<a class="btn btn-default" onclick="generate_menu()">Generate-Menu</a>
	</div>
</div>
<div id="assignedModulesGridWrapper" class="gridWrapper">
	<table id="assignedModulesListing"></table>
	<div id="assignedModulesListingPagintaion"></div>
</div>
<br>
<div id="userContainer" class="microViewLoading">
	<div class="modalcontent"></div>
</div>
</body>
<script>
$(window).on("resize", function (){
    var $grid = $("#assignedModulesListing"),
    newWidth = $grid.closest(".ui-jqgrid").parent().width();
    $grid.jqGrid("setGridWidth", newWidth, true);
});
$(document).ready(function(){
	list_menus_jqgrid();
	$("#visibility").click( function() {
		var s;
		s = jQuery("#assignedModulesListing").jqGrid('getGridParam','selarrrow');
		change_menu_visibility(s);
	});
	$("#landing_page").click( function() {
		var s;
		s = jQuery("#assignedModulesListing").jqGrid('getGridParam','selarrrow');
		if(s.length=='1'){
            mark_as_landing_page(s);
		}
        else
        	alert("Select any one menu, to mark it as Landing page");
	});
});
</script>