<?php
/**
*Description:
*
*Created by:Vinod H
*
*Created on:Jan 18, 2018
*/?>

		<style type="text/css">
			#contents{
				text-align:left;
				font-size:110%;
				padding-left:150px;
			}
			
			#contents label{
				float:left;
				width:150px;
				text-align:right;
			}
			.campnameError .campshortError .campDescError p{
				color:red;
			}
			h1{
				color:#2E6E9E;
				font-size:170%;
				margin-bottom:10px;
				margin-top:15px;
			}

			
			#campaignForm span.require{
				color: #F00;
			}
			.validateForm label.error{
				float:none !important;
				margin-left:130px;
				
			}
			.error{
				padding:inherit;
			}
			.errorName{
				color: #F00;
				margin-left:165px;
			}
			.errorShortCode{
				color: #F00;
			}
			.gridIdDetails{
				width:100%;
			}
			.analystForm div.formButtons, div.formButtons{
				margin-bottom:20px;
			}
			
		</style>
		<script>
		var idsOfSelectedRows = [];
		var d = new Date();
		var defaultStartYear =  (d.getFullYear())-5;
		var defaultEndYear = d.getFullYear();
		<?php if((!empty($yearRange[0]) || $yearRange[0]!='') && (!empty($yearRange[1]) || $yearRange[1]!='')){ ?>
    	    var defaultStartYear =  <?php echo $yearRange[0]?>;
    		var defaultEndYear = <?php echo $yearRange[1]?>;
	   <?php } ?>
		var updateIdsOfSelectedRows = function (id, isSelected) {
			var index = $.inArray(id, idsOfSelectedRows);
				if (!isSelected && index >= 0) {
					idsOfSelectedRows.splice(index, 1); // remove id from the list
				} else if (index < 0) {
					if(typeof id !== 'undefined'){
						if(id > 0){
							idsOfSelectedRows.push(id); // select KOLs Id are stored in array
						}
					}
				}
				console.log(idsOfSelectedRows);
		};
		function toggleSearchToolbar(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}
		};
		var projectName = '<?php echo $rowData['name']?>';
		$(document).ready(function (){
		  //	idsOfSelectedRows = arrKolIds;
			getKolAccessedDetails(defaultStartYear,defaultEndYear);
			
		});
		function getKolAccessedDetails(defaultStartYear,defaultEndYear){
			$("#actionSection").html("");
			$("#gridEventAccessDetailsContainer").html("");
			$("#gridKolsAccessDetailsContainer").html("");
			// Append the required div and table
			$("#gridKolsAccessDetailsContainer").html('<table id="gridKols"></table><div id="gridKolsListingPagintaion"></div>');
    		jQuery("#gridKols").jqGrid({
    			url:'<?php echo base_url();?>identifications/list_project_kols_details_grid/'+<?php echo $rowData['id'];?>+'/'+defaultStartYear+'/'+defaultEndYear,
    			datatype: "json",
    			colNames:['Id','kol_id','Name','Event Count','Affiliation Count','Publication Count','Trial Count'],
    		   	colModel:[
    				{name:'id',index:'id', hidden:true, search:false, resizable:false},
    				{name:'kol_id',index:'kol_id', hidden:true, search:false, resizable:false},
    				{name:'kol_name',index:'kol_name',search:true},
    				{name:'event_count',index:'event_count',width:120, align:'center',search:true,
    			   		formatter: function (cellvalue, options, rowObject) {
    			   	    	if(rowObject.event_count >0){
    					        return "<a href='javascript:void(0)' onclick=getEventAccessed('"+rowObject.kol_id+"')>"+rowObject.event_count+"</a>";
    						}else{
    							return rowObject.event_count;
    						}
    						
    			    	}},
    		    	{name:'affiliation_count',index:'affiliation_count',width:120, align:'center',search:true,
    			   		formatter: function (cellvalue, options, rowObject) {
    			   	    	if(rowObject.affiliation_count >0){
    					        return "<a href='javascript:void(0)' onclick=getAffiliationAccessed('"+rowObject.kol_id+"')>"+rowObject.affiliation_count+"</a>";
    						}else{
    							return rowObject.affiliation_count;
    						}
    						
    			    	}},
    		    	{name:'publication_count',index:'publication_count',width:120, align:'center',search:true,
    			   		formatter: function (cellvalue, options, rowObject) {
    			   	    	if(rowObject.publication_count >0){
    					        return "<a href='javascript:void(0)' onclick=getPublicationAccessed('"+rowObject.kol_id+"')>"+rowObject.publication_count+"</a>";
    						}else{
    							return rowObject.publication_count;
    						}
    						
    			    	}},
    		    	{name:'trial_count',index:'trial_count',width:120, align:'center',search:true,
    			   		formatter: function (cellvalue, options, rowObject) {
    			   	    	if(rowObject.trial_count >0){
    					        return "<a href='javascript:void(0)' onclick=getTrialAccessed('"+rowObject.kol_id+"')>"+rowObject.trial_count+"</a>";
    						}else{
    							return rowObject.trial_count;
    						}
    						
    			    	}}
    		   	],
    		   	rowNum:10,
    		   	multiselect: false,
    		   	rownumbers: true,
    		   	autowidth: true, 
    		   	loadonce:true,
    		   	ignoreCase:true,
    		   	hiddengrid:false,
    		   	rowList:paginationValues,
    		   	height: "auto",		 
    		   	pager: '#gridKolsListingPagintaion',
    		   	mtype: "POST",
    		   	sortname: 'kol_name',
    		    viewrecords: true,
    		    sortorder: "desc",
    		    shrinkToFit:true,
    		    jsonReader: { repeatitems : false, id: "0" }, 
    		    caption:"Id KOL Profile Details for Profile - "+projectName,
    		    gridComplete: function(){	
    		    }
    		});
    		jQuery("#gridKols").jqGrid('navGrid','#gridKolsListingPagintaion',{add:false,del:false,edit:false,search:false}); 
            jQuery("#gridKols").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
    		//Toggle Toolbar Search 
    		jQuery("#gridKols").jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
    			onClickButton:toggleSearchToolbar
    		});
		}

		function saveSelectedValue(thisEle){
			rowId = $(thisEle).parent().parent().attr('id');
			celValue = $(thisEle).val();
			var rowData = $('#JQBlistEventAccessDetails').jqGrid('getRowData', rowId);
			var filterData = {};
			filterData["id"] = rowData.id;
			filterData["activity_type"] = celValue;

			$.ajax({
			dataType:"text",
			url:base_url+"identifications/update_activity_type",
			type:"POST",
			data:filterData,
			success:function(returnData){
				rowData.activity_type= $(thisEle).val();
				$('#JQBlistEventAccessDetails').jqGrid('setRowData', rowId, rowData);
				$("#updateStatus").show();
				$("#updateStatus").html("Data Saved.........");
				$("#updateStatus").fadeOut('slow');
			}
			});
		
			//$(thisEle).parent().html($(thisEle).val());
			//alert($(thisEle).attr('rowid'));
		}
		
		
		function getEventAccessed(kol_id){
			var priorityDropDowns	= ":All;Speaking:Speaking;Organizing Committee:Organizing Committee";
			idsOfSelectedRows = [];
			$("#actionSection").html("");
			$("#actionSection").html("<button onclick=\"associationBtn('"+kol_id+"','event');return false;\">Asscoicate</button> <button onclick=\"dissAssociationBtn('"+kol_id+"','event');return false;\">Dis-Associate</button>");
			$("#gridEventAccessDetailsContainer").html("");
			// Append the required div and table
			$("#gridEventAccessDetailsContainer").html('<table id="JQBlistEventAccessDetails"></table><div id="listEventAccessDetailsPage"></div>');
			var gridWidth=$('#JQBlistEventAccessDetails').width();
			jQuery("#JQBlistEventAccessDetails").jqGrid({
				url: base_url + 'identifications/get_activity_details_by_kol_id/'+kol_id+'/'+<?php echo $rowData['id'];?>+'/events/'+defaultStartYear+'/'+defaultEndYear,
				datatype: "json",
				colNames:['Id','Is In Project','Activity Type','Event Name', 'Session Type','Session Name', 'Topic', 'Role'],
				colModel:[
								{name:'id',index:'id', hidden:true, search:false, resizable:false},
								{name:'is_project',index:'is_project',resizable:false},
								{name:'activity_type',index:'activity_type', width:120,title: false,formatter: function (cellvalue, options, rowObject) {
							    	var cellcontent = rowObject.activity_type;
							    	if(cellcontent == 'Speaking')
							    		cellcontent = "Speaking";
							    	if(cellcontent == 'Organizing Committee')
							    		cellcontent = "Organizing Committee";
						    		if(cellcontent == '' || !cellcontent)
						    			cellcontent = '';
									var selectContent = "<select rowid='"+rowObject.id+"' name='activity_type' onchange='saveSelectedValue(this); return false;' class='activity_type"+cellcontent+"'>";
									selectContent +="<option value=''";
									if(cellcontent == '' || !cellcontent) selectContent +=" selected='selected'";
									selectContent +=">None</option>";

									selectContent +="<option value='Organizing Committee'";
									if(cellcontent == 'Organizing Committee') selectContent +=" selected='selected'";
									selectContent +=">Organizing Committee</option>";

									selectContent +="<option value='Speaking'";
									if(cellcontent == 'Speaking') selectContent +=" selected='selected'";
									selectContent +=">Speaking</option>";
									selectContent +="</select>";

									return selectContent;
					    		},stype:'select', editoptions:{value:priorityDropDowns}},
								{name:'name',index:'name',width:395,resizable:false},
								{name:'conf_session_type',index:'conf_session_type',resizable:false},
								{name:'session_name',index:'session_name',resizable:false},
						   		{name:'event_topic',index:'event_topic',resizable:false},
						   		{name:'role',index:'role',resizable:false}
						   	],	   	
			   	rowNum:10,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	multiselect: true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		   
			   	pager: '#listEventAccessDetailsPage',
			   	toppager:false,
			   	mtype: "POST",
			   	sortname: 'user_name',
			    viewrecords: true,
			    sortorder: "asc",
			    jsonReader: { repeatitems : false, id: "0" },
			    //toolbar: "top",
			    caption:"Event associated to Project - "+projectName,
			    onSelectRow: updateIdsOfSelectedRows,
			    onSelectAll: function (aRowids, isSelected) {
			        var i, count, id;
			        for (i = 0, count = aRowids.length; i < count; i++) {
			            id = aRowids[i];
			            updateIdsOfSelectedRows(id, isSelected);
			        }
	   			 },
	   			loadComplete: function () {
	    		},
		   		rowList:paginationValues,
				gridComplete: function(){ 
					$("#activityDrillDownContainer .ui-jqgrid-titlebar").append('<span id="updateStatus" style="display: block; text-align: center; color: #fff;"> </span>');
			    }
			});

			jQuery("#JQBlistEventAccessDetails").jqGrid('navGrid','#listEventAccessDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

			//Toolbar search bar below the Table Headers
			jQuery("#JQBlistEventAccessDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			
			//Toggle Toolbar Search 
			jQuery("#JQBlistEventAccessDetails").jqGrid('navButtonAdd',"#listEventAccessDetailsPage",{
				caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}							
				} 
			}); 
			jQuery("#JQBlistEventAccessDetails").jqGrid('setGridWidth',gridWidth); 
		}
		
		function getAffiliationAccessed(kol_id){
			idsOfSelectedRows = [];
			$("#actionSection").html("");
			$("#actionSection").html("<button onclick=\"associationBtn('"+kol_id+"','affiliation');return false;\">Asscoicate</button> <button onclick=\"dissAssociationBtn('"+kol_id+"','affiliation');return false;\">Dis-Associate</button>");
			$("#gridEventAccessDetailsContainer").html("");
			// Append the required div and table
			$("#gridEventAccessDetailsContainer").html('<table id="JQBlistEventAccessDetails"></table><div id="listEventAccessDetailsPage"></div>');
			var gridWidth=$('#JQBlistEventAccessDetails').width();
			jQuery("#JQBlistEventAccessDetails").jqGrid({
				url: base_url + 'identifications/get_activity_details_by_kol_id/'+kol_id+'/'+<?php echo $rowData['id'];?>+'/affiliation/'+defaultStartYear+'/'+defaultEndYear,
				datatype: "json",
				colNames:['Id','Is In Project','Organization Name', 'Depatment', 'Title', 'Time Frame', 'Org Type', 'Engagement Type'],
				colModel:[
								{name:'id',index:'id', hidden:true, search:false, resizable:false},
								{name:'is_project',index:'is_project',resizable:false},
								{name:'name',index:'name',width:395,resizable:false},
								{name:'department',index:'department',resizable:false},
						   		{name:'title',index:'title',resizable:false},
						   		{name:'date',index:'date',resizable:false},
						   		{name:'type',index:'type',resizable:false},
						   		{name:'engagement_type',index:'engagement_type',resizable:false}
						   	],	   	
			   	rowNum:10,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	multiselect: true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		   
			   	pager: '#listEventAccessDetailsPage',
			   	toppager:false,
			   	mtype: "POST",
			   	sortname: 'user_name',
			    viewrecords: true,
			    sortorder: "asc",
			    jsonReader: { repeatitems : false, id: "0" },
			    //toolbar: "top",
			    caption:"Affiliation associated to Project - "+projectName,
			    onSelectRow: updateIdsOfSelectedRows,
			    onSelectAll: function (aRowids, isSelected) {
			        var i, count, id;
			        for (i = 0, count = aRowids.length; i < count; i++) {
			            id = aRowids[i];
			            updateIdsOfSelectedRows(id, isSelected);
			        }
	   			 },
	   			loadComplete: function () {
	    		},
		   		rowList:paginationValues,
				gridComplete: function(){ 
			    }
			});

			jQuery("#JQBlistEventAccessDetails").jqGrid('navGrid','#listEventAccessDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

			//Toolbar search bar below the Table Headers
			jQuery("#JQBlistEventAccessDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
			
			//Toggle Toolbar Search 
			jQuery("#JQBlistEventAccessDetails").jqGrid('navButtonAdd',"#listEventAccessDetailsPage",{
				caption:"Search",title:"Toggle Search",
				onClickButton:function(){ 			
					if(jQuery(".ui-search-toolbar").css("display")=="none") {
						jQuery(".ui-search-toolbar").css("display","");
					} else {
						jQuery(".ui-search-toolbar").css("display","none");
					}							
				} 
			}); 
			jQuery("#JQBlistEventAccessDetails").jqGrid('setGridWidth',gridWidth); 
		}
		
        function getPublicationAccessed(kol_id){
        	idsOfSelectedRows = [];
        	$("#actionSection").html("");
        	$("#actionSection").html("<button onclick=\"associationBtn('"+kol_id+"','publication');return false;\">Asscoicate</button> <button onclick=\"dissAssociationBtn('"+kol_id+"','publication');return false;\">Dis-Associate</button>");
        	$("#gridEventAccessDetailsContainer").html("");
        	// Append the required div and table
        	$("#gridEventAccessDetailsContainer").html('<table id="JQBlistEventAccessDetails"></table><div id="listEventAccessDetailsPage"></div>');
        	var gridWidth=$('#JQBlistEventAccessDetails').width();
        	jQuery("#JQBlistEventAccessDetails").jqGrid({
        		url: base_url + 'identifications/get_activity_details_by_kol_id/'+kol_id+'/'+<?php echo $rowData['id'];?>+'/publication/'+defaultStartYear+'/'+defaultEndYear,
        		datatype: "json",
        		colNames:['Id','Is In Project','PMID','Article Title', 'Journal Name', 'Date', 'Auth Position'],
        		colModel:[
        						{name:'id',index:'id', hidden:true, search:false, resizable:false},
        						{name:'is_project',index:'is_project',resizable:false},
        						{name:'pmid',index:'pmid',resizable:false},
        						{name:'article_title',index:'article_title',width:395,resizable:false},
        						{name:'journal_name',index:'journal_name',resizable:false},
        				   		{name:'date',index:'date',resizable:false},
        				   		{name:'auth_pos',index:'auth_pos',resizable:false}
        				   	],	   	
        	   	rowNum:10,
        	   	rownumbers: true,
        	   	autowidth: true, 
        	   	loadonce:true,
        	   	multiselect: true,
        	   	ignoreCase:true,
        	   	hiddengrid:false,
        	   	height: "auto",		   
        	   	pager: '#listEventAccessDetailsPage',
        	   	toppager:false,
        	   	mtype: "POST",
        	   	sortname: 'user_name',
        	    viewrecords: true,
        	    sortorder: "asc",
        	    jsonReader: { repeatitems : false, id: "0" },
        	    //toolbar: "top",
        	    caption:"Publication associated to Project - "+projectName,
        	    onSelectRow: updateIdsOfSelectedRows,
			    onSelectAll: function (aRowids, isSelected) {
			        var i, count, id;
			        for (i = 0, count = aRowids.length; i < count; i++) {
			            id = aRowids[i];
			            updateIdsOfSelectedRows(id, isSelected);
			        }
	   			 },
	   			loadComplete: function () {
	    		},
           		rowList:paginationValues,
        		gridComplete: function(){ 
        	    }
        	});
        
        	jQuery("#JQBlistEventAccessDetails").jqGrid('navGrid','#listEventAccessDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});
        
        	//Toolbar search bar below the Table Headers
        	jQuery("#JQBlistEventAccessDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
        	
        	//Toggle Toolbar Search 
        	jQuery("#JQBlistEventAccessDetails").jqGrid('navButtonAdd',"#listEventAccessDetailsPage",{
        		caption:"Search",title:"Toggle Search",
        		onClickButton:function(){ 			
        			if(jQuery(".ui-search-toolbar").css("display")=="none") {
        				jQuery(".ui-search-toolbar").css("display","");
        			} else {
        				jQuery(".ui-search-toolbar").css("display","none");
        			}							
        		} 
        	}); 
        	jQuery("#JQBlistEventAccessDetails").jqGrid('setGridWidth',gridWidth); 
        }
        
        function getTrialAccessed(kol_id){
        	idsOfSelectedRows = [];
        	$("#actionSection").html("");
        	$("#actionSection").html("<button onclick=\"associationBtn('"+kol_id+"','trial');return false;\">Asscoicate</button> <button onclick=\"dissAssociationBtn('"+kol_id+"','trial');return false;\">Dis-Associate</button>");
        	$("#gridEventAccessDetailsContainer").html("");
        	// Append the required div and table
        	$("#gridEventAccessDetailsContainer").html('<table id="JQBlistEventAccessDetails"></table><div id="listEventAccessDetailsPage"></div>');
        	var gridWidth=$('#JQBlistEventAccessDetails').width();
        	jQuery("#JQBlistEventAccessDetails").jqGrid({
        		url: base_url + 'identifications/get_activity_details_by_kol_id/'+kol_id+'/'+<?php echo $rowData['id'];?>+'/trial/'+defaultStartYear+'/'+defaultEndYear,
        		datatype: "json",
        		colNames:['Id','Is In Project','CT ID', 'Trial Name', 'Condition', 'Phase'],
        		colModel:[
        						{name:'kol_clinical_id',index:'kol_clinical_id', hidden:true, search:false, resizable:false},
        						{name:'is_project',index:'is_project',resizable:false},
        						{name:'ct_id',index:'ct_id',resizable:false},
        						{name:'trial_name',index:'trial_name',width:395,resizable:false},
        				   		{name:'condition',index:'condition',resizable:false},
        				   		{name:'phase',index:'phase',resizable:false}
        				   	],	   	
        	   	rowNum:10,
        	   	rownumbers: true,
        	   	autowidth: true, 
        	   	loadonce:true,
        	   	multiselect: true,
        	   	ignoreCase:true,
        	   	hiddengrid:false,
        	   	height: "auto",		   
        	   	pager: '#listEventAccessDetailsPage',
        	   	toppager:false,
        	   	mtype: "POST",
        	   	sortname: 'trial_name',
        	    viewrecords: true,
        	    sortorder: "asc",
        	    jsonReader: { repeatitems : false, id: "0" },
        	    //toolbar: "top",
        	    caption:"Trial associated to Project - "+projectName,
        	    onSelectRow: updateIdsOfSelectedRows,
			    onSelectAll: function (aRowids, isSelected) {
			        var i, count, id;
			        for (i = 0, count = aRowids.length; i < count; i++) {
			            id = aRowids[i];
			            updateIdsOfSelectedRows(id, isSelected);
			        }
	   			 },
	   			loadComplete: function () {
	    		},
           		rowList:paginationValues,
        		gridComplete: function(){ 
        	    }
        	});
        
        	jQuery("#JQBlistEventAccessDetails").jqGrid('navGrid','#listEventAccessDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});
        
        	//Toolbar search bar below the Table Headers
        	jQuery("#JQBlistEventAccessDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
        	
        	//Toggle Toolbar Search 
        	jQuery("#JQBlistEventAccessDetails").jqGrid('navButtonAdd',"#listEventAccessDetailsPage",{
        		caption:"Search",title:"Toggle Search",
        		onClickButton:function(){ 			
        			if(jQuery(".ui-search-toolbar").css("display")=="none") {
        				jQuery(".ui-search-toolbar").css("display","");
        			} else {
        				jQuery(".ui-search-toolbar").css("display","none");
        			}							
        		} 
        	}); 
        	jQuery("#JQBlistEventAccessDetails").jqGrid('setGridWidth',gridWidth); 
        }

		function associationBtn(kolId,actionType){
			if(idsOfSelectedRows==''){
				jAlert("Please select at least one "+actionType+" for association");
				return false;
			}
			var data ={};
			data['actionIds'] = idsOfSelectedRows;
			data['actionType'] = actionType;
			data['action'] = 'association';
			data['project_id'] = <?php echo $rowData['id'];?>;
			data['kol_id'] = kolId;
			$.ajax({
				url:'<?php echo base_url()?>identifications/save_project_activity_association',
				data:data,
				type:'post',
				dataType:'json',
				success:function(res){	
					if(res.status){
						if(actionType == 'event'){
							getEventAccessed(kolId);
						}else if(actionType == 'affiliation'){
							getAffiliationAccessed(kolId);
						}else if(actionType == 'publication'){
							getPublicationAccessed(kolId);
						}else if(actionType == 'trial'){
							getTrialAccessed(kolId);
						}
					}else{		
// 						$(".errorName").html(res.msgName);
					}
				}
			});
			
		}

		function dissAssociationBtn(kolId,actionType){
			if(idsOfSelectedRows==''){
				jAlert("Please select at least one "+actionType+" for Dis-association");
				return false;
			}
			var data ={};
			data['actionIds'] = idsOfSelectedRows;
			data['actionType'] = actionType;
			data['action'] = 'disassociation';
			data['project_id'] = <?php echo $rowData['id'];?>;
			data['kol_id'] = kolId;
			$.ajax({
				url:'<?php echo base_url()?>identifications/save_project_activity_association',
				data:data,
				type:'post',
				dataType:'json',
				success:function(res){	
					if(res.status){
						if(actionType == 'event'){
							getEventAccessed(kolId);
						}else if(actionType == 'affiliation'){
							getAffiliationAccessed(kolId);
						}else if(actionType == 'publication'){
							getPublicationAccessed(kolId);
						}else if(actionType == 'trial'){
							getTrialAccessed(kolId);
						}
					}else{		
// 						$(".errorName").html(res.msgName);
					}
				}
			});
		}
		function GetSelectedYearRange(el)
		{
		    var fromYear = document.getElementById('fromYear');
		    var endYear = document.getElementById('endYear');
		    defaultStartYear = fromYear.options[fromYear.selectedIndex].value;
		    defaultEndYear = endYear.options[endYear.selectedIndex].value;
		    getKolAccessedDetails(defaultStartYear,defaultEndYear);
		}
		</script>
				
				
				
			<h1>Project Association Details</h1>
				  	<p>
						<label>Project Name : </label>
			       		<span>&nbsp;<?php echo $rowData['name'];?></span>						
					</p>
					<p>
						<label>Year Range : </label>
			       		<span>&nbsp;<?php echo $rowData['year_range'];?></span>						
					</p>
					<p>
						<label>Description : </label>
			       		<span>&nbsp;<?php echo $rowData['description'];?></span>						
					</p>
					<p>
						<label>Client Names : </label>
			       		<span>&nbsp;<?php 
			       		        $clientNames = '';
			       		        foreach ($arrClientList as $arrList){
    			       		        if (in_array($arrList['id'], $selectedClients)){
    			       		            $clientNames .= $arrList['name'].',';
    								}
                                } echo $clientNames;?></span>						
					</p>
					<!-- End of Personal and Professional Information -->
					
					<?php if((!empty($yearRange[0]) || $yearRange[0]!='') && (!empty($yearRange[1]) || $yearRange[1]!='')){
                        $defaultStartYear =  $yearRange[0];
                        $defaultEndYear = $yearRange[1];
					}else{
					    $defaultStartYear = date("Y") - 5;
					    $defaultEndYear = date("Y");
					}
                    ?>
					<p>
						<label>From Year : </label>
			       		<span>&nbsp;<select name="fromYear" id="fromYear" style="margin:0px;">
			       				<?php
			       				$presentYear = date("Y");
			       				for($i='2000';$i<=$presentYear;$i++){?>
			       				<option value="<?php echo $i;?>" <?php if($defaultStartYear==$i) echo "selected='selected'";?>><?php echo $i;?></option>
			       				<?php }?>
			       			  </select></span>						
					</p>
					<p>
						<label>End Year : </label>
			       		<span>&nbsp;<select name="endYear" id="endYear" style="margin:0px;">
			       				<?php
			       				$presentYear = date("Y");
			       				for($i='2000';$i<=$presentYear;$i++){?>
			       				<option value="<?php echo $i;?>" <?php if($defaultEndYear==$i) echo "selected='selected'";?>><?php echo $i;?></option>
			       				<?php }?>
			       			  </select></span>
					</p>
					<p><button onclick="GetSelectedYearRange();">Filter By Date Range</button></p>
					<br><br>
					<div class="gridIdDetails" id="gridKolsAccessDetailsContainer">
			            <table id="gridKols"></table>
						<div id="gridKolsListingPagintaion"></div>
					</div>
					<br><br>
					<div id="actionSection">
					</div>
					<div id="activityDrillDownContainer">
                		<div class="gridIdDetails" id="gridEventAccessDetailsContainer">
                    		<table id="JQBlistEventAccessDetails"></table>
    						<div id="listEventAccessDetailsPage"></div>
                		</div>
                	</div>
                	<br><br>
