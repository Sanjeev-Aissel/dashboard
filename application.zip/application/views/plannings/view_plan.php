<?php

?>

<script type="text/javascript">

$(document).ready(function(){
		<?php 
			/** @Author Ramesh
			 ** @since  22 Aug 2012
		 	**The following code is used to disable caching in IE
		 	**/	
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
});
</script>
<style>

	.plansResult span{
	  	display:block;
	    font-weight: bold;
	    text-align: right;
	}
	.plansResult{
	  padding-left: 4px;
	}
	
	.inertactionTable th{
	  background-color: #2E6E9E;
	  border-right: 1px solid #EEEEEE;
	  color: white;
	}
	
	.inertactionTable tbody tr td {
	    border: 1px solid #EEEEEE !important;
	}
	
	#closeButton{
		float:right;		
	
	}

	.ui-icon-closethick {
	    background-position: -96px -128px;
	    cursor: pointer;
	}

	#viewPlanContainer {
	    background-color: #FFFFFF;
	    border-radius: 15px 15px 15px 15px;
	    display: block;
	    margin-left: 8px;
	  /*  margin-top: -68px;*/
	    padding-left: 5px;
	    padding-right: 17px;
	    padding-top: 24px;
	    position: absolute;
	    width: 573px;
	}
</style>


<div id="closeButton">
	<button onclick="closeViewPlan();">Back To Plans</button>
</div>

<table class="plansResult" cellspacing="5px" cellpadding="5px">
	<h3>Plan Details:</h3>
	<tbody>
	<tr>
		<th><span>Plan Id :</span></th>
		<td>
			
			<?php echo $arrPlans['id']?>
		
		</td>
		<th><span>Plan Date :</span></th>
		<td>
			
			<?php echo $arrPlans['plan_date']?>
		
		</td>
	
	</tr>
	<tr>
		<th><span>Objective Name :</span></th>
		<td>
			<?php echo $arrPlans['name']?>
		
		</td>
		<th><span>Objective Description :</span></th>
		<td>
			<?php echo $arrPlans['description']?>
		
		</td>
	
	</tr>
	
	<tr>
		<th><span>Assigned To:</span></th>
		<td>
			<?php echo $arrPlans['user_first_name']." ".$arrPlans['user_last_name']?>
		
		</td>
		<th><span><?php echo lang("KOL");?> Name :</span></th>
		<td>
		
			<?php echo $arrSalutation[$arrPlans['salutation']]." ".$arrPlans['kol_name']?>
		
		</td>
	
	</tr>
	
	<tr>
		<th><span>Target :</span></th>
		<td>
			
			<?php echo $arrPlans['targets']?>
		
		</td>
		<th><span>Achieved :</span></th>
		<td>
			<?php echo $arrPlans['achived_interactions']?>
		
		</td>
	</tr>
	<tr>
		
	
	</tr>
	</tbody>
</table>


<table class="inertactionTable" cellspacing="0px" cellpadding="7px">
	<h3>Related Interactions:</h3>
	<tr>
		<th>Date</th>
		<th>Interaction Mode</th>
		<th>Product</th>
		<th>Brand</th>
		<th>Role</th>
		<th>Category</th>
		<th>Follow Up On</th>
		<th>Created By</th>
	
	</tr>
	<?php foreach($arrInteractions as $row){?>
	
		<tr>
			<td><?php echo $row['date']?></td>
			<td><?php echo $row['name']?></td>
			<td><?php echo $row['product']?></td>
			<td><?php echo $row['brand']?></td>
			<td><?php echo $row['role']?></td>
			<td><?php echo $row['category']?></td>
			<td><?php echo $row['follow_up_on']?></td>
			<td><?php echo $row['first_name']." ".$row['last_name']?></td>
		</tr>
		
	<?php }?>
</table>
