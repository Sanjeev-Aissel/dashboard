<?php
/**
 * This is HTML page to associate ktl for listing details
 * 
 * @author Vinayak
 * @created 24-11-2011
 * @since  3.4	
 */
$assoKtlListKolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>

<style type="text/css">
	.clientTbl label{
	 	display:inline;
		float:left;
		font-size:125%;
		margin-right:10px;
		text-align:right;
		width:33%;
	 }
	 .clientTbl select{
	 	width:52%;
	 	
	 }
	
	 
	 input[type="text"]{
    margin: 0;
    width: 33%;
	}
	.microView .ui-dialog-content {
	    background-color: none !important;
	}
	
	label.error{
	margin-left: 104px;
    width: 57%;
	}
	
	#listNameCss,#catCss,#css1,#css2{
	color:red;
	}
	
	#input input[type="text"],#listInputBoxContaioner input[type="text"]{
		width:187px;
	}
	
	input[type="text"], input[type="password"], input.text, input.title, textarea, select {
    margin: 0;
	}
	.error{
		padding:0;
	}
	.formHeader{
		border-bottom:1px solid #ccc;
		margin-bottom:10px !important;
	}
	h5{
	margin-bottom: 10px !important;
	}
</style>

<script type="text/javascript">

var assoKtlListKolAutoCompleteOptions = {
		<?php 
		if(KOL_CONSENT){?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1/1',
		<?php }else{ ?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1',
		<?php } ?>
		<?php echo $assoKtlListKolAutoCompleteOptions;?>,
		onSelect: function(event, ui) { 
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			selText=selText.replace(/\&amp;/g,'&');
			$('#kolName').val(selText);
			$('#kolId').val(kolId);
		 },
	};

var validationRules	=  {
		kol_name: {
			required:true
		}
};

	var validationMessages = {
			kol_name: {
			required: "Required",
			remote: ""
		}
	};
	
$(document).ready(function(){
	$("#saveKtlListForm").validate({
		debug:true,
		//onkeyup:true,
		rules: validationRules,
		messages: validationMessages
	});
	<?php 
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
	?>
	var assoKtlListKolAutoComplete	= $('#kolName').autocomplete(assoKtlListKolAutoCompleteOptions);
});
function validateListForm(){
	if(!$("#saveKtlListForm").validate().form()){
		//enableButton("saveEducation");
		return false;
	}else
		return true;
}

$("#saveKtlList").click(function(){
	if(!$("#saveKtlListForm").validate().form()){
		return false;
	}
	var kols=$("#kolId").val();
	if(kols!=0){
		$(' div.categoryMsgBox').removeClass('success');
		$(' div.categoryMsgBox').addClass('notice');
		$(' div.categoryMsgBox').show();
		$('div.categoryMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		$('div.categoryMsgBox').css({color:"black"});
		$.ajax({
			url:'<?php echo base_url()?>my_list_kols/save_ktls_list',
			data:$('#saveKtlListForm').serialize(),
			type:'post',
			dataType:'json',
			success:function(returnData){
					if(returnData.kol_saved==true){
							$('div.categoryMsgBox').text(returnData.msg);
					}else{
							$('div.categoryMsgBox').text(returnData.msg);
					}
					if(returnData.kol_saved==true){
						$('div.categoryMsgBox').removeClass('error');
						$('div.categoryMsgBox').addClass('success');
						$('#listKolsOfcategory').load(base_url+'my_list_kols/list_kols_of_cetagory/'+returnData.list_name_id);
						setTimeout(closeDialog, 2000);
					}else{
						$('div.categoryMsgBox').addClass('error');
						$('div.categoryMsgBox').removeClass('success');
						$('div.categoryMsgBox').fadeOut(10000);
					}
				}
		});	
	}
});
function closeDialog(){
	$("#addListKtls").dialog("close");
}	

</script>


<div class="formHeader">
		<h5>Add <?php echo lang("KOL");?> to Selected Listing</h5>	
</div>
<div class="categoryMsgBox"></div><div class="errorBox"></div>
		<form action="<?php echo base_url();?>my_list_kols/save_ktl_listing" method="post" id="saveKtlListForm" name="saveKtlListForm" class="validateForm" onsubmit="return validateListForm();">
		<table class="clientTbl">
			<tr>
			<td>
					<b>Category Name :</b> <?php echo $listing_details->category; ?>
					<input type="hidden" name="catid" id="categoryId" value="<?php echo $listing_details->catId;?>"></input>
					<br/>
					<b>Listing  Name :</b> <?php echo $listing_details->list_name; ?>
					<input type="hidden" name="list_name_id" id="listId" value="<?php echo $listing_details->listId;?>"></input>
					</td>
			</tr>
			<tr>
				<td>
					<p>	
						<label for="kolName"><?php echo lang("KOL");?> Name :<span class="required">*</span></label>
						<input type="text" name="kol_name" id="kolName" value="" class="required autocompleteInputBox"></input>
						<input type="hidden" name="kol_id" id="kolId" value="">
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<div class="formButtons"">
						<input type="button" value="Save"  id="saveKtlList" name="saveKtlList">
			         </div>
		         </td>
	         </tr>
	        
         </table>
	</form>