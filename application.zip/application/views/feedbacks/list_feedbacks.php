<?php
/**
 * File Description : listing of feedbacks in jqgrid
 * 
 * @author		Laxman K
 * @since		5.0
 * @Created on  Aug 21, 2012
 */
?>
	<script type="text/javascript">
		function listRecordsPerPage(maxRecords,increament){
			var rowList=new Array();
		 	for(i=increament;i<=maxRecords;i+=increament){
		 		rowList.push(i);
		 	} 	
		 	return rowList;
		}
		
		/** 
		* Show/Hide the Search Tool Bar in the JQGrid
		*/
		function toggleSearchToolbar(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}
		};
		
		function list_feedbacks_grid(){
			$('#gridKolsListing').html('');
		    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
			jQuery("#gridKolsListingResultSet").jqGrid({
				url:'<?php echo base_url();?>feedbacks/list_feedbacks_grid',
				datatype: "json",
				colNames:['Feedback Type','Client','Subject','Description', 'Uploaded File','Created By'],
			   	colModel:[
					{name:'feedback_type',index:'feedback_type',width:70,search:true},
			   		{name:'clientName',index:'clientName',width:90, search:true},
			   		{name:'subject',index:'subject',search:true,width:90, resizable:false},
			   		{name:'description',index:'description',width:140,search:true},
			   		{name:'file_name',index:'file_name',width:80,search:true, align:'center',resizable:false},
					{name:'user_full_name',index:'user_full_name',width:60,search:true},
			   	],
			   	rowNum:10,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#gridKolsListingPagintaion',
			   	mtype: "POST",
			   	sortname: 'name',
			    viewrecords: true,
			    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:"Feedbacks",
			    gridComplete: function(){	
			    },
				rowList:listRecordsPerPage(200,10)
			});
			jQuery("#gridKolsListingResultSet").jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#gridKolsListingResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
			//Toggle Toolbar Search 
			jQuery("#gridKolsListingResultSet").jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
				onClickButton:toggleSearchToolbar
			});
		}
	
		$(document).ready(function(){
			list_feedbacks_grid();
		});
	</script>
	
	<style type="text/css">
		#listKols a{
			letter-spacing: 0px;
		}
		.ui-widget-content a {
			color:#000099;
		}

		.buttons {
			float: none;
		}
		tr.selectedRow {
		    background-color: #D8DFEA !important;
		}
		#contents{
			padding:10px 50px;
		}
		
		#contents table{
			font-size:125%;
			border-collapse:collapse;
		/*	border:1px solid #ccc; */
		}
		
		#contents table, td, th{
		/*	border:1px solid #ccc; */
		}
		
		h1{
			color:#2E6E9E;
			font-size:170%;
			margin-bottom:10px;
			margin-top:15px;
			text-align:left;
		}
		
		#linkHeaders{
			float:left;
			text-align:right;
		}
		a.addLink{
			text-decoration:none;
		}
		
		div#listKolsTbl{
			padding:0;
			width:100%;		
		}
		div.extraOptions div.rightSideOptions{
			text-align: right;
			font-weight:bold;
			padding:5px;
		}
		div.extraOptions div.leftSideOptions{
			float:left;
			text-align: left;
			width: 50%;
			margin-top: 5px;
		}
		input[type="checkbox"]{
			position: static;
		}
		.additionalLinks a{
			display:block;
			width:150px;
			float: left;
		}
		
		select.pubmed-status{
			width: 65px;
			float: left;
		}
		
		button.pubmed-status-chnage-btn{
			background-color: green;
		    border: 0 none;
		    border-radius: 5px 5px 5px 5px;
		    cursor: pointer;
		    display: block;
		    float: right;
		    height: 13px;
		    margin-right: 0;
		    margin-top: 5px;
		    width: 14px;
		}
		.processing{
			background-image: url("../images/anim_loading_16x16.gif");
			background-color: #ffffff !important;
		}
	</style>
	
	<div>
	<div class="msgBox">
	
	</div>
	</div>
	
		<div class="msgBoxContainer"><div class="kolMsgBox"></div></div>
	
		<div id="gridKolsListing">
			<div class="gridWrapper">
				<div id="gridKolsListingPagintaion"></div>
				<table id="gridKolsListingResultSet"></table>
			</div>
		</div>