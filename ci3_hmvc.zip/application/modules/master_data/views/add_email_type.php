
<!-- <h1>Add Email Type</h1> -->
<div class="emailTypeMsgBox"></div>
<form>
	<div align="center">
		<caption><h4>Add/Edit Email Type</h4></caption>
	</div>
	<table class="anaylystForm eventTbl ">

		<br />
		<tr>
			<td><div align="center">
					<span id="responseMessage"></span>
				</div>
				<p>
					<input type="hidden" id="hiddenId" readonly>
				
				<div align="center">
				<label>Email Type :</label><input type="text" name="type" id="type"
						align="center" />
				</div>
				</p></td>
		</tr>
		<tr>
			<td>
				<div class="formButton" align="center">
					<input type="button" value="Save" name="submit"
						onclick="saveEmailType();"></input> <input type="button"
						value="Cancel" name="submit" onclick="closeModal();"></input>
				</div>
			</td>
		</tr>
	</table>
	<!-- End of Table -->
</form>
<!-- End of User Form -->



