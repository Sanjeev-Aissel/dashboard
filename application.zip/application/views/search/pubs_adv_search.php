<?php
/**
*File To show Pubmed Advance search page.
*
*@author: Ambarish N
*@created on: 09-02-11
*/
?>

<div id="advSearchFieldsContainer">
	<div class="msgBoxContainer">
		<div class="advSearchMsgBox">
		</div>
	</div>
	<form action="<?php echo base_url()?>pubmeds/adv_search_publications" name="advSearchForm" method="post" id="advSearchForm">
		<fieldset><legend>Publications Advanced Search</legend>
		<p>
			<label>Keywords </label>
			<input type="text" name="pubKeywords" id="pubKeywords"/>
		</p>
		<p>
			<label>Authors</label>
			<input type="text" name="authors" id="authors"/>
		</p>
		<p>
			<label>MeshTerms</label>
			<input type="text" name="mesh_term" id="mesh_term"/>
		</p>
		<p>
			<label>Substances </label>
			<input type="text" name="substances" id="substances"/>
		</p>
		<input type="button" name="do_earch" id="doSearch" onclick="validateAdvSearchForm()" value="search"/>			
		</fieldset>
	</form>
</div>