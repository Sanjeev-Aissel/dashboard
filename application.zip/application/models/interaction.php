<?php

/**
 * This class contains the methods to Interactions module activites 
 * 
 * @package application.models
 * @author Ramesh B
 * @since 1.5
 * @created on 28-02-11
 */
class Interaction extends Model {

    function Interaction() {
        parent::Model();
        $this->load->model('common_helpers');
        $this->load->model('calendar');
        $this->load->model('update');
        $this->load->model('Client_User');
    }

    /**
     * Retrives the all the Interatctions Modes associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllModesOfClient($clientId,$orgType) {
        $arrModes = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        if(!empty($orgType)){
            $this->db->where('org_active',1);
        }
        $arrModeResults = $this->db->get('interactions_modes');
        foreach ($arrModeResults->result_array() as $row) {
            $arrModes[$row['id']] = $row;
        }
        return $arrModes;
    }

    /**
     * Retrives the all the Interatctions Topics associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllTopicsOfClient($clientId) {
        $arrTopics = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        $arrTopicResults = $this->db->get('interactions_topics');
        foreach ($arrTopicResults->result_array() as $row) {
            $arrTopics[$row['id']] = $row;
        }
        return $arrTopics;
    }

    /**
     * Retrives the all the Interatctions Brands associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllBrandsOfClient($clientId) {
        $arrBrands = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        $arrBrandResults = $this->db->get('interactions_brands');
        foreach ($arrBrandResults->result_array() as $row) {
            $arrBrands[$row['id']] = $row;
        }
        return $arrBrands;
    }

    /**
     * Retrives the all the Interatctions Roles associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllRolesOfClient($clientId) {
        $arrRoles = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        $arrRoleResults = $this->db->get('interactions_roles');
        foreach ($arrRoleResults->result_array() as $row) {
            $arrRoles[$row['id']] = $row;
        }
        return $arrRoles;
    }

    /**
     * Retrives the all the Interatctions Categories associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllCategoriesOfClient($clientId) {
        $arrCategories = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        $arrCategoryResults = $this->db->get('interactions_categories');
        foreach ($arrCategoryResults->result_array() as $row) {
            $arrCategories[$row['id']] = $row;
        }
        return $arrCategories;
    }

    /**
     * Retrives the all the Interatctions Therapeutic Areas associated with client from lookUp table
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getAllTherapeuticAreasOfClient() {
        $arrAreas = array();
        $arrAreaResults = $this->db->get('interactions_therapeutic_areas');
        foreach ($arrAreaResults->result_array() as $row) {
            $arrAreas[] = $row;
        }
        return $arrAreas;
    }

    /**
     * Saves the Interaction details
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Integer
     */
    function saveInteraction($arrInteractionDetails) {
        if ($this->db->insert('interactions', $arrInteractionDetails)) {
            //echo $this->db->last_query();
            return $this->db->insert_id();
            
        } else
            return 0;
    }

    function getInteractionAttendees($interactionID, $kolId = null, $interactionFor = 'kol',$ipad=false) {
    	
        $arrInteractionDetails = array();
        $arrInteractionDetails['kol_names'] = array();
        $arrInteractionDetails['kol_ids'] = array();
        $arrInteractionDetails['specialties'] = array();
        $arrInteractionDetails['title'] = array();
        $arrInteractionDetails['department'] = array();
        $arrInteractionDetails['categories'] = array();
        $arrInteractionDetails['roles'] = array();
        $arrInteractionDetails['kol_name_for_export'] = array();
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $this->db->select("kols.profile_image,kols.id,kols.unique_id,kols.salutation,kols.status,kols.deleted_by as kol_deleted,kols.last_name,kols.middle_name,kols.first_name,kols.division,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty,interactions_attendees.note,organizations.id as org_id,organizations.name as org_name, interactions_attendees.status as interaction_status,key_peoples.first_name as key_fn,key_peoples.middle_name as key_mn,key_peoples.last_name as key_ln,key_peoples.title as key_title,key_peoples.department,titles.title");
        $this->db->where('interaction_id', $interactionID);
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id', 'left');
        $this->db->join('key_peoples', 'interactions_attendees.key_id = key_peoples.id', 'left');
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
        $this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id', 'left');
        $this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id', 'left');
        if ($kolId != null && $kolId != -1) {
            /* if($interactionFor == 'org')
              $this->db->where('interactions_attendees.org_id',$kolId);
              else
              $this->db->where('interactions_attendees.kol_id',$kolId); */
        }
        //$this->db->order_by('interactions_attendees.kol_id');
        $interactionDetailsResult = $this->db->get('interactions_attendees');
       // echo $this->db->last_query();exit;
        foreach ($interactionDetailsResult->result_array() as $row) {
;
            $microview = '';
            $extraSegmentIf = "";
            if (IS_IPAD_REQUEST)
                $extraSegmentIf = IPAD_URL_SEGMENT . "/";
            if ($row['org_id'] != null && $row['org_id'] != '') {
            	if (IS_IPAD_REQUEST || $ipad){
            	    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
    	            	if($row['id']!=''){
    	            		$arrInteractionDetails['kol_names'][] = '<a href="' . base_url() . $extraSegmentIf . 'kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
    	            	}else{
    	            		$arrInteractionDetails['kol_names'][] =  $this->common_helpers->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
    	            	}
            	    }else{
            	        $arrInteractionDetails['kol_names'][] =  $this->common_helpers->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
            	    }
            	}else{
            	    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
                		if($row['id']!=''){
                        	$arrInteractionDetails['kol_names'][] = '<a href="' . base_url() . '/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
                		}else{
                        	$arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
                		}
            	    }else{
                	    $arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
                	}
            	}
                $microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
            }else {
                //if($row['status']==PRENEW || $row['status']==COMPLETED){
                if (true) {
                    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
                        if (IS_IPAD_REQUEST || $ipad) {
                            $arrInteractionDetails['kol_names'][] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                        } else {
                            $arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                        }
                    }else {
                        $arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
                    }
                    $microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
                } elseif ($row['status'] == New1 || $row['status'] == APPROVED) {
                    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
                        $arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . $extraSegmentIf . 'requested_kols/show_client_requested_kols">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                    }else {
                        $arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
                    }
                } elseif ($row['status'] == 'rejected') {
                    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
                    $arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . $extraSegmentIf . 'requested_kols/show_non_profiled_kols">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                    }else {
                        $arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
                    }
                } else {
                    if($row['kol_deleted']==0 || $row['kol_deleted']==null){
                        $arrInteractionDetails['kol_names'][] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
                    }else {
                        $arrInteractionDetails['kol_names'][] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
                    }
                }
            }
             $arrInteractionDetails['kol_images'][] = $row['profile_image'];
            $arrInteractionDetails['microview'][] = $microview;
            $arrInteractionDetails['specialties'][] = $row['specialty'];
            if($row['id']>0){
            	$arrInteractionDetails['department'][] = $row['division'];
            	$arrInteractionDetails['title'][] = $row['title'];
            }else{
            	$arrInteractionDetails['department'][] = $row['department'];
            	$arrInteractionDetails['title'][] = $row['key_title'];
            }
            $arrInteractionDetails['interaction_status'][] = $row['interaction_status'];
            $arrInteractionDetails['categories'][] = $row['category_name'];
            $arrInteractionDetails['roles'][] = $row['role_name'];
            $arrInteractionDetails['note'][] = $row['note'];
            if ($row['org_id'] != null && $row['org_id'] != '') {
                $arrInteractionDetails['last_interaction'][] = $this->interaction->getOrgLastInteractionById($row['org_id']);
                //   pr($arrInteractionDetails['last_interaction']);
            } else {
                $arrInteractionDetails['last_interaction'][] = $this->interaction->getKolLastInteractionById($row['id']);
            }
            if ($row['org_id'] != null && $row['org_id'] != '') {
            	$arrInteractionDetails['org_id'] = $row['org_id'];
            	$arrInteractionDetails['org_name'] = $row['org_name'];
                $arrInteractionDetails['kol_name_for_export'][] = $row['org_name'];
                $microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
            } else {
                $arrInteractionDetails['kol_name_for_export'][] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
            }



            $arrInteractionDetails['kol_ids'][] = $row['id'];
        }
        return $arrInteractionDetails;
    }

    function getInteractionAboutTopics($interactionID, $kolId = null) {
        $arrInteractionDetails = array();
        $this->db->select("interaction_topics.id as topic_id,interaction_topics.name as topic_name,products.name as product_name,products.id as product_id,interaction_types.name as objective_name,interaction_types.id as objective_id,interaction_sub_topics.name as sub_topic_name");
        $this->db->where('interactions_discussion_topic_mapped_data.interaction_id', $interactionID);

        $this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
        $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
        $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');

        $this->db->join('interaction_sub_topics', 'interaction_sub_topics.id = interactions_discussion_topic_mapped_data.sub_topic_id', 'left');
        if ($kolId != null && $kolId != -1) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions_discussion_topic_mapped_data.interaction_id', 'left');
            $this->db->where('interactions_attendees.kol_id', $kolId);
        }
        $this->db->order_by("interactions_discussion_topic_mapped_data.id",'asc');
        $interactionDetailsResult = $this->db->get('interactions_discussion_topic_mapped_data');
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionDetails['topic_names'][] = $row['topic_name'];
             $arrInteractionDetails['topic_ids'][] = $row['topic_id'];//cross_patform
            $arrInteractionDetails['objective_names'][] = $row['objective_name'];
            $arrInteractionDetails['objective_ids'][] = $row['objective_id'];//cross_patform
            $arrInteractionDetails['product_names'][] = $row['product_name'];
            $arrInteractionDetails['product_ids'][] = $row['product_id'];//cross_patform
            $arrInteractionDetails['sub_topic_names'][] = $row['sub_topic_name'];
        }
        return $arrInteractionDetails;
    }

    /**
     * Retrives the all the Interactions of the Client
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getInteractions($clientId, $kolId, $userId, $arrFilters) {
        $arrInteractionDetails = array();
//		if($kolId!=null && $kolId!=-1)
//			$this->db->where('interactions.kol_id',$kolId);
        if ($kolId != null && $kolId != -1) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
            $this->db->where('interactions_attendees.kol_id', $kolId);
        }
//         if ($userId != 0)
//             $this->db->where('interactions.created_by', $userId);
        if ($clientId != 0)
            $this->db->where('interactions.client_id', $clientId);
//		$this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_brands.name as brand_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty as area_name,objectives.name as objective_name");
        $this->db->select("interactions.*,interactions_modes.name as mode_name,timestampdiff(DAY,interactions.created_on,interactions.date ) as days");
//		$this->db->join('interactions_about', 'interactions_about.interaction_id = interactions.id','left');
//		$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id','left');
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');


        if ($endDate != null && $startDate != null) {
            $this->db->where("interactions.date BETWEEN '" . $startDate . "-01' AND '" . $endDate . "-31'");
        } else if ($startDate != null) {
            $this->db->like('interactions.date', $startDate);
        }
     if($arrFilters['one_week']==true && !isset($arrFilters['latest_date'])){//cross platform


            $this->db->where("interactions.date BETWEEN '" . date('Y-m-d', strtotime('-7 days')) . "' AND '" . date('Y-m-d') . "'");

        }
        
        if($arrFilters['latest_date']!=''){//cross platform
               $this->db->where("interactions.created_on  >= '".$arrFilters['latest_date']."'");
        }
        $this->db->order_by('id', 'desc');
        if ($limit != null)
            $this->db->limit($limit, $startFrom);
        $interactionDetailsResult = $this->db->get('interactions');
        //pr($this->db->last_query());exit;
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id'], $kolId);
            $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id'], $kolId);
            $row['kol_name'] = implode(',', $arrInteractionAttendees['kol_names']);
            $row['area_name'] = implode(',', $arrInteractionAttendees['specialties']);
            $row['category_name'] = implode(',', $arrInteractionAttendees['categories']);
            $row['role_name'] = implode(',', $arrInteractionAttendees['roles']);
            $row['topic_name'] = implode(',', $arrInteractionAboutTopics['topic_names']);
            $row['objective_name'] = implode(',', array_unique($arrInteractionAboutTopics['objective_names']));
            $row['product_name'] = implode(',', array_unique($arrInteractionAboutTopics['product_names']));
            $row['kol_name_for_export'] = implode(',', $arrInteractionAttendees['kol_name_for_export']);
            $row['topic_ids']=$arrInteractionAboutTopics;
            $row['kol_id'] = $kolId;
            $row['kol_image']=implode(',', $arrInteractionAttendees['kol_images']);
            if($arrFilters['latest_date']!=''){
            if( abs($row['days'])<=7)
            $arrInteractionDetails[] = $row;
            }
            else
                $arrInteractionDetails[] = $row;
            //	pr($row);
        }

        //	pr($arrInteractionDetails);
        return $arrInteractionDetails;
    }

    /**
     * Retrives Interaction record
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getInteractionDetails($interactionId) {
        $interactionDetails = array();
        $this->db->where('interactions.id', $interactionId);
//		$this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_brands.name as brand_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty as area_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,objectives.name as objective_name");
        $this->db->select("client_users.first_name as emp_fname,client_users.last_name as emp_lname,interactions.*,interactions_modes.name as mode_name, regions.region as state, cities.city as city,interaction_grouping.name as group_name, countries.country, interaction_location_types.name as location_category_name,CONCAT(created_users.first_name,' ',created_users.last_name) as created_by_name", false);
//		$this->db->join('interactions_about', 'interactions_about.interaction_id = interactions.id','left');
//		$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id','left');
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
//		$this->db->join('objectives', 'interactions_about.objective_id = objectives.id','left');
//		$this->db->join('interactions_topics', 'interactions_about.topic_id = interactions_topics.id','left');
//		$this->db->join('interactions_brands', 'interactions_about.brand_id = interactions_brands.id','left');
//		$this->db->join('interactions_products', 'interactions_products.id = interactions_about.product_id','left');
//		$this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id','left');
//		$this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id','left');
//		$this->db->join('kols', 'interactions_attendees.kol_id = kols.id','left');
//		$this->db->join('specialties', 'kols.specialty = specialties.id','left');
        $this->db->join('regions', 'RegionId = interactions.state_id', 'left');
        $this->db->join('cities', 'cityId = interactions.city_id', 'left');
        $this->db->join('countries', 'countries.CountryId = interactions.country_id', 'left');
        $this->db->join('client_users', 'interactions.employee_id = client_users.id', 'left');
        $this->db->join('client_users as created_users', 'interactions.created_by = created_users.id', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
        $this->db->join('interaction_location_types', 'interaction_location_types.id = interactions.location_category', 'left');
        $interactionDetailsResult = $this->db->get('interactions');
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id']);
            $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id']);
            $row['attendees'] = $arrInteractionAttendees;
            $row['aboutTopics'] = $arrInteractionAboutTopics;
            $interactionDetails = $row;
        }
        return $interactionDetails;
    }

    /**
     * Updates the given  Interaction record
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Boolean
     */
    function updateInteraction($interactionDetails) {
        $this->db->where('id', $interactionDetails['id']);
        if ($this->db->update('interactions', $interactionDetails))
            return true;
        else
            return false;
    }

    /**
     * Saves the Interaction Document details
     * @author 	Ramesh B
     * @Created on: 03-03-11
     * @since	1.5
     * @return Boolean
     */
    function saveInteractionDocument($arrDocDetails) {
        if ($this->db->insert('interaction_docs', $arrDocDetails)) {
            return true;
        } else
            return false;
    }

    /**
     * Retrives the Interaction Documents details
     * @author 	Ramesh B
     * @Created on: 05-03-11
     * @since	1.5
     * @return Array
     */
    function getInteractionDocs($interactionId, $docId = null) {
        $client_id = $this->session->userdata('client_id');
        $arrDocs = array();
        if ($docId != null)
            $this->db->where('interaction_docs.id', $docId);

        if ($interactionId != null)
            $this->db->where('interaction_docs.interaction_id', $interactionId);
        $this->db->select('interaction_docs.*');
        $this->db->select('interactions.country_id as country');
        $this->db->join ('interactions', 'interactions.id = interaction_docs.interaction_id', 'left' );
        $arrDocsResults = $this->db->get('interaction_docs');
        foreach ($arrDocsResults->result_array() as $row) {
            $row['download'] = $this->common_helpers->isActionAllowed('interaction_doc_download', 'download', $row);
            $arrDocs[] = $row;
        }
        return $arrDocs;
    }

    /**
     * Deletes the document with the given document id
     * @author 	Ramesh B
     * @Created on: 05-03-11
     * @since	1.5
     * @return Boolean
     */
    function deleteDocuments($documentId) {
        $fileName = "";
        $this->db->where('id', $documentId);
        $this->db->select('doc_path');
        $result = $this->db->get('interaction_docs');
        $data = $result->row();
        $fileName = $data->doc_path;
        $this->db->where('id', $documentId);
        if ($this->db->delete('interaction_docs'))
            return $fileName;
        else
            return false;
    }

    /**
     * Deletes the Interaction with the given Interaction id
     * @author 	Ramesh B
     * @Created on: 07-03-11
     * @since	1.5
     * @return 
     */
    function deleteInteraction($interactionId) {
        $this->db->where('id', $interactionId);
        if ($this->db->delete('interactions'))
            return true;
        else
            return false;
    }

    /**
     * Retrives the all the interactions which matches the given parameters, for each parameter it does AND operation, 
     * if the parameter is an 'Array' it does or with in that 
     * @author 	Ramesh B
     * @Created on: 08-03-11
     * @since	1.5.1
     * @return Array
     */
    function getInteractionsByParam($fromYear, $toYear, $clientId, $arrKolIds = 0, $arrTypes = 0, $arrCountries = 0, $arrSpecialties = 0, $groupBy = 0) {
        $arrInteractions = array();
        $isKolsJoined = false;
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id=interactions.id', 'left');
        //Adding condition for client id
        if ($clientId != 0)
            $this->db->where('interactions.client_id', $clientId);

        //Adding where condition for KOL Id's if Exist
        if (is_array($arrKolIds)) {
            //$kolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
            //$this->db->where_in('interactions.kol_id',$kolIds);
            $this->db->where_in('interactions_attendees.kol_id', $arrKolIds);
        } else if ($arrKolIds != 0) {
            $this->db->where('interactions_attendees.kol_id', $arrKolIds);
        }

        //Adding where condition for interaction Type's if Exist
        if (is_array($arrTypes)) {
            $this->db->where_in('interactions.mode', $arrTypes);
        } else if ($arrTypes != 0) {
            $this->db->where('interactions.mode', $arrTypes);
        }

        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
            $this->db->join('kols', 'kols.id=interactions.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
            $this->db->join('kols', 'kols.id=interactions.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialties)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=interactions.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialties);
        }else if ($arrSpecialties != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=interactions.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialties);
        }

        if ($fromYear != 0 && $toYear != 0) {
            $wherBetween = "(YEAR(interactions.date) BETWEEN '$fromYear' AND '$toYear' OR YEAR(interactions.date)='0')";
            $this->db->where($wherBetween);
        }


        //Adding Group by based param $groupBy
        if ((string) $groupBy == "year") {
            $this->db->select('YEAR(interactions.date) AS year, COUNT(YEAR(interactions.date)) AS count');
            $this->db->group_by('YEAR(interactions.date)');
            //echo $groupBy;
        } else if ((string) $groupBy == "month") {
            $this->db->select("YEAR(interactions.date) AS year, MONTH(interactions.date) as month, COUNT(MONTH(interactions.date)) AS count");
            $this->db->group_by('YEAR(interactions.date),MONTH(interactions.date)');
            //echo $groupBy;
        } else if ((string) $groupBy == 'mode') {
            $this->db->select('interactions_modes.name AS mode, COUNT(interactions.mode) AS count');
            $this->db->join('interactions_modes', 'interactions_modes.id=interactions.mode', 'left');
            $this->db->where('interactions_modes.name !=', 'null');
            $this->db->group_by('interactions.mode');
            //echo $groupBy;
        } else if ((string) $groupBy == 'grouping') {
            $this->db->select('interaction_grouping.name AS grouping, COUNT(interactions.grouping) AS count');
            $this->db->join('interaction_grouping', 'interaction_grouping.id=interactions.grouping', 'left');
            $this->db->where('interaction_grouping.name !=', 'null');
            $this->db->group_by('interactions.grouping');
            //echo $groupBy;
        } else if ((string) $groupBy == 'type') {
            $this->db->select('interaction_types.name AS type, COUNT(interactions_topic_mapped_data.objective_id) AS count');
            $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id=interactions.id', 'left');
            $this->db->join('interaction_types', 'interaction_types.id=interactions_topic_mapped_data.objective_id', 'left');
            $this->db->where('interaction_types.name !=', 'null');
            $this->db->group_by('interactions_topic_mapped_data.objective_id');
            //echo $groupBy;
        } else if ((string) $groupBy == 'topic') {
            $this->db->select('interactions_topics.name AS topic, COUNT(interactions_topic_mapped_data.topic_id) AS count');
            $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id=interactions.id', 'left');
            $this->db->join('interactions_topics', 'interactions_topics.id=interactions_topic_mapped_data.topic_id', 'left');
            $this->db->where('interactions_topics.name !=', 'null');
            $this->db->group_by('interactions_topic_mapped_data.topic_id');
            //echo $groupBy;
        } else if ((string) $groupBy == 'kolId') {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=interactions_attendees.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->select('kols.salutation,kols.last_name,kols.middle_name,kols.first_name, COUNT(interactions.id) AS count');
            $this->db->group_by('interactions.kol_id');
            $this->db->order_by('count DESC');
            //echo $groupBy;
        }else {
            $this->db->select('interactions.*');
            //echo 'No Grouping';
        }

        $arrInteractionsResults = $this->db->get('interactions');
        foreach ($arrInteractionsResults->result_array() as $row) {
            $arrInteractions[] = $row;
        }
        //echo $this->db->last_query();;
        return $arrInteractions;
    }

    /**
     * Retrives the all the interactions for the passed KOL id
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     */
    function getInteractionsByKolId($clientId, $kolId) {
        $arrInteractions = array();
        if ($clientId != 0)
            $this->db->where('interactions.client_id', $clientId);
        $this->db->where('interactions.kol_id', $kolId);
        $arrInteractionsResults = $this->db->get('interactions');
        foreach ($arrInteractionsResults->result_array() as $row) {
            $arrInteractions[] = $row;
        }
        return $arrInteractions;
    }

    /**
     * Deletes the Interactions for the passed KOL id
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     */
    function deleteInteractionsByKolId($clientId, $kolId) {
        $arrInteractions = $this->getInteractions($clientId, $kolId);
        foreach ($arrInteractions as $row) {
            $interactionId = $row['id'];
            $no = $this->checkNoOfKolsAssoWithInteaction($interactionId);
            if ($no == 1) {
                if ($row['calendar_event_id'] != 0)
                    $this->calendar->deleteEvent($row['calendar_event_id']);
                //Delete interaction documents
                $arrinteractionDocs = $this->getInteractionDocs($interactionId);
                if (sizeof($arrinteractionDocs) >= 1) {
                    foreach ($arrinteractionDocs as $interactionDoc) {
                        //Deletes the doccument and returns its file name
                        $fileName = $this->deleteDocuments($interactionDoc['id']);
                        if ($fileName != '') {
                            unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_interactions_documents/" . $fileName);
                        }
                    }
                }

                //Delete Interaction record
                $isDeleated = $this->deleteInteraction($interactionId);
                $this->update->deleteUpdateEntry(INTERACTION_ADD, $interactionId, MODULE_INTERACTION);
                $this->update->deleteUpdateEntry(INTERACTION_UPDATE, $interactionId, MODULE_INTERACTION);

                //Delete Interation about(Objective,tpoic,product,Brand);
                $this->deleteInteractionTopicDetail($interactionId);

                //Delete Interation Attendies
                $this->deleteInteractionAttendis($interactionId);

                //Delete Interation Usres
                $this->deleteInteractionUsers($interactionId);
            } else {
                //pr($row);
                $this->deleteKolAssociation($interactionId, $kolId);
            }
        }
    }

    /**
     * Returns the details of the interaction matching the calender event id
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     */
    function getInteractionByCalEventId($calEventId) {
        $interactionDetails = array();
        $this->db->where('interactions.calendar_event_id', $calEventId);
        $this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_roles.name as role_name,interactions_categories.name as category_name,interactions_therapeutic_areas.name as area_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,regions.region as state, cities.city as city, interaction_grouping.name as group_name");
        $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id = interactions.id', 'left');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        //$this->db->join('interaction_internal_users', 'interaction_internal_users.interaction_id = interactions.id','left');
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
        $this->db->join('interactions_topics', 'interactions_topic_mapped_data.topic_id = interactions_topics.id', 'left');
        #$this->db->join('interactions_brands', 'interactions.brand = interactions_brands.id','left');
        $this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id', 'left');
        $this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id', 'left');
        $this->db->join('interactions_therapeutic_areas', 'interactions_attendees.specialty_id = interactions_therapeutic_areas.id', 'left');
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id', 'left');
        $this->db->join('regions', 'RegionId = interactions.state_id', 'left');
        $this->db->join('cities', 'cityId = interactions.city_id', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
        $interactionDetailsResult = $this->db->get('interactions');
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id']);
            $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id']);
            //$row['internal_users']		= $this->getInteractionsInternalUsers($row['id']);
            $row['attendees'] = $arrInteractionAttendees;
            $row['aboutTopics'] = $arrInteractionAboutTopics;
            $interactionDetails = $row;
        }
        //echo $this->db->last_query();
        return $interactionDetails;
    }

    /**
     * Returns the years range of the user interactions.
     * @author 	Ramesh B
     * @Created on: 31-08-11
     * @since	3.1
     * @return Array
     */
    function getInteractionsYearsRange($clientId, $userId, $kolId = null) {
        $arrYears = array();
        $arrYears['min_year'] = '';
        $arrYears['max_year'] = '';
        $this->db->select("MIN(year(date)) AS min_year, max(year(date)) AS max_year");
        $this->db->where("year(date)!=", 0);
        $this->db->where("client_id", $clientId);
        if ($userId != 0)
            $this->db->where("created_by", $userId);
        if ($kolId != null)
            $this->db->where('kol_id', $kolId);
        $arrResults = $this->db->get("interactions");

        foreach ($arrResults->result_array() as $row) {
            $arrYears['min_year'] = $row['min_year'];
            $arrYears['max_year'] = $row['max_year'];
        }
        //echo $this->db->last_query();
        return $arrYears;
    }

    /**
     * Returns array of all the users achieved interactions for each kol.within the specified date rnage
     * @author Ramesh B
     * @since 3.1
     * @param $clientId
     * @param $startDate
     * @param $endDate
     * @return Boolean
     * @created 17-09-2011
     */
    function getAllUserAchievedInteractionsPerKOL($clientId, $startDate, $endDate) {
        $arrUsersInteractionsPerKolCount = array();
        $this->db->select('created_by,interactions_attendees.kol_id,COUNT(interactions_attendees.kol_id) AS achieved');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id=interactions.id', 'left');
        $this->db->where('client_id', $clientId);
        $this->db->where("date BETWEEN '$startDate' AND '$endDate'");
        $this->db->group_by('kol_id,created_by');
        $this->db->order_by('created_by', 'ASC');
        $results = $this->db->get('interactions');
        foreach ($results->result_array() as $row) {
            $arrUsersInteractionsPerKolCount[$row['created_by']][$row['kol_id']] = $row['achieved'];
        }
        return $arrUsersInteractionsPerKolCount;
    }

    /**
     * Returns the count of Interactions
     * @author Ramesh B
     * @since 3.3
     * @param $clientId
     * @param $userId
     * @param $kolId
     * @return Integer
     * @created 14-11-11
     */
    function countInteractions($clinetId, $userId, $kolId = null) {
        $count = '';
        if ($clinetId != 0)
            $this->db->where('client_id', $clinetId);
        if ($userId != 0)
            $this->db->where('created_by', $userId);
        if ($kolId != null && $kolId != 0) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id=interactions.id', 'left');
            $this->db->where('kol_id', $kolId);
        }
        if ($count = $this->db->count_all_results('interactions')) {
            return $count;
        } else {
            return false;
        }
    }

    function getAllProductsOfClient($clientId) {
        $arrProducts = array();
        //This client id condition will be enabled once we enter a separate values for each client
        //$this->db->where('client_id',$clientId);
        $arrProductResults = $this->db->get('interactions_products');
        foreach ($arrProductResults->result_array() as $row) {
            $arrProducts[$row['id']] = $row;
        }
        return $arrProducts;
    }

    function getAllObjectivesOfClient($clientId) {
        $arrObjectives = array();
        //This client id condition will be enabled once we enter a separate values for each client
        $this->db->where('client_id', $clientId);
        $arrObjectiveResults = $this->db->get('objectives');
        foreach ($arrObjectiveResults->result_array() as $row) {
            $arrObjectives[$row['id']] = $row;
        }
        return $arrObjectives;
    }

    function saveInteractionAttendis($kolAndCatdetail) {
// 		pr($kolAndCatdetail);
        if ($kolAndCatdetail['specialty_id'] == 0) {
            unset($kolAndCatdetail['specialty_id']);
        }
        if ($this->db->insert('interactions_attendees', $kolAndCatdetail)) {
            return true;
        } else {
            return false;
        }
    }

    function saveInteractionTopicDetail($topicDeatil) {
		
// 		if($this->db->insert('interactions_topic_mapped_data',$topicDeatil)){
        if ($this->db->insert('interactions_discussion_topic_mapped_data', $topicDeatil)) {
            return true;
        } else {
            return false;
        }
    }

    function getInteractionAttendis($id) {
        $arrAttendis = array();
        $this->db->select('interactions_attendees.*,kols.first_name,kols.middle_name,kols.last_name,specialties.specialty,interactions_attendees.status,organizations.name as org_name,organizations.status as org_status,titles.title,key_peoples.first_name as key_fn,key_peoples.middle_name as key_mn,key_peoples.last_name as key_ln,key_peoples.title as key_title');
        $this->db->join('kols', 'kols.id=interactions_attendees.kol_id', 'left');
        $this->db->join('organizations', 'organizations.id=interactions_attendees.org_id', 'left');
        $this->db->join('key_peoples', 'key_peoples.id=interactions_attendees.key_id', 'left');
        $this->db->join('specialties', 'specialties.id=interactions_attendees.specialty_id', 'left');
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->where('interaction_id', $id);
        $arrResults = $this->db->get('interactions_attendees');
        foreach ($arrResults->result_array() as $row) {
        	if($row['org_id'] != null && $row['org_id'] != '') {
        		if ($row['kol_id']!=''){
        			$row['attType'] = 'kol_type';
        		}else{
        			$row['attType'] = 'key_type';
        		}
        	}
            $arrAttendis[] = $row;
        }
        return $arrAttendis;
    }

    function getInteractionTopics($id) {
        $this->db->select('interactions_topic_mapped_data.*');
        $this->db->where('interaction_id', $id);
        $arrTopicsResult = $this->db->get('interactions_topic_mapped_data');
        foreach ($arrTopicsResult->result_array() as $row) {
            $arrTopics[] = $row;
        }
        return $arrTopics;
    }

    function deleteInteractionAttendis($interactionId) {
        $this->db->where('interaction_id', $interactionId);
        $this->db->delete('interactions_attendees');
    }

    function deleteInteractionTopicDetail($topicDeatl) {
        $this->db->where('interaction_id', $topicDeatl);
        $this->db->delete('interactions_topic_mapped_data');
    }

    function deleteInteractionUsers($interactionId) {
        $this->db->where('interaction_id', $interactionId);
        $this->db->delete('interaction_internal_users');
    }

    function getBrandsByProduct($productId) {
        $arrBrands = array();
        $this->db->where('product_id', $productId);
        $arrResults = $this->db->get('interactions_brands');
        foreach ($arrResults->result_array() as $row) {
            $arrBrands[$row['id']] = $row['name'];
        }
        return $arrBrands;
    }

    function getSpecialtyIdByKol($kolId) {
        $this->db->select('specialties.id');
        $this->db->where('kols.id', $kolId);
        $this->db->join('specialties','specialties.id = kols.specialty','left');
        $arrResult = $this->db->get('kols');
        foreach ($arrResult->result_array() as $row) {
            $speciltyId = $row['id'];
        }
        return $speciltyId;
    }

    function saveInteractionInternalUsers($users) {
        if ($this->db->insert('interaction_internal_users', $users)) {
            return true;
        } else {
            return false;
        }
    }

    function getInternalUsers($intId) {
        $users = array();
        $this->db->select('user_id');
        $this->db->where('interaction_id', $intId);
        $arrResult = $this->db->get('interaction_internal_users');
        foreach ($arrResult->result_array() as $row) {
            $users[$row['user_id']] = $row['user_id'];
        }
        return $users;
    }

    function checkNoOfKolsAssoWithInteaction($interactionId) {
        $this->db->where('interaction_id', $interactionId);
        $arrResult = $this->db->get('interactions_attendees');
        echo $arrResult->num_rows();
        return $arrResult->num_rows();
    }

    function deleteKolAssociation($interactionId, $kolId) {
        $this->db->where('interaction_id', $interactionId);
        $this->db->where('kol_id', $kolId);
        $this->db->delete('interactions_attendees');
    }

    function getInteractionsInternalUsers($intId) {
        $this->db->select('interaction_internal_users.user_id,kols.first_name,kols.middle_name,kols.last_name');
        $this->db->join('kols', 'kols.id=interaction_internal_users.user_id', 'left');
        $this->db->where('interaction_id', $intId);
        $arrResult = $this->db->get('interaction_internal_users');
        foreach ($arrResult->result_array() as $row) {
            $users[$row['user_id']] = $row;
        }
        return $users;
    }

    /*
     * To get List of Kol Names By passing Kol Name for autocomltete 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    /*function getAllKolNamesForAutocomplete($kolName) {
        $kolName = str_replace(",", " ", $kolName);
        $kolName = preg_replace('!\s+!', ' ', $kolName);
        $kolName = $this->db->escape_like_str($kolName);
        $arrKols = array();       
        $this->db->select("kols.id,first_name,middle_name,last_name,organizations.name as name,kols.status,kols.do_not_call_flag,regions.region as state,cities.city as city,kol_locations.private_practice");
        //	$this->db->select("kols.id,first_name,middle_name,last_name");
        $this->db->join('organizations', 'kols.org_id=organizations.id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id', 'left');
        //if (count(explode(' ', $kolName)) > 2) {
         //   $this->db->like("concat_ws(' ',last_name,first_name,middle_name)", $kolName);
        //}else if (count(explode(' ', $kolName)) == 1) {
        //    $this->db->like("concat_ws(' ',last_name)", $kolName);
       // } else {
       //     $this->db->like("concat_ws(' ',last_name,first_name)", $kolName);
       // }
        if (count(explode(' ', $kolName)) > 2) {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(3);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        }else if (count(explode(' ', $kolName)) == 1) {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(1);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        } else {            
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(2);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        }        
        //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
        $this->db->where('kols.customer_status', "ACTV");
        $this->db->order_by("last_name asc, first_name asc");
        $arrKolsResult = $this->db->get('kols');        
//			echo $this->db->last_query();
//			exit;
        $arrCompletedKols = array();
        $arrMyCustomers = array();
        foreach ($arrKolsResult->result_array() as $row) {
            $arrMyCustomers[$row['id']][] = str_replace('  ', ' ', $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']));
            if(!empty($row['name']))
                $arrMyCustomers[$row['id']][] = $row['name'];
            else
                $arrMyCustomers[$row['id']][] = $row['private_practice'];
            $arrMyCustomers[$row['id']][] = $row['state'];
            $arrMyCustomers[$row['id']][] = $row['city'];
            if ($row['do_not_call_flag'] == 1)
                $arrMyCustomers[$row['id']]['do_not_call_flag'] = "Do Not Call";
            else
                $arrMyCustomers[$row['id']]['do_not_call_flag'] = "";
        }
        $arrKols['kols'] = $arrCompletedKols;
        $arrKols['customers'] = $arrMyCustomers;
        return $arrKols;
    }*/
            function getAllKolNamesForAutocomplete($kolName,$restrictByRegion=0,$restrictOptInVisbility=0) {
                $userGroupName = getGroupDetails();
		$kolName = str_replace ( ",", " ", $kolName );
		$kolName = preg_replace ( '!\s+!', ' ', $kolName );
		$kolName = $this->db->escape_like_str ( $kolName );
		$client_id = $this->session->userdata('client_id');
		$arrKols = array ();
		$this->db->select ( "kols.id,kols.unique_id,first_name,middle_name,last_name,organizations.name as name,kols.status,kols.do_not_call_flag,regions.region as state,cities.city as city,kol_locations.private_practice" );
		// $this->db->select("kols.id,first_name,middle_name,last_name");
		$this->db->join ( 'organizations', 'kols.org_id=organizations.id', 'left' );
		$this->db->join ( 'regions', 'regions.regionID = kols.state_id', 'left' );
		$this->db->join ( 'cities', 'cities.cityID = kols.city_id', 'left' );
		$this->db->join ( 'kol_locations', 'kols.id = kol_locations.kol_id', 'left' );	
		if(INTERNAL_CLIENT_ID != $client_id){
			if($restrictByRegion){
				if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
				    $group_names = explode(',',  $userGroupName['group_names']);
// 				    $group_names = explode(',', $this->session->userdata('group_names'));
				    $this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
				    $this->db->where_in( 'countries.GlobalRegion', $group_names);
		    	}
		    }
		}
		if(INTERNAL_CLIENT_ID != $client_id){
    		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
    		$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$likeNameFormatOrder	= 'first_name,middle_name,last_name';
		//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
		$this->db->where('replace(concat(coalesce(kols.first_name,"")," ",coalesce(kols.middle_name,"")," ",coalesce(kols.last_name,"")),"  "," ") like "%'.$kolName.'%"', '',false);
		// $this->db->where_in('kols.status',array(COMPLETED,PRENEW));
		$this->db->where ( 'kols.customer_status', "ACTV" );
		if(KOL_CONSENT && $restrictOptInVisbility==1){
		    $this->db->where('(kols.opt_in_out_status is NULL OR kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$nameFormat = $this->session->userdata('name_order');
        if ($nameFormat == 1 || $nameFormat == 3)
            $this->db->order_by("first_name",'asc');
        else if ($nameFormat == 2)
            $this->db->order_by("last_name",'asc');
		$arrKolsResult = $this->db->get ( 'kols' );
		// echo $this->db->last_query();
		// exit;
		$arrCompletedKols = array ();
		$arrMyCustomers = array ();
		foreach ( $arrKolsResult->result_array () as $row ) {
			$arrMyCustomers [$row ['unique_id']] [] = str_replace ( '  ', ' ', $this->common_helpers->get_name_format ( $row ['first_name'], $row ['middle_name'], $row ['last_name'] ) );
			
			if (! empty ( $row ['name'] ))
				$arrMyCustomers [$row ['unique_id']] [] = $row ['name'];
			else
				$arrMyCustomers [$row ['unique_id']] [] = $row ['private_practice'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['state'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['city'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['id'];
			if ($row ['do_not_call_flag'] == 1)
				$arrMyCustomers [$row ['unique_id']] ['do_not_call_flag'] = "Do Not Call";
			else
				$arrMyCustomers [$row ['unique_id']] ['do_not_call_flag'] = "";
		}
		$arrKols ['kols'] = $arrCompletedKols;
		$arrKols ['customers'] = $arrMyCustomers;
		return $arrKols;
    }

    function exprtInteractionDeatils($clientId, $kolId, $userId, $startDate, $endDate, $limit = null, $startFrom = null, $interactionIds, $where) {
        $arrInteractionDetails = array();
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        if ($kolId != null && $kolId != -1) {
            if ($where['interaction_for'] == 'org')
                $this->db->where('interactions_attendees.org_id', $kolId);
            else
                $this->db->where('interactions_attendees.kol_id', $kolId);
        }
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id', 'left');

        $this->db->select("interactions.*,interactions_modes.name as mode_name, interaction_grouping.name as grouping_name, interaction_location_types.name as interaction_location_type_name");
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
        $this->db->join('interaction_grouping', 'interactions.grouping = interaction_grouping.id', 'left');


        $this->db->join('interaction_location_types', 'interaction_location_types.id = interactions.location_category', 'left');

        $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
        $this->db->join('products', 'interactions_discussion_topic_mapped_data.product_id = products.id', 'left');
        $this->db->join('interaction_types', 'interactions_discussion_topic_mapped_data.interaction_type = interaction_types.id', 'left');
        $this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
        $this->db->join('interaction_sub_topics', 'interactions_discussion_topic_mapped_data.sub_topic_id = interaction_sub_topics.id', 'left');

        $this->db->join('interaction_mirf', 'interaction_mirf.interaction_id=interactions.id', 'left');
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');

        $this->db->where("client_users.id IS NOT NULL");
        $this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)");

        if (isset($where['kol_name'])) {
            $this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%' or organizations.name LIKE '%" . $where['kol_name'] . "%')");
        }

        if (isset($where['date'])) {
            $this->db->like("interactions.date", $where['date']);
        }

        if (isset($where['recorded_by'])) {
            $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
        }

        if (isset($where['mode_name'])) {
            $this->db->like("interactions_modes.name", $where['mode_name']);
        }

        if (isset($where['objective_name'])) {
            $this->db->like("interaction_types.name", $where['objective_name']);
        }

        if (isset($where['product_name'])) {
            $this->db->like("products.name", $where['product_name']);
        }

        if (isset($where['quality_interaction'])) {
            if ($where['quality_interaction'][0] == "N" || $where['quality_interaction'][0] == "n")
                $this->db->like("interactions.quality_interaction", 0);
            else if ($where['quality_interaction'][0] == "Y" || $where['quality_interaction'][0] == "y")
                $this->db->like("interactions.quality_interaction", 1);
        }

        if (isset($where['generic_id'])) {
            $this->db->like("interactions.generic_id", $where['generic_id']);
        }

        if (isset($where['mirf'])) {
            if ($where['mirf'][0] == "A" || $where['mirf'][0] == "a")
                $this->db->where("interaction_mirf.id IS NULL");
            else if ($where['mirf'][0] == "E" || $where['mirf'][0] == "e" || $where['mirf'][0] == "V" || $where['mirf'][0] == "v")
                $this->db->where("interaction_mirf.id IS NOT NULL");
        }

        if (isset($where['sidx']) && isset($where['sord'])) {
            switch ($where['sidx']) {
                case 'kol_name' : $this->db->order_by("kols.first_name", $where['sord']);
                    break;
                case 'date' :$this->db->order_by("interactions.date", $where['sord']);
                    break;
                case 'recorded_by' :$this->db->order_by("client_users.first_name", $where['sord']);
                    break;
                case 'mode_name' :$this->db->order_by("interactions_modes.name", $where['sord']);
                    break;
                case 'objective_name' :$this->db->order_by("interaction_types.name", $where['sord']);
                    break;
                case 'product_name' :$this->db->order_by("products.name", $where['sord']);
                    break;
                case 'quality_interaction' :$this->db->order_by("interactions.quality_interaction", $where['sord']);
                    break;
                case 'mirf' :$this->db->order_by("interaction_mirf.id", $where['sord']);
                    break;
            }
            //$this->db->order_by($sidx,$sord);
        } else {

            $this->db->order_by('interactions.date', 'desc');
        }


        //$this->db->where_in('interactions.id',$interactionIds);
        if ($interactionIds != '')
            $this->db->where_in('interactions.generic_id', $interactionIds);
        //$this->db->order_by('date','desc');
        $this->db->group_by("interactions.id");
        $interactionDetailsResult = $this->db->get('interactions');
        //pr($this->db->last_query());exit;
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id'], $kolId);
            $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id'], $kolId);
            $row['kol_name'] = trim(implode(', ', $arrInteractionAttendees['kol_names']), " ,");
            $row['area_name'] = implode(', ', $arrInteractionAttendees['specialties']);
            $row['category_name'] = implode(', ', $arrInteractionAttendees['categories']);
            $row['role_name'] = implode(', ', $arrInteractionAttendees['roles']);
            $row['topic_name'] = trim(implode(', ', $arrInteractionAboutTopics['topic_names']), " ,");
            $row['brand_name'] = implode(', ', $arrInteractionAboutTopics['brand_names']);
            $row['objective_name'] = trim(implode(', ', $arrInteractionAboutTopics['objective_names']), " ,");
            $row['product_name'] = trim(implode(', ', $arrInteractionAboutTopics['product_names']), " ,");
            $row['sub_topic_name'] = trim(implode(', ', $arrInteractionAboutTopics['sub_topic_names']), " ,");
            $row['kol_name_for_export'] = implode(', ', $arrInteractionAttendees['kol_name_for_export']);
            $row['kol_id'] = $kolId;
            $arrInteractionDetails[] = $row;
            //	pr($row);
        }
//                
//                pr($arrInteractionDetails);
//                exit();
        //echo $this->db->last_query();
        //	pr($arrInteractionDetails);
        return $arrInteractionDetails;
    }

    function getAllGroupings($clientId,$orgType) {
        $arrModes = array();
        //	$this->db->where('client_id',$clientId);
        if(!empty($orgType)){
            $this->db->where('org_active',1);
        }
        $arrModeResults = $this->db->get('interaction_grouping');
        foreach ($arrModeResults->result_array() as $row) {
            $arrModes[] = $row;
        }
        return $arrModes;
    }

    function getAllTypesOfClient() {
        $arrModes = array();
        $this->db->where('status', 1);
        $arrModeResults = $this->db->get('interaction_types');
        foreach ($arrModeResults->result_array() as $row) {
            $arrModes[$row['id']] = $row;
        }
        return $arrModes;
    }

    function getProductByType($typeId) {
        $arrProducts = array();
        //$this->db->where('type_id',$typeId);
        $arrResults = $this->db->get('interactions_products');
        foreach ($arrResults->result_array() as $row) {
            $arrProducts[$row['id']] = $row['name'];
        }
        return $arrProducts;
    }

    function getTpicByProduct($groupId, $productId, $typeId) {
        $arrTopics = array();
        $this->db->join('interaction_topic_mapping', 'interaction_topic_mapping.topic_id=interactions_topics.id', 'left');
        $this->db->where('interaction_topic_mapping.interaction_type_id', $typeId);
        $this->db->where('interaction_topic_mapping.grouping_id', $groupId);
        //$this->db->where('interaction_topic_mapping.product_id',$productId);
        $arrResults = $this->db->get('interactions_topics');
        foreach ($arrResults->result_array() as $row) {
            $arrTopics[$row['topic_id']] = $row['name'];
        }
        return $arrTopics;
    }

    function getModeNumericReportData($arrFilters, $type) {
        $userGroupName = getGroupDetails();
    	$userId = $this->session->userdata('user_id');
    	$client_id = $this->session->userdata('client_id');
    	$userId = $this->session->userdata('user_id');
    	$clientId	= $client_id;
        $sd = $arrFilters['sd'];
        $ed = $arrFilters['ed'];
        if(is_array($arrFilters['sd'])){
            $sd = $arrFilters['sd'][0];
            $ed = $arrFilters['ed'][0];
        }
//            pr($arrFilters);
//            exit();
        $currentYear = date("Y");
        $arrModeResults = array();
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        
        
        $select = array('COUNT(DISTINCT CASE WHEN DATE BETWEEN  "' . $sd . '" AND "' . $ed . '" THEN interactions.id  END) AS gp',
            'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "1-' . $currentYear . '","2-' . $currentYear . '","3-' . $currentYear . '" ) THEN interactions.id END) AS q1',
            'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "4-' . $currentYear . '","5-' . $currentYear . '","6-' . $currentYear . '" ) THEN interactions.id END) AS q2',
            'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "7-' . $currentYear . '","8-' . $currentYear . '","9-' . $currentYear . '" ) THEN interactions.id END) AS q3',
            'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "10-' . $currentYear . '","11-' . $currentYear . '","12-' . $currentYear . '" ) THEN interactions.id END) AS q4',
            'COUNT(DISTINCT CASE WHEN DATE BETWEEN "' . $currentYear . '-01-01" AND CURDATE() THEN interactions.id END) AS ytd'
        );

        //This approach has a disadvantage as it is intrudusing the extra "'" before and after the our "'" or '"' characteres						
        /* $select = "interactions_modes.name";
          $select .=", COUNT(CASE WHEN DATE BETWEEN  '2012-09-03'AND '2012-09-03' THEN interactions.id  END) AS given_period";
          $select .=", COUNT(CASE WHEN CONCAT(MONTH(DATE), '-', YEAR(DATE)) IN ( '1-2012',2-2012,3-2012 ) THEN interactions.id END) AS Q1";
          $select .=", COUNT(CASE WHEN CONCAT(MONTH(DATE), '-', YEAR(DATE)) IN ( '4-2012',5-2012,6-2012 ) THEN interactions.id END) AS Q2";
          $select .=", COUNT(CASE WHEN CONCAT(MONTH(DATE), '-', YEAR(DATE)) IN ( '7-2012',8-2012,9-2012 ) THEN interactions.id END) AS Q3";
          $select .=", COUNT(CASE WHEN CONCAT(MONTH(DATE), '-', YEAR(DATE)) IN ( '10-2012',11-2012,12-2012 ) THEN interactions.id END) AS Q4";
          $select .=", COUNT(CASE WHEN DATE BETWEEN "2012-01-01" AND CURDATE() THEN interactions.id END) AS YTD"; */


        if (!empty(array_filter($arrFilters['type'])) || !empty(array_filter($arrFilters['product'])) || !empty(array_filter($arrFilters['topic'])) || $type == 'type' || $type == 'product' || $type == 'topic' || $type == 'subtopic')
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
        if (!empty(array_filter($arrFilters['mode'])))
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        if (!empty(array_filter($arrFilters['grouping'])))
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        if (!empty(array_filter($arrFilters['type'])))
            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['type']);
        if (!empty(array_filter($arrFilters['product'])))
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product']);
        if (!empty(array_filter($arrFilters['topic'])))
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic']);
        if ($arrFilters['subtopic'] != '')
            $this->db->where('interactions_discussion_topic_mapped_data.sub_topic_id', $arrFilters['subtopic']);
        
        if ($type == 'mode') {
            $select[] = 'interactions_modes.name as name';
            $select[] = 'interactions_modes.id as id';
            $this->db->join('interactions_modes', 'interactions_modes.id = interactions.mode', 'left');
            $this->db->where('interactions_modes.name !=', 'NULL');
            $this->db->group_by('interactions.mode WITH ROLLUP');
        }
        if ($type == 'grouping') {
            $select[] = 'interaction_grouping.name as name';
            $select[] = 'interaction_grouping.id as id';
            $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
            $this->db->where('interaction_grouping.name !=', 'NULL');
            $this->db->group_by('interactions.grouping WITH ROLLUP');
        }
        if ($type == 'type') {
            $select[] = 'interaction_types.name as name';
            $select[] = 'interaction_types.id as id';
            $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
            $this->db->where('interaction_types.name !=', 'NULL');
            $this->db->group_by('interactions_discussion_topic_mapped_data.interaction_type WITH ROLLUP');
        }
        if ($type == 'product') {
            $select[] = 'products.name as name';
            $select[] = 'products.id as id';
            $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
            $this->db->where('products.name !=', 'NULL');
            $this->db->group_by('interactions_discussion_topic_mapped_data.product_id WITH ROLLUP');
        }
        if ($type == 'topic') {
            $select[] = 'interaction_topics.name as name';
            $select[] = 'interaction_topics.id as id';
            $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
            $this->db->where('interaction_topics.name !=', 'NULL');
            $this->db->group_by('interactions_discussion_topic_mapped_data.topic_id WITH ROLLUP');
        }
        
        $kolId = $arrFilters['kol_id'];
        if(is_array($arrFilters['kol_id'])){
        	$kolId = $arrFilters['kol_id'][0];
        }
    	if ($kolId != null && $kolId != -1 && $kolId != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $kolId);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $kolId);
        	}
        }
        
        if ($kolId == null || $kolId == -1 || $kolId == 0 || $kolId =='') {
	        if ($client_id != INTERNAL_CLIENT_ID){
	        	if($this->session->userdata('user_role_id')==ROLE_MANAGER){
	        	    $group_names = explode(',',  $userGroupName['group_names']);
// 	        		$group_names = explode(',', $this->session->userdata('group_names'));
	        		$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
	        		$this->db->where_in ( 'countries.GlobalRegion', $group_names);
	        	}
	        }
        }
//         if (!empty(array_filter($arrFilters['user_id']))) {
//         	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        
        //             echo $client_id
        if($client_id != INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $client_id);
        }
        
        if ($isAttendiesJoined == false) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        }
        $this->db->select($select);
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->where("client_users.id IS NOT NULL");
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
        $results = $this->db->get('interactions');

//     		pr($this->db->last_query());exit;
        foreach ($results->result_array() as $row) {
            $arrModeResults[] = $row;
        }
        return $arrModeResults;
    }

    function listInteractionsByDrilldown($type, $id, $seg, $arrFilters,$ipad=false) {
//     	pr($arrFilters);exit;
        $userGroupName = getGroupDetails();
    	$userId = $this->session->userdata('user_id');
        $currentYear = date("Y");
        $arrInteractions = array();

        $client_id = $this->session->userdata('client_id');

        $this->db->select("interactions.*,interactions_modes.name as mode_name");
        if ($arrFilters['interaction_for'][0] == 'org'){
        	
        }
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');

        if ($arrFilters['type'] != 'null' || $arrFilters['product'] != 'null' || $arrFilters['topic'] != 'null' || $type == 'type' || $type == 'product' || $type == 'topic')
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');

        if ($type == 'mode') {
            $this->db->where('interactions_modes.name !=', 'NULL');
            if ($id != 0) {
                $this->db->where('interactions_modes.id', $id);
            }
        }
        if ($type == 'grouping') {
            $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
            $this->db->where('interaction_grouping.name !=', 'NULL');
            if ($id != 0) {
                $this->db->where('interaction_grouping.id', $id);
            }
        }
        if ($type == 'type') {
            $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
            $this->db->where('interaction_types.name !=', 'NULL');
            if ($id != 0) {
                $this->db->where('interaction_types.id', $id);
            }
        }
        if ($type == 'product') {
            $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
            $this->db->where('products.name !=', 'NULL');
            if ($id != 0) {
                $this->db->where('products.id', $id);
            }
        }
        if ($type == 'topic') {
            $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
            $this->db->where('interaction_topics.name !=', 'NULL');
            if ($id != 0) {
                $this->db->where('interaction_topics.id', $id);
            }
        }

        if ($seg == 'gp') {
            $this->db->where('DATE BETWEEN  "' . $arrFilters['sd'][0] . '" AND "' . $arrFilters['ed'][0] . '"');
        }
        if ($seg == 'q1') {
            $this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "1-' . $currentYear . '","2-' . $currentYear . '","3-' . $currentYear . '" )');
        }
        if ($seg == 'q2') {
            $this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "4-' . $currentYear . '","5-' . $currentYear . '","6-' . $currentYear . '" )');
        }
        if ($seg == 'q3') {
            $this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "7-' . $currentYear . '","8-' . $currentYear . '","9-' . $currentYear . '" )');
        }
        if ($seg == 'q4') {
            $this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "10-' . $currentYear . '","11-' . $currentYear . '","12-' . $currentYear . '" )');
        }
        if ($seg == 'ytd') {
            $this->db->where('DATE BETWEEN "' . $currentYear . '-01-01" AND CURDATE()');
        }

        if (!empty($arrFilters['mode'])) {
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        }
        if (!empty($arrFilters['grouping'])) {
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        }
        if (!empty($arrFilters['type'])) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['type']);
        }
        if (!empty($arrFilters['product'])) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product']);
        }
        if (!empty($arrFilters['topic'])) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic']);
        }
        
        if ($arrFilters['kol_id'][0] != null && $arrFilters['kol_id'][0] != -1 && $arrFilters['kol_id'][0] != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for'][0]) && ($arrFilters['interaction_for'][0] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id'][0]);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id'][0]);
        	}
        }
        if ($arrFilters['kol_id'][0] == null || $arrFilters['kol_id'][0] == -1 || $arrFilters['kol_id'][0] == 0) {
        	if ($client_id != INTERNAL_CLIENT_ID){
        		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        		    $group_names = explode(',',  $userGroupName['group_names']);
//         			$group_names = explode(',', $this->session->userdata('group_names'));
        			$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        			$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        		}
        	}
        }
//         if (!empty($arrFilters['user_id'])) {
//         	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        //             echo $client_id
        
        if($client_id != INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $client_id);
        }
        if ($isAttendiesJoined == false) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        }
        $this->db->select($select);
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->where("client_users.id IS NOT NULL");
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
        
        $this->db->group_by('interactions.id');
        $this->db->order_by('interactions.date','desc');
        $results = $this->db->get('interactions');
        foreach ($results->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id'],null,null,$ipad);
	            if(!empty($arrInteractionAttendees['kol_names'][0])){
	                $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id']);
	                //$row['kol_name']			= implode(',',$arrInteractionAttendees['kol_names']);
	                if(isset($arrInteractionAttendees['org_id'])){
	                	if (IS_IPAD_REQUEST || $ipad){
	                		$row['kol_name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/organizations/view/' . $arrInteractionAttendees['org_id'] . '">' . $arrInteractionAttendees['org_name']. '</a>';
	                	}else{
	                		$row['kol_name'] =  '<a href="' . base_url() . 'organizations/view/' . $arrInteractionAttendees['org_id'] . '">' . $arrInteractionAttendees['org_name']. '</a>';
	                	}
	                }else{
	                	$row['kol_name'] = $arrInteractionAttendees['kol_names'][0];
	                }
	                $row['area_name'] = implode(',', $arrInteractionAttendees['specialties']);
	                $row['category_name'] = implode(',', $arrInteractionAttendees['categories']);
	                $row['role_name'] = implode(',', $arrInteractionAttendees['roles']);
	                $row['topic_name'] = implode(',', $arrInteractionAboutTopics['topic_names']);
	                //$row['objective_name']		= implode(',',$arrInteractionAboutTopics['objective_names']);
	                $row['objective_name'] = $arrInteractionAboutTopics['objective_names'][0];
	                //$row['product_name']		= implode(',',$arrInteractionAboutTopics['product_names']);
	                $row['product_name'] = $arrInteractionAboutTopics['product_names'][0];
	                $row['kol_name_for_export'] = implode(',', $arrInteractionAttendees['kol_name_for_export']);
	                $arrInteractions[] = $row;
	            }
        }
       $sort = array();
        foreach($arrInteractions as $k=>$v) {
            $sort['date'][$k] = $v['date'];
            $sort['kol_name'][$k] = $v['kol_name'];
        }
        $sorted = array_multisort(strip_tags($sort['kol_name']), SORT_ASC,$sort['date'], SORT_DESC,$arrInteractions);
        return $arrInteractions;
    }

    function getProductById($id) {
        $value = '';
        $this->db->select('name');
        $this->db->where('id', $id);
        $results = $this->db->get('products');
        if ($results->num_rows() > 0) {
            $row = $results->row_array();
            $value = $row['name'];
        }
        return $value;
    }

    function getTopicById($id) {
        $value = '';
        $this->db->select('name');
        $this->db->where('id', $id);
        $results = $this->db->get('interaction_topics');
        if ($results->num_rows() > 0) {
            $row = $results->row_array();
            $value = $row['name'];
        }
        return $value;
    }

    function getAllKolNamesForAutocompleteRefineBy($kolName,$restrictOptInVisbility=0) {
        $kolName = str_replace(",", " ", $kolName);
        $kolName = preg_replace('!\s+!', ' ', $kolName);
        $kolName = $this->db->escape_like_str($kolName);
        $arrKols = array();
        $this->db->select("kols.id,first_name,middle_name,last_name,organizations.name as name,kols.profile_type,kols.profile_image");
        //	$this->db->select("kols.id,first_name,middle_name,last_name");
        $this->db->join('organizations', 'kols.org_id=organizations.id', 'left');
        //	$this->db->like("concat_ws(' ',first_name,middle_name,last_name)",$kolName);
        /*if (count(explode(' ', $kolName)) > 2) {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(3);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        }
        if (count(explode(' ', $kolName)) == 1) {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(1);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        } else {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(2);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        }*/
		$likeNameFormatOrder	= 'first_name,middle_name,last_name';
		//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
        //$this->db->where('kols.status',COMPLETED);
		$this->db->where('replace(concat(coalesce(first_name,"")," ",coalesce(middle_name,"")," ",coalesce(last_name,"")),"  "," ") like "%'.$kolName.'%"', '',false);
        $this->db->where('kols.customer_status', "ACTV");
        if(KOL_CONSENT && $restrictOptInVisbility==1){
            $this->db->where('(kols.opt_in_out_status is NULL OR kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
        }
        $this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
        $nameFormat = $this->session->userdata('name_order');
        if ($nameFormat == 1 || $nameFormat == 3)
            $this->db->order_by("first_name",'asc');
        else if ($nameFormat == 2)
            $this->db->order_by("last_name",'asc');
        
		$client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
		}
            
        $arrKolsResult = $this->db->get('kols');
       // echo $this->db->last_query();
        foreach ($arrKolsResult->result_array() as $row) {
        	$arrKOL	= array();
//				$arrKols[$row['id']][]=str_replace('  ',' ',$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER]);
			$arrKOL[] = str_replace('  ', ' ', $this->common_helpers->get_name_format($row[FIRST_ORDER], $row[SECOND_ORDER], $row[THIRD_ORDER]));
			$arrKOL[] = $row['name'];
			$arrKOL[] = $row['profile_type'];
			$arrKOL[] = $row['id'];
            $image = "images/kol_images/resized/".$row['profile_image'];
            if(file_exists($image))
            	$arrKOL[] = $row['profile_image'];
            
			$arrKols[]	= $arrKOL;
		}
		return $arrKols;
    }

function interacionByTopic($arrFilters) {
    	$client_id = $this->session->userdata('client_id');
    	$userId = $this->session->userdata('user_id');
    	$userGroupName = getGroupDetails();
        $this->db->select('interaction_topics.name,COUNT(DISTINCT interactions_discussion_topic_mapped_data.interaction_id) as count');
        $this->db->join('interaction_topics', 'interaction_topics.id=interactions_discussion_topic_mapped_data.topic_id', 'inner');
        $this->db->join('interactions', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');

        if ($arrFilters['start_date'] != '') {

            $this->db->where("((interactions.date between '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
        }
        
        if (!empty(array_filter($arrFilters['mode']))) {
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        }

        if (!empty(array_filter($arrFilters['grouping']))) {
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        }
        if (!empty(array_filter($arrFilters['topic_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
        }

        if (!empty(array_filter($arrFilters['objective_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
        }

        if (!empty(array_filter($arrFilters['product_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
        }
        if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
        	}
        }
        if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
        	if ($client_id != INTERNAL_CLIENT_ID){
        		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        		    $group_names = explode(',',  $userGroupName['group_names']);
//         			$group_names = explode(',', $this->session->userdata('group_names'));
        			$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        			$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        		}
        	}
        }
	
		if ($isAttendiesJoined == false) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
            $isAttendiesJoined = true;
        }
// 		if (!empty(array_filter($arrFilters['user_id']))) {
//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        if($client_id !== INTERNAL_CLIENT_ID){
       	 $this->db->where('interactions.client_id', $client_id);
        }
		$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        $this->db->group_by('topic_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
       
        $result = $this->db->get('interactions_discussion_topic_mapped_data');
//         print $this->db->last_query();
//         exit;
        
        foreach ($result->result_array() as $row) {
            $arrResult[] = $row;
        }

        return $arrResult;
    }

    function interacionByChannel($arrFilters) {
    	$client_id = $this->session->userdata('client_id');
    	$userId = $this->session->userdata('user_id');
    	$userGroupName = getGroupDetails();
        $topicJoin = false;
        $this->db->select('interactions_modes.name,COUNT(DISTINCT interactions.id) AS count');
        $this->db->join('interactions_modes', 'interactions_modes.id=interactions.mode', 'left');

        if ($arrFilters['start_date'] != '') {

            $this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
        }
        if (!empty(array_filter($arrFilters['mode']))) {
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        }

        if (!empty(array_filter($arrFilters['grouping']))) {
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        }

        if (!empty(array_filter($arrFilters['topic_id']))) {
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
            $topicJoin = true;
        }

        if (!empty(array_filter($arrFilters['objective_id']))) {
            if ($topicJoin == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
                $topicJoin = true;
            }

            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
        }

        if (!empty(array_filter($arrFilters['product_id']))) {
            if ($topicJoin == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
                $topicJoin = true;
            }
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
        }
		
        if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
        	}
        }
        if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
        	if ($client_id != INTERNAL_CLIENT_ID){
        		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        		    $group_names = explode(',',  $userGroupName['group_names']);
//         			$group_names = explode(',', $this->session->userdata('group_names'));
        			$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        			$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        		}
        	}
        }
//         if (!empty(array_filter($arrFilters['user_id']))) {
//         	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        if ($isAttendiesJoined == false) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        }
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $client_id);
        }
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->where("client_users.id IS NOT NULL");
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        $this->db->group_by('mode');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
        $result = $this->db->get('interactions');
//         pr($this->db->last_query());exit;
        foreach ($result->result_array() as $row) {
            $arrResult[] = $row;
        }
        return $arrResult;
    }

    function interactionByMonth($arrFilters) {
    	$client_id = $this->session->userdata('client_id');
    	$userId = $this->session->userdata('user_id');
    	$userGroupName = getGroupDetails();
        $topicJoin = false;
        if (!isset($arrFilters['get_count']))
            $this->db->select('products.name,COUNT(DISTINCT interactions.id) AS count,MONTH(DATE) as month,YEAR(DATE) AS year, CONCAT(MONTH(DATE),"",YEAR(DATE)) AS month_year', false);
        else
            $this->db->select("COUNT(DISTINCT interactions.id) AS COUNT");
        $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
        $this->db->join('products', 'interactions_discussion_topic_mapped_data.product_id=products.id', 'left');
        if ($arrFilters['start_date'] != '') {

            $this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
        }

        if (!empty(array_filter($arrFilters['mode']))) {
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        }

        if (!empty(array_filter($arrFilters['grouping']))) {
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        }
        if (!empty(array_filter($arrFilters['topic_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
        }

        if (!empty(array_filter($arrFilters['objective_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
        }

        if (!empty(array_filter($arrFilters['product_id']))) {
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
        }
		
        if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
        	}
        }
        if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
        	if ($client_id != INTERNAL_CLIENT_ID){
        		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        		    $group_names = explode(',',  $userGroupName['group_names']);
//         			$group_names = explode(',', $this->session->userdata('group_names'));
        			$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        			$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        		}
        	}
        }
//         if (!empty(array_filter($arrFilters['user_id']))) {
//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $arrFilters['client_id']);
        }
        if (!isset($arrFilters['get_count'])) {
            $this->db->group_by('interactions_discussion_topic_mapped_data.product_id,MONTH(DATE),YEAR(DATE)');
            $this->db->order_by('YEAR(DATE),MONTH(DATE)');
        }
        if ($isAttendiesJoined == false) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        }
        
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->where("client_users.id IS NOT NULL");
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
        $result = $this->db->get('interactions');
//         echo $this->db->last_query();exit;
        foreach ($result->result_array() as $row) {
            $arr1[] = $row;
            //$arrYear[]=$row['month'];
            $arrYear[] = $row['month_year'];
        }
        $arrResult[0] = $arr1;
        $arrResult[1] = $arrYear;
        return $arrResult;
    }

    function interacionByEmployee($arrFilters) {
    	$client_id = $this->session->userdata('client_id');
    	$userId = $this->session->userdata('user_id');
    	$userGroupName = getGroupDetails();
        $topicJoin = false;
        $this->db->select('concat(client_users.first_name," ",client_users.last_name) AS username,COUNT(DISTINCT interactions.id) AS count', false);
        $this->db->join('interactions_modes', 'interactions_modes.id=interactions.mode', 'left');
        $this->db->join('client_users', 'interactions.created_by=client_users.id', 'left');

        if ($arrFilters['start_date'] != '') {

            $this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
        }
        if (!empty(array_filter($arrFilters['mode']))) {
            $this->db->where_in('interactions.mode', $arrFilters['mode']);
        }

        if (!empty(array_filter($arrFilters['grouping']))) {
            $this->db->where_in('interactions.grouping', $arrFilters['grouping']);
        }

        if (!empty(array_filter($arrFilters['topic_id']))) {
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
            $topicJoin = true;
        }

        if (!empty(array_filter($arrFilters['objective_id']))) {
            if ($topicJoin == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
                $topicJoin = true;
            }

            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
        }

        if (!empty(array_filter($arrFilters['product_id']))) {
            if ($topicJoin == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
                $topicJoin = true;
            }
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
        }
		
        if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        	if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
        		$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
        	}else{
        		$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
        	}
        }
        if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
        	if ($client_id != INTERNAL_CLIENT_ID){
        		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        		    $group_names = explode(',',  $userGroupName['group_names']);
//         			$group_names = explode(',', $this->session->userdata('group_names'));
        			$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        			$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        		}
        	}
        }
//         if (!empty(array_filter($arrFilters['user_id']))) {
//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
//         }
        
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if (!empty(array_filter($arrFilters['user_id']))) {
        	$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $arrFilters['client_id']);
        }
        $this->db->group_by('interactions.created_by');
        
        if ($isAttendiesJoined == false) {
        	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        	$isAttendiesJoined = true;
        }
        
        $this->db->where("client_users.id IS NOT NULL");
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = interactions_attendees.kol_id', 'left');
        }
        $result = $this->db->get('interactions');
//         echo $this->db->last_query();
        foreach ($result->result_array() as $row) {
            $arrResult[] = $row;
        }
        return $arrResult;
    }

    /**
     * Retrives the all the Interactions of the Client
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getInteractionsOfOrgKols($clientId, $orgId, $arrFilters, $startFrom, $limit) {
        //pr($arrFilters);
        $arrInteractionDetails = array();
//		if($kolId!=null && $kolId!=-1)
//			$this->db->where('interactions.kol_id',$kolId);
        if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1) {
            //$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id','left');
            $this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
        }
        if ($arrFilters['user_id'] != 0)
            $this->db->where('interactions.created_by', $arrFilters['user_id']);
        if ($clientId != 0)
            $this->db->where('interactions.client_id', $clientId);
        $this->db->select("interactions.*,interactions_modes.name as mode_name,client_users.first_name,client_users.last_name,cities.city,regions.region");
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id', 'left');
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');

        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('cities', 'cities.CityId = interactions.city_id', 'left');
        $this->db->join('regions', 'regions.regionId = interactions.state_id', 'left');

        if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
            $this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
        } else if ($startDate != null) {
            $this->db->like('interactions.date', $startDate);
        }
        $isJoined = false;
        if ($arrFilters['objective_id'] != '' && $arrFilters['objective_id'] != 0) {
            $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id=interactions.id', 'left');
            $this->db->where('objective_id', $arrFilters['objective_id']);
            $isJoined = true;
        }

        if ($arrFilters['product_id'] != '' && $arrFilters['product_id'] != 0) {
            if ($isJoined == false) {
                $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id=interactions.id', 'left');
                $isJoined = true;
            }
            $this->db->where('product_id', $arrFilters['product_id']);
        }

        if ($arrFilters['topic_id'] != '' && $arrFilters['topic_id'] != 0) {
            if ($isJoined == false) {
                $this->db->join('interactions_topic_mapped_data', 'interactions_topic_mapped_data.interaction_id=interactions.id', 'left');
                $isJoined = true;
            }
            $this->db->where('topic_id', $arrFilters['topic_id']);
        }

        if ($arrFilters['mode'] != '' && $arrFilters['mode'] != 0) {
            $this->db->where('mode', $arrFilters['mode']);
        }

        if ($arrFilters['grouping'] != '' && $arrFilters['grouping'] != 0) {
            $this->db->where('grouping', $arrFilters['grouping']);
        }
        $this->db->where('org_id', $orgId);
        /* if($startDate!=0 && $endDate!=0){
          $wherBetween="(YEAR(interactions.date) BETWEEN '$startDate' AND '$endDate' OR YEAR(interactions.date)='0')";
          $this->db->where($wherBetween);
          } */
        $this->db->order_by('id', 'desc');
        if ($limit != 'all')
            $this->db->limit($limit, $startFrom);

        $this->db->group_by('interactions.id');
        $interactionDetailsResult = $this->db->get('interactions');
        //echo $this->db->last_query();
        if ($limit != 'all') {
            foreach ($interactionDetailsResult->result_array() as $row) {
                $arrInteractionAttendees = $this->getInteractionOrgAttendees($row['id'], null, $orgId);
                $arrInteractionAboutTopics = $this->getInteractionOrgAboutTopics($row['id'], $kolId);

                $row['kol_name'] = implode(',', $arrInteractionAttendees['kol_names']);
                $row['area_name'] = implode(',', $arrInteractionAttendees['specialties']);
                $row['category_name'] = implode(',', $arrInteractionAttendees['categories']);
                $row['role_name'] = implode(',', $arrInteractionAttendees['roles']);
                $row['topic_name'] = $arrInteractionAboutTopics['topic_names'];
                $row['objective_name'] = $arrInteractionAboutTopics['objective_names'];
                $row['product_name'] = $arrInteractionAboutTopics['product_names'];
                $row['kol_name_for_export'] = implode(',', $arrInteractionAttendees['kol_name_for_export']);
                $row['kol_id'] = $kolId;
                $arrInteractionDetails[] = $row;
                //	pr($row);
            }
            return $arrInteractionDetails;
        } else {

            return $interactionDetailsResult->num_rows();
        }
        //echo $this->db->last_query();
        //pr($arrInteractionDetails);
    }

    function getInteractionOrgAttendees($interactionID, $kolId = null, $orgId) {
        $arrInteractionDetails = array();
        $arrInteractionDetails['kol_names'] = array();
        $arrInteractionDetails['specialties'] = array();
        $arrInteractionDetails['categories'] = array();
        $arrInteractionDetails['roles'] = array();
        $arrInteractionDetails['kol_name_for_export'] = array();
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $this->db->select("kols.id,kols.salutation,kols.status,kols.last_name,kols.middle_name,kols.first_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty,interactions_attendees.note");
        $this->db->where('interaction_id', $interactionID);
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id', 'left');
        $this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
        $this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id', 'left');
        $this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id', 'left');
        //	$this->db->where('org_id',$orgId);
        if ($kolId != null && $kolId != -1)
            $this->db->where('interactions_attendees.kol_id', $kolId);
        $this->db->order_by('interactions_attendees.kol_id');
        $interactionDetailsResult = $this->db->get('interactions_attendees');
        foreach ($interactionDetailsResult->result_array() as $row) {
            $microview = '';
            if ($row['status'] == PRENEW || $row['status'] == COMPLETED) {
                $arrInteractionDetails['kol_names'][] = '<a target="_NEW" onclick="test(event)" href="' . base_url() . 'kols/view/' . $row['id'] . '">' . $arrSalutations[$row['salutation']] . " " . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'] . '</a>';
                $microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
            } elseif ($row['status'] == New1 || $row['status'] == APPROVED) {
                $arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . 'requested_kols/show_client_requested_kols">' . $arrSalutations[$row['salutation']] . " " . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'] . '</a>';
            } elseif ($row['status'] == 'rejected') {
                $arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . 'requested_kols/show_non_profiled_kols">' . $arrSalutations[$row['salutation']] . " " . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'] . '</a>';
            } else {
                $arrInteractionDetails['kol_names'][] = $arrSalutations[$row['salutation']] . " " . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
            }
            $arrInteractionDetails['microview'][] = $microview;
            $arrInteractionDetails['specialties'][] = $row['specialty'];
            $arrInteractionDetails['categories'][] = $row['category_name'];
            $arrInteractionDetails['roles'][] = $row['role_name'];
            $arrInteractionDetails['note'][] = $row['note'];
            $arrInteractionDetails['kol_name_for_export'][] = $arrSalutations[$row['salutation']] . " " . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
        }
        return $arrInteractionDetails;
    }

    function getInteractionOrgAboutTopics($interactionID, $kolId = null) {
        $arrInteractionDetails = array();
        $this->db->select("interactions_topics.name as topic_name,interactions_products.name as product_name,interaction_types.name as objective_name");
        $this->db->where('interactions_topic_mapped_data.interaction_id', $interactionID);

        $this->db->join('interactions_topics', 'interactions_topic_mapped_data.topic_id = interactions_topics.id', 'left');
        $this->db->join('interaction_types', 'interaction_types.id = interactions_topic_mapped_data.objective_id', 'left');
        $this->db->join('interactions_products', 'interactions_products.id = interactions_topic_mapped_data.product_id', 'left');
        if ($kolId != null && $kolId != -1) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions_topic_mapped_data.interaction_id', 'left');
            $this->db->where('interactions_attendees.kol_id', $kolId);
        }
        $interactionDetailsResult = $this->db->get('interactions_topic_mapped_data');
        //echo $this->db->last_query();
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionDetails['topic_names'][] = $row;
        }
        return $arrInteractionDetails;
    }

    /**
     * Retrives the all the Interactions of the Client
     * @author 	Ramesh B
     * @Created on: 01-03-11
     * @since	1.5
     * @return Array
     */
    function getOrgInteractionsForGrid($clientId, $orgId, $arrFilters) {
        $arrInteractionDetails = array();
//		if($kolId!=null && $kolId!=-1)
//			$this->db->where('interactions.kol_id',$kolId);
        if ($kolId != null && $kolId != -1) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
            $this->db->where('interactions_attendees.kol_id', $kolId);
        }
        if ($userId != 0)
            $this->db->where('interactions.created_by', $userId);
        if ($clientId != 0)
            $this->db->where('interactions.client_id', $clientId);
//		$this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_brands.name as brand_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty as area_name,objectives.name as objective_name");
        $this->db->select("interactions.*,interactions_modes.name as mode_name");
//		$this->db->join('interactions_about', 'interactions_about.interaction_id = interactions.id','left');
//		$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id','left');
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
//		$this->db->join('objectives', 'interactions_about.objective_id = objectives.id','left');
//		$this->db->join('interactions_topics', 'interactions_about.topic_id = interactions_topics.id','left');
//		$this->db->join('interactions_brands', 'interactions_about.brand_id = interactions_brands.id','left');
//		$this->db->join('interactions_products', 'interactions_products.id = interactions_about.product_id','left');
//		$this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id','left');
//		$this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id','left');
//		$this->db->join('kols', 'interactions_attendees.kol_id = kols.id','left');
//		$this->db->join('specialties', 'kols.specialty = specialties.id','left');

        if ($endDate != null && $startDate != null) {
            $this->db->where("interactions.date BETWEEN '" . $startDate . "-01' AND '" . $endDate . "-31'");
        } else if ($startDate != null) {
            $this->db->like('interactions.date', $startDate);
        }

        /* if($startDate!=0 && $endDate!=0){
          $wherBetween="(YEAR(interactions.date) BETWEEN '$startDate' AND '$endDate' OR YEAR(interactions.date)='0')";
          $this->db->where($wherBetween);
          } */
        $this->db->order_by('id', 'desc');
        if ($limit != null)
            $this->db->limit($limit, $startFrom);
        $interactionDetailsResult = $this->db->get('interactions');
        //echo $this->db->last_query();
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionAttendees = $this->getInteractionAttendees($row['id'], $kolId);
            $arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id'], $kolId);
            $row['kol_name'] = implode(',', $arrInteractionAttendees['kol_names']);
            $row['area_name'] = implode(',', $arrInteractionAttendees['specialties']);
            $row['category_name'] = implode(',', $arrInteractionAttendees['categories']);
            $row['role_name'] = implode(',', $arrInteractionAttendees['roles']);
            $row['topic_name'] = implode(',', $arrInteractionAboutTopics['topic_names']);
            $row['objective_name'] = implode(',', array_unique($arrInteractionAboutTopics['objective_names']));
            $row['product_name'] = implode(',', array_unique($arrInteractionAboutTopics['product_names']));
            $row['kol_name_for_export'] = implode(',', $arrInteractionAttendees['kol_name_for_export']);
            $row['kol_id'] = $kolId;
            $arrInteractionDetails[] = $row;
            //	pr($row);
        }
        //echo $this->db->last_query();
        //	pr($arrInteractionDetails);
        return $arrInteractionDetails;
    }

    function getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit, $startFrom, $doCount = null, $sidx = '', $sord = '', $where = '',$ipad=false) {
    	$client_id = $this->session->userdata('client_id');
    	$userGroupName = getGroupDetails();
    	if (!empty($arrFilters['manager_id']))
			$users=$this->common_helpers->getManagerAlignedUsers($arrFilters['manager_id']);
			
        $arrInteractionDetails = array();
//		if($kolId!=null && $kolId!=-1)
//			$this->db->where('interactions.kol_id',$kolId);
        $isAttendiesJoined = false;
        if ($kolId != null && $kolId != -1 && $kolId != 0) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
            $isAttendiesJoined = true;
            if (isset($arrFilters['interactionFor']) && ($arrFilters['interactionFor'] == 'org')){
                $this->db->where('interactions_attendees.org_id', $kolId);
            }else{
               $this->db->where('interactions_attendees.kol_id', $kolId);
            }
        }
        //Security: within profile - all, track-user: his interactions, track-manager: all interactions
        if ($userId != 0 && ($kolId == null || $kolId == 0 || $kolId == -1)){
            $this->db->where('interactions.created_by', $userId);
        }else{
        	
        }
        if ($clientId != INTERNAL_CLIENT_ID){
            $this->db->where('interactions.client_id', $clientId);
        } 
//		$this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_brands.name as brand_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty as area_name,objectives.name as objective_name");
        //$this->db->select("interactions.*,interactions_modes.name as mode_name,client_users.first_name,client_users.last_name,cities.city,regions.region,interaction_mirf.id as mirf_id ");
        $nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kols');
        $nameOrderFormat = $this->common_helpers->get_name_format('kols.first_name', 'kols.middle_name', 'kols.last_name');
        $this->db->select("interactions.id,interactions.client_id,interactions.data_type_indicator,interactions.date,interactions.created_by,interactions.quality_interaction,interactions.save_later,interactions.generic_id,interactions_modes.name as mode_name,client_users.first_name,client_users.last_name,cities.city,regions.region,interaction_mirf.id as mirf_id,interactions_attendees.kol_id,kols.salutation,kols.unique_id,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name,concat($nameFormatOrder) as kol_full_name,kols.deleted_by as kol_deleted,products.name as product,interaction_types.name AS type,interaction_topics.name AS topic,interaction_sub_topics.name AS sub_topic,organizations.id as org_id,organizations.name as org_name,interactions_modes.name as mode_name, interaction_grouping.name as grouping_name, interaction_location_types.name as interaction_location_type_name,interactions.mirf_case_num,client_users.territory as territory_id,emp.first_name as emp_first_name,emp.last_name as emp_last_name,specialties.specialty AS specialty,interactions.created_on,kols.mdm_id as mdm_id,interactions.employee_id,interactions.total_attendies",false);
        $this->db->select("case WHEN organizations.id is null THEN concat($nameFormatOrder) else organizations.name END as kol_org_name",false);
        $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');



        //	$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id','left');
        //$this->db->join('kols', 'interactions_attendees.kol_id = kols.id','left');

        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('client_users as emp', 'emp.id = interactions.employee_id', 'left');
        $this->db->join('cities', 'cities.CityId = interactions.city_id', 'left');
        $this->db->join('regions', 'regions.regionId = interactions.state_id', 'left');
        if ($kolId == null || $kolId == 0 || $kolId == -1){
        	if ($clientId != INTERNAL_CLIENT_ID){
	            if($this->session->userdata('user_role_id')==ROLE_MANAGER){
	                $group_names = explode(',',  $userGroupName['group_names']);
// 	                $group_names = explode(',', $this->session->userdata('group_names'));
	                $this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
	                $this->db->where_in ( 'countries.GlobalRegion', $group_names);
	            }
        	}   
        }
//       $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
       $this->db->join('interaction_grouping', 'interactions.grouping = interaction_grouping.id', 'left');        
       $this->db->join('interaction_location_types', 'interaction_location_types.id = interactions.location_category', 'left');
       
        $this->db->where("client_users.id IS NOT NULL");
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$clientId."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
        }
        if ($kolId != null && $kolId != -1) {
            if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
                $this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
            } else if ($startDate != null) {
                $this->db->like('interactions.date', $startDate);
            }
        } else {

            if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
//                if (strlen($arrFilters['start_date']) == 8)
//                    $this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "-01' AND '" . $arrFilters['end_date'] . "-31'");
//                else
                    $this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
            }else if ($startDate != null) {
                $this->db->like('interactions.date', $startDate);
            }
        }
        //Joins added to get attendies
        if ($isAttendiesJoined == false) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
            $isAttendiesJoined = true;
        }
        $this->db->join('kols', 'interactions_attendees.kol_id = kols.id ', 'left');
        $this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');

        $isJoined = false;
       
       
        if ($arrFilters['objective_id'] != '' && $arrFilters['objective_id'] != 0 && !empty(array_filter($arrFilters['objective_id']))) {
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
            $this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
            $isJoined = true;
        }

        if ($arrFilters['product_id'] != '' && $arrFilters['product_id'] != 0) {
            if ($isJoined == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
                $isJoined = true;
            }
            $this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
        }

        if ($arrFilters['topic_id'] != '' && $arrFilters['topic_id'] != 0 && !empty(array_filter($arrFilters['topic_id']))) {
            if ($isJoined == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
                $isJoined = true;
            }
            $this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
        }

        if ($arrFilters['org_id'] != '' && $arrFilters['org_id'] != 0) {
            $this->db->where('interactions_attendees.org_id', $arrFilters['org_id']);
        }

        if ($arrFilters['subtopic_id'] != '' && $arrFilters['subtopic_id'] != 0) {
            if ($isJoined == false) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
                $isJoined = true;
            }
            $this->db->where('interactions_discussion_topic_mapped_data.sub_topic_id', $arrFilters['subtopic_id']);
        }

        //To get primary topic details
        if ($isJoined == false) {
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
        }
        $this->db->join('products', 'interactions_discussion_topic_mapped_data.product_id = products.id', 'left');
        $this->db->join('interaction_types', 'interactions_discussion_topic_mapped_data.interaction_type = interaction_types.id', 'left');
        $this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
        $this->db->join('interaction_sub_topics', 'interactions_discussion_topic_mapped_data.sub_topic_id = interaction_sub_topics.id', 'left');

        if ($arrFilters['mode'] != '' && $arrFilters['mode'] != 0) {
            $this->db->where_in('mode', $arrFilters['mode']);
        }

        if ($arrFilters['grouping'] != '' && $arrFilters['grouping'] != 0) {
            $this->db->where_in('grouping', $arrFilters['grouping']);
        }
        if (array_filter($arrFilters['user_id']) != '' && array_filter($arrFilters['user_id']) != 0) {
            $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
        }
        //	$this->db->where('org_id',$orgId);
        /* if($startDate!=0 && $endDate!=0){
          $wherBetween="(YEAR(interactions.date) BETWEEN '$startDate' AND '$endDate' OR YEAR(interactions.date)='0')";
          $this->db->where($wherBetween);
          } */
        if ($limit != 'all' && $limit != 0) {
            $this->db->limit($limit, $startFrom);
            //$this->db->limit(1000);
        }
        
    	if(!isset($where['is_export']) && $where['is_export'] != true){
        	$this->db->group_by('interactions.id');
        }else{
//         	$this->db->group_by('interactions_discussion_topic_mapped_data.id');
        	$this->db->group_by('interactions.id');        	
        }
        $this->db->join('interaction_mirf', 'interaction_mirf.interaction_id=interactions.id', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');


         if (isset($where['kol_name'])) {
             $this->db->where("(case WHEN organizations.id is null THEN concat(kols.first_name,' ',CASE WHEN kols.middle_name IS NOT NULL || kols.middle_name!= '' THEN kols.middle_name ELSE '' END,' ',CASE WHEN kols.last_name IS NOT NULL || kols.last_name!= '' THEN kols.last_name ELSE '' END) like '%".$where['kol_name']."%' else organizations.name like '%".$where['kol_name']."%' END)",'',false);
            //$this->db->or_like("organizations.name",$where['kol_name']);
           // $this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%' or organizations.name LIKE '%" . $where['kol_name'] . "%')");
        }
        
        if (isset($where['date'])) {
    	   /* $dateLength = strlen($where['date']);
			if($dateLength == 10){
				$newDate = date("Y-d-m", strtotime($where['date']));
				$this->db->like("interactions.date", $newDate);
			}else{
				$this->db->like("interactions.date", $where['date']);
			} */
    	    $this->db->like("DATE_FORMAT(interactions.date,'%m/%d/%Y')", $where['date']);
		 }

        if (isset($where['recorded_by'])) {
            $this->db->like("concat(client_users.first_name,' ',client_users.last_name)",$where['recorded_by']);
//             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
        }
        if (isset($where['recorded_by_name'])) {
        	$this->db->like("concat(client_users.first_name,' ',client_users.last_name)",$where['recorded_by_name']);
        	//             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
        }
        if (isset($where['mode_name'])) {
            $this->db->like("interactions_modes.name", $where['mode_name']);
        }

        if (isset($where['objective_name'])) {
            $this->db->like("interaction_types.name", $where['objective_name']);
        }

        if (isset($where['product_name'])) {
            $this->db->like("products.name", $where['product_name']);
        }

        if (isset($where['quality_interaction'])) {
            if ($where['quality_interaction'][0] == "N" || $where['quality_interaction'][0] == "n")
                $this->db->like("interactions.quality_interaction", 0);
            else if ($where['quality_interaction'][0] == "Y" || $where['quality_interaction'][0] == "y")
                $this->db->like("interactions.quality_interaction", 1);
        }

        if (isset($where['generic_id'])) {
            $this->db->like("interactions.generic_id", $where['generic_id']);
        }

        if (isset($where['mirf'])) {
            if ($where['mirf'][0] == "A" || $where['mirf'][0] == "a")
                $this->db->where("interaction_mirf.id IS NULL");
            else if ($where['mirf'][0] == "E" || $where['mirf'][0] == "e" || $where['mirf'][0] == "V" || $where['mirf'][0] == "v")
                $this->db->where("interaction_mirf.id IS NOT NULL");
        }
        
        if (isset($where['emp_name'])) {
        	$empName = $where['emp_name'];
        	$this->db->like("CONCAT(emp.first_name,' ',emp.last_name)",$empName);
        }
		
        if(isset($where['is_export']) && $where['is_export'] == true){
        	$sidx = 'date';
        	$sord = 'DESC';
        }
        
	    if (!empty(array_filter($arrFilters['manager_id']))) { 
			$this->db->where_in("interactions.created_by", $users);
		}	
		if(!empty($arrFilters['plan_id'])){
		    $this->db->where("interactions.plan_name", $arrFilters['plan_id']);
		}
        if ($sidx != '' && $sord != '') {
            switch ($sidx) {
                case 'kol_name' : $this->db->order_by("kol_org_name", $sord);
                    break;
                case 'date' :$this->db->order_by("interactions.date", $sord);
                    break;
                case 'recorded_by' :$this->db->order_by("concat(client_users.first_name,' ',client_users.last_name)", $sord);
                    break;
                case 'recorded_by_name' :$this->db->order_by("concat(client_users.first_name,' ',client_users.last_name)", $sord);
                    break;
                case 'mode_name' :$this->db->order_by("interactions_modes.name", $sord);
                    break;
                case 'objective_name' :$this->db->order_by("interaction_types.name", $sord);
                    break;
                case 'product_name' :$this->db->order_by("products.name", $sord);
                    break;
                case 'quality_interaction' :$this->db->order_by("interactions.quality_interaction", $sord);
                    break;
                case 'mirf' :$this->db->order_by("interaction_mirf.id", $sord);
                    break;
                case 'generic_id' :$this->db->order_by("SUBSTR(interactions.generic_id FROM 1 FOR 2), SUBSTR(interactions.generic_id FROM 3)", $sord);
                    break;
            }
            //$this->db->order_by($sidx,$sord);
        } else {

            $this->db->order_by('interactions.date', 'desc');
        }
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        //	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $interactionDetailsResult = $this->db->get('interactions');
// 		pr($this->db->last_query());exit; 
        if ($limit != 'all') {
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            foreach ($interactionDetailsResult->result_array() as $row) {
                /* $arrInteractionAttendees	= $this->getInteractionAttendees($row['id'],$kolId,$arrFilters['interactionFor']);
                  //$arrInteractionAboutTopics	= $this->getInteractionOrgAboutTopics($row['id'],null);
                  $arrInteractionAboutTopics	= $this->getInteractionDiscussionTopicsByInteractionId($row['id'],null);


                  $row['kol_name']			= implode(',',$arrInteractionAttendees['kol_names']);
                  $row['area_name']			= implode(',',$arrInteractionAttendees['specialties']);
                  $row['category_name']		= implode(',',$arrInteractionAttendees['categories']);
                  $row['role_name']			= implode(',',$arrInteractionAttendees['roles']);
                  $row['topic_name']			= $arrInteractionAboutTopics['topic_names'];

                  $row['kol_name_for_export']	= implode(',',$arrInteractionAttendees['kol_name_for_export']); */

                //Optimized
                if ($row['org_id'] != null && $row['org_id'] != '') {
                	$row['orgInteractionAction'] = $row['org_id'];
                    if (IS_IPAD_REQUEST || $ipad)
                        $row['kol_name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/organizations/view/' . $row['org_id'] . '">' . $row['org_name'] . '</a>';
                    else
                        $row['kol_name'] = '<a  href="' . base_url() . 'organizations/view/' . $row['org_id'] . '">' . $row['org_name'] . '</a>';
                }else {
                	$row['orgInteractionAction'] = 0;
                    if (IS_IPAD_REQUEST || $ipad) {
                        if($row['kol_deleted'] == 0 || $row['kol_deleted'] == null){
                            $row['kol_name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                        }else{
                            $row['kol_name'] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']);
                        }
                    } else {
                        if($row['kol_deleted'] == 0 || $row['kol_deleted'] == null){
                            $row['kol_name'] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                        }else{
                            $row['kol_name'] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helpers->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']);
                        }
                    }
                }
                $row['kol_id'] = $kolId;
                $arrInteractionDetails[] = $row;
                //	pr($row);
            }
//			pr($arrInteractionDetails);
// 			pr($this->db->last_query());
//			exit;
            return $arrInteractionDetails;
        } else {
            return $interactionDetailsResult->num_rows();
        }

        //	pr($arrInteractionDetails);
        //return $arrInteractionDetails;
    }

    /*
     * Save the MIRF
     * @author Shruti Purushan
     * @since 2.9
     * @created 29-09-2015
     */

    function saveMirf($arrData, $data) {
        $arrData['created_by'] = $this->session->userdata('user_id');
        $arrData['created_on'] = date("Y-m-d H:i:s");
        if ($this->db->insert('interaction_mirf', $arrData)) {
            $mirf_id = $this->db->insert_id();
        } else {
            return false;
        }
        foreach ($data['product'] as $val) {

            if ($val != 0 && $val != '')
                $this->db->set('product_id', $val);
            $this->db->set('interaction_mirf_id', $data['interaction_mirf_id']);
            if ($val == 0)
                $this->db->set('other_product_name', $data['other_product_name']);
            if ($data['first_product_value'] == 1 || $val == 2) {
                $this->db->set('is_single_use_vial', $data['is_single_use_vial']);


                $this->db->set('is_dual_chamber_syringe', $data['is_dual_chamber_syringe']);


                $this->db->set('is_non_kit_specific_enquiry', $data['is_non_kit_specific_enquiry']);

                //
            }
            $this->db->set('interaction_mirf_id', $mirf_id);
            $this->db->insert('interaction_mirf_products');
        }
        return $mirf_id;
    }

    /*
     * Updating the MIRF
     * @author Shruti Purushan
     * @since 2.9
     * @created 29-09-2015
     */

    function updateMirf($arrData, $data) {
        $arrData['modified_by'] = $this->session->userdata('user_id');
        $arrData['modified_on'] = date("Y-m-d H:i:s");
        $this->db->where('interaction_mirf_id', $data['interaction_mirf_id']);
        $this->db->delete('interaction_mirf_products'); 
        foreach ($data['product'] as $val) {
            $this->db->where('interaction_mirf_id', $data['interaction_mirf_id']);
            if ($val != 0)
                $this->db->set('product_id', $val);
            //            pr($data['interaction_mirf_id']);
            $this->db->set('interaction_mirf_id', $data['interaction_mirf_id']);
            if ($val == 0)
                $this->db->set('other_product_name', $data['other_product_name']);
            if ($data['first_product_value'] == 1 || $val == 2) {


                $this->db->set('is_single_use_vial', $data['is_single_use_vial']);


                $this->db->set('is_dual_chamber_syringe', $data['is_dual_chamber_syringe']);


                $this->db->set('is_non_kit_specific_enquiry', $data['is_non_kit_specific_enquiry']);



                //
            }
            $this->db->insert('interaction_mirf_products');
        }
        $this->db->where('id', $arrData['id']);
        if ($this->db->update('interaction_mirf', $arrData)) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * Get the MIRF Details For Editing
     * @author Shruti Purushan
     * @since 2.9
     * @created 1-10-2015
     */

    function editMirf($id) {
        $arrReturnData = array();
        $this->db->select('interaction_mirf.* ');
        if (!empty($id)) {
            $this->db->where('interaction_mirf.id', $id);
        }

        $this->db->order_by('interaction_mirf.id', 'desc');
        $arrMirfResultSet = $this->db->get('interaction_mirf');
        //echo $this->db->last_query();
        foreach ($arrMirfResultSet->result_array() as $row) {
            //                pr($row);
            $row['client_territory'] = $this->Client_User->getUserTerritoryById($row['client_id']);
            $row['client_id'] = $this->Client_User->getUserNameById($row['client_id']);


            //			$row['created_user']= $row['ufname'].' '.$row['ulname'];
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getProductDetails($id) {
        $arrReturnData = array();
        $this->db->select('interaction_mirf_products.* ');
        if (!empty($id)) {
            $this->db->where('interaction_mirf_products.interaction_mirf_id', $id);
        }

        $this->db->order_by('interaction_mirf_products.interaction_mirf_id', 'desc');
        $arrResultSet = $this->db->get('interaction_mirf_products');
//                echo $this->db->last_query();
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[$row['product_id']] = $row;
        }
        return $arrReturnData;
    }

    function getProductNames() {
        $arrReturnData = array();
        $this->db->select('id,name');


        $this->db->order_by('id', 'desc');
        $arrResultSet = $this->db->get('products');
        //        echo $this->db->last_query();
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function listMirf($id = '',$gridFilter) {              
        $arrMirf = array();
        if (!empty($id['manager_id']))
                $users=$this->common_helpers->getManagerAlignedUsers($id['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('interaction_mirf.* ,interactions.generic_id as interactionGeneric');
        $this->db->join('interactions', 'interactions.id=interaction_mirf.interaction_id', 'left');
         $this->db->join('kols', 'kols.id=interaction_mirf.kol_id', 'left');
//           $this->db->join('interaction_mirf_products', 'interaction_mirf_products.interaction_mirf_id=interaction_mirf.interaction_id', 'left');
//         $this->db->join('products', 'products.id=interaction_mirf_products.product_id', 'left');
       
        if (!empty($id) && !is_array($id)) {
            $this->db->where('interaction_mirf.id', $id);
        }
        $dateString = "";
        if (is_array($id)) {
            if ($id['start_date'] != '' && $id['end_date'] != '')
                $dateString = ' BETWEEN "' . $id['start_date'] . '" AND "' . $id['end_date'] . '"';
            else if ($id['start_date'] != '')
                $dateString = ' >= "' . $id['start_date'] . '"';
            else if ($id['end_date'] != '')
                $dateString = ' <= "' . $id['end_date'] . '"';
        }
        if ($dateString != '') {
            $this->db->where('interaction_mirf.date_of_request ' . $dateString);
        }
        if (is_array($id)) {
            if (!empty($id['msl'])) {

                $this->db->where_in("interaction_mirf.created_by", $id['msl']);
            }
            if (!empty($id['team'])) {
                $this->db->join('user_groups', 'user_groups.user_id=interaction_mirf.client_id', 'left');
                $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');

                $this->db->where_in('user_groups.group_id ', $id['team']);
            }
            
            if (!empty($id['manager_id'])) { 
                $this->db->where_in("interaction_mirf.created_by", $users);
            }
            
        }
        if (!empty($gridFilter['state']))
            $this->db->like("interaction_mirf.state", $gridFilter['state']);
        if (!empty($gridFilter['date_of_request']))
            $this->db->like("interaction_mirf.date_of_request", $gridFilter['date_of_request']);
        if (!empty($gridFilter['kol_id'])){ 
           
            $this->db->like("CONCAT(kols.first_name,kols.last_name,kols.middle_name)", $gridFilter['kol_id']);
        }
//         if (!empty($gridFilter['products'])){ 
//           
//            $this->db->like("products.name", $gridFilter['products']);
//        }
        if (!empty($gridFilter['institution']))
            $this->db->like("interaction_mirf.institution", $gridFilter['institution']);  
         if (!empty($gridFilter['city']))
            $this->db->like("interaction_mirf.city", $gridFilter['city']);
          if (!empty($gridFilter['zip_code']))
            $this->db->like("interaction_mirf.zip_code", $gridFilter['zip_code']);
           if (!empty($gridFilter['interactionGeneric']))
            $this->db->like("interactions.generic_id", $gridFilter['interactionGeneric']);
            if (!empty($gridFilter['generic_id']))
            $this->db->like("interaction_mirf.generic_id", $gridFilter['generic_id']);
        $this->db->group_by('interaction_mirf.interaction_id');
        $this->db->order_by('interaction_mirf.id', 'desc');
        if (is_array($id)) {
            if($userRole == ROLE_USER){
                $this->db->where('interaction_mirf.created_by', $userId);
            }
            if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
                $this->db->where_in('interaction_mirf.created_by', $userIds);
            }
        }
        $arrMirfResultSet = $this->db->get('interaction_mirf');
        foreach ($arrMirfResultSet->result_array() as $row) {
            $row['kol_id'] = $this->kolNameById($row['kol_id']);
            $row['client_id'] = $this->Client_User->getUserNameById($row['client_id']);
            $row['date_of_request'] = sql_date_to_app_date($row['date_of_request']);
            $row['created_on'] = sql_date_to_app_date($row['created_on']);
             $row['first'] =$this->getProductNamesForFirstRow($row['id']);
              $row['prod']=$this->getProductNamesForSelectedIds($row['id']);
            $arrMirf[] = $row;
        }
//                                                        echo $this->db->last_query(); exit;
        return $arrMirf;   
//		 					                pr($arrMirf);
    }

    function kolNameById($userIds = 0) {
        $userIds = trim($userIds);
        if (empty($userIds)) {
            $userIds = 0;
        }
        $usernames = '';
        //		$query				= "SELECT CONCAT_WS(' ',kols.".FIRST_ORDER.",kols.".SECOND_ORDER.",kols.".THIRD_ORDER.") as username FROM kols WHERE kols.id IN (".$userIds.")";
        $query = "SELECT kols.first_name,kols.middle_name,kols.last_name FROM kols WHERE kols.id IN (" . $userIds . ")";
        $arrKolUsersResultSet = $this->db->query($query);
        //echo $this->db->last_query();
        $separator = '';
        foreach ($arrKolUsersResultSet->result_array() as $usersRow) {
            //			$usernames		.= $separator.$usersRow['username'];
            $usernames .= $separator . $this->common_helpers->get_name_format($usersRow['first_name'], $usersRow['middle_name'], $usersRow['last_name']);
            $separator = ', ';
        }
        return $usernames;
    }

    function deleteMirf($id) {
        $this->db->where('id', $id);
        $this->db->delete('interaction_mirf');
    }

    function deleteMirfProduct($id) {
        $this->db->where('interaction_mirf_id', $id);
        $this->db->delete('interaction_mirf_products');
    }

    function getProductNamesForSelectedIds($id) {
        $arrReturnData = array();
        $this->db->select('distinct(name),other_product_name');
        $this->db->join('products', 'products.id=interaction_mirf_products.product_id', 'left');
        $this->db->where('interaction_mirf_products.interaction_mirf_id', $id);
           $arrResultSet = $this->db->get('interaction_mirf_products');
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        } 
//        echo $this->db->last_query(); exit;
        return $arrReturnData;
    }
    
    function getProductNamesForFirstRow($id){
         $arrReturnData = array();
        $this->db->select(' is_single_use_vial,is_dual_chamber_syringe,is_non_kit_specific_enquiry');
        $this->db->join('products', 'products.id=interaction_mirf_products.product_id', 'left');
        $this->db->where('interaction_mirf_products.interaction_mirf_id', $id);
        $this->db->group_by('is_single_use_vial,is_dual_chamber_syringe,is_non_kit_specific_enquiry');
           $arrResultSet = $this->db->get('interaction_mirf_products');
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        } 
//        echo $this->db->last_query(); exit;
        return $arrReturnData;
    }

    function getMirfIdFromInteractionId($id) {
        $arrReturnData = array();

        $query = ("select id from interaction_mirf where interaction_id=$id");

        $arrResultSet = $this->db->query($query);
        foreach ($arrResultSet->result_array() as $row) {
            $id = $row;
        }
        return $id;
    }

    function getCleintUSers() {
        $this->db->select("id,first_name,last_name");
        $this->db->order_by("first_name", "asc");
        $this->db->order_by("first_name", "asc");
        $this->db->where_in('client_users.user_from', array(1, 2));
        $clientId = $this->session->userdata('client_id');
        $this->db->where_in('client_users.client_id', $clientId);
        $arrData = $this->db->get("client_users");
        $retArr = array();
        foreach ($arrData->result_array() as $row) {
            $retArr[] = $row;
        }
        return $retArr;
    }

    function getTerritoryData() {
        $this->db->select("id,first_name,last_name,user_name as territory_name,title as external_id,company_name as external_id_1,territory");
        $this->db->where('client_id', $this->session->userdata('client_id'));
        $this->db->where_in('user_from', array(1, 2));
		$this->db->order_by('first_name', 'asc');
        $arrData = $this->db->get("client_users");
        $arrRetData = array();
        foreach ($arrData->result_array() as $row) {
            $row['external_id'] = '';
            $row['external_id_1'] = '';
            $arrRetData[] = $row;
        }
        return $arrRetData;
    }

    function getKolLastInteractionById($kolId) {
        $clientId = $this->session->userdata('client_id');
        $this->db->select("interactions.date");
        $this->db->join("interactions_attendees", "interactions_attendees.interaction_id = interactions.id", "left");
        $this->db->where('interactions.client_id', $clientId);
        $this->db->where("interactions_attendees.kol_id", $kolId);
        $this->db->order_by("interactions.date", "desc");
        $arrRetData = $this->db->get("interactions");
        $retValue = '';
        foreach ($arrRetData->result_array() as $row) {
            $last_interaction = $row['date'];
            break;
        }
        if ($last_interaction != '')
            $retValue = date("m/d/Y", strtotime($last_interaction));
        return $retValue;
    }

    function getOrgLastInteractionById($kolId) {
        $clientId = $this->session->userdata('client_id');
        $this->db->select("interactions.date");
        $this->db->join("interactions_attendees", "interactions_attendees.interaction_id = interactions.id", "left");
        $this->db->where('interactions.client_id', $clientId);
        $this->db->where("interactions_attendees.org_id", $kolId);
        $this->db->order_by("created_on", "desc");
        $arrRetData = $this->db->get("interactions");
        $retValue = '';
        foreach ($arrRetData->result_array() as $row) {
            $last_interaction = $row['date'];
            break;
        }
        // echo $this->db->last_query();
        if ($last_interaction != '')
            $retValue = date("m/d/Y", strtotime($last_interaction));
        return $retValue;
    }

    function saveOtherAttendis($arrOtherAttendisDetails) {
        $this->db->insert("interactions_other_attendees", $arrOtherAttendisDetails);
        return true;
    }

    function getTerritoryNameById($territoryId) {
        $this->db->select("name");
        $this->db->where("id", $territoryId);
    }

    function getOtherAttendisDataById($interactionId) {

        $this->db->select("interactions_other_attendees.*, specialties.specialty");
        $this->db->join("specialties", "specialties.id = interactions_other_attendees.specialty_id", "left");
        $this->db->where("interactions_other_attendees.interaction_id", $interactionId);
        $arrData = $this->db->get("interactions_other_attendees");
        $arrRetData = array();
        foreach ($arrData->result_array() as $row) {
            $arrRetData[] = $row;
        }
//        echo $this->db->last_query(); 
//        exit;
        //pr($arrRetData);
        return $arrRetData;
    }

    function deleteInteractionOtherAttendis($interactionId) {
        $this->db->where('interaction_id', $interactionId);
        $this->db->delete('interactions_other_attendees');
    }

    function getAllTypes($typeId) {
        $arrTopics = array();
        $this->db->select("interaction_topics.id as topic_id,interaction_topics.name");
        $this->db->join('interaction_topics', 'interaction_topics.id = interaction_topics_by_type.topic_id', 'left');
        $this->db->where('interaction_topics_by_type.type_id', $typeId);
        $arrResults = $this->db->get('interaction_topics_by_type');
        foreach ($arrResults->result_array() as $row) {
            $arrTopics[$row['topic_id']] = $row['name'];
        }
        return $arrTopics;
    }

    function getAllTopics($typeId) {
        $this->db->select("interaction_sub_topics.id,interaction_sub_topics.name");
        $this->db->join("interaction_sub_topics", "interaction_sub_topics.id = interaction_sub_topics_association.sub_topic_id", "left");
        $this->db->where('interaction_sub_topics_association.topic_id', $topicId);
        $this->db->where('interaction_sub_topics_association.type_id', $typeId);
        $this->db->where('interaction_sub_topics_association.product_id', $productId);
        $arrData = $this->db->get('interaction_sub_topics_association');
        foreach ($arrData->result_array() as $row) {
            $arrRetData[$row['id']] = $row['name'];
        }
        return $arrRetData;
    }

    function getSubTopics($productId, $typeId, $topicId) {
        $this->db->select("interaction_sub_topics.id,interaction_sub_topics.name");
        $this->db->join("interaction_sub_topics", "interaction_sub_topics.id = interaction_sub_topics_association.sub_topic_id", "left");
        $this->db->where('interaction_sub_topics_association.topic_id', $topicId);
        $this->db->where('interaction_sub_topics_association.type_id', $typeId);
        $this->db->where('interaction_sub_topics_association.product_id', $productId);
        $arrData = $this->db->get('interaction_sub_topics_association');
        foreach ($arrData->result_array() as $row) {
            $arrRetData[$row['id']] = $row['name'];
        }
        return $arrRetData;
    }

    function getTopicByType($typeId, $productId) {
        $arrTopics = array();
        $this->db->distinct("interaction_topics.name");
        $this->db->select("interaction_topics.id,interaction_topics.name");
        $this->db->join('interaction_topics', 'interaction_topics.id=interaction_topics_by_type.topic_id', 'left');
        $this->db->where('interaction_topics_by_type.product_id ', $productId);
        $this->db->where('interaction_topics_by_type.type_id ', $typeId);
        $this->db->where('interaction_topics.status ', 1);
        $this->db->order_by("interaction_topics.name");
        $this->db->order_by("interaction_topics.id");
        $arrResults = $this->db->get('interaction_topics_by_type');
//        echo $this->db->last_query();
        foreach ($arrResults->result_array() as $row) {
			//$arrTopics[$row['id']] = $row['name'];
        	//$arrTopics[] = $row;
        	//check if the topic is 'Other' and add it last in the list
			if($row['name'] != 'Other'){
				$arrTopics1[] = $row;
			}else{
				$arrTopics2[] = $row;
			}
        }
        if(!empty($arrTopics2)){
            $arrTopics = array_merge($arrTopics1,$arrTopics2);
       	}else{
            $arrTopics = $arrTopics1;
        }
       return $arrTopics;
    }

    function getInteractionDiscussionTopics($id) {
        $this->db->select('interactions_discussion_topic_mapped_data.*');
        $this->db->where('interaction_id', $id);
        $arrTopicsResult = $this->db->get('interactions_discussion_topic_mapped_data');
        
        foreach ($arrTopicsResult->result_array() as $row) {
            $arrTopics[] = $row;
        }
        return $arrTopics;
    }

    function deleteInteractionDiscussionTopicDetail($topicDeatl) {
        $this->db->where('interaction_id', $topicDeatl);
        $this->db->delete('interactions_discussion_topic_mapped_data');
    }

    function getInteractionDiscussionTopicsByInteractionId($interactionID, $kolId = null) {
        $arrInteractionDetails = array();
        $this->db->select("interaction_topics.name AS topic_name,products.name AS product_name,interaction_types.name AS objective_name");
        $this->db->where('interactions_discussion_topic_mapped_data.interaction_id', $interactionID);

        $this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
        $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
        $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
        if ($kolId != null && $kolId != -1) {
            $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions_topic_mapped_data.interaction_id', 'left');
            $this->db->where('interactions_attendees.kol_id', $kolId);
        }
        $interactionDetailsResult = $this->db->get('interactions_discussion_topic_mapped_data');
// 		echo $this->db->last_query();
        foreach ($interactionDetailsResult->result_array() as $row) {
            $arrInteractionDetails['topic_names'][] = $row;
        }
        return $arrInteractionDetails;
    }

    function getMirfByInteraction($interactionId) {
        $mirfDetails = array();
        $this->db->where('interaction_id', $interactionId);
        $res = $this->db->get('interaction_mirf');
        if (is_object($res) && $res->num_rows() > 0) {
            $mirfDetails = $res->row_array();
        }
        return $mirfDetails;
    }

    /*
     * Get the intearction product Details 
     * @author Shruti Purushan
     * @since 2.9
     * @created 29-10-2015
     */

    function getProductIdByInteractionId($interactionId) {
        $arrReturnData = array();
        $this->db->select('interactions_discussion_topic_mapped_data.* ');

        $this->db->where('interaction_id', $interactionId);
        //		 			$this->db->order_by('interaction_mirf_products.interaction_mirf_id', 'desc');
        $arrResultSet = $this->db->get('interactions_discussion_topic_mapped_data');
        //        echo $this->db->last_query();
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[$row['product_id']] = $row;
        }
        return $arrReturnData;
    }

    /**
     * Fetching all location type for  organization 
     * @author 	Shruti Purushan
     * @Created on:  4-11-2015
     * @return
     */
    function getInteractionLocationTypes() {
        $arrInteractionLocationTypes = array();
        $this->db->select('id,name');
        $this->db->where('is_active', 1);
        $this->db->order_by('id', 'ASC');
        $result = $this->db->get('interaction_location_types');
        foreach ($result->result_array() as $row) {
            $arrInteractionLocationTypes[] = $row;
        }
        return $arrInteractionLocationTypes;
    }

    /*function getAllKolNamesForAutocompleteIpad($kolName) {
        	$kolName = str_replace(","," ",$kolName);
			$kolName = preg_replace('!\s+!', ' ', $kolName);
			$kolName	= $this->db->escape_like_str($kolName);
			
        $arrKols = array();
        $this->db->select("kols.id,first_name,middle_name,last_name,profile_image,gender,organizations.name as name,kols.status,kols.do_not_call_flag,regions.region as state,cities.city as city,kol_locations.private_practice");
        //	$this->db->select("kols.id,first_name,middle_name,last_name");
        $this->db->join('organizations', 'kols.org_id=organizations.id', 'left'); 
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id', 'left');
        
        if (count(explode(' ', $kolName)) > 2) {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(3);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)",$kolName);
        }if(count(explode(' ',$kolName))==1){
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(1);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)",$kolName);
        } else {
            $likeNameFormatOrder = $this->common_helpers->get_name_format_order(2);
            $this->db->like("concat_ws(' ',$likeNameFormatOrder)",$kolName);
        }
			$this->db->order_by("last_name,first_name");
        //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
        $this->db->where('kols.customer_status', "ACTV");
        $arrKolsResult = $this->db->get('kols');
//                        echo $this->db->last_query();
        $arrCompletedKols = array();
        $arrMyCustomers = array();
        foreach ($arrKolsResult->result_array() as $row) {
//					$arrCompletedKols[$row['id']][]	= str_replace('  ',' ',$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER]);
            $arrCompletedKols[$row['id']][] = str_replace('  ', ' ', $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']));
            if(!empty($row['name']))
                $arrCompletedKols[$row['id']][] = $row['name'];
            else
                $arrCompletedKols[$row['id']][] = $row['private_practice'];
            $arrCompletedKols[$row['id']][] = $row['profile_image'];
            $arrCompletedKols[$row['id']][] = $row['gender'];
            $arrCompletedKols[$row['id']][] = $row['state'];
            $arrCompletedKols[$row['id']][] = $row['city'];
            if ($row['do_not_call_flag'] == 0)
                $arrCompletedKols[$row['id']]['do_not_call_flag'] = '';
            else
                $arrCompletedKols[$row['id']]['do_not_call_flag'] = 'Do Not Call';
        }
        $arrKols['kols'] = $arrCompletedKols;
        $arrKols['customers'] = $arrMyCustomers;
        return $arrKols;
    }*/
            function getAllKolNamesForAutocompleteIpad($kolName) {
            	$kolName = str_replace(","," ",$kolName);
            	$kolName = preg_replace('!\s+!', ' ', $kolName);
            	$kolName	= $this->db->escape_like_str($kolName);
            		
            	$arrKols = array();
            	$this->db->select("kols.id,kols.unique_id,first_name,middle_name,last_name,profile_image,gender,organizations.name as name,kols.status,kols.do_not_call_flag,regions.region as state,cities.city as city,kol_locations.private_practice");
            	//	$this->db->select("kols.id,first_name,middle_name,last_name");
            	$this->db->join('organizations', 'kols.org_id=organizations.id', 'left');
            	$this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
            	$this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
            	$this->db->join('kol_locations', 'kols.id = kol_locations.kol_id', 'left');
            	$likeNameFormatOrder	= 'first_name,middle_name,last_name';
            	//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
            	$this->db->where('replace(concat(coalesce(first_name,"")," ",coalesce(middle_name,"")," ",coalesce(last_name,"")),"  "," ") like "%'.$kolName.'%"', '',false);
            	//$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
            	$this->db->where('kols.customer_status', "ACTV");
            	$nameFormat = $this->session->userdata('name_order');
            	if ($nameFormat == 1 || $nameFormat == 3)
            		$this->db->order_by("first_name",'asc');
            		else if ($nameFormat == 2)
            			$this->db->order_by("last_name",'asc');
            			$arrKolsResult = $this->db->get('kols');
            			//        echo $this->db->last_query();
            			$arrCompletedKols = array();
            			$arrMyCustomers = array();
            			foreach ($arrKolsResult->result_array() as $row) {
            				//					$arrCompletedKols[$row['id']][]	= str_replace('  ',' ',$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER]);
            				$arrCompletedKols[$row['unique_id']][] = str_replace('  ', ' ', $this->common_helpers->get_name_format($row[FIRST_ORDER], $row[SECOND_ORDER], $row[THIRD_ORDER]));
            				if(!empty($row['name']))
            					$arrCompletedKols[$row['unique_id']][] = $row['name'];
            					else
            						$arrCompletedKols[$row['unique_id']][] = $row['private_practice'];
            						$image = "images/kol_images/resized/".$row['profile_image'];
            						if(file_exists($image))
            							$arrCompletedKols[$row['unique_id']][] = $row['profile_image'];
            						else
            							$arrCompletedKols[$row['unique_id']][] = '';
            						$arrCompletedKols[$row['unique_id']][] = $row['gender'];
            						$arrCompletedKols[$row['unique_id']][] = $row['state'];
            						$arrCompletedKols[$row['unique_id']][] = $row['city'];
            						if ($row['do_not_call_flag'] == 0)
            							$arrCompletedKols[$row['unique_id']]['do_not_call_flag'] = '';
            							else
            								$arrCompletedKols[$row['unique_id']]['do_not_call_flag'] = 'Do Not Call';
            			}
            			$arrKols['kols'] = $arrCompletedKols;
            			$arrKols['customers'] = $arrMyCustomers;
            			return $arrKols;
            }

    function getGenId($id) {
        $this->db->select("generic_id");
        $result = $this->db->get('interactions');
        return $result->row_array();
    }

    function listInteractions($arrFilters, $groupByCategory = null) {
    	$userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $userGroupName = getGroupDetails();
        if (!empty($arrFilters['manager_ids']))
			$users=$this->common_helpers->getManagerAlignedUsers($arrFilters['manager_ids']);
        
        if ($groupByCategory == 'channel') {
            $this->db->select("interactions_modes.name AS interaction_channel,
  				COUNT(DISTINCT interactions.id) AS interactions_count", false);
        } else {
            $this->db->select("interactions.id,client_users.is_activated,CONCAT(client_users.first_name,' ',client_users.last_name) AS msl_name,
				groups.group_id AS interaction_group_id,groups.group_name AS interaction_group_name,
				interactions_modes.name AS interaction_channel,interactions_modes.id AS interaction_channel_id,
				interaction_grouping.name AS interaction_category,interaction_grouping.id AS interaction_category_id,
				interactions_modes.name AS interaction_channel,interactions_modes.id AS interaction_channel_id,kols.deleted_by as kol_deleted,
				kols.id as kol_id,kols.unique_id,kols.first_name,kols.middle_name,kols.last_name,interaction_types.name AS interaction_type,interaction_types.id AS interaction_type_id,
				interaction_topics.name AS interaction_topic,interaction_topics.id AS interaction_topic_id,interaction_sub_topics.name AS interaction_sub_topic,
				interaction_sub_topics.id AS interaction_sub_topic_id,products.name AS interaction_product,interactions.total_attendies AS attendees,
				CASE WHEN kols.is_speaker = 1 THEN 'YES' ELSE 'NO' END AS interaction_speaker,kols.id AS kol_id,degrees.degree AS interaction_kol_degree,
				interactions.mirf_case_num AS interaction_mirf_id,interactions.generic_id AS interaction_generic_id,interactions.id AS interaction_id,interactions.is_org_interaction,organizations.name as org_name,organizations.id as org_id,interactions.date as interaction_date", false);
        }
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
        $this->db->join('interactions_modes', 'interactions_modes.id = interactions.mode', 'left');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        $this->db->join('kols', 'kols.id = interactions_attendees.kol_id', 'left');
        $this->db->join('organizations', 'organizations.id = interactions_attendees.org_id', 'left');
        $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
        $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
        $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
        $this->db->join('interaction_sub_topics', 'interaction_sub_topics.id = interactions_discussion_topic_mapped_data.sub_topic_id', 'left');
        $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
        $this->db->join('degrees', 'degrees.id = kols.degree_id', 'left');
        $this->db->join('user_groups', 'user_groups.user_id = interactions.created_by', 'left');
        $this->db->join('groups', 'groups.group_id = user_groups.group_id', 'left');

        if ($arrFilters['fromDate'] != '' && $arrFilters['toDate'] != '') {
            $fromDate = $arrFilters['fromDate'];
            $toDate = $arrFilters['toDate'];
            $wherBetween = "(interactions.date BETWEEN '$fromDate' AND '$toDate')";
            $this->db->where($wherBetween);
        } else {
            if ($arrFilters != '' && $arrFilters['fromDate'] != null && isset($arrFilters['fromDate']) && sizeof($arrFilters['fromDate']) > 0)
                $this->db->where('interactions.date >=', $arrFilters['fromDate']);
            if ($arrFilters != '' && $arrFilters['toDate'] != null && isset($arrFilters['toDate']) && sizeof($arrFilters['toDate']) > 0)
                $this->db->where('interactions.date <=', $arrFilters['toDate']);
        }
        if ($arrFilters != '' && $arrFilters['msl_user'] != null && isset($arrFilters['msl_user']) && sizeof($arrFilters['msl_user']) > 0)
            $this->db->where_in('client_users.id', $arrFilters['msl_user']);
        if ($arrFilters != '' && $arrFilters['channel'] != null && isset($arrFilters['channel']) && sizeof($arrFilters['channel']) > 0)
            $this->db->where_in('interactions_modes.id', $arrFilters['channel']);
        if ($arrFilters != '' && $arrFilters['category'] != null && isset($arrFilters['category']) && sizeof($arrFilters['category']) > 0)
            $this->db->where_in('interaction_grouping.id', $arrFilters['category']);
        if ($arrFilters != '' && $arrFilters['product'] != null && isset($arrFilters['product']) && sizeof($arrFilters['product']) > 0)
            $this->db->where_in('products.id', $arrFilters['product']);
        if ($arrFilters != '' && $arrFilters['type'] != null && isset($arrFilters['type']) && sizeof($arrFilters['type']) > 0)
            $this->db->where_in('interaction_types.id', $arrFilters['type']);
        if ($arrFilters != '' && $arrFilters['topic'] != null && isset($arrFilters['topic']) && sizeof($arrFilters['topic']) > 0)
            $this->db->where_in('interaction_topics.id', $arrFilters['topic']);
        if ($arrFilters != '' && $arrFilters['sub_topic'] != null && isset($arrFilters['sub_topic']) && sizeof($arrFilters['sub_topic']) > 0)
            $this->db->where_in('interaction_sub_topics.id', $arrFilters['sub_topic']);
        if ($arrFilters != '' && $arrFilters['team'] != null && isset($arrFilters['team']) && sizeof($arrFilters['team']) > 0)
            $this->db->where_in('groups.group_id', $arrFilters['team']);
        if ($arrFilters != '' && $arrFilters['interaction_ids'] != null && isset($arrFilters['interaction_ids']) && sizeof($arrFilters['interaction_ids']) > 0)
            $this->db->where_in('interactions.id', $arrFilters['interaction_ids']);
		
		if (!empty($arrFilters['manager_ids'])) { 
			$this->db->where_in("interactions.created_by", $users);
		}    
        if ($groupByCategory == 'channel') {
            $this->db->group_by('interactions_modes.id');
        } else {
            $this->db->group_by('interactions.id');
        }
        
    	if($userRole == ROLE_USER){
            $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        
        if(isset($arrFilters['otherFilters'])){
        	if(isset($arrFilters['otherFilters']['msl_name']))
        		$this->db->like("CONCAT_WS(' ',client_users.first_name,client_users.last_name)", $arrFilters['otherFilters']['msl_name']);
			if(isset($arrFilters['otherFilters']['interaction_group_name']))
        		$this->db->like("groups.group_name", $arrFilters['otherFilters']['interaction_group_name']);
        	if(isset($arrFilters['otherFilters']['interaction_generic_id']))
        		$this->db->like("interactions.generic_id", $arrFilters['otherFilters']['interaction_generic_id']);
        	if(isset($arrFilters['otherFilters']['interaction_category']))
        		$this->db->like("interaction_grouping.name", $arrFilters['otherFilters']['interaction_category']);
        	if(isset($arrFilters['otherFilters']['interaction_channel']))
        		$this->db->like("interactions_modes.name", $arrFilters['otherFilters']['interaction_channel']);
        	if(isset($arrFilters['otherFilters']['interaction_speaker'])){
        		if(strlower($arrFilters['otherFilters']['interaction_speaker']) == 'yes'){
        			$arrFilters['otherFilters']['interaction_speaker'] = 1;
        		}else{
        			$arrFilters['otherFilters']['interaction_speaker'] = 0;
        		}
        		$this->db->like("kols.is_speaker", $arrFilters['otherFilters']['interaction_speaker']);
        	}
			if(isset($arrFilters['otherFilters']['interaction_kol_degree']))
        		$this->db->like("degrees.degree", $arrFilters['otherFilters']['interaction_kol_degree']);
        	if(isset($arrFilters['otherFilters']['profile_name']))
        		$this->db->like("CONCAT_WS(' ',kols.last_name,kols.first_name,kols.middle_name)", $arrFilters['otherFilters']['profile_name']);
        	if(isset($arrFilters['otherFilters']['interaction_type']))
        		$this->db->like("interaction_types.name", $arrFilters['otherFilters']['interaction_type']);
        	if(isset($arrFilters['otherFilters']['interaction_topic']))
        		$this->db->like("interaction_topics.name", $arrFilters['otherFilters']['interaction_topic']);
        	if(isset($arrFilters['otherFilters']['interaction_mirf_id']))
        		$this->db->like("interactions.mirf_case_num", $arrFilters['otherFilters']['interaction_mirf_id']);
			if(isset($arrFilters['otherFilters']['interaction_product']))
        		$this->db->like("products.name", $arrFilters['otherFilters']['interaction_product']);
        }
        
//			$this->db->where("kols.id IS NOT NULL");
//			$this->db->where("client_users.id IS NOT NULL");
        $this->db->order_by("interactions.date", "DESC");
//        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $this->db->where('(groups.group_type = "Team")');
		
        //$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)");
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $client_id);
        	if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        	    $group_names = explode(',',  $userGroupName['group_names']);
//         		$group_names = explode(',', $this->session->userdata('group_names'));
        		$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        		$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        	}
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)");
        }
        $results = $this->db->get("interactions");
//        pr($results->result_array());

// 		print $this->db->last_query();
//		exit;
        $arrData = array();
        if ($groupByCategory == 'channel') {
        	foreach ($results->result_array() as $row) {
        		$row['interaction_date'] = date("m/d/Y",strtotime($row['interaction_date']));
	            $row['is_activated'] = ($row['is_activated']) ? "Yes" : "No";
	            if($row['org_id'] != '')	            
	            	$row['profile_name'] = $row['org_name'];
	            else
	            	$row['profile_name'] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']);
	            $arrData[] = $row;
	        }
        	return $arrData;
        }else{
        	foreach ($results->result_array() as $row) {
        		$row['interaction_date'] = date("m/d/Y",strtotime($row['interaction_date']));
	            $row['is_activated'] = ($row['is_activated']) ? "Yes" : "No";
	            //Optimized
	            $row['exp_interaction_generic_id'] = $row['interaction_generic_id'];
            	if (IS_IPAD_REQUEST || $ipad)
            		$row['interaction_generic_id'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/interactions/view_micro_interaction/'. $row['interaction_id'] . '/null/1">' . $row['interaction_generic_id'] . '</a>';
            	else
            		$row['interaction_generic_id'] = '<a  href="' . base_url() . 'interactions/view_micro_interaction/'. $row['interaction_id'] . '/1">' . $row['interaction_generic_id'] . '</a>';
	            
	            if($row['org_id'] != '')	            
	            	$row['profile_name'] = $row['org_name'];
	            else
	            	$row['profile_name'] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']);
	            $arrData[] = $row;
	        }
	        return $arrData;
        }
    }

    function getInteractionFilters($arrFilters, $groupByCategory = null) {
    	$userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $userGroupIds = getGroupDetails();
        
        if (empty($arrFilters)) {
            $this->db->select("
				client_users.id AS client_user_id,CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name,
				groups.group_id AS interaction_group_id,groups.group_name AS interaction_group_name,
				interactions_modes.name AS interaction_channel,interactions_modes.id AS interaction_channel_id,
				interaction_grouping.name AS interaction_category, interaction_grouping.id AS interaction_category_id,
				products.id AS interaction_product_id,products.name AS interaction_product,
				interaction_types.id AS interaction_type_id,interaction_types.name AS interaction_type,
				interaction_topics.id AS interaction_topic_id,interaction_topics.name AS interaction_topic,
				interaction_sub_topics.id as interaction_sub_topic_id,interaction_sub_topics.name AS interaction_sub_topic,
				COUNT(DISTINCT interactions.id) AS count", false);
        }
        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
        $this->db->join('interactions_modes', 'interactions_modes.id = interactions.mode', 'left');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        $this->db->join('kols', 'kols.id = interactions_attendees.kol_id', 'left');
        $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
        $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
        $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
        $this->db->join('interaction_sub_topics', 'interaction_sub_topics.id = interactions_discussion_topic_mapped_data.sub_topic_id', 'left');
        $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
        $this->db->join('user_groups', 'user_groups.user_id = interactions.created_by', 'left');
        $this->db->join('groups', 'groups.group_id = user_groups.group_id', 'left');
        if($this->session->userdata('user_role_id')==ROLE_MANAGER){
            
            $group_ids = explode(',',  $userGroupIds['group_ids']);
//             $group_ids = explode(',', $this->session->userdata('group_ids'));           
            $this->db->where_in("user_groups.group_id",$group_ids);
            $this->db->group_by('client_users.id');
        }
        if ($arrFilters['fromDate'] != '' && $arrFilters['toDate'] != '') {
            $fromDate = $arrFilters['fromDate'];
            $toDate = $arrFilters['toDate'];
            $wherBetween = "(interactions.date BETWEEN '$fromDate' AND '$toDate')";
            $this->db->where($wherBetween);
        } else {
            if ($arrFilters != '' && $arrFilters['fromDate'] != null && isset($arrFilters['fromDate']) && sizeof($arrFilters['fromDate']) > 0)
                $this->db->where('interactions.date >=', $arrFilters['fromDate']);
            if ($arrFilters != '' && $arrFilters['toDate'] != null && isset($arrFilters['toDate']) && sizeof($arrFilters['toDate']) > 0)
                $this->db->where('interactions.date <=', $arrFilters['toDate']);
        }

        if ($arrFilters != '' && $arrFilters['channel'] != null && isset($arrFilters['channel']) && sizeof($arrFilters['channel']) > 0 && $groupByCategory != 'interaction_channel')
            $this->db->where_in('interactions_modes.id', $arrFilters['channel']);
        if ($arrFilters != '' && $arrFilters['category'] != null && isset($arrFilters['category']) && sizeof($arrFilters['category']) > 0 && $groupByCategory != 'interaction_category')
            $this->db->where_in('interaction_grouping.id', $arrFilters['category']);
        if ($arrFilters != '' && $arrFilters['product'] != null && isset($arrFilters['product']) && sizeof($arrFilters['product']) > 0 && $groupByCategory != 'interaction_product')
            $this->db->where_in('products.id', $arrFilters['product']);
        if ($arrFilters != '' && $arrFilters['type'] != null && isset($arrFilters['type']) && sizeof($arrFilters['type']) > 0 && $groupByCategory != 'interaction_type')
            $this->db->where_in('interaction_types.id', $arrFilters['type']);
        if ($arrFilters != '' && $arrFilters['topic'] != null && isset($arrFilters['topic']) && sizeof($arrFilters['topic']) > 0)
            $this->db->where_in('interaction_topics.id', $arrFilters['topic']);
        if ($arrFilters != '' && $arrFilters['sub_topic'] != null && isset($arrFilters['sub_topic']) && sizeof($arrFilters['sub_topic']) > 0)
            $this->db->where_in('interaction_sub_topics.id', $arrFilters['sub_topic']);

        if ($groupByCategory == 'interaction_channel') {
            $this->db->select("interactions_modes.name AS interaction_channel,interactions_modes.id AS interaction_channel_id, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->group_by('interactions_modes.id');
            $this->db->order_by('count', 'DESC');
        }

        if ($groupByCategory == 'interaction_category') {
            $this->db->select("interaction_grouping.name AS interaction_category, interaction_grouping.id AS interaction_category_id, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->group_by('interaction_grouping.id');
            $this->db->order_by('count', 'DESC');
        }

        if ($groupByCategory == 'interaction_product') {
            $this->db->select("products.id AS interaction_product_id,products.name AS interaction_product, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->where('products.id IS NOT NULL');
            $this->db->group_by('products.id');
            $this->db->order_by('count', 'DESC');
        }

        if ($groupByCategory == 'interaction_type') {
            $this->db->select("interaction_types.id AS interaction_type_id,interaction_types.name AS interaction_type, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->where('interaction_types.id IS NOT NULL');
            $this->db->group_by('interaction_types.id');
            $this->db->order_by('count', 'DESC');
        }

        if ($groupByCategory == 'interaction_topic') {
            $this->db->select("interaction_topics.id AS interaction_topic_id,interaction_topics.name AS interaction_topic, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->where('interaction_topics.id IS NOT NULL');
            $this->db->group_by('interaction_topics.id');
            $this->db->order_by('count', 'DESC');
        }

        if ($groupByCategory == 'interaction_sub_topic') {
            $this->db->select("interaction_sub_topics.id,interaction_sub_topics.name AS interaction_sub_topic, COUNT(DISTINCT interactions.id) AS count", false);
            $this->db->where('interaction_sub_topics.id IS NOT NULL');
            $this->db->group_by('interaction_sub_topics.id');
            $this->db->order_by('count', 'DESC');
        }
		
    	if($userRole == ROLE_USER){
            $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
            
        }
        $this->db->where('interactions.client_id', $this->session->userdata("client_id"));
        $this->db->group_by('interactions.id');
        $this->db->where('groups.group_type', 'Team');
        $results = $this->db->get("interactions");
//         pr($this->db->last_query());exit;
//			if($groupByCategory=='interaction_topic'){
//				echo $this->db->last_query();
//				exit;
//			}
        $arrData = array();
        foreach ($results->result_array() as $row) {
            $arrData[] = $row;
        }
        return $arrData;
    }

    function getInteractionsMonthlyByChannel($arrFilters) {
        $userGroupName = getGroupDetails();
    	$userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        if (!empty($arrFilters['manager_ids']))
			$users=$this->common_helpers->getManagerAlignedUsers($arrFilters['manager_ids']);
			
        $this->db->query('SET SESSION group_concat_max_len = 1000000');
        $arrMonthData = array();
        if($arrFilters['fromDate'] != '' && $arrFilters['toDate'] != ''){
        	$arrMonths = $this->common_helpers->getMonthAndYerBetweenTwoDates($arrFilters['fromDate'], $arrFilters['toDate']);
        	$arrMonthData['userdata'] = $arrMonths;
        }else if($arrFilters['fromDate'] == '' && $arrFilters['toDate'] == ''){
        	$arrMonths[date("Y")] = array(1,2,3,4,5,6,7,8,9,10,11,12);
			$arrMonthData['userdata'] = $arrMonths;
        }else{
        	if($arrFilters['fromDate'] == ''){
        		$arrFilters['fromDate'] = $this->getFirstDateFromInteractions();
				$arrMonths = $this->common_helpers->getMonthAndYerBetweenTwoDates($arrFilters['fromDate'], $arrFilters['toDate']);
	        	$arrMonthData['userdata'] = $arrMonths;
        	}
        	if($arrFilters['toDate'] == ''){
				$arrFilters['toDate'] = date("Y-m-d");
            	$arrMonths = $this->common_helpers->getMonthAndYerBetweenTwoDates($arrFilters['fromDate'], $arrFilters['toDate']);
	        	$arrMonthData['userdata'] = $arrMonths;
        	}
        }
//			pr($arrMonthData);
//			exit;
		$discTopicJoined = false;
		$product = false;
		$types = false;
		$topics = false;
		$subTopics = false;
        if ($arrFilters['report_type'] == 1) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,interactions_modes.name   AS interaction_channel,";
//				$this->db->join('interactions_modes','interactions_modes.id = interactions.mode','left');
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
            $this->db->group_by("interactions_modes.id");
        }
        if ($arrFilters['report_type'] == 2) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,products.name AS interaction_product,";
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
            $this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
            $this->db->group_by("products.id");
            $discTopicJoined = true;
            $product = true;
        }
        if ($arrFilters['report_type'] == 3) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,";
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
        }
        if ($arrFilters['report_type'] == 4) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,interaction_types.name as interaction_type,";
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
            $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
            $this->db->group_by("interaction_types.id");
            $discTopicJoined = true;
            $types = true;
        }
        if ($arrFilters['report_type'] == 5) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,interaction_topics.name as interaction_topic,";
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
            $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
            $this->db->group_by("interaction_topics.id");
            $discTopicJoined = true;
            $topics = true;
        }
        if ($arrFilters['report_type'] == 6) {
            $queryString = "interactions.id,groups.group_name AS team_name,interaction_grouping.name AS interaction_category,interaction_types.name as interaction_type,interaction_topics.name as interaction_topic,interaction_sub_topics.name as interaction_sub_topic,";
            $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
            $this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
            $this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
            $this->db->join('interaction_sub_topics', 'interaction_sub_topics.id = interactions_discussion_topic_mapped_data.sub_topic_id', 'left');
            $this->db->group_by("groups.group_id");
            $this->db->group_by("interaction_grouping.id");
            $this->db->group_by("interaction_types.id");
            $this->db->group_by("interaction_topics.id");
            $this->db->group_by("interaction_sub_topics.id");
            $discTopicJoined = true;
            $subTopics = true;
            $types = true;
            $topics = true;
         }

        foreach ($arrMonths as $year => $months) {
            foreach ($months as $month) {
                $queryString .= "COUNT(DISTINCT CASE WHEN MONTH(interactions.date) = $month AND YEAR(interactions.date) = $year THEN interactions.id END) AS m" . $month . "_ic" . $year . ",COUNT(DISTINCT CASE WHEN MONTH(interactions.date) = $month  AND YEAR(interactions.date) = $year THEN interactions_attendees.id END) AS m" . $month . "_iac" . $year . ",CAST(SUM(CASE WHEN MONTH(interactions.date) = $month  AND YEAR(interactions.date) = $year THEN interactions.total_attendies END) *COUNT(DISTINCT interactions.id)/COUNT(*) AS SIGNED) AS m" . $month . "_ac" . $year . ",GROUP_CONCAT(DISTINCT CASE WHEN MONTH(interactions.date) = $month  AND YEAR(interactions.date) = $year THEN interactions.id END) AS m" . $month . "_intIds" . $year . ", ";
            }
        }

        $queryString = rtrim($queryString, ',');
        $this->db->select($queryString, false);

        $this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
        $this->db->join('user_groups', 'user_groups.user_id = client_users.id', 'left');
        $this->db->join('groups', 'groups.group_id = user_groups.group_id', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = interactions.grouping', 'left');
        $this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
        $this->db->join('interactions_modes', 'interactions_modes.id = interactions.mode', 'left');

        if ($arrFilters['fromDate'] != '' && $arrFilters['toDate'] != '') {
            $fromDate = $arrFilters['fromDate'];
            $toDate = $arrFilters['toDate'];
            $wherBetween = "(interactions.date BETWEEN '$fromDate' AND '$toDate')";
            $this->db->where($wherBetween);
        } else {
            $this->db->where('YEAR(interactions.date) = YEAR(CURDATE())');
				if($arrFilters != '' && $arrFilters['fromDate']!=null && isset($arrFilters['fromDate']) && sizeof($arrFilters['fromDate'])>0){
					$this->db->where('interactions.date >=',$arrFilters['fromDate']);
				}
				if($arrFilters != '' && $arrFilters['toDate']!=null && isset($arrFilters['toDate']) && sizeof($arrFilters['toDate'])>0){
					$this->db->where('interactions.date <=',$arrFilters['toDate']);
				}
        }
        if ($arrFilters != '' && $arrFilters['channel'] != null && isset($arrFilters['channel']) && sizeof($arrFilters['channel']) > 0)
            $this->db->where_in('interactions_modes.id', $arrFilters['channel']);
        if ($arrFilters != '' && $arrFilters['msl_user'] != null && isset($arrFilters['msl_user']) && sizeof($arrFilters['msl_user']) > 0)
            $this->db->where_in('client_users.id', $arrFilters['msl_user']);
        if ($arrFilters != '' && $arrFilters['category'] != null && isset($arrFilters['category']) && sizeof($arrFilters['category']) > 0)
            $this->db->where_in('interaction_grouping.id', $arrFilters['category']);
            
        if ($arrFilters != '' && $arrFilters['product'] != null && isset($arrFilters['product']) && sizeof($arrFilters['product']) > 0) {
            if (!$discTopicJoined) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
                $discTopicJoined = true;
            }
            if (!$product) {
            	$this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
            	$product = true;
            }
            $this->db->where_in('products.id', $arrFilters['product']);
        }
        if ($arrFilters != '' && $arrFilters['type'] != null && isset($arrFilters['type']) && sizeof($arrFilters['type']) > 0) {
        	if (!$discTopicJoined) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
                $discTopicJoined = true;
            }
            if(!$types){
            	$this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
            	$types = true;
            }
            $this->db->where_in('interaction_types.id', $arrFilters['type']);
        }
        if ($arrFilters != '' && $arrFilters['topic'] != null && isset($arrFilters['topic']) && sizeof($arrFilters['topic']) > 0) {
            if (!$discTopicJoined) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
                $discTopicJoined = true;
            }
            if(!$topics){
            	$this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
            	$topics = true;
            }
            $isTopicsJoined = true;
            $this->db->where_in('interaction_topics.id', $arrFilters['topic']);
        }
        if ($arrFilters != '' && $arrFilters['sub_topic'] != null && isset($arrFilters['sub_topic']) && sizeof($arrFilters['sub_topic']) > 0) {
            if (!$discTopicJoined) {
                $this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
                $discTopicJoined = true;
            }
            if(!$subTopics){
            	$this->db->join('interaction_sub_topics', 'interaction_sub_topics.id = interactions_discussion_topic_mapped_data.sub_topic_id', 'left');
            	$subTopics = true;
            }
            $this->db->where_in('interaction_sub_topics.id', $arrFilters['sub_topic']);
        }
        if ($arrFilters != '' && $arrFilters['team'] != null && isset($arrFilters['team']) && sizeof($arrFilters['team']) > 0) {
            $this->db->where_in('groups.group_id', $arrFilters['team']);
        }
        
    	if (!empty($arrFilters['manager_ids'])) { 
			$this->db->where_in("interactions.created_by", $users);
		}
    	if($userRole == ROLE_USER){
            $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        
//        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $this->db->where('(groups.group_type = "Team")');
        $this->db->join('kols', 'kols.id = interactions_attendees.kol_id', 'left');
        $this->db->join('organizations', 'organizations.id = interactions_attendees.org_id', 'left');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->where('interactions.client_id', $client_id);
        	if($this->session->userdata('user_role_id')==ROLE_MANAGER){
        	    $group_names = explode(',',  $userGroupName['group_names']);
//         		$group_names = explode(',', $this->session->userdata('group_names'));
        		$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
        		$this->db->where_in ( 'countries.GlobalRegion', $group_names);
        	}
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$client_id."') OR organizations.id IS NOT NULL)",'',false);
        }else{
        	$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)");
        }
        $results = $this->db->get("interactions");
//			echo $this->db->last_query();
//			pr($this->db->last_query());
//			exit;
        $arrData = array();
        $i=1;
        foreach ($results->result_array() as $key => $row) {
        	$row['inc'] = $i;
            $arrData[] = $row; $i++;  
        }
        $arrData['userdata'] = $arrMonthData['userdata'];
//        pr($arrData);
//        exit;
        return $arrData;
    }

    function getTopMslForMirf() {
        $arrMsl = array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('count(interaction_mirf.created_by) as entry_count ,client_users.*');
        $this->db->join('client_users', 'client_users.id=interaction_mirf.created_by', 'left');
        $this->db->where('interaction_mirf.created_by IS NOT NULL');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        $this->db->group_by('interaction_mirf.created_by');
        $this->db->order_by('client_users.first_name', 'asc');
        $arrCoachingResultSet = $this->db->get('interaction_mirf');

        foreach ($arrCoachingResultSet->result_array() as $row) {


            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = $row['entry_count'];
            $arrMsl[] = $row;
        }
//              echo $this->db->last_query();
        return $arrMsl;
    }

    function getTeamForMirf() {
        $arrTeam = array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('groups.*');
        
        $this->db->join('user_groups','user_groups.group_id=groups.group_id','left');        
        $this->db->join('client_users', 'client_users.id=user_groups.user_id', 'left');        
        $this->db->where('(groups.group_type = "Team" OR groups.group_type IS NULL)');
         $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        $this->db->group_by('groups.group_name');
        $this->db->order_by('groups.group_name', 'asc');
        $arrResultSet = $this->db->get('groups');
//        echo $this->db->last_query(); exit;
        foreach ($arrResultSet->result_array() as $row) {
            $arrTeam[] = $row;
        }
        return $arrTeam;
    }
    
    function getFirstDateFromInteractions(){
    	$this->db->select("created_on");
    	$this->db->order_by("created_on","ASC");
    	$this->db->limit(1);
    	$results = $this->db->get("interactions");
//    	echo $this->db->last_query();
    	foreach ($results->result_array() as $row){
    		$retData = $row['created_on'];
    	}
    	return $retData;
    	
    }

    
	function getTypeByProduct($id) {
        $arrReturnData = array();
        $this->db->select("interaction_types.id,interaction_types.name");
        $this->db->join('interaction_types', 'interaction_types.id=interaction_type_by_product.type_id', 'left');
        $this->db->where('product_id', $id);
        $this->db->where('interaction_type_by_product.status', 1);
        $this->db->order_by('name', 'ASC');
        $arrResultSet = $this->db->get('interaction_type_by_product');
		$noProdRow = array();
        foreach ($arrResultSet->result_array() as $row) {
                 $arrReturnData[$row['id']] = $row;
        }
        return $arrReturnData; 
    }
    
    function unlockInteractionsById($interId,$flag){
    	$this->db->where('id',$interId);
    	$this->db->set('save_later',$flag);
    	if($this->db->update("interactions"))
    		return true;
    	else
    		return false;
    }
    
    function deleteInteractionsById($interId){
    	
    	$this->db->where("id",$interId);
    	if($this->db->delete("interactions")){
    		//Add Log activity
    		$arrLogDetails = array(
    				'type' => DELET_RECORD,
    				'description' => 'Delete Interactions',
    				'status' => STATUS_SUCCESS,
    				'kols_or_org_type' => 'Kol',
    				'kols_or_org_id' => $kolId,
    				'transaction_id' =>  $interId,
    				'transaction_table_id' => INTERACTIONS,
    				'transaction_name' => "Delete Interactions",
    				'parent_object_id' =>  $kolId
    		);
    		$this->config->set_item('log_details', $arrLogDetails);
    		return true;
    	}else{
    		//Add Log activity
    		$arrLogDetails = array(
    				'type' => DELET_RECORD,
    				'description' => 'Delete Interactions',
    				'status' => STATUS_FAIL,
    				'kols_or_org_type' => 'Kol',
    				'kols_or_org_id' => $kolId,
    				'transaction_id' =>  $interId,
    				'transaction_table_id' => INTERACTIONS,
    				'transaction_name' => "Delete Interactions",
    				'parent_object_id' =>  $kolId
    		);
    		$this->config->set_item('log_details', $arrLogDetails);
    		return false;
    	}
		/* $this->db->where("id",$interId);
		$arrResultSet = $this->db->get("interactions");
		$arrData = array();
		$arrResult = $arrResultSet->result_array();
		foreach($arrResult[0] as $key => $row){
			$arrData[$key] = $row;
		}
		$arrData['deleted_by'] = $this->session->userdata("user_id");
		$arrData['deleted_on'] = date("Y-m-d H:i:s");
		if($this->db->insert("interactions_deleted",$arrData)){
			$this->db->where("id",$interId);
			if($this->db->delete("interactions")){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		} */
    }
   /**
	 * Retrives the all the Interatctions Groups associated with client from lookUp table
	 * @author 	Sumati K
	 * @Created on: 
	 * @since	Mobile 3.0
	 * @return Array
	 */
	function getAllGroupsOfClient($clientId){
		$arrGroups=array();
		//This client id condition will be enabled once we enter a separate values for each client
		//$this->db->where('client_id',$clientId);
		$arrGroupResults=$this->db->get('interaction_grouping');
		foreach($arrGroupResults->result_array() as $row){
			$arrGroups[$row['id']]=$row;
		}
		return $arrGroups;
	}
        
	function getAllAttendeesAutocomplete($kolName,$restrictByRegion=0,$restrictOptInVisbility=0){
	    $userGroupName = getGroupDetails();
		$arrKolDetail=array();
		$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.status,kols.profile_image,kols.org_id,kols.gender,kols.specialty,kols.status');
		$this->db->order_by('first_name');
		//$this->db->like('first_name', $kolName);
		$this->db->like("concat_ws(' ',first_name,middle_name,last_name)",$kolName);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		    if($restrictByRegion==1  && $this->session->userdata('user_role_id') != ROLE_ADMIN && $this->session->userdata('user_role_id') != ROLE_READONLY_USER){
		        $group_names = explode(',',  $userGroupName['group_names']);
// 		        $group_names = explode(',', $this->session->userdata('group_names'));
		        $this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
		        $this->db->where_in( 'countries.GlobalRegion', $group_names);
		    }
		}
		if(KOL_CONSENT && $restrictOptInVisbility==1){
		    $this->db->where('(kols.opt_in_out_status is NULL OR kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$arrKolDetailResult	=	$this->db->get('kols');
		//pr($this->db->last_query());exit;
		foreach($arrKolDetailResult->result_array() as $row){
			$arrKolDetail[]=$row;
		}
		return $arrKolDetail;
	}
	
    function getMyInteractionsForOffline($userId){
    	$clientId = $this->session->userdata('client_id');
    	$arrIntrs = $this->getKolInteractions($clientId, 0, $userId, array(), 10, 0);
    	return $arrIntrs;
    }
    function getInteractionsCountByUsers($kolId,$group_by = false){
        $lastSixMonths = date("Y-m-d", strtotime("-6 months"));
        if($group_by)
            $this->db->select("interactions.created_by,count(interactions.id)");
        else
            $this->db->select("interactions.created_by");
        $this->db->join("interactions","interactions.id = interactions_attendees.interaction_id","left");
        $this->db->where("interactions_attendees.kol_id",$kolId);
        $this->db->where("interactions.date >",$lastSixMonths);
        if($group_by)
            $this->db->group_by("interactions.created_by");
        
        $arrInteractions = $this->db->get('interactions_attendees');
//        echo $this->db->last_query();
        return $arrInteractions->num_rows();
    }
    
    function getDiscussionTypeByProductIds($arrProducts){
        if(!HILLS_SPECIFIC){
        	$arrProductId = array();
        	foreach ($arrProducts as $arrProduct){
        		$arrProductId[] = $arrProduct['id'];
        	}
        	$whereIn =  implode(",",$arrProductId);
        }
    	$this->db->select('distinct(interaction_type_by_product.type_id),interaction_types.name');
    	$this->db->join('interaction_types','interaction_types.id = interaction_type_by_product.type_id','left');
    	if(!HILLS_SPECIFIC){
    	   $this->db->where_in('interaction_type_by_product.product_id',$whereIn);
    	}
    	$query = $this->db->get('interaction_type_by_product');
//     	echo $this->db->last_query();exit;
    	foreach ($query->result_array() as $row) {
    		$arrResult[] = $row;
    	}
    	return $arrResult;
    }
    
    function getTopicsByDiscussionTypesAndProductIds($arrProducts,$arrDiscussionTypes){
    	$arrProductId = array();
    	$arrDiscussionTypeId = array();
    	foreach ($arrProducts as $arrProduct){
    		$arrProductId[] = $arrProduct['id'];
    	}
    	$whereInProduct =  implode(",",$arrProductId);
    	 
    	foreach ($arrDiscussionTypes as $arrDiscussionType){
    		$arrDiscussionTypeId[] = $arrDiscussionType['type_id'];
    	}
    	$whereInDiscussionType =  implode(",",$arrDiscussionTypeId);
    	 
    	 
    	$arrTopics = array();
    	$this->db->select("distinct(interaction_topics.id),interaction_topics.name");
    	$this->db->join('interaction_topics', 'interaction_topics.id=interaction_topics_by_type.topic_id', 'left');
    	$this->db->where_in('interaction_topics_by_type.product_id ', $whereInProduct);
    	//$this->db->where_in('interaction_topics_by_type.type_id ', $whereInDiscussionType);
    	$this->db->where('interaction_topics.status ', 1);
    	$this->db->order_by("interaction_topics.name");
    	$arrResults = $this->db->get('interaction_topics_by_type');
    	foreach ($arrResults->result_array() as $row) {
    		//check if the topic is 'Other' and add it last in the list
    		if($row['name'] != 'Other'){
    			$arrTopics1[] = $row;
    		}else{
    			$arrTopics2[] = $row;
    		}
    	}
    	if(!empty($arrTopics2)){
    		$arrTopics = array_merge($arrTopics1,$arrTopics2);
    	}else{
    		$arrTopics = $arrTopics1;
    	}
    	//print $this->db->last_query();
    	return $arrTopics;
    }
    
    function getTopicsByDiscussionTypeId($typeId){
    	$arrId = array();
    	$arrResult = array();
    	$this->db->select("distinct(interaction_topics_by_type.topic_id)");
    	$this->db->where('interaction_topics_by_type.type_id', $typeId);
    	$arrResults = $this->db->get('interaction_topics_by_type');
    	foreach ($arrResults->result_array() as $row) {
    		$arrId[] = $row['topic_id'];
    	}
    	 
    	$this->db->select('interaction_topics.id,interaction_topics.name');
    	$this->db->where_in('interaction_topics.id', $arrId);
    	$this->db->order_by('interaction_topics.name');
    	$query = $this->db->get('interaction_topics');
    
    	foreach ($query->result_array() as $row2) {
    		if($row2['name'] != 'Other'){
    			$arrTopics1[] = $row2;
    		}else{
    			$arrTopics2[] = $row2;
    		}
    	}
    	if(!empty($arrTopics2)){
    		$arrTopics = array_merge($arrTopics1,$arrTopics2);
    	}else{
    		$arrTopics = $arrTopics1;
    	}
    	return $arrTopics;
    }
    function saveProductOrDiscussionTypeOrTopic($name,$tableName){
        $data = array();
        $get = $this->db->get_where($tableName,array("name"=>ucfirst($name)));
        if($get->num_rows()==0){
            $userId = $this->session->userdata('user_id');
            $this->db->insert($tableName,array("name"=>ucfirst($name),"status"=>1,"created_by"=>$userId));
            return $this->db->insert_id(); 
        }else{
            return false;
        }
    }
    function getAllKeyPeoplesForAutocomplete($keyName,$organizationId) {
    	
    	$kolName = str_replace ( ",", " ", $keyName );
    	$kolName = preg_replace ( '!\s+!', ' ', $keyName );
    	$kolName = $this->db->escape_like_str ( $keyName );
    	$this->db->select(array('key_peoples.*','key_people_roles.role','client_users.client_id'));
    	$this->db->join('key_people_roles','key_people_roles.id = key_peoples.role_id', 'left');
    	$this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
    	$this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
    	//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
    	$this->db->where('replace(concat(coalesce(key_peoples.first_name,"")," ",coalesce(key_peoples.middle_name,"")," ",coalesce(key_peoples.last_name,"")),"  "," ") like "%'.$keyName.'%"', '',false);
    	$this->db->where('key_peoples.org_id', $organizationId);
//     	$this->db->like("concat(key_peoples.first_name,key_peoples.middle_name,key_peoples.last_name)", $keyName);
    	$nameFormat = $this->session->userdata('name_order');
    	if ($nameFormat == 1 || $nameFormat == 3)
    		$this->db->order_by("key_peoples.first_name",'asc');
    		else if ($nameFormat == 2)
    			$this->db->order_by("key_peoples.last_name",'asc');
    			$arrKeyPeopleDetailsResult = $this->db->get ('key_peoples');
    			return $arrKeyPeopleDetailsResult->result_array();
    }
    
    function getKepPeopleTitle($keyId){
    	$arrKeyDetails = array();
    	$this->db->where('id',$keyId);
    	$query = $this->db->get('key_peoples');
    	foreach ($query->result_array() as $row) {
    				$arrKeyDetails[] = $row;
    	}
    	return $arrKeyDetails;
    }
    
    /**
     *  GET Organization details of the Specified Id
     * @param
     * @return array - $arrOrgDetail - Returns
     */
    function getOrgLocaionDetailsById($orgId) {
    	$arrKolDetails = array();
    	$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
    	$this->db->where('organizations.id', $orgId);
    	$this->db->select(array('organizations.*', 'countries.Country', 'regions.Region', 'cities.City'));
    	$this->db->join('countries', 'countries.CountryId = organizations.country_id', 'left');
    	$this->db->join('regions', 'regions.RegionId = organizations.state_id', 'left');
    	$this->db->join('cities', 'cities.cityId = organizations.city_id', 'left');
    	$arrKolDetailsResult = $this->db->get('organizations');
    	foreach ($arrKolDetailsResult->result_array() as $row) {
    				$arrKolDetails[] = $row;
    	}
    	return $arrKolDetails;
    }
    function getAssignedUsersForType($id, $type){
	$client_id = $this->session->userdata('client_id');
    	$arrUsersDetails = array();
    	 if($type == 'org'){
		    	 	$this->db->select("user_orgs.user_id, client_users.email");
		    	 	$this->db->select("organizations.name as typename");
		    	 	$this->db->join('client_users', 'client_users.id = user_orgs.user_id', 'left');
		    	 	$this->db->join('organizations', 'organizations.id = user_orgs.org_id', 'left');
		    	 	$this->db->where('user_orgs.org_id', $id);
		    	 	if($client_id !== INTERNAL_CLIENT_ID){
					   $this->db->where('client_users.client_id', $client_id);
		    	 	}
					$query = $this->db->get('user_orgs');
    			}else{ 
		    		$this->db->select("user_kols.user_id, client_users.email");
		    		$this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
		    		$this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
		    		$this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
		    		$this->db->where('user_kols.kol_id', $id); 
		    		if($client_id !== INTERNAL_CLIENT_ID){
		    		    $this->db->where('client_users.client_id', $client_id);
		    		}
		    		$query = $this->db->get('user_kols');	 
    		} 
    	$result = $query->result();
    	foreach($result as $row){
    		$typeName = $row->typename;
    		$userEmails[] =  $row->email;
    	}	
    	$arrUsersDetails['type_name'] = $typeName;
    	$arrUsersDetails['user_details'] = $userEmails;
    	 
    	return $arrUsersDetails;
    }
    function updateCreatedDate(){
    	$this->db->select("interactions.id as interactionId, interactions.date as interactionDate");
    	$query = $this->db->get("interactions");
    	foreach($query->result_array() as $row){
    		$this->db->set('created_on', $row['interactionDate'], FALSE);
    		$this->db->where('id', $row['interactionId']);
    		$this->db->update('interactions');
    	}
    	return true;
    }
    
    function getManagerName(){
        $userId = $this->session->userdata('user_id');
        $this->db->select('concat(client_manger.first_name," ",client_manger.last_name) as manager_name',false);
        $this->db->join("client_users as client_manger","client_manger.id = client_users.manager_id");
        $this->db->where('client_users.id',$userId);
        $query2 = $this->db->get('client_users');
        $user_data2 = $query2->row_array();
        return $user_data2['manager_name'];
    }
    
}