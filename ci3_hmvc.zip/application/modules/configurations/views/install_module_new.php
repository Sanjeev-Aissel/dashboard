<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<?php echo $html_form; ?>
<span id="responseMessageOfModuleInstal"></span>
<script type="text/javascript">
var validationRules	=  {
	module_import: {
		 accept: "zip",
		 required:true
     }
};
var validationMessages = {
	module_import: {
		accept:"Invalid file type,Only '.zip' files are allowed"
	}
};
$(document).ready(function(){
	$("#moduleImportForm").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>