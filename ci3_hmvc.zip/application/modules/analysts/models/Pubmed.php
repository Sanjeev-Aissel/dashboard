<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for publication from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 13-06-2018
 * @Refactored : 13-06-2018
 */
class pubmed extends CI_Model {
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolDetail()
	 * @param  : $kolId
	 * @return : $kolDetail
	 */
	function getKolDetail($kolId){
		$kolDetail=array();
		$this->db->where('id',$kolId);
		$kolDetail=$this->db->get('kols');
		$kolDetail=$kolDetail->row_array();
		return 	$kolDetail;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getPubmedUnprocessedKols()
	 * @param  : none
	 * @return : $arrKolDetails
	 */
	function getPubmedUnprocessedKols(){
		$arrKolDetails=array();
		$arrStatus = array(0);
		$this->db->select("id,salutation,first_name,middle_name,last_name,specialty");
		$this->db->where_in('is_pubmed_processed',$arrStatus);
		$this->db->where('kols.status',PROFILING);
		$this->db->order_by("created_on", "asc");
		$arrKolDetailResult=$this->db->get('kols');
		foreach($arrKolDetailResult->result_array() as $arrKol){
			$arrKolDetails[]= $arrKol;
		}
		//echo $this->db->last_query();
		return $arrKolDetails;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolNameCombinations()
	 * @param  : $kolId
	 * @return : $arrNameCombinations
	 */
	function getKolNameCombinations($kolId){
		$this->load->helper('text');
		$arrNameCombinations = array();
		$this->db->select('name');
		$this->db->where('kol_id',$kolId);
		$results = $this->db->get('kol_name_combinations');
		if(is_object($results) && $results->num_rows() > 0){
			foreach($results->result_array() as $row){
				$arrNameCombinations[] = ascii_to_entities($row['name']);
			}
		}
		return $arrNameCombinations;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : generate_name_combinations()
	 * @param  : $firsName, $midleName, $lastName
	 * @return : $arrName
	 */
	function generate_name_combinations($firsName, $midleName, $lastName){
	
		$firstName = $firsName;
		$middleName = $midleName;
		$lastName = $lastName;
	
		$firstNameInitial = substr($firstName, 0, 1);
		$middleNameInitial = substr($middleName, 0, 1);
		$middleNameLength = strlen($middleName);
	
		$lastNameInitial = substr($lastName, 0, 1);
	
		$arrName= array();
		if($firstName!="" && $middleName=="" && $lastName!=""){
			//echo "<h3>Case : 1 </h3>";
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
				
		}
		if($firstName!="" && $middleNameLength==1 && $lastName!=""){
			//echo "<h3>Case : 2 </h3>";
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			//Added when finding the kol from the co authors
			$arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
			$arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
		}
			
		if($firstName!="" && $middleNameLength!=1 &&$middleName!="" && $lastName!=""){
			//echo "<h3>Case : 3 </h3>";
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleName;
			$arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
			$arrName[] = $lastName." ".$middleName." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			//Added when finding the kol from the co authors
			$arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
			$arrName[] = $firstName." ".$middleName." ".$lastName;
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleName;
	
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
			$arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
		}
			
		return $arrName;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkPubExist()
	 * @param  : $pmid
	 * @return : $pubId
	 */
	function checkPubExist($pmid){
		$pubId='';
		$this->db->select('id');
		$this->db->where('pmid',$pmid);
		$arrPubs=$this->db->get('publications');
		if($arrPubs->num_rows()!=0){
			$pubObj=$arrPubs->first_row();
			$pubId=$pubObj->id;
		} else {
				
		}
		return $pubId;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkKolPubAssociationExist()
	 * @param  : $kolPublication
	 * @return : true : update | false : failure
	 */
	function checkKolPubAssociationExist($kolPublication){
		$this->db->select('id');
		$this->db->where('kol_id',$kolPublication['kol_id']);
		$this->db->where('pub_id',$kolPublication['pub_id']);
		$arrPublicationAssoc=$this->db->get('kol_publications');
		if($arrPublicationAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveKolPublication()
	 * @param  : $kolPublication
	 * @return : true : inserted | false : failure
	 */
	function saveKolPublication($kolPublication){
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$kolPublication['data_type_indicator'] = $dataType;
		if(isset($userId) && $userId != ''){
			$kolPublication['client_id'] = $clientId;
			$kolPublication['user_id'] = $userId;
		}else{
			$kolPublication['client_id'] = INTERNAL_CLIENT_ID;
			$kolPublication['user_id'] = INTERNAL_USER_ID;
		}
	
		if($this->db->insert('kol_publications',$kolPublication)){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : savePubmedMeshTerm()
	 * @param  : $term
	 * @return : $termId
	 */
	function savePubmedMeshTerm($term){
		$termId='';
		$this->db->select('id');
		$this->db->where('term_name',$term['term_name']);
		$this->db->where('parent_id',$term['parent_id']);
		$arrMeshTerms=$this->db->get('pubmed_mesh_terms');
		if($arrMeshTerms->num_rows()!=0){
			$meshTermObj=$arrMeshTerms->first_row();
			$termId=$meshTermObj->id;
		} else{
			if($this->db->insert('pubmed_mesh_terms',$term)){
				$termId=$this->db->insert_id();
				//Add Log activity
				/* $arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New MeshTerm record',
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $termId,
						'transaction_table_id' => PUBMED_MESH_TERMS,
						'transaction_name' => 'Add New MeshTerm',
						'parent_object_id' =>  $termId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true ); */
			}else{
				//Add Log activity
				/* $arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New MeshTerm record',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $termId,
						'transaction_table_id' => PUBMED_MESH_TERMS,
						'transaction_name' => 'Add New MeshTerm',
						'parent_object_id' =>  $termId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true ); */
				 
			}
		}
		return $termId;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : updateKolPublication()
	 * @param  : $kolPublication
	 * @return : true : updated | false : failure
	 */
	function updateKolPublication($kolPublication){
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrKolPubDetail['data_type_indicator'] = $dataType;
		$arrKolPubDetail['is_verified']	= $kolPublication['is_verified'];
		$arrKolPubDetail['is_deleted']	= $kolPublication['is_deleted'];
		$this->db->where('kol_id', $kolPublication['kol_id']);
		$this->db->where('pub_id', $kolPublication['pub_id']);
		if($this->db->update('kol_publications', $arrKolPubDetail)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAuthorshipPos()
	 * @param  : $pubId,$firstName,$lastName
	 * @return : $pos
	 */
	function getAuthorshipPos($pubId,$firstName,$lastName){
		$pos='';
		$this->db->select('publications_authors.position');
		$this->db->from('pubmed_authors');
		$this->db->join('publications_authors', 'publications_authors.author_id = pubmed_authors.id','left');
		$this->db->where('pub_id', $pubId);
		$this->db->where('last_name', $firstName);
		$where="(fore_name=\"".$lastName."\" OR initials=\"".$lastName."\")";
		$this->db->where($where);
		$arrAuthorsResult = $this->db->get();
		// 		pr($this->db->last_query());
		if($arrAuthorsResult && $arrAuthorsResult->num_rows()!=0){
			$arrAuthor=$arrAuthorsResult->row_array();
			$pos=$arrAuthor['position'];
		} else {
				
		}
		return 	$pos;
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : calculateAuthorShipPosition()
	 * @param  : $pubId,$kolId,$arrKolDetail
	 * @return : true : updated | false : failure
	 */
	function calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail){
		$position='';
		if($arrKolDetail==null)
			$arrKolDetail=$this->getKolDetail($kolId);
			// get the name details
			$firstName=$arrKolDetail['first_name'];
			$midleName=$arrKolDetail['middle_name'];
			$lastName=$arrKolDetail['last_name'];
			$kolId=$arrKolDetail['id'];
	
			//get the different combinations of names
			$arrNameCombinations=$this->generate_name_combinations($firstName, $midleName, $lastName);
			foreach($arrNameCombinations as $nameCombination){
				$arrName=explode(" ", $nameCombination);
				if(sizeof($arrName)==2){
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]);
				}
				else{
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]." ".$arrName[2]);
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]."".$arrName[2]);
				}
			}
			$position;
			// 		pr($arrPos);
			foreach($arrPos as $pos){
				if($pos!='')
					$position=$pos;
			}
			// save the authorsip position in the kol_publications table, later remove this from this function
			//$this->updateAuthorshipPos($kolId,$pubId,$position);
			//echo $position;
			return $position;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateAuthorshipPos()
	 * @param  : $kolId,$pubId,$position
	 * @return : true : updated | false : failure
	 */
	function updateAuthorshipPos($kolId,$pubId,$position){
		$kolPublication=array();
		$kolPublication['auth_pos']=$position;
		//$kolPublication['kol_id']=$kolId;
		//$kolPublication['pub_id']=$pubId;
	
		$this->db->where('kol_id', $kolId);
		$this->db->where('pub_id', $pubId);
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkAndAssociateAlreadyExistPubs()
	 * @param  : $arrUniquePMIDs, $kolId, $arrKolDetail,$isVerfied
	 * @return : true : updated | false : failure
	 */
	function checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId, $arrKolDetail,$isVerfied=0){
		$arrCount=sizeof($arrUniquePMIDs);
		for($i=0;$i<$arrCount; $i++){
			$pmid=$arrUniquePMIDs[$i];
			$pubId=$this->checkPubExist($pmid);
			if($pubId!=''){
				//echo 'Publication with PMID:'.$pmid.' already exist and it is Associated to KolId :'.$kolId.'</br>';
				$kolPublication=array();
				$kolPublication['kol_id']		= $kolId;
				$kolPublication['pub_id']		= $pubId;
				//Save the association only if it is not exist
				$kolPublication['is_verified']	= $isVerfied;
				$kolPublication['is_deleted']	= 0;
				if(!$this->checkKolPubAssociationExist($kolPublication)){
					$isSaved=$this->saveKolPublication($kolPublication);
				}else if($isVerfied){
					$isSaved=$this->updateKolPublication($kolPublication);
				}
				unset($arrUniquePMIDs[$i]);
					
				//Calculate Authorship position and save
				$position=$this->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				$this->updateAuthorshipPos($kolId,$pubId,$position);
				//echo "already exists PMID-".$pmid." Pub ID-".$pubId." Position-".$position;
			}
		}
		$arrUniquePMIDs=array_values($arrUniquePMIDs);
		//pr($arrUniquePMIDs);
		return $arrUniquePMIDs;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updatePubmedProcessedKol()
	 * @param  : $arrKolDetail
	 * @return : none
	 */
	function updatePubmedProcessedKol($arrKolDetail){
		$kolDetail['is_pubmed_processed']=	$arrKolDetail['is_pubmed_processed'];
		$this->db->where('id', $arrKolDetail['id']);
		$this->db->update('kols', $kolDetail);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateZeroAuthPosPubsAsDeleted()
	 * @param  : $kolId
	 * @return : id of last effect row
	 */
	function updateZeroAuthPosPubsAsDeleted($kolId){
		$arrResults = $this->db->query("UPDATE kol_publications SET is_deleted = 1,is_verified = 0 WHERE id IN
				(
				SELECT id FROM
				(
				SELECT kol_publications.id
				FROM kol_publications WHERE auth_pos = 0 AND kol_id = $kolId
				) AS pudsasdeleted
				)
				");
		return $this->db->affected_rows();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : savePublication()
	 * @param  : $pubDetails,$publicationId
	 * @return : if inserted $pubId | updates
	 */
	function savePublication($pubDetails,$publicationId=0){
		if($publicationId==0){
			$pubId='';
			if($this->db->insert('publications',$pubDetails)){
				$pubId=$this->db->insert_id();
			}else{
	
			}
			return $pubId;
		}else{
			$this->db->update("publications",$pubDetails,array("id"=>$publicationId));
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getNumberOfAuthors()
	 * @param  : $pubId
	 * @return : $numAuthors
	 */
	function getNumberOfAuthors($pubId){
		$numAuthors = 0;
		$this->db->where('pub_id',$pubId);
		$numAuthors=$this->db->count_all_results('publications_authors');
		return $numAuthors;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : deletePublicationAssociationDetails()
	 * @param  : $pubId
	 * @return : none
	 */
	function deletePublicationAssociationDetails($pubId){
		//Delete authors
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publications_authors');
	
		//Delete MEshTerms
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publication_mesh_terms');
	
		//Delete Substances
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publication_substances');
	
		//Delete Publication types
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publications_types');
	
		//Deelete CC
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publications_cc');
	
		//Delete Artcile Ids
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publication_article_ids');
	
		//Delete History
		$this->db->where('pub_id',$pubId);
		$this->db->delete('publication_history');
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getPubmedRecrawlKols()
	 * @param  : none
	 * @return : $arrKolDetails
	 */
	function getPubmedRecrawlKols(){
		$arrKolDetails=array();
		$arrStatus = array(2);
		$this->db->select("id,salutation,first_name,middle_name,last_name,specialty");
		$this->db->where_in('is_pubmed_processed',$arrStatus);
		$this->db->where('kols.status',PROFILING);
		$this->db->order_by("created_on", "asc");
		$arrKolDetailResult=$this->db->get('kols');
		foreach($arrKolDetailResult->result_array() as $arrKol){
			$arrKolDetails[]= $arrKol;
		}
		return $arrKolDetails;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getPMIDs()
	 * @param  : $kolId
	 * @return : $arrPMIDs
	 */
	function getPMIDs($kolId){
		$arrPMIDs = array();
		$this->db->select('pmid');
		$this->db->where('kol_id',$kolId);
		$arrResults = $this->db->get('kol_pmids');
		foreach($arrResults->result_array() as $row){
			$arrPMIDs[] = $row['pmid'];
		}
	
		return $arrPMIDs;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : savePubmedPubType()
	 * @param  : $type
	 * @return : $typeId
	 */
	function savePubmedPubType($type){
		$typeId='';
		$this->db->where('type',$type['type']);
		$arrPubTypes=$this->db->get('pubmed_publications_types');
		if($arrPubTypes->num_rows()!=0){
			$pubTypeObj=$arrPubTypes->first_row();
			$typeId=$pubTypeObj->id;
		} else{
			if($this->db->insert('pubmed_publications_types',$type)){
				$typeId=$this->db->insert_id();
				//Add Log activity
				/* $arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New Publication type record',
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'transaction_id' => $typeId,
						'transaction_table_id' => PUBMED_PUBLICATIONS_TYPES,
						'transaction_name' => 'Add New Publication type',
						'parent_object_id' => $typeId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true ); */
			}else{
				//Add Log activity
				/* $arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New Publication type record',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $typeId,
						'transaction_table_id' => PUBMED_PUBLICATIONS_TYPES,
						'transaction_name' => 'Add New Publication type',
						'parent_object_id' =>  $typeId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true ); */
			}
		}
		return $typeId;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : savejournalName()
	 * @param  : $journalName
	 * @return : $journalId
	 */
	function savejournalName($journalName){
		$journalId='';
		$arrJournal['name']=$journalName;
		$this->db->where('name',$journalName);
		if($arrJournals=$this->db->get('pubmed_journals')){
			if($arrJournals->num_rows()!=0){
				$journalObj=$arrJournals->first_row();
				$journalId=$journalObj->id;
			}
			else {
				if($this->db->insert('pubmed_journals',$arrJournal)){
					$journalId=$this->db->insert_id();
				}else{
			   
				}
			}
		}
		return $journalId;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : savePublicationType()
	 * @param  : $pubType
	 * @return : true : if exist or inserted  | flase : failure 
	 */
	function savePublicationType($pubType){
		$this->db->select('id');
		$this->db->where('pub_id',$pubType['pub_id']);
		$this->db->where('pub_type_id',$pubType['pub_type_id']);
		$resultSet	= $this->db->get('publications_types');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('publications_types',$pubType)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolPubsYearsRange()
	 * @param  : $kolId
	 * @return : $arrYears
	 */
	function getKolPubsYearsRange($kolId){
		$arrYears=array();
		$client_id = $this->session->userdata('client_id');
		$where="";
		if($client_id !== INTERNAL_CLIENT_ID){
			$where = "AND (kol_publications.client_id = $client_id or kol_publications.client_id = 1)";
		}
		$arrResults=$this->db->query("SELECT MIN(YEAR(publications.created_date)) AS min_year,MAX(YEAR(publications.created_date)) AS max_year
									FROM publications
									LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
									WHERE kol_publications.kol_id=".$kolId." AND kol_publications.is_deleted=0 AND YEAR(publications.created_date)!=0
				$where");
		//pr($this->db->last_query());exit;
		foreach($arrResults->result_array() as $row){
			$arrYears['min_year']=$row['min_year'];
			$arrYears['max_year']=$row['max_year'];
		}
		return $arrYears;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolPubsWithSingleAuthor()
	 * @param  : $kolId,$start,$end,$arrKolIds,$arrCountries,$arrSpecialities,$arrListNamesIds,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds
	 * @return : $arrYears
	 */
	function getKolPubsWithSingleAuthor($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds = 0){
		$arrPublicationsDetail=array();
	
		$queryString="SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE ";
		$this->db->select("kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
				
			//Adding where condition for Kol's if Exist
			if(is_array($arrKolIds) && $arrKolIds!=0){
				//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
			}else if($arrKolIds!=0){
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
			}
	
			//Adding where condition for Global Region's if Exist
			if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			}else if($arrGlobalRegionIds!=0){
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
				$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
			}
	
			//Adding where condition for Country's if Exist
			if(is_array($arrCountries) && $arrCountries!=0){
				//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
				$this->db->where_in('kols.country_id',$arrCountries);
				//$queryString	.= " AND kols.country_id IN($commaCountries) ";
			}else if($arrCountries!=0){
				$this->db->where_in('kols.country_id',$arrCountries);
				$queryString	.= " AND kols.country_id='$arrCountries' ";
			}
	
			//Adding where condition for Speciality's if Exist
			if(is_array($arrSpecialities) && $arrSpecialities!=0){
				$commaSpecialities=$this->common_helper->convertArrayToCommaSeparatedElements($arrSpecialities);
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
			}else if($arrSpecialities!=0){
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
			}
			if(is_array($arrStatesIds) && $arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}else if($arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}
			if($profileType!=0){
				$this->db->where('kols.profile_type',$profileType);
			}
			if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}else if($viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}
				
			if($arrListNamesIds!=''  && $arrListNamesIds!=0){
				$userId=$this->session->userdata('user_id');
				$clientId=$this->session->userdata('client_id');
				$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
				$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
				$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
				$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
				$this->db->where_in('list_names.id',$arrListNamesIds);
			}
			$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)");
			if($start!=0 && $end!=0){
				//$this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
				$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
			}
	
	
			if($keyword!=''){
				$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
				$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
				$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
				$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
				$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
					
			}
			$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id HAVING num_auths=1');
	
			//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
			//GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths=1";
	
			$arrPublications = $this->db->get('publications_authors' );
			//pr($this->db->last_query());exit;
			foreach($arrPublications->result_array() as $row){
					
				$arrPublicationsDetail[]=$row;
			}
	
			return $arrPublicationsDetail;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolPubsWithFirstAuthorship()
	 * @param  : $kolId,$start,$end,$arrKolIds,$arrCountries,$arrSpecialities,$arrListNamesIds,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds
	 * @return : $arrPublicationsDetail
	 */
	function getKolPubsWithFirstAuthorship($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds = 0){
		$arrPublicationsDetail=array();
	
		$queryString="SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country=countries.countryId
											WHERE";
		$this->db->select("kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
				
			//Adding where condition for Kol's if Exist
			if(is_array($arrKolIds) && $arrKolIds!=0){
				//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
			}else if($arrKolIds!=0){
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
			}
	
			//Adding where condition for Global Region's if Exist
			if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
				//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			}else if($arrGlobalRegionIds!=0){
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
				$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
			}
	
			//Adding where condition for Country's if Exist
			if(is_array($arrCountries) && $arrCountries!=0){
				//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
				$this->db->where_in('kols.country_id',$arrCountries);
				//$queryString	.= " AND kols.country_id IN($commaCountries) ";
			}else if($arrCountries!=0){
				$this->db->where_in('kols.country_id',$arrCountries);
				$queryString	.= " AND kols.country_id='$arrCountries' ";
			}
	
			//Adding where condition for Speciality's if Exist
			if(is_array($arrSpecialities) && $arrSpecialities!=0){
				$commaSpecialities=$this->common_helper->convertArrayToCommaSeparatedElements($arrSpecialities);
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
			}else if($arrSpecialities!=0){
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
			}
			if(is_array($arrStatesIds) && $arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}else if($arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}
			if($profileType!=0){
				$this->db->where('kols.profile_type',$profileType);
			}
			if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}else if($viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}
			if($arrListNamesIds!='' && $arrListNamesIds!=0){
				$userId=$this->session->userdata('user_id');
				$clientId=$this->session->userdata('client_id');
				$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
				$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
				$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
				$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
				$this->db->where_in('list_names.id',$arrListNamesIds);
			}
	
			$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1) AND kol_publications.auth_pos=1");
			if($start!=0 && $end!=0)
				$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
				//$this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
				if($keyword!=''){
					$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
					$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
					$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
					$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
					$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
						
				}
				$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1');
	
	
				//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND kol_publications.auth_pos=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
				//GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1";
	
				$arrPublications = $this->db->get('publications_authors');
				//	$arrPublications = $this->db->query($queryString);
				//echo $this->db->last_query();
				foreach($arrPublications->result_array() as $row){
						
					$arrPublicationsDetail[]=$row;
				}
				return $arrPublicationsDetail;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolPubsWithLastAuthorship()
	 * @param  : $kolId,$start,$end,$arrKolIds,$arrCountries,$arrSpecialities,$arrListNamesIds,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds
	 * @return : $arrPublicationsDetail
	 */
	function getKolPubsWithLastAuthorship($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType){
		$arrPublicationsDetail=array();
		$queryString="SELECT kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON publications_authors.pub_id=kol_publications.pub_id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE";
		$this->db->select("kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
				
			//Adding where condition for Kol's if Exist
			if(is_array($arrKolIds) && $arrKolIds!=0){
				//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
			}else if($arrKolIds!=0){
				$this->db->where_in('kol_publications.kol_id',$arrKolIds);
				//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
			}
			//Adding where condition for Global Region's if Exist
			if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			}else if($arrGlobalRegionIds!=0){
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
				$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
			}
			//Adding where condition for Country's if Exist
			if(is_array($arrCountries) && $arrCountries!=0){
				//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
				$this->db->where_in('kols.country_id',$arrCountries);
				//$queryString	.= " AND kols.country_id IN($commaCountries) ";
			}else if($arrCountries!=0){
				$this->db->where_in('kols.country_id',$arrCountries);
				$queryString	.= " AND kols.country_id='$arrCountries' ";
			}
	
			//Adding where condition for Speciality's if Exist
			if(is_array($arrSpecialities) && $arrSpecialities!=0){
				$commaSpecialities=$this->common_helper->convertArrayToCommaSeparatedElements($arrSpecialities);
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
			}else if($arrSpecialities!=0){
				$this->db->where_in('kols.specialty',$arrSpecialities);
				//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
			}
			if(is_array($arrStatesIds) && $arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}else if($arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}
			if($profileType!=0){
				$this->db->where('kols.profile_type',$profileType);
			}
			if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}else if($viewType!=0 && !empty($viewType)){
				$this->db->where_in('kols.id',$viewType);
			}
			if($arrListNamesIds!=''  && $arrListNamesIds!=0){
				$userId=$this->session->userdata('user_id');
				$clientId=$this->session->userdata('client_id');
				$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
				$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
				$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
				$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
				$this->db->where_in('list_names.id',$arrListNamesIds);
			}
	
			$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)");
			if($start!=0 && $end!=0)
				$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
				if($keyword!=''){
					$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
					$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
					$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
					$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
					$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
						
				}
				$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id');
	
				//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
				//GROUP BY kol_publications.kol_id,publications_authors.pub_id";
				$arrPublications = $this->db->get('publications_authors');
				//$arrPublications = $this->db->query($queryString);
				//echo $this->db->last_query();
				foreach($arrPublications->result_array() as $row){
						
					$arrPublicationsDetail[]=$row;
				}
				return $arrPublicationsDetail;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : getPublicationChart()
	 * @Param  : $kolId, $fromYear, $toYear, $keyword
	 * @return : $arrPublications
	 */
	function getPublicationChart($kolId, $fromYear, $toYear, $keyword) {
		$arrPublications = array();
		$this->db->select('year(created_date) as year,count(distinct kol_publications.pub_id) as count');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');
		if ($keyword != '') {
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
			$this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
			$this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
	
		$this->db->where('kol_id', $kolId);
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified', 1);
		if ($fromYear != 0 && $toYear != 0)
			$this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
			$this->db->group_by('year(created_date)');
			$this->db->order_by('year(created_date)', 'desc');
			//$this->db->limit('15');
	
			$arrPublicationsResult = $this->db->get('publications');
			foreach ($arrPublicationsResult->result_array() as $row) {
				$arrPublications[] = $row;
			}
			//pr($arrPublications);
			return $arrPublications;
	}
	
	/**
	 * Model functions for Organization module Scripts Starts
	 * @Author : Sanjeev K
	 * @Method : listPublicationDetailsForAnalyst()
	 * @Param  : $orgId,$type
	 * @return : $arrPublications
	 */
	function listPublicationDetailsForAnalyst($orgId,$type){
		$arrPublications=array();
		$this->db->select('publications.*,org_publications.id as asoc_id');
		$this->db->from('publications');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->where('org_id', $orgId);
		if($type=='unVerified'){
			$this->db->where('org_publications.is_deleted', 0);
			$this->db->where('org_publications.is_verified', 0);
		}else if($type=='verified'){
			$this->db->where('org_publications.is_deleted', 0);
			$this->db->where('org_publications.is_verified', 1);
		}else{
			$this->db->where('org_publications.is_verified', 0);
			$this->db->where('org_publications.is_deleted', 1);
		}
		$this->db->distinct();
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}
		//echo $this->db->last_query();
		return 	$arrPublications;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updatePublicationAsDeleted()
	 * @Param  : $id
	 * @return : Boolean -> true : updated | false : failure
	 */
	function updatePublicationAsDeleted($id){
		$orgPublication['is_deleted']=1;
		$orgPublication['is_verified']=0;
		$this->db->where('id', $id);
		if($this->db->update('org_publications', $orgPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updatePublicationAsVerified()
	 * @Param  : $id,$orgPublication
	 * @return : Boolean -> true : updated | false : failure
	 */
	function updatePublicationAsVerified($id,$orgPublication){
		$this->db->where('id', $id);
		if($this->db->update('org_publications', $orgPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgCoAuthors()
	 * @Param  : $orgId
	 * @return : $arrCoAuthos
	 */
	function getOrgCoAuthors($orgId){
		$arrCoAuthos=array();
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//This code is commented in order to allow the KOL name combinations also in name disambiguation
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$where2="!((last_name='Not Available' ) and (fore_name='Not Available'))";
		$this->db->where($where2);
		$this->db->where('publications_authors.position',1);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
	
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			$arrCoAuthos[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgProcessedCoAuthors()
	 * @Param  : $orgId
	 * @return : $arrProceCoAuths
	 */
	function getOrgProcessedCoAuthors($orgId){
		$arrProceCoAuths=array();
		$this->db->select('pubmed_authors.*');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('publications_authors.position',1);
	
		//$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
	
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			$arrProceCoAuths[$row['id']]=$row;
		}
		return $arrProceCoAuths;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAliasCoAuthors()
	 * @Param  : $orgId
	 * @return : $arrProceCoAuths
	 */
	function getAliasCoAuthors($orgId){
		$arrProceCoAuths=array();
		$this->db->select('ala.id,ala.last_name,ala.initials,ala.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->join('pubmed_authors as ala','pubmed_authors.alias_id=ala.id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
		$this->db->where('publications_authors.position',1);
		$this->db->group_by('pubmed_authors.alias_id');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			$arrProceCoAuths[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrProceCoAuths;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getCoAuthorById()
	 * @Param  : $orgId
	 * @return : $coAuthorDetails
	 */
	function getCoAuthorById($authorId){
		$coAuthorDetails=array();
		$this->db->where('id',$authorId);
		$result	=$this->db->get('pubmed_authors');
		foreach($result->result_array() as $row){
			$coAuthorDetails=$row;
		}
		return $coAuthorDetails;
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : getMatchingCoAuthors()
	 * @Param  : $arrCoAuthIds,$orgId
	 * @return : $arrCoAuthos
	 */
	function getMatchingCoAuthors($arrCoAuthIds,$orgId){
		//Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
		$arrCoAuthos=array();
		$coAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCoAuthIds);
	
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('publications_authors.position',1);
		$where="((pubmed_authors.last_name,pubmed_authors.fore_name) IN (SELECT last_name,fore_name FROM pubmed_authors WHERE id IN ($coAuthIds))";
		$where .=" OR (pubmed_authors.last_name,pubmed_authors.initials) IN (SELECT last_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.fore_name = '')";
		$where .=" OR (pubmed_authors.fore_name,pubmed_authors.initials) IN (SELECT fore_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.last_name = ''))";
		$this->db->where($where);
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
	
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			$arrCoAuthos[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : associateCoAuthors()
	 * @Param  : $matchingAuths,$aliasDeails
	 * @return : Boolean -> true : updated | false : failure
	 */
	function associateCoAuthors($matchingAuths,$aliasDeails){
		$isSavedToAuthTable=false;
	
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
	
		if($isSavedToAuthTable){
			$aliasId['alias_id']=$aliasDeails['alias_id'];
			$this->db->where_in('author_id',$matchingAuths);
			if($this->db->update('publications_authors', $aliasId)){
				return true;
			} else {
				return false;
			}
		}
		else {
			return false;
		}
		//echo $this->db->last_query();
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : disassociateCoAuthors()
	 * @Param  : $matchingAuths,$aliasDeails
	 * @return : Boolean -> true : updated | false : failure
	 */
	function disassociateCoAuthors($matchingAuths,$aliasDeails){
		$isSavedToAuthTable=false;
	
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
	
		if($isSavedToAuthTable){
			$matchingAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($matchingAuths);
			$arrResults=$this->db->query("UPDATE publications_authors SET alias_id=author_id WHERE author_id IN($matchingAuthIds)");
			//pr($arrResults);
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkAndAssociateAlreadyExistPubsForOrg()
	 * @Param  : $arrUniquePMIDs, $orgId, $arrOrgDetail,$isVerfied
	 * @return : $arrUniquePMIDs
	 */
	function checkAndAssociateAlreadyExistPubsForOrg($arrUniquePMIDs, $orgId, $arrOrgDetail,$isVerfied=0){
		$arrCount=sizeof($arrUniquePMIDs);
		for($i=0;$i<$arrCount; $i++){
			$pmid=$arrUniquePMIDs[$i];
			$pubId=$this->pubmed->checkPubExist($pmid);
			if($pubId!=''){
				//echo 'Publication with PMID:'.$pmid.' already exist and it is Associated to OrgId :'.$kolId.'</br>';
				$orgPublication=array();
				$orgPublication['org_id']		= $orgId;
				$orgPublication['pub_id']		= $pubId;
				//Save the association only if it is not exist
				$orgPublication['is_verified']	= $isVerfied;
				$orgPublication['is_deleted']	= 0;
				if(!$this->checkOrgPubAssociationExist($orgPublication)){
					$isSaved=$this->saveOrgPublication($orgPublication);
				}else if($isVerfied){
					$isSaved=$this->updateOrgPublication($orgPublication);
				}
				unset($arrUniquePMIDs[$i]);
					
				//Delete the orgid and pmid association from org_pmids table
					
				//Calculate Authorship position and save
				//$position=$this->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
				//$this->updateAuthorshipPos($orgId,$pubId,$position);
				//echo "already exists PMID-".$pmid." Pub ID-".$pubId." Position-".$position;
			}
		}
		$arrUniquePMIDs=array_values($arrUniquePMIDs);
		//pr($arrUniquePMIDs);
		return $arrUniquePMIDs;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgNameCombinations()
	 * @Param  : $orgId
	 * @return : $arrNameCombinations
	 */
	function getOrgNameCombinations($orgId){
		$this->load->helper('text');
		$arrNameCombinations = array();
		$this->db->select('name');
		$this->db->where('org_id',$orgId);
		$results = $this->db->get('org_name_combinations');
		if(is_object($results) && $results->num_rows() > 0){
			foreach($results->result_array() as $row){
				$arrNameCombinations[] = ascii_to_entities($row['name']);
			}
		}
		return $arrNameCombinations;
		 
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkOrgPubAssociationExist()
	 * @Param  : $orgPublication
	 * @return : Boolean -> true : updated | false : failure
	 */
	function checkOrgPubAssociationExist($orgPublication){
		$this->db->select('id');
		$this->db->where('org_id',$orgPublication['org_id']);
		$this->db->where('pub_id',$orgPublication['pub_id']);
		$arrPublicationAssoc=$this->db->get('org_publications');
		if($arrPublicationAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveOrgPublication()
	 * @Param  : $orgPublication
	 * @return : Boolean -> true : updated | false : failure
	 */
	function saveOrgPublication($orgPublication){
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		if(isset($userId) && $userId != ''){
			$orgPublication['client_id'] = $clientId;
			$orgPublication['user_id'] = $userId;
		}else{
			$orgPublication['client_id'] = INTERNAL_CLIENT_ID;
			$orgPublication['user_id'] = INTERNAL_USER_ID;
		}
	
		if($this->db->insert('org_publications',$orgPublication)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateOrgPublication()
	 * @Param  : $orgPublication
	 * @return : Boolean -> true : updated | false : failure
	 */
	function updateOrgPublication($orgPublication){
		$arrOrgPubDetail['is_verified']	= $orgPublication['is_verified'];
		$arrOrgPubDetail['is_deleted']	= $orgPublication['is_deleted'];
		$this->db->where('org_id', $orgPublication['org_id']);
		$this->db->where('pub_id', $orgPublication['pub_id']);
		if($this->db->update('org_publications', $arrOrgPubDetail)){
			return true;
		}else{
			return false;
		}
	}
}
?>