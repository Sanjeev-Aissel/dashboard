<?php
/**
*Model for organization pubmed operations
*
*@package application.models
*@author Ramesh B
*@since otsuka 1.0.11
*@created on 30-03-2013
*/

class Pubmed_org extends Model{

	//Constructore
	function Pubmed_org(){
		parent::Model();
		$this->load->model("common_helpers");
		$this->load->model("pubmed");
	}
	
	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return data Object
	 * @created on 30-03-2013
	 */
	function listPublicationDetailsForAnalyst($orgId,$type){
		$arrPublications=array();
		$this->db->select('publications.*,org_publications.id as asoc_id');
		$this->db->from('publications');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->where('org_id', $orgId);
		if($type=='unVerified'){
			$this->db->where('org_publications.is_deleted', 0);
			$this->db->where('org_publications.is_verified', 0);
		}else if($type=='verified'){
			$this->db->where('org_publications.is_deleted', 0);
			$this->db->where('org_publications.is_verified', 1);
		}else{
			$this->db->where('org_publications.is_verified', 0);
			$this->db->where('org_publications.is_deleted', 1);
		}
		$this->db->distinct();
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}
		//echo $this->db->last_query();
		return 	$arrPublications;
	}
	
	/**
	 * Saves the manual Publication and returns the id of it. setting the Cliend id is logged client id. and  is_verified=1
	 * @param Array $pubDetails
	 * @param Integer $kolId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Integer
	 * @created on 30-03-2013
	 */
	function savePublicationsManualAndFlags($pubDetails, $orgId){					
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';		
		//prepare the kol-to-publication association object
		$orgPublication=array();
		$orgPublication['org_id']=$orgId;
		$orgPublication['pub_id']=$pubId;
		$orgPublication['is_deleted']=0;
		$client_id = $this->session->userdata('client_id');	
		$userId = $this->session->userdata('user_id');	
		//For manual saving Cliend id is logged client id and its verified
		if(isset($client_id)){
			$orgPublication['client_id']   = $client_id;
			$orgPublication['is_verified'] = 1;
			$orgPublication['user_id']     = $userId;
		}else{
			$orgPublication['client_id'] = INTERNAL_CLIENT_ID;
		}						
		//save the kol-to-publication record
		$isSaved=$this->saveOrgPublication($orgPublication);
		//return the publication Id	
		return $pubId;
	}
	
	/**
	 * Saves given organizaton and publications associaton record
	 * @param Array $orgPublication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function saveOrgPublication($orgPublication){	
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		if(isset($userId) && $userId != ''){
			$orgPublication['client_id'] = $clientId;
			$orgPublication['user_id'] = $userId;
		}else{
			$orgPublication['client_id'] = INTERNAL_CLIENT_ID;
			$orgPublication['user_id'] = INTERNAL_USER_ID;
		}
		
		if($this->db->insert('org_publications',$orgPublication)){
			return true;  		
		}else{	      		
		    return false;
		}		
	}
	
	/**
	 * Sets publication as deleted by setting the 'is_deleted' to 1
	 * @param $orgPublication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function updatePublicationAsDeleted($id){
		$orgPublication['is_deleted']=1;
		$orgPublication['is_verified']=0;
		$this->db->where('id', $id);				
		if($this->db->update('org_publications', $orgPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Deletes the Association between Kol and Publication
	 * @param $pubId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function deletePublication($pubId){
		$this->db->where('pub_id', $pubId);
		if($this->db->delete('org_publications')){
			return true;
		}else{
			return false;
		} 
	}
	
	/**
	 * Sets publication as verified by setting the 'is_verified' to 1
	 * @param $orgPublication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function updatePublicationAsVerified($id,$orgPublication){	
		$this->db->where('id', $id);
		if($this->db->update('org_publications', $orgPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Retrives all the pubmed unprocessed organizatons
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function getPubmedUnprocessedOrgs(){
		$arrOrgDetails=array();
     	$arrStatus = array(0);
     	$this->db->select("id,name");
     	$this->db->where_in('is_pubmed_processed',$arrStatus);
     	$this->db->where('status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrOrgDetailResult=$this->db->get('organizations');
	    foreach($arrOrgDetailResult->result_array() as $arrOrg){
	    			$arrOrgDetails[]= $arrOrg;
	    		}
	    //echo $this->db->last_query();
	    return $arrOrgDetails;
	}
	
	/**
	 * Retrives all organizatons with pubmeds status 'recrawl'
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
     function getPubmedRecrawlOrgs(){
     	$arrOrgDetails=array();
     	$arrStatus = array(2);
     	$this->db->select("id,name");
     	$this->db->where_in('is_pubmed_processed',$arrStatus);
     	$this->db->where('status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrOrgDetailResult=$this->db->get('organizations');
	    foreach($arrOrgDetailResult->result_array() as $arrOrg){
	    			$arrOrgDetails[]= $arrOrg;
	    		}
	    return $arrOrgDetails;
     }
	
	/**
	 * Check whether the Publication with PMID exist or not if exist it removes it from array and 
	 * get's the publication Id of theat and associates it with kol
	 * @param $arrUniquePMIDs
	 * @param $kolId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 * added new parameter $isVerfied so that while crawling it should be unverified and if pubs are imported then we can set it to verified
	 */
	function checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $orgId, $arrOrgDetail,$isVerfied=0){
			$arrCount=sizeof($arrUniquePMIDs);
			for($i=0;$i<$arrCount; $i++){
				$pmid=$arrUniquePMIDs[$i];
				$pubId=$this->pubmed->checkPubExist($pmid);
				if($pubId!=''){
					//echo 'Publication with PMID:'.$pmid.' already exist and it is Associated to OrgId :'.$kolId.'</br>';
					$orgPublication=array();
					$orgPublication['org_id']		= $orgId;
					$orgPublication['pub_id']		= $pubId;				
					//Save the association only if it is not exist
					$orgPublication['is_verified']	= $isVerfied;
					$orgPublication['is_deleted']	= 0;
					if(!$this->checkOrgPubAssociationExist($orgPublication)){
						$isSaved=$this->saveOrgPublication($orgPublication);
					}else if($isVerfied){
						$isSaved=$this->updateOrgPublication($orgPublication);
					}
					unset($arrUniquePMIDs[$i]);
					
					//Delete the orgid and pmid association from org_pmids table
					
					//Calculate Authorship position and save
					//$position=$this->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
					//$this->updateAuthorshipPos($orgId,$pubId,$position);
					//echo "already exists PMID-".$pmid." Pub ID-".$pubId." Position-".$position;
				}
			}
			$arrUniquePMIDs=array_values($arrUniquePMIDs);
			//pr($arrUniquePMIDs);
			return $arrUniquePMIDs;
	}
	
	/**
	 * check whether the given organizatons and publication associaton exist or not
	 * @param $orgPublication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function checkOrgPubAssociationExist($orgPublication){
		$this->db->select('id');
		$this->db->where('org_id',$orgPublication['org_id']);
		$this->db->where('pub_id',$orgPublication['pub_id']);
		$arrPublicationAssoc=$this->db->get('org_publications');
		if($arrPublicationAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Updates org publications association statuses
	 * @param $orgPublication
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function updateOrgPublication($orgPublication){	
		$arrOrgPubDetail['is_verified']	= $orgPublication['is_verified'];
		$arrOrgPubDetail['is_deleted']	= $orgPublication['is_deleted'];
		$this->db->where('org_id', $orgPublication['org_id']);
		$this->db->where('pub_id', $orgPublication['pub_id']);
		if($this->db->update('org_publications', $arrOrgPubDetail)){
			return true;
		}else{
		    return false;
		}		
	}
	
	/**
	 * Updates organizaton as pubmed processed by setting 'is_pubmed_processed' to 1
	 * @param  $arrOrgDetail
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function updatePubmedProcessedOrg($arrOrgDetail){
		$kolDetail['is_pubmed_processed']=	$arrOrgDetail['is_pubmed_processed'];
		$this->db->where('id', $arrOrgDetail['id']);		
		$this->db->update('organizations', $arrOrgDetail);		
	}
	
	/**
	 * Retrievs all the  pmids for given organization id
	 * @param  $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return Array
	 * @created on 30-03-2013
	 */
	function getPMIDs($orgId){
     	$arrPMIDs = array();
     	$this->db->select('pmid');
     	$this->db->where('org_id',$orgId);
     	$arrResults = $this->db->get('org_pmids');
    	foreach($arrResults->result_array() as $row){
     		$arrPMIDs[] = $row['pmid'];
		}
     
     	return $arrPMIDs;
	}
	
	/**
	 * updates the organization pubmed processing status to given status
	 * @param  $orgId
	 * @param  $status
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
	function changeOrgPubmedStatus($orgId, $status){
		$arrOrgDetails = array();
		$arrOrgDetails['is_pubmed_processed'] = $status;
		$this->db->where('id',$orgId);
		if($this->db->update('organizations',$arrOrgDetails)){
			return true;
		}else{
			return false;
		}
	}
	
  	/**
	 * Saves the organization Pmids for crawaling
	 * @param  $arrData ex array('pmid'=>11,'org_id'=23124)
	 * @author Vinayak
	 * @since Otsuka 1.0.11
	 * @return boolean
	 * @created on 30-03-2013
	 */
     function saveOrgPMID($arrData){
		if($this->db->insert('org_pmids',$arrData)){
				return true;	      		
		}else{	      		
		    return false;
		}	
     }
     
     /**
	 * Get the Organzation publications details
	 * @param  $orgId
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrPublications
	 *
	 */
	function listOrgPublicationDetails($orgId,$limit){
		$arrPublications=array();
		$clientId = $this->session->userdata('client_id');
		
		$this->db->select('publications.*,org_publications.id as asoc_id,pubmed_journals.name as jname,organizations.name as orgName,organizations.cin_num');
		$this->db->from('publications');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals', 'publications.journal_id = pubmed_journals.id','left');
		$this->db->join('organizations', 'organizations.id = org_publications.org_id','left');
		$this->db->where('org_id', $orgId);
		$this->db->where('org_publications.is_deleted', 0);
		$this->db->where('org_publications.is_verified',1);
		if($limit!=null){
			$this->db->limit($limit);
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(org_publications.client_id=$clientId or org_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}
     
	
	 /**
	 * Get the Organzation publications details
	 * @param  $orgId,$fromyear and $toYear
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrPublications
	 *
	 */
	function listPublicationsByYearRange($orgId,$fromYear,$toYear){
		$clientId = $this->session->userdata('client_id');
		$arrPublications=array();
	
		$this->db->select('publications.*,org_publications.id as kp_id,org_publications.client_id,org_publications.user_id,pubmed_journals.name as journal_name');
		$this->db->join('org_publications','org_publications.pub_id = publications.id','inner');
		$this->db->join('pubmed_journals ','pubmed_journals.id = publications.journal_id','inner');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.'  and  '.$toYear.' OR YEAR(publications.created_date)="0")');
		//$this->db->where("(year(created_date) >= '$fromYear' AND year(created_date) <='$toYear')");
		$this->db->order_by('created_date','desc');
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(org_publications.client_id=$clientId or org_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		$arrPublicationResult = $this->db->get('publications');
		//echo $this->db->last_query();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}	
	
	
	 /**
	 * Get the Organzation publications year range
	 * @param  $orgId
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrYears
	 *
	 */
	function getOrgPubsYearsRange($orgId){
		$arrYears=array();
		$arrResults=$this->db->query("SELECT MIN(YEAR(publications.created_date)) AS min_year,MAX(YEAR(publications.created_date)) AS max_year
									FROM publications
									LEFT JOIN org_publications ON publications.id=org_publications.pub_id
									WHERE org_publications.org_id=".$orgId." AND org_publications.is_deleted=0 AND YEAR(publications.created_date)!=0");

		//echo $this->db->last_query();
		foreach($arrResults->result_array() as $row){
			$arrYears['min_year']=$row['min_year'];
			$arrYears['max_year']=$row['max_year'];
		}
		return $arrYears;
	}
	
	 /**
	 * Get the Organzation publications meajor mesh term data
	 * @param  $orgId, $fromYear, $toYear
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrMajorMeshterm
	 *
	 */
	function getPubMajorMeshTermChart($orgId, $fromYear, $toYear,$keyword){
		$arrMajorMeshterm=array();
		$this->db->select('pubmed_mesh_terms.id,pubmed_mesh_terms.term_name as mesh_term,count(distinct org_publications.pub_id) as count,pubmed_mesh_terms.parent_id');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');

		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_id',$orgId);
		$this->db->where('publication_mesh_terms.is_major','1');
		$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
		if($keyword!=''){
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('pubmed_mesh_terms.term_name,pubmed_mesh_terms.parent_id');
		$this->db->order_by('count','desc');
		$this->db->limit('20');

		$arrMajorMeshtermResult	=	$this->db->get('pubmed_mesh_terms');
		
		foreach($arrMajorMeshtermResult->result_array() as $row){
			$arrMajorMeshterm[]=$row;
		}
		return $arrMajorMeshterm;
	}
	
 	/**
	 * Get the Organzation publications substance data
	 * @param  $orgId, $fromYear, $toYea
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrMajorMeshterm
	 *
	 */
	function getPubSubstancesChart($orgId, $fromYear, $toYear,$keyword){
		$arrSubstances=array();
		$this->db->select('pubmed_substances.id,pubmed_substances.name ,count(distinct org_publications.pub_id) as count');
		$this->db->join('publication_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
		$this->db->join('publications', 'publications.id = publication_substances.pub_id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_id',$orgId);
		$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('pubmed_substances.name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		
		$arrSubstancesResult	=	$this->db->get('pubmed_substances');
		foreach($arrSubstancesResult->result_array() as $row){
			$arrSubstances[]=$row;
		}	
		//echo $this->db->last_query();
		//pr($arrSubstances);	
     	return $arrSubstances;
	}
	
	/**
	 * Get the Organzation publications journal data
	 * @param  $orgId, $fromYear, $toYea
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @return Array-$arrMajorMeshterm
	 *
	 */
	function getPubJournalsChart($orgId,$fromYear,$toYear,$keyword){
		$arrJournals=array();
		$this->db->select('pubmed_journals.id,pubmed_journals.name ,count(distinct org_publications.pub_id) as count');
		$this->db->join('publications','publications.journal_id=pubmed_journals.id','left');
		$this->db->join('org_publications','org_publications.pub_id=publications.id ','left');
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_id',$orgId);
		$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('pubmed_journals.name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		$arrJournalsResult	=	$this->db->get('pubmed_journals');
		if($arrJournalsResult->num_rows()!=0){
			foreach($arrJournalsResult->result_array() as $row){
					$arrJournals[]=$row;
			}
		}else{
				return false;
			}	
		return 	$arrJournals;
	}
	
	/**
	 * Returns the given Org Publication  detail
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @param $substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear
	 * @return $arrPubliations
	 * 
	 */
	function searchPublicationsByParameters($substance,$author,$meshTermName,$keyword,$aritcleName,$orgId,$fromYear,$toYear){
		$this->db->select('distinct(publications.id),publications.*,pubmed_journals.name as journal_name');
		$this->db->join('publications','publications.id=org_publications.pub_id','left');
		$this->db->join('pubmed_journals','publications.journal_id=pubmed_journals.id','left');
		
//		if($substance!=''){
//			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
//			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id');
//			$this->db->like("pubmed_substances.name",$substance);
//		}
//		
//		if($author!=''){
//			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
//			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
//			//$this->db->like('pubmed_authors.last_name',$author);
//			//$this->db->or_like('pubmed_authors.fore_name',$author);
//			
//			$this->db->where("((pubmed_authors.last_name  LIKE '%$author%' OR  pubmed_authors.fore_name  LIKE '%$author%'))");
//		}
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
		
//		if($meshTermName !=''){
//			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
//			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
//			$this->db->like('pubmed_mesh_terms.term_name',$meshTermName);
//		}
//		
//		if($aritcleName !=''){
//			$this->db->like('publications.article_title',$aritcleName);
//		}
	
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->order_by('created_date','desc');
		$arrResultSet = $this->db->get('org_publications');
		$arrPubliations =array();
//		echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrPubliations[]=$row;
		}
		return $arrPubliations;
	}
	
	/**
	 * Returns Publication details
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version 1.0.11
	 * @param $$orgId, $fromYear, $toYear
	 * @return $arrPubliations
	 * 
	 */
	function getPublicationChart($orgId, $fromYear, $toYear,$keyword){
		$arrPublications=array();
		$this->db->select('year(created_date) as year,count(distinct org_publications.pub_id) as count');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');

		$this->db->where('org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($fromYear != 0 && $toYear != 0)
			$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
			
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('year(created_date)');
		$this->db->order_by('year(created_date)','desc');
		//$this->db->limit('15');

		$arrPublicationsResult	=	$this->db->get('publications');
		//echo $this->db->last_query();
		foreach($arrPublicationsResult->result_array() as $row){
			$arrPublications[]=$row;
		}
		//pr($arrPublications);
		return $arrPublications;
	}
	
	function getFistAuthors($orgId,$affilition,$limit){
		$arrDetails = array();
		/*$this->db->select('pubmed_authors.*,count(distinct org_publications.pub_id) as num_pubs,org_publications.pub_id');
		$this->db->join('pubmed_authors','publications_authors.author_id=pubmed_authors.id','left');
		$this->db->select('pubmed_authors.*,count(distinct org_publications.pub_id) as num_pubs,org_publications.pub_id');
		$this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
		$this->db->join('org_publications','org_publications.pub_id=publications_authors.pub_id','left');
		if($affilition!=''){
			$this->db->join('publications','org_publications.pub_id=publications.id','left');
			$this->db->like('publications.affiliation',$affilition);
			
		}
		$this->db->where('publications_authors.position',1);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->group_by('last_name,fore_name,initials');
		$arrResultSet = $this->db->get('publications_authors');*/
		
		
		$this->db->select("pubmed_authors.*, count(distinct org_publications.pub_id) as num_pubs, org_publications.pub_id,GROUP_CONCAT(DISTINCT case publication_mesh_terms.is_major when 1 then concat(parent.term_name,'/',pubmed_mesh_terms.term_name) else null end SEPARATOR ':') AS key_words,GROUP_CONCAT(DISTINCT case publication_mesh_terms.is_major when 1 then pubmed_mesh_terms.term_name else null end SEPARATOR ':') AS all_key_words",false);
		$this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
		$this->db->join('org_publications','org_publications.pub_id=publications_authors.pub_id','left');
		$this->db->join('publication_mesh_terms','org_publications.pub_id=publication_mesh_terms.pub_id','left');
		$this->db->join('pubmed_mesh_terms','publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('pubmed_mesh_terms as parent ','pubmed_mesh_terms.parent_id = parent.id','left');
		if($affilition!=''){
			$this->db->join('publications','org_publications.pub_id=publications.id','left');
			$this->db->like('publications.affiliation',$affilition);
			
		}
		$this->db->where('publications_authors.position',1);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('(pubmed_authors.id!="" and last_name !="" and fore_name!="" and initials!="")');
		$this->db->group_by('last_name,fore_name,initials');
		if($limit!=null){
			$this->db->limit($limit);
		}
		//$this->db->limit(1);
		$arrResultSet = $this->db->get('publications_authors');
		
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
	//	pr($arrDetails);
		return $arrDetails;
	}
	
	function getPubMajorMeshTerms($orgId,$lastName,$foreName,$initials){
		$arrMajorMeshterm=array();
		$this->db->select('pubmed_mesh_terms.*,count(pubmed_mesh_terms.term_name) as count');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id=pubmed_mesh_terms.id','left');
		$this->db->join('org_publications', 'org_publications.pub_id=publication_mesh_terms.pub_id','left');
		$this->db->join('publications_authors','org_publications.pub_id=publications_authors.pub_id','left');
		$this->db->join('pubmed_authors','publications_authors.author_id=pubmed_authors.id','left');
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('publication_mesh_terms.is_major','1');
		$this->db->where('last_name',$lastName);
		$this->db->where('fore_name',$foreName);
		$this->db->where('initials',$initials);
		$this->db->group_by('pubmed_mesh_terms.term_name');
		$this->db->order_by('count','desc');
		$this->db->limit('5');
		$arrMajorMeshtermResult	=	$this->db->get('pubmed_mesh_terms');
		//echo $this->db->last_query();
		foreach($arrMajorMeshtermResult->result_array() as $row){
			$arrMajorMeshterm[]=$row;
		}
		//pr($arrMajorMeshterm);
		return $arrMajorMeshterm;
	}
	
function getKeyInvestigators($orgId,$limit){
		$arrDetails = array();
		$this->db->select('cts_investigators.id,cts_investigators.last_name,count(distinct org_clinical_trials.cts_id) as trial_count,GROUP_CONCAT(DISTINCT  cts_keywords.name ) AS key_words');
		$this->db->join('ct_investigators','ct_investigators.alias_id=cts_investigators.id','left');
		$this->db->join('org_clinical_trials','org_clinical_trials.cts_id=ct_investigators.cts_id','left');
		
		
		$this->db->join('ct_keywords','org_clinical_trials.cts_id=ct_keywords.cts_id','left');
		$this->db->join('cts_keywords','ct_keywords.keyword_id=cts_keywords.id','left');
		
		
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('(last_name!="")');
		$this->db->where('is_verified',1);
		
		$this->db->group_by('cts_investigators.last_name');
		if($limit!=null)
		$this->db->limit($limit);
		$arrResultSet = $this->db->get('cts_investigators');
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
		return $arrDetails;
	}
	
	function getKolNamesWithConcat(){
		$arrKolMames = array();
// 		$arrResulySet =	$this->db->query("SELECT id,concat(first_name, middle_name, last_name) as name
// 				FROM (kols) where status='".COMPLETED."'");
		$arrResulySet =	$this->db->query("SELECT id,concat(first_name, middle_name, last_name) as name
				FROM (kols) ");
		foreach($arrResulySet->result_array() as $row){
			$arrKolMames[$row['id']] = $row['name'];
		}
		return $arrKolMames;
	}
	
	function getKeywords($orgId,$name){
		$arrDetails = array();
		$this->db->select('name,count(name) as count');
		$this->db->join('ct_keywords','ct_keywords.keyword_id=cts_keywords.id','left');
		$this->db->join('org_clinical_trials','org_clinical_trials.cts_id=ct_keywords.cts_id','left');
		$this->db->join('ct_investigators','ct_investigators.cts_id=ct_keywords.cts_id','left');
		$this->db->join('cts_investigators','cts_investigators.id=ct_investigators.investigator_id','left');
		$this->db->where('cts_investigators.last_name',$name);
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->group_by('name');
		$this->db->order_by('count desc');
		$this->db->limit(5);
		$arrResultSet = $this->db->get('cts_keywords');
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row['name'];
		}
		return $arrDetails;
		
	}
	

	 function getOrgNameCombinations($orgId){
     	$this->load->helper('text');
     	$arrNameCombinations = array();
     	$this->db->select('name');
     	$this->db->where('org_id',$orgId);
     	$results = $this->db->get('org_name_combinations');
     	if(is_object($results) && $results->num_rows() > 0){
	     	foreach($results->result_array() as $row){
	     		$arrNameCombinations[] = ascii_to_entities($row['name']);
	     	}
     	}
     	return $arrNameCombinations;
     
	}
	
	function saveNameCombination($rowData){
     	if($this->db->insert('org_name_combinations',$rowData)){
			return true;	      		
		}else{	      		
		    return false;
		}	
     }
     
 function deleteNameCombination($name,$orgId){
     	$this->db->where('name',$name);
     	$this->db->where('org_id',$orgId);
     	if($this->db->delete('org_name_combinations'))
     		return true;
     	else
     		return false;
     }
     
     function getFnameAndInitials($id){
     	$arrNames = array();
     	$this->db->select('last_name,fore_name,initials');
     	$this->db->where('id',$id);
     	$arrResultSet = $this->db->get('pubmed_authors');
     	foreach($arrResultSet->result_array() as $row){
     		$arrNames = $row;
     	
     	}
     	return $arrNames;
     	
     }
     
     function getPublicationDetails($arrNames,$orgId,$fromYear,$toYear,$keyword,$affiliation){
     	$this->db->select('distinct( publications.id),publications.pmid,article_title,journal_id,created_date,pubmed_journals.name as journal_name');
        $this->db->join('org_publications','org_publications.pub_id=publications.id','left');
        $this->db->join('pubmed_journals','pubmed_journals.id=publications.journal_id','left');
        $this->db->join('publications_authors','publications_authors.pub_id=org_publications.pub_id','left');
        $this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
        $this->db->where('publications_authors.position',1);
        $this->db->where('org_publications.org_id',$orgId);
        $this->db->where('org_publications.is_deleted',0);
        $this->db->where('org_publications.is_verified',1);
        $this->db->where('pubmed_authors.last_name',$arrNames['last_name']);
        $this->db->where('pubmed_authors.fore_name',$arrNames['fore_name']);
        $this->db->where('pubmed_authors.initials',$arrNames['initials']);
        if($keyword!=''){
            $this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
            $this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
            $this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
            $this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
            $this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
            
        }
        if($affiliation!=null && $affiliation!=''){
            $this->db->like('publications.affiliation',$affiliation);
        }
        
        if($fromYear!= 0 && $toYear != 0 && $fromYear!='' && $toYear!='')
            $this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
        $this->db->order_by('publications.created_date','desc');
        $arrRsultSet = $this->db->get('publications');
        //pr($this->db->last_query());exit;
        foreach($arrRsultSet->result_array() as $row){
            $arrDetails[] = $row;
        }
        return $arrDetails;
     }
     
     	/**
	 * returns the list of co-authors belongs to kol
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return unknown_type
	 * @created 06-04-11
	 */
	function getOrgCoAuthors($orgId){
		$arrCoAuthos=array();
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//This code is commented in order to allow the KOL name combinations also in name disambiguation
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$where2="!((last_name='Not Available' ) and (fore_name='Not Available'))";
		$this->db->where($where2);
		$this->db->where('publications_authors.position',1);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[$row['id']]=$row;
		}	
//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	/**
	 * returns the list of co-authors which having alias belongs to kol
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return unknown_type
	 * @created 06-04-11
	 */
	function getOrgProcessedCoAuthors($orgId){
		$arrProceCoAuths=array();
		$this->db->select('pubmed_authors.*');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('publications_authors.position',1);
		
		//$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrProceCoAuths[$row['id']]=$row;
		}	
		return $arrProceCoAuths;
	}
	
	/**
	 * returns all the Co-Authors id's matching the given Author id's first name and fore name
	 * Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getMatchingCoAuthors($arrCoAuthIds,$orgId){
		//Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
		$arrCoAuthos=array();
		$coAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCoAuthIds);
		
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('publications_authors.position',1);
		$where="((pubmed_authors.last_name,pubmed_authors.fore_name) IN (SELECT last_name,fore_name FROM pubmed_authors WHERE id IN ($coAuthIds))";
		$where .=" OR (pubmed_authors.last_name,pubmed_authors.initials) IN (SELECT last_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.fore_name = '')";
		$where .=" OR (pubmed_authors.fore_name,pubmed_authors.initials) IN (SELECT fore_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.last_name = ''))";
		$this->db->where($where);
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[$row['id']]=$row;
		}	
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	/**
	 * returns all the Co-Authors id's which alias to one are the other co-Author
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getAliasCoAuthors($orgId){
		$arrProceCoAuths=array();
		$this->db->select('ala.id,ala.last_name,ala.initials,ala.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->join('pubmed_authors as ala','pubmed_authors.alias_id=ala.id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
		$this->db->where('publications_authors.position',1);
		$this->db->group_by('pubmed_authors.alias_id');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrProceCoAuths[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrProceCoAuths;
	}

	/**
	 * Returns the CoAuthor Details of given Id
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getCoAuthorById($authorId){
		$coAuthorDetails=array();
		$this->db->where('id',$authorId);
		$result	=$this->db->get('pubmed_authors');
		foreach($result->result_array() as $row){
			$coAuthorDetails=$row;
		}
		return $coAuthorDetails;
	}
	
	/**
	 * Associates the given set of coAuthors with the given alias details
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Boolean
	 * @created 07-04-11
	 */
	function associateCoAuthors($matchingAuths,$aliasDeails){
	$isSavedToAuthTable=false;
		
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
		
		if($isSavedToAuthTable){
			$aliasId['alias_id']=$aliasDeails['alias_id'];
			$this->db->where_in('author_id',$matchingAuths);
			if($this->db->update('publications_authors', $aliasId)){
				return true;
			} else {
				return false;
			}
		}
		else {
			return false;
		}
		//echo $this->db->last_query();
	}
	
	function disassociateCoAuthors($matchingAuths,$aliasDeails){
		$isSavedToAuthTable=false;
		
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
		
		if($isSavedToAuthTable){
			$matchingAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($matchingAuths);
			$arrResults=$this->db->query("UPDATE publications_authors SET alias_id=author_id WHERE author_id IN($matchingAuthIds)");
			//pr($arrResults);
			return true;
		}else {
			return false;
		}
	}
	
function getSubstancesPublications($substanceName, $org_id, $fromYear, $toYear,$filters = null){
		$arrPublicationsDetail=array();

		$this->db->select('pubmed_substances.name ,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date,count(publications_authors.pub_id) as authcount,publications.link');
		$this->db->join('publication_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
		$this->db->join('publications', 'publications.id = publication_substances.pub_id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		$this->db->join('organizations', 'org_publications.org_id = organizations.id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($org_id != 0)
			$this->db->where('org_id',$org_id);
		$this->db->where('pubmed_substances.id',$substanceName);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('organizations.status',COMPLETED);
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('org_publications.pub_id');
		$this->db->order_by('authcount','desc');
		$arrPublications	=	$this->db->get('pubmed_substances');
		//pr($this->db->last_query());exit;
		foreach($arrPublications->result_array() as $row){
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
/**
	 * Returns the list of Publication details of Particular Journal Name,KOl_Id,Time Range
	 * @param $journalName,$kol_id, $fromYear,$toYear,
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getPublicationsByJournals($journalName,$org_id, $fromYear,$toYear,$filters = null){
		$arrJournals=array();
		/*$arrJournalsResult = $this->db->query("select pubmed_journals.name ,publications.id,publications.pmid,
													pubmed_journals.name as journal_name,
													publications.article_title,publications.created_date,
													count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link from pubmed_journals
												LEFT JOIN publications ON publications.journal_id=pubmed_journals.id 
												LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id 
												where kol_id='$kol_id' AND `kol_publications`.`is_deleted` = 0 
												AND kol_publications.is_verified=1 
												AND pubmed_journals.id='$journalName'
												AND year(publications.created_date) between $fromYear and $toYear
												group by kol_publications.pub_id order by count desc ");*/
		
		$this->db->select('pubmed_journals.name ,publications.id,publications.pmid,
													pubmed_journals.name as journal_name,
													publications.article_title,publications.created_date,
													count(publications_authors.pub_id) as authcount,publications.link');
		$this->db->join('publications', 'publications.journal_id = pubmed_journals.id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->join('organizations', 'org_publications.org_id = organizations.id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($org_id != 0)
			$this->db->where('org_id',$org_id);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('organizations.status',COMPLETED);
		$this->db->where('pubmed_journals.id',$journalName);
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('org_publications.pub_id');
		$this->db->order_by('authcount','desc');
		$arrJournalsResult = $this->db->get('pubmed_journals');
		//pr($this->db->last_query());exit;
		foreach($arrJournalsResult->result_array() as $row){
			if($arrJournalsResult->num_rows()!=0){
				$arrJournals[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrJournals;
	}
	

	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getMajorMeshtermPublications($meshterm1,$meshterm2,$org_id, $fromYear, $toYear,$filters = null){
		$arrPublications=array();
		$this->db->select('pubmed_mesh_terms.term_name as mesh_term,
														publications.article_title,
														publications.journal_id,
														publications.created_date,
														pubmed_journals.name as journal_name,
														publications.id,
														organizations.name,publications.pmid,publications.link, count(publications_authors.pub_id) as authcount');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications.id','left');
		$this->db->join('organizations', 'org_publications.org_id = organizations.id','left');
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($org_id != 0)
			$this->db->where('org_publications.org_id',$org_id);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('organizations.status',COMPLETED);
		$this->db->where('pubmed_mesh_terms.id',$meshterm2);
		$this->db->where('pubmed_mesh_terms.parent_id',$meshterm1);
		$this->db->where('publication_mesh_terms.is_major',1);
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('org_publications.pub_id');
		$this->db->order_by('authcount','desc');
		$arrPublicationResult = $this->db->get('pubmed_mesh_terms');
		//pr($this->db->last_query());exit;
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	
	}
	
	/**
	 * returns the list of publications belongs to perticular year for the passed kol_id,
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 */
	function getYearPublications($org_id, $year,$filters = null){
		$arrPublicationsDetail=array();
		$this->db->select("year(created_date) as year,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date, count(publications_authors.pub_id) as authcount,publications.link");
		$this->db->join('org_publications','org_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals','pubmed_journals.id = publications.journal_id','left');
		$this->db->join('organizations', 'org_publications.org_id = organizations.id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		//LEFT JOIN publications_authors on publications_authors.pub_id = publications.id
		if($org_id != 0)
			$this->db->where('org_id',$org_id);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('year(publications.created_date)',$year);
		//$this->db->where('organizations.status',COMPLETED);
		
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
		$this->db->group_by('org_publications.pub_id');
		$this->db->order_by('year(created_date) desc');
		$arrPublications = $this->db->get('publications');
		//pr($this->db->last_query());exit;
		foreach($arrPublications->result_array() as $row){
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	function getFistAuthorsForChart($orgId,$startYear,$endYear,$keyword){
		$arrDetails = array();
		$this->db->select('pubmed_authors.*,count(distinct org_publications.pub_id) as num_pubs,org_publications.pub_id');
		$this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
		$this->db->join('org_publications','org_publications.pub_id=publications_authors.pub_id','left');
		
		
		$this->db->where('publications_authors.position',1);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($keyword!=''){
			$this->db->join('publications','publications.id=org_publications.pub_id','left');
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->limit(20);
		$this->db->group_by('last_name,fore_name,initials');
		$this->db->order_by('num_pubs','desc');
		$arrResultSet = $this->db->get('publications_authors');
		//pr($this->db->last_query());exit;
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
	//	pr($arrDetails);
		return $arrDetails;
	}
	
	function deleteClientPublication($id){
		$this->db->where('id',$id);
		if($this->db->delete('org_publications')){
			return true;
		}else{
			return false;
		}
	}
	
	function getPubTypeData($orgId,$fromYear,$toYear,$keyword){
		$this->db->select('pubmed_publications_types.id,pubmed_publications_types.type,COUNT(DISTINCT(publications_types.pub_id)) AS count');
		$this->db->join('publications','org_publications.pub_id=publications.id','inner');
		$this->db->join('publications_types','publications_types.pub_id=org_publications.pub_id','inner');
		$this->db->join('pubmed_publications_types','pubmed_publications_types.id=publications_types.pub_type_id','inner');
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('org_publications.is_verified',1);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.org_id',$orgId);
	if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('publications_types.pub_type_id');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		$results = $this->db->get('org_publications');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrIds[]=$row;
		}
		return $arrIds;
	}
	
function getPublicationsByType($typeId,$org_id, $fromYear,$toYear,$filters){
		$arrPublicationsDetail=array();
	
		$this->db->select('pubmed_publications_types.type ,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date,count(distinct org_publications.pub_id) as count,publications.link');
		$this->db->join('publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id','left');
		//$this->db->join('publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id','left');
		$this->db->join('org_publications', 'org_publications.pub_id = publications_types.pub_id','left');
		$this->db->join('publications', 'publications.id = org_publications.pub_id','left');
		
		
		
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		//$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		if($org_id != 0)
			$this->db->where('org_publications.org_id',$org_id);
		$this->db->where('pubmed_publications_types.id',$typeId);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('kols.status',COMPLETED);
		
		//Refine by filters
		if($filters != null){
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.specialty',$filters['specialty']);
			}
			if(isset($filters['country'])){
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$this->db->where_in('countries.Country',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_id',$filters['kol_id']);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.list_name',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
		}
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('org_publications.pub_id');
		$this->db->order_by('created_date','desc');
		//$this->db->limit('20');
		
		$arrPublications	=	$this->db->get('pubmed_publications_types');
		//echo $this->db->last_query();
		foreach($arrPublications->result_array() as $row){
		    $row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']);
		    $arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
}
