<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
<?php 
$queued_js_scripts = array('modules/kols/js/export_options',
		'modules/kols/js/kols',
		'alerts/jquery.alerts','js/chosen.jquery'
);
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.export-options {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}
.export-options li {
    float: left;
    margin-left: 0px;
}
.export-options li a {
    display: block;
    text-align: center;
    text-decoration: none;
}
</style>
<div class="col-sm-9">
<ul class="export-options">
<?php if($this->common_helper->check_module("my_list_kols")){?>
   <li>
      <div class="createListIcon sprite_iconSet" onclick="showListModalBox(<?php echo $kol_id;?>);">
         <a rel="tooltip" title="Create List" href="#">&nbsp;</a>
      </div>
   </li>
<?php }?>
   <li>															
		<div class="excelExportIcon sprite_iconSet" >
			<a rel="tooltip" onclick="showKolExportBox(<?php echo $kol_id;?>);return false;" title="Export profiles into Excel format">&nbsp;</a>
		</div>
   </li>
   <li>
      <div class="pdfExportIcon sprite_iconSet">
         <a rel="tooltip" href="<?php echo base_url().'kols/kols/export_pdf/'.$kol_id;?>" target="_new" title="Export profile into PDF format">&nbsp;</a>
      </div>
   </li>
   <li>
      <div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBox(<?php echo $kol_id;?>);return false;">
         <a rel="tooltip" href="#" title="Email Profile">&nbsp;</a>
      </div>
   </li>
   <?php if($this->common_helper->check_module("align_users")){?>
   <li>
      <div class="assignedUsers">
         <label style="float: left;">Assigned to:</label>
         <div style="float: right;display: flex;">
            <p style="float:left;margin:0px;">&nbsp;
               <?php
               if (count($assignedUsers) > 2) {
                	$arrChunk = array_chunk($assignedUsers,2);
                    $users_names=implode($assignedUsers, '<br>');
                    echo '<p class="tooltip-demo tooltop-bottom" style="float:left;margin:0px;display: flex;">&nbsp;' . implode($arrChunk[0], ', ');
                    echo '<a style="text-decoration:none;" href="#" rel="tooltip" title="' .$users_names. '"> &nbsp;more...</a>';
                    echo '</p>';
              }else{
                    echo '<p style="float:left;margin:0px;">&nbsp;' . implode($assignedUsers, ', ') . '</p>';
              }
            // echo implode(',',$assignedUsers);?>
            </p>
            <div class="actionIcon editIcon tooltip-demo tooltop-bottom" style="float: right; margin-left: 4px; margin-top: 2px;">
               <a class="tooltipLink" onclick="editUsers(<?php echo $kol_id;?>,'Edit');"  rel="tooltip" title="Edit">&nbsp;</a>
            </div>
         </div>
      </div>
   </li>
	<?php }?>
</ul>
</div>

<div class="col-sm-3">
	<?php if($this->common_helper->check_module("interactions")){?>
	<a type="button" class="btn custom-btn requestProfileIcon" style="float:right;" href="<?php echo base_url().'interactions/interactions/add_interaction/kols/'.$kol_id?>" title="Add Interaction">
	Add Interaction
	</a	>
	<?php }?>
	<a type="button" class="btn custom-btn requestProfileIcon" style="float:right;" onclick="addNewKolProfile(<?php echo $kol_id?>,this);return false;" title="Request">
		Request
	</a	>
</div>	

<div id="userContainer" class="microViewLoading">
	<div class="modalcontent"></div>
</div>