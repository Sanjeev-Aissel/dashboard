<?php
/**
 * File Description
 * 
 * @package	application.controllers.admin
 * @author		Vineet.K <vineet.kadkol@bilva.co.in>
 * @copyright	Copyright (c) 2012, Bilva Solutions <www.bilva.co.in>
 * @link		    http://www.bilva.co.in
 * @version		Version 1.0
 * @since		    Sep 22, 2012
 */

?>
<style>
	#topicForm .error{
		width:205px;
	}
	.microView .ui-dialog-content {
   	 	background-color: #ffffff;
	}
	#objectiveDesc{
	 	height: 50px;
    	width: 380px;
	}
	#topicName{
		width: 90%;
	}

</style>
<script type="text/javascript">
	var validationRules	=  {
		name: {
			required:true
		}
	};

	var validationMessages = {
		name: {
			required: "Required"
		}
	};
	$(function(){
		<?php 
			/** 
		 	** @since  22 Aug 2012
		 	**The following code is used to disable caching in IE
	 		**/
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
		$("#topicForm").validate({
			debug:true,
			onkeyup:false,
			rules: validationRules,
			messages: validationMessages
		});

	});

</script>
   
<div class="objectiveMsgBox"></div><div class="errorMsg"></div>
<div class="formHeader">
	<h5>Topic</h5>
</div>
<form action="<?php echo base_url()?>plannings/save_topic" id="topicForm" name="topicForm" onsubmit="return validateObjective();">
	<table class="objectveResultSet">
		<tr>
			<td>
				<input type="hidden" name="id" id="topicId1" value="<?php if(isset($arrTopics['id']) && $arrTopics['id']!='') echo $arrTopics['id'];  ?>" ></input>
			</td>
		</tr>
		<tr>
			<td>
				<label>Name:<span class="required">*</span></label>
				<input type="text" name="name" id="topicName" value="<?php if(isset($arrTopics['id']) && $arrTopics['name']!='') echo $arrTopics['name'];?>" class="required"></input>				
			</td>
		</tr>
		<tr>
			<td class="alignCenter">
				<input type="submit" value="<?php if(isset($arrTopics['id']) && $arrTopics['name']!=' ') echo 'Update' ;else echo 'Add';?>" onclick="saveTopic()" name="save" id="saveButton"> </input>
			</td>
		</tr>
	</table>
</form> 