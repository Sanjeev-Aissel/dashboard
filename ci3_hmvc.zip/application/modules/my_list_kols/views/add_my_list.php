<?php echo $html_form; ?>
<span id="responseMessageOfAddList"></span>
<script type="text/javascript">
var validationRules	=  {
		list_name: {
		required:true
     }
};
var validationMessages = {
		list_name: {
		required:"List name is required"
	}
};
$(document).ready(function(){
	$("#addListForm").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>