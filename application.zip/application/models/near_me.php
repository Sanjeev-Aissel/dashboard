<?php
/**
 * Controller for Near ME feature
 * @author Laxman K
 * @since 6.0.9 iMap v1.0
 * @package application.controllers	
 * @created on 27-10-2014
 * 
 */

class Near_me extends model{
	
	function Near_me(){
		parent::model();
                $this->load->model('specialty');
                $this->load->model('organization');
	}

	function getIcontactNames($userLat,$userLong,$radius=NEAR_ME_DISTANCE_RADIUS,$oldRadius=NEAR_ME_DISTANCE_RADIUS,$enableLimit=false, $offset=0,$limit=NEAR_ME_RECORDS_LIMIT_PER_REQUEST,$count=false){
		$returnData	= array();
		$unit	= 3959; // 3959 for miles and 6371 for kilometers
		if($count){
			$this->db->select("DISTINCT icontacts.id");
		}else{
			//$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,cities.Latitude,cities.Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
			$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,additional_contacts.latitude as Latitude,additional_contacts.longitude as Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
		}
		//$this->db->select("($unit * ACOS(COS(RADIANS($userLat)) * COS(RADIANS(cities.Latitude)) * COS(RADIANS(cities.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(cities.Latitude)))) AS distance");
		$this->db->select("($unit * ACOS(COS(RADIANS($userLat)) * COS(RADIANS(additional_contacts.Latitude)) * COS(RADIANS(additional_contacts.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(additional_contacts.Latitude)))) AS distance");
		$this->db->join('additional_contacts','additional_contacts.kol_id=icontacts.id');
		$this->db->join('cities','cities.CityId=additional_contacts.city_id');
		$this->db->join('survey_answers','survey_answers.nominee_id=additional_contacts.kol_id','left');
		$this->db->where('additional_contacts.present_address',1);
		if($radius>$oldRadius){
			//$this->db->having('distance>',$oldRadius,false);
			$this->db->having('distance<=',$radius,false);
		}else{
			$this->db->having('distance<=',$radius,false);
		}
		//$this->db->group_by('cities.CityId');
		if($enableLimit && !$count){
			$this->db->limit($limit,$offset);
		}
		$this->db->order_by('distance');
		$resultSet	= $this->db->get('icontacts');
		$noOfRecords	= $resultSet->num_rows();
		if($count){
			return $noOfRecords;
		}
		//echo $this->db->last_query();
		$currentLat	= 0;
		$currentLong	= 0;
		$betweenDistance	=	'0.00'; 
		$incrementStepsCount	= 0;
		foreach($resultSet->result_array() as $row){
			$address = array_filter(array($row['City'],$row['state_name'],$row['postal_code'],$row['country_name']));
			$row['type']	= '';
			if($row['influcener_id']>0){
				$row['type']	= 'influcener';
			}
			unset($row['state_name']);
			unset($row['influcener_id']);
			unset($row['postal_code']);
			unset($row['country_name']);
			$row['address']	= $row['address_line_1'].', <br />'.implode(', ',$address);
			$randomLat	= $betweenDistance.mt_rand();
			$randomLong	= $betweenDistance.mt_rand();
			$incrementStepsCount++;
			if($currentLat==$row['Latitude'] && $currentLong==$row['Longitude']){
				switch($incrementStepsCount%4){
					case 0:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
					case 1:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 2:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 3:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
				}
			}else{
				$currentLat	= $row['Latitude'];
				$currentLong	= $row['Longitude'];
				$incrementStepsCount	= 0;
			}
			$row['distance']	= round($row['distance'],5);
			$returnData[] = $row;
		}
		return $returnData;
	}
        
        function getKolNames($userLat,$userLong,$radius=NEAR_ME_DISTANCE_RADIUS,$oldRadius=NEAR_ME_DISTANCE_RADIUS,$enableLimit=false, $offset=0,$limit=NEAR_ME_RECORDS_LIMIT_PER_REQUEST,$count=false){
                $returnData	= array();
		$unit	= 3959; // 3959 for miles and 6371 for kilometers
                $this->db->join("cities","cities.CityId = kols.city_id");
                $this->db->join("regions","regions.RegionID = kols.state_id");
                $this->db->join("countries","countries.CountryId = kols.country_id ");
		if($count){
			$this->db->select("DISTINCT kols.*, cities.*, countries.*, regions.*");
                        $this->db->where("kols.status","completed");
		}else{
			//$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,cities.Latitude,cities.Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
			//$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,additional_contacts.latitude as Latitude,additional_contacts.longitude as Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
                        $this->db->select("DISTINCT kols.*, cities.*, countries.*, regions.*",false);
                        $this->db->where("kols.status","completed");
		}
		//$this->db->select("($unit * ACOS(COS(RADIANS($userLat)) * COS(RADIANS(cities.Latitude)) * COS(RADIANS(cities.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(cities.Latitude)))) AS distance");
		$this->db->select("($unit * (ACOS(COS(RADIANS($userLat)) * COS(RADIANS(cities.Latitude)) * COS(RADIANS(cities.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(cities.Latitude)))) AS distance");
		//$this->db->join('additional_contacts','additional_contacts.kol_id=icontacts.id');
		//$this->db->join('cities','cities.CityId=additional_contacts.city_id');
		//$this->db->join('survey_answers','survey_answers.nominee_id=additional_contacts.kol_id','left');
		//$this->db->where('additional_contacts.present_address',1);
		if($radius>$oldRadius){
			//$this->db->having('distance>',$oldRadius,false);
			$this->db->having('distance<=',$radius,false);
		}else{
			$this->db->having('distance<=',$radius,false);
		}
		//$this->db->group_by('cities.CityId');
		if($enableLimit && !$count){
			$this->db->limit($limit,$offset);
		}
		$this->db->order_by('distance');
		$resultSet	= $this->db->get('kols');
		$noOfRecords	= $resultSet->num_rows();
		if($count){
			return $noOfRecords;
		}
		$currentLat	= 0;
		$currentLong	= 0;
		$betweenDistance	=	'0.00'; 
		$incrementStepsCount	= 0;
		foreach($resultSet->result_array() as $row){
			$address = array_filter(array($row['City'],$row['Region'],$row['postal_code'],$row['Country']));
			$row['type']	= '';
			if($row['id']>0){
				$row['type']	= 'kol';
			}
			//unset($row['Region']);
			//unset($row['id']);
			//unset($row['postal_code']);
			//unset($row['Country']);
                        $row['organization'] = $this->organization->getOrgNameByOrgId($row['org_id']);
                        $row['specialty'] = $this->specialty->getSpecialtyById($row['specialty']);
			$row['address']	= $row['address1'].$row['address2'].', <br />'.implode(', ',$address);
			$randomLat	= $betweenDistance.mt_rand();
			$randomLong	= $betweenDistance.mt_rand();
			$incrementStepsCount++;
			if($currentLat==$row['Latitude'] && $currentLong==$row['Longitude']){
				switch($incrementStepsCount%4){
					case 0:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
					case 1:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 2:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 3:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
				}
			}else{
				$currentLat	= $row['Latitude'];
				$currentLong	= $row['Longitude'];
				$incrementStepsCount	= 0;
			}
			$row['distance']	= round($row['distance'],5);
			$returnData[] = $row;
		}
		return $returnData;
        }
        
function getNames($userLat,$userLong,$radius=NEAR_ME_DISTANCE_RADIUS,$oldRadius=NEAR_ME_DISTANCE_RADIUS,$enableLimit=false, $offset=0,$limit=NEAR_ME_RECORDS_LIMIT_PER_REQUEST,$count=false){
		$returnData	= array();
		$unit	= 3959; // 3959 for miles and 6371 for kilometers
		$this->db->join("cities","cities.CityId = kols.city_id");
		$this->db->join("regions","regions.RegionID = kols.state_id");
		$this->db->join("countries","countries.CountryId = kols.country_id ");
		if($count){
			$this->db->select("DISTINCT kols.id");
		}else{
			$this->db->join('specialties','specialties.id = kols.specialty', 'left');
			$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
			//$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,cities.Latitude,cities.Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
			//$this->db->select("DISTINCT survey_answers.nominee_id AS influcener_id,additional_contacts.full_name as name,icontacts.*,additional_contacts.city_id,cities.City,additional_contacts.latitude as Latitude,additional_contacts.longitude as Longitude,additional_contacts.state_name,additional_contacts.country_name,additional_contacts.postal_code,additional_contacts.address_line_1",false);
			$this->db->select("DISTINCT kols.id AS id, kols.salutation, concat(kols.first_name, ' ', kols.middle_name, ' ', kols.last_name) as name,profile_image,gender,kols.city_id,cities.City,cities.Latitude,cities.Longitude,regions.Region as state_name,countries.Country as country_name,kols.postal_code,kols.address1,countries.Country, specialties.specialty,organizations.name as organization",false);
		}
		//$this->db->select("($unit * ACOS(COS(RADIANS($userLat)) * COS(RADIANS(cities.Latitude)) * COS(RADIANS(cities.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(cities.Latitude)))) AS distance");
		$this->db->select("($unit * ACOS(COS(RADIANS($userLat)) * COS(RADIANS(cities.Latitude)) * COS(RADIANS(cities.Longitude)-RADIANS($userLong))+ SIN(RADIANS($userLat)) * SIN(RADIANS(cities.Latitude)))) AS distance");
		//$this->db->join('additional_contacts','additional_contacts.kol_id=icontacts.id');
		//$this->db->join('cities','cities.CityId=additional_contacts.city_id');
		//$this->db->join('survey_answers','survey_answers.nominee_id=additional_contacts.kol_id','left');
		//$this->db->where('additional_contacts.present_address',1);
		if($radius>$oldRadius){
			//$this->db->having('distance>',$oldRadius,false);
			$this->db->having('distance<=',$radius,false);
		}else{
			$this->db->having('distance<=',$radius,false);
		}
		//$this->db->group_by('cities.CityId');
		if($enableLimit && !$count){
			$this->db->limit($limit,$offset);
		}
		$this->db->order_by('distance');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		
		$resultSet	= $this->db->get('kols');
		//pr($this->db->last_query());exit;
		$noOfRecords	= $resultSet->num_rows();
		if($count){
			return $noOfRecords;
		}
		//echo $this->db->last_query();
		$currentLat	= 0;
		$currentLong	= 0;
		$betweenDistance	=	'0.00'; 
		$incrementStepsCount	= 0;
		foreach($resultSet->result_array() as $row){
			$address = array_filter(array($row['address1'],$row['address2'],$row['City'],$row['state_name'],$row['postal_code'],$row['country_name']));
			$row['type']	= '';
			if($row['influcener_id']>0){
				$row['type']	= 'influcener';
			}
			unset($row['state_name']);
			unset($row['influcener_id']);
			unset($row['postal_code']);
			unset($row['country_name']);
                        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                        $row['salutation'] = $arrSalutations[$row['salutation']];
			$row['address']	= implode(', ',$address);
			$randomLat	= $betweenDistance.mt_rand();
			$randomLong	= $betweenDistance.mt_rand();
			$incrementStepsCount++;
			if($currentLat==$row['Latitude'] && $currentLong==$row['Longitude']){
				switch($incrementStepsCount%4){
					case 0:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
					case 1:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 2:
							$row['Latitude']	= $currentLat + $randomLat;
							$row['Longitude']	= $currentLong - $randomLong;
						break;
					case 3:
							$row['Latitude']	= $currentLat - $randomLat;
							$row['Longitude']	= $currentLong + $randomLong;
						break;
				}
			}else{
				$currentLat	= $row['Latitude'];
				$currentLong	= $row['Longitude'];
				$incrementStepsCount	= 0;
			}
			$row['distance']	= round($row['distance'],5);
			$returnData[] = $row;
		}
		return $returnData;
	}
}

