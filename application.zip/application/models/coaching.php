<?php

/**
 * Model for KOL rating
 * 
 * @package application.models
 * @author Laxman K
 * @since KOLM v3.7 Abbott 1.0
 * @created on  17-03-2012
 */
class Coaching extends model {

    function Coaching() {
        parent::model();
        $this->load->model('Kol');
        $this->load->model("Client_User");
      $this->load->model('common_helpers');
      $this->load->model('customer_engagement');
    }

    function getInteractionTopics() {
        $this->db->select("name,id");

        $arrCoachingResultSet = $this->db->get('interaction_topics');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getManagerId($id) {
        $this->db->select("monitored_by");
        $this->db->where('id', $id);
        $arrCoachingResultSet = $this->db->get('compliance_monitoring');
        $id = $arrCoachingResultSet->row_array();
        return $id["monitored_by"];
    }

    function getManagers($id) {
        $this->db->select("first_name,last_name,id");
        if ($id != '')
            $this->db->where('id', $id);
        $this->db->where('user_role_id', 2);
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2));
        } 
        $arrCoachingResultSet = $this->db->get('client_users');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }

        if ($id != '') {
            $result = $arrCoachingResultSet->row_array();
            return $result["first_name"] . " " . $result["last_name"];
        } else
            return $arrReturnData;
    }

    function getInteractionTypes() {
        $this->db->select("name,id");

        $arrCoachingResultSet = $this->db->get('interaction_types');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getInteractionProdcuts() {
        $this->db->select("name,id");

        $arrCoachingResultSet = $this->db->get('products');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getAllKols() {
        $arrKolNames = array();
        $this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name');
//		$this->db->where('kols.status',COMPLETED);
        if ($this->session->userdata('name_order') == 2)
            $this->db->order_by('kols.last_name,kols.first_name');
        else if ($this->session->userdata('name_order') == 1)
            $this->db->order_by('kols.first_name,kols.last_name');
        else
            $this->db->order_by('kols.first_name,kols.middle_name,kols.last_name');
        $result = $this->db->get('kols');
        foreach ($result->result_array() as $row) {
            $arrKolNames[] = $row;
        }
        return $arrKolNames;
    }

    function exportCoaching($arrInteractionIds, $filters) {

        $arrFilterdCoachings = array();

        $arrFilter = json_decode($filters);
        $filtersToPass = json_encode($arrFilter->filters);

        $page = $arrFilter->page;
        $sidx = $arrFilter->sidx;
        $sord = $arrFilter->sord;
        $start = 10 * ($page - 1);

        $gridPageParam = array("page" => $page, "limit" => '', "sidx" => $sidx, "start" => $start, "sord" => $sord);

        $arrCoachings = $this->listCoaching('', $filtersToPass, $gridPageParam, false);



        foreach ($arrCoachings as $key => $value) {
            if (count($arrFilter->filters->rules) > 0 && count($arrCoachings) <= 10) {
                if (in_array($value["id"], $arrInteractionIds)) {
                    $arrFilterdCoachings[] = array("id" => $value["id"],"generic_id"=>$value["generic_id"], "username" => $value["username"], "specialty" => $value["specialty"], "status" => $value["status"], "date" => $value["date"], "kol_id" => $value["kol_id"], "evaluated_by" => $value["evaluated_by"]);
                }
            } else
                $arrFilterdCoachings[] = array("id" => $value["id"],"generic_id"=>$value["generic_id"], "username" => $value["username"], "specialty" => $value["specialty"], "status" => $value["status"], "date" => $value["date"], "kol_id" => $value["kol_id"], "evaluated_by" => $value["evaluated_by"]);
        }
        return $arrFilterdCoachings;
    }

    function exportCompliance($arrInteractionIds, $filters) {

        $arrFilterdCompliances = array();
        $arrFilter = json_decode($filters);
        $filtersToPass = json_encode($arrFilter->filters);


        $page = $arrFilter->page;
        $sidx = $arrFilter->sidx;
        $sord = $arrFilter->sord;
        $start = 10 * ($page - 1);

        $gridPageParam = array("page" => $page, "limit" => '', "sidx" => $sidx, "start" => $start, "sord" => $sord);
        $arrCompliances = $this->listCompliance('', $filtersToPass, $gridPageParam, false);


        foreach ($arrCompliances as $key => $value) {
            if ($value["interaction_type"] == 1)
                $type = 'One-on-One';
            else
                $type = 'Group';
            if (count($arrFilter->filters->rules) > 0 && count($arrCompliances) <= 10) {
                if (in_array($value["id"], $arrInteractionIds)) {

                    $arrFilterdCompliances[] = array("id" => $value["id"],"generic_id"=>$value["generic_id"], "date" => $value["date"], "interaction_type" => $type, "kols" => $value["kols"], "monitored_by_name" => $value["monitored_by_name"], "manager_name" => $value["manager_name"], "compliance_violation" => $value["compliance_violation"], "created_user" => $value["created_user"]);
                }
            } else
                $arrFilterdCompliances[] = array("id" => $value["id"], "generic_id"=>$value["generic_id"],"date" => $value["date"], "interaction_type" => $type, "kols" => $value["kols"], "monitored_by_name" => $value["monitored_by_name"], "manager_name" => $value["manager_name"], "compliance_violation" => $value["compliance_violation"], "created_user" => $value["created_user"]);
        }
        return $arrFilterdCompliances;
    }

    function getComplianceStateCityId($id) {
        $this->db->select("state_id,city_id");
        $this->db->where('id', $id);

        $arrCoachingResultSet = $this->db->get('compliance_monitoring');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getEmailId($id) {
        $this->db->select('email,first_name,last_name');
        $this->db->where('id', $id);
        $query = $this->db->get('client_users');
        $result = $query->row_array();
        $email = $result["email"];
        return $result;
    }

    function getAllOrgs() {
        $arrOrgs = array();
        $this->db->select('organizations.id,organizations.name');
        $this->db->order_by('organizations.name');
        $result = $this->db->get('organizations');
        foreach ($result->result_array() as $row) {
            $arrOrgs[] = $row;
        }
        return $arrOrgs;
    }

    function getAllSpecialties() {
        $arrSpecialty = array();
        $resultSet = $this->db->get('specialties');
        foreach ($resultSet->result_array() as $row) {
            $arrSpecialty[] = $row;
        }
        return $arrSpecialty;
    }

    function getAllAreas() {
       $arrTherapeutic = array();
        $this->db->select('id,name');
         $this->db->where('status', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('theraputic_areas');
        foreach ($result->result_array() as $row) {
            $arrTherapeutic[] = $row;
        }
        return $arrTherapeutic;
    }

    function getAllEngagement() {
        $arrEngagement = array();
        $this->db->select("status");
        $this->db->where('is_active !=1');
        $resultSet = $this->db->get('engagement_status');
        foreach ($resultSet->result_array() as $row) {
            $arrEngagement[] = $row;
        }
        return $arrEngagement;
    }

    /**
     * Save coaching details to "coachings" Table
     * @access 		public
     * @author 		shivu.dundur <shivu.dundur@bilva.co.in>
     * @version 	
     * @since 		Oct 01, 2012
     * @param 		Array - Coaching to be saved
     * @return 		Boolean
     */
    function saveCoachings($arrCoaching) {        
        if ($this->db->insert('coachings', $arrCoaching)) {            
            return $this->db->insert_id();
        } else {
            return false;
        }     
    }

    function getAreaById($areaId) {
        $specialty = '';
        $this->db->where('id', $areaId);
        $arrSpecialty = $this->db->get('theraputic_areas');
        foreach ($arrSpecialty->result_array() as $row) {
            $specialty = $row['name'];
        }
        return $specialty;
    }

    function getInteractionCat() {

        $arrCat = array();
        $this->db->select("name,id");
        $this->db->where('is_active !=1');
        $resultSet = $this->db->get('interaction_category');

        foreach ($resultSet->result_array() as $row) {
            $arrCat[] = $row;
        }

        return $arrCat;
    }

    function listCoaching($id = '', $filterData, $gridParam, $count = NULL) {



        if ($id == '') {
            $rules = json_decode($filterData);


            foreach ($rules->rules as $values) {

                if ($values->field == "username")
                    $username = $values->data;

                if ($values->field == "specialty")
                    $specialty = $values->data;

                if ($values->field == "status")
                    $status = $values->data;

                if ($values->field == "date")
                    $date = $values->data;

                if ($values->field == "kol_id")
                    $kol_id = $values->data;

                if ($values->field == "evaluated_by")
                    $evaluated_by = $values->data;
                
                 if ($values->field == "generic_id")
                    $generic_id = $values->data;
            }
        }

        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $arrCoaching = array();
        if ($count)
            $this->db->select('count(distinct coachings.id) as count');
        else
            $this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,coachings.* ');
        $this->db->join('client_users', 'client_users.id=coachings.username', 'left');

        if (isset($specialty)) {
            $this->db->join('theraputic_areas', 'coachings.specialty=theraputic_areas.id', 'left');
            $this->db->like('theraputic_areas.name', $specialty);
        }
        if (isset($username)) {
              $this->db->where("(client_users.first_name LIKE '%".$username."%'  OR  client_users.last_name LIKE '%".$username."%')" );
        }
        if (isset($status)) {

            $this->db->like('coachings.status', $status);
        }
        if (isset($evaluated_by)) {
             $this->db->join('client_users as evaluated', 'evaluated.id=coachings.evaluated_by', 'left');
            $this->db->where("(evaluated.first_name LIKE '%".$evaluated_by."%'  OR  evaluated.last_name LIKE '%".$evaluated_by."%')" );
//            $this->db->or_like('evaluated.last_name', $evaluated_by);
        }

        if (isset($date)) {

            $this->db->like('coachings.date', $date);
        }

        if (isset($kol_id)) {

            $this->db->like('coachings.hcname', $kol_id);
        }
            if (isset($generic_id)) {

            $this->db->like('coachings.generic_id', $generic_id);
        }
        if (!empty($id)) {
            $this->db->where('coachings.id', $id);
        }



        //Security : user will see hi own data, manager will see his team data, and super manager will see all data
        if ($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) {
            $this->db->where_in('coachings.username', $userIds);
        }else{
            $this->db->where('coachings.username', $userId);
        }

        if ($id == '' && isset($gridParam)) {

//          $this->db->where('coachings.id >=',$gridParam['start']);
            if (!$count)
                $this->db->limit($gridParam["limit"], $gridParam['start']);
            switch ($gridParam['sidx']) {
                case "username":$this->db->order_by('client_users.first_name', $gridParam['sord']);
                    break;
                case "specialty":$this->db->order_by('coachings.specialty', $gridParam['sord']);
                    break;
                case "status":$this->db->order_by('coachings.status', $gridParam['sord']);
                    break;
                case "date":$this->db->order_by('coachings.date', $gridParam['sord']);
                    break;
                case "kol_id":$this->db->order_by('coachings.hcname', $gridParam['sord']);
                    break;
                case "evaluated_by":$this->db->order_by('coachings.evaluated_by', $gridParam['sord']);
                    break;
            }
        }

        $arrCoachingResultSet = $this->db->get('coachings');
        //echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            if ($row['kol_id'] != '')
                $row['kol_id'] = $this->kolNameById($row['kol_id']);
            else
                $row['kol_id'] = $row['hcname'];
            $row['evaluated_by'] = $this->Client_User->getUserNameById($row['evaluated_by']);

            $row['created_on'] = sql_date_to_app_date($row['created_on']);
            $row['specialty'] = $this->coaching->getAreaById($row['specialty']);
            $row['username'] = $row['ufname'] . ' ' . $row['ulname'];
            $row['status'] = ucwords($row['status']);
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrCoaching[] = $row;
        }
        return $arrCoaching;
    }

    function editCoaching($id = '') {
        $arrCoaching = array();
        $this->db->select('coachings.* ');
        if (!empty($id)) {
            $this->db->where('coachings.id', $id);
        }
        $arrCoachingResultSet = $this->db->get('coachings');
        //echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $row['kol_id'] = explode(',', $row['kol_id']);
            $row['evaluated_by'] = $this->Client_User->getUserNameById($row['evaluated_by']);
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrCoaching[] = $row;
        }
//                pr($arrCoaching);
        return $arrCoaching;
    }

    function kolNameById($userIds = 0) {

        $userIds = trim($userIds);

        if (empty($userIds)) {
            $userIds = 0;
        }
        $usernames = '';
//		$query				= "SELECT CONCAT_WS(' ',kols.".FIRST_ORDER.",kols.".SECOND_ORDER.",kols.".THIRD_ORDER.") as username FROM kols WHERE kols.id IN (".$userIds.")";
        $query = "SELECT kols.id,kols.first_name,kols.middle_name,kols.last_name FROM kols WHERE kols.id IN (" . $userIds . ")";
        $arrKolUsersResultSet = $this->db->query($query);
        //echo $this->db->last_query();
        $separator = '';
        foreach ($arrKolUsersResultSet->result_array() as $usersRow) {

//			$usernames		.= $separator.$usersRow['username'];
            $usernames .= $separator . "<a href='" . base_url() . "kols/view/" . $usersRow['id'] . "' target='_blank' title=''>" . $this->common_helpers->get_name_format($usersRow['first_name'], $usersRow['middle_name'], $usersRow['last_name']) . "</a>";
            $separator = ', ';
        }
        return $usernames;
    }

    function updateCoachings($arrCoaching) {

        $this->db->where('id', $arrCoaching['id']);
        if ($this->db->update('coachings', $arrCoaching)) {

            return true;
        } else {
            return false;
        }
    }

    function deleteCoaching($id) {
        $this->db->where('id', $id);
        $this->db->delete('coachings');
    }

    function saveMedicalInsight($arrData) {
        $arrData['created_by'] = $this->session->userdata('user_id');
        $arrData['created_on'] = date("Y-m-d H:i:s");
        if ($this->db->insert('medical_insight', $arrData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function updateMedicalInsight($arrData) {
        $arrData['created_by'] = $this->session->userdata('user_id');
        $arrData['created_on'] = date("Y-m-d H:i:s");
//		$arrData['topics']		= implode(', ',$arrData['topics']);
        $this->db->where('id', $arrData['id']);
        if ($this->db->update('medical_insight', $arrData)) {
            return true;
        } else {
            return false;
        }
    }

//	function listMedicalInsight($id=''){
//		$arrReturnData 				= array();
//		$this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,medical_insight.* ');
//		$this->db->join('client_users','client_users.id=medical_insight.created_by','left');
//		if(!empty($id)){
//			$this->db->where('medical_insight.id',$id);
//		}
//		$this->db->order_by('medical_insight.id','desc');
//		$arrCoachingResultSet		= $this->db->get('medical_insight');
//		//echo $this->db->last_query();
//		foreach($arrCoachingResultSet->result_array() as $row){
//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
//			$row['created_user']= $row['ufname'].' '.$row['ulname'];
//			$arrReturnData[]	= $row;
//		}
//		return $arrReturnData;
//	}
    function listMedicalInsight($limit = null, $startFrom = null, $count = null, $sidx = '', $sord = '', $Details = '',$allUserFlag, $kolId = '', $id = '') {
//        $from=$_POST['from'];
//        $to=$_POST['to'];
        $from= ($this->input->post('from')) ? $this->input->post('from') :$Details['from'] ;
        $to= ($this->input->post('to')) ? $this->input->post('to') :$Details['to'] ;
        if($allUserFlag==0){
            $manager_id= ($this->input->post('manager_id')) ? $this->input->post('manager_id') :$Details['manager_id'] ;
        }   
        $users=$this->common_helpers->getManagerAlignedUsers($manager_id);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getManagerAlignedUsers($userId); 
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $clientId = $this->session->userdata('client_id');
        $arrReturnData = array();
        $this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,kols.first_name as kolfname ,kols.last_name as kollname,medical_insight.* ', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        $this->db->join('kols', 'kols.id=medical_insight.kol_id', 'left');
//                $this->db->where('client_users.client_id',$clientId);
        
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        } 
        if (!empty($id)) {
            $this->db->where('medical_insight.id', $id);
        }
        if ($kolId != '' && $kolId != 0) {
//                     echo $kolId;
            $this->db->where('medical_insight.kol_id', $kolId);
        } 
        if (!$count) {
            if ($Details['start'] >= 0) {
                $this->db->limit($Details['limit'], $Details['start']);
            }
        }
        if ($from != '')
            $this->db->where("medical_insight.created_on >='" . $from . "'");
        if ($to != '')
            $this->db->where("medical_insight.created_on <='" . $to . "'");
        if ($manager_id != '')
            $this->db->where_in('medical_insight.created_by', $users);
        if ($Details['topics'] != '') {
            $this->db->like('medical_insight.topics', $Details['topics']);
        }
         if ($Details['generic_id'] != '') {
            $this->db->like('medical_insight.generic_id', $Details['generic_id']);
        }
        if ($Details['specialty'] != '') {
            $this->db->like('medical_insight.specialty', $Details['specialty']);
        }
        if ($Details['product'] != '') {
            $this->db->like('medical_insight.product', $Details['product']);
        }
        if ($Details['source_type'] != '') {
            $this->db->like('medical_insight.source_type', $Details['source_type']);
        }
        if ($Details['agent'] != '') {
            $this->db->like('medical_insight.agent', $Details['agent']);
        }
        if ($Details['sphere_of_influence'] != '') {
            $this->db->like('medical_insight.sphere_of_influence', $Details['sphere_of_influence']);
        }
        if ($Details['summary'] != '') {
            $this->db->like('medical_insight.summary', $Details['summary']);
        }
        if ($Details['relevance'] != '') {
            $this->db->like('medical_insight.relevance', $Details['relevance']);
        }
        if ($Details['actions_to_consider'] != '') {
            $this->db->like('medical_insight.actions_to_consider', $Details['actions_to_consider']);
        }
        if ($Details['kol_id'] != '') {
            $this->db->like('CONCAT(kols.first_name,kols.last_name)', $Details['kol_id']);
        }
        if ($Details['created_on'] != '') {
            $this->db->like('medical_insight.created_on', $Details['created_on']);
        }
        if ($Details['created_user'] != '') {
            $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $Details['created_user']);
        }
        if($userRole == ROLE_USER && $allUserFlag==0){
           $this->db->where('medical_insight.created_by', $userId);
       }
       if(($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office" && $allUserFlag==0){
           $this->db->where_in('medical_insight.created_by', $userIds);
       }
        if ($count) {
            $this->db->distinct();
            $count = $this->db->count_all_results('medical_insight');
            return $count;
        } else {
            if ($sidx != '' && $sord != '') {
                switch ($sidx) {
                    case 'topics' : $this->db->order_by("medical_insight.topics", $sord);
                        break;
                    case 'specialty' :$this->db->order_by("medical_insight.specialty", $sord);
                        break;
                    case 'agent' :$this->db->order_by("medical_insight.agent", $sord);
                        break;
                    case 'sphere_of_influence' :$this->db->order_by("medical_insight.sphere_of_influence", $sord);
                        break;
                    case 'product' :$this->db->order_by("medical_insight.product", $sord);
                        break;
                    case 'source_type' :$this->db->order_by("medical_insight.source_type", $sord);
                        break;
                    case 'summary' :$this->db->order_by("medical_insight.summary", $sord);
                        break;
                    case 'relevance' :$this->db->order_by("medical_insight.relevance", $sord);
                        break;
                    case 'actions_to_consider' :$this->db->order_by("medical_insight.actions_to_consider", $sord);
                        break;
                    case 'kol_id' :$this->db->order_by('CONCAT(kols.first_name,kols.last_name)', $sord);
                        break;
                    case 'created_user' :$this->db->order_by('CONCAT(client_users.first_name,client_users.last_name)', $sord);
                        break;
                      case 'generic_id' :$this->db->order_by("medical_insight.generic_id", $sord);
                        break;
                     case 'created_on' :$this->db->order_by("medical_insight.created_on", $sord);
                        break;
                     
                }
                //$this->db->order_by($sidx,$sord);
            }
            $this->db->order_by('medical_insight.created_on', 'desc');
//                $this->db->limit(30);
            $arrCoachingResultSet = $this->db->get('medical_insight');
//		echo $this->db->last_query();
//                exit();
            foreach ($arrCoachingResultSet->result_array() as $row) {
//                    pr($row);
//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
                $row['created_user'] = $row['ufname'] . ' ' . $row['ulname'];
                $row['created_on'] = sql_date_to_app_date($row['created_on']);
                //$row['kol_id']= $row['kolfname'].' '.$row['kollname'];
                 
                if(!empty( $row['kol_id'])){
                if (IS_IPAD_REQUEST) {
                    $row['kol_id'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $row['kol_id'] . '">' . $this->common_helpers->get_name_format($row['kolfname'], $row['kolmname'], $row['kollname']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                } else {
                    $row['kol_id'] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $this->common_helpers->get_name_format($row['kolfname'], $row['kolmname'], $row['kollname']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
                }
                }
                else
                    $row['kol_id'] = "";
                if (!empty($Details['excelExport'])) {
                    $row['kol_id'] = $this->common_helpers->get_name_format($row['kolfname'], $row['kolmname'], $row['kollname']);
                }
                if($row['topics'] == '0')
                	$row['topics'] = "";
                $arrReturnData[] = $row;
            }

            return $arrReturnData;
        }
    }

    function editMedicalInsight($id = '') {
        $arrReturnData = array();
        $this->db->select('medical_insight.* ');
        if (!empty($id)) {
            $this->db->where('medical_insight.id', $id);
        }
        if ($kolId != '' && $kolId != 0) {
//                     echo $kolId;
            $this->db->where('medical_insight.kol_id', $kolId);
        }
        $this->db->order_by('medical_insight.id', 'desc');
        $arrCoachingResultSet = $this->db->get('medical_insight');
        //echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
            $row['created_user'] = $row['ufname'] . ' ' . $row['ulname'];
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function deleteMedicalInsight($id) {
        $this->db->where('id', $id);
        $this->db->delete('medical_insight');
    }

    function saveComplianceMonitoring($arrData) {
        $arrData['created_by'] = $this->session->userdata('user_id');
        $arrData['created_on'] = date("Y-m-d H:i:s");
        $arrData['date'] = app_date_to_sql_date($arrData['date']);
        $arrData['compliance_violated_by_date'] = app_date_to_sql_date($arrData['compliance_violated_by_date']);
        $kols = $arrData['kols'];

        $contact_type = $arrData['contact_type'];
        $organization = $arrData['organization'];
        $topics = $arrData['topics'];
        $additionalTopics = $arrData['additional_topics'];
        unset($arrData['kols']);
        unset($arrData['organization']);
        unset($arrData['topics']);
        unset($arrData['additional_topics']);
//                pr($arrData);
//                exit();
        if ($this->db->insert('compliance_monitoring', $arrData)) {
            $id = $this->db->insert_id();



            foreach ($kols as $values) {
                $preparedStatements = "insert into compliance_monitoring_kols(compliance_monitoring_id,kol_id) values (" . $id . ", " . $values . ")";
                $this->db->query($preparedStatements);
            }


            foreach ($organization as $orgValues) {
                $preparedStatements = "insert into compliance_monitoring_organizations(compliance_monitoring_id,org_id) values (" . $id . ", " . $orgValues . ")";
                $this->db->query($preparedStatements);
            }

            if (sizeof($topics) > 0) {
                $preparedStatements = "insert into compliance_monitoring_topics(compliance_monitoring_id,type_id,product_id,topic_id,is_additional_topic) values ";
                $separator = "";
                foreach ($topics as $key => $arrTopicData) {
                    $preparedStatements .= "$separator($id," . $arrTopicData['interaction_type'] . "," . $arrTopicData['product_id'] . "," . $arrTopicData['topic_id'] . ",0)";
                    $separator = ",";
                }
                $this->db->query($preparedStatements);
            }
            if (sizeof($additionalTopics) > 0) {
                $preparedStatements = "insert into compliance_monitoring_topics(compliance_monitoring_id,type_id,product_id,topic_id,is_additional_topic) values ";
                $separator = "";
                foreach ($additionalTopics as $key => $ids) {
                    $arrTopicData = explode("_", $ids);
                    $preparedStatements .= "$separator($id,$arrTopicData[0],$arrTopicData[1],$arrTopicData[2],1)";
                    $separator = ",";
                }
                //$this->db->query($preparedStatements);
            }
            return $id;
        } else {
            return false;
        }
    }

    function updateComplianceMonitoring($arrData, $compliance_id) {
        $arrData['date'] = app_date_to_sql_date($arrData['date']);
        $arrData['compliance_violated_by_date'] = app_date_to_sql_date($arrData['compliance_violated_by_date']);
        $kols = $arrData['kols'];
        $contact_type = $arrData['contact_type'];
        $organization = $arrData['organization'];
        $topics = $arrData['topics'];
        $additionalTopics = $arrData['additional_topics'];

        unset($arrData['kols']);
        unset($arrData['organization']);
        unset($arrData['topics']);
        unset($arrData['additional_topics']);

        foreach ($kols as $values) {

            $preparedStatements = "insert into compliance_monitoring_kols(compliance_monitoring_id,kol_id) values (" . $compliance_id . ", " . $values . ")";
            $this->db->query($preparedStatements);
        }


        foreach ($organization as $orgValues) {
            $preparedStatements = "insert into compliance_monitoring_organizations(compliance_monitoring_id,org_id) values (" . $compliance_id . ", " . $orgValues . ")";
            $this->db->query($preparedStatements);
        }
        if (sizeof($topics) > 0) {
            $preparedStatements = "insert into compliance_monitoring_topics(compliance_monitoring_id,type_id,product_id,topic_id,is_additional_topic) values ";
            $separator = "";
            foreach ($topics as $key => $arrTopicData) {
                $preparedStatements .= "$separator($compliance_id," . $arrTopicData['interaction_type'] . "," . $arrTopicData['product_id'] . "," . $arrTopicData['topic_id'] . ",0)";
                $separator = ",";
            }
            $this->db->query($preparedStatements);
        }
        if (sizeof($additionalTopics) > 0) {
            $preparedStatements = "insert into compliance_monitoring_topics(compliance_monitoring_id,type_id,product_id,topic_id,is_additional_topic) values ";
            $separator = "";
            foreach ($additionalTopics as $key => $ids) {
                $arrTopicData = explode("_", $ids);
                $preparedStatements .= "$separator($compliance_id,$arrTopicData[0],$arrTopicData[1],$arrTopicData[2],1)";
                $separator = ",";
            }
            //$this->db->query($preparedStatements);
        }


        $this->db->where('id', $compliance_id);
        if ($this->db->update('compliance_monitoring', $arrData))
            return true;
        else
            return false;
    }

    function listCompliance($id = '', $filterData, $gridParam, $count = NULL) {

ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);

        if ($id == '') {
            $rules = json_decode($filterData);
            foreach ($rules->rules as $values) {



                if ($values->field == "interaction_mode")
                    $mode = $values->data;

                if ($values->field == "kols")
                    $kols = $values->data;

                if ($values->field == "monitored_by_name")
                    $fma = $values->data;

                if ($values->field == "compliance_violation")
                    $voilation = $values->data;

                if ($values->field == "manager_name")
                    $manager = $values->data;

                if ($values->field == "created_user")
                    $created_by = $values->data;

                if ($values->field == "date")
                    $date = $values->data;
                
                if ($values->field == "generic_id")
                    $generic_id = $values->data;
            }
        }




        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $arrReturnData = array();
        if (!$count)
            $this->db->select('distinct client_users.first_name AS ufname, client_users.last_name AS ulname,compliance_monitoring.*,interaction_grouping.name as interaction_mode ,fma.first_name', false);
        else
            $this->db->select('count(distinct compliance_monitoring.id) as count');
        $this->db->join('client_users', 'client_users.id=compliance_monitoring.created_by', 'left');
        $this->db->join('client_users as monitor', 'monitor.id=compliance_monitoring.monitored_by', 'left');
        $this->db->join('client_users as fma', 'fma.id=compliance_monitoring.fma', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = compliance_monitoring.interaction_type', 'left');
        $this->db->join('compliance_monitoring_kols', 'compliance_monitoring.id = compliance_monitoring_kols.compliance_monitoring_id', 'left');
        $this->db->join('kols', 'kols.id = compliance_monitoring_kols.kol_id', 'left');
        $this->db->join('compliance_monitoring_organizations', 'compliance_monitoring.id = compliance_monitoring_organizations.compliance_monitoring_id', 'left');
        $this->db->join('organizations', 'organizations.id = compliance_monitoring_organizations.org_id', 'left');
        if (!empty($id)) {
            $this->db->where('compliance_monitoring.id', $id);
        }
        //$this->db->order_by('compliance_monitoring.date','desc');
        //Security : user will see hi own data, manager will see his team data, and super manager will see all data
//		if($userRole == ROLE_USER){
//			$this->db->where('compliance_monitoring.fma',$userId);
//		}

        if ($userRole == ROLE_USER) {
            $this->db->where('compliance_monitoring.fma', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('compliance_monitoring.fma', $userIds);
        }

        if (isset($fma)) {
            $this->db->like('fma.first_name', $fma);
            $this->db->or_like('fma.last_name', $fma);
        }
        if (isset($manager)) {

            $this->db->like('monitor.first_name', $manager);
            $this->db->or_like('monitor.last_name', $manager);
        }

        if (isset($voilation)) {

            $this->db->like('compliance_monitoring.compliance_violation', $voilation);
        }
        if (isset($created_by)) {

            $this->db->like('client_users.first_name', $created_by);
            $this->db->or_like('client_users.last_name', $created_by);
        }

        if (isset($mode)) {

            $this->db->like('interaction_grouping.name', $mode);
        }
        if (isset($date)) {

            $this->db->like('compliance_monitoring.date', $date);
        }

        if (isset($kols)) {
            $this->db->where("( kols.first_name  LIKE '%" . $kols . "%' OR  kols.last_name LIKE '%" . $kols . "%' OR kols.middle_name LIKE '%" . $kols . "%' or organizations.name LIKE '%" . $kols . "%')");
        }
if (isset($generic_id)) {

            $this->db->like('compliance_monitoring.generic_id', $generic_id);
        }

        if ($id == '' && isset($gridParam)) {

          
            if (!$count)
                $this->db->limit($gridParam["limit"], $gridParam['start']);
            switch ($gridParam['sidx']) {
                case "interaction_mode":$this->db->order_by('compliance_monitoring.interaction_type', $gridParam['sord']);
                    break;
                case "kols":$this->db->order_by('kols.last_name', $gridParam['sord']);
                    break;
                case "monitored_by_name":$this->db->order_by('fma.first_name', $gridParam['sord']);
                    break;
                case "compliance_violation":$this->db->order_by('compliance_monitoring.compliance_violation', $gridParam['sord']);
                    break;
                case "manager_name":$this->db->order_by('monitor.first_name', $gridParam['sord']);
                    break;
                case "created_user":$this->db->order_by('compliance_monitoring.created_by', $gridParam['sord']);
                    break;
                case "date":$this->db->order_by('compliance_monitoring.date', $gridParam['sord']);
                    break;
            }
        }
        $arrCoachingResultSet = $this->db->get('compliance_monitoring');
//                 echo $this->db->last_query();
        //echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $row['monitored_by_name'] = $this->Client_User->getUserNameById($row['fma']);
            $row['created_user'] = $row['ufname'] . ' ' . $row['ulname'];


            $row['compliance_violated_by_date'] = sql_date_to_app_date($row['compliance_violated_by_date']);
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrKols = $this->getComplianceKOLs($row['id']);
            $arrOrgs = $this->getComplianceOrgs($row['id']);
            $arrKolNames = array();
            $arrOrgNames = array();
            if ($row['id'] != '') {
                if (IS_IPAD_REQUEST) {
                    $arrKolNames[] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $arrKols[0]['id'] . '">' . $this->common_helpers->get_name_format($arrKols[0]['first_name'], $arrKols[0]['middle_name'], $arrKols[0]['last_name']) . '</a>';
                } else {
                    $arrKolNames[] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $arrKols[0]['id'] . '">' . $this->common_helpers->get_name_format($arrKols[0]['first_name'], $arrKols[0]['middle_name'], $arrKols[0]['last_name']) . '</a>';
                }
            } else{
                $arrKolNames[] = $row['hcpname'];
            }
            if (isset($arrOrgs[0])) {
                if (IS_IPAD_REQUEST)
                    $arrOrgNames[] = "<a href='" . base_url() . IPAD_URL_SEGMENT . "/organizations/view/" . $arrOrgs[0]['id'] . "' title=''>" . $arrOrgs[0]['name'] . "</a>";
                else
                    $arrOrgNames[] = "<a href='" . base_url() . "organizations/view/" . $arrOrgs[0]['id'] . "' target='_blank' title=''>" . $arrOrgs[0]['name'] . "</a>";
            }

//                        pr($row);
//                        exit();
//                        if($row['contact_type'] == "kol")


            $row['kols'] = $arrKolNames[0] . ", " . $arrOrgNames[0];
            $row['kols'] = trim($row['kols'], " ,");
//                        else
//                        $row['kols']	= implode(', ',$arrOrgNames);
            $row['compliance_id'] = $row['id'];
            $row["manager_name"] = $this->Client_User->getUserNameById($row['monitored_by']);
            if ($row["manager_name"] == '')
                $row["manager_name"] = $row['monitored_by_name'];
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getComplianceDetails($id = '') {
        $arrReturnData = array();
        $this->db->select("client_users.first_name as user_fname, client_users.last_name as user_lname, client_users.id as user_id,compliance_monitoring.*,interaction_grouping.name as interaction_mode, interaction_grouping.id as interaction_id");
        $this->db->join('client_users', 'client_users.id=compliance_monitoring.created_by', 'left');
        $this->db->join('interaction_grouping', 'interaction_grouping.id = compliance_monitoring.interaction_type', 'left');
        if (!empty($id)) {
            $this->db->where('compliance_monitoring.id', $id);
        }
        $this->db->order_by('compliance_monitoring.date', 'desc');
        $arrCoachingResultSet = $this->db->get('compliance_monitoring');
//            echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $row['monitored_by_name'] = $this->Client_User->getUserNameById($row['monitored_by']);
            $row['created_user'] = $row['ufname'] . ' ' . $row['ulname'];
            $row['date'] = sql_date_to_app_date($row['date']);
            $arrKols = $this->getComplianceKOLs($row['id']);
            $arrOrgs = $this->getComplianceOrgs($row['id']);
            $row['kols'] = $arrKols;
            $row['orgs'] = $arrOrgs;
            $row['compliance_id'] = $row['id'];
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function deleteCompliance($id) {
        $this->db->where('id', $id);
        $this->db->delete('compliance_monitoring');
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_topics');
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_kols');
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_organizations');
    }

    function getComplianceKOLs($id) {

        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $this->db->select("compliance_monitoring_kols.id as tableId,compliance_monitoring_kols.hcpname,kols.id,kols.salutation,kols.last_name,kols.middle_name,kols.first_name");
        $this->db->where('compliance_monitoring_kols.compliance_monitoring_id', $id);
        $this->db->join('kols', 'kols.id=compliance_monitoring_kols.kol_id', 'left');
        $arrCoachingResultSet = $this->db->get('compliance_monitoring_kols');
        //echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            if($row['id']=='')
                $row['first_name']=$row['hcpname'];
            $arrReturnData[] = $row;
        }
        //echo $this->db->last_query();
//        pr($arrReturnData);
        return $arrReturnData;
    }

    function getComplianceOrgs($id) {
        $this->db->select("organizations.id,organizations.name");
        $this->db->where('compliance_monitoring_organizations.compliance_monitoring_id', $id);
        $this->db->join('organizations', 'organizations.id=compliance_monitoring_organizations.org_id', 'left');
        $arrCoachingResultSet = $this->db->get('compliance_monitoring_organizations');
//		echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getComplianceTopics($id) {
        $arrData = array();
        $this->db->select("compliance_monitoring_topics.*");
        $this->db->where('compliance_monitoring_topics.compliance_monitoring_id', $id);

        $resultSet = $this->db->get('compliance_monitoring_topics');
        if ($resultSet->num_rows > 0) {
            foreach ($resultSet->result_array() as $row) {
                $arrData[] = $row;
            }
        }

        return $arrData;
    }

    function deleteComplianceMonitoringKOLs($id) {
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_kols');
    }

    function deleteComplianceMonitoringOrganizations($id) {
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_organizations');
    }

    function deleteComplianceMonitoringTopics($id) {
        $this->db->where('compliance_monitoring_id', $id);
        $this->db->delete('compliance_monitoring_topics');
    }

    function getTherapeuticAreaNames() {
        $arrTherapeutic = array();
        $this->db->select('id,name');
         $this->db->where('status', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('theraputic_areas');
        foreach ($result->result_array() as $row) {
            $arrTherapeutic[] = $row;
        }
        return $arrTherapeutic;
    }

    function therapeuticAreaIdByName($speciltyName) {
        $arrTherapeutic = array();
        $this->db->select('id,name');
        $this->db->where('name', $speciltyName);
        $result = $this->db->get('theraputic_areas');
        foreach ($result->result_array() as $row) {
            $arrTherapeutic[] = $row;
        }
        return $arrTherapeutic;
    }

    function getProductIdByName($productName) {
        $arrReturnData = array();
        $this->db->select('id,name');
        $this->db->where('name', $productName);
        $this->db->where('products.status', 1);
        $result = $this->db->get('products');
        foreach ($result->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getAllProduct() {
        $arrReturnData = array();
        $this->db->select('id,name');
        $this->db->where('name', $productName);
        $this->db->where('products.status', 1);
        $result = $this->db->get('products');
        foreach ($result->result_array() as $row) {
            $arrReturnData[] = $row;
        }
        return $arrReturnData;
    }

    function getProductByTheraputicArea($id) {
        $arrReturnData = array();
        /*$arrProducts = $this->common_helpers->getUserProducts();
        foreach ($arrProducts as $key => $value) {
            $productsArr[] = ($value['id']);
        }*/
        $this->db->select("id,name,type");
        $this->db->join('products', 'products.id=theraputic_area_products.product_id', 'left');
        /*if (count($productsArr) > 0)
            $this->db->where_in("theraputic_area_products.product_id", $productsArr);*/
        $this->db->where('theraputic_area_id', $id);
        $this->db->where('theraputic_area_products.status', 1);
        $this->db->order_by('name', 'ASC');
        $arrResultSet = $this->db->get('theraputic_area_products');
        $noProdId = 0;
        $otherId = 0;
	$noProdRow = array();
        $otherRow = array();
        foreach ($arrResultSet->result_array() as $row) {
            if(($row['name'] != "No Product") && ($row['name'] != "Other")){
                 $arrReturnData[] = $row; 
            }
            else if($row['name'] == "No Product"){
                    $noProdId = $row['id'];
                    $noProdRow = $row;
            }
            else{
                 $otherId = $row['id'];
                    $otherRow = $row;
            }
        }
        if($noProdId)
            $arrReturnData[] = $noProdRow;
         if($otherId)
            $arrReturnData[] = $otherRow; 
        return $arrReturnData;
    }

    function getKeyInsightByProduct($id, $specilaty) {
        $arrReturnData = array();

        $query = ("SELECT id,name FROM key_insight_topics_association LEFT join key_insight_topics
                    ON key_insight_topics_association.key_insight_topic_id=key_insight_topics.id where product_id=$id and theraputic_area_id=$specilaty and key_insight_topics_association.status=1 ORDER BY name ASC;");

        $arrResultSet = $this->db->query($query);
        foreach ($arrResultSet->result_array() as $row) {
            $arrReturnData[] = $row;
        }
//              echo $this->db->last_query();
        return $arrReturnData;
    }

    function getInvestigationalAgentNames() {
        $arrTherapeutic = array();
        $this->db->select('id,name');
        $this->db->where('is_active', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('investigational_agent');
        foreach ($result->result_array() as $row) {
            $arrInvestigational[] = $row;
        }
        return $arrInvestigational;
    }

    function getSourceTypeNames() {
        $arrSourceType = array();
        $this->db->select('id,name');
        $this->db->where('is_active', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('source_type');
        $noProdId = 0;
	$noProdRow = array();
        foreach ($result->result_array() as $row) {
            if($row['name'] != "Other")
                 $arrSourceType[] = $row;
            else{
                    $noProdId = $row['id'];
                    $noProdRow = $row;
            }
        }
        if($noProdId)
            $arrSourceType[] = $noProdRow;
        return $arrSourceType;
    }

    function getSphereOfInfluenceNames() {
        $arrSphereOfInfluence = array();
        $this->db->select('id,name');
        $this->db->where('is_active', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('sphere_of_influence');
        foreach ($result->result_array() as $row) {
            $arrSphereOfInfluence[] = $row;
        }
        return $arrSphereOfInfluence;
    }

    function getLatestComplienceIdByUser($userId) {
        $complienceId = 0;
        $this->db->where('fma', $userId);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $res = $this->db->get('compliance_monitoring');
        if (is_object($res) && $res->num_rows() > 0) {
            $row = $res->row_array();
            $complienceId = $row['id'];
        }

        return $complienceId;
    }

    function getLatestCoachingIdByUser($userId) {
        $coachingId = 0;
        $this->db->where('username', $userId);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $res = $this->db->get('coachings');
        if (is_object($res) && $res->num_rows() > 0) {
            $row = $res->row_array();
            $coachingId = $row['id'];
        }
        return $coachingId;
    }

    function exportMedical($arrInteractionIds) {

        $arrFilterdCoachings = array();
        $arrCoachings = $this->listMedicalInsight();

        foreach ($arrCoachings as $key => $value) {

            if (in_array($value["id"], $arrInteractionIds)) {
                $arrFilterdCoachings[] = array("id" => $value["id"], "specialty" => $value["specialty"], "product" => $value["product"], "source_type" => $value["source_type"], "agent" => $value["agent"], "topics" => $value["topics"], "sphere_of_influence" => $value["sphere_of_influence"], "summary" => $value["summary"], "relevance" => $value["relevance"], "actions_to_consider" => $value["actions_to_consider"], "created_user" => $value["created_user"]);
            }
        }
        return $arrFilterdCoachings;
    }

    function exportMedicalId($arrInteractionIds) {
        $arrKolDetails = array();

        $this->db->where('medical_insight.id', $arrInteractionIds);
        $this->db->select('client_users.first_name AS ufname, client_users.last_name AS ulname,medical_insight.* ', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');

        $arrKolDetailsResult = $this->db->get('medical_insight');
        foreach ($arrKolDetailsResult->result_array() as $row) {
            $row['created_user'] = $row['ufname'] . ' ' . $row['ulname'];
            $arrKolDetails[] = $row;
        }
        return $arrKolDetails;
    }

    function exportMedicalIdGridReport($id, $filter) {
        $arrFilterdCoachings = array();
        $arrCoachings = $this->getMedicalInsightCountBasedOnMSl($filter);
      
        foreach ($arrCoachings as $key => $value) {

            if (in_array($value["medId"], $id)) {
                $arrFilterdCoachings[] = array("is_activated" => $value["is_activated"], "medid" => $value["medid"], "username" => $value["username"], "entry_count" => $value["entry_count"], "group_name" => $value["group_name"], "date" => $value["created_on"]);
            }
        } 
        return $arrFilterdCoachings;
    }

    function getTherapeuticAreaNamesForChart() {
        $arrTherapeutic = array();
        $this->db->select('specialty, count(specialty) as CountOf');
        $this->db->group_by('specialty');
        $this->db->limit(100);
        $this->db->where('specialty IS NOT NULL');
        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrData[] = array($row['specialty'], (int) $row['CountOf']);
        }
//        echo $this->db->last_query();
        return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
    }

    function getMedicalInsightFilteredData($fields, $filters) {
//        
        $originalDate = $filters['from'];
        if ($filters['from'] != '') {
            $filters['from'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $filters['to'];
        if ($filters['to'] != '') {
            $filters['to'] = date("Y-m-d", strtotime($originalDate1));
        }

        if (($filters['automsl'] != ""))
            $filters['msl'][] = $filters['automsl'];
        if (($filters['autoproduct'] != ""))
            $filters['product'][] = $filters['autoproduct'];
        if (($filters['autosource'] != ""))
            $filters['source_type'][] = $filters['autosource'];
        if (($filters['autotopic'] != ""))
            $filters['topics'][] = $filters['autotopic'];

        // pr($filters); exit;
//switch ($fields) { 
//    case ($fields != 'msl' ||  isset($filters['thrp_name']) || isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product'])):
//         if($noFilters==1 || $fields != 'msl' ||  isset($filters['thrp_name']) || isset($filters['agent'])   ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product']) || isset($filters['topics'])){

        $this->db->select('count(medical_insight.created_by) as userCount ,medical_insight.created_by,client_users.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.created_by IS NOT NULL');
        $this->db->group_by('medical_insight.created_by');
//              $this->db->limit(4);
        $this->db->order_by('userCount', 'desc');
        $arrMSL = $this->db->get('medical_insight');
        $mslArray = $arrMSL->result_array();
//        break;
//         }
//    case  ($fields != 'therp' || isset($filters['msl']) || isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product'])):
//          if($noFilters==1 || $fields != 'therp' || isset($filters['msl']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product']) || isset($filters['topics'])){
        $this->db->select('count(medical_insight.specialty) as specialtyCount ,medical_insight.specialty, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.specialty IS NOT NULL');
        $this->db->group_by('medical_insight.specialty');
//              $this->db->limit(4);
        $this->db->order_by('specialtyCount', 'desc');
        $arrSpecialty = $this->db->get('medical_insight');
        $specialtyArray = $arrSpecialty->result_array();
//        break;
//          }
//    case ($fields != 'agent' || isset($filters['msl']) || isset($filters['thrp_name']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product'])):
//            if($noFilters==1 || $fields != 'agent' || isset($filters['msl']) ||  isset($filters['thrp_name']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) ||  isset($filters['product']) || isset($filters['topics'])){

        $this->db->select('count(medical_insight.agent) as agentCount ,medical_insight.agent, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.agent IS NOT NULL');
        $this->db->group_by('medical_insight.agent');
//              $this->db->limit(4);
        $this->db->order_by('agentCount', 'desc');
        $arrAgent = $this->db->get('medical_insight');

        $agentArray = $arrAgent->result_array();

//        break;
//            }
//    case ($fields != 'sphere' || isset($filters['msl']) || isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['source_type']) ||  isset($filters['product'])):
        //if($noFilters==1 || $fields != 'sphere' || isset($filters['msl']) ||  isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['source_type']) ||  isset($filters['product']) || isset($filters['topics'])){
        $this->db->select('count(medical_insight.sphere_of_influence) as sphereCount ,medical_insight.sphere_of_influence, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.sphere_of_influence IS NOT NULL');
        $this->db->group_by('medical_insight.sphere_of_influence');
//               $this->db->limit(4);
        $this->db->order_by('sphereCount', 'desc');
        $arrSphere = $this->db->get('medical_insight');

        $SphereArray = $arrSphere->result_array();

//        break;
        //  }
//    case ($fields != 'source' || isset($filters['msl']) || isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['product'])):
//       if($noFilters==1 || $fields != 'source' || isset($filters['msl']) || isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['product']) || isset($filters['topics'])){   
        $this->db->select('count(medical_insight.source_type) as sourceCount ,medical_insight.source_type, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.source_type IS NOT NULL');
        $this->db->group_by('medical_insight.source_type');
//              $this->db->limit(4);
        $this->db->order_by('sourceCount', 'desc');
        $arrSource = $this->db->get('medical_insight');

        $SourceArray = $arrSource->result_array();

//        break;
//       }
//    case ($fields != 'product' || isset($filters['msl']) || isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type'])):
//     if($noFilters==1 || $fields != 'product' || isset($filters['msl']) ||  isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) || isset($filters['topics'])){
        $this->db->select('count(medical_insight.product) as productCount ,medical_insight.product, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (isset($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.product IS NOT NULL');
        $this->db->group_by('medical_insight.product');
//               $this->db->limit(4);
        $this->db->order_by('productCount', 'desc');
        $arrProduct = $this->db->get('medical_insight');

        $ProductArray = $arrProduct->result_array();
//        break;
//     }
//    if($noFilters==1 || $fields != 'topics' || isset($filters['msl']) ||  isset($filters['thrp_name']) ||  isset($filters['agent']) ||  isset($filters['sphere_influencers']) ||  isset($filters['source_type']) || isset($filters['product'])){
        $this->db->select('count(medical_insight.topics) as topicsCount ,medical_insight.topics, `client_users`.*', false);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        if (isset($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (isset($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (isset($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (isset($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);

        if (isset($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        $this->db->where('medical_insight.topics IS NOT NULL');
        $this->db->group_by('medical_insight.topics');
//               $this->db->limit(4);
        $this->db->order_by('topicsCount', 'desc');
        $arrTopic = $this->db->get('medical_insight');

        $TopicArray = $arrTopic->result_array();
//        break;
//     }

        foreach ($mslArray as $value) {

            $this->db->select('id,first_name, last_name');
            $this->db->where('id', $value['id']);
            $arrUsername = $this->db->get('client_users');
            $username = $arrUsername->row_array();
//             echo $this->db->last_query();
//           if($username['first_name']!='' && $username['last_name']!='')
//               $arrayOfRefinedData['msl'][] = $username['first_name'] . "​_" . $username['last_name'] . "_​" . $username['id'];

            if ($username['first_name'] != '' && $username['last_name'] != '') {
                if (in_array($value['id'], $filters['msl']))
                    $arrayOfRefinedData['msl'][] = "true" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $value['userCount'];
                else
                    $arrayOfRefinedData['msl'][] = "nottrue" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $value['userCount'];
            }
        }
        foreach ($specialtyArray as $value) {

            $this->db->select(' id,name');
            $this->db->where('name', $value['specialty']);
            $arrArea = $this->db->get('theraputic_areas');
            $therpArea = $arrArea->row_array();
            //  echo $this->db->last_query();

            if ($therpArea['name'] != '') {
                if (in_array($value['specialty'], $filters['thrp_name']))
                    $arrayOfRefinedData['therp'][] = "true" . "_" . $therpArea['name'] . "_" . $therpArea['id'] . "_" . $value['specialtyCount'];
                else
                    $arrayOfRefinedData['therp'][] = "nottrue" . "_" . $therpArea['name'] . "_" . $therpArea['id'] . "_" . $value['specialtyCount'];
            }
        }

        foreach ($agentArray as $value) {

            $this->db->select(' id,name');
            $this->db->where('name', $value['agent']);
            $arrAgent = $this->db->get('investigational_agent');
            $Agent = $arrAgent->row_array();
//           echo $this->db->last_query();
//           if($Agent['name']!='')
//               $arrayOfRefinedData['agent'][] = $Agent['name'] . "_" . $Agent['id'];
            if ($Agent['name'] != '') {
                if (in_array($value['agent'], $filters['agent']))
                    $arrayOfRefinedData['agent'][] = "true" . "_" . $Agent['name'] . "_" . $Agent['id'] . "_" . $value['agentCount'];
                else
                    $arrayOfRefinedData['agent'][] = "nottrue" . "_" . $Agent['name'] . "_" . $Agent['id'] . "_" . $value['agentCount'];
            }
        }

        foreach ($SphereArray as $value) {

            $this->db->select('id,name');
            $this->db->where('name', $value['sphere_of_influence']);
            $sphereArray = $this->db->get('sphere_of_influence');
            $Sphere = $sphereArray->row_array();
//           echo $this->db->last_query();
//           if($Sphere['name']!='')
//               $arrayOfRefinedData['sphere'][] = $Sphere['name'] . "_" . $Sphere['id'];
            if ($Sphere['name'] != '') {
                if (in_array($value['sphere_of_influence'], $filters['sphere_influencers']))
                    $arrayOfRefinedData['sphere'][] = "true" . "_" . $Sphere['name'] . "_" . $Sphere['id'] . "_" . $value['sphereCount'];
                else
                    $arrayOfRefinedData['sphere'][] = "nottrue" . "_" . $Sphere['name'] . "_" . $Sphere['id'] . "_" . $value['sphereCount'];
            }
        }
        foreach ($SourceArray as $value) {

            $this->db->select('id,name');
            $this->db->where('name', $value['source_type']);
            $sourceArray = $this->db->get('source_type');
            $Source = $sourceArray->row_array();
//           echo $this->db->last_query();
//           if($Source['name']!='')
//               $arrayOfRefinedData['source'][] = $Source['name'] . "_" . $Source['id'];
            if ($Source['name'] != '') {
                if (in_array($value['source_type'], $filters['source_type']))
                    $arrayOfRefinedData['source'][] = "true" . "_" . $Source['name'] . "_" . $Source['id'] . "_" . $value['sourceCount'];
                else
                    $arrayOfRefinedData['source'][] = "nottrue" . "_" . $Source['name'] . "_" . $Source['id'] . "_" . $value['sourceCount'];
            }
        }
        foreach ($ProductArray as $value) {

            $this->db->select('id,name');
            $this->db->where('name', $value['product']);
            $productArray = $this->db->get('products');
            $Product = $productArray->row_array();
//           echo $this->db->last_query();
//           if($Product['name']!='')
//               $arrayOfRefinedData['product'][] = $Product['name'] . "_" . $Product['id'];
            if ($Product['name'] != '') {
                if (in_array($value['product'], $filters['product']))
                    $arrayOfRefinedData['product'][] = "true" . "_" . $Product['name'] . "_" . $Product['id'] . "_" . $value['productCount'];
                else
                    $arrayOfRefinedData['product'][] = "nottrue" . "_" . $Product['name'] . "_" . $Product['id'] . "_" . $value['productCount'];
            }
        }
        foreach ($TopicArray as $value) {

            $this->db->select('id,name');
            $this->db->where('name', $value['topics']);
            $topicsArray = $this->db->get('key_insight_topics');
            $Topic = $topicsArray->row_array();
//           echo $this->db->last_query();
//           if($Product['name']!='')
//               $arrayOfRefinedData['product'][] = $Product['name'] . "_" . $Product['id'];
            if ($Topic['name'] != '') {
                if (in_array($value['topics'], $filters['topics']))
                    $arrayOfRefinedData['topics'][] = "true" . "_" . $Topic['name'] . "_" . $Topic['id'] . "_" . $value['topicsCount'];
                else
                    $arrayOfRefinedData['topics'][] = "nottrue" . "_" . $Topic['name'] . "_" . $Topic['id'] . "_" . $value['topicsCount'];
            }
        }
        if ($noFilters == 1) {
            $arrayOfRefinedData['noFilter'][] = true;
        }
//        echo $this->db->last_query();
        echo json_encode($arrayOfRefinedData);
    }

    function getMedicalInsightCountBasedOnMSl($filters) {
        $originalDate = $filters['from'];
        if ($filters['from'] != '') {
            $filters['from'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $filters['to'];
        if ($filters['to'] != '') {
            $filters['to'] = date("Y-m-d", strtotime($originalDate1));
        }
        $users=$this->common_helpers->getManagerAlignedUsers($filters['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
	 $this->db->select('groups.group_name,medical_insight.id as medId,medical_insight.created_on,count(distinct medical_insight.id) as entry_count ,client_users.*', false);
           $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');

        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
//        if (!$count) {
//            if ($Details['start'] >= 0) {
//                $this->db->limit($Details['limit'], $Details['start']);
//            }
//        }
//        if ($Details['username'] != '') {
//            $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $Details['username']);
//        }
//        if($Details['group_name']!=''){
//			$this->db->like('groups.group_name',$Details['group_name']);
//		}
//                
//                 if($Details['entry_count']!=''){
//			$this->db->like('entry_count',$Details['entry_count']);
//		}
//               $this->db->select('count(medical_insight.created_by) as entry_count ,medical_insight.id as medid,client_users.*',false);
//        $clientId = $this->session->userdata('client_id');
//		if($clientId != INTERNAL_CLIENT_ID){
//			$this->db->where('client_users.client_id',$clientId);
//			$this->db->where_in('client_users.user_from',array(1,2));
//		}
        if (1) {

           if (!empty($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        }
        if (!empty($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (!empty($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (!empty($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if (1) {

            if (!empty($filters['source_type']))
                 $this->db->where_in("medical_insight.source_type", $filters['source_type']);
//                $filters['source_type'][] = $filters['autosource'];
//                     pr($filters['msl']); 
           
        }
//           
//            if(isset($filters['product']))
//                   $this->db->where_in("medical_insight.product",$filters['product']); 
        if (1) {

            if (!empty($filters['product']))
                $this->db->where_in("medical_insight.product", $filters['product']);
               // $filters['product'][] = $filters['autoproduct'];
//                     pr($filters['msl']); 
            
        }
        if (1) {

             if (!empty($filters['topics']))
                  $this->db->where_in("medical_insight.topics", $filters['topics']);
               // $filters['topics'][] = $filters['autotopic'];
//                     pr($filters['msl']); 
           
        }
        if (1) {
if (!empty($filters['team_name']))
                 $this->db->where_in("groups.group_id", $filters['team_name']);
               // $filters['group_id'][] = $filters['team_name'];
//                     pr($filters['msl']); 
           
        }
         if (!empty($filters['manager_id'])){
           
            $this->db->where_in("medical_insight.created_by", $users);
        }

        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
//        if ($count) {
//            $this->db->select('count(distinct medical_insight.id) as num_rows',false);
//                     
//			$count=$this->db->get('medical_insight');
//			$count=$count->row_array();
//			return $count['num_rows'];
//        }
//        else{
//         
//            if ($sidx != '' && $sord != '') {
//                switch ($sidx) {
//                    case 'entry_count' : $this->db->order_by("count(distinct medical_insight.id)", $sord);
//                        break;
//                    case 'username' :$this->db->order_by("CONCAT(client_users.first_name,client_users.last_name)", $sord);
//                        break;
//                    case 'group_name' :$this->db->order_by("groups.group_name", $sord);
//                        break;
//                }
//                //$this->db->order_by($sidx,$sord);
//            }
        $this->db->where('medical_insight.created_by IS NOT NULL');
        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('medical_insight.created_by');
        $this->db->order_by('entry_count', 'desc');
        if($userRole == ROLE_USER){
           $this->db->where('medical_insight.created_by', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('medical_insight.created_by', $userIds);
       }
        $arrCoachingResultSet = $this->db->get('medical_insight');
        foreach ($arrCoachingResultSet->result_array() as $row) {
            if ($row['is_activated'] == 1)
                $row['is_activated'] = 'Yes';
            else
                $row['is_activated'] = 'No';
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = $row['entry_count'];
            $row['date'] = $row['created_on'];
            $row['medid'] = $row['medId'];
            $row['group_name'] = $row['group_name'];
            $arrCoaching[] = $row;
        }
//        echo $this->db->last_query(); exit;
        return $arrCoaching;
//        }
//            
    }

    function getChartMedicalInsightCountBasedOnMSl($filters) {
        $originalDate = $filters['from'];
        if ($filters['from'] != '') {
            $filters['from'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $filters['to'];
        if ($filters['to'] != '') {
            $filters['to'] = date("Y-m-d", strtotime($originalDate1));
        }
        $arrTherapeutic = array();
         $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('count(distinct medical_insight.id) as entry_count ,client_users.*');
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        if (!empty($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (!empty($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (!empty($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (!empty($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        if (!empty($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (!empty($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (!empty($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
        if (!empty($filters['team_name']))
            $this->db->where_in("groups.group_id", $filters['team_name']);
        if($userRole == ROLE_USER){
           $this->db->where('medical_insight.created_by', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('medical_insight.created_by', $userIds);
       }
       $clientId = $this->session->userdata('client_id');
       if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        $this->db->where('medical_insight.created_by IS NOT NULL');
        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('medical_insight.created_by');
        $this->db->order_by('entry_count', 'desc');
//        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $arrCoachingResultSet = $this->db->get('medical_insight');
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $arrData[] = array($row['username'], (int) $row['entry_count']);
        }
      //  echo $this->db->last_query(); exit;
        return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
    }

    function getClientUser() {
        $userName = array();
          $userId = $this->session->userdata('user_id');
      $userRole = $this->session->userdata('user_role_id');
      $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
      $teamName = $this->common_helpers->getUserTeamName($userId);
     
        $this->db->select('distinct first_name,client_users.id,last_name', false);
            
//        $this->db->join('coachings', 'client_users.id=coachings.username', 'left');
        // $this->db->where_in('client_users.user_from',array(1,2));
        $clientId = $this->session->userdata('client_id');
       if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
//        $this->db->where("coachings.username !=' '");
        $this->db->order_by('first_name','asc');
        //    $this->db->limit(5);
         if($userRole == ROLE_USER){
          $this->db->where('client_users.id', $userId);
        }
      if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
          $this->db->where_in('client_users.id', $userIds);
      }
        $result = $this->db->get('client_users');
//echo $this->db->last_query();
        return $result->result_array();
    }

    function getTherapeuticAreaNamesForBarChart($filters) {

        $originalDate = $filters['from'];
        if ($filters['from'] != '') {
            $filters['from'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $filters['to'];
        if ($filters['to'] != '') {
            $filters['to'] = date("Y-m-d", strtotime($originalDate1));
        }
        $arrTherapeutic = array();
         $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('specialty, count(specialty) as CountOf');
        $this->db->join('client_users','client_users.id=medical_insight.created_by','left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        if (!empty($filters['msl']))
            $this->db->where_in("medical_insight.created_by", $filters['msl']);
        if (!empty($filters['thrp_name']))
            $this->db->where_in("medical_insight.specialty", $filters['thrp_name']);
        if (!empty($filters['agent']))
            $this->db->where_in("medical_insight.agent", $filters['agent']);
        if (!empty($filters['sphere_influencers']))
            $this->db->where_in("medical_insight.sphere_of_influence", $filters['sphere_influencers']);
        if ($filters['from'] != '')
            $this->db->where("medical_insight.created_on >='" . $filters['from'] . "'");
        if ($filters['to'] != '')
            $this->db->where("medical_insight.created_on <='" . $filters['to'] . "'");
        if (!empty($filters['source_type']))
            $this->db->where_in("medical_insight.source_type", $filters['source_type']);
        if (!empty($filters['product']))
            $this->db->where_in("medical_insight.product", $filters['product']);
        if (!empty($filters['topics']))
            $this->db->where_in("medical_insight.topics", $filters['topics']);
         if (!empty($filters['team_name']))
            $this->db->where_in("groups.group_id", $filters['team_name']);
if($userRole == ROLE_USER){
           $this->db->where('medical_insight.created_by', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('medical_insight.created_by', $userIds);
       }
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->where('medical_insight.specialty IS NOT NULL');
        $this->db->group_by('medical_insight.specialty');
        $this->db->order_by('CountOf', 'desc');
//        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $arrCoachingResultSet = $this->db->get('medical_insight');
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $arrData[] = $row;
        }
//        echo $this->db->last_query();
        return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
//            $arrTherapeutic	= array();
//            $this->db->select('specialty, count(specialty) as CountOf');
//            $this->db->group_by('specialty');
//                	$this->db->order_by('CountOf','desc');
//    	$this->db->order_by('specialty','asc');
//            $this->db->limit(100);
//            $this->db->where('specialty IS NOT NULL');
//            $result	= $this->db->get('medical_insight');
//            foreach($result->result_array() as $row){
//    		$arrData[]	= $row;
//    	}
////        echo $this->db->last_query();
//		return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
    }

    function getKeyInsightTopicNames() {
        $arrKeyInsightTopic = array();
        $this->db->select('id,name');
        $this->db->where('status', 1);
        $this->db->order_by('id', 'ASC');
        $result = $this->db->get('key_insight_topics');
        foreach ($result->result_array() as $row) {
            $arrKeyInsightTopic[] = $row;
        }
        return $arrKeyInsightTopic;
    }

    function getTopKeyInsightTopicNames() {
        $arrKeyInsightTopic = array();

        $this->db->select('key_insight_topics.id,key_insight_topics.name, COUNT(medical_insight.topics) AS num');
        $this->db->join('key_insight_topics', 'key_insight_topics.name=medical_insight.topics', 'left');
        $this->db->where('medical_insight.topics IS NOT NULL');
        $this->db->group_by('medical_insight.topics');
        $this->db->order_by('medical_insight.topics', 'asc');

        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrKeyInsightTopic[] = $row;
        }
        return $arrKeyInsightTopic;
    }

    function getTopProductNames() {
        $arrProduct = array();

        $this->db->select('products.id,products.name, COUNT(medical_insight.product) AS num');
        $this->db->join('products', 'products.name=medical_insight.product', 'left');
        $this->db->where('medical_insight.product IS NOT NULL');
        $this->db->group_by('medical_insight.product');
        $this->db->order_by('medical_insight.product', 'asc');
        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrProduct[] = $row;
        }
//            echo $this->db->last_query();
        return $arrProduct;
    }

    function getTopSourceType() {
        $arrSourceType = array();

        $this->db->select('source_type.id,source_type.name, COUNT(medical_insight.source_type) AS num');
        $this->db->join('source_type', 'source_type.name=medical_insight.source_type', 'left');
        $this->db->where('medical_insight.source_type IS NOT NULL');
        $this->db->group_by('medical_insight.source_type');
        $this->db->order_by('medical_insight.source_type', 'asc');
        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrSourceType[] = $row;
        }
//            echo $this->db->last_query();
        return $arrSourceType;
    }

    function getTopMsl() {
        $arrMsl = array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('count(distinct medical_insight.id) as entry_count ,client_users.*');
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        $this->db->where('medical_insight.created_by IS NOT NULL');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        $this->db->group_by('medical_insight.created_by');
        $this->db->order_by('client_users.first_name', 'asc');
        $arrCoachingResultSet = $this->db->get('medical_insight');

        foreach ($arrCoachingResultSet->result_array() as $row) {


            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = $row['entry_count'];
            $arrMsl[] = $row;
        }
//              echo $this->db->last_query();
        return $arrMsl;
    }

    function getUserCount($filters) {
        $arrTherapeutic = array();
            $userId = $this->session->userdata('user_id');
      $userRole = $this->session->userdata('user_role_id');
      $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
      $teamName = $this->common_helpers->getUserTeamName($userId);
      if($userRole == ROLE_USER){
          $this->db->where('client_users.id', $userId);
      }
      if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
          $this->db->where_in('client_users.id', $userIds);
      }
        $this->db->select(' username,count(username) as CountOf,client_users.*');
        $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $clientId = $this->session->userdata('client_id');
        if (isset($filters['msl_name']))
            $this->db->where_in("coachings.username ", $filters['msl_name']);
        if (isset($filters['eng_name']))
            $this->db->where_in("coachings.status", $filters['eng_name']);
        if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("coachings.date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("coachings.date <='" . $filters['to'] . "'");
        }

        if ($filters['to'] != '' && $filters['from'] != '') {
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
          $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
        }
         if (isset($filters['team_name']))
            $this->db->where_in("groups.group_id", $filters['team_name']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("coachings.specialty", $filters['thrp_name']);
//          $this->db->where("theraputic_areas.name !=''");
        
         $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('username');
       
        $this->db->where('username IS NOT NULL');
        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $result = $this->db->get('coachings');
        foreach ($result->result_array() as $row) {
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $arrData[] = array($row['username'], (int) $row['CountOf']);
        }
//        echo $this->db->last_query();
        return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
    }

    function categoryFilter($cat, $filters) {
        if ($filters['msl_auto'] != '') {
            $filters['msl_name'][] = $filters['msl_auto'];
        }

        if (!isset($filters['msl_name']) && !isset($filters['thrp_name']) && !isset($filters['eng_name']) && $filters['from'] == '' && $filters['to'] == '') {
            $noFilters = 1;
        }
//echo $noFilters;

        if (1) {

            $this->db->select(' status,count(status) as statusCount, `client_users`.*,coachings.date');
            $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
            if (isset($filters['msl_name']))
                $this->db->where_in("coachings.username ", $filters['msl_name']);
            if (isset($filters['thrp_name']))
                $this->db->where_in("coachings.specialty", $filters['thrp_name']);

            if ($filters['from'] != '') {
                $this->db->where("coachings.date >='" . $filters['from'] . "'");
            }
            if ($filters['to'] != '') {
                $this->db->where("coachings.date <='" . $filters['to'] . "'");
            }

            if ($filters['to'] != '' && $filters['from'] != '') {
                $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
            }
            $this->db->where('coachings.username IS NOT NULL');
            $this->db->group_by('status');
            $this->db->order_by('statusCount', 'desc');
            $arrStatus = $this->db->get('coachings');

            $status = $arrStatus->result_array();
        }

        if (1) {

            $this->db->select(' specialty,count(specialty) as specialtyCount, `client_users`.*,coachings.date');
            $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
            if (isset($filters['msl_name']))
                $this->db->where_in("coachings.username ", $filters['msl_name']);
            if (isset($filters['eng_name']))
                $this->db->where_in("coachings.status", $filters['eng_name']);
            if ($filters['from'] != '') {
                $this->db->where("coachings.date >='" . $filters['from'] . "'");
            }
            if ($filters['to'] != '') {
                $this->db->where("coachings.date <='" . $filters['to'] . "'");
            }

            if ($filters['to'] != '' && $filters['from'] != '') {
                $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
            }
            $this->db->where('coachings.username IS NOT NULL');
            $this->db->group_by('specialty');

            $this->db->order_by('specialtyCount', 'desc');
            $arrTherp = $this->db->get('coachings');
            $therp = $arrTherp->result_array();
            // echo $this->db->last_query();
        }

        if (1) {

            $this->db->select(' username, count(username) as userCount,`client_users`.*,coachings.date');
            $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
            if (isset($filters['eng_name']))
                $this->db->where_in("coachings.status ", $filters['eng_name']);
            if (isset($filters['thrp_name']))
                if ($filters['from'] != '') {
                    $this->db->where("coachings.date >='" . $filters['from'] . "'");
                }
            if ($filters['to'] != '') {
                $this->db->where("coachings.date <='" . $filters['to'] . "'");
            }

            if ($filters['to'] != '' && $filters['from'] != '') {
                $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
            }

            $this->db->limit();
            $this->db->group_by('username');
            $this->db->order_by('userCount', 'desc');
            $arrMsl = $this->db->get('coachings');
            $msl = $arrMsl->result_array();
            //echo $this->db->last_query();
        }
        // echo $this->db->last_query();

        $flag = 0;
        foreach ($msl as $valueMsl) {

            $this->db->select(' id,first_name, last_name');
            $this->db->where('id', $valueMsl['username']);
            $arrUsername = $this->db->get('client_users');
            $username = $arrUsername->row_array();
            if ($username['first_name'] != '' && $username['last_name'] != '') {
                if (in_array($valueMsl['username'], $filters['msl_name'])) {
                    $flag = 1;
                    $arrayOfRefinedData['msl'][] = "selected" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $valueMsl['userCount'];
                    $arrayOfMsls['msl'][] = "selected" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $valueMsl['userCount'];
                } else {
                    // $arrNonSelMsls[]="notselected"."_".$username['first_name'] . "_" . $username['last_name'] . "_" . $username['id']."_".$valueMsl['userCount'];
                    $arrayOfRefinedData['msl'][] = "notselected" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $valueMsl['userCount'];
                    $arrayOfMsls['msl'][] = "notselected" . "_" . $username['first_name'] . "_" . $username['last_name'] . "_" . $username['id'] . "_" . $valueMsl['userCount'];
                }
            }
        }
//     pr($arrayOfMsls);
//        if($flag==1){
//            unset($arrayOfRefinedData['msl']);
//       // rsort( $arrayOfRefinedData['msl']);
//            $i=0;
//            foreach($arrayOfMsls['msl'] as $values){
//            $data=explode("_",$values); 
//            if($i<5 && $data[0]!="selected"){
//            $arrayOfRefinedData['msl'][]=$values;
//            $i++;
//                    
//            }
//            if($data[0]=="selected")
//                $arrayOfRefinedData['msl'][]=$values;
//            
//            }
//        }


        $flag = 0;

        foreach ($therp as $valueThrp) {

            $this->db->select(' id,name');
            $this->db->where('id', $valueThrp['specialty']);
            $arrArea = $this->db->get('theraputic_areas');
            $therpArea = $arrArea->row_array();
            if ($therpArea['name'] != '') {
                if (in_array($valueThrp['specialty'], $filters['thrp_name'])) {
                    $flag = 1;
                    $arrayOfRefinedData['therp'][] = "selected" . "_" . $therpArea['name'] . "_" . $therpArea['id'] . "_" . $valueThrp['specialtyCount'];
                } else
                    $arrayOfRefinedData['therp'][] = "notselected" . "_" . $therpArea['name'] . "_" . $therpArea['id'] . "_" . $valueThrp['specialtyCount'];
            }
        }
        if ($flag == 1) {
            //rsort( $arrayOfRefinedData['therp']);
        }
        $flag = 0;
        foreach ($status as $valueStatus) {
            if (in_array($valueStatus['status'], $filters['eng_name'])) {
                $flag = 1;
                $arrayOfRefinedData['status'][] = "selected" . "_" . $valueStatus['status'] . "_" . $valueStatus['statusCount'];
            } else
                $arrayOfRefinedData['status'][] = "notselected" . "_" . $valueStatus['status'] . "_" . $valueStatus['statusCount'];
        }
        if ($flag == 1) {
            //rsort( $arrayOfRefinedData['therp']);
        }
        if ($noFilters == 1 || count($arrayOfRefinedData) == 0) {
            $arrayOfRefinedData['noFilter'][] = true;
        }

        echo json_encode($arrayOfRefinedData);
    }

    function getMsl($msl) {
        $arrMsl = array();
        $this->db->select('CONCAT(client_users.first_name, " ", client_users.last_name) as name, client_users.id', false);
        $this->db->like('CONCAT(client_users.first_name,  client_users.last_name)', $msl);
        $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
        $this->db->group_by('coachings.username');
        $arrMSLResult = $this->db->get('coachings');
        foreach ($arrMSLResult->result_array() as $arrMsls) {
            $arrMsl[$arrMsls['id']] = $arrMsls['name'];
        }
        return $arrMsl;
    }

    function listCoachingReport($filters) {
        if ($filters['msl_auto'] != '') {
            $filters['msl_name'][] = $filters['msl_auto'];
        }
         $users=$this->common_helpers->getManagerAlignedUsers($filters['manager_id']);
        $userId = $this->session->userdata('user_id');
      $userRole = $this->session->userdata('user_role_id');
      $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
      $teamName = $this->common_helpers->getUserTeamName($userId);
      if($userRole == ROLE_USER){
          $this->db->where('client_users.id', $userId);
      }
      if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
          $this->db->where_in('client_users.id', $userIds);
      }
         
         
        $this->db->select('groups.group_name,client_users.is_activated,coachings.id,coachings.evaluated_by,coachings.date,count(username) as entry_count ,client_users.*');
        $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }

        if (isset($filters['msl_name']))
            $this->db->where_in("coachings.username ", $filters['msl_name']);
        if (isset($filters['manager_id'])){
           
            $this->db->where_in("coachings.username ", $users);
        }
        if (isset($filters['thrp_name']))
            $this->db->where_in("coachings.specialty", $filters['thrp_name']);
        if (isset($filters['eng_name']))
            $this->db->where_in("status", $filters['eng_name']);
        if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("coachings.date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("coachings.date <='" . $filters['to'] . "'");
        }
        if ($filters['to'] != '' && $filters['from'] != '') {
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
          $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
                $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
            }
        if (isset($filters['team_name']))
            $this->db->where_in("groups.group_id", $filters['team_name']);

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('username');
        $this->db->order_by('entry_count', 'desc');

        $arrCoachingResultSet = $this->db->get('coachings');
//		 echo $this->db->last_query();
        foreach ($arrCoachingResultSet->result_array() as $row) {

            if ($row['is_activated'] == 1)
                $row['is_activated'] = 'Yes';
            else
                $row['is_activated'] = 'No';
           $row['evaluated_by'] = $this->Client_User->getUserNameById($row['evaluated_by']);
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = $row['entry_count'];
            $arrCoaching[] = $row;
        }

        return $arrCoaching;

//                pr($arrCoaching);
    }

    function getSphereOfInfluenceNamesCount() {
        $arrSourceType = array();

        $this->db->select('sphere_of_influence.id,sphere_of_influence.name, COUNT(medical_insight.sphere_of_influence) AS num');
        $this->db->join('sphere_of_influence', 'sphere_of_influence.name=medical_insight.sphere_of_influence', 'left');
        $this->db->where('medical_insight.sphere_of_influence IS NOT NULL');
        $this->db->group_by('medical_insight.sphere_of_influence');
        $this->db->order_by('medical_insight.sphere_of_influence', 'asc');
        $this->db->limit(4);
        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrSourceType[] = $row;
        }

        return $arrSourceType;
    }

    function getInvestigationalAgentNamesCount() {
        $arrSourceType = array();

        $this->db->select('investigational_agent.id,investigational_agent.name, COUNT(medical_insight.agent) AS num');
        $this->db->join('investigational_agent', 'investigational_agent.name=medical_insight.agent', 'left');
        $this->db->where('medical_insight.agent IS NOT NULL');
        $this->db->group_by('medical_insight.agent');
        $this->db->order_by('investigational_agent.name', 'asc');
        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrSourceType[] = $row;
        }

        return $arrSourceType;
    }

    function getAllAreasCount() {
        $arrSourceType = array();

        $this->db->select('theraputic_areas.id,theraputic_areas.name, COUNT(medical_insight.specialty) AS num');
        $this->db->join('theraputic_areas', 'theraputic_areas.name=medical_insight.specialty', 'left');
        $this->db->where('medical_insight.specialty IS NOT NULL');
        $this->db->group_by('medical_insight.specialty');
        $this->db->order_by('num', 'DESC');

        $result = $this->db->get('medical_insight');
        foreach ($result->result_array() as $row) {
            $arrSourceType[] = $row;
        }
//         echo $this->db->last_query(); exit;
        return $arrSourceType;
    }

    /*     * **Coaching Reports
     * 
     */

    function getTherapeuticAreaNamesForBarChartCoaching($filters) {
   
        $arrTherapeutic = array();
            $userId = $this->session->userdata('user_id');
      $userRole = $this->session->userdata('user_role_id');
      $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
      $teamName = $this->common_helpers->getUserTeamName($userId);
      if($userRole == ROLE_USER){
          $this->db->where('client_users.id', $userId);
      }
      if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
          $this->db->where_in('client_users.id', $userIds);
      }
        $this->db->select('theraputic_areas.name, count(specialty) as CountOf');
        $this->db->join('theraputic_areas', 'theraputic_areas.id=coachings.specialty', 'left');
        $this->db->join('client_users', 'client_users.id=coachings.username', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        //$this->db->join('groups', 'user_groups.group_id = groups.group_id AND groups.group_type = "Team"', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        if (isset($filters['msl_name']))
            $this->db->where_in("coachings.username ", $filters['msl_name']);
        if (isset($filters['thrp_name']))
            $this->db->where_in("coachings.specialty", $filters['thrp_name']);

        if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("coachings.date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("coachings.date <='" . $filters['to'] . "'");
        }

        if ($filters['to'] != '' && $filters['from'] != '') {
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
          $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("coachings.date >='" . $filters['from'] . "' and coachings.date <='" . $filters['to'] . "'  ");
        }
         if (isset($filters['team_name']))
            $this->db->where_in("groups.group_id", $filters['team_name']);
          $this->db->where("theraputic_areas.name !=''");
           $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        $this->db->group_by('specialty');
        $this->db->order_by('CountOf', 'desc');
        $this->db->order_by('specialty', 'asc');
        //$this->db->limit(100);
        $this->db->where('specialty IS NOT NULL');
        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        $result = $this->db->get('coachings');
        foreach ($result->result_array() as $row) {
            $arrData[] = $row;
        }
//    echo $this->db->last_query();

        return $arrData;
//            foreach($result->result_array() as $row){
//                    $arrTherapeutic[] = $row;
//            }
//            return $arrTherapeutic;
    }

    function exportCoachingReport($arrCoachingIds, $filters) {

        $arrFilterdCoachings = array();
        $arrCoachings = $this->listCoachingReport($filters);

        foreach ($arrCoachings as $key => $value) {

            if (in_array($value["id"], $arrCoachingIds)) {
                $arrFilterdCoachings[] = array("id" => $value["id"],'active'=>$value["is_activated"], "username" => $value["username"], "entry_count" => $value["entry_count"], "group_name" => $value["group_name"],'evaluated_by'=>$value['evaluated_by'], "date" => $value["date"]);
            }
        }

        return $arrFilterdCoachings;
    }

    function filterQuater($filters) {

        $q1 = array(1, 2, 3);
        $q2 = array(4, 5, 6);
        $q3 = array(7, 8, 9);
        $q4 = array(10, 11, 12);

        $fromDate = $filters['from'];

        $toDate = $filters['to'];
        if ($fromDate != '') {
            $timeFrom = strtotime($fromDate);
            $GLOBALS['monthFrom'] = date("m", $timeFrom);
            $GLOBALS['yearFrom'] = date("Y", $timeFrom);
        }
        if (trim($toDate) != '') {

            $timeTo = strtotime($toDate);
            $GLOBALS['monthTo'] = date("m", $timeTo);
            $GLOBALS['yearTo'] = date("Y", $timeTo);
        }

        //get total years

        $diff = abs(strtotime($fromDate) - strtotime($toDate));

        $years = floor($diff / (365 * 60 * 60 * 24));
        $this->getCountForMonths($filters, $years); //0&1 & 2
    }

    function getCountForMonths($filters, $diff) {


//        $totalNameSeries = 4 * 1;
//        pr($filters);
        $allyears = array();
       
        $this->db->select(" username,totalscore,MONTH(DATE) as month,YEAR(DATE) as year ");
        $this->db->where_in("username ", $filters['msls']);
         if ($filters['from'] != ''){
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
            $this->db->where("date >='" . $filters['from'] . "'");
        }
        if ($filters['to'] != ''){
             $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("date <='" . $filters['to'] . "'");
        }

        if ($filters['to'] != '' && $filters['from'] != '') {
            $originalDateFrom=$filters['from'];
         $filters['from'] = date("Y-m-d", strtotime($originalDateFrom));
          $originalDateTo=$filters['to'];
         $filters['to'] = date("Y-m-d", strtotime($originalDateTo));
            $this->db->where("date >='" . $filters['from'] . "' and date <='" . $filters['to'] . "'  ");
        }


//        $this->db->order_by("MONTH(DATE)", 'asc');

        //$this->db->group_by("MONTH(DATE)");
        $this->db->order_by("YEAR(DATE)",'asc');

        $result = $this->db->get("coachings");
        $count = $result->result_array();
//            echo $this->db->last_query();

        foreach ($count as $values) {
            $data[] = array("year" => $values['year'], "month" => $values['month'], "total" => $values['totalscore']);
        }
        $data['data'] = $data;
        if(count($data['data'])>0)
        return $this->load->view('reports/quarterly_table_formation', $data);
        else
            echo "no data";
    }

    function getMSLCoachingRankingData($where) {
        $data = array();
        $this->db->select(" totalscore as score,MONTH(DATE) as month,YEAR(DATE) as year");
        $this->db->where("username", $where['msl_name'][0]);
        $res = $this->db->get('coachings ');
        if ($res->num_rows > 0)
            $data = $res->result_array();

        return $data;
    }

    function getCongressSources() {
        $arrCongressSources = array();
        $this->db->select('id,name');
        $this->db->where('is_active', 1);
        $this->db->order_by('name', 'ASC');
        $result = $this->db->get('congress_sources');
        foreach ($result->result_array() as $row) {
            $arrCongressSources[] = $row;
        }
        return $arrCongressSources;
    }

}
