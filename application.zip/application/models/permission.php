<?php

class Permission extends Model{

	//Constructor
	function Permission(){
		parent::Model();
	
	}
	
	/**
	 * Update Allow type for Particular Methos and Role
	 * @author Vinayak M
	 * @since 3.6
	 * @created 22-12-2011
	 */
	function updateAllowType($accessObjectId,$roled,$data){
		$this->db->where('access_object_id',$accessObjectId);
		$this->db->where('role_id',$roled);
	
		if($this->db->update('access_permissions',$data)){
			return true;
			
		}else{
			return false;
		}
	}
	
    /**
	 * Fetches the 'Access Persmission' for given pair of 'acoId' and 'roleId'
	 * @author Ramesh B
	 * @since 3.6
	 * @return Array
	 * @created 22-12-2011
	 */
	function getPersmissionDetails($acoId,$userRoleId){
		$persmissionDetails=array();
		$this->db->where('access_object_id',$acoId);
		$this->db->where('role_id',$userRoleId);
		$results=$this->db->get('access_permissions');
		if($results->num_rows() > 0){
			$row=$results->first_row('array');
			$persmissionDetails=$row;
		}
		return $persmissionDetails;
	}
	
	/**
	 * Save the Access Permission for newly added Methods
	 * @author Vinayak M
	 * @since 3.6
	 * @created 22-12-2011
	 */
	function saveAccessPemissions($arrRoles,$accessObjectId){

		foreach($arrRoles as $row){
			$arr=array();
			$arr['access_object_id']=$accessObjectId;
			$arr['role_id']=$row['id'];
			$arr['is_allowed']=1;
			$this->db->insert('access_permissions',$arr);
			
		}
	}
}