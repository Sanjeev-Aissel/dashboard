<?php
/**
 * This is HTML page which lists all the Interactions of the perticular client
 * 
 * @author Ramesh B
 * @Created on: 01-03-11
 * @since  1.5	
 */
?>
<script type="text/javascript">
<!--       //         -->
$(function() {
	// Initiate the 'Ternary Navigation
	$("#interactionsTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );

	// Remove the Surrounding Border
	$("#interactionsTernaryNav" ).removeClass("ui-widget-content");

	// Remove the Round Corner
	$("#interactionsTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
	
	$("#interactionsTernaryNav li").removeClass( "ui-corner-top" );

	// Add the Custom Class to control View
	$("#interactionsTernaryNav > div").addClass( "span-20 last" );
});	

$(document).ready(function(){
	//Adds the another upload link below thw current upload field
	$("#addMoreFile").click(function(){
		var noOfFiles=0;
		noOfFiles=$("#noOfFiles").val();
		noOfFiles++;
		var newUpload="<p><label for=docName"+noOfFiles+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\">Description:</label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\">Upload:</label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input></p>";
		$("#fileUploadContainer").append(newUpload);
		$("#noOfFiles").val(noOfFiles);
	});

	//if editing the interaction, make 2nd tabe as selected
	var interactionId=$("#interactionId").val();
	if(interactionId!=null && interactionId!=''){
		jAlert(interactionId);
		$( "#interactionsTernaryNav" ).tabs( "option", "selected", 1 );
	}

	// Settings for the Dialog Box
	var interactionMicroProfileDialogOpts = {
			title: "Publication Snapshot",
			modal: true,
			autoOpen: false,
			width: 300,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#interactionMicroProfile").dialog(interactionMicroProfileDialogOpts);

	// Settings for the Add Interaction Dialog Box
	var interactionAddOpts = {
			title: "Add Interaction",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#interactionAddContainer").dialog(interactionAddOpts);

	// Settings for the Edit Interaction Dialog Box
	var interactionEditOpts = {
			title: "Edit Interaction",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#interactionEditContainer").dialog(interactionAddOpts);
});

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewInteractionMicroProfile(interactionId){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#interactionMicroProfile").dialog("open");
	$(".profileContent").load('<?php echo base_url().'interactions/view_micro_interaction/'?>'+interactionId);
	return false;
}	

function addInteraction(){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#interactionAddContainer").dialog("open");
	$(".profileContent").load('<?php echo base_url().'interactions/add_interaction/'?>');
	return false;	
}

function editInteraction(interactionId){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#interactionEditContainer").dialog("open");
	$(".profileContent").load('<?php echo base_url().'interactions/edit_interaction/'?>'+interactionId);
	return false;	
}

function addInteractionReload(noOfFiles){
	$("#interactionAddContainer").dialog("open");
	$(".profileContent").load('<?php echo base_url().'interactions/add_interaction/'?>'+noOfFiles);
}

function editInteractionReload(interactionId,noOfFiles){
	$("#interactionEditContainer").dialog("open");
	$(".profileContent").load('<?php echo base_url().'interactions/edit_interaction/'?>'+interactionId+'\/'+noOfFiles);
}
</script>
<div id="interactionsTernaryNav">
	<ul class="span-3 append-1 ternaryNav" >
		<li><a href="#interactionsList">Interactions List</a></li>
		<li><a href="#addInteraction">Add Interaction</a></li>
	</ul>
	<div><a href="#" onclick="addInteraction();" id="addButton">Add Interaction</a></div>
	<div id="interactionsList">
	<?php if($arrInteractions!=null){?>
		<table id="InteractionsTable">
			<thead>
				<tr>
					<th>Date</th>
					<th>Interaction Mode</th>
					<th>Topic</th>
					<th>Follow-up On</th>
                                        <th><?php echo lang("KOL");?> Name</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($arrInteractions as $interaction){?>
					<tr>
						<td><a href='#' onclick="viewInteractionMicroProfile(<?php echo $interaction['id'];?>);" ><img title='MicroView' src='<?php echo base_url()?>images/user3.png'></a> <?php echo $interaction['date'];?></td>
						<td><?php echo $interaction['mode_name'];?></td>
						<td><?php echo $interaction['topic_name'];?></td>
						<td><?php echo $interaction['follow_up_on'];?></td>
						<td><?php echo $interaction['salutation']." ".$interaction['last_name']." ".$interaction['middle_name']." ".$interaction['first_name'];?></td>
						<td><a href="#" onclick="editInteraction(<?php echo $interaction['id'];?>);" id="addButton">Edit</a></td>
					</tr>
				<?php }?>
			</tbody>
		</table>
		<!-- Container for the 'Interaction Micro Profile' modal box -->
		<div id="dailog1">	
			<div id="interactionMicroProfile" class="microProfileDialogBox">
				<div class="profileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Interaction Micro Profile' modal box -->
		<!-- Container for the 'Interaction Micro Profile' modal box -->
		<div id="dailog2">	
			<div id="interactionAddContainer" class="microProfileDialogBox">
				<div class="profileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Interaction Micro Profile' modal box -->
		<!-- Container for the 'Interaction Micro Profile' modal box -->
		<div id="dailog3">	
			<div id="interactionEditContainer" class="microProfileDialogBox">
				<div class="profileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Interaction Micro Profile' modal box -->
	<?php }?>
	</div>
	<div id="addInteraction">
		add
	</div>
</div>