<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for specialities from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 11-06-2018
 * @Refactored : 12-06-2018
 */
class speciality extends CI_Model {
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllSpecialties()
	 * @return : all kols associated to client
	 */
	function getAllSpecialties($contentPage=""){
		$arrSpecialties	= array();
		$clientId = $this->session->userdata('client_id');
		
		$arrSpecialtiesResult = $this->db->query("SELECT * FROM (`specialties`) WHERE `specialty` != '' AND (`client_id` = $clientId OR `all` = 1) ORDER BY `specialty` asc");
	
		foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
			$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		}
	
		$key = array_search('Non-medical / Others',$arrSpecialties);
		unset($arrSpecialties[$key]);
		
		if($clientId == INTERNAL_CLIENT_ID)
			$arrSpecialties1[$key] = 'Non-medical / Others';
			
		foreach($arrSpecialties as $key1=>$value1){
			$arrSpecialties1[$key1] = $value1;
		}
		return $arrSpecialties1;
	}
}
