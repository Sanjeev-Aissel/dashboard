<?php
?>
<style>
.fieldContainer{
	margin-top:2px;
	margin-bottom:20px;
}

.inputFiedConatiner{

	margin-top: 10px;
}

#speakerForm input[type="text"]{
	width:293px;
}

.inputLabel{
    margin-left: 2px;
}
.questionHeading{
	color:#333333;
	font-weight:bold !important;
}

.fieldContainer > label:first-child{
	border-bottom: 1px solid #cccccc;
    color: #333333;
    display: block;
    font-weight: bold !important;
    margin-bottom: 5px;
    margin-right: 25px;
    padding: 0 0 5px;
    font-size: 12px;
}
.fieldContainer div{
	/*padding-left: 14px;*/	
}

h5.heading {
    background: #ffffff none repeat scroll 0 0;
    color: #333333;
    margin-bottom: 5px;
    padding: 8px;
    text-align: center;
    font-size: 14px;
}
.formContainer{
	/*border:1px solid #ccc;*/
}
#speakerForm{
	margin-left: 20px;
}

</style>
<script type="text/javascript">
	function hideViewEvaluation(){
		$('#interactionsContainer').show();
    	$('#viewInteractionContainer').html("");
		$("#viewInteractionContainer").hide();
	}
</script>

 <div class="formContainer">
     <div><button onclick="hideViewEvaluation()">Back</button></div>
<h5 class="heading">Speaker Evaluation For <?php echo $arrDetail['kol_name']?><span style="float:right;color:#999">(
Speaker Evaluation Response before the Survey changes in April 2016
) </span> </h5>
	<form id="speakerForm">
		<label class="questionHeading">Evaluation ID: <?php echo $arrDetail['generic_id']?></label>
		
	</div>
		<div class="fieldContainer">
		<label class="questionHeading">1. Evaluator</label>
		<div><?php echo $arrDetail['evaluator']?></div>
		
		<div class="inputFiedConatiner">
			<label style="display:block" class="questionHeading">Name Of Evaluator</label>
			<div><?php echo $arrDetail['evaluator_name']?></div>
		</div>
	
	</div>
	
		<div class="fieldContainer">
			<label class="questionHeading">2. Program Date</label>
			<div><?php echo $arrDetail['program_date']?></div>
		</div>
		
		<div class="fieldContainer">
		<label class="questionHeading">3. No. of Attendees:</label>
		<div><?php echo $arrDetail['no_of_attendees']?></div>
		
		</div>
		<div class="fieldContainer">
			<label class="questionHeading">4. Speaker Details</label>
			<div><?php echo $arrDetail['speaker_detail']?></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="questionHeading">Speaker Name</label>
				<div><?php echo $arrDetail['speaker_name']?></div>
			</div>
		</div>
		<div class="fieldContainer">
		<label class="questionHeading">5. Speaker background: </label>
			<div><?php echo $arrDetail['speaker_background']?></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="questionHeading">Other</label>
				<div><?php echo $arrDetail['speaker_text']?></div>
			</div>
		</div>
		<div class="fieldContainer">
			
			<label class="questionHeading">6. Was this a co-moderated program?</label>
			<div><?php echo $arrDetail['moderated_program']?></div>
		</div>
		<div class="fieldContainer">
		
		<label class="questionHeading">7.Venue</label>
		<div><?php echo $arrDetail['venu']?></div>
		<div class="inputFiedConatiner">
			<label style="display:block" class="questionHeading">City, State: </label>
			
			<div><?php echo $arrDetail['venu_city']?></div>
		</div>
		</div>
		<div class="fieldContainer">
		
		<label class="questionHeading">8. Was venue appropriate for a promotional educational presentation (low noise level, private room/area, minimal distractions and modest venue)?</label>
	
		<div><?php echo $arrDetail['venu_presentation']?></div>
		<div class="inputFiedConatiner">
			<label style="display:block" class="questionHeading">Comments: </label>
		
			<div><?php echo $arrDetail['venu_presentation_comments']?></div>
		</div>
		</div>
		
		<div class="fieldContainer">
			<label class="questionHeading">9. Did audio/visual setup work properly?</label>
			
				<div><?php echo $arrDetail['audio_setup']?></div>
			<div class="inputFiedConatiner">
				<label style="display:block" class="questionHeading">Comments: </label>
			
				<div><?php echo $arrDetail['audio_setup_comments']?></div>
			</div>
		</div>	
		
		<div class="fieldContainer">
			<label class="questionHeading">10. Program Topic</label>
			<div><?php echo $arrDetail['program_topic']?></div>
			
			
		</div>
		
		
		
				<?php if($arrDetail['program_topic']=='Abilify Maintena'){?>
				<div class="fieldContainer">
					<label class="questionHeading">11. Abilify Maintena:</label>
					<div><?php echo $arrDetail['abilify_maintena']?></div>
				</div>
				<?php }?>
				<?php if($arrDetail['program_topic']=='Rexulti'){?>
				<div class="fieldContainer">
					<div class="rexulti questDetail">
						<label class="questionHeading">12. Rexulti:</label>
							<div><?php echo $arrDetail['rexulti']?></div>
						
					</div>
				</div>
				<?php }?>
				<?php if($arrDetail['program_topic']=='Nuedexta'){?>
				<div class="fieldContainer">
					<div class="nuedexta questDetail">
						<label class="questionHeading">13. Nuedexta:</label>
						<div><?php echo $arrDetail['nuedexta']?></div>
						
					</div>
				</div>
				<?php }?>
					<?php if($arrDetail['program_topic']=='Samsca'){?>
				<div class="fieldContainer">
					<div class="samsca questDetail">
						<label class="questionHeading">14. Samsca:</label>
						<div><?php echo $arrDetail['samsca']?></div>
						
					</div>
				</div>
				<?php }?>
				
				<?php if($arrDetail['program_topic']=='PsychU'){?>
				<div class="fieldContainer">
					<div class="psychU questDetail">
						<label class="questionHeading">16. PsychU (Enter Program Topic Below)</label>
							<div><pre><?php echo $arrDetail['psychu']?></pre></div>
					</div>
				</div>
				<?php }?>
				<div class="fieldContainer">
				
				<label class="questionHeading">17. Were the attendees the appropriate audience for the topic(s) presented?</label>
					
					<div><?php echo $arrDetail['topic_presented']?></div>
				</div>
				
				<div class="fieldContainer">
				<label class="questionHeading">18. What actions were taken to assure only appropriate individuals were in the audience?</label>
				<div><pre><?php echo $arrDetail['action']?></pre></div>
				</div>
				
				<div class="fieldContainer">
				<label class="questionHeading">19. Please rate the speakers based on the following:</label>
				<div>5 = Outstanding 4 = Strong 3 = Satisfactory 2 = Poor 1 = Very Poor</div>
				<div style="padding-left: 5px;">
				<table class="ratingContent">
				<?php 
					$arrQuestions = array(1=>'Product / Topic Knowledge',2=>'Effectiveness of delivery',3=>'Ability to answer questions',4=>"Ability to hold the audience's
attention",5=>'Ability to engage audience in discussion',6=>'Provided an impactful presentation',7=>'Ability to present in fair and balanced manner');
				
				?>
					<tr>
							
					<?php foreach($arrQuestions as $key=>$row){?>
						
							<td style="width:22%">
								<?php echo  $row;?>
							</td>
							<td>
							<?php if($ratingDetais[$key]['value']=='0')
                                                            echo "N/A";
                                                        else
                                                            echo $ratingDetais[$key]['value'];
                                                        ?>
							
							</td>
						</tr>
					<?php }?>
					
					</table>
					</div>
				</div>
				
				<div class="fieldContainer">
				
					<label class="questionHeading">20. Did the speaker stay within label during the presentation?</label>
					<div><?php echo $arrDetail['speaker_stay']?></div>
					
				</div>
				
				<div class="fieldContainer">
				
					<label class="questionHeading">21. Did the speaker minimize or dismiss product safety information?</label>
					<div><?php echo $arrDetail['saftey_info']?></div>
				
				</div>
				
				<?php if($arrDetail['speaker_stay']=='No'){?>
				<div class="fieldContainer">
					<div class="mirfContainer" style="display:none">
					<label class="questionHeading">22. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label>
					
					<div><?php echo $arrDetail['mirf']?></div>
					<div class="inputFiedConatiner">
						<label style="display:block"></label>
						<div><pre><?php echo $arrDetail['mirf_other']?></pre></div>
					</div>
				</div>
				<?php  if($arrDetail['speaker_stay']=='Yes'){?>
				
				</div>
				<?php if($arrDetail['speaker_stay']=='Yes'){?>
					<div class="fieldContainer">
						<div class="eventContainer" style="display:none">
						<label class="questionHeading">23. Were any adverse events reported by any attendee during the event?</label>
						
						<div><?php echo $arrDetail['adverse_event']?></div>
						</div>
					</div>
				<?php }?>
				<?php if($arrDetail['adverse_event']=='Yes') ?>
				<div class="fieldContainer">	
					<div class="policyContainer">
					<label class="questionHeading">24. Was the adverse event reported as per Otsuka Policy?</label>
					
					<div><?php echo $arrDetail['adverse_event_report']?></div>
					</div>
				</div>
				<?php }?>
				<?php if($arrDetail['adverse_event']=='No')?>
				<div class="fieldContainer">	
					<div class="productContainer">
						<label class="questionHeading">25. Was the speaker's articulation of their experience with the product on label?</label>
			
					<div><?php echo $arrDetail['speaker_articulation']?></div>
					<div>
						<label style="display:block" class="questionHeading">Comments: </label>
					
							<div><pre><?php echo $arrDetail['speaker_articulation_comment']?></pre></div>
					</div>
					</div>
				</div>
				<?php }?>
				<div class="fieldContainer">
					<label class="questionHeading">26. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label>
	
					<div><?php echo $arrDetail['mirf_doc']?></div>
					<div class="inputFiedConatiner">
						<label style="display:block" class="questionHeading">Other (please specify): </label>
					
						<div><pre><?php echo $arrDetail['mirf_comment']?></pre></div>
					</div>
				</div>
				<div class="fieldContainer">
				
					<label class="questionHeading">27. Speaker was compliant based on Otsuka's Regulatory and Compliance Guidelines:</label>
				<div><?php echo $arrDetail['guideline']?></div>
				</div>
				
				<div class="fieldContainer">
				
					<label class="questionHeading">28. On a scale of 15(1 = extremely unlikely; 5 = Extremely likely),How likely would you be to recommend this speaker to continue to be utilized by Otsuka?</label>
					<div><?php if($arrDetail['scale']==1){
						
						$arrDetail['scale'] ="Extremely unlikely";
						
					}
					if($arrDetail['scale']==2){
						
						$arrDetail['scale'] ="Not likely";
						
					}
					
					if($arrDetail['scale']==3){
						
						$arrDetail['scale'] ="Somewhat likely";
						
					}
					if($arrDetail['scale']==4){
						
						$arrDetail['scale'] ="Likely";
						
					}
					if($arrDetail['scale']==5){
						
						$arrDetail['scale'] ="Extremely likely";
						
					}
					echo $arrDetail['scale']?></div></div>
				
					<div class="fieldContainer">
				
					<label class="questionHeading">29. Recommend speaker for MSL followup visit for support (if any rating 3 or lower on any category, or identified need for greater than quarterly support):</label>
				
					<div><?php echo $arrDetail['msl_follow_up']?></div>
					<div class="inputFiedConatiner">
						<label style="display:block" class="questionHeading">Comments: </label>
				
						<div><pre><?php echo $arrDetail['msl_follow_up_comment']?></pre></div>
					</div>
				</div>
				
		</div>
	</form>
<table><tr>
        <td><strong>Recorded By: </strong><?php echo $arrDetail['user_name']?></td>
        </tr>
        <tr>
        <td><strong>Recorded On: </strong><?php echo $arrDetail['created_on']?></td>
    </tr></table>

</div>
