<?php
/*	Client View page to Add the Clients By Users
 *  @author Vinayak Malladad
 *  @since 1.5
 *  
 */
?>
<script type="text/javascript" src="http://localhost/pfizer/js/jquery/jquery.validate1.9.min.js"></script>	
<style>
.validateForm label{
	font-size: 12px;
}
.validateForm input[type="text"]{
	width: 310px;
}
.validateForm textarea{
	width: 300px;
}
h1{
	color: #2E6E9E;
	font-size: 20px;
}
.red{
	color: red;
	font-size: 12px;
}
.green{
	color: green;
	font-size: 12px;
}
#msgBox{
	float: right;
    text-align: left;
    width: 85%;
    margin-top: 3px;
}
.error{
	padding: 0px;
}
</style>
<!-- jQuery Core File -->
	
<script type="text/javascript">
var validationRules	=  {
	client_name: {
		required:true
	},
	client_email: {
		officialemail: true
	}
};
var validationMessages = {
	client_name: {
		required: "This field is required."
	}
};
$(function () {
	$("#saveClientForm").validate({
        debug: false,
        onkeyup: true,
        rules: validationRules,
        messages: validationMessages
    });
	jQuery.validator.addMethod("officialemail", function (value, element) {
	    if (value != "") {
	        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	        return regex.test(value);
	    }
	        return false;
	    
	}, "Invalid email");
});

function saveClient(){
	if(!$("#saveClientForm").validate().form()){
		return false;
	}else{
		$("#saveClientForm").submit();
		return true;
	}
}
</script>

<h1><?php if($arrClient==null) echo "Add Client"; else echo "Update Client";?></h1>
<form action="<?php echo base_url()."client_users/";if($arrClient==null) echo "save_client"; else echo "update_client";?>" method="post" id="saveClientForm" name="save_client_form" class="validateForm" enctype="multipart/form-data">
	<input type="hidden" name="id" id="clientId" value="<?php if($arrClient!=null) echo $arrClient['id'];?>"></input> 
	<table class="anaylystForm clientTbl" style="width: 50%;">
		<tr>
			<td>
				<label for="clientName">Name<span class="red">*</span></label>
			</td>
			<td>
				<input type="text" name="client_name" id="clientName" value="<?php if($arrClient['name']!=null) echo $arrClient['name'];?>"  />
			</td>
		</tr>
		<tr>
			<td>
				<label for="clientName">Support Email ID<span class="red">*</span></label>
			</td>
			<td>
				<input type="text" name="client_email" id="clientEmail" value="<?php if($arrClient['support_email_id']!=null) echo $arrClient['support_email_id'];?>"  />
			</td>
		</tr>
		<tr>
			<td>
				<label for="clientNotes">Notes</label>
			</td>
			<td>
				<textarea  name="client_notes" id="clientNotes" class="analystNotes"><?php if($arrClient['notes']!=null) echo $arrClient['notes'];?></textarea>
			</td>
		</tr>
		<tr>
			<td>
				<label for="clientLogo">Client Logo<br><span style="font-size: 11px">(Recommended size: 100x50)</span></label>
			</td>
			<td>
				<input type="file" name="client_logo" id="clientLogo"/>
				<?php 
					if($arrClient['client_logo']!=null){
						$clientLogo = $arrClient['client_logo'];
						echo '<input type="hidden" name="client_logo_name" value="'.$clientLogo.'"/>';
						echo '<img src="'.base_url().'images/client_logos/logos/'.$clientLogo.'" style="position:absolute;width:50px;height:50px;"/>';
					}
 				?>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>
				<label for="clientFavicon">Client Favicon<br><span style="font-size: 11px">(Recommended size: 16x16)</span></label>
			</td>
			<td>
				<input type="file" name="client_favicon" id="clientFavicon"/>
				<?php 
					if($arrClient['client_favicon']!=null){
						$clientFavicon = $arrClient['client_favicon'];
						echo '<input type="hidden" name="client_favicon_name" value="'.$clientFavicon.'"/>';
						echo '<img src="'.base_url().'images/client_logos/favicons/'.$clientFavicon.'" style="position:absolute;width:50px;height:50px;"/>';
					}
 				?>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>
				<input type="submit" value="Save" onclick="saveClient();" name="submit_button" />
				<div id='msgBox' class="<?php if($this->session->flashdata('class') == 'green'){echo 'green';} else{echo 'red';}?>"><?php echo $this->session->flashdata('feedback');?></div>
			</td>
		</tr>
	</table>
</form>

