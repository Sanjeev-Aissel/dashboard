<?php
/**
 * File to 'add and list' all event details from analyst application
 *
 * @author: Sanjeev K
 * @package application.module.views.kols.add_event
 * @version HMVC 1.0
 * @created on: 29-04-2018
 */
 $autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";

 function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}
 ?>
 <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
 <style>
	.navbar-global {
  background-color: indigo;
	}
	
	.navbar-global .navbar-brand {
	  color: white;
	}
	
	.navbar-global .navbar-user > li > a
	{
	  color: white;
	}
	
	.navbar-primary {
	  background-color: #ccc;
	  bottom: 0px;
	  left: 0px;
	  position: absolute;
	  top: 88px;
	  width: 200px;
	  z-index: 8;
	  overflow: hidden;
	  -webkit-transition: all 0.1s ease-in-out;
	  -moz-transition: all 0.1s ease-in-out;
	  transition: all 0.1s ease-in-out;
	}
	
	.navbar-primary.collapsed {
	  width: 60px;
	}
	
	.navbar-primary.collapsed .glyphicon {
	  font-size: 22px;
	}
	
	.navbar-primary.collapsed .nav-label {
	  display: none;
	}
	
	.btn-expand-collapse {
	    position: absolute;
	    display: block;
	    left: 0px;
	    bottom:0;
	    width: 100%;
	    padding: 8px 0;
	    border-top:solid 1px #666;
	    color: grey;
	    font-size: 20px;
	    text-align: center;
	}
	
	.btn-expand-collapse:hover,
	.btn-expand-collapse:focus {
	    background-color: #222;
	    color: white;
	}
	
	.btn-expand-collapse:active {
	    background-color: #111;
	}
	
	.navbar-primary-menu,
	.navbar-primary-menu li {
	  margin:0; padding:0;
	  list-style: none;
	}
	
	.navbar-primary-menu li a {
	  display: block;
	  padding: 10px 18px;
	  text-align: left;
	  border-bottom:solid 1px #e7e7e7;
	  color: #333;
	}
	
	.navbar-primary-menu li a:hover {
	  background-color: #fff;
	  text-decoration: none;
	  color: #000;
	}
	
	.navbar-primary-menu li a .glyphicon {
	  margin-right: 6px;
	}
	
	.navbar-primary-menu li a:hover .glyphicon {
	  color: #4285F4;
	}
	
	.main-content {
	  margin-left: 200px;
	  padding: 5px 20px;
	}
	
	.collapsed + .main-content {
	  margin-left: 60px;
	}
	.nav-tabs { 
		border-bottom: 2px solid #DDD; 
	}
	.nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { 
		border-width: 0;
	}
	.nav-tabs > li > a { 
		border: none; 
		color: #666; 
	}
	.nav-tabs > li.active > a, .nav-tabs > li > a:hover {
		border: none; 
		color: #4285F4 !important; 
		background: transparent; 
	}
	.nav-tabs > li > a::after { 
		content: ""; 
		background: #4285F4; 
		height: 2px; 
		position: absolute; 
		width: 100%; 
		left: 0px; 
		bottom: -1px; 
		transition: all 250ms ease 0s; 
		transform: scale(0); 
	}
	.nav-tabs > li.active > a::after, .nav-tabs > li:hover > a::after {
	 	transform: scale(1); 
	}
	.tab-nav > li > a::after { 
		background: #21527d none repeat scroll 0% 0%; 
		color: #fff; 
	}
	.tab-pane {
		padding: 10px 0; 
	}
	.tab-content{
		padding:10px 20px;
	}
	img.add-org {
	    position: absolute;
	    left: 23pc;
	    top: 23px;
	}
	.form-group {
	    margin-bottom: 5px;
	}
	.imageUpload {
	    margin-top: 35px;
	}
	.alert {
	    padding: 10px  !important;
	    margin-bottom: 0px !important;
	    }
	.close {
	    top: 0px  !important;
	    right: 0px  !important;
	    font-size:18px;
	}  
	input#saveContact {
	    position: absolute;
	    top: 22px;
	}  
	.gridData{
		padding:0px 0px !important;
	}
	.panel-heading .colpsible-panel:after {
	    
	    font-family: 'Glyphicons Halflings'; 
	    content: "\e114";    
	    float: right;        
	    color: #4285f4;         
	}
	.panel-heading .colpsible-panel.collapsed:after {
	    content: "\e080"; 
	}
	.gridWrapper {
	    width: 100% !important;
	} 
 
 </style>
	<script type="text/javascript">
	var otherTopicId=0;
	$(function(){
		// Initiate the 'Ternary Navigation
		$("#kolOverviewTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );
	
		// Remove the Surrounding Border
		$("#kolOverviewTernaryNav" ).removeClass("ui-widget-content");
	
		// Remove the Round Corner
		$("#kolOverviewTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
		
		$("#kolOverviewTernaryNav li").removeClass( "ui-corner-top" );
	
		// Add the Custom Class to control View
		$("#kolOverviewTernaryNav > div").addClass( "span-18 last" );
		//Validate function
	});

	//validate month date,year and alos the validate for start and End year
	function isValidDate(date,isStartDate,otherDate,eventType){
		$("#"+eventType+"StartContainer .error").remove();
		$("#"+eventType+"EndContainer .error").remove();
		var month=date.substring(0,2);
		var day=date.substring(3,5);
		var year=date.substring(6);
		var isDateValid=true;
		
		if(month>12)
			isDateValid=false;
		if(day>31)
			isDateValid=false;
		if(year.length<4)
			isDateValid=false;
		if(date!='' && !isDateValid){
			var errorFiled="<label  class=\"error\">Invalid Date<\/label>";
			if(isStartDate)
				$("#"+eventType+"StartContainer").append(errorFiled);
			else
				$("#"+eventType+"EndContainer").append(errorFiled);
			return false;
		}
		else{
			if(!(date=='' || otherDate=='')){
				var date1=new Date(month+" "+ day+","+ year);
				var date2=new Date(otherDate.substring(0,2)+" "+ otherDate.substring(3,5)+","+ otherDate.substring(6));
				if(isStartDate){
					var difference = date2 - date1;
					if(difference<0){
						var errorFiled="<label  class=\"error\">Should be Less than End Year<\/label>";
						$("#"+eventType+"StartContainer").append(errorFiled);
						return false;
					}
				}
				else{
					var difference = date1 - date2;
					if(difference<0){
						var errorFiled="<label  class=\"error\">Should be Greater than Start Year<\/label>";
						$("#"+eventType+"EndContainer").append(errorFiled);
						return false;
					}
				}
			}
			return true;
		}
	}
		var options, a;

		//--------------Start of Conference Event Autocomplet------------------------
			// Autocomplet Options for the 'Event Name' field of type 'Conference Event'
			var confEventNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_eventLookup_names/conference',
				<?php echo $autoSearchOptions;?>
				
			};	

			// Autocomplet Options for the 'Role Name' field of type 'Conference Event'
			var confRoleNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_role_names/conference',
				<?php echo $autoSearchOptions;?>
				
			};	
			//---------End of Conference Event Autocomplet-------------------------------
			
			// Autocomplet Options for the 'Event Name' field of type 'Online Event'
			var onEventNameCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_eventLookup_names/online',
				<?php echo $autoSearchOptions;?>
			};	

			// Autocomplet Options for the 'Role Name' field of type 'Online Event'
			var onRoleNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_role_names/online',
				<?php echo $autoSearchOptions;?>
			};										
			
			
			

						
		function getStatesByCountryId(idName){
			var countryId=$('#countryId' + idName).val();
			var params = "country_id="+countryId;	
			$("#stateId" + idName).html("<option>select state</option>");
			$("#cityId" + idName).html("<option>select city</option>");
			
			var states = document.getElementById('stateId' + idName);
			$.ajax({
				url: "<?php echo base_url()?>/country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {					
						var newState = document.createElement('option');
						newState.text = value.state_name;
						newState.value = value.state_id;
						 var prev = states.options[states.selectedIndex];
						 states.add(newState, prev);				
						});
				}		
			});		
			
		}

		function getCitiesByStateId(idName){
			
			var stateId=$('#stateId' + idName).val();
			
			$("#cityId" + idName).html("<option>select city</option>");	
			var cities = document.getElementById('cityId' + idName);
			var params = "state_id="+stateId;	
			
			$.ajax({
				url: "<?php echo base_url()?>/country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {	
								
					var newCity = document.createElement('option');
					newCity.text = value.city_name;
					newCity.value = value.city_id;
					 var prev = cities.options[cities.selectedIndex];
					 cities.add(newCity, prev);				
					});		
					
				}		
			});		
			
		}
		
		function validateDateFormat(e,src) {
			if (!e) var e = window.event
			if (e.keyCode) code = e.keyCode;
			else if (e.which) code = e.which;
		 
		 	if(src.value == null || src.value == "") {
		 		return true;
		 	}
		 
			if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
				jAlert("Please enter the date in mm/dd/yyyy format!");
				src.focus();
			}
		}

		function dateFormat(e,src) {		
			if (!e) var e = window.event
			if (e.keyCode) code = e.keyCode;
			else if (e.which) code = e.which;
			
			if(code != 37 && code != 38 && code != 39 && code != 40) { 
				if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
					src.value=src.value.replace(/[^0-9\/]/g,'');  
				
					if(code!=8 && code!=46) // not backspace or delete
					{	
						src.value=src.value.replace(/[^0-9]/g,'');
						
						if (src.value.length == 2) {
					        src.value += "/";
					    }
					    				
						if (src.value.length > 2) {
							if(src.value.indexOf('/') != 2) {
								src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
							}
						}
						
						if (src.value.length == 5) {
					        src.value += "/";
					    }
					    
						if (src.value.length > 5) {
							if(src.value.lastIndexOf('/') != 5) {
								src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
							}
						}
						
						if(src.value.length >= 10)
						{
							return false;
						}
					}  
				}
			}
			return true;
		}


		var validationRules	=  {
				event_name: {
					required:true,
					eventName:"<?php echo base_url();?>kols/get_eventLookup_id/"
				},
				start_date: {
					fullYear: true
				},
				end_date: {
					fullYear: true
				},
				eduUrl1: {
					url: true
				},
				eduUrl2: {
					url: true
				},
				event_type: {
					required:true
				},
				topic:{
					required:true
				}
				
			};

			var validationMessages = {
				event_name: {
					required: "Required",
					eventName: "Not Exists"					
				},
				start_date: "Only full year is allowed. Ex: 2010",
				end_date: "Only full year is allowed. Ex: 2010",
				url: "Please enter a valid URL address",
				event_type: {
				required:"Required"
				},
				topic:{
				required:"Required"
				},
				session_type:{
					required:"Required"
				}
			};

			function disableButton(buttonId){
				$("#"+buttonId).attr("disabled", "disabled");
			}

			function enableButton(buttonId){
				$("#"+buttonId).removeAttr("disabled");
			}	


		$(document).ready(function(){
			$('.instNotFound').hide();
			//$('.verticalslider_hideshow').click(function() {
			//	 $(this).toggleClass("right_arrow").toggleClass("left_arrow");
			//	 $(".verticalslider_tabs").toggle();
			//	 $(".tempUl").toggle();	
				 			
			//});
			
			
		//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
		$('div[id^="AutocompleteContainter_"]').remove();	

		// Trigger the Autocompleter for 'Event Name' field of type 'Conference Event'
    	a = $('#confEventName').autocomplete(confEventNameAutoCompleteOptions);	
    	
		// Trigger the Autocompleter for 'Role Name' field of type 'Conference Event'
    	a = $('#confRole').autocomplete(confRoleNameAutoCompleteOptions);	
    			
    	// Trigger the Autocompleter for 'Event Name' field of type 'Online Event'
    	a = $('#onEventName').autocomplete(onEventNameCompleteOptions);    	

		// Trigger the Autocompleter for 'Role Name' field of type 'Online Event'
    	a = $('#onRole').autocomplete(onRoleNameAutoCompleteOptions);    	



    	// populate the Event Lookup form 
		var eventLookupProfileDialogOpts = {
				title: "Create Event Lookup Profile",
				modal: true,
				autoOpen: false,
				dialogClass:'microView',
				height: 300,
				width: 600,
				open: function() {
					//display correct dialog content
				}
		};

		
		//	For Conference		
		//variable name1 is used to store an event name
		//replace function is used in order to consider a space
		$("#dailog4").dialog(eventLookupProfileDialogOpts);
		
		$("#eventLookupProfileLink").click(
	
				function (){
					$('#dailog4').dialog("open");
					var name=$("#confEventName").val();
					var name1=name.replace(/\s/g,'%20');
					//jAlert(name1);
					$('#eventLookupProfile').load('<?php echo base_url()?>kols/add_event_lookup/'+name1);
					return false;
		});				

		// For Online 
		//variable name1 is used to store an event name
		//replace function is used in order to consider a space
	$("#dailog4").dialog(eventLookupProfileDialogOpts);
		
		$("#onEventLookupProfileLink").click(
	
				function (){
					$('#dailog4').dialog("open");
					var name=$("#onEventName").val();
					var name1=name.replace(/\s/g,'%20');
					
					$('#eventLookupProfile').load('<?php echo base_url()?>kols/add_event_lookup/'+name1);
					return false;
		});		






		/**
		*  Save the 'Conference Event Details'
		*/
		$("#saveConference").click(function(){
			// Disable the SAVE Button
			disableButton("saveConference");

			$("#conferenceForm").validate().resetForm();
			
			if(!$("#conferenceForm").validate().form()){
				enableButton("saveConference");
				return false;
			}
			//dont save if dates provided are wrong
			var startDate=$('#confStart').val();
			var endDate=$('#confEnd').val();
			if(startDate!='' || endDate!=''){
				if(!isValidDate(startDate,true,endDate,'conf')){
					enableButton("saveConference");
					return false;
				}
				if(!isValidDate(endDate,false,startDate,'conf')){
					enableButton("saveConference");
					return false;
				}
			}
				

			// Check if the Event Name is present in Master table or not
			eventName	=	$("#confEventName").val(); 
			
			// To make name field Mandatory
		
				// URL to get the Event Lookup ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_eventLookup_id/'+eventName;
	
				// Variable to hold the eventLookup Id
				eventLookupId	= '';
				$.post(urlAction,'',
						function(returnData){
							if(returnData){
								eventLookupId	= returnData;
								$("#confEventNameNotFound").hide();
								saveConferenceDetails(eventLookupId);
							}else{
								enableButton("saveConference");
								$("#confEventNameNotFound").show();
	
								// Set the user entered name in the 'Add New Event Lookup' form
								$("#eventLookupName").val(eventName);
								return false;
							}
						}, 
						"json");
				//- End of checking the Event Name in Master Table
		});	

		
		
		function saveConferenceDetails(eventLookupId){
			$("#confEventId").val(eventLookupId);
			$('div.eventMsgBox').removeClass('success');
			$('div.eventMsgBox').addClass('notice');
			$('div.eventMsgBox').show();
			$('div.eventMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
						
			id = $("#confId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_event';
			}else{
				
				formAction = '<?php echo base_url();?>kols/update_event';
			}					
			
			 $.post(formAction, $("#conferenceForm").serialize(),
					 function(returnData){
							
		     			if(returnData.saved == true){
							
							// Clear the existing form details
							$("#confEventName").val("");
							$("#confEventType").val("");
							$("#confSessionType").val("");
							$("#confSessionName").val("");
							$("#confRole").val("");
							$("#confTopic").val("");
							//remove the other specialty topics from the conference topics select box
							removeTopic(otherTopicId);							
							$("#confStart").val("");
							$("#confEnd").val("");
							$("#confOrganizer").val("");
							$("#confLocation").val("");
							$("#confAddress").val("");
							$("#countryId1").val("");
							$("#stateId1").val("");
							$("#cityId1").val("");
							$("#confPostalCode").val("");
							$("#confUrl1").val("");
							$("#confUrl2").val("");
							$("#confNotes").val("");
							

							$("tr.ui-state-highlight").removeClass('ui-state-highlight');

							
							if(id == ''){									
								var datarow = {
										id				:	returnData.lastInsertId,
										name			:	returnData.data.event_name,
										event_type 		:	returnData.data.event_type,
										session_type	:	returnData.data.session_type,
										session_name	:	returnData.data.session_name,
										role 			:	returnData.data.role,
										topic_name			:	returnData.data.topic_name,
										start			:	returnData.data.start,
										end 			:	returnData.data.end,
										organizer		:	returnData.data.organizer,
										location		:	returnData.data.location,
										address			:	returnData.data.address,
										Country  		:	returnData.data.country_name,
										Region			:	returnData.data.state_name,
										City			:	returnData.data.city_name,
										postal_code 	:	returnData.data.postal_code,
										url1			:	returnData.data.url1,
										url2			:	returnData.data.url2,
										notes			:	returnData.data.notes
										
									}; 
								var su=jQuery("#JQBlistConferenceResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
								
								}
							else
							{
							
							//jQuery("#JQBlistBoardResultSet").trigger("reloadGrid");
							jQuery("#JQBlistConferenceResultSet").jqGrid('setRowData',returnData.data.id,{
																			id				:	returnData.lastInsertId,
																			name			:	returnData.data.event_name,
																			event_type 		:	returnData.data.event_type,
																			session_type	:	returnData.data.session_type,
																			session_name	:	returnData.data.session_name,
																			role 			:	returnData.data.role,
																			topic_name			:	returnData.data.topic_name,
																			start			:	returnData.data.start,
																			end 			:	returnData.data.end,
																			organizer		:	returnData.data.organizer,
																			location		:	returnData.data.location,
																			address			:	returnData.data.address,
																			Country  		:	returnData.data.country_name ,
																			Region			:	returnData.data.state_name,
																			City			:	returnData.data.city_name,
																			postal_code 	:	returnData.data.postal_code,
																			url1			:	returnData.data.url1,
																			url2			:	returnData.data.url2,
																			notes			:	returnData.data.notes
																		}); 
							$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}

					

							// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveConference").val("Add");
		
								// Re-Set the Hidden Id value
								$("#confId").val("");									
							}
							$('div.eventMsgBox').fadeOut(1500);
							$('.eventMsgBox ').hide();
							enableButton("saveConference");
				     	}else{
				     		enableButton("saveConference");
							// Display Error Message
					     }
					},"json");
		};	


		/**
		*  Save the 'Online Event Details'
		*/
		$("#saveOnline").click(function(){
			// Disable the SAVE Button
			disableButton("saveOnline");

			$("#onlineForm").validate().resetForm();
			
			if(!$("#onlineForm").validate().form()){
				enableButton("saveOnline");
				return false;
			}

			//Dont save if dates provided are wrong
			var startDate=$('#onStart').val();
			var endDate=$('#onEnd').val();
			if(!(startDate!='' || endDate!='')){
				if(!isValidDate(startDate,true,endDate,'on')){
					enableButton("saveOnline");
					return false;
				}
				if(!isValidDate(endDate,false,startDate,'on')){
					enableButton("saveOnline");
					return false;
				}
			}
			
			// Check if the Event Name is present in Master table or not
			eventName	=	$("#onEventName").val(); 
			// To make name field Mandatory
			
			
				// URL to get the Event Lookup ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_eventLookup_id/'+eventName;
	
				// Variable to hold the eventLookup Id
				eventLookupId	= '';
				$.post(urlAction,'',
						function(returnData){
							if(returnData){
								eventLookupId	= returnData;
								$("#onEventNameNotFound").hide();
								saveOnlineDetails(eventLookupId);
							}else{
								enableButton("saveOnline");
								$("#onEventNameNotFound").show();
	
								// Set the user entered name in the 'Add New Event' form
								$("#eventLookupCategory").val("online");
								$("#eventLookupName").val(eventName);
								return false;
							}
						}, 
						"json");
				//- End of checking the Intitute Name in Master Table
		});	
				

		function saveOnlineDetails(eventLookupId){
			$("#onEventId").val(eventLookupId);
	
			
			$('div.eventMsgBox').removeClass('success');
			$('div.eventMsgBox').addClass('notice');
			$('div.eventMsgBox').show();
			$('div.eventMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');		

		
			id = $("#onlineId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_event';
			}else{
				formAction = '<?php echo base_url();?>kols/update_event';
			}					
			
			 $.post(formAction, $("#onlineForm").serialize(),
					 function(returnData){
			     		if(returnData.saved == true){
							
							// Clear the existing form details
							$("#onEventName").val("");
							$("#onEventType").val("");
							$("#onRole").val("");
							$("#onTopic").val("");
							$("#onStart").val("");
							$("#onEnd").val("");
							$("#onSubject").val("");
							$("#onOrganizer").val("");
							$("#onUrl1").val("");
							$("#onUrl2").val("");
							$("#onNotes").val("");
							
							$("tr.ui-state-highlight").removeClass('ui-state-highlight');

							if(id == ''){									
							
								var datarow = {
										id			:	returnData.lastInsertId,
										name		:	returnData.data.event_name,
										event_type 	:	returnData.data.event_type,
										onEventTypeId	:	returnData.data.onEventTypeId,
										role 		:	returnData.data.role,
										topic		:	returnData.data.topic,
										start		:	returnData.data.start,
										end 		:	returnData.data.end,
										subject 	:	returnData.data.subject,
										organizer	:	returnData.data.organizer,
										url1		:	returnData.data.url1,
										url2		:	returnData.data.url2,
										notes		:	returnData.data.notes
										
									}; 
								var su=jQuery("#JQBlistOnlineResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
								
								}
							else
							{
							//jQuery("#JQBlistBoardResultSet").trigger("reloadGrid");
						
							jQuery("#JQBlistOnlineResultSet").jqGrid('setRowData',returnData.data.id,{
																								
																				id			:	returnData.lastInsertId,
																				name		:	returnData.data.event_name,
																				event_type 	:	returnData.data.event_type,
																				onEventTypeId	:	returnData.data.onEventTypeId,
																				role		:	returnData.data.role,
																				topic		:	returnData.data.topic,
																				start		:	returnData.data.start,
																				end 		:	returnData.data.end,
																				subject 	:	returnData.data.subject,
																				organizer	:	returnData.data.organizer,
																				url1		:	returnData.data.url1,
																				url2		:	returnData.data.url2,
																				notes		:	returnData.data.notes
																				}); 
							$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}


							// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveOnline").val("Add");
		
								// Re-Set the Hidden Id value
								$("#onlineId").val("");									
							}
							$('div.eventMsgBox').fadeOut(1500);
							$('.eventMsgBox ').hide();
							enableButton("saveOnline");
				     	}else{
				     		enableButton("saveOnline");
							// Display Error Message
					     }
					},"json");
		};			
		

		$("#conferenceForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		$("#onlineForm").validate({
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		



	});

		/**
		* Edit the 'Conference Event Details'
		*/
		function editConference(id){
		
			var rd=jQuery("#JQBlistConferenceResultSet").jqGrid('getRowData',id);
			var eventType ='';
			var sessionType='';
			var country='';

			eventType 	=	rd.event_type;
			sessionType	=	rd.session_type;
			country     =	rd.Country ;
			state		=	rd.Region;
			city		=	rd.City;
			topic		=	rd.topic_name;
			if(country=='')country=0;
			if(topic=='')topic=0;
			
			method = '<?php echo base_url();?>kols/get_conf_event_type_id';
			var data={};
			data['eventType']=eventType;
			data['sessionType']=sessionType;
			data['country']=country;
			data['topic']=topic;
			data['state']=state;
			data['sponsor_type']=rd.stype;
			data['organizer_type']=rd.otype;
			$.post(method,data,function(returnData){
				// Get the values from TR - Table Row, which is under editing
				id 					= rd.id;
				eventName 			= rd.name;
				eventId 			= returnData.event_type;
				sessionId 			= returnData.session_type;
				sessionName			= rd.session_name;
				role				= rd.role;
				otype = returnData.organizer_type;
				var isTopicIdPresent=false;
				$("#confTopic option").each(function(){
					if($(this).val()==returnData.topic_id)
						isTopicIdPresent=true;
				});
				if(isTopicIdPresent)
					topic				= returnData.topic_id;
				else{
					//remove the other specialty topics from the conference topics select box
					if(otherTopicId!=0)
						removeTopic(otherTopicId);
					var value=returnData.topic_id;
					var text=rd.topic_name;
					var topics = document.getElementById('confTopic');
					var newTopic = document.createElement('option');
					newTopic.text = text;
					newTopic.value = value;
					 var prev = topics.options[topics.selectedIndex];
					 topics.add(newTopic, prev);
					 topics.value=value;
					 //set this as a other specialty topic
					 otherTopicId=value;
				}
				start				= rd.start;
				end					= rd.end;
				organizer			= rd.organizer;
				eventLocation		= rd.location;
				address				= rd.address;
				countryId 			= returnData.country_id;
				stateId				= rd.Region; 
				cityId				= rd.City; 
				postalCode			= rd.postal_code;
				url1				= $(rd.url1).attr("href");
				url2				= $(rd.url2).attr("href");
				notes				= rd.notes;
				sessionSponsor				= rd.session_sponsor;
				//populate respective states and cities
				populateStatesCities(state,returnData.states,city,returnData.cities);
				
				// Add the values to the form
				$("#confEventName").val(eventName);
				$("#confEventType").val(eventId);
				$("#confSessionType").val(sessionId);
				$("#confSessionName").val(sessionName);
				$("#confRole").val(role);
				$("#confTopic").val(topic);
				$("#confStart").val(start);
				$("#confEnd").val(end);
				$("#confOrganizer").val(organizer);
				$("#confLocation").val(eventLocation);
				$("#confAddress").val(address);				
				$('#countryId1').val(countryId);
				$("#stateId1").val(stateId);
				$("#cityId1").attr('selected', cityId);
				$("#confPostalCode").val(postalCode);
				$("#confUrl1").val(url1);
				$("#confUrl2").val(url2);
				$("#confNotes").val(notes);
				$("#organizerType").val(otype);
				$("#sessionSponsor").val(sessionSponsor);	
				// Modify the text of 'Button' from 'Add' to 'Update'
				$("#saveConference").val("Update");
	
				// Set the Hidden Conference  Id value
				$("#confId").val(id);			
				$("tr").removeClass('ui-state-highlight');
				$("tr#"+id).addClass('ui-state-highlight');
			},"json");			
		}

		function populateStatesCities(state,arrStates,city,arrCities){
			var statesSelectData="<option value='0'>-- Select State --</option>";
			var citiesSelectData="<option value='0'>-- Select City --</option>";
			var stateId="";
			$.each(arrStates, function(key, value) {				 	
			 	if(value.state_name==state){
			 		stateId=value.state_id;
			 		statesSelectData="<option value='"+value.state_id+"' selected='selected'>"+value.state_name+"</option>"+statesSelectData;	
			 	}else{
			 		statesSelectData+="<option value='"+value.state_id+"'>"+value.state_name+"</option>";
				 }		
			});

			var cities = document.getElementById('cityId1');
			$.each(arrCities, function(key, value) {	
				if(value.city_name==city){
					citiesSelectData+="<option value='"+value.city_id+"'  selected='selected'>"+value.city_name+"</option>";	
			 	}else{
			 		citiesSelectData+="<option value='"+value.city_id+"'>"+value.city_name+"</option>";
				 }						
			});

			$("#stateId1").html(statesSelectData);
			$("#cityId1").html(citiesSelectData);
			$("#stateId1").val(stateId);
		}
		

		/**
		* Edit the 'Online Event Details'
		*/
		function editOnline(id){
		
			var rd=jQuery("#JQBlistOnlineResultSet").jqGrid('getRowData',id);
			var eventName='';
			eventName 	= rd.event_type;
			method		= '<?php echo base_url();?>kols/get_event_type_id/'+eventName;   

		//	$.post(method,function(returnData){
				eventTypeId = rd.onEventTypeId;
				
				// Get the values from TR - Table Row, which is under editing
				id 					= rd.id;
				eventName 			= rd.name;
				//eventType			= rd.event_type;
				role				= rd.role;
				topic				= rd.topic;
				start				= rd.start;
				end					= rd.end;
				subject				= rd.subject;
				organizer			= rd.organizer;
				url1				= $(rd.url1).attr("href");
				url2				= $(rd.url2).attr("href");
				notes				= rd.notes;
				// Add the values to the form
				$("#onEventName").val(eventName);
				$("#onEventType").val(eventTypeId);
				$("#onRole").val(role);
				$("#onTopic").val(topic);
				$("#onStart").val(start);
				$("#onEnd").val(end);
				$("#onSubject").val(subject);
				$("#onOrganizer").val(organizer);
				$("#onUrl1").val(url1);
				$("#onUrl2").val(url2);
				$("#onNotes").val(notes);
				$("#sessionSponsor").val(sessionSponsor);
				
				// Modify the text of 'Button' from 'Add' to 'Update'
				$("#saveOnline").val("Update");
	
				// Set the Hidden online Id value
				$("#onlineId").val(id);			
				$("tr").removeClass('ui-state-highlight');
				$("tr#"+id).addClass('ui-state-highlight');
			//},"json");
		}		

		

		/**
		* Delete the 'Conference Event Details'
		*/
		function deleteConference(id){								
			var	formAction = '<?php echo base_url();?>kols/delete_event/'+id;
			jQuery("#JQBlistConferenceResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});     
		}
		

		/**
		* Delete the 'Online Event Details'
		*/
		function deleteOnline(id){								
			var formAction = '<?php echo base_url();?>kols/delete_event/'+id;
			jQuery("#JQBlistOnlineResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});     
		}		



		function conferenceTab()
		{
                var kolId = $('#kolId').val();			
				var startYear='';
				var endYear='';
				
				/*
				*jqgrid for Conference Event table
				*/
				jQuery("#JQBlistConferenceResultSet").jqGrid({
				   	url:'<?php echo base_url();?>kols/list_events/conference/0/0/'+kolId,
					datatype: "json",
				   	colNames:['Id','EventName','EventType', 'SessionType', 'SessionName','Role','Sponsor type','Sponsor Session','Topic','Start','End','Organizer','Organizer Type','Location','Address','Country','State','City','PostalCode','URL1','URL2','Notes','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'name',index:'name', width:100,editable:true},
				   		{name:'event_type',index:'event_type',width:100,editable:true},
				   		{name:'session_type',index:'session_type',width:100,editable:true},
				   		{name:'session_name',index:'session_name',width:100,resizable:true,editable:true},
				   		{name:'role',index:'role',width:100,resizable:true,editable:true},
				   		{name:'stype',index:'stype',width:100,resizable:true,editable:true},
				   		{name:'session_sponsor',index:'session_sponsor',width:100,resizable:true,editable:true},
				   		{name:'topic_name',index:'topic',width:100,editable:true},
				   		{name:'start',index:'start',width:100,resizable:true,editable:true},
				   		{name:'end',index:'end',width:100,resizable:true,editable:true},
				   		{name:'organizer',index:'organizer', width:100,editable:true},
				   		{name:'otype',index:'otype', width:100,editable:true},
				   		{name:'location',index:'location',width:100,editable:true},
				   		{name:'address',index:'address',width:100,editable:true},
				   		{name:'Country',index:'Country',width:100,resizable:true,editable:true},
				   		{name:'Region',index:'Region',width:100,resizable:true,editable:true},
				   		{name:'City',index:'City',width:100,editable:true},
				   		{name:'postal_code',index:'postal_code',width:100,resizable:true,editable:true},
				   		{name:'url1',index:'url1',width:20,resizable:true,editable:true, search:false},
				   		{name:'url2',index:'url2',width:20,editable:true, search:false},
				   		{name:'notes',index:'notes',width:40,resizable:true,editable:true,search:false},
				   		{name:'act',resizable:true, search:false,width:60}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	autowidth: true, 
				   	shrinkToFit:false,
				   	loadonce:true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",	
				   	resizable:true,	  
				   	pager: '#listConferencePage',
				   	mtype: "POST",
				   	sortname: 'institute_id',
				    viewrecords: true,
				    sortorder: "desc",
				    shrinkToFit:false,
				    multiselect: true,
				    gridComplete: function(){ 
					    var ids = jQuery("#JQBlistConferenceResultSet").jqGrid('getDataIDs'); 
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];				    	
						    //	be = "<a href='#' onclick=\"editConference('"+cl+"');\" >edit</a>/<a href='#' onclick=\"deleteConference('"+cl+"');\" >delete</a>"; 	
						    	be = "<a href='#' onclick=\"editConference('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
						    	be += " | ";
						    	be += "<a href='#' onclick=\"deleteConference('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";				    	
						    				    	
						    	jQuery("#JQBlistConferenceResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistConferenceResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	}, 
		
			    	loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
		    				},
		
		    				
				    jsonReader: { repeatitems : false, id: "0" }, 
				    caption:"Conference Details"		    
				});
				jQuery("#JQBlistConferenceResultSet").jqGrid('navGrid','#listConferencePage',{edit:false,add:false,del:false,search:false,refresh:false});	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistConferenceResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistEducationResultSet").height(25).jqGrid('filterGrid',"JQBlistEducationResultSet",{gridModel:true,gridToolbar:true});
				jQuery("#JQBlistConferenceResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 

				// Delete selected row(s)
				jQuery("#JQBlistConferenceResultSet").jqGrid('navButtonAdd',"#listConferencePage",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
					onClickButton:function (){
						var selectedEvents	= $(this).getGridParam('selarrrow');
						if(selectedEvents.length>0){
							deleteSelectedEvents(selectedEvents);
						}else{
							jAlert('Please select atleast one Event');
						}
					}
				});
				//Toggle Toolbar Search 
				jQuery("#JQBlistConferenceResultSet").jqGrid('navButtonAdd',"#listConferencePage",{caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}
						
					} 
				}); 
		
		}

		function deleteSelectedEvents(eveIds){
			jConfirm("Are you sure you want to delete selected Event's?","Please confirm",function(r){
				if(r){
//					alert(eveIds);
					var data = {};
					data['ids'] = eveIds;
					$.ajax({
						url:'<?php echo base_url()?>kols/delete_selected_events',
						type:'post',
						data:data,
						dataType:"json",
						success:function(returnMsg){
							if(returnMsg.status)
								$('a[href="#conferenceTabId"]').trigger('click');
							}
					});
					}else{
							return false;
						}
			});
			} 
		function onlineTab()
		{
				/*
				*jqgrid for Online Event table
				*/
				jQuery("#JQBlistOnlineResultSet").jqGrid({
				   	url:'<?php echo base_url();?>kols/list_events/online',
					datatype: "json",
				   	colNames:['Id','EventName','EventType','EventID','Role','Topic','Start','End','Subject','Organizer','URL1','URL2','Notes','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'name',index:'name', width:200,editable:true},
				   		{name:'event_type',index:'event_type',width:80,editable:true},
				   		{name:'onEventTypeId',index:'onEventTypeId',width:10,editable:true, hidden: true},
				   		{name:'role',index:'role',width:80,resizable:true,editable:true},
				   		{name:'topic',index:'topic',width:80,editable:true},
				   		{name:'start',index:'start',width:80,resizable:true,editable:true},
				   		{name:'end',index:'end',width:80,resizable:true,editable:true},
				   		{name:'subject',index:'subject',width:80,editable:true},
				   		{name:'organizer',index:'organizer', width:70,editable:true},
				   		{name:'url1',index:'url1',width:50,resizable:true,editable:true, search:false},
				   		{name:'url2',index:'url2',width:50,editable:true, search:false},
				   		{name:'notes',index:'notes',width:50,resizable:true,editable:true,search:false},
				   		{name:'act',resizable:true,width:60,search:false}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	autowidth: true, 
				   	shrinkToFit:false, 
				   	loadonce:true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",	
				   	resizable:true,		   
				   	pager: '#listOnlinePage',
				   	mtype: "POST",
				   	sortname: 'institute_id',
				    viewrecords: true,
				    sortorder: "desc",
				    gridComplete: function(){ 
					    var ids = jQuery("#JQBlistOnlineResultSet").jqGrid('getDataIDs'); 
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];				    	
						  //  	be = "<a href='#' onclick=\"editOnline('"+cl+"');\" >edit</a>/<a href='#' onclick=\"deleteOnline('"+cl+"');\" >delete</a>"; 	
						    	be = "<a href='#' onclick=\"editOnline('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
						    	be += " | ";
						    	be += "<a href='#' onclick=\"deleteOnline('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";	
						    				    	
						    	jQuery("#JQBlistOnlineResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistOnlineResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	}, 
		
			    	loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    			},
				    	   	
				    jsonReader: { repeatitems : false, id: "0" }, 
				    caption:"Online Details"		    
				});
				jQuery("#JQBlistOnlineResultSet").jqGrid('navGrid','#listOnlinePage',{edit:false,add:false,del:false,search:false,refresh:false});	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistOnlineResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistEducationResultSet").height(25).jqGrid('filterGrid',"JQBlistEducationResultSet",{gridModel:true,gridToolbar:true});
				jQuery("#JQBlistOnlineResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistOnlineResultSet").jqGrid('navButtonAdd',"#listOnlinePage",{caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}
						
					} 
				}); 
		
		}
			
		//Opens the tab based topics in a model box
		function showAllTopics(){
			//$( "#eventTopics" ).dialog({ position: [e.clientX,e.clientY-130] });
			$("#eventTopics .profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#eventTopics").dialog("open");
			$("#eventTopics .profileContent").load('<?php echo base_url().'kols/view_all_topics/'?>',{},
					function(){
				});
		}

		//adds the given option to the conference topics select box
		function addSelectedTopicToList(value,text){
			//remove the other specialty topics from the conference topics select box
			if(otherTopicId!=0)
				removeTopic(otherTopicId);
			var topics = document.getElementById('confTopic');
			var newTopic = document.createElement('option');
			newTopic.text = text;
			newTopic.value = value;
			 var prev = topics.options[topics.selectedIndex];
			 topics.add(newTopic, prev);
			 topics.value=value;
			 //set this as a other specialty topic
			 otherTopicId=value;
		}

		//Removes the given option from the conference topics select box
		function removeTopic(topicId){			
			$("#confTopic  option").each(function(){
				if($(this).val()==topicId)
					$(this).remove();
			});
		}					
				
		$(document).ready(function() {
			$('.nav-tabs li a').click(function(){
				loadSelectedTab(this);
			});
			conferenceTab();

			// Settings for the Dialog Box
			var eventAllTopicsDialogOpts = {
					title: "",
					modal: true,
					autoOpen: false,
					width:420,
					dialogClass: "microView",
					open: function() {
						//display correct dialog content
					}
			};

			
			$("#eventTopics").dialog(eventAllTopicsDialogOpts);

		});

		function loadSelectedTab(selected){
			//var sel=$('#kolOverviewTernaryNav').tabs('option','selected');
			var sel= $(selected).attr('aria-controls');
			switch(sel){
				case 'conference': $("#genericGridContainer").html("");
						
						// Append the required div and table
						$("#genericGridContainer").html('<table id="JQBlistConferenceResultSet"></table><div id="listConferencePage"></div>');
	
						conferenceTab();
						break;
				
				case 'online': $("#genericGridContainer").html("");
						
						// Append the required div and table
						$("#genericGridContainer").html('<table id="JQBlistOnlineResultSet"></table><div id="listOnlinePage"></div>');
	
						onlineTab();
						break;
							
			}
		}
		$(".validateForm").validationEngine({
			promptPosition: "centerRight", // OPENNING BOX POSITION, IMPLEMENTED: topLeft, topRight, bottomLeft,  centerRight, bottomRight
			success :  false,				
			failure : function() {}			 		
		 });
		 
	</script>
	<?php $this->load->view('kols/secondary_menu');?>
<div class="main-content">
	<div class="row">
		<div id="kolTernaryNav" class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Details" class="active"><a href="#conference" aria-controls="conference" role="tab" data-toggle="tab">Conference</a></li>
                  <li role="Details"><a href="#online" aria-controls="online" role="tab" data-toggle="tab">Online</a></li>
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
               <div>
               	<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrKol['first_name'].' '.$arrKol['middle_name'].' '.$arrKol['last_name']; ?></h5>
               </div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="conference">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading">
									<h3 class="panel-title"><a class="colpsible-panel collapsed" data-toggle="collapse" data-parent="#accordion" href="#conferenceToggle" title="Click to Expand">Add Conference Details</a></h3> 
	                  				</a>
	                  			</div> 
	                  			<div id="conferenceToggle" class="panel-collapse collapse">
	                  			<div class="panel-body">
	                  				<div class="">
		                  				<form action="save_event" method="post" id="conferenceForm" name="conferenceForm" class="validateForm form-horizontal">
		                  					<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
		                  					<div class="form-group">
												<div class="col-md-3">
													<label class="control-label">Event Name <span class="required">*</span> :</label>
													<input type="hidden" name="type" value="conference">
													<input type="hidden" name="id" id="confId" value=""></input>
													<input type="hidden" name="event_id" id="confEventId" value=""></input>
													<input type="text" name="event_name" value="" id="confEventName" class="required form-control"></input>
													<div id="confEventNameNotFound" class="instNotFound">Sorry! The Event Name is not found in our database. <a href="#" id="eventLookupProfileLink">Click here</a> to add this Event Name</div>
												</div>
												<div class="col-md-3">
													<label class="control-label">Event Type <span class="required">*</span> :</label>
													<select name="event_type" id="confEventType" class="required form-control">
											   			<option value="">--- Select ---</option>
														<?php 
															foreach($arrConfEventTypes as $key => $value){
																echo '<option value="'.$key.'">'.$value.'</option>';
															}
														?>
											    	</select>
												</div>
												<div class="col-md-3">
													<label class="control-label">Session Type <span class="required">*</span> :</label>
													<select name="session_type" id="confSessionType" class="required form-control">
											   			<option value="">--- Select ---</option>
														<?php 
															foreach($arrConfSessionTypes as $key => $value){
																echo '<option value="'.$key.'">'.$value.'</option>';
															}
														?>
											    	</select>		
												</div>
												<div class="col-md-3">
													<label class="control-label">Session Name :</label>
													<input type="text" name="session_name" value="" id="confSessionName" class="form-control"></input>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-3">
													<label class="control-label">Sponsor Type :</label>
													<select name="sponsor_type" id="sponcerType" class="form-control">
											   			<option value="">--- Select ---</option>
														<?php 
															foreach($arrEventSponsorTypes as $key => $value){
																echo '<option value="'.$key.'">'.$value.'</option>';
															}
														?>
											    	</select>
												</div>
												<div class="col-md-3">
													<label class="control-label">Session Sponsor :</label>
													<input type="text" name="session_sponsor" value="" id="sessionSponsor" class="session_sponsor form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Role <span class="required">*</span> :</label>
													<select name="role" id="confRole" class="required form-control">
											   			<option value="">--- Select ---</option>
														<?php 
															foreach($arrRoles as $key => $value){
																echo '<option value="'.$value.'">'.$value.'</option>';
															}
														?>
											    	</select>
												</div>
												<div class="col-md-3">
													<label class="control-label">Topic <span class="required">*</span> :</label>
													<select name="topic" id="confTopic" class="required form-control">
											     		<option value="">--- Select ---</option>
														<?php 
															foreach($arrTopics as $key => $value){
																echo '<option value="'.$key.'">'.$value['name'].'</option>';
															}
														?>
											    	</select>
											    	<a id="allTopicBtn" href="#" onclick="showAllTopics();" style="float:right;">All</a>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-3">
													<label class="control-label">Start :</label>
													<input type="text" name="start" value="" id="confStart" class="form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,true,end.value,'conf')"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">End :</label>
													<input type="text" name="end" value="" id="confEnd" class="form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,false,start.value,'conf')"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Organizer :</label>
													<input type="text" name="organizer" value="" id="confOrganizer" class="form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Organizer Type :</label>
													<select name="organizer_type" id="organizerType" class="form-control">
											   			<option value="">--- Select ---</option>
														<?php 
															foreach($arrEventOrganizerTypes as $key => $value){
																echo '<option value="'.$key.'">'.$value.'</option>';
															}
														?>
							    				</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-3">
													<label class="control-label">Address :</label>
													<input type="text" name="address" value="" id="confAddress" class="form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Location :</label>
													<input type="text" name="location" value="" id="confLocation" class="form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Country :</label>
													<select name="country_id" id="countryId1" onchange="getStatesByCountryId(1);" class="form-control">
														<option value="">-- Select --</option>
														<?php foreach( $arrCountry as $country ){ ?>
														<option value="<?php echo $country['country_id'];?>">
														<?php echo $country['country_name'];?>
														</option>
														<?php }?>
													</select>
												</div>
												<div class="col-md-3">
													<label class="control-label">State / Province :</label>
													<select name="state_id" id="stateId1" onchange="getCitiesByStateId(1);" class="form-control">		
														<option>select state</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-3">
													<label class="control-label">City :</label>
													<select name="city_id" id="cityId1" class="form-control">
														<option >select city</option>		
													</select>
												</div>
												<div class="col-md-3">
													<label class="control-label">Postal Code :</label>
													<input type="text" name="postal_code" value="" id="confPostalCode" class="form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Url1 :</label>
													<input type="text" name="url1" value="" id="confUrl1" class="url form-control"></input>
												</div>
												<div class="col-md-3">
													<label class="control-label">Url2 :</label>
													<input type="text" name="url2" value="" id="confUrl2" class="url form-control"></input>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-12">
													<label class="control-label">Notes :</label>
													<textarea id="confNotes" rows="2" cols="40" name="notes" class="analystNotes form-control"></textarea>
												</div>
											</div>  
											<div style="text-align: center;">
												<button type="button" name="submit" id="saveConference" class="btn btn-primary pull-center"><span class="icon glyphicon glyphicon-plus-sign"></span> Add</button>
												<button type="button" name="cancel" id="clearInfo" onclick="clearInfo();" class="btn btn-default pull-center"><span class="icon red glyphicon glyphicon-remove-circle"></span> Cancel</button>
											</div>	
		                  				</form>
	                  				</div>
	                  			</div> 
	                  			</div>
	                  		</div>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="online">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading">
									<h3 class="panel-title"><a class="colpsible-panel collapsed" data-toggle="collapse" data-parent="#accordion" href="#onlineToggle" title="Click to Expand">Add Online Details</a></h3> 
	                  				</a>
	                  			</div> 
	                  			<div id="onlineToggle" class="panel-collapse collapse">
	                  			<div class="panel-body">
	                  				<div class="col-md-8 col-md-offset-2">
		                  				<form action="save_event" method="post" id="onlineForm" name="onlineForm" class="validateForm form-horizontal">
		                  					<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
		                  					<div class="form-group">
									<div class="col-md-5">
										<label class="control-label">Event Name <span class="required">*</span> :</label>
										<input type="hidden" name="type" value="online">
										<input type="hidden" name="id" id="onlineId" value=""></input>
										<input type="hidden" name="event_id" id="onEventId" value=""></input>
										<input type="text" name="event_name" value="" id="onEventName" class="required form-control"></input>
										<div id="onEventNameNotFound" class="instNotFound">Sorry! The Event Name is not found in our database. <a href="#" id="onEventLookupProfileLink">Click here</a> to add this Event Name</div>
									</div>
									<div class="col-md-5 col-md-offset-2">
										<label class="control-label">Event Type <span class="required">*</span> :</label>
										<select name="event_type" id="onEventType" class="required form-control">
									   			<option value="">--- Select ---</option>
												<?php 
													foreach($arrOnlineEventTypes as $key => $value){
														echo '<option value="'.$key.'">'.$value.'</option>';
													}
												?>
									    	</select>
									</div>
								</div>
								<div class="form-group">
									
									<div class="col-md-5">
										<label class="control-label">Subject :</label>
										<input type="text" name="subject" value="" id="onSubject" class="form-control"></input>
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-5">
										<label class="control-label">Role :</label>
										<input type="text" name="role" value="" id="onRole" class="form-control"></input>
									</div>
									<div class="col-md-5 col-md-offset-2">
										<label class="control-label">Topic :</label>
										<select name="topic" id="onTopic" class="form-control">
									     		<option value="1">provided later</option>
									     		<option value="2">Not yet decided</option>
									    </select>
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-5">
										<label class="control-label">Start :</label>
										<input type="text" name="start" value="" id="onStart" class="form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,true,end.value,'on')"></input>
									</div>
									<div class="col-md-5 col-md-offset-2">
										<label class="control-label">End :</label>
										<input type="text" name="end" value="" id="onEnd" class="form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,false,start.value,'on')"></input>
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-5">
										<label class="control-label">Organizer :</label>
										<input type="text" name="organizer" value="" id="onOrganizer" class="form-control"></input>
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-5">
										<label class="control-label">Url1 :</label>
										<input type="text" name="url1" value="" id="onUrl1" class="url form-control"></input>
									</div>
									<div class="col-md-5 col-md-offset-2">
										<label class="control-label">Url2 :</label>
										<input type="text" name="url1" value="" id="onUrl1" class="url form-control"></input>
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-12">
										<label class="control-label">Notes :</label>
										<textarea id="onNotes" rows="2" cols="40" name="notes" class="analystNotes form-control"></textarea>
									</div>
								</div>  
								<div style="text-align: center;">
									<button type="button" name="submit" id="saveOnline" class="btn btn-primary pull-center"><span class="icon glyphicon glyphicon-plus-sign"></span> Add</button>
									<button type="button" name="cancel" id="clearInfo" onclick="clearInfo();" class="btn btn-default pull-center"><span class="icon red glyphicon glyphicon-remove-circle"></span> Cancel</button>
								</div>	
		                  				</form>
	                  				</div>
	                  			</div> 
	                  			</div>
	                  		</div>	
                  </div>
        <!-- End Tab panels --> 
        <!-- Generic Grid Panel to load all four respective grid content --> 
			<div class="col-md-12 gridData">
                  <div class="gridWrapper" id="genericGridContainer">
					<table id="JQBlistConferenceResultSet"></table>
					<div id="listConferencePage"></div>
				  </div>
            </div>
		<!-- End of Grid Panel -->   
               </div>     
        </div>
	</div>
</div>			