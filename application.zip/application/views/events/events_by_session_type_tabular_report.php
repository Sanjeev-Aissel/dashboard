<?php


//To show row list in jqgrid
	function listRecordsPerPage($maxRecords=1000,$increament=100){
		$rowList="";
		for($i=100;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 
	
		$page						= 1; // get the requested page 
		$limit						= 100;
		$count					= sizeof($arrEvents);				
		if( $count >0 ){ 
			$total_pages 		= ceil($count/$limit); 
		}else{ 
			$total_pages 		= 0; 
		} 
		$data['records'] 		= $count;
		$data['total']   		= $total_pages;
		$data['page']    = $page;				
		$data['rows']    		= $arrEvents;  
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
	<meta charset="UTF-8" />
	<title>Key Opinion Leader Management</title>
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	<!-- jQuery Core File -->
	<link href="<?php echo base_url();?>css/tooltip/bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/tooltip/style.less" rel="stylesheet/less" type="text/css">
	<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<script src="<?php echo base_url();?>js/tooltip/less-1.2.1.min.js" type="text/javascript"></script>	
	<script src="<?php echo base_url();?>js/tooltip/bootstrap-tooltip.js"></script>
	<!-- jQuery UI File -->
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>	
	
	<!-- JQGrid Plugins -->
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min.js" type="text/javascript"></script>
	
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/client_layout.css" />
	<style type="text/css">
		#eventsListingContainer{
			margin:10px;
		}
		
		#eventsListingContainer h2, #eventsListingContainer h3{
			text-align:left;
			font-weight:normal;
		}
		
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			padding: 0px;
			padding-left:4px;
		}
		.ui-widget-header {
		    background-image: none;
		}
		.ui-jqgrid .ui-jqgrid-title {
		    font-size: 13px;
		    padding-left: 1px;
		}
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			border-bottom:1px solid #EEEEEE;
		}
		h2 {
		    color: #626262;
		    font-family: lucida grande,tahoma,verdana,helvetica,arial !important;
		    font-size: 12px;
		    font-weight: bold !important;
		}
		.gridWrapper .ui-jqgrid tr.ui-search-toolbar th div {
		    text-align: left;
		}
	</style>
	
	
<script type="text/javascript">

	var paginationValues		= new Array();
	<?php 
		$paginationValues	= explode(',',PAGINATION_VALUES);
		foreach($paginationValues as $key=>$value){
	?>
		paginationValues.push('<?php echo $value;?>');
	<?php
		}
	?>
	var eventsTitle = "<?php echo lang("events");?>";
	var eventNameHeader = "<?php echo lang("Overview.EventName");?>";
	var organizerHeader = "<?php echo lang("organizer");?>";
	var startDateHeader = "<?php echo lang("track.StartDate");?>";
	var endDateHeader = "<?php echo lang("track.EndDate");?>";
	var noOfProfilesHeader = "<?php echo lang("noOfProfiles");?>";

	$(document).ready(function(){
		var data = <?php echo json_encode($data);?>;
		jQuery("#JQBlistEventResultSet").jqGrid({
		  
			datatype: "jsonstring",
	        datastr: data,
		   	colNames:[eventNameHeader,organizerHeader,startDateHeader,endDateHeader],
		   	colModel:[
		   	    {name:'name',index:'name',width:300,search:true},
		   		{name:'organizer',index:'organizer',width:200},
		   		{name:'start',index:'start',width:50},
		   		{name:'end',index:'end',width:50}
//		   		{name:'attended_kols',index:'attended_kols',width:100, sorttype:"int"}
		   	],
		   	rowNum:100,
		   	rownumbers: true,
		   	autowidth: true, 
			
			gridComplete: function(){ 
	    		jQuery("#JQBlistEventResultSet").jqGrid('navGrid','hideCol',"id"); 
	    		var ALL = '<?php echo $count?>' ;
	    		$.each($('.ui-pg-selbox'),function(){
	    			$(this).children('option:last').val(ALL).text('All');
	    		});
	    	}, 
		   	loadonce:true,
		   	multiselect: false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	width: 800,  
		   	pager: '#listlistEventPage',
		   	toppager:true,
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
			rowList:paginationValues,
		    jsonReader: { repeatitems : false, id: "0" },
		    //toolbar: "top",
		    caption:eventsTitle,
		    rowList:[<?php echo listRecordsPerPage()?>]
	   	
		});
	
		jQuery("#JQBlistEventResultSet").jqGrid('navGrid','#listlistEventPage',{edit:false,add:false,del:false,search:false,refresh:false});
		
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistEventResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistEventResultSet").jqGrid('navButtonAdd',"#listlistEventPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

			// Set the JSON data
			//var data = <?php echo json_encode($arrEvents);?>;
			//jQuery("#JQBlistEventResultSet").jqGrid('addRowData',2,data);
			
			//Place holder to Jqgrid Search Column
			$(".ui-search-toolbar input[type='text']").each(function(){
				$(this).attr("placeholder","Search");
		    });
			
			<?php 
	    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
				if(preg_match('/MSIE/i',$u_agent)){
	    	?>
	    	$('.ui-search-toolbar input[placeholder]').each(function(){
	    		$(this).after("<span class='jq-placeholder'>"+$(this).attr('placeholder')+"</span>"); 
	            var input = $(this);       
	            $(input).focus(function(){
	                $(this).next().hide();
	            });
	            $(input).blur(function(){
	                 if (input.val() == '') {
	                	 $(this).next().show();
	                 }
	            });
	        });

	        $(".jq-placeholder").live("click",function(){
	        	$(this).hide();
	        	$(this).prev().focus();
		    });
	        <?php }?>
		
	});
	//- End of DOCUMENT.READY function
	
	
</script>

</head>
<body>

<div id="eventsListingContainer">
		<div id="searchResultsContainer">
		
			<div class="gridWrapper" id="gridContainer">
							<div id="listlistEventPage"></div>
							<table id="JQBlistEventResultSet"></table>
			</div>	
		</div>
	
</div>
</body>
</html>