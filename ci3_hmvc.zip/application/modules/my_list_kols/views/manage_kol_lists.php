<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"/>
<?php
	$queued_js_scripts = array('js/custom_js/jqgridExportToExcel',
			'jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'modules/my_list_kols/js/my_list_kols',
			'jquery_validator/dist/jquery.validate',
			'js/jquery.autocomplete','alerts/jquery.alerts'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<input type="hidden" id="hidden_category_id">
<input type="hidden" id="hidden_list_id">
<input type="hidden" id="hidden_category_name">
<input type="hidden" id="hidden_list_name">
<div class="row">
	<div class="col-md-6" id="catogriesDiv">
	<div class="panel panel-default">
	  <div class="panel-heading">
		  Categories
		  <button onclick="add_category();return false;" type="button" class="btn custom-btn pull-right" title="Add category">Add Category</button>
	  </div>
	  <div class="panel-body">
	  	<div class="gridWrapper clear" id="categoriesGridContainer">
			<table id="JQBlistCategoriesResultSet"></table>
			<div id="listCategoriesPage"></div>
		</div>
	  </div>
	</div>
	</div>
	<div class="col-md-6" id="listsDiv">
	<div class="panel panel-default">
	  <div class="panel-heading">
	  Lists
	  <button onclick="add_list();return false;" type="button" class="btn custom-btn pull-right" title="Add List">Add List</button>
	  </div>
	  <div class="panel-body">
		<div class="gridWrapper clear" id="ListGridContainer">
			<table id="JQBlistsResultSet"></table>
			<div id="listsPage"></div>
		</div>
		</div>
	</div>
	</div>
</div>
<div class="row"  id="kolsDiv">
<div class="panel panel-default">
	<div class="panel-heading">
	  KOL's
	  <div class="pull-right">
			<button onclick="add_kols_to_list();return false;" type="button" class="btn custom-btn" title="Add List">
				Add KOL To list
			</button>
			<button id="removeKols" type="button" class="btn custom-btn" title="Remove KOLs From list">
				Remove KOLs From list
			</button>
	 		<div class="excelExportIcon sprite_iconSet" onclick="showExportBox();return false;">
				<a rel="tooltip" title="Export profiles into Excel format">&nbsp;</a>
			</div>
		    <div class="pdfExportIcon sprite_iconSet" onclick="exportPdfProfile();" style="margin-left: 2px;">
		    	<form action="<?php echo base_url();?>kols/kols/export_pdf" id="kolPdfExport" method="post">
		    		<a rel="tooltip" href="#" title="Export profile into PDF format">&nbsp;</a>
				</form>
			</div>
			<div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBoxInOvearllPage();return false;">
				<a rel="tooltip" href="#" title="Email Profile">&nbsp;</a>
			</div>
		</div>
   </div>
	<div class="panel-body">
		<div class="gridWrapper clear" id="ListKOlsGridContainer">
			<table id="JQBlistKolsResultSet"></table>
			<div id="listKolsPage"></div>
		</div>
	</div>
	</div>
</div>
<div id="modalContainer1" class="microViewLoading">
	<div class="modalContent1"></div>
</div>
<script>
$(document).ready(function(){
	getCategoriesListOnLoad();
});
</script>