<table>
	<tr>
		<th>Updated</th>
		<th>Survey</th>
		<th>Created By</th>
		<th>Created On</th>
		<th>Respondent ID</th>
		<th>Influecner Type</th>
		<th>Influecner ID</th>
		<th>Zero Influencer</th>
	</tr>
<?php
foreach($arrData as $key=>$row){
	echo '<tr><td>'.$row['updated'].'</td><td>'.$row['survey_name'].' ('.$row['survey_id'].')</td><td>'.$row['user_name'].' ('.$row['created_by'].')</td><td>'.$row['created_on'].'</td><td>'.$row['respondent_name'].'-'.$row['resp_mdm'].' ('.$row['resp_id'].')</td><td>'.$row['type'].'</td><td>'.$row['influencer_name'].'-'.$row['influencer_mdm'].' ('.$row['influencer_id'].')</td><td>'.$row['zeroInfluencers'].'</td></tr>';
}
?>
</table>