<?php
/**
 * File to 'add' Institution details
 *
 * @author: Ambarish
 * @created on: 24-12-10
 */
?>

	<!-- style type="text/css">
		#institutionForm{
			text-align:left;
		}
		#institutionForm label{
			text-align:right;
			float:left;
			width:130px;
			padding-right:8px;
		}
	
		#institutionForm textarea{
			height:30px;
			width:250px;
		}
		
		#institutionForm instituteName{
			width:250px;
		}		
		
		#institutionForm div.formButtons{
			text-align:center;
		}
		
		#institutionFormContainer div.msgBoxContainer{
			margin-bottom:20px;
		}
		
		
	</style> -->
	<style>
	.formButtons{
		text-align: center;
	}
	</style>
	<script type="text/javascript">


		/**
		* Save the new Institute Name
		*/
		function saveInstitute(){
			formData	= $("#institutionForm").serialize();
			$.ajax({
				type:"post",
				dataType:"json",
				data: formData,
				url:'<?php echo base_url()?>kols/save_institution',
				success:function(returnMsg){
					$('div.instituteMsgBox').fadeIn("fast");
					$('div.instituteMsgBox').text(returnMsg.msg);
					if(returnMsg.saved){
						$('div.instituteMsgBox').removeClass('error');
						$('div.instituteMsgBox').addClass('success');

						// Remove/Hide the 'Inst Not Found' text
						$(".instNotFound").hide();
						
						//$('div.instituteMsgBox').fadeOut(5500);
						
						// The below code doesn't help in closing the dialog box with delay
						//$("#institutionProfile").delay(5000).fadeOut(function(){$("#institutionProfile").close()});
						//$("#institutionProfile").dialog({hide: 'slide'});
						
						// Call the 'CloseDialog' method with delay
						setTimeout(closeDialog, 1000);
						
					}else{
						
						$('div.instituteMsgBox').removeClass('success');
						$('div.instituteMsgBox').addClass('error');
						$('div.instituteMsgBox').fadeOut(10000);
					}
					$('div.instituteMsgBox').fadeOut(5500);
					
				}
			});
		}

		/**
		* Closes the Dialog Box with some time delay
		*/
		function closeDialog(){
			$("#institutionProfile").dialog("close");
		}
	
	</script>

<div id="institutionFormContainer">
	
	<form action="<?php echo base_url()?>kols/save_institution"  method="post" id="institutionForm" name="institutionForm" class="validateForm form-horizontal">
		<div class="msgBoxContainer"><div class="instituteMsgBox"></div></div>
		<p>
			<label for="instituteName">Name:<span class="required">*</span></label>
			<input type="text" name="name" value="<?php echo $name;?>" id="instituteName" class="form-control"/>
		</p>
			
		<p>
			<label for="instituteNotes">Notes:</label>
			<textarea name="notes" class="textArea form-control" id="instituteNotes"></textarea>
		</p>
		
		<div class="formButtons">
			<input type="button" class="btn btn-primary submit-btn" value="Add Institution" name="submit"  onclick=saveInstitute();>
		</div>
	</form>				
</div>				