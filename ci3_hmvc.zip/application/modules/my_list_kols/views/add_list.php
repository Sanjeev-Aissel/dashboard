<script type="text/javascript">
var dvjQuery = null;
var private1 = null;
	var validationRules	=  {
			category_id: {
				required:true
			},
			list_name_id:{
				required:true
				},
			category:{
				required: true,
				alphaNumeric:true
			},
			list_name:{
				required: true,
				alphaNumeric:true
			}
	};

		var validationMessages = {
				category_id: {
				required: "Required",
				remote: ""
			},
			list_name_id:{
				required: "Required"
			},
			category:{
				required: "Required"
				},
			list_name:{
					required: "Required"
				}
			
		};
	$(document).ready(function(){
		dvjQuery = $('.catType1').detach();
		$("#dvParent").html(dvjQuery);
		$("#saveListKolsForm").validate({
			debug:true,
			rules: validationRules,
			messages: validationMessages
		});
		$.validator.addMethod("alphaNumeric", function(value, element) {
	        return this.optional(element) || /^[a-z0-9\- ]+$/i.test(value);
	    }, "Letters, numbers and dashes are allowed.");
	});

	function validateListForm(){
		if(!$("#saveListKolsForm").validate().form()){
			return false;
		}else
			return true;
	}
	$("#saveKolList").click(function(){
		if(!$("#saveListKolsForm").validate().form()){
			return false;
		}
		var kols=$("#kolId").val();
		if(kols!=0){
			$(' div.categoryMsgBox').removeClass('success');
			$(' div.categoryMsgBox').addClass('notice');
			$(' div.categoryMsgBox').show();
			$('div.categoryMsgBox').html('Saving the data... <img src="<?php echo base_url()?>assets/images/ajax_loader_black.gif" />');
			$('div.categoryMsgBox').css({color:"black"});
			$.ajax({
				url:'<?php echo base_url()?>my_list_kols/my_list_kols/save_list_kols',
				data:$('#saveListKolsForm').serialize(),
				type:'post',
				dataType:'json',
				success:function(returnData){
						if(returnData.cat_saved==true){
							if(returnData.list_saved==false)
								$('div.categoryMsgBox').text(returnData.msg1);
							else
							$('div.categoryMsgBox').text(returnData.msg);
						}else if(returnData.cat_saved==false){
							$('div.categoryMsgBox').text(returnData.msg);
						}else{
							$('div.categoryMsgBox').text(returnData.msg1);
						}
						if((returnData.cat_saved==true) && (returnData.list_saved==true )){
							$('div.categoryMsgBox').removeClass('error');
							$('div.categoryMsgBox').addClass('success');
							setTimeout(closeDialog, 2000);
						}else{
							$('div.categoryMsgBox').addClass('error');
							$('div.categoryMsgBox').removeClass('success');
							$('div.categoryMsgBox').fadeOut(10000);
						}
						var category	= sessionStorage['categoryName'];
						if(category=="kol_create_list"){
							moveFromCurrentStep(5);
						}
					}
			});	
		}
		else{
			$('div.categoryMsgBox').text("No KOLs selected. Please select the KOLs and click on create list.");
			$('div.categoryMsgBox').css({color:'red'});
			setTimeout(closeDialog, 4000);
		}
	});
	function closeDialog(){
		$("#categoryModalBox").dialog("close");
		$("#categoryModalBoxWithinProile").dialog("close");
	}
	function displayField(){
		if($('#categoryId').val()==0){
			$("#list_name_id").html("<option value=''>Select</option><option id='css1' style='color:red' value='0' name='list_name'>Add New List Name</option>");
		}
		if(($('#categoryId').val()!=0) && ($('#categoryId').val()!='Select')){
			var id=$('#categoryId').val();
			//$("#list_name_id").html("<option value='0' id='css2' name='list_name'>Add New List</option>");
			$("#list_name_id").html("");
			var list = document.getElementById('list_name_id');
			//jAlert(list.toSource());
			$('#loadingTopic').show();
			$.ajax({
				url:'<?php echo base_url()?>my_list_kols/my_list_kols/get_list_names/'+id,
				type:'post',
				dataType:'json',
				success: function(responseText){					
					$('#list_name_id').prepend("<option value='' selected='selected'>Select</option>");
						$.each(responseText, function(key, value) {				
								if(value.list_name!='undefined'){
									 $('#list_name_id').append($("<option></option>")
							                    .attr("value",value.id)
							                    .text(value.list_name));		
								}
								if(value.is_public==1){
									$("#isPrivate").removeAttr("checked");
									$("#isPublic").attr({'checked':'checked'});
								}else{
									$("#isPrivate").attr({'checked':'checked'});
								}
							});
						$('#list_name_id').append("<option value='0' id='css2' name='list_name'>Add New List</option>")
				    },
					complete:function(){
						$('#loadingTopic').hide();
					}	
			});
		}
		if($('#categoryId').val()==0 && $('#categoryId').val() !=''){
			$('#input').html('<td><label>Add Category :</label></td><td><input  type="text" name="category" class="form-control required"/></td><td></td>');
		}else{
			$('#input').html('');
		}
	}
	function displayNameField(){
		var value =$('#list_name_id').val(); 
		if(value == 0 && value !=''){
			$('#listInputBoxContaioner').html('<td><label>Add List Name :</label></td><td><input type="text" name="list_name" class="form-control required"/></td><td></td>');
		}else{
			$('#listInputBoxContaioner').html('');
		}
	}
	function toggleCategory(thisObj){
		var is_public	= thisObj.value;
		if(is_public==1){
			private1 = $('.catType0').detach();
			$('#categoryId').append(dvjQuery);
		}else{
			$(".catType1").detach();
			$('#categoryId').append(private1);
		}
	}
</script>
		<div class="categoryMsgBox"></div><div class="errorBox"></div>
		<form action="<?php echo base_url();?>my_list_kols/my_list_kols/save_list_kols" method="post" id="saveListKolsForm" name="saveKolsForm" class="validateForm" onsubmit="return validateListForm();">
		<input  type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKols?>"/>
		<?php if($this->session->userdata('role_type')==ROLE_MANAGER){?>
			<label>Private</label>
			<input type="radio" name="is_public" id="isPrivate" value="0" checked="checked" onclick="toggleCategory(this);">
			<label>Public</label>
			<input type="radio" name="is_public" id="isPublic" value="1"  class="required" onclick="toggleCategory(this);">
		<?php }?>	
		<table class="anaylystForm table addList">
			<tr>
				<td>
					<label for="clientName">Categories :<span class="required">*</span></label>
				</td>
				<td>
					<select name="category_id" id="categoryId" onchange="displayField();" class="form-control required">
						<option value="">Select</option>
						<option value="0" id="catCss">Add New Category </option>
						<?php foreach($arrCetgory as $row){?>							
						<option class="catType<?php echo $row['is_public'];?>" value="<?php echo $row['id']?>"><?php echo $row['category']?></option>
						<?php }?>
					</select>
				</td>
				<td></td>
			</tr>
			<tr id="input">
			</tr>
			<tr>
				<td>
					<label for="clientNotes">List Names :<span class="required">*</span></label>
				</td>
				<td>
					<select name="list_name_id"  id="list_name_id" onchange="displayNameField()" class="form-control required">
					<option value="">Select</option>
					<option value="0" id="listNameCss">Add New List Name</option>
					</select>	
				</td>
				<td>
					<img id="loadingTopic" src="<?php echo base_url()?>assets/images/ajax_loader_black.gif" style="display:none"/>
				</td>
			</tr>
			 <tr id="listInputBoxContaioner">
	         </tr>
			<tr>
				<td colspan="3">
					<div class="formButtons"">
						<input type="button" class="btn btn-default" value="Save"  id="saveKolList" name="saveKolList">
			         </div>
		         </td>
	         </tr>	        
         </table>
	</form>