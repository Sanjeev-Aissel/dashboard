<?php
/**
 * @Author : Sanjeev K
 * @Desc : Controller for kols data manipulation 
 * @Since : KOLM_hmvc 1.0
 * @Package : application.controllers
 * @Created : 11-06-2018
 * @Refactored : 12-06-2018
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Kols extends MX_Controller {
	
	private $loggedUserId = null;
	
	//Constructor
	public function __construct()
	{
		parent::__construct();
		//load models
		$this->load->model('analysts/kol');
		$this->load->model('analysts/organization');
		$this->load->model('analysts/speciality');
		$this->load->model('analysts/json_store');
		$this->load->model('analysts/pubmed');
		$this->load->model('helpers/country_helper');
		$this->load->model('helpers/common_helper');
		
		//variables
		$this->loggedUserId = $this->session->userdata('user_id');
		$this->clientId		=$this->session->userdata('client_id');
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_kols()
	 * @Param  : none
	 * @return : loads list kols view
	 */
	function list_kols(){
		$this->common_helper->checkUsers();
		$analyst_client = $this->session->userdata('analyst_client');
		if(!isset($analyst_client)){
			redirect('clients/analysis_client');
		}
		
		$data['contentPage'] = 'kols/list_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_kols_grid()
	 * @Param  : none
	 * @return : returns kols list to jqgrid
	 */
	function list_kols_grid(){
		ini_set('memory_limit', '-1');
		$page = $_REQUEST['page']; 
		$limit = $_REQUEST['rows']; 
		$sidx = $_REQUEST['sidx']; 
		$sord = $_REQUEST['sord']; 
		if (!$sidx){
			$sidx = 1;
			}
		$filterData = $_REQUEST['filters'];
		$arrFilter = array();
		$arrFilter = json_decode(stripslashes($filterData));
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchGroupOperator = $this->common_helper->search_nested_arrays($arrFilter, $groupOp);
		$searchString = $this->common_helper->search_nested_arrays($arrFilter, $data);
		$searchOper = $this->common_helper->search_nested_arrays($arrFilter, $op);
		$searchField = $this->common_helper->search_nested_arrays($arrFilter, $field);
		$whereResultArray = array();
		foreach ($searchField as $key => $val) {
			$whereResultArray[$val] = $searchString[$key];
		}
		$searchGroupOperator = $searchGroupOperator[0];
		$searchResults = array();
	
		$count = $this->kol->getProcessedKols($limit, $start, true, $sidx, $sord, $whereResultArray);
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
			$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		if ($start < 0)
			$start = 0;
	
		$arrKolDetailResult = array();
		$data = array();
		$arrKolDetail = array();
				
		if ($arrKolDetailResult = $this->kol->getProcessedKols($limit, $start, false, $sidx, $sord, $whereResultArray)) {
			foreach ($arrKolDetailResult->result_array() as $row) {
				$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
				$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
				$row['kol_name'] = $kolName;
				$row['id'] = $row['id'];
				$row['is_imported'] = $row['is_imported'];
				$row['created_by'] = $row['user_full_name'];
				
				if ($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN) {
					if ($row['is_pubmed_processed'] == 0)
						$pubStatusHtml = "No";

					if ($row['is_pubmed_processed'] == 1)
						$pubStatusHtml = "Yes";

					if ($row['is_pubmed_processed'] == 2)
						$pubStatusHtml = "Re crawl";

					$row['pubmed_processed'] = $pubStatusHtml;
				}else {
					$pubStatus = 'No';
					if ($row['is_pubmed_processed'] == 1)
						$pubStatus = 'Yes';
					if ($row['is_pubmed_processed'] == 2)
						$pubStatus = 'Re crawl';
					
					$row['pubmed_processed'] = $pubStatus;
				}
				
				$row['trial_processed'] = ($row['is_clinical_trial_processed'] == 1) ? 'Yes' : 'No';
				$row['organization'] = $row['org_name'];
				$row['action'] = '<a href="'. base_url().'analysts/kols/edit_kol/'.$row['vid'].'" title="Edit"><span class="icon edit glyphicon glyphicon-edit"></span></a> <a onclick="deleteSelectedKols(' . $row['vid'] . ');" href="javascript:void(0)" title="delete"><span class="icon delete glyphicon glyphicon-trash"></span></a>';
				$arrKolDetail[] = $row;
			}

			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrKolDetail;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : add_kol()
	 * @Param  : none
	 * @return : loads add kol's view
	 */
	function add_kol(){
		$this->common_helper->checkUsers();
		$data['arrCountry'] = $this->country_helper->listCountries();
		
		// Get the list of Specialties
		$arrSpecialties = $this->speciality->getAllSpecialties();
		$data['arrSpecialties'] = $arrSpecialties;
		
		$arrSalutations = array(1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		
		$data['contentPage'] = 'kols/add_kol';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_kol()
	 * @Param  : salutation, gender, first_name, middle_name, last_name, suffix, specialty, org_id, is_pubmed_processed, status, npi_num, profile_type, unique_id
	 * @return : insert / modify kol details
	 */
	function save_kol(){
		// Get all the POST data
		$arrKol['salutation'] = $this->input->post('salutation');
		$arrKol['gender'] = $this->input->post('gender');
		$arrKol['first_name'] = ucwords(trim($this->input->post('first_name')));
		$arrKol['middle_name'] = ucwords(trim($this->input->post('middle_name')));
		$arrKol['last_name'] = ucwords(trim($this->input->post('last_name')));
		$arrKol['suffix'] = ucwords(trim($this->input->post('suffix')));
		$arrKol['specialty'] = $this->input->post('specialty');
		$arrKol['org_id'] = $this->input->post('org_id');
		$arrKol['is_pubmed_processed'] = 0;
		$arrKol['created_by'] = $this->loggedUserId;
		$arrKol['created_on'] = date("Y-m-d H:i:s");
		$arrKol['status'] = New1;
		$arrKol['npi_num'] = $this->input->post('npi_num');
		$arrKol['profile_type'] = $this->input->post('profile_type');
		$arrKol['unique_id'] = uniqid();
		//ending post details
		//check_duplicate_kols
		$kolId = $this->kol->saveKol($arrKol);
		if ($kolId) {
			$updateData['id'] = $kolId;
			$updateData['pin'] = $kolId;
			$this->kol->updateKolInfo($updateData);
			$this->session->set_flashdata('message', 'New Kol Saved Sucessfully');
		} else {
			$this->session->set_flashdata('message', 'Kol Could not be Saved! Try again');
		}
		
		redirect('kols/list_kols');
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_kol()
	 * @Param  : none
	 * @return : deletes deleted kol with selected parameters
	 */
	function delete_kol(){
		
	}
	
	
	/**
	 * top bar functionalities starts
	 * @Author : Sanjeev K
	 * @Method : update_status()
	 * @Param  : status, kol id(array)
	 * @return : update status of kol
	 */
	function update_status(){
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');

		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		if($arr['status']==COMPLETED){
			$status = STATUS_COMPLETED;
		}
		
		if($arr['status']==APPROVED){
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
		}
		
		if($arr['status'] == PROFILING)
			$status = STATUS_PROFILING;
		if($arr['status'] == REVIEW)
			$status = STATUS_REVIEW;
		if($arr['status'] == New1)
			$status = STATUS_NEW;
		
		$this->kol->updateStatus($arr);
	}
	
	/**
	 Grid bar functionalities
	 */
	
	/**
	 *  bottom bar functionalities
	 * @Author : Sanjeev K
	 * @Method : calculate_dashboard_data()
	 * @Param  : none
	 * @return : none
	 */
	function calculate_dashboard_data($kolId = null){
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		if ($kolId != null)
			$arrKols = array($kolId => 0);
			else
				$arrKols = $this->kol->getKolsIdAndPin();
	
				foreach ($arrKols as $kolId => $pin){
					$jsonFilter = "kol_id:" . $kolId;
					$this->json_store->deleteFromStore(JSON_STORE_DASHBOARD, $jsonFilter);
					$data = array();
					$data['affByOrgTypeData'] = array();
					$data['affByEngTypeData'] = array();
					$data['eventsTimelineData'] = array();
					$data['eventsByTopicData'] = array();
					$data['pubsByTimeData'] = array();
					$data['pubsAuthPosData'] = array();
						
					//-------------------------Affiliations by Org Type chart----------------------------------
					$arrKolIds[] = $kolId;
					$arrAffiliations = $this->kol->getAffiliationsByParam(0, 0, $arrKolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds = '', $arrSpecialityIds = '', $selectType = 'kol_memberships.type', $arrListNamesIds = '', $arrStatesIds = '');
					$arrOrgCounts = array();
					foreach ($arrAffiliations as $row) {
						$arr = array();
						if ($row['type'] == "university") {
							$arr[] = "University/Hospital";
						} else {
							$arr[] = ucwords($row['type']);
						}
						$arr[] = (int) $row['count'];
						$arrOrgCounts[] = $arr;
					}
					$data['affByOrgTypeData'] = $arrOrgCounts;
						
					//-------------------------Affiliations by Eng Type chart----------------------------------
					$arrAffiliations = array();
					$arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes = '', $arrOrgType, $arrCountriesIds, $arrSpecialityIds, $selectType = 'engagement_types.engagement_type', $arrListNamesIds, $arrStatesIds);
					$arrEngagementCounts = array();
					foreach ($arrAffiliations as $row) {
						$arr = array();
						if ($row['engagement_type'] != '') {
							$arr[] = $row['engagement_type'];
							$arr[] = (int) $row['count'];
							$arrEngagementCounts[] = $arr;
						}
					}
					$data['affByEngTypeData'] = $arrEngagementCounts;
					if($this->common_helper->check_module("events")){
						$this->load->model('events/event');
						//-------------------------Events by timeline chart----------------------------------
						$arrEventsTimelineData = $this->get_event_types_timeline_chart($kolId);
						$data['eventsTimelineData'] = $arrEventsTimelineData;
	
						//-------------------------Events by Topic chart----------------------------------
						$arrEventTopics = array();
						$arrEventsTopic = $this->event->getDataForEventsTopicChart($kolId, 0, 0);
						foreach ($arrEventsTopic as $row) {
							$arrTopic = array();
							$arrTopic[] = $row['name'];
							$arrTopic[] = (int) $row['count'];
							$arrEventTopics[] = $arrTopic;
						}
						$data['eventsByTopicData'] = $arrEventTopics;
					}
					//-------------------------Publications by timeline chart----------------------------------
					if($this->common_helper->check_module("pubmeds")){
						$this->load->model('pubmeds/pubmed');
						$arrPublications = $this->pubmed->getPublicationChart($kolId, 0, 0);
						$pubsByTimeData = array();
						$years = array();
						$count = array();
						foreach ($arrPublications as $publication) {
							$years[] = $publication['year'];
							$count[] = (int) $publication['count'];
						}
						$pubsByTimeData[] = array_reverse($years);
						$pubsByTimeData[] = array_reverse($count);
						$data['pubsByTimeData'] = $pubsByTimeData;
							
						//-------------------------Publicatons authorship position chart----------------------------------
						$arrSingleAuthPubs = $this->pubmed->getKolPubsWithSingleAuthor($kolId, 0, 0);
						$arrFirstAuthPubs = $this->pubmed->getKolPubsWithFirstAuthorship($kolId, 0, 0);
						$arrLastAuthPubs = $this->pubmed->getKolPubsWithLastAuthorship($kolId, 0, 0);
						$arrMiddleAuthPubs = $this->pubmed->getKolPubsWithMiddleAuthorship($kolId, 0, 0);
	
						$arrSingleAuthPubsCount = sizeof($arrSingleAuthPubs);
						$arrFirstAuthPubsCount = sizeof($arrFirstAuthPubs);
						$arrLastAuthPubsCount = 0;
						$arrMiddleAuthPubsCount = 0;
	
						foreach ($arrLastAuthPubs as $lastAuthPub) {
							if ($lastAuthPub['auth_pos'] == $lastAuthPub['max_pos'] && $lastAuthPub['max_pos'] != 1)
								$arrLastAuthPubsCount++;
						}
	
						foreach ($arrMiddleAuthPubs as $middleAuthPub) {
							if ($middleAuthPub['auth_pos'] != $middleAuthPub['max_pos'])
								$arrMiddleAuthPubsCount++;
						}
						$arrSectors = array(
								array("First Authorship", (int) $arrFirstAuthPubsCount),
								array("Single Authorship", (int) $arrSingleAuthPubsCount),
								array("Middle Authorship", (int) $arrMiddleAuthPubsCount),
								array("Last Authorship", (int) $arrLastAuthPubsCount),
						);
						$arrSectorsData = array();
						foreach ($arrSectors as $sector) {
							if ($sector[1] != 0)
								$arrSectorsData[] = $sector;
						}
						$data['pubsAuthPosData'] = $arrSectorsData;
					}
					//-------------------------Influence Map data calculation----------------------------------
					$arrFilterFields = array();
					$name = '';
					$arrPubDegrees = array('edu', 'org', 'aff', 'event', 'pub', 'trial');
					$kolName = $this->kol->getKolName($kolId);
					$arrKolIds = array();
					$arrKeywords[0] = $name;
					$arrKolDetailResult = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, 0, 0, false, false, null, $arrKolIds, true);
						
					$arrKolDetails = array();
					foreach ($arrKolDetailResult as $row) {
						$details = array();
						$details['first_name'] = $row['first_name'];
						$details['last_name'] = $row['last_name'];
	
						$arrKolDetails[$row['id']] = $details;
					}
					//pr($arrKolDetails);exit;
					$arrData = array();
					$arrPubKols = array();
					$arrEventKols = array();
					$arrAffKols = array();
					$arrEduKols = array();
					$arrOrgKols = array();
					$arrTrialKols = array();
						
					if (in_array('pub', $arrPubDegrees))
						$arrPubKols = $this->pubmed->getCoAuthoredKols($kolId);
						if (in_array('event', $arrPubDegrees))
							$arrEventKols = $this->kol->getCoEventedKols($kolId);
							if (in_array('aff', $arrPubDegrees))
								$arrAffKols = $this->kol->getCoAffiliatedKols($kolId);
								if (in_array('edu', $arrPubDegrees))
									$arrEduKols = $this->kol->getCoEducatedKols($kolId, $arrFilterFields);
									if (in_array('org', $arrPubDegrees))
										$arrOrgKols = $this->kol->getCoOrganizedKols($kolId, $arrFilterFields);
										if (in_array('trial', $arrPubDegrees)){
											if($this->common_helper->check_module("clinical_trials")){
												$this->load->model('clinical_trials/clinical_trial');
												$arrTrialKols = $this->clinical_trial->getCoTrialledKols($kolId, $arrFilterFields);
											}
										}
										$arrKols = $this->get_unique_kolids_with_weightages($arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols);
										if (sizeof($arrKols) > 0) {
											$arrData = $arrKols;
										}
											
										//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
										$nodeData = array();
										$nodeData['$lineWidth'] = 5;
										$nodeData['$color'] = "#ddeeff";
										$nodeData['$dim'] = 0;
										$influenceData = array();
										$centerNode = array();
										$influenceData['id'] = 'kol-' . $kolId;
										$influenceData['name'] = $kolName['first_name'] . " " . $kolName['middle_name'] . " " . $kolName['last_name'];
										$influenceData['data'] = $nodeData;
										$influenceData['children'] = array();
										foreach ($arrData as $key => $value) {
											//echo "KolId : ".$key."<br>";
											$nodeData = array();
											$nodeData['$color'] = "#555555";
											$nodeData['connections'] = $value['count'];
											$nodeDetails = array();
											$nodeDetails['id'] = $key;
											$nodeDetails['name'] = $arrKolDetails[$key]['first_name'] . " " . $arrKolDetails[$key]['last_name'];
											$nodeDetails['data'] = $nodeData;
											$arrAdjecencies = array();
											$nodeDetails['children'] = $arrAdjecencies;
											$influenceData['children'][] = $nodeDetails;
										}
										$retunData['connectionData'] = $influenceData;
										$retunData['coAuthorsKOLIds'] = array();
										$data['influenceData'] = $retunData;
										if (sizeof($influenceData['children']) > 0)
											$sampleName = $influenceData['children'][0]['name'];
											else
												$sampleName = 'NA';
												if ($sampleName != '') {
													$rowData['json_data'] = json_encode($data);
													$rowData['ref_id'] = JSON_STORE_DASHBOARD;
													$rowData['filter'] = "kol_id:" . $kolId;
													$this->json_store->insertJsonToStore($rowData);
													echo "Id :" . $kolId . '<br>';
												} else {
													echo $kolId . '<br>';
												}
				}
				echo "Calculation Complete.";
				$filePath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "system/logs/jobs/cron_job_status.txt";
				$content = "dashboard_data_cron.php :: " . date("Y-m-d H:i:s") . "::success :: no comments \r\n";
				//Log Activity
				$arrLogDetails = array(
						'type'=>CRON_JOBS,
						'description'=>"Calculation Complete",
						'status' => STATUS_SUCCESS,
						'transaction_table_id'=>'',
						'transaction_name'=>'calculate dashboard data',
						'miscellaneous1'=>$url
				);
				$this->config->set_item('log_details', $arrLogDetails);
				file_put_contents($filePath, $content, FILE_APPEND | LOCK_EX);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_event_types_timeline_chart()
	 * @Param  : $kolId
	 * @return : $arrData
	 */
	function get_event_types_timeline_chart($kolId) {
		$arrKolIds = array();
		$arrKolIds[] = $kolId;
		$congressData = array();
		$conferenceData = array();
		$grData = array();
		$amData = array();
		$cmeData = array();
		$webcastData = array();
		$webinarData = array();
		$podcastData = array();
		$arrEventTypeDetails = $this->kol->getEventTypesCountByTimeLine(0, 0, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds);
	
		//get unique years
		$arrUniqueYears = $this->get_unique_years($arrEventTypeDetails);
		$arrEventTypeCount = array();
		$arrEventTypes = array();
		$arrEventTypesData = array();
		$arrUniqueYear = array();
		foreach ($arrEventTypeDetails as $eventTypeDetail) {
			$arrEventTypeCount[$eventTypeDetail['year']][$eventTypeDetail['event_type']] += (int) $eventTypeDetail['count'];
			//$arrEventTypeCount[$eventTypeDetail['event_type']][$eventTypeDetail['year']] += (int)$eventTypeDetail['count'];
			$arrEventTypes[$eventTypeDetail['event_type']] = 1;
		}
		ksort($arrEventTypeCount);
		foreach ($arrEventTypeCount as $year => $arrRow) {
			$arrUniqueYear[] = (string) $year;
			foreach ($arrEventTypes as $eventType => $value) {
				if (isset($arrRow[$eventType])) {
					$arrEventTypesData[$eventType][] = $arrRow[$eventType];
				} else {
					$arrEventTypesData[$eventType][] = 0;
				}
			}
		}
		$arrTypesData = array();
		$arrData[] = array_values($arrUniqueYear);
		foreach ($arrEventTypes as $eventType => $value) {
			$arrTypesData[] = array('name' => $eventType, 'data' => $arrEventTypesData[$eventType]);
		}
		$arrData[] = $arrTypesData;
		return $arrData;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_unique_years()
	 * @Param  : $arrEventTypeDetails
	 * @return : $arrUniqueYears
	 */
	function get_unique_years($arrEventTypeDetails) {
		$arrYears = array();
		foreach ($arrEventTypeDetails as $eventTypeDetail) {
			$arrYears[] = $eventTypeDetail['year'];
		}
		$arrUniqueYears = array_unique($arrYears);
		sort($arrUniqueYears);
		return $arrUniqueYears;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_unique_kolids_with_weightages()
	 * @Param  : $arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols
	 * @return : $arrKols
	 */
	function get_unique_kolids_with_weightages($arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols) {
		$arrKols = array();
		if (sizeof($arrPubKols) > 0) {
			foreach ($arrPubKols as $row) {
				$arrKols[$row['kol_id']] = $row;
			}
		}
	
		if (sizeof($arrEventKols) > 0) {
			foreach ($arrEventKols as $row) {
				if (array_key_exists($row['kol_id'], $arrKols)) {
					$arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
				} else {
					$arrKols[$row['kol_id']] = $row;
				}
			}
		}
	
		if (sizeof($arrAffKols) > 0) {
			foreach ($arrAffKols as $row) {
				if (array_key_exists($row['kol_id'], $arrKols)) {
					$arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
				} else {
					$arrKols[$row['kol_id']] = $row;
				}
			}
		}
		if (sizeof($arrOrgKols) > 0) {
			foreach ($arrOrgKols as $row) {
				if (array_key_exists($row['kol_id'], $arrKols)) {
					$arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
				} else {
					$arrKols[$row['kol_id']] = $row;
				}
			}
		}
		if (sizeof($arrEduKols) > 0) {
			foreach ($arrEduKols as $row) {
				if (array_key_exists($row['kol_id'], $arrKols)) {
					$arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
				} else {
					$arrKols[$row['kol_id']] = $row;
				}
			}
		}
		if (sizeof($arrTrialKols) > 0) {
			foreach ($arrTrialKols as $row) {
				if (array_key_exists($row['kol_id'], $arrKols)) {
					$arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
				} else {
					$arrKols[$row['kol_id']] = $row;
				}
			}
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : add_events_to_affiliations()
	 * @Param  : $kolId, $eventId
	 * @return : none
	 */
	function add_events_to_affiliations($kolId = '',$eventId=''){
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$this->db->where("sponsor_type",2);
		//		$this->db->where("role","Speaker");
		if($kolId != '')
			$this->db->where("kol_id",$kolId);
			if($eventId != '')
				$this->db->where("id",$eventId);
				$arr = $this->db->get("kol_events");
				$arrData = array();
				//		echo $this->db->last_query();
				//		exit;
				foreach ($arr->result_array() as $row){
					//			pr($row);
					//			continue;
					if (strpos($row["start"], '/') !== FALSE){
						$start = $this->getYear($row["start"]);
					}else{
						$start = $this->common_helper->getOnlyYearByDate($row["start"]);
					}
					if (strpos($row["end"], '/') !== FALSE){
						$end = $this->getYear($row["end"]);
					}else{
						$end = $this->common_helper->getOnlyYearByDate($row["end"]);
					}
					$where = array();
					$where["kol_id"] = $row['kol_id'];
					$where["organizer"] = $row['session_sponsor'];
					$where["start"] = $start;
					$where["end"] = $end;
					$row['start'] = $start;
					$row['end'] = $end;
					$arrMembershipResult = $this->kol->getAllAffiliationsTypeIndustry('industry',$where);
					//			echo var_dump($arrMembershipResult);
					 
					if(!$arrMembershipResult){
						//				$arrData[] = $row;
						$arrAffData = array();
						//                         $row["session_sponsor"] = mysqli_real_escape_string($row["session_sponsor"]);
						$orgName["name"] = $row["session_sponsor"];
						$instiId 						= $this->kol->getInstituteIdElseSave($orgName);
						$arrAffData["kol_id"] 			= $row["kol_id"];
						$arrAffData["engagement_id"] 	= 17;
						$arrAffData["type"] 			= "industry";
						$arrAffData["institute_id"] 	= $instiId;
						$arrAffData["start_date"] 		= $row["start"];
						$arrAffData["end_date"] 		= $row["end"];
						$arrAffData["role"] 			= "Speaker";
						$arrAffData["created_by"] 		= $this->loggedUserId;
						$arrAffData["created_on"] 		= date("Y-m-d H:i:s");
						$arrAffData["data_type_indicator"] 		= $dataType;
						$arrAffData["client_id"] 		= $this->session->userdata('client_id');
						$arrAffData["added_from"] 		= 1;
						$arrAffData["source_row_id"] 	= $row["id"];
						$this->db->insert('kol_memberships',$arrAffData);
						//                         echo $this->db->last_query();
						//                         				pr($arrAffData);
						//                         				exit;
					}
				}
				return true;
	
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : updateKolLatLong()
	 * @Param  : none
	 * @return : none
	 */
	function updateKolLatLong(){
		//ini_set('display_errors',1);
		//error_reporting(E_ALL);
		$nameFormatOrder = $this->common_helper->get_name_format_order_simple('kols');
		$this->db->select('kol_locations.id,cities.City as city_name,states.name as state_name,countries.Country as country_name,kol_locations.postal_code,kol_locations.address1 as address_line_1,kol_locations.kol_id,concat('.$nameFormatOrder.') as kolFullName',false);
		$this->db->join('cities','cities.CityId = kol_locations.city_id','left');
		$this->db->join('states','states.id = kol_locations.state_id','left');
		$this->db->join('countries','countries.CountryId = kol_locations.country_id','left');
		$this->db->join('kols','kols.id = kol_locations.kol_id','left');
		// $this->db->where('kol_locations.is_primary',1);
		$this->db->where('processed_latlong',0);
		$this->db->where('concat('.$nameFormatOrder.')!=','');
		$resultSet    = $this->db->get('kol_locations');
		//      pr($this->db->last_query());exit;
		$count = 0;
		$loggedInUserName = $this->session->userdata('user_full_name');
		$messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/>';
		$messageBody .= "<table border='1'><tr><th>KOL Id</th><th>KOL Name</th><th>Postal Code</th><th>Address Line 1</th><th>City</th><th>State</th><th>Country</th></tr>";
		foreach($resultSet->result_array() as $row){
			$id = $row['id'];
			$address    =   $row['state_name'].' '.$row['country_name'];
			if(!(empty($row['address_line_1']))){
				$address    = $row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name'];
			}else if(!empty($row['postal_code'])){
				$address    = $row['postal_code'].' '.$row['state_name'].' '.$row['country_name'];
			}else if(!empty($row['city_name'])){
				$address    = $row['postal_code'].' '.$row['state_name'].' '.$row['country_name'];
			}
			// if(!(empty($row['address_line_1']) && empty($row['city_name']))){
			// $jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state'].' '.$row['country']).'&sensor=false');
			$jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyA9FjXX_skXFSbOZDPpFLBhMLHNW7ZIho8&address='.urlencode($address).'&sensor=false');
			//                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCd6S5yKz2qKTu4Qt03hjOg5jr_A9Dn6xc&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
			///                 $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCmnoL_uL1lLEIbFQ6P3rXXn5mmpAXNiPk&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
			//                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCLYXBSf24qrsH4PMEb61BXDVx6EhVtItk&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
			//                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBGv3HIWyQhQIyz_07ucMWkPgyrdAFB0pM&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
			//                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUo0dQ6rEoAfb-Dcd219qTdkgv3sOixqE&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
			$jsondata = json_decode($jsondata, true);
			if ($jsondata['status'] = 'OK') {
	
				$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
				$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
				if($lat != '' || $lon != ''){
					$updateLatLong = $this->db->query("UPDATE `kol_locations` SET `latitude` = $lat,`longitude` = $lon,`processed_latlong` =1 WHERE id = $id");
				}else{
					$messageBody .= "<tr><td>".$row['kol_id']."</td><td>".$row['kolFullName']."</td><td>".$row['postal_code']."</td><td>".$row['address_line_1']."</td><td>".$row['city_name']."</td><td>".$row['state_name']."</td><td>".$row['country_name']."</td></tr>";
					$count++;
				}
				//  }
			}
		}
		$messageBody .=  "</table>";
	
		if($count > 0){
			$config['protocol'] = PROTOCOL;
			$config['smtp_host'] = HOST;
			$config['smtp_port'] = PORT;
			$config['smtp_user'] = USER;
			$config['smtp_pass'] = PASS;
			$config['mailtype'] = 'html';
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->initialize($config);
			$this->email->clear();
			$this->email->set_newline("\r\n");
			$this->email->from(USER, SENDER);
			$loggedInUserEmail = $this->session->userdata('email');
			$loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
			$loggedInUserEmail = $this->session->userdata('email');
			$this->email->to($loggedInUserEmail);
			$this->email->message($messageBody);
			$this->email->subject(PRODUCT_NAME.': Missing Latitude and Longitude List');
			$this->email->set_crlf("\r\n");
			echo "Missing Latitude and Longitude for ".$count." KOLs<br/>";
			if ($this->email->send()) {
				echo "A email of the details has been sent to you.";
			} else {
				echo "Email could not be sent about the details";
			}
		}
	}
	
	/**
	 * Process Profile Score
	 * @Author : Sanjeev K
	 * @Method : caluculateAndInsertActivitesCount()
	 * @Param  : $kolIds
	 * @return : none
	 */
	function caluculateAndInsertActivitesCount($kolIds=null){
		//$kolIds =array(1,2,3,4,5);
		$kolIds = $this->input->post('sel');
		if($kolIds!=null){
			$this->db->where_in('kol_id',$kolIds);
			$this->db->delete('kol_activities_count');
		}else{
			$this->db->query("delete from kol_activities_count");
		}
		$this->db->select('id');
		$this->db->where_not_in('id',0);
		$this->db->where('status',COMPLETED);
		if($kolIds!=null){
			$this->db->where_in('id',$kolIds);
		}
		$arrKolidsResult = $this->db->get('kols');
	
		//$arrKolidsResult =$this->db->query("select id from kols where id!=0 and status='Completed'");
	
		foreach($arrKolidsResult->result_array() as $row){
				
			$arrKols[]=$row['id'];
		}
		$arrActvites=array();
		foreach($arrKols as $id){
			//Aff Count
			$affCountResultSet=$this->db->query("select count(*) as count from kol_memberships where kol_id=$id");
			//echo $this->db->last_query();
			$affCount='';
			foreach($affCountResultSet->result() as $affCountRow){
				$affCount=$affCountRow->count;
			}
				
			$arrActvites[$id]['affCount']=$affCount;
				
			//Event Count
			$eventsCountResultSet=$this->db->query("select count(*) as count from kol_events where kol_id=$id");
			$eventCount='';
			foreach($eventsCountResultSet->result() as $eveCountRow){
				$eventsCount=$eveCountRow->count;
			}
			$arrActvites[$id]['eventsCount']=$eventsCount;
				
			//Pubs Count
			$pubsCountResultSet=$this->db->query("select count(*) as count from kol_publications where kol_id=$id and kol_publications.is_verified=1 and kol_publications.is_deleted=0");
			$pubsCount='';
			foreach($pubsCountResultSet->result() as $pubCountRow){
				$pubsCount=$pubCountRow->count;
			}
			$arrActvites[$id]['pubsCount']=$pubsCount;
				
			//trialsCount
			$trialCountResultSet=$this->db->query("select count(*) as count from kol_clinical_trials where kol_id=$id");
			$trialCount='';
			foreach($trialCountResultSet->result() as $trailCountRow){
				$trialCount=$trailCountRow->count;
			}
			$arrActvites[$id]['trialCount']=$trialCount;
				
			//PracstiseCount
			$practsiseResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					left join engagement_types on kol_memberships.engagement_id=engagement_types.id
					where kol_memberships.type='university' and engagement_types.engagement_type='Clinical Practice' and kol_id=$id
					");
			$practiseCount ='';
			foreach($practsiseResultSet->result() as $practiseCountRow){
				$practiseCount=$practiseCountRow->count;
			}
			$arrActvites[$id]['practiseCount']=$practiseCount;
				
			//TeachingCount
			$teachingResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					left join engagement_types on kol_memberships.engagement_id=engagement_types.id
					where kol_memberships.type='university' and engagement_types.engagement_type='Teaching' and kol_id=$id
					");
			$teachingCount ='';
			foreach($teachingResultSet->result() as $teachingCountRow){
				$teachingCount=$teachingCountRow->count;
			}
			$arrActvites[$id]['teachingCount']=$teachingCount;
				
			///Society Exec Committee
			$socialComitteResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					left join engagement_types on kol_memberships.engagement_id=engagement_types.id
					where kol_memberships.type='association' and engagement_types.engagement_type='Leadership' and kol_id=$id
					");
			$socialComitteCount ='';
			foreach($socialComitteResultSet->result() as $socialComitteRow){
				$socialComitteCount=$socialComitteRow->count;
			}
			$arrActvites[$id]['socialComitteCount']=$socialComitteCount;
				
			//Society Board Memberships
			$socialBoardResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					left join engagement_types on kol_memberships.engagement_id=engagement_types.id
					where kol_memberships.type='association' and engagement_types.engagement_type='Board of Director' and kol_id=$id
					");
			$socialBoardCount ='';
			foreach($socialBoardResultSet->result() as $socialBoardRow){
				$socialBoardCount=$socialBoardRow->count;
			}
			$arrActvites[$id]['socialBoardCount']=$socialBoardCount;
				
			//Guidelines
			$guidelinesResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					left join engagement_types on kol_memberships.engagement_id=engagement_types.id
					where engagement_types.engagement_type='Guideline' and kol_id=$id
					");
			$guidelineCount ='';
			foreach($guidelinesResultSet->result() as $guidelineRow){
				$guidelineCount=$guidelineRow->count;
			}
			$arrActvites[$id]['guidelineCount']=$guidelineCount;
				
			//Government Agency Affiliations
			$governmentResultSet = $this->db->query("select count(*) as count
					from kol_memberships
					where type='government' and kol_id=$id
					");
			$governmentCount ='';
			foreach($governmentResultSet->result() as $governmentRow){
				$governmentCount=$governmentRow->count;
			}
			$arrActvites[$id]['governmentCount']=$governmentCount;
				
				
			//Executive Committee
			$executiveResultSet = $this->db->query("select count(*) as count
					from kol_events
					where kol_id =$id and (role='President' OR role='Vice President' OR role='Chair' OR role='Co-chair' or  role='Director')
					");
			$executiveCount ='';
			foreach($executiveResultSet->result() as $executiveRow){
				$executiveCount=$executiveRow->count;
			}
			$arrActvites[$id]['executiveCount']=$executiveCount;
				
			//Speaking Engagements
			$speakingResultSet = $this->db->query("select count(*) as count
					from kol_events
					where kol_id =$id and (role='Speaker' OR role='Keynote Speaker')
					");
			$speakingCount ='';
			foreach($speakingResultSet->result() as $speakingRow){
				$speakingCount=$speakingRow->count;
			}
			$arrActvites[$id]['speakingCount']=$speakingCount;
				
			//Faculty at Events
			$facultyResultSet = $this->db->query("select count(*) as count
					from kol_events
					where kol_id =$id and (role='Faculty')
					");
			$facultyCount ='';
			foreach($facultyResultSet->result() as $facultyRow){
				$facultyCount=$facultyRow->count;
			}
			$arrActvites[$id]['facultyCount']=$facultyCount;
				
			//Panelist at Events
			$panelistResultSet = $this->db->query("select count(*) as count
					from kol_events
					where kol_id =$id and (role='Panelist' or role='Moderator' or role='Coordinator')
					");
			$panelistCount ='';
			foreach($panelistResultSet->result() as $panelistRow){
				$panelistCount=$panelistRow->count;
			}
			$arrActvites[$id]['panelistCount']=$panelistCount;
				
	
	
			$yearRange				=	$arrYears=$this->pubmed->getKolPubsYearsRange($id);
	
			$arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($id,$yearRange['min_year'],$yearRange['max_year']);
			$arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($id,$yearRange['min_year'],$yearRange['max_year']);
			$arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($id,$yearRange['min_year'],$yearRange['max_year']);
			//	$arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($id,'','');
	
			$arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
			$arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
			$arrLastAuthPubsCount		=	0;
			$arrMiddleAuthPubsCount		=	0;
	
			foreach($arrLastAuthPubs as $lastAuthPub){
				if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
					$arrLastAuthPubsCount++;
			}
	
			$aurhPoscount = array((int)$arrFirstAuthPubsCount,(int)$arrSingleAuthPubsCount,(int)$arrLastAuthPubsCount);
	
			$arrSum=array_sum($aurhPoscount);
	
			$arrActvites[$id]['authPosCount']=$arrSum;
	
		}
	
		//Count of Professonal Experience
		//Get the count of Practise
	
	
		foreach($arrActvites as $id=>$value){
			$arrActvites[$id]['totalScore']=array_sum($value);
		}
	
		foreach($arrActvites as $id=>$value){
			$arrActvites[$id]['totalAllScore']=$value['authPosCount']+$value['panelistCount']+$value['facultyCount']+$value['speakingCount']+$value['executiveCount']+$value['governmentCount']+$value['guidelineCount']+$value['socialBoardCount']+$value['socialComitteCount']+$value['teachingCount']+$value['practiseCount']+$value['trialCount'];
			$arrActvites[$id]['totalProfessionalCount'] = $value['practiseCount']+$value['teachingCount']+$value['socialComitteCount']+$value['socialBoardCount']+$value['guidelineCount']+$value['governmentCount'];
			$arrActvites[$id]['totalEvents'] = $value['panelistCount']+$value['facultyCount']+$value['speakingCount']+$value['executiveCount'];
			$arrActvites[$id]['totalResearch'] = $value['authPosCount']+$value['trialCount'];
		}
		$bulkInsert='';
		$seperator	= '';
		foreach($arrActvites as $kolId=>$value){
				
			$bulkInsert	.= $seperator;
			$bulkInsert	.= "($kolId,".$value['affCount'].",".$value['pubsCount'].",".$value['eventsCount'].",".$value['trialCount'].",".$value['totalScore'].",".$value['authPosCount'].",".$value['panelistCount'].",".$value['facultyCount'].",".$value['speakingCount'].",".$value['executiveCount'].",".$value['governmentCount'].",".$value['guidelineCount'].",".$value['socialBoardCount'].",".$value['socialComitteCount'].",".$value['teachingCount'].",".$value['practiseCount'].",".$value['totalAllScore'].",".$value['totalProfessionalCount'].",".$value['totalEvents'].",".$value['totalResearch'].")";
			$seperator	= ',';
		}
	
		if($this->db->query("insert into kol_activities_count(`kol_id`,`affCount`,`pubsCount`,`eventsCount`,`trialCount`,`totalScore`,`authPosCount`,`panelistCount`,`facultyCount`,`speakingCount`,`executiveCount`,`governmentCount`,`guidelineCount`,`socialBoardCount`,`socialComitteCount`,`teachingCount`,`practiseCount`,`totalAllScore`,`totalProfessionalCount`,`totalEvents`,`totalResearch`) values $bulkInsert")){
				
			if($kolIds!=null){
				$data['status'] = true;
				echo json_encode($data);
					
			}else{
				echo COMPLETED;
			}
				
			$this->db->select('kol_id');
			$arrKolsResultset = $this->db->get('kol_activities_count');
			foreach($arrKolsResultset->result_array() as $kolId1){
	
				$kolTotalActivitiesCount 	= $this->kol_rating->getKolTotalActivityCount1($kolId1['kol_id']);
				//echo $kolTotalActivitiesCount;
					
				$spcilatyId  = $this->kol_rating->gerSpecilatyIdByKol($kolId1['kol_id']);
					
				$maxCount = $this->kol_rating->getMaxTotalCountOfKolBySpecialty($spcilatyId);
				$pforfileScore['profileScore']	=($kolTotalActivitiesCount/$maxCount)*100;
				$this->db->where('kol_activities_count.kol_id',$kolId1['kol_id']);
				$this->db->update('kol_activities_count',$pforfileScore);
					
			}
			//$maxCountOfAllIndividualParam = $this->kol_rating->getMaxCountBySpecialty($spcilatyId);
			//$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
	
		}else{
			if($kolIds!=null){
				$data['status'] = true;
				echo json_encode($data);
			}else{
				echo "Not completed";
			}
				
		}
		if($kolIds == null){
			$filePath=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."system/logs/jobs/cron_job_status.txt";
			$content = "profile_score_data_cron.php :: ".date("Y-m-d H:i:s")."::success :: no comments\r\n";
			echo $content;
			file_put_contents($filePath,$content, FILE_APPEND | LOCK_EX);
		}
		$content = "profile_score_data_cron.php :: ".date("Y-m-d H:i:s")."::success :: no comments\r\n";
		echo $content;
	}
	
	
	/**
	 End of bottom bar functionalities
	 */
	
	/**
	 * Edit option functionalities starts
	 * Overview Tab
	 * @Author : Sanjeev K
	 * @Method : edit_kol()
	 * @Param  : Kol Visibility Id (vid)
	 * @return : loads add kol's edit view
	 */
	function edit_kol($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		if (!$kolId) {
			$this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
			redirect('kols/list_kols');
		}
		// Getting the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		// If there is no record in the database
		if (!$arrKolDetail) {
			$this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
			redirect('kols/list_kols');
		}
		// Set the KOL ID into the Session
		$this->session->set_userdata('kolId', $kolId);
		$arrKolDetail['org_id'] = $this->kol->getOrgId($arrKolDetail['org_id']);
		$data['arrKol'] = $arrKolDetail;
		$data['kolId'] = $kolId;
		$data['arrCountry'] = $this->country_helper->listCountries();
		$arrStates = array();
		$arrCities = array();
		if ($arrKolDetail['country_id'] != 0) {
			$arrStates = $this->country_helper->getStatesByCountryId($arrKolDetail['country_id']);
		}
		if ($arrKolDetail['state_id'] != 0) {
			$arrCities = $this->country_helper->getCitiesByStateId($arrKolDetail['state_id']);
		}
		$data['arrStates'] = $arrStates;
		$data['arrCities'] = $arrCities;
		// Get the list of Specialties
		$arrSpecialties = $this->speciality->getAllSpecialties();
		$data['arrSpecialties'] = $arrSpecialties;
		$arrSalutations = array(1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		$data['arrContactDetails'] = array();
		$arrContactDetails = array();
		if ($arrContactDetails = $this->kol->listContacts($kolId)) {
			$data[] = $arrContactDetails;
		}
		$data['latitude'] = $arrKolDetail['latitude'];
		$data['longitude'] = $arrKolDetail['longitude'];
		$data['contentPage'] = 'kols/edit_kol';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : reset_profile_image()
	 * @Param  : none
	 * @return : boolean value
	 */
	function reset_profile_image() {
		$data['status'] = 'Failed to reset profile image';
		$clientId = $this->session->userdata('client_id');
		if ($clientId == INTERNAL_CLIENT_ID) {
			$kolId = $this->input->post('kol_id');
			if ($this->kol->resetProfileImage($kolId)) {
				$data['status'] = 'Successfully resetted to default profile image';
			}
		}
		echo $data['status'];
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : upload_image()
	 * @Param  : $kolId
	 * @return : insert image name
	 */
	function upload_image($kolId=null) {
        $this->load->library('ColinUpload');

        //pr($_FILES['kol_image']['name']);
        $pathInfo = pathinfo($_FILES['kol_image']['name']);
        //echo $pathInfo['extension'];
        $ext = $pathInfo['extension'];
        if ($ext == 'jpg' || $ext == 'png' || $ext == 'gif' || $ext == 'tiff' || $ext == 'bmp' || $ext == 'jpeg' | $ext = 'jpe' || $ext = 'jfif' || $ext == 'tif'
        ) {
            
        } else {
            echo '<div id="output">Fail</div>';
//            break;
        }
        $kolImage = new ColinUpload($_FILES['kol_image']);
        if ($kolImage->uploaded) {
            // Save uploaded image with a random name
            // Generate the Random String
            $this->load->helper('String');
            $newFileName = random_string('unique', 20);
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->Process('images/kol_images/original');
            if ($kolImage->processed) {
                
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
            // Resize the image to Medium Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            // If the Height of the original image is more than the Width. like 150 wide X 500 Height
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 300;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 400;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/medium');
            if ($kolImage->processed) {
                
            } else {
                log_message('error', 'Error while Resizing the Image to Medium Size' . $kolImage->error);
            }
            // Resize the image to Small Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 100;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 100;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/resized');


            // Resize the image to Small Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 40;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 40;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/resized/microview/');
            if ($kolImage->processed) {
                //echo 'Image Resized';
                $kolImage->Clean();
                // Save the Image Path into the database
                $this->kol->db->where('id', $kolId);
                $data['profile_image'] = $newFileName . '.' . $kolImage->file_src_name_ext;
                $this->kol->db->update('kols', $data);
                // Output the HTML text
                echo '<div id="output">success</div>';
                //then output your message (optional)
                $imageSrc = base_url() . 'images/kol_images/medium/' . $data['profile_image'];
                echo '<div id="message"><img src="' . $imageSrc . '" alt="Uploaded Image"> </div>';
                echo '<div id="imageSrc">' . $imageSrc . '</div>';
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
        }
    }

    /**
     * @Author : Sanjeev K
     * @Method : crop_image()
     * @Param  : $kolId
     * @return : insert image name to database
     */
    function crop_image() {
        $x1 = $this->input->post('x1');
        $y1 = $this->input->post('y1');
        $x2 = $this->input->post('x2');
        $y2 = $this->input->post('y2');
        $w = $this->input->post('w');
        $h = $this->input->post('h');
        $thumbImagePath = $this->input->post('thumbImagePath');
        // Get the FileName info
        $arrFileInfo = pathinfo($thumbImagePath);
        // Filename without Extension
        $fileName = $arrFileInfo['filename'];
        $fileExtn = $arrFileInfo['extension'];
        /** As of now we don't need this code * */
        $maxSmallImageWidth = 100;
        // Calculate the SCaling Factor
        $scale = $maxSmallImageWidth / $w;
        // Get the existing Image Dimension of the Medium Sized image
        list($imageWidth, $imageHeight, $imageType) = getimagesize($thumbImagePath);
        $newImageWidth = ceil($w * $scale);
        $newImageHeight = ceil($h * $scale);
        /** End of Unwanted Code * */
        $this->load->library('ColinUpload');
        // Create the absolute path of the local file system
        $docRoot = $_SERVER['DOCUMENT_ROOT'];
        $absFilePath = $docRoot . '/' . $this->config->item('app_folder_path') . 'images/kol_images/medium/' . $fileName . '.' . $fileExtn;
        $kolImage = new ColinUpload($absFilePath);
        $newFileName = $kolImage->file_src_name_body;
        $kolImage->file_new_name_body = $newFileName;
        // Resize the image to Medium Size and save
        $kolImage->file_new_name_body = $newFileName;
        $kolImage->image_resize = true;
        // For Colin Upload
        // My Observation - Top, Right , Bottom , Left (As seen with Crop dimension from Office Pict)
        $right = $imageWidth - $x1 - $w;
        $left = $x1;
        $top = $y1;
        $bottom = $imageHeight - $y1 - $h;
        //- End of Observation
        $kolImage->image_precrop = array($top, $right, $bottom, $left);
        $kolImage->image_x = 100;
        $kolImage->image_ratio_y = true;
        $kolImage->Process('images/kol_images/resized');
        if ($kolImage->processed) {
            //echo 'Image Resized';
            //$kolImage->Clean();
            // Save the Image Path into the database
            $kol_id = $this->kol->getKolIdByVisibilityId($this->session->userdata('kolId'));
            $this->kol->db->where('id', $kol_id);
            $data['profile_image'] = $kolImage->file_dst_name_body . '.' . $kolImage->file_src_name_ext;
            $this->kol->db->update('kols', $data);
        } else {
            log_message('error', 'Error while uploading the image' . $kolImage->error);
        }
        redirect(base_url() . 'analysts/kols/edit_kol/' . $this->session->userdata('kolId'));
    }
	/**
	 * @Author : Sanjeev K
	 * @Method : get_lat_long_dynamically()
	 * @Param  : none
	 * @return : get lat and long
	 */
	function get_lat_long_dynamically(){
	
		$address = $this->input->post("address");
		$country = $this->input->post("country");
		$state = $this->input->post("state");
		$city = $this->input->post("city");
		$postalCode = $this->input->post("postalCode");
		if(!empty($address) && !empty($city)){
			$jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($address.' '.$city.' '.$state.' '.$country).'&sensor=false');
			$jsondata = json_decode($jsondata, true);
			if ($jsondata['status'] = 'OK') {
				$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
				$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
				if($lat != '' || $long != ''){
					$data['lat'] = $lat;
					$data['lon'] = $lon;
					echo json_encode($data);
				}
			}
		}else{
			$jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($postalCode).'&sensor=false');
			$jsondata = json_decode($jsondata, true);
			if ($jsondata['status'] = 'OK') {
				$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
				$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
				if($lat != '' || $long != ''){
					$data['lat'] = $lat;
					$data['lon'] = $lon;
					echo json_encode($data);
				}
			}
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_kol()
	 * @Param  : salutation, gender, first_name, middle_name, last_name, suffix, specialty, org_id, is_pubmed_processed, status, npi_num, profile_type
	 * @return : update kol details
	 */
	function update_kol() {
		// Get the current KOL ID from the Session
		$arrKol['id'] = $this->input->post('kol_id');
		
		// Get all the POST data
		$arrKol['salutation'] = $this->input->post('salutation');
		$arrKol['first_name'] = ucwords(trim($this->input->post('first_name')));
		$arrKol['middle_name'] = ucwords(trim($this->input->post('middle_name')));
		$arrKol['last_name'] = ucwords(trim($this->input->post('last_name')));
		$arrKol['suffix'] = ucwords(trim($this->input->post('suffix')));
		$arrKol['specialty'] = $this->input->post('specialty');
		$arrKol['sub_specialty'] = ucwords(trim($this->input->post('sub_specialty')));
		$arrKol['gender'] = $this->input->post('gender');
		$arrKol['org_id'] = $this->input->post('org_id');
		$arrKol['title'] = ucwords(trim($this->input->post('title')));
		if(!empty($arrKol['title'])){
			$arrKol['title'] = $this->kol->saveTitle($arrKol['title']); 
		}
		$arrKol['division'] = ucwords(trim($this->input->post('division')));
		$arrKol['npi_num'] = $this->input->post('npi_num');
		$arrKol['research_interests'] = $this->input->post('research_interests');
		$arrKol['license'] = $this->input->post('license');
		$arrKol['biography'] = $this->input->post('biography');
		$arrKol['notes'] = $this->input->post('notes');
		$arrKol['url'] = $this->input->post('url');
		$arrKol['modified_by'] = $this->loggedUserId;
		$arrKol['modified_on'] = date("Y-m-d H:i:s");
		$arrKol['mdm_id'] = $this->input->post('mdm_id');
		if ($arrKol['mdm_id'] == '')
			$arrKol['mdm_id'] = null;
			//- End of getting all the POST data
			
		$arrKol['profile_type'] = $this->input->post('profile_type');
		$arrKol['org_id'] = $this->kol->getOrgName($arrKol['org_id']);
		$returnValue = $this->kol->updateKol($arrKol);
		echo json_encode($returnValue);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_kol_contact()
	 * @Param  : primary_phone, primary_email, address1, address2, country_id, city_id, state_id, postal_code, fax
	 * @return : loads add kol's edit view
	 */
	function update_kol_contact() {
	
		// Get the current KOL ID from the Session
		$arrKol['id'] = $this->input->post('kol_id');
		
		// Get the current KOL's Visibility ID 
		$vid = $this->input->post('kol_visible_id');
	
		// Get all the POST data
		$arrKol['primary_phone'] = $this->input->post('primary_phone');
		$arrKol['primary_email'] = $this->input->post('primary_email');
		$arrKol['address1'] = ucwords(trim($this->input->post('address1')));
		$arrKol['address2'] = ucwords(trim($this->input->post('address2')));
		$arrKol['country_id'] = $this->input->post('country_id');
		$arrKol['city_id'] = $this->input->post('city_id');
		$arrKol['state_id'] = $this->input->post('state_id');
		$arrKol['postal_code'] = $this->input->post('postal_code');
		$arrKol['fax'] = $this->input->post('fax');
		$arrKol['modified_by'] = $this->loggedUserId;
		$arrKol['modified_on'] = date("Y-m-d H:i:s");
		//- End of getting all the POST data
		//prepare array to update KOL latitude and longitude
		$arrKolLatLongData['kol_id'] = $vid;
		$arrKolLatLongData['latitude'] = $this->input->post('latitude');
		$arrKolLatLongData['longitude'] = $this->input->post('longitude');
		//update KOL latitude and longitude
		$this->kol->updateKolLocationLatitudeLongitude($arrKolLatLongData);
		//update other info
		$returnValue = $this->kol->updateKol($arrKol);
		echo json_encode($returnValue);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_contact()
	 * @Param  : $_POST
	 * @return : returns $arrResult
	 */
	function save_contact() {
		if (isset($_POST) && count($_POST) > 0) {
			// Getting the POST details of Contact
			$contactDetails = array('related_to' => $this->input->post('related_to'),
					'phone' => $this->input->post('phone'),
					'email' => $this->input->post('email'),
					'created_by' => $this->loggedUserId,
					'created_on' => date("Y-m-d H:i:s"),
					'kol_id' => $this->input->post('kol_id'));
	
	
			// Create an array to return the result
			$arrResult = array();
			if ($lastInsertId = $this->kol->saveContact($contactDetails)) {
				//$this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $lastInsertId, MODULE_KOL_EDUCATION, $contactDetails['kol_id']);
				$arrResult['saved'] = true;
				$arrResult['lastInsertId'] = $lastInsertId;
				$arrResult['data'] = $contactDetails;
			} else {
				$arrResult['saved'] = false;
			}
			echo json_encode($arrResult);
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_contact()
	 * @Param  : $_POST
	 * @return : returns $arrResult
	 */
	function update_contact() {
		if (isset($_POST) && count($_POST) > 0) {
			// Getting the POST details of Contact
			$contactDetails = array('id' => $this->input->post('id'),
					'related_to' => $this->input->post('related_to'),
					'phone' => $this->input->post('phone'),
					'email' => $this->input->post('email'),
					'modified_by' => $this->loggedUserId,
					'modified_on' => date("Y-m-d H:i:s"));
			// Create an array to return the result
			$arrResult = array();
			if ($this->kol->updateContact($contactDetails)) {
				$arrResult['saved'] = true;
				$arrResult['lastInsertId'] = $contactDetails['id'];
				$arrResult['data'] = $contactDetails;
			} else {
				$arrResult['saved'] = false;
			}
			echo json_encode($arrResult);
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_contact()
	 * @Param  : $id
	 * @return : echo success | failure
	 */
	function delete_contact($id) {
		if ($this->kol->deleteContactById($id)) {
			echo 'success';
		} else {
			echo 'failed to delete';
		}
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : list_contacts()
	 * @Param  : none
	 * @return : returns contacts list to jqgrid
	 */
	function list_contacts() {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrContactDetails = array();
		$data = array();
		if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
			$count = sizeof($arrContactDetails);
			if ($count > 0) {
				$total_pages = ceil($count / $limit);
			} else {
				$total_pages = 0;
			}
			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrContactDetails;
		}
		echo json_encode($data);
	}
	/** 
	 * End of Overview Tab
	 */
	
	/**
	 * Details Tab
	 * @Author : Sanjeev K
	 * @Method : details_kol()
	 * @Param  : Kol Visibility Id (vid)
	 * @return : loads kol's location tab with in detail view
	 */
	function details_kol($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		if (!$kolId) {
			$this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
			redirect('kols/list_kols');
		}
		// Getting the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrKol'] = $arrKolDetail;
		// If there is no record in the database
		if (!$arrKolDetail) {
			$this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
			redirect('kols/list_kols');
		}
		// Set the KOL ID into the Session
		$this->session->set_userdata('kolId', $kolId);
		
		$data['kolId'] = $kolId;
		$data['arrCountry'] = $this->country_helper->listCountries();
		$arrStates = array();
		$arrCities = array();
		if ($arrKolDetail['country_id'] != 0) {
			$arrStates = $this->country_helper->getStatesByCountryId($arrKolDetail['country_id']);
		}
		if ($arrKolDetail['state_id'] != 0) {
			$arrCities = $this->country_helper->getCitiesByStateId($arrKolDetail['state_id']);
		}
		$data['arrStates'] = $arrStates;
		$data['arrCities'] = $arrCities;
		//get titles list
		$arrResult =  $this->kol->getAllActiveTitles('all');
		foreach ($arrResult as $row){
			$arrTitles[$row['id']]=$row['title'];
		}
		$data['arrTitles'] = $arrTitles;
		$data['arrOrganizationTypes']= $this->organization->getAllOrganizationTypes();
		
		$data['contentPage'] = 'kols/details_kol';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_locations
	 * @Param  : Kol Visibility Id (vid)
	 * @return : returns kol's location list to jqgrid
	 */
	function list_locations($kolId = null) {
		$arrLocations	= array();
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$locations = array();
		$locations = $this->kol->listLocationDetails($kolId);
		foreach ($locations as $row) {
			$row['kol_id'] = $kolId;
			$row['address'] = trim($row['address'], ', ');
			$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
			$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
			if ($row['is_primary']){
				$row['is_primary'] = "<span class='is_primary'>&nbsp;</span>";
				$row['is_primary_value'] = 1;
			}else{
				$row['is_primary'] = "";
				$row['is_primary_value'] = 0;
			}
			if(!empty($row['private_practice']))
				$row['org_name'] = $row['private_practice'];
				else
					$row['org_name'] = $row['org_name'];
					$arrLocations[] = $row;
		}
		// 		$data['kolId'] = $kolId;
		// 		$data['locations'] = $arrLocations;
		//$data	= $arrLocations;
		$total_pages	= 0;
		$data	= array();
		$count = sizeof($arrLocations);
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		$data['records'] = $count;
		$data['total'] = $total_pages;
		$data['page'] = $page;
		$data['rows'] = $arrLocations;
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_location
	 * @Param  : location details in post method
	 * @return : insert / update location data
	 */
	function save_location() {
		$arrLocationDataExist['kol_id'] 			= $this->input->post('kol_id');
		$arrLocationDataExist['org_institution_id'] = $this->input->post('org_institution_id');
		$isExist 									= $this->kol->getKolLocationByOrgInstId($arrLocationDataExist);
		$dataType 									= 'User Added';
		$client_id									=$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		if(((!empty($this->input->post('id'))) && ($this->input->post('org_inst_selected') != $this->input->post('org_institution_id')) && ($isExist >0)) || (empty($this->input->post('id')) && ($isExist >0))) {
			$data['status'] = true;
			$data['duplicate_location'] = true;
		}else{
			$arrData['kol_id'] = $this->input->post('kol_id');
			$org_id = $this->input->post('org_institution_id');
			$private_practice = $this->input->post('organization');
			$arrData['division'] = $this->input->post('department_loc');
			$arrData['title'] = $this->input->post('title_loc');
			if (empty($org_id)) {
				$arrOrgData['address'] = trim($this->input->post('address1')) . " " . trim($this->input->post('address2'));
				$arrOrgData['status'] = 'Completed';
	
				$city_id = trim($this->input->post('city_id'));
				if (!empty($city_id)) {
					$arrOrgData['city_id'] = trim($this->input->post('city_id'));
				} else {
					$arrOrgData['city_id'] = "";
				}
				$arrOrgData['name'] = trim($this->input->post('organization'));
				$arrOrgData['state_id'] = trim($this->input->post('state_id'));
				$arrOrgData['country_id'] = trim($this->input->post('country_id'));
				$arrOrgData['postal_code'] = trim($this->input->post('postal_code'));
				$arrOrgData['created_by'] = $this->loggedUserId;
				$arrOrgData['created_on'] = date('Y-m-d H:i:s');
				$arrOrgData['modified_by'] = $this->loggedUserId;
				$arrOrgData['modified_on'] = date('Y-m-d H:i:s');
				$arrOrgData['type_id'] = trim($this->input->post('org_type'));
				$arrOrgData['profile_type'] = 1;
				$arrOrgData['status_otsuka'] = "ACTV";
				$arrOrgData['status'] = "";
				$org_id = $this->organization->saveOrganization($arrOrgData);
	
				$orgData['org_id'] 			= $org_id;
				$orgData['address1'] 			= trim($this->input->post('address1'));
				$orgData['address2'] 			= trim($this->input->post('address2'));
				$orgData['address_type'] 		= trim($this->input->post('address_type'));
				$orgData['country_id'] 	= $this->input->post('country_id');
				$orgData['state_id'] 	= $this->input->post('state_id');
				$orgData['city_id'] 		= $this->input->post('city_id');
				$orgData['postal_code'] 	= $this->input->post('postal_code');
				$orgData['phone_number_primary'] 	= $this->input->post('phone_number_loc');
				$orgData['phone_type_primary'] 	= $this->input->post('phone_type_loc');
				$orgData['is_primary'] 			= 1;
				$orgData['created_by'] 		= $this->loggedUserId;
				$orgData['created_on'] 		= date('Y-m-d H:i:s');
				$orgData['modified_by'] 		= $this->loggedUserId;
				$orgData['modified_on'] 		= date('Y-m-d H:i:s');
				$orgLocLasId = $this->organization->saveLocation($orgData);
				if(isset($orgData['phone_type_primary']) && $orgData['phone_number_primary'] > 0){
					$orgPhone = array();
					$orgPhone['type'] = $this->input->post('phone_type_loc');
					$orgPhone['number'] = $this->input->post('phone_number_loc');
					$orgPhone['contact_type'] = 'organization';
					$orgPhone['contact'] = $org_id;
					$orgPhone['is_primary'] = 1;
					$orgPhone['location_id'] = $orgLocLasId;
					$orgPhone['created_by'] = $this->loggedUserId;
					$orgPhone['created_on'] = date('Y-m-d H:i:s');
					$lastPhoneId = $this->kol->savePhone($orgPhone);
				}
			}
			$typeId = trim($this->input->post('org_type'));
			if (empty($typeId)) {
				$arrOrgType = array();
				$arrOrgType['id'] = $org_id;
				$arrOrgType['type_id'] = 7;
				$this->organization->updateOrgTypeForOrganization($arrOrgType);
			}else{
				$arrOrgType = array();
				$arrOrgType['id'] = $org_id;
				$arrOrgType['type_id'] = $typeId;
				$this->organization->updateOrgTypeForOrganization($arrOrgType);
			}
			$arrData['org_institution_id'] = $org_id;
			$arrData['address1'] = trim($this->input->post('address1'));
			$arrData['address2'] = trim($this->input->post('address2'));
			$arrData['address3'] = trim($this->input->post('address3'));
			if (!empty($private_practice))
				$arrData['private_practice'] = $this->input->post('organization');
				else
					$arrData['private_practice'] == '';
					$arrData['validation_status'] = trim($this->input->post('validation_status'));
					$arrData['address_type'] = trim($this->input->post('address_type'));
					$arrData['country_id'] = $this->input->post('country_id');
					$arrData['state_id'] = $this->input->post('state_id');
					$genericId = $this->common_helper->getGenericId("Location Form");
					$arrData['generic_id'] = $genericId;
						
					if ($arrData['state_id'] == '')
						unset($arrData['state_id']);
						$city_id = $this->input->post('city_id');
						if (!empty($city_id)) {
							if(is_numeric($city_id)){
								$arrOrgData['city_id'] = trim($this->input->post('city_id'));
								$arrData['city_id'] = $arrOrgData['city_id'];
							}else{
								$cityId = $this->kol->checkCityIfExistElseAdd($city_id,trim($this->input->post('state_id')),trim($this->input->post('country_id')));
								$arrData['city_id'] = $cityId;
							}
						} else {
							$arrData['city_id'] = "";
						}
						$arrData['postal_code'] = $this->input->post('postal_code');
						$arrData['phone_type'] = $this->input->post('phone_type_loc');
						$arrData['phone_number'] = $this->input->post('phone_number_loc');
						if ($this->input->post('is_primary') == "1")
							$arrData['is_primary'] = $this->input->post('is_primary');
							$arrData['modified_by'] = $this->loggedUserId;
							$arrData['modified_on'] = date('Y-m-d H:i:s');
							$arrData['data_type_indicator'] = $dataType;
							$id = $this->input->post('id');
							if (!empty($id)) {
								$arrData['id'] = $this->input->post('id');
								$lastId = $this->kol->saveLocation($arrData);
								if ($arrData['is_primary'] == '1') {
									// 					log_user_activity(null,true);
								}
								if ($lastId) {
									$data['status'] = true;
								} else {
									$data['status'] = false;
								}
								$lastId = $arrData['id'];
							} else {
								$arrData['created_by'] = $this->loggedUserId;
								$arrData['created_on'] = date('Y-m-d H:i:s');
								$lastId = $this->kol->saveLocation($arrData);
								if ($lastId) {
									$data['status'] = true;
									$data['id'] = $lastId;
								} else {
									$data['status'] = false;
								}
							}
							//if is primary then update the kols table address information
							if ($arrData['is_primary'] == '1') {
								$arrKolDetails = array();
								$arrKolDetails['id'] = $arrData['kol_id'];
								$arrKolDetails['org_id'] = $arrData['org_institution_id'];
								$arrKolDetails['address1'] = $arrData['address1'];
								$arrKolDetails['address2'] = $arrData['address2'];
								$arrKolDetails['country_id'] = $arrData['country_id'];
								$arrKolDetails['state_id'] = $arrData['state_id'];
								$arrKolDetails['city_id'] = $arrData['city_id'];
								$arrKolDetails['postal_code'] = $arrData['postal_code'];
								$arrKolDetails['modified_by'] = $this->loggedUserId;
								$arrKolDetails['modified_on'] = date('Y-m-d H:i:s');
								$arrKolDetails['division'] = $arrData['division'];
								$arrKolDetails['title'] =$arrData['title'];
								$this->kol->updateKol($arrKolDetails);
								$arrKolDetails['org_type']  =  trim($this->input->post('org_type'));
								$arrKolDetails['org_name']  =  $this->input->post('organization');
								$arrKolDetails['address_type']  =  $arrData['address_type'];
								$data['details'] = $arrKolDetails;
							}else{
								$data['details'] = '';
							}
		}
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_location
	 * @Param  : location id
	 * @return : delete location data
	 */
	function delete_location(){
		
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_kol_details
	 * @Param  : Kol Visibility Id (vid) with phone or staff or email or state license or assign profile 
	 * @return : returns kol's respective list to jqgrid
	 */
	function list_kol_details($type,$kolId = null) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
	
		if($type == 'phone'){
			$responce = array();
			$phone = array();
			$phone = $this->kol->getPhones($kolId, 'kol');
			foreach ($phone as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$row['kol_id'] = $kolId;
				$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
				$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
				if ($row['is_primary']==0)
					$row['is_primary'] = "No";
					else
						$row['is_primary'] = "Yes";
						$responce[] = $row;
			}
		}
		if($type == 'staff'){
			$responce = array();
			$staff = array();
			$staff = $this->kol->getStaffs($kolId, 'kol');
			foreach ($staff as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$row['kol_id'] = $kolId;
				$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
				$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
				$responce[] = $row;
			}
		}
		if($type == 'emails'){
			$responce = array();
			$emails = array();
			$emails = $this->kol->getEmails($kolId, 'kol');
			foreach ($emails as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$row['kol_id'] = $kolId;
				$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
				$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
				if ($row['is_primary']==0)
					$row['is_primary'] = "No";
					else
						$row['is_primary'] = "Yes";
						$responce[] = $row;
			}
		}
		if($type == 'statelicense'){
			$responce = array();
			$statelicense = array();
			$statelicense = $this->kol->getStateLicences($kolId, 'kol');
			foreach ($statelicense as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$row['kol_id'] = $kolId;
				$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
				$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
				if ($row['is_primary']==0)
					$row['is_primary'] = "No";
					else
						$row['is_primary'] = "Yes";
						$responce[] = $row;
			}
		}
		if($type == 'assign'){
			$responce = array();
			$assignedUsers = array();
			$assignedUsers = $this->kol->getAssignedUsers($kolId);
			foreach ($assignedUsers as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$row['kol_id'] = $kolId;
				if(ROLE_USER && $this->session->userdata('user_id') == $row['user_id']){
					$row['eAllowed'] = true;
					$row['dAllowed'] = true;
				}else{
					$row['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $row);
					$row['dAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'delete', $row);
				}
				$responce[] = $row;
			}
		}
		$total_pages	= 0;
		$data	= array();
		$count = sizeof($responce);
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		$data['records'] = $count;
		$data['total'] = $total_pages;
		$data['page'] = $page;
		$data['rows'] = $responce;
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_phone
	 * @Param  : phone details in post method
	 * @return : insert / update phone data
	 */
	function save_phone() {
		$data= $this->kol->insertOrUpdatePhoneNumber($_POST);
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_phone
	 * @Param  : phone id
	 * @return : delete phone data
	 */
	function delete_phone(){
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_staff
	 * @Param  : staff details in post method
	 * @return : insert / update staff data
	 */
	function save_staff() {
		$data= $this->kol->insertOrUpdateStaff($_POST);
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_staff
	 * @Param  : staff id
	 * @return : delete staff data
	 */
	function delete_staff(){
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_email
	 * @Param  : email details in post method
	 * @return : insert / update email data
	 */
	function save_email() {
		$data= $this->kol->insertOrUpdateEmail($_POST);
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_email
	 * @Param  : email row id
	 * @return : delete email data
	 */
	function delete_email(){
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_state_license
	 * @Param  : state license details in post method
	 * @return : insert / update email data
	 */
	function save_state_license() {
		$data= $this->kol->insertOrUpdateStateLicense($_POST);
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_state_license
	 * @Param  : state_license row id
	 * @return : delete state_license data
	 */
	function delete_state_license(){
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_client_assign
	 * @Param  : user id in post method
	 * @return : insert / update email data
	 */
	function save_client_assign(){
		$data= $this->kol->insertOrUpdateAssignClient($_POST);
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_client_assign
	 * @Param  : user kol align row id
	 * @return : delete user kol align id
	 */
	function delete_client_assign(){
	
	}
	
	/** 
	 * End of Details Tab
	 */
	
	/**
	 * Education Tab
	 * @Author : Sanjeev K
	 * @Method : add_education_detail
	 * @Param  : kol visibility id as $kolId
	 * @return : loads kol's location tab with in detail view
	 */
	function add_education_detail($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		// Get the existing education details
		$data['arrEducationDetails'] = array();
		// Get the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrKol'] = $arrKolDetail;
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		//Returns all the InstituteNames from the lookuptable
		$arrAllInstituteNames = $this->kol->getAllInstituteNames();
		$data['arrAllInstituteNames'] = $arrAllInstituteNames;
		//$this->load->view('education_training/add_education_detail', $data);
		$data['contentPage'] = 'kols/add_education_detail';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_education_details
	 * @Param  : $type, $kolId
	 * @return : loads education records in jqgrid
	 */
	function list_education_details($type, $kolId) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrEducationResults = array();
		$arrEducationDetails = array();
		$data = array();
		if ($arrEducationResults = $this->kol->listEducationDetails($type, $kolId)) {
			$count = sizeof($arrEducationResults);
			if ($count > 0) {
				$total_pages = ceil($count / $limit);
			} else {
				$total_pages = 0;
			}
			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrEducationResults;
		}
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_institute_names
	 * @Param  : $instituteName
	 * @return : json data $arrReturnData
	 */
	function get_institute_names($instituteName) {
		$instituteName = urldecode($this->input->post($instituteName));
		$arrInstituteNames = $this->kol->getInstituteNames($instituteName);
		$arrSuggestInstitutes = array();
		if (sizeof($arrInstituteNames) == 0) {
			$arrSuggestInstitutes[0] = 'No results found for ' . $instituteName;
		} else {
			$flag = 1;
			foreach ($arrInstituteNames as $id => $name) {
				if ($flag) {
					$arrSuggestInstitutes[] = '<div class="autocompleteHeading">Institute Names</div><div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestInstitutes[] = '<div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $instituteName;
		$arrReturnData['suggestions'] = $arrSuggestInstitutes;
		echo json_encode($arrReturnData);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_education_degrees
	 * @Param  : $educationType, $degreeName
	 * @return : json data $arrReturnData
	 */
	function get_education_degrees($educationType, $degreeName) {
		$arrDegreeNames = $this->kol->getEducationDegrees($educationType, $degreeName);
		$arrReturnData['query'] = $degreeName;
		$arrReturnData['suggestions'] = $arrDegreeNames;
		echo json_encode($arrReturnData);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_education_specialtys
	 * @Param  : $educationType, $specialtyName
	 * @return : json data $arrReturnData
	 */
	function get_education_specialtys($educationType, $specialtyName) {
		$arrSpecialtyNames = $this->kol->getEducationSpecialtys($educationType, $specialtyName);
		$arrReturnData['query'] = $specialtyName;
		$arrReturnData['suggestions'] = $arrSpecialtyNames;
		echo json_encode($arrReturnData);
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : get_institute_id
	 * @Param  : $name
	 * @return : saved education details
	 */
	function get_institute_id($name) {
		$instituteId = $this->kol->getInstituteId($name);
		echo json_encode($instituteId);
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : save_education_detail
	 * @Param  : values passed in posted method
	 * @return : institute details
	 */
	function save_education_detail() {
		if (isset($_POST) && count($_POST) > 0) {
			// Getting the POST details of Education
			$dataType = 'User Added';
			$client_id =$this->session->userdata('client_id');
			if($client_id == INTERNAL_CLIENT_ID){
				$dataType = 'Aissel Analyst';
			}
			$educationDetails = array('type' => $this->input->post('type'),
					'institute_id' => $this->input->post('institute_id'),
					'degree' => ucwords(trim($this->input->post('degree'))),
					'specialty' => ucwords(trim($this->input->post('specialty'))),
					'start_date' => trim($this->input->post('start_date')),
					'end_date' => trim($this->input->post('end_date')),
					'honor_name' => $this->input->post('honor_name'),
					'year' => $this->input->post('year'),
					'url1' => $this->input->post('url1'),
					'url2' => $this->input->post('url2'),
					'notes' => $this->input->post('notes'),
					'created_by' => $this->loggedUserId,
					'created_on' => date("Y-m-d H:i:s"),
					'kol_id' => $this->input->post('kol_id'),
					'client_id' => $this->session->userdata('client_id'),
					'data_type_indicator' => $dataType
			);
			if($educationDetails['type'] == 'board_certification'){
				$educationDetails['degree'] = '';
			}
			// Create an array to return the result
			$arrResult = array();
			if (!isset($educationDetails['institute_id']) || $educationDetails['institute_id'] == 0 || $educationDetails['institute_id'] == '')
				$educationDetails['institute_id'] = null;
				if ($lastInsertId = $this->kol->saveEducationDetail($educationDetails)) {
					$arrEducationDetails = $this->kol->getEducationById($lastInsertId);
					$educationDetails['first_name'] = $arrEducationDetails['first_name'];
					$educationDetails['last_name'] = $arrEducationDetails['last_name'];
					$educationDetails['is_analyst'] = $arrEducationDetails['is_analyst'];
					// $this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $lastInsertId, MODULE_KOL_EDUCATION, $educationDetails['kol_id']);
					$transaction_name = ucfirst($educationDetails['type']);
					$arrResult['saved'] = true;
					$arrResult['lastInsertId'] = $lastInsertId;
	
					//This field value doesn't apply's to "honors_awards"
					if ($educationDetails['type'] != 'honors_awards') {
						//Getting the name of the  Institute By Passing The Id
						$educationDetails['institute_id'] = $this->kol->getInstituteName($educationDetails['institute_id']);
					}
					//Additional prameter 'date' for client view use only. It doesn't afeect or include in the Analyst app
					$educationDetails['date'] = '';
					if ($educationDetails['start_date'] != '')
						$educationDetails['date'] .=$educationDetails['start_date'];
				 	else
				 		$educationDetails['date'] .='NA';
	
				 		$educationDetails['date'] .=" - ";
				 		 
				 		if ($educationDetails['end_date'] != '')
				 			$educationDetails['date'] .=$educationDetails['end_date'];
				 			else
				 				$educationDetails['date'] .='NA';
				 					
				 				if ($educationDetails['date'] == 'NA - NA') {
				 					$educationDetails['date'] = '';
				 				}
				 				//End of Additional prameter 'date' for client view use only
				 				if ($educationDetails['url1'] != '') {
				 					$educationDetails['url1'] = '<a href=\'' . $educationDetails['url1'] . '\' target="_new">URL1</a>';
				 				}
				 				if ($educationDetails['url2'] != '') {
				 					$educationDetails['url2'] = '<a href=\'' . $educationDetails['url2'] . '\' target="_new">URL2</a>';
				 				}
				 				$arrResult['data'] = $educationDetails;
				} else {
					$arrResult['saved'] = false;
				}
				echo json_encode($arrResult);
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_education_detail
	 * @Param  : values passed in posted method
	 * @return : institute id
	 */
	function update_education_detail() {
		if (isset($_POST) && count($_POST) > 0) {
			$inst_id = null;
			if($this->input->post('institute_id')){
				$inst_id = $this->input->post('institute_id');
			}
			// Getting the POST details of Education
			$educationDetails = array('id' => $this->input->post('id'),
					'type' => $this->input->post('type'),
					'institute_id' => $inst_id,
					'degree' => ucwords(trim($this->input->post('degree'))),
					'specialty' => ucwords(trim($this->input->post('specialty'))),
					'start_date' => $this->input->post('start_date'),
					'end_date' => $this->input->post('end_date'),
					'honor_name' => $this->input->post('honor_name'),
					'year' => $this->input->post('year'),
					'url1' => $this->input->post('url1'),
					'url2' => $this->input->post('url2'),
					'notes' => $this->input->post('notes'),
					'modified_by' => $this->loggedUserId,
					'modified_on' => date("Y-m-d H:i:s")
			);
			if($educationDetails['type'] == 'board_certification'){
				$educationDetails['degree'] = '';
			}
			// Create an array to return the result
			$arrResult = array();
			if ($this->kol->updateEducationDetail($educationDetails)) {
				//$this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_UPDATE, $educationDetails['id'], MODULE_KOL_EDUCATION, $this->input->post('kol_id'));
				$transaction_name = ucfirst($educationDetails['type']);
				$arrResult['saved'] = true;
				$arrResult['lastInsertId'] = $educationDetails['id'];
				//This field value doesn't apply's to "honors_awards"
				if ($educationDetails['type'] != 'honors_awards') {
					//Getting the name of the  Institute By Passing The Id
					$educationDetails['institute_id'] = $this->kol->getInstituteName($educationDetails['institute_id']);
				}
				if ($educationDetails['url1'] != '') {
					$educationDetails['url1'] = '<a href=\'' . $educationDetails['url1'] . '\' target="_new">URL1</a>';
				}
				if ($educationDetails['url2'] != '') {
					$educationDetails['url2'] = '<a href=\'' . $educationDetails['url2'] . '\' target="_new">URL2</a>';
				}
				$arrResult['data'] = $educationDetails;
			} else {
				$arrResult['saved'] = false;
			}
			echo json_encode($arrResult);
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_education_detail
	 * @Param  : $id
	 * @return : deleted status
	 */
	function delete_education_detail($id) {
		$arrdetails['table']='kol_educations';
		$arrdetails['id']=$id;
		if ($this->common_helper->deleteById($arrdetails)) {
			// 			$this->update->deleteUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $id, MODULE_KOL_EDUCATION);
			// 			$this->update->deleteUpdateEntry(KOL_PROFILE_EDUCATION_UPDATE, $id, MODULE_KOL_EDUCATION);
			//echo 'success';
			$data['status'] = 'success';
		} else {
			//echo 'failed to delete';
			$data['status'] = 'fail';
		}
		echo json_encode($data);
	}
	/** 
	 * End of Education Tab
	 */
	
	/**
	 * Affiliation Tab
	 * @Author : Sanjeev K
	 * @Method : add_membership
	 * @Param  : kol visibility id as $kolId
	 * @return : loads kol's organization type tab with in Affiliation view
	 */
	function add_membership($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		// Get the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrKol'] = $arrKolDetail;
		// Get the list of EngagementTypes
		//$this->load->Model('Engagement_type');
		$arrEngagementTypes = array();//$this->Engagement_type->getAllEngagementTypes();
		$key = array_search('Other', $arrEngagementTypes);
		unset($arrEngagementTypes[$key]);
		$arrEngagementTypes[$key] = 'Other';
		$data['arrEngagementTypes'] = $arrEngagementTypes;
		// Get the list of InstituteNames
		$arrInstituteNames = $this->kol->getAllInstituteNames();
		$data['arrInstituteNames'] = $arrInstituteNames;
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		//pr($data);
		$data['arrCountry'] = $this->country_helper->listCountries();
		//$this->load->view('memberships_affiliations/add_memberships_affiliations',$data);
		$data['contentPage'] = 'kols/add_memberships_affiliations';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_memberships
	 * @Param  : $type, $kolId
	 * @return : loads lsit of memerships records in jqgrid
	 */
	function list_memberships($type, $kolId = null) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrMembershipResult = array();
		$data = array();
		if ($arrMembershipResult = $this->kol->listMemberships($type, $kolId)) {
			$count = sizeof($arrMembershipResult);
			if ($count > 0) {
				$total_pages = ceil($count / $limit);
			} else {
				$total_pages = 0;
			}
			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrMembershipResult;
		}
	
		echo json_encode($data);
	}
	/**
	 * End of Affiliation Tab
	 */
	
	
	/**
	 * Events Tab
	 * @Author : Sanjeev K
	 * @Method : add_event
	 * @Param  : kol visibility id as $kolId
	 * @return : loads kol's conference tab with in Events view
	 */
	function add_event($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		$data['arrCountry'] = $this->country_helper->listCountries();
		// Get the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrKol'] = $arrKolDetail;
		// Get the list of Specialties
		//$this->load->model('Specialty');
		$arrSpecialties = array(); //$this->Specialty->getAllSpecialties();
		$data['arrSpecialties'] = $arrSpecialties;
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		// Get the list of Conference Event Types
		//$this->load->model('Event_helper');
		$arrConfEventTypes = array(); //$this->Event_helper->getAllConferenceEventTypes();
		$data['arrConfEventTypes'] = $arrConfEventTypes;
		// Get the list of Conference Session Types
		$arrConfSessionTypes = array(); //$this->Event_helper->getAllConferenceSessionTypes();
		$key = array_search('Other', $arrConfSessionTypes);
		unset($arrConfSessionTypes[$key]);
		$arrConfSessionTypes[$key] = 'Other';
		$data['arrConfSessionTypes'] = $arrConfSessionTypes;
		// Get the list of Online Event Types
		$arrOnlineEventTypes = array(); //$this->Event_helper->getAllOnlineEventTypes();
		$data['arrOnlineEventTypes'] = $arrOnlineEventTypes;
		//Returns all the EventNames from the lookuptable
		$arrAllEventNames = array(); //$this->kol->getAllEventLookupNames();
		$data['arrAllEventNames'] = $arrAllEventNames;
		// Get the list of Topic belongs to kol specialty
		$arrTopics = $this->kol->getTopicsBySpecialty($arrKolDetail['specialty']);
		$data['arrTopics'] = $arrTopics;
		//$this->load->view('events/add_event',$data);
		$arrRoles = $this->kol->getEventRoles();
		$data['arrRoles'] = $arrRoles;
		$data['arrEventOrganizerTypes'] = array(); //$this->Event_helper->getOrganizerTypes();
	
		$data['arrEventSponsorTypes'] = array(); //$this->Event_helper->getSponsorTypes();
		$data['contentPage'] = 'kols/add_event';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	/**
	 * End of Events Tab
	 */
	
	/**
	 * Social Media Tab
	 * @Author : Sanjeev K
	 * @Method : add_event
	 * @Param  : kol visibility id as $kolId
	 * @return : loads kol's conference tab with in Events view
	 */
	function add_social_media($kolId = null) {
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		// Get the KOL details
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrKol'] = $arrKolDetail;
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		$data['contentPage'] = 'kols/add_social_media';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_social_media
	 * @Param  : social media links for kol in post method($_POST)
	 * @return : insert/update social media links 
	 */
	function save_social_media() {
		if (isset($_POST) && count($_POST) > 0) {
	
			// Getting the POST details of Events
			$socialMediaDetails = array('blog' => $this->input->post('blog'),
					'linked_in' => $this->input->post('linked_in'),
					'facebook' => $this->input->post('facebook'),
					'twitter' => $this->input->post('twitter'),
					'myspace' => $this->input->post('myspace'),
					'you_tube' => $this->input->post('you_tube'),
					'id' => $this->input->post('kol_id'));
			$this->kol->saveSocialMedia($socialMediaDetails);
			//$this->update->insertUpdateEntry(KOL_PROFILE_SOCIAL_MEDIA_UPDATE, $socialMediaDetails['id'], MODULE_KOL_OVERVIEW, $socialMediaDetails['id']);
		}
	}
	/**
	 * End of Social Media Tab
	 */
	
	/**
	 * Requested Kols 
	 * @Author : Sanjeev K
	 * @Method : list_requested_kols
	 * @Param  : kol visibility id as $kolId
	 * @return : loads kol's conference tab with in Events view
	 */
	function list_requested_kols(){
	
		$this->common_helper->checkUsers();
		//$arrKolDetailResult = $this->kol->getRequestedKolDetail();
		$arrKolDetailResult = $this->kol->listAll();
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
	
		// To show the pubmed and CT Links for Autorised users right now for user id=5
		$data['user_id'] = $this->session->userdata('user_id');
	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
		$arrSpecialties	= $this->speciality->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
	
		//$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'kols/list_requested_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_request_status
	 * @Param  : array kolId, status
	 * @return : 
	 */
	function update_request_status(){
		/* $config['protocol'] 	= PROTOCOL;
		 $config['smtp_host'] 	= HOST;
		 $config['smtp_port'] 	= PORT;
		 $config['smtp_user'] 	= USER;
		 $config['smtp_pass'] 	= PASS;
		 $config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');
	
		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		if($arr['status']==COMPLETED){
			$status = STATUS_COMPLETED;
		}
	
		if($arr['status']==APPROVED){
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
		}
	
		if($arr['status'] == PROFILING)
			$status = STATUS_PROFILING;
			if($arr['status'] == REVIEW)
				$status = STATUS_REVIEW;
				if($arr['status'] == New1)
					$status = STATUS_NEW;
	
					foreach($arr['kolId'] as $id){
						//Update request
						$rowData = array();
						$arrRequestData = $this->kol->get($id);
						$arrKol = $this->kol->editKol($arrRequestData['kol_id']);
						$rowData['id'] = $arrRequestData['id'];
						$rowData['status'] = $arr['status'];
						if($arr['status'] == APPROVED || $arr['status'] == REJECT){
							$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
							$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
						}
						$isUpdated = $this->kol->update($rowData);
							
						//Update KOL status
						if(($arrRequestData['request_for'] == REQUEST_TYPE_PROFILE && $arrKol['status'] == New1) || $arr['status'] == COMPLETED ){
							$kolDetails = array();
							$kolDetails['id'] = $arrRequestData['kol_id'];
							$kolDetails['status'] = $arr['status'];
							if($arr['status'] == COMPLETED)
								$kolDetails['profile_type'] = $arrRequestData['profile_type'];
								$this->kol->updateKol($kolDetails);
						}
							
						if($arr['status'] == APPROVED || $arr['status'] == REJECT || $arr['status'] == COMPLETED){
							//Send mail
							$userEmailId  = $this->kol->getUserEmailId($arrRequestData['requested_by']);
							$data1['arrKol']=	$arrKol;
							$data1['arrRequestData']=	$arrRequestData;
							$userNAme = $this->session->userdata('user_full_name');
							$this->email->from($config['smtp_user'],$userNAme);
							if($arr['status'] == APPROVED){
								$this->email->subject(PRODUCT_NAME.': Profiling Request - Approved');
								$data1['requestAction'] = ANALYST_APPROVE_USER;
							}else if($arr['status'] == REJECT){
								$this->email->subject(PRODUCT_NAME.": Profiling Request - Rejected");
								$data1['requestAction'] = ANALYST_REJECT_USER;
							}else if($arr['status'] == COMPLETED){
								$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
								$data1['requestAction'] = ANALYST_COMPLETE_USER;
							}
							$html = $this->load->view('email_templates/prepare_email_content',$data1,true);
							$this->email->message($html);
							$this->email->to($userEmailId);
							$this->email->send();
	
							//Send mail to user manager if the status is completed
							if($arr['status'] == COMPLETED){
								$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($arrRequestData['requested_by']);
								$clientMangerEmailIds = str_replace($userEmailId, "", $clientMangerEmailIds);
								$clientMangerEmailIds = str_replace(",,", ",", $clientMangerEmailIds);
								$clientMangerEmailIds = trim($clientMangerEmailIds,',');
								if($clientMangerEmailIds != ''){
									$html = $this->load->view('email_templates/prepare_email_content',$data1,true);
									$this->email->message($html);
									$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
									$this->email->to($clientMangerEmailIds);
									$this->email->send();
								}
							}
	
						}
							
						//$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $kolId,$status);
					}
	
	
					if($arr['status']==COMPLETED){
						foreach($arr['kolId'] as $id){
							$arrRequestData = $this->requested_kol->get($id);
							$arrIds[]=$arrRequestData['kol_id'];
						}
						$arrUsers = $this->align_user->getRquetsterOfKol($arrIds);
						foreach($arrUsers as $row){
							//$this->align_user->assignKolsToUser($row);
						}
					}
	
	}
	/**
	 * My Customers
	 * @Author : Sanjeev K
	 * @Method : list_pre_requested_kols
	 * @Param  : null
	 * @return : loads my customer view
	 */
	function list_pre_requested_kols(){
		$this->common_helper->checkUsers();
		$clientId = $this->session->userdata('client_id');
		$status = PRENEW;
		$arrKolDetailResult = $this->kol->getNonProfiledKols($status,$clientId);
	
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
	
		// To show the pubmed and CT Links for Autorised users right now for user id=5
		$data['user_id'] = $this->session->userdata('user_id');
	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
		$arrSpecialties	= $this->speciality->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
	
		//$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'kols/list_pre_requested_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * Kols Visibility
	 * @Author : Sanjeev K
	 * @Method : list_kols_based_on_client
	 * @Param  : $previouslySelectedClientId
	 * @return : loads kols visiblity layout
	 */
	function list_kols_based_on_client($previouslySelectedClientId) {
		$data['analystSelectedClientId'] = $this->session->userdata('analyst_client');
		$data['contentPage'] = 'kols/list_kols_based_on_client';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_kols_associated_with_client
	 * @Param  : kol visibility id as $kolId
	 * @return : loads associated kols for client in jqgrid
	 */
	function get_kols_associated_with_client($clientId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data				= array();
		$arrReturnData = array();
		$arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$arrKolData = $this->kol->getKolsAssociatedWithClient($clientId);
		foreach ($arrKolData as $row) {
			$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['kol_name'];
			$row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $kolName . '</a>';
			$arrReturnData[] = $row;
		}
		$count=sizeof($arrReturnData);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
	
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrReturnData;
		echo json_encode($data);
	}
	
	
	/**
	 Industry Trail
	 */
	
	/**
	 ID Project
	 */
}
