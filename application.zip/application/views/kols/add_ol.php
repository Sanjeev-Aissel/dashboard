<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
$currentMethod = $this->uri->segment(2);
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery-ui-1.8.16/ui/jquery.ui.accordion',
    'jquery/jquery.validate1.9.min');

// add the JS files into queue i.e Append to the existing queue
$prevjs = $this->config->item('js_files_to_load');
if ($prevjs == null)
    $prevjs = array();
$this->config->set_item('js_files_to_load', array_merge($prevjs, $queued_js_scripts));
?>
<script src="<?php echo base_url(); ?>js/jquery/jquery.maskedinput.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/chosen.jquery.js"></script>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">

<style type="text/css">
   
    
    #contents{
        text-align:left;
        font-size:110%;
        padding-left:150px;
    }

    #kol_form table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
        font-weight: bold;
        color: #222222;
    }

    #kol_form td label{
        display: block;
        text-align:right;
        padding-right:6px;
        padding-top:2px;
    }

    h1{
        color:#2E6E9E;
        font-size:170%;
        margin-bottom:10px;
        margin-top:15px;
    }

    #kol_form{
        width: 85%;
        margin: auto;
    }

    #kol_form input[type='text']{
        width: 200px;
    }

    #kol_form select{
        width: 210px;
    }

    .contact_restrictions label {
        display: inline-block !important;
        width: 150px;
    }
    .contact_restrictions td {
        text-align: center;
    }

    #kol_form .error {
        /* background-image: url(../images/error_medium.gif); */
        background-position: 10px center;
        background-repeat: no-repeat;
        padding: initial !important;
        display: inline;
    }
    #kol_form .error, #kol_form .notice, #kol_form .success {
        padding: .8em;
        background:transparent !important;
        margin-bottom: 0em !important;
    }
    .postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    
</style>
<script type="text/javascript">

    function selectPhone() {
            var  phoneVal= document.getElementById("phone_type").value;
            if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")){
                $("#phone_number_loc").mask("(999) 999-9999");
            }
            else if(phoneVal=="Office Phone"){
                $("#phone_number_loc").mask("(999) 999-9999? x99999");
            }
            else{
                $("#phone_number_loc").unmask();
            }
    }    
    var validationRules = {
        first_name: {
            required: true
        },
        last_name: {
            required: true
        },
        /*
        prof_suffix: {
            required: true
        },
        */
        specialty: {
            required: true
        },
        address1: {
            required: true
        },
        country_id: {
            required: true
        },
        /*
        postal_code: {
            required: true
        },
        */
        city_id: {
            required: true
        },
        organization: {
            required: true
        },
        email: {
            officialemail: true
        },
        npi_num: {
            npinumber: true
        },
        phone_number_loc: {
            phnumber : true
        	//number: true,
        	//maxlength: 15
        }
    };
    var validationMessages = {
        first_name: {
            required: "Required"
        },
        last_name: {
            required: "Required"
        },
        /*
        prof_suffix: {
            required: "Required"
        },
        */
        specialty: {
            required: "Required"
        },
        address1: {
            required: "Required"
        },
        country_id: {
            required: "Required"
        },
        /*
        postal_code: {
            required: "Required"
        },
        */
        city_id: {
            required: "Required"
        },
        organization: {
            required: "Required"
        },
        npi_num: {
            npinumber: "Enter 10-digit NPI number"
        }
        
    };
    $(function () {
        $("#kol_form").validate({
            debug: true,
            onkeyup: true,
            rules: validationRules,
            messages: validationMessages
        });

        jQuery.validator.addMethod("officialemail", function (value, element) {
            if (value != "") {
                var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                return regex.test(value);
            } else {
                return true;
            }
        }, "Invalid email");

        jQuery.validator.addMethod("npinumber", function (value, element) {
            if (value != "") {
                var regex = /^([0-9]){10}$/;
                return regex.test(value);
            } else {
                return true;
            }
        }, "Invalid NPI Number");
           
        var phoneMsg = '';
        jQuery.validator.addMethod("phnumber", function (value, element) {  
        	      	                            
            if (value != "") {
            	var  phoneVal= document.getElementById("phone_type").value;
            	alert(phoneVal);
               	if((phoneVal=="Cell")||(phoneVal=="Fax")||(phoneVal=="Answering Service")||(phoneVal=="Office Phone")){
	                var regex =/^(?=.*[0-9])[-+0-9]+$/;     
	                if(regex.test(value)){                	
	                	var number = value.replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing                	                	
	                	if(number.length>15){
	                		phoneMsg ="Max 15 Digit";
	                    	return false;
	                	}	
	                	phoneMsg = '' ;               	
	                	return true;                	    	
	                }else{
	                	phoneMsg ="Invalid Phone Number";	               		
	                 	return false;
	                }               	
               	}else{  
               		if(phoneVal==''){            		
               			phoneMsg = 'Select Phone Type';		
                   		return false;
                   	}
               		phoneMsg = '' ;
                   	return true;
                }
            } else {            	
                return true;
            }
            
        }, function(params, element) {
        	  return phoneMsg;
        });     

        $('#products').chosen({
            placeholder_text: "Click to Select Products",
            allow_single_deselect: true
        });
        $('#prof_suffix').chosen({
            placeholder_text: "Click to Select Suffix",
            allow_single_deselect: true
        });

        $('#sub_specialty').chosen({
            placeholder_text: "Click to Select Sub Specialty",
            allow_single_deselect: true
        });
        
         $('#is_speaker_product').chosen({
            placeholder_text: "Click to Select Speaker Product",
            allow_single_deselect: true
        });

    });

    /**
     * Returns the list of States of the Selected Country ID
     */
    function getStatesByCountryId() {
    	$("#postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingStates").show();
        var countryId = $('#country_id').val();
        var params = "country_id=" + countryId;
        $("#state_id").html("<option value=''>-- Select State --</option>");
        $("#city_id").html("<option value=''>-- Select City --</option>");
        var states = document.getElementById('state_id');
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                $.each(responseText, function (key, value) {
                    var newState = document.createElement('option');
                    newState.text = value.state_name;
                    newState.value = value.state_id;
                    var prev = states.options[states.selectedIndex];
                    states.add(newState, prev);
                });
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
            },
            complete: function () {
                $("#loadingStates").hide();
            }
        });
    }

    /**
     * Returns the list of Cities of the Selected State
     */
    function getCitiesByStateId() {
    	$("#postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingCities").show();
        var stateId = $('#state_id').val();
        $("#city_id").html("<option value=''>-- Select City</option>");
        var cities = document.getElementById('city_id');
        var params = "state_id=" + stateId;
        if(stateId == ''){
			$("#loadingCities").hide();
			return false;
		}
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                if(responseText==''){
                    $('#cityDiv').html('');
                    $('#cityDiv').html('<input type="text" name="city_id" id="city_id" class="required" placeholder="Enter City" />');
                }else{
                    $('#cityDiv').html('');
                	$('#cityDiv').html('<select name="city_id" id="city_id" class="required" placeholder="Enter City"><option value="">-- Select City --</option></select>');                   
                	setTimeout(function(){ 	
                        $.each(responseText, function (key, value) {                	
                           /* var newCity = document.createElement('option');
                            newCity.text = value.city_name;
                            newCity.value = value.city_id;
                            var prev = cities.options[cities.selectedIndex];
                            cities.add(newCity, prev);*/
                            $('#city_id').append("<option value='"+value.city_id+"'>"+value.city_name+"</option>");
                        });
                        $("#city_id option[value='']").remove();
                        $("#city_id").prepend("<option value=''>-- Select City --</option>");
                        $("#city_id").val("");
                	}, 30);
                }
            },
            complete: function () {
                $("#loadingCities").hide();
            }
        });
    }

    // Autocomplet Options for the 'Organizer' field 
    var organizationNameAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names',
<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    //selText = selText.replace(/\&amp;/g, '&');
                    $('#organization').val(selText);
                    $('#org_institution_id').val(selId);
                    $('#org_institution_id').val(selId).trigger('change');
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#organization').val(trim(split(' ', selText)[4]));
                            return false;
                        } else {
                            //doSearchFilter1( - 1);
                        }
                    } else {
                        //doSearchFilter1( - 1);
                    }
                }
    };
    $(document).ready(function () {
          $('#private_practice').change(function() {
        if ($(this).prop('checked')) {
             $("#organization").removeClass("autocompleteInputBox"); //checked
        }
        else {
          $("#organization").addClass("autocompleteInputBox"); //not checked
        }
    });
      

        var count="<?php echo count($arrSelectedSepakerProducts) ?>";
        var isYes="<?php echo $arrKolData['is_speaker'] ?>";
        if(count==0 && isYes!=1)
         $("#speaker_product").hide();
         // Add the "focus" value to class attribute 
  $('#visit').focusin( function() {
     
    $(this).addClass('focus');
  }
  );

  // Remove the "focus" value to class attribute 
  $('#visit').focusout( function() {
    $(this).removeClass('focus');
  }
  );
  var changeAutoComplete = 0;
  var attr = $("#org_type").attr('disabled');
	if (typeof attr !== typeof undefined && attr !== false) {
		changeAutoComplete = 1;
	}
        $('#org_institution_id').change(function () {
//            alert("here");
            OrgId = $(this).val();
            $.ajax({
                url: '<?php echo base_url() ?>organizations/getOrgDetails/' + OrgId,
                type: 'POST',
                dataType: 'JSON',
                success: function (returnData) {

//                  $('#keyInsightName option').remove();
//                    $('#keyInsightName').append('<option value="select">Select key Insight Name</option>');
                    for (var result in returnData) {
//                     alert(returnData[result].city_id);
                        $("#country_id").val(returnData[result].country_id);
                        $("#address1").val(returnData[result].address);
                        $("#postal_code").val(returnData[result].postal_code);
                        $("#state_id").val(returnData[result].state_id);
                        if(returnData[result].type_id > 0){
    						$("#org_type").prop('selectedIndex',returnData[result].type_id);	
    						$("#org_type").prop('disabled', 'disabled');
    						$("#org_type").css('background-color','#ccc');
    						changeAutoComplete = 1;
                        }else{
    						$("#org_type").prop('disabled', '');
    						$("#org_type").css('background-color','#fff');
                        }
                        var stateId = $('#state_id').val();
                        if(stateId != ''){
	                        $("#city_id").html("<option value=''>-- Select City</option>");
	                        var cities = document.getElementById('city_id');
	                        var params = "state_id=" + stateId;
	                        $("#loadingCities").show();
	                        $.ajax({
	                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
	                            dataType: "json",
	                            data: params,
	                            type: "POST",
	                            success: function (responseText) {
	                                $.each(responseText, function (key, value) {
	
	                                    var newCity = document.createElement('option');
	                                    newCity.text = value.city_name;
	                                    newCity.value = value.city_id;
	                                    var prev = cities.options[cities.selectedIndex];
	                                    cities.add(newCity, prev);
	                                });
	
	                                $("#city_id").val(returnData[result].city_id);
	                            },
	                            complete: function () {
	                                $("#loadingCities").hide();
	                            }
	                        });
                    	}

                    }

                }
            });
            //fire your ajax call  
        });
		$("#organization").keypress(function(){
		    if(changeAutoComplete == 1){
		    	$("#org_type").prop('disabled', '');
				$("#org_type").css('background-color','#fff');
				$("#org_institution_id").val('');
			}
		});
        // Trigger the Autocompleter for 'organizer' field of  Event'
        a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);

        //------------------- Start of Postal code focusout ----------
        $("#postal_code").on("focusout",function(){
        	$("#postal_code").parent().find("label.error").remove();
            var postalEle = $(this);
			var postalCode = $(this).val();
			if(postalCode != ''){
				$("#loadingStates").show();
				$.ajax({
		            url: '<?php echo base_url() ?>country_helpers/get_zip_code_details/'+postalCode,
		            type: 'post',
		            dataType: 'json',
		            success: function (returnData) {
		            	$(postalEle).parent().find("label.error").remove();
		              if(returnData.status == 1){
						$("#country_id").val(returnData.details.country_id);

						$("#loadingStates").show();
				        var countryId = $('#country_id').val();
				        var params = "country_id=" + countryId;
				        $("#state_id").html("<option value=''>-- Select State --</option>");
				        $("#city_id").html("<option value=''>-- Select City --</option>");
				        var states = document.getElementById('state_id');
				        $.ajax({
				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
				            dataType: "json",
				            data: params,
				            type: "POST",
				            success: function (responseText) {
				                $.each(responseText, function (key, value) {
				                    var newState = document.createElement('option');
				                    newState.text = value.state_name;
				                    newState.value = value.state_id;
				                    var prev = states.options[states.selectedIndex];
				                    states.add(newState, prev);
				                });
				                $("#state_id option[value='']").remove();
				                $("#state_id").prepend("<option value=''>-- Select State --</option>");
				                $("#state_id").val("");
				            },
				            complete: function () {
				                $("#loadingStates").hide();
				                $("#state_id").val(returnData.details.region_id);
								//$("#city_id").val(returnData.details.city_id);
								var stateId = $('#state_id').val();
		                        $("#city_id").html("<option value=''>-- Select City</option>");
		                        var cities = document.getElementById('city_id');
		                        var params = "state_id=" + stateId;
		                        $("#loadingCities").show();
								 $.ajax({
		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
		                            dataType: "json",
		                            data: params,
		                            type: "POST",
		                            success: function (responseText) {
		                                $.each(responseText, function (key, value) {

		                                    var newCity = document.createElement('option');
		                                    newCity.text = value.city_name;
		                                    newCity.value = value.city_id;
		                                    var prev = cities.options[cities.selectedIndex];
		                                    cities.add(newCity, prev);
		                                });

		                                $("#city_id").val(returnData.details.city_id);
		                            },
		                            complete: function () {
		                                $("#loadingCities").hide();
		                            }
		                        });				                
				            }
				        });
						
	                        //if(returnData.details.city_id == ''){}
						 	//	$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
			          }else{
			        	  	$('#state_id').prop('selectedIndex',0);
				          	$('#city_id option[value!=""]').remove();
				          	$('#country_id').prop('selectedIndex',0);
						//	$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
				      }
		            },
		            complete: function () {
                        $("#loadingStates").hide();
                    }
		        });
			}
        });
		// ------------------- End of Postal code focusout ----------


        //-------------------- Start of Duplicate check on specialty change ----------------------
        $("#specialty").on("focusout",function(){
  			var specialtySelected = $(this).val();
  			if(specialtySelected != ''){
  				//$("#loadingStates").show();
  				$.ajax({
  		            url: '<?php echo base_url() ?>kols/check_duplicate_ol/1',
  		            type: 'post',
  		            dataType: 'json',
  		          	data: $('#kol_form').serialize(),
  		            success: function (returnData) {
  		              if(returnData.duplicate_found == 1){
  	  		              //alert(returnData.dupHtml);
  	  		              $("#micro .profileContent").html(returnData.dupHtml);
  	  		          		$("#micro").dialog("open");
  	  		          		return false;
  		              }else
  		            	$("#is_duplicate_case").val("0");
  		            }
  				});
  			}
        });
		//-------------------- End of Duplicate check on specialty change ----------------------

        $("#organization").on("input",function(){
  			var textSTring = $(this).val();
  			if(textSTring == ''){
				$("#org_institution_id").val('');
  	  		}
        });

        var addNewKol = {
				title: "Add HCP",
				modal: true,
				autoOpen: false,
				width: 600,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#micro").dialog(addNewKol);
		
                
    });

    function checkDuplicatesAndSave(){
    	if (!$("#kol_form").validate().form()) {
    		 $('html, body').animate({
                 scrollTop: $("#kol_form .error").first().offset().top-30
             });
    		 $("#kol_form .error").first().focus();
            return false;
        }
  		var specialtySelected = $("#specialty").val();
  		if(specialtySelected != ''){
  			//$("#loadingStates").show();
  			$.ajax({
  	            url: '<?php echo base_url() ?>kols/check_duplicate_ol/2',
  	            type: 'post',
  	            dataType: 'json',
  	          	data: $('#kol_form').serialize(),
  	            success: function (returnData) {
  	              if(returnData.duplicate_found == 1){
    		              //alert(returnData.dupHtml);
    		              $("#micro .profileContent").html(returnData.dupHtml);
    		          		$("#micro").dialog("open");
    		          		return false;
  	              }else{
  	            	$("#is_duplicate_case").val("0");
  	            	saveKol();
  	  	          }
  	            }
  			});
  		}
    }

    function saveKol() {
        if (!$("#kol_form").validate().form()) {
        	$('html, body').animate({
                scrollTop: $("#kol_form .error").first().offset().top-30
            });
   		 $("#kol_form .error").first().focus();
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_ol',
            type: 'post',
            dataType: 'json',
            data: $('#kol_form').serialize(),
            success: function (returnData) {
                if (returnData.status == true) {
                    $('.msgBox').html('<?php echo lang("HCP");?> data saved successfully');
                    $('.msgBox').fadeOut(1500);
                    window.location = "<?php echo base_url() ?>kols/view/" + returnData.id;
                } else if (returnData.is_duplicate) {
                    $('.msgBox').fadeOut();
                    jConfirm("Duplicate Entry Found. Do you want to proceed and save similar record??", "Please confirm", function (r) {
                        if (r) {
                            $('.msgBox').html('Saving data....');
                            $.ajax({
                                url: '<?php echo base_url() ?>kols/save_ol/1',
                                type: 'post',
                                dataType: 'json',
                                data: $('#kol_form').serialize(),
                                success: function (returnData) {
                                    if (returnData.status) {
                                        $('.msgBox').html('<?php echo lang("HCP");?> data saved successfully');
                                        $('.msgBox').fadeOut(1500);
                                        window.location = "<?php echo base_url() ?>kols/view/" + returnData.id;
                                    } else {
                                        $('.msgBox').html('Error saving HCP data');
                                        $('.msgBox').fadeOut(1500);
                                    }
                                }
                            });
                        } else {
                            return false;
                        }
                    });
                } else {

                    $('.msgBox').html('Error saving HCP data');
                    $('.msgBox').fadeOut(1500);
                }
            }
        });
    }

    function proceedToAdd1(){
    	$("#micro").dialog("close");
    	$("#is_duplicate_case").val("1");
    }
    function proceedToAdd2(){
    	$("#micro").dialog("close");
    	$("#is_duplicate_case").val("1");
    	saveKol();
    }
    
       function showSpeakerProduct(thisEle){
        if($(thisEle).val()==1){
            $("#speaker_product").show();
        }
        else
            $("#speaker_product").hide();
            
    }

    function changeAutoComplete(){
    	var orgType = $('#org_type').find(":selected").text();
    	if(orgType == 'Private Practice'){
        	$('#private_practice').val('1');
			//$('#organization').removeClass('autocompleteInputBox');
        }else{
        	$('#private_practice').val('0');
        	//$('#organization').addClass('autocompleteInputBox');
        }
    }
</script>

<div class="msgBox"></div>

<form id="kol_form" name="kol_form" action="save_kol" method="post">
<?php //pr($arrKolData);
   // pr($arrLocationData);?>
    <?php
    if ($currentMethod == "edit_ol") {
        ?>
        <input type="hidden" name='profile_type' value="<?php echo $arrKolData['profile_type'];?>"/>
        <input type="hidden" name="kol_id" value="<?php echo $arrKolData['id']; ?>"/>
        <?php
    }else{
    ?>
    	<input type="hidden" name='profile_type' value=""/>
		<input type="hidden" name="kol_id" value=""/>
		<input type="hidden" name="is_duplicate_case" value="0" id="is_duplicate_case"/>
    <?php }?>
    <table>
        <caption>
            <?php
//                pr($arrKolData);
            if ($currentMethod == "edit_ol") {
                echo "Edit HCP";
            } else {
                echo "Add New HCP";
            }
            ?>
        </caption>
        <tr>
            <td style="width: 50%;"><?php // pr($arrLocationData);          ?>
                <table>
<!--                    <tr>
                        <td><label for="compliance_flag">Do Not Call :</label></td>
                        <td><input type="checkbox" name="compliance_flag" id='compliance_flag' 
                    <?php
                    if ($currentMethod == "edit_ol") {
                        if ($arrKolData['compliance_flag'] == "1")
                            echo 'checked';
                    }
                    ?>
                                   />
                        </td>
                    </tr>-->
                    <tr>
                        <td><label for = "first_name">First Name<span class = "required">*</span> :</label></td>
                        <td><input type = "text" name = "first_name" id = 'first_name' class = "required" value='<?php
                            if ($currentMethod == "edit_ol") {
                                echo $arrKolData['first_name'];
                            }
                            ?>'/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "middle_name">Middle Name :</label></td>
                        <td><input type = "text" name = "middle_name" id = 'middle_name' value='<?php
                            if ($currentMethod == "edit_ol") {
                                echo $arrKolData['middle_name'];
                            }
                            ?>'/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "last_name">Last Name<span class = "required">*</span> :</label></td>
                        <td><input type = "text" name = "last_name" id = 'last_name' class = "required" value='<?php
                            if ($currentMethod == "edit_ol") {
                                echo $arrKolData['last_name'];
                            }
                            ?>'/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "prof_suffix">Professional Suffix :</label></td>
                        <td>
                        	<select class="chosenMultipleSelect" multiple="multiple"  name = "prof_suffix[]" id = 'prof_suffix'>
                            
                                <?php                               
                                foreach ($arrProfessionalSuffixes as $suffix) {
                                    ?>
                                    <option value="<?php echo $suffix['suffix']; ?>" 
                                        <?php
                                        if ($currentMethod == "edit_ol") {
                                            $found = array_search($suffix['suffix'], $selectedSuffixes);                                            
                                            if ($found!==false)
                                                echo 'selected';
                                        }
                                        ?>
                                    ><?php echo $suffix['suffix']; ?></option>
                                  
                                <?php } ?>   
                            </select>                            
                        </td>
                    </tr>
<!--                    <tr>
                        <td><label for = "degree_id">Degree :</label></td>
                        <td>
                            <select name = "degree_id" id = 'degree_id'>
                                <option value = ""> --Select--</option>
                                <?php
                                foreach ($arrDegrees as $degree) {
                                    ?>
                                    <option value="<?php echo $degree['id']; ?>" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        if ($arrKolData['degree_id'] == $degree['id'])
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $degree['degree']; ?></option>
                                            <?php
                                        }
                                        ?>                               
                            </select>
                        </td>
                    </tr>-->
                    <tr>
                        <td><label for = "title">Title :</label></td>
                        <td>                        	
                            <select name = "title" id = 'title'>
                                <option value = ""> --Select--</option>
                                <?php
                                foreach ($arrTitles as $title) {
                                    ?>
                                    <option value="<?php echo $title['id']; ?>" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        if ($arrKolData['title'] == $title['id'])
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $title['title']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "specialty">Specialty<span class = "required">*</span> :</label></td>
                        <td>
                            <select name = "specialty" id = 'specialty' class = "required">
                                <option value = ""> --Select--</option>
                                <?php
                                foreach ($arrSpecialties as $key => $value) {
                                    ?>
                                    <option value="<?php echo $key; ?>"  <?php
                                    if ($currentMethod == "edit_ol") {
                                        if ($arrKolData['specialty'] == $key)
                                            echo 'selected';
                                    }
                                    ?>><?php echo $value; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "sub_specialty">Sub Specialty:</label></td>
                        <td>
                            <select class="chosenMultipleSelect" multiple="multiple" id="sub_specialty" name="sub_specialty[]">
                                <option value = ""> --Select--</option>
                                	<?php
                                		foreach ($arrSpecialties as $key => $value) {
                                    ?>
	                                    <option value="<?php echo $key; ?>"
	                                    	<?php 
	                                    	if ($currentMethod == "edit_ol") {
	                                    		if ($arrkolSubSpecialty[$key] == $key)
	                                    			echo 'selected';
	                                    	}
	                                    	?>
	                                    ><?php echo $value; ?></option>
									<?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <!-- <td><label for="fma_specialty_id">FMA Specialty :</label></td>
                        <td>
                            <select name="fma_specialty_id" id='fma_specialty_id'>
                                <option value="">--Select--</option>
                                <?php
                                foreach ($arrSpecialties as $key => $value) {
                                    ?>
                                    <option value="<?php echo $key; ?>" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        if ($arrKolData['fma_speciality_id'] == $key)
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $value; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr> -->
                </table>
            </td>

            <td style="width: 50%;">
                <table>
                    <tr>
                        <td><label for="npi_num">NPI Number :</label></td>
                        <td>
                            <input type="text" name="npi_num" id='npi_num' value='<?php
                            if ($currentMethod == "edit_ol") {
                                echo $arrKolData['npi_num'];
                            }
                            ?>'/>

                        </td>
                    </tr>
                    <tr>
                        <td><label for="additional_role_id">Additional Role :</label></td>
                        <td>
                            <select name="additional_role_id" id='additional_role_id'>
                                <option value="">--Select--</option>
                                <?php
                                foreach ($arrAdditionalRoles as $role) {
                                    ?>
                                    <option value="<?php echo $role['id']; ?>" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        if ($arrKolData['additional_role_id'] == $role['id'])
                                            echo 'selected';
                                    }
                                    ?>
                                            ><?php echo $role['role_name']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <!--<td><label for="product_id">Product :</label></td>-->
                        <td><label for="products">Product :</label></td>
                        <td>
<!--                            <select name="product_id" id='product_id'>
                                <option value="">--Select--</option>

                            <?php
                            foreach ($arrProducts as $product) {
                                ?>
                                  <option value="<?php echo $product['id']; ?>" 
                                <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['product_id'] == $product['id'])
                                        echo 'selected';
                                }
                                ?>
                                                    ><?php echo $product['name']; ?></option>
                                <?php
                            }
                            ?>
                            </select>-->

                            <?php
//                            $selUsers = explode(',', $arrNotification['users']);
//                        pr($arrkolProducts);
                            ?>
                            
                            <select class="chosenMultipleSelect" multiple="multiple"  name="products[]" id="products">
                            
                                <?php
                                foreach ($arrProducts as $product) {
                                    ?>
                                    <option value="<?php echo $product['id']; ?>" 
                                    <?php
                                    if ($arrkolProducts) {
                                        foreach ($arrkolProducts as $kolProduct) {
                                            if ($product['id'] == $kolProduct['id'])
                                                echo 'selected';
                                        }
                                    }
                                    ?> 
                                            ><?php echo $product['name']; ?></option>
                                            <?php
                                        }
                                        ?>
                            </select>

                        </td>
                    </tr>
                    <tr>
                        <td><label for="patients_range">Range Of Patients Seen :</label></td>
                        <td>
                            <select name="patients_range" id='patients_range'>
                                <option value="">--Select--</option>
                                <option value="0" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['patients_range'] == "0")
                                        echo 'selected';
                                }
                                ?>
                                        >0</option>
                                <option value="1-5" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['patients_range'] == "1-5")
                                        echo 'selected';
                                }
                                ?>
                                        >1-5</option>
                                <option value="6-10" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['patients_range'] == "6-10")
                                        echo 'selected';
                                }
                                ?>
                                        >6-10</option>
                                <option value="11-20" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['patients_range'] == "11-20")
                                        echo 'selected';
                                }
                                ?>
                                        >11-20</option>
                                <option value="25+" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['patients_range'] == "25+")
                                        echo 'selected';
                                }
                                ?>
                                        >25+</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="email">Email :</label></td>
                        <td><input type="text" name="email" id="email" value='<?php
                            if ($currentMethod == "edit_ol") {
                                echo $arrKolData['primary_email'];
                            }
                            ?>'/></td>
                    </tr>
                    <tr>
                        <td><label for="is_speaker">Speaker :</label></td>
                        <td>
                            <select  name="is_speaker" onchange="showSpeakerProduct(this)" id='is_speaker'>
                                <option value="">--Select--</option>
                                <option value="1" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['is_speaker'] == "1")
                                        echo "selected";
                                }
                                ?>>Yes</option>
                                <option value="0" <?php
                                if ($currentMethod == "edit_ol") {
                                    if ($arrKolData['is_speaker'] == "0")
                                        echo "selected";
                                }
                                ?>>No</option>
                            </select>
                        </td>
                    </tr>
                      <tr id="speaker_product"  >
                        <td><label for="is_speaker_product">Speaker Program :</label></td>
                        <td>
                            <select  class="chosenMultipleSelect" multiple="multiple"  name="speaker_products[]"   id='is_speaker_product'>
                                <?php
                                foreach($arrSepakerProducts as $values){
                                     if ($currentMethod != "edit_ol")
                                        echo "<option value='".$values['id']."'>".$values['name']."</option>";
                                     else{
                                         foreach($arrSelectedSepakerProducts as $value){
                                             if($values['id']==$value['product_id'])
                                                echo "<option selected value='".$values['id']."'>".$values['name']."</option>";
                                             
                                         }
                                          echo "<option value='".$values['id']."'>".$values['name']."</option>";
                                     }
                                     
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="is_kol"><?php echo lang('KOL'); ?> :</label></td>
                        <td><input type="checkbox" name="is_kol" id="is_kol" <?php
                            if ($currentMethod == "edit_ol") {
                                if ($arrKolData['is_kol'] == "1")
                                    echo "checked";
                            }
                            ?>/></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <h5>Contact Preferences</h5>
            </td>
        </tr>
        <!-- <tr class="contact_restrictions">
            <td style="width: 50%">
                <label for="visit">Visit :</label>
                <input type="checkbox" name="visit" id="visit" <?php
                if ($currentMethod == "edit_ol") {
                    if ($arrContactData['visit'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
            <td style="width: 50%">
                <label for="call">Call :</label>
                <input type="checkbox" name="call" id="call" <?php
                if ($currentMethod == "edit_ol") {
                    if ($arrContactData['call'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
        </tr>
        <tr class="contact_restrictions">
            <td style="width: 50%">
                <label for="fax">Fax :</label>
                <input type="checkbox" name="fax" id="fax" <?php
                if ($currentMethod == "edit_ol") {
                    if ($arrContactData['fax'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
            <td style="width: 50%">
                <label for="mail">Mail :</label>
                <input type="checkbox" name="mail" id="mail" <?php
                if ($currentMethod == "edit_ol") {
                    if ($arrContactData['mail'] == "1")
                        echo "checked";
                }
                ?>/>
            </td>
        </tr> -->
        <table>
        	<tr class="contact_restrictions">
	        	<td>
	        		<label for="visit">Visit :</label>
	                <input type="checkbox" name="visit" id="visit" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['visit'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
	        	<td>
	        		<label for="call">Call :</label>
	                <input type="checkbox" name="call" id="call" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['call'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
	        	<td>
	        		<label for="fax">Fax :</label>
	                <input type="checkbox" name="fax" id="fax" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['fax'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
        	</tr>
        	<tr class="contact_restrictions">
	        	<td>
	        		<label for="mail">Mail :</label>
	                <input type="checkbox" name="mail" id="mail" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['mail'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
	        	<td>
	        		<label for="mail">Text :</label>
	                <input type="checkbox" name="cr_text" id="cr_text" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['text'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
	        	<td>
	        		<label for="mail">Email :</label>
	                <input type="checkbox" name="cr_email" id="cr_email" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['email'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
        	</tr>
        	<tr class="contact_restrictions">
	        	<td>
	        		<label for="mail">Video Call :</label>
	                <input type="checkbox" name="cr_video_call" id="cr_video_call" <?php
	                if ($currentMethod == "edit_ol") {
	                    if ($arrContactData['video_call'] == "1")
	                        echo "checked";
	                }
	                ?>/>
	        	</td>
        	</tr>
        </table>
        <table>
            <caption>Address</caption>
            <tbody>
                <tr>
                    <td>
                        <table style="te">
                            <tr style="display: none;">
                                <td class="alignRight">
                                    <label for="isPrimary">Primary Address:</label>
                                </td>
                                <td>
                                    <input type="checkbox" name="is_primary"  checked/>
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight"><label for="org_institution_id">Institution<span class = "required">*</span> :</label></td>
                                <td>
                                    <input type="text" name="organization" class="autocompleteInputBox" id="organization" placeholder="Enter Institution" title=""
                                    <?php  
                                    
                                    if ($currentMethod == "edit_ol" && $arrLocationData['org_institution_name'] != "0") {
                                        echo 'value="' . $arrLocationData['org_institution_name'] . '"';
                                    }
                                    else{
                                        echo 'value="' . $arrLocationData['private_practice'] . '"';
                                    }
                                    ?>
                                           />
                                    <input type="hidden" name="org_institution_id" id="org_institution_id" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        echo 'value="' . $arrLocationData['org_institution_id'] . '"';
                                    } else {
                                        echo 'value=""';
                                    }
                                    ?>
                                           />
                                    <input type="hidden" name="location_id" id="location_id" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        echo 'value="' . $arrLocationData['id'] . '"';
                                    } else {
                                        echo 'value=""';
                                    }
                                    ?>
                                           />
                                </td>
                            </tr>
                              <tr>
                              	<td><label for = "title">Institution Type :</label></td>
		                        <td>
		                        	<input type="hidden" name="private_practice" id="private_practice" value="1"/>                      	
		                            <select name = "org_type" id = 'org_type' onchange="changeAutoComplete();"
		                            <?php 
			                            if ($currentMethod == "edit_ol") {
			                            	if (!empty($orgTypeId))
			                            		echo "disabled";
			                            		echo " style='background-color: #ccc;'";
			                            }		                            
		                            ?>
		                            >
		                                <option value = ""> --Select--</option>
		                                <?php
		                                	foreach ($arrOrganizationTypes as $key => $value) {
		                                ?>
		                                <option value="<?php echo $key; ?>"
		                                <?php 
			                                if ($currentMethod == "edit_ol") {
			                                	if (!empty($orgTypeId) && $orgTypeId == $key)
			                                		echo "selected";
			                                }
		                                ?>
		                                ><?php echo $value; ?></option>
		                                <?php
		                                    }
		                                ?>
		                            </select>
		                        </td>
                                <!-- <td class="alignRight"><label for="private_practice">Private Practice :</label></td>
                        		<td><input type="checkbox" name="private_practice" id="private_practice" value="1" <?php
		                            if ($currentMethod == "edit_ol") {
		                                if (!empty($arrLocationData['private_practice']))
		                                    echo "checked";
		                            }
		                            ?>/>
		                        </td> -->
                            </tr>
                            <tr>
                                <td class="alignRight"><label for="address1">Address Line 1<span class="required">*</span>:</label></td>
                                <td>
                                    <input type="text" name="address1" id="address1" maxlength="50" class="required" 
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        echo 'value="' . $arrLocationData['address1'] . '"';
                                    }
                                    ?>></input>
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">
                                    <label for="address2">Address Line 2 :</label>
                                </td>
                                <td>
                                    <input type="text" name="address2" id="address2"  maxlength="50"
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        echo 'value="'.$arrLocationData['address2'].'"';
                                    }
                                    ?>></input>
                                </td>
                            </tr>
<!--                            <tr>
                                <td class="alignRight">
                                    <label for="address3">Address Line 3 :</label>
                                </td>
                                <td>
                                    <input type="text" name="address3" id="address3" maxlength="50"
                                    <?php
                                    if ($currentMethod == "edit_ol") {
                                        echo "value=" . $arrLocationData['address3'];
                                    }
                                    ?>></input>
                                </td>
                            </tr>-->
                            <!-- <tr>
                                <td class="alignRight">
                                    <label for="validation_status">Validation Status :</label>
                                </td>
                                <td>
                                <label style="text-align: left;"> <?php
                                    if (isset($locationData)) {
                                            echo $locationData['validation_status'];
                                        }  else 
                                            echo "New"; ?>
                                </label>
                                
        <input type="hidden" name="validation_status" value="<?php
                                    if (isset($locationData)) {
                                            echo $locationData['validation_status'];
                                        }  else 
                                            echo "New"; ?>"/>
                                </td>
                            </tr>-->
                        </table>
                    </td>

                    <td>
                        <table>
		
                            <!-- <tr>
                                <td class="alignRight">
                                    <label for="validated_address">Validated Address:</label>
                                </td>
                                <td>
                                    <label style="text-align: left;"><?php
                                        if ($currentMethod == "edit_ol") {
                                            if ($arrLocationData['validated_address'] == 1) {
                                                echo "Yes";
                                            }
                                        }
                                        ?></label>
                                </td>
                            </tr> -->
                            <tr>
                                <td class="alignRight">
                                    <label for="address_type">Address Type<span class="required">*</span> :</label>
                                </td>
                                <td>
                                    <label style="text-align: left;">Physical</label>
                                    <input type="hidden" name="address_type" value="Physical"/>
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">
                                    <label for="postal_code">Postal Code :</label>
                                </td>
                                <td>
                                    <input type="text" name="postal_code" id="postal_code"
                                    <?php
                                    if ($currentMethod == "edit_ol" && $arrLocationData['postal_code'] != "") {
                                        echo "value=" . $arrLocationData['postal_code'];
                                    }
                                    ?>
                                           />
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">
                                    <label for="country_id">Country<span class="required">*</span> :</label>
                                </td>
                                <td>
                                    <select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required">
                                        <option value="">-- Select Country --</option>
                                        <?php foreach ($arrCountries as $country) { ?>
                                            <option value="<?php echo $country['country_id']; ?>"
                                            <?php
                                            if ($arrLocationData['country_id'] == $country['country_id'])
                                                echo "selected";
                                            ?>

                                                    <?php
                                                    if ($currentMethod != "edit_ol" && $country['country_id'] == "254")
                                                        echo "selected";
                                                    ?>
                                                    >
                                                        <?php echo $country['country_name']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                    <img id="loadingStates" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">									
                                    <label for="state_id">State / Province :</label>
                                </td>
                                <td>
                                    <select name="state_id" id="state_id" onchange="getCitiesByStateId();">		
                                        <option value="">-- Select State --</option>
                                        <?php foreach ($arrStates as $state) { ?>
                                            <option value="<?php echo $state['state_id']; ?>"
                                            <?php
                                            if ($arrLocationData['state_id'] == $state['state_id'])
                                                echo "selected";
                                            ?>
                                                    >
                                                        <?php echo $state['state_name']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                    <img id="loadingCities" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">
                                    <label for="city_id">City<span class="required">*</span> :</label>
                                </td>
                                <td id="cityDiv">
                                    <select name="city_id" id="city_id" class="required">
                                        <option value="">-- Select City --</option>
                                        <?php
                                        foreach ($arrCities as $city) {
                                            echo '<option value="' . $city['city_id'] . '" ';
                                            if ($arrLocationData['city_id'] == $city['city_id'])
                                                echo "selected";
                                            echo '>' . $city['city_name'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="alignRight">
                                    <!--<label for="postal_extension">Postal Extension :</label>-->

                                    <label for="phone_type_loc">Phone Type :</label>
                                </td>
                                <td>
<!--                                    <input type="text" name="postal_extension" id="postal_extension"
                                    <?php
                                    if ($currentMethod == "edit_ol" && $arrLocationData['postal_extension'] != "") {
                                        echo "value=" . $arrLocationData['postal_extension'];
                                    }
                                    ?>
                                           />-->
                                           
                                    <select name="phone_type_loc" id="phone_type">
                                        <option value="" <?php if ($arrLocationData['phone_type'] == "") echo "selected"; ?>>--Select--</option>
                                        <option value="Answering Service" <?php if ($arrLocationData['phone_type'] == "Answering Service") echo "selected"; ?>>Answering Service</option>
                                        <option value="Cell" <?php if ($arrLocationData['phone_type'] == "Cell") echo "selected"; ?>>Cell</option>
                                        <option value="Face Time" <?php if ($arrLocationData['phone_type'] == "Face Time") echo "selected"; ?>>Face Time</option>
                                        <option value="Fax" <?php if ($arrLocationData['phone_type'] == "Fax") echo "selected"; ?>>Fax</option>
                                        <!--<option value="Home Phone">Home Phone</option>-->
                                        <option value="Office Phone" <?php if ($arrLocationData['phone_type'] == "Office Phone") echo "selected"; ?>>Office Phone</option>
                                        <option value="Pager" <?php if ($arrLocationData['phone_type'] == "Pager") echo "selected"; ?>>Pager</option>
                                        <option value="Voice Mail" <?php if ($arrLocationData['phone_type'] == "Voice Mail") echo "selected"; ?>>Voice Mail</option>
                                        <option value="Web Address" <?php if ($arrLocationData['phone_type'] == "Web Address") echo "selected"; ?>>Web Address</option>
                                    </select>

                                </td>
                            </tr>
                            <tr>
                                <td class="alignRight">
                                    <!--<label for="postal_city">Postal City :</label>--><label for="phone_number_loc">Phone Number :</label>
                                </td>
                                <td>
<!--                                    <input type="text" name="postal_city" id="postal_city"
                                    <?php
                                    if ($currentMethod == "edit_ol" && $arrLocationData['postal_city'] != "") {
                                        echo "value=" . $arrLocationData['postal_city'];
                                    }
                                    ?>
                                           />-->                                        
                                    <input type="text" name="phone_number_loc" id="phone_number_loc" 
                                    <?php                                    
                                    if (isset($arrLocationData)) {
                                        if ($arrLocationData['phone_number'] != "") {
                                            echo 'value="' . $arrLocationData['phone_number'] . '"';
                                        }
                                    }
                                    ?>
                                   /> <span id="phoneError"></span>

                                </td>
                            </tr>

                        </table>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
<!--                        <input type="submit" value="Save" class="blueButton" rel="tooltip" data-original-title="Save KOL" id="save_kol" onclick="saveKol();"/>-->
                        <a class="blueButton" rel="tooltip" href="#" data-original-title="Save <?php echo lang("HCP");?>" id="save_kol" onclick="checkDuplicatesAndSave();">Save</a>
                        <?php
                        if ($currentMethod == "edit_ol") {
                            ?>

                            <a class="blueButton" rel="tooltip" href="<?php echo base_url(); ?>kols/view/<?php echo $arrKolData['id']; ?>" data-original-title="Cancel">Cancel</a>
                            <?php
                        } else {
                            ?>
                            <a class="blueButton" rel="tooltip" href="<?php echo base_url(); ?>kols/list_kols_client_view" data-original-title="Cancel">Cancel</a>
                        <?php } ?>
                    </td>
                </tr>

                <!-- End of Personal and Professional Information -->


            </tbody>
        </table>
        </tr>
    </table>
</form>
<div id="micro" class="microProfileDialogBox">
		<div class="microViewProfile profileContent"></div>
	</div>
