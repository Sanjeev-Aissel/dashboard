<?php
/**
*Description:
*
*Created by:Developer
*
*Created on:Dec 13, 2010
*/?>

		<style type="text/css">
			#contents{
				text-align:left;
				font-size:110%;
				padding-left:150px;
			}
			
			#contents label{
				float:left;
				width:150px;
				text-align:right;
				padding-right:6px;
				padding-top:2px;
			}
			
			h1{
				color:#2E6E9E;
				font-size:170%;
				margin-bottom:10px;
				margin-top:15px;
			}
		
		</style>

						<h1>Add New <?php echo lang("KOL");?> for Processing</h1>
						<p>Note: This is a temporary interface for the Demo. Later this will be replaced by the Import Job</p>
					 	 
					 	  <form action="save_kol" method="post" id="persnoalForm" name="persnoalForm">
					 		 <?php echo form_open('kols/save_kol');``?> 							  			
							  			
							  		<p>
										<label for="npiNum" style="font-size: 15px">Profile Type :</label>
										<input type="radio" name="profile_type" value="Full Profile" checked="checked">Full Profile</input>
										<input type="radio" name="profile_type" value="Basic Plus">Basic Plus </input>
										<input type="radio" name="profile_type" value="Basic">Basic</input>
										<a href="http://support.aisselkolm.com/solution/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile-" target="_NEW">Compare</a>
							  		</p>
							  		<p><label>Salutation</label>
							   			<select name="salutation" >
								   			<option value="0">--- Select ---</option>
											<?php 
												foreach($arrSalutations as $key => $value){
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
							    		</select>
							    	</p>

								    <p>
								    	<label for="gender">Gender</label>
								   		<select name="gender" id="gender">
								     		<option value="Male">Male</option>
								     		<option value="Female">Female</option>
								    	</select>
							    	</p>
								   
								  	<p>
										<label for="">First Name</label>
							       		<input type="text" name="first_name" id="first_name" value="" maxlength="50"></input></p>
								   
								    <p>
							    		<label for="middle_name">Middle Name</label>
						       			<input type="text" name="middle_name" id="middle_name" value=""  maxlength="50"></input>
						       		</p>
								       
								       
								   	<p>
							   			<label for="last_name">Last Name</label>
							       		<input type="text" name="last_name" id="last_name" value=""  maxlength="50"></input></p>
								       
								    <p>
								    	<label for="suffix"">Suffix</label>
										<input type="text" name="suffix" id="suffix" value="" maxlength="50" />
									</p>
								    	
								  	<p>
								  		<label for="specialty">Specialty</label>
								   		<select name="specialty" id="specialty">
								   			<option value="0">--- Select ---</option>
											<?php 
												foreach($arrSpecialties as $key => $value){
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
								    	</select>
								    </p>
								    	
								    <p>
										<label for="orgName">Organization Name</label>
										<input type="text" name="org_id" id="orgName" value=""></input>
									</p> 
									 
									 <p>
										<label for="npiNum">NPI Num</label>
										<input type="text" name="npi_num" id="npiNum" value=""></input>
									</p>
								    
								    <div class="formButtons">	
			 		       				 <input type="submit" value="Save" name="submit"></input>
			 		    			</div>
								    
						 </form>
	               
					<!-- End of Personal and Professional Information -->