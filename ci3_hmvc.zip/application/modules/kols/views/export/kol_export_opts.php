<style>
.exportOpts{
    display: -webkit-inline-box;
    }
</style>
<script type="text/javascript">
    function selectAll(thisEle) {
        if($(thisEle).prop("checked") == true){
	         $('input[name="export_opts[]"]').attr("checked", "checked");
        }
        else if($(thisEle).prop("checked") == false){
	         $('input[name="export_opts[]"]').removeAttr("checked");
        }
    }
    function showNextPage() {
        var values = new Array();
        $.each($("input[name='export_opts[]']:checked"), function () {
            values.push($(this).val());
        });
        if (values == "") {
            alert("Please select atleast one checkbox to export");
            return false;
        }
        $('#exportform').submit();
    }
</script>
<form action="<?php echo base_url().'kols/kols/export_kol'; ?>" name="kolExportForm" method="post" id="exportform">
    <div id="selectionBox"> 
        <input  type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKols ?>"/>
        <table id="exportTable" border="0" class="table no_border">
            <tr>
                <td>
                    <input type="checkbox"  name="full_profile" value="full" onclick='selectAll(this);'/><label>Full Profile</label>
                </td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="professional" class="exportOpts"/>Prof Info
                </td>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="details" class="exportOpts"/>Details Info
                </td>
            </tr>
            <tr>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="biography" class="exportOpts"/>Biography
                </td>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="education" class="exportOpts"/>Education
                </td>
             </tr>
            <tr>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="affiliation" class="exportOpts"/>Affiliations
                </td>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="user_notes" class="exportOpts"/>User Notes
                </td>
            </tr>
            <tr>
                <td>
                    <input type="checkbox"  name="export_opts[]" value="media" class="exportOpts"/>Social Media
                </td>
                <td>
                <?php if($this->common_helper->check_module("events")){?>
                    <input type="checkbox"  name="export_opts[]" value="events" class="exportOpts"/>Events
                <?php }?>
                </td>
            </tr>
            <tr>
                <td>
                <?php if($this->common_helper->check_module("pubmeds")){?>
                    <input type="checkbox"  name="export_opts[]" value="publication" class="exportOpts"/>Publications
                <?php }?>
                </td>
                <td>
                <?php if($this->common_helper->check_module("clinical_trials")){?>
                    <input type="checkbox" name="export_opts[]" value="trial" class="exportOpts"/>Trials
                <?php }?>
                </td>
            </tr>
            <tr>
                <td colspan="3" class="align_center">
                <input type="button" name="next" value="Export" id="next" onclick="showNextPage();" class="btn custom-btn"/></td>
            </tr>
        </table>
    </div>
</form>