<form id="add_module_action">
			<div class="form-group row" id="">
					<label class="col-sm-4 col-form-label">Action-name:</label>
					<div class="col-sm-8">
						<input type="text" name="action_name" value="" id="action_name" class="form-control">
			    		<div id="role_action_duplicate" style="margin-top: 14px;">

		    			</div>
			    	</div>
			</div>
			<div class="form-group row">
					<label class="col-sm-4 col-form-label"></label>
			   		<div class="col-sm-8">
			     		<button type="submit" class="btn btn-primary" onclick="save_module_action();return false;">Save</button>    
			         	<button class="btn btn-primary" onclick="close_dialog();return false;">Cancel</button>
			    	</div>
			</div>
</form>
<script>
$("#add_module_action").validate({
	rules: {
		action_name: "required",
	},
	messages: {
		action_name: {
			required: "Please enter the action name",
	}
	}
});
</script>
