<?php
/**
*File To show clinical trials Advance search page.
*
*@author: Ambarish N
*@created on: 07-02-11
*/
?>

<div id="advSearchFieldsContainer">
	<div class="msgBoxContainer">
		<div class="advSearchMsgBox">
		</div>
	</div>
	<form action="<?php echo base_url()?>clinical_trials/adv_search_trials" name="advSearchForm" method="post" id="advSearchForm">
		<fieldset><legend>Trials Advanced Search</legend> 
		<p>
			<label>Intervention</label>
			<input type="text" name="interventions" id="interventions"/>
		</p>
		<p>
			<label>Condition</label>
			<input type="text" name="condition" id="condition"/>
		</p>
		<p>
			<label>Investigators</label>
			<input type="text" name="investigators" id="investigators"/>
		</p>
		<p>
			<label>MeshTerms </label>
			<input type="text" name="mesh_term" id="mesh_term"/>
		</p>
		<p>
			<label>Sponsors</label>
			<input type="text" name="sponsors" id="sponsors"/>
		</p>
		<input type="button" name="do_earch" id="doSearch" onclick="validateAdvSearchForm()" value="search"/>		
		</fieldset>
	</form>
</div>