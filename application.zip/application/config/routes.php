<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*require_once("/../libraries/mobile_device_detect.php");
$mobile = mobile_device_detect();*/
$user_agent       = $_SERVER['HTTP_USER_AGENT'];
$isMobileDevice = false;
if((preg_match('/ipad/i',$user_agent))){
	$isMobileDevice = true;
}

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| 	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['scaffolding_trigger'] = 'scaffolding';
|
| This route lets you set a "secret" word that will trigger the
| scaffolding feature for added security. Note: Scaffolding must be
| enabled in the controller in which you intend to use it.   The reserved 
| routes must come before any wildcard or regular expression routes.
|
*/

$route['default_controller'] = "login";
$route['scaffolding_trigger'] = "";


/**
 * Remapping the url with 'm' to 'mobile' controllers
 */
$route['m/register/(:any)'] = "mobile/register/campaign/$1";
$route['m/(:any)'] = "mobile/$1";
$route['i/(:any)'] = "ipad/$1";
$route['medintel'] = "media_intel_extractions/media_feature/";
$route['medintel/(:any)'] = "media_intel_extractions/media_feature/$1";
$route['m/medintel/(:any)'] = "mobile/media_intel_extractions/media_feature/$1";
$route['m/medintel'] = "mobile/media_intel_extractions/media_feature/";
$route['i/medintel'] = "ipad/media_intel_extractions/media_feature/";
$route['i/medintel/(:any)'] = "mobile/media_intel_extractions/media_feature/$1";

//iPad Reports routes
$route['i/reports/view_interaction_reports'] = "reports/view_interaction_reports";

$route['new_user_registration'] = "";
//$route['new_user_registration'] = "client_users/user_form";

//iPad detection for URLs from email.
if($isMobileDevice){
	$route['requested_kols/show_client_requested_kols'] = "ipad/requested_kols/show_client_requested_kols";
	$route['coachings/view_compliance/(:any)'] = "ipad/coachings/view_compliance/$1";
	
}
/**
 * Remapping the url for valid campaigns
 */
$route['register/save_user_registration_details'] = "register/save_user_registration_details";
$route['register/(:any)'] = "register/campaign/$1";
/* End of file routes.php */
/* Location: ./system/application/config/routes.php */