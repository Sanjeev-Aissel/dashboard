<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPwPj8G34QTdXihJzvRY4UJN2piezVAFY"></script>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<link href="<?php echo base_url().ASSETS;?>c3js/c3.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url().ASSETS;?>bootstrap_slider/bootstrap-slider.css" rel="stylesheet">
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'c3js/c3.min',
			'c3js/d3.c3.min',
			'jit/jit',
			'js/custom_js/jqgridExportToExcel',
			'modules/events/js/view_events',
			'bootstrap_slider/bootstrap-slider',
			'alerts/jquery.alerts'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>

<script type="text/javascript">
var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
var kolId = '<?php echo $arrKol['kols_client_visibility_id']?>'; 
var kol_unique_id 	= '<?php echo $arrKol['kols_client_visibility_unique_id']?>'; 
var subContentPage	= '<?php echo $subContentPage;?>';
var minYear='<?php echo $arrYearRange['min_year'];?>';
var maxYear='<?php echo $arrYearRange['max_year'];?>';
var customMarker = '<?php echo base_url().ASSETS;?>/images/image1.png';
var arrExcludeColumnsInExcelExport = new Array('micro','act'); 
var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by','is_analyst','first_name','last_name');	
$(document).ready(function(){
	setrangevalues();
	document.getElementById("showSliderRange").textContent=minYear+','+maxYear;
	var slider = new Slider('#yearRangeSlider',{});
	slider.on("slide", function(sliderValue) {
		document.getElementById("showSliderRange").textContent = sliderValue;
		loadSelectedChart();
	});
	loadSelectedChart();
});
</script>
<style>
#eventMap {
    position: relative;
    height: 320px;
}
</style>
<div style="margin:2% 0px;">
	<div style="display:inline;margin-left:2%;">
		<b>Year Range</b>(<b><span id="showSliderRange"></span></b>):
		<input id="yearRangeSlider" type="text" value="" data-slider-min="1990" data-slider-max="2018" data-slider-step="1" data-slider-value="[2000,2010]"/> 
	</div>
	<div class="pull-right">
	<?php if($subContentPage=='conference'){?>
		<a id="toggleConfGrouping" class="btn custom-btn" onclick="toggleEventGrouping('JQBlistConferenceResultSet','toggleConfGrouping');">Remove Group By Event Type</a>
	<?php }?>
	<?php if($role_permissions[$module_id]["add"]==1){?>
		<a class="btn custom-btn" href="<?php echo base_url().'events/events/add_client_event/'.$arrKol['kols_client_visibility_unique_id']?>">Add New Event</a>
	<?php }?>
	<?php if($subContentPage=='conference'){?>
		<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistConferenceResultSet','events');">
           <a href="#" rel="tooltip" data-original-title="Export Events Details into Excel format">&nbsp;</a>
        </div>
	<?php }?>
	</div>
</div>
<?php switch($subContentPage){
	case 'session_type':?><div class="pubChartContainer">
							<div class="row">
								<div class="col-sm-6">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Events by Timeline</h3>
									  </div>
									  <div class="panel-body">
										<div id="eventsChartByTimeline"></div>
									  </div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="panel panel-default">
										  <div class="panel-heading">
											<h3 class="panel-title">Events by Map</h3>
										  </div>
										  <div class="panel-body">
											<div id="eventMap"></div>
										  </div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-6">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Events by Sponsors</h3>
									  </div>
									  <div class="panel-body">
										<div id="eventsChartBySponsorType"></div>
									  </div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="panel panel-default">
										  <div class="panel-heading">
											<h3 class="panel-title">Events by Session Type</h3>
										  </div>
										  <div class="panel-body">
											<div id="eventsChartBySessionType"></div>
										  </div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-6">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Events by Topic</h3>
									  </div>
									  <div class="panel-body">
										<div id="eventsChartByTopic"></div>
									  </div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="panel panel-default">
										  <div class="panel-heading">
											<h3 class="panel-title">Events by Role</h3>
										  </div>
										  <div class="panel-body">
											<div id="eventsChartByRole"></div>
										  </div>
									</div>
								</div>
							</div>
							
						</div>
			<?php break;
			default:?><div id="conference">
						<div class="gridWrapper" id="confGridContainer">
							<table id="JQBlistConferenceResultSet"></table>
							<div id="listConferencePage"></div>
						</div>
					</div>
			<?php break;
			}?>