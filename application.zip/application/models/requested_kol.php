<?php 
/**
*Model for Clinical Trial operations
*
*@package application.models
*@author Ambarish N
*@since
*@created on 10-01-11
*/

class requested_kol extends Model{

	//Constructore
	function requested_kol(){
		parent::Model();
	}
	
	/**
	 * Set status as Approved 
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param $kolId
	 * @return Json data
	 * 
	 */
	function updateKolStatusAsApproved($arrKolsIds,$status,$approvedBy){
		$data['status'] = 	$status;
		$data['approved_by'] = $approvedBy;
		$data['modified_on'] = date("Y-m-d H:i:s");
		foreach($arrKolsIds as $kolId){
				$this->db->where('id',$kolId);
				$this->db->update('kols',$data);
			}
		
	}
	
	/**
	 * get client Maneger email id
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param $kolId
	 * @return Json data
	 * 
	 */
	function getClientManagerEmailId($cliientId){
		$email = array();
		$this->db->select('email');
		$this->db->where('client_id',$cliientId);
		$this->db->where('user_role_id',2);
		$emailResultSet = $this->db->get('client_users');
		foreach($emailResultSet->result_array() as $row){
			$email[] = $row;
		}
		
		return $email;
	}
	
	/**
	 * get client Analyst ManagerEmailId
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return $email
	 * 
	 */
	function getAnalystManagerEmailId(){
		$emails = array();
		$this->db->distinct();
		$this->db->select('email');
		$this->db->where('client_id',1);
		$this->db->where('user_role_id',2);
		$emailResultSet = $this->db->get('client_users');
		foreach($emailResultSet->result_array() as $row){
			$emails[] = $row['email'];
		}
		$emails = array_unique($emails);
		$arrEmails = array();
		foreach($emails as $email){
			$arrEmails[] = array('email' => $email);
		}
			 
		return $arrEmails;
	}
	
	/**
	 * get client Analyst ManagerEmailId
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return $email
	 * 
	 */
	function getUserEmailId($userId){
		$email = '';
		$this->db->select('email');
		$this->db->where('id',$userId);
	//	$this->db->where('user_role_id',2);
		$emailResultSet = $this->db->get('client_users');
		foreach($emailResultSet->result_array() as $row){
			$email=$row['email'];
		}
		return $email;
		
	}
	
	/**
	 * get Userid by KolId
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return $userId
	 * 
	 */
	function getRequestedUserId($kolId){
		$userId = '';
		$this->db->select('created_by');
		$this->db->where('id',$kolId);
		$resultSet = $this->db->get('kols');
		foreach($resultSet->result_array() as $row){
			$userId=$row['created_by'];
		}
		return $userId;
	}
	
	/**
	 * getKol datails
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return $userId
	 * 
	 */
	function getKolDetail($kolIds){
		$arrKoldetail = array();	
		$this->db->select("kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.created_by,client_users.id,client_users.email,client_users.user_role_id,client_users.client_id");
		$this->db->join('client_users','client_users.id=kols.created_by','left');
		$this->db->where_in('kols.id',$kolIds);		
		$result = $this->db->get('kols');
		foreach($result->result_array() as $row){
					$arrKoldetail[]=$row;
				}
		return $arrKoldetail;
	}
	
	function deleteRequestedKol($kolIds){
		$this->db->where_in('id',$kolIds);
		if($this->db->delete('kols')){
			return true;
		}else{
			return false;
		}
	}
	
	function getNonProfiledKols($profileStatus ,$clientId,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		$arrKols = array();
		$this->db->select('countries.country,kols.salutation,kols.primary_email,kols.address1,kols.primary_phone,specialties.specialty,organizations.name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.created_by,client_users.id,client_users.email,client_users.user_role_id,client_users.client_id,,client_users.first_name as user_full_name,kols.status');
		$this->db->join('client_users','client_users.id=kols.created_by','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('specialties','specialties.id=kols.specialty','left');
		if(is_array($profileStatus)){
			$this->db->where_in("kols.status",$profileStatus);
		}else{
			$this->db->where("(kols.status='".$profileStatus ."' or kols.status='".REJECT."')");
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(client_users.client_id=$clientId or client_users.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if(!empty($where)){
			if(isset($where['kol_name'])){
				$this->db->where("(kols.first_name LIKE '%".$where['kol_name']."%' or kols.middle_name LIKE '%".$where['kol_name']."%' or kols.last_name LIKE '%".$where['kol_name']."%')");
			}
			if(isset($where['name']))	
				$this->db->like('organizations.name',$where['name']);
			if(isset($where['specialty']))	
				$this->db->like('specialties.specialty',$where['specialty']);
			if(isset($where['country']))	
				$this->db->like('countries.Country',$where['country']);
			if(isset($where['primary_phone']))	
				$this->db->like('kols.primary_phone',$where['primary_phone']);
			if(isset($where['primary_email']))	
				$this->db->like('kols.primary_email',$where['primary_email']);
			if(isset($where['user_full_name'])){
				$cliId = INTERNAL_CLIENT_ID;
				$whereUsername	= "(concat(client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%' or (concat('Aissel Analyst',' ',client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%') AND client_users.client_id=".$cliId.")";
				$this->db->where($whereUsername);
			}
			if(isset($where['status'])){
				$str = $where['status'];
				if (preg_match("/$str/i","Requested")) {
					$this->db->where("(kols.status LIKE '%New%' OR kols.status LIKE '%".$where['status']."%')");
				}else if (preg_match("/$str/i","New")){
					$this->db->where("(kols.status NOT LIKE '%New%' AND kols.status LIKE '%".$where['status']."%')");
				}else{
					$this->db->like('kols.status',$where['status']);					
				}	
			}
		}
		if($limit != null){
			$this->db->limit($limit);
		}
		if($startFrom != null){
			$this->db->offset($startFrom);
		}
		
		if($sidx != null){
			switch($sidx){
				case 'name' : $this->db->order_by("organizations.name",$sord);
					break;
				case 'kol_name' : $this->db->order_by("kols.first_name",$sord);
					break;
				case 'specialty' : $this->db->order_by("specialties.specialty",$sord);
					break;
				case 'country' : $this->db->order_by("countries.Country",$sord);	
					break;
				case 'primary_phone' : $this->db->order_by("kols.primary_phone",$sord);	
					break;
				case 'primary_email' : $this->db->order_by("kols.primary_email",$sord);
					break;
				case 'status' : 
					$this->db->order_by("kols.status",$sord);
					break;
				case 'user_full_name' : 
							$this->db->order_by("client_users.client_id",$sord);
							$this->db->order_by("client_users.first_name",$sord);
					break;
			}
		}
		if(!$doCount){
			$resultSet = $this->db->get('kols');
//			echo $this->db->last_query();
//			exit();
			foreach($resultSet->result_array() as $row){
				$arrKols[]	= $row;
			}
			return $arrKols;
		}else{
			$resultSet = $this->db->count_all_results('kols');
			return $resultSet;
		}
	}
	
	
	function getNonProfiledKols1($profileStatus ,$clientId,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		$arrKols = array();
		$this->db->query('select countries.country,kols.salutation,kols.primary_email,kols.address1,kols.primary_phone,specialties.specialty,
		organizations.name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,kols.id as kol_id,kols.first_name,
		kols.middle_name,kols.last_name,kols.created_by,client_users.id,client_users.email,client_users.user_role_id,
		client_users.client_id,,client_users.first_name as user_full_name,kols.status,kols.*,
		(SELECT
    CASE 
	WHEN kols.salutation  = 0 THEN CONCAT(kols.first_name," ",kols.middle_name," ",kols.last_name)  
	WHEN kols.salutation  = 1 THEN CONCAT("Dr. ",kols.first_name,"  ",kols.middle_name," ",kols.last_name)   
	WHEN kols.salutation  = 2 THEN CONCAT("Prof. ",kols.first_name,"  ",kols.middle_name," ",kols.last_name) 
	WHEN kols.salutation  = 3 THEN CONCAT("Mr. ",kols.first_name,"  ",kols.middle_name," ",kols.last_name)   
	WHEN kols.salutation  = 4 THEN CONCAT("Ms. ",kols.first_name,"  ",kols.middle_name," ",kols.last_name)   
    END AS kol_name
FROM kols)kol_name'
		);
		$this->db->join('client_users','client_users.id=kols.created_by','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('specialties','specialties.id=kols.specialty','left');
		if(is_array($profileStatus)){
			$this->db->where_in("kols.status",$profileStatus);
		}else{
			$this->db->where("(kols.status='".$profileStatus ."' or kols.status='".REJECT."')");
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(client_users.client_id=$clientId or client_users.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if(!empty($where)){
			if(isset($where['kol_name'])){
//				$this->db->like('k_name',$where['kol_name']);
//				$this->db->like("",$where['kol_name']);
//				$select = "";
//				$whereKolname	= "(concat(kols.first_name,' ',kols.middle_name,' ',kols.last_name) LIKE '%".$where['kol_name']."%')";
//				$this->db->where("kol_name",$where['kol_name']);
				$this->db->where("(kols.first_name LIKE '%".$where['kol_name']."%' or kols.middle_name LIKE '%".$where['kol_name']."%' or kols.last_name LIKE '%".$where['kol_name']."%')");
			}
			if(isset($where['name']))	
				$this->db->like('organizations.name',$where['name']);
			if(isset($where['specialty']))	
				$this->db->like('specialties.specialty',$where['specialty']);
			if(isset($where['country']))	
				$this->db->like('countries.Country',$where['country']);
			if(isset($where['primary_phone']))	
				$this->db->like('kols.primary_phone',$where['primary_phone']);
			if(isset($where['primary_email']))	
				$this->db->like('kols.primary_email',$where['primary_email']);
			if(isset($where['user_full_name'])){
				$cliId = INTERNAL_CLIENT_ID;
				/*$str = $where['user_full_name'];
				$cliId = INTERNAL_CLIENT_ID;
				if (preg_match("/$str/i","Aissel Analyst")) {
					$cliId = INTERNAL_CLIENT_ID;
//					$this->db->where("(client_users.first_name LIKE '%".$where['user_full_name']."%' or client_users.last_name LIKE '%".$where['user_full_name']."%')");
//					$this->db->where("client_users.client_id",$cliId);
				
//					$this->db->where("(client_id != $cliId)");
					$this->db->where("(client_users.first_name LIKE '%".$where['user_full_name']."%' or client_users.last_name LIKE '%".$where['user_full_name']."%')");
				}else{
					$this->db->where("(client_users.first_name LIKE '%".$where['user_full_name']."%' or client_users.last_name LIKE '%".$where['user_full_name']."%')");
				}	*/
				$whereUsername	= "(concat(client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%' or (concat('Aissel Analyst',' ',client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%') AND client_users.client_id=".$cliId.")";
				$this->db->where($whereUsername);
			}
			if(isset($where['status'])){
				$str = $where['status'];
				if (preg_match("/$str/i","Requested")) {
					$this->db->where("(kols.status LIKE '%New%' OR kols.status LIKE '%".$where['status']."%')");
				}else if (preg_match("/$str/i","New")){
					$this->db->where("(kols.status NOT LIKE '%New%' AND kols.status LIKE '%".$where['status']."%')");
				}else{
					$this->db->like('kols.status',$where['status']);					
				}	
			}
		}
		if($limit != null){
			$this->db->limit($limit);
		}
		if($startFrom != null){
			$this->db->offset($startFrom);
		}
		
		if($sidx != null){
			switch($sidx){
				case 'name' : $this->db->order_by("organizations.name",$sord);
					break;
				case 'kol_name' : $this->db->order_by("kols.first_name",$sord);
					break;
				case 'specialty' : $this->db->order_by("specialties.specialty",$sord);
					break;
				case 'country' : $this->db->order_by("countries.Country",$sord);	
					break;
				case 'primary_phone' : $this->db->order_by("kols.primary_phone",$sord);	
					break;
				case 'primary_email' : $this->db->order_by("kols.primary_email",$sord);
					break;
				case 'status' : 
					$this->db->order_by("kols.status",$sord);
					break;
				case 'user_full_name' : 
							$this->db->order_by("client_users.client_id",$sord);
							$this->db->order_by("client_users.first_name",$sord);
					break;
			}
		}
		if(!$doCount){
			$resultSet = $this->db->get('kols');
			echo $this->db->last_query();
			exit();
			foreach($resultSet->result_array() as $row){
				$arrKols[]	= $row;
			}
			return $arrKols;
		}else{
			$resultSet = $this->db->count_all_results('kols');
			return $resultSet;
		}
	}
	
	function updateClientPreKol($arrKol){
	    $id = $arrKol['id'];
	    unset($arrKol['id']);
		$this->db->where('id',$id);
		if($this->db->update('kols',$arrKol)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Request',
					'description' => 'Requesting profile',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $id,
					'transaction_id' =>  $id,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Request',
					'parent_object_id' =>  $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Request',
					'description' => 'Requesting profile',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $id,
					'transaction_id' =>  $id,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Request',
					'parent_object_id' =>  $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return false;
		}
	}
	
	function save($rowData){
		if($this->db->insert('user_requests',$rowData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function update($rowData){
		$this->db->where('id',$rowData['id']);
		if($this->db->update('user_requests',$rowData))
			return true;
		else
			return false;
	}
	
	function listMyPendingApprovals($userId){
		$isApprover	= IS_APPROVER;
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		//$this->db->select('user_requests.*,client_users.*,kols.salutation,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name');
		$this->db->select('user_requests.status,user_requests.request_for,user_requests.comments,user_requests.is_re_request,user_requests.profile_type,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_requests.id,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,kols.id as kol_id,client_users.user_name as user_full_name,organizations.name,countries.country,user_requests.rej_or_appr_on,user_requests.requested_on');
		$this->db->join('client_users','client_users.id = user_requests.requested_by','left');
		$this->db->join('kols','kols.id = user_requests.kol_id','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->where('user_requests.status',New1);
		if($clientId != INTERNAL_CLIENT_ID){
			$this->db->where('client_users.client_id',$clientId);
			if(!$isApprover){
				if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
					$this->db->where('client_users.manager_id',$userId);
				else 
					$this->db->where('client_users.id',$userId);
			}
		}
		$this->db->order_by("user_requests.requested_on","desc");
		$results = $this->db->get('user_requests');
 		//pr($this->db->last_query());exit;
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
	}
	
	function listAll($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = ''){
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		//$this->db->select('user_requests.*,client_users.*,kols.salutation,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name');
		if (!$doCount) {
		$this->db->select('user_requests.status,user_requests.request_for,user_requests.comments,user_requests.is_re_request,user_requests.profile_type,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_requests.id,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,client_users.user_name as user_full_name,organizations.name,countries.country, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,user_requests.requested_on,user_requests.rej_or_appr_on,specialties.specialty');
		}
		$this->db->join('client_users','client_users.id = user_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_requests.rej_or_appr_by','left');
		$this->db->join('kols','kols.id = user_requests.kol_id','left');
		$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		
		//Add the where conditions for any jqgrid filtersproject
		if (isset($where['kol_name'])) {
		    $this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%')");
		}
		if (isset($where['specialty'])) {
		    $this->db->like('specialties.specialty', $where['specialty']);
		}
		if (isset($where['request_for'])) {
		    $this->db->like('user_requests.request_for', $where['request_for']);
		}
		if (isset($where['name'])) {
		    $this->db->like('organizations.name', $where['name']);
		}
		if (isset($where['requested_on'])) {
		    $this->db->like("DATE_FORMAT(user_requests.requested_on,'%m/%d/%Y')", $where['requested_on']);
		}
		if (isset($where['rej_or_appr_on'])) {
		    $this->db->like("DATE_FORMAT(user_requests.rej_or_appr_on,'%m/%d/%Y')", $where['rej_or_appr_on']);
		}
		if (isset($where['user_full_name'])) {
		    $this->db->like('client_users.user_name', $where['user_full_name']);
		}
		if (isset($where['status'])) {
		    $this->db->like('user_requests.status', $where['status']);
		}
		if($clientId != INTERNAL_CLIENT_ID)
			$this->db->where('client_users.client_id',$clientId);
		
		if ($doCount) {
		    $this->db->distinct();
		    $count = $this->db->count_all_results('user_requests');
		    return $count;
		} else {
		    if ($sidx != '' && $sord != '') {
		        switch ($sidx) {
		            case 'kol_name' : $this->db->order_by("kols.first_name", $sord);
		            break;
		            case 'specialty' : $this->db->order_by("specialties.specialty", $sord);
		            break;
		            case 'request_for' :$this->db->order_by("user_requests.request_for", $sord);
		            break;
		            case 'requested_on' :$this->db->order_by("user_requests.requested_on", $sord);
		            break;
		            case 'rej_or_appr_on' :$this->db->order_by("user_requests.rej_or_appr_on", $sord);
		            break;
		            case 'name' :$this->db->order_by("organizations.name", $sord);
		            break;
		            case 'user_full_name' :$this->db->order_by("client_users.user_name", $sord);
		            break;
		            case 'status' :$this->db->order_by("user_requests.status", $sord);
		            break;
		        }
		        //$this->db->order_by($sidx,$sord);
		    }
		}
		$this->db->order_by("user_requests.rej_or_appr_on","desc");
		$results = $this->db->get('user_requests', $limit, $startFrom);
		//pr($this->db->last_query());exit;
		return $results;
		//echo $this->db->last_query();
// 		if(is_object($results) && $results->num_rows() > 0)
// 			$arrResults = $results->result_array();
// 		return $arrResults;
	}
	
	
	function delete($id){
		$this->db->where_in('kol_id',$id);
		if($this->db->delete('user_requests')){
			return true;
		}else{
			return false;
		}
	}
	
	function get($id, $idType = false){
		$rowData = array();
		//Flag is set to differentiate KolId and userRequestId
		if($idType == 'userRequestId'){
				$this->db->where('id',$id);
			}else{
				$this->db->where('kol_id',$id);
		}
		$results = $this->db->get('user_requests');
		if($results->num_rows() > 0)
			$rowData = $results->row_array();
			
		return $rowData;
	}
	
	function getUserRequestDetails($arrIds){
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		//$this->db->select('user_requests.*,client_users.*,kols.salutation,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name');
		$this->db->select('user_requests.status,user_requests.request_for,user_requests.profile_type,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_requests.id,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,client_users.user_name as user_full_name,organizations.name,countries.country, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,kols.pin,specialties.specialty as spec,user_requests.requested_on,user_requests.rej_or_appr_on');
		$this->db->join('client_users','client_users.id = user_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_requests.rej_or_appr_by','left');
		$this->db->join('kols','kols.id = user_requests.kol_id','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->where_in('user_requests.id',$arrIds);
		$results = $this->db->get('user_requests');
		//pr($this->db->last_query());exit;
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
		
	}
	/**
	 * Add status for Kol data 
	 * @since july 10,2017
	 * @param $kolId, $status, $user_date
	 * @return Json data
	 *
	 */
	function changeKolUpdateDataStatus($kolId, $status, $user_date){
		$userId = $this->session->userdata("user_id");
		$data['kol_id'] = $kolId;
		$data['status'] = 	$status;
		$data['user_added_on'] = $user_date;
		$data['created_by'] = $userId;
		$data['created_on'] = date("Y-m-d H:i:s");
		if($this->db->insert("kol_update_status", $data)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update UpdateDataStatus of the KTL',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOL_UPDATE_STATUS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update UpdateDataStatus of the KTL',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOL_UPDATE_STATUS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return false;
		}
	
	}
}