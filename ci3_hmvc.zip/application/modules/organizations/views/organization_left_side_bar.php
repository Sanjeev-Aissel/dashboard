<div id="organizationShortDetails">
			<p class="profileName">
				qwert11234 <br>
				University/Hospital			</p>
			<div class="profileImage">
										<img alt="Image" src="<?php echo base_url(); ?>assets/images/organisation_inactive.svg" width="120px">
									</div>
			<div style="text-align: center;">
				<p style="margin-bottom:0px">
				Basic Profile
				</p>
			</div>
		</div>
		<div class="panel-group" id="accordion">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <span class="glyphicon glyphicon-folder-close">
                            </span>Overview <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><span style="float:right;">>></span></a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <span class="glyphicon glyphicon-pencil text-primary"></span><a href="http://www.jquery2dotnet.com">About</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
               
               <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a href="<?php echo base_url(); ?>organizations/view_keypeople/<?php echo $arrOrganization['id'];?>"><span class="glyphicon glyphicon-th">
                            </span>Key People</a>
                        </h4>
                    </div>
                </div>
              
               <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                             <span class="glyphicon glyphicon-folder-close">
                            </span>Track <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span style="float:right;">>></span></a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <span class="glyphicon glyphicon-pencil text-primary"></span><a href="http://www.jquery2dotnet.com">Interactions</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>  
                
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a href="<?php echo base_url(); ?>organizations/view_sub_organizations/<?php echo $arrOrganization['id'];?>"><span class="glyphicon glyphicon-th">
                            </span>Affiliate Orgs</a>
                        </h4>
                    </div>
                </div>
                
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a href=""><span class="glyphicon glyphicon-th">
                            </span>Org Network</a>
                        </h4>
                    </div>
                </div>
            </div>