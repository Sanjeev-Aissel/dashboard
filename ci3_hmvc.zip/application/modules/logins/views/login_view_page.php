<script src="<?php echo base_url().MODULES_ASSETS;?>logins/js/logins.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>logins/css/logins.css" rel="stylesheet">
<div class="container">    
    <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">                    
          <div class="panel panel-info" >
                <div class="panel-heading">
                        <div class="panel-title">Please Login</div>
                 </div>    
                 <div style="padding-top:30px" class="panel-body" >
                    <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                    <div id="login_error"></div>
                    <form action="" method="post" class="validateForm" id="loginform" class="form-horizontal">
                            <div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
								<input id="login-username" type="text" class="form-control" name="username" value="laxmank" placeholder="Username">                                        
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
								<input id="login-password" type="password" class="form-control" value="Hubli@321" name="password" placeholder="Password">
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                            	<input type="checkbox" onclick="showPassword()">      Show Password
                            </div>
                            <div class="form-group" style="text-align: center;">
								<a href="<?php echo base_url();?>logins/logins/show_forgot_password_page">Forgot Password?</a>
							</div>  
                            <div style="margin-top:10px" class="form-group">
								<div class="col-sm-12 controls"  style="display:block;">
									<input type="submit" id="btn-login" onclick="validate_login();return false;" value="login" class="btn btn-success form-control" style="display: block;">
								</div>
                            </div> 
                    </form>     
                </div>    
         </div>
         <div class="row">
	       <div class="col-sm-6">
	       <h6 class="text-primary">Aissel (Internal Client).</h6>
	        <p class="text-success">Manager:</p>
	       laxmank<br>
	      Hubli@321<br>
	        <p class="text-success">User:</p>
	       soumyars<br>
	       Soumyars@123<br>
	       </div>
	       <div class="col-sm-6">
	       <h6 class="text-primary">Colgate.</h6>
	      <p class="text-success">Manager:</p>
	       surajprabhu<br>
	      Suraj@123<br>
	      <p class="text-success">User:</p>
	       shrutipurushan<br>
	      Shruti@123<br>
	       </div>
         </div>
    </div> 
</div>
<script>
var base_url = '<?php echo base_url(); ?>';
var validationRules	=  {
		username: {
		 required:true
     },
     password: {
		 required:true
    }
};
var validationMessages = {
		username: {
		required:"Please enter Username"
	},
	password: {
		 required:"Please enter password"
    }
};
$(document).ready(function(){
	$("#loginform").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>