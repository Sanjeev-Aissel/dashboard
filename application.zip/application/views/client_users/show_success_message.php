<?php


/**
 * this is html file to show Success Message 
 * @package application.views.client_users
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 * 
 */
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>User Registration</title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	
	<link type="text/css" href="<?php echo base_url()?>css/client_layout.css"  rel="stylesheet" />

	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	<script src="<?php echo base_url()?>js/jquery.popupWindow.js" type="text/javascript"></script>
	
<style type="text/css">

	#container{	
		margin:0 auto;
		position:relative;
		text-align:left;
		width:696px;
		background:#fff;		
		margin-bottom:2em;
		}	
	#header{
		height:144px;
		background:#5DC9E1;
		color:#fff;
		}				
	#content{
		position:relative;
		}			
	#footer{	
		background-color: #DEDFDE;
	}
	.userRegistrationForm{
	   background: none repeat scroll 0 0 #F1F1F1;
	    float: left;
	    padding: 11px;
	    width: 98%;
	}
	.userForm .labelForfields{
		color: black;
	    float: left;
	    font-family: lucida Grande;
	    margin-right: 12px;
	    margin-top: -2px;
	    text-align: right;
	    width: 131px;
	    font-weight:bold;
	}
	.userForm tr td{
		padding:10px;
	}
	.userForm input[type="text"],input[type="password"],select{
		width:220px;
	 	height: 24px;
	}
	.error{
		color:red;
		padding-left:31px;
	}
    #errorBox{
    padding-left:143px;
    }
	.userForm input[type="button"] {
       background: none repeat scroll 0 0 -moz-use-text-color;
	    float: left;
	    font: bold 10pt Arial,Helvetica,sans-serif;
	    letter-spacing: 1px;
	    margin-left: 200px;
	    padding: 5px 10px;
	    text-align: center;
	  
	}
	#about{
	    font-family: lucida Grande;
	    font-style: normal;
	    font-weight: bold;
	    margin-left: 693px;
		margin-top: -14px;
	}
	.heading{
		color: #3366CC;
	    font-family: arial,sans-serif;
	    font-weight: bold;
	    font-size:12pt;
	}

</style>	

</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="loginTable">
  <tr>
    <td class="topHeaderRow">&nbsp;<h1><?php echo PRODUCT_VERSION; ?></h1></td>
  </tr>
  <tr>
    <td class="loginRow" align="center">
		<div style="padding: 5px 0px 25px; background: none repeat scroll 0% 0% rgb(239, 239, 239); width: 70%; margin: 10px 0px;">
			
			<h2 style="color: #3366CC">Congratulations!</h2>
			<h3> You've successfully created <?php echo PRODUCT_VERSION; ?> account.  <a href="<?php echo base_url();?>">Click</a> here for Login</h3>
		</div>
		
	</td>
  </tr>
  <tr>
    <td id="footer" align="right" height="50px;"><img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" class="logo_a" /> &nbsp;&nbsp;Copyright � 2011  Powered by Aissel Solutions &nbsp;&nbsp;</td>
  </tr>
</table>


</body>
</html>
	
