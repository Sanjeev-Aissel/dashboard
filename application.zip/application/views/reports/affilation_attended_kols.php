<style>
h5{
	margin-bottom: 0px;
}
</style>

<script src="<?php echo base_url()?>/js/tooltip/bootstrap-tooltip.js"></script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
$(".excelExportIcon").mouseout(function(){
    $(".tooltip").hide();
});
function submitData(){
	/* $("#dataTable a").contents().unwrap();
	var dataTable = $("#dataTable").html();
	$("#tablecontent").val(dataTable);
	$("#download-excel-form").submit(); */

	var affName = $("#affName").text();
	var html = '';
	html +="<tr><th>Organization :</th><th colspan='5'>"+affName+"</th></tr>";
	$("#dataTable thead").prepend(html);
	$("#dataTable a").contents().unwrap();
	var dataTable = $("#dataTable").html();
	$("#tablecontent").val(dataTable);
	setTimeout(function(){ $("#download-excel-form").submit();}, 500);
	$('#dataTable thead tr:first').remove();
}
</script>

<h5>Orgnaization : <span id="affName"><?php echo $arrKols[0]['name'] ?></span></h5>

<form method="post" id="download-excel-form" action="<?php echo base_url()?>download/jqgridExportToExcel/affiliation_data">
	<textarea name="table" id="tablecontent" style="display: none;"></textarea>
	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="submitData();" style="float: right;">
		<a href="#" data-toggle="tooltip" data-placement="left" title="Export details to excel">&nbsp;</a>
	</div>
</form>

<table id="dataTable">
    <thead>
        <tr>
        	<th></th>   
        	<th><?php echo lang('HCP');?></th>        	
        	<th>Specialty</th>
        	<th>Country</th>
        	<th>State</th>
        	<th>City</th>        	
        </tr>
    </thead> 
    <tbody>
    <?php 
    $i = 1;
    foreach ($arrKols as $row){ ?>
    	<tr>
    		<td><?php echo $i ?></td>
    		<td><a href="<?php echo base_url().'kols/view/'.$row['unique_id'] ?>"><?php echo $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']); ?></a></td>
    		<td><?php echo $row['specialty'] ?></td>
    		<td><?php echo $row['country'] ?></td>
    		<td><?php echo $row['state'] ?></td>
    		<td><?php echo $row['city'] ?></td>
    	</tr>
    <?php $i++; 
    } ?>	
    </tbody>  
</table>