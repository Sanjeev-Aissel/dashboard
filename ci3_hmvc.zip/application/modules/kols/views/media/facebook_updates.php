<?php
/**
 * File to render facebook updates for given username
 *
 * @author: Ramesh B
 * @created on: 26 jun 2013
 */
function get_facebook_updates($userName,$limit=5,$startFrom = null,$mediaUrl = ''){
	// Create our Application instance (replace this with your appId and secret).
	$facebook = new Facebook(array(
	  'appId'  => '386692868111818',
	  'secret' => 'cbdb6cd57aefb75fe0e90a0622cd5899',
	));
	//Facebook posts for the company 'NewYork-Presbyterian Hospital' 
	$fbApiUrl = "/$userName/posts?limit=$limit";
	if($startFrom != null)
		$fbApiUrl .="&until=$startFrom";
    $companyPosts = $facebook->api($fbApiUrl);
    //Get the value of the until parameter from next url for pagination
    $nextUrl = $companyPosts['paging']['next'];
    $urlarr = parse_url($nextUrl);
    $query = array();
	parse_str($urlarr['query'], $query);
	$until = $query['until'];
					
    $companyPosts = $companyPosts['data'];
    $arrPosts  = array();
    foreach($companyPosts as $row){
    	$post = array();
    	$post['message'] = $row['message'];
    	$post['picture'] = $row['picture'];
    	$post['likes'] = sizeof($row['likes']['data']);
    	$post['comments'] = sizeof($row['comments']['data']);
    	$post['shares'] = $row['shares']['count'];
    	$post['created_time'] = $row['created_time'];
    	if(isset($row['story'])){
    		$post['story'] = $row['story'];
    		if(!isset($row['status_type']) && $row['type'] == 'status'){
    			$storyText = "<a href='".$mediaUrl."' target='_new'>".$row['from']['name']."</a>";
    			$storyText .=" Added a comment";
    			$post['story'] = $storyText;
    			$post['message'] = " Added a comment ".$row['story'];;
    		}
    		
    	}else{
    		$storyText = "<a href='".$mediaUrl."' target='_new'>".$row['from']['name']."</a>";
    		switch($row['status_type']){
    			case 'shared_story' : $storyText .=" Shared a <a target='_new' href='".$row['link']."'>".$row['type']."</a>";
    									break;
    			case 'added_photos'	: $storyText .=" Added a photo";
    									break;
    			case 'mobile_status_update' : $storyText .=" Updated the status";
    									break;
    		}
    		
    		$post['story'] = $storyText;
    	}
    	
    	if((!isset($row['status_type']) || $row['status_type'] == 'shared_story') && ($row['type'] == 'video' || $row['type'] == 'link')){
    		$post['link'] = $row['link'];
    	}
    	$arrPosts[] = $post;
    }
    
    $data['arrPosts'] = $arrPosts;
    $data['until'] = $until;
    return $data;
}

function linkable2($text = ''){
    $text = preg_replace("/\s+/", ' ', str_replace(array("\r\n", "\r", "\n"), ' ', $text));
    $data = '';
    foreach( explode(' ', $text) as $str){
        if (preg_match('#^http?#i', trim($str)) || preg_match('#^www.?#i', trim($str))) {
            $data .= '<br /><a target="_new" href="'.$str.'">'.$str.'</a> ';
        } else {
            $data .= $str .' ';
        }
    }
    return trim($data);
}
?>

<?php 
	// Load the plugin
	$this->load->plugin('facebook/facebook');
	$arrComponents = explode("/",rtrim($mediaUrl,'/'));
	$userName = $arrComponents[sizeof($arrComponents)-1];
	if(strpos($userName,"?") !== false){
		$arrComponents = explode("?",$userName);
		$userName = $arrComponents[0];
	}
	if(!isset($limit))
		$limit=5;
	$data = get_facebook_updates($userName,$limit,$startFrom,$mediaUrl);
	$arrPosts = $data['arrPosts'];
	foreach ($arrPosts as $post){
		?>
		<li>
			<span class='storylink'><?php echo $post['story'];?></span>
			<div>
				<?php if($post['picture'] != ''){?>
					<?php if(isset($post['link'])){?>
						<a href="<?php echo $post['link'];?>" target="_new"><img class='fb-image' alt="" src="<?php echo $post['picture'];?>"></a>
					<?php }else{?>
						<img class='fb-image' alt="" src="<?php echo $post['picture'];?>">
					<?php }?>
				<?php }?>
				<?php if($post['message'] != ''){?>
				<p>
					<?php 
					//show only 300 characters
					if(strlen($post['message']) < 200)
						echo linkable2($post['message']);
					else
						echo linkable2(substr($post['message'], 0, 200)."...");
					?>
				</p>
				<?php }?>
				<?php if(isset($post['link'])){?>
					<a target="_new" href="<?php echo $post['link'];?>"><?php echo $post['link'];?></a>
				<?php }?>
				<div class="additinal-links">
					<?php if($post['likes'] != '' && $post['likes'] != 0){?>
						<span class="likesIcon"><a href="<?php echo $mediaUrl;?>" target="_new"></a></span>
						<span><?php echo $post['likes'];?></span>
					<?php }?>
					<?php if($post['comments'] != '' && $post['comments'] != 0){?>
						<span class="commentsIcon"><a href="<?php echo $mediaUrl;?>" target="_new"></a></span>
						<span><?php echo $post['comments'];?></span>
					<?php }?>
					<?php if($post['shares'] != '' && $post['shares'] != 0){?>
						<span class="sharesIcon"><a href="<?php echo $mediaUrl;?>" target="_new"></a></span>
						<span><?php echo $post['shares'];?></span>
					<?php }?>
				</div>
				<span class='human-time'>
				<?php 
					$post['created_time'] = humanTiming(strtotime(changeDateFormat($post['created_time'],DATE_ATOM,"Y-m-d h:m:s")));
					echo $post['created_time'];
				?>
				</span>
			</div>
		</li>
		<?php 
	}
?>
<span class="start-from"><?php echo $data['until'];?></span>