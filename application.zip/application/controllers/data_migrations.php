<?php

/*
 * Controller for iReport CRM data migration
 *  
 * @Author		: Rameshb B
 * @since 		: iReportV2
 * Created on	: 21-12-2015
 *  
 */

class Data_migrations extends Controller {

    private $loggedUserId = null;

    // constructor to initialize the data
    function Data_migrations() {
        parent::Controller();
        $this->load->model('coaching');
        $this->load->model('kol');
    }
    

    
    
   function medicalinsightMapping() {
   	 ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $result = $this->db->query('select * from  customer_dynamic where table_id=7888500000002230  AND (date_1 LIKE "%-14" OR date_1 LIKE "%-15" OR date_1 LIKE "%-16")');

        foreach ($result->result_array() as $values) {
           
            //specialty
            if (($values['code_1']) == "NSC")
                $specialty = "CNS";
            if (($values['code_1']) == "ONC")
                $specialty = "Oncology";
            if(($values['code_1'])=="HOSP")
               $specialty="Cardio-Renal";
            //source_type
            if (($values['code_4']) == "HCP")
                $source_type = "HCP direct knowledge";
            if (($values['code_4']) == "PDK")
                $source_type = "Payer direct knowledge";
            if (($values['code_4']) == "CSPS")
                $source_type = "Congress symposia/poster session";
            if (($values['code_4']) == "HCPS")
                $source_type = "HCP secondary knowledge";
            if (($values['code_4']) == "MWLE")
                $source_type = "Media: Websites, Listserve, etc.";
            if (($values['code_4']) == "IPDK")
                $source_type = "Industry professional direct knowledge";
            if (($values['code_4']) == "IPSK")
                $source_type = "Industry professional secondary knowledge";
            if (($values['code_4']) == "PSK")
                $source_type = "Payer secondary knowledge";
            if (($values['code_4']) == "NA")
                $source_type = "N/A";
            //agent
            if (($values['code_3']) == "OTH")
                $agent = "Other";
            if (($values['code_3']) == "SATX")
                $agent = "Sativex";
            if (($values['code_3']) == "OTHI")
                $agent = "Other";
            if (($values['code_3']) == "BREX")
                $agent = "Brexpiprazole";
            if (($values['code_3']) == "LUUA")
                $agent = "LUU AE58054";
            
            //Sphere of Influence
            if (($values['code_2']) == "LOC")
                $sphere = "Local";
            if (($values['code_2']) == "REG")
                $sphere = "Regional";
            if (($values['code_2']) == "NAT")
                $sphere = "National";
            if (($values['code_2']) == "GLOB")
                $sphere = "Global";
            
            //email 
            $userEmail = $this->db->query("select email_address from employee "
                    . "left join customer_dynamic on customer_dynamic.number_1=employee.employee_id "
                    . "where customer_dynamic.number_1=" . $values['number_1'] . "");
            $email = $userEmail->row_array();
            // echo $this->db->last_query();
            //created_by
            $userIds = $this->db->query("select id from client_users where lower(email)='" . strtolower($email['email_address']) . "'");
            $userId = $userIds->row_array();
            //echo $userId;
            //  echo $this->db->last_query();
            //product 

            $productIds = $this->db->query("SELECT name from products where otsuka_id='" . $values['text_1'] . "'");
            $productId = $productIds->row_array();
            
            //GET mapping customer_id
            $customerIdMap = $this->getMappingCustomerId($values['customer_id']);
             if($customerIdMap != '')
            	$values['customer_id'] = $customerIdMap;
            $kolIds = $this->db->query("SELECT id from kols where customer_id='" . $values['customer_id'] . "'");
            $kolId = $kolIds->row_array();
            

            $keyInsightArray = $this->db->query("SELECT name from key_insight_topics where otsuka_code='" . $values['code_5'] . "'");
            $keyInsightId = $keyInsightArray->row_array();

            $old_startdate_timestamp_create = strtotime($values['date_1']);
           $create_date = date('Y-m-d', $old_startdate_timestamp_create);
            
            $insertDataArray = array(
                "specialty" => $specialty,
                "agent" => $agent,
                "product" => $productId['name'],
                "source_type" => $source_type,
                "summary" => $values['text_5'],
                "topics" => $keyInsightId['name'],
                "created_by" => $userId['id'],
                "created_on" => $create_date,
                "sphere_of_influence" => $sphere,
                "relevance" => $values['text_2'],
                "actions_to_consider" => $values['text_3'],
                "other" => '',
                "kol_id" => $kolId['id'],
                "profile_type" => '',
                "ireport_id" => $values['customer_dynamic_id'],
                    );
            $this->db->insert("medical_insight", $insertDataArray);
            //   $lastId= $this->db->insert_id();
        }
    }

    function codeMapping() {
        $topic = $this->db->query("SELECT * from keyinsightcode");
        $keytopic = $topic->result_array();
        //    pr($keytopic);
        foreach ($keytopic as $values) {


            $this->db->query("update key_insight_topics set otsuka_code='" . $values['code'] . "' where name='" . $values['name'] . "'");
        }
    }
    
	
    function complianceMapping() {
    	 ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $result = $this->db->query("select * from coaching where skill_group_id='7888100000000001' ");
        foreach ($result->result_array() as $values) {
            //email 
            $resultEmail = $this->db->query("select email_address from employee "
                    . "left join coaching on coaching.employee_id=employee.employee_id "
                    . "where coaching.employee_id=" . $values['employee_id'] . "");
            $mail = $resultEmail->row_array();

            //created_by
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();

            //location, monitored_by ,off_label_inquiry	inquiry_unsolicited	response_consistancy	compliance_violation	compliance_violated_by	compliance_violated_by_title	violation_description
            //state_id	city_id	fma	compliance_violated_by_date	kol_id/org_id

            $resultDetails = $this->db->query("select * from coaching_comment where coaching_id=" . $values['coaching_id'] . "");
            $state = "";
            $city = "";
            foreach ($resultDetails->result_array() as $key => $data) {
                if ($data['comment_field_name'] == 'column_3') {
                    $location = $data['comments'];
                    $arrComplianceLocations = array(
                        'MC', 'NMC', 'Advisory Board', 'OM', 'ONM', 'CONG', 'SPPR', 'Investigator Meeting', 'OTH'
                    );   // Investigator and advisory board no short hand found in db
                    $location = array_search($location, $arrComplianceLocations);
                }
                if ($data['comment_field_name'] == 'column_4') {
					
                    $fmaName = $data['comments'];
                    $fmaName = explode(",", $fmaName);
                    $resultFma = $this->db->query('select id from client_users where last_name="' . trim($fmaName[0]) . '" and first_name="' . trim($fmaName[1]) . '"');
                    $fma = $resultFma->row_array();
                }
                if ($data['comment_field_name'] == 'column_6_id_1') {
                    $kolId[$key] = $data['comments'];
                }
                if ($data['comment_field_name'] == 'column_9_yes_check') {
                    if ($data['comments'] == 0)
                        $off = "yes";
                }
                if ($data['comment_field_name'] == 'column_9_no_check') {
                    if ($data['comments'] == 0)
                        $off = "no";
                }
                if ($data['comment_field_name'] == 'column_9a_yes_check') {
                    if ($data['comments'] == 0)
                        $inquiry = "yes";
                }
                if ($data['comment_field_name'] == 'column_9a_no_check') {
                    if ($data['comments'] == 0)
                        $inquiry = "no";
                }

                if ($data['comment_field_name'] == 'column_9b_yes_check') {
                    if ($data['comments'] == 0)
                        $response = "yes";
                }
                if ($data['comment_field_name'] == 'column_9b_no_check') {
                    if ($data['comments'] == 0)
                        $response = "no";
                }

                if ($data['comment_field_name'] == 'column_10_yes_check') {
                    if ($data['comments'] == 0)
                        $complianceVoilation = "yes";
                }
                if ($data['comment_field_name'] == 'column_10_no_check') {
                    if ($data['comments'] == 0)
                        $complianceVoilation = "no";
                }
                if ($data['comment_field_name'] == 'vc_title')
                    $title = $data['comments'];
                if ($data['comment_field_name'] == 'vc_date')
                    $voilationDate = $data['comments'];
                if ($data['comment_field_name'] == 'column_6b')
                    $state = trim($data['comments']);
                if ($data['comment_field_name'] == 'column_6a')
                    $city = trim($data['comments']);
                if ($data['comment_field_name'] == 'column_11_comment')
                    $description = $data['comments'];

                if ($data['comment_field_name'] == 'column_5') {
                    $id = $data['comments'];

                    //email 
                    $resultEmail = $this->db->query("select email_address from employee where employee_id=" . $id . "");
                    $mail = $resultEmail->row_array();
                    //manger id
                    $managerIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
                    $managerId = $managerIds->row_array();
                }
                $old_startdate_timestamp = strtotime($voilationDate);
                $date = date('Y-m-d', $old_startdate_timestamp);
                $old_startdate_timestamp_create = strtotime($values['create_date']);
                $create_date = date('Y-m-d', $old_startdate_timestamp_create);
                if ($values['interaction_category'] == "ONEO")
                    $iC = 1;
                else
                    $iC = 2;
                
            }
            
            		if($state != ''){
                    $resultState = $this->db->query("SELECT regions.RegionID FROM regions LEFT JOIN countries ON regions.CountryID = countries.CountryId WHERE countries.FIPS104 IN ('US','CA') AND regions.Code = '$state' ");
                    $state = $resultState->row_array();
                    $state = $state['RegionID'];
            		}
            		if($city != '' && $state != ''){
	                    $resultCity = $this->db->query('SELECT CityId FROM cities WHERE city = "'.$city.'" AND RegionID = '.$state);
	                    $city = $resultCity->row_array();
	                    $city = $city['CityId'];
            		}
                    
                    
        	$dataInsert = array(
                    "date" => $create_date,
                    "location" => $location,
                    "monitored_by" => $fma['id'],
                    "interaction_type" => $iC,
                    "off_label_inquiry" => $off,
                    "inquiry_unsolicited" => $inquiry,
                    "response_consistancy" => $response,
                    "compliance_violation" => $complianceVoilation,
                    "compliance_violated_by" => '',
                    "compliance_violated_by_title" => $title,
                    "compliance_violated_by_date" => $date,
                    "violation_description" => $description,
                    "contact_type" => '',
                    "signature" => '',
                    "created_by" => $userId['id'],
                    "created_on" => '',
                    "state_id" => $state,
                    "city_id" => $city,
                    "fma" => $managerId['id'],
        			"ireport_id" => $values['coaching_id']
                        );
                 $fma = $create_date = $location = $iC = $off = $inquiry = $response = $complianceVoilation = $title = $date = $description = $userId = $state= $city = $managerId = ''; 
                /* pr($dataInsert);
                 continue;*/
                $this->db->insert("compliance_monitoring", $dataInsert);
                $lastId = $this->db->insert_id();
                //  get type
               foreach ($kolId as $id) {
                    $resultType = $this->db->query("select name, first_name,middle_name, customer_type from customer "
                            . "where customer_id=" . $id . "");
                    $type = $resultType->row_array();
                    // get organization or kol id from kols table
                      $customerIdMap = $this->getMappingCustomerId($id);
                      if($customerIdMap != '')
                      	$id = $customerIdMap;
                    $resultId = $this->db->query("select id from kols "
                            . "where customer_id=" . $id . "");
                    $kolOrOrgId = $resultId->row_array();
                    $this->db->query("SET FOREIGN_KEY_CHECKS=0");
                   
                    if ($type["customer_type"] == "PRES") {
                        if($kolOrOrgId["id"]==''){
                         $dataInsert = array("compliance_monitoring_id" => $lastId, "hcpname" =>$type['name']." ".$type['first_name']);
                        $this->db->insert("compliance_monitoring_kols", $dataInsert);}
                        else{
                             $dataInsert = array("compliance_monitoring_id" => $lastId, "kol_id" => $kolOrOrgId["id"]);
                             $this->db->insert("compliance_monitoring_kols", $dataInsert);
                        }
                    } else {
                         $dataInsert = array("compliance_monitoring_id" => $lastId, "org_id" => $kolOrOrgId["id"]);
                        $this->db->insert("compliance_monitoring_organizations", $dataInsert);
                    }
                }
                
                
                //product, type,topic
                
                 $resultPurpose = $this->db->query("select * from compliance_topic_tpye "
                   
                    . "where coaching_id=" . $values['coaching_id'] . "");
            $purpose = $resultPurpose->row_array();
          //echo $this->db->last_query();
            //pr($purpose);
            $type='';
            $product='';
            $topic='';
            if(count($purpose)>0)
            {
                if($purpose['PRODUCT_ID']!=''){
            $product=$this->db->query("select id from products "
                   
                    . "where otsuka_id=" . $purpose['PRODUCT_ID'] . "");
            $product=$product->row_array();
            $product=$product['id'];
                }
            
            if($purpose['COACHING_TOPIC_TYPE']!=''){
            	if($purpose['COACHING_TOPIC_TYPE']=="OORE")
                $type=1;
            if($purpose['COACHING_TOPIC_TYPE']=="OOPP")
                $type=2;
                    if($purpose['COACHING_TOPIC_TYPE']=="OOPN")
                $type=3;
                   if($purpose['COACHING_TOPIC_TYPE']=="OINT")
                $type= 4  ; 
                   if($purpose['COACHING_TOPIC_TYPE']=="RACD")
               $type= 5;
               if($purpose['COACHING_TOPIC_TYPE']=="OPND")
               $type= 6;
            }
            
            if($purpose['COACHING_TOPIC']!=''){
              $topic=$this->db->query("select id from interaction_topics "
                   
                    . "where code='" . $purpose['COACHING_TOPIC'] . "'");
            $topic=$topic->row_array();
            $topic=$topic['id'];
            }

        	$dataInsert = array(
                    "compliance_monitoring_id" => $lastId,
                    "type_id" => $type,
                    "product_id" => $product,
                    "topic_id" => $topic,
                    "is_additional_topic" => '',
                    
                        );
                
                  $this->db->insert("compliance_monitoring_topics", $dataInsert);
        }
        }
    }
    
    
    
    /**
     * coaching
     */
      function mapping() {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $result = $this->db->query("select * from coaching where skill_group_id=7888300000000050 OR skill_group_id = 7888200000000050");
        foreach ($result->result_array() as $values) {
         
            //email 
            $resultEmail = $this->db->query("select email_address from employee "
                    . "left join coaching on coaching.employee_id=employee.employee_id "
                    . "where coaching.employee_id=" . $values['employee_id'] . "");
            $mail = $resultEmail->row_array();

            //username
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();
if(count($userId)==0)
    $userId['id']='';
            //speciality, engagement staus, therp area, hcid
            $resultDetails = $this->db->query("select * from coaching_comment where coaching_id=" . $values['coaching_id'] . "");
            $noHcpIdNames=array();
            foreach ($resultDetails->result_array() as $data) {
                if ($data['comment_field_name'] == 'evaluator_emp_id')
                    $managerId = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_thera_area')
                    $theparea = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_hcp') {
                    $hcp = $data['comments'];
                    $name = explode(",", $hcp);
                    $kolId = array();
                    foreach ($name as $key => $kol) {
                        $kolName = explode(" ", trim($kol));
                     
                        if(count($kolName)>0){
                            if(!isset($kolName[0]))
                                $kolName[0]='';
                            if(!isset($kolName[1]))
                                $kolName[1]='';
                        $hcpIds = $this->db->query("select id from kols where first_name='" . mysql_real_escape_string(trim($kolName[0])) . "' and last_name='" . mysql_real_escape_string(trim($kolName[1])) . "'");
                        $hcpId = $hcpIds->row_array();
                        if(count($hcpId)>0){
                        if ($hcpId['id'] != '')
                            $kolId[$key] = $hcpId['id'];
                        }
                        $noHcpIdNames[]=$kolName[0]." ".$kolName[1];
                        }
                        
                            
                    }
               		if (count($kolId) > 0)
                    $kolIds = trim(implode(',', $kolId));
                       
                }

                if ($data['comment_field_name'] == 'vc_fcr_top_eng_status')
                    $engStatus = $data['comments'];
                if ($data['comment_field_name'] == 'vc_fcr_top_comments')
                    $comment = $data['comments'];
            }
            //therp id from kol database
            $resultThep = $this->db->query("select id from theraputic_areas where name='" . $theparea . "' ");
            $theparea = $resultThep->row_array();
            if(count($theparea)==0)
                $theparea['id']='';

            //manager id from kol database(evaluator)
            $resultEmailManager = $this->db->query("select email_address from employee where employee_id=" . $managerId . " ");
            $managerEmail = $resultEmailManager->row_array();
            $managerIds = $this->db->query("select id from client_users where email='" . strtolower($managerEmail['email_address']) . "'");
            $mangerId = $managerIds->row_array();

            //question plans
            $resultP1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000002 ");
            $p1 = $resultP1->row_array();
            if(count($p1)>0){
            $resultP1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p1['skill_rating_id'] . "");
            $p1 = $resultP1->row_array();
            }

            $resultP2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000003 ");
            $p2 = $resultP2->row_array();
            if(count($p2)>0){
            $resultP2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p2['skill_rating_id'] . "");
            $p2 = $resultP2->row_array();
            }
            $resultP3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000004 ");
            $p3 = $resultP3->row_array();
             if(count($p3)>0){
            $resultP3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p3['skill_rating_id'] . "");
            $p3 = $resultP3->row_array();
             }
            $resultP4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000005 ");
            
            $p4 = $resultP4->row_array();
             if(count($p4)>0){
            $resultP4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p4['skill_rating_id'] . "");
            $p4 = $resultP4->row_array();
             }
            $resultP5 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000006 ");
            $p5 = $resultP5->row_array();
             if(count($p5)>0){
            $resultP5 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $p5['skill_rating_id'] . "");
            $p5 = $resultP5->row_array();
             }
            $resultPS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000007 ");
            $pS = $resultPS->row_array();
             if(count($pS)>0){
            $resultPS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $pS['skill_rating_id'] . "");
            $pS = $resultPS->row_array();
             }

            //question report
            $resultR1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000008 ");
            $r1 = $resultR1->row_array();
            if (count($r1) > 0) {
                $resultR1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $r1['skill_rating_id'] . "");
                $r1 = $resultR1->row_array();
            }



            $resultR2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000009 ");
            $r2 = $resultR2->row_array();
            if (count($r1) > 0) {
                $resultR2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $r2['skill_rating_id'] . "");
                $r2 = $resultR2->row_array();
            }
            $resultRS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888200000000010 ");
            $rS = $resultRS->row_array();
            if (count($r1) > 0) {
                $resultRS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $rS['skill_rating_id'] . "");
                $rS = $resultRS->row_array();
            }



            //medical dialogue

            $resultM1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000013 ");
            $m1 = $resultM1->row_array();
             if(count($m1)>0){
            $resultM1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m1['skill_rating_id'] . "");
            $m1 = $resultM1->row_array();
             }

            $resultM2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000014 ");
            $m2 = $resultM2->row_array();
            if(count($m2)>0){
            $resultM2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m2['skill_rating_id'] . "");
            $m2 = $resultM2->row_array();
            }
            $resultM3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000015 ");
            $m3 = $resultM3->row_array();
            if(count($m3)>0){
            $resultM3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m3['skill_rating_id'] . "");
            $m3 = $resultM3->row_array();
            }
            $resultM4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000016 ");
            $m4 = $resultM4->row_array();
            if(count($m4)>0){
            $resultM4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m4['skill_rating_id'] . "");
            $m4 = $resultM4->row_array();
            }
            $resultM5 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000017 ");
            $m5 = $resultM5->row_array();
            if(count($m5)>0){
            $resultM5 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m5['skill_rating_id'] . "");
            $m5 = $resultM5->row_array();
            }

            $resultM6 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000018 ");
            $m6 = $resultM6->row_array();
            if(count($m6)>0){
            $resultM6 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m6['skill_rating_id'] . "");
            $m6 = $resultM6->row_array();
            }

            $resultM7 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000019 ");
            $m7 = $resultM7->row_array();
            if(count($m7)>0){
            $resultM7 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $m7['skill_rating_id'] . "");
            $m7 = $resultM7->row_array();
            }

            $resultMS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000020 ");
            $mS = $resultMS->row_array();
            if(count($mS)>0){
            $resultMS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $mS['skill_rating_id'] . "");
            $mS = $resultMS->row_array();
            }

            //Next steps
            $resultN1 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000022 ");
            $n1 = $resultN1->row_array();
            if(count($n1)>0){
            $resultN1 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n1['skill_rating_id'] . "");
            $n1 = $resultN1->row_array();
            }

            $resultN2 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000023");
            $n2 = $resultN2->row_array();
             if(count($n2)>0){
            $resultN2 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n2['skill_rating_id'] . "");
            $n2 = $resultN2->row_array();
             }
            $resultN3 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000024");
            $n3 = $resultN3->row_array();
             if(count($n3)>0){
            $resultN3 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n3['skill_rating_id'] . "");
            $n3 = $resultN3->row_array();
             }
            $resultN4 = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000025");
            $n4 = $resultN4->row_array();
             if(count($n4)>0){
            $resultN4 = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $n4['skill_rating_id'] . "");
            $n4 = $resultN4->row_array();
             }
            $resultNS = $this->db->query("select skill_rating_id from coaching_skill_rating where coaching_id=" . $values['coaching_id'] . " and skill_id=7888300000000026");
            $nS = $resultNS->row_array();
             if(count($nS)>0){
            $resultNS = $this->db->query("select rating_short_description from skill_rating where skill_rating_id=" . $nS['skill_rating_id'] . "");
            $nS = $resultNS->row_array();
             }
            if(count($nS)>0){
            if ($nS['rating_short_description'] == 5)
                $nS['rating_short_description'] = 2;
            if ($nS['rating_short_description'] == 6)
                $nS['rating_short_description'] = 1;
            if ($nS['rating_short_description'] == 7)
                $nS['rating_short_description'] = 0;
            }
            else
                $nS['rating_short_description'] = 0;
            
             if(count($pS)>0){
            if ($pS['rating_short_description'] == 7)
                $pS['rating_short_description'] = 0;
             }
             else
                $pS['rating_short_description'] = 0;
             if(count($mS)>0){
            if ($mS['rating_short_description'] == 7)
                $mS['rating_short_description'] = 0;
             }
             else
                $mS['rating_short_description'] = 0;
             if(count($rS)>0){
            if ($rS['rating_short_description'] == 7)
                $rS['rating_short_description'] = 0;
             }
             else
                $rS['rating_short_description'] = 0;
            

            //planning
             if(count($p1)>0){
            if ($p1['rating_short_description'] == 7)
                $p1['rating_short_description'] = 0;
             }
             else
                $p1['rating_short_description'] = 0;
             
              if(count($p2)>0){
            if ($p2['rating_short_description'] == 7)
                $p2['rating_short_description'] = 0;
              }
              else
                $p2['rating_short_description'] = 0;
               if(count($p3)>0){
            if ($p3['rating_short_description'] == 7)
                $p3['rating_short_description'] = 0;
               }
               else
                $p3['rating_short_description'] = 0;
                if(count($p4)>0){
            if ($p4['rating_short_description'] == 7)
                $p4['rating_short_description'] = 0;
                }
                else
                $p4['rating_short_description'] = 0;
                 if(count($p5)>0){
            if ($p5['rating_short_description'] == 7)
                $p5['rating_short_description'] = 0;
                 }
                 else
                $p5['rating_short_description'] = 0;

            //open
                  if(count($r1)>0){
            if ($r1['rating_short_description'] == 7)
                $r1['rating_short_description'] = 0;
                  }
                  else
                $r1['rating_short_description'] = 0;
                   if(count($r2)>0){
            if ($r2['rating_short_description'] == 7)
                $r2['rating_short_description'] = 0;
                   }
                   else
                $r2['rating_short_description'] = 0;

            //med
                   
                    if(count($m1)>0){
            if ($m1['rating_short_description'] == 7)
                $m1['rating_short_description'] = 0;
                    }
                    else
                $m1['rating_short_description'] = 0;
                    
                   if(count($m2)>0){  
            if ($m2['rating_short_description'] == 7)
                $m2['rating_short_description'] = 0;
                   }
                   else
                $m2['rating_short_description'] = 0;
             if(count($m3)>0){
            if ($m3['rating_short_description'] == 7)
                $m3['rating_short_description'] = 0;
             }
             else
                $m3['rating_short_description'] = 0;
             if(count($m4)>0){
            if ($m4['rating_short_description'] == 7)
                $m4['rating_short_description'] = 0;
             }
             else
                $m4['rating_short_description'] = 0;
             if(count($m5)>0){
            if ($m5['rating_short_description'] == 7)
                $m5['rating_short_description'] = 0;
             }
             else
                $m5['rating_short_description'] = 0;
             if(count($m6)>0){
            if ($m6['rating_short_description'] == 7)
                $m6['rating_short_description'] = 0;
             }
             else
                $m6['rating_short_description'] = 0;
             if(count($m7)>0){
            if ($m7['rating_short_description'] == 7)
                $m7['rating_short_description'] = 0;
             }
             else
                $m7['rating_short_description'] = 0;
            //wrap
              if(count($n1)>0){
            if ($n1['rating_short_description'] == 7)
                $n1['rating_short_description'] = 0;
              }
              else
                $n1['rating_short_description'] = 0;
             if(count($n2)>0){
            if ($n2['rating_short_description'] == 7)
                $n2['rating_short_description'] = 0;
             }
             else
                $n2['rating_short_description'] = 0;
             if(count($n3)>0){
            if ($n3['rating_short_description'] == 7)
                $n3['rating_short_description'] = 0;
             }
             else
                $n3['rating_short_description'] = 0;
             if(count($n4)>0){
            if ($n4['rating_short_description'] == 7)
                $n4['rating_short_description'] = 0;
             }
             else
                $n4['rating_short_description'] = 0;



            $old_startdate_timestamp_create = strtotime($values['create_date']);
            $create_date = date('Y-m-d', $old_startdate_timestamp_create);
            //get engagement status from table
            $resultEng = $this->db->query("select status from engagement_status where id='" . $engStatus . "' ");
            $engStatus = $resultEng->row_array();

            $dataInsert = array(
                "username" => $userId['id'],
                "specialty" => $theparea['id'],
                "status" => $engStatus['status'],
                "date" => $create_date,
                "kol_id" => $kolIds,
                "evaluated_by" => $mangerId['id'],
                "plan_topic1" => $p1['rating_short_description'],
                "plan_topic2" => $p2['rating_short_description'],
                "plan_topic3" => $p3['rating_short_description'],
                "plan_topic4" => $p4['rating_short_description'],
                "plan_topic5" => $p5['rating_short_description'],
                "open_topic1" => $r1['rating_short_description'],
                "open_topic2" => $r2['rating_short_description'],
                "med_topic1" => $m1['rating_short_description'],
                "med_topic2" => $m2['rating_short_description'],
                "med_topic3" => $m3['rating_short_description'],
                "med_topic4" => $m4['rating_short_description'],
                "med_topic5" => $m5['rating_short_description'],
                "med_topic6" => $m6['rating_short_description'],
                "med_topic7" => $m7['rating_short_description'],
                "wrap_topic1" => $n1['rating_short_description'],
                "wrap_topic2" => $n2['rating_short_description'],
                "wrap_topic3" => $n3['rating_short_description'],
                "wrap_topic4" => $n4['rating_short_description'],
                "planscore" => $pS['rating_short_description'],
                "openscore" => $rS['rating_short_description'],
                "medscore" => $mS['rating_short_description'],
                "wrapscore" => $nS['rating_short_description'],
                "comment" => $comment,
                "hcname" => implode(",",$noHcpIdNames),
                "ireport_id"=>$values['coaching_id']
                    );
   
            $this->db->insert("coachings", $dataInsert);
           unset($userId);
            unset($theparea);
            unset($engStatus);
           unset($managerId);
           
            unset($kolIds);
           
            $comment='';
            unset($noHcpIdNames);
            
            
            
//            echo $this->db->last_query()."<br/>";
        }
    }
    
    
    
    function interactionMapping(){
               ini_set('memory_limit',"-1");
        	ini_set("max_execution_time",0);
              $result = $this->db->query('SELECT * FROM event WHERE start_date_time LIKE "%-14" OR start_date_time LIKE "%-15" OR start_date_time LIKE "%-16"');
                foreach ($result->result_array() as $values) {
                	$customerId = $values['customer_id'];
            //email 
            $resultEmail = $this->db->query("select email_address from employee where employee_id=". $values['creator_employee_id'] . "");
            $mail = $resultEmail->row_array();

            //created_by
            $userIds = $this->db->query("select id from client_users where email='" . strtolower($mail['email_address']) . "'");
            $userId = $userIds->row_array();
            if(count($userId)==0)
                $userId['id']=0;
          
            //email 
            $resultEmailEmployee = $this->db->query("select email_address from employee where employee_id= " . $values['employee_id'] . "");
            $mailEmployee = $resultEmailEmployee->row_array();
            
            //employee_id
            $empIds = $this->db->query("select id from client_users where email='" . strtolower($mailEmployee['email_address']) . "'");
            $empId = $empIds->row_array();
            
            //teritory_id
             $resultAlignment = $this->db->query("select alignment.alignment_id from alignment "
                    . "left join event on alignment.alignment_id=event.alignment_id "
                    . "where event.alignment_id=" . $values['alignment_id'] . "");
            $teritoryId = $resultAlignment->row_array();
          
            if($values['interaction_channel']=="INPR")
                $channel=1;
               if($values['interaction_channel']=="PHON")
                $channel=2;
             if($values['interaction_channel']=="WEB")
                $channel=3;
             
               if($values['interaction_channel']=="EML")
                $channel=4;
               
               
               if($values['category']=="ONEO")
                $category=1;
               else
                   $category=2;
             /*
            * ------------------attendees-----------------------------------------
            */
            $arrKolIds = array();
            $arrOrgIds = array();
             $orgId=0;
	        $kolId= 0;
            //find kolID from customer_id
             $customerIdMap = $this->getMappingCustomerId($customerId);
             if($customerIdMap != '')
            	$customerId = $customerIdMap;
            	
            if($customerId != 0){
            		$kolIdsRes = $this->db->query("select id from kols where customer_id='" . $customerId. "'");
	            	if($kolIdsRes->num_rows() > 0){
		            	$kolId = $kolIdsRes->row_array();
		                $kolId=$kolId['id'];
	            	}
	            	
	            	if($kolId == 0){
		            	$orgIdsRes = $this->db->query("select id from organizations where customer_id='" . $customerId. "'");
		            	if($orgIdsRes->num_rows() > 0){
			            	$orgId = $orgIdsRes->row_array();
			                $orgId=$orgId['id'];
		            	}
	            	}
	            	
	            	if($kolId != 0)
		            	$arrKolIds[] = $kolId;
		            if($orgId != 0)
		            	$arrOrgIds[] = $orgId;
            }
            $events = $this->db->query("select * from event_attendee where event_id='" . $values['event_id']. "' ");
            //$eventAtendee = $events->row_array();
            foreach($events->result_array() as $eventAtendee){
            	 $customerIdMap = $this->getMappingCustomerId($eventAtendee['customer_id']);
             	if($customerIdMap != '')
            		$eventAtendee['customer_id'] = $customerIdMap;
            	
	            //kol_id
	            $orgId=0;
	            $kolId= 0;
	            if($eventAtendee['customer_type']=='PRES'){
	            	$kolIdsRes = $this->db->query("select id from kols where customer_id='" . $eventAtendee['customer_id']. "'");
	            	if($kolIdsRes->num_rows() > 0){
	            	$kolId = $kolIdsRes->row_array();
	                $kolId=$kolId['id'];
	            	}
	            }else{
	            	$orgIdsRes = $this->db->query("select id from organizations where customer_id='" . $eventAtendee['customer_id']. "'");
	            	if($orgIdsRes->num_rows() > 0){
	            	$orgId = $orgIdsRes->row_array();
	                $orgId=$orgId['id'];
	            	}
	            }
	            if($eventAtendee['customer_type']=='' || is_array($kolId))
	                $kolId=0;
	                
	            if(is_array($kolId) || !is_numeric($kolId))
	            	$kolId = 0;
	            if(is_array($orgId) || !is_numeric($orgId))
	            	$orgId = 0;
	            	
	            if($kolId != 0 && !in_array($kolId,$arrKolIds))
	            	$arrKolIds[] = $kolId;
	            if($orgId != 0 && !in_array($orgId,$arrOrgIds))
	            	$arrOrgIds[] = $orgId;
            }
            //status
            if($eventAtendee['status']=="ATTD")
                $status="Attended";
            if($eventAtendee['status']=="INVT")
                $status="invited";
            if($eventAtendee['status']=="ACPT")
                $status="Accepted";
            
            $statusChangeDate=$values["status_change_date"];
            if($statusChangeDate!=''){
            	$statusChangeDate = strtotime($statusChangeDate);
            	$statusChangeDate = date('Y-m-d', $statusChangeDate);
            }else
            	$statusChangeDate = 0;

            if($values['entry_date'] != ''){
            $dateCreated = strtotime($values['entry_date']);
            $dateCreated = date('Y-m-d', $dateCreated);
            }else
            	$dateCreated = 0;
            if($values['start_date_time'] != ''){
             $old_startdate_timestamp = strtotime($values['start_date_time']);
            $date = date('Y-m-d', $old_startdate_timestamp);
            }else
            	$date = 0;
            
            $alignmentDetails =$this->db->query("select * from alignment where alignment_id = ".$teritoryId['alignment_id']);
            $alignmentDetails = $alignmentDetails->row_array();
           $teritoryId['alignment_id'] = $alignmentDetails['alignment_name'];
           
           $saveForLater = 0;
           if($values['status'] == "OPEN")
           		$saveForLater = 1;
            $dataInsert=array(
                  "client_id"=>12,
                  "date"=>$date,
                  "fromtime"=>'',
                  "mode"=>$channel,
                  "location"=>'',
                  "reminder"=>'',
                  "notes"=>'',
                  "created_by"=>$userId["id"],
                  "created_on"=>$dateCreated,
                  "modified_by"=>"",
                    "modified_on"=>$statusChangeDate,
                    "calendar_event_id"=>'',
                  "totime"=>'',
                  "total_attendies"=>$values["total_attendee_count"],
                  "grouping"=>$category,
                  "address"=>'',
                  "country_id"=>'',
                  "city_id"=>'',
                  "state_id"=>'',"totime"=>'',
                  "postal_code"=>'',
                  "location_type"=>'',
                  "mirf_case_num"=>$values['clm_id'],
                  "territory_id"=>$teritoryId['alignment_id'],
                  "employee_id"=>$empId['id'],
                  "save_later"=>$saveForLater,
                 "is_org_interaction"=>'',
                 "otsuka_id" => $values['event_id']
                  ) ;
                  //pr($dataInsert);
        	$this->db->insert("interactions",$dataInsert); 
           	$lastId= $this->db->insert_id();
          
           
           /*
            * Insert into interactions_attendees
            */
           $this->db->query("SET FOREIGN_KEY_CHECKS=0");
           foreach($arrKolIds as $kolId){
	           $dataInsert=array(
	                  "interaction_id"=>$lastId,
	               
	                  "kol_id"=>$kolId,
	                  "org_id"=>NULL,
	                  "specialty_id"=>NULL,
	                  "category_id"=>0,
	                  "role_id"=>0,
	                  "note"=>0,
	                  "status"=>$status
	                  ) ;
	                  
	             $this->db->insert("interactions_attendees",$dataInsert);
           }
          	foreach($arrOrgIds as $orgId){
	           $dataInsert=array(
	                  "interaction_id"=>$lastId,
	               
	                  "kol_id"=>NULL,
	                  "org_id"=>$orgId,
	                  "specialty_id"=>NULL,
	                  "category_id"=>0,
	                  "role_id"=>0,
	                  "note"=>0,
	                  "status"=>$status
	                  ) ;
	                  
	             $this->db->insert("interactions_attendees",$dataInsert);
           }
             /*
            * Insert into non_attendees
            */
           $contacts = $this->db->query("select * from event_contact where event_id='" . $values['event_id']. "'");
           //pr($contacts->result_array());
           //$eventContact = $contacts->row_array();
           foreach($contacts->result_array() as $eventContact){
 			$dataInsert=array(
                  "interaction_id"=>$lastId,
               
                  "name"=>$eventContact['name'],
                  "specialty_id"=>'',
                 
                  ) ;
             $this->db->insert("interactions_other_attendees",$dataInsert); 
           }
             
             /**
              * product topic subtopic
              * 
              * 
              * 
              */
           
             $topics = $this->db->query("SELECT	* FROM event_dynamic where table_id=7888500000001957  and event_id='" . $values['event_id']. "'");
             //pr($topics->result_array());
             //$eventTopic = $topics->row_array();
             foreach($topics->result_array() as $eventTopic){
            $productId = 0;
             $productIds = $this->db->query("SELECT id from products where otsuka_id='" . $eventTopic['text_1'] . "'");
           $productId = $productIds->row_array();
           $type = 0;
      		if($eventTopic['code_1']=="OORE" || $eventTopic['code_1']=="GRRE" || $eventTopic['code_1']=="REAC")
                $type=1;
            if($eventTopic['code_1']=="OOPP" || $eventTopic['code_1']=="GRPP")
                $type=2;
                    if($eventTopic['code_1']=="OOPN" || $eventTopic['code_1']=="GRPN")
                $type=3;
                   if($eventTopic['code_1']=="OINT")
                $type= 4;
                if($eventTopic['code_1']=="RACD")
                $type= 5;
                if($eventTopic['code_1']=="OPND")
                $type= 6; 
                   if($type=='')
                       $type=0;
              $topicId = 0;
              $arrTopics = $this->db->query("SELECT id from interaction_topics where code='" . $eventTopic['code_2'] . "'");
               $topicId = $arrTopics->row_array();
               $subtopicId = 0;
              $arrSubTopics = $this->db->query("SELECT id from interaction_sub_topics where code='" . $eventTopic['code_3'] . "'");
               $subtopicId = $arrSubTopics->row_array();
                $dataInsert=array(
                  "interaction_id"=>$lastId,               
                  "product_id"=>$productId['id'],
                  "interaction_type"=>$type,
                  "topic_id"=>$topicId['id'],                 
                  "sub_topic_id"=>$subtopicId['id']
                  
                  ) ;
                    
             $this->db->insert("interactions_discussion_topic_mapped_data",$dataInsert); 
             }
        }
        
        }
        
        
        
         function mappingOrg(){
            ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
            $result = $this->db->query("select * from  organizations where customer_id is not null ");
$i=0;
        foreach ($result->result_array() as $values) { 
            $i++;
//            if(!empty($values['customer_id'])){
             $updateDataArray=array();
            if($values['org_type']=="HOSP"){
                    $hospital = $this->db->query("select type,specialty,physician_count,admission_per_year,teaching,external_pharmacy,medical_zone,total_bed_count,accreditation,committee_frequency,committee_day,committee_comment from hospital where customer_id=" . $values['customer_id']);
//                  $hospital = $this->db->query("select type,specialty,physician_count,admission_per_year,teaching,external_pharmacy,medical_zone,total_bed_count,accreditation,committee_frequency,committee_day,committee_comment from hospital where  customer_id='10099000102167'");
                     $hosp = $hospital->row_array();
//                    
                     $institution_type=$hosp['type'];
                     $specialty=$hosp['specialty'];
                     $physician_count=$hosp['physician_count'];
                     $admission_per_year=$hosp['admission_per_year'];
                     $Research=$hosp['teaching'];
                     $irb_present=$hosp['external_pharmacy'];
                     $foundation=$hosp['medical_zone'];
                     $number_of_beds=$hosp['total_bed_count'];
                     $licensing_opertunities=$hosp['accreditation'];
                     $ists=$hosp['committee_frequency'];
                     $csts=$hosp['committee_day'];
                     $ceo_name=$hosp['committee_comment'];
              
            }
            if($values['org_type']=="MCO"){
                    $mco = $this->db->query("select mco_type from managed_care where customer_id=" . $values['customer_id']);
                    $mco_type = $mco->row_array();
            }
            if($values['org_type']=="DEPT"){
                    $department = $this->db->query("select bed_count from department where customer_id=" . $values['customer_id']);
                    $number_of_bed = $department->row_array();
                    $number_of_beds=$number_of_bed['bed_count'];
                    $specialty=$this->db->last_query("select customer_sub_type from customer=" . $values['customer_id']);
                    $specialties = $specialty->row_array();
                    $specialty=$specialties['customer_sub_type'];
            }
            
            if($values['org_type']=="PHAR"){
                    $pharmacy = $this->db->query("select rx_volume_range,area from pharmacy where customer_id=" . $values['customer_id']);
                    $pharma = $pharmacy->row_array();
                    $rx_vol=$pharma['rx_volume_range'];
                    $size=$pharma['area'];
                    $specialty=$this->db->last_query("select customer_sub_type from customer=" . $values['customer_id']);
                    $specialties = $specialty->row_array();
                    $specialty=$specialties['customer_sub_type'];
                    
            }
           if(!empty($specialty))
               $updateDataArray['specialty']=$specialty;
            if(!empty($institution_type))
               $updateDataArray['institution_type']=$institution_type;
              if(!empty($physician_count))
               $updateDataArray['num_of_physician']=$physician_count;
              if(!empty($admission_per_year))
               $updateDataArray['admission_per_year']=$admission_per_year;
               if(!empty($Research))
               $updateDataArray['research']=$Research;
                if(!empty($irb_present))
               $updateDataArray['irb_present']=$irb_present;
                  if(!empty($foundation))
               $updateDataArray['foundation']=$foundation;
                   if(!empty($number_of_beds))
               $updateDataArray['number_of_beds']=$number_of_beds;
                    if(!empty($licensing_opertunities))
               $updateDataArray['licensing_opertunities']=$licensing_opertunities;
                     if(!empty($ists))
               $updateDataArray['ists']=$ists;
                      if(!empty($csts))
               $updateDataArray['csts']=$csts;
                        if(!empty($ceo_name))
               $updateDataArray['ceo_name']=$ceo_name;
                        if(!empty($mco_type['mco_type']))
               $updateDataArray['mco_type']=$mco_type['mco_type'];
                         if(!empty($rx_vol))
               $updateDataArray['rx_vol']=$rx_vol;
                          if(!empty($size))
               $updateDataArray['size']=$size;
               
//            $updateDataArray = array(
//                "institution_type" => $institution_type,
//                "specialty" => $specialty,
//                "num_of_physician" => $physician_count,
//                "admission_per_year" => $admission_per_year,
//                "research" => $Research,
//                "irb_present" => $irb_present,
//                "foundation" => $foundation,
//                "number_of_beds" => $number_of_beds,
//                "licensing_opertunities" => $licensing_opertunities,
//                "ists" => $ists,
//                "csts" => $csts,
//                "ceo_name" => $ceo_name,
//                "mco_type" => $mco_type['mco_type'],
//                "rx_vol" => $rx_vol,
//                "size" => $size,
//                    );
            $this->db->where('customer_id',$values['customer_id']);
            $this->db->update("organizations", $updateDataArray);
//echo $this->db->last_query();
//            }

        }
        pr($i);
        }
        
        
	function getMappingCustomerId($customerId){
		$customerIdMap = '';
		$res = $this->db->query("SELECT customer_id_map from consolidated_list_dup_map where customer_id='" . $customerId . "'");
		if(is_object($res) && $res->num_rows() > 0){
	    	$rowData = $res->row_array();
	    	$customerIdMap = $rowData['customer_id_map'];
		}
		
		return $customerIdMap;
	}
}