<style type="text/css">
	
	.userTable{
	  <?php if($userRoleId == ROLE_ADMIN){?>
		margin-left:240px;
	  <?php } else { ?>
                margin-left:40px;
          <?php } ?>
	}
        .formButtons{
              <?php if($userRoleId == ROLE_ADMIN){?>
                text-align: left;
              <?php } ?>
        }
	.userTable .labelForfields{
		float:left;
		font-size:16px;
		margin-right:38px;
		text-align:right;
		width:100px;
		font-family:lucida Grande;
                <?php if (!IS_IPAD_REQUEST) { ?>
                    margin-top:-2px;
                <?php } else { ?>
                     margin-top:5px;
                <?php } ?>
	}               
	.userTable input[type="text"],input[type="password"]{
		margin-left:-29px;
		margin-top:0;
		<?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
	
	}	
	.userTable select{
		margin-left:-29px;
		margin-top:0;
                <?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
		
	}
	.userTable input[type="button"]{
              <?php if($userRoleId != ROLE_ADMIN){?>
		margin-right:48px;
                
              <?php } else { ?>
                margin-left: 58px;
              <?php } ?>
                width:70px;
		text-align:center;
		
	}
	span.require {
    color: #F00;
    }	
	.userTable label.error {
		background:none repeat scroll 0 0 transparent;
		border:0 none;
		color:red;
		font-weight:normal;
		margin:0;
		padding:0;
		text-align:center;
	}
	select.error{
		padding:0px;
	}
        <?php if (IS_IPAD_REQUEST) { ?>
        .ipadCSS{
            
    /* display: block; */
    width: 100%;
    height: 30px;
    padding:0px !important; 
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;

        }
        <?php } ?>
	</style>
		<script>
	var validationRules	=  {
			City: {
				required:true
			},
			CountryID: {
				required:true
			}
		};
		var validationMessages = {
		City: {
			required: "xax"
		},
		CountryID: {
			required: "xax"
		}
		};
		function closeDialog(){
			$("#userContainer").dialog("close");
		}
	</script>
<!-- <h1>Add New User</h1> -->
	<div class="clientUserMsgBox"></div>
<form action="#"   method="post" name="saveStateform" id="saveStateform" class="validateForm" style="width:450px">
	<input type="hidden" name="RegionID" id="RegionID" value="<?php if(isset($Statedetails->RegionID)){ echo $Statedetails->RegionID; }?>"></input>
		<table class="anaylystForm clientTbl userTable">
		    <tr>
				<td>
					<div class="labelForfields">Country:<span class="require">*</span></div>
					<select name="CountryID" name="CountryID" id="CountryID"  class="required ipadCSS">
						<option value="">-- Select --</option>
						<?php
						$selected	= '';
						foreach( $arrCountry as $country ){
							$selected	= '';
							if($Statedetails->CountryID===$country['country_id']){
								$selected	= ' selected="selected"';
							}
						?>
							<option value="<?php echo $country['country_id'];?>" <?php echo $selected;?>>
								<?php echo $country['country_name'];?>
							</option>
						<?php }?>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">State Name<span class="require">*</span></div>
                    :<input type='text' id="Region" name="Region" placeholder='State name' class="required ipadCSS"  value="<?php if(isset($Statedetails->Region)){ echo $Statedetails->Region; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Code</div>
                    :<input type='text' name="Code" placeholder='Code' value="<?php if(isset($Statedetails->Code)){ echo $Statedetails->Code; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="formButtons">
                     <input type="button" value="Save" name="submit" onclick="saveStateDetails();" class="ipadCSS"></input>
                     <input type="button" value="Cancel" onclick=closeDialog()></input>
                     </div>
				</td>
			</tr>
	</table>
<!-- End of Table -->
</form>