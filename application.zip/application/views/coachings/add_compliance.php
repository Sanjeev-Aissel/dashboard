<?php
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket', 'jquery/jquery.validate1.9.min',
    'chosen.jquery', 'signature_pad'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));

$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
$userId = $this->uri->segment(3);

if ($userId != '' && $userId != 0) {
    $currentMethod = "edit_compliance";
}
?>
<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, NoCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
$GLOBALS['count'] = 0;
$GLOBALS['countOrg'] = 0;
?>
  
<style type="text/css">

    .spanImp{
        color:#FF0000;    
    }
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        
        background: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#medContainer{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    /*  input{
       
       width:274px;
       }*/

    .alignment{
        width: 282px;
        margin-left: 207px; 
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    table caption{
        background:#ececec;
    }
    /*	table {
            border: 1px solid #DDDDDD;
        }*/
    table th{
        vertical-align: top;
    }
    tr.tableSubHeader th{
        background-color:#ececec;
    }
    . {
        background-color: #F5F5F5;
    }
    div.deleteIcon{
        float: None;
    }
    .type, .product, .topic{
        width:100%;
    }
    #organization, #organization_chzn {
        <?php if ($currentMethod == "edit_compliance") { ?>
            display: block;
        <?php } else { ?>
            display: None;
        <?php } ?>
    }
    #objectiveTable select{
        width: 200px;
    }
    #medContainer .add-icon{
        background-image: url("<?php echo base_url(); ?>images/add_active.png");
        display: inline-block;
        height: 31px;
        width: 25px;
        cursor: pointer;
        background-repeat: No-repeat;
        background-position: 1px 1px;
        background-size: 20px;
        margin-bottom: -13px; 
    }
    #medContainer .remove-icon{
        background-image: url("<?php echo base_url(); ?>images/delete_active.png");
        display: inline-block;
        height: 31px;
        width: 25px;
        cursor: pointer;
        background-repeat: No-repeat;
        background-position: 1px 1px;
        background-size: 20px;
        margin-bottom: -13px;
    }

    .m-signature-pad {
        position: absolute;
        font-size: 10px;
        width: 600px;
        height: 200px;
        top: 50%;
        left: 50%;
        margin-left: -350px;
        margin-top: -200px;
        border: 1px solid #e8e8e8;
        background-color: #fff;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.27), 0 0 40px rgba(0, 0, 0, 0.08) inset;
        border-radius: 4px;
    }

    .m-signature-pad:before, .m-signature-pad:after {
        position: absolute;
        z-index: -1;
        content: "";
        width: 40%;
        height: 10px;
        left: 20px;
        bottom: 10px;
        background: transparent;
        -webkit-transform: skew(-3deg) rotate(-3deg);
        -moz-transform: skew(-3deg) rotate(-3deg);
        -ms-transform: skew(-3deg) rotate(-3deg);
        -o-transform: skew(-3deg) rotate(-3deg);
        transform: skew(-3deg) rotate(-3deg);
        box-shadow: 0 8px 12px rgba(0, 0, 0, 0.4);
    }

    .m-signature-pad:after {
        left: auto;
        right: 20px;
        -webkit-transform: skew(3deg) rotate(3deg);
        -moz-transform: skew(3deg) rotate(3deg);
        -ms-transform: skew(3deg) rotate(3deg);
        -o-transform: skew(3deg) rotate(3deg);
        transform: skew(3deg) rotate(3deg);
    }

    .m-signature-pad--body {
        position: absolute;
        left: 20px;
        right: 20px;
        top: 20px;
        bottom: 60px;
        border: 1px solid #f4f4f4;
    }

    .m-signature-pad--body
    canvas {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        border-radius: 4px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.02) inset;
    }

    .m-signature-pad--footer {
        position: absolute;
        left: 20px;
        right: 20px;
        bottom: 20px;
        height: 40px;
    }

    .m-signature-pad--footer
    .description {
        color: #C3C3C3;
        text-align: center;
        font-size: 1.2em;
        margin-top: 1.8em;
    }

    .m-signature-pad--footer
    .button {
        position: absolute;
        bottom: 0;
    }

    .m-signature-pad--footer
    .button.clear {
        left: 0;
    }

    .m-signature-pad--footer
    .button.save {
        right: 0;
    }

    @media screen and (max-width: 1024px) {
        .m-signature-pad {
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: auto;
            height: auto;
            min-width: 250px;
            min-height: 140px;
            margin: 5%;
        }
        #github {
            display: None;
        }
    }
    .orgErr{
        color:#ff0000;   
    }

    .kolErr{
        color:#ff0000;  
    }
    @media screen and (min-device-width: 768px) and (max-device-width: 1024px) {
        .m-signature-pad {
            margin: 10%;
        }
    }

    @media screen and (max-height: 320px) {
        .m-signature-pad--body {
            left: 0;
            right: 0;
            top: 0;
            bottom: 32px;
        }
        .m-signature-pad--footer {
            left: 20px;
            right: 20px;
            bottom: 4px;
            height: 28px;
        }
        .m-signature-pad--footer
        .description {
            font-size: 1em;
            margin-top: 1em;
        }
    }
	th, td, caption{
		vertical-align: top;
	}
</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">

<div id="medContainer"><?php 
pr()?>
	<div id="addFormWrapper">
		<h5 class="heading"><?php if ($currentMethod == "edit_compliance") {echo 'Edit';}else{echo 'New';}?> Compliance Monitoring</h5>
	</div>
    <form id="complianceForm" action="<?php echo base_url(); ?>coachings/save_compliance" method="post">
        <?php
        if ($currentMethod == "edit_compliance") {
            ?>
            <input type="hidden" name="compliance_id" value="<?php if (isset($arrComplianceData['id']) && $reloadFlag!=1) echo $arrComplianceData["id"]; ?>">
        <?php } ?>
        <table>
            <tr class="evenRow">
                <th>01)</th><th>Name of FMA <span class="spanImp">*&nbsp;</span>:</th>
                <td colspan="2">
                    <select name="fma" class=" alignment required" onchange="checkPreviousEntry(this);">
                        <option value=''>Select User</option>
                        <?php
                        if(count($interactionDetails)==0){
                        if ($currentMethod == "edit_compliance" && count($interactionDetails)==0) {
                            foreach ($arrClientUsers as $key => $row) {
                                if ($arrComplianceData['fma'] != $row['id']) {
                                    echo '<option value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                                } else {
                                    echo '<option value="' . $row['id'] . '" selected>' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                                }
                            }
                        } else {
                            foreach ($arrClientUsers as $key => $row) {
                                
                                    echo '<option  value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                            }
                        }
                        }
                         else {
                              foreach ($arrClientUsers as $key => $row) {
                                if ( $row['id'] == $interactionDetails["employee_id"])
                                    echo '<option selected value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                                else
                                    echo '<option  value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                            }
                           
                        }
                       
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="">
                <th>02)</th><th>Name of Monitor<span class="spanImp">*&nbsp;</span>:</th>
                <td colspan="2"><span class="alignment"> <select style="margin-left:0" id="location" name="monitored_by" class=" alignment required">
                        <option value="">Select</option>
                        <?php
                        if ($currentMethod == "edit_compliance" )  {
                           
                            foreach ($managers as $key => $valueE) {
                                if (($valueE['id']==$arrComplianceData['monitored_by'] ) ) {
                                    echo '<option value="' . $valueE['id'] . '" selected>' . $valueE['first_name']." ".$valueE['last_name'] . '</option>';
                                } else {
                                    echo '<option value="' . $valueE['id'] . '">' . $valueE['first_name']." ".$valueE['last_name'] . '</option>';
                                }
                            }
                        } else {
                            foreach ($managers as $key => $value) {
                                echo '<option value="' . $value['id'] . '">' . $value['first_name']." ".$value['last_name'] . '</option>';
                            }
                        }
                        
                        if(count($interactionDetails)>0){
                           foreach ($managers as $key => $valueE) {
                                if (($valueE['id']==$this->session->userdata('user_id') ) ) {
                                    echo '<option value="' . $valueE['id'] . '" selected>' . $valueE['first_name']." ".$valueE['last_name'] . '</option>';
                                } else {
                                    echo '<option value="' . $valueE['id'] . '">' . $valueE['first_name']." ".$valueE['last_name'] . '</option>';
                                }
                            } 
                        }
                        ?>
                    </select></span></td>
            </tr>
            <tr class="evenRow">
                <th>03)</th><th style="width:315px;">Date of Visit <span class="spanImp">*&nbsp;</span>:</th>
                <td colspan="2"><input style="margin-left:208px;width:274px" id="date" class="alignment required" type="text" name="date" value="<?php
                      if ($currentMethod == "edit_compliance" || count($interactionDetails)>0){
                          if(count($interactionDetails)>0)
                            echo $interactionDetails['date'];
                          else
                              echo $arrComplianceData['date'];
                      }
                        else
                            echo date('m/d/Y');
                        ?>" id="date" /></td>
            </tr>
            <tr class="">
                <th>04)</th><th>Location(s) of interactions observed during visit <span class="spanImp">*&nbsp;</span>:</th>
                <td colspan="2">
                    <select id="locations" name="location[]" class=" alignment required">
                        <option value="">Select</option>
                        <?php 
                        if (($currentMethod == "edit_compliance")) {
                            $arrSelectedLocations = explode(",", $arrComplianceData["location"]);
                            foreach ($arrLocations as $key => $value) {
                                if (in_array($key, $arrSelectedLocations)) {
                                    echo '<option value="' . $key . '" selected>' . $value . '</option>';
                                } else {
                                    echo '<option value="' . $key . '">' . $value . '</option>';
                                }
                            }
                        } else {
                            foreach ($arrLocations as $key => $value) {
                                echo '<option value="' . $key . '">' . $value . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>

            <tr class="evenRow">
                    <!--<th>05)</th><th>KOL(s) in Attendance</th>-->
                <th>05)</th>
                <th>KTL's <span class="spanImp">*&nbsp;</span>:</th>
                <?php if ($currentMethod != "edit_compliance") {
                    ?>

                    <td id="kolSearch"><?php if (count($interactionDetails) == 0) { ?>
                            <input style="margin-left:208px;width:274px" id="kolName"  class="alignment autocompleteInputBox" autocomplete="off" type="text" placeholder="Search <?php echo ""; ?>" /><a class="add-icon" onclick="addMoreKols()"></a><span id="moreKol"></span><span class='kolErr'></span>
    <?php } ?>
                        <?php
                        if (count($interactionDetails) > 0) {

 
                            echo "<input style=\"margin-left:208px;width:274px\" id='kolName'  class='required autocompleteInputBox required' autocomplete='off' value='" . preg_replace('#<a.*?>([^>]*)</a>#i', '$1', $interactionDetails['kol_name']) . "' type='text' placeholder='Search KTL' /><a class='add-icon' onclick=\"addMoreKols()\"></a><span id=\"moreKol\"></span>";
                            echo "<input type='hidden' class='kolName_hidden'  name=kol[] value='" . $interactionDetails['kol_id'] . "'>";
                        }
                        ?>
                    </td>



                    <?php } ?>




<?php if ($currentMethod == "edit_compliance") {
    ?>
                    <td id="kolSearch" >
    <?php
    $flag = 0;
    foreach ($arrComplianceKOLs as $kolIds) {
        if ($flag == 0) {
            $flag = 1;
            echo "<input id='kolName' style=\"margin-left:208px\" class='alignment autocompleteInputBox ' autocomplete='off' value='" . $kolIds['first_name'] . ' ' . $kolIds['middle_name'] . ' ' . $kolIds['last_name'] . "' type='text' placeholder='Search KTL' /><a class='add-icon' onclick=\"addMoreKols()\"></a><span id=\"moreKol\"></span>";
            echo "<input type='hidden' class='kolName_hidden'  name=kol[] value='" . $kolIds['id'] . "'>";
        } else {
            $count = $count + 1;
            echo "<br class='kolName" . $count . "br'/><input id='kolName" . $count . "' value='" . $kolIds['first_name'] . ' ' . $kolIds['middle_name'] . ' ' . $kolIds['last_name'] . "' style=\"margin-left:208px\" class='alignment autocompleteInputBox kolName" . $count . "' autocomplete='off' type='text' placeholder='Search KTL' /><a class='remove-icon' onclick=\"removeMoreKols('kolName" . $count . "',this)\"></a>";
            echo "<input type='hidden' class='kolName" . $count . "_hidden'  name=kol[] value='" . $kolIds['id'] . "'>";
        }
    }

    if (count($arrComplianceKOLs) == 0) {
        echo "<input id='kolName' style=\"margin-left:208px\" class='alignment autocompleteInputBox ' autocomplete='off' value='' type='text' placeholder='Search KTL' /><a class='add-icon' onclick=\"addMoreKols()\"></a><span id=\"moreKol\"></span>";
    }
}
?>

            </tr>
            <tr class="evenRow">
               <!--<th>05)</th><th>KOL(s) in Attendance</th>-->
                <th></th>
                <th>HCO's :</th>
                    <?php if ($currentMethod != "edit_compliance") {
                        ?>
                    <td id="orgSearch"><input id='orgName' style="margin-left:208px;width:274px" class='alignment autocompleteInputBox ' autocomplete='off' type='text' placeholder='Search HCO' value='' /><a class='add-icon' onclick="addMoreOrgs()"></a><span id="moreOrg"></span><span class='orgErr'></span></td>
<?php } ?>

<?php if ($currentMethod == "edit_compliance") {
    ?>

                    <td id="orgSearch" colspan="2">
                    <?php
                    $orgFlag = 0;
                    foreach ($arrComplianceOrgs as $orgIds) {
                        if ($orgFlag == 0) {
                            $orgFlag = 1;
                            echo "<input class='firstOrg' id='orgName' style=\"margin-left:208px;width:282px\"  class='autocompleteInputBox alignment' autocomplete='off' value='" . $orgIds['name'] . "' type='text' placeholder='Search Org' /><a class='add-icon' onclick=\"addMoreOrgs()\"></a><span id=\"moreOrg\"></span><span class='orgErr'></span>";
                            echo "<input id='firstOrg' type='hidden' class='orgName_hidden'  name=org[] value='" . $orgIds['id'] . "'>";
                        } else {
                            $countOrg = $countOrg + 1;
                            echo "<br class='orgName" . $countOrg . "br'/><input id='orgName" . $countOrg . "' value='" . $orgIds['name'] . "' style=\"margin-left:208px\" class='autocompleteInputBox alignment orgName" . $countOrg . "' autocomplete='off' type='text' placeholder='Search Organaization' /><a class='remove-icon' onclick=\"removeMoreOrgs('orgName" . $countOrg . "',this)\"></a>";
                            echo "<input type='hidden' class='orgName" . $orgIds . "_hidden'  name=kol[] value='" . $orgIds['id'] . "'>";
                        }
                    }

                    if (count($arrComplianceOrgs) == 0) {
                        echo "<input id='orgName' style=\"margin-left:208px;width:282px\"  class='autocompleteInputBox alignment' autocomplete='off' value='' type='text' placeholder='Search Org' /><a class='add-icon' onclick=\"addMoreOrgs()\"></a><span id=\"moreOrg\"></span><span class='orgErr'></span>";
                    }
                }
                ?>

            </tr>

            <tr >
                <th></th><th>Location <span class="spanImp">*&nbsp;</span>:</th> 
                <td colspan="2">
                    <select style="margin-left: 207px !important; width:138px !important;" id='state_id' name="state" class=" alignment required" onchange="getCitiesByStateId()">
                        <option value="">Select State</option>
                    <?php
                    if ($currentMethod == "edit_compliance" || count($interactionDetails) > 0) {
                        foreach ($arrStates as $key => $value) {
                            if ($value["state_id"] == $arrLocationId[0] ||  $value['state_id']==$interactionDetails['state_id'])
                                echo '<option selected value="' . $value["state_id"] . '">' . $value["state_name"] . '</option>';
                            else
                                echo '<option  value="' . $value["state_id"] . '">' . $value["state_name"] . '</option>';
                        }
                    } else {
                        foreach ($arrStates as $key => $value) {
                            echo '<option value="' . $value["state_id"]. '">' . $value["state_name"] . '</option>';
                        }
                    }
                    ?>
                    </select>
                   
                    <select  style="margin-left: 0 !important;width:141px !important;" id='city_id' name="city" class=" alignment required">
                        <option value="">Select City</option>
                        <?php
                        if ($currentMethod == "edit_compliance" || count($interactionDetails) > 0) {
                            foreach ($arrCity as $value) {
                                if ($value['city_id'] == $arrLocationId[1] || $value['city_id']==$interactionDetails['city_id'])
                                    echo '<option selected value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                                else
                                    echo '<option  value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                            }
                        } else {
                            
                        }
                        ?>
                    </select>
                     <img id="loader" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:None"/>
            
                </td>
<!--                  <td >
                    <select  style="margin-left: 0 !important;" id='city_id' name="city" class=" alignment required">
                        <option value="">Select</option>
                        <?php
                        if ($currentMethod == "edit_compliance" || count($interactionDetails) > 0) {
                            foreach ($arrCity as $value) {
                                if ($value['city_id'] == $arrLocationId[1] || $interactionDetails['city_id'])
                                    echo '<option selected value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                                else
                                    echo '<option  value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                            }
                        } else {
                            
                        }
                        ?>
                    </select>
                </td>-->
            </tr>
<!--                <tr class="">
                <th></th><th><span class="spanImp">*&nbsp;</span>City<?php ?></th>
                <td colspan="2">
                    <select id='city_id' name="city" class=" alignment required">
                        <option value="">Select</option>
                <?php
                if ($currentMethod == "edit_compliance" ) {
                    foreach ($arrCity as $value) {
                        if ($value['city_id'] == $arrLocationId[1] )
                            echo '<option selected value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                        else
                            echo '<option  value="' . $value['city_id'] . '">' . $value["city_name"] . '</option>';
                    }
                } else {
                    
                }
                ?>
                    </select>
                </td>
            </tr>-->
            <tr class="evenRow">
<!--				<th>06)</th><th>Interaction Grouping</th>-->
                <th>06)</th><th>Interaction Category <span class="spanImp">*&nbsp;</span>:</th>
                <td colspan="2"><select name="interaction_type" class=" alignment required" id="groupId"><option value="">Select</option>
            <?php if ($currentMethod == "edit_compliance" || count($interactionDetails) > 0) {
                ?>
                            <option value="1" <?php if ($arrComplianceData["interaction_type"] == "1" || $interactionDetails['group_name']=='One-on-One' ) echo "selected"; ?>>One-on-One</option>
                            <option value="2" <?php if ($arrComplianceData["interaction_type"] == "2" || $interactionDetails['group_name']=='Group') echo "selected"; ?>>Group</option>
    <?php
} else {
    ?>
                            <option value="1" >One-on-One</option>
                            <option value="2" >Group</option>                           
                        <?php } ?>
                    </select></td>
            </tr>

            <tr class="evenRow">
                <th>07)</th>
                <td colspan="3">

<?php
//                        if ($currentMethod == "edit_compliance") {
//                            for ($i = 0; $i < count($arrComplianceTopics["topic_names"]); $i++) {
?>
<!--                                <tr>
                 <td><select name="visit_type" class="type" onchange="getProducts(this, 0)">
                         <option>Select  Type</option>-->
<?php
//                                            $product = $arrComplianceTopics["types"][$i];
//                                            foreach ($arrTypes as $key => $row) {
//                                                echo '<option value="' . $row['id'] . '"';
//                                                if ($product == $row['name'])
//                                                    echo "selected";
//                                                echo '>' . $row['name'] . '</option>';
//                                            }
?>
                    <!--                                        </select>
                                                        </td>
                                                        <td><select name="product" class="product" onchange="getTopics(this, 0)">
                                                                <option>Select Product</option>
                                                            </select>
                                                        </td>
                                                        <td><select name="topics[]" class="topic">
                                                                <option>Select Topic</option>
                                                            </select>
                                                        </td>
                                                        <td><div onclick="deleteRow(this, 0);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></td>
                                                    </tr>-->
<?php
//                            }
//                        }
?>
                    <!--                        <tr>
                    <td>Proactive Promotional</td>
                    <td>Abilify</td>
                    <td><input type="hidden" name="topics[]" class="1_1_2" value="1_1_2">Label/Safety Warning Update</td>
                    <td><div onclick="deleteRow(this, 0);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></td>
                    </tr>-->
                  
                    <table id="objectiveTable" class="highlightHeadings tabularGrid">
                       <caption>Purpose of Visit
                            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                            </div>
                        </caption>
                        <tr>
                          
                            <th class="alignCenter"><label for="product">Product<span class="required">*</span></label></th>
                            <th class="alignCenter"><label for="objective">Interaction Type<span class="required">*</span></label></th>
                            <th class="alignCenter"><label for=topic>Topic<span class="required">*</span></label></th>
                            <th class="alignCenter"></th>
                            <th></th>
                            <th>&nbsp;</th>
                        </tr>
<?php if (!isset($arrComplianceData['id']) && count($interactionDetails)==0) { ?>
                            <input type="hidden" id="NoOfObjectives" value="0" name="NoOfObjectives"></input>
                            <tr id="objective">
                                <td class="alignCenter">
                                    <p>
                                        <select name="product"  id="product" class="required" onchange="resetDropDowns(this)">
                                            <option value="">Select</option>
    <?php foreach ($arrProduct as $row) { ?>
                                                <option value="<?php echo $row['id']; ?>">
                                <?php echo $row['name']; ?>
                                                </option>
    <?php } ?>
                                        </select>
                                        <img id="loadingProduct" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:None"/>
                                    </p>
                                </td>
                                <td class="alignCenter">
                                    <p>
                                        <select name="objective"  id="objective"  onchange="getTopic(this)" class="required">
                                            <option value="">Select</option>	
                                            <?php foreach ($arrType as $row) { ?>
                                                <option value="<?php echo $row['id']; ?>">
        <?php echo $row['name']; ?>
                                                </option>
    <?php } ?>
                                        </select>
                                    </p>
                                </td>
                                <td class="alignCenter">
                                    <p>
                                        <select name="topic"  id="topic" class="required">
                                            <option value="">Select</option>	
                                        </select>
                                        <img id="loadingTopic" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:None"/>
                                    </p>
                                </td>
                                <td class="alignCenter">
                                    <p>

                                    </p>
                                </td>
                                <td>
                                    <p></p>
                                </td>
                                <td class="TextAlignCenter">
                                    <label id="addMoreObjectives"><img src="<?php echo base_url(); ?>images/add_active.png" alt="Add" title="Add"/></label>
                                </td>
                            </tr>
<?php } else {  ?>
                            <input type="hidden" id="NoOfObjectives" value="<?php echo $arrComplianceData['NoOfObjectives'] ?>" name="NoOfObjectives"></input>
    <?php $objectiveNo = '';  
    foreach ($arrDiscussion as $topicKey => $arrDiscussionData)  {
        ?>
                                <tr id="objective">
                                    <td>
                                        <p>
                                            <select name="product<?php echo $objectiveNo ?>"  id="product<?php echo $objectiveNo ?>" onchange="resetDropDowns(this)" class="required">
                                                <option value="">Select</option>	
                                <?php foreach ($arrDiscussionData['arrProducts'] as $product) { ?>
                                                    <option value="<?php echo $product['id']; ?>" <?php if ($product['id'] == $arrDiscussionData['row']['product_id']) echo 'SELECTED'; ?>>
                                    <?php echo $product['name']; ?>
                                                    </option>
        <?php } ?>
                                            </select>
                                            <img id="loadingProduct" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:None"/>
                                        </p>
                                    </td>
                                    <td><p>
                                            <select name="objective<?php echo $objectiveNo ?>"  id="objective<?php echo $objectiveNo ?>"  onchange="getTopic(this)" class="required">
                                                <option value="">Select</option>	
                                                <?php foreach ($arrDiscussionData['arrTypes'] as $key => $objective) { ?>
                                                    <option value="<?php echo $objective['id']; ?>" <?php if ($objective['id'] == $arrDiscussionData['row']['type_id']) echo 'SELECTED'; ?>>
            <?php echo $objective['name'] ?>
                                                    </option>
        <?php } ?>
                                            </select>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <select name="topic<?php echo $objectiveNo ?>"  id="topic<?php echo $objectiveNo ?>" onchange="getSubTopic(this)" class="required">
                                                <option value="">Select</option>	
                                                <?php foreach ($arrDiscussionData['arrTopics'] as $key => $value) { ?>
                                                    <option value="<?php echo $value['id']; ?>" <?php if ($value['id'] == $arrDiscussionData['row']['topic_id']) echo 'SELECTED'; ?>>
            <?php echo $value['name']; ?>
                                                    </option>
        <?php } ?>
                                            </select>
                                            <img id="loadingTopic" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:None"/>
                                        </p>
                                    </td>
                                    <td><p>

                                        </p>
                                    </td>
                                    <td>
                                        <p></p>
                                    </td>
                                    <td class="TextAlignCenter">
        <?php if ($topicKey == 0) { ?>
                                            <label id="addMoreObjectives"><img src="<?php echo base_url(); ?>images/add_active.png" alt="Add" title="Add"/></label>
        <?php } else { ?>
                                            <label id="deleteMoreObjectives"><img src="<?php echo base_url(); ?>images/delete_active.png" alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
        <?php } ?>
                                    </td>
                                </tr>
        <?php $objectiveNo++;
    }
}
?>
                    </table>

                    <table style="margin-top:5px; display: None;">
                        <caption style="font-weight: bold;">Additional Topic(s): (Optional)</caption>
                        <tr class="tableSubHeader">
                            <th style="text-align: center;width:25%;">Type</th><th style="text-align: center;width:25%;">Product</th><th style="text-align: center;width:50%;">Topic</th><th></th>
                        </tr>
                        <tr>
                            <td><select name="additional_visit_type" class="type" onchange="getProducts(this, 1)">
                                    <option>Select  Type</option>
<?php 
foreach ($arrTypes as $key => $row) {
    echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
}
?>
                                </select>
                            </td>
                            <td><select name="additional_product" class="product" onchange="getTopics(this, 1)">
                                    <option>Select Product</option>
                                </select>
                            </td>
                            <td><select name="additional_topics[]" class="topic">
                                    <option>Select Topic</option>
                                </select>
                            </td>
                            <td><div class="actionIcon addIcon" onclick="addMore(this, 1)"></div></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="">
                <th>08)</th><th>Off-Label Inquiry</th>
<?php
if ($currentMethod == "edit_compliance") {
    ?>
                    <td > <input  type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(1)" value="Yes" 
    <?php
    if ($arrComplianceData["off_label_inquiry"] == "Yes") {
        echo "checked";
    }
    ?>></input><label for="Yes">Yes</label><input id='radio1' type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(0)" value="No" 
                        <?php
                        if ($arrComplianceData["off_label_inquiry"] == "No") {
                            echo "checked";
                        }
                        ?>></input><label for="No">No</label></td>
                    <td ></td>
                                <?php
                            } else {
                                ?>
                    <td ><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(1)" value="Yes" ></input><label for="Yes">Yes</label><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(0)" value="No" checked="checked"></input><label for="No">No</label></td>
                    <td></td>
                        <?php
                           }
                           ?>
            </tr>
            <tr class=" toggleOffLabelInquiry" 
<?php
if ($currentMethod == "edit_compliance") {
    if ($arrComplianceData["off_label_inquiry"] != "Yes") {
        echo "style='display:None'";
    }
}
?>>
                <th></th><th>a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Was the inquiry unsolicited?</th>
            <?php
            if ($currentMethod == "edit_compliance") {
                ?>
                    <td><input type="radio" name="inquiry_unsolicited" value="Yes"
                <?php
                    if ($arrComplianceData["inquiry_unsolicited"] == "Yes") {
                        echo "checked";
                    }
                    ?>></input><label for="Yes">Yes</label><input type="radio" name="inquiry_unsolicited" value="No" 
                        <?php
                        if ($arrComplianceData["inquiry_unsolicited"] == "No") {
                            echo "checked";
                        }
                        ?>></input><label for="No">No</label></td>
                    <td></td>
                           <?php } else { ?>
                    <td><input type="radio" name="inquiry_unsolicited" value="Yes"></input><label for="Yes">Yes</label><input type="radio" name="inquiry_unsolicited" value="No" checked="checked"></input><label for="No">No</label></td>
                    <td></td>
                    <?php } ?>
            </tr>
            <tr class=" toggleOffLabelInquiry"
                           <?php
                    if ($currentMethod == "edit_compliance") {
                        if ($arrComplianceData["off_label_inquiry"] != "Yes") {
                            echo "style='display:None'";
                        }
                    }
                    ?>>
                <th></th><th>b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Was MSL/MML Response consistent with
                    company policy?</th>
            <?php
            if ($currentMethod == "edit_compliance") {
                ?>
                    <td><input type="radio" name="response_consistancy" value="Yes" 
                    <?php
                    if ($arrComplianceData["response_consistancy"] == "Yes") {
                        echo "checked";
                    }
                    ?>></input><label for="Yes">Yes</label><input type="radio" name="response_consistancy" value="No" 
                        <?php
                        if ($arrComplianceData["response_consistancy"] == "No") {
                            echo "checked";
                        }
                        ?>></input><label for="No">No</label></td>
                    <td></td>
                           <?php } else { ?>
                    <td><input type="radio" name="response_consistancy" value="Yes"></input><label for="Yes">Yes</label><input type="radio" name="response_consistancy" value="No" checked="checked"></input><label for="No">No</label></td>
                    <td></td>
                    <?php } ?>
            </tr>
            <tr class="evenRow">
                <th>09)</th><th>Did you identify any compliance violations?</th>
                    <?php
                    if ($currentMethod == "edit_compliance") {
                        ?>
                    <td><input type="radio" name="compliance_violation" value="Yes" onclick="toggleViolationDescription(1)" 
    <?php
    if ($arrComplianceData["compliance_violation"] == "Yes") {
        echo "checked";
    }
    ?>></input><label for="Yes">Yes</label><input id='radio2' type="radio" name="compliance_violation" value="No" onclick="toggleViolationDescription(0)" 
                        <?php
                        if ($arrComplianceData["compliance_violation"] == "No") {
                            echo "checked";
                        }
                        ?>></input><label for="No">No</label></td>
                    <td ></td>
                           <?php } else { ?>
                    <td><input type="radio" name="compliance_violation" value="Yes" onclick="toggleViolationDescription(1)"></input><label for="Yes">Yes</label><input type="radio" name="compliance_violation" value="No" onclick="toggleViolationDescription(0)" checked="checked"></input><label for="No">No</label></td>
                    <td></td>
                    <?php } ?>
            </tr>
            <tr class=" toggleViolationDescription" 
                           <?php
                    if ($currentMethod == "edit_compliance") {
                        if ($arrComplianceData["compliance_violation"] != "Yes") {
                            echo "style='display:None'";
                        }
                    }
                    ?>>
                <th>10)</th><th colspan="3">If the answer to question 09 is "Yes", please explain
                    and ensure the Director or Vice President informs the
                    Chief Compliance Officer within two (2) business days.</th>
            </tr>
            <tr class=" toggleViolationDescription" 
            <?php
                if ($currentMethod == "edit_compliance") {
                    if ($arrComplianceData["compliance_violation"] != "Yes") {
                        echo "style='display:None'";
                    }
                }
                ?>><th></th>
                <td colspan="3" style="text-align: center;">
                    <textarea name="violation_description" rows="5" style="width:98%;"><?php
            if ($currentMethod == "edit_compliance") {
                echo $arrComplianceData["violation_description"];
            }
            ?></textarea>
                </td>
            </tr>
           
            <tr style="display: None;"><th class="alignRight" colspan="1">SIGNATURE:</th> 
                <td colspan="2"> 
                    <a href="#" onclick="openSignaturePad(); return false;">Click here</a> 
                    <img id="signatureImage" width="500" height="200" <?php if (isset($arrComplianceData['signature'])) echo "src='" . base_url() . "images/mirf_signatures/" . $arrComplianceData['signature'] . "'"; ?>></img> 
                    <input type="hidden" name="hcp_signature" value="<?php if (isset($arrComplianceData['signature'])) echo $arrComplianceData['signature'];
                                                   else echo ''; ?>" style="width:97%;"></input></td>
            </tr>
          
        </table>
            <table>
                  <tr>
                <th>Recorded By:&nbsp;&nbsp;&nbsp;
            <?php
           echo $this->session->userdata('user_full_name');
            ?><br/>
            Recorded On:&nbsp;&nbsp;&nbsp;<input type="text" style="border-color: #fff" name="compliance_violated_by_date" readonly value="<?php echo date('m/d/Y'); ?>"/></th>
               
                
                
            </tr>
                
                
                
            </table>
            </form>
        <center>
            <input type="submit" id="submit"   onclick="validate(); "  value="<?php echo SUBMIT_BUTTON_LABEL ?>"/>
           
            <input type="button" value="Cancel" onclick="window.history.back();"/>
<!--            <a class="blueButton" href="#" onclick="window.history.back();">Cancel</a>-->
        </center>
    

</div>
<div id="signaturePadDialoge" class="microProfileDialogBox">
    <div class="signaturePadDialoge profileContent"></div>
</div>
<script type="text/javascript">
            var autoClickKolCount=0;
            var autoClickOrgCount=0;
            var countOrg = 0;
            var autosearchId;
            var autosearchIdOrg;
            var currentMethod = '<?php echo $currentMethod; ?>';
            var count = <?php if ($count == '') {
                                                       echo $count = 0;
                                                   } else echo $count; ?>;
            function getCitiesByStateId() {
            // Show the Loading Image
$("#loader").show();
            var stateId = $('#state_id').val();
                   
                    var cities = document.getElementById('city_id');
//        alert(JSON.stringify(cities));
                    var params = "state_id=" + stateId;
                    $.ajax({
                    url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
                            dataType: "json",
                            data: params,
                            type: "POST",
                            success: function (responseText) {
                                 $("#city_id").empty();
                               var html;
                               html="<option value=''>Select City</option>";
                                
                            $.each(responseText, function (key, value) {
//                            var newCity = document.createElement('option');
//                                    newCity.text = value.city_name;
//                                    newCity.value = value.city_id;
//                                    var prev = cities.options[cities.selectedIndex];
//                                    cities.add(newCity, prev);
                                    html+="<option value="+value.city_id+">"+value.city_name+"</option>";
//                                    alert(html);
                            });
                            $("#city_id").append(html);
                            },
                            complete: function () {
                                
                                
                            $("#loader").hide();
                            }
                    });
                    
            }
    $(document).ready(function () {

    $("#kolSearch input").live('click', function(){

    var id = $(this).attr("id");
            autosearchId = id;
            $('#' + id).autocomplete(kolAutoCompleteOptions);
    });
            $("#orgSearch input").live('click', function(){

    var id = $(this).attr("id");
            autosearchIdOrg = id;
            $('#' + id).autocomplete(orgAutoCompleteOptions);
    });
            var kolAutoCompleteOptions = {

            serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete',
<?php echo $autoSearchOptions; ?>,
                    onSelect: function(event, ui) {
                    var selTextKol = $(event).children('.kolName').html();
                            var id = $(event).children('.id1').html();
                            $("." + autosearchId + "_hidden").remove();
                            selTextKol = selTextKol.replace(/\&amp;/g, '&');
                            $('#' + autosearchId).val(selTextKol);
                            $('#contact_id').val(id);
                            autoClickKolCount=autoClickKolCount+1;
                           
                            $("#kolSearch").append("<input type='hidden' class='" + autosearchId + "_hidden'  name=kol[] value='" + id + "'>");
                    }
            }
    var orgAutoCompleteOptions = {

    serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names',
<?php echo $autoSearchOptions; ?>,
            onSelect: function(event, ui) {
            var selText = $(event).children().html();
                    $("." + autosearchIdOrg + "_hidden").remove();
                    var id = $(event).children().attr("name");
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#' + autosearchIdOrg).val(selText);
                    $('#contact_id').val(id);
                    autoClickOrgCount=autoClickOrgCount+1;
                    $("#orgSearch").append("<input type='hidden' class='" + autosearchIdOrg + "_hidden'  name=org[] value='" + id + "'>");
            }
    };
            $('#date').datepicker({
    dateFormat: 'mm/dd/yy'
    });
            $('#compliance_violated_date').datepicker({
    dateFormat: 'mm/dd/yy'
    });
//        $('.').chosen({allow_single_deselect: true});
            $('.chosenMultipleSelect').chosen({
    No_results_text: "Location Not found",
            placeholder_text: "Click to Select Location(s)",
            allow_single_deselect: true
    });
            $('.1').chosen({
//		No_results_text: "KOL Not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
    No_results_text: "<?php echo lang("HCP");?> Not found with the name",
            allow_single_deselect: true
    });
            $('.3').chosen({
//		No_results_text: "KOL Not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
    No_results_text: "Contact Type Not found with the name",
            allow_single_deselect: true
    });
            $('.2').chosen({
//		No_results_text: "KOL Not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
    No_results_text: "Organization Not found with the name",
            allow_single_deselect: true
    });
            if (currentMethod != "edit_compliance") {
    toggleViolationDescription(0);
            toggleOffLabelInquiry(0);
    }
    $('#addMoreObjectives').click(function(){

    var kolSHtml = $('#objective').html();
            $('#objectiveTable').append("<tr>" + kolSHtml + "</tr>");
            var NoofKols = $('#NoOfObjectives').val();
            var NoOfFields = parseInt(NoofKols) + 1;
            $('#NoOfObjectives').val(NoOfFields);
            var order = 'product' + NoOfFields;
            $('#objectiveTable tr:last td:eq(0) select').attr('name', order);
            $('#objectiveTable tr:last td:eq(0) select').attr('id', order);
            $('#objectiveTable tr:last td:eq(0) select option:first').attr('selected', 'selected').val('').text('Select');
            var objectFieldName = 'objective' + NoOfFields;
            $('#objectiveTable tr:last td:eq(1) select').attr('name', objectFieldName);
            $('#objectiveTable tr:last td:eq(1) select').attr('id', objectFieldName);
            $('#objectiveTable tr:last td:eq(1) select option:first').attr('selected', 'selected').val('').text('Select');
            var topic = 'topic' + NoOfFields;
            $('#objectiveTable tr:last td:eq(2) select').attr('name', topic);
            $('#objectiveTable tr:last td:eq(2) select').attr('id', topic);
            $('#objectiveTable tr:last td:eq(2) select option:first').attr('selected', 'selected').val('').text('Select');
            var product = 'subtopic' + NoOfFields;
            $('#objectiveTable tr:last td:eq(3) select').attr('name', product);
            $('#objectiveTable tr:last td:eq(3) select').attr('id', product);
            $('#objectiveTable tr:last td:eq(3) select option:first').attr('selected', 'selected').val('').text('Select');
            //	var brand = 'brand'+NoOfFields;
            //	$('#objectiveTable tr:last td:eq(3) select').attr('name',brand);
            //	$('#objectiveTable tr:last td:eq(3) select').attr('id',brand);

            $('#objectiveTable tr:last td:eq(5) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url() ?>/images/delete_active.png' onclick='deleteRow1(this)'>");
    });
            //Signature Pad dialogBox config
            var signaturePadDialogConf = {
            title: "Add KOL",
                    modal: true,
                    autoOpen: false,
                    width: 710,
                    height:550,
                    draggable:false,
                    position: ['center', 80],
                    dialogClass: "microView",
                    open: function() {
                    //display correct dialog content
                    }
            };
            $("#signaturePadDialoge").dialog(signaturePadDialogConf);
    });
            function deleteRow1(thisObj){
            $(thisObj).parent().parent().parent().remove();
            }
    function deleteRow(thisObj, isSecondary) {
    var prevRowObj = $(thisObj).parent().parent();
            $(prevRowObj).remove();
    }
    function addMore(thisObj, isSecondary) {
    var topicFieldName = 'topics';
            if (isSecondary == 1) {
    topicFieldName = 'additional_' + topicFieldName;
    }
    var prevRowObj = $(thisObj).parent().parent();
            var newRow = '<tr>' + $(prevRowObj).html() + '</tr>';
            var topicId = $(prevRowObj).find('.topic').val();
            $(prevRowObj).find('td:eq(0)').html($(prevRowObj).find('.type option:selected').text());
            $(prevRowObj).find('td:eq(1)').html($(prevRowObj).find('.product option:selected').text());
            var topicDetails = '<input type="hidden" name="' + topicFieldName + '[]" class="' + topicId + '" value="' + topicId + '" />' + $(prevRowObj).find('.topic option:selected').text();
            $(prevRowObj).find('td:eq(2)').html(topicDetails);
            $(prevRowObj).find('td:last').html('<div onclick="deleteRow(this,' + isSecondary + ');" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div>');
            $(prevRowObj).parent().append(newRow);
            $(prevRowObj).parent().find('tr:last .product option').remove();
            $(prevRowObj).parent().find('tr:last .product').append('<option value="">Select Product</option>');
            $(prevRowObj).parent().find('tr:last .topic option').remove();
            $(prevRowObj).parent().find('tr:last .topic').append('<option value="">Select Topic</option>');
    }
    function getProduct(proObject){
//    $('#loadingProduct').show();
    $('#' + topicId + " option").remove();
            $('#' + topicId).append('<option value="">Select</option>');
            var typeId = $(proObject).val();
            var productId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
            var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
            $.ajax({
            url:'<?php echo base_url() ?>/interactions/get_product_by_type/' + typeId,
                    dataType:'json',
                    success:function(returndata){
                    $('#' + topicId + " option").remove();
                            $('#' + topicId).append('<option value="">Select</option>');
                            $('#' + productId + " option").remove();
                            $('#' + productId).append('<option value="">Select</option>');
                            // .each loops through the array
                            $.each(returndata.arrProducts, function(key, value){

                            $('#' + productId).append($("<option></option>")
                                    .attr("value", key)
                                    .text(value));
                            });
                    },
                    complete:function(){
//                    	$('#loadingProduct').hide();
                    }
            });
    }

    function getTopic(proObject){


    //var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();

    var groupId = $('#grouping').val();
		var productId =  $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();
            var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
            //var typeId = $(proObject).val();	
            var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
            var subTopicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		if(typeId == "" || productId == ""){
			$('#'+topicId+" option" ).remove();
			$('#'+topicId).append('<option value="">Select</option>');
			$('#'+subTopicId+" option" ).remove();
			$('#'+subTopicId).append('<option value="">Select</option>');
		}else{
                    $('#'+topicId).parent().find("#loadingTopic").show();
            $.ajax({
				url:'<?php echo base_url()?>/interactions/get_topic_by_type/'+typeId+'/'+productId,
                    dataType:'json',
                    success:function(returndata){

                    $('#' + topicId + " option").remove();
                            $('#' + topicId).append('<option value="">Select</option>');
                            $('#' + subTopicId + " option").remove();
                            $('#' + subTopicId).append('<option value="">Select</option>');
                            // .each loops through the array
                            for (var result in returndata.arrTopics) {
                                       $('#'+topicId).append("<option  id='" + returndata.arrTopics[result].id + "' value='" + returndata.arrTopics[result].id + "'>" + returndata.arrTopics[result].name + "</option>");
                                  }
                            
                            /*$.each(returndata.arrTopics, function(key, value){

                            $('#' + topicId).append($("<option></option>")
                                    .attr("value", key)
                                    .text(value));
                            });*/
                    },
                    complete:function(){
                        $('#'+topicId).parent().find("#loadingTopic").hide();
//                    	$('#loadingTopic').hide();
                    }
            });
    }
	}
	
    function resetDropDowns(proObject){
    var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
            var subTopicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
            $('#' + topicId + " option").remove();
            $('#' + topicId).append('<option value="">Select</option>');
            $('#' + subTopicId + " option").remove();
            $('#' + subTopicId).append('<option value="">Select</option>');

            var typeObject = $(proObject).parent().parent().parent().find('td').find('select').eq(1);
             getTypeByProduct(proObject);
//    		getTopic(typeObject);
    }
    
    function getTypeByProduct(proObject) {
        productid = $(proObject).val();
                var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').attr('id');
                $('#' + typeId).parent().find("#loaderType").show();
                $.ajax({
                url: '<?php echo base_url() ?>interactions/get_type_by_product/' + productid,
                        type: 'POST',
                        dataType: 'JSON',
                        success: function (returnData) {
                        $('select#' + typeId + ' option').remove();
                                $('select#' + typeId).append('<option value="">Select</option>');
                                for (var result in returnData) {
//              $('#objectiveTable select#' +typeId).append("<option  id='" + returnData[result].id + "' value='" + returnData[result].id + "'>" + returnData[result].name + "</option>");
                        $('select#' + typeId).append($("<option></option>")
                                .attr("value", returnData[result].id)
                                .text(returnData[result].name));
                        }
                        $('#' + typeId).parent().find("#loaderType").hide();
                        }
                });
                return true;
}

    function toggleOffLabelInquiry(activate) {
    if (activate) {
    $('.toggleOffLabelInquiry').show();
    } else {
    $('.toggleOffLabelInquiry').hide();
    }
    }
    function toggleViolationDescription(activate) {
    if (activate) {
    $('.toggleViolationDescription').show();
    } else {
    $('.toggleViolationDescription').hide();
    }
    }
  
    function validate() {
       
    jQuery.extend(jQuery.validator.messages, {
    required: "Required.",
            remote: "Please fix this field.",
            email: "Please enter a valid email address.",
            url: "Please enter a valid URL.",
            date: "Please enter a valid date.",
            dateISO: "Please enter a valid date (ISO).",
            number: "Please enter a valid number.",
            digits: "Please enter only digits.",
            creditcard: "Please enter a valid credit card number.",
            equalTo: "Please enter the same value again.",
            accept: "Please enter a value with a valid extension.",
            maxlength: jQuery.validator.format("Please enter No more than {0} characters."),
            minlength: jQuery.validator.format("Please enter at least {0} characters."),
            rangelength: jQuery.validator.format("Please enter a value between {0} and {1} characters long."),
            range: jQuery.validator.format("Please enter a value between {0} and {1}."),
            max: jQuery.validator.format("Please enter a value less than or equal to {0}."),
            min: jQuery.validator.format("Please enter a value greater than or equal to {0}.")
            });
            if ($("#complianceForm").validate().form()){  

            var isAnyHCPManual = false;
            var isAnyHCOManual = false;
            $("#kolSearch .autocompleteInputBox").each(function(){
                if($(this).val() != ''){
					var thisId = $(this).attr('id');
					if($("."+thisId+"_hidden").length){
						
					}else
						isAnyHCPManual = true;
                }
            });
            $("#orgSearch > .autocompleteInputBox").each(function(){
            	
                if($(this).val() != ''){
					var thisId = $(this).attr('id');
				
					if($("."+thisId+"_hidden").length>0){
				
					}else
						isAnyHCOManual = true;
					
                }
            });
       
            if(isAnyHCPManual && isAnyHCOManual){
                 jAlert("Please select KTL  from Auto Suggestions");
             return false;
    }
              if(isAnyHCPManual){
             jAlert("Please select KTL  from Auto Suggestions");
             return false;
            }

             if(isAnyHCOManual){
                 jAlert("Please select KTL from Auto Suggestions");
                 return false;
                } 
              
            
    if ($('#kolName').val() == '' && $('#orgName').val() == ''){
	
            $(".kolErr").empty();
            $(".orgErr").empty();
            $(".kolErr").append("Either of KTL  field is required");
            $(".orgErr").append("Either of KTL field is required");
            return false;
    }
  else
          if($('.firstOrg').val()=='')
              $("#firstOrg").remove();
          $('#complianceForm').submit();
    }
    else{
 
    if ($('#kolName').val() == '' && $('#orgName').val() == ''){

            $(".kolErr").empty();
            $(".orgErr").empty();
           $(".kolErr").append("Either of KTL field is required");
            $(".orgErr").append("Either of KTL field is required");
    }

    return false;
    }

    }

    function toggleContactType() {
    if ($("#contact_type").val() == "kol") {
//            $("#kols").show();
    $("#kols_chzn").css("display", "inline-block");
//            $("#organization").hide();
            $("#organization_chzn").css("display", "None");
    } else {
//            $("#kols").hide();
    $("#kols_chzn").css("display", "None");
//            $("#organization").show();
            $("#organization_chzn").css("display", "inline-block");
    }
    }
    function removeMoreOrgs(id, thisEle){
        countOrg=countOrg-1
    $(id).remove();
            $(thisEle).remove();
            $("." + id + "br").remove();
            $("." + id).remove();
             $("." + id+"_hidden").remove();
    }
    function removeMoreKols(id, thisEle){
        count=count-1;
    $(id).remove();
            $(thisEle).remove();
            $("." + id + "br").remove();
            $("." + id).remove();
             $("." + id+"_hidden").remove();
    }
    function addMoreOrgs(){
    countOrg = countOrg + 1;
            $("#orgSearch").append("<br class='orgName" + countOrg + "br'/><input style=\"margin-left:208px;width:275px\" id='orgName" + countOrg + "'  class='autocompleteInputBox orgName" + countOrg + "' autocomplete='off' type='text' placeholder='Search HCO' /><a class='remove-icon' onclick=\"removeMoreOrgs('orgName" + countOrg + "',this)\"></a>");
    }
    function addMoreKols(){
    count = count + 1;
            $("#kolSearch").append("<br class='kolName" + count + "br'/><input id='kolName" + count + "' style=\"margin-left:208px;width:275px\"  class='autocompleteInputBox kolName" + count + "' autocomplete='off' type='text' placeholder='Search <?php echo lang("HCP")?>' /><a class='remove-icon' onclick=\"removeMoreKols('kolName" + count + "',this)\"></a>");
    }


    //Signature related js
    var signaturePad;
            function openSignaturePad(){
            $(".signaturePadDialoge").html("");
                    $(".signaturePadDialoge").html('<div id="signature-pad" class="m-signature-pad"> <div class="m-signature-pad--body"> <canvas></canvas> </div> <div class="m-signature-pad--footer"> <div class="description">Sign above</div>  <button class="button clear" data-action="clear">Clear</button>  <button class="button save" data-action="save">Save</button> </div></div>');
                    $("#signaturePadDialoge").dialog("open");
                    var wrapper = document.getElementById("signature-pad"),
                    clearButton = wrapper.querySelector("[data-action=clear]"),
                    saveButton = wrapper.querySelector("[data-action=save]"),
                    canvas = wrapper.querySelector("canvas"),
                    signaturePad;
                    function resizeCanvas() {
                    // When zoomed out to less than 100%, for some very strange reason,
                    // some browsers report devicePixelRatio as less than 1
                    // and only part of the canvas is cleared then.
                    var ratio = Math.max(window.devicePixelRatio || 1, 1);
                            canvas.width = canvas.offsetWidth * ratio;
                            canvas.height = canvas.offsetHeight * ratio;
                            canvas.getContext("2d").scale(ratio, ratio);
                    }

            window.onresize = resizeCanvas;
                    resizeCanvas();
                    signaturePad = new SignaturePad(canvas);
                    clearButton.addEventListener("click", function (event) {
                    signaturePad.clear();
                    });
                    saveButton.addEventListener("click", function (event) {
                    if (signaturePad.isEmpty()) {
                    alert("Please provide signature first.");
                    } else {
                    //window.open(signaturePad.toDataURL());
                    var data = {};
                            data['signature_data'] = signaturePad.toDataURL();
                            $.ajax({
                            url:base_url + "interactions/parse_signature_image",
                                    data:data,
                                    type:"POST",
                                    dataType:'json',
                                    success:function(returnData){
                                    //alert(returnData.image_name);
                                    imageUrl = returnData.image_url;
                                            $("#signatureImage").attr('src', imageUrl);
                                            $("#complianceForm input[name='hcp_signature']").val(returnData.image_name);
                                            $("#signaturePadDialoge").dialog("close");
                                    }
                            });
                    }
                    });
                    //$(".signaturePadDialoge").load(base_url+'requested_kols/upgrade_request_page');
                    return false;
            }

    function checkPreviousEntry(thisEle){
    var userId = $(thisEle).val();
            $.ajax({
            url:base_url + "coachings/is_complience_exist_for_user/" + userId,
                    dataType:'json',
                    success:function(returnData){
                    if (returnData.complience_id != 0){
                    jConfirm('An entry for the selected user was found.Are you sure you want to reload the page with exisiting details?', 'Confirmation Dialog', function(r) {
                    if (r == true)
                    {
                    window.location = base_url + "/coachings/edit_compliance/" + returnData.complience_id+"/1";
                   
                    
                    }
                    });
                    }
                    else
                    {

//                                $('#locations').val('');
//                            $('#state_id').val('');
//                            $('#city_id').val('');
//                            $('#date').val('');
//                            $('#groupId').val('');
//                            $('#product').val('');
//                            $('#objective select').val('');
//                            $('#topic').val('');
////                            $("input").val('');
// $("#kolSearch input").val('');
// $("#orgSearch input").val('');
//                            $("#submit").val('Save');
//                            $("#clear").val('clear');
//                            toggleOffLabelInquiry(0);
//                            toggleViolationDescription(0);
//                            $("#radio1").attr("checked", "checked");
//                            $("#radio2").attr("checked", "checked");
//                            $("#kolSearch input[type=text]").each(function() {
//
//                    if (this.id == "kolName" || this.id == "orgName")
//                            $("." + this.id + "_hidden").remove();
//                            else{
//                            $("." + this.id + "_hidden").remove();
//                                    $("#" + this.id).remove();
//                                    $(".remove-icon").remove();
//                                    $("br").remove();
//                            }
//
//
//                    });
//                           $("#orgSearch input[type=text]").each(function() {
//
//                    if (this.id == "kolName" || this.id == "orgName")
//                            $("." + this.id + "_hidden").remove();
//                            else{
//                            $("." + this.id + "_hidden").remove();
//                                    $("#" + this.id).remove();
//                                    $(".remove-icon").remove();
//                                    $("br").remove();
//                            }
//
//
//                    });
                    }

                    }
            });
    }
</script>
