<?php
$queued_js_scripts = array('jquery_validator/dist/jquery.validate');
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
#pubManualTbl>thead>tr>th{
	font-size: 12px !important;
}
.glyphicon {
    font-size: 14px;
}
#pubManualTbl>tbody>tr>td{
padding:5px !important;
}
</style>
<script>
$(document).ready(function(){
	$('.pubManualMsgBox').hide();
	//Adds the another Author input field below the current input field
	$("#addMoreAuthors").click(function(){
		var noOfAuthors=0;
		noOfAuthors=$("#noOfAuthors").val();
		noOfAuthors++;
		var newAuthor="<tr class=\"auths\" id=\"pubAuthorDelete"+noOfAuthors+"\"><td><input type='text' class='form-control' name='last_name[]' id=\"pubAuthorsLastName"+noOfAuthors+"\" /></td><td><input type='text' class='form-control' name='fore_name[]' id=\"pubAuthorsForeName"+noOfAuthors+"\" /></td><td><input type='text' class='form-control' name='initials[]' id=\"pubAuthorsInitials"+noOfAuthors+"\" class=\"smallField\"/></td><td style=\"vertical-align: middle;\"><a href=\"#\" onclick=\"deleteAuthor("+noOfAuthors+");\"><span class=\"glyphicon red glyphicon-remove-circle\"></span></a></td></tr>";
		$("#pubManualTbl").append(newAuthor);
		$("#noOfAuthors").val(noOfAuthors);
	});
	$('#pubCreatedDate').datepicker({
		dateFormat: 'mm/dd/yy',
		onSelect: function(dateText, inst) {
			$('#pubCreatedDate').removeClass('error');
	        $('#pubCreatedDate').next().hide();
	    }
	});
});
//Date validation
function validateDateFormat(e,src) {
	if (!e) var e = window.event
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
 
 	if(src.value == null || src.value == "") {
 		return true;
 	}
 
	if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
		jAlert("Please enter the date in mm/dd/yyyy format!");
		src.focus();
	}
}
function dateFormat(e,src) {		
	if (!e) var e = window.event
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
	
	if(code != 37 && code != 38 && code != 39 && code != 40) { 
		if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
			src.value=src.value.replace(/[^0-9\/]/g,'');  
			if(code!=8 && code!=46) // not backspace or delete
			{	
				src.value=src.value.replace(/[^0-9]/g,'');
				if (src.value.length == 2) {
			        src.value += "/";
			    }
				if (src.value.length > 2) {
					if(src.value.indexOf('/') != 2) {
						src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
					}
				}
				if (src.value.length == 5) {
			        src.value += "/";
			    }
				if (src.value.length > 5) {
					if(src.value.lastIndexOf('/') != 5) {
						src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
					}
				}
				if(src.value.length >= 10)
				{
					return false;
				}
			}  
		}
	}
	return true;
}
//Additional fields to Delete
function deleteAuthor(id,rowId=''){
	$("#duplicate_error").hide();
	if(rowId==''){
		$('#pubAuthorDelete'+id).remove();
	}else{
		var kolId = $('#kolId').val();
		var pubId = $('#pubManualId').val();
		var autId = id;
		jConfirm("Are you sure you want to delete the author?","Confirm box", function(r){
			if(r){
				$.ajax({
					type:"post",
					dataType:"json",
					url:"<?php echo base_url();?>/pubmeds/deleteAuthorOfPublication/"+kolId+"/"+pubId+"/"+autId,
					success:function(returnMsg){
						if(returnMsg.status=='success'){
							$('#pubAuthorDelete'+rowId).remove();
    						var noOfAuthors=0;
    						noOfAuthors=$("#noOfAuthors").val();
    						noOfAuthors--;
    						noOfAuthors=$("#noOfAuthors").val(noOfAuthors);
						}	
						else
							alert("There was some problem while deleting Author.");
    					}
    			});
			}
		});
	}	
}
//Validates the pubManualForm
function savePublicationManual(){
	if(!$("#pubManualForm").validate().form()){
		return false;
	}else{
		var values = []; //list of different values
		$('.auths input:text').each(
		   function() {
		     if (values.indexOf(this.value) >= 0) { //if this value is already in the list, marks
			      if($(this).val()!=''){
			    	$("#duplicate_error").show();
				  }
		     } else {
		    		$("#duplicate_error").hide(); //clears since last check
					values.push(this.value); //insert new value in the list
		      }
		    }
		);
		if($('#duplicate_error').is(':visible')){
			return false;
		}else{
// 			$('#savePubManual').attr({'disabled':'disabled'});
			id = $("#pubManualId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>pubmeds/save_publication_manual';
			}else{
				formAction = '<?php echo base_url();?>pubmeds/update_publication_manual';
			}
			
			formData	= $("#pubManualForm").serialize();
			$.ajax({
				type:"post",
				dataType:"json",
				data: formData,
				url:formAction,
				beforeSend: function(){
					$("#savePubManual").attr("disabled", "disabled");
		        },
		        
				success:function(returnMsg){
					$('.pubManualMsgBox').show();
					$('div.pubManualMsgBox').fadeIn("fast");
					$('div.pubManualMsgBox').text(returnMsg.msg);
					$('html, body').animate({
			            scrollTop: $("div.pubManualMsgBox").first().offset().top-100
			        });
					if(returnMsg.saved){
						$('div.pubManualMsgBox').removeClass('alert-danger');
						$('div.pubManualMsgBox').addClass('alert-success');
					}else{
						$('div.pubManualMsgBox').removeClass('alert-success');
						$('div.pubManualMsgBox').addClass('alert-danger');
					}
					$('div.pubManualMsgBox').fadeOut(10000);
				},
				complete:function(){
					$('#savePubManual').removeAttr("disabled");
				}
			});
		}
		
	}
			
}

</script>
	<!--  div class="panel-heading align_center"><?php if($publication['id']>0)echo 'Update Publication Details';else echo 'Add Publication';?></div> -->
	<div>
		<div class="col-md-10 col-md-offset-2 pubManualMsgBox alert alert-success" role="alert"></div>
		<form action=""   method="post" id="pubManualForm" name="pubManualForm" class="validateForm form-horizontal">
		<input type="hidden" name="id"  value="<?php echo $publication['id'];?>" id="pubManualId"/>
		<input type="hidden" name="kol_id"  value="<?php echo $kolId?>" id="kolId"/>
		<div class="form-group">
				<label class="col-sm-2 align_right">Article Name:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text"  class="required form-control" name="article_title" value="<?php echo $publication['article_title'];?>" id="pubArticleTitle" class="required"/>
		    	</div>
		    	<label class="col-sm-2 align_right">Journal Name:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text"  class="required form-control" name="journal_name" value="<?php echo $publication['journal_name'];?>" id="pubJournalName" class="required"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-2 align_right">Date:<span class="required">*</span></label>
				<div class="col-sm-4">
					  <input type="text" name="created_date" value="<?php echo $publication['created_date'];?>" id="pubCreatedDate" class="required form-control" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)"/>
		    	</div>
		    	<label class="col-sm-2 align_right">URL:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="link" value="<?php echo $publication['link'];?>" id="pubLink" />
		    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 align_right">Abstract:</label>
			<div class="col-sm-10">
				  <textarea class="form-control" name="abstract_text" id="pubAbstractText" rows="3" cols="30"><?php echo $publication['abstract_text'];?></textarea>
	    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 align_right">Authors:</label>
			<div class="col-sm-10">
				<table class="table" id="pubManualTbl">
					<thead>
					<tr>
						<th width="32%">Last Name:</th>
						<th width="32%">Fore Name:</th>
						<th width="32%">Initials:</th>
						<th width="4%">	
							<div id="addMoreAuthors" title="Add Another Author">
								<a href="javascript:void(0);"><span class="glyphicon glyphicon-plus-sign"></span></a>
							</div>
						</th>
					</tr>
					</thead>
					<tbody>
					<?php if($publication['id']=='' || (isset($arrMultipleAuthors) && sizeof($arrMultipleAuthors)==0)){?>
					<tr id="first_aut" class="auths">
						<td>
								<input type="hidden" name="authId"  value="<?php echo $arrAuthors['id'];?>" id="pubAuthId"/>
								<input type="hidden" name="before_no_of_authors" id="before_no_of_authors" value="<?php echo $publication['no_of_authors'];?>"/>
								<input type="hidden" name="no_of_authors" id="noOfAuthors" value="<?php echo $publication['no_of_authors'];?>"/>
								<input type="text" class="form-control" name="last_name[]" value="<?php echo $arrAuthors['last_name'];?>" id="pubAuthorsLastName"/>
						</td>
						<td>
								<input type="text" class="form-control" name="fore_name[]" value="<?php echo $arrAuthors['fore_name'];?>" id="pubAuthorsForeName"/>
						</td>
						<td>
								<input type="text" class="form-control" name="initials[]" value="<?php echo $arrAuthors['initials'];?>" id="pubAuthorsInitials" class="smallField"/>
						</td>
						<td style="vertical-align: middle;">
						</td>
					</tr>	
					<?php }?>
					<?php if(isset($arrMultipleAuthors) && sizeof($arrMultipleAuthors)>=1){?>
					<input type="hidden" name="before_no_of_authors" id="before_no_of_authors" value="<?php echo sizeof($arrMultipleAuthors);?>"/>
					<input type="hidden" name="no_of_authors" id="noOfAuthors" value="<?php echo sizeof($arrMultipleAuthors);?>"/>
						<?php 
							$i=0;
							foreach($arrMultipleAuthors as $author){?>
								<tr id="pubAuthorDelete<?php echo $i;?>" class="auths">		
									<td>
										<input type="hidden" name="authId[]"  value="<?php echo $author['id'];?>" id="pubAuthId<?php echo $i?>" />
										<input type="text" class="form-control" name="last_name[]" value="<?php echo $author['last_name'];?>" id="pubAuthorsLastName<?php echo $i?>" readonly="readonly"/>
									</td>
									<td>
										<input type="text" class="form-control" name="fore_name[]" value="<?php echo $author['fore_name'];?>" id="pubAuthorsForeName<?php echo $i?>" readonly="readonly"/>
									</td>
									<td>
										<input type="text" class="form-control" name="initials[]" value="<?php echo $author['initials'];?>" id="pubAuthorsInitials<?php echo $i?>" class="smallField" readonly="readonly"/>
									</td>								
	        						<td style="vertical-align: middle;">
	            						<a style="cursor: pointer;" onclick="deleteAuthor('<?php echo $author['id'] ?>','<?php echo $i; ?>');"><span class="glyphicon red glyphicon-remove-circle"></span></a>
	            					</td>	            					
	            				</tr>	
					<?php $i++; }?>					
				<?php 	}?>
				</tbody>
				</table>
	    	</div>
		</div>
		<div class="form-group row" style="text-align: center;">
			<p id="duplicate_error" style="color:red;display:none;">Duplicate author entry</p>
   			<button type="button" name="submit" onclick="savePublicationManual();return false;" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
            <button type="button" onclick="goBack();return false;" class="btn btn-default"><span class="glyphicon red glyphicon-remove-circle"></span> Cancel</button>
		</div>
	</form>
	</div>