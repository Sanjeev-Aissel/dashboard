<style>
.star-ratings-sprite {
	background: url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/2605/star-rating-sprite.png") repeat-x;
	font-size: 0;
	height: 21px;
	line-height: 0;
	overflow: hidden;
	text-indent: -999em;
	width: 110px;
	margin: 0 auto;
} 
.star-ratings-sprite-rating{
	background: url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/2605/star-rating-sprite.png") repeat-x;
	background-position: 0 100%;
	float: left;
	height: 21px;
	display:block;
}
.profile_name{
	background-color:#ececec;
	font-weight: 900;
	color: black;
	padding: 1%3%;
	text-align: center;
}
.profileImage{
	text-align:center;
}
.profile_type{
	font-weight: bold;
	font-size: medium;
	color: #626262;
	text-align: center;
	border-top: 1px solid #ccc;
	margin-top: 3%;
}
.list-group-item span {
     float: inherit;
}
</style>
<p class="profile_name"></p>

<div class="profileImage">
	<img alt="Image" src="" width="100">
</div>

<div id="show_profile_score"></div>
<div id="show_assessment_score"></div>
<div class="profile_type"></div>

<script>
$(document).ready(function(){
var kol_id='<?php echo $kol_id;?>';
	$.ajax({
		type:"post",
		dataType:"json",
		url:base_url+'kols/kols/get_kol_short_profile_details/'+kol_id,
		success:function(returnData){
			var pic_url=base_url+""+returnData.profile_image_name;
			$('.profile_name').text(returnData.name);
			$('.profile_type').text(returnData.profile_type);
			$('.profileImage img').attr('src',pic_url);
			if(returnData.profile_ratings >0){
				$('#show_profile_score').html('<div class="star-ratings-sprite"><span style="width:'+returnData.profile_ratings+'" class="star-ratings-sprite-rating"></span></div>');
			}
			if(returnData.assessment_score >0){
				$('#show_assessment_score').html('<div class="star-ratings-sprite"><span style="width:'+returnData.assessment_score+'%" class="star-ratings-sprite-rating"></span></div>');
			}
		}
	});
});
</script>