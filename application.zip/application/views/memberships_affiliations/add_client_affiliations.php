<?php
/**
* Description:File to create 'add'view for Memberships and Affiliations module
* @author:Vinayak
* @since :2.2
* Created on:may 5, 2011
* @package application.views.memberships_affiliations
*/

 $autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>


<style type="text/css">
	.clientForm input[type="text"], .clientForm select {
		width:145px;
	}
	
	.clientForm select {
		width:152px;
	}
	.clientForm input.institute_name{
		width:590px;
	}
	.clientForm input.url {
		width:267px;
	}
	
	.clientForm .urlFieled{
		float: none;
		width: 20px;
	}
	
</style>
<script type="text/javascript">

	/*
	* To Disable Form Button 
	* @since 2.2
	* @author Vinayak
	* @created on 4/5/2011
	*/
//	function disableButton(){
//		alert("d");
//		$('#saveAffiliations').attr({'disabled':'disabled'});
//	}

	/*
	* To Enable Form Button 
	* @since 2.2
	* @author Vinayak
	* @created on 4/5/2011
	*/
//	function enableButton(){
//		alert("e");
//		$('#saveAffiliations').removeAttr('disabled');
//
//	}

	/*
	* Date Validation(To Check End Date > Start Date) 
	* @since 2.2
	* @author Vinayak
	* @created on 4/5/2011
	*/
	function validate(endDate){
		var startDate=$("#uniStartDate").val();
		if(endDate!=''){	
			if(startDate>endDate){
				$(".msgBox").show();
				disableButton();
			}else{
				$(".msgBox").hide();
				enableButton();
			}
	
		}
	}

	$("#uniEndDate").focusout(function(){
		var startDate=$("#uniStartDate").val();
		var endDate = $(this).val();
		if(endDate!=''){	
			if(startDate>endDate){
				$(".msgBox").show();
				disableButton();
			}else{
				$(".msgBox").hide();
				enableButton();
			}
	
		}
		});


	var options, a;
	// Autocomplet Options for the  Name' field of 'University / Hospital' ,'Assocition','Industry','Gvt','Others'
	// Autocomplet Options for the 'Institute Name' field searches From the lookuptable
		var uniInstituteNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_institute_names',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var selText = $(event).children('.educations').html();
			var selId = $(event).children('.educations').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#uniName').val(selText);
			$('#uniNameId').val(selId);
			if(event.length>20){
				//$('#orgIdForAutocomplete').val(kolId);
				if(event.substring(0,21)=="No results found for "){
					return false;
				}
			}
		}
	
	};	

	$(document).ready(function(){
			a = $('#uniName').autocomplete(uniInstituteNameAutoCompleteOptions);
	});

	var validationRules	=  {
		name: {
			required:true
			//instituteName:"<?php echo base_url();?>kols/get_institute_id/"
		},
		start_date: {
			fullYear: true
		},
		end_date: {
			fullYear: true
		},
		eduUrl1: {
			url: true
		},
		eduUrl2: {
			url: true
		},
		type:{
			required:true
		}
	};

	var validationMessages = {
		name: {
			required: "Required"
		},
		start_date: "Only full year is allowed. Ex: 2010",
		end_date: "Only full year is allowed. Ex: 2010",
		url: "Please enter a valid URL address",
		type: {
			required: "Required"
		}
	};

	/**
	* Validate the text for 'Numeric Only'
	*/
	function allowNumericOnly(src) {
		if(!src.value.match(/^\d*$/)) {
			src.value=src.value.replace(/[^0-9]/g,'');  
		}
	}

	//Validate function
	$(document).ready(function() {				
		$(".validateForm").validationEngine({
				promptPosition: "centerRight", // OPENNING BOX POSITION, IMPLEMENTED: topLeft, topRight, bottomLeft,  centerRight, bottomRight
				success :  false,				
				failure : function() {
			}
		}); 		

		$("#universityForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

			 });
	//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
	$('div[id^="AutocompleteContainter_"]').remove();	

	// Trigger the Autocompleter for 'Event Name' field of type 'Conference Event'
	a = $('#uniName').autocomplete(uniInstituteNameAutoCompleteOptions);	
</script>

		<div class="formHeader"><h5>Affiliation</h5></div>
			<div class="uniMsgBox"></div><div class="msgBoxContainer"></div>
			<form action="save_membership" method="post" id="universityForm" name="universityForm" class="validateForm clientForm" onsubmit="return validateAffiliations();">
		    	<input type="hidden" name="type" value="university"></input>
		    	<input type="hidden" name="id" id="uniId" value="<?php echo $affId;?>"></input>
	    		<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId?>"></input>
		    	<table class="analystForm" id="universityTbl">
					<tr>
						<td colspan="2">		
						 	<p>
						 		<label for="uniName">Organization Name:<span class="required">*</span> </label> 
						 		<input type="hidden" name="institute_id" id="uniNameId"></input>
						 		<input type="text" name="name" id="uniName" class="required institute_name autocompleteInputBox" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['org_name'];}?>"></input>
						 	</p>
						</td>
						
					</tr>
					<tr>
						<td>
							<p>
								<label for="uniEngagement">Org Type:<span class="required">*</span></label> 
								<select name="type" id="type" class="required">
									
									<option value="">--- Select ---</option>
									<option value="association" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'association') echo 'selected';}?>>Association</option>
									<option value="government" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'government') echo 'selected';}?>>Government</option>
									<option value="industry" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'industry') echo 'selected';}?>>Industry</option>
									<option value="university" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'university') echo 'selected';}?>>University</option>
									<option value="others" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'others') echo 'selected';}?>>Others</option>
								</select>
							</p>
						</td>
			
						<td>
							<p>
								<label for="uniEngagement">Engagement Type:</label> 
								<select name="engagement_id" id="uniEngagement">
									<option value="0">--- Select ---</option>
										<?php 
										foreach($arrEngagementTypes as $key => $value){
										if($arrAffiliationsData['engagement_id'] == $key)
											echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
										else
											echo '<option value="'.$key.'">'.$value.'</option>';
										}
										?>
								</select>
							</p>
						</td>
					</tr>
					<tr>
						<td>		
					 		<p>
					 			<label for="uniDepartment">Dept/Committee:</label>
						        <input type="text" name="department" id="uniDepartment" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['department'];}?>" class=""></input>
							</p>
						 </td>	
						 <td>			
						 	<p>
						 		<label for="uniRole">Title:</label>
				        		<input type="text" name="role" id="uniRole" class="" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['role'];}?>"></input>
			        		</p>
						</td>
			  		</tr>
			  		<tr>
			  			<td>			
				  			<p>
				  				<label for="uniStartDate">Start Year:</label>
				        		<input type="text" name="start_date" id="uniStartDate" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['start_date'];}?>" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
			        		</p>
		        		</td>
		        		<td>
				   			<p>
				   				<label for="uniEndDate">End Year:</label>
				        		<input type="text" name="end_date" id="uniEndDate" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['end_date'];}?>" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" ></input>
			        		</p>
			        		<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
					 	</td> 
				 	</tr>
                                        <tr style="display:none;">
	 					<td>    		
							<p>
								<label>URL:</label><input type="text" name="url1" id="uniUrl1" value="" class="url"></input>
							</p>
						</td>
						<td>
					   	 	<p>
			   	 				<label class="urlFieled">URL: </label><input type="text" name="url2" id="uniUrl2" value="" class="url"></input>
							</p>
						</td>
					</tr>
					<tr>
						<td colspan="2">				        		  
							<div class="formButtons"">   
								<input type="submit" value="Save" name="submit" onclick="saveAllAffiliations();" id="saveAffiliations">
					         </div>
						</td>
						<td>
						
						</td>									
					</tr>
				</table>					         
			</form>
					     