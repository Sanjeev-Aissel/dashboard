<?php

/**
 * This is Controller file of 'Kol'
 *
 * @author Ambarish
 * @since
 * @package application.controllers
 * @created on 9-12-2011
 */
class Kols extends Controller {

    private $loggedUserId = null;
    private $arrSurveyTypes = array(
        1 => 'Local',
        2 => 'National'/* ,
              3=>'Global' */
    );
    //Constructor
    function Kols() {
        parent::Controller();
        $this->load->model('kol');
        $this->load->model("country_helper");
        $this->load->model("Event_helper");
        $this->load->model('pubmed');
        $this->load->model('clinical_trial');
        $this->load->model("Specialty");
        $this->load->library("Ajax_pagination");
        $this->load->model('common_helpers');
        $this->load->model('organization');
        $this->load->model('Client_User');
        $this->load->model('My_list_kol');
        $this->load->model("interaction");
        $this->load->model("payment");
        $this->load->model("contract");
        $this->load->model("json_store");
        $this->load->model("kol_rating");
        $this->load->model('survey');
        $this->load->model('align_user');
        $this->load->model('media_parser');
        $this->load->model('kol_consent');
        $this->loggedUserId = $this->session->userdata('user_id');
    }

    /**
     * Checks if the user has logged in or not
     * @access private
     */
    private function _is_logged_in() {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url() . "/login");
        } else {
            $this->loggedUserId = $this->session->userdata('user_id');
        }
    }

    //  ------------start of Kols overview functions----------
    /*
      // Function is not used
      function index1(){
      $this->load->view('index1');
      } */

    /**
     * Prepares the data reqiored for home page and Redirect's to clients home page
     * @return unknown_type
     */
    function client_index() {
    	//redirect('kols/list_kols_client_view');
    	
        $data['userName'] = $this->session->userdata('user_name');
        $data['noOfKols'] = $this->kol->countKols();
        $data['noOfOrgs'] = $this->organization->countOrganizations();
        $data['mediaSet']=true;
        $data['arrUpdates'] = $this->update->listUpdates();
        //pr($data['arrUpdates']);exit;
        $data['arrTopSpecialties'] = $this->kol->getTopSpecialties('0', '5');
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $user_id = $this->session->userdata("user_id");
        $data['contentPageMedia'] = 'media_inteligence/rss_feed_view';
        $bookmarked_content = $this->media_parser->getUsersBookmark($user_id);
        //   $bookmarked_source=$this->media_parser->getSourceBookmark($user_id);

        $blacklist_content = $this->media_parser->getUserBlacklists($user_id);
        $commentCountResult = $this->media_parser->getCommentCount(null, 1);
        $book_array = array();
        $blacklist_array = array();
        $commentCount = array();
        $sourceArr = array();
        $sourceResult = $this->media_parser->category_filter("link");
        //pr($sourceResult);
        foreach ($sourceResult as $source_values) {
            $sourceArr[] = $source_values;
        }
        foreach ($bookmarked_content as $values) {
            $book_array[] = $values;
        }

        foreach ($blacklist_content as $list_values) {
            $blacklist_array[] = $list_values;
        }
        foreach ($commentCountResult as $commentCounts) {
            $commentCount[] = $commentCounts;
        }
         $result=$this->media_parser->getBookMarkedArticles($this->session->userdata('user_id'),true);
        // echo $this->db->last_query();
        if(count($result)>0)
        	$data['newsExists']=1;
        $arrParams = array();
        $this->load->model('user_setting');
        $userId = $this->loggedUserId;
        $filterData = $this->user_setting->getDataFromAppSettings($userId,'medintel_filter_date');
        if($filterData > 0){
        	$filterData;
        	$data['fromFilterData'] = $filterData;
        }else{
        	$filterData = 30;
        	$data['fromFilterData'] = 30;
        }
        $arrParams['start_date'] = date('Y-m-d', strtotime("-$filterData days"));
        $arrParams['end_date'] = date('Y-m-d');
        $result = $this->media_parser->getFeedsToDisplay($arrParams);
         $result_count = $this->media_parser->getFeedsToDisplay($arrParams,true);
        // $result_cat_highlights=$this->media_parser->getEachTotalCatCount();
           $arrFilters['start_date'] = date('Y-m-d', strtotime(' -30 day'));;
         $arrFilters['end_date'] = date('Y-m-d');
        $filterd_feeds["count"]["people"] = $this->media_parser->category_filter(96, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Person", "num" => $filterd_feeds["count"]["people"]);
        $filterd_feeds["count"]["disease"] = $this->media_parser->category_filter(100, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "MedicalCondition", "num" => $filterd_feeds["count"]["disease"]);
        $filterd_feeds["count"]["organization"] = $this->media_parser->category_filter(95, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Organization", "num" => $filterd_feeds["count"]["organization"]);
        $filterd_feeds["count"]["technology"] = $this->media_parser->category_filter(98, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Technology", "num" => $filterd_feeds["count"]["technology"]);
        $filterd_feeds["count"]["company"] = $this->media_parser->category_filter(105, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Company", "num" => $filterd_feeds["count"]["company"]);
        $filterd_feeds["count"]["product"] = $this->media_parser->category_filter(110, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Product", "num" => $filterd_feeds["count"]["product"]);
        //pr($result_cat_highlights);
        $result_person = $this->media_parser->category_filter(96, $arrFilters);
        $result_disease = $this->media_parser->category_filter(100, $arrFilters);
        $result_technology = $this->media_parser->category_filter(95, $arrFilters);
        $result_product = $this->media_parser->category_filter(98, $arrFilters);
        $result_organization = $this->media_parser->category_filter(105, $arrFilters);
        $result_company = $this->media_parser->category_filter(110, $arrFilters);
        $arrFeeds = array();
        foreach ($result as $row) {
            $row["description"] = strip_tags($row["description"]);
            $row["bookmarks"] = $this->media_parser->getUserBookmark($user_id, $row["rss_feed_url_id"]);
            $arrFeeds[] = $row;
        }
        $data['person'] = $result_person;
        $data['technology'] = $result_technology;
        $data['medical_condition'] = $result_disease;
        $data['organization'] = $result_organization;
        $data['company'] = $result_company;
        $data['product'] = $result_product;
        $data['result'] = $arrFeeds;
        $data['book_marks'] = $book_array;
        $data['black_lists'] = $blacklist_array;
         $data['feedCount'] = count($result_count);

        $data['highlights'] = $result_cat_highlights;
        $data['comment_count'] = $commentCount;
        $data['source_links'] = $sourceArr;
        $data['selectedOption'] = $selOption;
        $clientId = $this->session->userdata("client_id");
        $data['client_id'] = $clientId;
      
        $data['contentPage'] = 'client_index';
        $this->load->view('layouts/client_view', $data);
        
    }

    /**
     * Prepares the data reqiored for home page and Redirect's to clients home page
     * @return unknown_type
     */
    function analyst_index() {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        $data['userName'] = $this->session->userdata('user_name');
        $data['noOfKols'] = $this->kol->countKols();
        $data['noOfOrgs'] = $this->organization->countOrganizations();

        $data['arrUpdates'] = $this->update->listUpdates('0', '5', null);
        $data['arrTopSpecialties'] = $this->kol->getTopSpecialties('0', '5');
        $data['contentPage'] = 'client_index';
        $this->load->view('layouts/analyst_view', $data);
    }

    /**
     * Display 'add kols' view page
     * @ACL-Alias Add Kol
     * @ACL-Discription Display Form to Add Kol Deatil
     * @ACL-Category Kols
     * @ACL-SubApp analyst
     */
    function add_kol() {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        $data['arrCountry'] = $this->Country_helper->listCountries();
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $arrSalutations = array(1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['contentPage'] = 'kols/add_kol';
        $this->load->view('layouts/analyst_view', $data);
    }

    /*
     * Saving a 'kols' data
     */

    function save_kol() {
        // Get all the POST data
        $arrKol['salutation'] = $this->input->post('salutation');
        $arrKol['gender'] = $this->input->post('gender');
        $arrKol['first_name'] = ucwords(trim($this->input->post('first_name')));
        $arrKol['middle_name'] = ucwords(trim($this->input->post('middle_name')));
        $arrKol['last_name'] = ucwords(trim($this->input->post('last_name')));
        $arrKol['suffix'] = ucwords(trim($this->input->post('suffix')));
        $arrKol['specialty'] = $this->input->post('specialty');
        $arrKol['org_id'] = $this->input->post('org_id');
        $arrKol['is_pubmed_processed'] = 0;
        $arrKol['created_by'] = $this->loggedUserId;
        $arrKol['created_on'] = date("Y-m-d H:i:s");
        $arrKol['status'] = New1;
        $arrKol['npi_num'] = $this->input->post('npi_num');
        $arrKol['profile_type'] = $this->input->post('profile_type');
        $arrKol['unique_id'] = uniqid();
        //ending post details
//            check_duplicate_kols
        $kolId = $this->kol->saveKol($arrKol);
        $this->update->insertUpdateEntry(KOL_PROFILE_ADD, $kolId, MODULE_KOL_OVERVIEW, $kolId);
        if ($kolId) {
            $updateData['id'] = $kolId;
            $updateData['pin'] = $kolId;
            $this->kol->updateKol($updateData);
            $this->session->set_flashdata('message', 'New Kol Saved Sucessfully');
        } else {
            $this->session->set_flashdata('message', 'Kol Could not be Saved! Try again');
        }

        redirect('kols/list_kols');
    }

    function check_duplicate_kols($fname = 0, $mname = 0, $lname = 0, $specialtyId = 0) {
        $arrKol['first_name'] = $fname;
//		$arrKol['middle_name']	 	=	$mname;
        $arrKol['last_name'] = $lname;
        $arrKol['specialty'] = $specialtyId;
        $arrKols = $this->kol->checkDuplicateKols($arrKol);
        if (sizeof($arrKols) > 0) {
            $arrData['duplicateKols'] = $arrKols;
            $arrData['arrSalutations'] = $arrSalutations;
            $arrData['hasDuplicates'] = true;
            return $arrData;
        } else {
            return false;
        }
    }

    /*
     * Listing  'kols' details
     * TODO Add the DocBlock and complete the details
     */

    function list_kols() {
        ini_set('memory_limit', '-1');
        // Remove any session attributes for the KOL and Organization
        //$this->session->unset_userdata('kolId');
        //$this->session->unset_userdata('organizationId');
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        /* $arrKolDetailResult = $this->kol->getKolDetail();
          $data				= array();
          $arrKolDetail		= array();
          foreach($arrKolDetailResult->result_array() as $row){
          $row['created_by']					= $row['user_full_name'];
          $row['is_pubmed_processed']			= ($row['is_pubmed_processed']==1) ? 'Yes':'No';
          $row['is_clinical_trial_processed']	= ($row['is_clinical_trial_processed']==1) ? 'Yes':'No';
          $row['is_imported']					= (isset($row['is_imported']) && $row['is_imported']==1) ? '<span class="highlightImported">(xls)<span>':'';
          $row['org_id']						= $this->kol->getOrgId($row['org_id']);
          $arrKolDetail[]						= $row;
          }
          $data['arrKol']							= $arrKolDetail; */
        // To show the pubmed and CT Links for Autorised users right now for user id=5
        $data['user_id'] = $this->session->userdata('user_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
        //pr($data['clientUser']);
        $data['contentPage'] = 'kols/list_kols';
        $this->load->view('layouts/analyst_view', $data);
    }

    function list_kols_grid_old() {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrKolDetailResult = array();
        $data = array();

        if ($arrKolDetailResult = $this->kol->getKolDetail()) {
            foreach ($arrKolDetailResult->result_array() as $row) {
                $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                $kolName = $arrSalutations[$row['salutation']] . ' ' . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                $row['kol_name'] = '<a href="' . base_url() . 'kols/view/' . $row['id'] . '">' . $kolName . '</a>';
                $row['kol_name'] .= (isset($row['is_imported']) && $row['is_imported'] == 1) ? '<span class="highlightImported"> (xls)<span>' : '';
                // Get the list of Specialties
                $this->load->model('Specialty');
                $arrSpecialties = $this->Specialty->getAllSpecialties();
                $row['specialty'] = $arrSpecialties[$row['specialty']];
                $row['created_by'] = $row['user_full_name'];
                if ($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN) {
                    if ($row['is_pubmed_processed'] == 0)
                        $pubStatusHtml = "No";

                    if ($row['is_pubmed_processed'] == 1)
                        $pubStatusHtml = "Yes";

                    if ($row['is_pubmed_processed'] == 2)
                        $pubStatusHtml = "Re crawl";

                    $row['pubmed_processed'] = $pubStatusHtml;
                }else {
                    $pubStatus = 'No';
                    if ($row['is_pubmed_processed'] == 1)
                        $pubStatus = 'Yes';
                    if ($row['is_pubmed_processed'] == 2)
                        $pubStatus = 'Re crawl';
                    $row['pubmed_processed'] = $pubStatus;
                }
                $row['trial_processed'] = ($row['is_clinical_trial_processed'] == 1) ? 'Yes' : 'No';
                $row['organization'] = $this->kol->getOrgId($row['org_id']);
                $row['action'] = '<div class="actionIcon editIcon"><a href="' . base_url() . 'kols/edit_kol/' . $row['id'] . '" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols(' . $row['id'] . ');" href="#" title="delete">&nbsp;</a></div>';
                $arrKolDetail[] = $row;
            }
            $count = sizeof($arrKolDetail);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrKolDetail;
        }
        ob_start('ob_gzhandler');
        echo json_encode($data);
    }

    /*
     *  Editing 'kols' detail
     */

    function edit_kol($kolId = null) {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        if (!$kolId) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        // Getting the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $arrKolDetail['org_id'] = $this->kol->getOrgId($arrKolDetail['org_id']);
        $data['arrKol'] = $arrKolDetail;
        $data['kolId'] = $kolId;
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $arrStates = array();
        $arrCities = array();
        if ($arrKolDetail['country_id'] != 0) {
            $arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
        }
        if ($arrKolDetail['state_id'] != 0) {
            $arrCities = $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
        }
        $data['arrStates'] = $arrStates;
        $data['arrCities'] = $arrCities;
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $arrSalutations = array(1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['arrContactDetails'] = array();
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($kolId)) {
            $data[] = $arrContactDetails;
        }
        $data['latitude'] = $arrKolDetail['latitude'];
        $data['longitude'] = $arrKolDetail['longitude'];
        $data['contentPage'] = 'kols/edit_kol';
        $this->load->view('layouts/analyst_view', $data);
    }

    /*
     *  Updating 'kols' details
     */

    function update_kol() {

        // Get the current KOL ID from the Session
        $arrKol['id'] = $this->input->post('kol_id');
        ;
        // Get all the POST data
        $arrKol['salutation'] = $this->input->post('salutation');
        $arrKol['first_name'] = ucwords(trim($this->input->post('first_name')));
        $arrKol['middle_name'] = ucwords(trim($this->input->post('middle_name')));
        $arrKol['last_name'] = ucwords(trim($this->input->post('last_name')));
        $arrKol['suffix'] = ucwords(trim($this->input->post('suffix')));
        $arrKol['specialty'] = $this->input->post('specialty');
        $arrKol['sub_specialty'] = ucwords(trim($this->input->post('sub_specialty')));
        $arrKol['gender'] = $this->input->post('gender');
        $arrKol['org_id'] = $this->input->post('org_id');
        $arrKol['title'] = ucwords(trim($this->input->post('title')));
        if(!empty($arrKol['title'])){
            $arrKol['title'] = $this->kol->saveTitle($arrKol['title']); // save title if not exists / if exsits get id
        }
        $arrKol['division'] = ucwords(trim($this->input->post('division')));
        $arrKol['npi_num'] = $this->input->post('npi_num');
        $arrKol['research_interests'] = $this->input->post('research_interests');
        $arrKol['license'] = $this->input->post('license');
        $arrKol['biography'] = $this->input->post('biography');
        //$arrKol['profile_image'] =	$this->input->post('profile_image');
        $arrKol['notes'] = $this->input->post('notes');
        $arrKol['url'] = $this->input->post('url');
        $arrKol['modified_by'] = $this->loggedUserId;
        $arrKol['modified_on'] = date("Y-m-d H:i:s");
        $arrKol['mdm_id'] = $this->input->post('mdm_id');
        if ($arrKol['mdm_id'] == '')
            $arrKol['mdm_id'] = null;
        //- End of getting all the POST data

        $arrKol['profile_type'] = $this->input->post('profile_type');
        $arrKol['org_id'] = $this->kol->getOrgName($arrKol['org_id']);
        //print_r($arrKol['org_id']);
        $returnValue = $this->kol->updateKol($arrKol);
        $this->update->insertUpdateEntry(KOL_PROFILE_OVERVIEW_UPDATE, $arrKol['id'], MODULE_KOL_OVERVIEW, $arrKol['id']);
        echo json_encode($returnValue);
    }

    function update_kol_contact() {
		
        // Get the current KOL ID from the Session
        $arrKol['id'] = $this->input->post('kol_id');
        ;

        // Get all the POST data
        $arrKol['primary_phone'] = $this->input->post('primary_phone');
        $arrKol['primary_email'] = $this->input->post('primary_email');
        $arrKol['address1'] = ucwords(trim($this->input->post('address1')));
        $arrKol['address2'] = ucwords(trim($this->input->post('address2')));
        $arrKol['country_id'] = $this->input->post('country_id');
        $arrKol['city_id'] = $this->input->post('city_id');
        $arrKol['state_id'] = $this->input->post('state_id');
        $arrKol['postal_code'] = $this->input->post('postal_code');
        $arrKol['fax'] = $this->input->post('fax');
        $arrKol['modified_by'] = $this->loggedUserId;
        $arrKol['modified_on'] = date("Y-m-d H:i:s");
        //- End of getting all the POST data
        //prepare array to update KOL latitude and longitude
        $arrKolLatLongData['kol_id'] = $arrKol['id'];
        $arrKolLatLongData['latitude'] = $this->input->post('latitude');
        $arrKolLatLongData['longitude'] = $this->input->post('longitude');
        //update KOL latitude and longitude
        $this->kol->updateKolLocationLatitudeLongitude($arrKolLatLongData);
        //update other info
        $returnValue = $this->kol->updateKol($arrKol);
        $this->update->insertUpdateEntry(KOL_PROFILE_OVERVIEW_UPDATE, $arrKol['id'], MODULE_KOL_OVERVIEW, $arrKol['id']);
        echo json_encode($returnValue);
    }

    function update_kol_biography() {

        // Get the current KOL ID from the Session
        $arrKol['id'] = $this->input->post('kol_id');

        // Get all the POST data
        $arrKol['research_interests'] = $this->input->post('research_interests');
        $arrKol['biography'] = $this->input->post('biography');
        $arrKol['modified_by'] = $this->loggedUserId;
        $arrKol['modified_on'] = date("Y-m-d H:i:s");
        //- End of getting all the POST data
        //print_r($arrKol['org_id']);

        $returnValue = $this->kol->updateKol($arrKol);
        $this->update->insertUpdateEntry(KOL_PROFILE_OVERVIEW_UPDATE, $arrKol['id'], MODULE_KOL_OVERVIEW, $arrKol['id']);
        echo json_encode($returnValue);
    }

    /*
     *  Delete 'kols' detail
     */

    function delete_kol($id) {
        $this->kol->deleteKol($id);
        $this->update->deleteKolRelatedUpdates($id);
        redirect('Kols/list_kols');
    }

    /*
     * Display Editing of the 'Overview Form'
     *
     */

    function edit_overview() {
        // Get the KOL details
        $arrKolDetail = $this->kol->editKol($this->session->userdata('kolId'));
        $data['arrKol'] = $arrKolDetail;
        $data['arrKol'] = $arrKolDetail;
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $arrStates = array();
        $arrCities = array();
        $arrKolDetail['org_id'] = $this->kol->getOrgId($arrKolDetail['org_id']);
        $data['arrKol'] = $arrKolDetail;
        if ($arrKolDetail['country_id'] != 0) {
            $arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
        }
        if ($arrKolDetail['state_id'] != 0) {
            $arrCities = $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
        }
        $data['arrStates'] = $arrStates;
        $data['arrCities'] = $arrCities;
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['arrContactDetails'] = array();
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
            $data[] = $arrContactDetails;
            $this->update->insertUpdateEntry(KOL_PROFILE_OVERVIEW_UPDATE, $arrContactDetails['id'], MODULE_KOL_OVERVIEW, $arrContactDetails['kol_id']);
        }
        $this->load->view('kols/edit_kol', $data);
    }

    // -------------------END of Kols overview functions- -----------------------------
    //--------------------Start of  memberships and affiliations functions- ------------
    /* Display adding 'kol memberships and affiliations' details view
     * Show the page of 'memberships and affiliations details'
     */
    function add_membership($kolId = null) {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        // Get the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        $data['arrKol'] = $arrKolDetail;
        // Get the list of EngagementTypes
        $this->load->Model('Engagement_type');
        $arrEngagementTypes = $this->Engagement_type->getAllEngagementTypes();
        $key = array_search('Other', $arrEngagementTypes);
        unset($arrEngagementTypes[$key]);
        $arrEngagementTypes[$key] = 'Other';
        $data['arrEngagementTypes'] = $arrEngagementTypes;
        // Get the list of InstituteNames
        $arrInstituteNames = $this->kol->getAllInstituteNames();
        $data['arrInstituteNames'] = $arrInstituteNames;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //pr($data);
        $data['arrCountry'] = $this->Country_helper->listCountries();
        //$this->load->view('memberships_affiliations/add_memberships_affiliations',$data);
        $data['contentPage'] = 'memberships_affiliations/add_memberships_affiliations';
        $this->load->view('layouts/analyst_view', $data);
    }

    /*
     * Save 'memberships and affiliations details' to DB
     */

    function save_membership() {
        //getting post Details
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $arrMembership['kol_id'] = $this->input->post('kol_id');
        $arrMembership['type'] = $this->input->post('type');
        $arrMembership['institute_id'] = $this->input->post('institute_id');
        $arrMembership['committee'] = ucwords(trim($this->input->post('committee')));
        $arrMembership['department'] = ucwords(trim($this->input->post('department')));
        $arrMembership['title'] = ucwords(trim($this->input->post('title')));
        $arrMembership['start_date'] = $this->input->post('start_date');
        $arrMembership['end_date'] = $this->input->post('end_date');
        $arrMembership['role'] = ucwords(trim($this->input->post('role')));
        $arrMembership['division'] = ucwords(trim($this->input->post('division')));
        $arrMembership['purpose'] = ucwords(trim($this->input->post('purpose')));
        $arrMembership['amount'] = $this->input->post('amount');
        $arrMembership['url1'] = $this->input->post('url1');
        $arrMembership['url2'] = $this->input->post('url2');
        $arrMembership['notes'] = $this->input->post('notes');
        $arrMembership['created_by'] = $this->loggedUserId;
        $arrMembership['created_on'] = date("Y-m-d H:i:s");
        $arrMembership['notes'] = $this->input->post('notes');
        $arrMembership['engagement_id'] = $this->input->post('engagement_id');
        $arrMembership['client_id'] = $this->session->userdata('client_id');
        $arrMembership['data_type_indicator'] = $dataType;
        // Create an array to return the result
        $arrResult = array();
        $this->load->model('Engagement_type');
        if ($lastInsertId = $this->kol->saveMembership($arrMembership)) {

            if ($arrMembership['type'] == "university") {
                $arrMembership['type'] = "Univ/Hospital";
            } else {
                $arrMembership['type'] = ucwords($arrMembership['type']);
            }

            $this->update->insertUpdateEntry(KOL_PROFILE_AFFILITION_ADD, $lastInsertId, MODULE_KOL_AFFILIATION, $arrMembership['kol_id']);
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => LOG_ADD,
                    'description' => 'Add Affilation',
                    'status' => 'success',
                    'transaction_id' => $lastInsertId,
                    'transaction_table_id' => KOL_MEMBERSHIPS,
                    'transaction_name' => 'Add Affilation',
                    'form_data' => json_encode($arrMembership),
                    'parent_object_id' => $arrMembership['kol_id'] 
            );
            $this->config->set_item('log_details', $arrLogDetails);            
            $arrResult['saved'] = true;
            $arrResult['msg'] = "Saved Successfully";
            $arrResult['lastInsertId'] = $lastInsertId;
            $arrMembership['engagement_id'] = $this->Engagement_type->getEngagementName($arrMembership['engagement_id']);
            $arrMembership['institute_id'] = $this->kol->getInstituteName($arrMembership['institute_id']);
            $arrMembership['institute_id'] = ucwords($arrMembership['institute_id']);
            if ($arrMembership['url1'] != '') {
                $arrMembership['url1'] = '<a href=\'' . $arrMembership['url1'] . '\' target="_new">URl1</a>';
            }
            if ($arrMembership['url2'] != '') {
                $arrMembership['url2'] = '<a href=\'' . $arrMembership['url2'] . '\' target="_new">URl2</a>';
            }
            $arrMembership['date'] = '';
            /* 		if($arrMembership['start_date'] != '')
              $arrMembership['date']	.=	$arrMembership['start_date'];

              if(($arrMembership['start_date'] != '') && ($arrMembership['end_date']))
              $arrMembership['date']	.=	" - ";

              if($arrMembership['end_date'] != '')
              $arrMembership['date']	.=	$arrMembership['end_date'];
             */

            if ($arrMembership['start_date'] != '')
                $arrMembership['date'] .= $arrMembership['start_date'];
            else
                $arrMembership['date'] .= 'NA';
            $arrMembership['date'] .= " - ";
            if ($arrMembership['end_date'] != '')
                $arrMembership['date'] .= $arrMembership['end_date'];
            else
                $arrMembership['date'] .= 'NA';
            if ($arrMembership['date'] == 'NA - NA') {
                $arrMembership['date'] = '';
            }
            $arrResult['data'] = $arrMembership;
        } else {
            $arrResult['saved'] = false;
        }
        echo json_encode($arrResult);
    }

//End of  saving membership details

    /*
     *  List 'memberships and affiliations details'
     */

    function list_memberships($type, $kolId = null) {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrMembershipResult = array();
        $data = array();
        if ($arrMembershipResult = $this->kol->listMemberships($type, $kolId)) {
            $count = sizeof($arrMembershipResult);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrMembershipResult;
        }

        echo json_encode($data);
    }

//End of listing Membership detailas

    /*
     *  List 'memberships and affiliations details' for grids
     */

    function list_memberships_grid($type, $kolId = null) {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrMembershipResult = array();
        $data = array();
        $arrMembership = array();
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        if ($arrMembershipResult = $this->kol->listMemberships($type, $kolId)) {
            foreach ($arrMembershipResult as $row) {
                $row['date'] = '';
                if ($row['start_date'] != '')
                    $row['date'] .= $row['start_date'];
                else
                    $row['date'] .= 'NA';

                $row['date'] .= " - ";

                if ($row['end_date'] != '')
                    $row['date'] .= $row['end_date'];
                else
                    $row['date'] .= 'NA';

                if ($row['date'] == 'NA - NA') {
                    $row['date'] = '';
                }
                $arrMembership[] = $row;
            }
            $count = sizeof($arrMembership);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrMembership;
        }
        echo json_encode($data);
    }

//End of listing Membership detailas

    /*
     *  List all 'memberships and affiliations details' for grids
     */

    function list_all_affiliations_details($kolId = null) {
        $client_id = $this->session->userdata('client_id');
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrMembershipResult = array();
        $data = array();
        $arrMembership = array();
        if ($arrMembershipResult = $this->kol->listAllAffiliationsDetails($kolId)) {
            foreach ($arrMembershipResult as $row) {
                if ($row['type'] == "university") {
                    $row['type'] = "Univ/Hospital";
                } else {
                    $row['type'] = ucfirst($row['type']);
                }
                //$row['type'] = ucwords($row['type']);
                $row['date'] = '';
                if ($row['start_date'] != '')
                    $row['date'] .= $row['start_date'];
                else
                    $row['date'] .= 'NA';

                $row['date'] .= " - ";

                if ($row['end_date'] != '')
                    $row['date'] .= $row['end_date'];
                else
                    $row['date'] .= 'NA';

                if ($row['date'] == 'NA - NA') {
                    $row['date'] = '';
                }
                $arrMembership[] = $row;
            }
            $count = sizeof($arrMembership);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrMembership;
        }
        ob_start('ob_gzhandler');
        echo json_encode($data);
    }

//End of list

    /*
     *  Edit 'memberships and affiliations details'
     */

    function edit_membership($id) {
        $arrMembership = $this->kol->editMembership($id);
        foreach ($arrMembership->result_array() as $row) {
            $data['arrMembership'][] = $row;
        }
        //$this->load->view('memberships_affiliations/edit_memberships_affiliations',$data);
        $this->load->view('memberships_affiliations/edit', $data);
    }

//End of editing membership details

    /*
     * Update 'memberships and affiliations details' to DB
     */

    function update_membership() {
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $arrMembership['id'] = $this->input->post('id');
        $arrMembership['type'] = $this->input->post('type');
        $arrMembership['institute_id'] = $this->input->post('institute_id');
        $arrMembership['committee'] = ucwords(trim($this->input->post('committee')));
        $arrMembership['department'] = ucwords(trim($this->input->post('department')));
        $arrMembership['title'] = ucwords(trim($this->input->post('title')));
        $arrMembership['start_date'] = $this->input->post('start_date');
        $arrMembership['end_date'] = $this->input->post('end_date');
        $arrMembership['role'] = ucwords($this->input->post('role'));
        $arrMembership['division'] = ucwords($this->input->post('division'));
        $arrMembership['purpose'] = $this->input->post('purpose');
        $arrMembership['amount'] = $this->input->post('amount');
        $arrMembership['url1'] = $this->input->post('url1');
        $arrMembership['url2'] = $this->input->post('url2');
        $arrMembership['notes'] = $this->input->post('notes');
        $arrMembership['engagement_id'] = $this->input->post('engagement_id');
        $arrMembership['client_id'] = $this->session->userdata('client_id');
        $arrMembership['modified_by'] = $this->loggedUserId;
        $arrMembership['modified_on'] = date("Y-m-d H:i:s");
        $arrMembership['data_type_indicator'] = $da;
        // Create an array to return the result

        $arrResult = array();
        $this->load->Model('Engagement_type');
        if ($this->kol->updateMembership($arrMembership)) {
            $this->update->insertUpdateEntry(KOL_PROFILE_AFFILITION_UPDATE, $arrMembership['id'], MODULE_KOL_AFFILIATION, $this->input->post('kol_id'));
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => LOG_UPDATE,
                    'description' => 'Update Affilation',
                    'status' => 'success',
                    'transaction_id' => $arrMembership['id'],
                    'transaction_table_id' => KOL_MEMBERSHIPS,
                    'transaction_name' => 'Update Affilation',
                    'form_data' => json_encode($arrMembership),
                    'parent_object_id' => $this->input->post('kol_id')
            );
            $this->config->set_item('log_details', $arrLogDetails);            
            
            
            $arrResult['saved'] = true;
            $arrResult['lastInsertId'] = $arrMembership['id'];
            $arrMembership['engagement_id'] = $this->Engagement_type->getEngagementName($arrMembership['engagement_id']);
            $arrMembership['institute_id'] = $this->kol->getInstituteName($arrMembership['institute_id']);
            if ($arrMembership['url1'] != '') {
                $arrMembership['url1'] = '<a href=\'' . $arrMembership['url1'] . '\' target="_new">URl1</a>';
            }
            if ($arrMembership['url2'] != '') {
                $arrMembership['url2'] = '<a href=\'' . $arrMembership['url2'] . '\' target="_new">URl2</a>';
            }
            $arrResult['data'] = $arrMembership;
        } else {
            $arrResult['saved'] = false;
        }
        echo json_encode($arrResult);
    }

//End of updating membership details

    /*
     *  Delete 'memberships and affiliations details'
     */

    function delete_membership($id) {
        if ($this->kol->deleteMembership($id)) {
            $this->update->deleteUpdateEntry(KOL_PROFILE_AFFILITION_ADD, $id, MODULE_KOL_AFFILIATION);
            $this->update->deleteUpdateEntry(KOL_PROFILE_AFFILITION_UPDATE, $id, MODULE_KOL_AFFILIATION);
            $arrReturnData['status'] = 'success';
        } else{
            $arrReturnData['status'] = 'fail';
        }
        echo json_encode($arrReturnData);
        //redirect('Kols/list_membership');
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$name
     * @return unknown_type
     */
    function get_membership_names($membershipType, $name) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $instituteName));
        $arrMembershipNames = $this->kol->getMembershipName($membershipType, $name);
        $arrReturnData['query'] = $name;
        $arrReturnData['suggestions'] = $arrMembershipNames;
        echo json_encode($arrReturnData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$department
     * @return unknown_type
     */
    function get_membership_departments($membershipType, $department) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $instituteName));
        $arrMembershipDepartment = $this->kol->getMembershipDepartment($membershipType, $department);
        $arrReturnData['query'] = $department;
        $arrReturnData['suggestions'] = $arrMembershipDepartment;
        echo json_encode($arrReturnData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$title
     * @return unknown_type
     */
    function get_membership_titles($membershipType, $title) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $title));
        $arrMembershipTitles = $this->kol->getMembershipTitle($membershipType, $title);
        $arrReturnData['query'] = $title;
        $arrReturnData['suggestions'] = $arrMembershipTitles;
        echo json_encode($arrReturnData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$committee
     * @return unknown_type
     */
    function get_membership_committees($membershipType, $committee) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $title));
        $arrMembershipCommittee = $this->kol->getMembershipCommittee($membershipType, $committee);
        $arrReturnData['query'] = $committee;
        $arrReturnData['suggestions'] = $arrMembershipCommittee;
        echo json_encode($arrReturnData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$role
     * @return unknown_type
     */
    function get_membership_roles($membershipType, $role) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $role));
        $arrMembershipRole = $this->kol->getMembershipRole($membershipType, $role);
        $arrReturnData['query'] = $role;
        $arrReturnData['suggestions'] = $arrMembershipRole;
        echo json_encode($arrReturnData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$division
     * @return unknown_type
     */
    function get_membership_divisions($membershipType, $division) {
        //echo json_encode($this->kol->getEducationInstitutes($educationType, $role));
        $arrMembershipDivision = $this->kol->getMembershipDivision($membershipType, $division);
        $arrReturnData['query'] = $division;
        $arrReturnData['suggestions'] = $arrMembershipDivision;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the Engagement Id
     *
     * @param String $engagementType
     * @return int (Integer id)
     */
    function get_engagement_id($engagementType = '') {
        $engagementType = $this->input->post('engagementName');
        $this->load->Model('Engagement_type');
        $engagementId = $this->Engagement_type->getEngagementId($engagementType);
        echo json_encode($engagementId);
    }

    //--------------------END of  memberships and affiliations functions- ------------
    //start of oraganization auto complete method
    /**
     *
     * @param String	$name
     * @return unknown_type
     */
    function get_org_names($name) {
        $arrOrgName = $this->kol->getAutoOrgName($name);
        $arrReturnData['query'] = $name;
        $arrReturnData['suggestions'] = $arrOrgName;
        echo json_encode($arrReturnData);
    }

    //	End of oraganization auto complete method
    //-------------Start of Event functions-------------------------------
    /**
     * Show the page of Add event details
     *
     */
    function add_event($kolId = null) {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        $data['arrCountry'] = $this->Country_helper->listCountries();
        // Get the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        $data['arrKol'] = $arrKolDetail;
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        // Get the list of Conference Event Types
        $this->load->model('Event_helper');
        $arrConfEventTypes = $this->Event_helper->getAllConferenceEventTypes();
        $data['arrConfEventTypes'] = $arrConfEventTypes;
        // Get the list of Conference Session Types
        $arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
        $key = array_search('Other', $arrConfSessionTypes);
        unset($arrConfSessionTypes[$key]);
        $arrConfSessionTypes[$key] = 'Other';
        $data['arrConfSessionTypes'] = $arrConfSessionTypes;
        // Get the list of Online Event Types
        $arrOnlineEventTypes = $this->Event_helper->getAllOnlineEventTypes();
        $data['arrOnlineEventTypes'] = $arrOnlineEventTypes;
        //Returns all the EventNames from the lookuptable
        $arrAllEventNames = $this->kol->getAllEventLookupNames();
        $data['arrAllEventNames'] = $arrAllEventNames;
        // Get the list of Topic belongs to kol specialty
        $arrTopics = $this->kol->getTopicsBySpecialty($arrKolDetail['specialty']);
        $data['arrTopics'] = $arrTopics;
        //$this->load->view('events/add_event',$data);
        $arrRoles = $this->kol->getEventRoles();
        $data['arrRoles'] = $arrRoles;
        $data['arrEventOrganizerTypes'] = $this->Event_helper->getOrganizerTypes();

        $data['arrEventSponsorTypes'] = $this->Event_helper->getSponsorTypes();
        $data['contentPage'] = 'events/add_event';
        $this->load->view('layouts/analyst_view', $data);
    }

    /** Date function to convert the date from php format to mysql.
     *
     * @param date $inputDate Input date (format - MM/DD/YYYY)
     * @return date  Output date (format - YYYY-MM-DD).
     */
    function convertDateToYYYY_MM_DD($inputDate) {
        $date = '';
        if (empty($inputDate)) {
            return $date;
        }
        $mmDate = substr($inputDate, 0, 2);
        $ddDate = substr($inputDate, 3, 2);
        $yyDate = substr($inputDate, 6, 4);
        return ($yyDate . '-' . $mmDate . '-' . $ddDate);
    }

    /**
     * Saves the Event Data to DB
     *
     */
    function save_event() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Events
            $dataType = 'User Added';
            $client_id =$this->session->userdata('client_id');
            if($client_id == INTERNAL_CLIENT_ID){
                $dataType = 'Aissel Analyst';
            }
            $eventDetails = array('type' => $this->input->post('type'),
                'event_id' => $this->input->post('event_id'),
                'event_type' => $this->input->post('event_type'),
                'session_type' => $this->input->post('session_type'),
                'session_name' => ucwords(trim($this->input->post('session_name'))),
                'role' => ucwords(trim($this->input->post('role'))),
                'topic' => $this->input->post('topic'),
                'start' => app_date_to_sql_date($this->input->post('start')),
                'end' => app_date_to_sql_date($this->input->post('end')),
                'organizer' => ucwords(trim($this->input->post('organizer'))),
                'sponsor_type' => ucwords(trim($this->input->post('sponsor_type'))),
                'session_sponsor' => ucwords(trim($this->input->post('session_sponsor'))),
                'location' => ucwords(trim($this->input->post('location'))),
                'organizer_type' => $this->input->post('organizer_type'),
                'address' => $this->input->post('address'),
                'country_id' => $this->input->post('country_id'),
                'state_id' => $this->input->post('state_id'),
                'city_id' => $this->input->post('city_id'),
                'postal_code' => $this->input->post('postal_code'),
                'subject' => $this->input->post('subject'),
                'url1' => $this->input->post('url1'),
                'url2' => $this->input->post('url2'),
                'notes' => $this->input->post('notes'),
                'created_by' => $this->loggedUserId,
                'created_on' => date("Y-m-d H:i:s"),
                'kol_id' => $this->input->post('kol_id'),
            	'latitude' => $this->input->post('latitude'),
            	'longitude' => $this->input->post('longitude'),
                'client_id' => $this->session->userdata('client_id'),
                'data_type_indicator'=> $dataType    
            );
				

            // Create an array to return the result
            $arrResult = array();
            //If the date is empty it shold show empty only
            $startDate = '';
            $endDate = '';
            if ($this->input->post('start') != '') {
                $startDate = $this->input->post('start');
            }
            if ($this->input->post('end') != '') {
                $endDate = $this->input->post('end');
            }
            if ($lastInsertId = $this->kol->saveEvent($eventDetails)) {
                $this->update->insertUpdateEntry(KOL_PROFILE_EVENT_ADD, $lastInsertId, MODULE_KOL_EVENT, $eventDetails['kol_id']);
                $arrLogDetails = array(
                        'module' => 'kols',
                        'type' => LOG_ADD,
                        'description' => 'New Events',
                        'status' => 'success',
                        'transaction_id' => $lastInsertId,
                        'transaction_table_id' => KOL_EVENTS,
                        'transaction_name' => 'New Events',
                        'form_data' => json_encode($eventDetails),
                        'parent_object_id' => $eventDetails['kol_id']
                );
                
                $this->config->set_item('log_details', $arrLogDetails);               
                $arrResult['lastInsertId'] = $lastInsertId;
                //Getting  the name of the specified 'country'  By passing The Id
                $eventDetails['country_name'] = $this->Country_helper->getCountryById($eventDetails['country_id']);
                //Getting  the name of the specified 'state'  By passing The Id
                $eventDetails['state_name'] = $this->Country_helper->getStateById($eventDetails['state_id']);
                //Getting  the name of the specified 'city'  By passing The Id
                $eventDetails['city_name'] = $this->Country_helper->getCityeById($eventDetails['city_id']);
                //Getting  the name of the specified Event  By passing The Id
                $eventDetails['event_name'] = $this->kol->getEventLookupName($eventDetails['event_id']);
                //Getting  the name of the specified Topic  By passing The Id
                $eventDetails['topic'] = $this->kol->getTopicName($eventDetails['topic']);
                //This field value  apply's to "conference type"
                if ($eventDetails['type'] == 'conference') {
                    //Getting  the name of the specified Conference Event Type By passing The Id
                    $eventDetails['event_type'] = $this->Event_helper->getConferenceEventTypeById($eventDetails['event_type']);

                    //Getting  the name of the specified Conference Session Type By passing The Id
                    $eventDetails['session_type'] = $this->Event_helper->getConferenceSessionTypeById($eventDetails['session_type']);
                } else {
                    //This field value  apply's to "online type"
                    //Getting  the name of the specified Online Event Type By passing The Id
                    $eventDetails['onEventTypeId'] = $eventDetails['event_type'];
                    $eventDetails['event_type'] = $this->Event_helper->getOnlineEventTypeById($eventDetails['event_type']);
                }
                $eventDetails['start'] = $startDate;
                $eventDetails['end'] = $endDate;
                if ($eventDetails['url1'] != '') {
                    $eventDetails['url1'] = '<a href=\'' . $eventDetails['url1'] . '\' target="_new">URL1</a>';
                }
                if ($eventDetails['url2'] != '') {
                    $eventDetails['url2'] = '<a href=\'' . $eventDetails['url2'] . '\' target="_new">URL2</a>';
                }
				
                $arrEventDetails = $this->kol->getEventById($lastInsertId);
                $eventDetails['first_name'] = $arrEventDetails['first_name'];
                $eventDetails['last_name'] = $arrEventDetails['last_name'];
                $eventDetails['is_analyst'] = $arrEventDetails['is_analyst'];
                
                $arrResult['saved'] = true;
                $arrResult['msg'] = "Saved Successfully";
                $arrResult['data'] = $eventDetails;
                if($eventDetails['sponsor_type'] == 2){
                    $this->add_events_to_affiliations($this->input->post('kol_id'),$lastInsertId);
                }    
                    
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * List the Events Data
     *
     */
    function list_events($type, $startYear = '', $endYear = '', $kolId,$sortByYear=false) {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrEventsResults = array();
        $data = array();
        if ($arrEventsResultsResult = $this->kol->listEvents($type, $kolId, $startYear, $endYear,null,null,$sortByYear)) {
            foreach ($arrEventsResultsResult as $row) {
                $row['topic'] = $this->kol->getTopicName($row['topic']);
                $arrEventsResults[] = $row;
            }
            $count = sizeof($arrEventsResults);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrEventsResults;
        }
        echo json_encode($data);
    }

    /**
     * Edit the Event Details
     *
     */
    function edit_event($id) {
        if ($arrEventDetails = $this->kol->editEventById($id)) {
            foreach ($arrEventDetails->result_array() as $row) {
                $data['arrEventDetails'][] = $row;
            }
        }
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $this->load->view('events/edit_event', $data);
    }

    /**
     * Updates the Event Data
     *
     */
    function update_event() {
        if (isset($_POST) && count($_POST) > 0) {
            $dataType = 'User Added';
            $client_id =$this->session->userdata('client_id');
            if($client_id == INTERNAL_CLIENT_ID){
                $dataType = 'Aissel Analyst';
            }
            // Getting the POST details of Events
            $eventDetails = array('id' => $this->input->post('id'),
                'type' => $this->input->post('type'),
                'event_id' => $this->input->post('event_id'),
                'event_type' => $this->input->post('event_type'),
                'session_type' => $this->input->post('session_type'),
                'session_name' => ucwords(trim($this->input->post('session_name'))),
                'role' => ucwords(trim($this->input->post('role'))),
                'topic' => $this->input->post('topic'),
                'start' => app_date_to_sql_date($this->input->post('start')),
                'end' => app_date_to_sql_date($this->input->post('end')),
                'organizer' => ucwords(trim($this->input->post('organizer'))),
                'sponsor_type' => ucwords(trim($this->input->post('sponsor_type'))),
                'session_sponsor' => ucwords(trim($this->input->post('session_sponsor'))),
                'location' => ucwords(trim($this->input->post('location'))),
                'organizer_type' => $this->input->post('organizer_type'),
                'address' => $this->input->post('address'),
                'country_id' => $this->input->post('country_id'),
                'state_id' => $this->input->post('state_id'),
                'city_id' => $this->input->post('city_id'),
                'postal_code' => $this->input->post('postal_code'),
                'subject' => $this->input->post('subject'),
                'url1' => $this->input->post('url1'),
                'url2' => $this->input->post('url2'),
                'notes' => $this->input->post('notes'),
                'modified_by' => $this->loggedUserId,
                'modified_on' => date("Y-m-d H:i:s"),
                'client_id' => $this->session->userdata('client_id'),
                'data_type_indicator' => $dataType   
            );
            // Create an array to return the result
            $arrResult = array();
            //if the date is empty it shold show empty only
            $startDate = '';
            $endDate = '';
            if ($this->input->post('start') != '') {
                $startDate = $this->input->post('start');
            }
            if ($this->input->post('end') != '') {
                $endDate = $this->input->post('end');
            }
            if ($this->kol->updateEvent($eventDetails)) {
               // $this->update->insertUpdateEntry(KOL_PROFILE_EVENT_UPDATE, $eventDetails['id'], MODULE_KOL_EVENT, $this->input->post('kol_id'));
                $arrLogDetails = array(
                        'module' => 'kols',
                        'type' => LOG_UPDATE,
                        'description' => 'Update Events',
                        'status' => 'success',
                        'transaction_id' => $eventDetails['id'],
                        'transaction_table_id' => KOL_EVENTS,
                        'transaction_name' => 'Update Events',
                        'form_data' => json_encode($eventDetails),
                        'parent_object_id' => $this->input->post('kol_id'),
                );
                
                $this->config->set_item('log_details', $arrLogDetails);
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $eventDetails['id'];
                //Getting  the name of the specified 'country'  By passing The Id
                $eventDetails['country_name'] = $this->Country_helper->getCountryById($eventDetails['country_id']);
                //Getting  the name of the specified 'state'  By passing The Id
                $eventDetails['state_name'] = $this->Country_helper->getStateById($eventDetails['state_id']);
                //Getting  the name of the specified 'city'  By passing The Id
                $eventDetails['city_name'] = $this->Country_helper->getCityeById($eventDetails['city_id']);
                $eventDetails['event_name'] = $this->kol->getEventLookupName($eventDetails['event_id']);
                //Getting  the name of the specified Topic  By passing The Id
                $eventDetails['topic_name'] = $this->kol->getTopicName($eventDetails['topic']);
                if ($eventDetails['type'] == 'conference') {
                    //Getting  the name of the specified Conference Event Type By passing The Id
                    $eventDetails['event_type'] = $this->Event_helper->getConferenceEventTypeById($eventDetails['event_type']);

                    //Getting  the name of the specified Conference Session Type By passing The Id
                    $eventDetails['session_type'] = $this->Event_helper->getConferenceSessionTypeById($eventDetails['session_type']);
                } else {
                    //Getting  the name of the specified Online Event Type By passing The Id
                    $eventDetails['onEventTypeId'] = $eventDetails['event_type'];
                    $eventDetails['event_type'] = $this->Event_helper->getOnlineEventTypeById($eventDetails['event_type']);
                }
                $eventDetails['start'] = $startDate;
                $eventDetails['end'] = $endDate;
                if ($eventDetails['url1'] != '') {
                    $eventDetails['url1'] = '<a href=\'' . $eventDetails['url1'] . '\' target="_new">URL1</a>';
                }
                if ($eventDetails['url2'] != '') {
                    $eventDetails['url2'] = '<a href=\'' . $eventDetails['url2'] . '\' target="_new">URL2</a>';
                }
                $arrResult['data'] = $eventDetails;
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * Delete the Event Data
     *
     */
    function delete_event($id) {
        if ($this->kol->deleteEventById($id)) {
            $this->update->deleteUpdateEntry(KOL_PROFILE_EVENT_ADD, $id, MODULE_KOL_EVENT);
            $this->update->deleteUpdateEntry(KOL_PROFILE_EVENT_UPDATE, $id, MODULE_KOL_EVENT);
            $arrResult['status'] = 'success';
        } else {
            $arrResult['status'] = 'fail';
        }
        echo json_encode($arrResult);
    }

    /**
     * Returns the list of Participation Names, based on the Event Type
     *
     * @param String	$eventType
     * @param String 	$participationName
     * @return unknown_type
     */
    function get_event_participations($eventType, $participationName) {
        $arrParticipationNames = $this->kol->getEventParticipations($eventType, $participationName);
        $arrReturnData['query'] = $participationName;
        $arrReturnData['suggestions'] = $arrParticipationNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the list of Subject Names, based on the Event Type
     *
     * @param String	$eventType
     * @param String 	$subjectName
     * @return unknown_type
     */
    function get_event_subjects($eventType, $subjectName) {
        $arrSubjectNames = $this->kol->getEventSubjects($eventType, $subjectName);
        $arrReturnData['query'] = $subjectName;
        $arrReturnData['suggestions'] = $arrSubjectNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the Event Id
     *
     * @param String $name
     * @return unknown_type
     */
    function get_eventLookup_id($name) {
        foreach ($this->uri->segments as $key => $value) {
            if ($key > 3 && !empty($value)) // checks events name with '/' in between
                $name.="/" . $value;
        }
        $eventId = $this->kol->getEventLookupId(urldecode($name));
        echo json_encode($eventId);
    }

    /**
     * Searches for the EventName and Returns the list of Event Names matched
     *
     * @param String $category
     * @param String $eventName
     * @return unknown_type
     */
    function get_eventLookup_names($category, $eventName) {
        $eventName = utf8_urldecode($this->input->post('keyword'));
        $arrEventLookupNames = $this->kol->getEventLookupNames($category, $eventName);
        $arrSuggestEvents = array();
        if (sizeof($arrEventLookupNames) == 0) {
            $arrSuggestEvents[0] = 'No results found for ' . $instituteName;
        } else {
            $flag = 1;
            foreach ($arrEventLookupNames as $id => $name) {
                if ($flag) {
                    $arrSuggestEvents[] = '<div class="autocompleteHeading">Events Names</div><div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestEvents[] = '<div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $eventName;
        $arrReturnData['suggestions'] = $arrSuggestEvents;
        echo json_encode($arrReturnData);
    }

    /**
     * Searches for the EventName and Returns the list of Event Names matched
     *
     * @param String $category
     * @param String $eventName
     * @return unknown_type
     */
    function get_search_eventLookup_names($eventName) {
        $eventName = utf8_urldecode($this->input->post($eventName));
        $arrEventLookupNames = $this->kol->getSearchEventLookupNames($eventName);
        $arrSuggestEvents = array();
        if (sizeof($arrEventLookupNames) == 0) {
            $arrSuggestEvents[0] = 'No results found for ' . $eventName;
        } else {
            $flag = 1;
            foreach ($arrEventLookupNames as $id => $name) {
                if ($flag) {
                    $arrSuggestEvents[] = '<div class="autocompleteHeading">Events</div><div class="dataSet"><label name="' . $id . '" class="events" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestEvents[] = '<div class="dataSet"><label name="' . $id . '" class="events" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $eventName;
        $arrReturnData['suggestions'] = $arrSuggestEvents;
        echo json_encode($arrReturnData);
    }

    /**
     * Show the page of Add Event Lookup details
     *
     */
    function add_event_lookup($eventName) {
        $data['eventName'] = $eventName;
        $this->load->view('events/add_event_lookup', $data);
    }

    /**
     * Saves the Event Lookup Detail to DB
     *
     */
    function save_event_lookup() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Event Lookup
            $eventLookupDetails = array('category' => $this->input->post('category'),
                'name' => ucwords(trim($this->input->post('name'))),
                'notes' => $this->input->post('notes'),
                'created_by' => $this->loggedUserId,
                'created_on' => date('Y-m-d H:i:s'));
            // Create an array to return the result
            $arrResult = array();
            if ($lastInsertId = $this->kol->saveEventLookup($eventLookupDetails)) {
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $lastInsertId;
                $arrResult['data'] = $eventLookupDetails;
                $arrResult['msg'] = "Successfully saved the new Event name";
            } else {
                $arrResult['saved'] = false;
                $arrResult['msg'] = "Sorry! Event Name is already present in the Database";
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * Searches for the Role name and Returns the list of Role names matched
     * @param String $type
     * @param String 	$roleName
     * @return unknown_type
     */
    function get_role_names($type, $roleName) {
        $arrRoleNames = $this->kol->getRoleNames($type, $roleName);
        $arrReturnData['query'] = $roleName;
        $arrReturnData['suggestions'] = $arrRoleNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Searches for the Role name and Returns the list of Role names matched
     * @param String $type
     * @param String 	$roleName
     * @return unknown_type
     */
    function get_search_role_names($roleName) {
        $arrRoleNames = $this->kol->getSearchRoleNames($roleName);
        $arrReturnData['query'] = $roleName;
        $arrReturnData['suggestions'] = $arrRoleNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Searches for the Organizer name and Returns the list of Organizer names matched
     *
     *
     * @param String 	$organizerName
     * @return unknown_type
     */
    function get_organizer_names($organizerName) {
        $arrOrganizerNames = $this->kol->getOrganizerNames($organizerName);
        $arrReturnData['query'] = $organizerName;
        $arrReturnData['suggestions'] = $arrOrganizerNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the Event Type ID
     *
     * @param String	$eventName
     * @return unknown_type
     */
    function get_event_type_id($eventName = '') {
        // Get Event Type ID by passing event name
        $eventTypeID = $this->Event_helper->getEventTypeId($eventName);
        echo json_encode($eventTypeID);
    }

    /**
     * Returns the Event Type ID
     *
     * @param String	$eventName
     * @return unknown_type
     */
    function get_conf_event_type_id() {
        $eventType = $this->input->post('eventType');
        $sessionType = $this->input->post('sessionType');
        $country = $this->input->post('country');
        $topicName = $this->input->post('topic');
        $stateName = $this->input->post('state');
        $organizerType = $this->input->post('organizer_type');
        $sponsorType = $this->input->post('sponsor_type');
        $eventTypeID = $this->Event_helper->getConfEventTypeId($eventType);
        $countryId = '';
        $stateId = '';
        $topicId = '';
        $arrStates = array();
        $arrCities = array();
        $sessionTypeId = $this->Event_helper->getConfSessionTypeId($sessionType);
        if ($topicName != '0')
            $topicId = $this->kol->getTopicId($topicName);
        if ($country != '0')
            $countryId = $this->Country_helper->getConcountryId($country);
        if ($countryId != '')
            ;
        $arrStates = $this->Country_helper->getStatesByCountryId($countryId);

        if ($organizerType != '') {
            $organizerTypeId = $this->Event_helper->getOrganizerIdByType($organizerType);
        }
        foreach ($arrStates as $state) {
            if ($state['state_name'] == $stateName)
                $stateId = $state['state_id'];
        }
        if ($stateId != '')
            $arrCities = $this->Country_helper->getCitiesByStateId($stateId);
        $arrReturnData['states'] = $arrStates;
        $arrReturnData['cities'] = $arrCities;
        $arrReturnData['event_type'] = $eventTypeID;
        $arrReturnData['session_type'] = $sessionTypeId;
        $arrReturnData['country_id'] = $countryId;
        $arrReturnData['topic_id'] = $topicId;
        $arrReturnData['organizer_type'] = $organizerTypeId;
        //$arrReturnData['state_id']		 = $stateId;
        echo json_encode($arrReturnData);
    }

    //-------------End of Event functions-------------------------------
    //-------------Start of Education & Training functions-------------------------------
    /**
     * Show the page of Add Education details
     *
     */
    function add_education_detail($kolId = null) {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        // Get the existing education details
        $data['arrEducationDetails'] = array();
        // Get the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Returns all the InstituteNames from the lookuptable
        $arrAllInstituteNames = $this->kol->getAllInstituteNames();
        $data['arrAllInstituteNames'] = $arrAllInstituteNames;
        //$this->load->view('education_training/add_education_detail', $data);
        $data['contentPage'] = 'education_training/add_education_detail';
        $this->load->view('layouts/analyst_view', $data);
    }

    /**
     * Saves the Education Detail to DB
     *
     */
    function save_education_detail() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Education
            $dataType = 'User Added';
            $client_id =$this->session->userdata('client_id');
            if($client_id == INTERNAL_CLIENT_ID){
                $dataType = 'Aissel Analyst';
            }
            $educationDetails = array('type' => $this->input->post('type'),
                'institute_id' => $this->input->post('institute_id'),
                'degree' => ucwords(trim($this->input->post('degree'))),
                'specialty' => ucwords(trim($this->input->post('specialty'))),
                'start_date' => trim($this->input->post('start_date')),
                'end_date' => trim($this->input->post('end_date')),
                'honor_name' => $this->input->post('honor_name'),
                'year' => $this->input->post('year'),
                'url1' => $this->input->post('url1'),
                'url2' => $this->input->post('url2'),
                'notes' => $this->input->post('notes'),
                'created_by' => $this->loggedUserId,
                'created_on' => date("Y-m-d H:i:s"),
                'kol_id' => $this->input->post('kol_id'),
                'client_id' => $this->session->userdata('client_id'),
                'data_type_indicator' => $dataType
            );
            if($educationDetails['type'] == 'board_certification'){
            	$educationDetails['degree'] = '';
            }
            // Create an array to return the result
            $arrResult = array();
            if (!isset($educationDetails['institute_id']) || $educationDetails['institute_id'] == 0 || $educationDetails['institute_id'] == '')
                $educationDetails['institute_id'] = null;
            if ($lastInsertId = $this->kol->saveEducationDetail($educationDetails)) {
            	$arrEducationDetails = $this->kol->getEducationById($lastInsertId);
            	$educationDetails['first_name'] = $arrEducationDetails['first_name'];
            	$educationDetails['last_name'] = $arrEducationDetails['last_name'];
            	$educationDetails['is_analyst'] = $arrEducationDetails['is_analyst'];
               // $this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $lastInsertId, MODULE_KOL_EDUCATION, $educationDetails['kol_id']);
               $transaction_name = ucfirst($educationDetails['type']);
            	$arrLogDetails = array(
            	        'module' => 'kols',
            	        'type' => LOG_ADD,
            	        'description' => 'New '.$transaction_name,
            	        'status' => 'success',
            	        'transaction_id' => $lastInsertId,
            	        'transaction_table_id' => KOL_EDUCATIONS,
            	        'transaction_name' => 'New '.$transaction_name,
            	        'form_data' => json_encode($educationDetails),
            	        'parent_object_id' => $educationDetails['kol_id'],
            	);
            	
            	$this->config->set_item('log_details', $arrLogDetails);
            	$arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $lastInsertId;

                //This field value doesn't apply's to "honors_awards"
                if ($educationDetails['type'] != 'honors_awards') {
                    //Getting the name of the  Institute By Passing The Id
                    $educationDetails['institute_id'] = $this->kol->getInstituteName($educationDetails['institute_id']);
                }
                //Additional prameter 'date' for client view use only. It doesn't afeect or include in the Analyst app
                $educationDetails['date'] = '';
                /* 		if($educationDetails['start_date'] != '')
                  $row['date']	.=	$educationDetails['start_date'];

                  if(($educationDetails['start_date'] != '') && ($educationDetails['end_date']!= ''))
                  $row['date']	.=	" - ";

                  if($educationDetails['end_date'] != '')
                  $row['date']	.=	$educationDetails['end_date'];
                  $educationDetails['date'] = $row['date'];
                 */
                if ($educationDetails['start_date'] != '')
                    $educationDetails['date'] .=$educationDetails['start_date'];
                else
                    $educationDetails['date'] .='NA';

                $educationDetails['date'] .=" - ";

                if ($educationDetails['end_date'] != '')
                    $educationDetails['date'] .=$educationDetails['end_date'];
                else
                    $educationDetails['date'] .='NA';

                if ($educationDetails['date'] == 'NA - NA') {
                    $educationDetails['date'] = '';
                }


                //End of Additional prameter 'date' for client view use only

                if ($educationDetails['url1'] != '') {
                    $educationDetails['url1'] = '<a href=\'' . $educationDetails['url1'] . '\' target="_new">URL1</a>';
                }
                if ($educationDetails['url2'] != '') {
                    $educationDetails['url2'] = '<a href=\'' . $educationDetails['url2'] . '\' target="_new">URL2</a>';
                }
                $arrResult['data'] = $educationDetails;
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * List the Education Details data
     *
     */
    function list_education_details($type, $kolId) {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrEducationResults = array();
        $arrEducationDetails = array();
        $data = array();
        if ($arrEducationResults = $this->kol->listEducationDetails($type, $kolId)) {
            $count = sizeof($arrEducationResults);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrEducationResults;
        }
        echo json_encode($data);
    }

    /**
     * List the "Education Details data for view_biography"
     *
     */
    function list_education_grid_details($type, $kolId = null, $isGrid=false) {
        $arrEducationResults = array();
        $arrEducationDetails = array();
        $arrEducationGridResults = array();
        $arrEducation = array();
        $data = array();

        if ($arrEducationResults = $this->kol->listEducationDetails($type, $kolId)) {
            foreach ($arrEducationResults as $row) {
                $row['date'] = '';
                if ($row['start_date'] != '')
                    $row['date'] .= $row['start_date'];
                else
                    $row['date'] .= 'NA';

                //	if(($row['start_date'] != '') && ($row['end_date']))
                $row['date'] .= " - ";
                if ($row['end_date'] != '')
                    $row['date'] .= $row['end_date'];
                else
                    $row['date'] .= 'NA';
                if ($row['date'] == 'NA - NA') {
                    $row['date'] = '';
                }
                $row['year'] = date_display($row['year']);
                $arrEducationGridResults[] = $row;
            }
            foreach($arrEducationGridResults as $key=>$value){
				if($value['type']=='education'){
					$arrEducationGridResults[$key]['type_name']	= "Education";
					$arrEducationGridResults[$key]['type'] = "education";
					$arrEducation['education'][]			= $arrEducationGridResults[$key];
				}
				if($value['type']=='training'){
					$arrEducationGridResults[$key]['type_name']	= "Training";
					$arrEducationGridResults[$key]['type'] = "training";
					$arrEducation['training'][]				= $arrEducationGridResults[$key];
				}
				if($value['type']=='honors_awards'){
					$arrEducationGridResults[$key]['type_name']	= "Honors and Awards";
					$arrEducationGridResults[$key]['type'] = "honors";
					$arrEducationGridResults[$key]['institute_id']	= $arrEducationGridResults[$key]['honor_name'];
					$arrEducation['honors_awards'][]		= $arrEducationGridResults[$key];
				}
				if($value['type']=='board_certification'){
					$arrEducationGridResults[$key]['type_name']	= "Board Certification";
					$arrEducationGridResults[$key]['type'] = "board_certification";
					$arrEducation['board_certification'][]	= $arrEducationGridResults[$key];
				}
				$arrEducation['allEduDetails'][]	= $arrEducationGridResults[$key];
			}
            //$data['rows'] 		= 	$arrEducationGridResults;
        }
        if ($arrContactsResults = $this->kol->listAdditionalContacts($kolId)) {
            foreach ($arrContactsResults as $row) {
                $arrEducation['additionalContacts'][] = $row;
            }
            //pr($arrEducation['additionalContacts']);
        }
        if($isGrid){
        	$data= array();
        	foreach ($arrEducation['allEduDetails'] as $row) {
        		$arr[] = $row;
        	}
        	$page = (int) $this->input->post('page'); // get the requested page
        	$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        	$count = sizeof($arr);
        	if ($count > 0) {
        		$total_pages = ceil($count / $limit);
        	} else {
        		$total_pages = 0;
        	}
        	$data['records'] = $count;
        	$data['total'] = $total_pages;
        	$data['page'] = $page;
        	$data['rows'] = $arr;
        	echo json_encode($data);
        }else{
        	echo json_encode($arrEducation);
        }
    }
    

    /**
     * Edit the Education Detail right now unused method
     *
     */
    function edit_education_detail($id) {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $count = $arrEducationDetails->num_rows();
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records  '] = $count;
        $data['total '] = $total_pages;
        $data['page  '] = $page;
        if ($arrEducationDetails = $this->kol->editEducationDetailById($id)) {
            foreach ($arrEducationDetails->result_array() as $row) {
                $data['rows'][] = $row;
            }
        }
        $this->load->view('education_training/edit_education_detail', $data);
    }

    /**
     * Updates the Education detail to DB
     *
     */
    function update_education_detail() {
        if (isset($_POST) && count($_POST) > 0) {
            $inst_id = null;
            if($this->input->post('institute_id')){
                $inst_id = $this->input->post('institute_id');
            }   
            
            $dataType = 'User Added';
            $client_id =$this->session->userdata('client_id');
            if($client_id == INTERNAL_CLIENT_ID){
                $dataType = 'Aissel Analyst';
            }
            // Getting the POST details of Education
            $educationDetails = array('id' => $this->input->post('id'),
                'type' => $this->input->post('type'),
                'institute_id' => $inst_id,
                'degree' => ucwords(trim($this->input->post('degree'))),
                'specialty' => ucwords(trim($this->input->post('specialty'))),
                'start_date' => $this->input->post('start_date'),
                'end_date' => $this->input->post('end_date'),
                'honor_name' => $this->input->post('honor_name'),
                'year' => $this->input->post('year'),
                'url1' => $this->input->post('url1'),
                'url2' => $this->input->post('url2'),
                'notes' => $this->input->post('notes'),
                'modified_by' => $this->loggedUserId,
                'modified_on' => date("Y-m-d H:i:s"),
                'client_id' => $this->session->userdata('client_id'),
                'data_type_indicator' => $dataType                        
            );
            if($educationDetails['type'] == 'board_certification'){
            	$educationDetails['degree'] = '';
            }
            // Create an array to return the result
            $arrResult = array();

            if ($this->kol->updateEducationDetail($educationDetails)) {
                //$this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_UPDATE, $educationDetails['id'], MODULE_KOL_EDUCATION, $this->input->post('kol_id'));
                $transaction_name = ucfirst($educationDetails['type']);
                $arrLogDetails = array(
                        'module' => 'kols',
                        'type' => LOG_ADD,
                        'description' => 'Update '.$transaction_name,
                        'status' => 'success',
                        'transaction_id' => $this->input->post('id'),
                        'transaction_table_id' => KOL_EDUCATIONS,
                        'transaction_name' => 'Update '.$transaction_name,
                        'form_data' => json_encode($educationDetails),
                        'parent_object_id' => $this->input->post('kol_id'),
                );
                 
                $this->config->set_item('log_details', $arrLogDetails);
                
                
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $educationDetails['id'];
                //This field value doesn't apply's to "honors_awards"
                if ($educationDetails['type'] != 'honors_awards') {
                    //Getting the name of the  Institute By Passing The Id
                    $educationDetails['institute_id'] = $this->kol->getInstituteName($educationDetails['institute_id']);
                }
                if ($educationDetails['url1'] != '') {
                    $educationDetails['url1'] = '<a href=\'' . $educationDetails['url1'] . '\' target="_new">URL1</a>';
                }
                if ($educationDetails['url2'] != '') {
                    $educationDetails['url2'] = '<a href=\'' . $educationDetails['url2'] . '\' target="_new">URL2</a>';
                }
                $arrResult['data'] = $educationDetails;
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * Delete the Education detail From DB
     *
     */
    function delete_education_detail($id) {
        if ($this->kol->deleteEducationDetailById($id)) {
            $this->update->deleteUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $id, MODULE_KOL_EDUCATION);
            $this->update->deleteUpdateEntry(KOL_PROFILE_EDUCATION_UPDATE, $id, MODULE_KOL_EDUCATION);
            //echo 'success';
            $data['status'] = 'success';
        } else {
            //echo 'failed to delete';
            $data['status'] = 'fail';
        }
        echo json_encode($data);
    }

    /**
     * Returns the list of Institute Names, based on the Education Type
     *
     * @param String	$educationType
     * @param String 	$instituteName
     * @return unknown_type
     */
    function get_education_institutes($educationType, $instituteName) {

        $arrInstituteNames = $this->kol->getEducationInstitutes($educationType, $instituteName);

        $arrReturnData['query'] = $instituteName;
        $arrReturnData['suggestions'] = $arrInstituteNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the list of Degree Names, based on the Education Type
     *
     * @param String	$educationType
     * @param String 	$degreeName
     * @return unknown_type
     */
    function get_education_degrees($educationType, $degreeName) {
        $arrDegreeNames = $this->kol->getEducationDegrees($educationType, $degreeName);
        $arrReturnData['query'] = $degreeName;
        $arrReturnData['suggestions'] = $arrDegreeNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the list of Specialty Names, based on the Education Type
     *
     * @param String	$educationType
     * @param String 	$specialtyName
     * @return unknown_type
     */
    function get_education_specialtys($educationType, $specialtyName) {
        $arrSpecialtyNames = $this->kol->getEducationSpecialtys($educationType, $specialtyName);
        $arrReturnData['query'] = $specialtyName;
        $arrReturnData['suggestions'] = $arrSpecialtyNames;
        echo json_encode($arrReturnData);
    }

    /**
     * Returns the Institute Id
     *
     * @param String $name
     * @return int (Integer id)
     */
    function get_institute_id($name) {
        $instituteId = $this->kol->getInstituteId($name);
        echo json_encode($instituteId);
    }

    /**
     * Returns the Institute Id if Exist else save the institute and returns its id
     * @author Ambarish
     * @since 2.2
     * @Created-on 03-may-11
     *
     * @param String $name
     * @return int (Integer id)
     */
    function get_institute_id_else_save() {
        $name = $this->input->post('name');
        //echo $name;
        $institutionDetails = array('name' => $name,
            'notes' => $this->input->post('notes'),
            'created_by' => $this->loggedUserId,
            'created_on' => date('Y-m-d H:i:s'));
        $instituteId = $this->kol->getInstituteIdElseSave($institutionDetails);
        echo json_encode($instituteId);
    }

    /**
     * Returns the Event Id if Exist else save the institute and returns its id
     * @author vinayak
     * @since 2.2
     * @Created-on 03-may-11
     *
     * @param String $name
     * @return int (Integer id)
     */
    function get_event_id_else_save($name) {
    	//since the space in $name was taking %20, we replace it to clean up to store in database.
    	$name = str_replace("%20"," ",$name);
    	
        $eventDetails = array('name' => $name,
            'notes' => $this->input->post('notes'),
            'created_by' => $this->loggedUserId,
            'created_on' => date('Y-m-d H:i:s'));
        $eventId = $this->kol->getEventIdElseSave($eventDetails);
        echo json_encode($eventId);
    }

    /**
     * Searches for the InstituteName and Returns the list of Institution Names matched
     *
     * @param String 	$instituteName
     * @return unknown_type
     */
    function get_institute_names($instituteName) {
        $instituteName = utf8_urldecode($this->input->post($instituteName));
        $arrInstituteNames = $this->kol->getInstituteNames($instituteName);
        $arrSuggestInstitutes = array();
        if (sizeof($arrInstituteNames) == 0) {
            $arrSuggestInstitutes[0] = 'No results found for ' . $instituteName;
        } else {
            $flag = 1;
            foreach ($arrInstituteNames as $id => $name) {
                if ($flag) {
                    $arrSuggestInstitutes[] = '<div class="autocompleteHeading">Institute Names</div><div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestInstitutes[] = '<div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $instituteName;
        $arrReturnData['suggestions'] = $arrSuggestInstitutes;
        echo json_encode($arrReturnData);
    }

    /**
     * Show the page of Add Institution details
     *
     */
    function add_institution($name) {
        $eventName = str_replace('%20', ' ', $name);
        $data['name'] = $eventName;
        $this->load->view('education_training/add_institution', $data);
    }

    /**
     * Saves the Institution Detail to DB
     *
     */
    function save_institution() {
        if (isset($_POST) && count($_POST) > 0) {
            $institutionDetails = array('name' => ucwords(trim($this->input->post('name'))),
                'notes' => $this->input->post('notes'),
                'created_by' => $this->loggedUserId,
                'created_on' => date('Y-m-d H:i:s'));
            $arrResult = array();
            //TODO: Check even for the Unique Institute Name validation, in the later stage
            if ($lastInsertId = $this->kol->saveInstitution($institutionDetails)) {
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $lastInsertId;
                $arrResult['data'] = $institutionDetails;
                $arrResult['msg'] = "Successfully saved the new institute name";
            } else {
                $arrResult['saved'] = false;
                $arrResult['msg'] = "Sorry! Institute Name is  already present in database";
            }
            echo json_encode($arrResult);
        }
    }

    //-------------End of Education & Training functions-------------------------------
    //-------------Start of Press functions-------------------------------
    /**
     * Show the page of Add Press details
     *
     */
    function add_press() {
        $this->load->view('media/add_press');
    }

    /**
     * Saves the Press Data to DB
     *
     */
    function save_press() {
        if (isset($_POST) && count($_POST) > 0) {

            // Getting the POST details of Events
            $pressDetails = array('publication_name' => $this->input->post('publication_name'),
                'article_name' => $this->input->post('article_name'),
                'date' => $this->input->post('date'),
                'link' => $this->input->post('link'));
        }
    }

    //-------------End of Press functions-------------------------------
    //-------------Start of Social Media functions-------------------------------
    /**
     * Show the page of Add Social Media details
     *
     */
    function add_social_media($kolId = null) {
        //Analyst App to be accessed by only Aissel users.
        $this->common_helpers->checkUsers();
        // Get the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['contentPage'] = 'media/add_social_media';
        $this->load->view('layouts/analyst_view', $data);
    }

    /**
     * Saves the Social Media Data to DB
     *
     */
    function save_social_media() {
        if (isset($_POST) && count($_POST) > 0) {

            // Getting the POST details of Events
            $socialMediaDetails = array('blog' => $this->input->post('blog'),
                'linked_in' => $this->input->post('linked_in'),
                'facebook' => $this->input->post('facebook'),
                'twitter' => $this->input->post('twitter'),
                'myspace' => $this->input->post('myspace'),
                'you_tube' => $this->input->post('you_tube'),
                'id' => $this->input->post('kol_id'));
            $this->kol->saveSocialMedia($socialMediaDetails);
            $this->update->insertUpdateEntry(KOL_PROFILE_SOCIAL_MEDIA_UPDATE, $socialMediaDetails['id'], MODULE_KOL_OVERVIEW, $socialMediaDetails['id']);
        }
    }

    //-------------End of Social Media functions-------------------------------
    //-------------Start of Contact functions-------------------------------
    /**
     * Show the page of Add Contact details
     *
     */
    function add_contact() {
        // Get the existing Contact details
        $data['arrContactDetails'] = array();
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
            $data[] = $arrContactDetails;
        }
        $arrKolDetail = $this->kol->editKol($this->session->userdata('kolId'));
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $this->load->view('contacts/add_contact', $data);
    }

    /**
     * Saves the Contact Details to DB
     *
     */
    function save_contact() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Contact
            $contactDetails = array('related_to' => $this->input->post('related_to'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'created_by' => $this->loggedUserId,
                'created_on' => date("Y-m-d H:i:s"),
                'kol_id' => $this->input->post('kol_id'));


            // Create an array to return the result
            $arrResult = array();
            if ($lastInsertId = $this->kol->saveContact($contactDetails)) {
                $this->update->insertUpdateEntry(KOL_PROFILE_EDUCATION_ADD, $lastInsertId, MODULE_KOL_EDUCATION, $contactDetails['kol_id']);
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $lastInsertId;
                $arrResult['data'] = $contactDetails;
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * List the Contacts Data
     *
     */
    function list_contacts() {
        $page = (int) $this->input->post('page'); // get the requested page
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
        $arrContactDetails = array();
        $data = array();
        if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
            $count = sizeof($arrContactDetails);
            if ($count > 0) {
                $total_pages = ceil($count / $limit);
            } else {
                $total_pages = 0;
            }
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrContactDetails;
        }
        echo json_encode($data);
    }

    /**
     * Edit the Contact Detail
     *
     */
    function edit_contact($id) {
        if ($arrContactDetails = $this->kol->editContactById($id)) {
            foreach ($arrContactDetails->result_array() as $row) {
                $data['arrContactDetails'][] = $row;
            }
        }
        $this->load->view('contacts/edit_contact', $data);
    }

    /**
     * Updates the Contact detail to DB
     *
     */
    function update_contact() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Contact
            $contactDetails = array('id' => $this->input->post('id'),
                'related_to' => $this->input->post('related_to'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'modified_by' => $this->loggedUserId,
                'modified_on' => date("Y-m-d H:i:s"));
            // Create an array to return the result
            $arrResult = array();
            if ($this->kol->updateContact($contactDetails)) {
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $contactDetails['id'];
                $arrResult['data'] = $contactDetails;
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * Delete the Contact detail From DB
     *
     */
    function delete_contact($id) {
        if ($this->kol->deleteContactById($id)) {
            echo 'success';
        } else {
            echo 'failed to delete';
        }
    }

    //-------------End of Contact functions-------------------------------
    //-------------Start of Organization functions-------------------------------

    /**
     * Show the page of Add Organizations details
     *
     */
    function add_organization() {
        // Get the existing Organization details
        $data['arrOrganizationDetails'] = array();
        if ($arrOrganizationDetails = $this->kol->listOrganizations()) {
            foreach ($arrOrganizationDetails->result_array() as $row) {
                $data['arrOrganizationDetails'][] = $row;
            }
        }
        //- End of getting Organization details
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $this->load->view('organizations/add_organization', $data);
    }

    /**
     * Saves the Organization Detail to DB
     *
     */
    function save_organization() {
        if (isset($_POST) && count($_POST) > 0) {
            // Getting the POST details of Organization
            $organizationDetails = array('name' => $this->input->post('name'),
                'background' => $this->input->post('background'),
                'mission_vision' => $this->input->post('mission_vision'),
                'products_services' => $this->input->post('products_services'),
                'headquarters' => $this->input->post('headquarters'),
                'website' => $this->input->post('website'),
                'address' => $this->input->post('address'),
                'phone' => $this->input->post('phone'),
                'fax' => $this->input->post('fax'),
                'country_id' => $this->input->post('country_id'),
                'state_id' => $this->input->post('state_id'),
                'city_id' => $this->input->post('city_id'),
                'postal_code' => $this->input->post('postal_code'),
                'comments' => $this->input->post('comments'),
                'blog' => $this->input->post('blog'),
                'facebook' => $this->input->post('facebook'),
                'twitter' => $this->input->post('twitter'),
                'youtube' => $this->input->post('youtube'),
                'linkedin' => $this->input->post('linkedin'),
                'myspace' => $this->input->post('myspace'),
                'created_by' => $this->loggedUserId,
                'created_on' => date('Y-m-d H:i:s'));
            // Create an array to return the result
            $arrResult = array();
            if ($lastInsertId = $this->kol->saveOrganization($organizationDetails)) {
                $arrResult['saved'] = true;
                $arrResult['lastInsertId'] = $lastInsertId;
                $arrResult['data'] = $organizationDetails;
                redirect(base_url() . 'kols/edit_kol/' . $this->session->userdata('kolId'));
            } else {
                $arrResult['saved'] = false;
            }
            echo json_encode($arrResult);
        }
    }

    /**
     * Returns the list of Names of Organizations
     *
     */
    function get_organization_names($organizationName,$restrictByRegion=0) {
    	if($organizationName!="keyword"){
    		$currentkolName  = $organizationName;
    		$organizationName   = $restrictByRegion;
    		$restrictByRegion  = $currentkolName;
    	}
        $organizationName = utf8_urldecode($this->input->post($organizationName));
        $arrOrgNames = $this->kol->getOrganizationNamesWithStateCity($organizationName,$restrictByRegion);
        $arrOrgs = array();
        if (sizeof($arrOrgNames) == 0) {
            $arrSuggestOrgs[0] = 'No results found for ' . $organizationName;
        } else {
            $flag = 1;
            foreach ($arrOrgNames as $row) {
                 $cityState=$row['city'];
            if(isset($row['city']) && isset($row['state']))
                 $cityState.= ', ';
             $cityState.=$row['state'];
                if ($flag) {
                    $arrSuggestOrgs[] = '<div class="autocompleteHeading">Organizations</div><div class="dataSet"><label name="' . $row['id'] . '" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestOrgs[] = '<div class="dataSet"><label name="' . $row['id'] . '" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $organizationName;
        $arrReturnData['suggestions'] = $arrSuggestOrgs;
        echo json_encode($arrReturnData);
    }

    //-------------End of Organization functions-------------------------------

    /**
     * Uploads the KOL Image
     */
    function upload_image($kolId=null) {
        $this->load->library('ColinUpload');

        //pr($_FILES['kol_image']['name']);
        $pathInfo = pathinfo($_FILES['kol_image']['name']);
        //echo $pathInfo['extension'];
        $ext = $pathInfo['extension'];
        if ($ext == 'jpg' || $ext == 'png' || $ext == 'gif' || $ext == 'tiff' || $ext == 'bmp' || $ext == 'jpeg' | $ext = 'jpe' || $ext = 'jfif' || $ext == 'tif'
        ) {
            
        } else {
            echo '<div id="output">Fail</div>';
//            break;
        }
        $kolImage = new ColinUpload($_FILES['kol_image']);
        if ($kolImage->uploaded) {
            // Save uploaded image with a random name
            // Generate the Random String
            $this->load->helper('String');
            $newFileName = random_string('unique', 20);
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->Process('images/kol_images/original');
            if ($kolImage->processed) {
                
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
            // Resize the image to Medium Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            // If the Height of the original image is more than the Width. like 150 wide X 500 Height
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 300;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 400;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/medium');
            if ($kolImage->processed) {
                
            } else {
                log_message('error', 'Error while Resizing the Image to Medium Size' . $kolImage->error);
            }
            // Resize the image to Small Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 100;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 100;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/resized');


            // Resize the image to Small Size and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            if ($kolImage->image_src_y > $kolImage->image_src_x) {
                $kolImage->image_y = 40;
                $kolImage->image_ratio_x = true;
            } else {
                $kolImage->image_x = 40;
                $kolImage->image_ratio_y = true;
            }
            $kolImage->Process('images/kol_images/resized/microview/');
            if ($kolImage->processed) {
                //echo 'Image Resized';
                $kolImage->Clean();
                // Save the Image Path into the database
                $this->kol->db->where('id', $kolId);
                $data['profile_image'] = $newFileName . '.' . $kolImage->file_src_name_ext;
                $this->kol->db->update('kols', $data);
                // Output the HTML text
                echo '<div id="output">success</div>';
                //then output your message (optional)
                $imageSrc = base_url() . 'images/kol_images/medium/' . $data['profile_image'];
                echo '<div id="message"><img src="' . $imageSrc . '" alt="Uploaded Image"> </div>';
                echo '<div id="imageSrc">' . $imageSrc . '</div>';
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
        }
    }

    /**
     * Crops the Uploaded Image
     * @return unknown_type
     */
    function crop_image() {
        $x1 = $this->input->post('x1');
        $y1 = $this->input->post('y1');
        $x2 = $this->input->post('x2');
        $y2 = $this->input->post('y2');
        $w = $this->input->post('w');
        $h = $this->input->post('h');
        $thumbImagePath = $this->input->post('thumbImagePath');
        // Get the FileName info
        $arrFileInfo = pathinfo($thumbImagePath);
        // Filename without Extension
        $fileName = $arrFileInfo['filename'];
        $fileExtn = $arrFileInfo['extension'];
        /** As of now we don't need this code * */
        $maxSmallImageWidth = 100;
        // Calculate the SCaling Factor
        $scale = $maxSmallImageWidth / $w;
        // Get the existing Image Dimension of the Medium Sized image
        list($imageWidth, $imageHeight, $imageType) = getimagesize($thumbImagePath);
        $newImageWidth = ceil($w * $scale);
        $newImageHeight = ceil($h * $scale);
        /** End of Unwanted Code * */
        $this->load->library('ColinUpload');
        // Create the absolute path of the local file system
        $docRoot = $_SERVER['DOCUMENT_ROOT'];
        $absFilePath = $docRoot . '/' . $this->config->item('app_folder_path') . 'images/kol_images/medium/' . $fileName . '.' . $fileExtn;
        $kolImage = new ColinUpload($absFilePath);
        $newFileName = $kolImage->file_src_name_body;
        $kolImage->file_new_name_body = $newFileName;
        // Resize the image to Medium Size and save
        $kolImage->file_new_name_body = $newFileName;
        $kolImage->image_resize = true;
        // For Colin Upload
        // My Observation - Top, Right , Bottom , Left (As seen with Crop dimension from Office Pict)
        $right = $imageWidth - $x1 - $w;
        $left = $x1;
        $top = $y1;
        $bottom = $imageHeight - $y1 - $h;
        //- End of Observation
        $kolImage->image_precrop = array($top, $right, $bottom, $left);
        $kolImage->image_x = 100;
        $kolImage->image_ratio_y = true;
        $kolImage->Process('images/kol_images/resized');
        if ($kolImage->processed) {
            //echo 'Image Resized';
            //$kolImage->Clean();
            // Save the Image Path into the database
            $this->kol->db->where('id', $this->session->userdata('kolId'));
            $data['profile_image'] = $kolImage->file_dst_name_body . '.' . $kolImage->file_src_name_ext;
            $this->kol->db->update('kols', $data);
        } else {
            log_message('error', 'Error while uploading the image' . $kolImage->error);
        }
        redirect(base_url() . 'kols/edit_kol/' . $this->session->userdata('kolId'));
    }

    /**
     * Uploads the Organization Logo
     */
    function upload_organization_logo() {
        $this->load->library('ColinUpload');
        $kolImage = new ColinUpload($_FILES['kol_image']);
        if ($kolImage->uploaded) {
            // Save uploaded image with a random name
            // Generate the Random String
            $this->load->helper('String');
            $newFileName = random_string('unique', 20);
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->Process('images/kol_images/original');
            if ($kolImage->processed) {
                
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
            // Resize the image and save
            $kolImage->file_new_name_body = $newFileName;
            $kolImage->image_resize = true;
            $kolImage->image_x = 144;
            $kolImage->image_ratio_y = true;
            $kolImage->Process('images/kol_images/resized');
            if ($kolImage->processed) {
                $kolImage->Clean();
                // Save the Image Path into the database
                $this->kol->db->where('id', $this->session->userdata('kolId'));
                $data['profile_image'] = $newFileName . '.' . $kolImage->file_src_name_ext;
                $this->kol->db->update('kols', $data);
                redirect(base_url() . 'kols/edit_kol/' . $this->session->userdata('kolId'));
            } else {
                log_message('error', 'Error while uploading the image' . $kolImage->error);
            }
        }
    }

    /*
     * View method for clint apllication
     *
     */

    function view($kolId = null, $subContentPage = '', $subContentParam = '') {
    	
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER) {
            $userId = $this->session->userdata('user_id');
        }
       /* if (!is_numeric($kolId)) {
            $kolId = $this->process_url_parameters($kolId);
        }*/

        if (!$kolId) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            //redirect('kols/list_kols');
            redirect('kols/list_kols_client_view');
        }
        // Getting the KOL details
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        
        if (is_numeric($arrKolDetail['suffix'])) {
            $arrKolDetail['suffix'] = $this->kol->getSuffixById($arrKolDetail['suffix']);
        }
//                pr($arrKolDetail);
        // If there is no record in the database
        if (!$arrKolDetail) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            //redirect('kols/list_kols');
            redirect('kols/list_kols_client_view');
        } else {
            $this->kol->addToKolAnalytics($kolId);
        }
        
        $arrKolDetail['state_name'] = '';
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $this->session->set_userdata('mdm_id', $arrKolDetail["mdm_id"]);
        $arrKolDetail['org_name'] = $this->kol->getOrgId($arrKolDetail['org_id']);
        if ($arrKolDetail['country_id'] != 0) {
            $arrKolDetail['country_name'] = $this->Country_helper->getCountryById($arrKolDetail['country_id']);
        }
        if ($arrKolDetail['city_id'] != 0) {
            $arrKolDetail['city_name'] = $this->Country_helper->getCityeById($arrKolDetail['city_id']);
        }
        if ($arrKolDetail['state_id'] != 0) {
            $arrKolDetail['state_name'] = $this->Country_helper->getStateById($arrKolDetail['state_id']);
        }
        $data['arrKol'] = $arrKolDetail;
        $arrKolInfo['kol_id'] = $kolId;
        $data['kol_id']=$kolId;
        
        //		$arrKolInfo['kol_name']	= $arrKolDetail['first_name'].' '.$arrKolDetail['middle_name'].' '.$arrKolDetail['last_name'];
        $arrKolInfo['kol_name'] = $this->common_helpers->get_name_format($arrKolDetail['first_name'], $arrKolDetail['middle_name'], $arrKolDetail['last_name']);
        //$data['arrCountry']		=	$this->Country_helper->listCountries();
        if ($arrKolDetail['state_id'] != 0) {
            if ($arrKolDetail['country_name'] == 'Canada' || $arrKolDetail['country_name'] == 'United States') {
                //$arrCities = $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
                $stateCode = $this->Country_helper->getStatecodeByStateIdorName($arrKolDetail['state_id'], 'id');
                $data['stateCode'] = $stateCode;
            }
        }
        // Get the list of Specialties
        $arrSpecialties = $this->Specialty->getAllSpecialties('all');
        $data['arrSpecialties'] = $arrSpecialties;
//         $data['arrPrimaryAdditionalSpecialties'] = $this->Specialty->getAllKolPrimaryAdditionalSpecialties($kolId);
        $arrSubSpecialties = $this->Specialty->getAllKolSubSpecialties($kolId);
        $data['arrSubSpecialties'] = $arrSubSpecialties;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['arrContactDetails'] = array();
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
            $data[] = $arrContactDetails;
        }
        //Get the count of "affilitions"
        $data['noOfAffilitions'] = array();
        $noOfAffilitions = $this->kol->countAfiliations($kolId);
        $data['noOfAffilitions'] = $noOfAffilitions;
        //Get the count of "Events"
        $data['noOfEvents'] = array();
        $noOfEvents = $this->kol->countEvents($kolId);
        $data['noOfEvents'] = $noOfEvents;
        //Get the count of "Publications"
        $data['noOfPublications'] = array();
        ;
        $noOfPublications = $this->kol->countPublications($kolId);
        $data['noOfPublications'] = $noOfPublications;
        //Get the count of "Trials"
        $data['noOfTrials'] = array();
        $noOfTrials = $this->kol->countTrials($kolId);
        $data['noOfTrials'] = $noOfTrials;
        /** Get the Education Details * */
        $data['arrEducationResults']['noOfRecords'] = '';
        $data['arrEducationResults']['rows'] = '';
        $arrEducationResults = array();
        if ($arrEducationResults = $this->kol->listEducationDetails('education', $this->session->userdata('kolId'))) {
            $count = sizeof($arrEducationResults);
            $data['arrEducationResults']['noOfRecords'] = $count;
            $data['arrEducationResults']['rows'] = $arrEducationResults;
        }
        //Get the Min and Max year range among the interactions and payments min and max year ranges
        $interactionsYearRanges = $this->interaction->getInteractionsYearsRange($clientId, $userId);
        $paymentsYearRanges = $this->payment->getPaymentsYearsRange($clientId, $userId);
        $arrYearRange['max_year'] = max($interactionsYearRanges['max_year'], $paymentsYearRanges['max_year']);
        $arrYearRange['min_year'] = min($interactionsYearRanges['min_year'], $paymentsYearRanges['min_year']);
        if ($arrYearRange['max_year'] == '') {
            $arrYearRange['max_year'] = date("Y");
        }
        if ($arrYearRange['min_year'] == '') {
            $arrYearRange['min_year'] = (int) $arrYearRange['max_year'] - 35;
        }
        $data['arrYearRange'] = $arrYearRange;
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['arrNotes'] = $this->kol->getNotes($kolId);
        $data['add_location'] = $this->common_helpers->isActionAllowed('location', 'add', $data);
        $data['add_education'] = $this->common_helpers->isActionAllowed('education', 'add', $data);
        
        $data['contentPage'] = 'view_biography';
        $data['subContentPage'] = $subContentPage;
        $data['subContentParam'] = $subContentParam;
        $clientKols = $this->kol->getAllKolIdsSpecificToClient();
        $data['clientKols']	= implode(",",$clientKols);
        if ($subContentPage == "personalinfo") {
            $kolPersonalInfo = array();
            $arrDocuments = array();
            $kolPersonalInfo = $this->kol->getKolPersonalInfo($kolId, $clientId);
            if (sizeof($kolPersonalInfo) > 0) {
                $arrDocuments = $this->kol->getPersonalInfoDocuments($kolPersonalInfo['id']);
            }
            $personalData['arrDocuments'] = $arrDocuments;
            $personalData['kolPersonalInfo'] = $kolPersonalInfo;
            $data['personalData'] = $personalData;
        }

        $this->load->model('Kol_rating');
        $arrCriteriaRating = $this->Kol_rating->getKolRatings($kolId);
        $asmtCategoryCount = array();
        $arrAsmtCat = array();
        if (sizeof($arrCriteriaRating) > 0) {
            $arrAsmtCat = $this->Kol_rating->getAsmtChartScore($kolId);
            $i = 0;
            $asmtPercentageScore = 0;
            foreach ($arrAsmtCat as $key => $arrAsmtCatData) {
                $i++;
                $asmtPercentageScore += $arrAsmtCatData['percentage'];
            }
            if ($i == 0) {
                $i = 1;
            }
            $asmtPercentageScore = ($asmtPercentageScore / $i);
            $maxRatingScore1 = $this->Kol_rating->getMaxRatingScore($arrKolDetail['country_id'], FALSE);
            $maxKolRatingScore1 = $this->Kol_rating->getMaxRatingScore($kolId, TRUE);
            foreach ($maxRatingScore1 as $key => $row) {
                $maxRatingScore[] = $row['count'];
                if ($asmtCatCount[$row['category_name']]) {
                    $asmtCatCount[$row['category_name']] = $asmtCatCount[$row['category_name']] + $row['count'];
                } else {
                    $asmtCatCount[$row['category_name']] = $row['count'];
                }
            }
            foreach ($maxKolRatingScore1 as $key => $row) {
                $maxKolRatingScore[] = $row['count'];
                if ($asmtKolCatCount[$row['category_name']]) {
                    $asmtKolCatCount[$row['category_name']] = $asmtKolCatCount[$row['category_name']] + $row['count'];
                } else {
                    $asmtKolCatCount[$row['category_name']] = $row['count'];
                }
            }
            $data['maxRatingScore'] = $maxRatingScore;
            $data['maxKolRatingScore'] = $maxKolRatingScore;
            $data['asmtPercentageScore'] = $asmtPercentageScore;

            foreach ($asmtCatCount as $key => $value) {
                if (isset($asmtKolCatCount)) {
                    $asmtCategoryCount[$key] = (int) (($asmtKolCatCount[$key] / $value) * 100);
                } else {
                    $asmtCategoryCount[$key] = (int) ((0 / $value) * 100);
                }
            }
        }
        if ($subContentPage == "assessment") {
//                    pr("here");
//                    exit();
            //	if($arrKolDetail['country_id'] != 0){
            $arrFormattedAsmtRules = array();
            $arrAsmtRules = array();
            $arrAsmtRules = $this->Kol_rating->getAllAsmtRules($arrKolDetail['country_id']);
            foreach ($arrAsmtRules as $key => $row) {
                $arrFormattedAsmtRules[$row['cat_name']][$row['criteria']][] = $row;
            }

            $data['arrAsmtRatings'] = $arrFormattedAsmtRules;
            $data['arrCriteriaRating'] = $arrCriteriaRating;
            $data['asmtCategoryCount'] = $asmtCategoryCount;
            $data['keys'] = array_keys($asmtCategoryCount);
            $data['values'] = array_values($asmtCategoryCount);
            //	}
        }

        if ($subContentPage == "details" || $subContentPage == "edit") {
            $data['best_times'] = $this->kol->getBestTimes($kolId);

            $data['arrKolData'] = $arrKolDetail;
            $data['arrKolProducts'] = $this->kol->getKolProducts($kolId);
            if (is_numeric($arrKolDetail['suffix'])) {
                $arrKolDetail['suffix'] = $this->kol->getSuffixById($arrKolDetail['suffix']);
            }
            $data['territoryId'] = $this->session->userdata('user_territory');
            $temp = $this->kol->getContactRestrictions($kolId);
            $data['arrContactData'] = $temp[0];
            $selectedSuffixes = explode(',',$arrKolDetail['suffix']);
            $data['selectedSuffixes'] = array_map('trim',$selectedSuffixes);
            $data['staffs'] = $this->kol->getStaffs($kolId, 'kol');
            $data['phones'] = $this->kol->getPhones($kolId, 'kol');
            $data['emails'] = $this->kol->getEmails($kolId);
            $data['stateLicenses'] = $this->kol->getStateLicences($kolId);
            $data['keyStatuses'] = $this->kol->getAllKeyStatus($kolId);
            $data['arrTitles'] = $this->kol->getAllActiveTitles('all');
            $kolLocationDetails = $this->kol->getKolPrimaryLocation($kolId);
            $data['arrLocationData'] = $kolLocationDetails[0];
            $arr = $this->kol->getKolPrimaryPhoneDetails($kolId);
            if (isset($arr['id'])) {
            	$data['arrLocationData']['phone_number'] = $arr['number'];
            	$data['arrLocationData']['phone_type'] = $arr['type'];
            } else {
            	$data['arrLocationData']['phone_number'] = '';
            	$data['arrLocationData']['phone_type'] = '';
            }
            $data['arrLocationData']['org_institution_name'] = $this->organization->getOrgNameByOrgId($data['arrLocationData']['org_institution_id']);
            $data['arrOrgDetails'] = $this->organization->editOrganization($data['arrLocationData']['org_institution_id']);
            $data['orgTypeId'] = $data['arrOrgDetails']['type_id'];
            $data['arrCountries'] = $this->Country_helper->listCountries();
            //$data['arrStates'] = $this->Country_helper->getStatesByCountryId(254);
            $data['arrStates'] = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
            if ($arrKolDetail['state_id'] != '' && $arrKolDetail['state_id'] != 0)
            	$data['arrCities'] = $this->Country_helper->getCitiesByStateId($data['arrKolData']['state_id']);
            $data['arrProducts'] = $this->common_helpers->getUserProducts($this->loggedUserId);
            $data['arrAdditionalRoles'] = $this->kol->getAllActiveAdditionalRoles();           
            $data['arrSpecialties'] = $this->Specialty->getAllSpecialties();
            $data['arrLocations'] = $this->kol->getAllLocationsByKolId($kolId);
            $data['arrSepakerProducts']=$this->common_helpers->getUserProducts($this->loggedUserId);
            $data['arrSelectedSepakerProducts'] = $this->kol->getKolSeakerProducts($kolId);
            $data['arrProfessionalSuffixes'] = $this->kol->getAllActiveProfessionalSuffixes();
            $data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
            $data['arrPhoneType'] = $this->kol->getPhoneType();
            $data['checkKolAssignedToUser']=$this->kol->checkKolAissenedToUser($kolId);
            $data['languages'] = $this->kol->getLanguages();
//                        pr($data['territoryId']);
//                        exit();
//                        $data['$licenses'] = $this->kol->getLicenses($kolId, 'kol');
            $data['contentPage'] = 'view_biography';
            $data['subContentPage'] = $subContentPage;
            if(KOL_CONSENT){
                if($data['arrKol']['opt_in_out_status'] == 4 || $data['arrKol']['opt_in_out_status'] == 0){
                    $data['subContentPage'] = $subContentPage;
                }else{
                    if($subContentPage == "details"){
                        $data['displayType'] = 'view';
                    }
                    $data['subContentPage'] = 'add_opt_in_form';
                }
            }
        }
        if ($subContentPage == "survey_form") {
            $this->load->model("survey");
            $data['arrActiveSurveys'] = $this->survey->getActiveSurveys();
            $data['arrRespondent'] = $this->survey->kolDetails($kolId, true);
            $data['arrTypes'] = $this->arrSurveyTypes;
            if (!empty($data['arrActiveSurveys'][0]['id']) && ($data['arrActiveSurveys'][0]['id'] > 0)) {
                $surveyId = $data['arrActiveSurveys'][0]['id'];
                $arrSurveyData = $this->survey->getActiveSurveyQuestions($surveyId);
                $data['arrSurveys'] = $arrSurveyData['arrQuestionData'];
                $data['surveyId'] = $arrSurveyData['surveyId'];
                $data['arrSurveyData']['name'] = $arrSurveyData['surveyName'];
            }
            $data['contentPage'] = 'surveys/kol_survey_form';
        }
        if ($subContentPage == "interaction_report") {
            $this->load->model('interaction');
            $this->load->model('client_user');
            $clientId = $this->session->userdata('client_id');
            //$clientId				= $this->session->userdata('client_id');
            $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
            $data['arrTopics'] = $this->interaction->getAllTopicsOfClient($clientId);
            $data['arrType'] = $this->interaction->getAllTypesOfClient();
            //$data['arrProduct'] = $this->interaction->getAllProductsOfClient($clientId);
            $data['arrProduct'] = $this->common_helpers->getUserProducts();
            $data['arrDiscussionType'] = $this->interaction->getDiscussionTypeByProductIds($data['arrProduct']);
            $data['arrDiscussionTopic'] = $this->interaction->getTopicsByDiscussionTypesAndProductIds($data['arrProduct'],$data['arrDiscussionType']);
            $data['arrUsers'] = $this->client_user->getClientUsers($clientId);
            $data['arrKolInfo'] = $arrKolInfo;
            $this->load->model('user_setting');
            $userId = $this->loggedUserId;
            $filterData = $this->user_setting->getDataFromAppSettings($userId,'interaction_filter_date');
            if($filterData > 0){
            	$data['fromFilterData'] = $filterData;
            }else{
            	$data['fromFilterData'] = 1;
            }
            $data['contentPage'] = 'interactions/view_numeric_report';
            
            
            $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
            $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
            $data['arrTopics'] = $this->interaction->getAllTopicsOfClient($clientId);
            $data['arrType'] = $this->interaction->getAllTypesOfClient();
            $data['arrProduct'] = $this->common_helpers->getUserProducts();
            $data['arrUsers'] = $this->Client_User->getClientUsers($clientId);
        	$managerId = $this->session->userdata("user_id");
	        $filterData['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
	        foreach ($filterData['arrManager'] as $row){
	        	$data['arrManager'][$row['id']] = $row['first_name']." ".$row['last_name'];
	        }
            $arrKolDetail = $this->kol->editKol($kolId);
            if (is_numeric($arrKolDetail['suffix'])) {
                $arrKolDetail['suffix'] = $this->kol->getSuffixById($arrKolDetail['suffix']);
            }
            // If there is no record in the database
            if (!$arrKolDetail) {
                return false;
            }
            $this->getKolProfileScore($kolId);
            // Set the KOL ID into the Session
            $this->session->set_userdata('kolId', $kolId);
            $data['arrKol'] = $arrKolDetail;
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            $data['arrSalutations'] = $arrSalutations;
            //Get Kol profile Score
            $kolsPforfileScore = $this->getKolProfileScore($kolId);
            $data['kolsPforfileScore'] = $kolsPforfileScore;
            $arrFilters = '';
            $userId = 0;
            if ($this->session->userdata('user_role_id') == ROLE_USER)
                $userId = $this->session->userdata('user_id');
//		$arrInteractionsResults=$this->interaction->getKolInteractions($clientId,$kolId,$userId,$arrFilters,$limit=10,'');
//		
//		$count=$this->interaction->getKolInteractions($clientId,$kolId,$userId,$arrFilters,$limit='all','');
//		$data['arrInteractionsResults']=	$arrInteractionsResults;
            //$data['arrOrganization']	= $arrOrganizationDetail;
            //$data['contentPage'] 	= 'interactions/list_kol_interactions';
            $data['kolId'] = $kolId;
            $data['count'] = $count;
            if ($count == 0) {
                $data['mes'] = "No interactions found";
            }
            $interactionIds = array();
            foreach ($arrInteractionsResults as $row) {
                $interactionIds[] = $row['id'];
            }
            //pr($interactionIds);
            $data['interactionIds'] = implode($interactionIds, ',');
            $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
            $data['subContentPage'] = $subContentPage;
        }
        if($subContentPage == "payments"){         
                $data['kolId'] = $kolId;
                $data['contentPage'] 	=	'payments/list_payments';
                $data['subContentPage']	=	"payments";                
        }
        if($subContentPage == "show_contracts"){
            $data['kolId'] = $kolId;
            $data['contentPage'] 	=	'contracts/list_contracts';
            $data['subContentPage']	=	$subContentPage;
        }
        if ($subContentPage == "list_medical_insights") {
            $this->load->model('interaction');
            $this->load->model('coaching');
            $this->load->model('client_user');
            $managerId = $this->session->userdata('user_id');
            $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
            $data['contentPage'] = 'coachings/list_medical_insights';
            $data['subContentPage'] = $subContentPage;
        }
        if ($subContentPage == "view_medical_insight") {
            $this->load->model('interaction');
            $this->load->model('coaching');
            $this->load->model('client_user');
            $kolId = $this->uri->segment(3);
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            $data['arrSalutations'] = $arrSalutations;
            $arrKolDetail = $this->kol->editKol($kolId);
            if (is_numeric($arrKolDetail['suffix'])) {
                $arrKolDetail['suffix'] = $this->kol->getSuffixById($arrKolDetail['suffix']);
            }
            $arrKolDetail['salutation'] = $arrSalutations[$arrKolDetail['salutation']];
            $data['arrKolDetail'] = $arrKolDetail;
            $aarData = $this->coaching->listMedicalInsight('', '', '', '', '', '', '','', $subContentParam);
            $data['arrData'] = $aarData[0];
            $data['contentPage'] = 'coachings/view_medical_insight';
            $data['subContentPage'] = $subContentPage;
        }
        if ($subContentPage == "medical_insight") {
            $this->load->model('coaching');
            $this->load->model('client_user');
            $this->load->model('interaction');
            $kolId = $this->uri->segment(3);
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            $data['arrSalutations'] = $arrSalutations;
            $arrKolDetail = $this->kol->editKol($kolId);
            $arrKolDetail['salutation'] = $arrSalutations[$arrKolDetail['salutation']];
            $data['arrKolDetail'] = $arrKolDetail;
            $clientId = $this->session->userdata('client_id');
            $therapeuticArea = $this->coaching->getTherapeuticAreaNames();
            $arrTemp = array();
            foreach ($therapeuticArea as $key => $value) {
                $arrTemp[$value['id']] = ($value['name']);
            }
            $investigationalAgent = $this->coaching->getInvestigationalAgentNames();
            $arrInvestigational = array();
            foreach ($investigationalAgent as $key => $value) {
                $arrInvestigational[$value['id']] = ($value['name']);
            }
            $sourceType = $this->coaching->getSourceTypeNames();
            $arrSourceType = array();
            foreach ($sourceType as $key => $value) {
                $arrSourceType[$value['id']] = ($value['name']);
            }
            $sphereOfInfluence = $this->coaching->getSphereOfInfluenceNames();
            $arrSphereOfInfluence = array();
            foreach ($sphereOfInfluence as $key => $value) {
                $arrSphereOfInfluence[$value['id']] = ($value['name']);
            }
            $congressSources = $this->coaching->getCongressSources();
            $arrCongressSources = array();
            foreach ($congressSources as $key => $value) {
                $arrCongressSources[$value['id']] = ($value['name']);
            }
            $data['congressSources'] = $arrCongressSources;
            $data['therapeuticArea'] = $arrTemp;
            $data['investigationalAgent'] = $arrInvestigational;
            $data['sourceType'] = $arrSourceType;
            $data['sphereOfInfluence'] = $arrSphereOfInfluence;
            $data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
            $data['contentPage'] = 'coachings/add_med_insight';
            $data['subContentPage'] = $subContentPage;
        }
        if ($subContentPage == "edit_medical_insight") {
            $this->load->model('coaching');
            $this->load->model('client_user');
            $this->load->model('interaction');
            $id = $this->uri->segment(5);
            $kolId = $this->uri->segment(3);
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            $data['arrSalutations'] = $arrSalutations;
            $arrKolDetail = $this->kol->editKol($kolId);
            $arrKolDetail['salutation'] = $arrSalutations[$arrKolDetail['salutation']];
            $data['arrKolDetail'] = $arrKolDetail;
            $clientId = $this->session->userdata('client_id');

            $data['medicalInsightDetails'] = $this->coaching->editMedicalInsight($id);
            $speciltyName = $data['medicalInsightDetails'][0]['specialty'];
            $therapeuticAreaId = $this->coaching->therapeuticAreaIdByName($speciltyName);
            foreach ($therapeuticAreaId as $key => $value) {
                $arrTempArea = ($value['id']);
            }
            $data['speciltyName'] = $arrTempArea;
            $arrProductName = $this->coaching->getProductByTheraputicArea($arrTempArea);
            $arrTemp1 = array();
            foreach ($arrProductName as $key => $value) {
                   $arrTemp1[]=$value;
//                $arrTemp1[$value['id']] = ($value['name']);
            }
            $data['productName'] = $arrTemp1;
            $productName = $data['medicalInsightDetails'][0]['product'];

            $productId = $this->coaching->getProductIdByName($productName);
            foreach ($productId as $key => $value) {
                $arrTempProduct = ($value['id']);
            }
            $arrTempKeyInsight = $this->coaching->getKeyInsightByProduct($arrTempProduct, $arrTempArea);
            $arrTemp2 = array();
            foreach ($arrTempKeyInsight as $key => $value) {
                $arrTemp2[$value['id']] = ($value['name']);
            }
            $data['KeyInsightName'] = $arrTemp2;
            $therapeuticArea = $this->coaching->getTherapeuticAreaNames();
            $arrTemp = array();
            foreach ($therapeuticArea as $key => $value) {
                //foreach ($value as $key1 => $value1) {
                //  echo $key1 ."=>". $value1."<br/>";
                $arrTemp[$value['id']] = ($value['name']);
                //}
            }
            $investigationalAgent = $this->coaching->getInvestigationalAgentNames();
            $arrInvestigational = array();
            foreach ($investigationalAgent as $key => $value) {
                $arrInvestigational[$value['id']] = ($value['name']);
            }
            $sourceType = $this->coaching->getSourceTypeNames();
            $arrSourceType = array();
            foreach ($sourceType as $key => $value) {
                $arrSourceType[$value['id']] = ($value['name']);
            }
            $sphereOfInfluence = $this->coaching->getSphereOfInfluenceNames();
            $arrSphereOfInfluence = array();
            foreach ($sphereOfInfluence as $key => $value) {
                $arrSphereOfInfluence[$value['id']] = ($value['name']);
            }
            $congressSources = $this->coaching->getCongressSources();
            $arrCongressSources = array();
            foreach ($congressSources as $key => $value) {
                $arrCongressSources[$value['id']] = ($value['name']);
            }
            $data['congressSources'] = $arrCongressSources;
            $data['therapeuticArea'] = $arrTemp;
            $data['investigationalAgent'] = $arrInvestigational;
            $data['sourceType'] = $arrSourceType;
            $data['sphereOfInfluence'] = $arrSphereOfInfluence;
            $data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
            $data['contentPage'] = 'coachings/add_med_insight';
            $data['subContentPage'] = $subContentPage;
        }
    if ($subContentPage == "bio" || $subContentPage == "") {
			$biographyTextDetails = array();
			$arrPubYearRange = $this->pubmed->getKolPubsYearsRange($kolId);
			if($arrPubYearRange['max_year']=='')
				$arrPubYearRange['max_year']	=0;
			if($arrPubYearRange['min_year']=='')
				$arrPubYearRange['min_year']	=0;
			//Prepare Experience
			$arrEducations = $this->kol->getKolYearsOfExperience("education",$kolId);
			$yearOfExp = $arrEducations[0]['end_date'];
			
			if($yearOfExp == ''){
				$arrEducations = $this->kol->getKolYearsOfExperience("training",$kolId);
				$yearOfExp = $arrEducations[0]['end_date'];
			}
			
			if($yearOfExp == ''){
				$arrEducations = $this->kol->getKolYearsOfExperience("board_certification",$kolId);
				$yearOfExp = $arrEducations[0]['start_date'];
			}
			
			if($yearOfExp == ''){
				$arrEducations		= $this->kol->getKolYearsOfExperienceFromAff($kolId);
				$yearOfExp = $arrEducations[0]['start_date'];
			}
			
			if($yearOfExp == ''){
				$pubDetails['sidx'] = 'created_date';
				$pubDetails['sord'] = 'asc';
				$arrEducations	= $this->pubmed->searchPublicationsByParameters('','','','','',$kolId,$arrPubYearRange['min_year'],$arrPubYearRange['max_year'],$pubDetails);
				foreach ($arrEducations as $pubData){
					if($pubData['created_date'] != '0000-00-00')
						$arrPubData[] = $pubData;
				}
				if(count($arrPubData)>0)
					$yearOfExp = date("Y",strtotime($arrPubData[0]['created_date']));
			}
			
			if($yearOfExp != '')
				$biographyTextDetails['experience'] = date("Y") - $yearOfExp;
			
			$arrEducationsDetails = $this->kol->listEducationDetails("education",$kolId);
			//$arrEducationsDetails = array_slice($arrEducationsDetails, 0, 2);
			$biographyTextDetails['educations'] = $arrEducationsDetails;
// 			echo $this->db->last_query();
			
			$arrAffliationsData = $this->kol->listAllAffiliationsDetails($kolId);
			$arrAffliations = array();
			foreach ($arrAffliationsData as $affData){
				$arrAffliations[] = $affData;
			}
			foreach ($arrAffliations as $key => $row) {
				$affName[$key]  = $row['start_date'];
			}
			array_multisort($affName, SORT_DESC,$arrAffliations);
			if($arrAffliations)
				$biographyTextDetails['affiliations'] = $arrAffliations;
			else
				$biographyTextDetails['affiliations'] = array();
			
			$speakerEvents = $this->kol->listEvents('conference',$kolId,'','','');
// 			pr($speakerEvents);
			$arrExcludeEventTopic = array("Admin. & Management", "Admin & Management", "Admin. and Management", "Admin and Management");
			foreach ($speakerEvents as $events){
				if(!in_array($events['topic_name'],$arrExcludeEventTopic)){ //if($events['role'] == 'Speaker')
					$biographyTextDetails['speakerEvents'][] = $events;
				}
			}				
//			$biographyTextDetails['pubAuthPosCount'] = $this->kol->getAuthPosCountByKolId($kolId);
			$biographyTextDetails['interactionsCount'] = $this->kol->getInteractionsCountByUsers($kolId,true);
			$biographyTextDetails['interactionsByUsersCount'] = $this->kol->getInteractionsCountByUsers($kolId);
			
			$arrYearRange					=	$this->kol->getEventsYearsRange($kolId);
			if($arrYearRange['max_year']=='')
				$arrYearRange['max_year']	=date("Y");
			if($arrYearRange['min_year']=='')
				$arrYearRange['min_year']	=(int)$arrYearRange['max_year']-35;
			$arrTopEvents = $this->kol->getDataForEventsTopicChart($kolId,$arrYearRange['min_year'],$arrYearRange['max_year']);
			$arrMajorMeshterm 	= $this->kol->getTopConceptDataForChart($kolId, $arrPubYearRange['min_year'],$arrPubYearRange['max_year'],'','all');
			$topThreeConceptData1 = $this->prepareTopConcepts($arrMajorMeshterm,'','C');
//			$topThreeConceptData2 = $this->prepareTopConcepts($arrMajorMeshterm,'','F');
// 			pr($topThreeConceptData1);
			$arrTopMeshTerms = array_merge($topThreeConceptData1['C']['categoryData']);
// 			pr(array_merge($topThreeConceptData1['C']['categoryData'],$topThreeConceptData2['F']['categoryData']));
			foreach ($arrTopMeshTerms as $key => $row) {
				$meshCount[$key]  = $row['count'];
			}
                                           $arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($kolId,$start,$end,0,0,0,0,$keyWord);
                                            $arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
                                            $arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
                                            $arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);

                                            $arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
                                            $arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
                                            $arrLastAuthPubsCount		=	0;
                                            $arrMiddleAuthPubsCount		=	0;
		
        foreach($arrLastAuthPubs as $lastAuthPub){
                if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
                        $arrLastAuthPubsCount++;
        }
			$biographyTextDetails['pubAuthPosCount'] = (int)$arrLastAuthPubsCount+(int)$arrFirstAuthPubsCount+(int)$arrSingleAuthPubsCount;
			array_multisort($meshCount, SORT_DESC,$arrTopMeshTerms);
			$biographyTextDetails['topPubMeshTerms'] = $arrTopMeshTerms;
			$biographyTextDetails['topEventsTopic'] = $arrTopEvents; 
// 			$data['biographyTextDetails'] = $biographyTextDetails;
			$get_profile_summary = $this->generate_profile_summary ($biographyTextDetails, $noOfPublications, $noOfTrials, $arrKolDetail);
			$data ['biographyTextDetails'] = json_decode($get_profile_summary, true);
		}
		
        if ($subContentPage != "payments") {
            $data['data']['rightSideContentPage'] = 'right_sidebar/kol_overview';
            $data['data']['rightSideContentPageData'] = array('kolId' => $kolId);
        }

        if ($subContentPage == "list_speaker_evaluation") {

            $kolId = $this->uri->segment(3);

            $data['contentPage'] = 'speakers/list_speaker_evaluation';
            $data['subContentPage'] = $subContentPage;
            $data['kolId'] = $kolId;
        }
        $data['clientId'] = $clientId;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $this->load->view('layouts/client_view', $data);
    }
    
    function generate_profile_summary($biographyTextDetails, $noOfPublications, $noOfTrials, $arrKolDetail) {
		$arrCarrier = array ();
		$arrTopics = array ();
		// Experience section
		if ($biographyTextDetails ['experience'] != '' && $biographyTextDetails ['experience'] != 0) {
			if ($biographyTextDetails ['experience'] == 1) {
				$arrCarrier ['experience'] = $biographyTextDetails ['experience'];
			} else {
				$arrCarrier ['experience'] = $biographyTextDetails ['experience'];
				;
			}
		}
		
		// Educational section
		if (count ( $biographyTextDetails ['educations'] ) > 0) {
			$i = 1;
			foreach ( $biographyTextDetails ['educations'] as $edu ) {
				if (!in_array($edu['institute_id'], $arrBioEduData )){
					if($i>2)
						continue;
				$arrCarrier ['education'] [$i] .=  $edu ['institute_id'];
				$i ++;
			}
				$arrBioEduData[] = $edu ['institute_id'];
		}
		}
		
		// Affiliation section
		if (count ( $biographyTextDetails ['affiliations'] ) > 0) {
			
			$primaryAff = trim($arrKolDetail ['org_name']);
			if ($arrKolDetail ['org_name'] != '') {
				$affText = trim($arrKolDetail ['org_name']) . ", ";
			} elseif ($arrKolDetail ['org_id'] != '') {
				$affText = trim($arrKolDetail ['org_id']) . ", ";
			} else {
				$affText = "";
			}
			
			$arrUniqueAff = array ();
			$count = 0;
			foreach ( $biographyTextDetails ['affiliations'] as $key => $aff ) {
				if (! in_array ( $aff ['name'], $arrUniqueAff ) && trim($aff['name']) != trim($arrKolDetail['org_name'])) {
					if ($count < 1 && $primaryAff != $aff ['name'] && $aff ['type'] == 'university') {
						$affText .= trim($aff ['name']) . ", ";
						$count++;
						
					}
					$arrUniqueAff [] = trim($aff ['name']);
				}
			}
			if ($affText != '') {
				$numAffLeft = count ( $arrUniqueAff ) - 1;
			} else {
				$numAffLeft = count ( $arrUniqueAff ) - 1;
				$affText = trim($arrUniqueAff [0]);
			}
		}
		
		if ($numAffLeft > 0) {
			$arrCarrier ['affiliations'] ['university_name'] =  trim ( $affText, " ," ) ;
			$arrCarrier ['affiliations'] ['affiliations_left'] = $numAffLeft;
		} else if ($affText != '') {
			$arrCarrier ['affiliations'] ['university_name'] = trim ( $affText, " ,"  );
		}
		
		// Events section
		if (count ( $biographyTextDetails ['speakerEvents'] ) > 0) {
			$arrCarrier ['speaker_events'] ['count'] = count ( $biographyTextDetails ['speakerEvents'] );
		}
		
		// Publications Section
		if ($noOfPublications > 0) {
			$arrCarrier ['publications'] ['count'] = $noOfPublications;
			$arrCarrier ['publications'] ['pub_auth_pos_count'] = $biographyTextDetails ['pubAuthPosCount'];
		}
		
		// Trails Section
		if ($noOfTrials > 0) {
			$arrCarrier ['trails'] ['no_of_trails'] = $noOfTrials;
		}
		
		// Interactions By Users Count
		if ($biographyTextDetails ['interactionsByUsersCount'] > 0) {
			$arrCarrier ['interactions'] ['interactions_by_users_count'] = $biographyTextDetails ['interactionsByUsersCount'];
			$arrCarrier ['interactions'] ['interactions_count'] = $biographyTextDetails ['interactionsCount'];
		}
		
		// Event Topics
		if (count ( $biographyTextDetails ['topEventsTopic'] ) > 0) {
			$arrTopicNames = array (
					"Therapeutic and Diagnostic Procedure",
					"Therapeutic & Diagnostic Procedure",
					"Education and Research",
					"Education & Research",
					"Patient and Healthcare",
					"Patient and Healthcare",
					"Professional Ethics",
					"Etiology/Cause of Disease",
					"Disease Complication",
					"Disease Prognosis",
					"Disease Management",
					"Admin. & Management",
					"Admin. and Management",
					"Admin & Management",
					"Admin and Management",
					"Pharmacy Management",
					"Statistics" 
			);
			foreach ( $biographyTextDetails ['topEventsTopic'] as $event ) {
				if (! in_array ( $event ["name"], $arrTopicNames )) {
					$arrTopEvents [] = $event;
				}
			}
			$arrTopEvents = array_slice ( $arrTopEvents, 0, 3 );
			$i = 1;
			foreach ( $arrTopEvents as $individual_event ) {
				$arrTopics ['topic'] [$i] ['name'] = $individual_event ['name'];
				$i ++;
			}
		}
		// Publication Mesh Terms
		if (count ( $biographyTextDetails ['topPubMeshTerms'] ) > 0) {
			$arrTopPubMeshTerms = array ();
			$arrTopPubMeshTerms = array_slice ( $biographyTextDetails ['topPubMeshTerms'], 0, 3 );
			$i = 1;
			foreach ( $arrTopPubMeshTerms as $individual_pubmeshterms ) {
				$arrTopics ['pub_mesh_terms'] [$i] ['name'] = $individual_pubmeshterms ['name'];
				$i ++;
			}
		}
		
		$arrGroup = array ();
		$arrGroup ['arrCarrier'] = $arrCarrier;
		$arrGroup ['arrTopics'] = $arrTopics;
		
		$structured_json_data = json_encode ( $arrGroup );
		
		// Store structured_json_data in database
		$update_profile_summary = $this->kol->updateKolProfileSummary ( $structured_json_data, $arrKolDetail ['id'] );
		if ($update_profile_summary == true) {
			return $structured_json_data;
		} else {
			return false;
		}
	}
	
	function display_profile_summary($details_json_format, $type = null) {
		
		$biographyTextDetails = json_decode($details_json_format, true);
		$html_container = '';
		if($biographyTextDetails['arrCarrier']['experience']>0){
    		if ($biographyTextDetails['arrCarrier']['experience']==1) {
    			$html_container .= '<li><span>' .$biographyTextDetails['arrCarrier']['experience']. " Year of experience</span></li>";
    		} else {
    			$html_container .= '<li><span>' .$biographyTextDetails['arrCarrier']['experience']. " Years of experience</span></li>";
    		}
		}
		if (count ( $biographyTextDetails ['arrCarrier'] ['education'] ) > 0) {
			foreach ( $biographyTextDetails ['arrCarrier'] ['education'] as $edu )
				$eduText .=  $edu  . ", ";
			$html_container .= "<li><span>Studied in " . trim ( $eduText, ' ,' ) . "</span></li>";
		}
		if ($biographyTextDetails ['arrCarrier'] ['affiliations'] ['affiliations_left'] > 0) {
			$html_container .= "<li><span>";
			$html_container .= $biographyTextDetails ['arrCarrier'] ['affiliations'] ['university_name'];
			if ($biographyTextDetails ['arrCarrier'] ['affiliations'] ['affiliations_left'] > 0) {
				$html_container .= " and ";
				$html_container .= $biographyTextDetails ['arrCarrier'] ['affiliations'] ['affiliations_left'];
				$html_container .= " other ";
				if ($biographyTextDetails ['arrCarrier'] ['affiliations'] ['affiliations_left'] > 1) {
					$html_container .= "affiliations";
				} else {
					$html_container .= "affiliation";
				}
			}
			$html_container .= "</span></li>";
		} else if ($biographyTextDetails ['arrCarrier'] ['affiliations'] ['university_name'] != '') {
			$html_container .= "<li><span>";
			$html_container .= "Affiliated with";
			$html_container .= $biographyTextDetails ['arrCarrier'] ['affiliations'] ['university_name'];
			$html_container .= "</span></li>";
		}
		if ($biographyTextDetails ['arrCarrier'] ['speaker_events'] ['count'] > 0) {
		    $html_container .= "<li><span>Speaker in ";
		    if ($biographyTextDetails ['arrCarrier'] ['speaker_events'] ['count'] > 1) {
		        $html_container .= $biographyTextDetails ['arrCarrier'] ['speaker_events'] ['count'] . " sessions";
		    } else {
		        $html_container .= $biographyTextDetails ['arrCarrier'] ['speaker_events'] ['count'] . " session";
		    }
		    $html_container .= " in ";
		    if ($biographyTextDetails ['arrCarrier'] ['speaker_events'] ['count'] > 1) {
		        $html_container .= "conferences";
		    } else {
		        $html_container .= "conference";
		    }
		    $html_container .= "</span></li>";
		}
		if ($biographyTextDetails ['arrCarrier'] ['publications'] ['count'] > 0) {
			$html_container .= "<li><span>";
			$html_container .= $biographyTextDetails ['arrCarrier'] ['publications'] ['count'];
			if ($biographyTextDetails ['arrCarrier'] ['publications'] ['count'] == 1) {
				$html_container .= " Publication";
			} else {
				$html_container .= " Publications";
			}
			if ($biographyTextDetails ['arrCarrier'] ['publications'] ['pub_auth_pos_count'] > 0) {
				if ($biographyTextDetails ['arrCarrier'] ['publications'] ['pub_auth_pos_count'] > 1) {
					$html_container .= " with " . $biographyTextDetails ['arrCarrier'] ['publications'] ['pub_auth_pos_count'] . " articles as lead author";
				} else {
					$html_container .= " with " . $biographyTextDetails ['arrCarrier'] ['publications'] ['pub_auth_pos_count'] . " article as lead author";
				}
			}
			$html_container .= "</span></li>";
		}
		if ($biographyTextDetails ['arrCarrier'] ['trails'] ['no_of_trails'] > 0) {
			$html_container .= "<li><span>Investigator in ";
			if ($biographyTextDetails ['arrCarrier'] ['trails'] ['no_of_trails'] > 1) {
				$html_container .= $biographyTextDetails ['arrCarrier'] ['trails'] ['no_of_trails'] . " clinical studies";
			} else {
				$html_container .= $biographyTextDetails ['arrCarrier'] ['trails'] ['no_of_trails'] . " clinical study";
			}
			$html_container .= "</span></li>";
		}
		if ($biographyTextDetails ['arrCarrier'] ['interactions'] ['interactions_by_users_count'] > 0) {
			$html_container .= "<li><span>";
			$html_container .= $biographyTextDetails ['arrCarrier'] ['interactions'] ['interactions_by_users_count'];
			if ($biographyTextDetails ['arrCarrier'] ['interactions'] ['interactions_by_users_count'] > 1) {
				$html_container .= " interactions";
			} else {
				$html_container .= " interaction";
			}
			$html_container .= " entered by ";
			$html_container .= $biographyTextDetails ['arrCarrier'] ['interactions'] ['interactions_count'];
			if ($biographyTextDetails ['arrCarrier'] ['interactions'] ['interactions_count'] > 1) {
				$html_container .= " employees ";
			} else {
				$html_container .= " employee ";
			}
			$html_container .= "in last 6 months</span></li>";
		}
		if (count ( $biographyTextDetails ['arrTopics'] ['topic'] ) > 0) {
			foreach ( $biographyTextDetails ['arrTopics'] ['topic'] as $event ) {
				$arrTopThreeEvents [] = $event ["name"];
			}
			if (count ( $arrTopThreeEvents ) > 0) {
				$html_container .= "<p><label><b>Top Event Topics : </b></label> <span>" . implode ( $arrTopThreeEvents, " | " ) . "</span></p>";
			}
		}
		if (count ( $biographyTextDetails ['arrTopics'] ['pub_mesh_terms'] ) > 0) {
			foreach ( $biographyTextDetails ['arrTopics'] ['pub_mesh_terms'] as $pubTerms ) {
				$arrTopThreePubTerms [] = $pubTerms ["name"];
			}
			if (count ( $arrTopThreePubTerms ) > 0) {
				$html_container .= "<p><label><b>Top Publication Topics : </b></label> <span>" . implode ( $arrTopThreePubTerms, " | " ) . "</span></p>";
			}
		}
		if ($type == 'excel') {
			$replace_list_tags = str_replace("</li>", "\r", $html_container);
			$replace_para_tags = str_replace("<p>", "\r", $replace_list_tags);
           		$add_pointer_list = str_replace("<li>", "&#8226; ", $replace_para_tags);
            		$str_decode_entity = html_entity_decode($add_pointer_list,ENT_QUOTES,'UTF-8');
            		$space_remover = str_replace("	", "", $str_decode_entity);
            		$prepared_str_excel = trim(strip_tags($space_remover));
            		return $prepared_str_excel;
		} else {
			return $html_container;
		}
	}
    function prepareProfileSummary($kol_id){
        $data=array();
        $data['exp']=$this->kol->profileSummary("Experience",$kol_id);
        $data['university']=$this->kol->profileSummary("University",$kol_id);
        $data['affiliation']=$this->kol->profileSummary("Affiliation",$kol_id);
        $data['speaker']=$this->kol->profileSummary("Speaker",$kol_id);
        $data['events']=$this->kol->profileSummary("Events",$kol_id);
        $arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($kol_id,$start,$end,0,0,0,0,$keyWord);
        $arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($kol_id,$start,$end,0,0,0,0,$keyWord);
        $arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($kol_id,$start,$end,0,0,0,0,$keyWord);
        $arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($kol_id,$start,$end,0,0,0,0,$keyWord);

        $arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
        $arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
        $arrLastAuthPubsCount		=	0;
        $arrMiddleAuthPubsCount		=	0;
		
        foreach($arrLastAuthPubs as $lastAuthPub){
                if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
                        $arrLastAuthPubsCount++;
        }
        $data['last_author_count']=$arrLastAuthPubsCount;
        $data['first_author_count']=$arrFirstAuthPubsCount;
       
        $arrPubYearRange = $this->pubmed->getKolPubsYearsRange($kol_id);
        $data['total_publications']=count($this->pubmed->searchPublicationsByParameters('','','','','',$kol_id,$arrPubYearRange['min_year'],$arrPubYearRange['max_year']));
        /* $arrMajorMeshterm     = $this->kol->getTopConceptDataForChart($kol_id, $arrPubYearRange['min_year'],$arrPubYearRange['max_year'],'','all');
        $topThreeConceptData = $this->prepareTopConcepts($arrMajorMeshterm,'','C');
        $data['top_mesh_terms'] = $topThreeConceptData['C']; */
      
        $data['interactionsCount'] = $this->interaction->getInteractionsCountByUsers($kol_id,true);
        $data['interactionsByUsersCount'] = $this->interaction->getInteractionsCountByUsers($kol_id);
        return $data;
    }
    
    /*
     * Display view page That contins Kols Biography and Education details
     * Display 'view_Biography' view page
     * @ACL-Alias View Biograpghy
     * @ACL-Discription Display view page That contins Kols Biography and Education details
     * @ACL-Category Kols
     * @ACL-SubApp client
     */

    function view_biography($kolId) {
        if (!$kolId) {
            return false;
        }
        // Getting the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $arrKolDetail['org_id'] = $this->kol->getOrgId($arrKolDetail['org_id']);
        $data['arrKol'] = $arrKolDetail;
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $arrStates = array();
        $arrCities = array();
        if ($arrKolDetail['country_id'] != 0) {
            $arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
        }
        if ($arrKolDetail['state_id'] != 0) {
            $arrCities = $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
        }
        $data['arrStates'] = $arrStates;
        $data['arrCities'] = $arrCities;
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['arrContactDetails'] = array();
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($this->session->userdata('kolId'))) {
            $data[] = $arrContactDetails;
        }
        //Get the count of "affilitions"
        $data['noOfAffilitions'] = array();
        ;
        $noOfAffilitions = $this->kol->countAfiliations($kolId);
        $data['noOfAffilitions'] = $noOfAffilitions;
        //Get the count of "Events"
        $data['noOfEvents'] = array();
        $noOfEvents = $this->kol->countEvents($kolId);
        $data['noOfEvents'] = $noOfEvents;
        //Get the count of "Publications"
        $data['noOfPublications'] = array();
        ;
        $noOfPublications = $this->kol->countPublications($kolId);
        $data['noOfPublications'] = $noOfPublications;
        //Get the count of "Trials"
        $data['noOfTrials'] = array();
        $noOfTrials = $this->kol->countTrials($kolId);
        $data['noOfTrials'] = $noOfTrials;
        $this->load->view('view_biography', $data);
    }

    /**
     * Display view page That contains KOL Affiliation Deatils
     * Display 'view_affiliations' view page
     * @ACL-Alias view Affiliations
     * @ACL-Discription Display view page That contains KOL Affiliation Deatils
     * @ACL-Category Affiliations
     * @ACL-SubApp client
     */
    function view_affiliations($kolId, $subContentPage = '') {
        // Getting the KOL details
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        $this->getKolProfileScore($kolId);
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['add_affiliation'] = $this->common_helpers->isActionAllowed('affiliation', 'add', $data['assignedUsers']);
//		pr($data['add_affiliation']);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['contentPage'] = 'view_affiliations';
        $data['subContentPage'] = $subContentPage;
        $data['data']['rightSideContentPage'] = 'right_sidebar/kol_affiliations';
        $data['data']['rightSideContentPageData'] = array('kolId' => $kolId);
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Display view page That contains KOL Event Deatils
     * Display 'view_events' view page
     * @ACL-Alias View Events
     * @ACL-Discription Display view page That contains KOL Event Deatils
     * @ACL-Category Events
     * @ACL-SubApp client
     */
    function view_events($kolId, $subContentPage = '') {
        // Getting the KOL details
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $arrYearRange = $this->kol->getEventsYearsRange($kolId);
        if ($arrYearRange['max_year'] == '')
            $arrYearRange['max_year'] = date("Y");
        if ($arrYearRange['min_year'] == '')
            $arrYearRange['min_year'] = (int) $arrYearRange['max_year'] - 35;
        $data['arrYearRange'] = $arrYearRange;
        $data['add_event'] = $this->common_helpers->isActionAllowed('event', 'add', $data);
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['contentPage'] = 'view_events';
        $data['subContentPage'] = $subContentPage;
        $data['data']['rightSideContentPage'] = 'right_sidebar/kol_events';
        $data['data']['rightSideContentPageData'] = array('arrYearRange' => $data['arrYearRange'], 'kolId' => $kolId);
        $this->load->view('layouts/client_view', $data);
    }

    /*
     * Display 'list_publications_client_view' view page
     * @ACL-Alias View Publications
     * @ACL-Discription Display view page That contains KOL Publication Deatils
     * @ACL-Category Publicatins
     * @ACL-SubApp client
     */

    function view_publications($kolId, $subContentPage = '') {
        if (!$kolId) {
            return false;
        }
        // Getting the KOL details
         $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['arrYearRange'] = $arrYears = $this->pubmed->getKolPubsYearsRange($kolId);
        $data['add_publication'] = $this->common_helpers->isActionAllowed('publication', 'add', $data);
        
        //Get KOL modified on date
        $data['kolModifiedDateTime'] = $this->kol->getKolModifiedDate($kolId);
       
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['contentPage'] = 'publications/list_publications_client_view';
        $data['subContentPage'] = $subContentPage;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['data']['rightSideContentPage'] = 'right_sidebar/kol_publications';
        $data['data']['rightSideContentPageData'] = array('arrYearRange' => $data['arrYearRange'], 'kolId' => $kolId);
        $this->load->view('layouts/client_view', $data);
    }

    /*
     * Display view page That contains KOL Clinical Deatils
     * @ACL-Alias View Clinical Trials
     * @ACL-Discription Display view page That contains KOL Clinical Deatils
     * @ACL-Category Clinical Trials
     * @ACL-SubApp client
     */

    function view_clinical_trials($kolId, $subContentPage = '') {
        if (!$kolId) {
            return false;
        }
        // Getting the KOL details
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        $data['add_trial'] = $this->common_helpers->isActionAllowed('trial', 'add', $data);
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        
        //Get KOL modified on date
        $data['kolModifiedDateTime'] = $this->kol->getKolModifiedDate($kolId);
        
        $data['subContentPage'] = $subContentPage;
        $data['contentPage'] = 'clinicals/list_clinical_trials_client_view';
        $data['data']['rightSideContentPage'] = 'right_sidebar/kol_trials';
        $data['data']['rightSideContentPageData'] = array('kolId' => $kolId);
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Generate Excel report for Multiple kol Id's
     * @ACL-Alias Multi Excel Export
     * @ACL-Discription Generate Excel report for Multiple kol Id's
     * @ACL-Category Kols
     * @ACL-SubApp client
     */
    function export_excel_multiple() {
        $kolsId = array();
        $kolsId = $this->input->post('exportId');
        $this->export_excel($kolsId);
    }

    /**
     * Generate Excel report for Multiple kol Id's
     * @ACL-Alias Single Excel Export
     * @ACL-Discription Generate Excel report for Multiple kol Id's
     * @ACL-Category Kols
     * @ACL-SubApp client
     */
    function export_excel_single($kolId) {
        $kolsId = array();
        $kolsId[0] = $kolId;
        $this->export_excel($kolsId);
    }

    /**
     * Retrives the data for passed Kol ID's and returns
     * those kol's data to the Excel sheet
     *
     * @param $kolsId
     * @return unknown_type
     */
    function export_excel($kolsId = array()) {
        $this->load->plugin('phpxls/writer');
        $dataResult = array();
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $dataContent['arrSpecialties'] = $arrSpecialties;
        foreach ($kolsId as $id) {
            $kolId = $id;
            //Get the details for overview  //Get the details for Social Media
            $arrKolDetails = $this->kol->getKolDetailsById($kolId);
            $data['arrKol'] = $arrKolDetails;
            // Get the list of Addtional Contact details of specified KolId
            $arrContactDetailsValue = array();
            if ($arrContactDetailsResult = $this->kol->listContacts($kolId)) {
                foreach ($arrContactDetailsResult as $arrContactDetails) {
                    $email = '';
                    $relatedTo = '';
                    if ($arrContactDetails['email'] != '') {
                        $email = "-" . $arrContactDetails['email'];
                    }
                    if ($arrContactDetails['related_to'] != '') {
                        $relatedTo = "(" . $arrContactDetails['related_to'] . ")";
                    }
                    $arrContactDetailsValue[] = $arrContactDetails['phone'] . $email . $relatedTo;
                }
                $data['arrAdditionalContact'] = $arrContactDetailsValue;
            }
            //Get the details for Education
            $arrEducationDetails = $this->kol->getEducationDetailById($kolId);
            $data['arrEducation'] = $arrEducationDetails;
            //Get the details for Affiliation
            $arrMembershipDetails = $this->kol->listAllMembershipsDetails($kolId);
            if ($arrMembershipDetails == false) {
                $arrMembershipDetails = array();
            }
            $data['arrMembership'] = $arrMembershipDetails;
            //Get the details for Events
            $arrEventsDetails = $this->kol->listAllEvents($kolId);
            $data['arrEvent'] = $arrEventsDetails;
            //Get the details for Pubmed
            $arrPublications = array();
            if ($arrPublicationsResults = $this->pubmed->listPublicationDetails($kolId)) {
                foreach ($arrPublicationsResults as $arrPublicationsResult) {
                    $arrPublication['id'] = $arrPublicationsResult['id'];
                    $arrPublication['pmid'] = $arrPublicationsResult['pmid'];
                    $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                    $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                    $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                    $arrPublication['date'] = $this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
                    $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                    $arrPublication['auth_pos'] = $arrPublicationsResult['auth_pos'];
                    //$arrPublication['auth_pos']=$this->pubmed->getAuthPosForPublication($arrPublicationsResult['journal_id']);
                    $arrPublication['kol_id'] = $kolId;
                    $arrPublications[] = $arrPublication;
                }
            }
            $data['arrPublication'] = $arrPublications;
            //Get the details for Clinical Trials
            $arrClinicalTrials = array();
            if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolId)) {
                foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                    $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                    $arrClinicalTrial['ct_id'] = $arrClinicalTrialsResult['ct_id'];
                    $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                    $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                    $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                    $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                    $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                    $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                    $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                    $arrClinicalTrial['kol_id'] = $kolId;
                    $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                    $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                    $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                    $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                    $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                    $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                    $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                    $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                    $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                    $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                    $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                    $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                    $arrKeywordsData = '';
                    $separator = '';
                    foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                        $arrKeywordsData .= $separator . $row['name'];
                        $separator = ',';
                    }
                    $arrClinicalTrial['keywords'] = $arrKeywordsData;
                    $arrMeshtermsData = '';
                    $separator = '';
                    foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                        $arrMeshtermsData .= $separator . $row['term_name'];
                        $separator = ',';
                    }
                    $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                    $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                    $arrClinicalTrials[] = $arrClinicalTrial;
                }
            }
            $data['arrClinicalTrial'] = $arrClinicalTrials;
            $dataResult[] = $data;
        }
        $dataContent['dataSet'] = $dataResult;
        $dataContent['contentPage'] = 'kols/export/kol_excel';
        $this->load->view('layouts/export_xls.php', $dataContent);
    }

    function get_pub_authors($pubId) {
        $authNames = '';
        $arrAuthors = $this->pubmed->listPublicationAuthors($pubId);
        foreach ($arrAuthors as $author) {
            $authName = $author['last_name'] . " " . $author['initials'];
            if ($authNames == '') {
                $authNames = $authName;
            } else {
                $authNames = $authNames . "," . $authName;
            }
        }
        return $authNames;
    }

    function get_sponsers($ctId) {
        $sponsersNames = '';
        $arrSponsers = $this->clinical_trial->listCTSponsors($ctId);
        foreach ($arrSponsers as $sponser) {
            $sponserName = $sponser['agency'];
            if ($sponsersNames == '') {
                $sponsersNames = $sponserName;
            } else {
                $sponsersNames = $sponsersNames . ";" . $sponserName;
            }
        }
        return $sponsersNames;
    }

    function get_interventions($ctId) {
        $interventionsNames = '';
        $arrInterventions = $this->clinical_trial->listCTInterventions($ctId);
        foreach ($arrInterventions as $intervention) {
            $interventionName = $intervention['name'];
            if ($interventionsNames == '') {
                $interventionsNames = $interventionName;
            } else {
                $interventionsNames = $interventionsNames . ";" . $interventionName;
            }
        }
        return $interventionsNames;
    }

    function get_investigators($ctId) {
        $investigatorsNames = '';
        $arrInvestigators = $this->clinical_trial->listCTInvestigators($ctId);
        foreach ($arrInvestigators as $investigator) {
            $investigatorName = $investigator['last_name'];
            if ($investigatorsNames == '') {
                $investigatorsNames = $investigatorName;
            } else {
                $investigatorsNames = $investigatorsNames . ";" . $investigatorName;
            }
        }
        return $investigatorsNames;
    }

    /**
     * Export pdf
     * Generate Excel Pdf for Kol
     * @ACL-Alias Export pdf
     * @ACL-Discription Generate Excel Pdf for Kol
     * @ACL-Category Kols
     * @ACL-SubApp client
     */
    function export_pdf($kolId) {
        ini_set('memory_limit', "800M");
        $this->load->plugin('export_pdf');
        $arrhtml = $this->get_mini_profile_as_html($kolId, 'Pdf');
        $html = $arrhtml[0];
        $filename = $arrhtml[1];
        pdf_create($html, $filename);
    }

    /**
     * returns the simple search results for kol, matching the keyword with name(first, middle and last)
     *
     * @ACL1-Alias Simple Search
     * @ACL1-Discription returns the simple search results for kol, matching the keyword with name(first, middle and last)
     * @ACL1-Category Search
     * @ACL1-SubApp client
     */
    function search_kols() {
//         $arrFilterById = $this->kol->getFilterByRecentApplied();
        $arrFilterById = false;
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        //		$arrFilterFields									= array();
        $arrFilterFields = ($arrFilterById['arrFilterFields']) ? $arrFilterById['arrFilterFields'] : array();
        //		pr($arrFilterFields);
        $category = $this->input->post('category');
        $keyword = trim($this->input->post('keyword'));
        $keywordSearchBy = trim($this->input->post('keywordSearchBy'));
        $this->session->set_userdata('keywordSearchByAutoComplete', $keywordSearchBy);
        if ($keywordSearchBy) {
            //echo base_url().'kols/view/'.$this->kol->getKolId(str_replace(' ','',$keyword));
            $kolId = $this->input->post('kolIdTop');

            redirect(base_url() . 'kols/view/' . $kolId);
        }
        $isRequestFromSearch = true;
        $arrKolsByCountryCount = array();
        $arrKolsByStateCount = array();
        $arrKolsBySpecialtyCount = array();
        $arrKolsByOrgCount = array();
        $arrKolsByEduCount = array();
        $arrKolsByEventCount = array();
        $arrKolsByListCount = array();
        $arrKols = array();
        //if this function is called from 'list_kols_client_view' as list of kols is same as search kols by 'blank' search string
        if ($category == null) {
            $category = 'people';
            $keyword = '';
            $isRequestFromSearch = false;
        }
        $doAnd = false;
        $splitDone = false;
        //Split the keyword by 'comma' or '+' or 'space'
        $arrKeywords = explode("+", $keyword);
        // Do And operation if Words are separated by '+' else do or operation
        if (sizeof($arrKeywords) > 1) {
            $doAnd = true;
        } else if (!$doAnd) {
            $arrKeywords = explode(",", $keyword);
            if (sizeof($arrKeywords) > 1) {
                $splitDone = true;
            }
        }
        if (!$doAnd && !$splitDone)
            $arrKeywords = explode(" ", $keyword);
        //		$arrFilterFields['viewType'] = 1;// My contacts = 1 and all contacts = 2
        $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
        if (sizeof($viewMyKols) > 0) {
            $viewTypeMyKols = MY_RECORDS;
            $arrFilterFields['viewType'] = $viewMyKols;
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        if ($doAnd) {
            $arrKols = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false);
            $count = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, true);
            //Get count of kols grouping by category(for each category)
            if ($isRequestFromSearch) {
                $arrKolsByCountryCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByCityCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type');
            }
        } else {
            $arrKols = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false);
            //$count = sizeof($arrKols);
            $count = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, true);
            //Get count of kols grouping by category(for each category)
            if ($isRequestFromSearch) {
                $arrKolsByCountryCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type');
            }
        }
        //Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
        $this->session->set_userdata('keyword', $keyword);
        unset($arrFilterFields['viewType']);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');

        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country']] = $row;
            $allCountryCount += $row['count'];
        }
        $allStateCount = 0;
        $assoArrKolsByStateCount = array();
        foreach ($arrKolsByStateCount as $row) {
            $assoArrKolsByStateCount[$row['state']] = $row;
            $allStateCount += $row['count'];
        }
    	$allCityCount = 0;
        $assoArrKolsByCiytCount = array();
        foreach ($arrKolsByCityCount as $row) {
            $assoArrKolsByCityCount[$row['city']] = $row;
            $allCityCount += $row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specs']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['org_id']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_name']] = $row;
            $allEduCount += $row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_name']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }

        // Preparing to display filter message
        $arrFiltersApplied = array();
        if (is_array($arrKolIds)) {
            if ((sizeof(array_filter($arrKolIds))) > 0)
                $arrFiltersApplied['kols'] = 'KOL Name';
        }
          $allOrgTypeCount=0;
        $assoArrOrgByTypeCount=array();
        foreach($arrOrgByTypeCount as $row){
                $assoArrOrgByTypeCount[$row['org_type_id']]=$row;
                $allOrgTypeCount+=$row['count'];
        }
        //		pr($arrFilterFields);
        $arrFilterFields['view_type'] = array($viewTypeMyKols);
        $arrFilterFields['profile_type'] = array($arrFilterFields['profile_type']);
        if (!empty($arrFilterFields)) {
            foreach ($arrFilterFields as $section => $arrValues) {
                if ((sizeof(array_filter($arrValues))) > 0) {
                    $separator = ' | ';
                    switch ($section) {
                        case 'specialty': $arrSelectedSpecialties = $this->Specialty->getSpecialtiesById($arrValues);
                            $arrFiltersApplied['specialty'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedSpecialties) . '">Specialty</a>';
                            break;
                        case 'country': $arrSelectedCountries = $this->Country_helper->getCountryNameById($arrValues);
                            $arrFiltersApplied['country'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCountries) . '">Country</a>';
                            break;
                        case 'state':
                            $arrSelectedStates = $this->Country_helper->getStateNameById($arrValues);
                            $arrFiltersApplied['state'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedStates) . '">State</a>';
                            break;
                        case 'city':
                            $arrSelectedCities = $this->Country_helper->getCityNameById($arrValues);
                            $arrFiltersApplied['city'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCities) . '">City</a>';
                            break;   
                        case 'organization':
                            $arrSelectedOrgs = $this->organization->getOrgsById($arrValues);
                            $arrFiltersApplied['organization'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOrgs) . '">Organization</a>';
                            break;
                        case 'education': $arrSelectedEducations = $this->kol->getInstituteNameById($arrValues);
                            $arrFiltersApplied['education'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEducations) . '">Education</a>';
                            break;
                        case 'event_id': $arrSelectedEvents = $this->kol->getEventNameById($arrValues);
                            $arrFiltersApplied['event'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEvents) . '">Event</a>';
                            break;
                        case 'kol_id': $arrKolName = $this->kol->getKolNameByIdFilterLabel($arrValues);
                            $arrFiltersApplied['kol_id'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $arrKolName . '">KOL name</a>';
                            break;
                        case 'list_id':
                            $listNames = array();
                            foreach ($arrValues as $key => $value) {
                                $row = $this->My_list_kol->editListName($value);
                                $listNames[] = $row['list_name'];
                            }
                            $arrFiltersApplied['list'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $listNames) . '">List</a>';
                            break;
                        case 'profile_type':
                            $arrFiltersApplied['profile_type'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $arrValues[0] . '">Profile Type</a>';
                            break;
                        case 'view_type':
                            if ($arrValues[0] == 1)
                                $viewTypeString = "My Contacts";
                            else
                                $viewTypeString = "All Contacts";
                            $arrFiltersApplied['viewType'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $viewTypeString . '">View Type</a>';
                            break;
                    }
                }
            }
        }
        //		pr($arrFiltersApplied);
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allCityCount'] = $allCityCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allListCount'] = $allListCount;
         $filterData['allOrgTypeCount']		=	$allOrgTypeCount;
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsByStateCount'] = $assoArrKolsByStateCount;
        $filterData['arrKolsByCityCount'] = $assoArrKolsByCityCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['arrOrgByTypeCount']	=	$arrOrgByTypeCount;
        $filterData['keyword'] = $keyword;
        $filterData['arrAdvSearchFields'] = "";
        $filterData['arrFilterFields'] = "";
        $filterData['searchType'] = "simple";
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['searchType'] = "simple";
        $kolResultsData['profileType'] = ($arrFilterById['arrFilterFields']['profile_type']) ? $arrFilterById['arrFilterFields']['profile_type'] : '';
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $this->load->model('user_setting');
        $userId = $this->loggedUserId;
        $filterData = $this->user_setting->getDataFromAppSettings($userId,'kols_list_view');
        if($filterData > 0){
        	$data['listView'] = $filterData;
        }else{
        	$data['listView'] = 1;
        }
        if ($isRequestFromSearch) {
            $details['kolResultsPage'] = 'search/kol_search_results';
            $details['filterPage'] = 'search/kol_filters_li_style';
        } else {
            if (isset($arrFilterById['id']) && $arrFilterById['id'] != '') {
                $details['savedFilterName'] = $arrFilterById['name'];
                $details['savedQueryFilterApplied'] = implode(', ', $arrFiltersApplied);
            } else if ($viewTypeMyKols != '') {
                $details['savedQueryFilterApplied'] = implode(', ', $arrFiltersApplied);
            }
            $details['filterPage'] = 'search/kol_filters_li_style';
            $details['kolResultsPage'] = 'search/my_kol_results';
        }
        $details['add_KOL'] = $this->common_helpers->isActionAllowed('kol', 'add', $kolResultsData);
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        if ($isRequestFromSearch) {
            $data['contentPage'] = 'search/kol_results';
        } else
            $data['contentPage'] = 'kols/list_kols_client_view';
        $data['mapSection'] = '';
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Display view page that contains Form Fields for Advance Search
     *
     * @ACL1-Alias Advance Search
     * @ACL1-Discription returns the Advance search results for kol, matching the keyword with name(first, middle and last)
     * @ACL1-Category Advance Search
     * @ACL1-SubApp client
     */
    function view_kol_adv_search() {
        $data['contentPage'] = 'search/kol_adv_search';
        $this->load->view('search/kol_adv_search');
    }

    function adv_search_kols() {
        $arrFilterFields = array();
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrKolsByCountryCount = array();
        $arrKolsBySpecialtyCount = array();
        $arrKolsByOrgCount = array();
        $arrKolsByEduCount = array();
        $arrKolsByEventCount = array();
        $arrKolsByListCount = array();
        $keywords = trim($this->input->post('keywords'));
        $firstName = trim($this->input->post('first_name'));
        $middleName = trim($this->input->post('middle_name'));
        $lastName = trim($this->input->post('last_name'));
        $specialty = trim($this->input->post('specialty'));
        $subSpecialty = trim($this->input->post('sub_specialty '));
        $country = trim($this->input->post('country'));
        $organization = trim($this->input->post('organization'));
        $title = trim($this->input->post('title'));
        $postalCode = trim($this->input->post('postal_code'));
        $arrAdvSearchFields['keywords'] = $keywords;
        $arrAdvSearchFields['first_name'] = $firstName;
        $arrAdvSearchFields['middle_name'] = $middleName;
        $arrAdvSearchFields['last_name'] = $lastName;
        $arrAdvSearchFields['sub_specialty'] = $subSpecialty;
        $arrAdvSearchFields['title'] = $title;
        $arrAdvSearchFields['postal_code'] = $postalCode;
        if ($specialty != '')
            $arrAdvSearchFields['specialty'][] = ucwords(trim($specialty));
        if ($country != '')
            $arrAdvSearchFields['country'][] = ucwords(trim($country));
        if ($organization != '')
            $arrAdvSearchFields['organization'][] = ucwords(trim($organization));

        $arrKols = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //Get count of kols grouping by category(for each category)
        $arrKolsByCountryCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'country');
        $arrKolsBySpecialtyCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
        $arrKolsByOrgCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
        $arrKolsByEduCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'education');
        $arrKolsByEventCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'event');
        $arrKolsByListCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'list');

        $advSearchSessData = array('keywords', 'arrFilterFields', 'arrAdvSearchFields');

        $this->session->unset_userdata($advSearchSessData);
        $this->session->set_userdata('keywords', $keywords);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        $this->session->set_userdata('arrAdvSearchFields', $arrAdvSearchFields);
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country']] = $row;
            $allCountryCount += $row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specs']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['name']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_name']] = $row;
            $allEduCount += $row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_name']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }
        $arrCountries = array();
        $arrSpecialties = array();
        $arrOrganizations = array();
        if (isset($arrAdvSearchFields['country']))
            $arrCountries = $arrAdvSearchFields['country'];
        if (isset($arrAdvSearchFields['specialty']))
            $arrSpecialties = $arrAdvSearchFields['specialty'];
        if (isset($arrAdvSearchFields['organization']))
            $arrOrganizations = $arrAdvSearchFields['organization'];
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allListCount'] = $allListCount;
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['selectedCountries'] = $arrCountries;
        $filterData['selectedSpecialties'] = $arrSpecialties;
        $filterData['selectedOrgs'] = $arrOrganizations;
        $filterData['keyword'] = "";
        $filterData['searchType'] = "advanced";
        $filterData['arrFilterFields'] = "";
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['searchType'] = "simple";
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFields);
        $details['kolResultsPage'] = 'search/kol_search_results';
        $details['filterPage'] = 'search/kol_filters_li_style';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        $data['mapSection'] = '';
        $this->load->view('layouts/client_view', $data);
    }

    function filter_search_kols() {
        ini_set("max_execution_time", 7200);
        ini_set('memory_limit', '-1');
        $arrKolIds = array();
        $arrFilterFields = array();
        $arrQueryOptions['sort_by'] = 'name';
        $arrQueryOptions['sort_order'] = 'asc';
        $page = $this->input->post('page');
        $myKols = $this->input->post('my_kols');
        $viewTypeMyKols = $this->input->post('viewTypeMyKols');
        $count = 0;
        $viewType = $this->uri->segment(3);
        $noOfRecordsPerPage = $this->uri->segment(4);
        $orgType 	= trim($this->input->post('org_type_id'));
                if($orgType=="Enter Org Type"){
				$orgType	= '';
                }
        $kolType 	= trim($this->input->post('kol_type_id'));
        if($kolType=="Enter Kol Title"){
                        $kolType	= '';
        }
        $regionType 	= trim($this->input->post('region_type_id'));
        if($regionType=="Enter Global Region"){
                        $regionType	= '';
        }
        if ($viewType == 'list') {
            $arrQueryOptions['sort_by'] = $this->input->post('sort_by');
            $arrQueryOptions['sort_order'] = $this->input->post('sort_order');
            if ($noOfRecordsPerPage == '') {
                $noOfRecordsPerPage = 10;
            }
        }
        if ($noOfRecordsPerPage == '' && ($viewType == 'main' || $viewType == '')) {
            $noOfRecordsPerPage = 10;
        }

        if ($this->input->post('savedFilterId') != 0) {
            $myKols = true;
        }

        $this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $searchType = '';
        $keyword = '';
        //Check whether the request is for selecting all the page results
        $kolsCount = $this->input->post('kols_count');
        if (isset($kolsCount) && $kolsCount != null) {
            $limit = $kolsCount;
            $startFrom = 0;
        }
        $arrCountries = array();
        /* 		if((int)$page>-1){
          //if the request is for the next page result then get the already saved search and filter fields from session
          $keyword								= trim($this->session->userdata('keyword'));
          $arrFilterFields						= $this->session->userdata('arrFilterFields');
          }
          else{
         */
        $searchType = $this->input->post('search_type');
        $keyword = trim($this->input->post('keyword'));
        //get the values entered in the input fields
        $profileType = trim($this->input->post('profile_type'));
        $specialty = trim($this->input->post('specialty_id'));
        $country = trim($this->input->post('country_id'));
        $state = trim($this->input->post('state_id'));
        $city = trim($this->input->post('city_id'));
        $organization = trim($this->input->post('organization_id'));
        $education = trim($this->input->post('education_id'));
        $eventName = trim($this->input->post('event_name_id'));
        $listName = trim($this->input->post('list_name_id'));
        $kolId = $this->common_helpers->getKolidOrUniqueId($this->input->post('kol_id'));
        //$kolName = trim($this->input->post('kol_id'));
        $kolName = $kolId;
        //$kolName								= trim($this->input->post('kol_name'));
        if ($this->input->post('savedFilterId') != 0) {
            $searchType = "simple";
        }
        if ($specialty == "Enter Specialty") {
            $specialty = '';
        }
        if ($country == "Enter Country") {
            $country = '';
        }
        if ($state == "Enter State") {
            $state = '';
        }
    	if ($city == "Enter City") {
            $city = '';
        }
        if ($education == "Enter Education") {
            $education = '';
        }
        if ($eventName == "Enter Event") {
            $eventName = '';
        }
        if ($listName == "Enter List") {
            $listName = '';
        }
        if ($organization == "Enter Organization") {
            $organization = '';
        }
        if ($kolName == "Enter ". lang('HCP'). " Name"|| $kolName == '') {
            $kolName = '';
        }
        //Get all the selected checkboxs details for respective category
        $arrCountries = $this->input->post('countries');
        if ($arrCountries != '')
            $arrCountries = explode(",", $arrCountries);
        //if the input field is not blank add the value in to respective category array values
        if ($country != '')
            $arrCountries[] = $country;
        $arrStates = $this->input->post('states');
        if ($arrStates != '')
            $arrStates = explode(",", $arrStates);
        $arrCities = $this->input->post('cities');
        if ($arrCities != '')
            $arrCities = explode(",", $arrCities);
        //if the input field is not blank add the value in to respective category array values
        if ($state != '')
            $arrStates[] = $state;
        if ($city != '')
            $arrCities[] = $city;
        $arrSpecialties = $this->input->post('specialties');
        if ($arrSpecialties != '')
            $arrSpecialties = explode(",", $arrSpecialties);
        if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations[] = $organization;
        }
        $arrOrgTypes	=	$this->input->post('org_types');
			if($arrOrgTypes!='')
				$arrOrgTypes	=explode(",",$arrOrgTypes);
			if($orgType!=''){
				$arrOrgTypes[]	=	$orgType;
			}
        $arrRegionTypes	=	$this->input->post('region_types');
       if($arrRegionTypes!='')
               $arrRegionTypes	=explode(",",$arrRegionTypes);
       if($regionType!=''){
               $arrRegionTypes[]	=	$regionType;
       }
        $arrKolTypes	=	$this->input->post('kol_types');
       if($arrKolTypes!='')
               $arrKolTypes	=explode(",",$arrKolTypes);
       if($kolType!=''){
               $arrKolTypes[]	=	$kolType;
       }
       if(KOL_CONSENT){
           $arrOptInOut = $this->input->post('opt_in_out_types');
           if ($arrOptInOut != '')
           $arrOptInOut = explode(",", $arrOptInOut);
       }
        /* 	$arrOrganizations						= array();
          foreach($arrOrganizations1 as $key => $orgId){
          $arrOrganizations[$orgId]			= $this->organization->getOrgNameByOrgId($orgId);
          }
         */
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        $arrKolNames = array();
        $kolNames = $this->input->post('kols');
        if ($kolNames != '') {
            $arrKolNames1 = explode(",", $kolNames);
            foreach ($arrKolNames1 as $key => $value) {
                $arrKolNames[] = $this->kol->getKolId($value);
            }
        }
        if ($kolName != '') {
            $arrKolNames[] = $kolName;
        }
        if ($arrKolNames != '' && $arrKolNames != 0) {
            foreach ($arrKolNames as $kolName) {
                //	$kolName						= str_replace(' ','',$kolName);
                $arrKolIds[] = $kolName;
            }
        } else {
            $arrKolIds = '';
        }
        //Prepare array of filter fields, ehich will be used for querying
        $arrFilterFields['view_type'] = array($viewTypeMyKols);
        $arrFilterFields['profile_type'] = array($profileType);
        $arrFilterFields['specialty'] = $arrSpecialties;
        $arrFilterFields['country'] = $arrCountries;
        $arrFilterFields['state'] = $arrStates;
        $arrFilterFields['type'] = $arrOrgTypes;
        $arrFilterFields['region'] = $arrRegionTypes;
        $arrFilterFields['title'] = $arrKolTypes;
       
        $arrFilterFields['city'] = $arrCities;
        $arrFilterFields['organization'] = $arrOrganizations;
        $arrFilterFields['education'] = $arrEducations;
        $arrFilterFields['event_id'] = $arrEvents;
        $arrFilterFields['list_id'] = $arrLists;
        $arrFilterFields['event_name'] = $eventName;
        if(KOL_CONSENT){
            $arrFilterFields['opt_inout'] = $arrOptInOut;
        }
        //pr($arrFilterFields);exit;
        $arrFiltersApplied = array();
        if (is_array($arrKolIds)) {
            if ((sizeof(array_filter($arrKolIds))) > 0)
                $arrFiltersApplied['kols'] = 'KTL Name';
        }
        foreach ($arrFilterFields as $section => $arrValues) {
            if ((sizeof(array_filter($arrValues))) > 0) {
                $separator = ' | ';
                switch ($section) {
                    case 'specialty': $arrSelectedSpecialties = $this->Specialty->getSpecialtiesById($arrValues);
                        $arrFiltersApplied['specialty'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedSpecialties) . '">Specialty</a>';
                        break;
                    case 'country': $arrSelectedCountries = $this->Country_helper->getCountryNameById($arrValues);
                        $arrFiltersApplied['country'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCountries) . '">Country</a>';
                        break;
                    case 'region': $arrSelectedRegion = $arrRegionTypes;
                        $arrFiltersApplied['region'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedRegion) . '">Region</a>';
                        break;
                    case 'state':
                        $arrSelectedStates = $this->Country_helper->getStateNameById($arrValues);
                        $arrFiltersApplied['state'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedStates) . '">State</a>';
                        break;
                    case 'city':
                        $arrSelectedCities = $this->Country_helper->getCityNameById($arrValues);
                        $arrFiltersApplied['city'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCities) . '">City</a>';
                        break;
                    case 'type':
                        $arrSelectedOrgs = $this->organization->getOrgTypeById($arrValues);
                        $arrFiltersApplied['type'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOrgs) . '">Org Type</a>';
                        break;
                    case 'organization':
                        $arrSelectedOrgs = $this->organization->getOrgsById($arrValues);
                        $arrFiltersApplied['organization'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOrgs) . '">Organization</a>';
                        break;
                    case 'education': $arrSelectedEducations = $this->kol->getInstituteNameById($arrValues);
                        $arrFiltersApplied['education'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEducations) . '">Education</a>';
                        break;
                    case 'event_id': $arrSelectedEvents = $this->kol->getEventNameById($arrValues);
                        $arrFiltersApplied['event'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEvents) . '">Event</a>';
                        break;
                    case 'kol_id': $arrKolName = $this->kol->getKolNameById($arrValues);
                        $arrFiltersApplied['kol_id'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $arrKolName . '">KOL name</a>';
                        break;
                    case 'title': $arrKolTitles = implode($separator, $arrValues);
                        $arrFiltersApplied['kol_id'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' .$arrKolTitles . '">Position</a>';
                        break;
                    case 'list_id':
                        $listNames = array();
                        foreach ($arrValues as $key => $value) {
                            $row = $this->My_list_kol->editListName($value);
                            $listNames[] = $row['list_name'];
                        }
                        $arrFiltersApplied['list'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $listNames) . '">List</a>';
                        break;
                    case 'profile_type':
                        $arrFiltersApplied['profile_type'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $profileType . '">Profile Type</a>';
                        break;
                    case 'opt_inout':
                        $arrSelectedOpt = $this->kol->getOptNameById($arrValues);
                        $arrFiltersApplied['opt_inout'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOpt) . '">Opt-in/Opt-out</a>';
                        break;
                    case 'view_type':
                        if ($arrValues[0] == 1)
                            $viewTypeString = "My Contacts";
                        else
                            $viewTypeString = "All Contacts";
                        $arrFiltersApplied['viewType'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $viewTypeString . '">View Type</a>';
                        break;
                }
            }
        }
        //	}
        $doAnd = false;
        $splitDone = false;
        //Split the keyword by 'comma' or '+' or 'space'
        $arrKeywords = explode("+", $keyword);
        if (sizeof($arrKeywords) > 1) {
            $doAnd = true;
        } else if (!$doAnd) {
            $arrKeywords = explode(",", $keyword);
            if (sizeof($arrKeywords) > 1) {
                $splitDone = true;
            }
        }
        if (!$doAnd && !$splitDone)
            $arrKeywords = explode(" ", $keyword);
        $arrKols = array();
        $arrFilterFields['profile_type'] = $profileType;
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $arrFilterFields['viewType'] = $viewMyKols;
            } else {
                $arrFilterFields['viewType'] = array(0);
            }
        }
        if ($doAnd) {
            $arrKols = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, false, null, $arrQueryOptions);
            $count = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, true);     		
        } else {
            $arrKols = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, false, false, $arrKolIds, false, $arrQueryOptions);
            $count = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, true, false, false, $arrKolIds);
			//$count = sizeof($arrKols);
        }        
        //if request is for all page results id, then just rerutn the kols ids as json data
        if (isset($kolsCount) && $kolsCount != null) {
            $arrIds = array();
            foreach ($arrKols as $row)
                $arrIds[] = (int) $row['id'];
            echo json_encode($arrIds);
            return;
        }
        $this->session->set_userdata('keyword', $keyword);
        unset($arrFilterFields['viewType']);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $filterData['keyword'] = $keyword;
        $filterData['arrAdvSearchFields'] = "";
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['searchType'] = $searchType;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['searchType'] = "simple";
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $details['filterPage'] = 'search/kol_filters';
        if (!empty($myKols))
            $details['kolResultsPage'] = 'search/my_kol_results';
        else
            $details['kolResultsPage'] = 'search/kol_search_results';
        $kolResultsData['arrSortBy'] = $arrQueryOptions;
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        if (sizeof($viewMyKols) < 1 && $viewTypeMyKols == MY_RECORDS) {
            $kolResultsData['savedQueryFilterApplied'] = implode(', ', $arrFiltersApplied);
        } else {
            $kolResultsData['filtersApplied'] = implode(', ', $arrFiltersApplied);
        }
        //echo json_encode($data);
        if (!empty($myKols))
            $this->load->view('search/my_kol_results', $kolResultsData);
        else
            $this->load->view('search/kol_search_results', $kolResultsData);
    }

    function filter_adv_search_kols() {
        $page = $this->input->post('page');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $arrFilterFields = array();
        $searchType = '';
        $keyword = '';
        //Check whether the request is for selecting all the page results
        $kolsCount = $this->input->post('kols_count');
        if (isset($kolsCount) && $kolsCount != null) {
            $limit = $kolsCount;
            $startFrom = 0;
        }
        /* 		if($page>=0){
          $keywords							= $this->session->userdata('keywords');
          $arrFilterFields					= $this->session->userdata('arrFilterFields');
          $arrAdvSearchFields					= $this->session->userdata('arrAdvSearchFields');
          }
          else{
         */ $searchType = trim($this->input->post('search_type'));
        $orgType = trim($this->input->post('org_type_id'));
        $kolType = trim($this->input->post('kol_type_id'));
        $regionType = trim($this->input->post('region_type_id'));
        $topicType = trim($this->input->post('topic_type_id'));
        $keywords = trim($this->input->post('keywords'));
        $firstName = trim($this->input->post('first_name'));
        $middleName = trim($this->input->post('middle_name'));
        $lastName = trim($this->input->post('last_name'));
        $specialty = trim($this->input->post('specialty_id'));
        $subSpecialty = trim($this->input->post('sub_specialty '));
        $country = trim($this->input->post('country_id'));
        $state = trim($this->input->post('state_id'));
        $organization = trim($this->input->post('organization_id'));
        $title = trim($this->input->post('title'));
        $postalCode = trim($this->input->post('postal_code'));
        $education = trim($this->input->post('education_id'));
        $eventName = trim($this->input->post('event_name_id'));
        $listName = trim($this->input->post('list_name_id'));
        $profileType = trim($this->input->post('profileType'));
        $viewTypeMyKols = trim($this->input->post('viewTypeMyKols'));
        $arrAdvSearchFields['profileType'] = $profileType;
        $arrAdvSearchFields['pkeywords'] = trim($this->input->post('pkeywords'));
        $arrAdvSearchFields['pauthpos'] = trim($this->input->post('pauthpos'));
        $arrAdvSearchFields['pqtype'] = trim($this->input->post('pqtype'));
        $arrAdvSearchFields['etopic'] = trim($this->input->post('etopic'));
        $arrAdvSearchFields['erole'] = trim($this->input->post('erole'));
        $arrAdvSearchFields['eqtype'] = trim($this->input->post('eqtype'));
        $arrAdvSearchFields['tkeywords'] = trim($this->input->post('tkeywords'));
        $arrAdvSearchFields['trole'] = trim($this->input->post('trole'));
        $arrAdvSearchFields['tqtype'] = trim($this->input->post('tqtype'));
         $arrAdvSearchFields['memebers'] = trim($this->input->post('members'));

        $arrAdvSearchFields['keywords'] = $keywords;
        $arrAdvSearchFields['first_name'] = $firstName;
        $arrAdvSearchFields['middle_name'] = $middleName;
        $arrAdvSearchFields['last_name'] = $lastName;
        $arrAdvSearchFields['sub_specialty'] = $subSpecialty;
        $arrAdvSearchFields['title'] = $title;
        $arrAdvSearchFields['postal_code'] = $postalCode;
        foreach ($arrAdvSearchFields as $index => $value) {
            $value = trim($value);
            if (empty($value)) {
                unset($arrAdvSearchFields[$index]);
            }
        }

        $arrOrgTypes = $this->input->post('org_types');
        if ($arrOrgTypes != '')
            $arrOrgTypes = explode(",", $arrOrgTypes);
        if ($orgType != '') {
            $arrOrgTypes[] = $orgType;
        }
        $arrKolTypes = $this->input->post('kol_types');
        if ($arrKolTypes != '')
            $arrKolTypes = explode(",", $arrKolTypes);
        if ($kolType != '') {
            $arrKolTypes[] = $kolType;
        }
        $arrRegionTypes = $this->input->post('region_types');
        if ($arrRegionTypes != '')
            $arrRegionTypes = explode(",", $arrRegionTypes);
        if ($regionType != '') {
            $arrRegionTypes[] = $regionType;
        }
        $arrTopicTypes = $this->input->post('topic_types');
        if ($arrTopicTypes != '')
            $arrTopicTypes = explode(",", $arrTopicTypes);
        if ($topicType != '') {
            $arrTopicTypes[] = $topicType;
        }
        //Get all the selected checkboxs details for respective category
        $arrCountries = $this->input->post('countries');
        if ($arrCountries != '')
            $arrCountries = explode(",", $arrCountries);
        //if the input field is not blank add the value in to respective category array values
        if ($country != '')
            $arrCountries[] = $country;
        $arrStates = $this->input->post('states');
        if ($arrStates != '')
            $arrStates = explode(",", $arrStates);
        //if the input field is not blank add the value in to respective category array values
        if ($state != '')
            $arrStates[] = $state;

        $arrSpecialties = $this->input->post('specialties');
        if ($arrSpecialties != '')
            $arrSpecialties = explode(",", $arrSpecialties);
        if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations[] = $organization;
        }
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $arrAdvSearchFields['viewType'] = $viewMyKols;
            } else {
                $arrAdvSearchFields['viewType'] = array(0);
            }
        }
        $arrAdvSearchFields['view_type'] = array($viewTypeMyKols);
        $arrAdvSearchFields['profile_type'] = array($profileType);
        $arrAdvSearchFields['specialty'] = $arrSpecialties;
        $arrAdvSearchFields['country'] = $arrCountries;
        $arrAdvSearchFields['state'] = $arrStates;
        $arrAdvSearchFields['organization'] = $arrOrganizations;
        $arrAdvSearchFields['education'] = $arrEducations;
        $arrAdvSearchFields['event_name'] = $arrEvents;
        $arrAdvSearchFields['list_id'] = $arrLists;
        $arrAdvSearchFields['type'] = $arrOrgTypes;
        $arrAdvSearchFields['kol_titles'] = $arrKolTypes;
        $arrAdvSearchFields['region'] = $arrRegionTypes;
        $arrAdvSearchFields['topic'] = $arrTopicTypes;

        $arrFiltersApplied = array();
        foreach ($arrAdvSearchFields as $section => $arrValues) {
            if ((sizeof(array_filter($arrValues))) > 0) {
                $separator = ' | ';
                switch ($section) {
                    case 'specialty': $arrSelectedSpecialties = $this->Specialty->getSpecialtiesById($arrValues);
                        $arrFiltersApplied['specialty'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedSpecialties) . '">Specialty</a>';
                        break;
                    case 'country': $arrSelectedCountries = $this->Country_helper->getCountryNameById($arrValues);
                        $arrFiltersApplied['country'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCountries) . '">Country</a>';
                        break;
                    case 'state':
                        $arrSelectedStates = $this->Country_helper->getStateNameById($arrValues);
                        $arrFiltersApplied['state'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedStates) . '">State</a>';
                        break;
                    case 'organization':
                        $arrSelectedOrgs = $this->organization->getOrgsById($arrValues);
                        $arrFiltersApplied['organization'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOrgs) . '">Organization</a>';
                        break;
                    case 'education': $arrSelectedEducations = $this->kol->getInstituteNameById($arrValues);
                        $arrFiltersApplied['education'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEducations) . '">Education</a>';
                        break;
                    case 'event_id': $arrSelectedEvents = $this->kol->getEventNameById($arrValues);
                        $arrFiltersApplied['event'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedEvents) . '">Event</a>';
                        break;
                    case 'list_id':
                        $listNames = array();
                        foreach ($arrValues as $key => $value) {
                            $row = $this->My_list_kol->editListName($value);
                            $listNames[] = $row['list_name'];
                        }
                        $arrFiltersApplied['list'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $listNames) . '">List</a>';
                        break;
                    case 'profile_type':
                        $arrFiltersApplied['profile_type'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $profileType . '">Profile Type</a>';
                        break;
                    case 'view_type':
                        if ($arrValues[0] == 1)
                            $viewTypeString = "My Contacts";
                        else
                            $viewTypeString = "All Contacts";
                        $arrFiltersApplied['viewType'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $viewTypeString . '">View Type</a>';
                        break;
                }
            }
        }
        //		}
        $arrKols = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //if request is for all page results id, then just rerutn the kols ids as json data
        if (isset($kolsCount) && $kolsCount != null) {
            $arrIds = array();
            foreach ($arrKols as $row)
                $arrIds[] = (int) $row['id'];
            $data['kolIds'] = $arrIds;
            echo json_encode($data);
            return null;
        }
        //		$advSearchSessData=array('keywords','arrFilterFields','arrAdvSearchFields');
        //		$this->session->unset_userdata($advSearchSessData);
        //		$this->session->set_userdata('keywords',$keywords);
        //		$this->session->set_userdata('arrFilterFields',$arrFilterFields);
        //		$this->session->set_userdata('arrAdvSearchFields',$arrAdvSearchFields);
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $filterData['keyword'] = "";
        $filterData['searchType'] = "advanced";
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['searchType'] = "advanced";
        $kolResultsData['kolsCount'] = $count;
        //		pr($arrFiltersApplied);
        if (sizeof($viewMyKols) < 1 && $viewTypeMyKols == MY_RECORDS) {
            $kolResultsData['savedQueryFilterApplied'] = implode(', ', $arrFiltersApplied);
        } else {
            $kolResultsData['filtersApplied'] = implode(', ', $arrFiltersApplied);
        }
        $arrAdvSearchFieldsForMsg = $arrAdvSearchFields;
        if ($arrAdvSearchFieldsForMsg['profileType'] == "Basic") {
            $arrAdvSearchFieldsForMsg['profileType'] = $arrAdvSearchFieldsForMsg['profileType'] . " Profiles";
        } else if ($arrAdvSearchFieldsForMsg['profileType'] == "Basic Plus") {
            $arrAdvSearchFieldsForMsg['profileType'] = str_replace(" Plus", "", $arrAdvSearchFieldsForMsg['profileType']) . "+ Profiles";
        } else if ($arrAdvSearchFieldsForMsg['profileType'] == "Full Profile") {
            $arrAdvSearchFieldsForMsg['profileType'] = "Full Profiles";
        }
        if (isset($arrAdvSearchFieldsForMsg['pauthpos']) && $arrAdvSearchFieldsForMsg['pauthpos'] > 0) {
            switch ($arrAdvSearchFieldsForMsg['pauthpos']) {
                case 1: $arrAdvSearchFieldsForMsg['pauthpos'] = 'First Author';
                    break;
                case 2: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Middle Author';
                    break;
                case 3: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Last Author';
                    break;
                case 4: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Single Author';
                    break;
            }
        }
        unset($arrAdvSearchFieldsForMsg['pqtype']);
        unset($arrAdvSearchFieldsForMsg['eqtype']);
        unset($arrAdvSearchFieldsForMsg['tqtype']);
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFieldsForMsg);
        $kolResultsData['profileType'] = $profileType;
        $details['filterPage'] = 'search/kol_filters';
        $details['kolResultsPage'] = 'search/my_kol_results';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        $this->load->view('search/kol_search_results', $kolResultsData);
    }

    /**
     *
     * @param String	$membershipType
     * @param String 	$committee
     * @return unknown_type
     */
    function get_specialty_names($spaciltyName) {
        $spaciltyName = utf8_urldecode($this->input->post($spaciltyName));
        $this->load->model('Specialty');
        $arrSpecialty = $this->Specialty->getSpecialties($spaciltyName);
        $arrSuggestSpecialties = array();
        if (sizeof($arrSpecialty) == 0) {
            $arrSuggestSpecialties[0] = 'No results found for ' . $spaciltyName;
        } else {
            $flag = 1;
            foreach ($arrSpecialty as $id => $name) {
                if ($flag) {
                    $arrSuggestSpecialties[] = '<div class="autocompleteHeading">Specialties</div><div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestSpecialties[] = '<div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $spaciltyName;
        $arrReturnData['suggestions'] = $arrSuggestSpecialties;
        echo json_encode($arrReturnData);
    }

    //-----Start of search function for "events"
    /**
     * returns the simple search results for Event, matching the keyword with event name
     * @return Array
     */
    function search_events() {
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrFilterFields = array();
        $arrEvents = array();
        $searchType = 'simple';
        $keyword = $this->input->post('keyword');
        //Getting "all Matching Events by event name"
        $arrEvents = $this->kol->getMatchEvents($keyword, $limit, $startFrom, false);
        $count = $this->kol->getMatchEvents($keyword, $limit, $startFrom, true);
        $filterData['keyword'] = $keyword;
        $filterData['searchType'] = $searchType;
        $filterData['arrFilterFields'] = "";
        $filterData['arrAdvSearchFields'] = "";
        $eventResultsData['eventsCount'] = $count;
        $eventResultsData['arrEvents'] = $arrEvents;
        $eventResultsData['searchType'] = "simple";
        $eventResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $details['eventResultsPage'] = 'search/event_search_results';
        $details['eventResultsData'] = $eventResultsData;
        $details['filterPage'] = 'search/event_filters';
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/event_results';
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * returns the simple filter search results for Event, matching the keyword with event name
     * @return Array
     */
    function filter_search_events() {
        $page = $this->input->post('page');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        $details = array();
        $keyword = $this->input->post('keyword');
        $eventName = $keyword;
        $searchType = $this->input->post('search_type');
        $arrFilterEvents['type'] = trim($this->input->post('type'));
        $arrFilterEvents['role'] = trim($this->input->post('role'));
        $arrFilterEvents['country'] = trim($this->input->post('country'));
        $arrFilterEvents['organizer'] = trim($this->input->post('organizer'));
        //Getting "filter Search MatchingEvents"
        $arrEvents = $this->kol->getFilterMatchEvents($keyword, $arrFilterEvents, $limit, $startFrom, false);
        $count = $this->kol->getFilterMatchEvents($keyword, $arrFilterEvents, $limit, $startFrom, true);
        $filterData['keyword'] = $keyword;
        $filterData['searchType'] = $searchType;
        $filterData['arrFilterFields'] = $arrFilterEvents;
        $filterData['arrAdvSearchFields'] = "";
        $eventResultsData['eventsCount'] = $count;
        $eventResultsData['arrEvents'] = $arrEvents;
        $eventResultsData['searchType'] = "simple";
        $eventResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $details['eventResultsPage'] = 'search/event_search_results';
        $details['eventResultsData'] = $eventResultsData;
        $details['arrEvents'] = $arrEvents;
        $details['filterPage'] = 'search/event_filters';
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/event_results';
        $this->load->view('search/event_search_results', $eventResultsData);
    }

    /**
     * Show the page of 'event_adv_search' details
     *
     */
    function view_event_adv_search() {
        $data['contentPage'] = 'search/event_adv_search';
        $this->load->model('Event_helper');
        $arrConfEventTypes = $this->Event_helper->getAllConferenceEventTypes();
        $data['arrConfEventTypes'] = $arrConfEventTypes;
        // Get the list of Conference Session Types
        $arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
        $data['arrConfSessionTypes'] = $arrConfSessionTypes;
        // Get the list of Online Event Types
        $arrOnlineEventTypes = $this->Event_helper->getAllOnlineEventTypes();
        $data['arrOnlineEventTypes'] = $arrOnlineEventTypes;
        $result = array_merge($arrConfEventTypes, $arrConfSessionTypes, $arrOnlineEventTypes);
        $data['arrEventSessionTypes'] = $result;
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * returns the "advance"  search results for Event
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     * @return Array
     */
    function adv_search_events() {
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrAdvSearchFields = array();
        $arrFilterFields = array();
        $arrFilterFields['country'] = '';
        $arrFilterFields['organizer'] = '';
        $arrFilterFields['role'] = '';
        $searchType = $this->input->post('search_type');
        $keyword = $this->input->post('keyword');
        $this->session->unset_userdata('arrFilterFields');
        $arrAdvSearchFields['type'] = trim($this->input->post('type'));
        $arrAdvSearchFields['role'] = trim($this->input->post('role'));
        $arrAdvSearchFields['country'] = trim($this->input->post('country'));
        $arrAdvSearchFields['state'] = trim($this->input->post('state'));
        $arrAdvSearchFields['organizer'] = trim($this->input->post('organizer'));
        //Getting "Advance Search MatchingEvents"
        $arrEvents = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //Get count of Events grouping by category(for each category)
        $arrEventsByCountryCount = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'country');
        $arrEventsByStateCount = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'state');
        $arrEventsByOrgCount = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'organizer');
        $arrEventsByRoleCount = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'role');
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrEventsByCountryCount = array();
        foreach ($arrEventsByCountryCount as $row) {
            $assoArrEventsByCountryCount[$row['country']] = $row;
            $allCountryCount += $row['count'];
        }
        $allStateCount = 0;
        $assoArrEventsByStateCount = array();
        foreach ($arrEventsByStateCount as $row) {
            $assoArrEventsByStateCount[$row['state']] = $row;
            $allStateCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrEventsByOrgCount = array();
        foreach ($arrEventsByOrgCount as $row) {
            $assoArrEventsByOrgCount[$row['organizer']] = $row;
            $allOrgCount += $row['count'];
        }
        $allRoleCount = 0;
        $assoArrEventsByRoleCount = array();
        foreach ($arrEventsByRoleCount as $row) {
            $assoArrEventsByRoleCount[$row['role']] = $row;
            $allRoleCount += $row['count'];
        }
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allRoleCount'] = $allRoleCount;
        $filterData['arrEventsByCountryCount'] = $assoArrEventsByCountryCount;
        $filterData['arrEventsByStateCount'] = $assoArrEventsByStateCount;
        $filterData['arrEventsByOrgCount'] = $assoArrEventsByOrgCount;
        $filterData['arrEventsByRoleCount'] = $assoArrEventsByRoleCount;
        $filterData['keyword'] = $keyword;
        $filterData['searchType'] = $searchType;
        $filterData['arrFilterFields'] = "";
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $eventResultsData['eventsCount'] = $count;
        $eventResultsData['arrEvents'] = $arrEvents;
        $eventResultsData['searchType'] = "simple";
        $eventResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFields);
        $details['eventResultsPage'] = 'search/event_search_results';
        $details['eventResultsData'] = $eventResultsData;
        $details['arrEvents'] = $arrEvents;
        $details['filterPage'] = 'search/event_filters';
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/event_results';
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * returns the "advance"  filter search results for Event
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     * @return Array
     */
    function filter_adv_search_events() {
        $page = $this->input->post('page');
        $count = 0;
        $noOfRecordsPerPage = $this->uri->segment(3);
        if (!empty($noOfRecordsPerPage)) {
            $this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
        }
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $searchType = $this->input->post('search_type');
        $keyword = $this->input->post('keyword');
        if ((int) $page > -1) {
            $keyword = trim($this->session->userdata('keyword'));
            $arrFilterFields = $this->session->userdata('arrFilterFields');
        } else {
            $searchType = $this->input->post('search_type');
            $keyword = trim($this->session->userdata('keyword'));
            $country = trim($this->input->post('country'));
            $state = trim($this->input->post('state'));
            $organization = trim($this->input->post('organizer'));
            $role = trim($this->input->post('role'));
            $listName = trim($this->input->post('list_name'));
            $arrCountries = $this->input->post('countries');
            if ($arrCountries != '')
                $arrCountries = explode(",", $arrCountries);
            if ($country != '')
                $arrCountries[] = $country;

            $arrStates = $this->input->post('states');
            if ($arrStates != '')
                $arrStates = explode(",", $arrStates);
            if ($state != '')
                $arrStates[] = $state;

            $arrOrganizations = $this->input->post('organizers');
            if ($arrOrganizations != '')
                $arrOrganizations = explode(",", $arrOrganizations);
            if ($organization != '') {
                $arrOrganizations[] = $organization;
            }
            $arrRoles = $this->input->post('roles');
            if ($arrRoles != '')
                $arrRoles = explode(",", $arrRoles);
            if ($role != '') {
                $arrRoles[] = $role;
            }
            $arrLists = $this->input->post('lists');
            if ($arrLists != '')
                $arrLists = explode(",", $arrLists);
            if ($listName != '') {
                if (stripos($listName, '(')) {
                    $arrListDetails = explode("(", $listName);
                    $listName = trim($arrListDetails[0]);
                    $categoryName = trim($arrListDetails[1], ") ");
                    $listName = $this->My_list_kol->getListName($listName, $categoryName);
                }
                $arrLists[] = $listName;
            }
            //Prepare array of filter fields, ehich will be used for querying
            $arrFilterFields['country'] = $arrCountries;
            $arrFilterFields['state'] = $arrStates;
            $arrFilterFields['organizer'] = $arrOrganizations;
            $arrFilterFields['role'] = $arrRoles;
            $arrFilterFields['list_id'] = $arrLists;
        }
        $searchType = 'addvanced';
        $arrAdvSearchFields['type'] = trim($this->input->post('type'));
        $arrAdvSearchFields['role'] = trim($this->input->post('eventRole'));
        $arrAdvSearchFields['country'] = trim($this->input->post('evntCountry'));
        $arrAdvSearchFields['state'] = trim($this->input->post('evntState'));
        $arrAdvSearchFields['organizer'] = trim($this->input->post('eventOrganizer'));
        //Getting "AdvSearchMatchingEvents"
        $arrEvents = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        $filterData['keyword'] = $keyword;
        $filterData['searchType'] = $searchType;
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $eventResultsData['eventsCount'] = $count;
        $eventResultsData['arrEvents'] = $arrEvents;
        $eventResultsData['searchType'] = "simple";
        $eventResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFields);
        $details['eventResultsPage'] = 'search/event_search_results';
        $details['eventResultsData'] = $eventResultsData;
        $details['arrEvents'] = $arrEvents;
        $details['filterPage'] = 'search/event_filters';
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/event_results';
        $this->load->view('search/event_search_results', $eventResultsData);
    }

    /*
     *  Getting the Event data for "view_event_micro"
     */

    function view_event_micro($eventID) {
        $arrEvents = array();
        $arrEvents = $this->kol->getEventMicroData($eventID);
        $data['arrEvents'] = $arrEvents;
        $this->load->view('events/view_events_micro_profile', $data);
    }

    /**
     * Counts the number each affilition types for one kol
     *
     * @ACL-Alias Affiliation Chart
     * @ACL-Discription Counts the number each affilition types for one kol
     * @ACL-Category Affiliations
     * @ACL-SubApp client
     */
    function view_affiliation_chart($kolId = null) {
        $arrAffiliations = $this->kol->getAffiliationChart($kolId);
        $affAndCount = array();
        foreach ($arrAffiliations as $affiliation) {
            $aff = array();
            $aff[] = ucwords($affiliation['type']);
            $aff[] = (int) $affiliation['count'];
            $affAndCount[] = $aff;
        }
        echo json_encode($affAndCount);
    }

    /**
     * Counts the number publication processed for each year for one kol
     *
     * @ACL1-Alias Publications Chart
     * @ACL1-Discription Counts the number each Publications types for one kol
     * @ACL1-Category Publications
     * @ACL-1SubApp client
     */
    function view_publication_chart($kolId = null, $fromYear, $toYear) {
        $arrPublications = $this->kol->getPublicationChart($kolId, $fromYear, $toYear);
        $years = array();
        $count = array();
        $yearMapping = array();
        foreach ($arrPublications as $publication) {
            if($publication['year']>0){
                $years[] = $publication['year'];
                $count[] = (int) $publication['count'];
                $yearMapping[substr($publication['year'], 2)] = $publication['year'];
            }
        }
        $data[] = array_reverse($years);
        $data[] = array_reverse($count);
        $data[] = $yearMapping;
        echo json_encode($data);
    }

    /**
     * Counts the number of Online "Event types" for one kol
     * @ACL-Alias Event types Chart
     * @ACL-Discription Counts the number of Online "Event types" for one kol
     * @ACL-Category Events
     * @ACL-SubApp client
     */
    function view_events_chart_by_event_type($kolId = null, $fromYear, $toYear) {
        $arrOnlineEvents = $this->kol->getOnlineEventsChart($kolId, $fromYear, $toYear);
        $arrConferenceEvents = $this->kol->getConferenceEventsChart($kolId, $fromYear, $toYear);
        $data = array();
        $confAndCount = array();
        foreach ($arrConferenceEvents as $conference) {
            $conf = array();
            $conf[] = ucwords($conference['event_type']);
            $conf[] = (int) $conference['count'];
            $data[] = $conf;
        }
        echo json_encode($data);
    }

    /**
     * Counts the number of Conference "Event types" for one kol
     * @ACL-Alias Event types Chart
     * @ACL-Discription Counts the number of Conference "Event types" for one kol
     * @ACL-Category Events
     * @ACL-SubApp client
     */
    function view_conference_event_chart($kolId = null, $fromYear, $toYear) {
        $arrConferenceEvents = $this->kol->getConferenceEventsChart($kolId, $fromYear, $toYear);
    }

    /**
     * Counts the number of Major Meshterm for one kol
     *
     * @param unknown_type $kolId
     * @return unknown_type
     */
    function view_pub_major_meshterm_chart($kolId = null, $fromYear, $toYear) {

        $keyWord = $this->input->post('keyWord');

        $this->session->set_userdata('kolKeyWords', $keyWord);
        $keyWord = $this->session->userdata('kolKeyWords');
        $arrMajorMeshterm = $this->kol->getPubMajorMeshTermChart($kolId, $fromYear, $toYear, $keyWord);
        $meshTerms = array();
        $count = array();
        $arrIds = array();
        $arrParentIds = array();
        foreach ($arrMajorMeshterm as $meshterm) {
            $termName = '';
            $parentId = $meshterm['parent_id'];
            if ($parentId != 0 && $parentId != null) {
                $parentName = $this->pubmed->getMeshTermName($parentId);
                $termName = $parentName . "/" . $meshterm['mesh_term'];
            } else {
                $termName = $meshterm['mesh_term'];
            }
            $meshTerms[] = ucwords($termName);
            $count[] = (int) $meshterm['count'];
            $arrIds[] = $meshterm['id'];
            $arrParentIds[] = $meshterm['parent_id'];
        }
        $data[] = $meshTerms;
        $data[] = $count;
        $data[] = $arrIds;
        $data[] = $arrParentIds;
        echo json_encode($data);
    }

    /*
     * Getting the kol data for "view_kol_micro"
     *
     * @ACL-Alias view kol micro
     * @ACL-Discription Getting the kol data for "view_kol_micro"
     * @ACL-Category Kols
     * @ACL-SubApp client
     */

    function view_kol_micro($kolId, $type = null, $isFromProfileRequestPage = null) {
        $arrKol = array();
        $arrKol = $this->kol->getKolMicroData($kolId);
        $arrKol[0]['id'] = $kolId;
        $data['arrKol'] = $arrKol[0];
        if (is_numeric($data['arrKol']['suffix'])) {
            $data['arrKol']['suffix'] = $this->kol->getSuffixById($data['arrKol']['suffix']);
        }
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Get the count of "affilitions"
        $data['noOfAffilitions'] = array();        
        $noOfAffilitions = $this->kol->countAfiliations($kolId);
        $data['noOfAffilitions'] = $noOfAffilitions;
        //Get the count of "Events"
        $data['noOfEvents'] = array();
        $noOfEvents = $this->kol->countEvents($kolId);
        $data['noOfEvents'] = $noOfEvents;
        //Get the count of "Publications"
        $data['noOfPublications'] = array();
        ;
        $noOfPublications = $this->kol->countPublications($kolId);
        $data['noOfPublications'] = $noOfPublications;
        //Get the count of "Trials"
        $data['noOfTrials'] = array();
        $noOfTrials = $this->kol->countTrials($kolId);
        $data['noOfTrials'] = $noOfTrials;
        
        $arrSubSpecialties = $this->Specialty->getAllKolSubSpecialties($kolId);
        $data['arrSubSpecialties'] = $arrSubSpecialties;
        
        //	if($data['arrKol']['city_id']!=0)
        //		$data['arrKol']['city']				= $this->Country_helper->getCityeById($data['arrKol']['city_id']);
        //	if($data['arrKol']['state_id']!=0){
        //		$data['arrKol']['state']			= $this->Country_helper->getStateById($data['arrKol']['state_id']);
        //		$data['arrKol'][0]['state_code']	= $this->Country_helper->getStatecodeByStateIdorName($data['arrKol']['state_id'],'id');
        //	}
        $data['type'] = $type;
        if($isFromProfileRequestPage == 1){
        	$data['showProfileRequestButton'] = 1;
        }
        $this->load->view('kols/view_kol_micro_profile', $data);
    }

    /*
     * Display page that contains list of Kols,Refune by options,Charts
     *
     * @ACL1-Alias list Kols Client View
     * @ACL1-Discription Display page that contains list of Kols,Refune by options,Charts
     * @ACL1-Category Kols
     * @ACL1-SubApp client
     */

    function list_kols_client_view() {
        $this->search_kols();
    }

    /**
     * Display the page of kols social media page for clint view
     *
     * @param unknown_type $kolId
     * @return unknown_type
     */
    function view_social_media($kolId = null, $subContentPage = '') {
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        if (!$kolId) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        // Getting the KOL details
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['contentPage'] = 'kols/view_social_media';
        $data['subContentPage'] = $subContentPage;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Generates the chart for Affiliations Group by Engagement Types
     *
     * @param unknown_type $fromYear
     * @param unknown_type $toYear
     * @param unknown_type $arrKolIds
     * @param unknown_type $arrEngTypes
     * @param unknown_type $arrOrgType
     * @param unknown_type $arrCountries
     * @param unknown_type $arrSpecialities
     * @return unknown_type
     */
    function chart_for_engagement($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrEngTypes = '', $arrOrgType = '', $arrCountries = 0, $arrSpecialities = 0) {
        $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType, $arrCountries, $arrSpecialities, $selectType = 'engagement_types.engagement_type');
        $arrEngagementCounts = array();
        foreach ($arrAffiliations as $row) {
            $arr = array();
            if ($row['engagement_type'] != '') {
                $arr[] = $row['engagement_type'];
                $arr[] = (int) $row['count'];
                $arrEngagementCounts[] = $arr;
            }
        }
        echo json_encode($arrEngagementCounts);
    }

    /**
     * Generates the chart for Affiliations Group by Engagement Types accept the data from post method
     * @return unknown_type
     */
    function chart_for_engagement_post() {
        $currController = $this->uri->segment(1);
        $arrFilterById = array();
        if ($currController == "reports") {
            //$arrFilterById = $this->kol->getFilterByRecentApplied();
            $arrFilterById = false;
            $arrFilterFields = array();
            $arrFilterFields = $arrFilterById['arrFilterFields'];
        }
        $arrKolIds = array();
        $fromYear = ($this->input->post('from_year') == null) ? 0 : $this->input->post('from_year');
        $toYear = ($this->input->post('to_year') == null) ? 0 : $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == null) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == null) ? 0 : $this->input->post('country'));
        $arrStates = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrEngTypes = ($this->input->post('engType') == '') ? '' : $this->input->post('engType');
        $arrOrgType = ($this->input->post('orgType') == '') ? '' : $this->input->post('orgType');
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');

        if ($arrOrgType != '' && $arrOrgType == "University/Hospital") {
            $arrOrgType = "university";
        }
        if ($arrSpecialities != '0' && $arrSpecialities != '') {
            foreach ($arrSpecialities as $key => $value)
                $arrSpecialityIds[] = $this->kol->getSpecialtyId($value);
        } else {
            $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != '0' && $arrCountries != '') {
            foreach ($arrCountries as $key => $value)
                $arrCountriesIds[] = $this->Country_helper->getConcountryId($value);
        } else {
            $arrCountriesIds = $arrCountries;
        }
        if ($arrStates != '0' && $arrStates != '') {
            foreach ($arrStates as $key => $value)
                $arrStatesIds[] = $this->Country_helper->getStateId($value);
        } else {
            $arrStatesIds = $arrStates;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            foreach ($arrListNames as $key => $value)
                $arrListNamesIds[] = $this->My_list_kol->getListNameId($value);
        } else {
            $arrListNamesIds = $arrListNames;
        }

        if ($arrKolNames != '0' && $arrKolNames != '') {
            foreach ($arrKolNames as $key => $kolName) {
                if (!is_numeric($kolName)) {
                    // As in the model we concatinate First, middle and last name we are avoiding spaces
                    //	$kolFullNameWithoutSpace	= str_replace(" ","",$kolName);
                    $arrKolIds[] = $this->kol->getKolId($kolName);
                } else {
                    $arrKolIds[] = $kolName;
                }
            }
        } else {
            $arrKolIds = $arrKolNames;
        }
        $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes = '', $arrOrgType, $arrCountriesIds, $arrSpecialityIds, $selectType = 'engagement_types.engagement_type', $arrListNamesIds, $arrStatesIds, $arrProfileType);
        $arrEngagementCounts = array();
        foreach ($arrAffiliations as $row) {
            $arr = array();
            if ($row['engagement_type'] != '') {
                $arr[] = $row['engagement_type'];
                $arr[] = (int) $row['count'];
                $arrEngagementCounts[] = $arr;
            }
        }
        //	pr($arrEngagementCounts);
        echo json_encode($arrEngagementCounts);
    }

    /**
     *  Generates the chart for Affiliations Group by Organization Types
     *
     * @param unknown_type $fromYear
     * @param unknown_type $toYear
     * @param unknown_type $arrKolIds
     * @param unknown_type $arrEngTypes
     * @param unknown_type $arrOrgType
     * @param unknown_type $arrCountries
     * @param unknown_type $arrSpecialities
     * @return unknown_type
     */
    function chart_for_organization($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrEngTypes = '', $arrOrgType = '', $arrCountries = 0, $arrSpecialities = 0) {
        $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType, $arrCountries, $arrSpecialities, $selectType = 'kol_memberships.type');
        $arrOrgCounts = array();
        foreach ($arrAffiliations as $row) {
            $arr = array();
            $arr[] = ucwords($row['type']);
            $arr[] = (int) $row['count'];
            $arrOrgCounts[] = $arr;
        }
        echo json_encode($arrOrgCounts);
    }

    /**
     * Generates the chart for Affiliations Group by Organization Types accept the data from post method
     * @return unknown_type
     */
    function chart_for_organization_post() {
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = ($this->input->post('from_year') == null) ? 0 : $this->input->post('from_year');
        $toYear = ($this->input->post('to_year') == null) ? 0 : $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');	
         $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
         $arrSpecialities = ($this->input->post('specialty') == null) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == null) ? 0 : $this->input->post('country');
        //	$arrStates								= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrEngTypes = ($this->input->post('engType') == '') ? '' : $this->input->post('engType');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
        	if (!is_array($arrGlobalRegions))
        		$arrGlobalRegionIds = explode(",", $arrGlobalRegions);
        		else
        			$arrGlobalRegionIds = $arrGlobalRegions;
        }
        
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
            else
                $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
            else
                $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
            else
                $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
            else
                $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
            else
                $arrListNamesIds = $arrListNames;
        }
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $kolIds, $arrEngTypes, $arrOrgType = '', $arrCountriesIds, $arrSpecialityIds, $selectType = 'kol_memberships.type', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        $arrOrgCounts = array();
        foreach ($arrAffiliations as $row) {
            $arr = array();
            if ($row['type'] == "university") {
                $arr[] = "University/Hospital";
            } else {
                $arr[] = ucwords($row['type']);
            }
            $arr[] = (int) $row['count'];
            $arrOrgCounts[] = $arr;
        }
        echo json_encode($arrOrgCounts);
    }

    /*
     * Counts the number of Affiliations based on "engagament_type" for one kol
     * @author Vianayak Malladad
     * @since 1.5
     * @created on 7 March,2011
     * view_affiliation_by_eng_type=>(view affiliation chart by engagament_type)
     */

    function view_affiliation_by_eng_type($kolId, $type) {
        $arrAffResult = $this->kol->getAffilitionsByEngType($kolId, $type);
        $data = array();
        foreach ($arrAffResult as $row) {
            $arrAff = array();
            $arrAff[] = ucwords($row['engagement_type']);
            $arrAff[] = (int) $row['count'];
            $data[] = $arrAff;
        }
        echo json_encode($data);
    }

    /*
     * Counts the number of Events based on "session_type" for one kol
     * @author Vianayak Malladad
     * @since 1.5
     * @created on 7 March,2011
     *
     */

    function view_events_by_session_type($kolId = 0, $startYear, $endYear, $role = '', $arrCountryId = 0, $arrSpecialities = 0) {
        $kolId = (int) $kolId;
        $startYear = (int) $startYear;
        $endYear = (int) $endYear;
        $arrCountryId = (int) $arrCountryId;
        $arrSpecialities = (int) $arrSpecialities;
        $role = $this->db->escape_like_str($role);
        $data = array();
        $arrEventsresult = $this->kol->getEventsBySessionType($kolId, $startYear, $endYear, $role, $arrCountryId, $arrSpecialities = 0);
        foreach ($arrEventsresult as $row) {
            $arrEvents = array();
            $arrEvents[] = ucwords($row['session_type']);
            $arrEvents[] = (int) $row['count'];
            $data[] = $arrEvents;
        }
        echo json_encode($data);
    }

    function events_by_session_type_post() {
        $arrSpecialities1 = array();
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrSpecialities = ($this->input->post('specialty') == null) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == null) ? 0 : $this->input->post('country');
        $arrStates = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');

        if ($arrSpecialities != '0' && $arrSpecialities != '') {
            foreach ($arrSpecialities as $key => $value)
                $arrSpecialityIds[] = $this->kol->getSpecialtyId($value);
        } else {
            $arrSpecialityIds = $arrSpecialities;
        }

        if ($arrCountries != '0' && $arrCountries != '') {
            foreach ($arrCountries as $key => $value)
                $arrCountriesIds[] = $this->Country_helper->getConcountryId($value);
        } else {
            $arrCountriesIds = $arrCountries;
        }
        if ($arrStates != '0' && $arrStates != '') {
            foreach ($arrStates as $key => $value)
                $arrStatesIds[] = $this->Country_helper->getStateId($value);
        } else {
            $arrStatesIds = $arrStates;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            foreach ($arrKolNames as $key => $kolName) {
                //$kolName1		= str_replace(" ","",$kolName);
                $arrKolIds[] = $this->kol->getKolId($kolName);
            }
        } else {
            $arrKolIds = $arrKolNames;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            foreach ($arrListNames as $key => $value)
                $arrListNamesIds[] = $this->My_list_kol->getListNameId($value);
        } else {
            $arrListNamesIds = $arrListNames;
        }
        $role = $this->input->post('role');
        $data = array();
        $arrEventsresult = $this->kol->getEventsBySessionType($arrKolIds, $fromYear, $toYear, $role, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds);
        foreach ($arrEventsresult as $row) {
            $arrEvents = array();
            $arrEvents[] = ucwords($row['session_type']);
            $arrEvents[] = (int) $row['count'];
            $data[] = $arrEvents;
        }
        echo json_encode($data);
    }

    /*
     * Counts the number of Events based on "Role" for one kol
     * @author Vianayak Malladad
     * @since 1.5
     * @created on 8 March,2011
     *
     */

    function view_events_by_role($kolId = 0, $startYear, $endYear, $sessionType = '', $counTryId = 0) {
        $kolId = (int) $kolId;
        $startYear = (int) $startYear;
        $endYear = (int) $endYear;
        $counTryId = (int) $counTryId;
        $sessionType = $this->db->escape_like_str($sessionType);
        $arrEventsresult = $this->kol->getEventsByRole($kolId, $startYear, $endYear, $sessionType, $counTryId = 0);
        $data = array();
        foreach ($arrEventsresult as $row) {
            $arrEvents = array();

            $arrEvents[] = ucwords($row['role']);
            $arrEvents[] = (int) $row['count'];
            $data[] = $arrEvents;
        }
        echo json_encode($data);
    }

    function view_events_by_role_post() {
        $data = array();
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id');
        $arrSpecialities = ($this->input->post('specialty') == null) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == null) ? 0 : $this->input->post('country');
        $arrStates = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $sessionType = $this->input->post('sessionType');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        if ($arrSpecialities != '0' && $arrSpecialities != '') {
            foreach ($arrSpecialities as $key => $value)
                $arrSpecialityIds[] = $this->kol->getSpecialtyId($value);
        } else {
            $arrSpecialityIds = $arrSpecialities;
        }

        if ($arrCountries != '0' && $arrCountries != '') {
            foreach ($arrCountries as $key => $value)
                $arrCountriesIds[] = $this->Country_helper->getConcountryId($value);
        } else {
            $arrCountriesIds = $arrCountries;
        }
        if ($arrStates != '0' && $arrStates != '') {
            foreach ($arrStates as $key => $value)
                $arrStatesIds[] = $this->Country_helper->getStateId($value);
        } else {
            $arrStatesIds = $arrStates;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            foreach ($arrKolNames as $key => $value) {
                //	$value1			= str_replace(" ","",$value);
                $arrKolIds[] = $this->kol->getKolId($value);
            }
        } else {
            $arrKolIds = $arrKolNames;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            foreach ($arrListNames as $key => $value)
                $arrListNamesIds[] = $this->My_list_kol->getListNameId($value);
        } else {
            $arrListNamesIds = $arrListNames;
        }
        $arrEventsresult = $this->kol->getEventsByRole($arrKolIds, $fromYear, $toYear, $sessionType, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds);
        //pr($arrEventsresult);
        foreach ($arrEventsresult as $row) {
            $arrEvents = array();
            $arrEvents[] = ucwords($row['role']);
            $arrEvents[] = (int) $row['count'];
            $data[] = $arrEvents;
        }
        echo json_encode($data);
    }

    /**
     * Retrives the data required for the kols checkbox's kind of filters
     * @author 	Ramesh B
     * @since	2.1
     * @return
     * @created 27-04-2011
     */
    function reload_filters() {
        ini_set("max_execution_time", 7200);
        $arrFilterFields = array();
        $page = $this->input->post('page');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $searchType = '';
        $keyword = '';
        $arrCountries = array();
        $arrStates = array();
        $arrSpecialties = array();
        //	if((int)$page>-1){
        //		$keyword										= trim($this->session->userdata('keyword'));
        //		$arrFilterFields								= $this->session->userdata('arrFilterFields');
        //	}
        //	else{
        $searchType = $this->input->post('search_type');
        $keyword = trim($this->input->post('keyword'));
        $specialty = trim($this->input->post('specialty_id'));
        $country = trim($this->input->post('country_id'));
        $state = trim($this->input->post('state_id'));
        $city = trim($this->input->post('city_id'));
        $organization = trim($this->input->post('organization_id'));
        $education = trim($this->input->post('education_id'));
        $eventName = trim($this->input->post('event_name_id'));
        $listName = trim($this->input->post('list_name_id'));
        $kolName = trim($this->input->post('kol_name'));
        $kolId = trim($this->input->post('kol_id'));
        $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
        $arrCountries = $this->input->post('countries');
        $profileType = trim($this->input->post('profile_type'));
        $savedFilterId = trim($this->input->post('savedFilterId'));
        $viewTypeMyKols = trim($this->input->post('viewTypeMyKols'));
        $orgType 	= trim($this->input->post('org_type_id'));
        $kolType 	= trim($this->input->post('kol_type_id'));
        $regionType 	= trim($this->input->post('region_type_id'));
        if ($savedFilterId != '') {
            $savedFilterId = "simple";
        }
        if ($arrCountries != '')
            $arrCountries = explode(",", $arrCountries);
        if ($country != '')
            $arrCountries[] = $country;
        $arrStates = $this->input->post('states');
        if ($arrStates != '')
            $arrStates = explode(",", $arrStates);
        if ($state != '')
            $arrStates[] = $state;
        $arrCities = $this->input->post('cities');
        if ($arrCities != '')
            $arrCities = explode(",", $arrCities);
        if ($city != '')
            $arrCities[] = $city;
        $arrSpecialties = $this->input->post('specialties');
        if ($arrSpecialties != '')
            $arrSpecialties = explode(",", $arrSpecialties);
        if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        //$arrOrganizations1								= array();
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations[] = $organization;
        }
        $arrOrgTypes	=	$this->input->post('org_types');
        if($arrOrgTypes!='')
                $arrOrgTypes	=explode(",",$arrOrgTypes);
        if($orgType!=''){
                $arrOrgTypes[]	=	$orgType;
        }
        $arrKolTypes	=	$this->input->post('kol_types');
        if($arrKolTypes!='')
                $arrKolTypes	=explode(",",$arrKolTypes);
        if($kolType!=''){
                $arrKolTypes[]	=	$kolType;
        }
         $arrRegionTypes	=	$this->input->post('region_types');
        if($arrRegionTypes!='')
                $arrRegionTypes	=explode(",",$arrRegionTypes);
        if($regionType!=''){
                $arrRegionTypes[]	=	$regionType;
        }
        if(KOL_CONSENT){
            $arrOptInOutTypes	=	$this->input->post('opt_in_out_types');
            if($arrOptInOutTypes!='')
                $arrOptInOutTypes	=explode(",",$arrOptInOutTypes);
            if($OptInOutType!=''){
                $arrOptInOutTypes[]	=	$OptInOutType;
            }
        }
        /* 	$arrOrganizations								= array();
          foreach($arrOrganizations1 as $key => $orgId){
          $arrOrganizations[$orgId]					= $this->organization->getOrgNameByOrgId($orgId);
          }
         */
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');

        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }

        $arrKolNames = $this->input->post('kols');
        if ($arrKolNames != '')
            $arrKolNames = explode(",", $arrKolNames);
        if ($kolName != '') {
            $arrKolNames[] = $kolName;
        }
        if ($arrKolNames != '' && $arrKolNames != 0) {
            foreach ($arrKolNames as $kolName) {
                //	$kolName								= str_replace(' ','',$kolName);
                $arrKolIds[] = $this->kol->getKolId($kolName);
            }
        } else {
            $arrKolIds = '';
        }
        $arrKolIds = $this->input->post('kol_id');

        //Prepare array of filter fields, ehich will be used for querying
        $arrFilterFields['specialty'] = $arrSpecialties;
        $arrFilterFields['country'] = $arrCountries;
        $arrFilterFields['state'] = $arrStates;
        $arrFilterFields['city'] = $arrCities;
        $arrFilterFields['organization'] = $arrOrganizations;
        $arrFilterFields['education'] = $arrEducations;
        $arrFilterFields['event_id'] = $arrEvents;
        $arrFilterFields['list_id'] = $arrLists;
        $arrFilterFields['event_name'] = $eventName;
        $arrFilterFields['profile_type'] = $profileType;
        $arrFilterFields['type'] 		= $arrOrgTypes;
        $arrFilterFields['title'] 		= $arrKolTypes;
        $arrFilterFields['region'] 		= $arrRegionTypes;
        if(KOL_CONSENT){
            $arrFilterFields['opt_inout'] 		= $arrOptInOutTypes;
        }
       /* $titles=array();
        foreach( $arrFilterFields['title'] as $title 	){
            $titles[]=$title;
        }
        $arrFilterFields['title'] 		= $titles;*/
         
        //	}
        $doAnd = false;
        $splitDone = false;
        //Split the keyword by 'comma' or '+' or 'space'
        $arrKeywords = explode("+", $keyword);
        // Do And operation if Words are separated by '+' else do or operation
        if (sizeof($arrKeywords) > 1) {
            $doAnd = true;
        } else if (!$doAnd) {
            $arrKeywords = explode(",", $keyword);
            if (sizeof($arrKeywords) > 1) {
                $splitDone = true;
            }
        }
        if (!$doAnd && !$splitDone)
            $arrKeywords = explode(" ", $keyword);
        $arrKols = array();
        // We can modify the below logic so as to use the single 'or' and 'and' methods by
        //sending the array of keyword names and enbling the where condition based on the
        //size of the array in those methods
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $arrFilterFields['viewType'] = $viewMyKols;
            } else {
                $arrFilterFields['viewType'] = array(0);
            }
        }

        if (sizeof($arrKeywords) == 1) {
            $arrKeywords[0] = trim($keyword);
            //Get count of kols grouping by category(for each category)
            $arrKolsByCountryCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country', $arrKolIds);
            $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state', $arrKolIds);
            $arrKolsByCityCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city', $arrKolIds);
            $arrKolsBySpecialtyCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty', $arrKolIds);
            $arrKolsByOrgCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization', $arrKolIds);
            $arrKolsByEduCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education', $arrKolIds);
            $arrKolsByEventCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event', $arrKolIds);
            $arrKolsByListCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list', $arrKolIds);
            $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
            $arrKolByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title', $arrKolIds);
            $arrRegionCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region', $arrKolIds);
            if(KOL_CONSENT){
                $arrOptInCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout', $arrKolIds);
            }
            
        }
        if (sizeof($arrKeywords) == 2) {
            if ($doAnd) {
                $arrKols = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false);
                $count = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, true);
                //Get count of kols grouping by category(for each category)
                $arrKolsByCountryCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByCityCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
                $arrKolByTypeCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title');
                $arrRegionCount=$this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region');
                if(KOL_CONSENT){
                    $arrOptInCount=$this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout');
                }
                
            } else {
                //Get count of kols grouping by category(for each category)
                $arrKolsByCountryCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByCityCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
                $arrKolByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title');
                $arrRegionCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region');
                if(KOL_CONSENT){
                    $arrOptInCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout');
                }

                
            }
        }
        if (sizeof($arrKeywords) == 3) {
            if ($doAnd) {
                //Get count of kols grouping by category(for each category)
                $arrKolsByCountryCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByCityCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
                $arrKolByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title');
                $arrRegionCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region');
                if(KOL_CONSENT){
                    $arrOptInCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout');
                }
                
            } else {
                //Get count of kols grouping by category(for each category)
                $arrKolsByCountryCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country');
                $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state');
                $arrKolsByCityCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city');
                $arrKolsBySpecialtyCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
                $arrKolsByOrgCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
                $arrKolsByEduCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education');
                $arrKolsByEventCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event');
                $arrKolsByListCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list');
                $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
                $arrKolByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title');
                $arrRegionCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region');
                if(KOL_CONSENT){
                    $arrOptInCount=$this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout');
                }
                
            }
        }
        unset($arrFilterFields['viewType']);
        //Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
        //$this->session->set_userdata('keyword',$keyword);
        //$this->session->set_userdata('arrFilterFields',$arrFilterFields);
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country_id']] = $row;
            $allCountryCount+=$row['count'];
        }
        $allStateCount = 0;
        $assoArrKolsByStateCount = array();
        foreach ($arrKolsByStateCount as $row) {
            $assoArrKolsByStateCount[$row['state_id']] = $row;
            $allStateCount+=$row['count'];
        }
    	$allCityCount = 0;
        $assoArrKolsByCityCount = array();
        foreach ($arrKolsByCityCount as $row) {
            $assoArrKolsByCityCount[$row['city_id']] = $row;
            $allCityCount+=$row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specialty']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['org_id']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_id']] = $row;
            $allEduCount += $row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        //		pr($arrKolsByEventCount);
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_id']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }
        
        $allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['org_type_id']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
                   $allKolTypeCount=0;
		$assoArrKolByTypeCount=array();
		foreach($arrKolByTypeCount as $row){
			$assoArrKolByTypeCount[$row['title']]=$row;
			$allKolTypeCount+=$row['count'];
		}
            $allRegionCount=0;
        $assoRegionCount=array();
        foreach($arrRegionCount as $row){
                //$assoRegionCount[$row['region_type_id']]=$row;
                $assoRegionCount[$row['GlobalRegion']]=$row;
                $allRegionCount+=$row['count'];
        }
        if(KOL_CONSENT){
            $allOptInOutCount=0;
            $assoOptInCount=array();
            foreach($arrOptInCount as $row){
                $assoOptInCount[$row['opt_in_out_id']]=$row;
                $allOptInOutCount+=$row['count'];
            }
        }
        
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allOrgTypeCount']		= $allOrgTypeCount;
        $filterData['allkolTypeCount']		= $allKolTypeCount;
        $filterData['allRegionCount']		= $allRegionCount;
        $filterData['allCityCount'] = $allCityCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allListCount'] = $allListCount;
        $filterData['allOrgTypeCount']		=	$allOrgTypeCount;
        if(KOL_CONSENT){
            $filterData['allOptInOutCount'] = $allOptInOutCount;
        }
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsByStateCount'] = $assoArrKolsByStateCount;
        $filterData['arrKolsByCityCount'] = $assoArrKolsByCityCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['arrOrgByTypeCount']	=	$arrOrgByTypeCount;
        $filterData['arrKolByTypeCount']	=	$assoArrKolByTypeCount;
        $filterData['arrRegionCount']	=	$assoRegionCount;
        if(KOL_CONSENT){
            $filterData['arrOptInOutCount']	=	$assoOptInCount;
        }
        
        $filterData['selectedCountries'] = $this->Country_helper->getCountryNameById($arrCountries);
        $filterData['selectedStates'] = $this->Country_helper->getStateNameById($arrStates);
        $filterData['selectedCities'] = $this->Country_helper->getCityNameById($arrCities);
        $filterData['selectedSpecialties'] = $this->Specialty->getSpecialtiesById($arrSpecialties);
        $filterData['selectedOrgs'] = $this->organization->getOrgsById($arrOrganizations);
        $filterData['selectedEdus'] = $this->kol->getInstituteNameById($arrEducations);
        $filterData['selectedEvents'] = $this->kol->getEventNameById($arrEvents);
        $filterData['selectedLists'] = $this->My_list_kol->getListsById($arrLists);
        $filterData['selectedOrgTypes']		= $this->organization->getOrgTypeById($arrOrgTypes);
        if(KOL_CONSENT){
            $filterData['selectedOptInOut']		= $this->kol->getOptNameById($arrOptInOutTypes);
        }
        $selectedVal=array();
        foreach($arrKolTypes as $values){
            $selectedVal[$values]=$values;
        }
        $selectedValRegions=array();
        foreach($arrRegionTypes as $values){
            $selectedValRegions[$values]=$values;
        }
//        pr($selectedValRegions);
        $filterData['selectedKolTypes']		= $selectedVal;
         $filterData['selectedRegionTypes']		= $selectedValRegions;
//        pr( $filterData['selectedKolTypes']	);
        $filterData['selectedKol'] = $arrKolNames;
        $filterData['savedFilterId'] = $savedFilterId;
        $filterData['profileType'] = $profileType;
        $filterData['keyword'] = $keyword;
        $filterData['arrAdvSearchFields'] = "";
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['searchType'] = $searchType;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['searchType'] = "simple";
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $details['filterPage'] = 'search/kol_filters';
        $details['kolResultsPage'] = 'search/kol_search_results';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        $filterData['mapSection'] = '';
        $filterData['customFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        //		pr($filterData['selectedSpecialties']);
        
        $this->load->view('search/kol_filters_li_style', $filterData);
    }

    function adv_search_links() {
        $this->load->model('Event_helper');
        $data['contentPage'] = 'search/event_adv_search';
        $arrConfEventTypes = $this->Event_helper->getAllConferenceEventTypes();
        //	$data['arrConfEventTypes']							= $arrConfEventTypes;
        // Get the list of Conference Session Types
        //	$arrConfSessionTypes								= $this->Event_helper->getAllConferenceSessionTypes();
        //	$data['arrConfSessionTypes']						= $arrConfSessionTypes;
        // Get the list of Online Event Types
        //	$arrOnlineEventTypes 								= $this->Event_helper->getAllOnlineEventTypes();
        //	$data['arrOnlineEventTypes']						= $arrOnlineEventTypes;
        //	$result												= array_unique(array_merge($arrConfEventTypes,$arrConfSessionTypes,$arrOnlineEventTypes));
        $result = $arrConfEventTypes;
        sort($result);
        $key = array_search('Other', $result);
        unset($result[$key]);
        $result[$key] = 'Other';
        $data['arrEventSessionTypes'] = $result;
        $data['arrEventTopics'] = $this->kol->getAllEventTopics();
        //	$data['arrEventRoles']								= $this->kol->getAllEventRoles();
        $data['arrEventRoles'] = $this->kol->getEventRoles();
        $data['arrTrialRoles'] = $this->kol->getAllTrialRoles();
        $this->load->view('search/adv_search_links', $data);
    }

    /**
     *
     * Display page that contains list of Kols,Refune by options,Charts
     * @ACL-Alias Add Client Affiliations
     * @ACL-Discription Display adding 'kol memberships and affiliations' view page
     * @ACL-Category Affiliations
     * @ACL-SubApp client
     *
     *  @author Vinayak
     *  @since 2.2
     *  @creatted on 7-5-2011
     */
    function add_client_affiliations($kolId) {
    	if($this->session->userdata('logged_in')){
    		$data['kolId'] = $kolId;
	        $data['arrMembership'] = array('engagement_id' => '');
	        $this->load->Model('Engagement_type');
	        $arrEngagementTypes = $this->Engagement_type->getAllEngagementTypes();
	        $key = array_search('Other', $arrEngagementTypes);
	        unset($arrEngagementTypes[$key]);
	        $arrEngagementTypes[$key] = 'Other';
	        $data['arrEngagementTypes'] = $arrEngagementTypes;
	        $this->load->view('memberships_affiliations/add_client_affiliations', $data);
    	}
    	else{
    		echo "Session Expired, Please <a href='".base_url()."'>click here</a> to Login";
    	}
        
    }
    
    /*
     *
     * @author Vinayak
     * @since 2.2
     * @creatted on 7-5-2011
     * Display View Page with form fieds to add Event detail
     * @ACL-Alias Add Client Events
     * @ACL-Discription Display View Page with form fieds to add Event detail
     * @ACL-Category Events
     * @ACL-SubApp client
     */

    function add_client_event($kolId) {
        $data['kolId'] = $kolId;
        // Get the list of Conference Event Types
        $this->load->model('Event_helper');
        $arrConfEventTypes = $this->Event_helper->getAllConferenceEventTypes();
        $data['arrConfEventTypes'] = $arrConfEventTypes;
        // Get the list of Conference Session Types
        $arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
        $key = array_search('Other', $arrConfSessionTypes);
        unset($arrConfSessionTypes[$key]);
        $arrConfSessionTypes[$key] = 'Other';
        $data['arrConfSessionTypes'] = $arrConfSessionTypes;

        $data['arrEventSponsorTypes'] = $this->Event_helper->getSponsorTypes();
        $data['arrEventOrganizerTypes'] = $this->Event_helper->getOrganizerTypes();
        $kolId = $this->session->userdata('kolId');
        // Getting the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        // Get the list of Topic belongs to kol specialty
        $arrTopics = $this->kol->getTopicsBySpecialty($arrKolDetail['specialty']);
        $data['arrTopics'] = $arrTopics;
        $data['arrCountry'] = $this->Country_helper->listCountries();

        $data['arrRoles'] = $this->kol->getEventRoles();
        $this->load->view('events/add_client_event', $data);
    }
    
    /**
     * @author Vinayak
     * @since 2.2
     * @creatted on 7-5-2011
     * Display View Page with form fieds to add Edua=cations detail
     * @ACL-Alias Add Client Education
     * @ACL-Discription Display View Page with form fieds to add Eduacations detail
     * @ACL-Category Education
     * @ACL-SubApp client
     */
    function add_client_education($kolId) {
        $data['kolId'] = $kolId;
        $data['locationType'] = array(
            '1' => 'Private practice',
            '2' => 'Hospital',
            '3' => 'Institution',
            '4' => 'Physical',
            '5' => 'Others'
        );
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $this->load->view('education_training/add_client_education', $data);
    }
    function edit_client_education($kolId,$eId,$type) {
        $data['kolId'] = $kolId;
        $data['eId'] = $eId;
        $data['type'] = $type;
        $data['locationType'] = array(
                '1' => 'Private practice',
                '2' => 'Hospital',
                '3' => 'Institution',
                '4' => 'Physical',
                '5' => 'Others'
        );
        $data['arrCountry'] = $this->Country_helper->listCountries();
        $data['eduData'] = $this->kol->getEducationById($eId);       
        $this->load->view('education_training/add_client_education', $data);
    }

    /**
     * Fetches the client added kols personal info and shows, if there is no info then shows add button
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     */
    function view_personal_info($kolId = null) {
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $kolPersonalInfo = array();
        $arrDocuments = array();
        $kolPersonalInfo = $this->kol->getKolPersonalInfo($kolId, $clientId);
        if (sizeof($kolPersonalInfo) > 0) {
            $arrDocuments = $this->kol->getPersonalInfoDocuments($kolPersonalInfo['id']);
        }
        $data['arrDocuments'] = $arrDocuments;
        $data['kolPersonalInfo'] = $kolPersonalInfo;
        $this->load->view('kols/view_personal_info', $data);
    }

    /**
     * Shows the Personal Info Add Form
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     *  @creatted on 7-5-2011
     * Display View Page with form fieds to add Kol Personal detail
     * @ACL-Alias Add Kol Personal Detail
     * @ACL-Discription Display View Page with form fieds to add Kol Personal detail
     * @ACL-Category Kols
     * @ACL-SubApp client
     */
    function add_personal_info() {
        $this->load->view('kols/add_personal_info');
    }

    /**
     * Get the Personal Info details from Form and save it as record with client and kolids
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     */
    function save_personal_info() {
        $this->load->model('calendar');
        $birthdayEventId = 0;
        $anniversaryEventId = 0;
        $kolId = $this->session->userdata('kolId');
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $personalInfoId = $this->input->post('personal_info_id');
        if (isset($personalInfoId) && $personalInfoId != null && $personalInfoId != '') {
            $kolPersonalInfo['id'] = $personalInfoId;
            $kolPersonalInfo['modified_by'] = $userId;
            $kolPersonalInfo['modified_date'] = date("Y-m-d H:i:s");
            $kolPersonalInfo['birthday_event_id'] = $this->input->post('birthday_event_id');
            $kolPersonalInfo['anniversary_event_id'] = $this->input->post('anniversary_event_id');
        } else {
            $kolPersonalInfo['created_by'] = $userId;
            $kolPersonalInfo['created_date'] = date("Y-m-d H:i:s");
            $kolPersonalInfo['birthday_event_id'] = $birthdayEventId;
            $kolPersonalInfo['anniversary_event_id'] = $anniversaryEventId;
        }
        $kolPersonalInfo['kol_id'] = $kolId;
        $kolPersonalInfo['client_id'] = $clientId;
        $kolPersonalInfo['gender'] = $this->input->post('gender');
        $kolPersonalInfo['home_town'] = $this->input->post('home_town');
        $kolPersonalInfo['birthday'] = app_date_to_sql_date($this->input->post('birthday'));
        if ($this->input->post('birthday') == '')
            $kolPersonalInfo['birthday'] = '';
        $kolPersonalInfo['languages'] = $this->input->post('languages');
        $kolPersonalInfo['spouse_name'] = $this->input->post('spouse_name');
        $kolPersonalInfo['anniversary'] = app_date_to_sql_date($this->input->post('anniversary'));
        if ($this->input->post('anniversary') == '')
            $kolPersonalInfo['anniversary'] = '';
        $kolPersonalInfo['children'] = $this->input->post('children');
        $kolPersonalInfo['pets'] = $this->input->post('pets');
        $kolPersonalInfo['home_phone'] = $this->input->post('home_phone');
        $kolPersonalInfo['cell_phone'] = $this->input->post('cell_phone');
        $kolPersonalInfo['IM_screen_name1'] = $this->input->post('IM_screen_name1');
        $kolPersonalInfo['IM_screen_name2'] = $this->input->post('IM_screen_name2');
        $kolPersonalInfo['special_interests'] = $this->input->post('special_interests');
        $kolPersonalInfo['sports'] = $this->input->post('sports');
        $kolPersonalInfo['music'] = $this->input->post('music');
        $kolPersonalInfo['activities'] = $this->input->post('activities');
        $kolPersonalInfo['books'] = $this->input->post('books');
        $kolPersonalInfo['vacation'] = $this->input->post('vacation');
        $kolPersonalInfo['journals'] = $this->input->post('journals');
        $kolPersonalInfo['magazines'] = $this->input->post('magazines');
        //BirthDay and Anniversary reminder calendar events details
        $returnData = array();
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $arrBDEventDetails = array();
        $arrAnnEventDetails = array();
        $arrKolName = $this->kol->getKolName($kolId);
        //BirthDay event details
        $arrBDEventDetails['subject'] = "Birthday: " . $arrKolName['first_name'] . " " . $arrKolName['middle_name'] . " " . $arrKolName['last_name'];
        $arrBDEventDetails['starttime'] = $kolPersonalInfo['birthday'];
        $arrBDEventDetails['endtime'] = $kolPersonalInfo['birthday'];
        $arrBDEventDetails['isalldayevent'] = true;
        $arrBDEventDetails['description'] = "";
        $arrBDEventDetails['location'] = $kolPersonalInfo['home_town'];
        $arrBDEventDetails['color'] = "10";
        $arrBDEventDetails['client_id'] = $clientId;
        $arrBDEventDetails['event_type'] = EVENT_TYPE_BIRTHDAY;
        if ($kolPersonalInfo['birthday_event_id'] != 0) {
            $arrBDEventDetails['id'] = $kolPersonalInfo['birthday_event_id'];
            $arrBDEventDetails['modified_by'] = $userId;
            $arrBDEventDetails['modified_on'] = date("Y-m-d H:i:s");
        } else {
            $arrBDEventDetails['created_by'] = $userId;
            $arrBDEventDetails['created_on'] = date("Y-m-d H:i:s");
        }
        //Anniversary event details
        $arrAnnEventDetails['subject'] = "Anniversary: " . $arrKolName['first_name'] . " " . $arrKolName['middle_name'] . " " . $arrKolName['last_name'];
        $arrAnnEventDetails['starttime'] = $kolPersonalInfo['anniversary'];
        $arrAnnEventDetails['endtime'] = $kolPersonalInfo['anniversary'];
        $arrAnnEventDetails['isalldayevent'] = true;
        $arrAnnEventDetails['description'] = "";
        $arrAnnEventDetails['location'] = $kolPersonalInfo['home_town'];
        $arrAnnEventDetails['color'] = "11";
        $arrAnnEventDetails['client_id'] = $clientId;
        $arrAnnEventDetails['event_type'] = EVENT_TYPE_ANNIVERSARY;
        if ($kolPersonalInfo['anniversary_event_id'] != 0) {
            $arrAnnEventDetails['id'] = $kolPersonalInfo['anniversary_event_id'];
            $arrAnnEventDetails['modified_by'] = $userId;
            $arrAnnEventDetails['modified_on'] = date("Y-m-d H:i:s");
        } else {
            $arrAnnEventDetails['created_by'] = $userId;
            $arrAnnEventDetails['created_on'] = date("Y-m-d H:i:s");
        }
        if (isset($personalInfoId) && $personalInfoId != null && $personalInfoId != '') {
            //Add or Update or Delete BirthDay event
            if ($kolPersonalInfo['birthday'] != '') {
                if ($kolPersonalInfo['birthday_event_id'] != 0)
                    $this->calendar->updateEvent($arrBDEventDetails);
                else
                    $kolPersonalInfo['birthday_event_id'] = $this->calendar->addEvent($arrBDEventDetails);
            }else {
                if ($kolPersonalInfo['birthday_event_id'] != 0) {
                    $this->calendar->deleteEvent($kolPersonalInfo['birthday_event_id']);
                    $kolPersonalInfo['birthday_event_id'] = 0;
                }
            }
            //Add or Update or Delete Anniversary event
            if ($kolPersonalInfo['anniversary'] != '') {
                if ($kolPersonalInfo['anniversary_event_id'] != 0)
                    $this->calendar->updateEvent($arrAnnEventDetails);
                else
                    $kolPersonalInfo['anniversary_event_id'] = $this->calendar->addEvent($arrAnnEventDetails);
            }else {
                if ($kolPersonalInfo['anniversary_event_id'] != 0) {
                    $this->calendar->deleteEvent($kolPersonalInfo['anniversary_event_id']);
                    $kolPersonalInfo['anniversary_event_id'] = 0;
                }
            }
            $this->kol->updatePersonalInfo($kolPersonalInfo);
            $this->update->insertUpdateEntry(KOL_PERSONAL_INFO_UPDATE, $kolPersonalInfo['kol_id'], MODULE_KOL_OVERVIEW, $kolPersonalInfo['kol_id']);
        } else {
            //Add BirthDay event
            if ($kolPersonalInfo['birthday'] != '') {
                $kolPersonalInfo['birthday_event_id'] = $this->calendar->addEvent($arrBDEventDetails);
            }
            //Add Anniversary event
            if ($kolPersonalInfo['anniversary'] != '') {
                $kolPersonalInfo['anniversary_event_id'] = $this->calendar->addEvent($arrAnnEventDetails);
            }
            $newPersonalInfoId = $this->kol->savePersonalInfo($kolPersonalInfo);
            $this->update->insertUpdateEntry(KOL_PERSONAL_INFO_ADD, $kolPersonalInfo['kol_id'], MODULE_KOL_OVERVIEW, $kolPersonalInfo['kol_id']);
            $personalInfoId = $newPersonalInfoId;
        }

        /* $config['upload_path'] 									= 'documents/kol_personal_documents';
          $config['allowed_types']								= 'xls|doc|ppt|xlsx|docx|pptx|pdf|txt|rtf|bmp|jpg|jpeg|gif|png|odt|mp3|mp4|avi|dat|wav|mpg|mpeg|wmv|mov|tiff|zip|rar|tar|tgz|htm';
          $config['max_size']										= '2048';
          $maxFileUploads 										= 5;
          $arrDocuments											= $this->kol->getPersonalInfoDocuments($personalInfoId); */
        $numOfFiles = (int) $this->input->post('no_of_files');
        $numOfFiles = ($numOfFiles - sizeof($arrDocuments));

        $target_path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "/documents/kol_personal_documents";
        for ($i = 1; $i <= $numOfFiles; $i++) {
            //Proceed only if the uploaded file name is not blank
            if ($_FILES["file_path" . $i]['name'] != null && $_FILES["file_path" . $i]['name'] != "") {
                //Get the file information, use for file validations like allowed file type, file size etc
                $path_info = pathinfo($_FILES["file_path" . $i]['name']);
                $path_info['size'] = $_FILES["file_path" . $i]['size'];
                //Generate a randome name
                $newFileName = random_string('unique', 20) . "." . $path_info['extension'];
                $overview_file_target_path = $target_path . "/" . $newFileName;
                //Move uploaded file in to interactions document location
                if (move_uploaded_file($_FILES['file_path' . $i]['tmp_name'], $overview_file_target_path)) {
                    $arrDocDetails = array();
                    $arrDocDetails['personal_info_id'] = $personalInfoId;
                    $arrDocDetails['doc_name'] = $this->input->post('doc_name' . $i);
                    if (empty($arrDocDetails['doc_name'])) {
                        $arrDocDetails['doc_name'] = str_replace("." . $path_info['extension'], $_FILES["file_path" . $i]['name']);
                    }
                    $arrDocDetails['description'] = $this->input->post('description' . $i);
                    $arrDocDetails['doc_path'] = $newFileName;
                    $arrDocDetails['created_by'] = $userId;
                    $arrDocDetails['created_on'] = date('Y-m-d H:i:s');
                    $this->kol->savePersonalInfoDocument($arrDocDetails);
                } else {
                    echo "Error";
                }
            }
        }
        redirect(base_url() . 'kols/view/' . $kolId . '/personalinfo');
    }

    /**
     * Get the Kol Personal Info details of this client for edit and repopulate in form
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 06-05-2011
     */
    function edit_personal_info() {
        $kolId = $this->session->userdata('kolId');
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $kolPersonalInfo = array();
        $kolPersonalInfo = $this->kol->getKolPersonalInfo($kolId, $clientId);
        $arrDocuments = $this->kol->getPersonalInfoDocuments($kolPersonalInfo['id']);
        $data['arrDocuments'] = $arrDocuments;
        $data['kolPersonalInfo'] = $kolPersonalInfo;
        $this->load->view('kols/add_personal_info', $data);
    }

    /**
     * Deletes the kol personal info document given document id
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 06-05-2011
     */
    function delete_personal_info_doc($documentId) {
        $isDeleted = false;
        $isDeleted = $this->kol->deletePersonalInfoDocument($documentId);
        echo $isDeleted;
    }

    /**
     * Reads the given file from server and and downloads into browser
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 06-05-2011
     */
    function download_file($fileName) {
        $this->load->helper('download');
        // Read the contents of the file
        $data = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName);
        force_download($fileName, $data);
    }

    /**
     * Retrives the data required for the kols checkbox's kind of filters (search results)
     * @author 	Ramesh B
     * @since	2.4
     * @return
     * @created 07-06-2011
     */
    function reload_adv_filters() {
        ini_set("max_execution_time", 7200);
        $page = $this->input->post('page');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $arrFilterFields = array();
        $searchType = '';
        $keyword = '';
        //		if($page>0){
        //			$keywords											= $this->session->userdata('keywords');
        //			$arrFilterFields									= $this->session->userdata('arrFilterFields');
        //			$arrAdvSearchFields									= $this->session->userdata('arrAdvSearchFields');
        //		}
        //		else{

        $orgType = trim($this->input->post('org_type_id'));
        $kolType = trim($this->input->post('kol_type_id'));
        $regionType = trim($this->input->post('region_type_id'));
         $topicType = trim($this->input->post('topic_type_id'));
        $searchType = trim($this->input->post('search_type'));
        $keywords = trim($this->input->post('keywords'));
        $firstName = trim($this->input->post('first_name'));
        $middleName = trim($this->input->post('middle_name'));
        $lastName = trim($this->input->post('last_name'));
        $specialty = trim($this->input->post('specialty_id'));
        $subSpecialty = trim($this->input->post('sub_specialty '));
        $country = trim($this->input->post('country_id'));
        $state = trim($this->input->post('state_id'));
        $organization = trim($this->input->post('organization_id'));
        $title = trim($this->input->post('title'));
        $postalCode = trim($this->input->post('postal_code'));
        $education = trim($this->input->post('education_id'));
        $eventName = trim($this->input->post('event_name_id'));
        $listName = trim($this->input->post('list_name_id'));
        $profileType = trim($this->input->post('profileType'));
        $viewTypeMyKols = trim($this->input->post('viewTypeMyKols'));
        $arrAdvSearchFields['pkeywords'] = trim($this->input->post('pkeywords'));
        $arrAdvSearchFields['pauthpos'] = trim($this->input->post('pauthpos'));
        $arrAdvSearchFields['pqtype'] = trim($this->input->post('pqtype'));
        $arrAdvSearchFields['etopic'] = trim($this->input->post('etopic'));
        $arrAdvSearchFields['erole'] = trim($this->input->post('erole'));
        $arrAdvSearchFields['eqtype'] = trim($this->input->post('eqtype'));
        $arrAdvSearchFields['tkeywords'] = trim($this->input->post('tkeywords'));
        $arrAdvSearchFields['trole'] = trim($this->input->post('trole'));
        $arrAdvSearchFields['tqtype'] = trim($this->input->post('tqtype'));
        $arrAdvSearchFields['keywords'] = $keywords;
        $arrAdvSearchFields['first_name'] = $firstName;
        $arrAdvSearchFields['middle_name'] = $middleName;
        $arrAdvSearchFields['last_name'] = $lastName;
        $arrAdvSearchFields['sub_specialty'] = $subSpecialty;
        $arrAdvSearchFields['title'] = $title;
        $arrAdvSearchFields['postal_code'] = $postalCode;
        $arrAdvSearchFields['profileType'] = $profileType;
        $arrAdvSearchFields['memebers'] =  trim($this->input->post('members'));
        foreach ($arrAdvSearchFields as $index => $value) {
            $value = trim($value);
            if (empty($value)) {
                unset($arrAdvSearchFields[$index]);
            }
        }

        if (trim($this->input->post('savedFilterId')) != 0) {
            $searchType = 'advanced';
        }
        //Get all the selected checkboxs details for respective category
        $arrCountries = $this->input->post('countries');
        if ($arrCountries != '')
            $arrCountries = explode(",", $arrCountries);
        //if the input field is not blank add the value in to respective category array values
        if ($country != '')
            $arrCountries[] = $country;

        $arrStates = $this->input->post('states');
        if ($arrStates != '')
            $arrStates = explode(",", $arrStates);
        //if the input field is not blank add the value in to respective category array values
        if ($state != '')
            $arrStates[] = $state;

        $arrSpecialties = $this->input->post('specialties');
        if ($arrSpecialties != '')
            $arrSpecialties = explode(",", $arrSpecialties);
        if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations[] = $organization;
        }
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        $arrOrgTypes = $this->input->post('org_types');
        if ($arrOrgTypes != '')
            $arrOrgTypes = explode(",", $arrOrgTypes);
        if ($orgType != '') {
            $arrOrgTypes[] = $orgType;
        }
        $arrKolTypes = $this->input->post('kol_types');
        if ($arrKolTypes != '')
            $arrKolTypes = explode(",", $arrKolTypes);
        if ($kolType != '') {
            $arrKolTypes[] = $kolType;
        }
        $arrRegionTypes = $this->input->post('region_types');
        if ($arrRegionTypes != '')
            $arrRegionTypes = explode(",", $arrRegionTypes);
        if ($regionType != '') {
            $arrRegionTypes[] = $regionType;
        }
        $arrTopicTypes = $this->input->post('topic_types');
        if ($arrTopicTypes != '')
            $arrTopicTypes = explode(",", $arrTopicTypes);
        if ($topicType != '') {
            $arrTopicTypes[] = $topicType;
        }
        $arrAdvSearchFields['specialty'] = $arrSpecialties;
        $arrAdvSearchFields['country'] = $arrCountries;
        $arrAdvSearchFields['state'] = $arrStates;
        $arrAdvSearchFields['organization'] = $arrOrganizations;
        $arrAdvSearchFields['education'] = $arrEducations;
        $arrAdvSearchFields['event_name'] = $arrEvents;
        $arrAdvSearchFields['list_id'] = $arrLists;
        $arrAdvSearchFields['type'] = $arrOrgTypes;
        $arrAdvSearchFields['kol_titles'] = $arrKolTypes;
        $arrAdvSearchFields['region'] = $arrRegionTypes;
         $arrAdvSearchFields['topic'] = $arrTopicTypes;
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $arrAdvSearchFields['viewType'] = $viewMyKols;
            } else {
                $arrAdvSearchFields['viewType'] = array(0);
            }
        }
        //		}
        //Get count of kols grouping by category(for each category)
        $arrKolsCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, false);
        $arrKolsByCountryCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'country');
        $arrKolsByStateCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'state');
        $arrKolsBySpecialtyCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
        $arrKolsByOrgCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
        $arrKolsByEduCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'education');
        $arrKolsByEventCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'event');
        $arrKolsByListCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'list');
        $arrOrgByTypeCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'type');
        $arrKolByTypeCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'title');
        $arrRegionCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'region');

                $arrTopicCount = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'topic');

//Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allOrgTypeCount = 0;
        $assoArrOrgByTypeCount = array();
        foreach ($arrOrgByTypeCount as $row) {
            $assoArrOrgByTypeCount[$row['org_type_id']] = $row;
            $allOrgTypeCount+=$row['count'];
        }
        $allKolTypeCount = 0;
        $assoArrKolByTypeCount = array();
        foreach ($arrKolByTypeCount as $row) {
            $assoArrKolByTypeCount[$row['title']] = $row;
            $allKolTypeCount+=$row['count'];
        }
        $allRegionCount = 0;
        $assoRegionCount = array();
        foreach ($arrRegionCount as $row) {
            $assoRegionCount[$row['region_type_id']] = $row;
            $allRegionCount+=$row['count'];
        }

         $allTopicCount = 0;
        $assoTopicCount = array();
        foreach ($arrTopicCount as $row) {
            $assoTopicCount[$row['name']] = $row;
            $allTopicCount+=$row['count'];
        }



        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country_id']] = $row;
            $allCountryCount += $row['count'];
        }
        $allStateCount = 0;
        $assoArrKolsByStateCount = array();
        foreach ($arrKolsByStateCount as $row) {
            $assoArrKolsByStateCount[$row['state_id']] = $row;
            $allStateCount += $row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specialty']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['org_id']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_id']] = $row;
            $allEduCount += $row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_name_id']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allOrgTypeCount'] = $allOrgTypeCount;
        $filterData['allkolTypeCount'] = $allKolTypeCount;
        $filterData['allRegionCount'] = $allRegionCount;
         $filterData['allTopicCount'] = $allTopicCount;
        $filterData['allListCount'] = $allListCount;
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsByStateCount'] = $assoArrKolsByStateCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['arrOrgByTypeCount'] = $arrOrgByTypeCount;
        $filterData['arrKolByTypeCount'] = $assoArrKolByTypeCount;
        $filterData['arrRegionCount'] = $assoRegionCount;
          $filterData['arrTopicCount'] = $assoTopicCount;
          
//          pr($assoTopicCount);
        $filterData['selectedOrgTypes'] = $this->organization->getOrgTypeById($arrOrgTypes);


        $selectedVal = array();
        foreach ($arrKolTypes as $values) {
            $selectedVal[$values] = $values;
        }
        $selectedValRegions = array();
        foreach ($arrRegionTypes as $values) {
            $selectedValRegions[$values] = $values;
        }
         $selectedValTopics = array();
        foreach ($arrTopicTypes as $values) {
            $selectedValTopics[$values] = $values;
        }
        $filterData['selectedKolTypes'] = $selectedVal;
        $filterData['selectedRegionTypes'] = $selectedValRegions;
         $filterData['selectedTopicTypes'] = $selectedValTopics;
//        pr( $filterData['selectedKolTypes']	);
        $filterData['selectedCountries'] = $this->Country_helper->getCountryNameById($arrCountries);
        $filterData['selectedStates'] = $this->Country_helper->getStateNameById($arrStates);
        $filterData['selectedSpecialties'] = $this->Specialty->getSpecialtiesById($arrSpecialties);
        $filterData['selectedOrgs'] = $this->organization->getOrgsById($arrOrganizations);
        $filterData['selectedEdus'] = $this->kol->getInstituteNameById($arrEducations);
        $filterData['selectedEvents'] = $this->kol->getEventNameById($arrEvents);
        $filterData['selectedLists'] = $arrLists;
        $filterData['profileType'] = $profileType;
        $filterData['keyword'] = "";
        $filterData['searchType'] = $searchType;
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $filterData['customFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $filterData['savedFilterId'] = trim($this->input->post('savedFilterId'));
        $this->load->view('search/kol_filters_li_style', $filterData);
    }

    /*
     *  Retrives the data required for the all Charts checkbox's kind of filters
     * 	@since 2.4
     *  @author Vinayak
     *  @created 31-5-2011
     *
     */

    function reload_report_filter() {
        ini_set("max_execution_time", 7200);
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $arrList = array();
        $arrListNamesIds = array();
        $reportSection1 = $this->input->post('reportSection');
        $chartType = ($this->input->post('chartType') == null) ? 0 : $this->input->post('chartType');
        //Alternative session storage
        $arrrefinedByFilter = array();
        $arrrefinedByFilter['fromYear'] = ($this->input->post('from_year') == null) ? 0 : $this->input->post('from_year');
        $arrrefinedByFilter['toYear'] = ($this->input->post('to_year') == null) ? 0 : $this->input->post('to_year');
        $arrrefinedByFilter['arrKolNames'] = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == null) ? 0 : $this->input->post('kol_id'));
        $arrrefinedByFilter['selected_kol_id'] = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrrefinedByFilter['arrGlobalRegions'] = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == null) ? 0 : $this->input->post('global_region'));
        $arrrefinedByFilter['arrSpecialities'] = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == null) ? 0 : $this->input->post('specialty'));
        $arrrefinedByFilter['arrCountries'] = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == null) ? 0 : $this->input->post('country'));
        $arrrefinedByFilter['arrStates'] = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == null) ? 0 : $this->input->post('state'));
        $arrrefinedByFilter['arrListNames'] = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == null) ? 0 : $this->input->post('listName'));
        $arrrefinedByFilter['profileType'] = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');

        $arrrefinedByFilter['savedFilterId'] = ($arrFilterById['id']) ? $arrFilterById['id'] : 0;
        //		pr($arrrefinedByFilter);
        $data['totalGlobalRegionCount'] = 0;
        $data['totalSpecialtyCount'] = 0;
        $data['totalCountryCount'] = 0;
        $data['totalStateCount'] = 0;
        $data['totalListCount'] = 0;
        /*if ($this->session->userdata('reportSection') == $reportSection1) {
            $this->session->set_userdata('filterContent', $arrrefinedByFilter);
        } else {
            $this->session->set_userdata('reportSection', $this->input->post('reportSection'));
        } */       
           
        //$arrfilterdata = $this->session->userdata('filterContent');
        $arrfilterdata = $arrrefinedByFilter;
        $fromYear = $arrfilterdata['fromYear'];
        $toYear = $arrfilterdata['toYear'];
        $arrKolNames = $arrfilterdata['arrKolNames'];
        $selected_kol_id = $arrfilterdata['selected_kol_id'];
        $arrGlobalRegions = $arrfilterdata['arrGlobalRegions'];
        $arrSpecialities = $arrfilterdata['arrSpecialities'];
        $arrCountries = $arrfilterdata['arrCountries'];
        //$arrStates								= $arrfilterdata['arrStates'];
        $arrStatesIds = $arrfilterdata['arrStates'];
        $arrListNames = $arrfilterdata['arrListNames'];
        $profileType = $arrfilterdata['profileType'];
		
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
        	if (!is_array($arrGlobalRegions))
        		$arrGlobalRegionIds = explode(",", $arrGlobalRegions);
        		else
        		$arrGlobalRegionIds = $arrGlobalRegions;
        }
        if ($arrSpecialities != '0' && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
            else
                $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != '0' && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
            else
                $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != '0' && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
            else
                $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $selected_kol_id;
            else
                $kolIds = $arrKolNames;
        }else {
            $kolIds = $selected_kol_id;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrCountries))
                $arrListNamesIds = explode(",", $arrListNames);
            else
                $arrListNamesIds = $arrListNames;
        }

        $reportSection = '';
        switch ($chartType) {
            case 'Kols By Country' :
            case 'Kols By Publications' :
            case 'Kols By Speciality' :
            case 'Kols By Activity' :
                $reportSection = 'activity';
                //				$data['totalKolsCount']		= $this->kol->getAllKolsCount();
                //				$data['totalListCount']		= $this->kol->getAllListKolsCount();
                break;
            case 'Events By Timeline' :
            case 'Events By Session Type' :
            case 'Kols By EventType' :
            case 'Events By Role' :
                $reportSection = 'events';
                break;
            case 'Affiliations By Org Type':
            case 'Affiliations By Eng Type':
                $reportSection = 'affiliations';
                break;
            case 'Publications By Year' :
            case 'Publications By Keywords' :
            case 'Publications By Journals' :
            case 'Publications By Substances' :
            case 'Publications By Type' :
                $reportSection = 'publications';
                break;
            case 'Scattered  Diagram':
                $reportSection = 'segmentation';
                $data['totalKolsCount'] = $this->kol->getAllKolsCount();
                break;
        }
        $viewType = array();
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
                $arrfilterdata['viewType'] = $viewMyKols;
            } else {
                //$viewType = array(0);
                $arrfilterdata['viewType'] = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
       //$data['arrRegions'] = $this->kol->getAllSpecialties($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewType);
        $data['arrSpacialties'] = $this->kol->getAllSpecialties($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        $data['arrGlobalRegions'] = $this->Country_helper->listGlobalRegionsAndCount($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        $data['arrCountries'] = $this->Country_helper->listCountriesAndCount($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        $data['arrStates'] = $this->Country_helper->listStatesAndCount($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
		
        $stateId = $this->input->post('state_id');
        if (!array_key_exists($stateId, $data['arrStates'])) {
            $stateName = $this->Country_helper->getStateNameById($stateId);
            $data['arrStates'][$stateId] = array('state_name' => $stateName[$stateId], 'count' => 0);
        }
        $data['arrKolDetails'] = $this->kol->getAllkols($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType,$viewTypeMyKols);
        $data['arrListName'] = $this->My_list_kol->getAllListNamesAndCount($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $kolIds, $arrListNamesIds, $reportSection, $chartType, $arrStatesIds, $profileType, $viewTypeMyKols, $arrGlobalRegionIds,$arrfilterdata);
        $data['viewType'] = $viewTypeMyKols;
        switch ($reportSection) {
            case 'events':
            case 'affiliations':
            case 'publications':
            case 'activity':
            case 'segmentation':
            	$totalGlobalRegionCount = 0;
                $totalSpecialtyCount = 0;
                $totalCountryCount = 0;
                $totalStateCount = 0;
                $totalListCount = 0;
                foreach ($data['arrGlobalRegions'] as $arrGlobalRegion => $arrRowData) {
                	$totalGlobalRegionCount += $arrRowData['count'];
                }
                foreach ($data['arrSpacialties'] as $arrSpecialty => $arrRowData) {
                    $totalSpecialtyCount += $arrRowData['count'];
                }
                foreach ($data['arrCountries'] as $arrCountry => $arrRowData) {
                    $totalCountryCount += $arrRowData['count'];
                }
                foreach ($data['arrStates'] as $arrState => $arrRowData) {
                    $totalStateCount += $arrRowData['count'];
                }
                foreach ($data['arrListName'] as $arrLists => $arrRowData) {
                    $totalListCount += $arrRowData['count'];
                }
                $data['totalGlobalRegionCount'] = $totalGlobalRegionCount;
                $data['totalSpecialtyCount'] = $totalSpecialtyCount;
                $data['totalCountryCount'] = $totalCountryCount;
                $data['totalStateCount'] = $totalStateCount;
                $data['totalListCount'] = $totalListCount;
                break;
        }

        $data['selectedKol'] = $arrKolNames;
        $data['startDate'] = $fromYear;
        $data['endDate'] = $toYear;
        $data['reportSection'] = $reportSection1;
        $data['customFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $data['arrfilterdata'] = $arrfilterdata;
        $this->load->view('reports/report_filter_li_style', $data);
    }

    /*
     * Returns the list of kol Names, based on Kol Name
     * @author Vinayak
     * @since 2.4
     * @created 3-6-2011
     * @param $kolName
     *
     */

    function get_kol_names_for_autocomplete($kolName) {
    	
        $kolName = utf8_urldecode($this->input->post($kolName));
        $kolName = $this->db->escape_like_str($kolName);
        $arr['query'] = $kolName;
        $arr['suggestions'] = '';
        
        $arrKolNames1 = array();
        $arrKolNames = $this->interaction->getAllKolNamesForAutocomplete($kolName);
        $flag = 1;
        foreach ($arrKolNames['kols'] as $key => $row) {
            $cityState=$row[2];
            if(isset($row[2]) && isset($row[3]))
                 $cityState.= ', ';
             $cityState.=$row[3];
            $donotcall = '<span style="color: red">' . $row['do_not_call_flag'] . '</span>';
            if ($flag) {
                $arrKolNames1[] = '<div class="autocompleteHeading">Contacts</div><div class="dataSet"><label name="' . $row[0] . '" class="kolName" style="display:block">' . $row[0] . "</label><p class='orgName'>" . $row[1] . " " .$cityState. "</p>" . $donotcall . "<span style='display:none' class='id1'>" . $key . "</span></div>";
                $flag = 0;
            } else {
                $arrKolNames1[] = '<div class="dataSet"><label name="' . $row[0] . '" class="kolName" style="display:block">' . $row[0] . "</label><p class='orgName'>" . $row[1] . " " . $cityState. "</p>" . $donotcall . "<span style='display:none' class='id1'>" . $key . "</span></div>";
            }
        }
        $flag = 0;
        foreach ($arrKolNames['customers'] as $key => $row) {
             $cityState=$row[2];
            if(isset($row[2]) && isset($row[3]))
                 $cityState.= ', ';
             $cityState.=$row[3];
            $donotcall = '<span style="color: red">' . $row['do_not_call_flag'] . '</span>';
            if (!$flag && ($this->loggedUserId>0)) {
                $arrKolNames1[] = "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1] $cityState</p>" . $donotcall . "<span style='display:none' class='id1'>$key</span></div>";
                $flag = 1;
            } else {
            	if($this->loggedUserId>0)
                $arrKolNames1[] = "<div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1] $cityState</p>" . $donotcall . "<span style='display:none' class='id1'>$key</span></div>";
            }
        }
        if ((sizeof($arrKolNames['kols']) < 1) && (sizeof($arrKolNames['customers']) < 1) && ($this->loggedUserId>0)) {
            $arrKolNames1[] = "<div style='padding-left:5px;'>No results found for " . str_replace(')', '', $kolName) . "</div><div><label name='No results found for " . $kolName . "' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
        }
        
        if(!$this->loggedUserId>0){
        	$arrKolNames1[] = "<div style='padding-left:5px;padding-top: 5px;padding-bottom: 5px;'>Session is expired, please <a href='".base_url()."'>click here</a> to login</div>";
        }
        $arr['suggestions'] = $arrKolNames1;
        echo json_encode($arr);
    }

    /*
     * To  get country name and their counts for charts
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     *
     */

    function get_countries() {
        $organization = trim($this->input->post('organization'));
        $specialty = trim($this->input->post('specialty'));
        $country = trim($this->input->post('country'));
        $arrCountries = $this->input->post('countries');
        $education = trim($this->input->post('education'));
        $eventName = trim($this->input->post('event_name'));
        $listName = trim($this->input->post('list_name'));
        $kolName = trim($this->input->post('kol_name'));
        if ($arrCountries != '') {
            if ($country != '') {
                $arrCountries .=',' . $country;
            }
            $arrCountries = explode(",", $arrCountries);
        } else if ($country != '') {
            $arrCountries[] = $country;
        }
        $arrSpecialties = $this->input->post('specialties');
        if ($arrSpecialties != '') {
            if ($specialty != '') {
                $arrSpecialties .=',' . $specialty;
            }
            $arrSpecialties = explode(",", $arrSpecialties);
        } else if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }

        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations1 = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations1[] = $this->organization->getOrgIdByOrgName($organization);
        }
        $arrOrganizations = array();
        if (sizeof($arrOrganizations1) > 0) {
            foreach ($arrOrganizations1 as $key => $orgId) {
                $arrOrganizations[$orgId] = $this->organization->getOrgNameByOrgId($orgId);
            }
        } else {
            $arrOrganizations = '';
        }
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        $arrKolNames = $this->input->post('kols');
        if ($arrKolNames != '')
            $arrKolNames = explode(",", $arrKolNames);
        if ($kolName != '') {
            $arrKolNames[] = $kolName;
        }

        if ($arrKolNames != '' && $arrKolNames != 0) {
            foreach ($arrKolNames as $kolName) {
                //$kolName			= str_replace(' ','',$kolName);
                $arrKolIds[] = $this->kol->getKolId($kolName);
            }
        } else {
            $arrKolIds = '';
        }
        //$arrCountries=$this->kol->getKolsByParam1($arrCountries,$arrSpecialties,$arrOrganizations,$arrEvents,$arrEducations,$arrLists);
        $arrCountries = $this->kol->getCountries($arrCountries, $arrSpecialties, $arrOrganizations, $arrEvents, $arrEducations, $arrLists, $arrKolIds);
        $arrCountryCount = array();
        foreach ($arrCountries as $row) {
            $arrCountryCount[] = array($row['country'], (int) $row['count']);
        }
        echo json_encode($arrCountryCount);
    }

    /*
     * To  getspecialty name and their counts for charts
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     *
     */

    function get_specialties() {
        $organization = trim($this->input->post('organization'));
        $arrSpecialties = $this->input->post('specialties');
        $specialty = trim($this->input->post('specialty'));
        $country = trim($this->input->post('country'));
        $arrCountries = $this->input->post('countries');
        $education = trim($this->input->post('education'));
        $eventName = trim($this->input->post('event_name'));
        $listName = trim($this->input->post('list_name'));
        $kolName = trim($this->input->post('kol_name'));
        if ($arrCountries != '') {
            if ($country != '') {
                $arrCountries .= ',' . $country;
            }
            $arrCountries = explode(",", $arrCountries);
        } else if ($country != '') {
            $arrCountries[] = $country;
        }
        if ($arrSpecialties != '') {
            if ($specialty != '') {
                $arrSpecialties .=',' . $specialty;
            }
            $arrSpecialties = explode(",", $arrSpecialties);
        } else if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations1 = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations1[] = $this->organization->getOrgIdByOrgName($organization);
        }
        $arrOrganizations = array();
        if (sizeof($arrOrganizations1) > 0) {
            foreach ($arrOrganizations1 as $key => $orgId) {
                $arrOrganizations[$orgId] = $this->organization->getOrgNameByOrgId($orgId);
            }
        } else {
            $arrOrganizations = '';
        }
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('lists');
        if ($arrLists != '')
            $arrLists = explode(",", $arrLists);
        if ($listName != '') {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        $arrKolNames = $this->input->post('kols');
        if ($arrKolNames != '')
            $arrKolNames = explode(",", $arrKolNames);
        if ($kolName != '') {
            $arrKolNames[] = $kolName;
        }
        if ($arrKolNames != '' && $arrKolNames != 0) {
            foreach ($arrKolNames as $kolName) {
                //$kolName					= str_replace(' ','',$kolName);
                $arrKolIds[] = $this->kol->getKolId($kolName);
            }
        } else {
            $arrKolIds = '';
        }
        //$arrSpecialty=$this->kol->getKolsByParam2($arrCountries,$arrSpecialties,$arrOrganizations,$arrEvents,$arrEducations,$arrLists);
        $arrSpecialty = $this->kol->getSpecialties($arrCountries, $arrSpecialties, $arrOrganizations, $arrEvents, $arrEducations, $arrLists, $arrKolIds);
        $arrSpecialtyCount = array();
        foreach ($arrSpecialty as $row) {
            $arrSpecialtyCount[] = array($row['specialty'], (int) $row['count']);
        }
        echo json_encode($arrSpecialtyCount);
    }

    /**
     * Retrives the data required for the Events checkbox's kind of filters
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     */
    function reload_event_filters() {
        $arrFilterFields = array();
        $page = $this->input->post('page');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $searchType = '';
        $keyword = '';
        $arrCountries = array();
        $arrSpecialties = array();
        if ($page > -1) {
            $keyword = $this->session->userdata('keyword');
            $arrFilterFields = $this->session->userdata('arrFilterFields');
        } else {
            $searchType = $this->input->post('search_type');
            $keyword = $this->input->post('keyword');
            $specialty = trim($this->input->post('specialty'));
            $country = trim($this->input->post('country'));
            $state = trim($this->input->post('state'));
            $organization = trim($this->input->post('organizer'));
            $role = trim($this->input->post('role'));
            $listName = trim($this->input->post('list_name'));
            $arrCountries = $this->input->post('countries');
            if ($arrCountries != '')
                $arrCountries = explode(",", $arrCountries);
            if ($country != '')
                $arrCountries[] = $country;
            $arrStates = $this->input->post('state');
            if ($arrStates != '')
                $arrStates = explode(",", $arrStates);
            if ($state != '')
                $arrStates[] = $state;

            //echo $specialty;
            $arrSpecialties = $this->input->post('specialties');
            if ($arrSpecialties != '')
                $arrSpecialties = explode(",", $arrSpecialties);
            if ($specialty != '') {
                $arrSpecialties[] = $specialty;
            }
            $arrOrganizations = $this->input->post('organizers');
            if ($arrOrganizations != '')
                $arrOrganizations = explode(",", $arrOrganizations);
            if ($organization != '') {
                $arrOrganizations[] = $organization;
            }
            $arrRoles = $this->input->post('roles');
            if ($arrRoles != '')
                $arrRoles = explode(",", $arrRoles);
            if ($role != '') {
                $arrRoles[] = $role;
            }
            $arrLists = $this->input->post('lists');
            if ($arrLists != '')
                $arrLists = explode(",", $arrLists);
            if ($listName != '') {
                if (stripos($listName, '(')) {
                    $arrListDetails = explode("(", $listName);
                    $listName = trim($arrListDetails[0]);
                    $categoryName = trim($arrListDetails[1], ") ");
                    $listName = $this->My_list_kol->getListName($listName, $categoryName);
                }
                $arrLists[] = $listName;
            }
            //Prepare array of filter fields, ehich will be used for querying
            $arrFilterFields['specialty'] = $arrSpecialties;
            $arrFilterFields['country'] = $arrCountries;
            $arrFilterFields['state'] = $arrStates;
            $arrFilterFields['organizer'] = $arrOrganizations;
            $arrFilterFields['role'] = $arrRoles;
            $arrFilterFields['list_id'] = $arrLists;
        }
        //Split the keyword by 'comma' or '+' or 'space'
        $arrKeywords = explode("+", $keyword);
        // We can modify the below logic so as to use the single 'or' and 'and' methods by
        //sending the array of keyword names and enbling the where condition based on the
        //size of the array in those methods
        if (sizeof($arrKeywords) == 1) {
            $name = $keyword;
            $arrAdvSearchFields['type'] = trim($this->input->post('type'));
            $arrAdvSearchFields['role'] = trim($this->input->post('eventRole'));
            $arrAdvSearchFields['country'] = trim($this->input->post('evntCountry'));
            $arrAdvSearchFields['state'] = trim($this->input->post('evntState'));
            $arrAdvSearchFields['organizer'] = trim($this->input->post('evntOrganizer'));
            $arrEventsByCountryCount = $this->kol->getMatchEvents($keyword, $arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'country');
            $arrEventsByStateCount = $this->kol->getMatchEvents($keyword, $arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'state');
            $arrEventsByOrgCount = $this->kol->getMatchEvents($keyword, $arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'organizer');
            $arrEventsByRoleCount = $this->kol->getMatchEvents($keyword, $arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'role');
        }

        //Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
        $this->session->set_userdata('keyword', $keyword);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrEventsByCountryCount = array();
        foreach ($arrEventsByCountryCount as $row) {
            $assoArrEventsByCountryCount[$row['country']] = $row;
            $allCountryCount += $row['count'];
        }
        $allStateCount = 0;
        $assoArrEventsByStateCount = array();
        foreach ($arrEventsByStateCount as $row) {
            $assoArrEventsByStateCount[$row['state']] = $row;
            $allStateCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrEventsByOrgCount = array();
        foreach ($arrEventsByOrgCount as $row) {
            $assoArrEventsByOrgCount[$row['organizer']] = $row;
            $allOrgCount += $row['count'];
        }
        $allRoleCount = 0;
        $assoArrEventsByRoleCount = array();
        foreach ($arrEventsByRoleCount as $row) {
            $assoArrEventsByRoleCount[$row['role']] = $row;
            $allRoleCount += $row['count'];
        }
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allRoleCount'] = $allRoleCount;
        $filterData['arrEventsByCountryCount'] = $assoArrEventsByCountryCount;
        $filterData['arrEventsByStateCount'] = $assoArrEventsByStateCount;
        $filterData['arrEventsByOrgCount'] = $assoArrEventsByOrgCount;
        $filterData['arrEventsByRoleCount'] = $assoArrEventsByRoleCount;
        $filterData['selectedCountries'] = $arrCountries;
        $filterData['selectedStates'] = $arrStates;
        $filterData['selectedOrgs'] = $arrOrganizations;
        $filterData['selectedRoles'] = $arrRoles;
        $filterData['keyword'] = $keyword;
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['searchType'] = $searchType;
        $eventResultsData['searchType'] = "simple";
        $eventResultsData['eventsCount'] = $count;
        $eventResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $keyword);
        $details['filterPage'] = 'search/event_filters';
        $details['eventResultsPage'] = 'search/event_search_results';
        $details['eventResultsData'] = $eventResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/event_results';
        $this->load->view('search/event_filters', $filterData);
    }

    /**
     * Connects to the givenn rss feed url and parses the xml data and returns the rss feeds as a array
     * @author 	Ramesh B
     * @since	2.5
     * @created 25-06-2011
     */
    function get_rss_data($rssUrl) {
        $doc = new DOMDocument();
        $doc->load($rssUrl);
        $arrFeeds = array();
        $arrDetails = array();
        $i = 0;
        foreach ($doc->getElementsByTagName('item') as $node) {
            $titleObj = $node->getElementsByTagName('title')->item(0);
            if ($titleObj != null) {
                $itemRSS['title'] = $titleObj->nodeValue;
                $itemRSS['desc'] = "";
                $itemRSS['link'] = "";
                $itemRSS['date'] = "";
                $descObj = $node->getElementsByTagName('description')->item(0);
                if ($descObj != null)
                    $itemRSS['desc'] = $descObj->nodeValue;
                if ($rssUrl == "http://rss.biospace.com/newsstory.rss")
                    $itemRSS['desc'] = strip_tags($itemRSS['desc']);
                $linkObj = $node->getElementsByTagName('link')->item(0);
                if ($linkObj != null)
                    $itemRSS['link'] = $linkObj->nodeValue;
                $dateObj = $node->getElementsByTagName('pubDate')->item(0);
                if ($dateObj != null)
                    $itemRSS['date'] = $dateObj->nodeValue;
            }
            array_push($arrFeeds, $itemRSS);
            $arrDetails[] = $itemRSS;
            if ($i >= 4)
                break;
            $i++;
        }
        return $arrDetails;
    }

    /**
     * Gets the all the topics belogs to given specialty and returns as a JSON Data
     * @author 	Ramesh B
     * @since	2.5
     * @created 25-06-2011
     */
    function get_topics_by_specialty($specialtyId) {
        $kolId = $this->session->userdata('kolId');
        // Get the list of Topic belongs to kol specialty
        $arrTopics = $this->kol->getTopicsBySpecialty($specialtyId);
        $arrPreparedTopics = array();
        foreach ($arrTopics as $key => $value) {
            $arrPreparedTopics[$key] = $value['name'];
        }
        echo json_encode($arrPreparedTopics);
    }

    /**
     * Gets the all the topics and gives it to the view all topics module box page
     * @author 	Ramesh B
     * @since	2.5
     * @created 25-06-2011
     */
    function view_all_topics() {
        $kolId = $this->session->userdata('kolId');
        // Getting the KOL details
        $arrKolDetail = $this->kol->editKol($kolId);
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $data['arrSpecialties'] = $arrSpecialties;
        $data['kolSpecialty'] = $arrKolDetail['specialty'];
        $this->load->view('events/view_all_topics', $data);
    }

    /**

     * Show the Kol export page for the selected kols
     * Display View Page for Exporting Kol
     * @ACL-Alias Export Kols
     * @ACL-Discription Display View Page for Exporting Kol
     * @ACL-Category Kols
     * @ACL-SubApp Client
     *
     * @param $kols
     * @return unknown_type
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     */
    function show_kol_export_opts($kols) {
        $data['arrKols'] = $kols;
        $this->load->view('kols/export/kol_export_opts', $data);
    }

    /**
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     * Retrives the data for passed Kol ID's and returns
     * those kol's data to the Excel sheet
     *
     * @param $kolsId
     * @return unknown_type
     */
    function kol_export_opts_old() {
        $this->load->plugin('phpxls/writer');
        $startTime = microtime(true);
        $dataResult = array();
        $exportOpts = $this->input->post('export_opts');
        $kols = $this->input->post('kol_id');
        $arrKols = explode(',', $kols);
//		$arrKols = array(2016,1619,1976,264,2018);
//			$kolId = $kolsId;
        $clientId = $this->session->userdata('client_id');
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $arrSpecialtie['arrSpecialties'] = $arrSpecialties;
        // Get the kol's Id and its PIN
        $kolArray = $this->kol->getKolsIdAndPin();
        foreach ($arrKols as $id) {
            $kolId = $id;
            //Get Kols related data
            $arrKolDetails = $this->kol->getKolDetailsById($kolId);
            $data['arrKol'] = $arrKolDetails;
            if (in_array('education', $exportOpts)) {
                //Get the details for Education
                $arrEducationDetails = $this->kol->getEducationDetailById($kolId);
                $data['arrEducation'] = $arrEducationDetails;
            }
            if (in_array('affiliation', $exportOpts)) {
                //Get the details for Affiliation
                $arrMembershipDetails = $this->kol->listAllMembershipsDetails($kolId);
                if ($arrMembershipDetails == false) {
                    $arrMembershipDetails = array();
                }
                $data['arrMembership'] = $arrMembershipDetails;
            }
            if (in_array('event', $exportOpts)) {
                //Get the details for Events
                $arrEventsDetails = $this->kol->listAllEvents($kolId);
                $data['arrEvent'] = $arrEventsDetails;
            }
            if (in_array('publication', $exportOpts)) {
                //Get the details for Pubmed
                $arrPublications = array();
                if ($arrPublicationsResults = $this->pubmed->listPublicationDetails($kolId)) {

                    foreach ($arrPublicationsResults as $arrPublicationsResult) {
                        $arrPublication['id'] = $arrPublicationsResult['id'];
                        $arrPublication['pmid'] = $arrPublicationsResult['pmid'];
                        $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                        $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                        $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                        $arrPublication['date'] = $this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
                        $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                        $arrPublication['auth_pos'] = $arrPublicationsResult['auth_pos'];
                        //$arrPublication['auth_pos']		= $this->pubmed->getAuthPosForPublication($arrPublicationsResult['journal_id']);
                        $arrPublication['kol_id'] = $kolId;
                        $arrPublications[] = $arrPublication;
                    }
                }
                $data['arrPublication'] = $arrPublications;
            }
            if (in_array('trial', $exportOpts)) {
                //Get the details for Clinical Trials
                $arrClinicalTrials = array();
                if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolId)) {
                    foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                        $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                        $arrClinicalTrial['ct_id'] = $arrClinicalTrialsResult['ct_id'];
                        $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                        $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                        $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                        $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                        $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['kol_id'] = $kolId;
                        $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                        $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                        $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                        $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                        $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                        $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                        $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                        $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                        $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                        $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                        $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                        $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                        $arrKeywordsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrKeywordsData .= $separator . $row['name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['keywords'] = $arrKeywordsData;
                        $arrMeshtermsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrMeshtermsData .= $separator . $row['term_name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                        $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                        $arrClinicalTrials[] = $arrClinicalTrial;
                    }
                }
                $data['arrClinicalTrial'] = $arrClinicalTrials;
            }

            if (in_array('interaction', $exportOpts)) {
                $clientId = $this->session->userdata('client_id');
                $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                $userId = 0;
                if ($this->session->userdata('user_role_id') == ROLE_USER)
                    $userId = $this->session->userdata('user_id');
                //Get the details for Interactions
                $arrInteractions = $this->interaction->getInteractions($clientId, $kolId, $userId, 0, 0);

                $data['arrInteraction'] = $arrInteractions;
                $arrSalutation['arrSalutations'] = $arrSalutations;
            }
            $dataResult[] = $data;
        }
        $dataContent['dataSet'] = $dataResult;
        if (in_array('professional', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data10[0] = array('PIN', 'Salutation', 'First Name', 'Middle Name', 'Last Name', 'Suffix', 'Gender', 'Specialty', 'Sub-Specialty', 'Company Name', 'Division', 'Title', 'License #', 'NPI Number', 'Profile Type', 'Url');
            } else {
                $data10[0] = array('PIN', 'Salutation', 'First Name', 'Middle Name', 'Last Name', 'Suffix', 'Gender', 'Specialty', 'Sub-Specialty', 'Company Name', 'Division', 'Title', 'License #', 'NPI Number', 'Profile Type');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data10[$i][] = $kolArray[$row['id']];
                    $data10[$i][] = $row['salutation'];
                    $data10[$i][] = $row['first_name'];
                    $data10[$i][] = $row['middle_name'];
                    $data10[$i][] = $row['last_name'];
                    $data10[$i][] = $row['suffix'];
                    $data10[$i][] = $row['gender'];
                    $data10[$i][] = $arrSpecialtie['arrSpecialties'][$row['specialty']];
                    $data10[$i][] = $row['sub_specialty'];
                    $data10[$i][] = $row['org_id'];
                    $data10[$i][] = $row['division'];
                    $data10[$i][] = $row['title'];
                    $data10[$i][] = $row['license'];
                    $data10[$i][] = $row['npi_num'];
                    $data10[$i][] = $row['profile_type'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $data10[$i][] = $row['url'];
                    }
                    $i++;
                }
            }
        }
        if (in_array('contact', $exportOpts)) {
            $data9[0] = array('PIN', 'Primary Phone', 'Fax', 'Primary Email', 'Address 1', 'Address 2', 'City', 'State / Province', 'Postal Code', 'Country');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data9[$i][] = $kolArray[$row['id']];
                    $data9[$i][] = $row['primary_phone'];
                    $data9[$i][] = $row['fax'];
                    $data9[$i][] = $row['primary_email'];
                    $data9[$i][] = $row['address1'];
                    $data9[$i][] = $row['address2'];
                    $data9[$i][] = $row['City'];
                    $data9[$i][] = $row['Region'];
                    $data9[$i][] = $row['postal_code'];
                    $data9[$i][] = $row['Country'];
                    $i++;
                }
            }
        }
        if (in_array('biography', $exportOpts)) {
            if(HIDE_CLINICAL_RESERCH_INTERESTS) {
                $data8[0] = array('PIN', 'Biography', 'Clinical Research Interests');
            }else{
                $data8[0] = array('PIN', 'Biography');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    
                        $data8[$i][] = $kolArray[$row['id']];
                        $data8[$i][] = $row['biography'];
                        if(HIDE_CLINICAL_RESERCH_INTERESTS) {
                            $data8[$i][] = $row['research_interests'];
                        }
                    $i++;
                }
            }
        }
        if (in_array('education', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data1[0] = array('PIN', 'Education Type', 'Institution Name', 'Degree', 'Specialty', 'Time Frame', 'Url1', 'Url2');
            } else {

                $data1[0] = array('PIN', 'Education Type', 'Institution Name', 'Degree', 'Specialty', 'Time Frame');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrEducation'] as $row) {
                    $data1[$i][] = $kolArray[$row['kol_id']];
                    $data1[$i][] = ucwords($row['type']);
                    if ($row['type'] == 'honors_awards') {
                        $data1[$i][] = $row['honor_name'];
                    } else {
                        $data1[$i][] = $row['name'];
                    }
                    $data1[$i][] = $row['degree'];
                    $data1[$i][] = $row['specialty'];

                    $row['date'] = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $row['date'] .= $row['start_date'];

                    if (($row['start_date'] != '') && ($row['end_date']))
                        $row['date'] .= " - ";
                    if ($row['end_date'] != '')
                        $row['date'] .= $row['end_date'];
                    $data1[$i][] = $row['date'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $data1[$i][] = $row['url1'];
                        $data1[$i][] = $row['url2'];
                    }
                    $i++;
                }
            }
        }
        if (in_array('affiliation', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data2[0] = array('PIN', 'Organization Name', 'Dept/Committee', 'Title/Purpose', 'Time frame', 'Organization Type', 'Engagement Type', 'Url1', 'Url2');
            } else {
                $data2[0] = array('PIN', 'Organization Name', 'Dept/Committee', 'Title/Purpose', 'Time frame', 'Organization Type', 'Engagement Type');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrMembership'] as $row) {
                    $data2[$i][] = $kolArray[$row['kol_id']];
                    $data2[$i][] = $row['name'];
                    $data2[$i][] = $row['department'];
                    $data2[$i][] = $row['role'];

                    $row['date'] = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $row['date'] .= $row['start_date'];

                    if (($row['start_date'] != '') && ($row['end_date']))
                        $row['date'] .= " - ";

                    if ($row['end_date'] != '')
                        $row['date'] .= $row['end_date'];

                    $data2[$i][] = $row['date'];
                    $data2[$i][] = ucwords($row['type']);
                    $data2[$i][] = $row['engagement_type'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        if (isset($row['url1ForExport'])) {
                            $data2[$i][] = $row['url1ForExport'];
                        }
                        if (isset($row['ur12ForExport'])) {
                            $data2[$i][] = $row['ur12ForExport'];
                        }
                    }
                    $i++;
                }
            }
        }
        if (in_array('event', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data3[0] = array('PIN', 'Event Name', 'Event Type', 'Session Type', 'Session Name', 'Role', 'Topic', 'Start', 'End', 'Organizer', 'Organizer Type', 'Session Sponsor', 'Sponsor Type', 'Location', 'Address', 'Country', 'State', 'City', 'Postal Code', 'Url1', 'Url2');
            } else {
                $data3[0] = array('PIN', 'Event Name', 'Event Type', 'Session Type', 'Session Name', 'Role', 'Topic', 'Start', 'End', 'Organizer', 'Organizer Type', 'Session Sponsor', 'Sponsor Type', 'Location', 'Address', 'Country', 'State', 'City', 'Postal Code');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrEvent'] as $row) {
                    if ($row['type'] == 'conference') {
                        $data3[$i][] = $kolArray[$row['kol_id']];
                        $data3[$i][] = $row['name'];
                        $data3[$i][] = $row['event_type'];
                        $data3[$i][] = $row['session_type'];
                        $data3[$i][] = $row['session_name'];
                        $data3[$i][] = $row['role'];
                        $data3[$i][] = $this->kol->getTopicName($row['topic']);
                        $data3[$i][] = $row['start'];
                        $data3[$i][] = $row['end'];
                        $data3[$i][] = $row['organizer'];
                        $data3[$i][] = $row['otype'];
                        $data3[$i][] = $row['session_sponsor'];
                        $data3[$i][] = $row['stype'];
                        $data3[$i][] = $row['location'];
                        $data3[$i][] = $row['address'];
                        $data3[$i][] = $row['Country'];
                        $data3[$i][] = $row['Region'];
                        $data3[$i][] = $row['City'];
                        $data3[$i][] = $row['postal_code'];
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $data3[$i][] = $row['url1ForExport'];
                            }
                            if (isset($row['ur12ForExport'])) {
                                $data3[$i][] = $row['ur12ForExport'];
                            }
                        }
                    }
                    if ($row['type'] == 'online') {
                        $data3[$i][] = $kolArray[$row['kol_id']];
                        $data3[$i][] = ucwords($row['type']);
                        $data3[$i][] = $row['name'];
                        $data3[$i][] = $row['event_type'];
                        $data3[$i][] = $row['session_type'];
                        $data3[$i][] = $row['session_name'];
                        $data3[$i][] = $row['role'];
                        $data3[$i][] = $this->kol->getTopicName($row['topic']);
                        $data3[$i][] = $row['start'];
                        $data3[$i][] = $row['end'];
                        $data3[$i][] = $row['organizer'];
                        $data3[$i][] = $row['location'];
                        $data3[$i][] = '';
                        $data3[$i][] = $row['Country'];
                        $data3[$i][] = $row['Region'];
                        $data3[$i][] = $row['City'];
                        $data3[$i][] = '';
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $data3[$i][] = $row['url1ForExport'];
                            }
                            if (isset($row['ur12ForExport'])) {
                                $data3[$i][] = $row['ur12ForExport'];
                            }
                        }
                    }
                    $i++;
                }
            }
        }
        if (in_array('publication', $exportOpts)) {
            $data4[0] = array('PIN', 'Article Title', 'PMID', 'Journal Name', 'Date', 'Authors', 'Authorship Position');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrPublication'] as $row) {
                    $data4[$i][] = $kolArray[$row['kol_id']];
                    $data4[$i][] = $row['article_title'];
                    $data4[$i][] = $row['pmid'];
                    $data4[$i][] = $row['journal_name'];
                    $data4[$i][] = $row['date'];
                    $data4[$i][] = $row['authors'];
                    $data4[$i][] = $row['auth_pos'];
                    $i++;
                }
            }
        }
        if (in_array('trial', $exportOpts)) {
            $data5[0] = array('PIN', 'CTID', 'Study Type', 'Trial Name', 'Condition', 'Intervention', 'Phase', 'Role', 'Number of enrollees', 'Number of trial sites', 'Sponsors', 'Status', 'Start Date', 'End Date', 'Minimum Age', 'Maximum Age', 'Gender', 'Investigators', 'Collaborator', 'Purpose', 'Official Title', 'Keywords', 'MeSH Terms', 'Url');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrClinicalTrial'] as $row) {
                    $data5[$i][] = $kolArray[$row['kol_id']];
                    $data5[$i][] = $row['ct_id'];
                    $data5[$i][] = $row['study_type'];
                    $data5[$i][] = $row['trial_name'];
                    $data5[$i][] = $row['condition'];
                    $data5[$i][] = $row['interventions'];
                    $data5[$i][] = $row['phase'];
                    $data5[$i][] = $row['kol_role'];
                    $data5[$i][] = $row['no_of_enrollees'];
                    $data5[$i][] = $row['no_of_trial_sites'];
                    $data5[$i][] = $row['sponsors'];
                    $data5[$i][] = $row['status'];
                    $data5[$i][] = $row['start_date'];
                    $data5[$i][] = $row['end_date'];
                    $data5[$i][] = $row['min_age'];
                    $data5[$i][] = $row['max_age'];
                    $data5[$i][] = $row['gender'];
                    $data5[$i][] = $row['investigators'];
                    $data5[$i][] = $row['collaborator'];
                    $data5[$i][] = $row['purpose'];
                    $data5[$i][] = $row['official_title'];
                    $data5[$i][] = $row['keywords'];
                    $data5[$i][] = $row['mesh_terms'];
                    $data5[$i][] = $row['url'];
                    $i++;
                }
            }
        }
        if (in_array('media', $exportOpts)) {
            $data7[0] = array('PIN', 'Blog', 'Linkedin', 'Facebook', 'Twitter', 'YouTube');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data7[$i][] = $kolArray[$row['id']];
                    $data7[$i][] = $row['blog'];
                    $data7[$i][] = $row['linked_in'];
                    $data7[$i][] = $row['facebook'];
                    $data7[$i][] = $row['twitter'];
                    $data7[$i][] = $row['you_tube'];
                    $i++;
                }
            }
        }
        if (in_array('interaction', $exportOpts)) {
            $data6[0] = array('PIN', 'KOL Name', 'Date', 'Time', 'Mode', 'Location', ' Topic', 'Brand', 'Role', 'Follow-Up On', 'Category', 'Therapeutic Area', 'Notes');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrInteraction'] as $row) {
                    $data6[$i][] = $kolArray[$row['kol_id']];
                    $data6[$i][] = $arrSalutation['arrSalutations'][$row['salutation']] . " " . $row['kol_name_for_export'];
                    if ($row['date'] != '0000-00-00') {
                        $data6[$i][] = $row['date'];
                    } else {
                        $data6[$i][] = '';
                    }
                    $data6[$i][] = $row['time'];
                    $data6[$i][] = $row['mode_name'];
                    $data6[$i][] = $row['location'];
                    $data6[$i][] = $row['topic_name'];
                    $data6[$i][] = $row['brand_name'];
                    $data6[$i][] = $row['role_name'];
                    if ($row['follow_up_on'] != '0000-00-00') {
                        $data6[$i][] = $row['follow_up_on'];
                    } else {
                        $data6[$i][] = '';
                    }
                    $data6[$i][] = $row['category_name'];
                    $data6[$i][] = $row['area_name'];
                    $data6[$i][] = $row['notes'];
                    $i++;
                }
            }
        }
        //$filename="Education.xls";
        //for downloading the file
        $workbook = new Spreadsheet_Excel_Writer();
        // To allow more than 255 charecters.
        $workbook->setVersion(8);
        $format_und = & $workbook->addFormat();
        $format_und->setBottom(2); //thick
        $format_und->setRight(1);
        $format_und->setBold();
        $format_und->setHAlign('centre');
        $format_und->setVAlign('vcentre');
        $format_und->setColor('black');
        $format_und->setFontFamily('Arial');
        $format_und->setSize(11);
        $format_reg = & $workbook->addFormat();
        $format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);
        $arr = array();
        if (in_array('professional', $exportOpts)) {
            $sheet10 = $data10;
            $arr['Prof_Info'] = $sheet10;
        }
        if (in_array('contact', $exportOpts)) {
            $sheet9 = $data9;
            $arr['Contact Info'] = $sheet9;
        }
        if (in_array('biography', $exportOpts)) {
            $sheet8 = $data8;
            $arr['Biography'] = $sheet8;
        }
        if (in_array('education', $exportOpts)) {
            $sheet1 = $data1;
            $arr['Education'] = $sheet1;
        }
        if (in_array('affiliation', $exportOpts)) {
            $sheet2 = $data2;
            $arr['Affiliation'] = $sheet2;
        }
        if (in_array('event', $exportOpts)) {
            $sheet3 = $data3;
            $arr['Event'] = $sheet3;
        }
        if (in_array('publication', $exportOpts)) {
            $sheet4 = $data4;
            $arr['Publication'] = $sheet4;
        }
        if (in_array('trial', $exportOpts)) {
            $sheet5 = $data5;
            $arr['Trial'] = $sheet5;
        }
        if (in_array('media', $exportOpts)) {
            $sheet7 = $data7;
            $arr['Social Media'] = $sheet7;
        }
        if (in_array('interaction', $exportOpts)) {
            $sheet6 = $data6;
            $arr['Interaction'] = $sheet6;
        }
        foreach ($arr as $wbname => $rows) {
            $rowcount = count($rows);
            $colcount = count($rows[0]);
            $worksheet = & $workbook->addWorksheet($wbname);
            $worksheet->setColumn(0, 0, 5); //setColumn(startcol,endcol,float)
            if ($wbname == 'Prof_Info') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Contact Info') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Biography') {
                $worksheet->setColumn(1, 40, 40);
            } else if ($wbname == 'Education') {
                $worksheet->setColumn(1, 1, 40.00);
                $worksheet->setColumn(2, 6, 15.00);
            } else if ($wbname == 'Affiliation') {
                $worksheet->setColumn(1, 3, 40.00);
                $worksheet->setColumn(4, 9, 15.00);
            } else if ($wbname == 'Event') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Publication') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Trial') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Social Media') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Interaction') {
                $worksheet->setColumn(1, 18, 30);
            }
            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;
                    if ($j == 0)
                        $fmt = & $format_und;
                    if (isset($rows[$j][$i])) {
                        $value = utf8_decode($rows[$j][$i]);
                        //Format 'postal code cells as 'string'
                        if ($wbname == 'Contact Info' && $i == 8) {
                            $worksheet->writeString($j, $i, $value, $fmt);
                        } else
                            $worksheet->write($j, $i, $value, $fmt);
                    }
                }
            }
        }
        $workbook->send('kol.xls');
        $workbook->close();
    }

    /**
     * Show the kol import page for the Client view
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     * @return unknown_type
     */
    function kol_import_page() {
        $this->load->view('kols/kol_import_page');
    }

    /**
     * Show the kol import page for the Analyst view
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     * @return unknown_type
     */
    function analyst_kol_import_page() {
        $this->load->view('kols/kol_import_page');
    }

    /**
     * Reads the KOL data From Excel sheet Based on the sheet name specified
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     * @return unknown_type
     *  Importing of kols
     * @ACL-Alias Import Kols
     * @ACL-Discription Display importing of kols
     * @ACL-Category Kols
     */
    function import_kol_profiles() {
        ini_set("max_execution_time", 7200);
        // Load the plugin
        $this->load->plugin('excelReader/reader2');
        $currentMethod = $this->input->post('methodName');
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $arrSpecialitys = $this->Specialty->getAllSpecialties();
        // Get the file information of the Uploaded EXCEL file
        $fileInfo = pathinfo($_FILES["prof_import"]['name']);
        // Location of the folder where all the Uploaded Excel documents will be stored
        $folderLocation = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_profiles/";
        // Generate the Random Text, which will be used to store as FILE NAME, on the server
        // This will ensure that we won't be over-writing any files on the server, even by mistake, while importing
        $randomText = random_string('unique', 20);
        $uploadedFile = $folderLocation . $randomText . "." . $fileInfo['extension'];
        if ($_FILES["prof_import"]['name'] != null) {
            //Proceed only if the uploaded file if of type 'xls' or 'xlsx
            if ($fileInfo['extension'] == 'xls' || $fileInfo['extension'] == 'xlsx') {
                // Move the Uploaded file to predefined location on server with constructed new name
                if (move_uploaded_file($_FILES['prof_import']['tmp_name'], $uploadedFile)) {
                    // Create the new excel reader object
                    $reader = new Spreadsheet_Excel_Reader($uploadedFile, true, 'utf-8');
                    // Dump the EXCEL data for debugging
                    //Prepare the data required fileds
                    $arrEventTypes = $this->Event_helper->getAllConferenceEventTypes();
                    $arrSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
                    $arrCountries = $this->Country_helper->listCountries();
                    $arrStates = $this->Country_helper->listStates();
                    $arrCities = $this->Country_helper->listCities();
                    $countryId = 0;
                    $stateId = 0;
                    $cityId = 0;
                    //To Read the shhet name and its index
                    foreach ($reader->boundsheets as $k => $sheet) {
                        /**
                         * The EXCEL file information is available as an array of SHEETS.
                         * Each sheet information is available as a two dimensional array or ROW AND COLUMN
                         * Example: The First cell of the First Sheet can be accessed as
                         * $reader->sheets[1]["cells"][1][1]	== $reader->sheets[SHEET_NUMBER]["cells"][ROW_NUMBER][COLUMN_NUMBER]
                         */
                        // Start of processing the sheet - "Professional Info"
                        if ((trim($sheet['name']) == 'Professional Info') || (trim($sheet['name']) == 'Prof_Info')) {
                            //echo "started personal info<br />";
                            //Check the Professional Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Salutation" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "First Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Middle Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Last Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Suffix" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Gender" ||
                                    trim($reader->sheets[$k]["cells"][$row][8]) != "Specialty" ||
                                    trim($reader->sheets[$k]["cells"][$row][9]) != "Sub-Specialty" ||
                                    trim($reader->sheets[$k]["cells"][$row][10]) != "Company Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][11]) != "Division" ||
                                    trim($reader->sheets[$k]["cells"][$row][12]) != "Title" ||
                                    trim($reader->sheets[$k]["cells"][$row][13]) != "License #" ||
                                    trim($reader->sheets[$k]["cells"][$row][14]) != "NPI Number" ||
                                    trim($reader->sheets[$k]["cells"][$row][15]) != "Profile Type") {
                                $arrImportStatusMsg['professional']['incorrect_format'] = 'Professional Info Header format is incorrect';
                                break;
                            }

                            $existingkols = array();
                            $arrLocationData = array(); // for kol_location
                            $arrEmailData = array(); // for email
                            $arrPhoneData = array();// for phone
                            $kid;// kol_id for kol_location
                            $korg_id; //org_id for kol_location
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                // Get Salutation ID based on the Salutation Text
                                $kolsDetails['salutation'] = array_search(trim($reader->sheets[$k]["cells"][$row][2]), $arrSalutations);
                                if (!$kolsDetails['salutation']) {
                                    $kolsDetails['salutation'] = '';
                                }
                                $kolsDetails['first_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $kolsDetails['middle_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                $kolsDetails['last_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                $kolsDetails['suffix'] = trim($reader->sheets[$k]["cells"][$row][6]);
                                $kolsDetails['gender'] = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                                // Get Specialty ID based on the Specialty Text
                                $kolsDetails['specialty'] = array_search(trim($reader->sheets[$k]["cells"][$row][8]), $arrSpecialitys);
                                if (!$kolsDetails['specialty']) {
                                    $kolsDetails['specialty'] = '';
                                }
                                $kolsDetails['sub_specialty'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
                                $organization['name'] = trim($reader->sheets[$k]["cells"][$row][10]);
                                if ($organization['name'] != '') {
                                    $kolsDetails['org_id'] = $this->organization->saveOrganization($organization);
                                    $korg_id = $kolsDetails['org_id'];
                                    if ($kolsDetails['org_id']) {
                                        //Update pin as kolid
                                        $updateData['id'] = $kolsDetails['org_id'];
                                        $updateData['cin_num'] = $kolsDetails['org_id'];
                                        $this->organization->updateOrganization($updateData);
                                        $arrLocationData['org_institution_id'] = $kolsDetails['org_id'];
                                    }
                                }
                                $kolsDetails['division'] = ucwords(trim($reader->sheets[$k]["cells"][$row][11]));
                                $kolsDetails['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][12]));
                                $kolsDetails['license'] = trim($reader->sheets[$k]["cells"][$row][13]);
                                $kolsDetails['npi_num'] = trim($reader->sheets[$k]["cells"][$row][14]);
                                $kolsDetails['profile_type'] = trim($reader->sheets[$k]["cells"][$row][15]);

                                if ($kolsDetails['profile_type'] == '' || ($kolsDetails['profile_type'] != 'Full Profile' && $kolsDetails['profile_type'] != 'Basic' && $kolsDetails['profile_type'] != 'Basic Plus')) {
                                    $kolsDetails['profile_type'] = 'Full Profile';
                                }

                                $kolsDetails['created_by'] = $this->loggedUserId;
                                $kolsDetails['created_on'] = date("Y-m-d H:i:s");
                                $kolsDetails['is_imported'] = 1;
                                $kolsDetails['is_pubmed_processed'] = 0;
                                $kolsDetails['status'] = New1;
                                //Save only if the 'PIN' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $id = $this->kol->saveImportedKol($kolsDetails);
                                    $kid=$id;
                                    //If the kol already Exists then it won't save
                                    if ($id == false) {
                                        //array of already existing kols
                                        $existingkols[] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
                                        unset($kolsDetails['first_name']);
                                        unset($kolsDetails['middle_name']);
                                        unset($kolsDetails['last_name']);
                                       	$id = $this->kol->updateImportedKol($kolsDetails);
                                       	$kid=$id;
                                    }
                                } else {
                                    //array of KOL having no 'PIN'
                                    $arrImportStatusMsg['professional']['no_pin_num'][] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
                                }
                            }
                            $arrImportStatusMsg['professional']['success'] = true;
                            $arrImportStatusMsg['professional']['existingKols'] = $existingkols;
                        }
                        //End of processing the sheet - 'Professional Info' or 'Prof_Info'
                        // Start of processing the sheet - "Contact Info"
                        if (trim($sheet['name']) == 'Contact Info' || trim($sheet['name']) == 'Contact_Info') {
                            //echo "started contact info<br />";
                            //Check the Contact Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Primary Phone" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Fax" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Primary Email" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Address 1" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Address 2" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "City" ||
                                    trim($reader->sheets[$k]["cells"][$row][8]) != "State / Province" ||
                                    trim($reader->sheets[$k]["cells"][$row][9]) != "Postal Code" ||
                                    trim($reader->sheets[$k]["cells"][$row][10]) != "Country") {
                                $arrImportStatusMsg['contact']['incorrect_format'] = 'Contact Info Header format is incorrect';
                                break;
                            }
                            // Start parsing the Values
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $countryId = 0;
                                $stateId = 0;
                                $cityId = 0;
                                // Create a new array
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $kolsDetails['primary_phone'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $kolsDetails['fax'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $kolsDetails['primary_email'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                $kolsDetails['address1'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                $kolsDetails['address2'] = trim($reader->sheets[$k]["cells"][$row][6]);
                                
                                $arrLocationData['org_institution_id'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_org_id'];                                
                                $arrLocationData['address1'] = $kolsDetails['address1'];
                                $arrLocationData['address2'] = $kolsDetails['address2'];
                                $arrLocationData['address3'] = '';
                                $arrLocationData['validation_status'] = 'VALD';
                                $arrLocationData['address_type'] = 'Physical';                           
                               
                                // Get the CityID, based on the provided City Name

                                if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][8])), $arrStates))
                                    $stateId = $arrStates[ucwords(trim($reader->sheets[$k]["cells"][$row][8]))]['state_id'];
                                $kolsDetails['state_id'] = $stateId;
                                $arrLocationData['state_id'] = $stateId;


                                $city = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                                if ($city != '') {
                                    $kolsDetails['city_id'] = $this->kol->getCityIdByState($city, $stateId);
                                    $arrLocationData['city_id'] = $kolsDetails['city_id'];
                                }

                                $kolsDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
                                $arrLocationData['postal_code'] = $kolsDetails['postal_code'];
                                if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][10])), $arrCountries))
                                    $countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][10]))]['country_id'];
                                $kolsDetails['country_id'] = $countryId;
                                
                                $arrLocationData['country_id'] = $countryId;
                                $arrLocationData['is_primary'] = 1;
                                $arrLocationData['created_by'] = $this->loggedUserId;
                                $arrLocationData['created_on'] = date('Y-m-d H:i:s');
                                $arrLocationData['modified_by'] = $this->loggedUserId;
                                $arrLocationData['modified_on'] = date('Y-m-d H:i:s');                                
                                $arrLocationData['kol_id'] = $kid;
                                $lastLocId = $this->kol->saveKolLocation($arrLocationData); // insert in kol_location
                                
                                $arrEmailData['type'] = 'Work';
                                $arrEmailData['email'] = $kolsDetails['primary_email'];
                                $arrEmailData['is_primary'] = 1;
                                $arrEmailData['contact'] = $kid;
                                $arrEmailData['created_by'] = $this->loggedUserId;
                                $arrEmailData['created_on'] = date('Y-m-d H:i:s');
                                $arrEmailData['modified_by'] = $this->loggedUserId;
                                $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                                $this->kol->saveKolEmails($arrEmailData); // insert in email
                                
                                
                                $arrPhoneData['number'] = $kolsDetails['primary_phone'];
                                $arrPhoneData['is_primary'] = 1;
                                $arrPhoneData['contact'] = $kid;
                                $arrPhoneData['location_id'] = $lastLocId; 
                                $arrPhoneData['contact_type'] = "location";
                                $arrPhoneData['created_by'] = $this->loggedUserId;
                                $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                                $arrPhoneData['modified_by'] = $this->loggedUserId;
                                $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                                $this->kol->saveKolPhones($arrPhoneData); // insert in phone_number                                
                                
                                //Update only if the 'pin' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $id = $this->kol->updateImportedKol($kolsDetails);
                                    if ($id == false) {
                                        //Array of KOLs with mentioned 'PIN' not present in database
                                        $arrImportStatusMsg['contact']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                    }
                                } else {
                                    //Array of KOLs having no 'PIN' in EXCEL file
                                    $arrImportStatusMsg['contact']['no_pin_num'][] = $kolsDetails['primary_phone'];
                                }
                            }
                            $arrImportStatusMsg['contact']['success'] = true;
                        }
                        //- End of processing the sheet - 'Contact Info'
                        // Start of processing the sheet - "Biography"
                        if (trim($sheet['name']) == 'Biography') {
                            //echo "started biography<br />";
                            //Check the Biography Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Biography" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Clinical Research Interests") {
                                $arrImportStatusMsg['biography']['incorrect_format'] = 'Biography Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $kolsDetails['biography'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $kolsDetails['research_interests'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                //Update only if the 'pin' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $id = $this->kol->updateImportedKol($kolsDetails);
                                    if ($id == false) {
                                        //array of 'pin' not present in database
                                        $arrImportStatusMsg['biography']['no_matching_cin_num'][] = $kolsDetails['pin'];
                                    }
                                } else {
                                    //aray of kol having no 'pin'
                                    $arrImportStatusMsg['biography']['no_pin_num'][] = $kolsDetails['biography'];
                                }
                            }
                            $arrImportStatusMsg['biography']['success'] = true;
                        }
                        //- End of processing the sheet - 'Biography'
                        // Start of processing the sheet - 'Education'
                        if (trim($sheet['name']) == 'Education') {
                            //echo "started education<br />";
                            //Check the Education Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Education Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Institution Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Degree" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Specialty" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Time Frame") {
                                $arrImportStatusMsg['education']['incorrect_format'] = 'Education Info Header format is incorrect';
                                break;
                            }
                            //Arrays to check education types
                            $eduTypes = array("Education", "education");
                            $trainingTypes = array("Training", "training");
                            $boardTypes = array("Board_certification", "Board Certification", "Board certification");
                            $honorTypes = array("Honors_awards", "Awards/Honors", "Honors/Awards", "Honors", "Awards", "Honors/awards", "Honors and Awards");
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolDetails = array();
                                $eduDetails = array();
                                $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                //Check for the  Education Type
                                $educationType = trim($reader->sheets[$k]["cells"][$row][2]);
                                if (in_array($educationType, $eduTypes)) {
                                    $type = "education";
                                } else if (in_array($educationType, $trainingTypes)) {
                                    $type = "training";
                                } else if (in_array($educationType, $boardTypes)) {
                                    $type = "board_certification";
                                } else if (in_array($educationType, $honorTypes)) {
                                    $type = "honors_awards";
                                } else {
                                    //Deafult value
                                    $type = "education";
                                }
                                $eduDetails['type'] = $type;
                                if ($type != "honors_awards") {
                                    //Get Institute id
                                    $institution = array();
                                    $institution['name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                    $institution['created_by'] = $this->loggedUserId;
                                    $institution['created_on'] = date('Y-m-d H:i:s');
                                    if ($institution['name'] != '')
                                        $institueId = $this->kol->getInstituteIdElseSave($institution);
                                    $eduDetails['institute_id'] = $institueId;
                                }
                                if ($type == "honors_awards") {
                                    //$eduDetails['institute_id'] = '';
                                    $eduDetails['honor_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                }
                                $eduDetails['degree'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                $eduDetails['specialty'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                //Get the start and end years
                                $timeFrame = trim($reader->sheets[$k]["cells"][$row][6]);
                                $startDate = "";
                                $endDate = "";
                                $arrTimeFrame = explode('-', $timeFrame);
                                $startDate = trim($arrTimeFrame[0]);
                                if (sizeof($arrTimeFrame) > 1) {
                                    $endDate = trim($arrTimeFrame[1]);
                                }
                                //For honours Separate column year
                                if ($type == "honors_awards") {
                                    $eduDetails['year'] = $startDate;
                                    $eduDetails['start_date'] = $startDate;
                                    $eduDetails['end_date'] = $endDate;
                                } else {
                                    $eduDetails['start_date'] = $startDate;
                                    $eduDetails['end_date'] = $endDate;
                                }
                                $eduDetails['created_by'] = $this->loggedUserId;
                                $eduDetails['created_on'] = date("Y-m-d H:i:s");
                                $eduDetails['client_id'] = $this->session->userdata('client_id');
                                //Save only if the 'pin' is not blank
                                if ($kolDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                    if ($kolId != 0) {
                                        $eduDetails['kol_id'] = $kolId;
                                        $id = $this->kol->saveEducationDetail($eduDetails);
                                    } else {
                                        $arrImportStatusMsg['education']['no_matching_pin_num'][] = $eduDetails['pin'];
                                    }
                                } else {
                                    //aray of Education having no 'pin'
                                    $arrImportStatusMsg['education']['no_pin_num'][] = $institution['name'];
                                }
                            }
                            $arrImportStatusMsg['education']['success'] = true;
                        }
                        //- End of processing the sheet - 'Education'
                        // Start of processing the sheet - 'Affiliation'
                        if (trim($sheet['name']) == 'Affiliation') {
                            //echo "started affiliation<br />";
                            //Check the Affiliation Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Organization Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Dept/Committee" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Title/Purpose" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Time frame" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Organization Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Engagement Type") {
                                $arrImportStatusMsg['affiliation']['incorrect_format'] = 'Affiliation Info Header format is incorrect';
                                break;
                            }
                            //Arrays to check Affiliation types
                            $uniTypes = array("University/Hospital", "University", "university");
                            $assocTypes = array("Association", "association", "Associations");
                            $indTypes = array("Industry", "industry");
                            $govTypes = array("Government", "Government Agency", "Government-Agency", "Government agency", "government");
                            $otherTypes = array("Others", "others", "Other", "other");
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolDetails = array();
                                $affDetails = array();
                                $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                //Check for the  Organization Type(Type of Affiliation)
                                $orgType = trim($reader->sheets[$k]["cells"][$row][6]);
                                if (in_array($orgType, $uniTypes)) {
                                    $type = "university";
                                } else if (in_array($orgType, $assocTypes)) {
                                    $type = "association";
                                } else if (in_array($orgType, $indTypes)) {
                                    $type = "industry";
                                } else if (in_array($orgType, $govTypes)) {
                                    $type = "government";
                                } else if (in_array($orgType, $otherTypes)) {
                                    $type = "others";
                                } else {
                                    //Deafult value
                                    $type = "university";
                                }
                                $affDetails['type'] = $type;
                                //Get Institute id//Oranization Id
                                $institution = array();
                                $institution['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $institution['created_by'] = $this->loggedUserId;
                                $institution['created_on'] = date('Y-m-d H:i:s');
                                if ($institution['name'] != '')
                                    $institueId = $this->kol->getInstituteIdElseSave($institution);
                                $affDetails['institute_id'] = $institueId;
                                $affDetails['department'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $affDetails['role'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                //Get the start and end years
                                $timeFrame = trim($reader->sheets[$k]["cells"][$row][5]);
                                $startDate = "";
                                $endDate = "";
                                $arrTimeFrame = explode('-', $timeFrame);
                                if (sizeof($arrTimeFrame) > 0) {
                                    $startDate = trim($arrTimeFrame[0]);
                                }
                                if (sizeof($arrTimeFrame) > 1) {
                                    $endDate = trim($arrTimeFrame[1]);
                                }
                                $this->load->model('Engagement_type');
                                //Get Engagement id
                                $engagement = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                                $engagementId = $this->Engagement_type->getEngagementId($engagement);
                                if ($engagementId) {
                                    $affDetails['engagement_id'] = $engagementId;
                                }
                                $affDetails['start_date'] = $startDate;
                                $affDetails['end_date'] = $endDate;
                                $affDetails['created_by'] = $this->loggedUserId;
                                $affDetails['created_on'] = date("Y-m-d H:i:s");
                                $affDetails['client_id'] = $this->session->userdata('client_id');
                                //Save only if the 'pin' is not blank
                                if ($kolDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                    if ($kolId != 0) {
                                        $affDetails['kol_id'] = $kolId;
                                        $id = $this->kol->saveMembership($affDetails);
                                    } else {
                                        $arrImportStatusMsg['affiliation']['no_matching_pin_num'][] = $kolDetails['pin'];
                                    }
                                } else {
                                    //aray of Affiliation having no 'pin'
                                    $arrImportStatusMsg['affiliation']['no_pin_num'][] = $institution['name'];
                                }
                            }
                            $arrImportStatusMsg['affiliation']['success'] = true;
                        }
                        //- End of processing the sheet - 'Affiliation'
                        // Start of processing the sheet - 'Event'
                        if (trim($sheet['name']) == 'Event') {
                            //echo "In Events<br />";
                            //Check the Event Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Event Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Event Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Session Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Session Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Role" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Topic" ||
                                    trim($reader->sheets[$k]["cells"][$row][8]) != "Start" ||
                                    trim($reader->sheets[$k]["cells"][$row][9]) != "End" ||
                                    trim($reader->sheets[$k]["cells"][$row][10]) != "Organizer" ||
                                    trim($reader->sheets[$k]["cells"][$row][11]) != "Location" ||
                                    trim($reader->sheets[$k]["cells"][$row][12]) != "Address" ||
                                    trim($reader->sheets[$k]["cells"][$row][13]) != "Country" ||
                                    trim($reader->sheets[$k]["cells"][$row][14]) != "State" ||
                                    trim($reader->sheets[$k]["cells"][$row][15]) != "City" ||
                                    trim($reader->sheets[$k]["cells"][$row][16]) != "Postal Code") {
                                $arrImportStatusMsg['event']['incorrect_format'] = 'Event Info Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolDetails = array();
                                $eventDetails = array();
                                $event = array();
                                $countryId = 0;
                                $stateId = 0;
                                $cityId = 0;
                                $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $event['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                if ($kolDetails['pin'] != '' && $event['name'] != '') {
                                    $eventDetails['type'] = 'conference';
                                    //Get event id
                                    $event['category'] = 'conference';
                                    $event['created_by'] = $this->loggedUserId;
                                    $event['created_on'] = date('Y-m-d H:i:s');
                                    $eventId = $this->kol->getEventIdElseSave($event);
                                    $eventDetails['event_id'] = $eventId;
                                    //Get the event type ID
                                    $eventType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][3])), $arrEventTypes);
                                    if (!$eventType) {
                                        $arrEventType['event_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][3]));
                                        if ($this->db->insert('conf_event_types', $arrEventType)) {
                                            $eventType = $this->db->insert_id();
                                            $arrEventTypes[$eventType] = $arrEventType['event_type'];
                                        } else {
                                            $eventType = "";
                                        }
                                    }
                                    $eventDetails['event_type'] = $eventType;
                                    //Get the Session type ID
                                    $sessionType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][4])), $arrSessionTypes);
                                    if (!$sessionType) {
                                        $arrSessionType['session_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][4]));
                                        if ($this->db->insert('conf_session_types', $arrSessionType)) {
                                            $sessionType = $this->db->insert_id();
                                            $arrSessionTypes[$sessionType] = $arrSessionType['session_type'];
                                        } else {
                                            $sessionType = "";
                                        }
                                    }
                                    $eventDetails['session_type'] = $sessionType;

                                    $eventDetails['session_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                    $eventDetails['role'] = ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
                                    //Get the Evet Topic Id and then Save
                                    $topic = '';
                                    $topicId = '';
                                    $topic = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                                    if ($topic != '') {
                                        $topicId = $this->kol->getTopicId($topic);
                                        if ($topicId == 0) {
                                            $arrEventTopic['name'] = $topic;
                                            if ($this->db->insert('event_topics', $arrEventTopic)) {
                                                $topicId = $this->db->insert_id();
                                            }
                                        }
                                    }
                                    $eventDetails['topic'] = $topicId;
                                    //Get the start and end Dates
                                    $startDate = '';
                                    $endDate = '';
                                    $startDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][8]));
                                    $endDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][9]));
                                    $eventDetails['start'] = $startDate;
                                    $eventDetails['end'] = $endDate;
                                    $eventDetails['organizer'] = trim($reader->sheets[$k]["cells"][$row][10]);
                                    $eventDetails['location'] = trim($reader->sheets[$k]["cells"][$row][11]);
                                    $eventDetails['address'] = trim($reader->sheets[$k]["cells"][$row][12]);
                                    if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][13])), $arrCountries))
                                        $countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][13]))]['country_id'];
                                    $eventDetails['country_id'] = $countryId;
                                    if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][14])), $arrStates))
                                        $stateId = $arrStates[ucwords(trim($reader->sheets[$k]["cells"][$row][14]))]['state_id'];
                                    $eventDetails['state_id'] = $stateId;
                                    if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][15])), $arrCities))
                                        $cityId = $arrCities[ucwords(trim($reader->sheets[$k]["cells"][$row][15]))]['city_id'];
                                    $eventDetails['city_id'] = $cityId;
                                    $eventDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][16]));
                                    $eventDetails['created_by'] = $this->loggedUserId;
                                    $eventDetails['created_on'] = date("Y-m-d H:i:s");
                                    $eventDetails['client_id'] = $this->session->userdata('client_id');
                                    //Save only if the 'pin' is not blank
                                    if ($kolDetails['pin'] != "") {
                                        $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                        if ($kolId != 0) {
                                            $eventDetails['kol_id'] = $kolId;
                                            $id = $this->kol->saveEvent($eventDetails);
                                        } else {
                                            $arrImportStatusMsg['event']['no_matching_pin_num'][] = $kolDetails['pin'];
                                        }
                                    } else {
                                        //aray of Event having no 'pin'
                                        $arrImportStatusMsg['event']['no_pin_num'][] = $event['name'];
                                    }
                                }
                            }
                            $arrImportStatusMsg['event']['success'] = true;
                        }
                        //- End of processing the sheet - 'Event'
                        //- End of processing the sheet - 'Publication'
                        if (trim($sheet['name']) == 'Publication') {
                            //echo "started publication<br />";
                            //Check the Publication Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Article Title" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "PMID" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Journal Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Authors" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Authorship Position") {
                                $arrImportStatusMsg['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolDetails = array();
                                $pubDetails = array();
                                $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $pubDetails['article_title'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $pubDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                //get journal name
                                $journalName = '';
                                $journalName = trim($reader->sheets[$k]["cells"][$row][4]);
                                $pubDetails['created_date'] = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][5]));
                                //Considering this data also Manually added Import data
                                $pubDetails['is_manual'] = 1;
                                $pubDetails['link'] = trim($reader->sheets[$k]["cells"][$row][8]);
                                //For Authors
                                //Currently considering as last name, initial, first name format
                                $multipleAuthors = array();
                                $authorsData = trim($reader->sheets[$k]["cells"][$row][6]);
                                $arrAuthor = explode(',', $authorsData);
                                foreach ($arrAuthor as $authors) {
                                    $lastName = '';
                                    $initials = '';
                                    $foreName = '';
                                    $authors = trim($authors);
                                    $singleAuthor = explode(" ", $authors);
                                    $singleAuthorStrings = array();
                                    foreach ($singleAuthor as $authString) {
                                        if ($authString != '')
                                            $singleAuthorStrings[] = $authString;
                                    }
                                    $singleAuthor = $singleAuthorStrings;
                                    if (sizeof($singleAuthor) > 0) {
                                        $lastName = trim($singleAuthor[0]);
                                    }
                                    //As per the CR Considering the last name and initial to insert. they will change in the ambiguity
                                    if (sizeof($singleAuthor) > 1) {
                                        $initials = trim($singleAuthor[1]);
                                    }
                                    if (sizeof($singleAuthor) > 2) {
                                        $initials = $initials . " " . trim($singleAuthor[2]);
                                    }
                                    $author['last_name'] = $lastName;
                                    $author['initials'] = $initials;
                                    $author['fore_name'] = '';
                                    $multipleAuthors[] = $author;
                                }
                                $authPosition = trim($reader->sheets[$k]["cells"][$row][7]);
                                //Save only if the 'pin' is not blank
                                if ($kolDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                    if ($kolId != 0) {
                                        $pmId = array();
                                        if ($pubDetails['pmid'] == '') {
                                            $pmId[] = $this->pubmed->getManualPmid();
                                            $pubDetails['pmid'] = $pmId[0];
                                        } else {
                                            //Check for the pmid. if its present then associate it with kol
                                            $arrUniquePMIDs = array($pubDetails['pmid']);
                                            //Returns the NEW pmid which is not there in database
                                            $pmId = $this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId, null, 1);
                                        }

                                        //If its new pmID then insert it into database
                                        if (sizeof($pmId) > 0) {
                                            $pubDetails['journal_id'] = $this->pubmed->savejournalName($journalName);
                                            $pubId = $this->pubmed->savePublicationsManualAndFlags($pubDetails, $kolId);
                                            //save 'publication-authors'
                                            $isSaved = $this->save_pub_authors($multipleAuthors, $pubId);
                                            $position = '';
                                            if (!empty($authPosition)) {
                                                $position = $authPosition;
                                            } else {
                                                //	Calculate Authorship position and save
                                                $position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
                                            }
                                            $this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
                                        } else {
                                            $arrImportStatusMsg['publication']['pmid_exist'][] = $pubDetails['pmid'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
                                            $pubId = $this->pubmed->checkPubExist($pubDetails['pmid']);
                                            if (!empty($authPosition)) {
                                                $position = $authPosition;
                                            } else {
                                                //	Calculate Authorship position and save
                                                $position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
                                            }
                                            //echo $pubId.':'.$kolId.':'.$position."-";
                                            $this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
                                        }
                                    } else {
                                        $arrImportStatusMsg['publication']['no_matching_pin_num'][] = $kolDetails['pin'];
                                    }
                                } else {
                                    //aray of publication having no 'pin'
                                    $arrImportStatusMsg['publication']['no_pin_num'][] = $publication['pmid'];
                                }
                            }
                            $arrImportStatusMsg['publication']['success'] = true;
                        }
                        //- End of processing the sheet - 'Publication'
                        //- End of processing the sheet - 'Clinical Trial'
                        if (trim($sheet['name']) == 'Trial') {
                            //echo "started trial<br />";
                            //Check the Trial Info Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "CTID" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Study Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Trial Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Condition" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Intervention" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Phase" ||
                                    trim($reader->sheets[$k]["cells"][$row][8]) != "Role" ||
                                    trim($reader->sheets[$k]["cells"][$row][9]) != "Number of enrollees" ||
                                    trim($reader->sheets[$k]["cells"][$row][10]) != "Number of trial sites" ||
                                    trim($reader->sheets[$k]["cells"][$row][11]) != "Sponsors" ||
                                    trim($reader->sheets[$k]["cells"][$row][12]) != "Status" ||
                                    trim($reader->sheets[$k]["cells"][$row][13]) != "Start Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][14]) != "End Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][15]) != "Minimum Age" ||
                                    trim($reader->sheets[$k]["cells"][$row][16]) != "Maximum Age" ||
                                    trim($reader->sheets[$k]["cells"][$row][17]) != "Gender" ||
                                    trim($reader->sheets[$k]["cells"][$row][18]) != "Investigators" ||
                                    trim($reader->sheets[$k]["cells"][$row][19]) != "Collaborator" ||
                                    trim($reader->sheets[$k]["cells"][$row][20]) != "Purpose" ||
                                    trim($reader->sheets[$k]["cells"][$row][21]) != "Official Title" ||
                                    trim($reader->sheets[$k]["cells"][$row][22]) != "Keywords" ||
                                    trim($reader->sheets[$k]["cells"][$row][23]) != "MeSH Terms" ||
                                    trim($reader->sheets[$k]["cells"][$row][24]) != "Url") {
                                $arrImportStatusMsg['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolDetails = array();
                                $trialDetails = array();
                                $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $trialDetails['ct_id'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $trialDetails['study_type'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $trialDetails['trial_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                $trialDetails['kol_role'] = trim($reader->sheets[$k]["cells"][$row][8]);
                                $trialDetails['no_of_enrollees'] = trim($reader->sheets[$k]["cells"][$row][9]);
                                $trialDetails['no_of_trial_sites'] = trim($reader->sheets[$k]["cells"][$row][10]);
                                $trialDetails['start_date'] = trim($reader->sheets[$k]["cells"][$row][13]);
                                $trialDetails['end_date'] = trim($reader->sheets[$k]["cells"][$row][14]);
                                $trialDetails['min_age'] = trim($reader->sheets[$k]["cells"][$row][15]);
                                $trialDetails['max_age'] = trim($reader->sheets[$k]["cells"][$row][16]);
                                $trialDetails['gender'] = trim($reader->sheets[$k]["cells"][$row][17]);
                                $trialDetails['collaborator'] = trim($reader->sheets[$k]["cells"][$row][19]);
                                $trialDetails['purpose'] = trim($reader->sheets[$k]["cells"][$row][20]);
                                $trialDetails['official_title'] = trim($reader->sheets[$k]["cells"][$row][21]);
                                $trialKeywords = trim($reader->sheets[$k]["cells"][$row][22]);
                                $trialMeshTerms = trim($reader->sheets[$k]["cells"][$row][23]);
                                $trialDetails['link'] = trim($reader->sheets[$k]["cells"][$row][24]);
                                $statusName = trim($reader->sheets[$k]["cells"][$row][12]);

                                //Considering this data also Manually added Import data
                                $trialDetails['is_manual'] = 1;


                                //As per the CR Sponcer and Investigators are separating by (;),semicolon
                                //For sponcers
                                $arrSponcers = array();
                                $multipleSponcers = array();
                                $multiSponcers = array();
                                $sponcers = trim($reader->sheets[$k]["cells"][$row][11]);
                                if ($sponcers != '') {
                                    $arrSponcers = explode(';', $sponcers);
                                    foreach ($arrSponcers as $singleSponcer) {
                                        $multipleSponcers['agency'] = $singleSponcer;
                                        $multiSponcers[] = $multipleSponcers;
                                    }
                                }
                                $trialDetails['condition'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                //For intervention
                                $arrInterventions = array();
                                $multipleInterventions = array();
                                $multiInterventions = array();
                                $interventions = trim($reader->sheets[$k]["cells"][$row][6]);
                                if ($interventions != '') {
                                    $arrInterventions = explode(';', $interventions);
                                    foreach ($arrInterventions as $singleIntervention) {
                                        $multipleInterventions['name'] = $singleIntervention;
                                        $multiInterventions[] = $multipleInterventions;
                                    }
                                }
                                $trialDetails['phase'] = trim($reader->sheets[$k]["cells"][$row][7]);
                                //For Investigators
                                $arrInvestigator = array();
                                $multipleInvestigators = array();
                                $multiInvestigators = array();
                                $investigators = trim($reader->sheets[$k]["cells"][$row][18]);
                                if ($investigators != '') {
                                    $arrInvestigator = explode(';', $investigators);
                                    foreach ($arrInvestigator as $singleInvestigator) {
                                        $multipleInvestigators['last_name'] = $singleInvestigator;
                                        $multiInvestigators[] = $multipleInvestigators;
                                    }
                                }

                                //Save only if the 'pin' is not blank
                                if ($kolDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                    if ($kolId != 0) {
                                        $nctId = array();
                                        if ($trialDetails['ct_id'] == '') {
                                            $nctId[] = $this->clinical_trial->getManualCtid();
                                            $trialDetails['ct_id'] = $nctId[0];
                                        } else {
                                            //Check for the ct_id. if its present then associate it with kol
                                            $arrUniqueCTIDs = array($trialDetails['ct_id']);
                                            //Returns the NEW CTID which is not there in database
                                            $nctId = $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId);
                                        }
                                        //If its new CTID then insert it into database
                                        if (sizeof($nctId) > 0) {
                                            $statusId = $this->clinical_trial->saveStatus($statusName);
                                            $trialDetails['status_id'] = $statusId;
                                            $ctId = $this->clinical_trial->saveClinicalTrialsManualAndFlags($trialDetails, $kolId);
                                            if (sizeof($multiSponcers) > 0) {
                                                $isSaved = $this->clinical_trial->saveSponsers($multiSponcers, $ctId);
                                            }
                                            if (sizeof($multiInterventions) > 0) {
                                                $isSaved = $this->clinical_trial->saveInterventions($multiInterventions, $ctId);
                                            }
                                            if (sizeof($multiInvestigators) > 0) {
                                                $isSaved = $this->clinical_trial->saveInvestigators($multiInvestigators, $ctId);
                                            }
                                            if ($trialKeywords != '') {
                                                $arrTrialKeywords = explode(',', $trialKeywords);
                                                foreach ($arrTrialKeywords as $key => $keyword) {
                                                    if ($keywordId = $this->clinical_trial->getKeywordIdByKeyword($keyword)) {
                                                        //	echo 'Already exists '.$keyword;
                                                    } else if ($keywordId = $this->clinical_trial->saveKeyword(array('name' => $keyword))) {
                                                        //	echo 'New Keyword '.$keyword;
                                                    }
                                                    if (!empty($keywordId)) {
                                                        $arrAssociateKeyword['keyword_id'] = $keywordId;
                                                        $arrAssociateKeyword['cts_id'] = $ctId;
                                                        $this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
                                                    }
                                                }
                                            }
                                            if ($trialMeshTerms != '') {
                                                $arrTrialMeshTerms = explode(',', $trialMeshTerms);
                                                foreach ($arrTrialMeshTerms as $key => $meshTerm) {
                                                    if ($meshTermId = $this->clinical_trial->getMeshTermIdByMeshTerm($meshTerm)) {
                                                        //	echo 'Already exists '.$keyword;
                                                    } else if ($meshTermId = $this->clinical_trial->saveMeshterms(array('term_name' => $meshTerm))) {
                                                        //	echo 'New Keyword '.$keyword;
                                                    }
                                                    if (!empty($meshTermId)) {
                                                        $arrAssociateMeshTerm['term_id'] = $meshTermId;
                                                        $arrAssociateMeshTerm['cts_id'] = $ctId;
                                                        $this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
                                                    }
                                                }
                                            }
                                        } else
                                            $arrImportStatusMsg['trial']['ctid_exist'][] = $trialDetails['ct_id'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
                                    }else {
                                        $arrImportStatusMsg['trial']['no_matching_pin_num'][] = $kolDetails['pin'];
                                    }
                                } else {
                                    //aray of trial having no 'pin'
                                    $arrImportStatusMsg['trial']['no_pin_num'][] = $trialDetails['ct_id'];
                                }
                            }
                            $arrImportStatusMsg['trial']['success'] = true;
                        }
                        //- End of processing the sheet - 'Clinical Trials'
                        // Start of processing the sheet - 'Social Media'
                        if (trim($sheet['name']) == 'Social Media') {
                            //echo "started social media<br />";
                            //Check the Social Media Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Blog" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Linkedin" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Facebook" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Twitter" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "YouTube") {
                                $arrImportStatusMsg['media']['incorrect_format'] = 'Social Media Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $kolsDetails['blog'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                $kolsDetails['linked_in'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $kolsDetails['facebook'] = trim($reader->sheets[$k]["cells"][$row][4]);
                                $kolsDetails['twitter'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                $kolsDetails['you_tube'] = trim($reader->sheets[$k]["cells"][$row][6]);
                                //Update only if the 'pin' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $id = $this->kol->updateImportedKol($kolsDetails);
                                    if ($id == false) {
                                        //array of 'pin' not present in database
                                        $arrImportStatusMsg['media']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                    }
                                } else {
                                    //aray of media having no 'pin'
                                    $arrImportStatusMsg['media']['no_pin_num'][] = $kolsDetails['linked_in'];
                                }
                            }
                            $arrImportStatusMsg['media']['success'] = true;
                        }
                        //- End of processing the sheet - 'Social Media'
                        // Start of processing the sheet - 'PMIDs Only'
                        if (trim($sheet['name']) == 'PMIDs_only') {
                            //echo "started social media<br />";
                            //Check the Social Media Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "Article Title" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "PMID" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Journal Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Authors" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Authorship Position") {
                                $arrImportStatusMsg['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $kolsDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                //Add only if the 'pin' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
                                    if ($kolId == false) {
                                        //array of 'pin' not present in database
                                        $arrImportStatusMsg['publication']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                    } else {
                                        $status = $this->pubmed->savePMID($kolsDetails['pmid'], $kolId);
                                        if ($status == false)
                                            $arrImportStatusMsg['publication']['pmid_exist'][] = $kolsDetails['pmid'];

                                        $kolPubmedStatusData = array();
                                        $kolPubmedStatusData['id'] = $kolId;
                                        $kolPubmedStatusData['is_pubmed_processed'] = 2;
                                        $this->pubmed->updatePubmedProcessedKol($kolPubmedStatusData);
                                    }
                                }else {
                                    //aray of media having no 'pin'
                                    $arrImportStatusMsg['publication']['no_pin_num'][] = $kolsDetails['linked_in'];
                                }
                            }
                            $arrImportStatusMsg['publication']['success'] = true;
                        }
                        //- End of processing the sheet - 'PMIDs only'
                        // Start of processing the sheet - 'CTIDs Only'
                        if (trim($sheet['name']) == 'CTIDs_only') {
                            //echo "started social media<br />";
                            //Check the Social Media Header Format
                            $row = 1;
                            if (trim($reader->sheets[$k]["cells"][$row][1]) != "PIN" ||
                                    trim($reader->sheets[$k]["cells"][$row][2]) != "CTID" ||
                                    trim($reader->sheets[$k]["cells"][$row][3]) != "Study Type" ||
                                    trim($reader->sheets[$k]["cells"][$row][4]) != "Trial Name" ||
                                    trim($reader->sheets[$k]["cells"][$row][5]) != "Condition" ||
                                    trim($reader->sheets[$k]["cells"][$row][6]) != "Intervention" ||
                                    trim($reader->sheets[$k]["cells"][$row][7]) != "Phase" ||
                                    trim($reader->sheets[$k]["cells"][$row][8]) != "Role" ||
                                    trim($reader->sheets[$k]["cells"][$row][9]) != "Number of enrollees" ||
                                    trim($reader->sheets[$k]["cells"][$row][10]) != "Number of trial sites" ||
                                    trim($reader->sheets[$k]["cells"][$row][11]) != "Sponsors" ||
                                    trim($reader->sheets[$k]["cells"][$row][12]) != "Status" ||
                                    trim($reader->sheets[$k]["cells"][$row][13]) != "Start Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][14]) != "End Date" ||
                                    trim($reader->sheets[$k]["cells"][$row][15]) != "Minimum Age" ||
                                    trim($reader->sheets[$k]["cells"][$row][16]) != "Maximum Age" ||
                                    trim($reader->sheets[$k]["cells"][$row][17]) != "Gender" ||
                                    trim($reader->sheets[$k]["cells"][$row][18]) != "Investigators" ||
                                    trim($reader->sheets[$k]["cells"][$row][19]) != "Collaborator" ||
                                    trim($reader->sheets[$k]["cells"][$row][20]) != "Purpose" ||
                                    trim($reader->sheets[$k]["cells"][$row][21]) != "Official Title" ||
                                    trim($reader->sheets[$k]["cells"][$row][22]) != "Keywords" ||
                                    trim($reader->sheets[$k]["cells"][$row][23]) != "MeSH Terms" ||
                                    trim($reader->sheets[$k]["cells"][$row][24]) != "Url") {
                                $arrImportStatusMsg['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
                                break;
                            }
                            for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                                $kolsDetails = array();
                                $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                                $kolsDetails['ctid'] = trim($reader->sheets[$k]["cells"][$row][2]);
                                //Add only if the 'pin' is not blank
                                if ($kolsDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
                                    if ($kolId == false) {
                                        //array of 'pin' not present in database
                                        $arrImportStatusMsg['trial']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                    } else {
                                        $status = $this->clinical_trial->saveCTID($kolsDetails['ctid'], $kolId);
                                        if ($status == false)
                                            $arrImportStatusMsg['trial']['ctid_exist'][] = $kolsDetails['ctid'];

                                        $kolTrialStatusData = array();
                                        $kolTrialStatusData['id'] = $kolId;
                                        $kolTrialStatusData['is_clinical_trial_processed'] = 0;
                                        $this->clinical_trial->updateClinicalTrialProcessedKol($kolTrialStatusData);
                                    }
                                }else {
                                    //aray of media having no 'pin'
                                    $arrImportStatusMsg['trial']['no_pin_num'][] = $kolsDetails['linked_in'];
                                }
                            }
                            $arrImportStatusMsg['trial']['success'] = true;
                        }
                        //- End of processing the sheet - 'CTIDs only'
                    }
                    //- End of Looping through each sheets
                } else {
                    $arrImportStatusMsg['professional']['upload_error'] = "Error in uploading file '" . $_FILES["prof_import"]['name'] . "'";
                }
                //- End of processing the EXCEL FILE
            } else {
                // Set the error message if the file is not of EXCEL
                $arrImportStatusMsg['professional']['file_type_missmatch'] = "Sorry! File is not the valid EXCEL FILE. Kindly upload the Valid Excel file with XLS or XLSX extension'";
            }
        }
        //Delete The uploaded file which is used to read the data.
        unlink($uploadedFile);
        if ($currentMethod == 'analyst_kol_import_page') {
            $data['arrImportStatusMsg'] = $arrImportStatusMsg;
            $data['contentPage'] = 'kols/kol_import_status';
            $this->load->view('layouts/analyst_view', $data);
        } else {
            $data['arrImportStatusMsg'] = $arrImportStatusMsg;
            $data['contentPage'] = 'kols/kol_import_status';
            $this->load->view('layouts/client_view', $data);
        }
    }

    /**
     * @author 	Ambarish N
     * @since	2.5
     * @created July-04-2011
     *
     * Used for Import data saving with Auth Position
     * Saves the array of authers one by one
     * @param Array $arrAuthors
     * @param Integer $pubId
     * @return boolean
     */
    function save_pub_authors($arrAuthors, $pubId) {
        $position = 1;
        foreach ($arrAuthors as $author) {
            $authId = $this->pubmed->savePubmedAuthor($author);
            $pubAuthor = array();
            $pubAuthor['pub_id'] = $pubId;
            $pubAuthor['author_id'] = $authId;
            $pubAuthor['position'] = $position;
            $pubAuthor['alias_id'] = $authId;
            $position++;
            $isSaved = $this->pubmed->savePublicationAuthor($pubAuthor);
        }
    }

    /**
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     *
     * Deletes the entire KOL Related formation. For the passed KOL's id
     * @param Array $kolsId
     * @return boolean
     */
    function delete_kols($kolsId) {
        $clientId = $this->session->userdata('client_id');
        $arrKols = explode(',', $kolsId);
        foreach ($arrKols as $kolId) {
            $arrInteractions = array();
            // Getting the KOL details
            $arrKolDetail = $this->kol->editKol($kolId);
            //Delete kol Profile images
            if ($arrKolDetail['profile_image'] != '') {
                unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/medium/" . $arrKolDetail['profile_image']);
                unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/original/" . $arrKolDetail['profile_image']);
                unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/resized/" . $arrKolDetail['profile_image']);
            }
            //$this->kol->deleteKol($kolId);
            $this->delete_kol_data("kols","id",$kolId);
            //$this->kol->deleteAdditionalContactByKolId($kolId);
            $this->delete_kol_data("kol_additional_contacts","kol_id",$kolId);
            //$this->kol->deleteEducationsByKolId($kolId);
            $this->delete_kol_data("kol_educations","kol_id",$kolId);
            //$this->kol->deleteAffiliationsByKolId($kolId);
            $this->delete_kol_data("kol_memberships","kol_id",$kolId);
            //$this->kol->deleteEventsByKolId($kolId);
            $this->delete_kol_data("kol_events","kol_id",$kolId);
            //$this->kol->deleteKolNotesByKolId($kolId);
            $this->delete_kol_data("kol_notes","kol_id",$kolId);
            //$this->kol->deleteASMTRatingByKolId($kolId);
            $this->delete_kol_data("asmt_kols_rating","kol_id",$kolId);
            //$this->kol->deleteKolActivityCountByKolId($kolId);
            $this->delete_kol_data("kol_activities_count","kol_id",$kolId);
            //$this->kol->deleteKolLocationsByKolId($kolId);
            $this->delete_kol_data("kol_locations","kol_id",$kolId);
            //$this->kol->deleteListKolsByKolId($kolId);
            $this->delete_kol_data("list_kols","kol_id",$kolId);
            //$this->kol->deletePlanProfilesByKolId($kolId);
            $this->delete_kol_data("plan_profiles","kol_id",$kolId);
            //$this->kol->deleteUserKolsByKolId($kolId);
            $this->delete_kol_data("user_kols","kol_id",$kolId);
            
            $this->pubmed->deleteKolPublicationByKolId($kolId);
            $this->clinical_trial->deleteTrialsByKolId($kolId);
            $this->update->deleteKolRelatedUpdates($kolId);

            $this->interaction->deleteInteractionsByKolId(0, $kolId);
            $this->payment->deletePaymentsByKolId(0, $kolId);
            $this->contract->deleteContractsByKolId(0, $kolId);
            $this->json_store->deleteFromStoreByKolId(0, $kolId);
            $arrPersonalInfos = $this->kol->getPersonalInfoByKolId($kolId);
            if (sizeof($arrPersonalInfos) >= 1) {
                foreach ($arrPersonalInfos as $personalInfo) {
                    $arrPersonalInfoDocs = array();
                    $arrPersonalInfoDocs = $this->kol->getPersonalInfoDocuments($personalInfo['id']);
                    if (sizeof($arrPersonalInfoDocs) >= 1) {
                        foreach ($arrPersonalInfoDocs as $personalInfoDoc) {
                            //Deletes the doccument and returns its file name
                            $fileName = $this->kol->deletePersonalInfoDocuments($personalInfoDoc['id']);
                            if ($fileName != '') {
                                unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName);
                            }
                        }
                    }
                }
            }
            //End of Personal info doccuments delete
            $this->kol->deletePersonalInfoByKolId($kolId);
        }
        //End of for loop for each kol
        $msg = true;
        echo json_encode($msg);
    }
    
    /**
     * @author 	Sanjeev K
     * @since	-.-
     * @created Nov-15-2016
     *
     * Deletes the entire KOL Related formation. For the passed KOL's id
     * @param Array $kolsId
     * @functions show_kol_delete_opts, kol_delete_opts, delete_kol_data.
     * @return -
     */
    
    function show_kol_delete_opts($kols,$is_from_client_visibility,$clientIdFromKolVisibility) {
    	$data['is_from_client_visibility'] = $is_from_client_visibility;
    	$data['client_id_from_kol_visibility'] = $clientIdFromKolVisibility;
    	$data['arrKols'] = $kols;
    	$this->load->view('kols/delete/kol_delete_opts', $data);
    }
    
    function kol_delete_opts(){
    	//error_reporting(E_ALL);
    	//is_from_client_visibility
    	$isFromClientVisibility = $this->input->post('is_from_client_visibility');
    	$clientIdFromKolVisibility = $this->input->post('client_id_from_kol_visibility');
    	$deleteOpts = $this->input->post('delete_opts');
    	$kols = $this->input->post('kol_id');
    	$arrKolIds	= array_filter(explode(",",$kols));
    	$arrayConditions = array();
    	//$arrKolIds	= implode(",",array_filter($arrKolIds));
    	foreach($deleteOpts as $row){
    		switch ($row) {
    			case 'contact':
    				/* Query goes here */
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("kol_locations",$arrayConditions);
    				
    				$arrayConditions = '';
    				$arrayConditions["contact"] = $arrKolIds;
    				$this->delete_kol_data("emails",$arrayConditions);
    				$this->delete_kol_data("state_licenses",$arrayConditions);
    				
    				$arrayConditions["contact_type"] = "kol";
    				$this->delete_kol_data("staffs",$arrayConditions);
    				$this->delete_kol_data("phone_numbers",$arrayConditions);
    				break;
    			case 'events':
    				/* Query goes here */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("kol_events",$arrayConditions);
    				break;
    			case 'trails':
    				/* Query goes here */
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("kol_clinical_trials",$arrayConditions);
    				break;
    			case 'publications':
    				/* Query goes here */
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("kol_publications",$arrayConditions);
    				break;
    			//check once again	
    			case 'dasboard':
    				/* Query goes here */
    				foreach($arrKolIds as $value){
    					$newKolIds[] = 'kol_id:'.$value;
    				}
    				$arrayConditions["kol_id"] = $newKolIds;
    				$this->delete_kol_data("json_store",$arrayConditions);
    				break;
    			case 'profile':
    				/* Query goes here */
    				break;
    			case 'assessments':
    				/* Query goes here */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("asmt_kols_rating",$arrayConditions);
    				break;
    			case 'media':
    				/* Query goes here */
    				break;
    			case 'interactions':
    				/* Query goes here */
    				/*deleteInteractionAttendis */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("interactions_attendees",$arrayConditions);
    				break;
    			case 'payments':
    				/* Query goes here */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("payments",$arrayConditions);
    				break;
    			case 'planning':
    				/* Query goes here */
					$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("plan_profiles", $arrayConditions);
    				break;
    			case 'contracts':
    				/* Query goes here */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("contracts", $arrayConditions);
    				break;
    			case 'lists':
    				/* Query goes here */
    				$arrayConditions = array();
    				$arrayConditions["kol_id"] = $arrKolIds;
    				$this->delete_kol_data("list_kols",$arrayConditions);
    				break;
    			case 'surveys':
    				/* Query goes here */
    				break;
    			case 'identify':
    				/* Query goes here */
    				//project_kols
    				break;
    			case 'education':
    				$CheckedSubEduType = $_POST['edu_delete_opts'];
    				$sizeOfCheckedSubEduType = sizeof($CheckedSubEduType);
    				if($sizeOfCheckedSubEduType>0){
    					foreach($CheckedSubEduType as $rowEduType){
    						switch ($rowEduType) {
    							case 'edu_education':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "education";
    								$this->delete_kol_data("kol_educations",$arrayConditions);
    								break;
    							case 'edu_training':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "training";
    								$this->delete_kol_data("kol_educations",$arrayConditions);
    								break;
    							case 'edu_certifications':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "board_certification";
    								$this->delete_kol_data("kol_educations",$arrayConditions);
    								break;
    							case 'edu_awards':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "honors_awards";
    								$this->delete_kol_data("kol_educations",$arrayConditions);
    								break;
    							default:
    								break;
    						}
    					}
    				}
    				break;
    			case 'affiliation':
    				$CheckedSubAffType = $_POST['aff_delete_opts'];
    				$sizeOfCheckedSubAffType = sizeof($CheckedSubAffType);
    				if($sizeOfCheckedSubAffType>0){
    					foreach($CheckedSubAffType as $rowAffType){
    						switch ($rowAffType) {
    							case 'aff_association':
    								/* Query goes here */
//     								kol_memberships and type
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "association";
    								$this->delete_kol_data("kol_memberships",$arrayConditions);
    								break;
    							case 'aff_government':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "government";
    								$this->delete_kol_data("kol_memberships",$arrayConditions);
    								break;
    							case 'aff_industry':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "industry";
    								$this->delete_kol_data("kol_memberships",$arrayConditions);
    								break;
    							case 'aff_university':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "university";
    								$this->delete_kol_data("kol_memberships",$arrayConditions);
    								break;
    							case 'aff_others':
    								/* Query goes here */
    								$arrayConditions = array();
    								$arrayConditions["kol_id"] = $arrKolIds;
    								$arrayConditions["type"] = "others";
    								$this->delete_kol_data("kol_memberships",$arrayConditions);
    								break;
    							default:
    								break;
    						}
    					}
    				}
    				break;
    			default:
    				break;
    		}
    	}
    	//check for condition
    	if(isset($_POST['full_profile'])&&($_POST['full_profile']=='full')){
    		/* Kol table delette script */
    		foreach($arrKolIds as $kolId){
    			$arrKolDetail = $this->kol->editKol($kolId);
    			if ($arrKolDetail['profile_image'] != '') {
    				//Delete kol Profile images
    				if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/medium/" . $arrKolDetail['profile_image'])) {
    					unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/medium/" . $arrKolDetail['profile_image']);
    				}
    				if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/original/" . $arrKolDetail['profile_image'])) {
    					unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/original/" . $arrKolDetail['profile_image']);
    				}
    				if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/resized/" . $arrKolDetail['profile_image'])) {
    					unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/kol_images/resized/" . $arrKolDetail['profile_image']);
    				}
    			}
    		}
    		$arrayConditions = array();
	    	$arrayConditions["id"] = $arrKolIds;
	    	$this->delete_kol_data("kols",$arrayConditions);
    	}
    	if($isFromClientVisibility == '1'){
    		redirect('kols/list_kols_based_on_client/'.$clientIdFromKolVisibility);
    	}else{
    		redirect('kols/list_kols');
    	}
    	
    }
    
    function delete_kol_data($tableName,$arrayCondition){
    		$this->kol->delete_kol_data_all($tableName,$arrayCondition);
    }

/*    function delete_kol_data($tableName,$columnName,$columnValue){
        $this->kol->delete_kol_data($tableName,$columnName,$columnValue);
    }
*/
    /* to import event topics into event table
     * @author Vinayak
     * @sine 2.6
     * @created 12-7-2011
     *
     */

    function topic_import() {
        $reader = new Spreadsheet_Excel_Reader();
        $reader->setUTFEncoder('iconv');
        $reader->setOutputEncoding('UTF-8');
        $target_path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/Specialty Topics.xls/";
        $reader->read($target_path);
        //$reader->read($_FILES['prof_import']['tmp_name']);
        $reader->setOutputEncoding('CP-1251');
        foreach ($reader->boundsheets as $n => $value) {
            for ($k = 1; $k < count($reader->sheets[$n]['cells']); $k++) {
                $specialty = $reader->sheets[$n]['cells'][$k][1];
                $data['specialty_id'] = $this->kol->getSpecialtyId($specialty);
                for ($m = 2; $m <= count($reader->sheets[$n]['cells'][$k]); $m++) {
                    $data['name'] = $reader->sheets[$n]['cells'][$k][$m];
                    $this->kol->saveEventTopic($data);
                }
            }
            for ($k = 1; $k = count($reader->sheets[$n]['cells']); $k++) {
                for ($j = 1; $j < count($reader->sheets[$n]['cells']); $j++) {
                    $specialty = $reader->sheets[$n]['cells'][$j][1];
                    $data['specialty_id'] = $this->kol->getSpecialtyId($specialty);
                    for ($m = 2; $m <= count($reader->sheets[$n]['cells'][$k]); $m++) {
                        $data['name'] = $reader->sheets[$n]['cells'][$k][$m];
                        $this->kol->saveEventTopic($data);
                    }
                }
            }
        }
    }

    /* Fetches the given tab rss data, parses and prepares a data array
     * @author Ramesh B
     * @sine 2.6
     * @created 12-7-2011
     *
     */

    function load_rss_data($tabNumber) {
        $arrRssUrl = array();
        $arrRssUrl[1] = "http://www.medicalnewstoday.com/rss/featurednews.xml";
        $arrRssUrl[2] = "http://feeds.feedburner.com/worldpharmanews";
        $arrRssUrl[3] = "http://www.pharmabiz.com/Includes/xmlInclude/Pharmabizrss.xml";
        $arrRssUrl[4] = "http://rss.biospace.com/newsstory.rss";
        $arrRssUrl[5] = "http://www.pharmaceutical-business-review.com/rss";
        $arrRssUrl[6] = "http://www.pharmatimes.com/worldnews.rss.ashx";
        $arrRssUrl[7] = "http://www.pharmaceutical-technology.com/news-rss.xml";
        $arrRssUrl[8] = "http://atvb.ahajournals.org/rss/current.xml";
        $arrRssDetails = array();
        $arrRssDetails['arrRssDetails'] = $this->get_rss_data($arrRssUrl[$tabNumber]);
        $this->load->view("rss_feeds/rss_box", $arrRssDetails);
    }

    function repalce_dups() {
        $this->kol->getDuplicateInstituteNames();
    }

    /*
     * Get the data for Events Topic Chart
     * @author Vinayak Malladad
     * @since 3.1
     * @created on 5-9-2011
     * @param $kolId,$startYear,$endYear
     */

    function view_events_chart_by_topic($kolId, $startYear, $endYear) {
        $arrEventTopics = array();
        $arrEventsTopic = $this->kol->getDataForEventsTopicChart($kolId, $startYear, $endYear);
        foreach ($arrEventsTopic as $row) {
            $arrTopic = array();
            $arrTopic[] = $row['name'];
            $arrTopic[] = (int) $row['count'];
            $arrEventTopics[] = $arrTopic;
        }
        echo json_encode($arrEventTopics);
    }

    /*
     * Get the data for Events Role Chart By Topic
     * @author Vinayak Malladad
     * @since 3.1
     * @created on 5-9-2011
     * @param $kolId,$topicName,$startYear,$endYear
     */

    function view_events_rolechart_by_topic($kolId, $startYear, $endYear) {
        $topicName = $this->input->post('topic_name');
        $arrEventsRole = $this->kol->getDataForEventsRoleChartByTopic($kolId, $topicName, $startYear, $endYear);
        $arrEventRoles = array();
        foreach ($arrEventsRole as $row) {
            $arrRole = array();
            $arrRole[] = $row['role'];
            $arrRole[] = (int) $row['count'];
            $arrEventRoles[] = $arrRole;
        }
        echo json_encode($arrEventRoles);
    }

    /**
     * Fetches and returns  the specialty Id for a given kolId
     * @author Ramesh B
     * @since 3.1
     * @param  kolId
     * @return JSON
     * @created 13-09-2011
     */
    function get_kol_specialty_id($kolId = null) {
        if ($kolId == null || $kolId == '') {
            $kolName = $this->input->post('kol_name');
            //	$value1=str_replace(" ","",$kolName);
            $kolId = $this->kol->getKolId($kolName);
        }

        $arrKolDetails = $this->kol->getKolDetailsById($kolId);
        $data['specialtyId'] = $arrKolDetails[0]['specialty'];
        $data['specialtyName'] = $this->Specialty->getSpecialtyById($data['specialtyId']);
        echo json_encode($data);
    }

    /**
     * Prepares the initial filter by data for 'list_kols_client_view' page
     * @author Ramesh B
     * @since 3.6
     * @created 14-12-2011
     */
    function list_kols_client_view_filters() {
        ini_set("max_execution_time", 7200);
        //$arrFilterById = $this->kol->getFilterByRecentApplied();
        $arrFilterById = false;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrFilterFields = array();
        $arrFilterFields = $arrFilterById['arrFilterFields'];
        $arrKeywords[] = '';
        
        //Get count of kols grouping by category(for each category)
        $profileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : null;
        
        $arrKolTypes = ($arrFilterFields['title']) ? $arrFilterFields['title'] : null; 
        
        $arrKolIds = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : null;
        //		$arrCountries										= null;
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : null;
        //		$arrStates											= null;
        $arrStates = ($arrFilterFields['state']) ? $arrFilterFields['state'] : null; //$arrFilterFields['state'];
        //		$arrCity											= null;
        $arrCities = ($arrFilterFields['city']) ? $arrFilterFields['city'] : null; //$arrFilterFields['state'];
        //		$arrSpecialties										= null;
        $arrSpecialties = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : null; //$arrFilterFields['specialty'];
        //		$arrOrganizations									= null;
        $arrOrganizations = ($arrFilterFields['organization']) ? $arrFilterFields['organization'] : null; //$arrFilterFields['organization'];
        //		$arrEducations										= null;
        $arrEducations = ($arrFilterFields['education']) ? $arrFilterFields['education'] : null; //$arrFilterFields['education'];
        //		$arrEvents											= null;
        $arrEvents = ($arrFilterFields['event_id']) ? $arrFilterFields['event_id'] : null; //$arrFilterFields['event_id'];
        //		$arrLists											= null;
        $arrLists = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : null; //$arrFilterFields['list_id'];
        if(KOL_CONSENT){
            $arrOptInOut = ($arrFilterFields['opt_inout']) ? $arrFilterFields['opt_inout'] : null; //$arrFilterFields['list_id'];
        }
        $arrKolNames = null;
        $keyword = null;
        //		$arrFilterFields['viewType'] = 1; // My Contacts = 1 and All contacts = 2
        $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
        if (sizeof($viewMyKols) > 0) {
            $viewTypeMyKols = MY_RECORDS;
            $arrFilterFields['viewType'] = $viewMyKols;
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        //pr($arrFilterFields);exit;
        $arrKolsByCountryCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'country', $arrKolIds);
        $arrKolsByStateCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'state', $arrKolIds);
        $arrKolsByCityCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'city', $arrKolIds);
        //echo $this->db->last_query();
        $arrKolsBySpecialtyCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'specialty', $arrKolIds);
        $arrKolsByOrgCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'organization', $arrKolIds);
        $arrKolsByEduCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'education', $arrKolIds);
        $arrKolsByEventCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'event', $arrKolIds);
        $arrKolsByListCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'list', $arrKolIds);
//       
        $arrOrgByTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'type', $arrKolIds);
        $arrKolTypeCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'title', $arrKolIds);
        $arrRegionCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region', $arrKolIds);
        if(KOL_CONSENT){
            $arrOptInCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'opt_inout', $arrKolIds);
        }
//pr($arrOrgByTypeCount);
//         $arrOrgByTypeCount		= $this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'type');
        
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country_id']] = $row;
            $allCountryCount += $row['count'];
        }
        $allStateCount = 0;
        $assoArrKolsByStateCount = array();
        foreach ($arrKolsByStateCount as $row) {
            $assoArrKolsByStateCount[$row['state']] = $row;
            $allStateCount += $row['count'];
        }
    	$allCityCount = 0;
        $assoArrKolsByCityCount = array();
        foreach ($arrKolsByCityCount as $row) {
            $assoArrKolsByCityCount[$row['city']] = $row;
            $allCityCount += $row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specialty']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['org_id']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_name']] = $row;
            $allEduCount +=$row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_id']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }
        $allOrgTypeCount=0;
        $assoArrOrgByTypeCount=array();
        foreach($arrOrgByTypeCount as $row){
                $assoArrOrgByTypeCount[$row['org_type_id']]=$row;
                $allOrgTypeCount+=$row['count'];
        }
        $allKolTypeCount=0;
        $assoArrKolTypeCount=array();
        foreach($arrKolTypeCount as $row){
                $assoArrKolTypeCount[$row['kol_type_id']]=$row;
                $allKolTypeCount+=$row['count'];
        }
        $allRegionCount=0;
        $assoRegionCount=array();
        foreach($arrRegionCount as $row){
                $assoRegionCount[$row['region_type_id']]=$row;
                $allRegionCount+=$row['count'];
        }
        if(KOL_CONSENT){
            $allOptInOutCount=0;
            $assoOptInCount=array();
            foreach($arrOptInCount as $row){
                $assoOptInCount[$row['opt_in_out_id']]=$row;
                $allOptInOutCount+=$row['count'];
            }
        }
        //		$arrSpecialties = $this->Specialty->getSpecialtyById($arrSpecialties);
        //Setting all the required data and forwording in to respective page
        //		foreach ($arrSpecialties as $key => $val){
        //			$arrSpecialties1[] = $this->Specialty->getSpecialtyById($key);
        //		}
        //		pr($arrSpecialties);
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allStateCount'] = $allStateCount;
        $filterData['allCityCount'] = $allCityCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allOrgTypeCount'] = $allOrgTypeCount;
        $filterData['allRegionCount'] = $allRegionCount;
        if(KOL_CONSENT){
            $filterData['allOptInOutCount'] = $allOptInOutCount;
        }
       
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allListCount'] = $allListCount;
        $filterData['allkolTypeCount']		=	$allKolTypeCount;
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsByStateCount'] = $assoArrKolsByStateCount;
        $filterData['arrKolsByCityCount'] = $assoArrKolsByCityCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['arrOrgByTypeCount']	=	$arrOrgByTypeCount;
        $filterData['arrKolByTypeCount']	=	$arrKolTypeCount;
        $filterData['arrRegionCount']	=	$arrRegionCount;
        if(KOL_CONSENT){
            $filterData['arrOptInOutCount']	=	$arrOptInCount;
        }
//        pr($arrKolTypeCount);
      
//        pr($filterData['arrOrgByTypeCount']);
        $filterData['selectedCountries'] = $arrCountries;
        $filterData['selectedStates'] = $arrStates;
        $filterData['selectedCities'] = $arrCities;
        $filterData['selectedSpecialties'] = $arrSpecialties;
        $filterData['selectedOrgs'] = $arrOrganizations;
        $filterData['selectedEdus'] = $arrEducations;
        $filterData['selectedEvents'] = $arrEvents;
        $filterData['selectedLists'] = $arrLists;
        $filterData['selectedKolTypes'] = $arrKolTypes;
        if(KOL_CONSENT){
            $filterData['selectedOptInOut'] = $arrOptInOut;
        }
        
//        pr($allCityCount);
//        pr($assoArrKolsByCityCount);
        
        if ($arrKolIds != '')
            $filterData['selectedKol'] = $this->kol->getKolNameById($arrKolIds);
        $filterData['profileType'] = $profileType;
        $filterData['viewType'] = $viewTypeMyKols;
        $filterData['keyword'] = $keyword;
        $filterData['arrAdvSearchFields'] = "";
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['searchType'] = 'simple';
        //echo json_encode($data);
        $filterData['mapSection'] = '';
        $filterData['customFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $filterData['savedFilterId'] = $arrFilterById['id'];
        $this->load->view('search/kol_filters_li_style', $filterData);
    }

    /*
     * displays all the KOLs who are related to the values entered in advanced search tab
     * @author 	: Laxman K
     * @since	: KOLM v 3.6
     * @date	: 20-02-2012
     *
     */

    function new_adv_search_kols() {
        $arrFilterFields = array();
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrKolsByCountryCount = array();
        $arrKolsBySpecialtyCount = array();
        $arrKolsByOrgCount = array();
        $arrKolsByEduCount = array();
        $arrKolsByEventCount = array();
        $arrKolsByListCount = array();
        $keywords = trim($this->input->post('keywords'));
        $firstName = trim($this->input->post('first_name'));
        $middleName = trim($this->input->post('middle_name'));
        $lastName = trim($this->input->post('last_name'));
        $specialty = trim($this->input->post('specialty'));
        $subSpecialty = trim($this->input->post('sub_specialty'));
        $country = trim($this->input->post('country'));
        $organization = trim($this->input->post('organization'));
        $title = trim($this->input->post('title'));
        $postalCode = trim($this->input->post('postal_code'));
        $arrAdvSearchFields['pkeywords'] = trim($this->input->post('pkeywords'));
        $arrAdvSearchFields['pauthpos'] = trim($this->input->post('pauthorposition'));
        $arrAdvSearchFields['pqtype'] = trim($this->input->post('pqtype'));
        $arrAdvSearchFields['etopic'] = trim($this->input->post('etopic'));
        if ($arrAdvSearchFields['etopic'] == 'Select Event Topic') {
            $arrAdvSearchFields['etopic'] = '';
        }
        $arrAdvSearchFields['erole'] = trim($this->input->post('erole'));
        if ($arrAdvSearchFields['erole'] == 'Select Event Role') {
            $arrAdvSearchFields['erole'] = '';
        }
        $arrAdvSearchFields['eqtype'] = trim($this->input->post('eqtype'));
        $arrAdvSearchFields['tkeywords'] = trim($this->input->post('tkeywords'));
        $arrAdvSearchFields['trole'] = trim($this->input->post('trole'));
        if ($arrAdvSearchFields['trole'] == 'Select Trial Role') {
            $arrAdvSearchFields['trole'] = '';
        }
        $arrAdvSearchFields['tqtype'] = trim($this->input->post('tqtype'));
        $arrAdvSearchFields['keywords'] = $keywords;
        $arrAdvSearchFields['first_name'] = $firstName;
        $arrAdvSearchFields['middle_name'] = $middleName;
        $arrAdvSearchFields['last_name'] = $lastName;
        $arrAdvSearchFields['sub_specialty'] = $subSpecialty;
        $arrAdvSearchFields['title'] = $title;
        $arrAdvSearchFields['postal_code'] = $postalCode;
        if ($specialty != '')
            $arrAdvSearchFields['specialty'][] = ucwords(trim($specialty));
        if ($country != '')
            $arrAdvSearchFields['country'][] = ucwords(trim($country));
        if ($organization != '')
            $arrAdvSearchFields['organization'][] = ucwords(trim($organization));
        $advSearchSessData = array('keywords', 'arrFilterFields', 'arrAdvSearchFields');
        $this->session->set_userdata('keywords', $keywords);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        $this->session->set_userdata('arrAdvSearchFields', $arrAdvSearchFields);

        $arrKols = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //Get count of kols grouping by category(for each category)
        $arrKolsByCountryCount = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'country');
        $arrKolsBySpecialtyCount = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'specialty');
        $arrKolsByOrgCount = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'organization');
        $arrKolsByEduCount = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'education');
        $arrKolsByListCount = $this->kol->getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false, true, 'list');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allCountryCount = 0;
        $assoArrKolsByCountryCount = array();
        foreach ($arrKolsByCountryCount as $row) {
            $assoArrKolsByCountryCount[$row['country']] = $row;
            $allCountryCount += $row['count'];
        }
        $allSpecialtyCount = 0;
        $assoArrKolsBySpecialtyCount = array();
        foreach ($arrKolsBySpecialtyCount as $row) {
            $assoArrKolsBySpecialtyCount[$row['specs']] = $row;
            $allSpecialtyCount += $row['count'];
        }
        $allOrgCount = 0;
        $assoArrKolsByOrgCount = array();
        foreach ($arrKolsByOrgCount as $row) {
            $assoArrKolsByOrgCount[$row['name']] = $row;
            $allOrgCount += $row['count'];
        }
        $allEduCount = 0;
        $assoArrKolsByEduCount = array();
        foreach ($arrKolsByEduCount as $row) {
            $assoArrKolsByEduCount[$row['institute_name']] = $row;
            $allEduCount += $row['count'];
        }
        $allEventCount = 0;
        $assoArrKolsByEventCount = array();
        foreach ($arrKolsByEventCount as $row) {
            $assoArrKolsByEventCount[$row['event_name']] = $row;
            $allEventCount += $row['count'];
        }
        $allListCount = 0;
        $assoArrKolsByListCount = array();
        foreach ($arrKolsByListCount as $row) {
            $assoArrKolsByListCount[$row['list_name_id']] = $row;
            $allListCount += $row['count'];
        }
        $arrCountries = array();
        $arrSpecialties = array();
        $arrOrganizations = array();
        if (isset($arrAdvSearchFields['country']))
            $arrCountries = $arrAdvSearchFields['country'];
        if (isset($arrAdvSearchFields['specialty']))
            $arrSpecialties = $arrAdvSearchFields['specialty'];
        if (isset($arrAdvSearchFields['organization']))
            $arrOrganizations = $arrAdvSearchFields['organization'];
        //Setting all the required data and forwording in to respective page
        $filterData['allCountryCount'] = $allCountryCount;
        $filterData['allSpecialtyCount'] = $allSpecialtyCount;
        $filterData['allOrgCount'] = $allOrgCount;
        $filterData['allEduCount'] = $allEduCount;
        $filterData['allEventCount'] = $allEventCount;
        $filterData['allListCount'] = $allListCount;
        $filterData['arrKolsByCountryCount'] = $assoArrKolsByCountryCount;
        $filterData['arrKolsBySpecialtyCount'] = $assoArrKolsBySpecialtyCount;
        $filterData['arrKolsByOrgCount'] = $assoArrKolsByOrgCount;
        $filterData['arrKolsByEduCount'] = $assoArrKolsByEduCount;
        $filterData['arrKolsByEventCount'] = $assoArrKolsByEventCount;
        $filterData['arrKolsByListCount'] = $assoArrKolsByListCount;
        $filterData['selectedCountries'] = $arrCountries;
        $filterData['selectedSpecialties'] = $arrSpecialties;
        $filterData['selectedOrgs'] = $arrOrganizations;
        $filterData['keyword'] = "";
        $filterData['searchType'] = "advanced";
        $filterData['arrFilterFields'] = "";
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['searchType'] = 'advanced';
        $arrSearchInputs = $arrAdvSearchFields;
        foreach ($arrSearchInputs as $index => $value) {
            if (empty($value)) {
                unset($arrSearchInputs[$index]);
            }
        }
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrSearchInputs);
        $filterData['arrSearchInputs'] = $arrSearchInputs;
        $details['kolResultsPage'] = 'search/kol_search_results';
        $details['filterPage'] = 'search/kol_filters_li_style';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        //$data['contentPage'] 								= 'kols/list_kols_client_view';
        $data['mapSection'] = '';
        $this->load->view('layouts/client_view', $data);
    }

    /*
     * displays paginated KOLs who are related to the values entered in advanced search tab
     * @author 	: Laxman K
     * @since	: KOLM v 3.6
     * @date	: 20-02-2012
     *
     */

    function filter_adv_search_kols1() {
        $arrAdvSearchFields = array();
        $viewTypeMyKols = $this->input->post('view_type');
        $profileType = trim($this->input->post('profileType'));
        $arrAdvSearchFields['profileType'] = $profileType;
        $arrAdvSearchFields['keywords'] = trim($this->input->post('keywords'));
        $arrAdvSearchFields['first_name'] = trim($this->input->post('first_name'));
        $arrAdvSearchFields['last_name'] = trim($this->input->post('last_name'));
        $arrAdvSearchFields['pkeywords'] = trim($this->input->post('pkeywords'));
        $arrAdvSearchFields['pauthpos'] = trim($this->input->post('pauthpos'));
        $arrAdvSearchFields['pqtype'] = trim($this->input->post('pqtype'));
        $arrAdvSearchFields['etopic'] = trim($this->input->post('etopic'));
        $arrAdvSearchFields['erole'] = trim($this->input->post('erole'));
        $arrAdvSearchFields['eqtype'] = trim($this->input->post('eqtype'));
        $arrAdvSearchFields['tkeywords'] = trim($this->input->post('tkeywords'));
        $arrAdvSearchFields['trole'] = trim($this->input->post('trole'));
        $arrAdvSearchFields['tqtype'] = trim($this->input->post('tqtype'));
        foreach ($arrAdvSearchFields as $index => $value) {
            $value = trim($value);
            if (empty($value)) {
                unset($arrAdvSearchFields[$index]);
            }
        }
        $page = $this->input->post('page');
        $count = 0;
        $noOfRecordsPerPage = $this->uri->segment(3);
        if (!empty($noOfRecordsPerPage))
            $this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
        $limit = $this->ajax_pagination->per_page;
        $startFrom = $page;
        if ($startFrom == -1)
            $startFrom = 0;
        $arrFilterFields = array();
        $searchType = 'advanced';
        $keyword = '';
        //Check whether the request is for selecting all the page results
        $kolsCount = $this->input->post('kols_count');
        if (isset($kolsCount) && $kolsCount != null) {
            $limit = $kolsCount;
            $startFrom = 0;
        }
        //	$keywords								= $this->session->userdata('keywords');
        //	$arrFilterFields						= $this->session->userdata('arrFilterFields');
        //Get all the selected checkboxs details for respective category
        $arrCountries = $this->input->post('country_ids');

        if ($arrCountries != '' && !is_array($arrCountries))
            $arrCountries = explode(",", $arrCountries);
        //if the input field is not blank add the value in to respective category array values
        if ($country != '')
            $arrCountries[] = $country;
        $arrStates = $this->input->post('state_ids');
        if ($arrStates != '' && !is_array($arrStates))
            $arrStates = explode(",", $arrStates);
        //if the input field is not blank add the value in to respective category array values
        if ($state != '')
            $arrStates[] = $state;

        $arrSpecialties = $this->input->post('specialty_ids');
        if ($arrSpecialties != '' && !is_array($arrSpecialties))
            $arrSpecialties = explode(",", $arrSpecialties);
        if ($specialty != '') {
            $arrSpecialties[] = $specialty;
        }
        $arrOrganizations = $this->input->post('organizations');
        if ($arrOrganizations != '')
            $arrOrganizations = explode(",", $arrOrganizations);
        if ($organization != '') {
            $arrOrganizations[] = $organization;
        }
        $arrEducations = $this->input->post('educations');
        if ($arrEducations != '')
            $arrEducations = explode(",", $arrEducations);
        if ($education != '') {
            $arrEducations[] = $education;
        }
        $arrEvents = $this->input->post('events');
        if ($arrEvents != '')
            $arrEvents = explode(",", $arrEvents);
        if ($eventName != '') {
            $arrEvents[] = $eventName;
        }
        $arrLists = $this->input->post('list_ids');
        if ($arrLists != '' && !is_array($arrLists))
            $arrLists = explode(",", $arrLists);
        if ($listName != '' && !is_array($arrLists)) {
            if (stripos($listName, '(')) {
                $arrListDetails = explode("(", $listName);
                $listName = trim($arrListDetails[0]);
                $categoryName = trim($arrListDetails[1], ") ");
                $listName = $this->My_list_kol->getListName($listName, $categoryName);
            }
            $arrLists[] = $listName;
        }
        $arrAdvSearchFields['specialty'] = $arrSpecialties;
        $arrAdvSearchFields['country'] = $arrCountries;
        $arrAdvSearchFields['state'] = $arrStates;
        $arrAdvSearchFields['organization'] = $arrOrganizations;
        $arrAdvSearchFields['education'] = $arrEducations;
        $arrAdvSearchFields['event_name'] = $arrEvents;
        $arrAdvSearchFields['list_id'] = $arrLists;
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
            if (sizeof($viewMyKols) > 0) {
                $arrAdvSearchFields['viewType'] = $viewMyKols;
            } else {
                $arrAdvSearchFields['viewType'] = array(0);
            }
        }
        //$arrAdvSearchFields						= $this->session->userdata('arrAdvSearchFields');
        $arrKols = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //if request is for all page results id, then just rerutn the kols ids as json data
        if (isset($kolsCount) && $kolsCount != null) {
            $arrIds = array();
            foreach ($arrKols as $row)
                $arrIds[] = (int) $row['id'];
            $data['kolIds'] = $arrIds;
            echo json_encode($data);
            return null;
        }
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $filterData['keyword'] = "";
        $filterData['searchType'] = "advanced";
        $filterData['mapSection'] = 'no';
        $filterData['arrFilterFields'] = $arrFilterFields;
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['searchType'] = 'advanced';
        $kolResultsData['mapSection'] = 'no';
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['profileType'] = $profileType;
        $arrAdvSearchFieldsForMsg = $arrAdvSearchFields;
        if ($arrAdvSearchFieldsForMsg['profileType'] == "Basic") {
            $arrAdvSearchFieldsForMsg['profileType'] = $arrAdvSearchFieldsForMsg['profileType'] . " Profiles";
        } else if ($arrAdvSearchFieldsForMsg['profileType'] == "Basic Plus") {
            $arrAdvSearchFieldsForMsg['profileType'] = str_replace(" Plus", "", $arrAdvSearchFieldsForMsg['profileType']) . "+ Profiles";
        } else if ($arrAdvSearchFieldsForMsg['profileType'] == "Full Profile") {
            $arrAdvSearchFieldsForMsg['profileType'] = "Full Profiles";
        }
        if (isset($arrAdvSearchFieldsForMsg['pauthpos']) && $arrAdvSearchFieldsForMsg['pauthpos'] > 0) {
            switch ($arrAdvSearchFieldsForMsg['pauthpos']) {
                case 1: $arrAdvSearchFieldsForMsg['pauthpos'] = 'First Author';
                    break;
                case 2: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Middle Author';
                    break;
                case 3: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Last Author';
                    break;
                case 4: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Single Author';
                    break;
            }
        }
        unset($arrAdvSearchFieldsForMsg['pqtype']);
        unset($arrAdvSearchFieldsForMsg['eqtype']);
        unset($arrAdvSearchFieldsForMsg['tqtype']);
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFieldsForMsg);
        $kolResultsData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $details['filterPage'] = 'search/kol_filters';
        $details['kolResultsPage'] = 'search/my_kol_results';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        $this->load->view('search/kol_search_results', $kolResultsData);
    }

    /**
     *  Getting the kol data for "Micro View" for flex based influence map
     * @author Ramesh B
     * @param $kolId
     * @return JSON
     * @created 16-02-12
     */
    function view_kol_micro_flex_influence($kolId) {
        $arrKol = array();
        $arrKol = $this->kol->getKolMicroData($kolId);
        $arrKol = $arrKol[0];
        unset($arrKol['biography']);
        unset($arrKol['research_interests']);
        unset($arrKol['notes']);

        $data['noOfAffilitions'] = array();
        ;
        $noOfAffilitions = $this->kol->countAfiliations($kolId);
        $data['noOfAffilitions'] = $noOfAffilitions;
        //Get the count of "Events"
        $data['noOfEvents'] = array();
        $noOfEvents = $this->kol->countEvents($kolId);
        $data['noOfEvents'] = $noOfEvents;
        //Get the count of "Publications"
        $data['noOfPublications'] = array();
        ;
        $noOfPublications = $this->kol->countPublications($kolId);
        $data['noOfPublications'] = $noOfPublications;
        //Get the count of "Trials"
        $data['noOfTrials'] = array();
        $noOfTrials = $this->kol->countTrials($kolId);
        $data['noOfTrials'] = $noOfTrials;
        if ($arrKol['city_id'] != 0) {
            $arrKol['city'] = $this->Country_helper->getCityeById($arrKol['city_id']);
        }
        if ($arrKol['state_id'] != 0) {
            $arrKol['state'] = $this->Country_helper->getStateById($arrKol['state_id']);
            $arrKol['state_code'] = $this->Country_helper->getStatecodeByStateIdorName($arrKol['state_id'], 'id');
        }
        $kolPrimaryDetails = "";
        if ($arrKol['title'] != '')
            $kolPrimaryDetails .= $arrKol['title'] . '<br />';
        if ($arrKol['division'] != '')
            $kolPrimaryDetails .=$arrKol['division'] . '<br />';
        if ($arrKol['name'] != '')
            $kolPrimaryDetails .=$arrKol['name'] . '<br />';
        if ($arrKol['country'] != '')
            $kolPrimaryDetails .=$arrKol['country'];
        $data['primaryDetails'] = $kolPrimaryDetails;
        $kolAddress = "";
        if (!empty($arrKol['address1']) && isset($arrKol['address1']))
            $kolAddress .= "" . $arrKol['address1'] . ",<br />";
        if (!empty($arrKol['address2']) && isset($arrKol['address2']))
            $kolAddress .= $arrKol['address2'] . ",<br />";
        if (!empty($arrKol['city']) && isset($arrKol['city']))
            $kolAddress .= $arrKol['city'] . ", ";
        if (!empty($arrKol['state']) && isset($arrKol['state'])) {
            if ($arrKol['state'] == 'Canada' || $arrKol['state'] == 'United States')
                $kolAddress .= $arrKol['state_code'][0]['state_code'];
            else
                $kolAddress .= $arrKol['state'];
        }
        if ((!empty($arrKol['postal_code']) && isset($arrKol['postal_code'])))
            $kolAddress .= " " . $arrKol['postal_code'] . "<br />";
        if (!empty($arrKol['country']) && isset($arrKol['country']))
            $kolAddress .= $arrKol['country'];

        if ($arrKol['primary_email'] == null)
            $arrKol['primary_email'] = '';
        if ($arrKol['primary_phone'] == null)
            $arrKol['primary_phone'] = '';
        if ($arrKol['fax'] == null)
            $arrKol['fax'] = '';
        $data['arrKol'] = $arrKol;
        $data['kolAddress'] = $kolAddress;
        $data2[] = $data;
        echo json_encode($data2);
    }

    /*
     * get authors first or middle or last name which matches with the $fieldValue
     * @author 	: Laxman K
     * @since	: KOLM v 3.7
     * @date	: 02-03-2012
     * @param	: $fieldName is table column name i.e first_name|middle_name|last_name
     * 				$fieldValue is the value which is compared with $fieldName column
     * $returns : array of first_name|middle_name|last_name which are matched with $fieldName
     */

    function get_kol_name_for_autocomplete($fieldName, $fieldValue) {
        $fieldValue = utf8_urldecode($this->input->post($fieldValue));
        $arrKolNames = $this->kol->getKolNameForAutocomplete($fieldName, $fieldValue);
        $arr['query'] = $fieldValue;
        $arr['suggestions'] = array_values($arrKolNames);
        //pr($arrKolNames);
        echo json_encode($arr);
    }

    /*
     * displays all the KOLs who are related to the values entered in advanced search tab
     * @author 	: Laxman K
     * @since	: KOLM v 3.6
     * @date	: 20-02-2012
     *
     */

    function adv_search() {
        $arrFilterById = array();
        //$arrFilterById = $this->kol->getFilterByRecentApplied();
        $arrFilterById = false;
        $arrFilterFields = array();
        $arrFilterFields = ($arrFilterById['arrFilterFields']) ? $arrFilterById['arrFilterFields'] : array();
        $keywords = '';
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : array();
        $arrStates = ($arrFilterFields['state']) ? $arrFilterFields['state'] : array();
        $arrCities = ($arrFilterFields['city']) ? $arrFilterFields['city'] : array();
        $arrSpecialties = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : array();
        $arrOrganizations = ($arrFilterFields['organization']) ? $arrFilterFields['organization'] : array();
        //		$arrEducation							= ($arrFilterFields['education']) ? $arrFilterFields['education']:'';
        //		$arrEvents								= ($arrFilterFields['event_id']) ? $arrFilterFields['event_id']:'';
        $profileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : '';
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $count = 0;
        $limit = $this->ajax_pagination->per_page;
        $startFrom = 0;
        $arrAdvSearchFields['keywords'] = trim($this->input->post('keywords'));
        $arrAdvSearchFields['first_name'] = trim($this->input->post('first_name'));
        $arrAdvSearchFields['last_name'] = trim($this->input->post('last_name'));
        $arrAdvSearchFields['pkeywords'] = trim($this->input->post('pkeywords'));
        $arrAdvSearchFields['pauthpos'] = trim($this->input->post('pauthorposition'));
        $arrAdvSearchFields['pqtype'] = trim($this->input->post('pqtype'));
        $arrAdvSearchFields['etopic'] = trim($this->input->post('etopic'));
        $arrAdvSearchFields['erole'] = trim($this->input->post('erole'));
        $arrAdvSearchFields['eqtype'] = trim($this->input->post('eqtype'));
        $arrAdvSearchFields['tkeywords'] = trim($this->input->post('tkeywords'));
        $arrAdvSearchFields['trole'] = trim($this->input->post('trole'));
        $arrAdvSearchFields['tqtype'] = trim($this->input->post('tqtype'));
         $arrAdvSearchFields['memebers'] = trim($this->input->post('members'));
        foreach ($arrAdvSearchFields as $index => $value) {
            $value = trim($value);
            if (empty($value)) {
                unset($arrAdvSearchFields[$index]);
            }
        }
        $advSearchSessData = array('keywords', 'arrFilterFields', 'arrAdvSearchFields');
        $viewMyKols = $this->kol->getMyKolsView($this->loggedUserId);
        if (sizeof($viewMyKols) > 0) {
            $viewTypeMyKols = MY_RECORDS;
            $arrFilterFields['viewType'] = $viewMyKols;
        } else {
            $viewTypeMyKols = ALL_RECORDS;
            //			$arrFilterFields['viewType'] = array(0);
        }
        $this->session->set_userdata('keywords', $keywords);
        $this->session->set_userdata('arrFilterFields', $arrFilterFields);
        $this->session->set_userdata('arrAdvSearchFields', $arrAdvSearchFields);
        //		pr($arrFilterFields);
        $arrKols = $this->kol->getAdvSearchMatchingKolsOptimised($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, false);
        $count = $this->kol->getAdvSearchMatchingKolsOptimised($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, true);
        //Setting all the required data and forwording in to respective page
        //		pr($arrKols);
        $arrAdvSearchFields['view_type'] = array($viewTypeMyKols);
        $arrAdvSearchFields['profile_type'] = array($profileType);
        $arrAdvSearchFields['specialty'] = $arrSpecialties;
        $arrAdvSearchFields['country'] = $arrCountries;
        $arrAdvSearchFields['state'] = $arrStates;
        $arrAdvSearchFields['city'] = $arrCities;
        $arrAdvSearchFields['organization'] = $arrOrganizations;
        $arrFiltersApplied = array();
        foreach ($arrAdvSearchFields as $section => $arrValues) {
            if ((sizeof(array_filter($arrValues))) > 0) {
                $separator = ' | ';
                switch ($section) {
                    case 'specialty': $arrSelectedSpecialties = $this->Specialty->getSpecialtiesById($arrValues);
                        $arrFiltersApplied['specialty'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedSpecialties) . '">Specialty</a>';
                        break;
                    case 'country': $arrSelectedCountries = $this->Country_helper->getCountryNameById($arrValues);
                        $arrFiltersApplied['country'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCountries) . '">Country</a>';
                        break;
                    case 'state':
                        $arrSelectedStates = $this->Country_helper->getStateNameById($arrValues);
                        $arrFiltersApplied['state'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedStates) . '">State</a>';
                        break;
                    case 'city':
                        $arrSelectedCities = $this->Country_helper->getCityNameById($arrValues);
                        $arrFiltersApplied['city'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedCities) . '">City</a>';
                        break;
                    case 'organization':
                        $arrSelectedOrgs = $this->organization->getOrgsById($arrValues);
                        $arrFiltersApplied['organization'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . implode($separator, $arrSelectedOrgs) . '">Organization</a>';
                        break;
                    case 'profile_type':
                        $arrFiltersApplied['profile_type'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $profileType . '">Profile Type</a>';
                        break;
                    case 'view_type':
                        if ($arrValues[0] == 1)
                            $viewTypeString = "My Contacts";
                        else
                            $viewTypeString = "All Contacts";
                        $arrFiltersApplied['viewType'] = '<a href="#" onclick="return false;" rel="tooltip" data-original-title="' . $viewTypeString . '">View Type</a>';
                        break;
                }
            }
        }
        //		pr($arrFiltersApplied);
        if ($arrFilterById['id'] != '' || $viewTypeMyKols != '') {
            $kolResultsData['savedQueryFilterApplied'] = implode(',', $arrFiltersApplied);
            $kolResultsData['savedFilterName'] = $arrFilterById['name'];
        }
        $filterData['allCountryCount'] = $count;
         $filterData['allTopicCount'] = $count;
        $filterData['arrKolsByCountryCount'] = $arrKols['arrCountries'];
        $filterData['selectedCountries'] = $arrCountries;
        $filterData['allStateCount'] = $count;
        $filterData['allOrgTypeCount'] = $count;
        $filterData['arrKolsByStateCount'] = $arrKols['arrStates'];
//        pr($arrKols['arrOrganizationsType']);
        $filterData['allkolTypeCount'] = $count;
        $filterData['arrKolByTypeCount'] = $arrKols['arrTitles'];
        $filterData['allRegionCount'] = $count;
        $filterData['arrRegionCount'] = $arrKols['arrRegions'];
        ;
//         pr($filterData['arrKolByTypeCount']);
        $filterData['arrOrgByTypeCount'] = $arrKols['arrOrganizationsType'];
          $filterData['arrTopicCount'] = $arrKols['arrTopics'];
        $filterData['selectedStates'] = $arrStates;
        $filterData['allCityCount'] = $count;
        $filterData['arrKolsByCityCount'] = $arrKols['arrCities'];
        $filterData['selectedCities'] = $arrCities;
        $filterData['allSpecialtyCount'] = $count;
        $filterData['arrKolsBySpecialtyCount'] = $arrKols['arrSpecialties'];
        $filterData['selectedSpecialties'] = $arrSpecialties;
        $filterData['allOrgCount'] = $count;
        $filterData['arrKolsByOrgCount'] = $arrKols['arrOrganizations'];
        $filterData['selectedOrgs'] = $arrOrganizations;
        $filterData['allEduCount'] = $count;
        //		$filterData['selectedEdus']				= $arrEducation;
        $filterData['allEventCount'] = $count;
        //		$filterData['selectedEvents']			= $arrEvents;
        $filterData['profileType'] = $profileType;
        $filterData['viewType'] = $viewTypeMyKols;
        $filterData['savedFilterId'] = ($arrFilterById['id']) ? $arrFilterById['id'] : 0;
        $filterData['allListCount'] = $count;
        $filterData['customFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $kolResultsData['arrKols'] = $arrKols;
        $kolResultsData['arrSalutations'] = $arrSalutations;
        $kolResultsData['kolsCount'] = $count;
        $kolResultsData['searchType'] = 'advanced';
        $arrAdvSearchFieldsForMsg = $arrAdvSearchFields;
        if (isset($arrAdvSearchFieldsForMsg['pauthpos']) && $arrAdvSearchFieldsForMsg['pauthpos'] > 0) {
            switch ($arrAdvSearchFieldsForMsg['pauthpos']) {
                case 1: $arrAdvSearchFieldsForMsg['pauthpos'] = 'First Author';
                    break;
                case 2: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Middle Author';
                    break;
                case 3: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Last Author';
                    break;
                case 4: $arrAdvSearchFieldsForMsg['pauthpos'] = 'Single Author';
                    break;
            }
        }
        unset($arrAdvSearchFieldsForMsg['pqtype']);
        unset($arrAdvSearchFieldsForMsg['eqtype']);
        unset($arrAdvSearchFieldsForMsg['tqtype']);
        $memeberName=$this->kol->getMemberName($arrAdvSearchFields['memebers']);
        $arrAdvSearchFieldsForMsg['memebers']=$memeberName;
        $kolResultsData['msg'] = $this->common_helpers->genSearchResMsgs($startFrom, $limit, $count, $arrAdvSearchFieldsForMsg);
        $filterData['arrAdvSearchFields'] = $arrAdvSearchFields;
        $details['kolResultsPage'] = 'search/kol_search_results';
        $details['filterPage'] = 'search/kol_filters_li_style';
        $details['kolResultsData'] = $kolResultsData;
        $details['filterData'] = $filterData;
        $data['data'] = $details;
        $data['contentPage'] = 'search/kol_results';
        //$data['contentPage'] 					= 'kols/list_kols_client_view';
        $data['mapSection'] = '';
        $this->load->view('layouts/client_view', $data);
    }

    /**
     * Get the Html for "Email"  and "Export Pdf"
     * @author Vinayak
     * @version 3.8
     * @since april 7,2012
     * @param $kolId
     * @return $html
     * @$returnText -iF $returnTo=='Email' or $returnTo=='Pdf'
     */
    function get_mini_profile_as_html($kolId, $returnTo) {
        ini_set("max_execution_time", 7200);
        //$this->load->plugin('export_pdf');
        $arrEducationResults = array();
        $arrEducationDetails = array();
        $arrEducationGridResults = array();
        $data = array();
        $arrMembershipResult = array();
        $arrEventsResults = array();
        $arrMembership = array();
        $arrEvent = array();
        // Getting the Education Details
        if ($arrEducationResults = $this->kol->listAllEducationDetails($kolId)) {
            foreach ($arrEducationResults as $row) {
                $row['date'] = $row['start_date'] . '-' . $row['end_date'];
                if ($row['start_date'] != '') {
                    $row['date'] = $row['start_date'];
                }
                if ($row['end_date'] != '' && $row['start_date'] != '') {
                    $row['date'] .= '-' . $row['end_date'];
                }
                if ($row['start_date'] == '' && $row['end_date'] != '') {
                    $row['date'] = $row['end_date'];
                }
                if ($row['start_date'] == '' && $row['end_date'] == '') {
                    $row['date'] = ' ';
                }
                $arrEducationGridResults[] = $row;
            }
        }
        $data['arrEducation'] = $arrEducationGridResults;
        // Getting the Membership Details
        if ($arrMembershipResult = $this->kol->listAllMembershipsDetails($kolId)) {
            foreach ($arrMembershipResult as $row) {
                if ($row['start_date'] != '') {
                    $row['date'] = $row['start_date'];
                }
                if ($row['end_date'] != '' && $row['start_date'] != '') {
                    $row['date'] .= '-' . $row['end_date'];
                }
                if ($row['start_date'] == '' && $row['end_date'] != '') {
                    $row['date'] = $row['end_date'];
                }
                if ($row['start_date'] == '' && $row['end_date'] == '') {
                    $row['date'] = ' ';
                }
                $arrMembership[] = $row;
            }
        }
        foreach ($arrMembership as $key1 => $row) {
            if ($key1 < (sizeof($arrMembership) - 1)) {
                if ($arrMembership[$key1 + 1]['engagement_type'] == $row['engagement_type'] && $arrMembership[$key1 + 1]['type'] == $row['type']) {
                    $arrMembership[$key1 + 1]['engagement_type'] = '';
                }
            }
        }
        $data['arrMembership'] = $arrMembership;
        // Getting the Events Details
        if ($arrEventsResults = $this->kol->listAllEvents($kolId, $limit = 20)) {
            foreach ($arrEventsResults as $row) {
                if ($row['start'] != '') {
                    $row['date'] = $row['start'];
                }
                if ($row['end'] != '' && $row['start'] != '') {
                    $row['date'] .= '-' . $row['end'];
                }
                if ($row['start'] == '' && $row['end'] != '') {
                    $row['date'] = $row['end'];
                }
                if ($row['start'] == '' && $row['end'] == '') {
                    $row['date'] = ' ';
                }
                $arrEvent[] = $row;
            }
        }
        foreach ($arrEvent as $key1 => $row) {
            if ($key1 < (sizeof($arrEvent) - 1)) {
                if ($arrEvent[$key1 + 1]['session_type'] == $row['session_type']) {
                    $arrEvent[$key1 + 1]['session_type'] = '';
                }
            }
        }
        $data['arrEvent'] = $arrEvent;
        // Getting the KOL details
        $arrKolDetail = array();
        $arrKolDetail = $this->kol->editKol($kolId);
        if(!empty($arrKolDetail['org_id']) || $arrKolDetail['org_id'] != 0)
             $arrKolDetail['org_name'] = $this->kol->getOrgId($arrKolDetail['org_id']);
        else
            $arrKolDetail['org_name'] = $arrKolDetail['private_practice'];
       
        if ($arrKolDetail['country_id'] != 0) {
            $arrKolDetail['country_id'] = $this->Country_helper->getCountryById($arrKolDetail['country_id']);
        }
        if ($arrKolDetail['state_id'] != 0) {
            $arrKolDetail['state_id'] = $this->Country_helper->getStateById($arrKolDetail['state_id']);
        }
        if ($arrKolDetail['city_id'] != 0) {
            $arrKolDetail['city_id'] = $this->Country_helper->getCityeById($arrKolDetail['city_id']);
        }
        if ($arrKolDetail['specialty'] != 0) {
        	$specialty = $this->Specialty->getSpecialtyById($arrKolDetail['specialty']);
        	$arrKolDetail['specialtyName'] = $this->common_helpers->isDataNull($specialty) ? "" : $specialty;
        }
        if($arrKolDetail['biography'] != null){
        	$arrKolDetail['biography'] = $this->display_profile_summary($arrKolDetail['biography'], 'html');
        }
        $arrSubSpecialties = $this->Specialty->getAllKolSubSpecialties($kolId);
        $arrKolDetail['sub_specialty'] = array_filter($arrSubSpecialties);
        $data['arrKol'] = $arrKolDetail;
        //pr($arrKolDetail);
        // Getting the ContactDetails
        $arrContactDetails = array();
        if ($arrContactDetails = $this->kol->listContacts($kolId)) {
            $data['arrContact'] = $arrContactDetails;
        }
        // Getting the Salutations
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Start of publications
        $arrPublications = array();
        $limitValue = '20';
        if ($arrPublicationsResults = $this->pubmed->listPublicationDetailsByLimit($kolId, $limitValue)) {
            foreach ($arrPublicationsResults as $arrPublicationsResult) {
                $arrPublication['issn_number'] = $arrPublicationsResult['issn_number'];
                $arrPublication['volume'] = $arrPublicationsResult['volume'];
                $arrPublication['id'] = $arrPublicationsResult['id'];
                $arrPublication['pmid'] = '<a href=\'' . $arrPublicationsResult['link'] . '\' target="_new">' . $arrPublicationsResult['pmid'] . '</a>';
                $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                $arrPublication['date'] = $arrPublicationsResult['created_date'];
                $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                $arrPublication['subject'] = '';
                $arrPublications[] = $arrPublication;
            }
            $data['arrPublications'] = $arrPublications;
        }
        //End of publications
        //Start of Clinical trials
        $arrClinicalTrials = array();
        if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolId)) {
            foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                if ($arrClinicalTrialsResult['start_date'] != '') {
                    $arrClinicalTrialsResult['date'] = $arrClinicalTrialsResult['start_date'];
                }
                if ($arrClinicalTrialsResult['end_date'] != '' && $arrClinicalTrialsResult['start_date'] != '') {
                    $arrClinicalTrialsResult['date'] .= '-' . $arrClinicalTrialsResult['end_date'];
                }
                if ($arrClinicalTrialsResult['start_date'] == '' && $arrClinicalTrialsResult['end_date'] != '') {
                    $arrClinicalTrialsResult['date'] = $arrClinicalTrialsResult['end_date'];
                }
                if ($arrClinicalTrialsResult['start_date'] == '' && $arrClinicalTrialsResult['end_date'] == '') {
                    $arrClinicalTrialsResult['date'] = ' ';
                }
                $arrClinicalTrial['date'] = $arrClinicalTrialsResult['date'];
                $arrClinicalTrial['ct_id'] = '<a href=\'' . $arrClinicalTrialsResult['link'] . '\' target="_new">' . $arrClinicalTrialsResult['ct_id'] . '</a>';
                $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                $arrKeywordsData = '';
                $separator = '';
                foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                    $arrKeywordsData .= $separator . $row['name'];
                    $separator = ',';
                }
                $arrClinicalTrial['keywords'] = $arrKeywordsData;
                $arrMeshtermsData = '';
                $separator = '';
                foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                    $arrMeshtermsData .= $separator . $row['term_name'];
                    $separator = ',';
                }
                $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                $arrClinicalTrials[] = $arrClinicalTrial;
            }
            $data['arrClinicalTrials'] = $arrClinicalTrials;
        }
        //End of Clinical trials
        $arrMajorMeshterm = $this->pubmed->getPubMajorMeshTermChartForPdf($kolId);
        $meshTerms = array();
        $count = array();
        foreach ($arrMajorMeshterm as $meshterm) {
            $termName = '';
            $parentId = $meshterm['parent_id'];
            if ($parentId != 0 && $parentId != null) {
                $parentName = $this->pubmed->getMeshTermName($parentId);
                $termName = $parentName . "/" . $meshterm['mesh_term'];
            } else {
                $termName = $meshterm['mesh_term'];
            }
            $meshTerms[] = ucwords($termName);
        }
        $data['arrMajorTerms'] = implode(', ', $meshTerms);
        $arrMinorMeshterm = $this->pubmed->getPubMinorMeshTermChartForPdf($kolId);
        $meshTerms1 = array();
        foreach ($arrMinorMeshterm as $mesTerm1) {
            $termName1 = '';
            $termName1 = $mesTerm1['mesh_term'];
            $meshTerms1[] = ucwords($termName1);
        }
        $data['locationData'] = $this->kol->getDetailsInfoById($kolId,'Location');
        $data['phoneData'] = $this->kol->getDetailsInfoById($kolId,'Phone');
        $data['emailData'] = $this->kol->getDetailsInfoById($kolId,'Email');
        $data['licenseData'] = $this->kol->getDetailsInfoById($kolId,'License');
        $data['specialtyData'] = $this->kol->getDetailsInfoById($kolId,'Specialty');
        $data['staffData'] = $this->kol->getDetailsInfoById($kolId,'Staff');
        $data['arrMinorTerms'] = implode(', ', $meshTerms1);
        if ($returnTo == 'Pdf') {
            $html = $this->load->view("kols/export/kol_pdf", $data, true);
        } else {
            $html = $this->load->view("kols/export/kol_profile_for_email", $data, true);
        }
        $filename = $this->common_helpers->get_name_format($arrKolDetail['first_name'],$arrKolDetail['middle_name'],$arrKolDetail['last_name']);
        $arrHtml = array($html, $filename);
        return $arrHtml;
    }

    /**
     * Show Email From
     * @author Vinayak
     * @version 3.8
     * @since april 7,2012
     * @param $kolId
     * @return $html
     *
     */
    function send_profile_email($kolId) {
        $data['kolId'] = $kolId;
        $arrKolName = $this->kol->getKolName($kolId);
        $kolName = '';
        $kolName = $this->common_helpers->get_name_format($arrKolName['first_name'],$arrKolName['middle_name'], $arrKolName['last_name']);
        $data['kolName'] = $kolName;
        $this->load->view('kols/email/email_form', $data);
    }

    /**
     * Sending  a Email using Email Helper
     * @author Vinayak
     * @version 3.8
     * @since april 7,2012
     * @param
     * @return true/false
     *
     */
    function send_email() {
        $format = $this->input->post('format');
        $kolId = $this->input->post('kolId');
        $from = $this->input->post('from');
        $to = $this->input->post('to');
        $email = $this->input->post('email');
        $note = $this->input->post('note');
        $note = nl2br($note);
        $config['protocol'] = PROTOCOL;

        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, $from);
        $this->email->to($to);
        //Get KOl name
        $arrKolName = $this->kol->getKolName($kolId);
        $kolName = '';
        $kolName = $this->common_helpers->get_name_format($arrKolName['first_name'],$arrKolName['middle_name'], $arrKolName['last_name']);
        //If Request of format is Pdf then get Pdf file Content for emial
        
        if ($format == 'Pdf') {
            $this->email->message($note);
            $pdfPath = $this->get_mini_profile_as_pdf($kolId);
          //  echo $pdfPath;
            $this->email->attach($pdfPath, 'attachment');
            //If Request of format is Excel then get Excel file Content for emial
        } elseif ($format == 'Excel') {
            $this->email->message($note);
//             $excelPath = $this->generate_full_frofile_as_excel($kolId, $kolName);
            $excelPath = $this->export_kol_new(true,$kolId, $kolName);
            $this->email->attach($excelPath, 'attachment');
        }
        //End of Pdf and Excel
        //If Request of format is Html then get Html Content for emial
        if ($format == 'html') {
            $arrHtml = $this->get_mini_profile_as_html($kolId, 'Email');
            $html = $arrHtml[0];
            $this->email->message(nl2br($note) . "<br /><hr /><br />" . $html);
        }
        $this->email->subject("Dr. " . $kolName . " Profile");
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Your message has been sent';
            if (isset($excelPath)) {
                unlink($excelPath);
            }
            if (isset($pdfPath)) {
                unlink($pdfPath);
            }
        } else {
            $emailData['status'] = 'Mail not sent';
        }
       //echo $this->email->print_debugger();
        echo json_encode($emailData);
    }

    /**
     * Save and return Path  of Generated Pdf
     * @author Vinayak
     * @version 3.8
     * @since april 7,2012
     * @param $kolId
     * @return $path
     *
     */
    function get_mini_profile_as_pdf($kolId) {
        $arrHtml = $this->get_mini_profile_as_html($kolId, 'Pdf');
        $html = $arrHtml[0];
        $fileName = $arrHtml[1];
        require_once($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "/system/plugins/dompdf/dompdf_config.inc.php");
        spl_autoload_register('DOMPDF_autoload');
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->render();
        $pdf = $dompdf->output();
        $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kols_pdf/" . $fileName . ".pdf";
        file_put_contents($path, $pdf);
        return $path;
    }

    /**
     * Save and return Path  of Generated Excel File
     * @author Vinayak
     * @version 3.8
     * @since april 7,2012
     * @param $kolId
     * @return $path
     *
     */
	function generate_full_frofile_as_excel($kolId, $kolName) {
        $this->load->plugin('phpxls/writer');
        $dataResult = array();
        $exportOpts = array('education', 'affiliation', 'event', 'publication', 'trial', 'interaction', 'professional', 'biography', 'contact','user_notes');
        $kols = $kolId;
        $arrKols = explode(',', $kols);
        //	$kolId = $kolsId;
        $clientId = $this->session->userdata('client_id');
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $arrSpecialtie['arrSpecialties'] = $arrSpecialties;
        // Get the kol's Id and its PIN
        $kolArray = $this->kol->getKolsIdAndPin();
        foreach ($arrKols as $id) {
            $kolId = $id;
            //Get Kols related data
            $arrKolDetails = $this->kol->getKolDetailsById($kolId);
            $data['arrKol'] = $arrKolDetails;
            if (in_array('education', $exportOpts)) {
                //Get the details for Education
                $arrEducationDetails = $this->kol->getEducationDetailById($kolId);
                $data['arrEducation'] = $arrEducationDetails;
            }
            if (in_array('affiliation', $exportOpts)) {
                //Get the details for Affiliation
                $arrMembershipDetails = $this->kol->listAllMembershipsDetails($kolId);
                if ($arrMembershipDetails == false) {
                    $arrMembershipDetails = array();
                }
                //pr($arrMembershipDetails);
                $data['arrMembership'] = $arrMembershipDetails;
            }
            if (in_array('event', $exportOpts)) {
                //Get the details for Events
                $arrEventsDetails = $this->kol->listAllEvents($kolId);
                $data['arrEvent'] = $arrEventsDetails;
            }
            if (in_array('publication', $exportOpts)) {
                //Get the details for Pubmed
                $arrPublications = array();
                if ($arrPublicationsResults = $this->pubmed->listPublicationDetails($kolId)) {

                    foreach ($arrPublicationsResults as $arrPublicationsResult) {
                        $arrPublication['id'] = $arrPublicationsResult['id'];
                        $arrPublication['pmid'] = $arrPublicationsResult['pmid'];
                        $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                        $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                        $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                        $arrPublication['date'] = $this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
                        $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                        $arrPublication['auth_pos'] = $arrPublicationsResult['auth_pos'];
                        $arrPublication['kol_id'] = $kolId;
                        $arrPublications[] = $arrPublication;
                    }
                }
                $data['arrPublication'] = $arrPublications;
            }
            if (in_array('trial', $exportOpts)) {
                //Get the details for Clinical Trials
                $arrClinicalTrials = array();
                if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolId)) {
                    foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                        $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                        $arrClinicalTrial['ct_id'] = $arrClinicalTrialsResult['ct_id'];
                        $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                        $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                        $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                        $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                        $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['kol_id'] = $kolId;
                        $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                        $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                        $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                        $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                        $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                        $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                        $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                        $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                        $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                        $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                        $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                        $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                        $arrKeywordsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrKeywordsData .= $separator . $row['name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['keywords'] = $arrKeywordsData;
                        $arrMeshtermsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrMeshtermsData .= $separator . $row['term_name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                        $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                        $arrClinicalTrials[] = $arrClinicalTrial;
                    }
                }
                $data['arrClinicalTrial'] = $arrClinicalTrials;
            }

            if (in_array('interaction', $exportOpts)) {
                //$arrInteractions = array();
                $clientId = $this->session->userdata('client_id');
                $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                $userId = 0;
                if ($this->session->userdata('user_role_id') == ROLE_USER)
                    $userId = $this->session->userdata('user_id');
                //Get the details for Interactions
                $arrInteractions = $this->interaction->getInteractions($clientId, $kolId, $userId, 0, 0);
                $data['arrInteraction'] = $arrInteractions;
                $arrSalutation['arrSalutations'] = $arrSalutations;
            }
            if (in_array('user_notes', $exportOpts)) {
                //Get the details for Pubmed
                $arrUserNotes = array();
                if ($arrUserNotesResults = $this->kol->getNotes($kolId)) {
            
                    foreach ($arrUserNotesResults as $arrUserNotesResults) {
                        $arrNote['notes'] = $arrUserNotesResults['notes'];
                        $arrNote['added_by'] = $arrUserNotesResults['first_name']." ".$arrUserNotesResults['last_name'];
                        $arrNote['created_on'] =date('d M Y, h:i A', strtotime($arrUserNotesResults['created_on']));
                        $arrUserNotes[] = $arrNote;
                    }
                }
                $data['arrUserNotes'] = $arrUserNotes;
            }
            
            $dataResult[] = $data;
        }
        $dataContent['dataSet'] = $dataResult;
        if (in_array('professional', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data10[0] = array('PIN', 'Salutation', 'First Name', 'Middle Name', 'Last Name', 'Suffix', 'Gender', 'Specialty', 'Sub-Specialty', 'Company Name', 'Division', 'Title', 'License #', 'NPI Number', 'Url');
            } else {
                $data10[0] = array('PIN', 'Salutation', 'First Name', 'Middle Name', 'Last Name', 'Suffix', 'Gender', 'Specialty', 'Sub-Specialty', 'Company Name', 'Division', 'Title', 'License #', 'NPI Number');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data10[$i][] = $kolArray[$row['id']];
                    $data10[$i][] = $row['salutation'];
                    $data10[$i][] = $row['first_name'];
                    $data10[$i][] = $row['middle_name'];
                    $data10[$i][] = $row['last_name'];
                    $data10[$i][] = $row['suffix'];
                    $data10[$i][] = $row['gender'];
                    $data10[$i][] = $arrSpecialtie['arrSpecialties'][$row['specialty']];
                    $data10[$i][] = $row['sub_specialty'];
                    $data10[$i][] = $row['org_id'];
                    $data10[$i][] = $row['division'];
                    $data10[$i][] = $row['title'];
                    $data10[$i][] = $row['license'];
                    $data10[$i][] = $row['npi_num'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $data10[$i][] = $row['url'];
                    }
                    $i++;
                }
            }
        }
        if (in_array('contact', $exportOpts)) {
            $data9[0] = array('PIN', 'Primary Phone', 'Fax', 'Primary Email', 'Address 1', 'Address 2', 'City', 'State / Province', 'Postal Code', 'Country');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data9[$i][] = $kolArray[$row['id']];
                    $data9[$i][] = $row['primary_phone'];
                    $data9[$i][] = $row['fax'];
                    $data9[$i][] = $row['primary_email'];
                    $data9[$i][] = $row['address1'];
                    $data9[$i][] = $row['address2'];
                    $data9[$i][] = $row['City'];
                    $data9[$i][] = $row['Region'];
                    $data9[$i][] = $row['postal_code'];
                    $data9[$i][] = $row['Country'];
                    $i++;
                }
            }
        }
        if (in_array('biography', $exportOpts)) {
            $data8[0] = array('PIN', 'Profile Summary', 'Clinical Research Interests');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                	$biography_excel = $this->display_profile_summary($row['biography'], 'excel');
                    $data8[$i][] = $kolArray[$row['id']];
                    $data8[$i][] = $biography_excel;
                    $data8[$i][] = $row['research_interests'];
                    $i++;
                }
            }
        }

        if (in_array('education', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data1[0] = array('PIN', 'Education Type', 'Institution Name', 'Degree', 'Specialty', 'Time Frame', 'Url1', 'Url2');
            } else {

                $data1[0] = array('PIN', 'Education Type', 'Institution Name', 'Degree', 'Specialty', 'Time Frame');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrEducation'] as $row) {
                    $data1[$i][] = $kolArray[$row['kol_id']];
                    $data1[$i][] = ucwords($row['type']);
                    if ($row['type'] == 'honors_awards') {
                        $data1[$i][] = $row['honor_name'];
                    } else {
                        $data1[$i][] = $row['name'];
                    }
                    $data1[$i][] = $row['degree'];
                    $data1[$i][] = $row['specialty'];
                    $row['date'] = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $row['date'] .= $row['start_date'];
                    if (($row['start_date'] != '') && ($row['end_date']))
                        $row['date'] .= " - ";
                    if ($row['end_date'] != '')
                        $row['date'] .= $row['end_date'];
                    $data1[$i][] = $row['date'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $data1[$i][] = $row['url1'];
                        $data1[$i][] = $row['url2'];
                    }
                    $i++;
                }
            }
        }
        if (in_array('affiliation', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data2[0] = array('PIN', 'Organization Name', 'Dept/Committee', 'Title/Purpose', 'Time frame', 'Organization Type', 'Engagement Type', 'Url1', 'Url2');
            } else {
                $data2[0] = array('PIN', 'Organization Name', 'Dept/Committee', 'Title/Purpose', 'Time frame', 'Organization Type', 'Engagement Type');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrMembership'] as $row) {
                    $data2[$i][] = $kolArray[$row['kol_id']];
                    $data2[$i][] = $row['name'];
                    $data2[$i][] = $row['department'];
                    $data2[$i][] = $row['role'];
                    $row['date'] = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $row['date'] .= $row['start_date'];
                    if (($row['start_date'] != '') && ($row['end_date']))
                        $row['date'] .= " - ";
                    if ($row['end_date'] != '')
                        $row['date'] .= $row['end_date'];
                    $data2[$i][] = $row['date'];
                    $data2[$i][] = ucwords($row['type']);
                    $data2[$i][] = $row['engagement_type'];
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        if (isset($row['url1ForExport'])) {
                            $data2[$i][] = $row['url1ForExport'];
                        }
                        if (isset($row['ur12ForExport'])) {
                            $data2[$i][] = $row['ur12ForExport'];
                        }
                    }
                    $i++;
                }
            }
        }
        if (in_array('event', $exportOpts)) {
            if ($clientId == INTERNAL_CLIENT_ID) {
                $data3[0] = array('PIN', 'Event Name', 'Event Type', 'Session Type', 'Session Name', 'Role', 'Topic', 'Start', 'End', 'Organizer', 'Location', 'Address', 'Country', 'State', 'City', 'Postal Code', 'Url1', 'Url2');
            } else {
                $data3[0] = array('PIN', 'Event Name', 'Event Type', 'Session Type', 'Session Name', 'Role', 'Topic', 'Start', 'End', 'Organizer', 'Location', 'Address', 'Country', 'State', 'City', 'Postal Code');
            }
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrEvent'] as $row) {
                    if ($row['type'] == 'conference') {
                        $data3[$i][] = $kolArray[$row['kol_id']];
                        $data3[$i][] = $row['name'];
                        $data3[$i][] = $row['event_type'];
                        $data3[$i][] = $row['session_type'];
                        $data3[$i][] = $row['session_name'];
                        $data3[$i][] = $row['role'];
                        $data3[$i][] = $this->kol->getTopicName($row['topic']);
                        $data3[$i][] = $row['start'];
                        $data3[$i][] = $row['end'];
                        $data3[$i][] = $row['organizer'];
                        $data3[$i][] = $row['location'];
                        $data3[$i][] = $row['address'];
                        $data3[$i][] = $row['Country'];
                        $data3[$i][] = $row['Region'];
                        $data3[$i][] = $row['City'];
                        $data3[$i][] = $row['postal_code'];
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $data3[$i][] = $row['url1ForExport'];
                            }
                            if (isset($row['ur12ForExport'])) {
                                $data3[$i][] = $row['ur12ForExport'];
                            }
                        }
                    }
                    if ($row['type'] == 'online') {
                        $data3[$i][] = $kolArray[$row['kol_id']];
                        $data3[$i][] = ucwords($row['type']);
                        $data3[$i][] = $row['name'];
                        $data3[$i][] = $row['event_type'];
                        $data3[$i][] = $row['session_type'];
                        $data3[$i][] = $row['session_name'];
                        $data3[$i][] = $row['role'];
                        $data3[$i][] = $this->kol->getTopicName($row['topic']);
                        $data3[$i][] = $row['start'];
                        $data3[$i][] = $row['end'];
                        $data3[$i][] = $row['organizer'];
                        $data3[$i][] = $row['location'];
                        $data3[$i][] = '';
                        $data3[$i][] = $row['Country'];
                        $data3[$i][] = $row['Region'];
                        $data3[$i][] = $row['City'];
                        $data3[$i][] = '';
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $data3[$i][] = $row['url1ForExport'];
                            }
                            if (isset($row['ur12ForExport'])) {
                                $data3[$i][] = $row['ur12ForExport'];
                            }
                        }
                    }
                    $i++;
                }
            }
        }
        if (in_array('publication', $exportOpts)) {
            $data4[0] = array('PIN', 'Article Title', 'PMID', 'Journal Name', 'Date', 'Authors', 'Authorship Position');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrPublication'] as $row) {
                    $data4[$i][] = $kolArray[$row['kol_id']];
                    $data4[$i][] = $row['article_title'];
                    $data4[$i][] = $row['pmid'];
                    $data4[$i][] = $row['journal_name'];
                    $data4[$i][] = $row['date'];
                    $data4[$i][] = $row['authors'];
                    $data4[$i][] = $row['auth_pos'];
                    $i++;
                }
            }
        }
        if (in_array('trial', $exportOpts)) {
            //	$data5[0]							= array('PIN','CTID','Trial Name','Status','Sponsors','Condition','Intervention','Phase','Investigators');
            $data5[0] = array('PIN', 'CTID', 'Study Type', 'Trial Name', 'Condition', 'Intervention', 'Phase', 'Role', 'Number of enrollees', 'Number of trial sites', 'Sponsors', 'Status', 'Start Date', 'End Date', 'Minimum Age', 'Maximum Age', 'Gender', 'Investigators', 'Collaborator', 'Purpose', 'Official Title', 'Keywords', 'MeSH Terms', 'Url');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrClinicalTrial'] as $row) {
                    /* 	$data5[$i][]				= $kolArray[$row['kol_id']];
                      $data5[$i][]				= $row['ct_id'];
                      $data5[$i][]				= $row['trial_name'];
                      $data5[$i][]				= $row['status'];
                      $data5[$i][]				= $row['sponsors'];
                      $data5[$i][]				= $row['condition'];
                      $data5[$i][]				= $row['interventions'];
                      $data5[$i][]				= $row['phase'];
                      $data5[$i][]				= $row['investigators'];
                     */
                    $data5[$i][] = $kolArray[$row['kol_id']];
                    $data5[$i][] = $row['ct_id'];
                    $data5[$i][] = $row['study_type'];
                    $data5[$i][] = $row['trial_name'];
                    $data5[$i][] = $row['condition'];
                    $data5[$i][] = $row['interventions'];
                    $data5[$i][] = $row['phase'];
                    $data5[$i][] = $row['kol_role'];
                    $data5[$i][] = $row['no_of_enrollees'];
                    $data5[$i][] = $row['no_of_trial_sites'];
                    $data5[$i][] = $row['sponsors'];
                    $data5[$i][] = $row['status'];
                    $data5[$i][] = $row['start_date'];
                    $data5[$i][] = $row['end_date'];
                    $data5[$i][] = $row['min_age'];
                    $data5[$i][] = $row['max_age'];
                    $data5[$i][] = $row['gender'];
                    $data5[$i][] = $row['investigators'];
                    $data5[$i][] = $row['collaborator'];
                    $data5[$i][] = $row['purpose'];
                    $data5[$i][] = $row['official_title'];
                    $data5[$i][] = $row['keywords'];
                    $data5[$i][] = $row['mesh_terms'];
                    $data5[$i][] = $row['url'];
                    $i++;
                }
            }
        }
        if (in_array('media', $exportOpts)) {
            $data7[0] = array('PIN', 'Blog', 'Linkedin', 'Facebook', 'Twitter', 'YouTube');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrKol'] as $row) {
                    $data7[$i][] = $kolArray[$row['id']];
                    $data7[$i][] = $row['blog'];
                    $data7[$i][] = $row['linked_in'];
                    $data7[$i][] = $row['facebook'];
                    $data7[$i][] = $row['twitter'];
                    $data7[$i][] = $row['you_tube'];
                    $i++;
                }
            }
        }
        if (in_array('user_notes', $exportOpts)) {
            $data15[0] = array('PIN','Notes','Added By','Created On');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrUserNotes'] as $row) {
                    $data15[$i][] = $kolArray[$row['id']];
                    $data15[$i][] = $row['notes'];
                    $data15[$i][] = $row['added_by'];
                    $data15[$i][] = $row['created_on'];
                    $i++;
                }
            }
        }
        if (in_array('interaction', $exportOpts)) {
            $data6[0] = array('PIN', 'KOL Name', 'Date', 'Time', 'Mode', 'Location', ' Topic', 'Brand', 'Role', 'Follow-Up On', 'Category', 'Therapeutic Area', 'Notes');
            $i = 1;
            foreach ($dataContent['dataSet'] as $data) {
                foreach ($data['arrInteraction'] as $row) {
                    $data6[$i][] = $kolArray[$row['kol_id']];
                    $data6[$i][] = $arrSalutation['arrSalutations'][$row['salutation']] . " " . $row['first_name'] . " " . $row['middle_name'] . " " . $row['last_name'];
                    if ($row['date'] != '0000-00-00') {
                        $data6[$i][] = $row['date'];
                    } else {
                        $data6[$i][] = '';
                    }
                    $data6[$i][] = $row['time'];
                    $data6[$i][] = $row['mode_name'];
                    $data6[$i][] = $row['location'];
                    $data6[$i][] = $row['topic_name'];
                    $data6[$i][] = $row['brand_name'];
                    $data6[$i][] = $row['role_name'];
                    if ($row['follow_up_on'] != '0000-00-00') {
                        $data6[$i][] = $row['follow_up_on'];
                    } else {
                        $data6[$i][] = '';
                    }
                    $data6[$i][] = $row['category_name'];
                    $data6[$i][] = $row['area_name'];
                    $data6[$i][] = $row['notes'];
                    $i++;
                }
            }
        }
        //for downloading the file
        $excelPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kols_pdf/" . $kolName . ".xls";
        $workbook = new Spreadsheet_Excel_Writer($excelPath);
        // To allow more than 255 charecters.
        $workbook->setVersion(8);
        $format_und = & $workbook->addFormat();
        $format_und->setBottom(2); //thick
        $format_und->setRight(1);
        $format_und->setBold();
        $format_und->setHAlign('centre');
        $format_und->setVAlign('vcentre');
        $format_und->setColor('black');
        $format_und->setFontFamily('Arial');
        $format_und->setSize(11);
        $format_reg = & $workbook->addFormat();
        $format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);
        $arr = array();
        if (in_array('professional', $exportOpts)) {
            $sheet10 = $data10;
            $arr['Prof_Info'] = $sheet10;
        }
        if (in_array('contact', $exportOpts)) {
            $sheet9 = $data9;
            $arr['Contact Info'] = $sheet9;
        }
        if (in_array('biography', $exportOpts)) {
            $sheet8 = $data8;
            $arr['Profile Summary'] = $sheet8;
        }
        if (in_array('education', $exportOpts)) {
            $sheet1 = $data1;
            $arr['Education'] = $sheet1;
        }
        if (in_array('affiliation', $exportOpts)) {
            $sheet2 = $data2;
            $arr['Affiliation'] = $sheet2;
        }
        if (in_array('event', $exportOpts)) {
            $sheet3 = $data3;
            $arr['Event'] = $sheet3;
        }
        if (in_array('publication', $exportOpts)) {
            $sheet4 = $data4;
            $arr['Publication'] = $sheet4;
        }
        if (in_array('trial', $exportOpts)) {
            $sheet5 = $data5;
            $arr['Trial'] = $sheet5;
        }
        if (in_array('media', $exportOpts)) {
            $sheet7 = $data7;
            $arr['Social Media'] = $sheet7;
        }
        if (in_array('interaction', $exportOpts)) {
            $sheet6 = $data6;
            $arr['Interaction'] = $sheet6;
        }
        if (in_array('user_notes', $exportOpts)) {
            $sheet15 = $data15;
            $arr['User Notes'] = $sheet15;
        }
        foreach ($arr as $wbname => $rows) {
            $rowcount = count($rows);
            $colcount = count($rows[0]);
            $worksheet = & $workbook->addWorksheet($wbname);
            $worksheet->setColumn(0, 0, 5); //setColumn(startcol,endcol,float)
            if ($wbname == 'Prof_Info') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Contact Info') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Profile Summary') {
                $worksheet->setColumn(1, 40, 40);
            } else if ($wbname == 'Education') {
                $worksheet->setColumn(1, 1, 40.00);
                $worksheet->setColumn(2, 6, 15.00);
            } else if ($wbname == 'Affiliation') {
                $worksheet->setColumn(1, 3, 40.00);
                $worksheet->setColumn(4, 9, 15.00);
            } else if ($wbname == 'Event') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Publication') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Trial') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Social Media') {
                $worksheet->setColumn(1, 18, 30);
            } else if ($wbname == 'Interaction') {
                $worksheet->setColumn(1, 18, 30);
            }else if ($wbname == 'User Notes') {
                $worksheet->setColumn(1, 18, 30);
            }
            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;
                    if ($j == 0)
                        $fmt = & $format_und;
                    if (isset($rows[$j][$i])) {
                        $value = utf8_decode($rows[$j][$i]);
                        //Format 'postal code cells as 'string'
                        if ($wbname == 'Contact Info' && $i == 8) {
                            $worksheet->writeString($j, $i, $value, $fmt);
                        } else
                            $worksheet->write($j, $i, $value, $fmt);
                    }
                }
            }
        }
        $workbook->close();
        return $excelPath;
    }

    /* Calculate KOLs activity count
     *
     * @author Vinayak
     * @since May 5,2012
     * @version 3.10
     * @param $kolId
     */

    function getKolProfileScore($kolId) {
        //$maxActvityCount 				= $this->kol_rating->getMaxActivitiesCount();
        //	$sumOfMaxCountOfIndividualParam =
        //Getting Total Activity count for Partcular KOL
        $kolTotalActivitiesCount = $this->kol_rating->getKolTotalActivityCount1($kolId);
        //echo $kolTotalActivitiesCount;

        $spcilatyId = $this->kol_rating->gerSpecilatyIdByKol($kolId);
        $maxCount = $this->kol_rating->getMaxTotalCountOfKolBySpecialty($spcilatyId);
        //$maxCountOfAllIndividualParam = $this->kol_rating->getMaxCountBySpecialty($spcilatyId);
        //$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
        //$kolsPforfileScore	=($kolTotalActivitiesCount/$maxCount)*100;
        if ($maxCount > 0) {
            $kolsPforfileScore = ($kolTotalActivitiesCount / $maxCount) * 100;
        } else {
            $kolsPforfileScore = 0;
        }
        /* foreach($arrKolTotalActivitiesCount as $key=>$value){
          if($value['specialty']==0){
          $count 				= $value['totalScore'];
          $kolsPforfileScore	=($count/$max)*100;
          }else{
          $count 				= $value['totalScore'];
          $count1				= $maxActvityCount[$value['specialty']]['maxActivityCount'];
          $kolsPforfileScore	=($count/$count1)*100;
          }
          } */

        $kolsPforfileScore = $this->kol_rating->getProfileScore($kolId);
        return $kolsPforfileScore;
    }

    /* To remember the visibility of bottom dock and refined by filter
     *
     * @author Laxman K
     * @since May 7,2012
     * @version 3.10
     * @param 	$sessionName
     * 			$visibility i.e value should be either show or hide
     */

    function remember_slider($sessionName, $visibility = 'show') {
        if (!empty($sessionName))
            $this->session->set_userdata($sessionName, $visibility);
    }

    /* Gets the affiliation details and shows in microview page
     *
     * @author Ramesh B
     * @since June 6,2012
     * @version 4.2
     * @param $affId
     */

    function view_micro_affiliation($affId) {
        $data = array();
        // Getting the Payment details
        $arrAffDetails = $this->kol->getAffiliationById($affId);
        $data['arrAffDetails'] = $arrAffDetails;
        $this->load->view('memberships_affiliations/affiliation_micro_view', $data);
    }

    /* Gets the event details and shows in microview page
     *
     * @author Ramesh B
     * @since June 6,2012
     * @version 4.2
     * @param $eventId
     */

    function view_micro_event($eventId) {
        $data = array();

        // Getting the Payment details
        $arrEvents[] = $this->kol->getEventById($eventId);
        foreach ($arrEvents as $row) {
            $row['start'] = sql_date_to_app_date($row['start']);
            $row['end'] = sql_date_to_app_date($row['end']);
            $arrEventsResult[] = $row;
        }
        $data['arrEvents'] = $arrEventsResult;
        $this->load->view('events/view_events_micro_profile', $data);
    }

    /* Save the Conatct details
     *
     */

    function additional_contact() {
        $arrContacts['kol_id'] = $this->input->post('kol_id');
        $arrContacts['type'] = $this->input->post('type');
        $arrContacts['location'] = $this->input->post('location');
        $arrContacts['org_id'] = $this->input->post('org_id');
        $arrContacts['title'] = $this->input->post('title');
        $arrContacts['division'] = $this->input->post('division');
        $arrContacts['address'] = $this->input->post('address1');
        $arrContacts['fax'] = $this->input->post('fax');
        $arrContacts['phone'] = $this->input->post('primary_phone');
        $arrContacts['email'] = $this->input->post('primary_email');
        $arrContacts['country_id'] = $this->input->post('country_id');
        $arrContacts['state_id'] = $this->input->post('state_id');
        $arrContacts['city_id'] = $this->input->post('city_id');
        $arrContacts['client_id'] = $this->session->userdata('client_id');
        $arrContacts['created_by'] = $this->session->userdata['user_id'];
        if ($id = $this->kol->saveAdditionalContact($arrContacts)) {
            $locationType = array(
                '1' => 'Private practice',
                '2' => 'Hospital',
                '3' => 'Institution',
                '4' => 'Physical',
                '5' => 'Others'
            );
            $data['status'] = 'success';
            $data['lastInsertId'] = $id;
            $data['data']['type'] = $locationType[$arrContacts['type']];
            $data['data']['address'] = $arrContacts['address'];
            $data['data']['phone'] = $arrContacts['phone'];
            $data['data']['act'] = "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteContact('" . $id . "');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\">&nbsp;</a></div></label>";
        } else {
            $data['status'] = 'unsuccess';
        }
        echo json_encode($data);
    }

    /**
     * Delete the Contact detail From DB
     *
     */
    function delete_contact_detail($id) {
        if ($this->kol->deleteContactsDetailById($id)) {
            echo 'success';
        } else {
            echo 'failed to delete';
        }
    }

    function get_kol_names_for_autocomplete_test($kolName) {
        $arrKolNames = $this->kol->getKolNamesForAutocompleteTest($kolName);
        $arr['query'] = $kolName;
        $arr['suggestions'] = $arrKolNames;
        echo json_encode($arr);
    }

    function get_kol_names_for_autocomplete_refineby($restrictOptInVisbility=0,$kolName) {
        $kolName = utf8_urldecode($this->input->post('keyword'));
        $arrKolNames1 = array();
        $arrKolNames = $this->interaction->getAllKolNamesForAutocompleteRefineBy($kolName,$restrictOptInVisbility);
        //pr($arrKolNames);
        if ((sizeof($arrKolNames)) < 1) {
            $arrKolNames1[] = '<div style="padding-left:5px;">No results found for ' . $kolName . '</div><div><label name="No results found for ' . $kolName . '" class="kolName" style="display:block"></label><label class="orgName"></label><span style="display:none" class="id1"></span></div>';
        } else {
            foreach ($arrKolNames as $key => $row) {
                $arrKolNames1[] = '<div class="dataSet"><label name="' . $row[0] . '" class="kolName" style="display:block">' . $row[0] . '</label><label>' . $row[1] . '</label><span style="display:none" class="id1">' . $row[3] . '</span><span style="display:none" class="profile_type">' . $row[2] . '</span></div>';
            }
        }
        $arr['query'] = $kolName;
        $arr['suggestions'] = $arrKolNames1;
        echo json_encode($arr);
    }

    /* Retrives the dashboard charts data and prepares the json formated data and returns
     *
     * @author Ramesh B
     * @since oct 30,2012
     * @version otsuka1.0.3
     * @param $kolId
     * @return JSON
     */

    function get_dashboard_charts_data($kolId) {
        $this->load->model('json_store');
        $jsonFilter = "kol_id:" . $kolId;
        $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_DASHBOARD, $jsonFilter);
        if ($arrStoredJson == false) {
            $data = array();
            $data['affByOrgTypeData'] = array();
            $data['affByEngTypeData'] = array();
            $data['eventsTimelineData'] = array();
            $data['eventsByTopicData'] = array();
            $data['pubsByTimeData'] = array();
            $data['pubsAuthPosData'] = array();

            //-------------------------Affiliations by Org Type chart----------------------------------
            $arrKolIds[] = $kolId;
            $arrAffiliations = $this->kol->getAffiliationsByParam(0, 0, $arrKolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds = '', $arrSpecialityIds = '', $selectType = 'kol_memberships.type', $arrListNamesIds = '', $arrStatesIds = '');
            $arrOrgCounts = array();
            foreach ($arrAffiliations as $row) {
                $arr = array();
                if ($row['type'] == "university") {
                    $arr[] = "University/Hospital";
                } else {
                    $arr[] = ucwords($row['type']);
                }
                $arr[] = (int) $row['count'];
                $arrOrgCounts[] = $arr;
            }
            $data['affByOrgTypeData'] = $arrOrgCounts;

            //-------------------------Affiliations by Eng Type chart----------------------------------
            $arrAffiliations = array();
            $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes = '', $arrOrgType, $arrCountriesIds, $arrSpecialityIds, $selectType = 'engagement_types.engagement_type', $arrListNamesIds, $arrStatesIds);
            $arrEngagementCounts = array();
            foreach ($arrAffiliations as $row) {
                $arr = array();
                if ($row['engagement_type'] != '') {
                    $arr[] = $row['engagement_type'];
                    $arr[] = (int) $row['count'];
                    $arrEngagementCounts[] = $arr;
                }
            }
            $data['affByEngTypeData'] = $arrEngagementCounts;

            //-------------------------Events by timeline chart----------------------------------
            $arrEventsTimelineData = $this->get_event_types_timeline_chart($kolId);
            $data['eventsTimelineData'] = $arrEventsTimelineData;

            //-------------------------Events by Topic chart----------------------------------
            $arrEventTopics = array();
            $arrEventsTopic = $this->kol->getDataForEventsTopicChart($kolId, 0, 0);
            foreach ($arrEventsTopic as $row) {
                $arrTopic = array();
                $arrTopic[] = $row['name'];
                $arrTopic[] = (int) $row['count'];
                $arrEventTopics[] = $arrTopic;
            }
            $data['eventsByTopicData'] = $arrEventTopics;

            //-------------------------Publications by timeline chart----------------------------------
            $arrPublications = $this->kol->getPublicationChart($kolId, 0, 0);
            $pubsByTimeData = array();
            $years = array();
            $count = array();
            
            foreach ($arrPublications as $publication) {
                if($publication['year']>0){
                    $years[] = $publication['year'];
                    $count[] = (int) $publication['count'];
                }
            }
            $pubsByTimeData[] = array_reverse($years);
            $pubsByTimeData[] = array_reverse($count);
            $data['pubsByTimeData'] = $pubsByTimeData;

            //-------------------------Publicatons authorship position chart----------------------------------
            $arrSingleAuthPubs = $this->pubmed->getKolPubsWithSingleAuthor($kolId, 0, 0);
            $arrFirstAuthPubs = $this->pubmed->getKolPubsWithFirstAuthorship($kolId, 0, 0);
            $arrLastAuthPubs = $this->pubmed->getKolPubsWithLastAuthorship($kolId, 0, 0);
            $arrMiddleAuthPubs = $this->pubmed->getKolPubsWithMiddleAuthorship($kolId, 0, 0);

            $arrSingleAuthPubsCount = sizeof($arrSingleAuthPubs);
            $arrFirstAuthPubsCount = sizeof($arrFirstAuthPubs);
            $arrLastAuthPubsCount = 0;
            $arrMiddleAuthPubsCount = 0;

            foreach ($arrLastAuthPubs as $lastAuthPub) {
                if ($lastAuthPub['auth_pos'] == $lastAuthPub['max_pos'] && $lastAuthPub['max_pos'] != 1)
                    $arrLastAuthPubsCount++;
            }

            foreach ($arrMiddleAuthPubs as $middleAuthPub) {
                if ($middleAuthPub['auth_pos'] != $middleAuthPub['max_pos'])
                    $arrMiddleAuthPubsCount++;
            }
            $arrSectors = array(
                array("First Authorship", (int) $arrFirstAuthPubsCount),
                array("Single Authorship", (int) $arrSingleAuthPubsCount),
                array("Middle Authorship", (int) $arrMiddleAuthPubsCount),
                array("Last Authorship", (int) $arrLastAuthPubsCount),
            );
            $arrSectorsData = array();
            foreach ($arrSectors as $sector) {
                if ($sector[1] != 0)
                    $arrSectorsData[] = $sector;
            }
            $data['pubsAuthPosData'] = $arrSectorsData;

            //-------------------------Influence Map data calculation----------------------------------
            $arrFilterFields = array();
            $arrKeywords = array();
            $name = '';
            $arrPubDegrees = array('edu', 'org', 'aff', 'event', 'pub', 'trial');
            $kolName = $this->kol->getKolName($kolId);
            $arrKolIds = array();
            $arrKeywords[0] = $name;
            $arrKolDetailResult = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, 0, 0, false, false, null, $arrKolIds, true);

            $arrKolDetails = array();
            foreach ($arrKolDetailResult as $row) {
                $details = array();
                $details['first_name'] = $row['first_name'];
                $details['last_name'] = $row['last_name'];

                $arrKolDetails[$row['id']] = $details;
            }
            //pr($arrKolDetails);
            $arrData = array();
            $arrPubKols = array();
            $arrEventKols = array();
            $arrAffKols = array();
            $arrEduKols = array();
            $arrOrgKols = array();
            $arrTrialKols = array();

            if (in_array('pub', $arrPubDegrees))
                $arrPubKols = $this->pubmed->getCoAuthoredKols($kolId);
            if (in_array('event', $arrPubDegrees))
                $arrEventKols = $this->kol->getCoEventedKols($kolId);
            if (in_array('aff', $arrPubDegrees))
                $arrAffKols = $this->kol->getCoAffiliatedKols($kolId);
            if (in_array('edu', $arrPubDegrees))
                $arrEduKols = $this->kol->getCoEducatedKols($kolId, $arrFilterFields);
            if (in_array('org', $arrPubDegrees))
                $arrOrgKols = $this->kol->getCoOrganizedKols($kolId, $arrFilterFields);
            if (in_array('trial', $arrPubDegrees))
                $arrTrialKols = $this->clinical_trial->getCoTrialledKols($kolId, $arrFilterFields);
            $arrKols = $this->get_unique_kolids_with_weightages($arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols);
            if (sizeof($arrKols) > 0) {
                $arrData = $arrKols;
            }
            //Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
            $nodeData = array();
            $nodeData['$lineWidth'] = 5;
            $nodeData['$color'] = "#ddeeff";
            $nodeData['$dim'] = 0;
            $influenceData = array();
            $centerNode = array();
            $influenceData['id'] = 'kol-' . $kolId;
            $influenceData['name'] = $kolName['first_name'] . " " . $kolName['middle_name'] . " " . $kolName['last_name'];
            $influenceData['data'] = $nodeData;
            $influenceData['children'] = array();
            foreach ($arrData as $key => $value) {
                //echo "KolId : ".$key."<br>";
                $nodeData = array();
                $nodeData['$color'] = "#555555";
                $nodeData['connections'] = $value['count'];
                $nodeDetails = array();
                $nodeDetails['id'] = $key;
                $nodeDetails['name'] = $arrKolDetails[$key]['first_name'] . " " . $arrKolDetails[$key]['last_name'];
                $nodeDetails['data'] = $nodeData;
                $arrAdjecencies = array();
                $nodeDetails['children'] = $arrAdjecencies;
                $influenceData['children'][] = $nodeDetails;
            }
            $retunData['connectionData'] = $influenceData;
            $retunData['coAuthorsKOLIds'] = array();
            $data['influenceData'] = $retunData;

            $rowData['json_data'] = json_encode($data);
            $rowData['ref_id'] = JSON_STORE_DASHBOARD;
            $rowData['filter'] = "kol_id:" . $kolId;
            $this->json_store->insertJsonToStore($rowData);

            ob_start('ob_gzhandler');
            echo json_encode($data);
        } else {
            $data = $arrStoredJson['json_data'];
            ob_start('ob_gzhandler');
            echo $data;
        }
    }

    /* Retrives Events by timeline chart data and this is used in the above method 'get_dashboard_charts_data'
     *
     * @author Ramesh B
     * @since oct 30,2012
     * @version otsuka1.0.3
     * @param $kolId
     * @return Array
     */

    function get_event_types_timeline_chart($kolId) {
        $arrKolIds = array();
        $arrKolIds[] = $kolId;
        $congressData = array();
        $conferenceData = array();
        $grData = array();
        $amData = array();
        $cmeData = array();
        $webcastData = array();
        $webinarData = array();
        $podcastData = array();
        $arrEventTypeDetails = $this->kol->getEventTypesCountByTimeLine(0, 0, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds);

        //get unique years
        $arrUniqueYears = $this->get_unique_years($arrEventTypeDetails);
        $arrEventTypeCount = array();
        $arrEventTypes = array();
        $arrEventTypesData = array();
        $arrUniqueYear = array();
        foreach ($arrEventTypeDetails as $eventTypeDetail) {
            $arrEventTypeCount[$eventTypeDetail['year']][$eventTypeDetail['event_type']] += (int) $eventTypeDetail['count'];
            //$arrEventTypeCount[$eventTypeDetail['event_type']][$eventTypeDetail['year']] += (int)$eventTypeDetail['count'];
            $arrEventTypes[$eventTypeDetail['event_type']] = 1;
        }
        ksort($arrEventTypeCount);
        foreach ($arrEventTypeCount as $year => $arrRow) {
            $arrUniqueYear[] = (string) $year;
            foreach ($arrEventTypes as $eventType => $value) {
                if (isset($arrRow[$eventType])) {
                    $arrEventTypesData[$eventType][] = $arrRow[$eventType];
                } else {
                    $arrEventTypesData[$eventType][] = 0;
                }
            }
        }
        //pr($arrEventTypesData);
        $arrTypesData = array();
        $arrData[] = array_values($arrUniqueYear);
        foreach ($arrEventTypes as $eventType => $value) {
            $arrTypesData[] = array('name' => $eventType, 'data' => $arrEventTypesData[$eventType]);
        }       
        $arrData[] = $arrTypesData;
        return $arrData;
        /*
          //pr($arrEventTypeDetails);
          foreach($arrUniqueYears as $year){
          //collect the Congress type counts for this year
          $congressDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Congress'){
          $checkCongress = true;
          $congressDataCount+=(int)$eventTypeDetail['count'];
          }
          }

          $congressData[]=(int)$congressDataCount;

          //collect the Conference type counts for this year
          $conferenceDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Conference'){
          $checkConference = true;
          $conferenceDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $conferenceData[]=(int)$conferenceDataCount;

          //collect the Grand Rounds type counts for this year
          $grDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Grand Round'){
          $checkGrand = true;
          $grDataCount+=(int)$eventTypeDetail['count'];
          }
          $grData[]=(int)$grDataCount;

          //collect the Annual Meeting type counts for this year
          $amDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Annual Meeting'){
          $checkAnual = true;
          $amDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $amData[]=(int)$amDataCount;

          //collect the CME type counts for this year
          $cmeDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='CME'){
          $cmeDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $cmeData[]=(int)$cmeDataCount;


          //collect the webcast type counts for this year
          $webcastDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Webcast'){
          $webcastDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $webcastData[]=(int)$webcastDataCount;


          //collect the webinar type counts for this year
          $webinarDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Webinar'){
          $webinarDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $webinarData[]=(int)$webinarDataCount;

          //collect the podcast type counts for this year
          $podcastDataCount=0;
          foreach($arrEventTypeDetails as $eventTypeDetail){
          if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Podcast'){
          $podcastDataCount+=(int)$eventTypeDetail['count'];
          }
          }
          $podcastData[]=(int)$podcastDataCount;

          }

          $arrData[]=array_values($arrUniqueYears);

          //[["2004","2006","2007","2008","2009","2010","2011"],
          //	[{"name":"congress","data":[1,2,3,4,4,4,4]},{"name":"Conference","data":[1,2,3,4,4,4,4]}]]



          if($checkCongress){
          //$arrData[]=$congressData;
          $congData = array('name'=>'Congress','data'=>$congressData);
          $arrEventTypes[]=$congData;
          }

          if($checkConference){
          //$arrData[]=$congressData;
          $confData = array('name'=>'Conference','data'=>$conferenceData);
          $arrEventTypes[]=$confData;
          }
          //$arrData[]=$conferenceData;
          if($checkGrand){
          //$arrData[]=$congressData;
          $grandData = array('name'=>'Grand Round','data'=>$grData);
          $arrEventTypes[]=$grandData;
          }

          if($checkAnual){
          //$arrData[]=$congressData;
          $annulData = array('name'=>'Annual Meeting','data'=>$amData);
          $arrEventTypes[]=$annulData;
          }

          $arrData[]=$arrEventTypes;
          //	$arrData[] =  array(array('name'=>'congress','data'=>array(1,2,3,4,4,4,4)),array('name'=>'Conference','data'=>array(1,2,3,4,4,4,4)));
          //echo json_encode($arrData);
          return $arrData;
         */
    }

    /* Fetches the array of unique years form the array of events details count and sorts them in revers order
     *
     * @author Ramesh B
     * @since oct 30,2012
     * @version otsuka1.0.3
     * @param $arrEventTypeDetails
     * @return Array
     */

    function get_unique_years($arrEventTypeDetails) {
        $arrYears = array();
        foreach ($arrEventTypeDetails as $eventTypeDetail) {
            $arrYears[] = $eventTypeDetail['year'];
        }
        $arrUniqueYears = array_unique($arrYears);
        sort($arrUniqueYears);
        return $arrUniqueYears;
    }

    /* Loop trought all the array and prpares a array of unique kolId's with combined weightges
     *
     * @author Ramesh B
     * @since oct 30,2012
     * @version otsuka1.0.3
     * @param $arrEventTypeDetails
     * @return Array
     */

    function get_unique_kolids_with_weightages($arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols) {
        $arrKols = array();
        if (sizeof($arrPubKols) > 0) {
            foreach ($arrPubKols as $row) {
                $arrKols[$row['kol_id']] = $row;
            }
        }

        if (sizeof($arrEventKols) > 0) {
            foreach ($arrEventKols as $row) {
                if (array_key_exists($row['kol_id'], $arrKols)) {
                    $arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
                } else {
                    $arrKols[$row['kol_id']] = $row;
                }
            }
        }

        if (sizeof($arrAffKols) > 0) {
            foreach ($arrAffKols as $row) {
                if (array_key_exists($row['kol_id'], $arrKols)) {
                    $arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
                } else {
                    $arrKols[$row['kol_id']] = $row;
                }
            }
        }
        if (sizeof($arrOrgKols) > 0) {
            foreach ($arrOrgKols as $row) {
                if (array_key_exists($row['kol_id'], $arrKols)) {
                    $arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
                } else {
                    $arrKols[$row['kol_id']] = $row;
                }
            }
        }
        if (sizeof($arrEduKols) > 0) {
            foreach ($arrEduKols as $row) {
                if (array_key_exists($row['kol_id'], $arrKols)) {
                    $arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
                } else {
                    $arrKols[$row['kol_id']] = $row;
                }
            }
        }
        if (sizeof($arrTrialKols) > 0) {
            foreach ($arrTrialKols as $row) {
                if (array_key_exists($row['kol_id'], $arrKols)) {
                    $arrKols[$row['kol_id']]['count'] = (int) $arrKols[$row['kol_id']]['count'] + (int) $row['count'];
                } else {
                    $arrKols[$row['kol_id']] = $row;
                }
            }
        }

        return $arrKols;
    }

    function reset_kol_data() {
        $clientId = $this->session->userdata('client_id');
        if ($clientId == INTERNAL_CLIENT_ID) {
            $submitted = trim($this->input->post('process'));
            $arrKolIds = explode(',', $this->input->post('kol_ids'));
            $msg = '';
            if (!empty($submitted) && sizeof($arrKolIds) > 0) {
                $arrSections = $this->input->post('arrSections');
                foreach ($arrSections as $key => $section) {
                    switch ($section) {
                        case 'edu':
                            $this->kol->deleteEducationsByKolId($arrKolIds);
                            $msg.='Education Details are deleted<br />';
                            break;
                        case 'aff':
                            $this->kol->deleteAffiliationsByKolId($arrKolIds);
                            $msg.='Affiliation Details are deleted<br />';
                            break;
                        case 'events':
                            $this->kol->deleteEventsByKolId($arrKolIds);
                            $msg.='Events Details are deleted<br />';
                            break;
                        case 'ct':
                            $this->clinical_trial->deleteTrialsByKolId($arrKolIds);
                            $msg.='Clinical Trial Details are deleted<br />';
                            break;
                        case 'pinfo':
                            $this->kol->deletePersonalInfoByKolId($arrKolIds);
                            $msg.='Personal Information is deleted<br />';
                            break;
                        case 'contacts':
                            $this->kol->deleteAdditionalContactByKolId($arrKolIds);
                            $msg.='Additional Contact Details are deleted<br />';
                            break;
                    }
                }
            }
            $data['msg'] = $msg;
            $data['contentPage'] = 'kols/reset_data';
            $this->load->view('layouts/analyst_view', $data);
        }
    }

    function calculate_dashboard_data($kolId = null) {
    	ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->model('json_store');
        if ($kolId != null)
            $arrKols = array($kolId => 0);
        else
            $arrKols = $this->kol->getKolsIdAndPin();

        foreach ($arrKols as $kolId => $pin) {
            $jsonFilter = "kol_id:" . $kolId;
            $this->json_store->deleteFromStore(JSON_STORE_DASHBOARD, $jsonFilter);
            $data = array();
            $data['affByOrgTypeData'] = array();
            $data['affByEngTypeData'] = array();
            $data['eventsTimelineData'] = array();
            $data['eventsByTopicData'] = array();
            $data['pubsByTimeData'] = array();
            $data['pubsAuthPosData'] = array();

            //-------------------------Affiliations by Org Type chart----------------------------------
            $arrKolIds[] = $kolId;
            $arrAffiliations = $this->kol->getAffiliationsByParam(0, 0, $arrKolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds = '', $arrSpecialityIds = '', $selectType = 'kol_memberships.type', $arrListNamesIds = '', $arrStatesIds = '');
            $arrOrgCounts = array();
            foreach ($arrAffiliations as $row) {
                $arr = array();
                if ($row['type'] == "university") {
                    $arr[] = "University/Hospital";
                } else {
                    $arr[] = ucwords($row['type']);
                }
                $arr[] = (int) $row['count'];
                $arrOrgCounts[] = $arr;
            }
            $data['affByOrgTypeData'] = $arrOrgCounts;

            //-------------------------Affiliations by Eng Type chart----------------------------------
            $arrAffiliations = array();
            $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes = '', $arrOrgType, $arrCountriesIds, $arrSpecialityIds, $selectType = 'engagement_types.engagement_type', $arrListNamesIds, $arrStatesIds);
            $arrEngagementCounts = array();
            foreach ($arrAffiliations as $row) {
                $arr = array();
                if ($row['engagement_type'] != '') {
                    $arr[] = $row['engagement_type'];
                    $arr[] = (int) $row['count'];
                    $arrEngagementCounts[] = $arr;
                }
            }
            $data['affByEngTypeData'] = $arrEngagementCounts;

            //-------------------------Events by timeline chart----------------------------------
            $arrEventsTimelineData = $this->get_event_types_timeline_chart($kolId);
            $data['eventsTimelineData'] = $arrEventsTimelineData;

            //-------------------------Events by Topic chart----------------------------------
            $arrEventTopics = array();
            $arrEventsTopic = $this->kol->getDataForEventsTopicChart($kolId, 0, 0);
            foreach ($arrEventsTopic as $row) {
                $arrTopic = array();
                $arrTopic[] = $row['name'];
                $arrTopic[] = (int) $row['count'];
                $arrEventTopics[] = $arrTopic;
            }
            $data['eventsByTopicData'] = $arrEventTopics;

            //-------------------------Publications by timeline chart----------------------------------
            $arrPublications = $this->kol->getPublicationChart($kolId, 0, 0);
            $pubsByTimeData = array();
            $years = array();
            $count = array();
            foreach ($arrPublications as $publication) {
                $years[] = $publication['year'];
                $count[] = (int) $publication['count'];
            }
            $pubsByTimeData[] = array_reverse($years);
            $pubsByTimeData[] = array_reverse($count);
            $data['pubsByTimeData'] = $pubsByTimeData;

            //-------------------------Publicatons authorship position chart----------------------------------
            $arrSingleAuthPubs = $this->pubmed->getKolPubsWithSingleAuthor($kolId, 0, 0);
            $arrFirstAuthPubs = $this->pubmed->getKolPubsWithFirstAuthorship($kolId, 0, 0);
            $arrLastAuthPubs = $this->pubmed->getKolPubsWithLastAuthorship($kolId, 0, 0);
            $arrMiddleAuthPubs = $this->pubmed->getKolPubsWithMiddleAuthorship($kolId, 0, 0);

            $arrSingleAuthPubsCount = sizeof($arrSingleAuthPubs);
            $arrFirstAuthPubsCount = sizeof($arrFirstAuthPubs);
            $arrLastAuthPubsCount = 0;
            $arrMiddleAuthPubsCount = 0;

            foreach ($arrLastAuthPubs as $lastAuthPub) {
                if ($lastAuthPub['auth_pos'] == $lastAuthPub['max_pos'] && $lastAuthPub['max_pos'] != 1)
                    $arrLastAuthPubsCount++;
            }

            foreach ($arrMiddleAuthPubs as $middleAuthPub) {
                if ($middleAuthPub['auth_pos'] != $middleAuthPub['max_pos'])
                    $arrMiddleAuthPubsCount++;
            }
            $arrSectors = array(
                array("First Authorship", (int) $arrFirstAuthPubsCount),
                array("Single Authorship", (int) $arrSingleAuthPubsCount),
                array("Middle Authorship", (int) $arrMiddleAuthPubsCount),
                array("Last Authorship", (int) $arrLastAuthPubsCount),
            );
            $arrSectorsData = array();
            foreach ($arrSectors as $sector) {
                if ($sector[1] != 0)
                    $arrSectorsData[] = $sector;
            }
            $data['pubsAuthPosData'] = $arrSectorsData;

            //-------------------------Influence Map data calculation----------------------------------
            $arrFilterFields = array();
            $name = '';
            $arrPubDegrees = array('edu', 'org', 'aff', 'event', 'pub', 'trial');
            $kolName = $this->kol->getKolName($kolId);
            $arrKolIds = array();
            $arrKeywords[0] = $name;
            $arrKolDetailResult = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, 0, 0, false, false, null, $arrKolIds, true);

            $arrKolDetails = array();
            foreach ($arrKolDetailResult as $row) {
                $details = array();
                $details['first_name'] = $row['first_name'];
                $details['last_name'] = $row['last_name'];

                $arrKolDetails[$row['id']] = $details;
            }
            //pr($arrKolDetails);exit;
            $arrData = array();
            $arrPubKols = array();
            $arrEventKols = array();
            $arrAffKols = array();
            $arrEduKols = array();
            $arrOrgKols = array();
            $arrTrialKols = array();

            if (in_array('pub', $arrPubDegrees))
                $arrPubKols = $this->pubmed->getCoAuthoredKols($kolId);
            if (in_array('event', $arrPubDegrees))
                $arrEventKols = $this->kol->getCoEventedKols($kolId);
            if (in_array('aff', $arrPubDegrees))
                $arrAffKols = $this->kol->getCoAffiliatedKols($kolId);
            if (in_array('edu', $arrPubDegrees))
                $arrEduKols = $this->kol->getCoEducatedKols($kolId, $arrFilterFields);
            if (in_array('org', $arrPubDegrees))
                $arrOrgKols = $this->kol->getCoOrganizedKols($kolId, $arrFilterFields);
            if (in_array('trial', $arrPubDegrees))
                $arrTrialKols = $this->clinical_trial->getCoTrialledKols($kolId, $arrFilterFields);
            $arrKols = $this->get_unique_kolids_with_weightages($arrPubKols, $arrEventKols, $arrAffKols, $arrEduKols, $arrOrgKols, $arrTrialKols);
            if (sizeof($arrKols) > 0) {
                $arrData = $arrKols;
            }

            //Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
            $nodeData = array();
            $nodeData['$lineWidth'] = 5;
            $nodeData['$color'] = "#ddeeff";
            $nodeData['$dim'] = 0;
            $influenceData = array();
            $centerNode = array();
            $influenceData['id'] = 'kol-' . $kolId;
            $influenceData['name'] = $kolName['first_name'] . " " . $kolName['middle_name'] . " " . $kolName['last_name'];
            $influenceData['data'] = $nodeData;
            $influenceData['children'] = array();
            foreach ($arrData as $key => $value) {
                //echo "KolId : ".$key."<br>";
                $nodeData = array();
                $nodeData['$color'] = "#555555";
                $nodeData['connections'] = $value['count'];
                $nodeDetails = array();
                $nodeDetails['id'] = $key;
                $nodeDetails['name'] = $arrKolDetails[$key]['first_name'] . " " . $arrKolDetails[$key]['last_name'];
                $nodeDetails['data'] = $nodeData;
                $arrAdjecencies = array();
                $nodeDetails['children'] = $arrAdjecencies;
                $influenceData['children'][] = $nodeDetails;
            }
            $retunData['connectionData'] = $influenceData;
            $retunData['coAuthorsKOLIds'] = array();
            $data['influenceData'] = $retunData;
            if (sizeof($influenceData['children']) > 0)
                $sampleName = $influenceData['children'][0]['name'];
            else
                $sampleName = 'NA';
            if ($sampleName != '') {
                $rowData['json_data'] = json_encode($data);
                $rowData['ref_id'] = JSON_STORE_DASHBOARD;
                $rowData['filter'] = "kol_id:" . $kolId;
                $this->json_store->insertJsonToStore($rowData);
                echo "Id :" . $kolId . '<br>';
            } else {
                echo $kolId . '<br>';
            }
        }
        echo "Calculation Complete.";
        $filePath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "system/logs/jobs/cron_job_status.txt";
        $content = "dashboard_data_cron.php :: " . date("Y-m-d H:i:s") . "::success :: no comments \r\n";
        file_put_contents($filePath, $content, FILE_APPEND | LOCK_EX);
    }

    function reset_profile_image() {
        $data['status'] = 'Failed to reset profile image';
        $clientId = $this->session->userdata('client_id');
        if ($clientId == INTERNAL_CLIENT_ID) {
            $kolId = $this->input->post('kol_id');
            if ($this->kol->resetProfileImage($kolId)) {
                $data['status'] = 'Successfully resetted to default profile image';
            }
        }
        echo $data['status'];
    }

    /*
     * Lists all processed kols for analyst application, it's for ajax pagination,search and sort version of jqgrid
     * @author Ramesh B
     * @since 22 Feb 2013
     * @version otsuka1.0.11
     * @return JSON
     */

    function list_kols_grid() {
        ini_set('memory_limit', '-1');
        $page = $_REQUEST['page']; // get the requested page
        $limit = $_REQUEST['rows']; // get how many rows we want
        $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
        $sord = $_REQUEST['sord']; // get the direction
        if (!$sidx)
            $sidx = 1;

        //if ($page > $total_pages) $page=$total_pages;
        //$start = $limit*$page - $limit; // do not put $limit*($page - 1)
        //if ($start < 0) $start = 0;
        $filterData = $_REQUEST['filters'];
        $arrFilter = array();
        $arrFilter = json_decode(stripslashes($filterData));
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
        $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
        $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
        $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
        $whereResultArray = array();
        foreach ($searchField as $key => $val) {
            $whereResultArray[$val] = $searchString[$key];
        }
        $searchGroupOperator = $searchGroupOperator[0];
        $searchResults = array();

        $count = $this->kol->getProcessedKols($limit, $start, true, $sidx, $sord, $whereResultArray);
        //pr($this->db->last_query());exit;
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        if ($page > $total_pages)
            $page = $total_pages;
        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        if ($start < 0)
            $start = 0;

        $arrKolDetailResult = array();
        $data = array();
        $arrKolDetail = array();
        //		pr($sidx);
        //		pr($whereResultArray);
        if ($arrKolDetailResult = $this->kol->getProcessedKols($limit, $start, false, $sidx, $sord, $whereResultArray)) {
            //echo $this->db->last_query();
            foreach ($arrKolDetailResult->result_array() as $row) {
                $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                $kolName = $arrSalutations[$row['salutation']] . ' ' . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                $row['kol_name'] = $kolName;
                $row['id'] = $row['id'];
                $row['is_imported'] = $row['is_imported'];
                //				$row['kol_name']	.= (isset($row['is_imported']) && $row['is_imported']==1) ? '<span class="highlightImported"> (xls)<span>':'';
                $row['created_by'] = $row['user_full_name'];
                if ($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN) {
                    if ($row['is_pubmed_processed'] == 0)
                        $pubStatusHtml = "No";

                    if ($row['is_pubmed_processed'] == 1)
                        $pubStatusHtml = "Yes";

                    if ($row['is_pubmed_processed'] == 2)
                        $pubStatusHtml = "Re crawl";

                    $row['pubmed_processed'] = $pubStatusHtml;
                }else {
                    $pubStatus = 'No';
                    if ($row['is_pubmed_processed'] == 1)
                        $pubStatus = 'Yes';
                    if ($row['is_pubmed_processed'] == 2)
                        $pubStatus = 'Re crawl';
                    $row['pubmed_processed'] = $pubStatus;
                }
                $row['trial_processed'] = ($row['is_clinical_trial_processed'] == 1) ? 'Yes' : 'No';
                $row['organization'] = $row['org_name'];
                $row['action'] = '<div class="actionIcon editIcon"><a href="' . base_url() . 'kols/edit_kol/' . $row['id'] . '" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols(' . $row['id'] . ');" href="#" title="delete">&nbsp;</a></div>';
                $arrKolDetail[] = $row;
            }

            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrKolDetail;
        }
        ob_start('ob_gzhandler');
        echo json_encode($data);
    }

    function change_language() {
        //echo $this->config->item('language');
        $language = $this->input->post('language');
        //echo $language;
        $this->session->set_userdata('lang', $language);
        //$this->config->set_item('language', $language);
        //pr($this->session->userdata);
        //echo $this->config->item('language');
        //
		//$this->lang->load('kolm');
        redirect($_SERVER['HTTP_REFERER']);
    }

    function save_custom_filters() {
        $arrData['name'] = trim(ucfirst($this->input->post('filterName')));
        $arrData['filter_type'] = 1;
        $arrData['filter_value'] = json_encode(str_replace(";","",$this->input->post('saveFilter')));
        $arrData['created_on'] = date('Y-m-d H:i:s');
        $arrData['created_by'] = $this->loggedUserId;
        $arrData['client_id'] = $this->session->userdata('client_id');
        $arrData['applied_on'] = date('Y-m-d H:i:s');
        $lastId = $this->kol->saveCustomFilters($arrData);
        if ($lastId) {
            $data['status'] = true;
            $data['id'] = $lastId;
        } else {
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function add_kol_saved_filters() {
        $data['savedFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $this->load->view('search/add_saved_filters', $data);
    }

    function get_filter_by_id($id) {
        $arrData['id'] = $id;
        $arrData['applied_on'] = date('Y-m-d H:i:s');
        $data = $this->kol->getFilterById($arrData);
        if ($data) {
            $data1['status'] = true;
            $data1['filterData'] = json_decode($data);
        } else {
            $data1['status'] = false;
        }
        echo json_encode($data1);
    }

    function update_custom_filters() {
        $arrData['name'] = $this->input->post('filterName');
        $arrData['id'] = $this->input->post('filterId');
        $arrData['filter_value'] = json_encode($this->input->post('saveFilter'));
        $arrData['modified_on'] = date('Y-m-d H:i:s');
        $arrData['created_by'] = $this->loggedUserId;
        $arrData['client_id'] = $this->session->userdata('client_id');
        if ($this->kol->updateCustomFilters($arrData)) {
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function get_saved_filters() {
        $data['savedFilters'] = $this->kol->getAllCustomFilterByUser($this->loggedUserId);
        $this->load->view('search/edit_saved_filters', $data);
    }

    function delete_saved_filter($filterId) {
        if ($this->kol->deleteSavedFilter($filterId)) {
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function update_saved_filter() {
        $arrData['id'] = $this->input->post('id');
        $arrData['name'] = $this->input->post('filterName');
        if ($this->kol->updateSavedFilter($arrData)) {
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function reset_applied_filter() {
        $userId = $this->loggedUserId;
        $data = $this->kol->resetAppliedFilter($userId);
        if ($data)
            $status['status'] = true;
        else
            $status['status'] = false;
        echo json_encode($status);
    }

    function view_kol_interactions($kolId) {
        $clientId = $this->session->userdata('client_id');
        $data['arrGroupings'] = $this->interaction->getAllGroupings($clientId);
        $data['arrModes'] = $this->interaction->getAllModesOfClient($clientId);
        $data['arrTopics'] = $this->interaction->getAllTopicsOfClient($clientId);
        $data['arrType'] = $this->interaction->getAllTypesOfClient();
        $data['arrProduct'] = $this->common_helpers->getUserProducts();
        $data['arrUsers'] = $this->Client_User->getClientUsers($clientId);
        $arrKolDetail = $this->kol->editKol($kolId);
        // If there is no record in the database
        if (!$arrKolDetail) {
            return false;
        }
        $this->getKolProfileScore($kolId);
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $arrFilters = '';
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');
        $arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit = 10, '');
        $count = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit = 'all', '');

        $data['arrInteractionsResults'] = $arrInteractionsResults;
        //$data['arrOrganization']	= $arrOrganizationDetail;
        $data['contentPage'] = 'interactions/list_kol_interactions';
        $data['kolId'] = $kolId;

        $data['count'] = $count;
        if ($count == 0) {
            $data['mes'] = "No interactions found";
        }

        $interactionIds = array();
        foreach ($arrInteractionsResults as $row) {
            $interactionIds[] = $row['id'];
        }
        //pr($interactionIds);
        $data['interactionIds'] = implode($interactionIds, ',');
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        //pr($data);
        //$data['startFrom'] = $startForm;
// 		pr($data);
        $this->load->view('layouts/client_view', $data);
    }

    function view_interactions($kolId) {

        $clientId = $this->session->userdata('client_id');
        $arrFilters['end_date'] = $this->input->post('ed');
        $arrFilters['start_date'] = $this->input->post('sd');
        $arrFilters['objective_id'] = $this->input->post('type');
        $arrFilters['product_id'] = $this->input->post('product');
        $arrFilters['topic_id'] = $this->input->post('topic');
        $arrFilters['subtopic_id'] = $this->input->post('subtopic');

        $arrFilters['mode'] = $this->input->post('mode');
        $arrFilters['grouping'] = $this->input->post('grouping');
        $arrFilters['kol_id'] = $this->input->post('kol_id');
        $startFrom = $this->input->post('startFrom');
        $userId = 0;
        $arrFilters['interactionFor'] = $this->input->post('interaction_for');
        $arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit = 10, $startFrom);
        $count = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, 'all', $startFrom);
        $data['startFrom'] = $startFrom;
        $data['arrInteractionsResults'] = $arrInteractionsResults;

        $data['contentPage'] = 'organizations/interactions/show_interaction_details';
        $data['count'] = $count;
        if ($count == 0) {
            $data['mes'] = "No interactions found for the criteria selected by you";
        }

        $interactionIds = array();
        foreach ($arrInteractionsResults as $row) {
            $interactionIds[] = $row['id'];
        }
        $interactionIds1 = $this->input->post('interaction_ids');
        //pr($interactionIds);
        $data['interactionIds'] = implode($interactionIds, ',');
        $data['interactionIds'].="," . $interactionIds1;

        $this->load->view('interactions/show_kol_interaction_details', $data);
    }

    function getLoacionOfEvents($kolId) {
        $arrEventOfLoacation = $this->kol->getEventLoaction($kolId);
        //pr($arrEventOfLoacation);
        $data['locations'] = $arrEventOfLoacation;
        echo json_encode($data);
    }

    /*
     * Counts the number of Events based on "session_type" for one kol
     * @author Vianayak Malladad
     * @since 6.5
     * @created on 10 Desc,2011
     *
     */

    function view_events_by_sponsor_type($kolId = 0, $startYear, $endYear, $role = '', $arrCountryId = 0, $arrSpecialities = 0) {
        $data = array();
        $arrEventsresult = $this->kol->getEventsBySponsorType($kolId, $startYear, $endYear, $role, $arrCountryId, $arrSpecialities = 0);
        foreach ($arrEventsresult as $row) {
            $arrEvents = array();
            $arrEvents[] = ucwords($row['type']);
            $arrEvents[] = (int) $row['count'];
            $data[] = $arrEvents;
        }
        echo json_encode($data);
    }

    function import_page() {
        $data['contentPage'] = 'kols/import_page';
        //
        //$this->load->view('layouts/analyst_view', $data);
        $this->load->view('layouts/analyst_view', $data);
    }

    function upload_zip_file() {
        //	$path_info = pathinfo($_FILES["overview_import"]['name']);


        $dest = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/" . $_FILES["prof_import"]['name'];
        move_uploaded_file($_FILES["prof_import"]['tmp_name'], $dest);

        $name = substr($_FILES["prof_import"]['name'], 0, -4);
        $this->load->library('unzip');
        $this->unzip->extract($dest, $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/");


        $arrUHFiles = array();
        $payerPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/";
        if ($handle = opendir($payerPath)) {
            /* This is the correct way to loop over the directory. */

            $chk = substr($entry, -4);
            //$arrUHFiles[] = $entry;
            if ($chk != '.zip') {
                if (is_dir($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/" . $name)) {

                    if ($handle1 = opendir($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/" . $name)) {

                        while (false !== ($entry1 = readdir($handle1))) {
                            echo $entry1;
                            if ($entry1 != '.' && $entry1 != '..' && $entry1 != '.svn') {
                                $arrUHFiles[$name][] = $entry1;
                            }
                        }
                    }
                }
            }
        }
        $data['arrProfiles'] = $arrUHFiles;

        $data['contentPage'] = 'kols/list_import_files';
        //
        $this->load->view('layouts/analyst_view', $data);
        //	pr($arrUHFiles);
    }

    function list_all_uploaded_files() {
        $arrFiles = array();
        $kolUploadedPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/";
        if ($handle = opendir($kolUploadedPath)) {
            /* This is the correct way to loop over the directory. */
            while (false !== ($entry = readdir($handle))) {

                if ($entry != '.' && $entry != '..' && $entry != '.svn') {
                    $chk = substr($entry, -4);
                    //$arrUHFiles[] = $entry;

                    if ($chk != '.zip') {

                        if (is_dir($kolUploadedPath . $entry)) {

                            if ($handle1 = opendir($kolUploadedPath . $entry)) {

                                while (false !== ($entry1 = readdir($handle1))) {
                                    if ($entry1 != '.' && $entry1 != '..' && $entry1 != '.svn') {
                                        $arrFiles[$entry][] = $entry1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        $data['arrProfiles'] = $arrFiles;

        $data['contentPage'] = 'kols/list_import_files';
        $this->load->view('layouts/analyst_view', $data);
    }

    function delete_files() {

        $uploadedPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/";
        $arrFiles = $this->input->post('files');
        $arrFolders = $this->input->post('folders');
        //	pr($arrFiles);
        foreach ($arrFiles as $row) {
            $pos = strpos($row, '&');
            $folderNAme = substr($row, 0, $pos);
            $files[$folderNAme][] = substr($row, $pos + 1);
        }

        foreach ($files as $folder => $fileNames) {


            foreach ($fileNames as $fileName) {
                unlink($uploadedPath . $folder . "/" . $fileName);
            }
        }

        foreach ($arrFolders as $folderName) {
            rmdir($uploadedPath . $folderName);


            unlink($uploadedPath . $folderName . ".zip");
        }
    }

    function import_multiple_kol_profiles() {
        $edcationDetailCount = array();
        $affiliationCount = array();
        $pubCount = array();
        $trialCount = array();

        $initialTime = microtime(true);
        //ini_set("max_execution_time", 7200);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        // Load the plugin
        $files = $this->input->post('files');
        $arrFiles = array();
        foreach ($files as $row) {
        	$row	= str_replace(';','',$row);
            $pos = strpos($row, '&');
            $folderNAme = substr($row, 0, $pos);
            $arrFiles[$folderNAme][] = substr($row, $pos + 1);
        }
        $arrEventTypes = $this->Event_helper->getAllConferenceEventTypes();
        $arrSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
        $arrCountries = $this->Country_helper->listCountries();
        $arrStates = $this->Country_helper->listStates();
        $arrCities = $this->Country_helper->listCities();
        $arrStatesAssociated = $this->Country_helper->listStatesAssociated();
        $arrCitiesAssociated = $this->Country_helper->listCitiesAssociated();
        $arrEventOrganizerTypes = $this->Event_helper->getOrganizerTypes();

        $arrEventSponsorTypes = $this->Event_helper->getSponsorTypes();
        $countryId = 0;
        $stateId = 0;
        $cityId = 0;
        

//         $this->load->plugin('excelReader/reader2');
        $this->load->plugin("excelreader/reader2");
        $currentMethod = $this->input->post('methodName');
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $arrSpecialitys = $this->Specialty->getAllSpecialties();
        $arrStaffTitle = $this->kol->getStaffTitle();
        $arrPhoneType = $this->kol->getPhoneType();
        
        $profile_type = 'Aissel Analyst';
        // Get the file information of the Uploaded EXCEL file
        //$fileInfo 					= pathinfo($_FILES["prof_import"]['name']);
        // Location of the folder where all the Uploaded Excel documents will be stored
        // Generate the Random Text, which will be used to store as FILE NAME, on the server
        // This will ensure that we won't be over-writing any files on the server, even by mistake, while importing
        //$randomText					= random_string('unique', 20);
        //$uploadedFile 				= $folderLocation . $randomText . "." . $fileInfo['extension'];
        foreach ($arrFiles as $folder => $filename) {
            $folderLocation = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/" . $folder;
            foreach ($filename as $file1) {
                $arrImportStatusMsg[$file1] = array();
                //$startTime = microtime(true);
                $uploadedFile = $folderLocation . "/" . $file1;

                $reader = new Spreadsheet_Excel_Reader($uploadedFile, true, 'utf-8');
                // Dump the EXCEL data for debugging
                //Prepare the data required fileds
                //To Read the shhet name and its index
                $arrKOLDetailsByPIN = array();
                foreach ($reader->boundsheets as $k => $sheet) {

                    /**
                     * The EXCEL file information is available as an array of SHEETS.
                     * Each sheet information is available as a two dimensional array or ROW AND COLUMN
                     * Example: The First cell of the First Sheet can be accessed as
                     * $reader->sheets[1]["cells"][1][1]	== $reader->sheets[SHEET_NUMBER]["cells"][ROW_NUMBER][COLUMN_NUMBER]
                     */
                    
                    // Start of processing the sheet - "Professional Info"
                    if (strcasecmp(trim($sheet['name']),'Professional Info')==0 || strcasecmp(trim($sheet['name']),'Prof_Info')==0) {
                        //echo "started personal info<br />";
                        //Check the Professional Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Salutation")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"First Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Middle Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Last Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Suffix")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Gender")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Specialty")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Sub-Specialty")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Company Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Division")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Title")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"License #")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"NPI Number")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Profile Type")!=0) {
                            $arrImportStatusMsg[$file1]['professional']['incorrect_format'] = 'Professional Info Header format is incorrect';
                            break;
                        }

                        $existingkols = array();
                        $arrLocationData = array(); // for kol_location
                        $arrEmailData = array(); // for email
                        $arrPhoneData = array();// for phone
                        $arrLicenceData = array(); // for licence
                        $kid;// kol_id for kol_location
                        $korg_id; //org_id for kol_location
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            // Get Salutation ID based on the Salutation Text
                            $kolsDetails['salutation'] = array_search(trim($reader->sheets[$k]["cells"][$row][2]), $arrSalutations);
                            if (!$kolsDetails['salutation']) {
                                $kolsDetails['salutation'] = '';
                            }
                            $kolsDetails['first_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            $kolsDetails['middle_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            $kolsDetails['last_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
                            $kolsDetails['suffix'] = trim($reader->sheets[$k]["cells"][$row][6]);
                            if(!empty($kolsDetails['suffix'])){
                                $suffix = explode(',', $kolsDetails['suffix']);
                                foreach ($suffix as $suffixRow){                                    
                                	$suffix_id = $this->kol->saveSuffix(trim($suffixRow)); // save suffix if not exists                                	
                                	//$kolsDetails['suffix'] = $suffix_id;
                                }
                            }
                            $kolsDetails['gender'] = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                            // Get Specialty ID based on the Specialty Text
                            $kolsDetails['specialty'] = array_search(trim($reader->sheets[$k]["cells"][$row][8]), $arrSpecialitys);
                            if (!$kolsDetails['specialty']) {
                            	$sep = array("specialty"=>trim($reader->sheets[$k]["cells"][$row][8]),"client_id"=>INTERNAL_CLIENT_ID,"all"=>1);
                            	$sep_id = $this->kol->saveSpecialty($sep); // save specialty if not exists
                                $kolsDetails['specialty'] = $sep_id;
                            }
                            $kolsDetails['sub_specialty'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
                            $organization['name'] = trim($reader->sheets[$k]["cells"][$row][10]);
                            if (!empty($organization['name'])) {
                                $organization['created_by'] = $this->loggedUserId;
                                $organization['created_on'] = date("Y-m-d H:i:s");
                                $organization['modified_by'] = $this->loggedUserId;
                                $organization['modified_on'] = date('Y-m-d H:i:s');
                                $organization['status_otsuka'] = "ACTV";
                                $kolsDetails['org_id'] = $this->organization->saveOrganization($organization);
                                $korg_id = $kolsDetails['org_id'];
                                $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_org_id'] = $kolsDetails['org_id'];
                                if ($kolsDetails['org_id']) {
                                    //Update pin as kolid
                                    $updateData['id'] = $kolsDetails['org_id'];
                                    $updateData['cin_num'] = $kolsDetails['org_id'];
                                    $this->organization->updateOrganization($updateData);
                                }
                            }
                            $kolsDetails['division'] = ucwords(trim($reader->sheets[$k]["cells"][$row][11]));
                            $kolsDetails['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][12]));
                            if(!empty($kolsDetails['title'])){
                            	$kolsDetails['title'] = $this->kol->saveTitle($kolsDetails['title']); // save title if not exists / if exsits get id
                            }
                            $kolsDetails['license'] = trim($reader->sheets[$k]["cells"][$row][13]);
                            $kolsDetails['npi_num'] = trim($reader->sheets[$k]["cells"][$row][14]);
                            $kolsDetails['profile_type'] = trim($reader->sheets[$k]["cells"][$row][15]);
							if($kolsDetails['profile_type'] == "Market Access Profile" || $kolsDetails['profile_type'] == "Market Access"){
								$kolsDetails['profile_type'] = 'Market Access';
							}elseif($kolsDetails['profile_type']=='' || ($kolsDetails['profile_type']!='Full Profile' && $kolsDetails['profile_type']!='Basic' && $kolsDetails['profile_type']!='Basic Plus' && $kolsDetails['profile_type']!='Legacy')){
								$kolsDetails['profile_type'] = 'Full Profile';
							}

                            $kolsDetails['created_by'] = $this->loggedUserId;
                            $kolsDetails['created_on'] = date("Y-m-d H:i:s");
                            $kolsDetails['is_imported'] = 1;
                            $kolsDetails['is_pubmed_processed'] = 0;
                            //$kolsDetails['status'] = New1;
                            $status = trim($reader->sheets[$k]["cells"][$row][17]);
                            if ($status != '') {
                                $kolsDetails['status'] = $status;
                            } else {
                                $kolsDetails['status'] = New1;
                            }
                            if ($kolsDetails['pin'] != "") {
                                $id = $this->kol->saveImportedKol($kolsDetails);
                                $kid=$id;
                                //$arrLicenceData[$kolsDetails['pin']]['state_license'] = $kolsDetails['license'];
                                // echo $reader->sheets[$k]["cells"][$row][13].'--'.$kolsDetails['license'].'<br />';
                                //If the kol already Exists then it won't save
                                if ($id == false) {
                                    //array of already existing kols
                                    $existingkols[] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
                                    /*unset($kolsDetails['first_name']);
                                    unset($kolsDetails['middle_name']);
                                    unset($kolsDetails['last_name']);*/
                                    $kid = $this->kol->updateImportedKol($kolsDetails);
                                    $idVla = $this->kol->getKolIdByPin($kolsDetails['pin']);
                                    $totalKolIds[$idVla] = $idVla;
                                }else{
									$totalKolIds[$id] = $id;
								}
								//Assign User
								/* $arrData = array();
								$arrData['user_id'] = $this->loggedUserId;
								$arrData['kol_id'] = $kid;
								$arrData['type'] = 2;
								$saveAssignId = $this->kol->saveAssignClient($arrData); */
                                $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'] = $kid;
                                $arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'] = $kolsDetails['license'];
                            } else {
                                //array of KOL having no 'PIN'
                                $arrImportStatusMsg[$file1]['professional']['no_pin_num'][] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
                            }
                           // pr(count($reader->sheets[$k]["cells"]));
                        }
                        $arrImportStatusMsg[$file1]['professional']['success'] = true;
                        $arrImportStatusMsg[$file1]['professional']['existingKols'] = $existingkols;
                    }
                    //echo $k;exit;
                    //End of processing the sheet - 'Professional Info' or 'Prof_Info'
                    // Start of processing the sheet - "Contact Info"
                    if (strcasecmp(trim($sheet['name']),'Contact Info')==0 || strcasecmp(trim($sheet['name']),'Contact_Info')==0) {
                        //echo "started contact info<br />";
                        //Check the Contact Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Primary Phone")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Fax")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Primary Email")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Address 1")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Address 2")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"City")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"State / Province")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Postal Code")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Country")!=0) {
                            $arrImportStatusMsg[$file1]['contact']['incorrect_format'] = 'Contact Info Header format is incorrect';
                            break;
                        }
                        // Start parsing the Values
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $countryId = 0;
                            $stateId = 0;
                            $cityId = 0;
                            // Create a new array
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $kolsDetails['primary_phone'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $kolsDetails['fax'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            $kolsDetails['primary_email'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            $kolsDetails['address1'] = trim($reader->sheets[$k]["cells"][$row][5]);
                            $kolsDetails['address2'] = trim($reader->sheets[$k]["cells"][$row][6]);
                            
                            $arrLocationData['org_institution_id'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_org_id'];
                            $arrLocationData['address1'] = $kolsDetails['address1'];
                            $arrLocationData['address2'] = $kolsDetails['address2'];
                            $arrLocationData['address3'] = '';
                            $arrLocationData['validation_status'] = 'VALD';
                            $arrLocationData['address_type'] = 'Physical';
                            // Get the CityID, based on the provided City Name

                            if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][8])), $arrStates)) {
                                
                            }


                            $countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][10]))]['country_id'];
                            $state = ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
                            if ($state != '') {
                                $stateId = $this->Country_helper->checkStateIfExistElseAdd($state, $countryId);
                                $kolsDetails['state_id'] = $stateId;
                                $arrLocationData['state_id'] = $stateId;
                                $arrLicenceData[$kolsDetails['pin']]['region'] = $stateId;
                            }
                            $city = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                            if ($city != '') {
                                $kolsDetails['city_id'] = $this->Country_helper->checkCityIfExistElseAdd($city, $stateId, $countryId);
                                $arrLocationData['city_id'] = $kolsDetails['city_id'];
                            }

                            $kolsDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
                            $arrLocationData['postal_code'] = $kolsDetails['postal_code'];
                            if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][10])), $arrCountries))

                            //echo
                                $kolsDetails['country_id'] = $countryId;
                                $arrLocationData['country_id'] = $countryId;                                
                                $arrLocationData['is_primary'] = 1;
                                $arrLocationData['created_by'] = $this->loggedUserId;
                                $arrLocationData['created_on'] = date('Y-m-d H:i:s');
                                $arrLocationData['modified_by'] = $this->loggedUserId;
                                $arrLocationData['modified_on'] = date('Y-m-d H:i:s');
                                $arrLocationData['kol_id'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
                                $genericId = $this->common_helpers->getGenericId("Location Form");
                                $arrLocationData['generic_id'] = $genericId;
                                $arrLocationData['data_type_indicator'] = $profile_type;
                                $lastLocId = $this->kol->saveKolLocation($arrLocationData); // insert in kol_location
                                
                                $arrEmailData['type'] = 'Work';
                                $arrEmailData['email'] = $kolsDetails['primary_email'];
                                $arrEmailData['is_primary'] = 1;
                                $arrEmailData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
                                $arrEmailData['created_by'] = $this->loggedUserId;
                                $arrEmailData['created_on'] = date('Y-m-d H:i:s');
                                $arrEmailData['modified_by'] = $this->loggedUserId;
                                $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                                $arrEmailData['data_type_indicator'] = $profile_type;
                                $this->kol->saveKolEmails($arrEmailData); // insert in email                                
                                
                                $arrPhoneData['number'] = $kolsDetails['primary_phone'];                              
                                $arrPhoneData['is_primary'] = 1;
                                $arrPhoneData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
                                $arrPhoneData['location_id'] = $lastLocId;
                                $arrPhoneData['contact_type'] = "location";
                                $arrPhoneData['created_by'] = $this->loggedUserId;
                                $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                                $arrPhoneData['modified_by'] = $this->loggedUserId;
                                $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                                $arrPhoneData['type'] = 'Office Phone';
                                $arrPhoneData['data_type_indicator'] = $profile_type;
                                $this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
                                //pr($arrKOLDetailsByPIN);
                                if(isset($arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license']) && !empty($arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'])){
                                    $arrNewLicenceData  = array();
                                    $arrNewLicenceData['state_license'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'];
                                    $arrNewLicenceData['region'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['region'];
                                    $arrNewLicenceData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
                                    $arrNewLicenceData['is_primary'] = 1;
                                    $arrNewLicenceData['created_by'] = $this->loggedUserId;
                                    $arrNewLicenceData['created_on'] = date('Y-m-d H:i:s');
                                    $arrNewLicenceData['modified_by'] = $this->loggedUserId;
                                    $arrNewLicenceData['modified_on'] = date('Y-m-d H:i:s');
                                    $arrNewLicenceData['data_type_indicator'] = $profile_type;
                                   // pr($arrLicenceData);
                                  // pr($arrNewLicenceData);
                                    
                                    $this->kol->saveKolLicense($arrNewLicenceData); // insert in sate_licence
                                }
                                
                                
                                if($kolsDetails['fax']!=''){
                                	$arrPhoneData['is_primary'] = 0;
                                	$arrPhoneData['number']=$kolsDetails['fax'];
                                	$arrPhoneData['type'] = 'Fax';
                                	$this->kol->saveKolPhones($arrPhoneData); // insert fax in phone_number
                                }
                                
                            //Update only if the 'pin' is not blank
                            if ($kolsDetails['pin'] != "") {
                                $id = $this->kol->updateImportedKol($kolsDetails);
                                if ($id == false) {
                                    //Array of KOLs with mentioned 'PIN' not present in database
                                    $arrImportStatusMsg[$file1]['contact']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                }
                            } else {
                                //Array of KOLs having no 'PIN' in EXCEL file
                                $arrImportStatusMsg[$file1]['contact']['no_pin_num'][] = $kolsDetails['primary_phone'];
                            }
                        }
                        $arrImportStatusMsg[$file1]['contact']['success'] = true;
                    }
                    

                    if (strcasecmp(trim($sheet['name']),'Details_Page')==0) {
                    	//echo "started contact info<br />";
                    	//Check the Contact Info Header Format
                    	$row = 1;
                    	if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Is Primary")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Data Type")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Institution Name")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Department")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Title")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"License")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Specialty")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Specialty Type")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Phone Type")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Phone")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Email Type")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Email")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"Address 1")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Address 2")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"City")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"State/ Province")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Country")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Postal Code")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Staff Name")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Languages Spoken")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Bio / Comments")!=0 ||
                    			strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"Areas of Interest")!=0) {
                    				$arrImportStatusMsg[$file1]['details']['incorrect_format'] = 'Details Header format is incorrect';
                    				break;
                    			}
                    
                    			$globalOrgId = '';
                    			$insData = false;
                    			// Start parsing the Values
                    			for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                    				//Save only if the 'pin' is not blank
                    				$detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
                    				if ($detailsPin != "") {
                    					$kolId = $this->kol->getKolIdByPin($detailsPin);
                    					if ($kolId != 0) {
                    						$edcationDetailCount[$kolId]['kolId'] = $kolId;
                    						$insData = true;
                    					} else {
                    						$insData = false;
                    						$arrImportStatusMsg[$file1]['details']['no_matching_pin_num'][] = $detailsPin;
                    					}
                    				} else {
                    					//aray of Affiliation having no 'pin'
                    					$insData = false;
                    					$arrImportStatusMsg[$file1]['details']['no_pin_num'][] = trim($reader->sheets[$k]["cells"][$row][3]);
                    				}
                    				$countryId = 0;
                    				$stateId = 0;
                    				$cityId = 0;
                    				$dataType = trim($reader->sheets[$k]["cells"][$row][3]);
                    				switch($dataType){
                    					//Location Info Details
                    					case 'Location':
                    						$arrLoc = array();
                    						$arrLoc['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
                    						if(strcasecmp($arrLoc['is_primary'],'Yes')==0){
                    							$arrLoc['is_primary'] = 1;
                    						}else{
                    							$arrLoc['is_primary'] = 0;
                    						}
                    						$arrLoc['division'] = trim($reader->sheets[$k]["cells"][$row][5]);
                    						$arrLoc['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
                    						if(!empty($arrLoc['title'])){
                    							$arrLoc['title'] = $this->kol->saveTitle($arrLoc['title']); // save title if not exists / if exsits get id
                    						}
                    						$arrLoc['address1'] = trim($reader->sheets[$k]["cells"][$row][14]);
                    						$arrLoc['address2'] = trim($reader->sheets[$k]["cells"][$row][15]);
                    						// Get the Country Id,State Id,City Id based on the provided Names
                    						$country_name = trim($reader->sheets[$k]["cells"][$row][18]);
                    						$arrLoc['country_id'] = $this->country_helper->checkCountryIfExistElseAdd($country_name);
                    						if(!empty(trim($reader->sheets[$k]["cells"][$row][17]))){
                    							$arrLoc['state_id'] = $this->country_helper->checkStateIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][17]),$arrLoc['country_id']);
                    						}
                    						if(!empty(trim($reader->sheets[$k]["cells"][$row][16]))){
                    							$arrLoc['city_id'] = $this->country_helper->checkCityIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][16]),$arrLoc['state_id'],$arrLoc['country_id']);
                    						}
                    						$arrLoc['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
                    						$department_name = trim($reader->sheets[$k]["cells"][$row][5]);
                    						$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
                    						if(!empty($institute_name)){
	                    						$arrLoc['org_institution_id'] = $this->organization->getOrgIdByOrgName($institute_name);
	                    						if ($arrLoc['org_institution_id'] == 0) {
	                    							$arrOrgData = array();
	                    							$arrOrgData['address'] = $arrLoc['address1'] . " " . $arrLoc['address2'];
	                    							$arrOrgData['name'] = $institute_name;
	                    							$arrOrgData['state_id'] = $arrLoc['state_id'];
	                    							$arrOrgData['city_id'] = $arrLoc['city_id'];
	                    							$arrOrgData['country_id'] = $arrLoc['country_id'];
	                    							$arrOrgData['postal_code'] = $arrLoc['postal_code'];
	                    							$arrOrgData['created_by'] = $this->loggedUserId;
	                    							$arrOrgData['created_on'] = date('Y-m-d H:i:s');
	                    							$arrOrgData['modified_by'] = $this->loggedUserId;
	                    							$arrOrgData['modified_on'] = date('Y-m-d H:i:s');
	                    							$arrOrgData['type_id'] = $this->kol->getOrgTypeIdByName($department_name);
	                    							if($arrOrgData['type_id'] == 0){
	                    								$arrOrgData['type_id'] = 7;
	                    							}
	                    							$arrOrgData['profile_type'] = 1;
	                    							$arrOrgData['status_otsuka'] = "ACTV";
	                    							$arrOrgData['status'] = "";
	                    							$org_id = $this->organization->saveOrganization($arrOrgData);
	                    							$arrLoc['org_institution_id'] = $org_id;
	                    						}
                    						}
                    						$arrLoc['kol_id'] = $kolId;
                    						$arrLoc['data_type_indicator'] = $profile_type;
                    						if($insData){
                    							$lastLocId = $this->kol->saveKolLocation($arrLoc);//insert in kol_locations
                    							if($arrLoc['is_primary'] == 1){
                    								$arrKolDetails = array();
                    								$arrKolDetails['id'] = $kolId;
                    								$arrKolDetails['org_id'] = $arrLoc['org_institution_id'];
                    								$arrKolDetails['address1'] = $arrLoc['address1'];
                    								$arrKolDetails['address2'] = $arrLoc['address2'];
                    								$arrKolDetails['country_id'] = $arrLoc['country_id'];
                    								$arrKolDetails['state_id'] = $arrLoc['state_id'];
                    								$arrKolDetails['city_id'] = $arrLoc['city_id'];
                    								$arrKolDetails['postal_code'] = $arrLoc['postal_code'];
                    								$arrKolDetails['modified_by'] = $this->loggedUserId;
                    								$arrKolDetails['modified_on'] = date('Y-m-d H:i:s');
                    								$this->kol->updateKol($arrKolDetails);
                    							}
                    							$insData = false;
                    						}
                    						break;
                    					case 'Phone':
                    						$arrPhoneData = array();
                    						$arrPhoneData['number'] = trim($reader->sheets[$k]["cells"][$row][11]);
                    						$arrPhoneData['type'] = array_search(trim($reader->sheets[$k]["cells"][$row][10]), $arrPhoneType);
                    						if (!$arrPhoneData['type']) {
                    						    if(!empty($arrPhoneData['type'])){
                        							$phoneType = array("name"=>trim($reader->sheets[$k]["cells"][$row][10]));
                        							$type_id = $this->kol->savePhoneType($phoneType); // save specialty if not exists
                        							$arrPhoneData['type'] = $type_id;
                    						    }
                    						}
                    						$arrPhoneData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
                    						if($arrPhoneData['is_primary']=='Yes' || $arrPhoneData['is_primary']=='yes'){
                    
                    							$arrPhoneData['is_primary'] = 1;
                    						}else{
                    							$arrPhoneData['is_primary'] = 0;
                    						}
                    						$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
                    						if(!empty($institute_name)){
	                    						$org_institution_id = $this->organization->getOrgIdByOrgName($institute_name,false);
	                    						$arrPhoneData['location_id'] = '';
	                    						if ($org_institution_id > 0) {
	                    							$arrLocationData['org_institution_id'] = $org_institution_id;
	                    							$arrLocationData['kol_id'] = $kolId;
	                    							$locationId = $this->kol->getKolLocationByOrgInstId($arrLocationData);
	                    							if(is_numeric($locationId)){
	                    								$arrPhoneData['location_id'] = $locationId;
	                    							}
	                    						}
                    						}
                    						$arrPhoneData['contact'] = $kolId;
                    						$arrPhoneData['contact_type'] = "location";
                    						$arrPhoneData['created_by'] = $this->loggedUserId;
                    						$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                    						$arrPhoneData['modified_by'] = $this->loggedUserId;
                    						$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                    						$arrPhoneData['data_type_indicator'] = $profile_type;
                    						if($insData){
                    							$this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
                    							$insData = false;
                    						}
                    						break;
                    						//Email Info Details
                    					case 'Email':
                    						$arrEmailData = array();
                    						$arrEmailData['type'] = trim($reader->sheets[$k]["cells"][$row][12]);
                    						$arrEmailData['email'] = trim($reader->sheets[$k]["cells"][$row][13]);
                    						$arrEmailData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
                    						if($arrEmailData['is_primary']=='Yes' || $arrEmailData['is_primary']=='yes'){
                    							$arrEmailData['is_primary'] = 1;
                    						}else{
                    							$arrEmailData['is_primary'] = 0;
                    						}
                    						$arrEmailData['contact'] = $kolId;
                    						$arrEmailData['created_by'] = $this->loggedUserId;
                    						$arrEmailData['created_on'] = date('Y-m-d H:i:s');
                    						$arrEmailData['modified_by'] = $this->loggedUserId;
                    						$arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                    						$arrEmailData['data_type_indicator'] = $profile_type;
                    						if($insData){
                    							$this->kol->saveKolEmails($arrEmailData); // insert in email
                    							$insData = false;
                    						}
                    						break;
                    						//License Info Details
                    					case 'License':
                    						
                    						$arrNewLicenceData  = array();
                    						$arrNewLicenceData['state_license'] = trim($reader->sheets[$k]["cells"][$row][7]);
                    						$country_name = trim($reader->sheets[$k]["cells"][$row][18]);
                    						$arrNewLicenceData['country_id'] = $this->country_helper->checkCountryIfExistElseAdd($country_name);
                    						if(!empty(trim($reader->sheets[$k]["cells"][$row][17]))){
                    						    $arrNewLicenceData['region'] = $this->country_helper->checkStateIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][17]),$arrNewLicenceData['country_id']);
                    						}
                    						$arrNewLicenceData['contact'] = $kolId;
                    						$arrNewLicenceData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
                    						if($arrNewLicenceData['is_primary']=='Yes' || $arrNewLicenceData['is_primary']=='yes'){
                    							$arrNewLicenceData['is_primary'] = 1;
                    						}else{
                    							$arrNewLicenceData['is_primary'] = 0;
                    						}
                    						$arrNewLicenceData['created_by'] = $this->loggedUserId;
                    						$arrNewLicenceData['created_on'] = date('Y-m-d H:i:s');
                    						$arrNewLicenceData['modified_by'] = $this->loggedUserId;
                    						$arrNewLicenceData['modified_on'] = date('Y-m-d H:i:s');
                    						$arrNewLicenceData['data_type_indicator'] = $profile_type;
                    						if($insData){
                    							$this->kol->saveKolLicense($arrNewLicenceData); // insert in sate_licence
                    							$insData = false;
                    						}
                    						break;
                    						//Specialty Info Details
                    					case 'Specialty':
                    						$arrNewSpecialty = array();
                    						$arrNewSpecialty['kol_sub_specialty_id'] = array_search(trim($reader->sheets[$k]["cells"][$row][8]), $arrSpecialitys);
                    						if (!$arrNewSpecialty['kol_sub_specialty_id']) {
                    						    if(!empty($arrNewSpecialty['kol_sub_specialty_id'])){
                    							$sep = array("specialty"=>trim($reader->sheets[$k]["cells"][$row][8]),"client_id"=>INTERNAL_CLIENT_ID,"all"=>1);
                    							$sep_id = $this->kol->saveSpecialty($sep); // save specialty if not exists
                    							$arrNewSpecialty['kol_sub_specialty_id'] = $sep_id;
                    						    }
                    						}
                    						$arrNewSpecialty['kol_id']= $kolId;
                    						$specialtyType = trim($reader->sheets[$k]["cells"][$row][9]);
                    						switch($specialtyType){
                    							case 'Primary Specialty':
                    								$arrNewSpecialty['priority'] = 1;
                    								break;
                    							case 'Additional Specialty';
                    							$arrNewSpecialty['priority'] = 2;
                    							break;
                    							case 'Sub-Specialty';
                    							$arrNewSpecialty['priority'] = 0;
                    							break;
                    						}
                    						if($insData){
                    							$this->kol->saveKolSpecialty($arrNewSpecialty); // insert in sate_licence
                    							$insData = false;
                    						}
                    						break;
                    					case 'Staff':
                    						$arrNewStaffData  = array();
                    						$arrNewStaffData['title'] = trim($reader->sheets[$k]["cells"][$row][6]);
                    						$arrNewStaffData['name'] = trim($reader->sheets[$k]["cells"][$row][20]);
                    						$arrNewStaffData['phone_number'] = trim($reader->sheets[$k]["cells"][$row][11]);
                    						$arrNewStaffData['phone_type'] = array_search(trim($reader->sheets[$k]["cells"][$row][10]), $arrPhoneType);
                    						if (!$arrNewStaffData['phone_type']) {
                    						    if(!empty($arrNewStaffData['phone_type'])){
                        							$phoneType = array("name"=>trim($reader->sheets[$k]["cells"][$row][10]));
                        							$type_id = $this->kol->savePhoneType($phoneType); // save specialty if not exists
                        							$arrNewStaffData['phone_type'] = $type_id;
                    						    }
                    						}
                    						$arrNewStaffData['title'] = array_search(trim($reader->sheets[$k]["cells"][$row][6]), $arrStaffTitle);
                    						if (!$arrNewStaffData['title']) {
                    						    if(!empty($arrNewStaffData['title'])){
                        							$stafftitle = array("name"=>trim($reader->sheets[$k]["cells"][$row][6]));
                        							$title_id = $this->kol->saveStaffTitle($stafftitle); // save specialty if not exists
                        							$arrNewStaffData['title'] = $title_id;
                    						    }
                    						}
                    						$arrNewStaffData['email'] = trim($reader->sheets[$k]["cells"][$row][13]);
                    						$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
                    						if(!empty($institute_name)){
	                    						$org_institution_id = $this->organization->getOrgIdByOrgName($institute_name,false);
	                    						$arrNewStaffData['location_id'] = '';
	                    						if ($org_institution_id > 0) {
	                    							$arrLocationData['org_institution_id'] = $org_institution_id;
	                    							$arrLocationData['kol_id'] = $kolId;
	                    							$locationId = $this->kol->getKolLocationByOrgInstId($arrLocationData);
	                    							if(is_numeric($locationId)){
	                    								$arrNewStaffData['location_id'] = $locationId;
	                    							}
	                    						}
                    						}
                    						$arrNewStaffData['contact'] = $kolId;
                    						$arrNewStaffData['contact_type'] = "location";
                    						$arrNewStaffData['created_by'] = $this->loggedUserId;
                    						$arrNewStaffData['created_on'] = date('Y-m-d H:i:s');
                    						$arrNewStaffData['modified_by'] = $this->loggedUserId;
                    						$arrNewStaffData['modified_on'] = date('Y-m-d H:i:s');
                    						$arrNewStaffData['data_type_indicator'] = $profile_type;
                    						if($insData){
                    							$this->kol->saveStaff($arrNewStaffData); // insert in sate_licence
                    							$insData = false;
                    						}
                    						break;
                    					case 'Areas of Interest':
                    						$rowData = trim($reader->sheets[$k]["cells"][$row][23]);
                    						if(!empty($rowData)){
                    							$arrData =array();
                    							$arrData['area_of_interest'] = $rowData;
                    							if($insData){
                    								$this->kol->additionalDataInsert($arrData,$kolId);
                    								$insData = false;
                    							}
                    						}
                    						break;
                    					case 'Bio / Comments':
                    						$rowData = trim($reader->sheets[$k]["cells"][$row][22]);
                    						if(!empty($rowData)){
                    							$arrData =array();
                    							$arrData['bio_comments'] = $rowData;
                    							if($insData){
                    								$this->kol->additionalDataInsert($arrData,$kolId);
                    								$insData = false;
                    							}
                    						}
                    						break;
                    					case 'Languages Spoken':
                    						$rowData = trim($reader->sheets[$k]["cells"][$row][21]);
                    						if(!empty($rowData)){
                    							$arrData =array();
                    							$arrData['languages_spoken'] = $rowData;
                    							if($insData){
                    								$this->kol->additionalDataInsert($arrData,$kolId);
                    								$insData = false;
                    							}
                    						}
                    						break;
                    				}
                    
                    			}
                    			
                    			$arrImportStatusMsg[$file1]['details']['success'] = true;
                    }
                    
                    
                    //- End of processing the sheet - 'Contact Info'
                    // Start of processing the sheet - "Biography"
                    if (strcasecmp(trim($sheet['name']),'Biography')==0) {
                        //echo "started biography<br />";
                        //Check the Biography Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Biography")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Clinical Research Interests")!=0) {
                            $arrImportStatusMsg[$file1]['biography']['incorrect_format'] = 'Biography Header format is incorrect';
                            break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $kolsDetails['biography'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $kolsDetails['research_interests'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            //Update only if the 'pin' is not blank
                            if ($kolsDetails['pin'] != "") {
                                $id = $this->kol->updateImportedKol($kolsDetails);
                                if ($id == false) {
                                    //array of 'pin' not present in database
                                    $arrImportStatusMsg[$file1]['biography']['no_matching_cin_num'][] = $kolsDetails['pin'];
                                }
                            } else {
                                //aray of kol having no 'pin'
                                $arrImportStatusMsg[$file1]['biography']['no_pin_num'][] = $kolsDetails['biography'];
                            }
                        }
                        $arrImportStatusMsg[$file1]['biography']['success'] = true;
                    }
                    //- End of processing the sheet - 'Biography'
                    // Start of processing the sheet - 'Education'
                    if (strcasecmp(trim($sheet['name']),'Education')==0) {
                        $educationBulkInsert = array();
                        //echo "started education<br />";
                        //Check the Education Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Education Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Institution Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Degree")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Specialty")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Time Frame")!=0) {
                            $arrImportStatusMsg[$file1]['education']['incorrect_format'] = 'Education Info Header format is incorrect';
                            break;
                        }
                        //Arrays to check education types
                        $eduTypes = array("Education", "education");
                        $trainingTypes = array("Training", "training");
                        $boardTypes = array("board_certification","Board_certification", "Board Certification", "Board certification");
                        $honorTypes = array("honors_awards","Honors_awards", "Awards/Honors", "Honors/Awards", "Honors", "Awards", "Honors/awards", "Honors and Awards");
                        $startTime = microtime(true);
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolDetails = array();
                            $eduDetails = array();
                            $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            //Check for the  Education Type
                            $educationType = trim($reader->sheets[$k]["cells"][$row][2]);
                            if (in_array($educationType, $eduTypes)) {
                                $type = "education";
                            } else if (in_array($educationType, $trainingTypes)) {
                                $type = "training";
                            } else if (in_array($educationType, $boardTypes)) {
                                $type = "board_certification";
                            } else if (in_array($educationType, $honorTypes)) {
                                $type = "honors_awards";
                            } else {
                                //Deafult value
                                $type = "education";
                            }
                            $eduDetails['type'] = $type;
                            if ($type != "honors_awards") {
                                //Get Institute id
                                $institution = array();
                                $institution['name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                                $institution['created_by'] = $this->loggedUserId;
                                $institution['created_on'] = date('Y-m-d H:i:s');
                                if ($institution['name'] != '')
                                    $institueId = $this->kol->getInstituteIdElseSave($institution);
                                $eduDetails['institute_id'] = $institueId;
                            }
                            if ($type == "honors_awards") {
                             //   $eduDetails['institute_id'] = '';
                                $eduDetails['honor_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            }
                            $eduDetails['degree'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            $eduDetails['specialty'] = trim($reader->sheets[$k]["cells"][$row][5]);
                            //Get the start and end years
                            $timeFrame = trim($reader->sheets[$k]["cells"][$row][6]);
                            $startDate = "";
                            $endDate = "";
                            $arrTimeFrame = explode('-', $timeFrame);
                            $startDate = trim($arrTimeFrame[0]);
                            if (sizeof($arrTimeFrame) > 1) {
                                $endDate = trim($arrTimeFrame[1]);
                            }
                            //For honours Separate column year
                            if ($type == "honors_awards") {
                                $eduDetails['year'] = $startDate;
                                $eduDetails['start_date'] = $startDate;
                                $eduDetails['end_date'] = $endDate;
                            } else {
                                $eduDetails['start_date'] = $startDate;
                                $eduDetails['end_date'] = $endDate;
                            }
                            $eduDetails['created_by'] = $this->loggedUserId;
                            $eduDetails['created_on'] = date("Y-m-d H:i:s");
                            $eduDetails['client_id'] = $this->session->userdata('client_id');
                            $eduDetails['data_type_indicator'] = $profile_type;
                            //Save only if the 'pin' is not blank
                            if ($kolDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                if ($kolId != 0) {
                                    $edcationDetailCount[$kolId]['kolId'] = $kolId;

                                    $eduDetails['kol_id'] = $kolId;
                                    $id = $this->kol->saveEducationDetail($eduDetails);
                                    $educationBulkInsert[] = $eduDetails;
                                } else {
                                    $arrImportStatusMsg[$file1]['education']['no_matching_pin_num'][] = $eduDetails['pin'];
                                }
                            } else {
                                //aray of Education having no 'pin'
                                $arrImportStatusMsg[$file1]['education']['no_pin_num'][] = $institution['name'];
                            }
                        }
                        foreach ($edcationDetailCount as $kolId => $values) {
                            if (!(isset($edcationDetailCount[$kolId]['educationCount']))) {
                                $edcationDetailCount[$kolId]['educationCount'] = $this->kol->getCountOfEducations($kolId);
                            }
                        }

                        //echo "Endtime".(microtime(true)-$startTime);
                        $arrImportStatusMsg[$file1]['education']['success'] = true;


                        //$this->kol->saveEducationDetailByBulk($educationBulkInsert);
                    }

                    //- End of processing the sheet - 'Education'
                    // Start of processing the sheet - 'Affiliation'
                    if (strcasecmp(trim($sheet['name']),'Affiliation')==0) {
                        $arrAffiliationForBulk = array();
                        //echo "started affiliation<br />";
                        //Check the Affiliation Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Organization Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Dept/Committee")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Title/Purpose")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Time frame")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Organization Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Engagement Type")!=0) {
                            $arrImportStatusMsg[$file1]['affiliation']['incorrect_format'] = 'Affiliation Info Header format is incorrect';
                            break;
                        }
                        //Arrays to check Affiliation types
                        $uniTypes = array("University/Hospital", "University", "university");
                        $assocTypes = array("Association", "association", "Associations");
                        $indTypes = array("Industry", "industry");
                        $govTypes = array("Government", "Government Agency", "Government-Agency", "Government agency", "government");
                        $otherTypes = array("Others", "others", "Other", "other");
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolDetails = array();
                            $affDetails = array();
                            $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            //Check for the  Organization Type(Type of Affiliation)
                            $orgType = trim($reader->sheets[$k]["cells"][$row][6]);
                            if (in_array($orgType, $uniTypes)) {
                                $type = "university";
                            } else if (in_array($orgType, $assocTypes)) {
                                $type = "association";
                            } else if (in_array($orgType, $indTypes)) {
                                $type = "industry";
                            } else if (in_array($orgType, $govTypes)) {
                                $type = "government";
                            } else if (in_array($orgType, $otherTypes)) {
                                $type = "others";
                            } else {
                                //Deafult value
                                $type = "university";
                            }
                            $affDetails['type'] = $type;
                            //Get Institute id//Oranization Id
                            $institution = array();
                            $institution['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $institution['created_by'] = $this->loggedUserId;
                            $institution['created_on'] = date('Y-m-d H:i:s');
                            if ($institution['name'] != '')
                                $institueId = $this->kol->getInstituteIdElseSave($institution);
                            $affDetails['institute_id'] = $institueId;
                            $affDetails['department'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            $affDetails['role'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            //Get the start and end years
                            $timeFrame = trim($reader->sheets[$k]["cells"][$row][5]);
                            $startDate = "";
                            $endDate = "";
                            $arrTimeFrame = explode('-', $timeFrame);
                            if (sizeof($arrTimeFrame) > 0) {
                                $startDate = trim($arrTimeFrame[0]);
                            }
                            if (sizeof($arrTimeFrame) > 1) {
                                $endDate = trim($arrTimeFrame[1]);
                            }
                            $this->load->model('Engagement_type');
                            //Get Engagement id
                            $engagement = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                            $engagementId = $this->Engagement_type->getEngagementId($engagement);
                            if ($engagementId) {
                                $affDetails['engagement_id'] = $engagementId;
                            }
                            $affDetails['start_date'] = $startDate;
                            $affDetails['end_date'] = $endDate;
                            $affDetails['created_by'] = $this->loggedUserId;
                            $affDetails['created_on'] = date("Y-m-d H:i:s");
                            $affDetails['client_id'] = $this->session->userdata('client_id');
                            $affDetails['data_type_indicator'] = $profile_type;
							//pr($affDetails);
                            //Save only if the 'pin' is not blank
                            if ($kolDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                if ($kolId != 0) {
                                    $affDetails['kol_id'] = $kolId;
                                    $edcationDetailCount[$kolId]['kolId'] = $kolId;
                                    //$edcationDetailCount[$kolId]['affCount'] = 12;
                                    //$id						= $this->kol->saveMembership($affDetails);
                                    $arrAffiliationForBulk[] = $affDetails;
                                } else {
                                    $arrImportStatusMsg[$file1]['affiliation']['no_matching_pin_num'][] = $kolDetails['pin'];
                                }
                            } else {
                                //aray of Affiliation having no 'pin'
                                $arrImportStatusMsg[$file1]['affiliation']['no_pin_num'][] = $institution['name'];
                            }
                        }
                        foreach ($edcationDetailCount as $kolId => $values) {
                            if (!(isset($edcationDetailCount[$kolId]['affiliationCount']))) {
                                $edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
                            }
                        }

                        //pr($edcationDetailCount);
                        $arrImportStatusMsg[$file1]['affiliation']['success'] = true;
                       // pr($arrAffiliationForBulk);
                       // exit;
                        $this->kol->saveAffiliationDetailByBulk($arrAffiliationForBulk);
                    }
                    //- End of processing the sheet - 'Affiliation'
                    // Start of processing the sheet - 'Event'
                    if (strcasecmp(trim($sheet['name']),'Event')==0) {
                        $startTime = microtime(true);
                        $arrEventsForBulk = array();
                        //echo "In Events<br />";
                        //Check the Event Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Event Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Event Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Session Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Session Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Role")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Topic")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Start")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"End")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Organizer")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Organizer Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Session Sponsor")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Sponsor Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"Location")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Address")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Country")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"State")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"City")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Postal Code")!=0) {
                            $arrImportStatusMsg[$file1]['event']['incorrect_format'] = 'Event Info Header format is incorrect';
                            //break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolDetails = array();
                            $eventDetails = array();
                            $event = array();
                            $countryId = 0;
                            $stateId = 0;
                            $cityId = 0;
                            $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $event['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            if ($kolDetails['pin'] != '' && $event['name'] != '') {
                                $eventDetails['type'] = 'conference';
                                //Get event id
                                $event['category'] = 'conference';
                                $event['created_by'] = $this->loggedUserId;
                                $event['created_on'] = date('Y-m-d H:i:s');
                                $eventId = $this->kol->getEventIdElseSave($event);
                                $eventDetails['event_id'] = $eventId;
                                //Get the event type ID
                                $eventType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][3])), $arrEventTypes);
                                if (!$eventType) {
                                    $arrEventType['event_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][3]));
                                    if ($this->db->insert('conf_event_types', $arrEventType)) {
                                        $eventType = $this->db->insert_id();
                                        $arrEventTypes[$eventType] = $arrEventType['event_type'];
                                    } else {
                                        $eventType = "";
                                    }
                                }
                                $eventDetails['event_type'] = $eventType;
                                //Get the Session type ID
                                $sessionType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][4])), $arrSessionTypes);
                                if (!$sessionType) {
                                    $arrSessionType['session_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][4]));
                                    if ($this->db->insert('conf_session_types', $arrSessionType)) {
                                        $sessionType = $this->db->insert_id();
                                        $arrSessionTypes[$sessionType] = $arrSessionType['session_type'];
                                    } else {
                                        $sessionType = "";
                                    }
                                }
                                $eventDetails['session_type'] = $sessionType;

                                $eventDetails['session_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
                                $eventDetails['role'] = ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
                                //Get the Evet Topic Id and then Save
                                $topic = '';
                                $topicId = '';
                                $topic = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
                                if ($topic != '') {
                                    $topicId = $this->kol->getTopicId($topic);
                                    if ($topicId == 0) {
                                        $arrEventTopic['name'] = $topic;
                                        if ($this->db->insert('event_topics', $arrEventTopic)) {
                                            $topicId = $this->db->insert_id();
                                        }
                                    }
                                }
                                $eventDetails['topic'] = $topicId;
                                //Get the start and end Dates
                                $startDate = '';
                                $endDate = '';
                                $startDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][8]));
                                $endDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][9]));
                                $eventDetails['start'] = $startDate;
                                $eventDetails['end'] = $endDate;
                                $eventDetails['organizer'] = trim($reader->sheets[$k]["cells"][$row][10]);

                                $oranizerType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][11])), $arrEventOrganizerTypes);

                                $eventDetails['organizer_type'] = $oranizerType;

                                $eventDetails['session_sponsor'] = trim($reader->sheets[$k]["cells"][$row][12]);

                                $sponsorType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][13])), $arrEventSponsorTypes);

                                $eventDetails['sponsor_type'] = $sponsorType;


                                //
                                $eventDetails['location'] = trim($reader->sheets[$k]["cells"][$row][14]);

                                $eventDetails['address'] = trim($reader->sheets[$k]["cells"][$row][15]);
                                if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][16])), $arrCountries))
                                    $countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][16]))]['country_id'];
                                $eventDetails['country_id'] = $countryId;
                                $index = $countryId.'_'.ucwords(trim(str_replace(" ", "_", $reader->sheets[$k]["cells"][$row][17])));
                                if (array_key_exists($index, $arrStatesAssociated)){                                    
                                    $stateId = $arrStatesAssociated[$index]['state_id'];
                                }    
                                $eventDetails['state_id'] = $stateId;
                                $index = $countryId.'_'.$stateId.'_'.ucwords(trim(str_replace(" ", "_", $reader->sheets[$k]["cells"][$row][18])));
                                if (array_key_exists($index, $arrCitiesAssociated)){
                                    $cityId = $arrCitiesAssociated[$index]['city_id'];
                                } 
                                $eventDetails['city_id'] = $cityId;
                                $eventDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
                                $eventDetails['created_by'] = $this->loggedUserId;
                                $eventDetails['created_on'] = date("Y-m-d H:i:s");
                                $eventDetails['client_id'] = $this->session->userdata('client_id');
                                $eventDetails['data_type_indicator'] = $profile_type;
                                
                                //Save only if the 'pin' is not blank
                                if ($kolDetails['pin'] != "") {
                                    $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                    if ($kolId != 0) {
                                        $eventDetails['kol_id'] = $kolId;
                                        //$id						= $this->kol->saveEvent($eventDetails);
                                        $edcationDetailCount[$kolId]['kolId'] = $kolId;
                                        $arrEventsForBulk[] = $eventDetails;
                                    } else {
                                        $arrImportStatusMsg[$file1]['event']['no_matching_pin_num'][] = $kolDetails['pin'];
                                    }
                                } else {
                                    //aray of Event having no 'pin'
                                    $arrImportStatusMsg[$file1]['event']['no_pin_num'][] = $event['name'];
                                }
                            }
                        }
                        foreach ($edcationDetailCount as $kolId => $values) {
                            if (!(isset($edcationDetailCount[$kolId]['eventCount']))) {
                                $edcationDetailCount[$kolId]['eventCount'] = $this->kol->getCountOfEvents($kolId);
                            }
                        }
                        //	echo "End Time".(microtime(true)-$startTime);
                        $arrImportStatusMsg[$file1]['event']['success'] = true;
                        $this->kol->saveEventDetailByBulk($arrEventsForBulk);
                    }
                    //- End of processing the sheet - 'Event'
                    //- End of processing the sheet - 'Publication'
                    if (strcasecmp(trim($sheet['name']),'Publication')==0) {
                        //echo "started publication<br />";
                        //Check the Publication Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                               strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Article Title")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"PMID")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Journal Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Authors")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Authorship Position")!=0) {
                            $arrImportStatusMsg[$file1]['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
                            break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolDetails = array();
                            $pubDetails = array();
                            $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $pubDetails['article_title'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $pubDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            //get journal name
                            $journalName = '';
                            $journalName = trim($reader->sheets[$k]["cells"][$row][4]);
                            $pubDetails['created_date'] = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][5]));
                            //Considering this data also Manually added Import data
                            $pubDetails['is_manual'] = 1;
                            $pubDetails['link'] = trim($reader->sheets[$k]["cells"][$row][8]);
                            $pubDetails['data_type_indicator'] = $profile_type;
                            //For Authors
                            //Currently considering as last name, initial, first name format
                            $multipleAuthors = array();
                            $authorsData = trim($reader->sheets[$k]["cells"][$row][6]);
                            $arrAuthor = explode(',', $authorsData);
                            foreach ($arrAuthor as $authors) {
                                $lastName = '';
                                $initials = '';
                                $foreName = '';
                                $authors = trim($authors);
                                $singleAuthor = explode(" ", $authors);
                                $singleAuthorStrings = array();
                                foreach ($singleAuthor as $authString) {
                                    if ($authString != '')
                                        $singleAuthorStrings[] = $authString;
                                }
                                $singleAuthor = $singleAuthorStrings;
                                if (sizeof($singleAuthor) > 0) {
                                    $lastName = trim($singleAuthor[0]);
                                }
                                //As per the CR Considering the last name and initial to insert. they will change in the ambiguity
                                if (sizeof($singleAuthor) > 1) {
                                    $initials = trim($singleAuthor[1]);
                                }
                                if (sizeof($singleAuthor) > 2) {
                                    $initials = $initials . " " . trim($singleAuthor[2]);
                                }
                                $author['last_name'] = $lastName;
                                $author['initials'] = $initials;
                                $author['fore_name'] = '';
                                $multipleAuthors[] = $author;
                            }
                            $authPosition = trim($reader->sheets[$k]["cells"][$row][7]);
                            //Save only if the 'pin' is not blank
                            if ($kolDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                if ($kolId != 0) {

                                    //foreach($edcationDetailCount as $kolId=>$values){
                                    if (!(isset($edcationDetailCount[$kolId]['pubCount']))) {
                                        $edcationDetailCount[$kolId]['pubCount'] = $this->kol->getCountOfPubs($kolId);
                                    }
                                    //}
                                    $pmId = array();
                                    if ($pubDetails['pmid'] == '') {
                                        $pmId[] = $this->pubmed->getManualPmid();
                                        $pubDetails['pmid'] = $pmId[0];
                                    } else {
                                        //Check for the pmid. if its present then associate it with kol
                                        $arrUniquePMIDs = array($pubDetails['pmid']);
                                        //Returns the NEW pmid which is not there in database
                                        $pmId = $this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId, null, 1);
                                    }

                                    //If its new pmID then insert it into database
                                    if (sizeof($pmId) > 0) {
                                        $pubDetails['journal_id'] = $this->pubmed->savejournalName($journalName);
                                        $pubId = $this->pubmed->savePublicationsManualAndFlags($pubDetails, $kolId);
                                        //save 'publication-authors'
                                        $isSaved = $this->save_pub_authors($multipleAuthors, $pubId);
                                        $position = '';
                                        if (!empty($authPosition)) {
                                            $position = $authPosition;
                                        } else {
                                            //	Calculate Authorship position and save
                                            $position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
                                        }
                                        $this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
                                    } else {
                                        $arrImportStatusMsg[$file1]['publication']['pmid_exist'][] = $pubDetails['pmid'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
                                        $pubId = $this->pubmed->checkPubExist($pubDetails['pmid']);
                                        if (!empty($authPosition)) {
                                            $position = $authPosition;
                                        } else {
                                            //	Calculate Authorship position and save
                                            $position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
                                        }
                                        //echo $pubId.':'.$kolId.':'.$position."-";
                                        $this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
                                    }
                                } else {
                                    $arrImportStatusMsg[$file1]['publication']['no_matching_pin_num'][] = $kolDetails['pin'];
                                }
                            } else {
                                //aray of publication having no 'pin'
                                $arrImportStatusMsg[$file1]['publication']['no_pin_num'][] = $publication['pmid'];
                            }
                        }
                        $arrImportStatusMsg[$file1]['publication']['success'] = true;
                    }
                    //- End of processing the sheet - 'Publication'
                    //- End of processing the sheet - 'Clinical Trial'
                    if (strcasecmp(trim($sheet['name']),'Trial')==0) {
                        //echo "started trial<br />";
                        //Check the Trial Info Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"CTID")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Study Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Trial Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Condition")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Intervention")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Phase")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Role")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Number of enrollees")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Number of trial sites")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Sponsors")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Status")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Start Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"End Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Minimum Age")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Maximum Age")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"Gender")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Investigators")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Collaborator")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Purpose")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Official Title")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Keywords")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"MeSH Terms")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][24]),"Url")!=0) {
                            $arrImportStatusMsg[$file1]['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
                            break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolDetails = array();
                            $trialDetails = array();
                            $kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $trialDetails['ct_id'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $trialDetails['study_type'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            $trialDetails['trial_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            $trialDetails['kol_role'] = trim($reader->sheets[$k]["cells"][$row][8]);
                            $trialDetails['no_of_enrollees'] = trim($reader->sheets[$k]["cells"][$row][9]);
                            $trialDetails['no_of_trial_sites'] = trim($reader->sheets[$k]["cells"][$row][10]);
                            $trialDetails['start_date'] = trim($reader->sheets[$k]["cells"][$row][13]);
                            $trialDetails['end_date'] = trim($reader->sheets[$k]["cells"][$row][14]);
                            $trialDetails['min_age'] = trim($reader->sheets[$k]["cells"][$row][15]);
                            $trialDetails['max_age'] = trim($reader->sheets[$k]["cells"][$row][16]);
                            $trialDetails['gender'] = trim($reader->sheets[$k]["cells"][$row][17]);
                            $trialDetails['collaborator'] = trim($reader->sheets[$k]["cells"][$row][19]);
                            $trialDetails['purpose'] = trim($reader->sheets[$k]["cells"][$row][20]);
                            $trialDetails['official_title'] = trim($reader->sheets[$k]["cells"][$row][21]);
                            $trialKeywords = trim($reader->sheets[$k]["cells"][$row][22]);
                            $trialMeshTerms = trim($reader->sheets[$k]["cells"][$row][23]);
                            $trialDetails['link'] = trim($reader->sheets[$k]["cells"][$row][24]);
                            $statusName = trim($reader->sheets[$k]["cells"][$row][12]);
                            $trialDetails['data_type_indicator'] = $profile_type;
                            //Considering this data also Manually added Import data
                            $trialDetails['is_manual'] = 1;


                            //As per the CR Sponcer and Investigators are separating by (;),semicolon
                            //For sponcers
                            $arrSponcers = array();
                            $multipleSponcers = array();
                            $multiSponcers = array();
                            $sponcers = trim($reader->sheets[$k]["cells"][$row][11]);
                            if ($sponcers != '') {
                                $arrSponcers = explode(';', $sponcers);
                                foreach ($arrSponcers as $singleSponcer) {
                                    $multipleSponcers['agency'] = $singleSponcer;
                                    $multiSponcers[] = $multipleSponcers;
                                }
                            }
                            $trialDetails['condition'] = trim($reader->sheets[$k]["cells"][$row][5]);
                            //For intervention
                            $arrInterventions = array();
                            $multipleInterventions = array();
                            $multiInterventions = array();
                            $interventions = trim($reader->sheets[$k]["cells"][$row][6]);
                            if ($interventions != '') {
                                $arrInterventions = explode(';', $interventions);
                                foreach ($arrInterventions as $singleIntervention) {
                                    $multipleInterventions['name'] = $singleIntervention;
                                    $multiInterventions[] = $multipleInterventions;
                                }
                            }
                            $trialDetails['phase'] = trim($reader->sheets[$k]["cells"][$row][7]);
                            //For Investigators
                            $arrInvestigator = array();
                            $multipleInvestigators = array();
                            $multiInvestigators = array();
                            $investigators = trim($reader->sheets[$k]["cells"][$row][18]);
                            if ($investigators != '') {
                                $arrInvestigator = explode(';', $investigators);
                                foreach ($arrInvestigator as $singleInvestigator) {
                                    $multipleInvestigators['last_name'] = $singleInvestigator;
                                    $multiInvestigators[] = $multipleInvestigators;
                                }
                            }

                            //Save only if the 'pin' is not blank
                            if ($kolDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
                                if ($kolId != 0) {

                                    if (!(isset($edcationDetailCount[$kolId]['trialCount']))) {
                                        $edcationDetailCount[$kolId]['trialCount'] = $this->kol->getCountOfTrials($kolId);
                                    }
                                    $nctId = array();
                                    if ($trialDetails['ct_id'] == '') {
                                        $nctId[] = $this->clinical_trial->getManualCtid();
                                        $trialDetails['ct_id'] = $nctId[0];
                                    } else {
                                        //Check for the ct_id. if its present then associate it with kol
                                        $arrUniqueCTIDs = array($trialDetails['ct_id']);
                                        //Returns the NEW CTID which is not there in database
                                        $nctId = $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId);
                                    }
                                    //If its new CTID then insert it into database
                                    if (sizeof($nctId) > 0) {
                                        $statusId = $this->clinical_trial->saveStatus($statusName);
                                        $trialDetails['status_id'] = $statusId;
                                        $ctId = $this->clinical_trial->saveClinicalTrialsManualAndFlags($trialDetails, $kolId);
                                        if (sizeof($multiSponcers) > 0) {
                                            $isSaved = $this->clinical_trial->saveSponsers($multiSponcers, $ctId);
                                        }
                                        if (sizeof($multiInterventions) > 0) {
                                            $isSaved = $this->clinical_trial->saveInterventions($multiInterventions, $ctId);
                                        }
                                        if (sizeof($multiInvestigators) > 0) {
                                            $isSaved = $this->clinical_trial->saveInvestigators($multiInvestigators, $ctId);
                                        }
                                        if ($trialKeywords != '') {
                                            $arrTrialKeywords = explode(',', $trialKeywords);
                                            foreach ($arrTrialKeywords as $key => $keyword) {
                                                if ($keywordId = $this->clinical_trial->getKeywordIdByKeyword($keyword)) {
                                                    //	echo 'Already exists '.$keyword;
                                                } else if ($keywordId = $this->clinical_trial->saveKeyword(array('name' => $keyword))) {
                                                    //	echo 'New Keyword '.$keyword;
                                                }
                                                if (!empty($keywordId)) {
                                                    $arrAssociateKeyword['keyword_id'] = $keywordId;
                                                    $arrAssociateKeyword['cts_id'] = $ctId;
                                                    $this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
                                                }
                                            }
                                        }
                                        if ($trialMeshTerms != '') {
                                            $arrTrialMeshTerms = explode(',', $trialMeshTerms);
                                            foreach ($arrTrialMeshTerms as $key => $meshTerm) {
                                                if ($meshTermId = $this->clinical_trial->getMeshTermIdByMeshTerm($meshTerm)) {
                                                    //	echo 'Already exists '.$keyword;
                                                } else if ($meshTermId = $this->clinical_trial->saveMeshterms(array('term_name' => $meshTerm))) {
                                                    //	echo 'New Keyword '.$keyword;
                                                }
                                                if (!empty($meshTermId)) {
                                                    $arrAssociateMeshTerm['term_id'] = $meshTermId;
                                                    $arrAssociateMeshTerm['cts_id'] = $ctId;
                                                    $this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
                                                }
                                            }
                                        }
                                    } else
                                        $arrImportStatusMsg[$file1]['trial']['ctid_exist'][] = $trialDetails['ct_id'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
                                }else {
                                    $arrImportStatusMsg[$file1]['trial']['no_matching_pin_num'][] = $kolDetails['pin'];
                                }
                            } else {
                                //aray of trial having no 'pin'
                                $arrImportStatusMsg[$file1]['trial']['no_pin_num'][] = $trialDetails['ct_id'];
                            }
                        }
                        $arrImportStatusMsg[$file1]['trial']['success'] = true;
                    }
                    //- End of processing the sheet - 'Clinical Trials'
                    // Start of processing the sheet - 'Social Media'
                    if (strcasecmp(trim($sheet['name']),'Social Media')==0) {
                        //echo "started social media<br />";
                        //Check the Social Media Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Blog")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Linkedin")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Facebook")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Twitter")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"YouTube")!=0) {
                            $arrImportStatusMsg[$file1]['media']['incorrect_format'] = 'Social Media Header format is incorrect';
                            //break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $kolsDetails['blog'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            $kolsDetails['linked_in'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            $kolsDetails['facebook'] = trim($reader->sheets[$k]["cells"][$row][4]);
                            $kolsDetails['twitter'] = trim($reader->sheets[$k]["cells"][$row][5]);
                            $kolsDetails['you_tube'] = trim($reader->sheets[$k]["cells"][$row][6]);
                            //Update only if the 'pin' is not blank
                            if ($kolsDetails['pin'] != "") {
                                $id = $this->kol->updateImportedKol($kolsDetails);
                                if ($id == false) {
                                    //array of 'pin' not present in database
                                    $arrImportStatusMsg[$file1]['media']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                }
                            } else {
                                //aray of media having no 'pin'
                                $arrImportStatusMsg[$file1]['media']['no_pin_num'][] = $kolsDetails['linked_in'];
                            }
                        }
                        $arrImportStatusMsg[$file1]['media']['success'] = true;
                    }
                    //- End of processing the sheet - 'Social Media'
                    // Start of processing the sheet - 'PMIDs Only'
                    if (strcasecmp(trim($sheet['name']),'PMIDs_only')==0) {
                        //echo "started social media<br />";
                        //Check the Social Media Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Article Title")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"PMID")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Journal Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Authors")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Authorship Position")!=0) {
                            $arrImportStatusMsg['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
                            break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $kolsDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
                            //Add only if the 'pin' is not blank
                            if ($kolsDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
                                if ($kolId == false) {
                                    //array of 'pin' not present in database
                                    $arrImportStatusMsg['publication']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                } else {
                                    $status = $this->pubmed->savePMID($kolsDetails['pmid'], $kolId);
                                    if ($status == false)
                                        $arrImportStatusMsg['publication']['pmid_exist'][] = $kolsDetails['pmid'];

                                    $kolPubmedStatusData = array();
                                    $kolPubmedStatusData['id'] = $kolId;
                                    $kolPubmedStatusData['is_pubmed_processed'] = 2;
                                    $this->pubmed->updatePubmedProcessedKol($kolPubmedStatusData);
                                }
                            }else {
                                //aray of media having no 'pin'
                                $arrImportStatusMsg['publication']['no_pin_num'][] = $kolsDetails['linked_in'];
                            }
                        }
                        $arrImportStatusMsg['publication']['success'] = true;
                    }
                    //- End of processing the sheet - 'PMIDs only'
                    // Start of processing the sheet - 'CTIDs Only'
                    if (strcasecmp(trim($sheet['name']),'CTIDs_only')==0) {
                        //echo "started social media<br />";
                        //Check the Social Media Header Format
                        $row = 1;
                        if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"CTID")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Study Type")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Trial Name")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Condition")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Intervention")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Phase")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Role")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Number of enrollees")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Number of trial sites")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Sponsors")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Status")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Start Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"End Date")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Minimum Age")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Maximum Age")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"Gender")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Investigators")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Collaborator")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Purpose")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Official Title")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Keywords")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"MeSH Terms")!=0 ||
                                strcasecmp(trim($reader->sheets[$k]["cells"][$row][24]),"Url")!=0) {
                            $arrImportStatusMsg['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
                            break;
                        }
                        for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                            $kolsDetails = array();
                            $kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
                            $kolsDetails['ctid'] = trim($reader->sheets[$k]["cells"][$row][2]);
                            //Add only if the 'pin' is not blank
                            if ($kolsDetails['pin'] != "") {
                                $kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
                                if ($kolId == false) {
                                    //array of 'pin' not present in database
                                    $arrImportStatusMsg['trial']['no_matching_pin_num'][] = $kolsDetails['pin'];
                                } else {
                                    $status = $this->clinical_trial->saveCTID($kolsDetails['ctid'], $kolId);
                                    if ($status == false)
                                        $arrImportStatusMsg['trial']['ctid_exist'][] = $kolsDetails['ctid'];

                                    $kolTrialStatusData = array();
                                    $kolTrialStatusData['id'] = $kolId;
                                    $kolTrialStatusData['is_clinical_trial_processed'] = 0;
                                    $this->clinical_trial->updateClinicalTrialProcessedKol($kolTrialStatusData);
                                }
                            }else {
                                //aray of media having no 'pin'
                                $arrImportStatusMsg['trial']['no_pin_num'][] = $kolsDetails['linked_in'];
                            }
                        }
                        $arrImportStatusMsg['trial']['success'] = true;
                    }
                    //- End of processing the sheet - 'CTIDs only'
                }
                //- End of Looping through each sheets
                /* } else{
                  $arrImportStatusMsg['professional']['upload_error']		= "Error in uploading file '".$_FILES["prof_import"]['name']."'";
                  } */
                //- End of processing the EXCEL FILE
                /* }else{
                  // Set the error message if the file is not of EXCEL
                  $arrImportStatusMsg['professional']['file_type_missmatch']	= "Sorry! File is not the valid EXCEL FILE. Kindly upload the Valid Excel file with XLS or XLSX extension'";
                  }
                  } */
                //if($currentMethod == 'analyst_kol_import_page'){
                //pr($arrImportStatusMsg);
                //$data['arrImportStatusMsg'][]	= $arrImportStatusMsg;
                $data[$file1]['timeTaken'] = "Time Taken for Import " . $file1 . ": " . ( microtime(true) - $startTime) . "";

                /* }else{
                  $data['arrImportStatusMsg']	= $arrImportStatusMsg;
                  $data['contentPage'] 		= 'kols/kol_import_status';
                  //$this->load->view('layouts/client_view',$data);
                  } */
            }
            $data['arrImportStatusMsg'][] = $arrImportStatusMsg;
        }
        //Delete The uploaded file which is used to read the data.
        //unlink($uploadedFile);


        foreach ($edcationDetailCount as $key => $count) {
            $arrName = $this->kol->getKolName($key);
            $count['name'] = $arrName['first_name'] . " " . $arrName['middle_name'] . " " . $arrName['last_name'];
            if (isset($count['educationCount'])) {
                $eduCount = $this->kol->getCountOfEducations($key);
                $count['eduCountAfterImport'] = $eduCount - $count['educationCount'];
            }
            if (isset($count['affiliationCount'])) {
                $affCount = $this->kol->getCountOfAffiliation($key);
                $count['affCountAfterImport'] = $affCount - $count['affiliationCount'];
            }
            if (isset($count['eventCount'])) {
                $eventCount = $this->kol->getCountOfEvents($key);
                $count['eventCountAfterImport'] = $eventCount - $count['eventCount'];
            }
            if (isset($count['pubCount'])) {
                $pubCount = $this->kol->getCountOfPubs($key);
                $count['pubCountAfterImport'] = $pubCount - $count['pubCount'];
            }


            if (isset($count['trialCount'])) {
                $trialCount = $this->kol->getCountOfTrials($key);
                $count['trailCountAfterImport'] = $trialCount - $count['trialCount'];
            }

            $arrCounts[] = $count;
        }
        // Add the industry sponser events to industry affiliation
//         pr($totalKolIds);
//         exit;
        foreach ($totalKolIds as $key=>$val){
            $this->add_events_to_affiliations($val);
        }
        //pr($arrCounts);
        $data['arrCounts'] = $arrCounts;
        $data['contentPage'] = 'kols/kol_import_status';
        $this->load->view('layouts/analyst_view', $data);
        //echo "Total Time Taken : ".( microtime(true)-$initialTime);
    }
    function add_events_to_affiliations($kolId = '',$eventId=''){
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $this->db->where("sponsor_type",2);
        //		$this->db->where("role","Speaker");
        if($kolId != '')
            $this->db->where("kol_id",$kolId);
            if($eventId != '')
                $this->db->where("id",$eventId);
                $arr = $this->db->get("kol_events");
                $arrData = array();
                //		echo $this->db->last_query();
                //		exit;
                foreach ($arr->result_array() as $row){
                    //			pr($row);
                    //			continue;
                    if (strpos($row["start"], '/') !== FALSE){
                        $start = $this->getYear($row["start"]);
                    }else{
                        $start = $this->common_helpers->getOnlyYearByDate($row["start"]);
                    }
                    if (strpos($row["end"], '/') !== FALSE){
                        $end = $this->getYear($row["end"]);
                    }else{
                        $end = $this->common_helpers->getOnlyYearByDate($row["end"]);
                    }
                    $where = array();
                    $where["kol_id"] = $row['kol_id'];
                    $where["organizer"] = $row['session_sponsor'];
                    $where["start"] = $start;
                    $where["end"] = $end;
                    $row['start'] = $start;
                    $row['end'] = $end;
                    $arrMembershipResult = $this->kol->getAllAffiliationsTypeIndustry('industry',$where);
                    //			echo var_dump($arrMembershipResult);
                    	
                    if(!$arrMembershipResult){
                        //				$arrData[] = $row;
                        $arrAffData = array();
//                         $row["session_sponsor"] = mysqli_real_escape_string($row["session_sponsor"]);
                        $orgName["name"] = $row["session_sponsor"];
                        $instiId 						= $this->kol->getInstituteIdElseSave($orgName);
                        $arrAffData["kol_id"] 			= $row["kol_id"];
                        $arrAffData["engagement_id"] 	= 17;
                        $arrAffData["type"] 			= "industry";
                        $arrAffData["institute_id"] 	= $instiId;
                        $arrAffData["start_date"] 		= $row["start"];
                        $arrAffData["end_date"] 		= $row["end"];
                        $arrAffData["role"] 			= "Speaker";
                        $arrAffData["created_by"] 		= $this->loggedUserId;
                        $arrAffData["created_on"] 		= date("Y-m-d H:i:s");
                        $arrAffData["data_type_indicator"] 		= $dataType;
                        $arrAffData["client_id"] 		= $this->session->userdata('client_id');
                        $arrAffData["added_from"] 		= 1;
                        $arrAffData["source_row_id"] 	= $row["id"];
                        $this->db->insert('kol_memberships',$arrAffData);
//                         echo $this->db->last_query();
//                         				pr($arrAffData);
//                         				exit;
                    }
                }
                return true;
    
    }
    
    function getYear($monYear){
        $monYear = explode("/",$monYear);
        if(count($monYear) == 2)
            return $monYear[1];
            if(count($monYear) == 3)
                return $monYear[2];
    }

    function get_events_by_session_type_by_kol_id($kolId, $startDate, $endDate, $session_type) {
        $arrEvents = $this->kol->getEventsBySessionTypeByKolId($kolId, $startDate, $endDate, trim($session_type));
        $data['arrEvents'] = $arrEvents;
        //		pr($data['arrEvents']);
        $this->load->view('events/events_by_session_type_tabular_report', $data);
    }

    function get_events_by_topic_name_by_kol_id($kolId, $startDate, $endDate, $topicName) {
        $arrEvents = $this->kol->getEventsByTopicNameByKolId($kolId, $startDate, $endDate, trim($topicName));
        $data['arrEvents'] = $arrEvents;
        //		pr($data['arrEvents']);
        $this->load->view('events/events_by_session_type_tabular_report', $data);
    }

    function get_events_by_role_by_kol_id($kolId, $startDate, $endDate, $roleName) {
        $arrEvents = $this->kol->getEventsByRoleByKolId($kolId, $startDate, $endDate, trim($roleName));
        $data['arrEvents'] = $arrEvents;
        //		pr($data['arrEvents']);
        $this->load->view('events/events_by_session_type_tabular_report', $data);
    }

    function get_events_by_timeline_by_kol_id($kolId, $startDate, $eventType) {
        $arrEvents = $this->kol->getEventsByTimelineByKolId($kolId, $startDate, trim($eventType));
        $data['arrEvents'] = $arrEvents;
        $this->load->view('events/events_by_session_type_tabular_report', $data);
    }

    function get_events_by_soonsor_by_kol_id($kolId, $startDate, $endDate, $sponsorType) {
        $arrEvents = $this->kol->getEventsBySponsorByKolId($kolId, $startDate, $endDate, trim($sponsorType));
        $data['arrEvents'] = $arrEvents;
        $this->load->view('events/events_by_session_type_tabular_report', $data);
    }

    function delete_selected_educations($arrEduIds) {
        $arrEdus = explode(',', $arrEduIds);
        foreach ($arrEdus as $key => $id) {
            if ($id != '')
                $arrIds[] = $id;
        }
        if (sizeof($arrIds) > 0) {
            $this->kol->deleteEducationDetailByIds($arrIds);
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        //		pr($arrIds);
        echo json_encode($data);
    }

    function delete_selected_affiliations($arrTrainIds) {
        $arrAffIds = $this->input->post('ids');
        foreach ($arrAffIds as $key => $id) {
            if ($id != 'undefined')
                $arrIds[] = $id;
        }
        if (sizeof($arrIds) > 0) {
            $this->kol->deleteselectedAffiliations($arrIds);
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        //		pr($arrIds);
        echo json_encode($data);
    }

    function delete_selected_events() {
        $arrEveIds = $this->input->post('ids');
        foreach ($arrEveIds as $key => $id) {
            if ($id != 'undefined')
                $arrIds[] = $id;
        }
        if (sizeof($arrIds) > 0) {
            $this->kol->deleteselectedEvents($arrIds);
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        //		pr($arrIds);
        echo json_encode($data);
    }

    function process_url_parameters($urlString) {
        $filters = $this->filters_to_array($urlString);
        $kolId = (isset($filters['AISSELID'])) ? $filters['AISSELID'] : null;
        $npiId = (isset($filters['NPI'])) ? $filters['NPI'] : null;
        $firstName = (isset($filters['FIRST'])) ? $filters['FIRST'] : null;
        $lastName = (isset($filters['LAST'])) ? $filters['LAST'] : null;
        $middleName = (isset($filters['MIDDLE'])) ? $filters['MIDDLE'] : null;
        $CGDMAPPID = (isset($filters['CGDMAPPID'])) ? $filters['CGDMAPPID'] : null;
        $CGDMUSERID = (isset($filters['CGDMUSERID'])) ? $filters['CGDMUSERID'] : null;

        if ($kolId != null || $kolId != '') {
            return $kolId;
        }

        if (($kolId == null || $kolId == '') && ($npiId != null || $npiId != '')) {
            $kolId = $this->kol->getKolIdByNPI($npiId);
            if ($kolId != 0)
                return $kolId;
        }

        if (($firstName != null && $firstName != '') || ($lastName != null && $lastName != '') || ($middleName != null && $middleName != ''))
            redirect(base_url() . "requested_kols/show_client_requested_kols/" . $urlString);

        return $kolId;
    }

    /**
     *
     * @author 	Ramesh B
     * @since
     * @return
     * @created 15 Jan 2014
     */
    function filters_to_array($reportFilters) {
        $filters = array();
        if ($reportFilters != '') {
            $reportFiltersElements = explode(':', $reportFilters);
            foreach ($reportFiltersElements as $filterElement) {
                $filterElements = explode('=', $filterElement);
                $filterName = $filterElements[0];
                $filterValue = $filterElements[1];
                $filters[$filterName] = $filterValue;
            }
        }
        return $filters;
    }

    /*
     * To display survey form where user can enter survey of particular KOL
     * @param $id	- KOL id
     */

    function survey_form($kolId) {
        $arrData = array();
        $this->load->model("survey");
        $arrData['arrSurveys'] = $this->survey->getActiveSurveys();
        $arrData['arrRespondent'] = $this->survey->kolDetails($kolId, true);
        $arrData['contentPage'] = 'surveys/kol_survey_form';
        $this->load->view('layouts/client_view', $arrData);
    }

    function kol_export_opts() {
        $this->export_kol_new();
    }

    function export_kol_new($email=false,$kolId,$kolName) {
//		error_reporting(E_ALL);
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/classes/PHPExcel.php');
        if(!$email){
	        $exportOpts = $this->input->post('export_opts');
	//         pr($exportOpts);exit;
	        $kols = $this->input->post('kol_id');
	        $arrKolIds = explode(',', $kols);
        }else{
        	$exportOpts = array('education', 'affiliation', 'event', 'publication', 'trial', 'interaction', 'professional', 'biography', 'contact','user_notes','details');
        	$arrKolIds = array($kolId);
        }
        // Get PIN
        $kolArray = $this->kol->getKolsIdAndPin();
        // Get the list of Specialties
        $this->load->model('Specialty');
        $arrSpecialties = $this->Specialty->getAllSpecialties();
        $arrSubSpecialties = $this->Specialty->getAllKolSubSpecialties($arrKolIds);
        $subSpecialties = '';
        foreach($arrSubSpecialties as $key=>$value){
        	$subSpecialties .= $value.',';
        }
        $arrStyles =  array(
				'font'    => array(
						'bold'      => true,
						'italic'    => false
				),
				'borders' => array(
						'bottom'     => array(
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array(
										'rgb' => '000000'
								)
						),
						'quotePrefix'    => true
				)
		);
//		$exportOpts = array();
//		$exportOpts[] = "professional";
//		$exportOpts[] = "contact";
//		$exportOpts[] = "biography";
//		$exportOpts[] = "education";
//		$exportOpts[] = "affiliation";
//		$exportOpts[] = "event";
//		$exportOpts[] = "publication";
//		$exportOpts[] = "trial";
//		$exportOpts[] = "media";
//		pr($exportOpts);
//		exit;
        $clientId = $this->session->userdata('client_id');

        $objPHPExcel = new PHPExcel();
//		$objPHPExcel->setActiveSheetIndex(0);
//		$arrKolIds = array(2016,1619,1976,264,2018);
        $arrExcelData = array();
        foreach ($arrKolIds as $kolsId) {
            $arrKolDetails[$kolsId] = $this->kol->getKolDetailsById($kolsId);
        }
//         pr($arrKolDetails);exit;
//		foreach ($arrKolIds as $kolsId){
//			$arrKolDetails	=	$this->kol->getKolDetailsById($kolId);
        if (in_array('professional', $exportOpts)) {
            //New Worksheet
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//				$objWorksheet = $objPHPExcel->getActiveSheet();
            $objWorksheet->setTitle('Prof_Info');
            //Add header
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Salutation')
                    ->setCellValue('C1', 'First Name')
                    ->setCellValue('D1', 'Middle Name')
                    ->setCellValue('E1', 'Last Name')
                    ->setCellValue('F1', 'Suffix')
                    ->setCellValue('G1', 'Gender')
                    ->setCellValue('H1', 'Specialty')
                    ->setCellValue('I1', 'Sub-Specialty')
                    ->setCellValue('J1', 'Company Name')
                    ->setCellValue('K1', 'Division')
                    ->setCellValue('L1', 'Title')
                   // ->setCellValue('M1', 'License #')
                    //->setCellValue('N1', 'NPI Number')
                    ->setCellValue('M1', 'Profile Type');

            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('P1', 'Url');
            }
            $i = 2;
//             pr($arrKolDetails);
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$row['id']])
                            ->setCellValue('B' . $i, $row['salutation'])
                            ->setCellValue('C' . $i, $row['first_name'])
                            ->setCellValue('D' . $i, $row['middle_name'])
                            ->setCellValue('E' . $i, $row['last_name'])
                            ->setCellValue('F' . $i, $row['suffix'])
                            ->setCellValue('G' . $i, $row['gender'])
                            ->setCellValue('H' . $i, $arrSpecialties[$row['specialty']])
                            ->setCellValue('I' . $i, rtrim($subSpecialties,','))
                            ->setCellValue('J' . $i, $row['org_id'])
                            ->setCellValue('K' . $i, $row['division'])
                            ->setCellValue('L' . $i, $row['title'])
                            //->setCellValue('M' . $i, $row['license'])
                            //->setCellValue('N' . $i, $row['npi_num'])
                            ->setCellValue('M' . $i, $row['profile_type']);

                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $objWorksheet->setCellValue('P' . $i, $row['url']);
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Contact info section
        if (in_array('contact', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Contact Info');
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Primary Phone')
                    ->setCellValue('C1', 'Fax')
                    ->setCellValue('D1', 'Primary Email')
                    ->setCellValue('E1', 'Address 1')
                    ->setCellValue('F1', 'Address 2')
                    ->setCellValue('G1', 'City')
                    ->setCellValue('H1', 'State / Province')
                    ->setCellValue('I1', 'Postal Code')
                    ->setCellValue('J1', 'Country');
            $i = 2;
//             pr($arrKolDetails);
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
//                 $arrKolLocations	=	$this->kol->getLocationDetailsByKolId($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['primary_phone'])
                            ->setCellValue('C' . $i, $row['fax'])
                            ->setCellValue('D' . $i, $row['primary_email'])
                            ->setCellValue('E' . $i, $row['address1'])
                            ->setCellValue('F' . $i, $row['address1'])
                            ->setCellValue('G' . $i, $row['City'])
                            ->setCellValue('H' . $i, $row['Region'])
                            ->setCellValue('I' . $i, $row['postal_code'])
                            ->setCellValue('J' . $i, $row['Country']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
        
        //Details info section
        if (in_array('details', $exportOpts)) {
        	
        	$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        	$objWorksheet->setTitle('Details');
        	//Location Info
        	$objWorksheet->setCellValue('A1', 'Location');
        	$objWorksheet->setCellValue('A2', 'PIN')
        	->setCellValue('B2', 'Is Primary')
        	->setCellValue('C2', 'Institution Name')
        	->setCellValue('D2', 'Department')
        	->setCellValue('E2', 'Title')
        	->setCellValue('F2', 'Address 1')
        	->setCellValue('G2', 'Address 2')
        	->setCellValue('H2', 'City')
        	->setCellValue('I2', 'State/ Province')
        	->setCellValue('J2', 'Country')
        	->setCellValue('K2', 'Postal Code');
        	$locationData = $this->kol->getDetailsInfoById($arrKolIds,'Location');
        	$i = 3;
        	foreach ($locationData as $row) {
        			$objWorksheet->setCellValue('A' . $i, (isset($row['pin'])?$row['pin']:''))
        			->setCellValue('B' . $i, (isset($row['is_primary'])?$row['is_primary']:''))
        			->setCellValue('C' . $i, (isset($row['org_name'])?$row['org_name']:''))
        			->setCellValue('D' . $i, (isset($row['division'])?$row['division']:''))
        			->setCellValue('E' . $i, (isset($row['title'])?$row['title']:''))
        			->setCellValue('F' . $i, (isset($row['address1'])?$row['address1']:''))
        			->setCellValue('G' . $i, (isset($row['address2'])?$row['address2']:''))
        			->setCellValue('H' . $i, (isset($row['City'])?$row['City']:''))
        			->setCellValue('I' . $i, (isset($row['Region'])?$row['Region']:''))
        			->setCellValue('J' . $i, (isset($row['Country'])?$row['Country']:''))
        			->setCellValue('K' . $i, (isset($row['postal_code'])?$row['postal_code']:''));
        			$i++;
        	}
        	
        	
        	//Phone Info
        	$objWorksheet->setCellValue('N1', 'Phone');
        	$objWorksheet->setCellValue('N2', 'PIN')
        	->setCellValue('O2', 'Is Primary')
        	->setCellValue('P2', 'Institution Name')
        	->setCellValue('Q2', 'Phone Type')
        	->setCellValue('R2', 'Phone');
        	$phoneData = $this->kol->getDetailsInfoById($arrKolIds,'Phone');
        	$i = 3;
        	foreach ($phoneData as $row) {
        		$objWorksheet->setCellValue('N' . $i, (isset($row['pin'])?$row['pin']:''))
        		->setCellValue('O' . $i, (isset($row['is_primary'])?$row['is_primary']:''))
        		->setCellValue('P' . $i, (isset($row['org_name'])?$row['org_name']:''))
        		->setCellValue('Q' . $i, (isset($row['name'])?$row['name']:''))
        		->setCellValue('R' . $i, (isset($row['number'])?$row['number']:''));
        		$i++;
        	}
        	
        	//Email Info
        	$objWorksheet->setCellValue('U1', 'Email');
        	$objWorksheet->setCellValue('U2', 'PIN')
        	->setCellValue('V2', 'Is Primary')
        	->setCellValue('W2', 'Email Type')
        	->setCellValue('X2', 'Email');
        	$emailData = $this->kol->getDetailsInfoById($arrKolIds,'Email');
        	$i = 3;
        	foreach ($emailData as $row) {
        		$objWorksheet->setCellValue('U' . $i, (isset($row['pin'])?$row['pin']:''))
        		->setCellValue('V' . $i, (isset($row['is_primary'])?$row['is_primary']:''))
        		->setCellValue('W' . $i, (isset($row['type'])?$row['type']:''))
        		->setCellValue('X' . $i, (isset($row['email'])?$row['email']:''));
        		$i++;
        	}
        	
        	//License Info
        	$objWorksheet->setCellValue('AA1', 'License');
        	$objWorksheet->setCellValue('AA2', 'PIN')
        	->setCellValue('AB2', 'Is Primary')
        	->setCellValue('AC2', 'License')
        	->setCellValue('AD2', 'State/ Province')
        	->setCellValue('AE2', 'Country');
        	$licenseData = $this->kol->getDetailsInfoById($arrKolIds,'License');
        	$i = 3;
        	foreach ($licenseData as $row) {
        		$objWorksheet->setCellValue('AA' . $i, (isset($row['pin'])?$row['pin']:''))
        		->setCellValue('AB' . $i, (isset($row['is_primary'])?$row['is_primary']:''))
        		->setCellValue('AC' . $i, (isset($row['state_license'])?$row['state_license']:''))
        		->setCellValue('AD' . $i, (isset($row['Region'])?$row['Region']:''))
        		->setCellValue('AE' . $i, (isset($row['Country'])?$row['Country']:''));
        		$i++;
        	}
        	 //Specialty Info
        	$objWorksheet->setCellValue('AH1', 'Specialty');
        	$objWorksheet->setCellValue('AH2', 'PIN')
        	->setCellValue('AI2', 'Is Primary')
        	->setCellValue('AJ2', 'Specialty')
        	->setCellValue('AK2', 'Specialty Type');
        	$specialtyData = $this->kol->getDetailsInfoById($arrKolIds,'Specialty');
        	$i = 3;
        	foreach ($specialtyData as $row) {
        		$objWorksheet->setCellValue('AH' . $i, (isset($row['pin'])?$row['pin']:''))
        		->setCellValue('AI' . $i, (isset($row['is_primary'])?$row['is_primary']:''))
        		->setCellValue('AJ' . $i, (isset($row['specialty'])?$row['specialty']:''))
        		->setCellValue('AK' . $i, (isset($row['priority'])?$row['priority']:''));
        		$i++;
        	}
        	
        	//Staff Info
        	$objWorksheet->setCellValue('AN1', 'Staff');
        	$objWorksheet->setCellValue('AN2', 'PIN')
        	->setCellValue('AO2', 'Institution Name')
        	->setCellValue('AP2', 'Title')
        	->setCellValue('AQ2', 'Phone Type')
        	->setCellValue('AR2', 'Phone')
        	->setCellValue('AS2', 'Email')
        	->setCellValue('AT2', 'Address 1')
        	->setCellValue('AU2', 'Address 2')
        	->setCellValue('AV2', 'City')
        	->setCellValue('AW2', 'State/ Province')
        	->setCellValue('AX2', 'Country')
        	->setCellValue('AY2', 'Postal Code')
        	->setCellValue('AZ2', 'Staff Name');
        	$staffData = $this->kol->getDetailsInfoById($arrKolIds,'Staff');
        	$i = 3;
        	foreach ($staffData as $row) {
        		$objWorksheet->setCellValue('AN' . $i, (isset($row['pin'])?$row['pin']:''))
        		->setCellValue('AO' . $i, (isset($row['org_name'])?$row['org_name']:''))
        		->setCellValue('AP' . $i, (isset($row['staff_title'])?$row['staff_title']:''))
        		->setCellValue('AQ' . $i, (isset($row['phone_type'])?$row['phone_type']:''))
        		->setCellValue('AR' . $i, (isset($row['phone_number'])?$row['phone_number']:''))
        		->setCellValue('AS' . $i, (isset($row['email'])?$row['email']:''))
        		->setCellValue('AT' . $i, (isset($row['address1'])?$row['address1']:''))
        		->setCellValue('AU' . $i, (isset($row['address2'])?$row['address2']:''))
        		->setCellValue('AV' . $i, (isset($row['City'])?$row['City']:''))
        		->setCellValue('AW' . $i, (isset($row['Region'])?$row['Region']:''))
        		->setCellValue('AX' . $i, (isset($row['Country'])?$row['Country']:''))
        		->setCellValue('AY' . $i, (isset($row['postal_code'])?$row['postal_code']:''))
        		->setCellValue('AZ' . $i, (isset($row['name'])?$row['name']:''));
        		$i++;
        	} 
        	$objPHPExcel->addSheet($objWorksheet);
        }
// exit;
        //Biography section
        if (in_array('biography', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Profile_Summary');
            if(HIDE_CLINICAL_RESERCH_INTERESTS) {
                $objWorksheet->setCellValue('A1', 'PIN')
                ->setCellValue('B1', 'Profile Summary')
                ->setCellValue('C1', 'Clinical Research Interests');
            }else{
                $objWorksheet->setCellValue('A1', 'PIN')
                ->setCellValue('B1', 'Profile Summary');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    
                	$biography_excel = $this->display_profile_summary($row['biography'], 'excel');
                	if(HIDE_CLINICAL_RESERCH_INTERESTS) {
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                        ->setCellValue('B' . $i, $biography_excel)
                        ->setCellValue('C' . $i, $row['research_interests']);
                    }else{
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                        ->setCellValue('B' . $i, $biography_excel);
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Education section
        if (in_array('education', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Education');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Education Type')
                        ->setCellValue('C1', 'Institution Name')
                        ->setCellValue('D1', 'Degree')
                        ->setCellValue('E1', 'Specialty')
                        ->setCellValue('F1', 'Time Frame')
                        ->setCellValue('G1', 'Url1')
                        ->setCellValue('H1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Education Type')
                        ->setCellValue('C1', 'Institution Name')
                        ->setCellValue('D1', 'Degree')
                        ->setCellValue('E1', 'Specialty')
                        ->setCellValue('F1', 'Time Frame');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrEducationDetails = $this->kol->getEducationDetailById($kolsId);
                foreach ($arrEducationDetails as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['type']);
                    if ($row['type'] == 'honors_awards') {
                        $objWorksheet->setCellValue('C' . $i, $row['honor_name']);
                    } else {
                        $objWorksheet->setCellValue('C' . $i, $row['name']);
                    }
                    $objWorksheet->setCellValue('D' . $i, $row['degree'])
                            ->setCellValue('E' . $i, $row['specialty']);
                    $eduDate = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $eduDate .= $row['start_date'];
                    if (($row['start_date'] != '') && ($row['end_date']))
                        $eduDate .= " - ";
                    if ($row['end_date'] != '')
                        $eduDate .= $row['end_date'];
                    $objWorksheet->setCellValue('F' . $i, $eduDate);


                    if ($clientId == INTERNAL_CLIENT_ID) {
                        $objWorksheet->setCellValue('G' . $i, $row['url1'])
                                ->setCellValue('H' . $i, $row['url2']);
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Affiliation section
        if (in_array('affiliation', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Affiliation');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Organization Name')
                        ->setCellValue('C1', 'Dept/Committee')
                        ->setCellValue('D1', 'Title/Purpose')
                        ->setCellValue('E1', 'Time frame')
                        ->setCellValue('F1', 'Organization Type')
                        ->setCellValue('G1', 'Engagement Type')
                        ->setCellValue('H1', 'Url1')
                        ->setCellValue('I1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Organization Name')
                        ->setCellValue('C1', 'Dept/Committee')
                        ->setCellValue('D1', 'Title/Purpose')
                        ->setCellValue('E1', 'Time frame')
                        ->setCellValue('F1', 'Organization Type')
                        ->setCellValue('G1', 'Engagement Type');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrMembershipDetails = $this->kol->listAllMembershipsDetails($kolsId);
                foreach ($arrMembershipDetails as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['name'])
                            ->setCellValue('C' . $i, $row['department'])
                            ->setCellValue('D' . $i, $row['role']);
                    $affDate = '';
                    if ($row['start_date'] != '' && $row['start_date'] != 0)
                        $affDate .= $row['start_date'];
                    if (($row['start_date'] != '') && ($row['end_date']))
                        $affDate .= " - ";
                    if ($row['end_date'] != '')
                        $affDate .= $row['end_date'];
                    $objWorksheet->setCellValue('E' . $i, $affDate)
                            ->setCellValue('F' . $i, ucwords($row['type']))
                            ->setCellValue('G' . $i, $row['engagement_type']);
                    if ($clientId == INTERNAL_CLIENT_ID) {
                        if (isset($row['url1ForExport'])) {
                            $objWorksheet->setCellValue('H' . $i, $row['url1ForExport']);
                        }
                        if (isset($row['ur12ForExport'])) {
                            $objWorksheet->setCellValue('I' . $i, $row['ur12ForExport']);
                        }
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Events section
        if (in_array('event', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Event');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Event Name')
                        ->setCellValue('C1', 'Event Type')
                        ->setCellValue('D1', 'Session Type')
                        ->setCellValue('E1', 'Session Name')
                        ->setCellValue('F1', 'Role')
                        ->setCellValue('G1', 'Topic')
                        ->setCellValue('H1', 'Start')
                        ->setCellValue('I1', 'End')
                        ->setCellValue('J1', 'Organizer')
                        ->setCellValue('K1', 'Organizer Type')
                        ->setCellValue('L1', 'Session Sponsor')
                        ->setCellValue('M1', 'Sponsor Type')
                        ->setCellValue('N1', 'Location')
                        ->setCellValue('O1', 'Address')
                        ->setCellValue('P1', 'Country')
                        ->setCellValue('Q1', 'State')
                        ->setCellValue('R1', 'City')
                        ->setCellValue('S1', 'Postal Code')
                        ->setCellValue('T1', 'Url1')
                        ->setCellValue('U1', 'Url2');
            } else {
                $objWorksheet->setCellValue('A1', 'PIN')
                        ->setCellValue('B1', 'Event Name')
                        ->setCellValue('C1', 'Event Type')
                        ->setCellValue('D1', 'Session Type')
                        ->setCellValue('E1', 'Session Name')
                        ->setCellValue('F1', 'Role')
                        ->setCellValue('G1', 'Topic')
                        ->setCellValue('H1', 'Start')
                        ->setCellValue('I1', 'End')
                        ->setCellValue('J1', 'Organizer')
                        ->setCellValue('K1', 'Organizer Type')
                        ->setCellValue('L1', 'Session Sponsor')
                        ->setCellValue('M1', 'Sponsor Type')
                        ->setCellValue('N1', 'Location')
                        ->setCellValue('O1', 'Address')
                        ->setCellValue('P1', 'Country')
                        ->setCellValue('Q1', 'State')
                        ->setCellValue('R1', 'City')
                        ->setCellValue('S1', 'Postal Code');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrEventsDetails = $this->kol->listAllEvents($kolsId);
                foreach ($arrEventsDetails as $row) {
                    if ($row['type'] == 'conference') {
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                                ->setCellValue('B' . $i, $row['name'])
                                ->setCellValue('C' . $i, $row['event_type'])
                                ->setCellValue('D' . $i, $row['session_type'])
                                ->setCellValue('E' . $i, $row['session_name'])
                                ->setCellValue('F' . $i, $row['role'])
                                ->setCellValue('G' . $i, $this->kol->getTopicName($row['topic']))
                                ->setCellValue('H' . $i, $row['start'])
                                ->setCellValue('I' . $i, $row['end'])
                                ->setCellValue('J' . $i, $row['organizer'])
                                ->setCellValue('K' . $i, $row['otype'])
                                ->setCellValue('L' . $i, $row['session_sponsor'])
                                ->setCellValue('M' . $i, $row['stype'])
                                ->setCellValue('N' . $i, $row['location'])
                                ->setCellValue('O' . $i, $row['address'])
                                ->setCellValue('P' . $i, $row['Country'])
                                ->setCellValue('Q' . $i, $row['Region'])
                                ->setCellValue('R' . $i, $row['City'])
                                ->setCellValue('S' . $i, $row['postal_code']);
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $objWorksheet->setCellValue('T' . $i, $row['url1ForExport']);
                            }
                            if (isset($row['ur12ForExport'])) {
                                $objWorksheet->setCellValue('U' . $i, $row['ur12ForExport']);
                            }
                        }
                    }

                    if ($row['type'] == 'online') {
                        $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                                ->setCellValue('B' . $i, ucwords($row['type']))
                                ->setCellValue('C' . $i, $row['name'])
                                ->setCellValue('D' . $i, $row['event_type'])
                                ->setCellValue('E' . $i, $row['session_type'])
                                ->setCellValue('F' . $i, $row['role'])
                                ->setCellValue('G' . $i, $this->kol->getTopicName($row['topic']))
                                ->setCellValue('H' . $i, $row['start'])
                                ->setCellValue('I' . $i, $row['end'])
                                ->setCellValue('J' . $i, $row['organizer'])
                                ->setCellValue('K' . $i, '')
                                ->setCellValue('L' . $i, '')
                                ->setCellValue('M' . $i, '')
                                ->setCellValue('N' . $i, $row['location'])
                                ->setCellValue('O' . $i, $row['Address'])
                                ->setCellValue('P' . $i, $row['Country'])
                                ->setCellValue('Q' . $i, $row['Region'])
                                ->setCellValue('R' . $i, $row['City'])
                                ->setCellValue('S' . $i, '');
                        if ($clientId == INTERNAL_CLIENT_ID) {
                            if (isset($row['url1ForExport'])) {
                                $objWorksheet->setCellValue('T' . $i, $row['url1ForExport']);
                            }
                            if (isset($row['ur12ForExport'])) {
                                $objWorksheet->setCellValue('U' . $i, $row['ur12ForExport']);
                            }
                        }
                    }
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
//    pr($arrEventsDetails);exit;
        //Publications section
        if (in_array('publication', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('publication');
            //Add header
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Article Title')
                    ->setCellValue('C1', 'PMID')
                    ->setCellValue('D1', 'Journal Name')
                    ->setCellValue('E1', 'Date')
                    ->setCellValue('F1', 'Authors')
                    ->setCellValue('G1', 'Authorship Position');

            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                //Get the details for Pubmed
                $arrPublications = array();
                if ($arrPublicationsResults = $this->pubmed->listPublicationDetails($kolsId)) {
                    foreach ($arrPublicationsResults as $arrPublicationsResult) {
                        $arrPublication['id'] = $arrPublicationsResult['id'];
                        $arrPublication['pmid'] = $arrPublicationsResult['pmid'];
                        $arrPublication['journal_name'] = $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
                        $arrPublication['article_title'] = $arrPublicationsResult['article_title'];
                        $arrPublication['affiliation'] = $arrPublicationsResult['affiliation'];
                        $arrPublication['date'] = $this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
                        $arrPublication['authors'] = $this->get_pub_authors($arrPublication['id']);
                        $arrPublication['auth_pos'] = $arrPublicationsResult['auth_pos'];
                        //$arrPublication['auth_pos']		= $this->pubmed->getAuthPosForPublication($arrPublicationsResult['journal_id']);
                        $arrPublication['kol_id'] = $kolId;
                        $arrPublications[] = $arrPublication;
                    }
                }

                foreach ($arrPublications as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['article_title'])
                            ->setCellValue('C' . $i, $row['pmid'])
                            ->setCellValue('D' . $i, $row['journal_name'])
                            ->setCellValue('E' . $i, $row['date'])
                            ->setCellValue('F' . $i, $row['authors'])
                            ->setCellValue('G' . $i, $row['auth_pos']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }

        //Trial section
        if (in_array('trial', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Trial');
            $i = 2;
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'CTID')
                    ->setCellValue('C1', 'Study Type')
                    ->setCellValue('D1', 'Trial Name')
                    ->setCellValue('E1', 'Condition')
                    ->setCellValue('F1', 'Intervention')
                    ->setCellValue('G1', 'Phase')
                    ->setCellValue('H1', 'Role')
                    ->setCellValue('I1', 'Number of enrollees')
                    ->setCellValue('J1', 'Number of trial sites')
                    ->setCellValue('K1', 'Sponsors')
                    ->setCellValue('L1', 'Status')
                    ->setCellValue('M1', 'Start Date')
                    ->setCellValue('N1', 'End Date')
                    ->setCellValue('O1', 'Minimum Age')
                    ->setCellValue('P1', 'Maximum Age')
                    ->setCellValue('Q1', 'Gender')
                    ->setCellValue('R1', 'Investigators')
                    ->setCellValue('S1', 'Collaborator')
                    ->setCellValue('T1', 'Purpose')
                    ->setCellValue('U1', 'Official Title')
                    ->setCellValue('V1', 'Keywords')
                    ->setCellValue('W1', 'MeSH Terms')
                    ->setCellValue('X1', 'Url');
            //Get the details for Clinical Trials
            foreach ($arrKolIds as $kolsId) {
                $arrClinicalTrials = array();
                if ($arrClinicalTrialsResults = $this->clinical_trial->listClinicalTrialsDetails($kolsId)) {
                    foreach ($arrClinicalTrialsResults as $arrClinicalTrialsResult) {
                        $arrClinicalTrial['id'] = $arrClinicalTrialsResult['id'];
                        $arrClinicalTrial['ct_id'] = $arrClinicalTrialsResult['ct_id'];
                        $arrClinicalTrial['trial_name'] = $arrClinicalTrialsResult['trial_name'];
                        $arrClinicalTrial['status'] = $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
                        $arrClinicalTrial['sponsors'] = $this->get_sponsers($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['condition'] = $arrClinicalTrialsResult['condition'];
                        $arrClinicalTrial['interventions'] = $this->get_interventions($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['phase'] = $arrClinicalTrialsResult['phase'];
                        $arrClinicalTrial['investigators'] = $this->get_investigators($arrClinicalTrialsResult['id']);
                        $arrClinicalTrial['kol_id'] = $kolId;
                        $arrClinicalTrial['study_type'] = $arrClinicalTrialsResult['study_type'];
                        $arrClinicalTrial['kol_role'] = $arrClinicalTrialsResult['kol_role'];
                        $arrClinicalTrial['no_of_enrollees'] = $arrClinicalTrialsResult['no_of_enrollees'];
                        $arrClinicalTrial['no_of_trial_sites'] = $arrClinicalTrialsResult['no_of_trial_sites'];
                        $arrClinicalTrial['start_date'] = $arrClinicalTrialsResult['start_date'];
                        $arrClinicalTrial['end_date'] = $arrClinicalTrialsResult['end_date'];
                        $arrClinicalTrial['min_age'] = $arrClinicalTrialsResult['min_age'];
                        $arrClinicalTrial['max_age'] = $arrClinicalTrialsResult['max_age'];
                        $arrClinicalTrial['gender'] = $arrClinicalTrialsResult['gender'];
                        $arrClinicalTrial['collaborator'] = $arrClinicalTrialsResult['collaborator'];
                        $arrClinicalTrial['purpose'] = $arrClinicalTrialsResult['purpose'];
                        $arrClinicalTrial['official_title'] = $arrClinicalTrialsResult['official_title'];
                        $arrKeywordsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrKeywordsData .= $separator . $row['name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['keywords'] = $arrKeywordsData;
                        $arrMeshtermsData = '';
                        $separator = '';
                        foreach ($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key => $row) {
                            $arrMeshtermsData .= $separator . $row['term_name'];
                            $separator = ',';
                        }
                        $arrClinicalTrial['mesh_terms'] = $arrMeshtermsData;
                        $arrClinicalTrial['url'] = $arrClinicalTrialsResult['link'];
                        $arrClinicalTrials[] = $arrClinicalTrial;
                    }
                }

                foreach ($arrClinicalTrials as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['ct_id'])
                            ->setCellValue('C' . $i, $row['study_type'])
                            ->setCellValue('D' . $i, $row['trial_name'])
                            ->setCellValue('E' . $i, $row['condition'])
                            ->setCellValue('F' . $i, $row['interventions'])
                            ->setCellValue('G' . $i, $row['phase'])
                            ->setCellValue('H' . $i, $row['kol_role'])
                            ->setCellValue('I' . $i, $row['no_of_enrollees'])
                            ->setCellValue('J' . $i, $row['no_of_trial_sites'])
                            ->setCellValue('K' . $i, $row['sponsors'])
                            ->setCellValue('L' . $i, $row['status'])
                            ->setCellValue('M' . $i, $row['start_date'])
                            ->setCellValue('N' . $i, $row['end_date'])
                            ->setCellValue('O' . $i, $row['min_age'])
                            ->setCellValue('P' . $i, $row['max_age'])
                            ->setCellValue('Q' . $i, $row['gender'])
                            ->setCellValue('R' . $i, $row['investigators'])
                            ->setCellValue('S' . $i, $row['collaborator'])
                            ->setCellValue('T' . $i, $row['purpose'])
                            ->setCellValue('U' . $i, $row['official_title'])
                            ->setCellValue('V' . $i, $row['keywords'])
                            ->setCellValue('W' . $i, $row['mesh_terms'])
                            ->setCellValue('X' . $i, $row['url']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
     //user notes      
        if (in_array('user_notes', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('User Notes');
            if ($clientId == INTERNAL_CLIENT_ID) {
                $objWorksheet->setCellValue('A1', 'PIN')
                ->setCellValue('B1', 'Notes')  
                ->setCellValue('C1', 'Added By')
                ->setCellValue('D1', 'Created On');
            } else {
               $objWorksheet->setCellValue('A1', 'PIN')
                ->setCellValue('B1', 'Notes')                
                ->setCellValue('C1', 'Added By')
                ->setCellValue('D1', 'Created On');
            }
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
                $arrUserNotesDetails = $this->kol->getNotes($kolsId);
                foreach ($arrUserNotesDetails as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                    ->setCellValue('B' . $i, $row['note'])                    
                    ->setCellValue('C' . $i, $row['first_name']." ".$row['last_name'])
                    ->setCellValue('D' . $i, date('d M Y, h:i A', strtotime($row['created_on'])));
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
        //Social Media section
        if (in_array('media', $exportOpts)) {
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            $objWorksheet->setTitle('Social Media');
            $objWorksheet->setCellValue('A1', 'PIN')
                    ->setCellValue('B1', 'Blog')
                    ->setCellValue('C1', 'Linkedin')
                    ->setCellValue('D1', 'Facebook')
                    ->setCellValue('E1', 'Twitter')
                    ->setCellValue('F1', 'YouTube');
            $i = 2;
            foreach ($arrKolIds as $kolsId) {
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                foreach ($arrKolDetails[$kolsId] as $row) {
                    $objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
                            ->setCellValue('B' . $i, $row['blog'])
                            ->setCellValue('C' . $i, $row['linked_in'])
                            ->setCellValue('D' . $i, $row['facebook'])
                            ->setCellValue('E' . $i, $row['twitter'])
                            ->setCellValue('F' . $i, $row['you_tube']);
                    $i++;
                }
            }
            $objPHPExcel->addSheet($objWorksheet);
        }
        if (in_array('interaction', $exportOpts)) {
        	$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        	$objWorksheet->setTitle('Interaction');
        	$objWorksheet->setCellValue('A1', 'PIN')
        	->setCellValue('B1', 'KOL Name')
        	->setCellValue('C1', 'Date')
        	->setCellValue('D1', 'Time')
        	->setCellValue('E1', 'Mode')
        	->setCellValue('F1', 'Location')
        	->setCellValue('G1', 'Topic')
        	->setCellValue('H1', 'Brand')
        	->setCellValue('I1', 'Role')
        	->setCellValue('J1', 'Follow-Up On')
        	->setCellValue('K1', 'Category')
        	->setCellValue('L1', 'Therapeutic Area')
        	->setCellValue('M1', 'Notes');
        
        	//	$arrKolDetails['arrInteraction'][$kolsId]			$data6[0]=array('PIN','KOL Name','Date','Time','Mode','Location',' Topic','Brand','Role','Follow-Up On','Category','Therapeutic Area','Notes');
        	$i = 2;
        	foreach ($arrKolIds as $kolsId) {
        		//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
        		foreach ($arrKolDetails['arrInteraction'][$kolsId] as $row) {
        			$objWorksheet->setCellValue('A' . $i, $kolArray[$kolsId])
        			->setCellValue('B' . $i, $arrSalutation['arrSalutations'][$row['salutation']] . " " . $row['kol_name_for_export']);
        			if ($row['date'] != '0000-00-00') {
        				$objWorksheet->setCellValue('C' . $i, $row['date']);
        			} else {
        				$objWorksheet->setCellValue('C' . $i, '');
        			}
        			$objWorksheet->setCellValue('D' . $i, $row['time'])
        			->setCellValue('E' . $i, $row['mode_name'])
        			->setCellValue('F' . $i, $row['location'])
        			->setCellValue('G' . $i, $row['topic_name'])
        			->setCellValue('H' . $i, $row['brand_name'])
        			->setCellValue('I' . $i, $row['role_name']);
        			if ($row['follow_up_on'] != '0000-00-00') {
        				$objWorksheet->setCellValue('J' . $i, $row['follow_up_on']);
        			} else {
        				$objWorksheet->setCellValue('J' . $i, '');
        			}
        			$objWorksheet->setCellValue('K' . $i, $row['category_name'])
        			->setCellValue('L' . $i, $row['area_name'])
        			->setCellValue('M' . $i, $row['notes']);
        			$i++;
        		}
        	}
        	$objPHPExcel->addSheet($objWorksheet);
        }
//		}
        // remove first sheet

        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );

        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        $arrLabel =  array(
        		'font'    => array(
        				'bold'      => true,
        				'italic'    => false
        		)
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            if (in_array('professional', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'P') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($arrStyles);
            }
            if (in_array('contact', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'J') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($arrStyles);
            }
            if (in_array('details', $exportOpts)) {
            	$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            	foreach (range('A', 'AZ') as $columnID) {
            		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            	}
            	$objPHPExcel->getActiveSheet()->getStyle('A1:AZ1')->applyFromArray($arrStyles);
            	$objPHPExcel->getSheet(0)->getStyle('A1:AZ1')->applyFromArray($arrLabel);
            }
            if (in_array('Profile_Summary', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'C') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($arrStyles);
            }
            if (in_array('education', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'H') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($arrStyles);
            }
            if (in_array('affiliation', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'I') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($arrStyles);
            }
            if (in_array('event', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'U') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:U1')->applyFromArray($arrStyles);
            }
            if (in_array('publication', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'G') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($arrStyles);
            }
            if (in_array('trial', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'X') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:X1')->applyFromArray($arrStyles);
            }
            if (in_array('media', $exportOpts)) {
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'F') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            }
            if (in_array('interaction', $exportOpts)) {
            	$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            	foreach (range('A', 'M') as $columnID) {
            		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            	}
            	$objPHPExcel->getActiveSheet()->getStyle('A1:M1')->applyFromArray($arrStyles);
            }
        }
        $objPHPExcel->setActiveSheetIndex(0);
    	if($email){
	         $fileName	= $kolName;
	       	 $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	       	 $filePath	= $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/kol_personal_documents/".$fileName.'.xlsx';
	       	 $objWriter->save($filePath);
	       	 return $filePath;
        }else{
	        // Redirect output to a client’s web browser (Excel2007)
	        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	        header('Content-Disposition: attachment;filename="KTL_profiles.xlsx"');
	        header('Cache-Control: max-age=0');
	        // If you're serving to IE 9, then the following may be needed
	        header('Cache-Control: max-age=1');
	
	        // If you're serving to IE over SSL, then the following may be needed
	        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
	        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	        header('Pragma: public'); // HTTP/1.0
	
	        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	        $objWriter->save('php://output');
	        exit;
        }
    }

    function test_pdf() {
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');

        //$rendererName = PHPExcel_Settings::PDF_RENDERER_TCPDF;
        //$rendererName = PHPExcel_Settings::PDF_RENDERER_MPDF;
        $rendererName = PHPExcel_Settings::PDF_RENDERER_DOMPDF;
        //$rendererLibrary = 'tcPDF5.9';
        $rendererLibrary = 'DomPDF.php';
        //$rendererLibrary = 'domPDF0.6.0beta3';
        $rendererLibraryPath = $this->config->item('app_folder_path') . 'system/plugins/php_excel/Classes/PHPExcel/libraries/Writer/PDF/' . $rendererLibrary;
//		echo $rendererLibrary."</br>".$rendererLibraryPath;
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
                ->setLastModifiedBy("Maarten Balliauw")
                ->setTitle("PDF Test Document")
                ->setSubject("PDF Test Document")
                ->setDescription("Test document for PDF, generated using PHP classes.")
                ->setKeywords("pdf php")
                ->setCategory("Test result file");


        // Add some data
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'Hello')
                ->setCellValue('B2', 'world!')
                ->setCellValue('C1', 'Hello')
                ->setCellValue('D2', 'world!');

        // Miscellaneous glyphs, UTF-8
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A4', 'Miscellaneous glyphs')
                ->setCellValue('A5', '�����������������');

        // Rename worksheet
        $objPHPExcel->getActiveSheet()->setTitle('Simple');
        $objPHPExcel->getActiveSheet()->setShowGridLines(false);

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $objPHPExcel->setActiveSheetIndex(0);


        if (!PHPExcel_Settings::setPdfRenderer(
                        $rendererName, $rendererLibraryPath
                )) {
            die(
                    'NOTICE: Please set the $rendererName and $rendererLibraryPath values' .
                    '<br />' .
                    'at the top of this script as appropriate for your directory structure'
            );
        }


        // Redirect output to a client�s web browser (PDF)
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment;filename="01simple.pdf"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'PDF');
        $objWriter->save('php://output');
        exit;
    }

    /**
     * List the Locations data for view_biography"
     *
     */
    function list_locations($kolId = null) {
        $locations = array();
        $locations = $this->kol->listLocationDetails($kolId);
        foreach ($locations as $row) {
            $row['kol_id'] = $kolId;
            $row['address'] = trim($row['address'], ', ');
            $row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
            $row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
            if ($row['is_primary']){
                $row['is_primary'] = "<span class='is_primary'>&nbsp;</span>";
                $row['is_primary_value'] = 1;
            }else{
                $row['is_primary'] = "";
                $row['is_primary_value'] = 0;
            }
            if(!empty($row['private_practice']))
                $row['org_name'] = $row['private_practice'];
            else
                $row['org_name'] = $row['org_name'];
            $arrLocations[] = $row;
        }
        $data['kolId'] = $kolId;
        $data['locations'] = $arrLocations;
        echo json_encode($data);
    }
    /**
     * List the Locations data for view_biography"
     *
     */
    function list_kol_details($type,$kolId = null) {
    	if($type == 'phone'){
    		$responce = array();
    		$phone = array();
    		$phone = $this->kol->getPhones($kolId, 'kol');
//     		echo $this->db->last_query();exit;
    		foreach ($phone as $row) {
    			$responce->rows[$i]['id']=$row['id'];
    			$row['kol_id'] = $kolId;
    			$row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
    			$row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
    			if ($row['is_primary']==0)
    				$row['is_primary'] = "No";
    			else
    				$row['is_primary'] = "Yes";
    			$responce[] = $row;
    		}
    	}
    	if($type == 'staff'){
    		$responce = array();
    		$staff = array();
    		$staff = $this->kol->getStaffs($kolId, 'kol');
    		//     		echo $this->db->last_query();exit;
    		foreach ($staff as $row) {
    			$responce->rows[$i]['id']=$row['id'];
    			$row['kol_id'] = $kolId;
    			$row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
    			$row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
    			$responce[] = $row;
    		}
    	}
    	if($type == 'emails'){
    		$responce = array();
    		$emails = array();
    		$emails = $this->kol->getEmails($kolId, 'kol');
    		//     		echo $this->db->last_query();exit;
    		foreach ($emails as $row) {
    			$responce->rows[$i]['id']=$row['id'];
    			$row['kol_id'] = $kolId;
    			$row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
    			$row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
    			if ($row['is_primary']==0)
    				$row['is_primary'] = "No";
    			else
    				$row['is_primary'] = "Yes";
    			$responce[] = $row;
    		}
    	}
    	if($type == 'statelicense'){
    		$responce = array();
    		$statelicense = array();
    		//pr($arrKolDetail);exit;
    		//$arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
    		$statelicense = $this->kol->getStateLicences($kolId, 'kol');
    		foreach ($statelicense as $row) {
    			$responce->rows[$i]['id']=$row['id'];
    			$row['kol_id'] = $kolId;
    			$row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
    			$row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
    			if ($row['is_primary']==0)
    				$row['is_primary'] = "No";
    			else
    				$row['is_primary'] = "Yes";
    			$responce[] = $row;
    		}
    	}
    	if($type == 'assign'){
    		$responce = array();
    		$assignedUsers = array();
    		$assignedUsers = $this->kol->getAssignedUsers($kolId);
    		foreach ($assignedUsers as $row) {
    			$responce->rows[$i]['id']=$row['id'];
    			$row['kol_id'] = $kolId;
    			if(ROLE_USER && $this->session->userdata('user_id') == $row['user_id']){
    			    $row['created_by'] = '';
        			$row['eAllowed'] = true;
        			$row['dAllowed'] = true;
    			}else{
    			    $row['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $row);
    			    $row['dAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'delete', $row);
    			}
    			
    			$responce[] = $row;
    		}
    		
    	}
    	echo json_encode($responce);
    }
    
    
    function get_opt_log_details($kolId){
        $responce = array();
        $optDetails = $this->kol->getOptLogDetails($kolId);
        foreach ($optDetails as $row) {
            $responce->rows[$i]['id']=$row['id'];
            if($row['expire_date'] == '0000-00-00')
                $row['expire_date'] = '';
            else 
                $row['expire_date'] = sql_date_to_app_date($row['expire_date']);
            
            $row['created_on'] = sql_date_to_app_date($row['created_on']);
            if($row['transaction_name']!="Opt-in Approved"){
                $row['expire_date'] = '';
            }
            $responce[] = $row;
        }
        echo json_encode($responce);
    }
    /**
     * Add Location for kol
     */
    function add_location($kolId = null) {
        $data['arrCountries'] = $this->Country_helper->listCountries();
		$first_key = key($data['arrCountries']);
		$data['arrFirstCountry'] = $data['arrCountries'][$first_key]['country_id'];
		//$data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['arrFirstCountry']);
		$data['arrStates'] = array();
        $data['arrTitles'] = $this->kol->getAllActiveTitles('all');
        //$data['arrCities']		=	$this->Country_helper->listCities();
        $data['arrInstitutions'] = $this->Country_helper->listCountries();
        $data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
        $data['kolId'] = $kolId;
        $this->load->view('kols/add_location', $data);
    }
    /**
     * Add/Update Phone for kol
     */
    function add_update_phone($kolId = null,$type,$id) {
    	if($type=='edit'){
    		$tableName = 'phone_numbers';
    		$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
    		$data['displayContent'] = true;
    	}else{
	    	$data['displayContent'] = false;
    	}
    	$data['kolId'] = $kolId;
    	$data['arrPhoneType'] = $this->kol->getPhoneType();
    	$data['arrLocations'] = $this->kol->getAllLocationsByKolId($kolId);
    	$this->load->view('kols/add_update_phone',$data);
    }
    /**
     * Add/Update Staff for kol
     */
    function add_update_staffs($kolId = null,$type,$id) {
    	if($type=='edit'){
    		$tableName = 'staffs';
    		$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
    		$data['displayContent'] = true;
    	}else{
    		$data['displayContent'] = false;
    	}
    	$data['arrPhoneType'] = $this->kol->getPhoneType();
    	$data['arrStaffTitle'] = $this->kol->getStaffTitle(); 
    	$data['arrLocations'] = $this->kol->getAllLocationsByKolId($kolId);
    	$data['kolId'] = $kolId;
    	$this->load->view('kols/add_update_staff',$data);
    }
    /**
     * Add/Update Emails for kol
     */
    function add_update_emails($kolId = null,$type,$id) {
    	if($type=='edit'){
    		$tableName = 'emails';
    		$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
    		$data['displayContent'] = true;
    	}else{
    		$data['displayContent'] = false;
    	}
    	$data['kolId'] = $kolId;
    	$this->load->view('kols/add_update_emails',$data);
    }
    /**
     * Add/Update State Licence for kol
     */
    function add_update_licenses($kolId = null,$type,$id) {
    	if($type=='edit'){
    		$tableName = 'state_licenses';
    		$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
    		$countryId = $data['getSavedDetails']['country_id'];
    		$data['countryID'] = $countryId;
    		$data['arrCountries'] = $this->Country_helper->listCountries();
    		$data['arrStates'] = $this->Country_helper->getStatesByCountryId($countryId);
    		$data['displayContent'] = true;
    	}else{
    		$data['displayContent'] = false;
    		$data['arrCountries'] = $this->Country_helper->listCountries();
    		$first_key = key($data['arrCountries']);
    		$countryId = $data['arrCountries'][$first_key]['country_id'];
    		$data['countryID'] = $countryId;
    		$data['arrCountries'] = $this->Country_helper->listCountries();
    		$data['arrStates'] = array();
    	}    	
    	$data['kolId'] = $kolId;
    	$this->load->view('kols/add_update_licenses',$data);
    }
    
    /**
     * Add/Update Assign client for kol
     */
    function add_update_assign_client($kolId = null,$type,$id) {
    	$client_id = $this->session->userdata('client_id');
    	if($type=='edit'){
    		$tableName = 'user_kols';
    		$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
    		$data['displayContent'] = true;
    	}else{
    		$data['displayContent'] = false;
    	}
    	$data['arrClients'] = $this->kol->listUsers($client_id);
    	$data['arrClientsType'] = $this->kol->getAllClientsType();
    	$data['kolId'] = $kolId;
    	
    	$this->load->view('kols/add_update_assign_client',$data);
    }

    /**
     * Edit Location for kol
     */
    function edit_location($id = null) {
        $data['locationData'] = $this->kol->getLocationById($id);        
        $data['locationData'] = $data['locationData'][0];
        $data['locationData']['org_institution_name'] = $this->organization->getOrgNameByOrgId($data['locationData']['org_institution_id']);
        $data['arrOrgDetails'] = $this->organization->editOrganization($data['locationData']['org_institution_id']);
        $data['orgTypeId'] = $data['arrOrgDetails']['type_id'];
//            $data['staffData'] = $this->kol->getStaffs($id, 'location');
//            $data['phoneData'] = $this->kol->getPhones($id, 'location');
//            pr($data);
        $data['arrCountries'] = $this->Country_helper->listCountries();
        if ($data['locationData']['country_id'] != '' && $data['locationData']['country_id'] != 0)
            $data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['locationData']['country_id']);
        else{
            $first_key = key($data['arrCountries']);
            $countryId = $data['arrCountries'][$first_key]['country_id'];
            $data['arrStates'] = $this->Country_helper->getStatesByCountryId($countryId);
        }    
        if ($data['locationData']['state_id'] != '' && $data['locationData']['state_id'] != 0)
            $data['arrCities'] = $this->Country_helper->getCitiesByStateId($data['locationData']['state_id']);
        $data['arrTitles'] = $this->kol->getAllActiveTitles('all');
		$data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
        $this->load->view('kols/add_location', $data);
    }

    /**
     * Save Location for kol
     */
    function save_location() {
    	$arrLocationDataExist['kol_id'] = $this->input->post('kol_id');
    	$arrLocationDataExist['org_institution_id'] = $this->input->post('org_institution_id');
    	$isExist = $this->kol->getKolLocationByOrgInstId($arrLocationDataExist);
    	$dataType = 'User Added';
    	$client_id =$this->session->userdata('client_id');
    	if($client_id == INTERNAL_CLIENT_ID){
    	    $dataType = 'Aissel Analyst';
    	}
    	if(((!empty($this->input->post('id'))) && ($this->input->post('org_inst_selected') != $this->input->post('org_institution_id')) && ($isExist >0)) || (empty($this->input->post('id')) && ($isExist >0))) {
    		$data['status'] = true;
    		$data['duplicate_location'] = true;
	    }else{
	        $arrData['kol_id'] = $this->input->post('kol_id');
	        $org_id = $this->input->post('org_institution_id');
	        $private_practice = $this->input->post('organization');
	        $arrData['division'] = $this->input->post('department_loc');
	        $arrData['title'] = $this->input->post('title_loc');
	        if (empty($org_id)) {
	            $arrOrgData['address'] = trim($this->input->post('address1')) . " " . trim($this->input->post('address2'));
	            //            $arrKolData['status'] = trim($this->input->post('validation_status'));
	            $arrOrgData['status'] = 'Completed';
	
	            $city_id = trim($this->input->post('city_id'));
	            if (!empty($city_id)) {
	                $arrOrgData['city_id'] = trim($this->input->post('city_id'));
	            } else {
	                $arrOrgData['city_id'] = "";
	            }
	            $arrOrgData['name'] = trim($this->input->post('organization'));
	            $arrOrgData['state_id'] = trim($this->input->post('state_id'));
	            $arrOrgData['country_id'] = trim($this->input->post('country_id'));
	            $arrOrgData['postal_code'] = trim($this->input->post('postal_code'));
	            $arrOrgData['created_by'] = $this->loggedUserId;
	            $arrOrgData['created_on'] = date('Y-m-d H:i:s');
	            $arrOrgData['modified_by'] = $this->loggedUserId;
	            $arrOrgData['modified_on'] = date('Y-m-d H:i:s');
	            /* $arrOrgTypes = $this->organization->getMatchingOrgTypes("University/Hospital");
	             reset($arrOrgTypes);
	             $arrOrgData['type_id'] = key($arrOrgTypes);  */
	            $arrOrgData['type_id'] = trim($this->input->post('org_type'));
	            $arrOrgData['profile_type'] = 1;
	            $arrOrgData['status_otsuka'] = "ACTV";
	            $arrOrgData['status'] = "";
	            $org_id = $this->organization->saveOrganization($arrOrgData);
	            //Add Log activity
	            $formData = $_POST;
	            $formData = json_encode($formData);
	            $arrLogDetails = array(
	            		'module' => 'Organization',
	            		'type' => LOG_ADD,
	            		'description' => 'New Organization',
	            		'status' => 'success',
	            		'transaction_id' => $org_id,
	            		'transaction_table_id' => ORGANIZATIONS,
	            		'transaction_name' => "New Organization",
	            		'form_data' => $formData,
	            		'parent_object_id' => $org_id
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            log_user_activity(null,true);
	            //exit;
	            $orgData['org_id'] 			= $org_id;
	            $orgData['address1'] 			= trim($this->input->post('address1'));
	            $orgData['address2'] 			= trim($this->input->post('address2'));
	            $orgData['address_type'] 		= trim($this->input->post('address_type'));
	            $orgData['country_id'] 	= $this->input->post('country_id');
	            $orgData['state_id'] 	= $this->input->post('state_id');
	            $orgData['city_id'] 		= $this->input->post('city_id');
	            $orgData['postal_code'] 	= $this->input->post('postal_code');
	            $orgData['phone_number_primary'] 	= $this->input->post('phone_number_loc');
	            $orgData['phone_type_primary'] 	= $this->input->post('phone_type_loc');
	            $orgData['is_primary'] 			= 1;
	            $orgData['created_by'] 		= $this->loggedUserId;
	            $orgData['created_on'] 		= date('Y-m-d H:i:s');
	            $orgData['modified_by'] 		= $this->loggedUserId;
	            $orgData['modified_on'] 		= date('Y-m-d H:i:s');
	            $orgLocLasId = $this->organization->saveLocation($orgData);
	            if(isset($orgData['phone_type_primary']) && $orgData['phone_number_primary'] > 0){
	            	$orgPhone = array();
	            	$orgPhone['type'] = $this->input->post('phone_type_loc');
	            	$orgPhone['number'] = $this->input->post('phone_number_loc');
	            	$orgPhone['contact_type'] = 'organization';
	            	$orgPhone['contact'] = $org_id;
	            	$orgPhone['is_primary'] = 1;
	            	$orgPhone['location_id'] = $orgLocLasId;
	            	$orgPhone['created_by'] = $this->loggedUserId;
	            	$orgPhone['created_on'] = date('Y-m-d H:i:s');
	            	$lastPhoneId = $this->kol->savePhone($orgPhone);
	            }
	        }
	        $typeId = trim($this->input->post('org_type'));
	        if (empty($typeId)) {
	        	$arrOrgType = array();
	        	$arrOrgType['id'] = $org_id;
	        	$arrOrgType['type_id'] = 7;
	        	$this->organization->updateOrgTypeForOrganization($arrOrgType);
	        }else{
	        	$arrOrgType = array();
	        	$arrOrgType['id'] = $org_id;
	        	$arrOrgType['type_id'] = $typeId;
	        	$this->organization->updateOrgTypeForOrganization($arrOrgType);
	        }
	        $arrData['org_institution_id'] = $org_id;
	        $arrData['address1'] = trim($this->input->post('address1'));
	        $arrData['address2'] = trim($this->input->post('address2'));
	        $arrData['address3'] = trim($this->input->post('address3'));
	        if (!empty($private_practice))
	            $arrData['private_practice'] = $this->input->post('organization');
	        else
	             $arrData['private_practice'] == '';
	        $arrData['validation_status'] = trim($this->input->post('validation_status'));
	        $arrData['address_type'] = trim($this->input->post('address_type'));
	        $arrData['country_id'] = $this->input->post('country_id');
	        $arrData['state_id'] = $this->input->post('state_id');
	        $genericId = $this->common_helpers->getGenericId("Location Form");
	        $arrData['generic_id'] = $genericId;
	
	        if ($arrData['state_id'] == '')
	            unset($arrData['state_id']);
	        $city_id = $this->input->post('city_id');
	        if (!empty($city_id)) {
	        	if(is_numeric($city_id)){
	        		$arrOrgData['city_id'] = trim($this->input->post('city_id'));
	        		$arrData['city_id'] = $arrOrgData['city_id'];
	        	}else{
	        		$cityId = $this->kol->checkCityIfExistElseAdd($city_id,trim($this->input->post('state_id')),trim($this->input->post('country_id')));
	        		$arrData['city_id'] = $cityId;
	        	}
	        } else {
	        	$arrData['city_id'] = "";
	        }
	        $arrData['postal_code'] = $this->input->post('postal_code');
	//            $arrData['postal_extension'] 	= $this->input->post('postal_extension');
	//            $arrData['postal_city'] 	= $this->input->post('postal_city');
	        $arrData['phone_type'] = $this->input->post('phone_type_loc');
	        $arrData['phone_number'] = $this->input->post('phone_number_loc');
	        if ($this->input->post('is_primary') == "1")
	            $arrData['is_primary'] = $this->input->post('is_primary');
	        $arrData['modified_by'] = $this->loggedUserId;
	        $arrData['modified_on'] = date('Y-m-d H:i:s');
	        $arrData['data_type_indicator'] = $dataType;
	        $id = $this->input->post('id');
	        if (!empty($id)) {
	            $arrData['id'] = $this->input->post('id');
	
	            $lastId = $this->kol->saveLocation($arrData);
	        $formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'module' => 'kols',
	                'type' => LOG_ADD,
	                'description' => 'Update Location',
	                'status' => 'success',
	                'transaction_id' => $arrData['id'],
	            	'transaction_table_id' => KOL_LOCATIONS,
	                'transaction_name' => "Update Location",
	            	'form_data' => $formData,
	                'parent_object_id' =>  $arrData['kol_id']
	            );
	
	       	
	
			$this->config->set_item('log_details', $arrLogDetails);
	                log_user_activity(null,true);
	//                pr($this->db->last_query());
	//                exit();
	            if ($lastId) {
	                    
	                $data['status'] = true;
	            } else {
	                $data['status'] = false;
	            }
	            $lastId = $arrData['id'];
	//                $this->kol->deleteStaff("", $lastId);
	//                $this->kol->deletePhone("", $lastId);
	//                $this->kol->deleteLocStaff($id);
	//                $this->kol->deleteLocPhone($id);
	        } else {
	            $arrData['created_by'] = $this->loggedUserId;
	            $arrData['created_on'] = date('Y-m-d H:i:s');
	            $lastId = $this->kol->saveLocation($arrData);
	//                $this->kol->deleteLocStaff($lastId);
	//                $this->kol->deleteLocPhone($lastId);
	//                pr($this->db->last_query());
	//                exit();
	            if ($lastId) {
	                    $formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'module' => 'kols',
	                'type' => LOG_ADD,
	                'description' => 'Save Location',
	                'status' => 'success',
	                'transaction_id' =>  $lastId,
	            	'transaction_table_id' => KOL_LOCATIONS,
	                'transaction_name' => "Save Location",
	            	'form_data' => $formData,
	                'parent_object_id' =>   $arrData['kol_id']
	            );
	
	       	
	
			$this->config->set_item('log_details', $arrLogDetails);
	                log_user_activity(null,true);
	                $data['status'] = true;
	                $data['id'] = $lastId;
	            } else {
	                $data['status'] = false;
	            }
	        }
	
	        //if is primary then update the kols table address information
	        if ($arrData['is_primary'] == '1') {
	            $arrKolDetails = array();
	            $arrKolDetails['id'] = $arrData['kol_id'];
	            $arrKolDetails['org_id'] = $arrData['org_institution_id'];
	            $arrKolDetails['address1'] = $arrData['address1'];
	            $arrKolDetails['address2'] = $arrData['address2'];
	            $arrKolDetails['country_id'] = $arrData['country_id'];
	            $arrKolDetails['state_id'] = $arrData['state_id'];
	            $arrKolDetails['city_id'] = $arrData['city_id'];
	            $arrKolDetails['postal_code'] = $arrData['postal_code'];
	            $arrKolDetails['modified_by'] = $this->loggedUserId;
	            $arrKolDetails['modified_on'] = date('Y-m-d H:i:s');
	            $arrKolDetails['division'] = $arrData['division'];
	            $arrKolDetails['title'] =$arrData['title'];
	            $this->kol->updateKol($arrKolDetails);
	                $formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'module' => 'kols',
	                'type' => LOG_ADD,
	                'description' => 'Update Location',
	                'status' => 'success',
	                'transaction_id' =>  $arrKolDetails['id'],
	            	'transaction_table_id' => KOL_LOCATIONS,
	                'transaction_name' => "Update Location",
	            	'form_data' => $formData,
	                'parent_object_id' =>  $arrKolDetails['id']
	            );
	
	       	
	
			$this->config->set_item('log_details', $arrLogDetails);
	                log_user_activity(null,true);
	          $arrKolDetails['org_type']  =  $arrOrgData['type_id'];
	          $arrKolDetails['org_name']  =  $this->input->post('organization');
	          $arrKolDetails['address_type']  =  $arrData['address_type'];
	          $data['details'] = $arrKolDetails;
	        }else{
	        	$data['details'] = '';
	        }
	        /*
	          $arrStaffTitles = $this->input->post('staff_title');
	          $arrStaffNames = $this->input->post('staff_name');
	          $arrStaffPhones = $this->input->post('staff_phone');
	          $i = 0;
	          foreach($arrStaffTitles as $staff_title){
	          if($staff_title != "") {
	          $arrStaffData = array('title' => $staff_title,
	          'name' => $arrStaffNames[$i],
	          'phone_number' => $arrStaffPhones[$i],
	          //                    if($arrData['kol_id'] != "") {
	          'contact_type' => "location",
	          'contact' => $this->input->post('kol_id'),
	          'location_id' => $lastId,
	          //                    }
	          'created_by' => $this->loggedUserId,
	          'created_on' => date('Y-m-d H:i:s'),
	          'modified_by' => $this->loggedUserId,
	          'modified_on' => date('Y-m-d H:i:s'));
	          $lastStaffId = $this->kol->saveStaff($arrStaffData);
	          }
	          $i++;
	          }
	
	
	          $arrPhoneTypes = $this->input->post('phone_type');
	          $arrPhoneNumbers = $this->input->post('phone_number');
	          $i = 0;
	          foreach($arrPhoneTypes as $phone_type){
	          if($phone_type != "") {
	          $arrPhoneData = array('type' => $phone_type,
	          'number' => $arrPhoneNumbers[$i],
	          //                    if($arrData['kol_id'] != "") {
	          'contact_type' => "location",
	          'contact' => $this->input->post('kol_id'),
	          'location_id' => $lastId,
	          //                    }
	          'created_by' => $this->loggedUserId,
	          'created_on' => date('Y-m-d H:i:s'),
	          'modified_by' => $this->loggedUserId,
	          'modified_on' => date('Y-m-d H:i:s'));
	          $lastPhoneId = $this->kol->savePhone($arrPhoneData);
	          }
	          $i++;
	          }
	         */
	    }
        echo json_encode($data);
    }

    /**
     * Delete location of kol
     */
    function delete_location($id = null,$kolId) {
    	$msg = '';
    	$rowPhoneData = $this->db->get_where('phone_numbers', array('contact' => $kolId,'location_id' => $id))->result();
    	$rowStaffData = $this->db->get_where('staffs', array('contact' => $kolId,'location_id' => $id))->result();
    	if(sizeof($rowPhoneData) > 0 && sizeof($rowStaffData) > 0){
    		$msg = 'Kindly delete associated records from Phone/Staff Section';
    	}else if(sizeof($rowPhoneData) > 0){
    		$msg = 'Kindly delete associated record from Phone Section';
    	}else if(sizeof($rowStaffData) > 0){
    		$msg = 'Kindly delete associated record from Staff Section';
    	}else{
	        $this->kol->deleteStaff("", $id, $kolId);
	        $this->kol->deletePhone("", $id, $kolId);
        	$this->kol->deleteLocation($id);
    	}
    	echo json_encode($msg);
    }

    function save_staff($id = null) {
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $arrData['title'] = trim($this->input->post('staff_title'));
        $arrData['name'] = trim($this->input->post('staff_name'));
        $arrData['phone_number'] = trim($this->input->post('staff_phone'));
        $arrData['phone_type'] = trim($this->input->post('phone_type'));
        $arrData['email'] = trim($this->input->post('email'));
        $arrData['contact_type'] = trim($this->input->post('contact_type'));
        $arrData['contact'] = trim($this->input->post('contact'));
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');
        $arrData['location_id'] = trim($this->input->post('staff_location'));
        $arrData['data_type_indicator'] = $dataType;
        $logtype=LOG_ADD;$transaction_name="New Staff";
        if ($id != "" || $id != null) {
            $data['status'] = $this->kol->updateStaff($id, $arrData);
            $logtype=LOG_UPDATE;$transaction_name="Update Staff";
        } else {
            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');

            $lastStaffId = $this->kol->saveStaff($arrData);
            if ($lastStaffId) {
                $data['status'] = true;
                $data['id'] = $lastStaffId;
            } else {
                $data['status'] = false;
            }
        }
        if($data['status']){
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => $logtype,
                    'description' => $transaction_name,
                    'status' => 'success',
                    'transaction_id' => $lastStaffId,
                    'transaction_table_id' => STAFFS,
                    'transaction_name' => $transaction_name,
                    'form_data' => json_encode($arrData),
                    'parent_object_id' => $arrData['contact'],
            );
             
            $this->config->set_item('log_details', $arrLogDetails);
        }
        echo json_encode($data);
    }
    
    
    function save_client_assign($id = null) {
    	$transaction_name = '';
    	$logtype='';
    	$arrData['user_id'] = trim($this->input->post('client'));
    	$arrData['kol_id'] = trim($this->input->post('kol_id'));
    	$arrData['type'] = trim($this->input->post('client_type'));
    	if ($id != "" || $id != null) {
    	    $arrData['modified_by'] = $this->loggedUserId;
    	    $arrData['modified_on'] = date('Y-m-d H:i:s');
    		$data['status'] = $this->kol->updateAssignClient($id, $arrData);
    		$logtype=LOG_UPDATE;$transaction_name="Update Assign Client";
    	} else {
    	    $arrData['created_by'] = $this->loggedUserId;
    	    $arrData['created_on'] = date('Y-m-d H:i:s');
    		$lastAssignId = $this->kol->saveAssignClient($arrData);
    		if ($lastAssignId) {
    			$data['status'] = true;
    			$data['id'] = $lastAssignId;
    			$logtype=LOG_ADD;$transaction_name="New Client Assigned";
    		} else {
    			$data['status'] = false;
    		}
    	}
    	if($data['status']){
    		$arrLogDetails = array(
    				'module' => 'kols',
    				'type' => $logtype,
    				'description' => $transaction_name,
    				'status' => 'success',
    				'transaction_id' => $lastAssignId,
    				'transaction_table_id' => KOL_USER_CONATACT_TYPE,
    				'transaction_name' => $transaction_name,
    				'form_data' => json_encode($arrData),
    				'parent_object_id' => $arrData['kol_id'],
    		);
    		 
    		$this->config->set_item('log_details', $arrLogDetails);
    	}
    	echo json_encode($data);
    }
    
 

    function delete_staff($id = null) {
        $this->kol->deleteStaff($id, "");
        $data = true;
        echo json_encode($data);
    }

    function delete_phone($id = null) {
    	$data = true;
        $this->kol->deletePhone($id, "");
        echo json_encode($data);
    }

    function delete_email($id = null) {
    	$data = true;
        $this->kol->deleteEmail($id);
        echo json_encode($data);
    }

    function delete_state_license($id = null) {
        $this->kol->deleteStateLicense($id);
        $data = true;
        echo json_encode($data);
    }
    function delete_assign($id = null,$kolId) {
    	$this->kol->deleteAssignUser($id);
    	$data = true;
    	echo json_encode($data);
    }
    
    function delete_ol_key_status($id = null) {
        $this->kol->deleteOLKeyStatus($id);
    }

    function save_phone($id = null) {
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $arrData['type'] = trim($this->input->post('phone_type'));
        $arrData['number'] = trim($this->input->post('phone_number'));
        $arrData['contact_type'] = trim($this->input->post('contact_type'));
        $arrData['contact'] = trim($this->input->post('contact'));
        $arrData['is_primary'] = (trim($this->input->post('phone_is_primary')) == "on") ? "1" : "0";
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');
        $arrData['location_id'] = trim($this->input->post('phone_location'));
        $arrData['data_type_indicator'] = $dataType;
        
		if($arrData['is_primary'] == 1){
			$data['details'] = $arrData;
		}else{
			$data['details'] = '';
		}
		$logtype=LOG_ADD;$transaction_name="New Phone";
        if ($id != "" || $id != null) {
            $data['status'] = $this->kol->updatePhone($id, $arrData);
            $logtype=LOG_UPDATE;$transaction_name="Update Phone";
        } else {
            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');

            $lastPhoneId = $this->kol->savePhone($arrData);
            if ($lastPhoneId) {
                $data['status'] = true;
                $data['id'] = $lastPhoneId;
            } else {
                $data['status'] = false;
            }
        }
        if($data['status']){
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => $logtype,
                    'description' => $transaction_name,
                    'status' => 'success',
                    'transaction_id' => $lastPhoneId,
                    'transaction_table_id' => PHONE_NUMBERS,
                    'transaction_name' => $transaction_name,
                    'form_data' => json_encode($arrData),
                    'parent_object_id' => $arrData['contact'],
            );
             
            $this->config->set_item('log_details', $arrLogDetails);
        }
        echo json_encode($data);
    }

    function save_email($id = null) {
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $data=array();
        $arrData['type'] = trim($this->input->post('email_type'));
        $arrData['email'] = trim($this->input->post('email'));
        if (trim($this->input->post('email_is_primary')) == "on"){
            $arrData['is_primary'] = 1;
            $data['details'] = $arrData['email'];
        }else{
            $arrData['is_primary'] = 0;
            $data['details'] = '';
        }
        $arrData['contact'] = trim($this->input->post('contact'));
        $arrData['contact_type'] = trim($this->input->post('contact_type'));
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');
        $arrData['data_type_indicator'] = $dataType;
        $logtype=LOG_ADD;$transaction_name="New Email";
        if ($id != "" || $id != null) {            
            $data['id'] = $this->kol->updateEmail($id, $arrData);
            $data['status'] = true;            
            $logtype=LOG_UPDATE;$transaction_name="Update Email";
        } else {
            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');

            $lastEmailId = $this->kol->saveEmail($arrData);
            if ($lastEmailId) {
                $data['status'] = true;
                $data['id'] = $lastEmailId;
            } else {
                $data['status'] = false;
            }
        }
        if($data['status']){
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => $logtype,
                    'description' => $transaction_name,
                    'status' => 'success',
                    'transaction_id' => $lastEmailId,
                    'transaction_table_id' => EMAILS,
                    'transaction_name' => $transaction_name,
                    'form_data' => json_encode($arrData),
                    'parent_object_id' => $arrData['contact'],
            );

            $this->config->set_item('log_details', $arrLogDetails);
        }
        echo json_encode($data);
    }

    function save_state_license($id = null) {
        $dataType = 'User Added';
        $client_id =$this->session->userdata('client_id');
        if($client_id == INTERNAL_CLIENT_ID){
            $dataType = 'Aissel Analyst';
        }
        $arrData['state_license'] = trim($this->input->post('state_license_number'));
        $arrData['region'] = trim($this->input->post('state_id'));
        $arrData['country_id'] = trim($this->input->post('country_id'));
        $arrData['contact'] = trim($this->input->post('contact'));
        if (trim($this->input->post('license_is_primary')) == "on")
            $arrData['is_primary'] = 1;
        else
            $arrData['is_primary'] = 0;
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');
        $arrData['data_type_indicator'] = $dataType;
        $logtype=LOG_ADD;$transaction_name="New License";
        if ($id != "" || $id != null) {
            $data['status'] = $this->kol->updateStateLicense($id, $arrData);
            $logtype=LOG_UPDATE;$transaction_name="Update License";
        } else {
            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');

            $lastLicenseId = $this->kol->saveStateLicense($arrData);
            if ($lastLicenseId) {
                $data['status'] = true;
                $data['id'] = $lastLicenseId;
            } else {
                $data['status'] = false;
            }
        }
        if($data['status']){
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => $logtype,
                    'description' => $transaction_name,
                    'status' => 'success',
                    'transaction_id' => $lastLicenseId,
                    'transaction_table_id' => STATE_LICENSES,
                    'transaction_name' => $transaction_name,
                    'form_data' => json_encode($arrData),
                    'parent_object_id' => $arrData['contact'],
            );

            $this->config->set_item('log_details', $arrLogDetails);
        }
        echo json_encode($data);
    }

    function save_key_status($id = null) {
        $arrData['therapeutic_class'] = trim($this->input->post('therapeutic_class'));
        $arrData['key_status'] = trim($this->input->post('key_status'));
        $arrData['product'] = trim($this->input->post('product'));
        $arrData['alignment'] = trim($this->input->post('alignment'));
        $arrData['contact'] = trim($this->input->post('contact'));
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');

        if ($id != "" || $id != null) {
            $data['status'] = $this->kol->updateOLKeyStatus($id, $arrData);
        } else {
            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');

            $lastStatusId = $this->kol->saveOLKeyStatus($arrData);
            if ($lastStatusId) {
                $data['status'] = true;
                $data['id'] = $lastStatusId;
            } else {
                $data['status'] = false;
            }
        }
        echo json_encode($data);
    }

    function add_ol() {      
        $data['arrCountries'] = $this->Country_helper->listCountries();
        $data['arrDegrees'] = $this->kol->getAllActiveDegrees();
        $data['arrTitles'] = $this->kol->getAllActiveTitles('all');
        $data['arrProducts'] = $this->common_helpers->getUserProducts($this->loggedUserId);
        $data['arrAdditionalRoles'] = $this->kol->getAllActiveAdditionalRoles();
        $data['arrProfessionalSuffixes'] = $this->kol->getAllActiveProfessionalSuffixes();
        $data['arrStates'] = $this->Country_helper->getStatesByCountryId(254);
        $data['arrSpecialties'] = $this->Specialty->getAllSpecialties('all');
//        $data['arrSepakerProducts']=$this->get_speaker_products();
        $data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
        $data['arrSepakerProducts']=$this->common_helpers->getUserProducts($this->loggedUserId);
        $data['contentPage'] = 'kols/add_ol';
//            pr($data);
        $this->load->view('layouts/client_view', $data);
    }

    function edit_ol($kolId = null) {
        $data['arrDegrees'] = $this->kol->getAllActiveDegrees();
        $data['arrTitles'] = $this->kol->getAllActiveTitles('all');
        $data['arrProducts'] = $this->common_helpers->getUserProducts($this->loggedUserId);
        $data['arrkolProducts'] = $this->kol->getKolProducts($kolId);
        $data['arrkolSubSpecialty'] = $this->Specialty->getKolSubSpecialty($kolId);
//        $data['arrSepakerProducts']=$this->get_speaker_products();
        $data['arrSepakerProducts']=$this->common_helpers->getUserProducts($this->loggedUserId);
        $data['arrSelectedSepakerProducts'] = $this->kol->getKolSeakerProducts($kolId);
        $data['arrAdditionalRoles'] = $this->kol->getAllActiveAdditionalRoles();
        $temp = $this->kol->getKolInfo($kolId);
        $data['arrProfessionalSuffixes'] = $this->kol->getAllActiveProfessionalSuffixes();
        $selectedSuffixes = explode(',',$temp[0]['suffix']);
        $data['selectedSuffixes'] = array_map('trim',$selectedSuffixes);
//         pr($data['selectedSuffixes']);       
        $data['arrKolData'] = $temp[0];
        $temp = $this->kol->getKolPrimaryLocation($kolId);
        $data['arrLocationData'] = $temp[0];
        
        $arr = $this->kol->getKolPrimaryPhoneDetails($data['arrLocationData']['id']);
        if (isset($arr['id'])) {
            $data['arrLocationData']['phone_number'] = $arr['number'];
            $data['arrLocationData']['phone_type'] = $arr['type'];
        } else {
            $data['arrLocationData']['phone_number'] = '';
            $data['arrLocationData']['phone_type'] = '';
        }
        $data['arrLocationData']['org_institution_name'] = $this->organization->getOrgNameByOrgId($data['arrLocationData']['org_institution_id']);
        $data['arrOrgDetails'] = $this->organization->editOrganization($data['arrLocationData']['org_institution_id']);
        $data['orgTypeId'] = $data['arrOrgDetails']['type_id'];
        
        $temp = $this->kol->getContactRestrictions($kolId);
        $data['arrContactData'] = $temp[0];
//                    pr($data);
        $data['arrCountries'] = $this->Country_helper->listCountries();
        $data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['arrKolData']['country_id']);
        if ($data['arrKolData']['state_id'] != '' && $data['arrKolData']['state_id'] != 0)
            $data['arrCities'] = $this->Country_helper->getCitiesByStateId($data['arrKolData']['state_id']);

        $data['arrSpecialties'] = $this->Specialty->getAllSpecialties('all');
        $data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
        $data['contentPage'] = 'kols/add_ol';
        $this->load->view('layouts/client_view', $data);
    }

    function save_ol($replaceFlag = 0) {
        $kol_id = $this->input->post('kol_id');
        $arrKolData = array();
        //$arrKolData['fma_speciality_id'] = trim($this->input->post('fma_specialty_id'));
        $arrKolData['fma_speciality_id'] = '';
        $arrKolData['npi_num'] = trim($this->input->post('npi_num'));
        $arrProducts = $this->input->post('products');
        $suffix = implode(',',$this->input->post('prof_suffix'));
        $arrSpeakerProducts = $this->input->post('speaker_products');
        $arrSubSpecialty = $this->input->post('sub_specialty');
        $arrKolData['additional_role_id'] = trim($this->input->post('additional_role_id'));
        $arrKolData['is_speaker'] = $this->input->post('is_speaker');
        $arrKolData['degree_id'] = trim($this->input->post('degree_id'));
        $arrKolData['first_name'] = trim($this->input->post('first_name'));
        $arrKolData['middle_name'] = trim($this->input->post('middle_name'));
        $arrKolData['primary_phone'] = trim($this->input->post('phone_number_loc'));
        $arrKolData['external_profile_id'] = trim($this->input->post('crm_id'));
        $arrKolData['last_name'] = trim($this->input->post('last_name'));
        $arrKolData['suffix'] = $suffix;
        $arrKolData['specialty'] = trim($this->input->post('specialty'));
        $org_id = trim($this->input->post('org_institution_id'));
        $is_private_practice = trim($this->input->post('private_practice')); 
        $city_id = trim($this->input->post('city_id'));
        
        //if (empty($org_id) && isset($is_private_practice) && !empty($is_private_practice)) {
        if (empty($org_id)) {
        	$arrOrgData = array();
            $arrOrgData['address'] = trim($this->input->post('address1')) . " " . trim($this->input->post('address2'));
            //            $arrKolData['status'] = trim($this->input->post('validation_status'));
            $arrOrgData['status'] = '';

            $city_id = trim($this->input->post('city_id'));
            if (!empty($city_id)) {
                if(is_numeric($city_id)){
                    $arrOrgData['city_id'] = trim($this->input->post('city_id'));
                    $city_id = $arrOrgData['city_id'];
                }else{
                   $city_id = $this->kol->checkCityIfExistElseAdd($city_id,trim($this->input->post('state_id')),trim($this->input->post('country_id')));
                   $arrOrgData['city_id'] = $city_id;
                }
            } else {
                $arrOrgData['city_id'] = "";
            }
            $arrOrgData['name'] = trim($this->input->post('organization'));
            $arrOrgData['state_id'] = trim($this->input->post('state_id'));
            $arrOrgData['country_id'] = trim($this->input->post('country_id'));
            $arrOrgData['postal_code'] = trim($this->input->post('postal_code'));
            $arrOrgData['created_by'] = $this->loggedUserId;
            $arrOrgData['created_on'] = date('Y-m-d H:i:s');
            $arrOrgData['modified_by'] = $this->loggedUserId;
            $arrOrgData['modified_on'] = date('Y-m-d H:i:s');
            /* $arrOrgTypes = $this->organization->getMatchingOrgTypes("University/Hospital");
            reset($arrOrgTypes);
            $arrOrgData['type_id'] = key($arrOrgTypes);  */
            $arrOrgData['type_id'] = trim($this->input->post('org_type'));
            $arrOrgData['profile_type'] = 1;
            $arrOrgData['status_otsuka'] = "ACTV";
            $arrOrgData['status'] = "Completed";           
            $org_id = $this->organization->saveOrganization($arrOrgData);
            //Add Log activity
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
            		'module' => 'Organization',
            		'type' => LOG_ADD,
            		'description' => 'New Organization',
            		'status' => 'success',
            		'transaction_id' => $org_id,
            		'transaction_table_id' => ORGANIZATIONS,
            		'transaction_name' => "New Organization",
            		'form_data' => $formData,
            		'parent_object_id' => $org_id
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null,true);
            //exit;
            $orgData['org_id'] 			= $org_id;
            $orgData['address1'] 			= trim($this->input->post('address1'));
            $orgData['address2'] 			= trim($this->input->post('address2'));
            $orgData['address_type'] 		= trim($this->input->post('address_type'));
            $orgData['country_id'] 	= $this->input->post('country_id');
            $orgData['state_id'] 	= $this->input->post('state_id');
            $orgData['city_id'] 		= $this->input->post('city_id');
            $orgData['postal_code'] 	= $this->input->post('postal_code');
            $orgData['phone_number_primary'] 	= $this->input->post('phone_number_loc');
            $orgData['phone_type_primary'] 	= $this->input->post('phone_type_loc');
            $orgData['is_primary'] 			= 1;
            $orgData['created_by'] 		= $this->loggedUserId;
            $orgData['created_on'] 		= date('Y-m-d H:i:s');
            $orgData['modified_by'] 		= $this->loggedUserId;
            $orgData['modified_on'] 		= date('Y-m-d H:i:s');
            $orgLocLasId = $this->organization->saveLocation($orgData);
            if(isset($orgData['phone_type_primary']) && $orgData['phone_number_primary'] > 0){
            	$orgPhone = array();
            	$orgPhone['type'] = $this->input->post('phone_type_loc');
            	$orgPhone['number'] = $this->input->post('phone_number_loc');
            	$orgPhone['contact_type'] = 'organization';
            	$orgPhone['contact'] = $org_id;
            	$orgPhone['is_primary'] = 1;
            	$orgPhone['location_id'] = $orgLocLasId;
            	$orgPhone['created_by'] = $this->loggedUserId;
            	$orgPhone['created_on'] = date('Y-m-d H:i:s');
            	$lastPhoneId = $this->kol->savePhone($orgPhone);
            }
        }
        $typeId = trim($this->input->post('org_type'));
        if (empty($typeId)) {
        	$arrOrgType = array();
        	$arrOrgType['id'] = $org_id;
        	$arrOrgType['type_id'] = 7;
        	$this->organization->updateOrgTypeForOrganization($arrOrgType);
        }else{
        	$arrOrgType = array();
        	$arrOrgType['id'] = $org_id;
        	$arrOrgType['type_id'] = $typeId;
        	$this->organization->updateOrgTypeForOrganization($arrOrgType);
        }
        $arrKolData['org_id'] = $org_id;       
        $arrKolData['title'] = trim($this->input->post('title'));
        $arrKolData['primary_email'] = trim($this->input->post('email'));
        $arrKolData['address1'] = trim($this->input->post('address1'));
        $arrKolData['address2'] = trim($this->input->post('address2'));
        if (!empty($city_id)) {
            if(is_numeric($city_id)){
                $arrKolData['city_id'] = trim($this->input->post('city_id'));
                $city_id=$arrKolData['city_id'];
            }else{
               $city_id = $this->kol->checkCityIfExistElseAdd($city_id,trim($this->input->post('state_id')),trim($this->input->post('country_id')));
               $arrKolData['city_id'] = $city_id;
            }
        }
        $arrKolData['state_id'] = trim($this->input->post('state_id'));
        $arrKolData['country_id'] = trim($this->input->post('country_id'));
        $arrKolData['postal_code'] = trim($this->input->post('postal_code'));
        
        if(empty($kol_id)){
        	$arrKolData['created_by'] = $this->loggedUserId;
        	$arrKolData['created_on'] = date('Y-m-d H:i:s');
        	$arrKolData['modified_by'] = '';
        	$arrKolData['modified_on'] = '';
        }else{
        	$arrKolData['modified_by'] = $this->loggedUserId;
        	$arrKolData['modified_on'] = date('Y-m-d H:i:s');
        }
        
//            $arrKolData['status'] = trim($this->input->post('validation_status'));
        $arrKolData['status'] = 'Completed';
        if($this->input->post('profile_type')==''){
        	//$arrKolData['profile_type'] = 'Basic';
            $arrKolData['profile_type'] = USER_ADDED;
        }else{
        	$arrKolData['profile_type'] = trim($this->input->post('profile_type'));
        }
       
        $arrKolData['patients_range'] = trim($this->input->post('patients_range'));
        if ($this->input->post('compliance_flag') == "on")
            $arrKolData['compliance_flag'] = 1;
        else
            $arrKolData['compliance_flag'] = 0;
        if ($this->input->post('is_kol') == "on")
            $arrKolData['is_kol'] = 1;
        else
            $arrKolData['is_kol'] = 0;

//            pr($arrKolData);
//            exit();
        if (!empty($kol_id)) {
            $this->kol->deleteKolProducts($kol_id);
            $this->kol->insertKolProducts($kol_id, $arrProducts);
            $this->kol->deleteKolSubSpecialty($kol_id);
            $this->kol->insertKolSubSpecialty($kol_id, $arrSubSpecialty);
            $this->kol->deleteKolSpeakerProducts($kol_id);
            $this->kol->insertKolSpakerProducts($kol_id, $arrSpeakerProducts);
            $this->kol->updateKolInfo($arrKolData, $kol_id);
            
            if($arrKolData['specialty'] > 0){
            	$arrData=array();
            	$arrData['kol_id']=$kol_id;
            	$arrData['kol_sub_specialty_id']=$arrKolData['specialty'];
            	$arrData['priority'] = 1;
            	$this->kol->saveKolSpecialty($arrData);
            }
            $kolId = $kol_id;
        } else {
            $fname = $arrKolData['first_name'];
            $mname = $arrKolData['middle_name'];
            $lname = $arrKolData['last_name'];
            $specialty = $arrKolData['specialty'];
            /* if(!$this->check_duplicate_kols($fname, $mname, $lname, $specialty)) {
              $kolId = $this->kol->saveKolInfo($arrKolData);
              $this->kol->insertKolProducts($kolId, $arrProducts);
              } else if($replaceFlag == 1 && $this->check_duplicate_kols($fname, $mname, $lname, $specialty)) {
              $kolId = $this->kol->saveKolInfo($arrKolData);
              $this->kol->insertKolProducts($kolId, $arrProducts);
              } else {
              $data['status'] = false;
              $data['is_duplicate'] = true;
              echo json_encode($data);
              exit();
              } */
            $arrKolData['is_duplicate_case'] = $this->input->post('is_duplicate_case');
            
            $kolId = $this->kol->saveKolInfo($arrKolData);   
            if($arrKolData['specialty'] > 0){
            	$arrData=array();
            	$arrData['kol_id']=$kolId;
            	$arrData['kol_sub_specialty_id']=$arrKolData['specialty'];
            	$arrData['priority'] = 1;
            	$this->kol->saveKolSpecialty($arrData);
            }
            //Assign User
            $arrData = array();
            $arrData['user_id'] = $this->loggedUserId;
            $arrData['kol_id'] = $kolId;
            $arrData['type'] = 1;
            $saveAssignId = $this->kol->saveAssignClient($arrData);
            
//        pr($arrLogDetails);
        	$this->config->set_item('log_details', $arrLogDetails);
       
       		 log_user_activity($arrLogDetails, true);
    
            $this->kol->insertKolProducts($kolId, $arrProducts);
            
            $this->kol->insertKolSpakerProducts($kolId, $arrSpeakerProducts);
            
            $this->kol->insertKolSubSpecialty($kolId, $arrSubSpecialty);
        }

        if ($kolId) {
        	$arrLocationData = array();
        	$arrContactData = array();
            if ($this->input->post('visit') == "on")
                $arrContactData['visit'] = 1;
            else
                $arrContactData['visit'] = 0;
            
            if ($this->input->post('call') == "on")
                $arrContactData['call'] = 1;
            else
                $arrContactData['call'] = 0;
            
            if ($this->input->post('fax') == "on")
                $arrContactData['fax'] = 1;
            else
                $arrContactData['fax'] = 0;
            
            if ($this->input->post('mail') == "on")
                $arrContactData['mail'] = 1;
            else
                $arrContactData['mail'] = 0;
            
            if ($this->input->post('cr_text') == "on")
                $arrContactData['text'] = 1;
            else
                $arrContactData['text'] = 0;
            
            if ($this->input->post('cr_email') == "on")
                $arrContactData['email'] = 1;
            else
                $arrContactData['email'] = 0;
                	
            if ($this->input->post('cr_video_call') == "on")
                $arrContactData['video_call'] = 1;
            else
                $arrContactData['video_call'] = 0;
            
            $arrContactData['contact_type'] = 'kol';

            if (!empty($kol_id)) {
                $lastId = $this->kol->updateContactRestrictions($arrContactData, $kol_id);
                $arrContRests = $this->kol->getContactRestrictions($kol_id);
                if(is_array($arrContRests) && count($arrContRests) > 0){
                }else{
                	$arrContactData['contact'] = $kolId;
                	$lastId = $this->kol->saveContactRestrictions($arrContactData);
                }
            } else {
                $arrContactData['contact'] = $kolId;
                $lastId = $this->kol->saveContactRestrictions($arrContactData);
            }
            $arrLocationData['org_institution_id'] = $arrKolData['org_id'];
            $arrLocationData['address1'] = trim($this->input->post('address1'));
            $arrLocationData['address2'] = trim($this->input->post('address2'));
            $arrLocationData['address3'] = trim($this->input->post('address3'));
            //$arrLocationData['validation_status'] = trim($this->input->post('validation_status'));
            $arrLocationData['validation_status'] = '';
            $arrLocationData['address_type'] = trim($this->input->post('address_type'));
            $arrLocationData['country_id'] = $this->input->post('country_id');
            $arrLocationData['state_id'] = $this->input->post('state_id');
            if ($arrLocationData['state_id'] == '')
                unset($arrLocationData['state_id']);
            $arrLocationData['city_id'] = $city_id;
            if ($arrLocationData['city_id'] == '')
                unset($arrLocationData['city_id']);
            $arrLocationData['postal_code'] = $this->input->post('postal_code');
//                $arrLocationData['postal_extension'] 	= $this->input->post('postal_extension');
//                $arrLocationData['postal_city'] 	= $this->input->post('postal_city');
            $arrLocationData['phone_type'] = $this->input->post('phone_type_loc');
            $arrLocationData['phone_number'] = $this->input->post('phone_number_loc');
            if (empty($is_private_practice)) {
                
               $arrLocationData['private_practice'] == '';
            } else {
                 $arrLocationData['private_practice'] = $this->input->post('organization');
                 
            }
//               
            //if($this->input->post('is_primary'))
            $arrLocationData['is_primary'] = 1;
            $arrLocationData['division'] = $this->input->post('department_loc');
            $arrLocationData['title'] = $arrKolData['title'];
            //else
            //$arrLocationData['is_primary'] 	= 0;
            $arrLocationData['created_by'] = $this->loggedUserId;
            $arrLocationData['created_on'] = date('Y-m-d H:i:s');
            $arrLocationData['modified_by'] = $this->loggedUserId;
            $arrLocationData['modified_on'] = date('Y-m-d H:i:s');
            $lastInsertedLocationId = '';
            $isPresentOrg = '';
            $updatedId = '';
            if (!empty($kol_id)) {
            	$arrLocationDataExist['kol_id'] = $kolId;
            	$arrLocationDataExist['org_institution_id'] = $arrKolData['org_id'];
            	$isExist = $this->kol->getKolLocationByOrgInstId($arrLocationDataExist);
//             	echo $isExist;
            	if($isExist > 0){
            		$updatedId = $isExist;
            		$isPresentOrg = true;
                	$lastId = $this->kol->updateKolPrimaryLocation($arrLocationData, $kol_id);
                	$data['id'] = $kol_id;
            	}else{
            		$isPresentOrg = false;
            		$data['id'] = $kolId;
            		$arrLocationData['kol_id'] = $kolId;
            		$genericId = $this->common_helpers->getGenericId("Location Form");
            		$arrLocationData['generic_id'] = $genericId;
            		$lastId = $this->kol->saveLocation($arrLocationData);
            		$lastInsertedLocationId = $lastId;
            	}
//             	exit;
            } else {
                $data['id'] = $kolId;
                $arrLocationData['kol_id'] = $kolId;
                $genericId = $this->common_helpers->getGenericId("Location Form");
                $arrLocationData['generic_id'] = $genericId;
                $lastId = $this->kol->saveLocation($arrLocationData);
	            $lastInsertedLocationId = $lastId;
           }
           	$this->save_kol_client_association($kolId,'fromKol');
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }

        if ($this->input->post("kol_id") == '') {
        	$arrEmailData = array();
            /* Save email to emails table */
            if ($this->input->post('email') != '') {
                $arrEmailData = array();
                $arrEmailData['type'] = 'Work';
                $arrEmailData['email'] = trim($this->input->post('email'));
                $arrEmailData['is_primary'] = 1;
                $arrEmailData['contact'] = $kolId;
                $arrPhoneData['location_id'] = $lastId;
                $arrEmailData['created_by'] = $this->loggedUserId;
                $arrEmailData['created_on'] = date('Y-m-d H:i:s');
                $arrEmailData['modified_by'] = $this->loggedUserId;
                $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                $this->db->insert('emails', $arrEmailData);
            }
            /* Save phone to phone_number table */
            if ($this->input->post('phone_number_loc') != '') {
                $arrPhoneData = array();
                $arrPhoneData['type'] = trim($this->input->post('phone_type_loc'));
                $arrPhoneData['number'] = trim($this->input->post('phone_number_loc'));
                $arrPhoneData['is_primary'] = 1;
                $arrPhoneData['contact'] = $kolId;
                $arrPhoneData['location_id'] = $lastId;
                $arrPhoneData['contact_type'] = "location";
                $arrPhoneData['created_by'] = $this->loggedUserId;
                $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                $arrPhoneData['modified_by'] = $this->loggedUserId;
                $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                $this->db->insert('phone_numbers', $arrPhoneData);
            }
            $data['status'] = true;
        } else {
            /* Save email to emails table */
            if ($this->input->post('email') != '') {
                $arrEmailData = array();
                $arrEmailData['type'] = 'Work';
                $arrEmailData['email'] = trim($this->input->post('email'));
                $arrEmailData['is_primary'] = 1;
                $arrEmailData['contact'] = $this->input->post("kol_id");
                $arrEmailData['created_by'] = $this->loggedUserId;
                $arrEmailData['created_on'] = date('Y-m-d H:i:s');
                $arrEmailData['modified_by'] = $this->loggedUserId;
                $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                $this->kol->updateOlEmail($arrEmailData);
            }
            if($isPresentOrg){
            	/* Update phone to phone_number table */
            	$arrPhoneDataExist['contact'] = $kolId;
            	if($updatedId ==''){
            		$arrPhoneDataExist['location_id'] = $this->input->post("location_id");
            	}else{
            		$arrPhoneDataExist['location_id'] = $updatedId;
            	}
            	$isExist = $this->kol->getKoPhoneByLocationId($arrPhoneDataExist);
            	if($isExist > 0){
            	if ($this->input->post('phone_number_loc') != '' || $this->input->post('phone_type_loc') != '') {
            		$arrPhoneData = array();
            		$arrPhoneData['type'] = trim($this->input->post('phone_type_loc'));
            		$arrPhoneData['number'] = trim($this->input->post('phone_number_loc'));
            		$arrPhoneData['is_primary'] = 1;
            		$arrPhoneData['contact'] = $this->input->post("kol_id");
            		$arrPhoneData['contact_type'] = "location";
            		if($updatedId ==''){
            			$arrPhoneData['location_id'] = $this->input->post("location_id");
            		}else{
            			$arrPhoneData['location_id'] = $updatedId;
            		}
            		$arrPhoneData['created_by'] = $this->loggedUserId;
            		$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
            		$arrPhoneData['modified_by'] = $this->loggedUserId;
            		$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
            		$this->kol->updateOlPhone($arrPhoneData);
//             		echo $this->db->last_query();
            	}
            }else{
            		if ($this->input->post('phone_number_loc') != '') {
            			$arrPhoneData = array();
            			$arrPhoneData['type'] = trim($this->input->post('phone_type_loc'));
            			$arrPhoneData['number'] = trim($this->input->post('phone_number_loc'));
            			$arrPhoneData['is_primary'] = 1;
            			$arrPhoneData['contact'] = $kolId;
            			if($updatedId ==''){
            				$arrPhoneData['location_id'] = $this->input->post("location_id");
            			}else{
            				$arrPhoneData['location_id'] = $updatedId;
            			}
            			$arrPhoneData['contact_type'] = "location";
            			$arrPhoneData['created_by'] = $this->loggedUserId;
            			$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
            			$arrPhoneData['modified_by'] = $this->loggedUserId;
            			$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
            			$this->kol->savePhone($arrPhoneData);
            		}
            	}
            	
            }else{
            	/* Save phone to phone_number table */
            	if ($this->input->post('phone_number_loc') != '') {
            		$arrPhoneData = array();
            		$arrPhoneData['type'] = trim($this->input->post('phone_type_loc'));
            		$arrPhoneData['number'] = trim($this->input->post('phone_number_loc'));
            		$arrPhoneData['is_primary'] = 1;
            		$arrPhoneData['contact'] = $kolId;
            		$arrPhoneData['location_id'] = $lastId;
            		$arrPhoneData['contact_type'] = "location";
            		$arrPhoneData['created_by'] = $this->loggedUserId;
            		$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
            		$arrPhoneData['modified_by'] = $this->loggedUserId;
            		$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
            		$this->kol->savePhone($arrPhoneData);
            	}
            }
            $data['status'] = true;
        }
        
        //Add Log activity
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'module' => 'kols',
                'type' => LOG_ADD,
                'description' => 'New HCP',
                'status' => 'success',
                'transaction_id' => $kolId,
            	'transaction_table_id' => KOLS,
                'transaction_name' => "New HCP",
            	'form_data' => $formData,
				'parent_object_id' => $kolId
            );

       	if ($this->input->post("kol_id") != '') {
			$arrLogDetails['type'] = LOG_UPDATE;
			$arrLogDetails['description'] = 'Update HCP';
			$arrLogDetails['transaction_name'] = 'Update HCP';
		}

		$this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null,true);
        echo json_encode($data);
    }

    function save_notes($kolId) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $arr['note'] = trim($this->input->post('user_note'));
        $arr['created_by'] = $this->loggedUserId;
        $arr['created_on'] = date("Y-m-d H:i:s");
        $arr['kol_id'] = $kolId;
        $arr['document']= '';
        $arr['document_name']= '';
        if($_FILES["note_file"]['name']!=''){
            $target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
            $path_info = pathinfo($_FILES["note_file"]['name']);
            $newFileName	= random_string('unique', 20).".".$path_info['extension'];
            $overview_file_target_path = $target_path ."/". $newFileName;
            if(move_uploaded_file($_FILES['note_file']['tmp_name'],$overview_file_target_path)){
                $arr['document'] = $newFileName;
                $fname = explode('.', $_FILES["note_file"]['name']);
                $arr['orginal_doc_name']= $_FILES["note_file"]['name'];
                $arr['document_name']= $fname[0];
                if($this->input->post('fileName')){
                    $arr['document_name']= trim($this->input->post('fileName'));
                }
            }
        }
        $arr['id'] = $this->kol->saveNote($arr);


        $arr['name'] = $this->session->userdata('user_full_name');
        $currentDateTime = $arr['created_on'];

        $arr['created_on'] = date('d M Y, h:i A', strtotime($currentDateTime));
        $arr['note'] = nl2br($arr['note']);
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
                'module' => 'kols',
                'type' => LOG_ADD,
            'description' => 'Save Note',
            'status' => 'success',
                'transaction_id' => $arr['id'],
            'transaction_table_id' => KOL_NOTES,
                'transaction_name' => 'Save Note',
                'form_data' => $formData,
            'parent_object_id'=>$arr['kol_id'],
        );
            
        $this->config->set_item('log_details', $arrLogDetails);
        //log_user_activity(null, true);
       
        //log_user_activity($arrLogDetails, true);			
        echo json_encode($arr);
    }

    function delete_notes($noteId) {
        $arrData = array();
        if ($this->kol->deleteNote($noteId)) {
            $arrData['status'] = true;
        } else {
            $arrData['status'] = false;
        }
        echo json_encode($arrData);
    }
    function delete_notes_attachment($noteId){
        $arrData = array();
        if ($this->kol->deleteNoteAttachment($noteId)) {
            $arrData['status'] = true;
        } else {
            $arrData['status'] = false;
        }
        echo json_encode($arrData);
    }
    function update_notes($noteId,$orginal_doc='',$kolId) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $arr['note'] = trim($this->input->post('user_note'));
        $arr['modified_by'] = $this->loggedUserId;
        $arr['modified_on'] = date("Y-m-d H:i:s");
        if(trim($this->input->post('fileName'))!=''){
        $arr['document_name']= trim($this->input->post('fileName'));
        }    
        $arr['orginal_doc_name'] = '';
        if($orginal_doc!='undefined'){
            $arr['orginal_doc_name']= trim($orginal_doc);
        }
        $arr['id'] = $noteId;       
        if($_FILES["note_file"]['name']!=''){
            $target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
            $path_info = pathinfo($_FILES["note_file"]['name']);
            $newFileName	= random_string('unique', 20).".".$path_info['extension'];
            $overview_file_target_path = $target_path ."/". $newFileName;
            if(move_uploaded_file($_FILES['note_file']['tmp_name'],$overview_file_target_path)){
                $arr['document'] = $newFileName;
                $fname = explode('.', $_FILES["note_file"]['name']);
                 $arr['orginal_doc_name']= $_FILES["note_file"]['name'];
                $arr['document_name']= $fname[0];
                if($this->input->post('fileName')){
                    $arr['document_name']= trim($this->input->post('fileName'));
                }
            }
        }
        $arrUpdateData  = $arr;
        if ($this->kol->updateNote($arrUpdateData)) {
            $arr['name'] = $this->session->userdata('user_full_name');
            $currentDateTime = $arr['modified_on'];
            $arr['created_on'] = date('d M Y, h:i A', strtotime($currentDateTime));
            $arr['created_on'] = str_replace(',', " at ", $arr['created_on']);
            $arr['note'] = nl2br($arr['note']);
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                    'module' => 'kols',
                    'type' => LOG_UPDATE,
                    'description' => 'Update Note',
                    'status' => 'success',
                    'transaction_id' => $arr['id'],
                    'transaction_table_id' => KOL_NOTES,
                    'transaction_name' => 'Update Note',
                    'form_data' => $formData,
                    'parent_object_id' => $kolId,
            );
            
            $this->config->set_item('log_details', $arrLogDetails);
            //log_user_activity(null, true);
            echo json_encode($arr);
        }
    }

    function get_notes_by_id($noteId) {
//		echo "lll";
        $arr = $this->kol->getNotesById($noteId);
        $arr = $arr[0];
        if ($arr['modified_on'] != '')
            $currentDateTime = $arr['modified_on'];
        else
            $currentDateTime = $arr['created_on'];
        $arr['created_on'] = date('Y-m-d,h:i A', strtotime($currentDateTime));
        $arr['created_on'] = str_replace(',', " at ", $arr['created_on']);
//		pr($arr);
        echo json_encode($arr);
    }

    function view_location($id = null) {
        $data['locationData'] = $this->kol->getLocationById($id);
        $result = $this->common_helpers->getUserName($data['locationData'][0]['created_by']);

        $country_id = $data['locationData'][0]['country_id'];
        $state_id = $data['locationData'][0]['state_id'];
        $city_id = $data['locationData'][0]['city_id'];
        $data['locationData'] = $data['locationData'][0];
        $data['locationData']['org_institution_name'] = $this->organization->getOrgNameByOrgId($data['locationData']['org_institution_id']);
        $data['staffData'] = $this->kol->getStaffs($id, 'location');
        $data['phoneData'] = $this->kol->getPhones($id, 'location');
        $data['country_id'] = $this->Country_helper->getCountryById($country_id);
        $data['state_id'] = $this->Country_helper->getStateById($state_id);
        $data['city_id'] = $this->Country_helper->getCityeById($city_id);
        $data['result'] = $result;
        $this->load->view('kols/view_location', $data);
    }

    function save_best_time($kolId = null, $day = null) {
        $days = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
        $arrData['kol_id'] = $kolId;
        $arrData['day'] = $days[$day];
        $arrData['time'] = date("H:i:s", strtotime($this->input->post("time")));
        $data['status'] = $this->kol->saveBestTime($arrData);
        if ($data['status']) {
            $data['kol_id'] = $kolId;
            $data['day'] = $day;
            $data['time'] = $this->input->post("time");
        }
        echo json_encode($data);
    }

    function delete_best_time($id = null) {
        $this->kol->deleteBestTime($id);
        $data['status'] = true;
        echo json_encode($data);
    }

    function check_duplicate_ol($step) {
        $data = array();
        $arrData['kol_id'] = $this->input->post('kol_id');
        $arrData['first_name'] = $this->input->post('first_name');
        $arrData['last_name'] = $this->input->post('last_name');
        $arrData['specialty'] = $this->input->post('specialty');
        if ($step == '2') {
            //$arrData['postal_code'] = $this->input->post('postal_code');
            $arrData['city_id'] = $this->input->post('city_id');
            $arrData['state_id'] = $this->input->post('state_id');
        }
        $arrDuplicates = $this->kol->checkDuplicateOL($arrData);
        if (count($arrDuplicates) > 0) {
            $viewData['arrDuplicates'] = $arrDuplicates;
            $viewData['step'] = $step;
            $viewData['kolId'] = $arrData['kol_id'];
            $data['duplicate_found'] = 1;
            $dupHtml = $this->load->view("kols/view_duplicate_ols", $viewData, true);
            $data['dupHtml'] = $dupHtml;
        } else
            $data['duplicate_found'] = 0;

        echo json_encode($data);
    }

    function getKolDetails($kolId) {
        $arrKolDetail = $this->kol->getKolMicroData($kolId);
        echo json_encode($arrKolDetail);
    }
    
    function get_speaker_products(){
        $arrSpeaker = $this->kol->getSpeakerProducts();
    return $arrSpeaker;
    }
    
    function get_kol_titles($title){
    
        $titleKeyword		= utf8_urldecode($this->input->post($title));
		$arrKolTitles = $this->kol->getMatchingkolTitles($titleKeyword);
		$arrSuggestTitles	= array();
		if(sizeof($arrKolTitles)==0){
			$arrSuggestTitles[0]		= 'No results found for '.$titleKeyword;
		}else{
			$flag	= 1;
			foreach($arrKolTitles as $typeId=>$title){
				if($flag){
					$arrSuggestTitles[]='<div class="autocompleteHeading">Positions</div><div class="dataSet"><label name="'.$title.'" class="kolTypes" style="display:block">'.$title."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestTitles[]='<div class="dataSet"><label name="'.$title.'" class="kolTypes" style="display:block">'.$title."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $titleKeyword;
		$arrReturnData['suggestions']	= $arrSuggestTitles;
		echo json_encode($arrReturnData);
    }
    
    function get_region($region){
                $regionKeyword		= utf8_urldecode($this->input->post($region));
		$arrRegions= $this->kol->getMatchingRegions($regionKeyword);
		$arrSuggestRegions	= array();
		if(sizeof($arrRegions)==0){
			$arrSuggestRegions[0]		= 'No results found for '.$regionKeyword;
		}else{
			$flag	= 1;
//                      pr($arrRegions);
			foreach($arrRegions as $key=>$title){
				if($flag){
					$arrSuggestRegions[]='<div class="autocompleteHeading">Global Regions</div><div class="dataSet"><label name="'.$title.'" class="regionTypes" style="display:block">'.$title."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestRegions[]='<div class="dataSet"><label name="'.$title.'" class="regionTypes" style="display:block">'.$title."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $regionKeyword;
		$arrReturnData['suggestions']	= $arrSuggestRegions;
		echo json_encode($arrReturnData);
    }

    function sync_from_offline(){
    	$userId = $this->session->userdata('user_id');
    	$clientId = $this->session->userdata('client_id');
    	$kols = $this->input->post('mykols');
    	foreach($kols as $kol){
    		if(isset($kol['need_sync']) && $kol['need_sync'] == true){
    			$kolDetails = array();
    			$kolDetails['first_name'] = $kol['first_name'];
    			$kolDetails['last_name'] = $kol['last_name'];
    			$newKolId = $this->kol->saveKol($kolDetails);
    			if($newKolId){
    				
    				$arrUsers[] = $userId;
    				$kolIds[] = $newKolId;
    				$this->align_user->saveKolAlignment($kolIds,$arrUsers);
    			}
    		}
    	}
    	
    	$arrInteractions = $this->input->post('myints');
    	$arrInteractions = json_decode($arrInteractions);
    	foreach($arrInteractions as $row){
    		$row = (array)$row;
    		if(isset($row['need_sync']) && $row['need_sync'] == true){
    			$intDetails = array();
    			$intDetails['date'] = date("Y-m-d H:i:s");
    			$intDetails['territory_id'] = $row['territory'];
    			$intDetails['employee_id'] = $row['employee'];
    			$intDetails['mirf_case_num'] = $row['mirf_case_num'];
    			$intDetails['location_category'] = $row['location_type'];
    			$intDetails['mode'] = $row['channel'];
    			$intDetails['grouping'] = $row['category'];
    			$intDetails['created_by'] = $userId;
    			$intDetails['created_on'] = date("Y-m-d H:i:s");
    			$intDetails['client_id'] = $clientId;
    			 $genericId = $this->common_helpers->getGenericId("Interactions Name");
           	 	$intDetails['generic_id'] = $genericId;
    			$interactionId = $this->interaction->saveInteraction($intDetails);
    			if($interactionId){
    				$kolAndCatdetail = array();
    				$kolAndCatdetail['interaction_id'] = $interactionId;
    				$kolAndCatdetail['kol_id'] = $row['kol_id'];
	    			$this->interaction->saveInteractionAttendis($kolAndCatdetail);
	    			$topicDeatl = array();
	    			$topicDeatl['interaction_id'] = $interactionId;
	    			$topicDeatl['product_id'] = $row['product_id'];
	    			$topicDeatl['interaction_type'] = $row['type_id'];
	    			$topicDeatl['topic_id'] = $row['topic_id'];
	    			$topicDeatl['sub_topic_id'] = $row['sub_topic_id'];
	    			$this->interaction->saveInteractionTopicDetail($topicDeatl);
    			}
    			
    		}
    	}
    }
    
	function sync_to_offline(){
    	$arrKols = array();
    	$userId = $this->session->userdata('user_id');
    	
    	//Get user kols - aligned kols
    	$arrKols = $this->kol->getMyKolsForOffline($userId);
    	foreach($arrKols as $key => $row){
    		$locations = array();
        	$locations = $this->kol->listLocationDetails($row['id']);
        	$arrKols[$key]['locations'] =  $locations; 
    	}
    	
    	//Get user interactions for offline
    	$arrInteractions = $this->interaction->getMyInteractionsForOffline($userId);
    	foreach($arrInteractions as $key => $row){
    		unset($arrInteractions[$key]['kol_name']);
    	}
    	
    	//Prepare all the data to be sent
    	$data['myints'] = $arrInteractions;
    	$data['mykols'] = $arrKols;
    	echo json_encode($data);
    }
    
    function get_key_members($title){
        $titleKeyword = utf8_urldecode($this->input->post($title));
        $arrMembers = $this->kol->getMatchingkolMembers($titleKeyword);
        $arrSuggestTitles = array();
        if (sizeof($arrMembers) == 0) {
            $arrSuggestTitles[0] = 'No results found for ' . $titleKeyword;
        } else {
            $flag = 1;
            foreach ($arrMembers as $typeId => $title) {
                $data=explode("_",$title);
                if ($flag) {
                    $arrSuggestTitles[] = '<div class="autocompleteHeading">Key Membership</div><div class="dataSet"><label name="' . $data[1] . '" class="kolTypes" style="display:block">' . $data[0] . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestTitles[] = '<div class="dataSet"><label name="' . $data[1] . '" class="kolTypes" style="display:block">' . $data[0] . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $titleKeyword;
        $arrReturnData['suggestions'] = $arrSuggestTitles;
        echo json_encode($arrReturnData);
    }
    
    function get_topics($title){
        $titleKeyword = utf8_urldecode($this->input->post($title));
        $arrTopic = $this->kol->getMatchingTopics($titleKeyword);
        $arrSuggestTopics = array();
        if (sizeof($arrTopic) == 0) {
            $arrSuggestTopics[0] = 'No results found for ' . $titleKeyword;
        } else {
            $flag = 1;
            foreach ($arrTopic as $typeId => $title) {
                
                if ($flag) {
                    $arrSuggestTopics[] = '<div class="autocompleteHeading">Topics</div><div class="dataSet"><label name="' . $title . '" class="topicTypes" style="display:block">' . $title . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestTopics[] = '<div class="dataSet"><label name="' . $title . '" class="topicTypes" style="display:block">' . $title . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $titleKeyword;
        $arrReturnData['suggestions'] = $arrSuggestTopics;
        echo json_encode($arrReturnData);
    }
    
    function delete_created_ol($kolid){
        $this->kol->deleteStaff("", $kolid);
        $this->kol->deletePhone("", $kolid);
        $this->kol->deleteLocation($kolid);
        $this->kol->deleteKol($kolid);
        redirect('kols/list_kols_client_view');
    }
   // to update titles with actual id
    function update_titles(){
    	// query to update kols.title to their respective id from titles 
    	$update = $this->db->query("update kols k join titles t on k.title = t.title set k.title = t.id");
    	
    	// get non numeric titles and insert them to titles table and update kols title field with id
    	$select=$this->db->query("SELECT distinct(title),id FROM kols WHERE title REGEXP '^[A-Za-z ]+$'");
    	if($select->num_rows()>0){
	    	foreach($select->result_array() as $row){
	    		$this->db->insert("titles",array("title"=>$row['title'],"client_id"=>INTERNAL_CLIENT_ID,"is_active"=>1));
	    		$l_id = $this->db->insert_id();
	    		$this->db->update("kols",array("title"=>$l_id),array("title"=>$row['title']));
	    		
	    	}
    	}
    }
    function update_suffix(){
        // query to update kols.suffix to their respective id from suffix
        $update = $this->db->query("update kols k join professional_suffix t on k.suffix = t.suffix set k.suffix = t.id");
         
        // get non numeric suffix and insert them to suffix table and update kols suffix field with id
        $select=$this->db->query("SELECT distinct(suffix),id FROM kols WHERE suffix REGEXP '^[A-Za-z ,()-/_]+$'");
//         pr($select->result_array());exit;
        if($select->num_rows()>0){
            foreach($select->result_array() as $row){
                $this->db->insert("professional_suffix",array("suffix"=>$row['suffix'],"is_active"=>1));
                $l_id = $this->db->insert_id();
                $this->db->update("kols",array("suffix"=>$l_id),array("suffix"=>$row['suffix']));                 
            }
        }        
    }
    function update_suffix_reverse(){
        // query to update kols.suffix to their respective id from suffix
        $update = $this->db->query("update kols k join professional_suffix t on k.suffix = t.id set k.suffix = t.suffix");  
        // get non numeric suffix and insert them to suffix table and update kols suffix field with id
        $select=$this->db->query("SELECT * FROM professional_suffix WHERE suffix REGEXP ','");
//                 pr($select->result_array());
        if($select->num_rows()>0){
            foreach($select->result_array() as $row){
                $suffix = explode(',', $row['suffix']);
                foreach ($suffix as $r){
                    $get = $this->db->get_where("professional_suffix",array("suffix"=>$r));
                    if($get->num_rows()==0){
                        $this->db->insert("professional_suffix",array("suffix"=>trim($r),"is_active"=>1));
                    }                    
                }                
                $this->db->delete("professional_suffix",array("id"=>$row['id']));
            }
        }
    }
    function update_organization(){
        $update = $this->db->update("organizations",array("type_id"=>7),array("type_id"=>0));
    }
    function list_unprocessed_trials(){
        $data = array();
        $data['contentPage'] = 'clinicals/unprocessed_trials';
        $this->load->view('layouts/analyst_view',$data);
    }
    
    function view_pub_top_concepts($kolId=null, $fromYear, $toYear){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$keyWord = $this->input->post('keyWord');
		$startFrom = $this->input->post('startFrom');
		$category = $this->input->post('category');
		$this->session->set_userdata('kolKeyWords',$keyWord);
		
		$arrMajorMeshterm 	= $this->kol->getTopConceptDataForChart($kolId, $fromYear, $toYear,$keyWord,'all');
		$topConceptData = $this->prepareTopConcepts($arrMajorMeshterm,$startFrom,$category);
		$data = array();
		$meshCatCounter=0;
		$data['arrData'] = $topConceptData;
		echo json_encode($data);
                exit;//required
	}
        
	function prepareTopConcepts($arrTopConceptsData, $startFrom = '', $category = '') {
        $arrRetData = array();
        $arr = array();
        foreach ($arrTopConceptsData as $row) {
            if ($row['tree_id'] != '') {
                $treeId = explode(",", $row['tree_id']);
                foreach ($treeId as $key => $id) {
                    $arr[$id[0]][$row['name']] = $row;
                }
            }
        }

        if (isset($arr['E'])) {
            foreach ($arr['E'] as $row) {
                $treeId = explode(",", $row['tree_id']);
                foreach ($treeId as $key => $id) {
                    $arr[substr($id, 0, 3)][$row['name']] = $row;
                }
            }
        }
        unset($arr['E']);
        $authDetails = array();
        $arrRetData = array();
        foreach ($arr as $key => $row) {
            $authDetails[$key] = array_values($row);
        }
        if ($startFrom == '')
            $startFrom = 0;

        $interArr = array();
        if ($category != '') {
            $interArr[$category] = $authDetails[$category];
            $authDetails = $interArr;
        }
//		pr($authDetails);
//		exit;		
        foreach ($authDetails as $key => $row) {
            switch ($key) {
                case 'C' : $tCount = $authDetails['C'][0]['count'];
                    $arrResults = $authDetails['C'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_C';
//								$data['pmidsCount'] = $arr['C'];
                    $data['title'] = 'Diseases';
                    $data['category'] = 'C';
                    $arrRetData['C'] = $data;
                    break;
                case 'D' : $tCount = $authDetails['D'][0]['count'];
                    $arrResults = $authDetails['D'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_D';
//								$data['pmidsCount'] = $arr['D'];
                    $data['title'] = 'Chemicals and Drugs';
                    $data['category'] = 'D';
                    $arrRetData['D'] = $data;
                    break;
                case 'E01' : $tCount = $authDetails['E01'][0]['count'];
                    $arrResults = $authDetails['E01'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_E1';
//								$data['pmidsCount'] = $arr['E1'];
                    $data['title'] = 'Dentistry';
                    $data['category'] = 'E01';
                    $arrRetData['E01'] = $data;
                    break;
                case 'E02' : $tCount = $authDetails['E02'][0]['count'];
                    $arrResults = $authDetails['E02'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_E2';
//								$data['pmidsCount'] = $arr['E2'];
                    $data['title'] = 'Investigative & Diagnostic';
                    $data['category'] = 'E02';
                    $arrRetData['E02'] = $data;
                    break;
                case 'E06' : $tCount = $authDetails['E06'][0]['count'];
                    $arrResults = $authDetails['E06'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_E3';
//								$data['pmidsCount'] = $arr['E3'];
                    $data['title'] = 'Devices';
                    $data['category'] = 'E06';
                    $arrRetData['E06'] = $data;
                    break;
                case 'E07' : $tCount = $authDetails['E07'][0]['count'];
                    $arrResults = $authDetails['E07'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_E4';
//								$data['pmidsCount'] = $arr['E4'];
                    $data['title'] = 'Procedures';
                    $data['category'] = 'E07';
                    $arrRetData['E07'] = $data;
                    break;
                case 'F' : $tCount = $authDetails['F'][0]['count'];
                    $arrResults = $authDetails['F'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_F';
//								$data['pmidsCount'] = $arr['F'];
                    $data['title'] = 'Psychiatry and Psychology';
                    $data['category'] = 'F';
                    $arrRetData['F'] = $data;
                    break;
                case 'H' : $tCount = $authDetails['H'][0]['count'];
                    $arrResults = $authDetails['H'];
                    $data = array();
                    $topCount = $tCount;
                    $count = count($arrResults);
                    $data['topCount'] = $topCount;
                    $arrSlice = array_slice($arrResults, $startFrom, 20);
                    $data['categoryData'] = $arrSlice;
                    $data['next'] = $startFrom + 20;
                    $data['prev'] = $startFrom - 20;
                    $data['total'] = $count;
                    $data['reportSection'] = 'category_H';
//								$data['pmidsCount'] = $arr['H'];
                    $data['title'] = 'Disciplines and Specialties';
                    $data['category'] = 'H';
                    $arrRetData['H'] = $data;
                    break;
            }
        }
//			pr($arrRetData);
//			exit;
//		$this->sortaasort($arrRetData,'pmidsCount');
        return $arrRetData; //array_values($arrRetData);
    }
	
    /*
     * Generate md5 value of kol id and store in unique id column.
     * This is used for kol consent.
     */
    function generate_unique_id_for_kol(){
    	$this->kol->generateUniqueIdForKol();
    }
    
    /*
     * Generate html view for given unique id.
     */
    function kol_consent($uniqueId){
    	 $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
    	$consentStatus = $this->kol->getKolConsentStatus($kolId);
    	if($kolId){
    		$arrhtml = $this->get_mini_profile_as_html($kolId, 'Pdf');
    		$data['unique_id'] = $uniqueId;
    		$data['kol_id'] = $kolId;
    		$data['consent_status'] = $consentStatus;
    		$data['html'] = $arrhtml[0];
    	}else{
    		$data['html'] = 'Invalid Request';
    	}
    	$this->load->view('kols/kol_consent_view', $data);
    }
    /*
     * Updates the kol consent data as per kol's request.
     */
    function update_kol_consent(){
    	if($this->input->post('flag') != 'deny'){
    		if (empty($_FILES['consent_attachment']['name'])) {
    			// No file was selected for upload
    			$consentData['kol_id'] = $this->input->post('kol_id');
    			$consentData['consent_notes'] = $this->input->post('consent_notes');
    			$consentData['consent_attachment_name'] = '';
    			$status = $this->kol->updateKolConsent($consentData);
    			if($status == '1'){
    				$data['status'] = 'success';
    			}else{
    				$data['status'] = 'fail';
    			}
    		}else{
    
    			$uploadPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/consent_documents";
    			$config['upload_path'] = $uploadPath;
    			$config['allowed_types'] = 'gif|jpg|png';
    			$this->load->library('upload', $config);
    			if (!$this->upload->do_upload('consent_attachment')){
    				//$data = array('error' => $this->upload->display_errors());
    				$data['status'] = 'fail';
    			}else{
    				$uploadData = array('upload_data' => $this->upload->data());
    				$consentData = array();
    				$consentData['kol_id'] = $this->input->post('kol_id');
    				$consentData['consent_notes'] = $this->input->post('consent_notes');
    				$consentData['consent_attachment_name'] = $uploadData['upload_data']['file_name'];
    				$status = $this->kol->updateKolConsent($consentData,'1');
    				if($status == '1'){
    					$data['status'] = 'success';
    				}else{
    					$data['status'] = 'fail';
    				}
    			}
    		}
    	}else{
    		$consentData['kol_id'] = $this->input->post('kol_id');
    		$status = $this->kol->updateKolConsent($consentData,'0');
    		if($status == '1'){
    			$data['status'] = 'success';
    		}else{
    			$data['status'] = 'fail';
    		}
    	}
    	$this->load->view('kols/kol_consent_status_view', $data);
    }
    
    
    function edit_client_affiliations($kolId,$affId) {
    	$data['kolId'] = $kolId;
    	$data['affId'] = $affId;
    	$data['arrMembership'] = array('engagement_id' => '');
    	$this->load->Model('Engagement_type');
    	$arrEngagementTypes = $this->Engagement_type->getAllEngagementTypes();
    	$key = array_search('Other', $arrEngagementTypes);
    	unset($arrEngagementTypes[$key]);
    	$arrEngagementTypes[$key] = 'Other';
    	$data['arrEngagementTypes'] = $arrEngagementTypes;
    
    	$arrAffiliationsData = $this->kol->getAffiliationsDataById($affId);
    	$data['arrAffiliationsData'] = $arrAffiliationsData;
    	$this->load->view('memberships_affiliations/add_client_affiliations', $data);
    }
    
    
    function edit_client_event($kolId,$eventId) {
    	$data['kolId'] = $kolId;
    	// Get the list of Conference Event Types
    	$this->load->model('Event_helper');
    	$arrConfEventTypes = $this->Event_helper->getAllConferenceEventTypes();
    	$data['arrConfEventTypes'] = $arrConfEventTypes;
    	// Get the list of Conference Session Types
    	$arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
    	$key = array_search('Other', $arrConfSessionTypes);
    	unset($arrConfSessionTypes[$key]);
    	$arrConfSessionTypes[$key] = 'Other';
    	$data['arrConfSessionTypes'] = $arrConfSessionTypes;
    	$data['arrEventSponsorTypes'] = $this->Event_helper->getSponsorTypes();
    	$data['arrEventOrganizerTypes'] = $this->Event_helper->getOrganizerTypes();
    	$kolId = $this->session->userdata('kolId');
    	
    	$arrEventData = $this->kol->getEventById($eventId);
    	// Getting the KOL details
    	//$arrKolDetail = $this->kol->editKol($kolId);
    	// Get the list of Topic belongs to kol specialty
    	$arrTopics = $this->kol->getTopicsBySpecialty($arrEventData['et_specialty_id']);
    	$data['arrTopics'] = $arrTopics;
    	$data['arrCountry'] = $this->Country_helper->listCountries();
    	$data['arrRoles'] = $this->kol->getEventRoles();
    	 
    	
    	$data['arrEventData'] = $arrEventData;
    	$this->load->view('events/add_client_event', $data);
    }
    function note_document_download($noteId){       
        $arrNotes = $this->kol->getNotesById($noteId);
        $this->load->helper('download');
        ob_clean();
        $data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/kol_note_documents/".$arrNotes[0]['document']);
        $arrFileName    = explode(".",$arrNotes[0]['document']);
        $name = $arrNotes[0]['document_name'].".".$arrFileName[sizeof($arrFileName)-1];
        force_download($name, $data);
    }
    function view_summary_events($kol_id){
		$data['name']=$name;
		$data['kol_id']=$kol_id;
		$this->load->view('kols/profile_summary_kol_events',$data);
	}
	
function list_KOLS_events($kol_id){
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $name = $this->input->post("name");
        $topicType = $this->input->post("topicType");
        // 		echo $topicType;exit;
        if($topicType == 'events'){
            $arrCoachingResultData = $this->kol->profileSummaryEvents($name,$kol_id);
        }
        else if ($topicType == 'pubs'){
            $arrCoachingResultData = $this->kol->profileSummaryPublications($name,$kol_id);
        }
                $arrCoachingResult = array();
                foreach ($arrCoachingResultData as $row){
                    $arrLoc = array();
                    if($row["city"] != '')
                        $arrLoc[] = $row["city"];
                        if($row["state_code"] != '')
                            $arrLoc[] = $row["state_code"];
                            $row['topic_count']	= round($row['topic_count']);
                            $row["location"] = implode(", ",$arrLoc);
                            $arrCoachingResult[] = $row;
                }
                $count = sizeof($arrCoachingResult);
                if ($count > 0) {
                    $total_pages = ceil($count / $limit);
                } else {
                    $total_pages = 0;
                }
                $data['records'] = $count;
                $data['total'] = $total_pages;
                $data['page'] = $page;
                $data['rows'] = $arrCoachingResult;
                echo json_encode($data);
    
    }
	
	//Function to show page to associate or disassociate KOLs to particular client
	function associate_disassociate_kols($kolId){
		$data['kol_id'] = $kolId;
		$arrClientList = $this->kol->getAllClients();
		$data['arrClientList'] = $arrClientList;
		$this->load->view('kols/associate_disassociate_kols',$data);
	}
	//Function to save association or disassociation KOLs to particular client
	function save_kol_client_association($kolId=null,$fromKol=''){
		if($kolId == null){
			$arrAssociationData['kol_id'] = $this->input->post('kol_id');
			$arrAssociationData['client_id'] = $this->input->post('client');
			$arrAssociationData['associationFlag'] = $this->input->post('associationFlag');
		}else{
			$arrAssociationData['kol_id'] = $kolId;
			$arrAssociationData['client_id'] = $this->session->userdata('client_id');
			$arrAssociationData['associationFlag'] = 'associate';
		}
		$returnData = $this->kol->saveKolClientAssociation($arrAssociationData);
		if($returnData){
			$status = true;
		}else{
			$status = false;
		}
		if($fromKol==''){
		  	echo json_encode($status);
		}else{
		    return $status;
		}
	}
	
	/*genetrate unique id for kols which do not have unique id*/
	function generateUniqueIdForKols(){
		$get = $this->db->get_where("kols",array("unique_id"=>null));
		foreach($get->result() as $row){
			$unique_id = md5($row->id);
			$this->db->update("kols",array("unique_id"=>$unique_id),array("id"=>$row->id));
		}
	}
	function add(){
		$arrSpecialties = $this->Specialty->getAllSpecialties('all');
		$data['arrSpecialties'] = $arrSpecialties;
		$arrSubSpecialties = $this->Specialty->getAllKolSubSpecialties($kolId);
		$data['arrSubSpecialties'] = $arrSubSpecialties;
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations'] = $arrSalutations;
		$data['arrTitles'] = $this->kol->getAllActiveTitles('all');
		$data['arrCountries'] = $this->Country_helper->listCountries();
		$first_key = key($data['arrCountries']);
		$data['arrFirstCountry'] = $data['arrCountries'][$first_key]['country_id'];
		//$data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['arrFirstCountry']);
		$data['arrStates'] = array();
		$data['arrProducts'] = $this->common_helpers->getUserProducts($this->loggedUserId);
		$data['arrSepakerProducts']=$data['arrProducts'];
		$data['arrAdditionalRoles'] = $this->kol->getAllActiveAdditionalRoles();
		$data['arrSpecialties'] = $this->Specialty->getAllSpecialties();
		$data['arrProfessionalSuffixes'] = $this->kol->getAllActiveProfessionalSuffixes();
		$data['arrOrganizationTypes'] = $this->organization->getAllOrganizationTypes();
		$data['arrPhoneType'] = $this->kol->getPhoneType();
		$data['arrKol']    = array('id'=>0);
		$data['arrYearRange']['min_year']    = 0;
		$data['arrYearRange']['max_year']    = 0;
		$data['languages'] = $this->kol->getLanguages();
		$data['checkKolAssignedToUser'] = true;
		$data['contentPage'] = 'view_biography';
		$group_names = explode(',', $this->session->userdata('group_names'));
		$regionNames = $this->kol->getEnableRegionForOptInOut();
		$result=array_intersect($group_names,$regionNames);
		$data['subContentPage'] = 'add';
		if(KOL_CONSENT){
		    if(sizeof($result) > 0){
                $data['subContentPage'] = 'add_opt_in_form';
            }
		}
        $this->load->view('layouts/client_view', $data);
	}
	//gets all data from transaction table and echo's constants (format: define('KOLS','255'))
	function createTranscationConstants(){
		$get = $this->db->get("transaction_tables");
		foreach($get->result() as $row){
			$name = strtoupper($row->name);
			$id = strtoupper($row->id);
			echo "define('$name','$id');"."<br/>";
		}
	}
	//Returns the list of KOL Names, based on search
	//$restrictOptInVisbility defalut 0 shows all kols irrespective of the Opt-in status, 1 only the KTLs that have Opted-in
	function get_kol_names_for_all_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0) {
	    /* if($kolName!="keyword"){
	        $currentkolName  = $kolName;
	        $kolName   = $restrictByRegion;
	        $restrictByRegion  = $currentkolName;
	    } */
		$kolName = utf8_urldecode($this->input->post('keyword'));
		$kolName = $this->db->escape_like_str($kolName);
		$arr['query'] = $kolName;
		$arr['suggestions'] = '';
		$arrKolNames1 = array();
		$arrKolNames = $this->kol->getAllKolNamesForAllAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);		
		$flag = 1;
		foreach ($arrKolNames['kols'] as $key => $row) {
			$cityState=$row[2];
			if(isset($row[2]) && isset($row[3]))
				$cityState.= ', ';
				$cityState.=$row[3];
				$unique_id=$row[4];
				$donotcall = '<span style="color: red">' . $row['do_not_call_flag'] . '</span>';
				if ($flag) {
					$arrKolNames1[] = '<div class="autocompleteHeading">Contacts</div><div class="dataSet"><label name="' . $row[0] . '" class="kolName" style="display:block">' . $row[0] . "</label><p class='orgName'>" . $row[1] . " " .$cityState. "</p>" . $donotcall . "<span style='display:none' class='id1'>" . $unique_id . "</span></div>";
					$flag = 0;
				} else {
					$arrKolNames1[] = '<div class="dataSet"><label name="' . $row[0] . '" class="kolName" style="display:block">' . $row[0] . "</label><p class='orgName'>" . $row[1] . " " . $cityState. "</p>" . $donotcall . "<span style='display:none' class='id1'>" . $unique_id . "</span></div>";
				}
		}
		$flag = 0;
		foreach ($arrKolNames['customers'] as $key => $row) {
			$cityState=$row[2];
			
			if(isset($row[2]) && isset($row[3]))
				$cityState.= ', ';
				$cityState.=$row[3];
				$unique_id=$row[4];
				$donotcall = '<span style="color: red">' . $row['do_not_call_flag'] . '</span>';
				if (!$flag && ($this->loggedUserId>0)) {
					$arrKolNames1[] = "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1] $cityState</p>" . $donotcall . "<span style='display:none' class='id1'>$unique_id</span></div>";
					$flag = 1;
				} else {
					if($this->loggedUserId>0)
						$arrKolNames1[] = "<div class='dataSet'><label name='" . $row[0] . "' class='kolName' style='display:block'>$row[0]</label><p class='orgName'>$row[1] $cityState</p>" . $donotcall . "<span style='display:none' class='id1'>$unique_id</span></div>";
				}
		}
		if ((sizeof($arrKolNames['kols']) < 1) && (sizeof($arrKolNames['customers']) < 1) && ($this->loggedUserId>0)) {
			$arrKolNames1[] = "<div style='padding-left:5px;'>No results found for " . str_replace(')', '', $kolName) . "</div><div><label name='No results found for " . $kolName . "' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
		}
	
		if(!$this->loggedUserId>0){
			$arrKolNames1[] = "<div style='padding-left:5px;padding-top: 5px;padding-bottom: 5px;'>Session is expired, please <a href='".base_url()."'>click here</a> to login</div>";
		}
		$arr['suggestions'] = $arrKolNames1;
		echo json_encode($arr);
	}
	
	function get_lat_long_dynamically(){
		
		$address = $this->input->post("address");
		$country = $this->input->post("country");
		$state = $this->input->post("state");
		$city = $this->input->post("city");
		$postalCode = $this->input->post("postalCode");
		if(!empty($address) && !empty($city)){
			$jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($address.' '.$city.' '.$state.' '.$country).'&sensor=false');
			$jsondata = json_decode($jsondata, true);
			if ($jsondata['status'] = 'OK') {
				$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
				$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
				if($lat != '' || $long != ''){
					$data['lat'] = $lat;
					$data['lon'] = $lon;
					echo json_encode($data);
				}
			}
		}else{
			$jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($postalCode).'&sensor=false');
			$jsondata = json_decode($jsondata, true);
			if ($jsondata['status'] = 'OK') {
				$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
				$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
				if($lat != '' || $long != ''){
					$data['lat'] = $lat;
					$data['lon'] = $lon;
					echo json_encode($data);
				}
			}
		}
	}
	function updateKolLatLong(){
        //ini_set('display_errors',1);
        //error_reporting(E_ALL);
        $nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kols');
        $this->db->select('kol_locations.id,cities.City as city_name,regions.Region as state_name,countries.Country as country_name,kol_locations.postal_code,kol_locations.address1 as address_line_1,kol_locations.kol_id,concat('.$nameFormatOrder.') as kolFullName',false);
        $this->db->join('cities','cities.CityId = kol_locations.city_id','left');
        $this->db->join('regions','regions.RegionID = kol_locations.state_id','left');
        $this->db->join('countries','countries.CountryId = kol_locations.country_id','left');
        $this->db->join('kols','kols.id = kol_locations.kol_id','left');
       // $this->db->where('kol_locations.is_primary',1);
        $this->db->where('processed_latlong',0);
        $this->db->where('concat('.$nameFormatOrder.')!=','');
        $resultSet    = $this->db->get('kol_locations');
//      pr($this->db->last_query());exit;
        $count = 0;
        $loggedInUserName = $this->session->userdata('user_full_name');
        $messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/>';
        $messageBody .= "<table border='1'><tr><th>KOL Id</th><th>KOL Name</th><th>Postal Code</th><th>Address Line 1</th><th>City</th><th>State</th><th>Country</th></tr>";
        foreach($resultSet->result_array() as $row){
            $id = $row['id'];
            $address    =   $row['state_name'].' '.$row['country_name'];
            if(!(empty($row['address_line_1']))){
                $address    = $row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name'];
            }else if(!empty($row['postal_code'])){
                $address    = $row['postal_code'].' '.$row['state_name'].' '.$row['country_name'];
            }else if(!empty($row['city_name'])){
                $address    = $row['postal_code'].' '.$row['state_name'].' '.$row['country_name'];
            }
           // if(!(empty($row['address_line_1']) && empty($row['city_name']))){
               // $jsondata = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state'].' '.$row['country']).'&sensor=false');
                                   $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyA9FjXX_skXFSbOZDPpFLBhMLHNW7ZIho8&address='.urlencode($address).'&sensor=false');
                //                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCd6S5yKz2qKTu4Qt03hjOg5jr_A9Dn6xc&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
                ///                 $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCmnoL_uL1lLEIbFQ6P3rXXn5mmpAXNiPk&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
                //                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCLYXBSf24qrsH4PMEb61BXDVx6EhVtItk&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
                //                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBGv3HIWyQhQIyz_07ucMWkPgyrdAFB0pM&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
                //                     $jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUo0dQ6rEoAfb-Dcd219qTdkgv3sOixqE&address='.urlencode($row['address_line_1'].' '.$row['city_name'].' '.$row['state_name'].' '.$row['country_name']).'&sensor=false');
                $jsondata = json_decode($jsondata, true);
                if ($jsondata['status'] = 'OK') {   

                    $lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
                    $lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
                    if($lat != '' || $lon != ''){
                        $updateLatLong = $this->db->query("UPDATE `kol_locations` SET `latitude` = $lat,`longitude` = $lon,`processed_latlong` =1 WHERE id = $id");
                    }else{
                        $messageBody .= "<tr><td>".$row['kol_id']."</td><td>".$row['kolFullName']."</td><td>".$row['postal_code']."</td><td>".$row['address_line_1']."</td><td>".$row['city_name']."</td><td>".$row['state_name']."</td><td>".$row['country_name']."</td></tr>";
                        $count++;
                    }
              //  }
            }
        }
        $messageBody .=  "</table>";        

        if($count > 0){
            $config['protocol'] = PROTOCOL;
            $config['smtp_host'] = HOST;
            $config['smtp_port'] = PORT;
            $config['smtp_user'] = USER;
            $config['smtp_pass'] = PASS;
            $config['mailtype'] = 'html';
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->initialize($config);
            $this->email->clear();
            $this->email->set_newline("\r\n");
            $this->email->from(USER, SENDER);
            $loggedInUserEmail = $this->session->userdata('email');
            $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
            $loggedInUserEmail = $this->session->userdata('email');
            $this->email->to($loggedInUserEmail);
            $this->email->message($messageBody);
            $this->email->subject(PRODUCT_NAME.': Missing Latitude and Longitude List');
            $this->email->set_crlf("\r\n");
            echo "Missing Latitude and Longitude for ".$count." KOLs<br/>";
            if ($this->email->send()) {
                echo "A email of the details has been sent to you.";
            } else {
                echo "Email could not be sent about the details";
            }
        }
    }
	function move_kol_address_to_kol_location(){
	    $arrKols = $this->db->query("SELECT * FROM kols WHERE kols.id not in (SELECT kol_locations.kol_id FROM kol_locations where kol_locations.kol_id is not null)");
	   // pr($arrKols->result_array());
	   foreach($arrKols->result_array() as $arrKol){
	       if($arrKol["org_id"] != ''){ 
    	       $arrLocationData['org_institution_id'] = $arrKol['org_id'];
    	       $arrLocationData['address1'] = $arrKol['address1'];
    	       $arrLocationData['address2'] = $arrKol['address2'];
    	       $arrLocationData['address3'] = '';
    	       $arrLocationData['validation_status'] = 'VALD';
    	       $arrLocationData['address_type'] = 'Physical';
    	       $arrLocationData['state_id'] = $arrKol['state_id'];
    	       $arrLocationData['city_id'] = $arrKol['city_id'];
    	       $arrLocationData['postal_code'] = $arrKol['postal_code'];
    	       $arrLocationData['country_id'] = $arrKol['country_id'];
    	       $arrLocationData['is_primary'] = 1;
    	       $arrLocationData['created_by'] = $this->loggedUserId;
    	       $arrLocationData['created_on'] = date('Y-m-d H:i:s');
    	       $arrLocationData['modified_by'] = $this->loggedUserId;
    	       $arrLocationData['modified_on'] = date('Y-m-d H:i:s');
    	       $arrLocationData['kol_id'] = $arrKol['id'];
    	       $genericId = $this->common_helpers->getGenericId("Location Form");
    	       $arrLocationData['generic_id'] = $genericId;
    	       $lastLocId = $this->kol->saveKolLocation($arrLocationData);
	       }
	   }
	}
	
	/*
	 * Listing  'kols' details for specific clients
	 * 
	 */
	
	function list_kols_based_on_client($previouslySelectedClientId) {
		$arrClientList = $this->kol->getAllClients();
		$data['previouslySelectedClientId'] = $previouslySelectedClientId;
		$data['arrClientList'] = $arrClientList;
		$data['contentPage'] = 'kols/list_kols_based_on_client';
		$this->load->view('layouts/analyst_view', $data);
	}
	
	
	
	function get_kols_associated_with_client($clientId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data				= array();
		$arrReturnData = array();
		$arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$arrKolData = $this->kol->getKolsAssociatedWithClient($clientId);
		foreach ($arrKolData as $row) {
			$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['kol_name'];
			$row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $kolName . '</a>';
			$arrReturnData[] = $row;
		}
		$count=sizeof($arrReturnData);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
	
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrReturnData;
		echo json_encode($data);
	}
	
	function get_kols_not_associated_with_client($clientId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data				= array();
		$arrReturnData = array();
		$arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$arrKolData = $this->kol->getKolsNotAssociatedWithClient($clientId);
		foreach ($arrKolData as $row) {
			$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['kol_name'];
			$row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $kolName . '</a>';
			$arrReturnData[] = $row;
		}
		$count=sizeof($arrReturnData);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
	
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrReturnData;
		echo json_encode($data);
	}
	
	function update_kols_status_within_client_visibility(){
		$postData = array();
		$postData['where'] = $this->input->post("where");
		$postData['kol_id'] = $this->input->post("kol_id");
		$postData['update_status'] = $this->input->post("update_status");
		$arrReturnData = $this->kol->updateKolsStatusWithinClientVisibility($postData);
		echo json_encode($arrReturnData);
	}
	
	function insertPrimarySpecialty(){
		$query = $this->db->query("Select id,specialty from kols where specialty > 0");
		foreach($query->result_array() as $row){
			$arrData=array();
			$arrData['kol_id']=$row['id'];
			$arrData['kol_sub_specialty_id']=$row['specialty'];
			$arrData['priority'] = 1;
			$this->kol->saveKolSpecialty($arrData);
		}
	}
	function update_auth_pos_category($projectId=0,$kolId=0){
	    ini_set('memory_limit', "-1");
	    ini_set("max_execution_time", 0);
	    if($kolId>0){
	        $this->db->where("project_id",$projectId);
	        //        $this->db->where_in("kol_id",array(590,1026,1027,1028,1029,1030,1031,1032,1033,1034,1035,1036,1037,1038,1039,1040,1041,1042,1043,1044,1045,1046,1047,1048,1049,1050,1051,1052));
	        //         $this->db->where("date(project_kols.created_on) = '2017-01-20'");
	        //         $this->db->where("project_kols.kol_id",1776);
	        //         $this->db->where("project_kols.kol_id > 1889 OR kol_id in (1741,1764,1864,1885,1886,1888,1735)");
	        $result = $this->db->get('project_kols');
	        //echo $this->db->last_query();
	
	        $arr = array();
	        foreach ($result->result_array() as $row){
	            $arr[$row['kol_id']] = $row['kol_id'];
	        }
	    }else{
	        $arr[$kolId] = $kolId;
	    }
	    //pr($arr);
	    //exit;
	    foreach ($arr as $key=>$kolId){
	        $this->db->where("kol_id",$kolId);
	        $result1 = $this->db->get('kol_publications');
	        //             pr($result1->result_array());
	        if($result1->num_rows() > 0){
	            foreach ($result1->result_array() as $kolPubs){
	                $this->db->where("pub_id",$kolPubs["pub_id"]);
	                $kolPubAuthresult = $this->db->get('publications_authors');
	                $totalAuthCount = $kolPubAuthresult->num_rows();
	                $authPosCat = '';
	                if($totalAuthCount == 1){
	                    $authPosCat = 'sa';
	                }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] == 1){
	                    $authPosCat = 'fa';
	                }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] == $totalAuthCount){
	                    $authPosCat = 'la';
	                }else if($totalAuthCount > 1 && $kolPubs["auth_pos"] < $totalAuthCount && $kolPubs["auth_pos"] > 1){
	                    $authPosCat = 'ma';
	                }
	                //                     pr($kolPubs);
	                $this->db->where("id",$kolPubs['id']);
	                $this->db->set("position_category",$authPosCat);
	                $this->db->update("kol_publications");
	                //                     echo $authPosCat." - ".$totalAuthCount;
	
	            }
	        }
	    }
	    echo "Done.";
	}
	
	function set_lang_url_link($langId){
	    $langName = $this->kol_consent->getLangNameById($langId);
	    $this->session->set_userdata('lang',$langName);
	    $data['status'] = true;
	    echo json_encode($data);
	}
	function save_opt_ol() {
	    $kol_id = $this->input->post('kol_id');
	    $date = date('Y-m-d H:i:s');
	    $defaultLang = 'english';
	    $arrKolData = array();
	    $arrKolData['first_name'] = trim($this->input->post('first_name'));
	    $arrKolData['last_name'] = trim($this->input->post('last_name'));
	    $arrKolData['primary_email'] = trim($this->input->post('email'));
	    $arrKolData['country_id'] = trim($this->input->post('country_id'));
	    $arrKolData['salutation'] = $this->input->post('salutation');
	    $arrKolData['primary_language_id'] = $this->input->post('lang_id');
	    $arrKolData['created_by'] = $this->loggedUserId;
	    $arrKolData['created_on'] = date('Y-m-d H:i:s');
	    $arrKolData['modified_by'] = $this->loggedUserId;
	    $arrKolData['modified_on'] = date('Y-m-d H:i:s');
	    $arrKolData['profile_type'] = USER_ADDED;
	    if (!empty($kol_id)) {
	        $savetype = false;
	        if(KOL_CONSENT){
	            $savetype = $this->input->post('savetype');
	            if($savetype == 'save_data'){
	                $savetype = false;
	                $arrKolData['opt_in_out_status'] = 1;
	            }else{
	                $savetype = true;
	                $arrKolData['opt_in_out_status'] = 2;
	            }
	        }
	        $this->kol->updateKolInfo($arrKolData, $kol_id);
	        $emailIds = '';
	        $user_email = $this->kol_consent->getAssignedUserEmails($kol_id);
	        foreach($user_email as $row){
	            $emailIds .= $seperator."'".$row."'";
	            $seperator = ',';
	        }
	        if(KOL_CONSENT && $savetype){
	            $arrLinkData = array();
	            $arrLinkData['kol_id'] = $kol_id;
	            $arrLinkData['unique_id'] = md5($kol_id.$date);
	            $arrLinkData['status'] = 0;
	            $arrLinkData['created_by'] = $this->loggedUserId;
	            $arrLinkData['note'] = '';
	            $arrLinkData['upload_file_content'] = '';
	            $query = $this->kol_consent->generateUrlLink($arrLinkData);
	            $kolName = $this->kol_consent->getKolNameByKolId($kol_id);
	            $langName = $this->kol_consent->getLanguageNameByLangId($kol_id);
// 	            if($langName==null){
// 	                $langName = 'english';
// 	            }
	            $this->session->set_userdata('lang',$langName);
	            if($query > 0 || $query == 'updated'){
	                //Log activity
	                $arrLogDetails = array(
	                    'module'=>"opt_in_out",
	                    'description'=>'Requested Opt-In / Opt-Out Invite for KTL '.$kol_id.' by '.$this->loggedUserId,
	                    'type' => 'Requested Url',
	                    'status' => 'Success',
	                    'user_id' => $this->loggedUserId,
	                    'transaction_table_id'=>'',
	                    'transaction_name'=>'Opt-in Requested',
	                    'miscellaneous1'=>$kol_id
	                );
	                $this->config->set_item('log_details', $arrLogDetails);
	                log_user_activity(null, true);
	                //$data['status'] = true;
	                //Email Notification
	                $landingContent = lang('OptInOutEmail.LandingContent');
	                $landingMissionCaption = lang('OptInOutEmail.LandingMissionCaption');
	                $landingMissionContent = lang('OptInOutEmail.LandingMissionContent');
	                $ktlEmailId = $arrKolData['primary_email'];
	                $urlLink = base_url().'kol_consents/change_language/'.$arrLinkData['unique_id'].'/'.$langName.'/page';
	                $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
	                $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
	                $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
								$url
							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
	                $img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
	                $content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
	                $content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
	                $content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
	                $content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
	                $content .="<tr><td align='center'>$img</td></tr>";
	                $content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='margin:1em 0;font-size: 16px;'>$landingMissionContent</p></td></tr>";
	                $content .="</table>";
	                $emailStatus = $this->send_email_notification($subject,$content,$kol_id);
	                if($emailStatus){
	                    $data['status'] = true;
	                    $data['emailId'] = $emailIds.'<br/><br/>'.$popUpContent;
	                }
	            }
	        }else{
	            $data['status'] = true;
	        }
	    }else{
	        $savetype = false;
	        if(KOL_CONSENT){
	            $savetype = $this->input->post('savetype');
	            if($savetype == 'save_data'){
	                $savetype = false;
	                $arrKolData['opt_in_out_status'] = 1;
	            }else{
	                $savetype = true;
	                $arrKolData['opt_in_out_status'] = 2;
	            }
	        }
	        //Save KTL
	        $kolId = $this->kol->saveKolInfo($arrKolData);
	        //Assign User
	        $arrData = array();
	        $arrData['user_id'] = $this->loggedUserId;
	        $arrData['kol_id'] = $kolId;
	        $arrData['type'] = 1;
	        $saveAssignId = $this->kol->saveAssignClient($arrData);
	        $this->save_kol_client_association($kolId,'fromKol');
            //Log activity
            $arrLogDetails = array(
                'module'=>"opt_in_out",
                'description'=>'New Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$this->loggedUserId,
                'type' => 'New Url',
                'status' => 'Success',
                'user_id' => $this->loggedUserId,
                'transaction_table_id'=>'',
                'transaction_name'=>'New',
                'miscellaneous1'=>$kolId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
            
            
	        $emailIds = '';
	        $user_email = $this->kol_consent->getAssignedUserEmails($kolId);
	        foreach($user_email as $row){
	            $emailIds .= $seperator."'".$row."'";
	            $seperator = ',';
	        }
	        if(KOL_CONSENT && $savetype){
	            $arrLinkData = array();
	            $arrLinkData['kol_id'] = $kolId;
	            $arrLinkData['unique_id'] = md5($kolId.$date);
	            $arrLinkData['status'] = 0;
	            $arrLinkData['created_by'] = $this->loggedUserId;
	            $arrLinkData['note'] = '';
	            $arrLinkData['upload_file_content'] = '';
	            $query = $this->kol_consent->generateUrlLink($arrLinkData);
	            $kolName = $this->kol_consent->getKolNameByKolId($kolId);
	            $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
// 	            if($langName==null){
// 	                $langName = 'english';
// 	            }
	            $this->session->set_userdata('lang',$langName);
	            $ktlEmailId = $arrKolData['primary_email'];
	            if($query > 0 || $query == 'updated'){
	                //Log activity
	                $arrLogDetails = array(
	                    'module'=>"opt_in_out",
	                    'description'=>'Requested Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$this->loggedUserId,
	                    'type' => 'Requested Url',
	                    'status' => 'Success',
	                    'user_id' => $this->loggedUserId,
	                    'transaction_table_id'=>'',
	                    'transaction_name'=>'Opt-in Requested',
	                    'miscellaneous1'=>$kolId
	                );
	                $this->config->set_item('log_details', $arrLogDetails);
	                log_user_activity(null, true);
	                //$data['status'] = true;
	                //Email Notification
	                $landingContent = lang('OptInOutEmail.LandingContent');
	                $landingMissionCaption = lang('OptInOutEmail.LandingMissionCaption');
	                $landingMissionContent = lang('OptInOutEmail.LandingMissionContent');
	                $urlLink = base_url().'kol_consents/change_language/'.$arrLinkData['unique_id'].'/'.$langName.'/page';
	                $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
	                $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
	                $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
								$url
							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
	                $img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
	                $content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
	                $content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
	                $content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
	                $content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
	                $content .="<tr><td align='center'>$img</td></tr>";
	                $content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='margin:1em 0;font-size: 16px;'>$landingMissionContent</p></td></tr>";
	                $content .="</table>";
	                $emailStatus = $this->send_email_notification($subject,$content,$kolId);
	                if($emailStatus){
	                    $data['status'] = true;
	                    $data['emailId'] = $emailIds.'<br/><br/>'.$popUpContent;
	                }
	                
	            }
	        }else{
	            $data['status'] = true;
	        }
	    }
	    $this->session->set_userdata('lang',$defaultLang);
	    //Add Log activity
	    $formData = $_POST;
	    $formData = json_encode($formData);
	    $arrLogDetails = array(
	        'module' => 'kols',
	        'type' => LOG_ADD,
	        'description' => 'New HCP',
	        'status' => 'success',
	        'transaction_id' => $kolId,
	        'transaction_table_id' => KOLS,
	        'transaction_name' => "New HCP",
	        'form_data' => $formData,
	        'parent_object_id' => $kolId
	    );
	    
	    if ($this->input->post("kol_id") != '') {
	        $arrLogDetails['type'] = LOG_UPDATE;
	        $arrLogDetails['description'] = 'Update HCP';
	        $arrLogDetails['transaction_name'] = 'Update HCP';
	    }
	    
	    $this->config->set_item('log_details', $arrLogDetails);
	    $this->session->unset_userdata('lang','english');
	    log_user_activity(null,true);
	    echo json_encode($data);
	}
	/**
	 * Sends a mail of success and faliure of the Opt In - Opt Out
	 * @param string $subject
	 * @param string $content
	 * @param string $emailId
	 */
function send_email_notification($subject,$content,$kolId){
    	$emailIds = '';
    	$seperator = '';
    	$user_email = $this->kol_consent->getAssignedUserEmails($kolId);
    	foreach($user_email as $row){
    		$emailIds .= $seperator."'".$row."'";
    		$seperator = ',';
    	}
//     	$emailId = 'vhanagal@gmail.com';
    	$fromEmail	= SENDER;
    	$note = nl2br($content);
    	/* $config['protocol']  = PROTOCOL;
    	$config['smtp_host'] = HOST;
    	$config['smtp_port'] = PORT;
    	$config['smtp_user'] = USER;
    	$config['smtp_pass'] = PASS;
    	$config['mailtype'] 		= 'html'; */
    	$config = email_config_initializer('optinout');
    	$this->load->library('email', $config);
    	$this->email->set_newline("\r\n");
    	$this->email->initialize($config);
    	$this->email->set_newline("\r\n");
    	$this->email->from($config['smtp_user'],$fromEmail);
    	$this->email->to($user_email);
    	$this->email->message($note);
    	$this->email->subject($subject);
    	$this->email->set_crlf("\r\n");
    	if($this->email->send()){
    		//Log Activity
    		$arrLogDetails = array(
    				'description'=>"Email sent to ".$emailIds,
    				'type' => 'Email Notification',
    				'status' => 'Success',
    				'transaction_table_id'=>'',
    				'user_id' => $this->loggedUserId,
    				'transaction_name'=>"Email sent to ".$emailIds
    		);
    		$this->config->set_item('log_details', $arrLogDetails);
    		// 			log_user_activity(null, true);
    		$status	=  true;
    	}else{
    		//Log Activity
    		$arrLogDetails = array(
    				'description'=>"Email Not sent to ".$emailIds,
    				'type' => 'Email Notification',
    				'status' => 'Failure',
    				'transaction_table_id'=>'',
    				'transaction_name'=>"Email Not sent to ".$emailIds
    		);
    		$this->config->set_item('log_details', $arrLogDetails);
    		// 			log_user_activity(null, true);
    		$status 	=  false;
    	}
    	$this->email->clear(TRUE);
    	return $status;
    }
    // update data type indicator for exicting data
    function update_data_type_indicator(){
        $get = $this->db->get_where("kols");
        foreach($get->result_array() as $kols){                  
          $data_type = $kols['profile_type'];
          if($kols['profile_type']=='Basic' || $kols['profile_type']=='Full Profile'){
              $data_type = 'Aissel Analyst';
          }
          // kol affiliations
         $this->db->update("kol_memberships",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol events
          $this->db->update("kol_events",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol publications
          $this->db->update("kol_publications",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol clinical trials
          $this->db->update("kol_clinical_trials",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol education
          $this->db->update("kol_educations",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol contracts
          $this->db->update("contracts",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol payments
          $this->db->update("payments",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol locations
          $this->db->update("kol_locations",array("data_type_indicator"=>$data_type),array("kol_id"=>$kols['id']));
          
          // kol emails
          $this->db->update("emails",array("data_type_indicator"=>$data_type),array("contact"=>$kols['id']));
          
          // kol phone numbers
          $this->db->update("phone_numbers",array("data_type_indicator"=>$data_type),array("contact"=>$kols['id']));
          
          // kol state licence
          $this->db->update("state_licenses",array("data_type_indicator"=>$data_type),array("contact"=>$kols['id']));
          
          // kol staffs
          $this->db->update("staffs",array("data_type_indicator"=>$data_type),array("contact"=>$kols['id']));
          
        }            
       
    }
    // update data type indicator for interaction data
    function update_data_type_indicator_for_interaction(){        
        $get = $this->db->get("interactions");
        foreach($get->result_array() as $row){
            $data_type = 'User Added';
            if($row['client_id']==1){
                $data_type = 'Aissel Analyst';
            }
            $this->db->update("interactions",array("data_type_indicator"=>$data_type),array("id"=>$row['id']));
        }
    }
    // update data type indicator for planning data
    function update_data_type_indicator_for_planning(){
        $get = $this->db->get("plan_details");
        foreach($get->result_array() as $row){
            $data_type = 'User Added';
            if($row['client_id']==1){
                $data_type = 'Aissel Analyst';
            }
            $this->db->update("plan_details",array("data_type_indicator"=>$data_type),array("id"=>$row['id']));
        }
    }
    // update data type indicator for objective data
    function update_data_type_indicator_for_objectives(){
        $get = $this->db->get("objectives");
        foreach($get->result_array() as $row){
            $data_type = 'User Added';
            if($row['client_id']==1){
                $data_type = 'Aissel Analyst';
            }
            $this->db->update("objectives",array("data_type_indicator"=>$data_type),array("id"=>$row['id']));
        }
    }
    // update data type indicator for key people
    function update_data_type_indicator_for_key_peoples(){
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $this->db->select(array("key_peoples.id","client_users.client_id"));
        $this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
        $this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
        $get = $this->db->get("key_peoples");
        foreach($get->result_array() as $row){
            $data_type = 'User Added';
            if($row['client_id']==1){
                $data_type = 'Aissel Analyst';
            }
            $this->db->update("key_peoples",array("data_type_indicator"=>$data_type),array("id"=>$row['id']));
        }
    }
    function update_data_type_indicator_for_affiliates_partnerships(){
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $this->db->select('client_users.client_id,affiliates_partnerships.id');
        $this->db->join('organizations','organizations.id=affiliates_partnerships.org_id','left');
        $this->db->join('organizations as o','o.id = affiliates_partnerships.sub_org_id','left');
        $this->db->join('client_users','client_users.id = o.created_by','left');        
        $arrResultSet = $this->db->get('affiliates_partnerships');
        foreach($arrResultSet->result_array() as $row){
            $data_type = 'User Added';
            if($row['client_id']==1){
                $data_type = 'Aissel Analyst';
            }
            $this->db->update("affiliates_partnerships",array("data_type_indicator"=>$data_type),array("id"=>$row['id']));
        }
    }
}
