<script type="text/javascript">
$(document).ready(function(){
	initialise();
});
</script>
<div id="kolsListingDiv">
<form name="searchFilterForm" method="post" id="searchFilterForm">
<div class="filterDiv1">
	<table class="filter_table table no_bottom_margin no">
		<tr>
			<td width="40%">Assigned</td>
			<td width="55%">
				<select name="view_type" id="viewType" class="form-control input_hight_for_filters"  onchange="doSearchFilter()">
					<?php if($this->common_helper->check_module("align_users")){ ?>
						<option value="1" <?php if($viewType == MY_RECORDS)echo 'selected="selected"';?>>My Contacts</option>
					<?php }?>
					<option value="2" <?php if($viewType == ALL_RECORDS)echo 'selected="selected"';?>>All Contacts</option>
				</select>
			</td>
			<td width="5%"></td>
		</tr>
		<tr>
			<td>Saved Filters</td>
			<td>
				<select name="saved_filter_id" id="savedFilterId" data-placeholder="Choose saved filters..." class="form-control input_hight_for_filters"  onchange="activeCustmFilters()">
					<option value="">Select Filter</option>
					<?php echo  $savedFilterId ;foreach($customFilters as $customFilter){ ?>
		 				<option value='<?php echo $customFilter['id'];?>' <?php if($savedFilterId == $customFilter['id']){ echo 'selected="selected"';}?> >
		 				<?php echo $customFilter['name'];?>
		 				</option>
					<?php }?>
				</select>
			</td>
			<td>
			<span class="glyphicon glyphicon glyphicon-save" onclick="save_filter();"></span>
			</td>
		</tr>
		<tr>
			<td>Profile Type</td>
			<td>
				<select name="profile_type" id="profileType" class="form-control input_hight_for_filters" onchange="doSearchFilter()">
						<option value="">All Profiles</option>
						<option value="Full Profile" <?php if($profileType == "Full Profile") echo "selected='selected'";?>>Full Profiles</option>
						<!-- <option value="Basic Plus" <?php if($profileType == "Basic Plus") echo "selected='selected'";?>>Basic+ Profiles</option> -->
						<option value="Basic" <?php if($profileType == "Basic") echo "selected='selected'";?>>Basic Profiles</option>
						<!-- <option value="Market Access" <?php if($profileType == "Market Access") echo "selected='selected'";?>>Market Access Profile</option>-->
						<option value="User Added" <?php if($profileType == "User Added") echo "selected='selected'";?>>User Added</option>
						<option value="Legacy" <?php if($profileType == "Legacy") echo "selected='selected'";?>>Legacy</option>
				</select>
			</td>
			<td></td>
		</tr>
	</table>
			<?php if(isset($selectedKols) && $selectedKols!=null){?>
			<table class="filter_table table no_bottom_margin no">
				<?php foreach($selectedKols as $id=>$name){?>
				<tr class="kol<?php echo $id;?>">
					<td width="45%">
						<input type="checkbox" name="kols[]" class="kolElement hideCheckbox" id="kol<?php echo $id?>" checked="checked" value="<?php echo $id?>" onclick="doSearchFilter1()" />&nbsp;<?php echo $name;?>
					</td>
					<td width="50%">
						<div class="progress no_bottom_margin">
						  <div class="progress-bar" role="progressbar" 
						  style="width:<?php if(isset($id)) echo round((1/1)*100); else echo 0;?>%;"
						  title="1(<?php echo round((1/1)*100);?>%)"
						  aria-valuenow="100" 
						  aria-valuemin="0" aria-valuemax="100">
						  </div>
						</div>
					</td>
					<td width="5%">
						1
					</td>
				</tr>
				<?php } ?>
			</table>
		<?php } ?>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="influence_kol_name" class="form-control input_hight_for_filters autocompleteInputBox" id="influenceKolName" value="" placeholder="Enter KTL Name" title="" />
		<input type="hidden" name="influence_kol_id" id="influenceKolId" value=""/>
	</div>
</div>
<!-- --------------------------Global Region-------------------------------------------------------------------------------------- -->
<a href="#global_regions_div"  data-toggle="collapse" aria-expanded="true" class="">Global Region</a>
<div class="filterDiv">
<div id="global_regions_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
				<input type="checkbox"  class="allrecords hideCheckbox" name="all_region_types" id="allRegionTypes" value="regionType" <?php if(isset($selectedGlobalRegions) && $selectedGlobalRegions!=null) echo ''; else echo "checked='checked'"?>/>
				All Regions 
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				  style="width: <?php if(isset($allRegionCount)) echo round(($allRegionCount/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="25" 
				  aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
				<?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		foreach($arrRegionsByKolsCount as $regionCountDetails){ 
			?>
			 	<?php if($regionCountDetails['global_region_id']>0 && $regionCountDetails['global_region_name']!=''){?>
				 	<tr class=" regionType<?php echo $regionCountDetails['global_region_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="global_region_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $regionCountDetails['global_region_id'];?>" value="<?php echo $regionCountDetails['global_region_id'];?>" 
							<?php
							if(in_array($regionCountDetails['global_region_id'],$selectedGlobalRegions)){
								echo 'checked="checked"';
								foreach (array_keys($selectedGlobalRegions,$regionCountDetails['global_region_id'], true) as $key) {
									unset($selectedGlobalRegions[$key]);
								}
							}?>
							/><?php echo $regionCountDetails['global_region_name'];?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$allRegionCount)*100)."%)";?>" 
				  						style="width: <?php if(isset($allRegionCount)) echo round(($regionCountDetails['count']/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td><?php echo $regionCountDetails['count'];?></td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedGlobalRegions) && $selectedGlobalRegions!=null){
				foreach($selectedGlobalRegions as $typeId=>$regionId){?>
				<tr class=" regionType<?php echo $regionId;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="global_region_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $regionId;?>" value="<?php echo $regionId;?>" checked="checked"/>
						<?php echo $arrRegionsByKolsCount[$regionId]['global_region_name'];?>
					</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  				title="<?php echo $arrRegionsByKolsCount[$regionId]['count']."(".round(($arrRegionsByKolsCount[$regionId]['count']/$allRegionCount)*100)."%)";?>"
				  				style="width: <?php if(isset($allRegionCount)) echo round(($arrRegionsByKolsCount[$regionId]['count']/$allRegionCount)*100); else echo 0;?>%;">
							</div>
						</div>
					</td>
					<td><?php if (array_key_exists($regionId, $arrRegionsByKolsCount)) echo $arrRegionsByKolsCount[$regionId]['count']; else echo 0;?></td>
				</tr>
			<?php 
				}}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
    	<input type="text" name="region_type" id="regionType" class="form-control input_hight_for_filters autocompleteInputBox" value="" placeholder="Enter Global Region" title="" />
		<input type="hidden" name="region_type_id" id="regionTypeId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Country-------------------------------------------------------------------------------------- -->
<a href="#countries_div"  data-toggle="collapse" aria-expanded="true" class="">Country</a>
<div class="filterDiv">
<div id="countries_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
				<input class="allrecords hideCheckbox" type="checkbox" name="all_countries" id="allCountries"   value="country" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> />
				All Countries
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		foreach($arrCountryByKolsCount as $countryCountDetails){ ?>
			 		<?php if($countryCountDetails['country']!=''){?>
				 	<tr class=" country<?php echo $countryCountDetails['country_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $countryCountDetails['country_id'];?>" value="<?php echo $countryCountDetails['country_id'];?>"  
							<?php
							if(in_array($countryCountDetails['country_id'],$selectedCountries)){
								echo 'checked="checked"';
								foreach (array_keys($selectedCountries,$countryCountDetails['country_id'], true) as $key) {
									unset($selectedCountries[$key]);
								}
							}
							?> 
							/><?php echo $countryCountDetails['country'];?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allCountryCount)*100)."%)";?>" 
				  						style="width:<?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td><?php echo $countryCountDetails['count'];?></td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedCountries) && $selectedCountries!=null){
				foreach($selectedCountries as $key=>$country_id){?>
				<tr class=" country<?php echo $country_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $country_id;?>" value="<?php echo $country_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrCountryByKolsCount[$country_id]['country'];?>
					</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  				title="<?php echo $arrCountryByKolsCount[$country_id]['count']."(".round(($arrCountryByKolsCount[$country_id]['count']/$allCountryCount)*100)."%)";?>"
				  				style="width: <?php if(isset($allCountryCount)) echo round(($arrCountryByKolsCount[$country_id]['count']/$allCountryCount)*100); else echo 0;?>%;">
							</div>
						</div>
					</td>
					<td><?php if (array_key_exists($country_id, $arrCountryByKolsCount)) echo $arrCountryByKolsCount[$country_id]['count']; else echo 0;?></td>
				</tr>
				<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="country" class="form-control input_hight_for_filters autocompleteInputBox" id="country" value="" placeholder="Enter Country" title=""/>
		<input type="hidden" name="country_id" id="countryId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Position-------------------------------------------------------------------------------------- -->
<a href="#position_div"  data-toggle="collapse" aria-expanded="true" class="">Position</a>
<div class="filterDiv">
<div id="position_div"  class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
				<input class="allrecords hideCheckbox" type="checkbox" name="all_positions" id="allPositions" value="position" <?php if(isset($selectedKolPositions) && $selectedKolPositions!=null) echo ''; else echo "checked='checked'"?> />
				All Positions
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allKolPositionCount)) echo $allKolPositionCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
				foreach($arrKolPositionsByKolsCount as $kolPositionCountDetails){?>
			 		<?php if($kolPositionCountDetails['title_id']!='' && $kolPositionCountDetails['title']!='' && $kolPositionCountDetails['title_id']>0){  ?>					 	
				 	<tr class=" kolPosition<?php echo $kolPositionCountDetails['title_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="kol_position_ids[]" class="kolTypeElement hideCheckbox" id="kolPosition<?php echo $kolPositionCountDetails['title_id'];?>" value="<?php echo $kolPositionCountDetails['title_id'];?>"  
									<?php 
									if(in_array($kolPositionCountDetails['title_id'],$selectedKolPositions)){
										echo 'checked="checked"';
										foreach (array_keys($selectedKolPositions,$kolPositionCountDetails['title_id'], true) as $key) {
											unset($selectedKolPositions[$key]);
										}
									}
									?>
							/><?php								
								echo $kolPositionCountDetails['title'];									
							?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $kolPositionCountDetails['count']."(".round(($kolPositionCountDetails['count']/$allKolPositionCount)*100)."%)";?>" 
				  						style="width: <?php if(isset($allKolPositionCount)) echo round(($kolPositionCountDetails['count']/$allKolPositionCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td><?php if(isset($kolPositionCountDetails['count'])) echo $kolPositionCountDetails['count']; else echo 0;?></td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedKolPositions) && $selectedKolPositions!=null){
				foreach($selectedKolPositions as $key=>$position_id){?>
				<tr class=" kolPosition<?php echo $position_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="kol_position_ids[]" class="countryElement hideCheckbox" id="position<?php echo $position_id;?>" value="<?php echo $position_id;?>"  checked="checked"/>
						<?php echo $arrKolPositionsByKolsCount[$position_id]['title'];?>
					</td>
				 	<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  				title="<?php echo $arrKolPositionsByKolsCount[$position_id]['count']."(".round(($arrKolPositionsByKolsCount[$position_id]['count']/$allKolPositionCount)*100)."%)";?>"
				  				style="width: <?php if(isset($allKolPositionCount)) echo round(($arrKolPositionsByKolsCount[$position_id]['count']/$allKolPositionCount)*100); else echo 0;?>%;">
							</div>
						</div>
					</td>
					<td>
					 <?php if (array_key_exists($position_id, $arrKolPositionsByKolsCount)) echo $arrKolPositionsByKolsCount[$position_id]['count']; else echo 0;?>
					 </td>
				</tr>
				<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
     	<input type="text" name="kol_position" class="form-control input_hight_for_filters autocompleteInputBox" id="kolPosition" value="" placeholder="Enter Position" title="" />
		<input type="hidden" name="kol_position_id" id="kolPositionId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Opt-in/Opt-out-------------------------------------------------------------------------------------- -->
<a href="#opt_in_div"  data-toggle="collapse" aria-expanded="true" class="">Opt-in/Opt-out</a>
<div class="filterDiv">
<div id="opt_in_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td class="textAlignRight" width="45%">
				<input class="allrecords hideCheckbox" type="checkbox" name="all_opt_in_out" id="allOptInOut" value="opt_inout" <?php if(isset($selectedOptInOut) && $selectedOptInOut!=null) echo ''; else echo "checked='checked'"?> />
				All
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allOptInOutCount)) echo $allOptInOutCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		foreach($arrOptInOutCount as $optInCountDetails){ ?>
		 	<?php if($optInCountDetails['opt_in_out_id']>0 && $optInCountDetails['opt_name']!=''){?>
				<tr class=" optType<?php echo $optInCountDetails['opt_in_out_id'];?>">
						<td class="textAlignRight">
						 			<input type="checkbox" name="opt_in_out_ids[]" class="optInOutElement hideCheckbox" id="optInOut<?php echo $optInCountDetails['opt_in_out_id'];?>" value="<?php echo $optInCountDetails['opt_in_out_id'];?>"  
									<?php
									if(in_array($optInCountDetails['opt_in_out_id'],$selectedOptInOut)){
										echo 'checked="checked"';
										foreach (array_keys($selectedOptInOut,$optInCountDetails['opt_in_out_id'], true) as $key) {
											unset($selectedOptInOut[$key]);
										}
									}
									?>
									/><?php echo $optInCountDetails['opt_name'];?>
						</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $optInCountDetails['count']."(".round(($optInCountDetails['count']/$allOptInOutCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allOptInOutCount)) echo round(($optInCountDetails['count']/$allOptInOutCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td>
						<?php if(isset($optInCountDetails['count'])) echo $optInCountDetails['count']; else echo 0;?>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
</div>
</div>
<!-- --------------------------Specialty------------------------------------------------------------------------------------- -->
<a href="#speciality_div"  data-toggle="collapse" aria-expanded="true" class="">Specialty</a>
<div class="filterDiv">
<div id="speciality_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
			<input class="allrecords hideCheckbox" type="checkbox" name="all_specialties" id="allSpecialties" value="specialty" <?php if(isset($selectedSpecialties) && $selectedSpecialties!=null) echo ''; else echo "checked='checked'"?> />
			All Specialties
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allSpecialtyCount)) echo $allSpecialtyCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsBySpecialtyCount as $specialtyCountDetails){?>
		 	<?php if($specialtyCountDetails['specialty']!='' && $specialtyCountDetails['specialty']!= 0){?>
				<tr class=" specialty<?php echo $specialtyCountDetails['specialty'];?>">
					 	<td class="textAlignRight">
			 				<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $specialtyCountDetails['specialty'];?>" value="<?php echo $specialtyCountDetails['specialty'];?>"  
							<?php
							if(in_array($specialtyCountDetails['specialty'],$selectedSpecialties)){
								echo 'checked="checked"';
								foreach (array_keys($selectedSpecialties,$specialtyCountDetails['specialty'], true) as $key) {
									unset($selectedSpecialties[$key]);
								}
							}
							?> 
							/><?php echo $specialtyCountDetails['specs'];?>
					 	</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $specialtyCountDetails['count']."(".round(($specialtyCountDetails['count']/$allSpecialtyCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allSpecialtyCount)) echo round(($specialtyCountDetails['count']/$allSpecialtyCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td>
						<?php if(isset($specialtyCountDetails['count'])) echo $specialtyCountDetails['count']; else echo 0;?>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedSpecialties) && $selectedSpecialties!=null){
				foreach($selectedSpecialties as $key=>$specialty_id){?>
				<tr class=" specialty<?php echo $specialty_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="specialty_ids[]" class="countryElement hideCheckbox" id="specialty<?php echo $specialty_id;?>" value="<?php echo $specialty_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsBySpecialtyCount[$specialty_id]['specs'];?>
					</td>
				 	<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  				title="<?php echo $arrKolsBySpecialtyCount[$specialty_id]['count']."(".round(($arrKolsBySpecialtyCount[$specialty_id]['count']/$allSpecialtyCount)*100)."%)";?>"
				  				style="width:<?php if(isset($allSpecialtyCount)) echo round(($arrKolsBySpecialtyCount[$specialty_id]['count']/$allSpecialtyCount)*100); else echo 0;?>%;">
							</div>
						</div>
					</td>
					<td>
					<?php if (array_key_exists($specialty_id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$specialty_id]['count']; else echo 0;?>
					</td>
				</tr>
				<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
     	<input type="text" name="specialty" class="form-control input_hight_for_filters autocompleteInputBox" id="specialty" value="" placeholder="Enter Specialty"/>
		<input type="hidden" name="specialty_id" id="specialtyId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Org Type------------------------------------------------------------------------------------- -->
<a href="#org_type_div"  data-toggle="collapse" aria-expanded="true" class="">Org Type</a>
<div class="filterDiv">
<div id="org_type_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
			<input class="allrecords hideCheckbox" type="checkbox" name="all_org_types" id="allOrgTypes" value="orgType" <?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null) echo ''; else echo "checked='checked'"?> />
			All Org Types
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allOrgTypeCount)) echo $allOrgTypeCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrOrgByTypeCount as $orgTypeCountDetails){ ?>
		 	<?php if($orgTypeCountDetails['org_type_id']>0){ ?>
			 	<tr class=" orgType<?php echo $orgTypeCountDetails['org_type_id'];?>">
			 		<td class="textAlignRight">
			 			<input type="checkbox" name="org_type_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>" value="<?php echo $orgTypeCountDetails['org_type_id'];?>"  
						<?php
						if(in_array($orgTypeCountDetails['org_type_id'],$selectedOrgTypes)){
							echo 'checked="checked"';
							foreach (array_keys($selectedOrgTypes,$orgTypeCountDetails['org_type_id'],true) as $key) {
								unset($selectedOrgTypes[$key]);
							}
						}
						?>
						/><?php echo $orgTypeCountDetails['type'];?>
			 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $orgTypeCountDetails['count']."(".round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allOrgTypeCount)) echo round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
						</td>
						<td>
						<?php if(isset($orgTypeCountDetails['count'])) echo $orgTypeCountDetails['count']; else echo 0;?>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null){
				foreach($selectedOrgTypes as $typeId=>$org_type_id){
					?>
				<tr class=" orgType<?php echo $org_type_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="org_type_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $org_type_id;?>" value="<?php echo $org_type_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrOrgByTypeCount[$org_type_id]['type'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrOrgByTypeCount[$org_type_id]['count']."(".round(($arrOrgByTypeCount[$org_type_id]['count']/$allOrgTypeCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allOrgTypeCount)) echo round(($arrOrgByTypeCount[$org_type_id]['count']/$allOrgTypeCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if (array_key_exists($org_type_id, $arrOrgByTypeCount)) echo $arrOrgByTypeCount[$org_type_id]['count']; else echo 0;?>
				  				</div>
							</div>
					</td>
				</tr>
			<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn">
	       	 <i class="glyphicon glyphicon-search"></i>
	        </button>
     	</div>
      	<input type="text" name="org_type" class="form-control input_hight_for_filters autocompleteInputBox" id="orgType" value="" placeholder="Enter Org Type"/>
		<input type="hidden" name="org_type_id" id="orgTypeId" value="" />
    </div>
</div>
</div>
<!-- --------------------------State------------------------------------------------------------------------------------- -->
<a href="#state_div"  data-toggle="collapse" aria-expanded="true" class="">State</a>
<div class="filterDiv">
<div id="state_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
				<input class="allrecords hideCheckbox" type="checkbox" name="all_states" id="allStates"   value="state" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> />
				All States
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByStateCount as $key=>$arrStateCountDetails){ ?>
		 	<?php if($arrStateCountDetails['state']!='' && $arrStateCountDetails['state_id']>0){?>
		 	<tr class=" state<?php echo $arrStateCountDetails['state_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $arrStateCountDetails['state_id'];?>" value="<?php echo $arrStateCountDetails['state_id'];?>"  
					<?php
					if(in_array($arrStateCountDetails['state_id'],$selectedStates)){
						echo 'checked="checked"';
						foreach (array_keys($selectedStates,$arrStateCountDetails['state_id'],true) as $key) {
							unset($selectedStates[$key]);
						}
					}
					?> 
					/><?php echo $arrStateCountDetails['state'];?>
		 		</td>
		 		<td>
		 			<div class="progress no_bottom_margin">
		  				<div class="progress-bar" role="progressbar" 
		  						 title="<?php echo $arrStateCountDetails['count']."(".round(($arrStateCountDetails['count']/$allStateCount)*100)."%)";?>"
		  						style="width: <?php if(isset($allStateCount)) echo round(($arrStateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"
		  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
		  				</div>
					</div>
				</td>
				<td>
				<?php if(isset($arrStateCountDetails['count'])) echo $arrStateCountDetails['count']; else echo 0;?>
				</td>
			</tr>
		<?php $i++; if($i>3) break; }}?>
		<?php if(isset($selectedStates) && $selectedStates!=null){
			foreach($selectedStates as $typeId=>$state_id){
					?>
				<tr class=" state<?php echo $state_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="state_ids[]" class="hideCheckbox" id="state<?php echo $state_id;?>" value="<?php echo $state_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsByStateCount[$state_id]['state'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrKolsByStateCount[$state_id]['count']."(".round(($arrKolsByStateCount[$state_id]['count']/$allStateCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allStateCount)) echo round(($arrKolsByStateCount[$state_id]['count']/$allStateCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
					</td>
					<td>
					<?php if (array_key_exists($state_id, $arrKolsByStateCount)) echo $arrKolsByStateCount[$state_id]['count']; else echo 0;?>
					</td>
				</tr>
		<?php }
		}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
     	<input type="text" name="state_name" id="stateName" class="form-control input_hight_for_filters autocompleteInputBox" value="" placeholder="Enter State"/>
		<input type="hidden" id="state_id" value='' name="state_id">
    </div>
</div>
</div>
<!-- --------------------------Lists------------------------------------------------------------------------------------- -->
<?php if($this->common_helper->check_module("my_list_kols")){?>
<a href="#list_div"  data-toggle="collapse" aria-expanded="true" class="">List</a>
<div class="filterDiv">
<div id="list_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
			<input class="allrecords hideCheckbox" type="checkbox" name="all_events" id="allLists" value="list" <?php if(isset($selectedLists) && $selectedLists!=null) echo ''; else echo "checked='checked'"?> />
			All Lists
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				  style="width: <?php if(isset($allListCount)) echo round(($allListCount/$allListCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			 <?php if(isset($allListCount)) echo $allListCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByListCount as $listCountDetails){ ?>
		 	<?php if($listCountDetails['list_name']!=''){?>
		 	<tr class=" list<?php echo $listCountDetails['list_name_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo $listCountDetails['list_name_id'];?>" value="<?php echo $listCountDetails['list_name_id'];?>" 
		 				<?php 
		 				if(in_array($listCountDetails['list_name_id'],$selectedLists)){
		 					echo 'checked="checked"';
		 					foreach (array_keys($selectedLists,$listCountDetails['list_name_id'],true) as $key) {
		 						unset($selectedLists[$key]);
		 					}
		 				}
						?> 
					/><?php echo $listCountDetails['list_name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $listCountDetails['count']."(".round(($listCountDetails['count']/$allListCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allListCount)) echo round(($listCountDetails['count']/$allListCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				</div>
				</div>
			</td>
			<td>
			<?php if(isset($listCountDetails['count'])) echo $listCountDetails['count']; else echo 0;?>
			</td>
		</tr>
		<?php $i++; if($i>3) break; }}?>
		<?php if(isset($selectedLists) && $selectedLists!=null){
			foreach($selectedLists as $typeId=>$list_id){
					?>
				<tr class=" list<?php echo $list_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="list_ids[]" class="hideCheckbox" id="list<?php echo $list_id;?>" value="<?php echo $list_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsByListCount[$list_id]['list_name'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrKolsByListCount[$list_id]['count']."(".round(($arrKolsByListCount[$list_id]['count']/$allListCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allOrgCount)) echo round(($arrKolsByListCount[$list_id]['count']/$allListCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
					</td>
					<td>
					<?php if (array_key_exists($list_id, $arrKolsByListCount)) echo $arrKolsByListCount[$list_id]['count']; else echo 0;?>
					</td>
				</tr>
			<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="list_name" class="form-control input_hight_for_filters autocompleteInputBox" id="listName" value="" placeholder="Enter List"/>
		<input type="hidden" name="list_id" id="listNameId" value="" />
    </div>
</div>
</div>
<?php }?>
<!-- --------------------------Organization------------------------------------------------------------------------------------- -->
<a href="#org_div"  data-toggle="collapse" aria-expanded="true" class="">Organization</a>
<div class="filterDiv">
<div id="org_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
				<input class="allrecords hideCheckbox" type="checkbox" name="all_orgs" id="allOrgs" value="organization" <?php if(isset($selectedOrgs) && $selectedOrgs!=null) echo ''; else echo "checked='checked'"?> />
				All Organizations
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allOrgCount)) echo round(($allOrgCount/$allOrgCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			<?php if(isset($allOrgCount)) echo $allOrgCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByOrgCount as $orgCountDetails){?>
		 	<?php
		 		if($orgCountDetails['name']!=''){?>
		 	<tr class=" org<?php echo $orgCountDetails['org_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="organization_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgCountDetails['org_id'];?>" value="<?php echo $orgCountDetails['org_id'];?>"  
						<?php
						if(in_array($orgCountDetails['org_id'],$selectedOrgs)){
							echo 'checked="checked"';
							foreach (array_keys($selectedOrgs,$orgCountDetails['org_id'],true) as $key) {
								unset($selectedOrgs[$key]);
							}
						}
						?>
							/><?php echo $orgCountDetails['name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $orgCountDetails['count']."(".round(($orgCountDetails['count']/$allOrgCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allOrgCount)) echo round(($orgCountDetails['count']/$allOrgCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				</div>
				</div>
			</td>
			<td>
			<?php if(isset($orgCountDetails['count'])) echo $orgCountDetails['count']; else echo 0;?>
			</td>
		</tr>
			<?php $i++; if($i>3) break; }}?>			
			<?php if(isset($selectedOrgs) && $selectedOrgs!=null){
				foreach($selectedOrgs as $typeId=>$org_id){
					?>
				<tr class=" org<?php echo $org_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="organization_ids[]" class="orgElement hideCheckbox" id="org<?php echo $org_id;?>" value="<?php echo $org_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsByOrgCount[$org_id]['name'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrKolsByOrgCount[$org_id]['count']."(".round(($arrKolsByOrgCount[$org_id]['count']/$allOrgCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allOrgCount)) echo round(($arrKolsByOrgCount[$org_id]['count']/$allOrgCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
					</td>
					<td>
					<?php if (array_key_exists($org_id, $arrKolsByOrgCount)) echo $arrKolsByOrgCount[$org_id]['count']; else echo 0;?>
					</td>
				</tr>
			<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="organization" class="form-control input_hight_for_filters autocompleteInputBox" id="organization" value="" placeholder="Enter Organization"/>
		<input type="hidden" name="organization_id" id="organizationId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Education------------------------------------------------------------------------------------- -->
<a href="#edu_div"  data-toggle="collapse" aria-expanded="true" class="">Education</a>
<div class="filterDiv">
<div id="edu_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr >
			<td width="45%">
			<input class="allrecords hideCheckbox" type="checkbox" name="all_edus" id="allEdus" value="education" <?php if(isset($selectedEdus) && $selectedEdus!=null) echo ''; else echo "checked='checked'"?> />
			All Educations
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allEduCount)) echo round(($allEduCount/$allEduCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			 <?php if(isset($allEduCount)) echo $allEduCount; else echo 0;?>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByEduCount as $eduCountDetails){ ?>
		 	<?php if($eduCountDetails['institute_id']!=''){?>
		 	<tr class=" education<?php echo $eduCountDetails['institute_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="education_ids[]" class="hideCheckbox" id="education<?php echo $eduCountDetails['institute_id'];?>" value="<?php echo $eduCountDetails['institute_id'];?>"  
					<?php if(isset($selectedEdus) && sizeof($selectedEdus)>0 && $selectedEdus!=null){
						if(in_array($eduCountDetails['institute_id'],$selectedEdus)){
							echo 'checked="checked"';
							foreach (array_keys($selectedEdus,$eduCountDetails['institute_id'],true) as $key) {
								unset($selectedEdus[$key]);
							}
						}
					}?>
					/><?php echo $eduCountDetails['institute_name'];?>
		 		</td>
		 		<td>
		 			<div class="progress no_bottom_margin">
		  				<div class="progress-bar" role="progressbar" 
		  						title="<?php echo $eduCountDetails['count']."(".round(($eduCountDetails['count']/$allEduCount)*100)."%)";?>"
		  						style="width: <?php if(isset($allEduCount)) echo round(($eduCountDetails['count']/$allEduCount)*100); else echo 0;?>%;"
		  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
		  				</div>
					</div>
				</td>
				<td>
				<?php if(isset($eduCountDetails['count'])) echo $eduCountDetails['count']; else echo 0;?>
				</td>
			</tr>
			<?php $i++; if($i>3) break; }}?>
			<?php if(isset($selectedEdus) && $selectedEdus!=null){
				foreach($selectedEdus as $typeId=>$education_id){
					?>
				<tr class=" education<?php echo $education_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="education_ids[]" class="hideCheckbox" id="education<?php echo $education_id;?>" value="<?php echo $education_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsByEduCount[$education_id]['institute_name'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrKolsByEduCount[$education_id]['count']."(".round(($arrKolsByEduCount[$education_id]['count']/$allEduCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allOrgCount)) echo round(($arrKolsByEduCount[$education_id]['count']/$allEduCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
					</td>
					<td>
					<?php if (array_key_exists($education_id, $arrKolsByEduCount)) echo $arrKolsByEduCount[$education_id]['count']; else echo 0;?>
					</td>
				</tr>
			<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="education" class="form-control input_hight_for_filters autocompleteInputBox" id="education" value="" placeholder="Enter Education"/>
      	<input type="hidden" name="education_id" id="educationId" value="" />
    </div>
</div>
</div>
<!-- --------------------------Event------------------------------------------------------------------------------------- -->
<?php if($this->common_helper->check_module("events")){?>
<a href="#event_div"  data-toggle="collapse" aria-expanded="true" class="">Event</a>
<div class="filterDiv">
<div id="event_div"   class="collapse in" aria-expanded="true">
	<table class="filter_table table no_bottom_margin no">
		<tr class="filter_fonts">
			<td width="45%">
			<input class="allrecords hideCheckbox" type="checkbox" name="all_events" id="allEvents" value="event" <?php if(isset($selectedEvents) && $selectedEvents!=null) echo ''; else echo "checked='checked'"?> />
			All Events
			</td>
			<td width="50%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allEventCount)) echo round(($allEventCount/$allEventCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  </div>
				</div>
			</td>
			<td width="5%">
			 <?php if(isset($allEventCount)) echo $allEventCount; else echo 0;?>
			</td>
		</tr>
		<?php if(isset($selectedEvents) && $selectedEvents!=null){
			foreach($selectedEvents as $typeId=>$event_id){?>
				<tr class="filter_fonts event<?php echo $event_id;?>">
			 		<td class="textAlignRight">
						<input type="checkbox" name="event_ids[]" class="hideCheckbox" id="event<?php echo $event_id;?>" value="<?php echo $event_id;?>"  checked="checked"/>&nbsp;
						<?php echo $arrKolsByEventCount[$event_id]['event_name'];?>
					</td>
			 		<td>
			 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrKolsByEventCount[$event_id]['count']."(".round(($arrKolsByEventCount[$event_id]['count']/$allEventCount)*100)."%)";?>"
				  						 style="width: <?php if(isset($allEventCount)) echo round(($arrKolsByEventCount[$event_id]['count']/$allEventCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				</div>
							</div>
					</td>
					<td>
					<?php if (array_key_exists($event_id, $arrKolsByEventCount)) echo $arrKolsByEventCount[$event_id]['count']; else echo 0;?>
					</td>
				</tr>
			<?php }
			}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" >
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" name="event_name" class="form-control input_hight_for_filters autocompleteInputBox" id="eventName" value="" placeholder="Enter Event"/>
		<input type="hidden" name="event_id" id="eventId" value="" />
    </div>
</div>
</div>
<?php } ?>
</form>
</div>