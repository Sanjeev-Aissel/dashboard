<?php
$kolNameAutoCompleteOptionsSearchTop = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {submitSearch('top');}";
?>
<style type="text/css">
	#upgradeBox ul{
		margin:0px;
		list-style:none;
	}
	#kol_name_upgrade,#profile_type{
		width:200px;
	}
	
</style>
<script type="text/javascript">
$(document).ready(function(){
	var kolNameUpgradeAutoComplete = {
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
			<?php echo $kolNameAutoCompleteOptionsSearchTop;?>,
					onSelect : function(event, ui) {
						var kolId = $(event).children('.id1').html();
						var selText = $(event).children('.kolName').html();
						var profile_type = $(event).children('.profile_type').html();
						selText=selText.replace(/\&amp;/g,'&');
						$('#upgradeBox #kol_name_upgrade').val(selText);
						$('#upgradeBox #kol_id').val(kolId);
						adjustProfileTypeDropdown(profile_type);
				}
		};
	var autoSearchDataDock	= $('#upgradeBox #kol_name_upgrade').autocomplete(kolNameUpgradeAutoComplete);
});

function adjustProfileTypeDropdown(profile_type){
	//$("#profile_type").html('<option value="">Select</option><option value="Basic">Basic</option><option value="Basic Plus">Basic Plus</option><option value="Full Profile">Full Profile</option>');
	$("#profile_type option[value='Full Profile']").removeAttr("disabled");
	$("#profile_type option[value='Basic Plus']").removeAttr("disabled");
	$("#profile_type option[value='Basic']").removeAttr("disabled");
	if(profile_type == 'Full Profile'){
		$("#profile_type option[value='Full Profile']").attr("disabled","disabled");
		$("#profile_type option[value='Basic Plus']").attr("disabled","disabled");
		$("#profile_type option[value='Basic']").attr("disabled","disabled");
	}
	if(profile_type == 'Basic Plus'){
		$("#profile_type option[value='Basic Plus']").attr("disabled","disabled");
		$("#profile_type option[value='Basic']").attr("disabled","disabled");
	}
	if(profile_type == 'Basic'){
		$("#profile_type option[value='Basic']").attr("disabled","disabled");
	}
	$("#current_profile_type").html(profile_type);

	if(profile_type=='Full Profile'){
		$('#upgradeForm input[type="button"]').attr('disabled','disabled');
	}
}
</script>

<div class="msgBox"></div>
<div id='upgradeBox'>
	<form action="" name="upgradeForm" id="upgradeForm">
		<input type='hidden' value='' id='kol_id' />
		<ul>
			<li>
				<label><?php echo lang("KOL");?> Name :</label>
				<input type='text' value='' id='kol_name_upgrade' class="autocompleteInputBox"/>
			</li>
			<li>
				<label>Profile Type :</label>
				<span id="current_profile_type"></span>
			</li>
			<li>
				<label>Upgrade To :</label>
				<select id="profile_type">
					<option value="">Select</option>
					<option value="Full Profile">Full Profile</option>
					<option value="Basic Plus">Basic Plus</option>
					<option value="Basic">Basic</option>
				</select>
			</li>
			<li>
				<input type='button' value='Submit' onclick='saveUpgradeRequest();' style="margin-left: 120px;"/>
			</li>
		</ul>
	</form>
</div>