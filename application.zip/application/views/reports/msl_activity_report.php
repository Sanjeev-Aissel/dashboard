<?php 

	$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<script type="text/javascript">

$(document).ready(function(){
	//listMslActivityData();
}); var filters;
    var lastRequestXHR;
    function cancelLastRequest(){
            lastRequestXHR.abort();
            $("#applyFilter").val("Apply Filters");
            $("#applyFilter").attr("onclick","reloaReport();");
    }
function filterCurrentReport(data){
	listMslActivityData(data);
}

function listMslActivityData(data){
	$('#gridContainer').html('<div id="listMslActivityPage"></div><table id="listMslActivityResultSet"></table>');
	var ele=document.getElementById('gridContainer');
	var gridWidth=ele.clientWidth;
	jqgridMinWidth = gridWidth;
	//var ele=document.getElementById('test');
	//var gridWidth=ele.clientWidth - 15;
	
//	gridWidth+=10;
	jQuery("#listMslActivityResultSet").jqGrid({
		url:base_url+'reports/msl_activity_grid_data/',
		datatype: "json",
	   	colNames:['Id','MSL/MML Name','Interactions','UOQ','Medical Insight', 'Speaker Evaluation','Sphere of Influence'],
	   	colModel:[
			{name:'id',index:'id', hidden:true,width:50},
			{name:'name',index:'name',width:200},
			{name:'intc',index:'intc', width:70,sorttype:'int', resizable:false,search:false},
                        
	   		{name:'uoq',index:'uoq',width:100,sorttype:'int', resizable:false,search:false},
	   		{name:'mic',index:'mic',width:100,sorttype:'int', resizable:false,search:false},
	   		{name:'speaker_eval',index:'speaker_eval',width:100,sorttype:'int', resizable:false,search:false},
	   		{name:'survey',index:'survey',width:100,sorttype:'int', resizable:false,search:false},
//	   		{name:'coc',index:'coc',width:100,sorttype:'int', resizable:false}
	   	],
		postData:data,
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#listMslActivityPage',
	   	mtype: "POST",
	   	sortname: 'name',
	    viewrecords: true,
	    sortorder: "desc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"MSL Activity",
            loadBeforeSend: function (xhr) { 
	    	lastRequestXHR = xhr; 
	    },
	    grouping: false, 
   		rowList:paginationValues
	});
        $("#applyFilter").val("Apply Filters");
	    	$("#applyFilter").attr("onclick","reloaReport();");
		 var postParams = $('#listMslActivityResultSet').getGridParam("postData");
            filters=data;
                postParams = JSON.stringify(data);
               
	jQuery("#listMslActivityResultSet").jqGrid('navGrid','#listMslActivityPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#listMslActivityResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#listMslActivityResultSet").jqGrid('navButtonAdd',"#listMslActivityPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	//jQuery("#listMslActivityResultSet").jqGrid('setGridWidth',gridWidth); 
	jQuery("#listMslActivityResultSet").jqGrid('setGridWidth',gridWidth); 
	jqgridIds	= new Array('listMslActivityResultSet');
        <?php if (!IS_IPAD_REQUEST) { ?>
        var buttonsText = "<div class='title-bar-actions'>";
		buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel();return false;' >	<a rel='tooltip' href='#' title='Export MSL Detail into Excel format'>&nbsp;</a>	</div>";
		buttonsText += "</div>";
        <?php } else { ?>
        var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
            buttonsText += '<input type="button" value="Export excel as email" onclick="export_excel();" class="toggle-button" style="margin-top:-3px;">';
            buttonsText += "</div>";
        <?php } ?>
	$("#gridContainer .ui-jqgrid-titlebar").append(buttonsText);
}
function export_excel(){

 var postParams = $('#listMslActivityResultSet').getGridParam("postData");
 $("#filterData").val(JSON.stringify(postParams));
            var excelFilters = '';


            

        

                $(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

                    if($(this).val() != ''){

                        var filterName = $(this).attr('name');

                        var filterValue = $(this).val();

                        excelFilters += filterName+" : "+filterValue+",";

                    }
//                                        alert(excelFilters);

                });

                //$("#excel-filters").val(excelFilters);

                var selectedOPtion = $(".ui-pg-selbox").val();

                $(".ui-pg-selbox option:last").attr('selected','selected');

                $('.ui-pg-selbox').trigger('change');

                if($("#listMslActivityResultSet").html() != null )

                    var arrIds = jQuery("#listMslActivityResultSet").jqGrid('getDataIDs');

                else

                    var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//            if($('#orgIntaerctionContainer').css('display')!='block'){
//
//            
//
//                $('#ids').val(arrIds);
//
//            }


            


        
               $('#ids').val(arrIds);
            $("#excel-filters").val(excelFilters);

        //    return false;
    <?php if (!IS_IPAD_REQUEST) { ?>
            $('#export').submit();
    <?php } else { ?>
              var data= $("#export").serialize();
                   sendMail(data);
    <?php } ?>

            $(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

            $('.ui-pg-selbox').trigger('change');

        }
function sendMail(data){
        alert("Excel has been mailed successfully.");
      $.ajax({
         
                    url: "<?php echo base_url()?>reports/send_email_for_export_reports/MSL_Activity",
                            dataType: "json",
                            data: data,
                            type: "POST",
                            success: function (responseText) {
                           
                            },
                            complete: function () {
                           
                            }
                    });               
    }

</script>
<style>
	.refinedByWrapper{
		float: unset;
	}
        
.title-bar-actions{
    float: right;
    margin-right: 8px;
    margin-top: -6px;
}
  <?php if(IS_IPAD_REQUEST == 1){ ?>
		.tabsContainer li{
			font-size: 12px;
		}
        #load_listMslActivityResultSet{
            display:none !important;
        }
         .tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
        <?php } ?>
</style>
<form action="<?php echo base_url()?>reports/msl_export/" method='post' id="export">
		<input type="hidden" id="ids" name="msl_activity" value=""></input>
                <input type="hidden" id="filterData" name="filter" value=""></input>
                <!--<input type="hidden" name="filters" value="" id="excel-filters" />-->
	</form>
<?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a>
	</div>
<?php }?>
<div class="tabsWrapper" id="test">
		<ul class="tabsContainer">
			<li class="current" name="tab0"><a id="list" href="#">Report</a></li>
<!--			<li name="tab1"><a id="report" href="#">Chart</a></li>-->
		</ul>
		<div class="tabsContent">
			<div class="tab0 tabContent" style="display:block;">
				<div id="gridTabContainer" style="margin-top: 20px;">
					<div class="gridWrapper" id="gridContainer">
						
						<div id="listMslActivityPage">Select Filters for report</div>
				
						<table id="listMslActivityResultSet"></table>
				
					</div>
				</div>
			</div>
		</div>
	</div>