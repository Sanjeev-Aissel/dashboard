<?php
$kolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jquery_validator/css/screen.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jquery_validator/dist/jquery.validate.js"></script>
<?php
$queued_js_scripts = array('js/jquery.autocomplete',		
							'datepicker/js/daterangepicker.jQuery',
							'datepicker/js/date');    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.deleteIcon{
    height: 20px;
    width: 20px;
}
</style>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading align_center">
			<?php if($arrPayment['kol_id']>0)echo 'Update Payment Details';else echo 'Add Payment';?>
		</div>
		<div class="panel-body">
			<div class="col-md-12 planMsgBox alert alert-success" role="alert"></div>
			<form action=""   method="post" id="paymentForm" name="paymentForm" class="validateForm">
				<input type="hidden" name="payment_id" id="PaymentId" value="<?php echo $arrPayment['id'];?>"/>
				<div class="form-group row">
					<label class="col-sm-1 align_right">KTL Name:<span class="required">*</span></label>
					<div class="col-sm-3">
		    			<input type="text" class="required autocompleteInputBox form-control" id="kolName" name="kol_name" value="<?php  if($arrPayment['kol_name']!='') echo $arrPayment['kol_name'];if(isset($kol_name)) echo $kol_name;?>" <?php if($arrPayment['kol_name']!='') echo 'readonly="readonly"';?>/>
						<input type="hidden" name="kol_id" id="kolId" value="<?php if($arrPayment['kol_id']!=''){ echo $arrPayment['kol_id']; }else{if(isset($kolId)) echo $kolId;}?>"/>
						<input type="hidden" name="kol_name_of_auto" id="kolNameForAuto" value="<?php if($arrPayment['kol_name']!='') echo $arrPayment['kol_name'];if(isset($kol_name)) echo $kol_name;?>"/>
					</div>
			    	<label class="col-sm-1 align_right">Specialty:</label>
					<div class="col-sm-3">
						  <input type="text" class="form-control" name="speciality" value="<?php if($arrPayment['specialty_name']!=''){ echo $arrPayment['specialty_name']; }?>" id="speciality" readonly="readonly"/>
						  <input type="hidden" name="speciality_id" id="speciality_id" value="<?php if($arrPayment['specialty_id']!=''){ echo $arrPayment['specialty_id']; }?>"/>
			    	</div>
			    	<label class="col-sm-1 align_right">Title:</label>
					<div class="col-sm-3">
						  <input type="text" class="form-control" name="title" value="<?php if($arrPayment['title_name']!=''){ echo $arrPayment['title_name']; }?>" id="title" readonly="readonly"/>
						  <input type="hidden" name="title_id" id="title_id" value="<?php if($arrPayment['title_id']!=''){ echo $arrPayment['title_id']; }?>"/>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-1 align_right">Date:<span class="required">*</span></label>
					<div class="col-sm-3">
						  <input type="text"  class="required form-control" id="paymentDate" name="date" value="<?php if($arrPayment['date']!='') echo $arrPayment['date'];?>" class="required"/>
			    	</div>
			    	<label class="col-sm-1 align_right">Requested By:<span class="required">*</span></label>
					<div class="col-sm-3">
						<select name="requested_by" id="requestedBy" class="required form-control" >
							<option value="">--Select--</option>
							<?php foreach($arrPaymentRequestBy as $key => $value){ 
								if($arrPayment['requested_by'] == $key){ ?>
									<option value="<?php echo $key;?>" selected="selected"><?php echo $value;?></option>
								<?php }else{?>	
									<option value="<?php echo $key;?>"><?php echo $value;?></option>
							<?php } }?>
						</select>
					</div>
			    	<label class="col-sm-1 align_right">Paid By:<span class="required">*</span></label>
					<div class="col-sm-3">
						<select name="paid_by" id="paid_by" class="required form-control">
							<option value="">--Select--</option>
							<?php foreach($arrPaymentPaidBy as $key => $value){
									if($arrPayment['paid_by'] == $key){ ?>
										<option value="<?php echo $key;?>" selected="selected"><?php echo $value;?></option>
								<?php }else{?>	
								<option value="<?php echo $key;?>"><?php echo $value;?></option>
							<?php }}?>
						</select>
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-1 align_right">Reason:</label>
					<div class="col-sm-11">
						  <textarea class="form-control" id="notes" name="reason" rows="2"><?php if(isset($arrPayment['reason'])) echo $arrPayment['reason'];?></textarea>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-1 align_right">Payment:</label>
					<input type="hidden" name="no_of_fileds" id="noOfFields" value="<?php if(isset($noOfFields)) echo $noOfFields;else echo 1; ?>"/>
					<div class="col-sm-11">
						<table class="table no_border" id="payment">
							<tr>
								<td width="32%">
									<label>Type:<span class="required">*</span></label>
								</td>
								<td width="32%">
									<label>Currency:<span class="required">*</span></label>
								</td>
								<td width="32%">
									<label>Amount:<span class="required">*</span></label>
								</td>
								<td width="4%">	
									<div class="actionIcon addIcon" id="addMoreAuthors" onclick="showNextFields()" title="Add Another Author">
										<a href="#" >&nbsp;</a>
									</div>
								</td>
							</tr>
							<tr id="amount1">
								<td width="32%">
									<select name="type[]" id="type" class="form-control required">
										<option value="">Select</option>
										<?php
										foreach($arrPaymentTypes as $key=>$value){
												if($arrPayment['arrTypesAndAmount'][0]['type']==$key){?>
												<option value="<?php echo $key ?>" selected="selected"><?php echo $value ?></option>
										<?php }else{?>
											<option value="<?php echo $key ?>"><?php echo $value ?></option>
										<?php } }?>
									</select>
								</td>
								<td width="32%">
									<select name="currency[]" id="currency" class="form-control required" >
										<option value="">Select</option>
											<?php
										foreach($arrPaymentCurrencies as $key=>$value){
												if($arrPayment['arrTypesAndAmount'][0]['currency']==$key){?>
												<option value="<?php echo $key ?>" selected="selected"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
										<?php }else{?>
											<option value="<?php echo $key ?>"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
										<?php } }?>
									</select>
								</td>
								<td width="32%">
									<input type="text" name="amount[]" value="<?php if($arrPayment['arrTypesAndAmount']!='') echo $arrPayment['arrTypesAndAmount'][0]['indAmount'];?>"  id="amount" class="form-control totalAmount required" maxlength="8" >
								</td>
								<td width="4%">	
								</td>
							</tr>
							<?php $arrLength=sizeof($arrPayment['arrTypesAndAmount']);
							if($arrLength>1){
								for($i=1;$i<$arrLength;$i++){?>
							<tr>
								<td width="32%">
									<select name="type[]" id="type" class="form-control required">
										<option value="">Select</option>
										<?php
										foreach($arrPaymentTypes as $key=>$value){?>
											<option value="<?php echo $key ?>" <?php if($arrPayment['arrTypesAndAmount'][$i]['type']==$key){ echo 'selected="selected"';}?>>
												<?php echo $value ?>
											</option>
										<?php }?>
									</select>
								</td>
								<td width="32%">
									<select name="currency[]" id="currency" class="form-control required" >
										<option value="">Select</option>
											<?php
										foreach($arrPaymentCurrencies as $key=>$value){
											if($arrPayment['arrTypesAndAmount'][$i]['currency']==$key){?>
												<option value="<?php echo $key ?>" selected="selected"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
										<?php }else{?>
											<option value="<?php echo $key ?>"><?php echo $value['currency_name'].' - '.$value['currency_symbol']; ?></option>
										<?php } }?>
									</select>
								</td>
								<td width="32%">
									<input type="text" name="amount[]" value="<?php if($arrPayment['arrTypesAndAmount']!='') echo $arrPayment['arrTypesAndAmount'][$i]['indAmount'];?>"  id="amount" class="form-control totalAmount required" maxlength="8" >
								</td>
								<td width="4%">	
									<img onclick="deleteAmount(this)" class="deleteIcon" alt="add" title="Delete" src="<?php echo base_url()?>assets/images/delete_active.png"></img>
								</td>
							</tr>
							<?php }
							}?>
						</table>
			    	</div>
				</div>
				<div class="form-group row" style="text-align: center;">
			   		<a type="button" onclick="savePayement();return false;" class="btn btn-primary" id="savePaymentButton">Save</a>
			    	<a type="button" onclick="goBack();return false;" class="btn btn-primary">Cancel</a>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
var kolNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/kols/get_kol_names_for_all_autocomplete/1',
		onSelect: function(event, ui) { 
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			selText=selText.replace(/\&amp;/g,'&');
			selText=selText.replace(/\&nbsp;/g,'');
			$('#kolName').val(selText);
			$('#kolId').val(kolId);
			$('#kolNameForAuto').val(selText);
			getKolOtherDetails();
		 },
		<?php echo $kolAutoCompleteOptions;?>,
	};

var validationRules	=  {
		kol_name: {
			required:true			
		}		
	};
	var validationMessages = {
			kol_name: {
			number: "required"
		}
	};
$(document).ready(function () {
	a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
	$('div.planMsgBox').hide();
	$('#paymentDate').datepicker({
		dateFormat: 'mm/dd/yy',
		maxDate: new Date,
		onSelect: function(dateText, inst) {
			$("#paymentDate").removeClass("error");
			$("#paymentDate").next().remove();
	    }
	});
	$('#paymentDate').focus(function(){
		$('table.ui-datepicker-calendar').show();
	});
	$("#paymentForm").validate({
		onkeyup:false,
		rules: validationRules,
		messages: validationMessages
	});
	$(document).on('input','.totalAmount',function(){
		  this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
	});
});
function showNextFields(){
	var no_of_fields = $('#noOfFields').val();
	no_of_fields = parseInt(no_of_fields)+1;
	$('#noOfFields').val(no_of_fields);
	$('#payment').append("<tr>"+$('#amount1').html()+"</tr>");
	
	var lastTypeName1 = "type"+no_of_fields;
	$('#payment tr:last td:eq(0) select').attr('name','type[]');
	$('#payment tr:last td:eq(0) select').attr('id',lastTypeName1);
	$('#payment tr:last td:eq(0) select option:first').val('').text('Select').attr('selected','selected');

	var lastCurrency1 = "currency"+no_of_fields;
	$('#payment tr:last td:eq(1) select').attr('name','currency[]');
	$('#payment tr:last td:eq(1) select').attr('id',lastCurrency1);
	$('#payment tr:last td:eq(1) select option:first').val('').text('Select').attr('selected','selected');
	
	var lastAmountName1 = "amount"+no_of_fields;
	$('#payment tr input:last').attr('name','amount[]');
	$('#payment tr input:last').attr('id',lastAmountName1);
	$('#payment tr input:last').val('');

	$('#payment tr:last td:last').html('<img onclick="deleteAmount(this)" class="deleteIcon" alt="add" title="Delete" src="<?php echo base_url()?>assets/images/delete_active.png"></img>');
}
function savePayement(){
	var kolName = $('#kolName').val();
	var kolNameAuto = $('#kolNameForAuto').val();
	if(kolName !=kolNameAuto){
		$('#kolId').val('');
	}
	if(!$("#paymentForm").validate().form()){
		return false;
	}else{
		var data=$("#paymentForm").serialize();
		var kolName = $('#kolName').val();
		kolName = $.trim(kolName);
		if(kolName.indexOf(' ')>=1){
		}else if(kolName.indexOf(',')>=1){
		}else{
			status='False';
			return false;
		}
//		return true;
	$('div.planMsgBox').removeClass('alert-success');
	$('div.planMsgBox').addClass('alert-warning');
	$('div.planMsgBox').show();
	$('div.planMsgBox').html('Saving the data... <img src="'+base_url+'assets/images/ajax_loader_black.gif" />');
	 	$.ajax({
			url:"<?php echo base_url()?>payments/payments/save_payment1",
			data:data,
			type:'POST',
			dataType:'json',
			beforeSend: function(){
				$("#savePaymentButton").removeAttr("onclick", null);
	        },
			success:function(returnData){
				$('.planMsgBox').text(returnData.msg);
				$('html, body').animate({
		            scrollTop: $("div.planMsgBox").first().offset().top-100
		        });
				if(returnData.saved == true){
					$('div.planMsgBox').removeClass('alert-warning');
					$('div.planMsgBox').addClass('alert-success');				
		     	}else{
					$('div.planMsgBox').removeClass('alert-success');
					$('div.planMsgBox').addClass('alert-danger');
			    }
				$('div.planMsgBox').fadeOut(10000);
			},
			complete:function(){
				$('#savePaymentButton').attr('onclick','savePayement()');
			}
		});
	}
}
function deleteAmount(thisEle){
	var amountDeletd = $(thisEle).parent().parent().find('input[type="text"]').val();
	$(thisEle).parent().parent().remove();
// 	calculateTotal();
 }
function getKolOtherDetails(){
	var kolAutoCompleteId = "kolNameForAuto";
	var kolId	= $("#"+kolAutoCompleteId).prev().val();
	var kolName=$("#"+kolAutoCompleteId).val();
	var data = {};
	data['kol_name'] = kolName;
	if(!kolId){
		kolId = '<?php echo $kolId;?>';
	}
	var otherDetailsUrl = '<?php echo base_url()?>kols/kols/get_kol_other_details/'+kolId;
	if(kolName!=''){
		$.ajax({
			url:otherDetailsUrl,
			type:'post',
			data:data,
			dataType:"json",
			success:function(returndData){				
				var specialtyName=returndData.specialtyName;
				var last_interaction=returndData.title;
				$("#"+kolAutoCompleteId).parent().parent().find('div').eq(1).find('input').val(specialtyName);
				$("#"+kolAutoCompleteId).parent().parent().find('div').eq(2).find('input').val(last_interaction);
			}
		});
	}else{
		$("#therapeuticArea").val("");
	}
}	
</script>