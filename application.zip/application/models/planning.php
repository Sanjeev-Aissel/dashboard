<?php
class Planning extends model{
	
	function Planning(){
		parent::model();
		$this->load->model('common_helpers');
	}
	
	/*
	 * To save obective details
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param $objectiveId
	 * @return $last insert id
	 */	
	function saveObjective($arrObjective){
		if($this->db->insert('objectives',$arrObjective)){
			return $this->db->insert_id();
		}else{
			false;
		}
				
	}
        
        
        
        function savePlanObjective($arrObjective){
		if($this->db->insert('plan_objectives',$arrObjective)){
			return $this->db->insert_id();
		}else{
			false;
		}
				
	}
	
	/*
	 * To get obective details
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param $objectiveId
	 * @return $arrObjective
	 */	
	function listObjectiveDetails(){
		$arrObjective = array();
		$userGroupIds = getGroupDetails();
		$group_ids = explode(',',  $userGroupIds['group_ids']);
// 		$group_ids = explode(',', $this->session->userdata('group_ids'));
		$clientId = $this->session->userdata('client_id'); 
		$this->db->select('objectives.*,plans.objective_id,client_users.country,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('plans','plans.objective_id=objectives.id','left');
		$this->db->join('client_users','client_users.id=objectives.created_by','left');		
        if($clientId!==INTERNAL_CLIENT_ID){
           if($this->session->userdata('user_role_id') != ROLE_ADMIN && $this->session->userdata('user_role_id') != ROLE_READONLY_USER){ 
            $this->db->join('user_groups','user_groups.user_id=client_users.id','left');
            $this->db->where_in("user_groups.group_id",$group_ids);		    
           }
           $this->db->where('objectives.client_id',$clientId);
        }
            
		$this->db->order_by('objectives.name','asc');
		$this->db->group_by('objectives.id');
		$arrObjectiveResult = $this->db->get('objectives');
// 		pr($this->db->last_query());exit;
		foreach($arrObjectiveResult->result_array() as $row){
		    $row['eAllowed'] = $this->common_helpers->isActionAllowed('objective', 'edit', $row);
			$arrObjective[]=$row;
		}
		return $arrObjective;
	}
	
	/*
	 * To get obective details by passing id
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param $objectiveId
	 * @return $arrObjectives
	 */	
	function getObejctiveDetailsForEditing($objectiveId){
		$arrObjectives=array();
		$this->db->where('id',$objectiveId);
		$arrResult = $this->db->get('objectives');
		foreach($arrResult->result_array() as $row){
			$arrObjectives=$row;
		} 
		return $arrObjectives;
	}
	
	/*
	 * to update objective details 
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param $objectiveId
	 * @return true/false
	 */	
	function updateObjective($arrObjective){
		$this->db->where('id',$arrObjective['id']);
		if($this->db->update('objectives',$arrObjective)){
			return true;
		}else{
			return false;
		}
	}
	
	/*
	 * to get the Plan details 
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param 
	 * @return $arrPlans
	 */	
	function listPlans($startDate,$endDate){
		$clientId   = $this->session->userdata('client_id');
		$userId     = $this->session->userdata('user_id');
		$userRoleId = $this->session->userdata('user_role_id');
		$this->db->select('plans.id,objectives.name as objective_name,kols.first_name,kols.middle_name,kols.last_name,plans.targets,plans.plan_date,client_users.user_name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,plans.user_id,plans.kol_id,plans.objective_id');
		$this->db->join('kols','kols.id=plans.kol_id','left');
		$this->db->join('objectives','objectives.id=plans.objective_id','left');
		$this->db->join('client_users','client_users.id=plans.user_id','left');
		if($userRoleId!=ROLE_MANAGER || $userRoleId!=ROLE_ADMIN){
			
			$this->db->where('plans.user_id',$userId);
		}
		$this->db->where('plans.client_id',$clientId);
		$this->db->where("(year(plan_date) between $startDate and $endDate)");
		$arrResult = $this->db->get('plans');
//	echo $this->db->last_query();
		foreach($arrResult->result_array() as $row){
			//$row['first_name'] = '<a target="_new" href=\''.base_url().'kols/view/'. $row['id'].'\'>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
			$row['kol_name'] =  $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
			$row['user_name'] = $row['user_first_name']." ".$row['user_last_name'];
			$arrPlans[] =$row; 
		}
		return $arrPlans;
	}
	
        
   function listPlansNew($startDate,$endDate){
        $userGroupName = getGroupDetails();
        $clientId   = $this->session->userdata('client_id');
		$userId     = $this->session->userdata('user_id');
		$userRoleId = $this->session->userdata('user_role_id');
		$this->db->select('plan_details.*,plan_details.id as plan_id,plan_profiles.kol_id as kol_id,client_users.user_name,client_users.first_name as user_first_name,client_users.last_name as user_last_name');
		/*if(trim($userRoleId)!==trim(ROLE_MANAGER) && $userRoleId!==ROLE_ADMIN){
			$this->db->join('plan_profiles','plan_profiles.plan_id=plan_details.id','left');
			$this->db->where('plan_profiles.user_id',$userId);
		}*/
        if($clientId!==INTERNAL_CLIENT_ID){
		  $this->db->where('plan_details.client_id',$clientId);
        }
		$this->db->where("(year(plan_details.plan_start)>=$startDate and (year(plan_details.plan_end)<=$endDate or year(plan_details.plan_start)<=$endDate))");
		$this->db->order_by("plan_details.plan_start","desc");
		$this->db->join('plan_profiles','plan_profiles.plan_id=plan_details.id','left');
		$this->db->join('client_users','client_users.id=plan_details.created_by','left');
		$this->db->join('kols','kols.id=plan_profiles.kol_id','left');
		if($clientId!==INTERNAL_CLIENT_ID){
    		if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER ){
    		    $group_names = explode(',',  $userGroupName['group_names']);
//     		    $group_names = explode(',', $this->session->userdata('group_names'));
    		    $this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
    		    $this->db->where_in ( 'countries.GlobalRegion', $group_names);
    		}
		}
		$this->db->group_by('plan_details.id');
		$arrResult = $this->db->get('plan_details');
//                pr($this->db->last_query());exit;
		foreach($arrResult->result_array() as $row){
			//$row['first_name'] = '<a target="_new" href=\''.base_url().'kols/view/'. $row['id'].'\'>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
//			$row['kol_name'] =  $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
			$row['user_name'] = $row['user_first_name']." ".$row['user_last_name'];
                        $row['plan_start']=sql_date_to_app_date($row['plan_start']);
                        $row['plan_end']=sql_date_to_app_date($row['plan_end']);
                       $row['eAllowed'] = $this->common_helpers->isActionAllowed('contract', 'edit', $row);
			$arrPlans[] =$row; 
		}
// 		pr($this->db->last_query());exit;
		return $arrPlans;
      }
        
        
        function getPlanNames(){
            $userGroupName = getGroupDetails();
            $clientId   = $this->session->userdata('client_id');
            $this->db->select('plan_details.*');
            if($clientId!==INTERNAL_CLIENT_ID){
    		    $this->db->where('plan_details.client_id',$clientId);
            }
            $this->db->join('plan_profiles','plan_profiles.plan_id=plan_details.id','left');
            $this->db->join('kols','kols.id=plan_profiles.kol_id','left');
            if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
                $group_names = explode(',',  $userGroupName['group_names']);
//                 $group_names = explode(',', $this->session->userdata('group_names'));
                $this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
                $this->db->where_in ( 'countries.GlobalRegion', $group_names);
            }
            $arrResult = $this->db->get('plan_details');
            foreach($arrResult->result_array() as $row){
                $name[$row['id']]=$row['plan_name'];
            }
            return $name;
        }
	/*
	 * Delete objective details by passing objective Id 
	 *  
	 * @author Vinayak
 	 * @since  3.1	
 	 * @created  12-09-11
	 * @param $objectiveId
	 */	
	function deleteObjective($objectiveId){
		
		$this->db->where('id',$objectiveId);
		if($this->db->delete('objectives')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Objectives',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $objectiveId,
					'transaction_table_id' => OBJECTIVES,
					'transaction_name' => "Delete Objectives",
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return 'success';
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Objectives',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_id' =>  $objectiveId,
					'transaction_table_id' => OBJECTIVES,
					'transaction_name' => "Delete Objectives",
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return 'fail';
		}
	}
	
	/**
	 * Saves given plan details
	 * @author Ramesh B
	 * @since 3.1
	 * @param  Plan details- Array
	 * @return boolean
	 * @created 13-09-2011
	 */
	function savePlan($arrPlanDetails){
		if($this->db->insert('plan_details',$arrPlanDetails)){
			return $this->db->insert_id();
		}else{
			false;
		}
	}
        
        function savePlanProfiles($arrPlanDetails,$ids){
            foreach($ids as $values){
            	if(empty($values)){
            		continue;
            	}
                $arrPlanDetails['kol_id']=$values;
                $result=$this->checkForDup($arrPlanDetails);
                if(!$result)//skip dups
                $this->db->insert('plan_profiles',$arrPlanDetails);
            }
            
        }
		
        function updatePlanId($previousPlanId, $newPlanId){
        	$data = array(
        			'id' => $previousPlanId
        	);
        	$this->db->where('id', $newPlanId);
        	$query = $this->db->update('plan_details', $data);
	        if ($query)
	                return $previousPlanId;
	            else
	                return false;
        }
        
        function checkForDup($arrPlanDetails) {
            $this->db->select('plan_details.id');

            $this->db->join('plan_details', 'plan_details.id=plan_profiles.plan_id', 'left');
            $this->db->where('plan_details.id', $arrPlanDetails['plan_id']);
            $this->db->where('plan_details.created_by', $this->session->userdata('user_id'));
            $this->db->where('plan_profiles.user_id', $arrPlanDetails['user_id']);
            $this->db->where('plan_profiles.kol_id', $arrPlanDetails['kol_id']);
            $results = $this->db->get('plan_profiles');
            if ($results->num_rows() < 1)
                return false;
            else
                return true;
    }

    /**
	 * Fetches the plan details for given plan Id
	 * @author Ramesh B
	 * @since 3.1
	 * @param planId
	 * @return Array
	 * @created 13-09-2011
	 */
	function getPlan($planId){
		$arrPlanDetails=array();
		$this->db->select('plans.*,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->where('plans.id',$planId);
		$this->db->join('kols','kols.id=plans.kol_id','left');
		$results=$this->db->get('plans');
		foreach($results->result_array() as $row){
			$arrPlanDetails=$row;
		}
		return $arrPlanDetails;
	}

	/**
	 * Updates the given plan details
	 * @author Ramesh B
	 * @since 3.1
	 * @param Plan Details - Array
	 * @return boolean
	 * @created 13-09-2011
	 */
	function updatePlan($arrPlanDetails){
		$this->db->where('id',$arrPlanDetails['id']);
		if($this->db->update('plans',$arrPlanDetails))
			return true;
		else
			return false;
	}
	
	/**
	 * Deletes the plan details for given plan Id
	 * @author Ramesh B
	 * @since 3.1
	 * @param planId
	 * @return Boolean
	 * @created 13-09-2011
	 */
	function deletePlan($planId){
		$this->db->where('id',$planId);
		if($this->db->delete('plans')){
		//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete plans',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $planId,
					'transaction_table_id' => PLANS,
					'transaction_name' => "Delete plans",
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}
		else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete plans',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_id' => $planId,
					'transaction_table_id' => PLANS,
					'transaction_name' => "Delete plans",
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}
	
        function deletePlanDetails($planId){
                $this->db->where('id',$planId);
		$this->db->delete('plan_details');
                
                $this->db->where('plan_id',$planId);
		$this->db->delete('plan_objectives');
                
                
                $this->db->where('plan_id',$planId);
		$this->db->delete('plan_profiles');
        }
	/**
	 * To get achived Interactions by passing $userId,kolId,objectiveId
	 * @author Vinayak
	 * @since 3.1
	 * @param  $userId,kolId,objectiveId
	 * @return noubmer of rows
	 * @created 14-09-2011
	 */
	function getAchivedInteractions($userId,$kolId,$objectiveId){
		$this->db->join('interactions_attendees','interactions_attendees.interaction_id=interactions.id','left');
		$this->db->join('interactions_about','interactions_about.interaction_id=interactions.id','left');
		$this->db->where("(created_by=$userId and interactions_attendees.kol_id=$kolId and interactions_about.objective_id=$objectiveId)");
		$arrResult = $this->db->get('interactions');
		return $arrResult->num_rows();
	}
	
	/**
	 * To get Plan details by passing planId
	 * @author Vinayak
	 * @since 3.1
	 * @param  planId
	 * @return $arrPlans
	 * @created 14-09-2011
	 */
	function getPlanDetail($planId,$isEditSet){
		
		$arrPlans  = array();
		/* if(!$isEditSet)
         	$this->db->select('plan_details.*,plan_profiles.status,client_users.user_name,kols.first_name,kols.middle_name,kols.last_name,kols.salutation,kols.primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name,plan_profiles.user_id,plan_profiles.kol_id as kols');
		else
            $this->db->select('group_concat(kol_id) as kols,plan_details.*,plan_profiles.status,client_users.user_name,kols.first_name,kols.middle_name,kols.last_name,kols.salutation,kols.primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name,plan_profiles.user_id'); */
		if(!$isEditSet){
			//$this->db->select('plan_details.*,plan_profiles.*,client_users.user_name,kols.first_name,kols.middle_name,kols.last_name,kols.salutation,kols.primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name');
			$this->db->select('plan_details.*,plan_profiles.status,client_users.user_name,group_concat(kols.first_name) as first_name,group_concat(kols.middle_name) as middle_name,group_concat(kols.last_name) as last_name,kols.salutation, group_concat(`kols`.`primary_email`) as primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name,plan_profiles.user_id,group_concat(plan_profiles.kol_id) as kols');
		}else{
			//$this->db->select('group_concat(kol_id) as kols,plan_details.*,plan_profiles.*,client_users.user_name,kols.first_name,kols.middle_name,kols.last_name,kols.salutation,kols.primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name');
			$this->db->select('group_concat(kol_id) as kols,plan_details.*,plan_profiles.status,client_users.user_name,kols.first_name,kols.middle_name,kols.last_name,kols.salutation,kols.primary_email,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.id as user_id,plan_profiles.user_id');
		}
		
                $this->db->join('plan_profiles','plan_profiles.plan_id=plan_details.id','left');
                $this->db->join('kols','kols.id=plan_profiles.kol_id','left');
				$this->db->join('client_users','client_users.id=plan_profiles.user_id','left');
				$this->db->where('plan_details.id',$planId);
                //$this->db->where('plan_details.client_id',$this->session->userdata('client_id'));
				if($isEditSet){
                    $this->db->group_by('plan_profiles.user_id');
                    $this->db->group_by('plan_profiles.status');
				}else{
					$this->db->group_by('plan_profiles.user_id');
					$this->db->group_by('plan_profiles.status');
				}
				$this->db->order_by('plan_profiles.id','asc');
                    $arrResult = $this->db->get('plan_details');
                foreach($arrResult->result_array() as $row){
			//$row['first_name'] = '<a target="_new" href=\''.base_url().'kols/view/'. $row['id'].'\'>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
//			$row['kol_name'] =  $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
			
                        $row['plan_start']=sql_date_to_app_date($row['plan_start']);
                        $row['plan_end']=sql_date_to_app_date($row['plan_end']);
			$arrPlans[] =$row; 
		}
//              echo $this->db->last_query();
		return $arrPlans;
                
		return $arrResult->result_array();
	}
	
        
        function getObj($id){
            
		$clientId = $this->session->userdata('client_id'); 
		$this->db->select('objectives.*');
		$this->db->join('plan_objectives','plan_objectives.objective_id=objectives.id','left');
                  $this->db->join('plan_details','plan_objectives.plan_id=plan_details.id','left');
		$this->db->where('plan_details.client_id',$clientId);
                $this->db->where('plan_details.id',$id);
		$arrObjectiveResult = $this->db->get('objectives');
		foreach($arrObjectiveResult->result_array() as $row){
			
			$arrObjective[]=$row;
		}
		return $arrObjective;
        }
	/**
	 * To get Plan details and their releted interactions by passing $userId,$objectiveId,$kolId
	 * @author Vinayak
	 * @since 3.1
	 * @param  $userId,$objectiveId,$kolId
	 * @return $arrInteractions
	 * @created 14-09-2011
	 */
	function getRelatedInteractions($userId,$objectiveId,$kolId){
		$arrInteractions = array();
		$this->db->select('interactions_products.name as product,client_users.first_name,client_users.last_name,interactions.id,interactions.date,interactions.follow_up_on,interactions_modes.name,interactions_roles.name as role,interactions_categories.name as  category,interactions_brands.name as brand');
		$this->db->join('interactions_modes','interactions_modes.id=interactions.mode','left');
		$this->db->join('interactions_attendees','interactions_attendees.interaction_id=interactions.id','left');
		$this->db->join('interactions_about','interactions_about.interaction_id=interactions.id','left');
		$this->db->join('interactions_brands','interactions_brands.id=interactions_about.brand_id','left');
		$this->db->join('interactions_categories','interactions_categories.id=interactions_attendees.category_id','left');
		$this->db->join('interactions_roles','interactions_roles.id=interactions_attendees.role_id','left');
		$this->db->join('interactions_products','interactions_brands.product_id=interactions_products.id','left');
		$this->db->join('client_users','interactions.created_by=client_users.id','left');
		$this->db->where("(interactions.created_by=$userId  and interactions_attendees.kol_id=$kolId)");
		$arrResult = $this->db->get('interactions');
		foreach($arrResult->result_array() as $row){
			$arrInteractions[] =$row;
		}
		return $arrInteractions;
	}
	

	
	/**
	 *Checks for duplicate plan entry fro given parameters
	 * @author Ramesh B
	 * @since 3.1
	 * @param $objectiveId
	 * @param $userId
	 * @param $kolId
	 * @param $clientId
	 * @param $planDate
	 * @return Boolean
	 * @created 13-09-2011
	 */
	function checkForDuplicatePlan($planName,$clientId){
		//$this->db->where('objective_id',$objectiveId);
		$this->db->where('plan_name',$planName);
		$this->db->where('client_id',$clientId);
		
		//While update
		
		$results=$this->db->get('plan_details');
		if($results->num_rows()==0)
			return true;
		else
			return false;
	}
	
	/**
	 * Returns the all the objectives of the user on which plans are logged
	 * @author Ramesh B
	 * @since 3.1
	 * @param $userId
	 * @return Boolean
	 * @created 13-09-2011
	 */
	function getPlannedObjectives($userId,$clientId){
		$arrObjectives=array();
		$this->db->distinct();
		$this->db->select('objectives.*');
		if($userId!=0){
			$this->db->where('plans.user_id',$userId);
		}
		$this->db->where('objectives.client_id',$clientId);
		$this->db->where('(objectives.name IS NOT NULL OR objectives.name !="")');
		$this->db->join('plans','plans.objective_id=objectives.id','left');
		$results=$this->db->get('objectives');
		foreach($results->result_array() as $row){
			$arrObjectives[]=$row;
		}
		//echo $this->db->last_query();
		return $arrObjectives;
	}
	
	/**
	 * Returns array of all the users targets for each kol.within the specified date rnage
	 * @author Ramesh B
	 * @since 3.1
	 * @param $clientId
	 * @param $startDate
	 * @param $endDate
	 * @return Boolean
	 * @created 17-09-2011
	 */
	function getAllUserTargetsPerKOL($clientId,$startDate,$endDate){
		$arrTargetsDetails=array();
		$this->db->select('user_id,kol_id,SUM(targets) AS target');
		$this->db->where('client_id',$clientId);
		$this->db->where("plan_date BETWEEN '$startDate' AND '$endDate'");
		$this->db->group_by('kol_id,user_id');
		$this->db->order_by('user_id','ASC');
		$results=$this->db->get('plans');
		foreach($results->result_array() as $row){
			$arrTargetsDetails[$row['user_id']][$row['kol_id']]=$row['target'];
		}
		return $arrTargetsDetails;
	}
	
	
	/**
	 * To List Topic details
	 *  
	 * @author Vineet Kadkol
 	 * @since 	
 	 * @created  22-09-2012
	 * @param null
	 * @return array
	 * 
	 */	
	function listTopicDetails(){
		$arrTopics = array();
		$clientId = $this->session->userdata('client_id'); 
		$this->db->where('client_id',$clientId);
		$arrTopicsResult = $this->db->get('interactions_topics');
		foreach($arrTopicsResult->result_array() as $row){
			$arrTopics[]=$row;
		}
		return $arrTopics;
	}
	
	
	
	/**
	 * To save Topic details
	 *  
	 * @author Vineet Kadkol
 	 * @since 	
 	 * @created  22-09-2012
	 * @param $objectiveId
	 * @return $last insert id
	 * 
	 */	
	function saveTopic($arrTopic){
		if($this->db->insert('interactions_topics',$arrTopic)){
			return $this->db->insert_id();
		}else{
			false;
		}
	}
	
	/**
	 * To save Topic details
	 *  
	 * @author Vineet Kadkol
 	 * @since  	
 	 * @created  22-09-2012
	 * @param $arrTopic
	 * @return BooleaN
	 * 
	 */	
	function updateTopic($arrTopic){
		$this->db->where('id',$arrTopic['id']);
		if($this->db->update('interactions_topics',$arrTopic)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Retrives the topic details for given id
	 *  
	 * @author Ramesh B
 	 * @since  	
 	 * @created  26-09-2012
	 * @param $id
	 * @return Array
	 * 
	 */	
	function getTopic($id){
		$topicDetails = array();
		$this->db->where('id',$id);
		$result = $this->db->get('interactions_topics');
		if($result->num_rows() > 0){
			$topicDetails = $result->row_array();
		}
		return $topicDetails;
	}
	
	
	function deleteTopic($id){
		$this->db->where('id',$id);
		if($this->db->delete('interactions_topics'))
			return true;
		else
			return false;
	}
	function getMaxYearPlanning(){
    	$this->db->select_max('plan_end');    
        $get = $this->db->get('plan_details');
        //pr($this->db->last_query());exit;
        return $get->row()->plan_end;
	}
	
	function getPlanDetailsById($id){
	    $planDetails = array();
	    $this->db->where('id',$id);
	    $result = $this->db->get('plan_details');
	    foreach($result->result_array() as $row){
	        $planDetails[]=$row;
	    }
	    return $planDetails;
	}
	
	function getAssignedUsersForType($ids){
	    $client_id = $this->session->userdata('client_id');
	    $this->db->select("user_kols.user_id, client_users.email");
	    $this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
	    $this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
	    $this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
	    $this->db->where_in('user_kols.kol_id', $ids);
	    if($client_id !== INTERNAL_CLIENT_ID){
	        $this->db->where('client_users.client_id', $client_id);
	    }
	    $query = $this->db->get('user_kols');
	    $result = $query->result();
	    foreach($result as $row){
	        $typeName = $row->typename;
	        $userEmails[] =  $row->email;
	    }
	    $arrUsersDetails['type_name'] = $typeName;
	    $arrUsersDetails['user_details'] = $userEmails;
	    return $arrUsersDetails;
	}
	
}