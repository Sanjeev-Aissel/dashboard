<?php
/**
 * File to render twitter updates for given username
 *
 * @author: Ramesh B
 * @created on: 26 jun 2013
 */

function get_tweets($userName,$limit=5,$startFrom = 1){
	$tweets = array();
 	//Load tweets from user timeline. version 1.0
  	/*$result = simplexml_load_file("https://api.twitter.com/1/statuses/user_timeline.rss?count=5&screen_name=".$username);
  	//other url
  	//https://api.twitter.com/1/statuses/user_timeline.json?include_entities=true&include_rts=true&screen_name=apjabdulkalam&count=2
  
  	//Iteration of XML object
  	foreach(get_object_vars($result) as $property => $value) {
    	//Iteration of each Item
	   	if(isset($value->item)) {
			for ($iterator = 0; $iterator < count($value->item); $iterator++) {
				$tweets[] =$value->item[$iterator];
			}
	   }
	}*/
	
	//Vrstion 1.1
	/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
	$settings = array(
	    'oauth_access_token' => "537098294-3CsXJioP2QwdfEYFfvtesjSSqkCgo75yxKhqUAQH",
	    'oauth_access_token_secret' => "azPqmHEyVKGJuVKqkrXhqeBqZkZA7CIBxVsDkDhIVA",
	    'consumer_key' => "beQLViOzHNiOOEON07CqA",
	    'consumer_secret' => "Sa1x1HzA697Sdbe5SucrsEXvsYhYV00dn9dgNr1MBHI"
	);
	
	/** Perform a GET request and echo the response **/
	/** Note: Set the GET field BEFORE calling buildOauth(); **/
	$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
	//for pagination use 'page=1'
	$getfield = '?screen_name='.$userName."&include_rts=1&count=$limit&page=$startFrom";
	$requestMethod = 'GET';
	$twitter = new TwitterAPIExchange($settings);
	
	$tweets = $twitter->setGetfield($getfield)
	             ->buildOauth($url, $requestMethod)
	             ->performRequest();
             
	return $tweets;
}

function linkable($text = ''){
    $text = preg_replace("/\s+/", ' ', str_replace(array("\r\n", "\r", "\n"), ' ', $text));
    $data = '';
    foreach( explode(' ', $text) as $str){
        if (preg_match('#^http?#i', trim($str)) || preg_match('#^www.?#i', trim($str))) {
            $data .= '<br /><a target="_new" href="'.$str.'">'.$str.'</a> ';
        } else {
            $data .= $str .' ';
        }
    }
    return trim($data);
}

function twitterDateToSqlDate($twitterDate){
	$sqlDate = '';
	$arrElements = explode(" ",$twitterDate);
	//prev format 'D M d h:m:s O Y'
	//Required format '2013-02-28T20:46:29.000Z'
	$nmonth = date("m", strtotime("$arrElements[1]-$arrElements[5]"));
	$fmtDate = $arrElements[5]."-".$nmonth."-".$arrElements[2]."T".$arrElements[3].".000Z";
	$sqlDate = changeDateFormat($fmtDate,DATE_ATOM,"Y-m-d h:m:s");
	return $sqlDate;
}
?>

<?php
	$arrComponents = explode("/",rtrim($mediaUrl,'/'));
	$companyName = $arrComponents[sizeof($arrComponents)-1];
	$this->load->plugin('twitter/TwitterAPIExchange');
	if(!isset($limit))
		$limit=5;
	if(!isset($startFrom))
		$startFrom=1;
	$responseJson = get_tweets($companyName,$limit,$startFrom);
    if($responseJson) {
        $responseAray = json_decode($responseJson);
        foreach($responseAray as $resp) {
            ?>
            <li>
            	<?php 
            		$description = linkable($resp->text);
            		$arrElements = explode(":",$description);
            		$suffixText = $arrElements[0];
            	?>
	            <a style="color:#00BEF2;" target="_new" href="https://twitter.com/intent/user?screen_name=<?php echo $companyName;?>" target="_blank">@<?php echo $resp->user->screen_name;?></a>
	            <?php 
	            	//if(strpos($suffixText, '@') !== false)
	            		//echo $suffixText;
	            ?>
	            <br /> 
	            <?php 
	            	//$description = preg_replace('#([^\s]*@[^\s]*)#', ' ', $description);
	            	//if(strpos($suffixText, '@') !== false)
	            		//$description = str_replace($suffixText, '', $description);
	            	echo trim($description," :");
	            ?>
	            <br /> 
	            <div class="additinal-links">
	            	<a style="color:#0E313B;" target="_new" href="https://twitter.com/intent/tweet?in_reply_to=<?php echo $resp->id_str;?>">reply</a> |
		            <a style="color:#0E313B;" target="_new" href="https://twitter.com/intent/retweet?tweet_id=<?php echo $resp->id_str;?>">retweet</a> |
		            <a style="color:#0E313B;" target="_new" href="https://twitter.com/intent/favorite?tweet_id=<?php echo $resp->id_str;?>">favorite</a>
	            </div>
	            <span class='human-time'>
				<?php
					//$resp->pubDate = humanTiming(strtotime(changeDateFormat($resp->pubDate,DATE_RFC822,"Y-m-d h:m:s")));
					//$hTime = humanTiming(strtotime(changeDateFormat($resp->{'created_at'},"D M d h:m:s O Y","Y-m-d h:m:s")));
					$hTime = humanTiming(strtotime(twitterDateToSqlDate($resp->{'created_at'})));
					echo $hTime;
				?>
				</span>
			
            </li>
            <?php
        }
    }
?>
<span class="start-from"><?php echo ++$startFrom;?></span>