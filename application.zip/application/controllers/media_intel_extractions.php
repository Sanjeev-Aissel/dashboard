<?php

/**

 * Created By: Yuvaraj M
 * Created On:10-04-2015 11:00 AM
 * Updated on:21-04-2015
 */
?>
<?php

class Media_intel_extractions extends Controller {

    function Media_intel_extractions() {
        parent::Controller();
        $this->load->model('media_parser');
         $this->load->model('client_User');
        $this->load->model('kol');
        $this->load->model("kol_rating");
        $this->load->model('align_user');
        ini_set('max_execution_time', 3600);
        $this->loggedUserId = $this->session->userdata('user_id');
     
    }
    function ajaxTest()
    {
         $id = $this->input->post("id");
         $result = $this->media_parser->getMessage($id);
        if(count($result)==0)
        {
           usleep(5000000);
             $this->ajaxTest();
              
        }
        $response["msg"]="hi";
       
        echo json_encode($response);
        // echo $result["userid"];
         
            
    }
    function media_log($logArr)
    {
        
        $this->media_parser->mediaLog($logArr);
    }
    
    function test()
    {
    }
    function send_mail() {
        $flag = 0;
        $result = $this->media_parser->getMailId();
        foreach ($result as $values) {
            // pr($values);
            $email = $values["email"];
            $userName = $values["first_name"];
            $resutlArticles = $this->media_parser->getBookMarkedArticles($values['id']);
            //pr($values["id"]);
            $resultTopCat = $this->ajax_entity_filters(date('Y-m-d',strtotime("-3 days")), $values['id']);
            $TopPeople = array();
            $TopDiseases = array();
            $TopOrganization = array();
            $TopProduct = array();
            $TopTechnology = array();
            $TopCompany = array();
            $i = 0;
            

            // pr($resultTopCat);
            foreach ($resultTopCat["People"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopPeople[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $i = 0;

            foreach ($resultTopCat["MedicalCondition"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopDiseases[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $i = 0;
            $flag = 0;
            foreach ($resultTopCat["Organization"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopOrganization[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $i = 0;
            $flag = 0;
            foreach ($resultTopCat["Technology"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopTechnology[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $i = 0;
            $flag = 0;
            foreach ($resultTopCat["Product"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopProduct[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $i = 0;
            $flag = 0;
            foreach ($resultTopCat["Company"] as $values) {
                if ($values["isbookmarked"] == 1) {
                    $i++;
                    $TopCompany[] = $values["entity_name"];
                    if ($i >= 3)
                        $flag = 1;
                }
                if ($flag == 1)
                    break;
            }
            $data["topPeople"] = $TopPeople;
            $data["topDiseases"] = $TopDiseases;
            $data["topOrganization"] = $TopOrganization;
            $data["topTechnology"] = $TopTechnology;
            $data["topCompany"] = $TopCompany;
            $data["topProduct"] = $TopProduct;
            $data["userName"] = $userName;
            $data["date"] = date('M d, Y ');
            $data["resutlArticles"] = $resutlArticles;
            $data['user_id']=$values['id'];
            $content = $this->load->view('media_inteligence/mail_view', $data, true);
    //        pr($content);
            if (!empty($resutlArticles))
                $this->sendMail($content, $email);
            /*else
            {
                 $logArrNoNews=array("id"=>NULL,"module"=>"send_mail","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$email,"description"=>"No news found for tdy",
                        "type"=>"daily_news","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logArrNoNews);
            }*/
        }
    }

    function demo() {
        require('opencalais.php');
        $apikey = "ilGS2fGxTJ1C2HgAxb3vcMfZ4X71j0KH";
        $content = "Viruses that develop in animals and can spread to humans are on the rise around the world and scientists say more research is needed to prevent them from evolving.

Viruses that pose a risk to both human and animal health are known as zoonotic diseases.

The more severe examples include ebola in west Africa, Middle East Respiratory Syndrome (MERS) in the Arabian Peninsula, Severe Acute Respiratory Syndrome (SARS) in Asia, and even Hendra in Australia.";


        $oc = new OpenCalais($apikey, $content);
    }

    function analystSourceGrid() {

        $data['contentPage'] = 'media_inteligence/source_list';
        $this->load->view('layouts/analyst_view', $data);
    }
    function bookmarkSourceGrid(){
        $arrClints = $this->Client_User->getClients();
        $data['arrClients'] = $arrClints;
        $data['contentPage'] = 'media_inteligence/entity_grid';
        //Add Log activity
        $arrLogDetails = array(
        'type' => VIEW_RECORD,
        'description' => "Visited Book Mark Source Grid Page",
        'status' => STATUS_SUCCESS,
        'transaction_name' => "View Book Mark Source Grid Page"
        		);
        $this->config->set_item('log_details', $arrLogDetails);
        $this->load->view('layouts/analyst_view', $data);
        
    }
    function get_entities() {

        $cat = $this->input->post("cat");
        $result_person = $this->media_parser->getEntitesForMerge($cat);
//        $data['records'] = count($result_person);
//        $data['total'] = 25;
//        $data['page'] = 1;
//        $data['rows'] = $result_person;
        echo json_encode($result_person);
    }

    function entity_merge() {
        $result_person = $this->media_parser->getEntitesForMerge("Person");
        $data["person"] = $result_person;
        $data['contentPage'] = 'media_inteligence/entities_merge';
        $this->load->view('layouts/analyst_view', $data);
    }

    function merge_selected_entities() {
        $arrEntities = array();
        $arrEntities = $_POST;
        $result = $this->media_parser->mergeEntities($arrEntities);
    }
    
    function list_logs()
    {
          $result = $this->media_parser->getLogs();
          $data['records'] = count($result);
        $data['total'] = 10;
        $data['page'] = 1;
        $data['rows'] = $result;

        echo json_encode($data);
    }
    function get_merged_entities() {
        $result = $this->media_parser->getMergedEntities();
        echo json_encode($result);
    }

    function restore_merged_entities() {
        $aliasEntityName = $this->input->post('data');
        $result = $this->media_parser->restoreMergedEntities($aliasEntityName);
    }

    function list_source_grid() {
        $result = $this->media_parser->getSources();
        $data['records'] = count($result);
        $data['total'] = 10;
        $data['page'] = 1;
        $data['rows'] = $result;

        echo json_encode($data);
    }
    
    function list_bookmark_grid() {
    	ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $result = $this->media_parser->getEntitesForMerge('',true);
        $data['records'] = count($result);
        $data['total'] = 10;
        $data['page'] = 1;
        $data['rows'] = $result;

        echo json_encode($data);
    }

    function list_bookmarks(){
        $result = $this->media_parser->getAnalystBookmarks();
        $data['records'] = count($result);
        $data['total'] = 10;
        $data['page'] = 1;
        $data['rows'] = $result;

        echo json_encode($data);
    }
    
    function list_ignores(){
        $result = $this->media_parser->getAnalystIgnores();
        $data['records'] = count($result);
        $data['total'] = 10;
        $data['page'] = 1;
        $data['rows'] = $result;

        echo json_encode($data);
    }
    function update_source() {
        $id = $this->input->post("id");
        $link = $this->input->post("link");
        $attribute_name = $this->input->post("attribute_name");
        $attribute_value = $this->input->post("attribute_value");
        $tag_name = $this->input->post("tag_name");
        $publisher = $this->input->post("publisher");
        $result = $this->media_parser->updateSource($id, $link, $attribute_name, $attribute_value, $tag_name, $publisher);
        echo $result;
    }

    function view_logs()
    {
        $result = $this->media_parser->getSourceDetail($id);
        $data["content"] = $result;
        $data['contentPage'] = 'media_inteligence/list_log_activities';
        $this->load->view('layouts/analyst_view', $data);
    }
    function save_source_data() {
        $id = $this->input->post("id");
        $link = $this->input->post("link");
        $attribute_name = $this->input->post("attribute_name");
        $attribute_value = $this->input->post("attribute_value");
        $tag_name = $this->input->post("tag_name");
        $publisher = $this->input->post("publisher");
        $result = $this->media_parser->saveSourceData($id, $link, $attribute_name, $attribute_value, $tag_name, $publisher);
        echo $result;
    }

    function source_details($id) {
        $result = $this->media_parser->getSourceDetail($id);
        $data["content"] = $result;
        $data['contentPage'] = 'media_inteligence/source_detail';
        $this->load->view('layouts/analyst_view', $data);
    }

    function add_source() {

        $data['contentPage'] = 'media_inteligence/add_source';
        $this->load->view('layouts/analyst_view', $data);
    }

    function ignore_source() {
        $id = $this->input->post("id");
        $result = $this->media_parser->ignoreSource($id);
        echo $result;
    }

    function restore_source() {
        $id = $this->input->post("id");
        $result = $this->media_parser->restoreSource($id);
        echo $result;
    }
    function sendMailToAdmin($content) {
       
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';

        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, 'ColaplDBSync');
        //$this->email->to($to);
        //$this->email->from('yuvim86@gmail.com', 'Your Name');
        //$this->email->to("rameshb@aissel.com"); 
        $this->email->to("yuvarajm@aissel.com");
       // $this->email->cc('rameshb@aissel.com'); 

        $this->email->subject("Colpal Db Status – " . date('M d, Y ') . "");

        $result=$this->email->message($content);
       

        $this->email->send();
    }
    function sendMail($content, $email) {
//        pr($email);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';

        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, 'KTL Database MedIntel');
        //$this->email->to($to);
        //$this->email->from('yuvim86@gmail.com', 'Your Name');
//        $this->email->to("yuvarajm@aissel.com"); 
        $this->email->to($email);

        $this->email->subject("Today's top Articles for you! – " . date('M d, Y ') . "");

        $this->email->message($content);

        $res=$this->email->send();
        if($res)
        {
            $logArrMailSucc=array("id"=>NULL,"module"=>"sendMail","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$email,"description"=>"",
                        "type"=>"daily_news","status"=>"success","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logArrMailSucc); 
        }
        else
        {
             $logArrMailFail=array("id"=>NULL,"module"=>"sendMail","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$email,"description"=>"Coudnt Send Mail",
                        "type"=>"daily_news","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logArrMailFail);
        }
    }
function get_media($kolId){
		
		$articlesArr 	= $this->kol->getKolMediaById($kolId);
               
                return $articlesArr;
		
	}
    function media_feature($selOption) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $user_id = $this->session->userdata("user_id");
        $data['contentPage'] = 'media_inteligence/rss_feed_view';
        $this->load->model('user_setting');
        $userId = $this->loggedUserId;
        $filterData = $this->user_setting->getDataFromAppSettings($userId,'medintel_filter_date');
        if($filterData > 0){
            $filterData;
            $data['fromFilterData'] = $filterData;
        }else{
            $filterData = 30;
            $data['fromFilterData'] = 30;
        }
        /* $bookmarked_content = $this->media_parser->getUsersBookmark($user_id);
        //   $bookmarked_source=$this->media_parser->getSourceBookmark($user_id);

        $blacklist_content = $this->media_parser->getUserBlacklists($user_id);
        $commentCountResult = $this->media_parser->getCommentCount(null, 1);
        $book_array = array();
        $blacklist_array = array();
        $commentCount = array();
        $sourceArr = array();
        $sourceResult = $this->media_parser->category_filter("link");
        //pr($sourceResult);
        foreach ($sourceResult as $source_values) {
            $sourceArr[] = $source_values;
        }
        foreach ($bookmarked_content as $values) {
            $book_array[] = $values;
        }

        foreach ($blacklist_content as $list_values) {
            $blacklist_array[] = $list_values;
        }
        foreach ($commentCountResult as $commentCounts) {
            $commentCount[] = $commentCounts;
        }
        $arrParams = array();
        
        $arrParams['start_date'] = date('Y-m-d', strtotime("-$filterData days"));
        $arrParams['end_date'] = date('Y-m-d');
        $result = $this->media_parser->getFeedsToDisplay($arrParams);
         $result_count = $this->media_parser->getFeedsToDisplay($arrParams,true);
        // $result_cat_highlights=$this->media_parser->getEachTotalCatCount();
           $arrFilters['start_date'] = date('Y-m-d', strtotime(' -30 day'));;
         $arrFilters['end_date'] = date('Y-m-d');
         $arrFilters['user_id']=$this->session->userdata('user_id');
        $filterd_feeds["count"]["people"] = $this->media_parser->category_filter(96, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Person", "num" => $filterd_feeds["count"]["people"]);
        $filterd_feeds["count"]["disease"] = $this->media_parser->category_filter(100, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "MedicalCondition", "num" => $filterd_feeds["count"]["disease"]);
        $filterd_feeds["count"]["organization"] = $this->media_parser->category_filter(95, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Organization", "num" => $filterd_feeds["count"]["organization"]);
        $filterd_feeds["count"]["technology"] = $this->media_parser->category_filter(98, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Technology", "num" => $filterd_feeds["count"]["technology"]);
        $filterd_feeds["count"]["company"] = $this->media_parser->category_filter(105, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Company", "num" => $filterd_feeds["count"]["company"]);
        $filterd_feeds["count"]["product"] = $this->media_parser->category_filter(110, $arrFilters, true);
        $result_cat_highlights[] = array("category_name" => "Product", "num" => $filterd_feeds["count"]["product"]);
        //pr($result_cat_highlights);
        $result_person = $this->media_parser->category_filter(96, $arrFilters);
        $result_disease = $this->media_parser->category_filter(100, $arrFilters);
        $result_technology = $this->media_parser->category_filter(95, $arrFilters);
        $result_product = $this->media_parser->category_filter(98, $arrFilters);
        $result_organization = $this->media_parser->category_filter(105, $arrFilters);
        $result_company = $this->media_parser->category_filter(110, $arrFilters);
        $arrFeeds = array();
        foreach ($result as $row) {
            $row["description"] = strip_tags($row["description"]);
            $row["bookmarks"] = $this->media_parser->getUserBookmark($user_id, $row["rss_feed_url_id"]);
            $arrFeeds[] = $row;
        }
        $data['person'] = $result_person;
        $data['technology'] = $result_technology;
        $data['medical_condition'] = $result_disease;
        $data['organization'] = $result_organization;
        $data['company'] = $result_company;
        $data['product'] = $result_product;
        $data['result'] = $arrFeeds;
        $data['book_marks'] = $book_array;
        $data['black_lists'] = $blacklist_array;
        $data['feedCount'] = count($result_count);
            $result=$this->media_parser->getBookMarkedArticles($this->session->userdata('user_id'),true);
            if(count($result)>0)
                $data['newsExists']=1;
        $data['highlights'] = $result_cat_highlights;
        $data['popup']=$this->media_parser->getPopUpSettings();
        $data['comment_count'] = $commentCount;
        $data['source_links'] = $sourceArr; */
        $result=$this->media_parser->getBookMarkedArticles($this->session->userdata('user_id'),true);
        if(count($result)>0)
            $data['newsExists']=1;
        $data['selectedOption'] = $selOption;
        $clientId = $this->session->userdata("client_id");
        $data['client_id'] = $clientId;
        $this->load->view('layouts/client_view', $data);
    }

    function feedTest()
    {
         $this->media_parser->getDetails();
    }
    function get_kol_id($kolId = null, $subContentPage = '') {

        if (!$kolId) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        $arrKolDetail = $this->kol->editKol($kolId);
        $firstName = $arrKolDetail["first_name"];
        $spaceSplitter = " ";
        $lastName = $arrKolDetail['last_name'];
        $completeName = array();
        $completeName[] = $firstName . $spaceSplitter . $lastName;
        $completeName[] = $lastName . $spaceSplitter . $firstName;
        $result = $this->check_entity_name($completeName);
        $commentCount = array();
        $commentCountResult = $this->media_parser->getCommentCount(null, 1);
        foreach ($commentCountResult as $commentCounts) {
            $commentCount[] = $commentCounts;
        }

        if ($result != fail) {//if true

            $articleRes = $this->get_kol_articles($result["entity_name"]);
            $data['articleArr'] = $articleRes;
        }
        $data['comment_count'] = $commentCount;
        // If there is no record in the database
        if (!$arrKolDetail) {
            $this->session->set_flashdata('errorMessage', 'Invalid KOL Id');
            redirect('kols/list_kols');
        }
        // Set the KOL ID into the Session
        $this->session->set_userdata('kolId', $kolId);
        $resultArr=$this->get_media($kolId);
        $data['arrKol'] = $arrKolDetail;
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $data['arrSalutations'] = $arrSalutations;
        //Get Kol profile Score
        $kolsPforfileScore = $this->getKolProfileScore($kolId);
        $data['kolsPforfileScore'] = $kolsPforfileScore;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['contentPage'] = 'media_inteligence/kol_media_list';
        $data['subContentPage'] = $subContentPage;
        $data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
        $data['mediaCount'] = $this->media_parser->getKolMediaCounts($arrKolDetail);;
        $data['articles']=$resultArr;
//        $data['hideTab'] = $this->get_all_counts($kolId,$arrKolDetail['profile_type']);
        $this->load->view('layouts/client_view', $data);
    }

    function check_entity_name($completeName) {
        $result = $this->media_parser->checkEntityName($completeName);
        return $result;
    }

    function get_kol_articles($completeName) {
        $resArticles = $this->get_kol_feeds($completeName);
        return $resArticles;
    }

    function getKolProfileScore($kolId) {
        $kolTotalActivitiesCount = $this->kol_rating->getKolTotalActivityCount1($kolId);
        $spcilatyId = $this->kol_rating->gerSpecilatyIdByKol($kolId);
        $maxCount = $this->kol_rating->getMaxTotalCountOfKolBySpecialty($spcilatyId);
        if ($maxCount > 0) {
            $kolsPforfileScore = ($kolTotalActivitiesCount / $maxCount) * 100;
        } else {
            $kolsPforfileScore = 0;
        }
        $kolsPforfileScore = $this->kol_rating->getProfileScore($kolId);
        return $kolsPforfileScore;
    }

    function remove_bookmarks() {
        $user_id = $this->session->userdata("user_id");
        $entity_id = $this->input->post("entity_id");
        $this->media_parser->remove_book_mark($user_id, $entity_id);
        //Add Log activity
        $arrLogDetails = array(
        'type' => MARK_AS_UNFAVOURITE,
        'description' => 'Marked as Unfavourite',
        'status' => STATUS_SUCCESS,
        'transaction_id' =>  $entity_id,
        'transaction_table_id' => USER_BOOKMARKS,
        'transaction_name' => "Mark As Unfavourite"
        		);
        $this->config->set_item('log_details', $arrLogDetails);
        return true;
    }
    
    function export_log()
    {
         $this->media_parser->exportLog();
    }

    function reset_filters() {
        
    }

    function user_bookmarks() {
        $user_id = $this->session->userdata("user_id");
        $entity_id = $this->input->post("entity_id");
        $result = $this->media_parser->user_bookmark($entity_id, $user_id);  
        $bookmark["status"] = $result;
        echo json_encode($bookmark);
    }
    
//    function user_bookmarks_all_users(){
//        $entity_id = $this->input->post("entity_id");
//        $arrUserResults	= $this->client_User->getUsers($this->session->userdata("client_id"));
//        $result = $this->media_parser->user_bookmark_all_users($entity_id,$this->session->userdata("user_id"),$arrUserResults,$this->input->post("remove"));
//        
//    }

    function save_tags() {
        $entityId = $this->input->post("ent_id");
        $tagName = $this->input->post("tag_name");
        $userId = $this->session->userdata("user_id");
        $result = $this->media_parser->saveTag($userId, $entityId, $tagName);
        //Add Log activity
        $arrLogDetails = array(
        'type' => ADD_RECORD,
        'description' => 'Add New Tag',
        'status' => STATUS_SUCCESS,
        'transaction_id' =>  $entityId,
        'transaction_table_id' => ENTITY_TAGS,
        'transaction_name' => 'Add New Tag'
        );
        $this->config->set_item('log_details', $arrLogDetails);
        echo json_encode($result);
    }

    function get_tag_entities() {
        $tagName = $this->input->post("tag_name");
        $result = $this->media_parser->getTagEntities($tagName);
        echo json_encode($result);
    }

    function get_ignored_entites() {
        $userId = $this->session->userdata("user_id");
        $clientId = $this->session->userdata("client_id");
//        if ($clientId == INTERNAL_CLIENT_ID)
//            $userId = null;
        $result = $this->media_parser->getIgnoredEntities($userId);
        echo json_encode($result);
    }

    function remove_blacklists() {
        $userId = $this->session->userdata("user_id");
        if ($clientId == INTERNAL_CLIENT_ID)
            $userId = null;
        $entities = $this->input->post('entities');
        $entityId = $this->input->post("ent_id");

        if (!empty($entities)) {

            foreach ($entities as $values) {
                $result = $this->media_parser->removeBlacklists($userId, $values);
            }
        } else {



            $result = $this->media_parser->removeBlacklists($userId, $entityId);
        }

        if ($result == true)
            echo true;
        else
            echo false;
    }

    function get_tag_names() {
        $userId = $this->session->userdata("user_id");
        $tagName = $this->input->post("keyword");

        $arrSuggestedTagNames = array();
        $arrResult = $this->media_parser->getTagName($userId, $tagName);
        $arrReturnData = array();
        if (sizeof($arrResult) == 0) {
            $arrSuggestedTagNames[0] = 'No results found for ' . $tagName;
        } else {
            $flag = 1;
            foreach ($arrResult as $id => $row) {
                if ($flag) {
                    $arrSuggestedTagNames[] = '<div class="autocompleteHeading">Tag Names</div><div class="dataSet"><label name="' . $row["id"] . '" class="tags" style="display:block">' . $row["tag_name"] . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestedTagNames[] = '<div class="dataSet"><label name="' . $row["id"] . '" class="tags" style="display:block">' . $row["tag_name"] . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $tagName;
        $arrReturnData['suggestions'] = $arrSuggestedTagNames;
        echo json_encode($arrReturnData);
    }

    function get_tags() {
        $entName = $this->input->post("ent_name");
        $userId = $this->session->userdata("user_id");
        $result = $this->media_parser->userSpecificTags($userId, $entName);
        echo json_encode($result);
    }

    function blacklist_entities() {
        $user_id = $this->session->userdata("user_id");
        $entity_id = $this->input->post("entity_id");
        $clientId = $this->session->userdata("client_id");
//        if ($clientId == INTERNAL_CLIENT_ID)
//            $result = $this->media_parser->blacklist_entity($entity_id, null);
//        else
            $result = $this->media_parser->blacklist_entity($entity_id, $user_id);
        echo $result;
    }

    function search_entity_name($category, $people, $organization, $company, $product, $technology, $disease, $selOption, $startDate, $endDate, $keyword) {

        $arrFilters = array();
        $People = array();
        $Organization = array();
        $Company = array();
        $Product = array();
        $Technology = array();
        $Disease = array();
        $People = explode(',', $people);
        $Organization = explode(',', $organization);
        $Company = explode(',', $company);
        $Product = explode(',', $product);
        $Technology = explode(',', $technology);
        $Disease = explode(',', $disease);
        // $arrFilters['people']='';
        $startDate=utf8_urldecode($startDate);
        $endDate=utf8_urldecode($endDate);
      
        if ($Disease[0] != 0)
            $arrFilters['disease'] = $Disease;
        if ($Organization[0] != 0)
            $arrFilters['organization'] = $Organization;
        if ($Product[0] != 0)
            $arrFilters['product'] = $Product;
        if ($Technology[0] != 0)
            $arrFilters['technology'] = $Technology;
        if ($Company[0] != 0)
            $arrFilters['company'] = $Company;
        if ($People[0] != 0)
            $arrFilters['people'] = $People;
        if ($startDate != '0')
            $arrFilters['start_date'] =  $startDate;
        if ($endDate != '0')
            $arrFilters['end_date'] = $endDate;
        
        $arrFilters['sel_option'] = $selOption;
//        if ($selOption == 1)
            $arrFilters['user_id'] = $this->session->userdata("user_id");
        $keyword = utf8_urldecode($this->input->post("keyword"));
        $arrSuggested = array();

        //$arrResult=$this->media_parser->searchEntityName($category,$keyword);
        //
          // pr($arrResult);
        if ($category == "people")
            $id = 96;
        if ($category == "disease")
            $id = 100;
        if ($category == "organization")
            $id = 95;
        if ($category == "technology")
            $id = 98;
        if ($category == "company")
            $id = 105;
        if ($category == "product")
            $id = 110;
        $arrResult = $this->media_parser->category_filter($id, $arrFilters, false, false, $keyword, $category);

        // pr($arrResult);

        $arrReturnData = array();
        if (sizeof($arrResult) == 0) {
            $arrSuggested[0] = 'No results found for ' . $keyword;
        } else { {
                $flag = 1;
                foreach ($arrResult as $id => $row) {
                    // $arrSuggested[]=   "<label> <input type='checkbox'    name='".$keyword."[]' hidden  checked='checked'/>".$row["entity_name"]."&nbsp;(".$row["numc"].")</label>";
                    $arrSuggested[] = "<div class=\"dataSet\"><input id='" . $row["entity_name"] . "' class='" . $row["id"] . "'   type=\"checkbox\" value='" . $row["id"] . "'   name='" . $category . "[]' hidden  checked='checked' /><label for='" . $row["id"] . "'  class=\"tags\" style=\"display:block\"><b style='font-weight:normal;font-size:12px;'>" . $row["entity_name"] . "</b>&nbsp;(" . $row["numc"] . ")</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $keyword;
        $arrReturnData['suggestions'] = $arrSuggested;

        echo json_encode($arrReturnData);
    }

    function get_comment_count() {
        $feed_id = $this->input->post("feed_id");
        $resultArr = $this->media_parser->getCommentCount($feed_id);
        echo json_encode($resultArr);
    }

    function ajax_show_more_cats() {
        $arrFilters = array();
        $arrFilters = $_POST;
        $user_id = $this->session->userdata("user_id");
        $category_name = $this->input->post("cat_name");
        $result_ajax = $this->media_parser->getEntityCategoryCount($category_name);
        $bookmarked_content = $this->media_parser->getUsersBookmark($user_id);
        $book_array = array();
        foreach ($bookmarked_content as $values) {
            $book_array[] = $values;
        }
        $blacklist_content = $this->media_parser->getUserBlacklists($user_id);
        $blacklist_array = array();
        foreach ($blacklist_content as $list_values) {
            $blacklist_array[] = $list_values;
        }
        $cat_details = array();
        foreach ($result_ajax as $values) {
            if ($values["rss_feed_url_id"] != '') {
                foreach ($book_array as $marks) {

                    if ($values["id"] == $marks["entity_id"])
                        $values["isbookmarked"] = true;
                }
                foreach ($blacklist_array as $list_values) {

                    if ($values["id"] == $list_values["entity_id"])
                        $values["isblacklisted"] = true;
                }
                if (count($arrFilters['people']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['people']))
                        $values["selected"] = true;
                }
                if (count($arrFilters['disease']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['disease']))
                        $values["selected"] = true;
                }
                if (count($arrFilters['organization']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['organization']))
                        $values["selected"] = true;
                }
                if (count($arrFilters['company']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['company']))
                        $values["selected"] = true;
                }
                if (count($arrFilters['prdouct']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['prdouct']))
                        $values["selected"] = true;
                }
                if (count($arrFilters['technology']) > 0) {
                    if (in_array($values["entity_name"], $arrFilters['technology']))
                        $values["selected"] = true;
                }
                $cat_details[] = $values;
            }
        }
        echo json_encode($cat_details);
    }

    function show_more_entity_filters($date, $userId) {

        $arrFilters = array();
        $arrFilters = $_POST;
        if (!empty($date)) {
            $arrFilters['start_date'] = $date;
            $arrFilters['end_date'] = $date;
        }
        // pr($arrFilters);
        $cat = $this->input->post("loadMoreCat");
        // pr($cat);
        // pr($arrFilters);
        $filterd_feeds = array();
        if (empty($userId))
            $user_id = $this->session->userdata("user_id");
        else {
            $arrFilters['sel_option'] = 1;
            $user_id = $userId;
        }
        // pr($user_id);
        $loadMoreClick = $this->input->post("loadMoreClick");
        // pr($loadMoreClick);
        $arrFilters['user_id'] = $user_id;


        $bookmarked_content = $this->media_parser->getUsersBookmark($user_id);
        foreach ($bookmarked_content as $values) {
            $book_array[] = $values;
        }
        $blacklist_content = $this->media_parser->getUserBlacklists($user_id);
        $blacklist_array = array();
        foreach ($blacklist_content as $list_values) {
            $blacklist_array[] = $list_values;
        }
        $arrPeople = $this->media_parser->category_filter(96, $arrFilters);

        $filterd_feeds["count"]["people"] = $this->media_parser->category_filter(96, $arrFilters, true);
        $filterd_feeds['entity_count']["people"] = count($this->media_parser->category_filter(96, $arrFilters, 0, true));
        $arrPeopleSend = array();
        $i = 0;
        foreach ($arrPeople as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrPeople[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrPeople[$key]["isblacklisted"] = true; //
            }
            if (count($arrFilters['people']) > 0) {
                if (in_array($row["id"], $arrFilters['people'])) {
                    $arrPeople[$key]["selected"] = true;
                }
            }
            if (count($arrFilters['link']) > 0) {
                if (in_array($row["rss_link_id"], $arrFilters['link'])) {
                    $arrPeople[$key]["selected_source"] = true;
                }
            }
            $i++;
            if ($i <= 5 || $arrPeople[$key]["selected"] == true) {
                $arrPeopleSend[] = $arrPeople[$key];
            }
        }
        if (empty($loadMoreClick))
            $filterd_feeds['People'] = $arrPeopleSend;
        else
            $filterd_feeds['People'] = $arrPeople;
        $arrDisease = $this->media_parser->category_filter(100, $arrFilters);
        $filterd_feeds["count"]["disease"] = $this->media_parser->category_filter(100, $arrFilters, true);
        $filterd_feeds['entity_count']["disease"] = count($this->media_parser->category_filter(100, $arrFilters, 0, true));
        $arrDiseaseSend = array();
        $i = 0;
        foreach ($arrDisease as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrDisease[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrDisease[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['disease']) > 0) {
                if (in_array($row["id"], $arrFilters['disease'])) {
                    $arrDisease[$key]["selected"] = true;
                }
            }

            $i++;
            if ($i <= 5 || $arrDisease[$key]["selected"] == true) {
                $arrDiseaseSend[] = $arrDisease[$key];
            }
        }

        if (empty($loadMoreClick))
            $filterd_feeds['MedicalCondition'] = $arrDiseaseSend;
        else
            $filterd_feeds['MedicalCondition'] = $arrDisease;
        $arrTechnology = $this->media_parser->category_filter(98, $arrFilters);
        $filterd_feeds["count"]["technology"] = $this->media_parser->category_filter(98, $arrFilters, true);
        $filterd_feeds['entity_count']["technology"] = count($this->media_parser->category_filter(98, $arrFilters, 0, true));
        $arrTechnologySend = array();
        $i = 0;
        foreach ($arrTechnology as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrTechnology[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrTechnology[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['technology']) > 0) {
                if (in_array($row["id"], $arrFilters['technology'])) {
                    $arrTechnology[$key]["selected"] = true;
                }
            }

            $i++;
            if ($i <= 5 || $arrTechnology[$key]["technology"] == true) {
                $arrTechnologySend[] = $arrTechnology[$key];
            }
        }

        if (empty($loadMoreClick))
            $filterd_feeds['Technology'] = $arrTechnologySend;
        else
            $filterd_feeds['Technology'] = $arrTechnology;
        $arrCompany = $this->media_parser->category_filter(105, $arrFilters);
        $filterd_feeds["count"]["company"] = $this->media_parser->category_filter(105, $arrFilters, true);
        $filterd_feeds['entity_count']["company"] = count($this->media_parser->category_filter(105, $arrFilters, 0, true));
        $arrCompanySend = array();
        $i = 0;
        foreach ($arrCompany as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrCompany[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrCompany[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['company']) > 0) {
                if (in_array($row["id"], $arrFilters['company'])) {
                    $arrCompany[$key]["selected"] = true;
                }
            }

            $i++;
            if ($i <= 5 || $arrCompany[$key]["selected"] == true) {
                $arrCompanySend[] = $arrCompany[$key];
            }
        }
        if (empty($loadMoreClick))
            $filterd_feeds['Company'] = $arrCompanySend;
        else
            $filterd_feeds['Company'] = $arrCompany;


        //pr($filterd_feeds);
        $arrProduct = $this->media_parser->category_filter(110, $arrFilters);
        $filterd_feeds["count"]["product"] = $this->media_parser->category_filter(110, $arrFilters, true);
        $filterd_feeds['entity_count']["product"] = count($this->media_parser->category_filter(110, $arrFilters, 0, true));
        $arrProductSend = array();
        $i = 0;
        foreach ($arrProduct as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrProduct[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrProduct[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['product']) > 0) {
                if (in_array($row["id"], $arrFilters['product'])) {
                    $arrProduct[$key]["selected"] = true;
                }
            }

            $i++;
            if ($i <= 5 || $arrProduct[$key]["selected"] == true) {
                $arrProductSend[] = $arrProduct[$key];
            }
        }

        if (empty($loadMoreClick))
            $filterd_feeds['Product'] = $arrProductSend;
        else {
            $filterd_feeds['Product'] = $arrProduct;
        }
        $arrOrganization = $this->media_parser->category_filter(95, $arrFilters);
        $filterd_feeds["count"]["organization"] = $this->media_parser->category_filter(95, $arrFilters, true);
        $filterd_feeds['entity_count']["organization"] = count($this->media_parser->category_filter(95, $arrFilters, 0, true));
        $arrOrganizationSend = array();
        $i = 0;
        foreach ($arrOrganization as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrOrganization[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrOrganization[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['organization']) > 0) {
                if (in_array($row["id"], $arrFilters['organization'])) {
                    $arrOrganization[$key]["selected"] = true;
                }
            }

            $i++;
            if ($i <= 5 || $arrOrganization[$key]["selected"] == true) {
                $arrOrganizationSend[] = $arrOrganization[$key];
            }
        }

        if (empty($loadMoreClick))
            $filterd_feeds['Organization'] = $arrOrganizationSend;
        else
            $filterd_feeds['Organization'] = $arrOrganization;
        $arrSource = $this->media_parser->category_filter("link", $arrFilters);
        //pr($arrFilters['link']);

        foreach ($arrSource as $key => $row) {

            if (count($arrFilters['link']) > 0) {
                if (in_array($row["id"], $arrFilters['link'])) {

                    $arrSource[$key]["selected"] = true;
                }
            }
        }
        $filterd_feeds["source"] = $arrSource;
        $filterd_feeds["source_count"] = count($arrSource);
        //pr($arrSource);
        $a = array();
        $row = count($filterd_feeds["People"]);
        // pr($arrFilters["people"]);
        if (count($arrFilters['people']) > 0) {
            foreach ($filterd_feeds["People"] as $value) {

                //pr($row);

                foreach ($arrFilters["people"] as $result) {
                    //pr($result);
//                    if(!(in_array($result,$value)))
//                     {
//
//                           $filterd_feeds["People"][$row]["id"]="123";
//                             $filterd_feeds["People"][$row]["name"]="yuvi";
//                             $row++;
//                     }
                }
            }
        }
//            pr($a);
////            pr($arrFilters['people']);
//                $people=array();
//                 foreach($filterd_feeds["People"] as $value)
//                {
//                   $people[]=$value["id"];
//                }
//               foreach($arrFilters["people"] as $result)
//               {
//                    if(!in_array($result,$people))
//                    {
//                          $filterd_feeds["People"][$row]["id"]=$result;
//                          //$this->media_parser->getEntityName
//                             $filterd_feeds["People"][$row]["entity_name"]="yuvi";
//                              $filterd_feeds["People"][$row]["selected"]=true;
//                             $row++;
//                    }
//                          
//                            
//               }
        //pr($flag);
        // echo $flag;
//                  pr($filterd_feeds);
//                exit;
        //ob_start('ob_gzhandler');
        $gridDetials = array();
        if ($cat == 'people' || $cat == 'disease' || $cat == 'organization' || $cat == 'technology' || $cat == 'product' || $cat == 'company') {
            if ($cat == 'disease')
                $cat = "medicalCondition";
            $cats = ucfirst($cat);
            $Category = array();
            $Category[$cats] = $filterd_feeds[$cats];
            foreach ($Category[$cats] as $key => $values) {
                $gridDetials[] = array("id" => $values["id"], "entity_name" => $values["entity_name"], "numc" => $values["numc"], "isbookmarked" => $values["isbookmarked"]);
            }
            $data['records'] = count($Category[$cats]);
            $data['total'] = 100;
            $data['page'] = 1;
            $data['rows'] = $gridDetials;

            echo json_encode($data);
//                            
//                        if( $cat=="medicalCondition")
//                        {
//                            $Category["count"]["disease"]=$filterd_feeds["count"]["disease"];
//                            $Category["entity_count"]["disease"]=$filterd_feeds["entity_count"]["disease"];
//                        }
//                        else{
//                            $Category["count"][$cat]=$filterd_feeds["count"][$cat];
//                            $Category["entity_count"][$cat]=$filterd_feeds["entity_count"][$cat];
//                        }
//                        echo json_encode($Category);
//                        }
//                        else
//                            if(empty($date))
//                                echo json_encode($filterd_feeds);
//                            else
//                                return $filterd_feeds;
        }
    }

    function ajax_entity_filters($date, $userId,$isPreloadSet) {
        $arrFilters = array();
        $arrFilters = $_POST;
       
// if(!(isset($arrFilters['people'])) && !(isset($arrFilters['organization'])) && !(isset($arrFilters['disease'])) && !(isset($arrFilters['link'])) && !(isset($arrFilters['company'])) && !(isset($arrFilters['technology'])) && !(isset($arrFilters['product'])) && $arrFilters["sel_option"]==0 && $isPreloadSet!=1)
// {          
//     $this->get_preloaded_datas();
//     exit;
// }
        if (!empty($date)) {
            $arrFilters['start_date'] = $date;
            $arrFilters['end_date'] = $date;
        }
        // pr($arrFilters);
        $cat = $this->input->post("loadMoreCat");
        // pr($cat);
        // pr($arrFilters);
        $filterd_feeds = array();
        if (empty($userId))
            $user_id = $this->session->userdata("user_id");
        else {
            $arrFilters['sel_option'] = 1;
            $user_id = $userId;
        }
        if($arrFilters["start_date"]=='' && $arrFilters["end_date"]=='')
        {
            
        $arrFilters['start_date'] = date('Y-m-d', strtotime(' -30 day'));;
         $arrFilters['end_date'] = date('Y-m-d');
        }
      
        // pr($user_id);
        $loadMoreClick = $this->input->post("loadMoreClick");
        // pr($loadMoreClick);
        $arrFilters['user_id'] = $user_id;


        $bookmarked_content = $this->media_parser->getUsersBookmark($user_id);
        foreach ($bookmarked_content as $values) {
            $book_array[] = $values;
        }
        $blacklist_content = $this->media_parser->getUserBlacklists($user_id);
        $blacklist_array = array();
        foreach ($blacklist_content as $list_values) {
            $blacklist_array[] = $list_values;
        }
        $arrPeople = $this->media_parser->category_filter(96, $arrFilters);

        $filterd_feeds["count"]["people"] = $this->media_parser->category_filter(96, $arrFilters, true);
        $filterd_feeds['entity_count']["people"] = count($this->media_parser->category_filter(96, $arrFilters, 0, true));
        $arrPeopleSend = array();
        $i = 0;

        foreach ($arrPeople as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrPeople[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrPeople[$key]["isblacklisted"] = true; //
            }
            if (count($arrFilters['people']) > 0) {
                if (in_array($row["id"], $arrFilters['people'])) {
                    $arrPeople[$key]["selected"] = true;
                }
            }
            if (count($arrFilters['link']) > 0) {
                if (in_array($row["rss_link_id"], $arrFilters['link'])) {
                    $arrPeople[$key]["selected_source"] = true;
                }
            }
            $i++;
            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrPeople[$key]["selected"] == true) {
                    $arrPeopleSend[] = $arrPeople[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrPeople[$key]["selected"] == true) {
                    $arrPeopleSend[] = $arrPeople[$key];
                }
            }
        }

        //if(empty($loadMoreClick))
        $filterd_feeds['People'] = $arrPeopleSend;
        //   else
        //   $filterd_feeds['People'] = $arrPeople;
        $arrDisease = $this->media_parser->category_filter(100, $arrFilters);
        $filterd_feeds["count"]["disease"] = $this->media_parser->category_filter(100, $arrFilters, true);
        $filterd_feeds['entity_count']["disease"] = count($this->media_parser->category_filter(100, $arrFilters, 0, true));
        $arrDiseaseSend = array();
        $i = 0;

        foreach ($arrDisease as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrDisease[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrDisease[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['disease']) > 0) {
                if (in_array($row["id"], $arrFilters['disease'])) {
                    $arrDisease[$key]["selected"] = true;
                }
            }

            $i++;

            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrDisease[$key]["selected"] == true) {
                    $arrDiseaseSend[] = $arrDisease[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrDisease[$key]["selected"] == true) {
                    $arrDiseaseSend[] = $arrDisease[$key];
                }
            }
        }

        $filterd_feeds['MedicalCondition'] = $arrDiseaseSend;

        $arrTechnology = $this->media_parser->category_filter(98, $arrFilters);
        $filterd_feeds["count"]["technology"] = $this->media_parser->category_filter(98, $arrFilters, true);
        $filterd_feeds['entity_count']["technology"] = count($this->media_parser->category_filter(98, $arrFilters, 0, true));
        $arrTechnologySend = array();
        $i = 0;
        foreach ($arrTechnology as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrTechnology[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrTechnology[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['technology']) > 0) {
                if (in_array($row["id"], $arrFilters['technology'])) {
                    $arrTechnology[$key]["selected"] = true;
                }
            }

            $i++;

            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrTechnology[$key]["technology"] == true) {
                    $arrTechnologySend[] = $arrTechnology[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrTechnology[$key]["selected"] == true) {
                    $arrTechnologySend[] = $arrTechnology[$key];
                }
            }
        }

        //   if(empty($loadMoreClick))
        $filterd_feeds['Technology'] = $arrTechnologySend;
        // else
        // $filterd_feeds['Technology'] = $arrTechnology;
        $arrCompany = $this->media_parser->category_filter(105, $arrFilters);
        $filterd_feeds["count"]["company"] = $this->media_parser->category_filter(105, $arrFilters, true);
        $filterd_feeds['entity_count']["company"] = count($this->media_parser->category_filter(105, $arrFilters, 0, true));
        $arrCompanySend = array();
        $i = 0;
        foreach ($arrCompany as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrCompany[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrCompany[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['company']) > 0) {
                if (in_array($row["id"], $arrFilters['company'])) {
                    $arrCompany[$key]["selected"] = true;
                }
            }

            $i++;

            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrCompany[$key]["selected"] == true) {
                    $arrCompanySend[] = $arrCompany[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrCompany[$key]["selected"] == true) {
                    $arrCompanySend[] = $arrCompany[$key];
                }
            }
        }
        // if(empty($loadMoreClick))
        $filterd_feeds['Company'] = $arrCompanySend;
        // else
        //  $filterd_feeds['Company'] = $arrCompany;
        //pr($filterd_feeds);
        $arrProduct = $this->media_parser->category_filter(110, $arrFilters);
        $filterd_feeds["count"]["product"] = $this->media_parser->category_filter(110, $arrFilters, true);
        $filterd_feeds['entity_count']["product"] = count($this->media_parser->category_filter(110, $arrFilters, 0, true));
        $arrProductSend = array();
        $i = 0;
        foreach ($arrProduct as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrProduct[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrProduct[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['product']) > 0) {
                if (in_array($row["id"], $arrFilters['product'])) {
                    $arrProduct[$key]["selected"] = true;
                }
            }

            $i++;

            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrProduct[$key]["selected"] == true) {
                    $arrProductSend[] = $arrProduct[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrProduct[$key]["selected"] == true) {
                    $arrProductSend[] = $arrProduct[$key];
                }
            }
        }


        $filterd_feeds['Product'] = $arrProductSend;
        $arrOrganization = $this->media_parser->category_filter(95, $arrFilters);
        $filterd_feeds["count"]["organization"] = $this->media_parser->category_filter(95, $arrFilters, true);
        $filterd_feeds['entity_count']["organization"] = count($this->media_parser->category_filter(95, $arrFilters, 0, true));
        $arrOrganizationSend = array();
        $i = 0;
        foreach ($arrOrganization as $key => $row) {
            foreach ($book_array as $marks) {

                if ($row["id"] == $marks["entity_id"])
                    $arrOrganization[$key]["isbookmarked"] = true;
            }
            foreach ($blacklist_array as $list_values) {

                if ($row["id"] == $list_values["entity_id"])
                    $arrOrganization[$key]["isblacklisted"] = true;
            }
            if (count($arrFilters['organization']) > 0) {
                if (in_array($row["id"], $arrFilters['organization'])) {
                    $arrOrganization[$key]["selected"] = true;
                }
            }

            $offset = $this->input->post('show_more_offset');
            $i++;


            if (empty($loadMoreClick)) {
                if ($i <= 5 || $arrOrganization[$key]["selected"] == true) {
                    $arrOrganizationSend[] = $arrOrganization[$key];
                }
            } else {
                $offset = $this->input->post('show_more_offset');
                $endOffset = 1 * $offset + 10;
                if (($i > $offset && $i <= $endOffset) || $arrOrganization[$key]["selected"] == true) {
                    $arrOrganizationSend[] = $arrOrganization[$key];
                }
            }
        }

        // if(empty($loadMoreClick))
        $filterd_feeds['Organization'] = $arrOrganizationSend;
        // else
        //  $filterd_feeds['Organization'] = $arrOrganization;
        $arrSource = $this->media_parser->category_filter("link", $arrFilters);

//           //pr($arrFilters['link']);
//      
        foreach ($arrSource as $key => $row) {

            if (count($arrFilters['link']) > 0) {
                if (in_array($row["id"], $arrFilters['link'])) {

                    $arrSource[$key]["selected"] = true;
                }
            }
        }
        $filterd_feeds["source"] = $arrSource;
        $filterd_feeds["source_count"] = count($arrSource);

        //ob_start('ob_gzhandler');
        if ($cat == 'people' || $cat == 'disease' || $cat == 'organization' || $cat == 'technology' || $cat == 'product' || $cat == 'company') {
            if ($cat == 'disease')
                $cat = "medicalCondition";
            $cats = ucfirst($cat);
            $Category = array();
            $Category[$cats] = $filterd_feeds[$cats];

            if ($cat == "medicalCondition") {
                $Category["count"]["disease"] = $filterd_feeds["count"]["disease"];
                $Category["entity_count"]["disease"] = $filterd_feeds["entity_count"]["disease"];
            } else {
                $Category["count"][$cat] = $filterd_feeds["count"][$cat];
                $Category["entity_count"][$cat] = $filterd_feeds["entity_count"][$cat];
            }
            echo json_encode($Category);
        } else
        if (empty($date) && $isPreloadSet!=1)
        {
           
            
                echo json_encode($filterd_feeds);
//            pr($filterd_feeds)
            
        }
        else
        {
            
                return $filterd_feeds;
        }
        //Add Log activity
        $arrLogDetails = array(
        'type' => VIEW_RECORD,
        'description' => "Visited Media Page",
        'status' => STATUS_SUCCESS,
        'transaction_name' => "View Media Page"
        		);
        $this->config->set_item('log_details', $arrLogDetails);
    }
    
    function get_preloaded_datas()
    {
        $this->media_parser->getPreloadedData();
    }
    function user_comments() {
        $user_id = $this->session->userdata("user_id");
        $comment = $this->input->post("comment");
        $feed_id = $this->input->post("feed_id");
        $date = date("Y-m-d H:i:s");
        $result = $this->media_parser->saveComment($user_id, $comment, $feed_id);
        if ($result) {
            $timeago = get_timeago(strtotime($date));
            $submiteDetails = array("date" => $timeago, "first_name" => $result["first_name"], "last_name" => $result["last_name"]);
        }
        echo json_encode($submiteDetails);
    }

    function get_comments() {
        $commmentDetails = array();
        $feed_id = $this->input->post("feed_id");
        $result = $this->media_parser->getComment($feed_id);
        foreach ($result as $values) {
            $timeago = get_timeago(strtotime($values['date']));

            $values["date"] = $timeago;
            $commentDetails[] = $values;
        }
        echo json_encode($commentDetails);
    }

    function parse_data($value, $rssLinkId, $rssId, $contents) {
        $catArr = array();
        $entArr = array();
        /**
         * Get attribute_name and value from rss_link table
         */
        $this->load->model('media_parser');
        $result = $this->media_parser->getRssLinkData($rssLinkId);
        // echo $this->db->last_query();
        $attribute_name = $result['attribute_name'];
        $attribute_value = $result['attribute_value'];
        $tag_name = $result['tag_name'];
        $this->load->model('media_parser');
        /** feed_url from parse_data function * */
        $feed_url = $value["link"];
        /**
         * Obtain an API Key by registering on website
         * 
         */
        $apikey = "F845L8s6ahZ98fuDzLV41d7pRPqdv2LC";
        $oc = new HTTPSClientCalaisPost();
        
        /**
         * Get the content of feed_url
         */
        $content = $contents;
        /**
         * Create a dom object and get the article inner content and discard rest of the data
         */
        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $doc->loadHTML($content);
        libxml_use_internal_errors(false);
        $items = $doc->getElementsByTagName($tag_name);
        $i = 0;
        foreach ($items as $item) {
            if ($item->hasAttribute($attribute_name) && $item->getAttribute($attribute_name) == $attribute_value) {
                /**
                 * Cal function DOMinnerHTML to extract inner article main content
                 */
                $article_content = DOMinnerHTML($item);
                //log for inner article content laong with feed_id
                /**
                 * Get the entities and entity_type of the extracted inner article content from API
                 * and Loop through each type and entity and insert it into tables
                 */
              $entities = $oc->request($apikey,$article_content);
               $resultData=json_decode($entities, TRUE);
              
               foreach($resultData as $key=>$datas){
//                   var_dump($datas['_typeGroup']."=>".$datas['_type']."=>".$datas['name']);
                   $result = $this->media_parser->insertParsedEntity($datas['_type'], $datas['name'], $feed_url, $rssId);
//                    var_dump($datas);
               }
               
                if(empty($entities))
                {
                     $logEntArrFail=array("id"=>NULL,"module"=>"parse_data","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"entities coudnt be extracted either due to error in article content or API",
                        "type"=>"entity_extract","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logEntArrFail);
                }
                else
                {
                    $logEntArrSucc=array("id"=>NULL,"module"=>"parse_data","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"",
                        "type"=>"entity_extract","status"=>"success","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logEntArrSucc);
                }
//                    pr(strlen($article_content));
//                    exit;


//                foreach ($entities as $type => $values) {
//                    $catArr[] = $type;
//                    foreach ($values as $entity) {
//                        $entArr[] = $entity;
//                        $result = $this->media_parser->insertParsedEntity($type, $entity, $feed_url, $rssId);
//                    }
//                }
                //log for obatined entities along with rss_feed id and innercontent

               // $this->media_parser->logEntitiesCatAndInnerContent($rssId, count($catArr), count($entArr), strlen($article_content));
            }
        }
    }

    /*     * function to get feed urls associated with a link
     * 
     */
    function log_article_clicks()
    {
//     pr($this->session->userdata);
        $url=$this->input->post("articleUrl");
         $userId = $this->session->userdata("user_id");
         $logArticle=array("id"=>NULL,"module"=>"log_article_clicks","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$url,"description"=>"",
                        "type"=>"userClick","status"=>"","file_name"=>"","client_id"=>$userId,"browser"=>$this->session->userdata("user_agent"),"os"=>"","ip_address"=>$this->session->userdata("ip_address"));  
          $this->media_log($logArticle);
    }
    function get_data() { /*
     * Require opencalais file to conenct to opencalais API
     */
   
        $j=0;
        require('opencalais.php');
        $this->load->model('media_parser');
        /*
         * Get the rss_link from rss_link table to fetch individual feed urls
         */
        $result = $this->media_parser->getRssLinkId();

        /**
         * loop through Each links and get the feed urls,title,date,description
         */
        //pr($result);
        foreach ($result as $values) {
           $rssUrls= explode(",", $values->link);
           foreach($rssUrls as $val)
           {
          
           $rssUrl=$val;
         
            $doc = new DOMDocument();
            $doc->load($rssUrl);
            $arrFeeds = array();
            $arrDetails = array();
            $i = 0;
            foreach ($doc->getElementsByTagName('item') as $node) {
                $titleObj = $node->getElementsByTagName('title')->item(0);
                if ($titleObj != null) {
                    $itemRSS['title'] = $titleObj->nodeValue;
                    $itemRSS['desc'] = "";
                    $itemRSS['link'] = "";
                    $itemRSS['date'] = "";
                    $descObj = $node->getElementsByTagName('description')->item(0);
                    if ($descObj != null)
                        $itemRSS['desc'] = $descObj->nodeValue;
                    if ($rssUrl == "http://rss.biospace.com/newsstory.rss")
                        $itemRSS['desc'] = strip_tags($itemRSS['desc']);
                    $linkObj = $node->getElementsByTagName('link')->item(0);
                    if ($linkObj != null)
                        $itemRSS['link'] = $linkObj->nodeValue;
                    $dateObj = $node->getElementsByTagName('pubDate')->item(0);
                    if ($dateObj != null)
                        $itemRSS['date'] = $dateObj->nodeValue;
                }
                array_push($arrFeeds, $itemRSS);
                /**
                 * Store each of the obtained feed_urls  details in array
                 */
                $arrDetails[] = $itemRSS;
                $i++;
                if($i>5)
                    break;
            }
            //  pr($arrDetails)."<br/>";
            /**
             * Loop through array to get individual feed_url link
             */
//                pr(count($arrDetails))."<br/>";
//                 pr($values->id);
            //  $resultOldCount=$this->media_parser->oldRssCount($values->id);
            //   $oldRssCount=$resultOldCount["count"];

            foreach ($arrDetails as $value) {
                $this->load->model('media_parser');
                $contents = file_get_contents($value['link']);
              
                require_once 'alchemyapi.php';
                $alchemyapi = new AlchemyAPI();
               
//              
//                    
//
                $response = $alchemyapi->imageExtraction('url',$value["link"], null);
                 $img_url=$response["image"];
                    if (empty($img_url)) 
                    {
                          $api_url = "http://api.embed.ly/1/extract?key=b2f5bb2b578049979caca4d12cecd990&url=" . $value["link"] . "&maxwidth=100px&maxheight=100px";
                /**
                 * Insert feed_url and it contents to database
                 */
                $api_content = file_get_contents($api_url);
//                    $json_content=trim($api_content,'?()');
                $obj = json_decode($api_content);

                if (empty($value["description"])) {
                    $value["description"] = $obj->description;
                }
                if (isset($obj->related[0]->thumbnail_url)) {
                    $img_url = $obj->related[0]->thumbnail_url;
                } else {
                    $img_url = $obj->images[0]->url;
                }
                if (empty($img_url)) {
                    $img_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbMpL-ka6O0_jq0YUoPqTkfePaPxtXQ0eARuLNFSaFzrSlyksy2MjCrg";
                }
                    }
               
               
                $date = $value["date"];
                $old_article_timestamp = strtotime($date);
                $newArticleDate = date('Y-m-d', $old_article_timestamp);


                $old_current_timestamp = strtotime(date("Y-m-d"));
                $newCurrentDate = date('Y-m-d', $old_current_timestamp);
                if ((strtotime($newArticleDate) > strtotime($newCurrentDate)) || strtotime($newArticleDate) == "0000:00:00 00:00:00") {
                    $valid = "no";
                } else {
                    $valid = "yes";
                }

                if ($valid == "yes")
                {
                    $value['description']=preg_replace('~<style(.*?)</style>~Usi', "", $value['description']);
                    $res = $this->media_parser->insertFeedUrl($value, $values->id, $contents, $img_url);
                   
                    
                     if($res)   
                     {
                    $logArr=array("id"=>NULL,"module"=>"media_feature","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"",
                        "type"=>"feeedInsert","status"=>"success","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logArr);
                     }
//                     else
//                     {
//                         $logArrFail=array("id"=>NULL,"module"=>"media_feature","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"feed Coudnt be inserted into database",
//                        "type"=>"feeedInsert","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
//                     }
                    
                       
                      
                    
                   
                }


                if ($res) {
                    /**
                     * If rss_feed url doesnt exsist in table
                     * Pass each feed_url,rss_link to parse_data function to extract entities
                     * 
                     * rssUrl is passed to get attribute name and value of rss_link 
                     * to extract article content for parsing data
                     */
                    $resId = $this->media_parser->getFeedId($value['link']);

                    if (empty($resId["id"])) {
                        echo "resId:" . $resId["id"] . "<br/>";
                    } else {
                       
                        $this->parse_data($value, $values->id, $resId["id"], $contents);
                    }
                } else {
                    /** Discard:rss feed_url entry exists and was already parsed
                     * 
                     */
                    //echo "entry exists";
                     $logArrFail=array("id"=>NULL,"module"=>"media_feature","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"feed Exists in database",
                        "type"=>"feeedInsert","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                }
            }
            //code to log id fo rss_link and count of todays rss_feeds
//          $j++;
//            if($j>6)
//                break;
            //$this->media_parser->logSourceIdAndFeedCount(count($arrDetails), $values->id, $oldRssCount);
       
           }}
        $this->prepareINsertStatmentsForSync();
       
    }

    function prepareInsertStatmentsForSync() {
       
       $content= $this->media_parser->prepareInsertStatmentsForSyncs();
      
       $this->sendMailToAdmin($content);
    }

    function downloadServerFile() {
        // error_reporting(E_ALL);
        $content='';
        $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . 'dbsync/';
        // define some variables
  
        $local_file = $path.date('Y-m-d').".zip";

        $server_file = "/var/www/kolm/dbsync/".date('Y-m-d').".zip";
         echo $local_file;
        //$local_file = $path."/". date("Y-m-d",strtotime("-1 day")).".zip";
        //$server_file = "/kolm/dbsync/".date("Y-m-d",strtotime("-1 day")).".zip";
      
        // set up basic connection
        $conn_id = ftp_connect("203.129.219.196");

        // login with username and password
        $login_result = ftp_login($conn_id, "aisselftp196", "aisselftp196");
        if($login_result)
        {
             $logEntArrSucc=array("id"=>NULL,"module"=>"downloadServerFile","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"",
                        "type"=>"entity_extract","status"=>"success","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logEntArrSucc);
                     echo "login done";
        }
        else
        {
             $logEntArrFail=array("id"=>NULL,"module"=>"downloadServerFile","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>$value["link"],"description"=>"Server connection failed",
                        "type"=>"entity_extract","status"=>"fail","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
                    
                     $this->media_log($logEntArrFail);
                     echo "failed login";
                     exit();
        }

        // try to download $server_file and save to $local_file

        include '/var/www/html/sec/vendor/test.php';
        // if (ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)) {
        //     echo "downloading..";
        //    $content="File was downloaded and was wirrte to colpal \n";
        //     $zip = new ZipArchive;
        //     if ($zip->open($local_file) === TRUE) {
        //         if($zip->extractTo($path.'/'))
        //         {
        //             echo "zip extracted";
        //             $this->check_for_updates ($local_file);
        //             $content+="The file was extracted to colpal \n";
        //         }
        //         else
        //              $content+="There was a problem in zip \n";
        //         $this->sendMailToAdmin($content);
        //         $zip->close();
        //     } else {
        //          $content+="There was a problem in zip \n";
        //           $this->sendMailToAdmin($content);
        //     }
        //     return true;
        // } else {
        //     //Try one more time
        //     if (ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)) {
        //        // echo "Successfully written to $local_file\n";
        //         $zip = new ZipArchive;
        //         if ($zip->open($local_file) === TRUE) {
        //             if($zip->extractTo($path.'/'))
        //                 $this->check_for_updates ($local_file);
        //            else
        //                  $content+="There was a problem in zip \n";
        //             $zip->close();
        //         } else {
        //             $content+="There was a problem in zip \n";
        //         }
        //         return true;
        //     } else {
        //         echo "ftp get failed..";
        //         $content+="There was a problem in zip \n";
        //           $this->sendMailToAdmin($content);
        //         unlink($local_file);
        //         return false;
        //     }
        // }

        // // close the connection
        // ftp_close($conn_id);
    }
    
	function check_for_updates($filePath)
    {
        $filePath = str_replace(".zip", ".sql", $filePath);
		$dbhostname = $this->db->hostname;    // Database hostname
		$arrHostAndPort	= explode(':',$dbhostname);
		$dbhostname	= $arrHostAndPort[0];	
        $dbuser = $this->db->username;    // Database username
        $dbpwd = $this->db->password;  // Database password
        $dbname = $this->db->database;  // Database name. Use --all-databases if you have more than one
        //echo $filename;
        //         $command = "mysql -h $dbhostname -u $dbuser --password=$dbpwd --database= $dbname < $filePath";
        $command = "mysql -h $dbhostname -u $dbuser --password=$dbpwd --default_character_set utf8 --database= $dbname < $filePath";
        //echo $command;
        $output = shell_exec($command);
        $this->sendMailToAdmin("The file was read and imported to Colpal database ");
        //pr($output);
	}
	
	function update_by_file($filename)
    {
    	if(!empty($filename)){
	    	$filePath	= "/var/www/html/".$this->config->item('app_folder_path')."dbsync/".$filename.".sql";
	    	$this->check_for_updates($filePath);
    	}
	}

    function get_feed_url() {
        require('opencalais.php');
        $res = $this->media_parser->getFeedUrl();
        foreach ($res as $values) {
            $rowData = $this->media_parser->getFeedDetailsById($values['id']);
            $this->parse_data($rowData, $rowData["rss_link_id"], $values["id"]);
        }
    }

    function get_kol_feeds($completeName) {
        $user_id = $this->session->userdata("user_id");
        $arrParams = array();

        $arrParams['people'] = $completeName;
        $arrStatFilters = $completeName;
        $arrParams['stat_filters'] = $arrStatFilters;
        $result_ajax = $this->media_parser->getKolFeeds($completeName);
        foreach ($result_ajax as $values) {

            $values["description"] = strip_tags($values["description"]);
            $values['bookmarks'] = $this->media_parser->getUserAjaxUserBookmarks($user_id, $values["rss_feed_url_id"]);

            $old_date_timestamp = strtotime($values['date']);
            $new_date = date('M d, Y ', $old_date_timestamp);
            $values["date"] = $new_date;
            $feed_details[] = $values;
        }
        return $feed_details;
    }
    function storePreloadedData()
    {
       $result= $this->ajax_entity_filters(null,null,1);
       $this->media_parser->storePreloadedData($result);
    }
    function embedTesting() {
        $api_url = "http://api.embed.ly/1/extract?key=8cafcfa0f34645b1ba4a6cedb4919cfd&url=http://pharmabiz.com/ArticleDetails.aspx?aid=88301&sid=14&maxheight=100px";
        /**
         * Insert feed_url and it contents to database
         */
        $api_content = file_get_contents($api_url);

        $json_content = trim($api_content, '?()');
        $obj = json_decode($api_content);
        pr($obj);
//                      foreach($obj->related as $values)

        if (isset($obj->related[0]->thumbnail_url)) {
            $img_url = $obj->related[0]->thumbnail_url;
            pr($img_url);
        } else {
            $img_url = $obj->images[0]->url;
            pr($img_url);
        }
    }

    function get_feeds() {
        
        $arrParams = array();
        $arrParams = $_POST;
        $user_id = $this->session->userdata('user_id');
        $tagName = $this->input->post('tag_name');
        if ($tagName != '')
            $arrParams["tag_name"] = $tagName;
        $startDate = $this->input->post('start_date');
        //pr($starDate);
        $endDate = $this->input->post('end_date');



        $selOption = $this->input->post('sel_option');
        $arrParams['offset'] = $this->input->post('offset');
        $sourceLinkId = $this->input->post('link');
        if (!empty($startDate)) {
           
            $old_startdate_timestamp = strtotime($startDate);
            $startDate = date('Y-m-d', $old_startdate_timestamp);
            $arrParams['start_date'] = $startDate;
        }
        if (!empty($endDate)) {
          
            $old_enddate_timestamp = strtotime($endDate);
            $endDate = date('Y-m-d', $old_enddate_timestamp);
            $arrParams['end_date'] = $endDate;
        }
        if ($selOption != 0) {
            $arrParams['user_id'] = $user_id;
        }
        if ($sourceLinkId != '') {
            $arrParams['source_id'] = $sourceLinkId;
        }
   if(  empty($startDate) && empty($endDate))
        {
   
        $arrParams['start_date'] = date('Y-m-d', strtotime(' -30 day'));;
         $arrParams['end_date'] = date('Y-m-d');
        }
        if (isset($arrParams["tag_name"])) {
            unset($arrParams['people']);
            unset($arrParams['disease']);
            unset($arrParams['organization']);
            unset($arrParams['technology']);
            unset($arrParams['company']);
            unset($arrParams['product']);
            $result = $this->media_parser->getTagEntities($tagName);

            foreach ($result as $values) {
                if ($values["category_name"] == "MedicalCondition") {
                    $arrParams['disease'][] = $values["id"];
                }
                if ($values["category_name"] == "Person") {
                    $arrParams['people'][] = $values["id"];
                }
                if ($values["category_name"] == "Organization") {
                    $arrParams['organization'][] = $values["id"];
                }
                if ($values["category_name"] == "Technology") {
                    $arrParams['technology'][] = $values["id"];
                }
                if ($values["category_name"] == "Company") {
                    $arrParams['company'][] = $values["id"];
                }
                if ($values["category_name"] == "Product") {
                    $arrParams['product'][] = $values["id"];
                }
            }
        }
        $arrStatFilters = array();
        if (isset($arrParams['people'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['people']);
        }
        if (isset($arrParams['disease'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['disease']);
        }
        if (isset($arrParams['company'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['company']);
        }
        if (isset($arrParams['technology'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['technology']);
        }
        if (isset($arrParams['organization'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['organization']);
        }
        if (isset($arrParams['product'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['product']);
        }
        if (isset($arrParams['source_id'])) {
            $arrStatFilters = array_merge($arrStatFilters, $arrParams['source_id']);
        }
        $arrParams['stat_filters'] = $arrStatFilters;
        $result_ajax = $this->media_parser->getFeedsToDisplay($arrParams);
         $result_ajax_count = $this->media_parser->getFeedsToDisplay($arrParams,true);
        foreach ($result_ajax as $values) {
            
            $values["description"] = strip_tags($values["description"]);
            $values['bookmarks'] = $this->media_parser->getUserAjaxUserBookmarks($user_id, $values["rss_feed_url_id"]);
            $resultArr = $this->media_parser->getCommentCount($values["rss_feed_url_id"]);
            $values["commentCount"] = $resultArr["comment_count"];
            $date=explode(' ',$values['date']);
            $dateNew=date_create($date[0]);
            $values["date"] = date_format($dateNew,"M d, Y");;
            $values["feedCount"]=count($result_ajax_count);
            $feed_details[] = $values;
        }
        $countArr=array();
//       if(!())
//       {
//           $result=$this->media_parser->getPreloadedData();    
//       }
        ob_start('ob_gzhandler');
        echo json_encode($feed_details);
    }

    function get_all_counts($kolId, $type) {
        $arrData = array();
        if ($type != '' && $type == 'Market Access') {
            if ($arrData["AllAff"] = $this->kol->getAllAffTypes($kolId, "")) {
                $arrData["AffUnivHosp"] = $this->kol->getAllAffTypes($kolId, "university");
                $arrData["AffAssoc"] = $this->kol->getAllAffTypes($kolId, "association");
                $arrData["AffIndustry"] = $this->kol->getAllAffTypes($kolId, "industry");
                $arrData["AffGovtAgency"] = $this->kol->getAllAffTypes($kolId, "government");
                $arrData["AffOthers"] = $this->kol->getAllAffTypes($kolId, "others");
            } else {
                $arrData["AffUnivHosp"] = false;
                $arrData["AffAssoc"] = false;
                $arrData["AffIndustry"] = false;
                $arrData["AffGovtAgency"] = false;
                $arrData["AffOthers"] = false;
            }
            $arrData["Event"] = $this->kol->getEvent($kolId);
            $arrData["Pubs"] = $this->kol->getPubs($kolId);
            $arrData["ClinicalTrial"] = $this->kol->getAllClinicalTrials($kolId);
            $arrData["SocialMedia"] = $this->kol->getSocialMediaCount($kolId);
            $arrData["Media"] = $this->kol->getMediaCount($kolId);
        } else {
            $arrData["AllAff"] = true;
            $arrData["AffUnivHosp"] = true;
            $arrData["AffAssoc"] = true;
            $arrData["AffIndustry"] = true;
            $arrData["AffGovtAgency"] = true;
            $arrData["AffOthers"] = true;
            $arrData["Event"] = true;
            $arrData["Pubs"] = true;
            $arrData["ClinicalTrial"] = true;
            $arrData["SocialMedia"] = $this->kol->getSocialMediaCount($kolId);
            $arrData["Media"] = $this->kol->getMediaCount($kolId);
        }
        return $arrData;
    }

    function restore_empty_images() {
        $this->media_parser->restore();
    }
    function clear_ambugates()
    {
       $this->media_parser->clearAmbugates();
    }
    function opencalais_test() {
        error_reporting(E_ALL);
        require('opencalais.php');
        $apikey = "ud6upwzgxuj2x5ef26vx9qc4";
        //$apikey = '82FjCOLPvEKdeQrqyGeWerjys1uULK8S';
        $oc = new OpenCalais($apikey);

        $content = file_get_contents("D:\Programs\wamp\www\kolm_core\application\controllers\htmltext.txt");
        //$article_content=DOMinnerHTML($item); 

        $article_content = "A new study states that there is no strong evidence to suggest that varenicline, a common smoking cessation drug, is associated with increased risks of adverse health outcomes.";
        $entities = $oc->getEntities($content);
        pr($entities);
    }
    
    
    function filemanager(){
        $this->session->set_userdata('username', 'admin');
        $this->session->set_userdata('repository', 'default');
        $this->session->set_userdata('userlevel', '3');
//            pr( $this->session->userdata);
          $data['contentPage'] = 'media_inteligence/filemanager';
        $this->load->view('layouts/client_view', $data);
    }
    
    function analyst_entity_actions(){
       $ent_ids = explode(',',$this->input->post('ids'));
       $type=$this->input->post('type');
       $client_id=$this->input->post('client_id');
       $user_ids=$this->input->post('user_ids');
         $arrUserResults	= $this->client_User->getUsers($client_id,true);
     //    if($this->session->userdata('user_id')==232){
      //   	echo $this->db->last_query();
     //    }
       $this->media_parser->analystAction($ent_ids,$user_ids,$type,$client_id,$arrUserResults);
    }

    function get_users($client_id){
       $data= $this->client_User->getUsers($client_id);
       echo json_encode($data);
    }
    
    function get_entity_users($id,$type){
        $data= $this->media_parser->getEntityUsers($id,$type);
        echo json_encode($data);
    }
    
    function unsubscribe($userId){
        $data['user_id']=$userId;
        $data['contentPage'] = 'login/media_unsubscribe';
        $this->load->view('layouts/app_view', $data);
    }
    
    function email_option(){
        $result=$this->media_parser->getEmailSettings();
        echo json_encode($result);
    }
    
    function disable_popup(){
         $result=$this->media_parser->disablePopUp();
    }
    function deleteNull(){
        
    $this->db->query("delete from rss_entity where entity_name_id NOT IN(SELECT id from entities)");
    }
    function view_feed($userID,$feedId){
        $mobile = mobile_device_detect();
        $device = "d";
        if(isset($mobile[1])){
            if(preg_match('/iPad/',$mobile[1])){
                $device = "i";
            }else{
                $device = "m";
            }
        }
        $this->db->select('rss_feed.rss_feed_url');
        $this->db->where_in('rss_feed.id', $feedId);
        $query = $this->db->get('rss_feed');
        $rowData    = $query->result_array();
        $feedUrl    = $rowData[0]['rss_feed_url'];
        $arrLogDetails = array(
            'module' => $device,
            'controller' => 'media_intel_extractions',
            'method' => 'view_feed',
            'param' => "/$userID/$feedId",
            'type' => 'VIEW',
            'description' => 'visited medintel NEWS Feed via email subscription for '.$feedUrl,
            'status' => 'success',
            'transaction_name' => 'View Email NEWS FEED',
            'created_by'    => $userID
        );
        $this->config->set_item('log_details', $arrLogDetails);
        log_user_activity(null,true);
        redirect($feedUrl);
    }
    
}

// ************************* End of class **********************************************/

/**
 * 
 * @param DOMNode $element
 * Returns innercontent of an article
 */
function DOMinnerHTML(DOMNode $element) {
    return $element->nodeValue;
    $innerHTML = "";
    $children = $element->childNodes;

    foreach ($children as $child) {
        $innerHTML .= $element->ownerDocument->saveHTML($child);
    }

    return $innerHTML;
}

function get_timeago($ptime) {
    $estimate_time = time() - $ptime;

    if ($estimate_time < 1) {
        return '1 second ago';
    }

    $condition = array(
        12 * 30 * 24 * 60 * 60 => 'year',
        30 * 24 * 60 * 60 => 'month',
        24 * 60 * 60 => 'day',
        60 * 60 => 'hour',
        60 => 'minute',
        1 => 'second'
    );

    foreach ($condition as $secs => $str) {
        $d = $estimate_time / $secs;

        if ($d >= 1) {
            $r = round($d);
            return ' ' . $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
        }
    }
}
