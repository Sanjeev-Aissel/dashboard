<?php
/**
*Description:
*
*Created by:Vinod H
*
*Created on:March 28, 2016
*/?>

		<style type="text/css">
			#contents{
				text-align:left;
				font-size:110%;
				padding-left:150px;
			}
			
			#contents label{
				float:left;
				width:150px;
				text-align:right;
				padding-right:6px;
				padding-top:2px;
			}
			.campnameError .campshortError .campDescError p{
				color:red;
			}
			h1{
				color:#2E6E9E;
				font-size:170%;
				margin-bottom:10px;
				margin-top:15px;
			}

			
			#campaignForm span.require{
				color: #F00;
			}
			.validateForm label.error{
				float:none !important;
				margin-left:130px;
				
			}
			.error{
				padding:inherit;
			}
			.errorName{
				color: #F00;
				margin-left:165px;
			}
			.errorShortCode{
				color: #F00;
			}
			.gridCampaign{
				width:100%;
			}
			.analystForm div.formButtons, div.formButtons{
				margin-bottom:20px;
			}
		</style>
		<script>
		var idsOfSelectedRows = [];
		var arrKolIds = [];
		var array1 = [];
		var array2 = [];
		var validationRules	=  {
				campaign_name: {
					required:true
				},
				campaign_short_code: {
					required:true,
					minlength: 2,
					maxlength:10
				}
			};
			var validationMessages = {
					campaign_name: {
						required: "xax"
					},
					campaign_short_code: {
						required: "zxz"
					}
			};
			function toggleSearchToolbar(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}
			};
			$(document).ready(function (){
				var $grid = $("#gridKols"),
			    updateIdsOfSelectedRows = function (id, isSelected) {
			        var index = $.inArray(id, idsOfSelectedRows);
			        if (!isSelected && index >= 0) {
			            idsOfSelectedRows.splice(index, 1); // remove id from the list
			        } else if (index < 0) {
			            idsOfSelectedRows.push(id); // select KOLs Id are stored in array
			        }
			    };
			    
				<?php 
				
				if($campId!=''){
					foreach($campaignKols as $row){ ?>
						arrKolIds.push("<?php echo $row['kol_id'];?>");
						array2.push("<?php echo $row['kol_id'];?>");
					<?php } ?>
					array1 = array2;
					idsOfSelectedRows = arrKolIds;
					
				<?php }
				?>
				
			  //	idsOfSelectedRows = arrKolIds;
				jQuery("#gridKols").jqGrid({
					url:'<?php echo base_url();?>kols/list_kols_grid',
					datatype: "json",
					colNames:['Id','Name','Specialty','Gender','Organizations', 'Pubmed ?','Trials ?','Created By','type','Status','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
						{name:'kol_name',index:'kol_name',search:true,
				   			formatter: function (cellvalue, options, rowObject) {
//				   				jAlert(rowObject.is_imported);
				   				if(rowObject.is_imported == parseInt(1)){
					   				 return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
							         $.jgrid.htmlEncode(cellvalue) + "</a> <span class='highlightImported'> (xls)<span>";
					   			}
							        return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
						            $.jgrid.htmlEncode(cellvalue) + "</a>";
				    	},firstsortorder:'asc'},
				   		{name:'specialty',index:'specialty',width:90, search:true},
				   		{name:'gender',index:'gender',search:true,width:50, resizable:false},
				   		{name:'organization',index:'organization',search:true},
				   		{name:'pubmed_processed',index:'pubmed_processed',hidden:true,width:50, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
						{name:'trial_processed',index:'trial_processed',hidden:true,width:50,search:true, align:'center',resizable:false},
						{name:'created_by',index:'created_by',width:80,search:true},
						{name:'profile_type',index:'profile_type',width:60,search:true},
						{name:'status',index:'status',width:60,search:true},
						{name:'action',index:'action',width:45, align:'center',search:false, resizable:false, hidden:true}
						
				   	],
				   	onSelectRow: function(id){
					   	
	                if(id && id!==lastsel2){
	                  grid.restoreRow(lastsel2);
	                  grid.editRow(id,true);
	                  lastsel2=id;
	                }
	               },
	               onCellSelect: function(id){
		   				var option=$("option[value='0']", $('#'+id+'_pubmed_processed'));
		   				option.attr("disabled","disabled");
	               },
	               
	               editurl: '<?php echo base_url();?>pubmeds/chnage_kol_pubmed_status',
				   	rowNum:10,
				   	multiselect: true,
				   	rownumbers: true,
				   	autowidth: true, 
				   	loadonce:false,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	rowList:paginationValues,
				   	height: "auto",		 
				   	pager: '#gridKolsListingPagintaion',
				   	mtype: "POST",
				   	sortname: 'name',
				    viewrecords: true,
				    sortorder: "desc",
				    shrinkToFit:true,
				    jsonReader: { repeatitems : false, id: "0" }, 
				    caption:"KOL Profiles",
				    gridComplete: function(){	
				    },
					onSelectRow: updateIdsOfSelectedRows,
				    onSelectAll: function (aRowids, isSelected) {
				        var i, count, id;
				        for (i = 0, count = aRowids.length; i < count; i++) {
				            id = aRowids[i];
				            updateIdsOfSelectedRows(id, isSelected);
				        }
				    },
				    loadComplete: function () {
				        var $this = $(this), i, count;
				        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
				            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
				        }
				    }
				});
				jQuery("#gridKols").jqGrid('navGrid','#gridKolsListingPagintaion',{add:false,del:false,edit:false,search:false}); 
                jQuery("#gridKols").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
				//Toggle Toolbar Search 
				jQuery("#gridKols").jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
					onClickButton:toggleSearchToolbar
				});
				//Redirect to list_campaigns on click of cancel
				$('#cancel_campaign').click(function(){
					window.location.href = '<?php echo base_url();?>campaigns/list_campaigns';
				});
			});
				function save_campaign(){
					if($("#campaignForm").validate().form()){
						//validate the campaign fields;
					}else{
						return false;
					}
					var campaignName = $("#campaign_name").val();
					var campaignShortCode = $("#campaign_short_code").val();
					var projectId = $('#campaign_identification_id').val();
					var campaignDescription = $("#campaign_description").val();
					var campaign_identification_id = $("#campaign_description").val();
					//var kolId = jQuery("#gridKols").jqGrid('getGridParam','selarrrow');
					var kolId = idsOfSelectedRows;// Get the Ids of selected KOLs
					var kolSameId = array1;// Get the Ids of selected KOLs
					if(kolId==''){
						jAlert("Please select at least one KOL");
						return false;
					}
					//alert(KolId);
					var data ={};
					<?php if($campId!=''){ ?>
					data['campaign_id'] = <?php echo $campId; } ?>;
					
					data['campaign_name'] = campaignName;
					data['campaign_short_code'] = campaignShortCode;
					data['campaign_identification_id'] = projectId;
					data['campaign_description'] = campaignDescription;
					data['kolId'] = kolId;
					data['kolSameId'] = kolSameId;
					$.ajax({
						url:'<?php echo base_url()?>campaigns/save_campaign',
						data:data,
						type:'post',
						dataType:'json',
						success:function(res){
							//alert(res.toSource());	
							if(res.status){
								window.location.href = '<?php echo base_url();?>campaigns/list_campaigns';
							}else{		
								$(".errorName").html(res.msgName);
							}
						}
					});
				}
				</script>
				
				
				
			<h1>Add New Campaign</h1>
				<form action="" method="post" id="campaignForm" name="campaignForm" class="validateForm" >
					<input type="hidden" name="campaign_id" id="campaign_id" value="<?php if(isset($campId)) echo $campId;?>" />
				  	<p>
						<label for="campaign_name">Campaign Name</label><span class="require">*</span>
			       			<input type="text" name="campaign_name" id="campaign_name" value="<?php if(isset($campName)) echo $campName;?>" class="required"></input>						
					</p>
					<p>
						<label for="campaign_short_code">Short Code</label><span class="require">*</span>
			       			<input type="text" name="campaign_short_code" id="campaign_short_code" value="<?php if(isset($campShortCode)) echo $campShortCode;?>" class="required"></input>
			       			<p class="errorName"></p>
					</p>
					<p>
						<label for="campaign_identification_id">Project Name</label><span class="require">*</span>
							
							<select name="campaign_identification_id" id="campaign_identification_id" class="required">
								<option value="">Select Project</option>
								<?php
									$selected	= '';
									if(!isset($campIdentificationId)){
										$campIdentificationId	= '';
									}
									foreach($arrProjects as $row) {
										$selected	= '';
										if($row->id==$campIdentificationId){
											$selected	= "selected='selected'";
										}
										echo '<option value="'.$row->id.'" '.$selected.'>'.$row->name.'</option>';
									}
								?>
							</select>
					</p>
					<span class="campShortError"></span><span class="campErrorSameShortCode"></span>
					<p>
						<label for="">Description</label>
						<textarea name="campaign_description" id="campaign_description" cols="30" rows="5" ><?php echo $campDescription;?></textarea>
					</p>
					<span class="campDescError"></span>	    
				
					<div class="gridCampaign">
			            <table id="gridKols"></table>
						<div id="gridKolsListingPagintaion"></div>
					</div>
					  <br /> 
					<div class="formButtons">	
						<button type="button" name="submit" onclick="save_campaign();">Save</button>
 		       			<button type="button" id="cancel_campaign" >Cancel</button>
 		    		</div>
								    
				 </form>
					<!-- End of Personal and Professional Information -->
