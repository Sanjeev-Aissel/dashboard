<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
	<meta charset="UTF-8" />
	<title>KOLM User Analytics</title>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/client_layout.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/jquery.alerts.css" />
	<script src="<?php echo base_url();?>js/jquery.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/i18n/grid.locale-en.js" ></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.jqGrid.min.js" ></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery/jquery.validate1.9.min.js" ></script>
	<script type="text/javascript">
	    var userRoleId		= '<?php echo $this->session->userdata('user_role_id')?>';
		var ROLE_MANAGER 	= '<?php echo ROLE_MANAGER?>';
		var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
		var ROLE_USER		= '<?php echo ROLE_USER?>';
		var INTERNAL_CLIENT_ID		= '<?php echo INTERNAL_CLIENT_ID?>';
		var paginationValues		= new Array();
		<?php 
			$paginationValues	= explode(',',PAGINATION_VALUES);
			foreach($paginationValues as $key=>$value){
		?>
			paginationValues.push('<?php echo $value;?>');
		<?php
			}
		?>
	</script>
 	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<style type="text/css">
		.gridWrapper {
			width: 50%;
		}
		
		#myPendingApprovalsResultSet_cb{
			vertical-align: top;
		}
		#rejectBox span{
			color: black;
		    font-size: 12px;
		}
		#rejectBox label{
			font-size: 13px !important;
		}
		#rejectBox textarea{
			width: 90%;
		}
		#rejectBox input{
			float: right;
   			margin-right: 35px;
		}
		.approve-reject{
			float: left;
   			margin-left: 5px;
		}
		.approve{
			background-attachment: scroll;
		    background-clip: border-box;
		    background-color: transparent;
		    background-image: url("../images/approve.png");
		    background-origin: padding-box;
		    background-position: 0 0;
		    background-repeat: repeat;
		    height: 22px;
		    width: 22px;
		    margin-top: -3px;
		}
		.reject{
			background-attachment: scroll;
		    background-clip: border-box;
		    background-color: transparent;
		    background-image: url("../images/reject.png");
		    background-origin: padding-box;
		    background-position: 0 0;
		    background-repeat: no-repeat;
		    height: 18px;
		    width: 18px;
		    margin-top: 1px;
		}
		#allProfileRequestsGridContainer{
			margin: 20px auto auto;
		}
		.gridWrapper .ui-jqgrid tr.jqgrow td{
			padding: 2px 2px 2px 4px !important;
		}
		.title-bar-actions{
			float:right;
			margin-right: 19px;
		}
		.title-bar-actions .sprite_iconSet{
			float:right;
			margin-left: 0;
		}
		.title-bar-actions .blueButton{
			background: none no-repeat scroll left center #BBBBBB;
		    border-color: #8A8A8A !important;
		    margin-left: 5px;
		}
		.reasonContent{
			height: 79px !important;
			width:350px;
		}
		.reasonContent .profileContent{
			height: 60px !important;
    		min-height: 40px !important;
		}
		.title-bar-actions .approve-button, .title-bar-actions .reject-button{
			padding-bottom: 2px;
		}
		.title-bar-actions .approve-button{
			background-image: url("../images/approve.png");
			background-size: 22px auto;
    		padding-left: 23px;
		}
		.title-bar-actions .reject-button{
			background-image: url("../images/reject.png");
			background-size: 16px auto;
    		padding-left: 24px;
		}
		#cb_myPendingApprovalsResultSet{
			margin-left: 6px;
		}
		.rowFailed {
			color: red !important;
		}
	</style>

	<script type="text/javascript">

		function allProfileRequests(){
			$("#allProfileRequests").html("");
			// Append the required div and table
			$("#allProfileRequests").html('<table id="allProfileRequestsResultSet"></table><div id="allProfileRequestsPager"></div>');
		
			jQuery("#allProfileRequestsResultSet").jqGrid({
			   	url:'<?php echo base_url()?>login/list_all_user_analytics_details/',
				datatype: "json",
			 	colNames:['Id','','Username','Client Name','Login Time','Logout Time','User from'],
			   	colModel:[
							{name:'id',index:'id', hidden:true},
							{name:'is_login_failed',index:'is_login_failed', hidden:true},
							{name:'user_name',index:'user_name', search:true},
							{name:'name',index:'name', search:true},
							{name:'login_time',index:'login_time',width:110, search:true},
							{name:'logout_time',index:'logout_time',width:100, resizable:false,title: false},
							{name:'user_from',index:'user_from',width:100, resizable:false,title: false},
			   	],
			   	rowNum:10,
			   	rownumbers: true,
				//rownumWidth: 60,
				multiselect: false,
			   	autowidth: true, 
			   	loadonce:false,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",	
			   	width:"100%",
			   	resizable:true,
			   	shrinkToFit: true,
			   	pager: '#allProfileRequestsPager',
			   	mtype: "POST",
			   	sortname: 'institute_id',
			    viewrecords: true,
			    sortorder: "desc",
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:"All User Analytics View",
			    rowList:paginationValues,
			    afterInsertRow: function(id, data)
		        {
		            if(parseInt(data.is_login_failed) == 1) {
		                $('tr#'+id).find('td').addClass('rowFailed');
		            }
		        },
			   	gridComplete: function(){
			    	var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];				    	
				    	var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', cl);
						    	
				    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+rowData.kol_id+"',this,true); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
				    	jQuery("#allProfileRequestsResultSet").jqGrid('setRowData',cl,{micro:microviewLink});
		    		} 

			    	jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	//Initialize the tooltips
		    	},
		    	onSelectAll: function(aRowids,status) {
		    		var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
		    		
					    	var cl = ids[i];				    	
					    	var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', cl);
					    
					    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
								
					    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#allProfileRequestsResultSet")[0]);
					                cbs.removeAttr("checked");

					                //modify the selarrrow parameter
					                jQuery("#allProfileRequestsResultSet")[0].p.selarrrow = jQuery("#allProfileRequestsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
					                    .map(function() { return this.id; }) // convert to set of ids
					                    .get(); // convert to instance of Array
							}
						
			    	} 

			          
		        }
			});
			//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
			jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','#allProfileRequestsPager',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#allProfileRequestsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
				$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == 'Search')
						$(this).val("");
			    });
			},afterSearch:function(){
				/*$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == '')
						$(this).val("Search");
			    });*/
			}});

			//Add action button in the title bar
			var buttonsText = "<div class='title-bar-actions'>";
				buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel()' >	<a rel='tooltip' href='#' title='Export'>&nbsp;</a>	</div>";
				buttonsText += "</div>";
			$("#allProfileRequestsGridContainer .ui-jqgrid-titlebar").append(buttonsText); 		
		}

		$(document).ready(function(){
			allProfileRequests();
		});



		function findPos(obj) {
			 var obj2 = obj;
			 var curtop = 0;
			 var curleft = 0;
			 if (document.getElementById || document.all) {
			  do  {
			   curleft += obj.offsetLeft-obj.scrollLeft;
			   curtop += obj.offsetTop-obj.scrollTop;
			   obj = obj.offsetParent;
			   obj2 = obj2.parentNode;
			   while (obj2!=obj) {
			    curleft -= obj2.scrollLeft;
			    curtop -= obj2.scrollTop;
			    obj2 = obj2.parentNode;
			   }
			  } while (obj.offsetParent)
			 } else if (document.layers) {
			  curtop += obj.y;
			  curleft += obj.x;
			 }
			 return [curtop, curleft];
			}   // en
			
		function export_excel(){
				var excelFilters = '';
				$("#allProfileRequestsGridContainer .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
					if($(this).val() != ''){
						var filterName = $(this).attr('name');
						var filterValue = $(this).val();
						excelFilters += filterName+" : "+filterValue+",";
					}
				});
				$("#filters").val(excelFilters);
				var selectedOPtion = $(".ui-pg-selbox").val();
				$(".ui-pg-selbox option:last").attr('selected','selected');
		    	$('.ui-pg-selbox').trigger('change');
		    	var arrIds = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    	$('#exportIds').val(arrIds);
			//	return false;
		    	$('#exportClientRequestDetail').submit();
		    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
		    	$('.ui-pg-selbox').trigger('change');
			}
		
	</script>


	<form action="<?php echo base_url()?>login/export_analytic_detail" method="post" id="exportClientRequestDetail">
		<input type="hidden" value="" name="exportIds" id="exportIds"></input>
		<input type="hidden" value="" name="filters" id="filters"></input>
		<input type="hidden" value="" name="type" id="type">
	</form>
	
	<div>
		<div class="gridWrapper" id="allProfileRequestsGridContainer">
			<table id="allProfileRequestsResultSet"></table>
			<div id="allProfileRequestsPager"></div>
		</div>		
	</div>
	
	<!-- Container for the 'Micro Profile'  box -->
	
</body>
</html>

