<?php
/**
 * Page to show Engagement plan reports
 * 
 * @package views.plannings
 * @author Ramesh B
 * @since 3.1
 * @created 17-09-2011
*/
?>

<script type="text/javascript">
	$(document).ready(function(){
		//Expand or Collaps the subnode based on the current status
		$('.expander').click(function(){
			var parentTrId=$(this).parent().parent().attr('id');
			var parentTrClass=$(this).parent().parent().attr('class');
			//If current status is collapsed , then make it as expanded and show all its subnodes
			if($(this).parent().parent().hasClass('collapsed')){
				$(this).parent().parent().removeClass('collapsed');
				$(this).parent().parent().addClass('expanded');
				$(this).attr('title','collapse');
				$('.subNodeOf'+parentTrId).show();
			}else{
			//If current status is expanded , then make it as collapsed and hide all its subnodes
				$(this).parent().parent().removeClass('expanded');
				$(this).parent().parent().addClass('collapsed');
				$(this).attr('title','expand');
				$('.subNodeOf'+parentTrId).hide();
			}
		});
	});

</script>

<table>
	<thead>
		<tr>
			<th>
				Username
			</th>
			<th>
				Target
			</th>
			<th>
				Achieved
			</th>
		</tr>
	</thead>
	
	<tbody>
		<?php if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){?>
			<?php foreach($arrReportData as $userId => $userReportDetails){?>
				<?php $last_key = end(array_keys($userReportDetails));
				 foreach($userReportDetails as $kolId => $arrDetails){?>
					<tr  id="<?php if($kolId==0) echo 'Node'.$userId;?>" class="<?php if($kolId!=0) echo 'subNode subNodeOfNode'.$userId; else echo 'collapsed parentNode';?>" style="<?php if($kolId!=0) echo 'display:none'?>">
						<td class="<?php if($kolId!=0) echo 'nodeLevelTwo'; if($last_key==$kolId) echo ' endNode'?>" width="60%">
							<?php if($kolId==0){?>
								<div class="expandCollapse"></div>
								<span class="expander" title="expand">
										<?php echo $arrUsers[$userId];?>
								</span>
							<?php }  else {
								 echo $arrKolsNames[$kolId]; 
							}?>
						</td>
						<td width="20%">
							<?php echo $arrDetails['target'];?>
						</td>
						<td width="20%">
							<?php echo $arrDetails['achieved'];?>
						</td>
					</tr>
				<?php }?>
			<?php }?>
		<?php } else {?>
			<?php foreach($arrReportData as $userId => $userReportDetails){?>
				<?php if($userId==$this->session->userdata('user_id')){?>
					<?php $last_key = end(array_keys($userReportDetails));
					 foreach($userReportDetails as $kolId => $arrDetails){?>
						<tr  id="<?php if($kolId==0) echo 'Node'.$userId;?>" class="<?php if($kolId!=0) echo 'subNode subNodeOfNode'.$userId; else echo 'expanded parentNode';?>">
							<td class="<?php if($kolId!=0) echo 'nodeLevelTwo'; if($last_key==$kolId) echo ' endNode'?>" width="60%">
								<?php if($kolId==0){?>
									<div class="expandCollapse"></div>
									<span class="expander" title="cllapse">
											<?php echo $arrUsers[$userId];?>
									</span>
								<?php }  else {
									 echo $arrKolsNames[$kolId]; 
								}?>			
							</td>
							<td width="20%">
								<?php echo $arrDetails['target'];?>
							</td>
							<td width="20%">
								<?php echo $arrDetails['achieved'];?>
							</td>
						</tr>
					<?php }?>
				<?php }?>
			<?php }?>
		<?php }?>	
	</tbody>
</table>