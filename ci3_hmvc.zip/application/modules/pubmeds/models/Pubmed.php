<?php
class pubmed extends CI_Model {
	function searchPublicationsByParameters($substance, $author, $meshTermName, $keyword, $aritcleName, $kolId, $fromYear, $toYear) {
		$this->db->select ( 'distinct(publications.id),publications.*,kol_publications.auth_pos,kol_publications.kol_id,pubmed_journals.name as journal_name,kol_publications.client_id,kol_publications.user_id,kol_publications.id as kol_pub_id,kol_publications.data_type_indicator,client_users.first_name,client_users.last_name' );
		$this->db->join ( 'publications', 'publications.id=kol_publications.pub_id', 'left' );
		$this->db->join ( 'pubmed_journals', 'publications.journal_id=pubmed_journals.id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kol_publications.user_id', 'left' );
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		if ($fromYear != '' && $toYear != '') {
			
			$this->db->where ( "(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')" );
		}
		$this->db->where ( 'kol_publications.is_verified', 1 );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.kol_id', $kolId );
		$this->db->order_by ( "publications.created_date", 'desc' );
		$arrResultSet = $this->db->get ( 'kol_publications' );
		$arrPubliations = array ();
		foreach ( $arrResultSet->result_array () as $row ) {
			$arrPubliations [] = $row;
		}
		return $arrPubliations;
	}
	function getJournalNameById($journalId) {
		$journalName = '';
		$this->db->where ( 'id', $journalId );
		$arrJournals = $this->db->get ( 'pubmed_journals' );
		if ($arrJournals->num_rows () != 0) {
			$journalObj = $arrJournals->first_row ();
			$journalName = $journalObj->name;
		}
		return $journalName;
	}
	function listPublicationDetails($kolId, $listType) {
		$arrPublications = array ();
		$clientId = $this->session->userdata ( 'client_id' );
		$this->db->select ( 'publications.*,kol_publications.auth_pos,kol_publications.id as asoc_id' );
		$this->db->from ( 'publications' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id = publications.id', 'left' );
		$this->db->where ( 'kol_id', $kolId );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		if ($listType != 'export') {
			if ($clientId != INTERNAL_CLIENT_ID) {
				$this->db->where ( "kol_publications.client_id", $clientId );
			}
		}
		$arrPublicationResult = $this->db->get ();
		foreach ( $arrPublicationResult->result_array () as $row ) {
			if ($arrPublicationResult->num_rows () != 0) {
				$arrPublications [] = $row;
			} else {
				return false;
			}
		}
		return $arrPublications;
	}
	/**
	 * returns the list of Top publications belongs to perticular kolId passed with Limit
	 * 
	 * @param
	 *        	$kolId
	 * @return unknown_type
	 */
	function listPublicationDetailsByLimit($kolId, $limitValue) {
		$clientId = $this->session->userdata ( 'client_id' );
		$arrPublications = array ();
		$this->db->select ( 'publications.*' );
		$this->db->from ( 'publications' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id = publications.id', 'left' );
		$this->db->where ( 'kol_id', $kolId );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		
		if ($clientId != INTERNAL_CLIENT_ID) {
			$this->db->where ( "(kol_publications.client_id=$clientId or kol_publications.client_id=" . INTERNAL_CLIENT_ID . ")" );
		}
		$this->db->order_by ( 'publications.created_date', 'desc' );
		$this->db->limit ( $limitValue );
		
		$arrPublicationResult = $this->db->get ();
		foreach ( $arrPublicationResult->result_array () as $row ) {
			if ($arrPublicationResult->num_rows () != 0) {
				$arrPublications [] = $row;
			} else {
				return false;
			}
		}
		return $arrPublications;
	}
	/*
	 * To get Major mesh term data
	 * @author Vinayak
	 * @since 3.1.1
	 * @created July-19-2011
	 * @param $kolId
	 * @return array - $arrMajorMeshterm
	 *
	 */
	function getPubMajorMeshTermChartForPdf($kolId) {
		$arrMajorMeshterm = array ();
		$this->db->select ( 'pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count,pubmed_mesh_terms.parent_id' );
		$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
		$this->db->join ( 'publications', 'publications.id = publication_mesh_terms.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id = publications.id', 'left' );
		
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		$this->db->where ( 'kol_id', $kolId );
		$this->db->where ( 'publication_mesh_terms.is_major', '1' );
		
		$this->db->group_by ( 'pubmed_mesh_terms.term_name' );
		$this->db->order_by ( 'count', 'desc' );
		$this->db->limit ( '20' );
		$arrMajorMeshtermResult = $this->db->get ( 'pubmed_mesh_terms' );
		foreach ( $arrMajorMeshtermResult->result_array () as $row ) {
			$arrMajorMeshterm [] = $row;
		}
		// pr($arrMajorMeshterm);
		return $arrMajorMeshterm;
	}
	/*
	 * To get Minor mesh term data
	 * @author Vinayak
	 * @since 3.1.1
	 * @created July-19-2011
	 * @param $kolId
	 * @return array - $arrMajorMeshterm
	 *
	 */
	function getPubMinorMeshTermChartForPdf($kolId) {
		$arrMinorMeshterm = array ();
		$this->db->select ( 'pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count' );
		$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
		$this->db->join ( 'publications', 'publications.id = publication_mesh_terms.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id = publications.id', 'left' );
		
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		$this->db->where ( 'kol_id', $kolId );
		$this->db->where ( 'publication_mesh_terms.is_major', '0' );
		
		$this->db->group_by ( 'pubmed_mesh_terms.term_name' );
		$this->db->order_by ( 'count', 'desc' );
		$this->db->limit ( '20' );
		
		$arrMinorMeshtermResult = $this->db->get ( 'pubmed_mesh_terms' );
		foreach ( $arrMinorMeshtermResult->result_array () as $row ) {
			$arrMinorMeshterm [] = $row;
		}
		// pr($arrMinorMeshterm);
		return $arrMinorMeshterm;
	}
	function getKolPubsWithSingleAuthor($kolId, $start, $end, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $keyword, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds = 0) {
		$arrPublicationsDetail = array ();
		
		$queryString = "SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE ";
		$this->db->select ( "kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR" );
		$this->db->join ( 'publications', 'publications.id=publications_authors.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id=publications.id', 'left' );
		$this->db->join ( 'kols', 'kols.id=kol_publications.kol_id', 'left' );
		if ($kolId != 0)
			$this->db->where ( "kol_publications.kol_id", $kolId );
		// $queryString.=" kol_publications.kol_id=".$kolId." ";
		
		// Adding where condition for Kol's if Exist
		if (is_array ( $arrKolIds ) && $arrKolIds != 0) {
			// $commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id IN($commaKolIds) ";
		} else if ($arrKolIds != 0) {
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		
		// Adding where condition for Global Region's if Exist
		if (is_array ( $arrGlobalRegionIds ) && $arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
			$queryString .= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		
		// Adding where condition for Country's if Exist
		if (is_array ( $arrCountries ) && $arrCountries != 0) {
			// $commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			// $queryString .= " AND kols.country_id IN($commaCountries) ";
		} else if ($arrCountries != 0) {
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			$queryString .= " AND kols.country_id='$arrCountries' ";
		}
		
		// Adding where condition for Speciality's if Exist
		if (is_array ( $arrSpecialities ) && $arrSpecialities != 0) {
			$commaSpecialities = $this->common_helpers->convertArrayToCommaSeparatedElements ( $arrSpecialities );
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty IN($commaSpecialities) ";
		} else if ($arrSpecialities != 0) {
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty='$arrSpecialities' ";
		}
		if (is_array ( $arrStatesIds ) && $arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		} else if ($arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		}
		if ($profileType != 0) {
			$this->db->where ( 'kols.profile_type', $profileType );
		}
		if (is_array ( $viewType ) && $viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		} else if ($viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		}
		
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata ( 'user_id' );
			$clientId = $this->session->userdata ( 'client_id' );
			$this->db->join ( 'list_kols', 'list_kols.kol_id=kols.id', 'left' );
			$this->db->join ( 'list_names', 'list_names.id=list_kols.list_name_id', 'left' );
			$this->db->join ( 'list_categories', 'list_categories.id=list_names.category_id', 'left' );
			$this->db->where ( "(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))" );
			$this->db->where_in ( 'list_names.id', $arrListNamesIds );
		}
		$this->db->where ( "(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)" );
		if ($start != 0 && $end != 0) {
			// $this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
			$this->db->where ( "(((YEAR(publications.created_date) BETWEEN '" . $start . "' AND '" . $end . "')or YEAR(publications.created_date)='0')) " );
		}
		
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		$this->db->group_by ( 'kol_publications.kol_id,publications_authors.pub_id HAVING COUNT(publications_authors.pub_id)=1' );
		
		// $queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
		// GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths=1";
		
		$arrPublications = $this->db->get ( 'publications_authors' );
		// pr($this->db->last_query());exit;
		foreach ( $arrPublications->result_array () as $row ) {
			
			$arrPublicationsDetail [] = $row;
		}
		
		return $arrPublicationsDetail;
	}
	function getKolPubsWithFirstAuthorship($kolId, $start, $end, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $keyword, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds = 0) {
		$arrPublicationsDetail = array ();
		
		$queryString = "SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country=countries.countryId
											WHERE";
		$this->db->select ( "kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR" );
		$this->db->join ( 'publications', 'publications.id=publications_authors.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id=publications.id', 'left' );
		$this->db->join ( 'kols', 'kols.id=kol_publications.kol_id', 'left' );
		if ($kolId != 0)
			$this->db->where ( "kol_publications.kol_id", $kolId );
		// $queryString.=" kol_publications.kol_id=".$kolId." ";
		
		// Adding where condition for Kol's if Exist
		if (is_array ( $arrKolIds ) && $arrKolIds != 0) {
			// $commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id IN($commaKolIds) ";
		} else if ($arrKolIds != 0) {
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		
		// Adding where condition for Global Region's if Exist
		if (is_array ( $arrGlobalRegionIds ) && $arrGlobalRegionIds != 0) {
			// $commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
			$queryString .= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		
		// Adding where condition for Country's if Exist
		if (is_array ( $arrCountries ) && $arrCountries != 0) {
			// $commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			// $queryString .= " AND kols.country_id IN($commaCountries) ";
		} else if ($arrCountries != 0) {
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			$queryString .= " AND kols.country_id='$arrCountries' ";
		}
		
		// Adding where condition for Speciality's if Exist
		if (is_array ( $arrSpecialities ) && $arrSpecialities != 0) {
			$commaSpecialities = $this->common_helpers->convertArrayToCommaSeparatedElements ( $arrSpecialities );
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty IN($commaSpecialities) ";
		} else if ($arrSpecialities != 0) {
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty='$arrSpecialities' ";
		}
		if (is_array ( $arrStatesIds ) && $arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		} else if ($arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		}
		if ($profileType != 0) {
			$this->db->where ( 'kols.profile_type', $profileType );
		}
		if (is_array ( $viewType ) && $viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		} else if ($viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata ( 'user_id' );
			$clientId = $this->session->userdata ( 'client_id' );
			$this->db->join ( 'list_kols', 'list_kols.kol_id=kols.id', 'left' );
			$this->db->join ( 'list_names', 'list_names.id=list_kols.list_name_id', 'left' );
			$this->db->join ( 'list_categories', 'list_categories.id=list_names.category_id', 'left' );
			$this->db->where ( "(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))" );
			$this->db->where_in ( 'list_names.id', $arrListNamesIds );
		}
		
		$this->db->where ( "(kol_publications.is_deleted=0 AND kol_publications.is_verified=1) AND kol_publications.auth_pos=1" );
		if ($start != 0 && $end != 0)
			$this->db->where ( "(((YEAR(publications.created_date) BETWEEN '" . $start . "' AND '" . $end . "')or YEAR(publications.created_date)='0')) " );
		// $this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		$this->db->group_by ( 'kol_publications.kol_id,publications_authors.pub_id HAVING COUNT(publications_authors.pub_id)>1' );
		
		// $queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND kol_publications.auth_pos=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
		// GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1";
		
		$arrPublications = $this->db->get ( 'publications_authors' );
		// $arrPublications = $this->db->query($queryString);
		// echo $this->db->last_query();
		foreach ( $arrPublications->result_array () as $row ) {
			
			$arrPublicationsDetail [] = $row;
		}
		return $arrPublicationsDetail;
	}
	function getKolPubsWithLastAuthorship($kolId, $start, $end, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $keyword, $arrStatesIds, $profileType, $viewType) {
		$arrPublicationsDetail = array ();
		$queryString = "SELECT kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON publications_authors.pub_id=kol_publications.pub_id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE";
		$this->db->select ( "kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR" );
		$this->db->join ( 'publications', 'publications.id=publications_authors.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id=publications.id', 'left' );
		$this->db->join ( 'kols', 'kols.id=kol_publications.kol_id', 'left' );
		if ($kolId != 0)
			$this->db->where ( "kol_publications.kol_id", $kolId );
		// $queryString.=" kol_publications.kol_id=".$kolId." ";
		
		// Adding where condition for Kol's if Exist
		if (is_array ( $arrKolIds ) && $arrKolIds != 0) {
			// $commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id IN($commaKolIds) ";
		} else if ($arrKolIds != 0) {
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		// Adding where condition for Global Region's if Exist
		if (is_array ( $arrGlobalRegionIds ) && $arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
			$queryString .= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		// Adding where condition for Country's if Exist
		if (is_array ( $arrCountries ) && $arrCountries != 0) {
			// $commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			// $queryString .= " AND kols.country_id IN($commaCountries) ";
		} else if ($arrCountries != 0) {
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			$queryString .= " AND kols.country_id='$arrCountries' ";
		}
		
		// Adding where condition for Speciality's if Exist
		if (is_array ( $arrSpecialities ) && $arrSpecialities != 0) {
			$commaSpecialities = $this->common_helpers->convertArrayToCommaSeparatedElements ( $arrSpecialities );
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty IN($commaSpecialities) ";
		} else if ($arrSpecialities != 0) {
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty='$arrSpecialities' ";
		}
		if (is_array ( $arrStatesIds ) && $arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		} else if ($arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		}
		if ($profileType != 0) {
			$this->db->where ( 'kols.profile_type', $profileType );
		}
		if (is_array ( $viewType ) && $viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		} else if ($viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata ( 'user_id' );
			$clientId = $this->session->userdata ( 'client_id' );
			$this->db->join ( 'list_kols', 'list_kols.kol_id=kols.id', 'left' );
			$this->db->join ( 'list_names', 'list_names.id=list_kols.list_name_id', 'left' );
			$this->db->join ( 'list_categories', 'list_categories.id=list_names.category_id', 'left' );
			$this->db->where ( "(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))" );
			$this->db->where_in ( 'list_names.id', $arrListNamesIds );
		}
		
		$this->db->where ( "(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)" );
		if ($start != 0 && $end != 0)
			$this->db->where ( "(((YEAR(publications.created_date) BETWEEN '" . $start . "' AND '" . $end . "')or YEAR(publications.created_date)='0')) " );
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		$this->db->group_by ( 'kol_publications.kol_id,publications_authors.pub_id' );
		
		// $queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
		// GROUP BY kol_publications.kol_id,publications_authors.pub_id";
		$arrPublications = $this->db->get ( 'publications_authors' );
		// $arrPublications = $this->db->query($queryString);
		// echo $this->db->last_query();
		foreach ( $arrPublications->result_array () as $row ) {
			
			$arrPublicationsDetail [] = $row;
		}
		return $arrPublicationsDetail;
	}
	function getKolPubsWithMiddleAuthorship($kolId, $start, $end, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $keyword, $arrStatesIds, $profileType, $viewType) {
		$arrPublicationsDetail = array ();
		$queryString = "SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,MAX(publications_authors.position) AS max_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE";
		
		$this->db->select ( "kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,MAX(publications_authors.position) AS max_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR" );
		$this->db->join ( 'publications', 'publications.id=publications_authors.pub_id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id=publications.id', 'left' );
		$this->db->join ( 'kols', 'kols.id=kol_publications.kol_id', 'left' );
		if ($kolId != 0)
			$this->db->where ( "kol_publications.kol_id", $kolId );
		// $queryString.=" kol_publications.kol_id=".$kolId." ";
		
		// Adding where condition for Kol's if Exist
		if (is_array ( $arrKolIds ) && $arrKolIds != 0) {
			// $commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id IN($commaKolIds) ";
		} else if ($arrKolIds != 0) {
			$this->db->where_in ( 'kol_publications.kol_id', $arrKolIds );
			// $queryString .= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		// Adding where condition for Global Region's if Exist
		if (is_array ( $arrGlobalRegionIds ) && $arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join ( 'countries', 'kols.country_id=countries.countryId', 'left' );
			$this->db->where_in ( 'countries.GlobalRegion', $arrGlobalRegionIds );
			$queryString .= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		// Adding where condition for Country's if Exist
		if (is_array ( $arrCountries ) && $arrCountries != 0) {
			// $commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			// $queryString .= " AND kols.country_id IN($commaCountries) ";
		} else if ($arrCountries != 0) {
			$this->db->where_in ( 'kols.country_id', $arrCountries );
			$queryString .= " AND kols.country_id='$arrCountries' ";
		}
		
		// Adding where condition for Speciality's if Exist
		if (is_array ( $arrSpecialities ) && $arrSpecialities != 0) {
			$commaSpecialities = $this->common_helpers->convertArrayToCommaSeparatedElements ( $arrSpecialities );
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty IN($commaSpecialities) ";
		} else if ($arrSpecialities != 0) {
			$this->db->where_in ( 'kols.specialty', $arrSpecialities );
			// $queryString .= " AND kols.specialty='$arrSpecialities' ";
		}
		if (is_array ( $arrStatesIds ) && $arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		} else if ($arrStatesIds != 0) {
			$this->db->where_in ( 'kols.state_id', $arrStatesIds );
		}
		if ($profileType != 0) {
			$this->db->where ( 'kols.profile_type', $profileType );
		}
		if (is_array ( $viewType ) && $viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		} else if ($viewType != 0 && ! empty ( $viewType )) {
			$this->db->where_in ( 'kols.id', $viewType );
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata ( 'user_id' );
			$clientId = $this->session->userdata ( 'client_id' );
			$this->db->join ( 'list_kols', 'list_kols.kol_id=kols.id', 'left' );
			$this->db->join ( 'list_names', 'list_names.id=list_kols.list_name_id', 'left' );
			$this->db->join ( 'list_categories', 'list_categories.id=list_names.category_id', 'left' );
			$this->db->where ( "(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))" );
			$this->db->where_in ( 'list_names.id', $arrListNamesIds );
		}
		
		$this->db->where ( "(kol_publications.is_deleted=0 AND kol_publications.is_verified=1) AND kol_publications.auth_pos!=1 " );
		if ($start != 0 && $end != 0)
			// $this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
			$this->db->where ( "(((YEAR(publications.created_date) BETWEEN '" . $start . "' AND '" . $end . "')or YEAR(publications.created_date)='0')) " );
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		
		$this->db->group_by ( 'kol_publications.kol_id,publications_authors.pub_id HAVING COUNT(publications_authors.pub_id)>1' );
		
		// $queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND kol_publications.auth_pos!=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
		// GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1";
		$arrPublications = $this->db->get ( 'publications_authors' );
		// $arrPublications = $this->db->query($queryString);
		// echo $this->db->last_query();
		foreach ( $arrPublications->result_array () as $row ) {
			
			$arrPublicationsDetail [] = $row;
		}
		return $arrPublicationsDetail;
	}
	function getCoAuthoredKols($arrKolIds = null) {
		// Old Querry
		$arrKols = array ();
		$this->db->select ( "pub2.kol_id, COUNT(pub2.kol_id) as count" );
		$this->db->join ( 'kol_publications as pub2', 'kol_publications.pub_id=pub2.pub_id', 'left' );
		$this->db->join ( 'kols', 'pub2.kol_id = kols.id', 'left' );
		// $where="kol_publications.kol_id='$arrKolIds' AND pub2.kol_id!='$arrKolIds'";
		// $this->db->where($where);
		$this->db->where ( 'kol_publications.kol_id', $arrKolIds );
		$this->db->where ( 'pub2.kol_id !=', $arrKolIds );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		$this->db->where ( 'pub2.is_deleted', 0 );
		$this->db->where ( 'pub2.is_verified', 1 );
		// $this->db->where('kols.status',COMPLETED);
		$client_id = $this->session->userdata ( 'client_id' );
		if ($client_id !== INTERNAL_CLIENT_ID) {
			$this->db->join ( 'kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left' );
			$this->db->where ( 'kols_client_visibility.client_id', $client_id );
		}
		$this->db->where ( '(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false );
		$this->db->where ( '(kols.deleted_by is null or kols.deleted_by=0)', '', false );
		$this->db->group_by ( 'pub2.kol_id' );
		$results = $this->db->get ( 'kol_publications' );
		// echo $this->db->last_query();
		foreach ( $results->result_array () as $row ) {
			$arrKols [] = $row;
		}
		return $arrKols;
	}
	function getKolPubsYearsRange($kolId) {
		$arrYears = array ();
		$client_id = $this->session->userdata ( 'client_id' );
		$where = "";
		if ($client_id !== INTERNAL_CLIENT_ID) {
			$where = "AND (kol_publications.client_id = $client_id or kol_publications.client_id = 1)";
		}
		$arrResults = $this->db->query ( "SELECT MIN(YEAR(publications.created_date)) AS min_year,MAX(YEAR(publications.created_date)) AS max_year
									FROM publications
									LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
									WHERE kol_publications.kol_id=" . $kolId . " AND kol_publications.is_deleted=0 AND YEAR(publications.created_date)!=0
				$where" );
		foreach ( $arrResults->result_array () as $row ) {
			$arrYears ['min_year'] = $row ['min_year'];
			$arrYears ['max_year'] = $row ['max_year'];
		}
		return $arrYears;
	}
	function getPubJournalsChart($kolId, $fromYear, $toYear, $keyword) {
		$arrJournals = array ();
		$this->db->select ( "pubmed_journals.id,pubmed_journals.name ,count(distinct kol_publications.pub_id) as count" );
		$this->db->join ( 'publications', 'publications.journal_id=pubmed_journals.id', 'left' );
		$this->db->join ( 'kol_publications', 'kol_publications.pub_id=publications.id', 'left' );
		
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		$this->db->where ( 'kol_id', $kolId );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.is_verified', 1 );
		
		$where = 'year(publications.created_date)';
		$where .= 'between '.$fromYear.' and '.$toYear;
		$this->db->where($where);
		
// 		$this->db->where ( '(year(publications.created_date) between ' . $fromYear . ' and ' . $toYear . ')' );
		$this->db->group_by ( 'pubmed_journals.name' );
		$this->db->order_by ( 'count', 'desc' );
		$this->db->limit ( 20 );
		$arrJournalsResult = $this->db->get ( 'pubmed_journals' );
		if ($arrJournalsResult->num_rows () != 0) {
			foreach ( $arrJournalsResult->result_array () as $row ) {
				$arrJournals [] = $row;
			}
		} else {
			return false;
		}
		return $arrJournals;
	}
	function getPubTypeData($kolId, $fromYear, $toYear, $keyword) {
		$this->db->select ( 'pubmed_publications_types.id,pubmed_publications_types.type,COUNT(DISTINCT(publications_types.pub_id)) AS count' );
		$this->db->join ( 'publications', 'kol_publications.pub_id=publications.id', 'inner' );
		$this->db->join ( 'publications_types', 'publications_types.pub_id=kol_publications.pub_id', 'inner' );
		$this->db->join ( 'pubmed_publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id', 'inner' );
		if ($fromYear != '' && $toYear != '') {
			
			$this->db->where ( "(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')" );
		}
		
		if ($keyword != '') {
			$this->db->join ( 'publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left' );
			$this->db->join ( 'pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left' );
			$this->db->join ( 'publication_substances', 'publication_substances.pub_id=publications.id', 'left' );
			$this->db->join ( 'pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left' );
			$this->db->where ( "(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')" );
		}
		$this->db->where ( 'kol_publications.is_verified', 1 );
		$this->db->where ( 'kol_publications.is_deleted', 0 );
		$this->db->where ( 'kol_publications.kol_id', $kolId );
		$this->db->group_by ( 'publications_types.pub_type_id' );
		$this->db->order_by ( 'count', 'desc' );
		$this->db->limit ( '20' );
		$results = $this->db->get ( 'kol_publications' );
		foreach ( $results->result_array () as $row ) {
			$arrIds [] = $row;
		}
		return $arrIds;
	}
	function updatePublicationAsDeleted($id){
		$kolPublication['is_deleted']=1;
		$kolPublication['is_verified']=0;
		$this->db->select('kol_id');
		$this->db->where('id',$id);
		$queryRes = $this->db->get('kol_publications');
		$row = $queryRes->row();
		if (isset($row))
		{
			if($row->kol_id > 0){
				$transactionName = 'Sets publication as deleted by setting the is_deleted to 1';
				$kol_org_type = 'Kol';
				$kols_or_org_id = $row->kol_id;
				$parentObjectId = $row->kol_id;
			}
		}
		$this->db->where('id', $id);
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}
	function getPublicationDetail($pubId){
		$publication=array();
		$this->db->where('id',$pubId);
		$publication=$this->db->get('publications');
		$publication=$publication->row_array();
		return 	$publication;
	}
	function listPublicationAuthors($pubId){
		$arrAuthors=array();
		$this->db->select('pubmed_authors.*,publications_authors.position');
		$this->db->from('pubmed_authors');
		$this->db->join('publications_authors', 'publications_authors.author_id = pubmed_authors.id','left');
		$this->db->where('pub_id', $pubId);
		$where="!((last_name='Not Available' ) and (initials='Not Available'))";
		$this->db->where($where);
		$this->db->order_by("publications_authors.position","ASC");
		$arrAuthorsResult = $this->db->get();
		foreach($arrAuthorsResult->result_array() as $row){
			$arrAuthors[]=$row;
		}
		return 	$arrAuthors;
	}
	function updatePublicationManual($arrPublicationDetails){
		$this->db->where('id',$arrPublicationDetails['id']);
		if($this->db->update('publications',$arrPublicationDetails)){
			return true;
		}else{
			return false;
		}
	}
	function updatePublicationJournalManual($arrPublicationDetails){
		if($this->db->query("update pubmed_journals
							LEFT JOIN publications ON pubmed_journals.id=publications.journal_id
							set pubmed_journals.name='".$arrPublicationDetails['journal_name']."'
							WHERE publications.id=".$arrPublicationDetails['id'])){
							return true;
		}else{
			return false;
		}
	}
	function calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail){
		$position='';
		if($arrKolDetail==null)
			$arrKolDetail=$this->getKolDetail($kolId);
			// get the name details
			$firstName=$arrKolDetail['first_name'];
			$midleName=$arrKolDetail['middle_name'];
			$lastName=$arrKolDetail['last_name'];
			$kolId=$arrKolDetail['id'];
			
			//get the different combinations of names
			$arrNameCombinations=$this->generate_name_combinations($firstName, $midleName, $lastName);
			foreach($arrNameCombinations as $nameCombination){
				$arrName=explode(" ", $nameCombination);
				if(sizeof($arrName)==2){
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]);
				}
				else{
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]." ".$arrName[2]);
					$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]."".$arrName[2]);
				}
			}
			$position;
			// 		pr($arrPos);
			foreach($arrPos as $pos){
				if($pos!='')
					$position=$pos;
			}
			// save the authorsip position in the kol_publications table, later remove this from this function
			//$this->updateAuthorshipPos($kolId,$pubId,$position);
			//echo $position;
			return $position;
	}
	function getKolDetail($kolId){
		$kolDetail=array();
		$this->db->where('id',$kolId);
		$kolDetail=$this->db->get('kols');
		$kolDetail=$kolDetail->row_array();
		return 	$kolDetail;
	}
	function generate_name_combinations($firsName, $midleName, $lastName){
		
		$firstName = $firsName;
		$middleName = $midleName;
		$lastName = $lastName;
		
		$firstNameInitial = substr($firstName, 0, 1);
		$middleNameInitial = substr($middleName, 0, 1);
		$middleNameLength = strlen($middleName);
		
		$lastNameInitial = substr($lastName, 0, 1);
		
		$arrName= array();
		if($firstName!="" && $middleName=="" && $lastName!=""){
			//echo "<h3>Case : 1 </h3>";
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
			
		}
		if($firstName!="" && $middleNameLength==1 && $lastName!=""){
			//echo "<h3>Case : 2 </h3>";
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			//Added when finding the kol from the co authors
			$arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
			$arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
		}
		if($firstName!="" && $middleNameLength!=1 &&$middleName!="" && $lastName!=""){
			//echo "<h3>Case : 3 </h3>";
			$arrName[] = $lastName." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleName;
			$arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
			$arrName[] = $lastName." ".$middleName." ".$firstName;
			$arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			//Added when finding the kol from the co authors
			$arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
			$arrName[] = $firstName." ".$middleName." ".$lastName;
			$arrName[] = $firstName." ".$lastName;
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleName;
			$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			$arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
			$arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
			$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
			$arrName[] = $lastName." ".$firstNameInitial;
			$arrName[] = $firstNameInitial." ".$lastName;
		}
		return $arrName;
	}
	function updateAuthorshipPos($kolId,$pubId,$position){
		$kolPublication=array();
		$kolPublication['auth_pos']=$position;
		$this->db->where('kol_id', $kolId);
		$this->db->where('pub_id', $pubId);
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}
	function delete_author_publication($pubId,$autId){
		if($this->db->delete("publications_authors",array("pub_id"=>$pubId,"author_id"=>$autId)) && $this->db->delete("pubmed_authors",array("id"=>$autId))){
			return true;
		}
		return false;
	}
	function savejournalName($journalName){
		$journalId='';
		$arrJournal['name']=$journalName;
		$this->db->where('name',$journalName);
		if($arrJournals=$this->db->get('pubmed_journals')){
			if($arrJournals->num_rows()!=0){
				$journalObj=$arrJournals->first_row();
				$journalId=$journalObj->id;
			}
			else {
				if($this->db->insert('pubmed_journals',$arrJournal)){
					$journalId=$this->db->insert_id();
				}else{
					
				}
			}
		}
		return $journalId;
	}
	function getManualPmid(){
		$pmid='';
		$this->db->select('min(pmid) as pmid');
		$returndPmid=$this->db->get('publications');
		if($returndPmid->num_rows() == 0){
			$pmid = -1;
		}else{
			foreach($returndPmid->result_array() as $arrRow){
				if($arrRow['pmid'] <= 0){
					$pmid = $arrRow['pmid']-1;
				}else
					$pmid = -1;
			}
		}
		return $pmid;
	}
	function savePublicationsManualAndFlags($pubDetails, $kolId){
		$kolPublication=array();
		$kolPublication['data_type_indicator'] = $pubDetails['data_type_indicator'];
		unset($pubDetails['data_type_indicator']);
		//save the publication and get the publication id
		$pubId=$this->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';
		//prepare the kol-to-publication association object
		$kolPublication['kol_id']=$kolId;
		$kolPublication['pub_id']=$pubId;
		$kolPublication['is_deleted']=0;
		$client_id = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		//For manual saving Cliend id is logged client id and its verified
		if(isset($client_id)){
			$kolPublication['client_id']   = $client_id;
			$kolPublication['is_verified'] = 1;
			$kolPublication['user_id']     = $userId;
		}else{
			$kolPublication['client_id'] = INTERNAL_CLIENT_ID;
		}
		//save the kol-to-publication record
		$isSaved=$this->saveKolPublication($kolPublication);
		//return the publication Id
		return $pubId;
	}
	function savePublication($pubDetails,$publicationId=0){
		if($publicationId==0){
			$pubId='';
			if($this->db->insert('publications',$pubDetails)){
				$pubId=$this->db->insert_id();
			}else{
				
			}
			return $pubId;
		}else{
			$this->db->update("publications",$pubDetails,array("id"=>$publicationId));
		}
	}
	function saveKolPublication($kolPublication){
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$kolPublication['data_type_indicator'] = $dataType;
		if(isset($userId) && $userId != ''){
			$kolPublication['client_id'] = $clientId;
			$kolPublication['user_id'] = $userId;
		}else{
			$kolPublication['client_id'] = INTERNAL_CLIENT_ID;
			$kolPublication['user_id'] = INTERNAL_USER_ID;
		}
		
		if($this->db->insert('kol_publications',$kolPublication)){
			return true;
		}else{
			return false;
		}
	}
	function getAuthorshipPos($pubId,$firstName,$lastName){
		$pos='';
		$this->db->select('publications_authors.position');
		$this->db->from('pubmed_authors');
		$this->db->join('publications_authors', 'publications_authors.author_id = pubmed_authors.id','left');
		$this->db->where('pub_id', $pubId);
		$this->db->where('last_name', $firstName);
		$where="(fore_name=\"".$lastName."\" OR initials=\"".$lastName."\")";
		$this->db->where($where);
		$arrAuthorsResult = $this->db->get();
		// 		pr($this->db->last_query());
		if($arrAuthorsResult && $arrAuthorsResult->num_rows()!=0){
			$arrAuthor=$arrAuthorsResult->row_array();
			$pos=$arrAuthor['position'];
		}
		return 	$pos;
	}
	function listPublicationMeshTerms($pubId){
		$arrMeshTerms=array();
		$this->db->select('pubmed_mesh_terms.*,publication_mesh_terms.is_major');
		$this->db->from('pubmed_mesh_terms');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->where('pub_id', $pubId);
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
			$arrMeshTerms[]=$row;
		}
		return 	$arrMeshTerms;
	}
	function getPublicationChart($kolId, $fromYear, $toYear, $keyword) {
		$arrPublications = array();
		$this->db->select('year(created_date) as year,count(distinct kol_publications.pub_id) as count');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');
		if ($keyword != '') {
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
			$this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
			$this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
	
		$this->db->where('kol_id', $kolId);
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified', 1);
		if ($fromYear != 0 && $toYear != 0)
			$this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
			$this->db->group_by('year(created_date)');
			$this->db->order_by('year(created_date)', 'desc');
			//$this->db->limit('15');
				
			$arrPublicationsResult = $this->db->get('publications');
			foreach ($arrPublicationsResult->result_array() as $row) {
				$arrPublications[] = $row;
			}
			//pr($arrPublications);
			return $arrPublications;
	}
	function getTopConceptDataForChart($kolId, $fromYear, $toYear, $keyword, $limit = '') {
		$arrMajorMeshterm = array();
		$this->db->select('pubmed_mesh_terms.id,pubmed_mesh_terms.term_name as name,count(distinct kol_publications.pub_id) as count,pubmed_mesh_terms.parent_id,pubmed_mesh_terms.tree_id');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id', 'left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');
	
		if ($keyword != '') {
			//$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			//$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
			$this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified', 1);
		$this->db->where('kol_id', $kolId);
		//$this->db->where('publication_mesh_terms.is_major','0');
		$where = 'year(publications.created_date)';
		$where .= 'between '.$fromYear.' and '.$toYear;
		$this->db->where($where);
		$this->db->group_by('pubmed_mesh_terms.term_name');
		$this->db->order_by('count', 'desc');
		if ($limit != 'all')
			$this->db->limit('20');
				
			$arrMajorMeshtermResult = $this->db->get('pubmed_mesh_terms');
			// 		echo $this->db->last_query();exit;
			foreach ($arrMajorMeshtermResult->result_array() as $row) {
				$arrMajorMeshterm[] = $row;
			}
			return $arrMajorMeshterm;
	}
	function countPublications($kolId) {
		$count = '';
		$this->db->where('kol_id', $kolId);
		$this->db->where('is_deleted', 0);
		$this->db->where('is_verified', 1);
		if ($count = $this->db->count_all_results('kol_publications')) {
			return $count;
		} else {
			return $count;
		}
	}
	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 */
	function listPublicationDetailsForAnalyst($kolId,$type){
		$arrPublications=array();
		$this->db->select('publications.*,kol_publications.auth_pos,kol_publications.id as asoc_id');
		$this->db->from('publications');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->where('kol_id', $kolId);
		if($type=='unVerified'){
			$this->db->where('kol_publications.is_deleted', 0);
			$this->db->where('kol_publications.is_verified', 0);
		}else if($type=='verified'){
			$this->db->where('kol_publications.is_deleted', 0);
			$this->db->where('kol_publications.is_verified', 1);
		}else{
			$this->db->where('kol_publications.is_verified', 0);
			$this->db->where('kol_publications.is_deleted', 1);
		}
		$this->db->distinct();
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}
		return 	$arrPublications;
	}
	/**
	 * Sets publication as verified by setting the 'is_verified' to 1
	 * @param $kolPublication
	 * @return unknown_type
	 * @author Vinayak
	 */
	function updatePublicationAsVerified($id,$kolPublication){
		$this->db->where('id', $id);
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}
}
?>