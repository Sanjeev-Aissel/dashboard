<?php
/**
 * File to 'add' Contact details
 *
 * @author: Ambarish
 * @created on: 13-12-10
 */
?>


	<!-- Validator Plugin -->

	<link type="text/css" href="<?php echo base_url()?>css/validationEngine.jquery.css" rel="Stylesheet" />
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine-en.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine.js"></script>

	<script type="text/javascript">
	$(document).ready(function() {				
		$(".validateForm").validationEngine({
				promptPosition: "centerRight", // OPENNING BOX POSITION, IMPLEMENTED: topLeft, topRight, bottomLeft,  centerRight, bottomRight
				success :  false,				
				failure : function() {
			}
		}); 	

		/**
		* Save the 'Contact Details'
		*/
		$("#saveContact").click(function(){

			id = $("#contactId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_contact';
			}else{
				formAction = '<?php echo base_url();?>kols/update_contact';
			}					
			
			 $.post(formAction, $("#contactForm").serialize(),
					 function(returnData){
			     		if(returnData.saved == true){

							// Before appending the data, if there is any recently added row, then remove the Class Name from that
							$("tr.recentlyAddedRow").removeClass('recentlyAddedRow');
							
							// Append the data to the Listing Table
							$newRecord = "<tr class='recentlyAddedRow' id='contact_"+returnData.lastInsertId+"'>";
							$newRecord += "<td>" + returnData.data.related_to + "</td>";
							$newRecord += "<td>" + returnData.data.phone + "</td>";
							$newRecord += "<td>" + returnData.data.email + "</td>";
							
							$newRecord += "<td> <a class='editLink' href='#' onClick='javascript:editContact("+ returnData.lastInsertId +")'>Edit</a>"  + "</td>";
							$newRecord += "<td> <a class='deleteLink' href='#' onClick='javascript:deleteContact("+ returnData.lastInsertId +")'>Delete</a>"  + "</td>";
							$newRecord += "</tr>";

							$(".listContactResultSet").prepend($newRecord);
							//- End of Appending the data to the Listing Table
							
							// Clear the existing form details
							$("#contactRelatedTo").val("");
							$("#contactPhone").val("");
							$("#contactEmail").val("");
							
							// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveContact").val("Add");

								// Re-Set the Hidden Eduction Id value
								$("#contactId").val("");									
							}
							
				     	}else{
							// Display Error Message
					     }
					},"json");
		});				
	 });

	/**
	* Edit the 'Contact Details'
	*/
	function editContact(id){
		$("#contact_"+id).each(function(){
			// Get the values from TR - Table Row, which is under editing
			relatedTo 		= $(this).find('td').eq(0).html();
			phone		 	= $(this).find('td').eq(1).html();
			email			= $(this).find('td').eq(2).html();

			// Add the values to the form
			$("#contactRelatedTo").val(relatedTo);
			$("#contactPhone").val(phone);
			$("#contactEmail").val(email);

			// Modify the text of 'Button' from 'Add' to 'Update'
			$("#saveContact").val("Update");

			// Set the Hidden Eduction Id value
			$("#contactId").val(id);
			
		});

		// Remove the row from the Table
		$("#contact_"+id).remove();
	}

	/**
	* Delete the 'Contact Details'
	*/
	function deleteContact(id){								

		formAction = '<?php echo base_url();?>kols/delete_contact/'+id;
		jConfirm("Are you sure you want to delete?","Please confirm",function(r){
				if(r){
					$.post(formAction,
							 function(returnData){
					     		
					     		if(returnData=='success'){
					     			// Remove the row from the Table
					    			$("#contact_"+id).remove();
						     		}
							},
							"text");
					}else{
						return false;
					}
			});
	}		 
	</script>



<!--Add Contact details-->
<h1>Add Contact details</h1>
<form action="save_contact" method="post" id="contactForm" name="contactForm" class="validateForm">
	<p>
		<input type="hidden" name="id" id="contactId" value=""></input>
	</p>
	
	<p>
		<label for="contactRelatedTo">Related To:</label>
		<input type="text" name="related_to" value="" id="contactRelatedTo" ></input>
	</p>

	<p>
		<label for="contactPhone">Phone No:</label>
		<input type="text" name="phone" value="" id="contactPhone" class="validate[custom[telephone]]" title="enter"></input>
	</p>

	<p>
		<label for="contactEmail">Email:</label>
		<input type="text" name="email" value="" id="contactEmail" class="validate[custom[email]]"></input>
	</p>
		
	<div class="formButtons">
		<input type="button" value="Add" name="submit" id="saveContact">
	</div>
</form>	
<!--End of Add Contact details-->

<!--List Contacts details-->
<h1>List of Contacts details </h1>	
	<div id="listContact">
		<table class="listResultSet listContactResultSet">
			<thead>
				<tr>
					<th>Related To</th>
					<th>Phone</th>
					<th>Email</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<?php 
				foreach($arrContactDetails as $contactInfo): 
					$rowId	= "contact_" . $contactInfo['id'];
			?>
			<tr id="<?php echo $rowId;?>">
				<td><?php echo $contactInfo['related_to'];?></td>
				<td><?php echo $contactInfo['phone'];?></td>
				<td><?php echo $contactInfo['email'];?></td>
				
				<?php echo '<td><a class="editLink" href="#" onClick="editContact(\''.$contactInfo['id'].'\')">Edit</a></td>' ?>
				<?php echo '<td><a class="deleteLink" href="#" onClick="deleteContact(\''.$contactInfo['id'].'\')">Delete</a></td>' ?>
			</tr>
	
		
			<?php 
			endforeach;
			?>
		</table>
	</div>	
<!--End of List Contacts details -->	

