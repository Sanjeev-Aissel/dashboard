<?php

/**
 * class for city, states, countries help
 * 
 * @package application.models
 * @author Ramesh B
 * @since
 * @created on 
 */
//class City_state_country extends controller{
class Country_helper extends Model{
	
	/*
	 * Constructore
	 */
	function Country_helper(){
		
		parent::Model();
		
	}
	
	/*
	 * function to list all the available countries
	 */
	function listCountries(){
		$client_id = $this->session->userdata('client_id');
		$arrCountry=array();
		$userGroupName = getGroupDetails();
		$group_names = explode(',',  $userGroupName['group_names']);
// 		$group_names = explode(',', $this->session->userdata('group_names'));
		//preparing temp arrCountry
			/*
			$country1=array('country_id' => '0','country_name'=>'india');
			$country2=array('country_id' => '1','country_name'=>'aus');
			$country3=array('country_id' => '2','country_name'=>'usa');
			$arrCountry['0']=$country1;
			$arrCountry['1']=$country2;
			$arrCountry['2']=$country3;
			*/
		//end of preparinf temp arrCountry		
// 		$this->db->group_by('Country');
		$this->db->order_by('Country');
//		$this->db->where('CountryId',254);
        if(INTERNAL_CLIENT_ID != $client_id){
            if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
    		  $this->db->where_in('GlobalRegion',$group_names);
            }
        }
		$result=$this->db->get('countries');
		$country=array();
		// looping trought each row to get 'country_id->coubtry_name' pair
			foreach ($result->result() as $row)
				{					
					$country['country_id']=$row->CountryId;
					$country['country_name']=$row->Country;
					$arrCountry[$country['country_name']]=$country;
				}
		// end of looping trought all rows
		
		return $arrCountry;		
	}
	
	/*
	 * function to list all the available states
	 */
	function listStates(){
		$arrStates=array();
		$this->db->order_by('Region');
		$result=$this->db->get('regions');
		$state=array();
		// looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result() as $row)
				{					
					$state['state_id']=$row->RegionID;	
					$state['state_name']=$row->Region;
					$arrStates[$state['state_name']]=$state;
				}
		// end of looping trought all rows
		
		return $arrStates;		
	}
	function listStatesAssociated(){
	    $arrStates=array();
	    $this->db->order_by('Region');
	    $result=$this->db->get('regions');
	    $state=array();
	    // looping trought each row to get 'state_id->state_name' pair
	    foreach ($result->result() as $row)
	    {
	        $state['state_id']=$row->RegionID;
	        $state['state_name']=$row->Region;
	        $index = $row->CountryID.'_'.str_replace(" ", "_", $row->Region);
	        $arrStates[$index]=$state;
	    }
	    // end of looping trought all rows
	
	    return $arrStates;
	}
	
/*
 *  Function to fetch 2 digit state code from datatbase where state id or state name is sent as parameter
 *  and indicated by second parameter 'id' or 'name'
 * 
 */	
	function getStatecodeByStateIdorName($stateIDorName,$stateBy){
		$arrStateCode	=	array();
		$stateCode		=	array();
		if($stateBy == 'name')
			$this->db->where('Region', $stateIDorName);
		else if($stateBy == 'id')
			$this->db->where('RegionID', $stateIDorName);
		$result	=	$this->db->get('regions');
		foreach ($result->result() as $row)
			{					
				$stateCode['state_code']	=	$row->Code;
				$arrStatesCode[]	=	$stateCode;
			}
			return $arrStatesCode;
	}
	/*
	 * function to get states belongs to county 
	 * takes 'country_id' as parameter
	 */
	function getStatesByCountryId($countryId){
				
		$arrState=array();
		
		$this->db->where('CountryID', $countryId); 
		//$condition=array ('CountryID' => $countryId);
		//$result=$this->db->get_where('regions',$condition);
		$this->db->order_by('Region');
		$result=$this->db->get('regions');
		$state=array();
		// looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result() as $row)
				{										
					$state['state_id']=$row->RegionID;	
					$state['state_name']=$row->Region;
					$arrState[]=$state;				    
				}
		// end of looping trought all rows
		
		return $arrState;	
		
	}
	
	/*
	 * function to list all the available cities
	 */
	function listCities(){
		$arrCity=array();
		$this->db->select('city,cityId');
		$result=$this->db->get('cities');
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result() as $row)
				{										
					$city['city_id']	=	$row->cityId;	
					$city['city_name']	=	$row->city;
					$arrCity[$city['city_name']]=	$city;				    
				}
		// End of looping trought all rows
		
		return $arrCity;			
	}
	function listCitiesAssociated(){
	    $arrCity=array();
	    $this->db->select('city,cityId,CountryID,RegionID');
	    $result=$this->db->get('cities');
	    $city=array();
	    // Looping trought each row to get 'state_id->state_name' pair
	    foreach ($result->result() as $row)
	    {
	        $city['city_id']	=	$row->cityId;
	        $city['city_name']	=	$row->city;
	        $index = $row->CountryID.'_'.$row->RegionID.'_'.str_replace(" ", "_", $row->city);
	        $arrCity[$index]=	$city;
	    }
	    // End of looping trought all rows
	
	    return $arrCity;
	}
	/*
	 * function to get cities belongs to state
	 * takes 'state_id' as parameter
	 */
function getCitiesByStateId($stateId,$cityName='',$forAutocomplete=false,$limit=50,$offset=0){
	
		$arrCity=array();
		$this->db->select('cities.city,cities.cityId,regions.Region as state,cities.Latitude,cities.Longitude');
		//if($stateId>0){
			$this->db->where('cities.RegionID', $stateId);
		//} 
		if(!empty($cityName)){
			$this->db->like('cities.city', $cityName);
		}
		$this->db->join('regions','regions.RegionID=cities.RegionID','inner');
		//$condition=array ('CountryID' => $countryId);
		//$result=$this->db->get_where('regions',$condition);
		$this->db->order_by('City');
		if($stateId == 0 || !isset($stateId))
			$this->db->limit($limit,$offset);
		
		$result=$this->db->get('cities');
		//echo $this->db->last_query();
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result_array() as $row)
				{
					$city['city_id']	=	$row['cityId'];	
					$city['city_name']	=	$row['city'];
					if($forAutocomplete){
						$arrCity[$row['cityId']][]=$row['city'];
						$arrCity[$row['cityId']][]=$row['state'];
						$arrCity[$row['cityId']][]=$row['Latitude'];
						$arrCity[$row['cityId']][]=$row['Longitude'];
					}else{
						$arrCity[]	=	$city;
					}	    
				}
		// End of looping trought all rows
		
		return $arrCity;	
		
	}
	
	/*
	 * Function to get country by Using id
	 * 
	 */
	function getCountryById($id){
		$arrCountry = array();
		$this->db->where('CountryID',$id);
		$result = $this->db->get('countries');
		foreach($result->result_array() as $row){
			if($result->num_rows!=0){
				$arrCountry = $row['Country'];
			}else{
				return false;
			}
			
		}
		return $arrCountry;
	
	}	
	
	/*
	 * Function to get state by Using 'id'
	 * 
	 */
	function getStateById($id){
		$arrState =	array();
		$this->db->where('RegionID',$id);
		$result = $this->db->get('regions');
		foreach($result->result_array() as $row){
			$arrState = $row['Region'];
		}
		return $arrState;
	
	}	
	
	
	/*
	 * Function to get state by Using 'id'
	 * 
	 */
	function getCityeById($id){
		$arrCity =array();
		$this->db->select('city');
		$this->db->where('CityID',$id);
		$result = $this->db->get('cities');
		foreach($result->result_array() as $row){
			$arrCity = $row['city'];
		}
		return $arrCity;
	}	

	/*
	 * Function to get country 'id' by Using country 'name'
	 */
	function getConcountryId($country){
		$arrCountryId  = array();
		$this->db->where('Country',$country);
		$this->db->select('CountryID');
		$result = $this->db->get('countries');
		foreach($result->result_array() as $row){
			$arrCountryId = $row['CountryID'];
		}
		return $arrCountryId;
	}

	/*
	 * Function to get state'Id' by Using state 'name'
	 */
	function getStateId($state){
		$arrCityId  = array();
		$this->db->where('Region',$state);
		$this->db->select('RegionID');
		$result = $this->db->get('regions');
		foreach($result->result_array() as $row){
			$arrCityId = $row['RegionID'];
		}
		return $arrCityId;
	}
	
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 * 
	 * 
	 * @param $orgName
	 * @return Array	$arrRoleNames	
	 */
	function getCountryNames($Country){
		$this->db->select('CountryId,Country');
		$this->db->like('Country', $Country);
		$this->db->join('kols','kols.country_id=countries.CountryId','inner');
		//$this->db->where('status',COMPLETED);
		$this->db->group_by('country_id');
		$arrResultSet = $this->db->get('countries');
		$arrCountryNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCountryNames[$arrRow['CountryId']] = $arrRow['Country'];
		}
		
		return $arrCountryNames;
	}
	function getCountryByStateId($stateId){
	    $this->db->select('CountryId');	   
	    $this->db->where('RegionID',$stateId);	    
	    $arrResultSet = $this->db->get('regions')->row();	    	
	    return $arrResultSet->CountryId;
	}

	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 * 
	 * 
	 * @param $orgName
	 * @return Array	$arrRoleNames	
	 */
	function getStateNames($state){
		$this->db->select('region as state');
		$this->db->like('region', $state);
		$arrResultSet = $this->db->get('regions');
		
		$arrStateNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrStateNames[] = $arrRow['state'];
		}
		
		return $arrStateNames;
	}
	
	/*
	 * To get all countrie And their counts for reports((Refine by charts by chek box kind of filtering))
	 * @author Vinayak
	 * @since 2.4
	 * @created on 3-6-2011
	 */
	function listGlobalRegionsAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType,$arrStatesIds=0,$profileType,$viewType, $arrGlobalRegionIds=0){
	
		$arrCountry=array();
		$country=array();
		if($reportSection=='events'){
			$this->db->select('countries.GlobalRegion as global_region, count(DISTINCT kol_events.event_id) as count');
				
			$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kol_events','kols.id=kol_events.kol_id','left');
				
			if($chartType=='Events By Session Type'){
				$this->db->where_not_in('kol_events.session_type','');
			}
			if($fromYear!=0 && $toYear!=0)
				$this->db->where("(year(kol_events.start) between  ".$fromYear."  and  ".$toYear."  or year(kol_events.start)=0)");
		}
		
		if($reportSection=='affiliations'){
			$this->db->select('countries.GlobalRegion as global_region,count(DISTINCT kol_memberships.institute_id) as count');
			$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kol_memberships','kol_memberships.kol_id=kols.id','left');
			if($chartType=='Affiliations By Eng Type'){
				$this->db->where_not_in('kol_memberships.engagement_id','');
			}
				
			if($fromYear!=0 && $toYear!=0){
				$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
			}
		}
		
		if($reportSection=='activity'){
			$this->db->select('countries.GlobalRegion as global_region, COUNT(kols.id) as count');
			$this->db->join('kols','kols.country_id=countries.countryId','inner');
			//	$this->db->where('kols.status',COMPLETED);
		}
		if($reportSection=='publications'){
			$this->db->select("countries.GlobalRegion as global_region, count(kol_publications.id) as count");
			$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kol_publications','kol_publications.kol_id=kols.id','left');
			$this->db->join('publications','publications.id=kol_publications.pub_id','left');
			$this->db->where('kol_publications.is_verified',1);
			$this->db->where('kol_publications.is_deleted',0);
			if($fromYear!=0 && $toYear!=0)
				$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.'  and  '.$toYear.' OR YEAR(publications.created_date)="0")');
		}
		
		if($reportSection=='segmentation'){
			$this->db->select('countries.GlobalRegion as global_region, count(kols.id) as count');
			$this->db->join('kols','kols.country_id=countries.countryId','inner');
		}
		
		if($arrSpecialityIds!='' && $arrSpecialityIds!=0){
			//$this->db->join('kols','kols.id=kol_events.kol_id','left');
			$this->db->where_in('kols.specialty',$arrSpecialityIds);
		}
		/* if($arrCountriesIds!='' && $arrCountriesIds!=0){
			$this->db->where_in('regions.CountryID',$arrCountriesIds);
		} */
		if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
			$this->db->where_in('kols.country_id', $arrCountriesIds);
		}
		if($arrStatesIds!='' && $arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
		if($arrKolIds!='' && $arrKolIds!=0){
			//$this->db->join('kols','kols.id=kol_events.kol_id','left');
			$this->db->where_in('kols.id',$arrKolIds);
		}
		if($arrListNamesIds!='' && $arrListNamesIds!=0 && sizeof($arrListNamesIds)>0){
			$userId=$this->session->userdata('user_id');
			$clientId=$this->session->userdata('client_id');
			$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
			$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
			$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
			$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			$this->db->where_in('list_names.id',$arrListNamesIds);
		}
		if ($profileType != ''){
		    if($profileType == DISCOVERY){
		        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols.profile_type', $profileType);
		        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		    }
		    //             $this->db->where('kols.profile_type', $arrProfileType);
		}else{
		    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		}
		if(isset($viewType) && sizeof($viewType) > 0){
			$this->db->where_in("kols.id",$viewType);
		}
		
// 		$this->db->where('kols.status',COMPLETED);
		$this->db->group_by('countries.GlobalRegion');
		$this->db->order_by('count desc');
			
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
			
		$result=$this->db->get('countries');
		//echo $this->db->last_query();exit;
		// looping trought each row to get 'country_id->coubtry_name' pair
		foreach ($result->result_array() as $row)
		{
			$globalRegion['count']      		= $row['count'];
			$globalRegion['GlobalRegion']	= $row['global_region'];
			$arrGlobalRegion[$row['global_region']]	= $globalRegion;
		}
		
		// end of looping trought all rows
		return $arrGlobalRegion;
	}
	
	/*
	 * To get all countrie And their counts for reports((Refine by charts by chek box kind of filtering))
	 * @author Vinayak
	 * @since 2.4
	 * @created on 3-6-2011
	 */
	function listCountriesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType,$arrStatesIds=0,$profileType,$viewType, $arrGlobalRegionIds=0){
		
		$arrCountry=array();
		$country=array();
		if($reportSection=='events'){
			$this->db->select('countries.country,count(DISTINCT kol_events.event_id) as count,countries.countryId');
			
			$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kol_events','kols.id=kol_events.kol_id','left');
			
			if($chartType=='Events By Session Type'){
				$this->db->where_not_in('kol_events.session_type','');
			}
			if($fromYear!=0 && $toYear!=0)
			$this->db->where("(year(kol_events.start) between  ".$fromYear."  and  ".$toYear."  or year(kol_events.start)=0)");
		}
		
		if($reportSection=='affiliations'){
			$this->db->select('countries.country,count(DISTINCT kol_memberships.institute_id) as count,countries.countryId');
			$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kol_memberships','kol_memberships.kol_id=kols.id','left');
			if($chartType=='Affiliations By Eng Type'){
				$this->db->where_not_in('kol_memberships.engagement_id','');
			}
			
			if($fromYear!=0 && $toYear!=0){
				$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
			}
		}
		
		if($reportSection=='activity'){
			$this->db->select('countries.country,count(kols.id) as count,countries.countryId');
			$this->db->join('kols','kols.country_id=countries.countryId','inner');
		//	$this->db->where('kols.status',COMPLETED);
		}
		
		if($reportSection=='publications'){
				$this->db->select("countries.country,count(kol_publications.id) as count,countries.countryId");
				$this->db->join('kols','kols.country_id=countries.countryId','left');
				$this->db->join('kol_publications','kol_publications.kol_id=kols.id','left');
				$this->db->join('publications','publications.id=kol_publications.pub_id','left');
				$this->db->where('kol_publications.is_verified',1);
				$this->db->where('kol_publications.is_deleted',0);
				if($fromYear!=0 && $toYear!=0)
					$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.'  and  '.$toYear.' OR YEAR(publications.created_date)="0")');
			}
		
			if($reportSection=='segmentation'){
				$this->db->select('countries.country,count(kols.id) as count,countries.countryId');
				$this->db->join('kols','kols.country_id=countries.countryId','inner');
			}
			if($arrSpecialityIds!='' && $arrSpecialityIds!=0){
				//$this->db->join('kols','kols.id=kol_events.kol_id','left');
				$this->db->where_in('kols.specialty',$arrSpecialityIds);
			}
			if ($arrGlobalRegionIds != '' && $arrGlobalRegionIds != 0) {
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			}
			if($arrStatesIds!='' && $arrStatesIds!=0){
				$this->db->where_in('kols.state_id',$arrStatesIds);
			}
			if($arrKolIds!='' && $arrKolIds!=0){
				//$this->db->join('kols','kols.id=kol_events.kol_id','left');
				$this->db->where_in('kols.id',$arrKolIds);
			}
			if($arrListNamesIds!='' && $arrListNamesIds!=0 && sizeof($arrListNamesIds)>0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
				}
			if ($profileType != ''){
			    if($profileType == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', $profileType);
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
			$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
			if(isset($viewType) && sizeof($viewType) > 0){
				$this->db->where_in("kols.id",$viewType);
			}
// 			$this->db->where('kols.status',COMPLETED);
			$this->db->group_by('countries.country');
			$this->db->order_by('count desc');
			
			$client_id = $this->session->userdata('client_id');
			if($client_id !== INTERNAL_CLIENT_ID){
				$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
				$this->db->where('kols_client_visibility.client_id', $client_id);
			}
			
			$result=$this->db->get('countries');
			//echo $this->db->last_query();
			// looping trought each row to get 'country_id->coubtry_name' pair
			foreach ($result->result_array() as $row)
				{					
					$country['count']      		= $row['count'];	
					$country['country_name']	= $row['country'];
					$country['country_id']  	= $row['countryId'];
					$arrCountry[$row['countryId']]= $country;				    
				}
			//	pr($this->db->last_query());exit;
			// end of looping trought all rows
			return $arrCountry;		
	}
	function listStatesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType,$arrStatesIds=0,$profileType,$viewType, $arrGlobalRegionIds=0){
		
		$arrState	= array();
		$state		= array();
		if($reportSection=='events'){
			$this->db->select('regions.region as state,count(DISTINCT kol_events.event_id) as count,regions.regionID');
			
			//$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kols','kols.state_id=regions.regionID','left');
			$this->db->join('kol_events','kols.id=kol_events.kol_id','left');
			
			if($chartType=='Events By Session Type'){
				$this->db->where_not_in('kol_events.session_type','');
			}
			if($fromYear!=0 && $toYear!=0)
			$this->db->where("(year(kol_events.start) between  ".$fromYear."  and  ".$toYear."  or year(kol_events.start)=0)");
		}
		
		if($reportSection=='affiliations'){
			$this->db->select('regions.region as state,count(DISTINCT kol_memberships.institute_id) as count,regions.regionID');
		//	$this->db->join('kols','kols.country_id=countries.countryId','left');
			$this->db->join('kols','kols.state_id=regions.regionID','left');
			$this->db->join('kol_memberships','kol_memberships.kol_id=kols.id','left');
			if($chartType=='Affiliations By Eng Type'){
				$this->db->where_not_in('kol_memberships.engagement_id','');
			}
			
			if($fromYear!=0 && $toYear!=0)
				$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
		}
		
		if($reportSection=='activity'){
			$this->db->select('regions.region as state,count(kols.id) as count,regions.regionID');
			//$this->db->join('kols','kols.country_id=countries.countryId','inner');
			$this->db->join('kols','kols.state_id=regions.regionID','left');
			//$this->db->where('kols.status',COMPLETED);
		}
		
		if($reportSection=='publications'){
				$this->db->select("regions.region as state,count(kol_publications.id) as count,regions.regionID");
				//$this->db->join('kols','kols.country_id=countries.countryId','left');
				$this->db->join('kols','kols.state_id=regions.regionID','left');
				$this->db->join('kol_publications','kol_publications.kol_id=kols.id','left');
				$this->db->join('publications','publications.id=kol_publications.pub_id','left');
				$this->db->where('kol_publications.is_verified',1);
				$this->db->where('kol_publications.is_deleted',0);
				if($fromYear!=0 && $toYear!=0)
					$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.'  and  '.$toYear.' OR YEAR(publications.created_date)="0")');
			}	
		
			if($reportSection=='segmentation'){
				$this->db->select('regions.region as state,count(kols.id) as count,regions.regionID');
				//$this->db->join('kols','kols.country_id=countries.countryId','inner');
				$this->db->join('kols','kols.state_id=regions.regionID','inner');
			
			}
			if ($arrGlobalRegionIds != '' && $arrGlobalRegionIds != 0) {
				$this->db->join('countries','kols.country_id=countries.countryId','inner');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			}
			if($arrSpecialityIds!='' && $arrSpecialityIds!=0){
				//$this->db->join('kols','kols.id=kol_events.kol_id','left');
				$this->db->where_in('kols.specialty',$arrSpecialityIds);
			}
			if($arrCountriesIds!='' && $arrCountriesIds!=0){
				$this->db->where_in('regions.CountryID',$arrCountriesIds);
			}
			if($arrKolIds!='' && $arrKolIds!=0){
				//$this->db->join('kols','kols.id=kol_events.kol_id','left');
				$this->db->where_in('kols.id',$arrKolIds);
			}
			if($arrListNamesIds!='' && $arrListNamesIds!=0 && sizeof($arrListNamesIds)>0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
				}
			if ($profileType != ''){
			    if($profileType == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', $profileType);
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
			if(isset($viewType) && sizeof($viewType) > 0){
				$this->db->where_in("kols.id",$viewType);
			}
// 			$this->db->where('kols.status',COMPLETED);
			$this->db->group_by('regions.region');
			$this->db->order_by('count desc');
			
			$client_id = $this->session->userdata('client_id');
			if($client_id !== INTERNAL_CLIENT_ID){
				$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
				$this->db->where('kols_client_visibility.client_id', $client_id);
			}
				
			$result=$this->db->get('regions');/* 
			echo $this->db->last_query();
			exit; */
			// looping trought each row to get 'country_id->coubtry_name' pair
			foreach ($result->result_array() as $row){
					$state['count']      		= $row['count'];	
					$state['state_name']		= $row['state'];
					$state['state_id']  		= $row['regionID'];
					$arrState[$row['regionID']]	= $state;				    
				}
			// end of looping trought all rows
			$arrStateIdsWithoutName	= array_flip(array_diff_key(array_flip($arrStatesIds), $arrState));
			if(sizeof($arrStateIdsWithoutName)>0){
				$this->db->select('regions.region as state,regions.regionID');
				$this->db->where_in('regions.regionID',$arrStateIdsWithoutName);
				$result	= $this->db->get('regions');
				foreach ($result->result_array() as $row){
						$state['count']      		= 0;	
						$state['state_name']		= $row['state'];
						$state['state_id']  		= $row['regionID'];
						$arrState[$row['regionID']]	= $state;				    
					}
			}
			return $arrState;		
	}
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 * 
	 * 
	 * @param $orgName
	 * @return Array	$arrRoleNames	
	 */
function getStateNamesForAutoComplete($state,$isGeneric=false,$country='',$limit=50,$offset=0){
		$this->db->select('region as state, countries.Country as country,regions.RegionID');
		$this->db->join('countries','countries.countryId=regions.CountryId','inner');
		if(!empty($country))
		  $this->db->like('countries.Country', $country);
		if(strlen($state)>2){
			$this->db->like('region', $state);
		}else{
			$this->db->like('Code', $state);
		}
		if(!$isGeneric){
		    $client_id = $this->session->userdata('client_id');
			$this->db->join('kols','kols.state_id=regions.RegionID','inner');
			//$this->db->where('kols.status',COMPLETED);
			if($client_id !== INTERNAL_CLIENT_ID){
			    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			    $this->db->where('kols_client_visibility.client_id', $client_id);
			}
			$this->db->group_by('state_id');
		}
		$this->db->order_by('region');
		$this->db->limit($limit,$offset);
		$arrResultSet = $this->db->get('regions');
		$arrStateNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['state'];
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['country'];
		}
		//echo $this->db->last_query();
		return $arrStateNames;
	}
	
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 * 
	 * 
	 * @param $orgName
	 * @return Array	$arrRoleNames	
	 */
	function getOrgCountryNames($Country){
		$this->db->select('Country');
		$this->db->like('Country', $Country);
		$this->db->join('organizations','organizations.country_id=countries.CountryId','inner');
		$this->db->where('status',COMPLETED);
		$this->db->group_by('country_id');
		$arrResultSet = $this->db->get('countries');

		$arrCountryNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCountryNames[] = $arrRow['Country'];
		}
		
		return $arrCountryNames;
	}
	
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 * 
	 * 
	 * @param $orgName
	 * @return Array	$arrRoleNames	
	 */
	function getOrgStateNamesForAutoComplete($state){
		$this->db->select('region as state, countries.Country as country,regions.RegionID');
		$this->db->like('region', $state);
		$this->db->join('countries','countries.countryId=regions.CountryId','inner');
		$this->db->join('organizations','organizations.state_id=regions.RegionID','inner');
		
		$this->db->where('organizations.status',COMPLETED);
		$this->db->group_by('state_id');
		$arrResultSet = $this->db->get('regions');
		$arrStateNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['state'];
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['country'];
		}
		return $arrStateNames;
	}
	
		function getStateNameById($arrIds){
		$arrState =	array();
		$this->db->where_in('RegionID',$arrIds);
		$result = $this->db->get('regions');
		foreach($result->result_array() as $row){
			$arrState[$row['RegionID']] = $row['Region'];
		}
		return $arrState;
	
	}
	
	function getCityNameById($arrIds){
		$arrCity =	array();
		$this->db->where_in('CityId',$arrIds);
		$result = $this->db->get('cities');
		foreach($result->result_array() as $row){
			$arrCity[$row['CityId']] = $row['City'];
		}
		return $arrCity;
	
	}
	
	function getCountryNameById($arrCountryIds){
		$arrCountries =	array();
		$this->db->where_in('CountryId',$arrCountryIds);
		$result = $this->db->get('countries');
		foreach($result->result_array() as $row){
			$arrCountries[$row['CountryId']] = $row['Country'];
		}
		return $arrCountries;
	}
	
	function getStateNameByStateCode($stateCode){
		$arrStates =	array();
		$this->db->where('regions.CountryID',254);
		$this->db->where('regions.Code',$stateCode);
		$result = $this->db->get('regions');
//		echo $this->db->last_query();
		if($result->num_rows() == 1){
			foreach($result->result_array() as $row){
				$arrStates = $row['Region'];
			}
			return $arrStates;
		}else{
			return $stateCode;
		}
	}
	
function getCitiesByStateIdIpad($stateId,$cityName='',$forAutocomplete=false,$countryId,$limit=50,$offset=0){
	
		$arrCity=array();
		$this->db->select('cities.city,cities.cityId,regions.Region as state,cities.Latitude,cities.Longitude');
		if($stateId>0){
			$this->db->where('cities.RegionID', $stateId);
		} 
			$this->db->where('cities.CountryId', $countryId);
		if(!empty($cityName)){
			$this->db->like('cities.city', $cityName);
		}
		$this->db->join('regions','regions.RegionID=cities.RegionID','inner');
		//$condition=array ('CountryID' => $countryId);
		//$result=$this->db->get_where('regions',$condition);
		$this->db->order_by('City');
		$this->db->limit($limit,$offset);
		
		$result=$this->db->get('cities');
		//echo $this->db->last_query();
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result_array() as $row)
				{
					$city['city_id']	=	$row['cityId'];	
					$city['city_name']	=	$row['city'];
					if($forAutocomplete){
						$arrCity[$row['cityId']][]=$row['city'];
						$arrCity[$row['cityId']][]=$row['state'];
						$arrCity[$row['cityId']][]=$row['Latitude'];
						$arrCity[$row['cityId']][]=$row['Longitude'];
					}else{
						$arrCity[]	=	$city;
					}	    
				}
		// End of looping trought all rows
		
		return $arrCity;	
		
	}
	
	function getCitiesByStateIdNew($stateId){
	
		$arrCity=array();
		$this->db->select('city,cityId');
		$this->db->where('RegionID', $stateId); 
		//$condition=array ('CountryID' => $countryId);
		//$result=$this->db->get_where('regions',$condition);
		$this->db->order_by('City');
		$result=$this->db->get('cities');
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
			foreach ($result->result_array() as $row)
				{
					$city['city_id']	=	$row['cityId'];	
					$city['city_name']	=	$row['city'];
					$arrCity[]			=	$city;	    
				}
		// End of looping trought all rows
		
		return $arrCity;	
		
	}
	
	function getStateNamesBYCountryIdForAutoComplete($state,$countryId){
		$this->db->select('regions.region as state,regions.RegionID');
		$this->db->where('regions.CountryId', $countryId);
		$this->db->select('countries.country as country_name');
		$this->db->join('countries','countries.countryId=regions.CountryId','inner');
		if(strlen($state) == 2)
			$this->db->like('Code', $state);
		else
			$this->db->like('region', $state);
		$arrResultSet = $this->db->get('regions');
		$arrStateNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['state'];
			$arrStateNames[$arrRow['RegionID']][] = $arrRow['country_name'];
		}
		return $arrStateNames;
	}
	
	function getCityNamesByStateIdAndCountryId($ctiy,$stateId,$countryId){
		$this->db->select('cities.City as city,cities.CityId');
		$this->db->where('cities.CountryID', $countryId);
		$this->db->select('regions.Region as state_name');
		$this->db->join('regions','regions.RegionID=cities.RegionID','inner');
		if($stateId != '')
			$this->db->where('cities.RegionId', $stateId);
		$this->db->like('city', $ctiy);
		$arrResultSet = $this->db->get('cities');
		$arrCityNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCityNames[$arrRow['CityId']][] = $arrRow['city'];
			$arrCityNames[$arrRow['CityId']][] = $arrRow['state_name'];
		}
		return $arrCityNames;
	}
        
//        function getCitiesNameByStateId($stateId,$countryId){
//	
//		$arrCity=array();
//		$this->db->select('city,cityId');
//		$this->db->where('RegionID', $stateId); 
//                $this->db->where('CountryID', $countryId); 
//		//$condition=array ('CountryID' => $countryId);
//		//$result=$this->db->get_where('regions',$condition);
//		$this->db->order_by('City');
//		$result=$this->db->get('cities');
//		$city=array();
//		// Looping trought each row to get 'state_id->state_name' pair
//			foreach ($result->result_array() as $row)
//				{
//					$city['city_id']	=	$row['cityId'];	
//					$city['city_name']	=	$row['city'];
//					$arrCity[]			=	$city;	    
//				}
//		// End of looping trought all rows
//		
//		return $arrCity;	
//		
//	}
        
        function getStateNamesByStateIdAndCountryId($state,$countryId){
		$arrCityId  = array();
		$this->db->where('Region',$state);
                $this->db->where('CountryID',$countryId);
		$this->db->select('RegionID');
		$result = $this->db->get('regions');
		foreach($result->result_array() as $row){
			$arrCityId = $row['RegionID'];
		}
		return $arrCityId;
	}
	
	function getZipCodeDetails($zipCode){
		$this->db->where("postal_code",$zipCode);
		$res = $this->db->get("zip_codes");
		if($res->num_rows() > 0){
			return $res->row_array();
		}else
			return '';
	}
	
	function getCityIdByDetails($details){
		$this->db->where("RegionId",$details['region_id']);
		$this->db->where("City",$details['place_name']);
		$res = $this->db->get("cities");
		if($res->num_rows() > 0){
			$row = $res->row_array();
			return $row['CityId'];
		}else
			return '';
	}
	
	function getCityNamesForAutoComplete($city,$isGeneric=false,$country="United States",$limit=50,$offset=0){
	    $this->db->select('cities.CityId,cities.City as city,regions.Region,countries.Country');
	    $this->db->join('countries','countries.CountryId = cities.CountryID','inner');
	    $this->db->join('regions','regions.RegionID = cities.RegionID','inner');
		$this->db->like('cities.City', $city);
		if(!$isGeneric){
			$this->db->join('kols','kols.city_id=cities.CityId','inner');
			$this->db->where('kols.customer_status',"ACTV");
			$client_id = $this->session->userdata('client_id');			
			//$this->db->where('kols.status',COMPLETED);
			if($client_id !== INTERNAL_CLIENT_ID){
			    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			    $this->db->where('kols_client_visibility.client_id', $client_id);
			}
			$this->db->group_by('city_id');
		}
		$this->db->order_by('city');
		$this->db->limit($limit,$offset);
		$arrResultSet = $this->db->get('cities');
// 		echo $this->db->last_query();
// 		exit;
		$arrCityNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCityNames[$arrRow['CityId']][] = $arrRow['city'];
			$arrCityNames[$arrRow['CityId']][] = $arrRow['Region'];
			$arrCityNames[$arrRow['CityId']][] = $arrRow['Country'];
		}
		return $arrCityNames;
	}
	function getExcludedKolsCountries($arrIds){
        $this->db->select(array('countries.CountryId', 'countries.Country', '0 as kol_country_count'), false);
        $this->db->order_by("Country", "asc"); 
        $this->db->join('kols','countries.CountryId=kols.country_id');
        if(count($arrIds) !=0)
        $this->db->where_not_in('countries.CountryId', $arrIds);
        $this->db->where('kols.status',COMPLETED);
        $this->db->group_by('countries.CountryId');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
        $query = $this->db->get('countries');
        //pr($this->db->last_query());exit;
        return $query->result_array();
    }
    
    function getExcludedKolsStates($arrIds){
        $this->db->select(array('regions.RegionID', 'regions.Region', '0 as kol_state_count'), false);
        $this->db->order_by("Region", "asc"); 
        $this->db->join('kols','regions.RegionID=kols.state_id');
        if(count($arrIds) !=0)
            $this->db->where_not_in('regions.RegionID', $arrIds);
        $this->db->where('kols.status',COMPLETED);
        $this->db->group_by('regions.RegionID');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
        $query = $this->db->get('regions');
        //pr($this->db->last_query());exit;
        return $query->result_array();
    }
    function checkCountryIfExistElseAdd($country,$isAdded=false){
	    	$this->db->select('CountryId');
	    	$this->db->where('Country',$country);
	    	$this->db->limit(1);
	    	$query = $this->db->get('countries');
	    	$result = $query->result_array();
	    	 
	    	if($result['0']['CountryId'] == ""){
	    		$data = array(
	    				'Country' => $country
	    		);
	    		$this->db->insert('countries', $data);
	    		if($isAdded){
	    		    $dataData = array();
	    		    $dataData['status'] = true;
	    		    $dataData['id'] = $this->db->insert_id();
	    		    return $dataData;
	    		}else{
	    		    return $this->db->insert_id();
	    		}
	    	}else{
	    	    if($isAdded){
	    	        $dataData = array();
	    	        $dataData['status'] = false;
	    	        $dataData['id'] = $result['0']['CountryId'];
	    	        return $dataData;
	    	    }else{
	    		     return $result['0']['CountryId'];
	    	    }
	    	}
	    }
        function checkStateIfExistElseAdd($state,$country,$isAdded=false){
            $this->db->select('RegionID');
            $this->db->where('Region',$state);
            $this->db->where('CountryID',$country);
            $this->db->limit(1);
            $query = $this->db->get('regions');
            $result = $query->result_array();
             
            if($result['0']['RegionID'] == ""){
                $data = array(
                        'CountryID' => $country,
                        'Region' => $state
                );
                $this->db->insert('regions', $data);
                if($isAdded){
                    $dataData = array();
                    $dataData['status'] = true;
                    $dataData['id'] = $this->db->insert_id();
                    return $dataData;
                }else{
                    return $this->db->insert_id();
                }
            }else{
                if($isAdded){
                    $dataData = array();
                    $dataData['status'] = false;
                    $dataData['id'] = $result['0']['RegionID'];
                    return $dataData;
                }else{
                    return $result['0']['RegionID'];
                }
            }
        }
        function checkCityIfExistElseAdd($city,$stateId,$country,$isAdded=false){
            $this->db->select('CityId');
            $this->db->where('city',$city);
            $this->db->where('RegionID',$stateId);
            $this->db->where('CountryID',$country);
            $this->db->limit(1);
            $query = $this->db->get('cities');
            $result = $query->result_array();
             
            if($result['0']['CityId'] == ""){
                $data = array(
                        'CountryID' => $country,
                        'RegionID' => $stateId,
                        'City'	=>	$city
                );
                $this->db->insert('cities', $data);
                if($isAdded){
                    $dataData = array();
                    $dataData['status'] = true;
                    $dataData['id'] = $this->db->insert_id();
                    return $dataData;
                }else{
                    return $this->db->insert_id();
                }
            }else{
                if($isAdded){
                    $dataData = array();
                    $dataData['status'] = false;
                    $dataData['id'] = $result['0']['CityId'];
                    return $dataData;
                }else{
                    return $result['0']['CityId'];
                }
            }
        }
}
