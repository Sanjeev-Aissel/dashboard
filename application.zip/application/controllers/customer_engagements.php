<?php

/*
 * @Author		: Laxman K
 * Created on	: 08-03-2016
 *  
 */

class customer_engagements extends Controller {

    private $loggedUserId = null;
    private $interactonType = array('' => 1, 'one' => 1, 'group' => 2);
     

    // constructor to initialize the data
    function customer_engagements() {
        parent::Controller();
        $this->load->model('customer_engagement');
        $this->load->model('coaching');
        $this->load->model('common_helpers');
        $this->load->model('Client_User');
        $this->loggedUserId = $this->session->userdata('user_id');
    }

    function send_mail($sub, $content, $email) {

        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        $this->email->to($email);
        $this->email->subject(preg_replace('/<\/?a[^>]*>/', '', $sub));
        $this->email->message($content);
        $this->email->set_crlf("\r\n");
        $res = $this->email->send();
//echo $this->email->print_debugger();
    }

    function add($interactionType = 'one', $userId = '', $interactionId = '', $engageMentId = '', $isViewSet = '', $reloadFlag = '', $isPdfSet = '') {


        $interactionDetails = array();
        $userRoleID = $this->session->userdata('user_role_id');
        $data['interactionType'] = $this->interactonType[$interactionType];

        if ($interactionId != '' && $interactionId != '0') {
            $arrInteractionsResults = $this->interaction->getInteractionDetails($interactionId);
            $interactionDetails['user_id'] = $arrInteractionsResults["created_by"];
            $interactionDetails["kol_name"] = $arrInteractionsResults['attendees']['kol_names'][0];
            $interactionDetails["kol_id"] = $arrInteractionsResults['attendees']['kol_ids'][0];
            $interactionDetails["date"] = sql_date_to_app_date($arrInteractionsResults['date']);;
             $interactionDetails["employee_id"]=$arrInteractionsResults['employee_id'];
        }
        $data['interactionDetails'] = $interactionDetails;
        if ($userRoleID == ROLE_MANAGER || $userRoleID == ROLE_ADMIN|| $isViewSet==true) {
            $clientId = $this->session->userdata('client_id');
            $data['arrKols'] = $this->coaching->getAllKols();
            //$data['arrClientUsers'] = $this->Client_User->getUsers($clientId);
            $managerId = $this->session->userdata('user_id');
            
            /**
             * Check if logged in manager is aligned to field group
             * 
             */
            $result=$this->customer_engagement->groupAlignmentCheck($managerId);
            if($result)
                $all=true;
            else
                $all=false;
            
            $data['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager($managerId,$all);
            
             $userIds=array();
            foreach ( $data['arrClientUsers'] as $key => $row) {
                        $userIds[]=$row['id'];
            }
            if (!in_array( $interactionDetails["employee_id"], $userIds) && count($interactionDetails)>0) {
             $userName=$this->common_helpers->getUserName($interactionDetails["employee_id"]);
             $details=explode(" ",$userName);
             
              $data['arrClientUsers'][]=array("first_name"=>$details[0],"last_name"=>$details[2],"id"=>$interactionDetails["employee_id"]);
               
            }
            $data['arrSpecialties'] = $this->coaching->getAllAreas();
            $data['arrEngagement'] = $this->coaching->getAllEngagement();
            $data['arrQuestions'] = $this->customer_engagement->getAllEngagementQuestions($data['interactionType']);


            //check is coaching entry present for user
            if ($reloadFlag == 1) {
                $data['reloadFlag'] = 1;
            }
            if ($userId != '' && $userId != 0) {
                $latestCoachingId = $this->coaching->getLatestCoachingIdByUser($userId);
                if ($latestCoachingId != 0) {
                    $data['coachingDetails'] = $this->coaching->editCoaching($latestCoachingId);
                    unset($data['coachingDetails'][0]['id']);
                    $data['contentPage'] = 'customer_engagements/add_form';
                    $this->load->view('layouts/client_view', $data);
                } else {
                    $data['contentPage'] = 'customer_engagements/add_form';
                    if(IS_IPAD_REQUEST)
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
            else
        $this->load->view('layouts/client_view', $data);
                }
            } else {

                /**
                 * Perform edit
                 */
                if ($engageMentId != '') {
                  
                    $data['coachingDetails'] = $this->customer_engagement->editCoaching($engageMentId, $interactionType);
                     
                     if (!in_array( $data['coachingDetails']['basic'][0]['user_id'], $userIds) ) {
                    $userName=$this->common_helpers->getUserName($data['coachingDetails']['basic'][0]['user_id']);
                    $details=explode(" ",$userName);

                     $data['arrClientUsers'][]=array("first_name"=>$details[0],"last_name"=>$details[1],"id"=>$data['coachingDetails']['basic'][0]['user_id']);

                   }
                    $data['evaluatedBy'] = $this->common_helpers->getUserName($data['coachingDetails']['basic'][0]['created_by']);
                    $data['evaluatedOn'] = sql_date_to_app_date($data['coachingDetails']['basic'][0]['created_on']);

                    $data['engagementId'] = $engageMentId;
                }

                if ($isPdfSet == "true") {

                    $this->export_to_pdf($data);
                    exit;
                }

                if ($isViewSet != "true")
                    $data['contentPage'] = 'customer_engagements/add_form';
                else
                    $data['contentPage'] = 'customer_engagements/view_form';
                if(IS_IPAD_REQUEST)
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
            else
        $this->load->view('layouts/client_view', $data);
            }
            /* $formData = $_POST;
              $formData = json_encode($formData);
              $arrLogDetails = array(
              'type' => LOG_ADD,
              'description' => 'Add Customer Engagement',
              'status' => 'success',
              'transaction_id' => '',
              'transaction_table_id' => '',
              'transaction_name' => "add customer engagements",
              'form_data' => $formData
              );
              $this->config->set_item('log_details', $arrLogDetails);
              log_user_activity($arrLogDetails, true); */
        } else {
            $this->list_engagements();
        }
    }

    function export_to_pdf($data) {
        $content = $this->load->view('customer_engagements/pdf_export', $data, TRUE);

        ini_set('memory_limit', "800M");
        $this->load->plugin('export_pdf');
        $filename = 'Customer Engagement Form';
        pdf_create($content, $filename);
    }

    function get_user_team($userId = 0) {
        $arrData = array();
        $arrData['team_name'] = $this->common_helpers->getUserTeamName($userId);
        echo json_encode($arrData);
    }

//    function view($engageMentId = '', $interactionType = '') {
//        $managerId = $this->session->userdata('user_id');
//        $data['arrClientUsers'] = $this->Client_User->getAlignedUsersToManager($managerId);
//        $data['arrSpecialties'] = $this->coaching->getAllAreas();
//        $data['arrEngagement'] = $this->coaching->getAllEngagement();
//        $data['arrQuestions'] = $this->customer_engagement->getAllEngagementQuestions($interactionType);
//        $data['coachingDetails'] = $this->customer_engagement->editCoaching($engageMentId, $interactionType);
//        $data['interactionType']=$interactionType;
//        $data['contentPage'] = 'customer_engagements/view_form';
//        $this->load->view('layouts/client_view', $data);
//    }

    function save() {
        $editId = $this->input->post('engId');
        $arrData['created_by'] = $this->loggedUserId;
        $arrData['modified_by'] = $this->loggedUserId;
        $date = $this->input->post('date');
        list($month, $day, $year) = split('[/.-]', $date);
        $arrData['date'] = $year . "-" . $month . "-" . $day;
        $arrData['interaction_type'] = $this->input->post('interaction_type');
        $arrData['comment'] = $this->input->post('comment');
        $arrData['user_id'] = $this->input->post('usernames');
        $arrData['therapeutic_area'] = $this->input->post('specialty');
        $arrData['no_of_kols'] = $this->input->post('no_of_hcps');
        $arrData['presentation_topic'] = $this->input->post('presentation_topic');
        $orgId = $this->input->post('org');
        if (empty($orgId))
            $arrData['group_name'] = $this->input->post('group_name');
        else
            $arrData['org_id'] = $orgId;

        $arrData['status'] = $this->input->post('status');
        $kolIds = $this->input->post('kol');
        $arrData['generic_id'] = $this->common_helpers->getGenericId("Customer Engagement Form");
        if ($editId != '')
            $this->customer_engagement->deleteEngagement($editId);
        $engagementId = $this->customer_engagement->saveEngagement($arrData);
        $arrTopics = $this->input->post('topics');
        if (sizeof($arrTopics) > 0) {
            $arrTopicData = array();
            foreach ($arrTopics as $questionId => $value) {
                $arrTopicData[] = array('customer_engagement_id' => $engagementId,
                    'customer_engagement_question_id' => $questionId,
                    'customer_engagement_value' => $value,
                    'created_by' => $arrData['created_by'],
                    'modified_by' => $arrData['modified_by']
                );
            }
            $this->customer_engagement->insert_batch('customer_engagement_responses', $arrTopicData);
        }
        if ($arrData['interaction_type'] == 1 && sizeof($kolIds) > 0) {
            $arrKOLData = array();
            foreach ($kolIds as $key => $koldId) {
                $arrKOLData[] = array('customer_engagement_id' => $engagementId,
                    'kol_id' => $koldId,
                    'created_by' => $arrData['created_by'],
                    'modified_by' => $arrData['modified_by']
                );
            }
            $this->customer_engagement->insert_batch('customer_engagement_kols', $arrKOLData);
        }
        $interactionTypeValue = array_keys($this->interactonType, $arrData['interaction_type']);
        $orgName=$this->customer_engagement->getOrgs($orgId);
       
        if($arrData['interaction_type']==1)
            $type="one";
        else
            $type="group";
        $result = $this->coaching->getEmailId($arrData['user_id']);
        $evaluator = $this->session->userdata("user_full_name");
        $kolNames = $this->customer_engagement->kolNameById($engagementId);
        if($arrData['interaction_type']==1){
        $content = 'Hi  ' . $result['first_name'] . " " . $result["last_name"] . ', <br/><br/>
 
This is an alert email to inform you that ' . $evaluator . '  has completed the evaluation of the Customer Engagement 1:1 during the interaction with ' . $kolNames . '. <br/> You can view the evaluation by clicking on the below URL. <br/>
 
<a href=" '. base_url() . 'customer_engagements/add/'.$type.'/0/0/'.$engagementId.'/true" />View</a> <br/>
 
Note: This is an auto generated message do not reply to this message. If you wish to report an issue, please write to support@aissel.com.';
        }
        else{
             $content = 'Hi  ' . $result['first_name'] . " " . $result["last_name"] . ', <br/><br/>
 
This is an alert email to inform you that ' . $evaluator . '  has completed the evaluation of the Customer Engagement Group during the interaction with organization ' .  $orgName[1] .''. $arrData['group_name'].  '. <br/> You can view the evaluation by clicking on the below URL. <br/>
 
<a href=" '. base_url() . 'customer_engagements/add/'.$type.'/0/0/'.$engagementId.'/true" />View</a> <br/>
 
Note: This is an auto generated message do not reply to this message. If you wish to report an issue, please write to support@aissel.com.';
        }
        if($arrData['interaction_type']==1)
        $sub = 'Customer Engagement Evaluation Alert : ' . $kolNames . '';
    else {
        $sub = 'Customer Engagement Evaluation Alert : ' . $orgName[1] .''. $arrData['group_name']. '';
    }

    
        $this->send_mail($sub, $content, $result["email"]);
        if (IS_IPAD_REQUEST)
        	redirect(IPAD_URL_SEGMENT.'/customer_engagements/list_engagements/' . $interactionTypeValue[0]);
        else
        	redirect('customer_engagements/list_engagements/' . $interactionTypeValue[0]);
    }

    function list_engagements($interactionType = '') {

        $data['interaction_type'] = $interactionType;
        $data['coaching_add'] = $this->common_helpers->isActionAllowed('coaching', 'add', $data);
        $data['contentPage'] = 'customer_engagements/list_engagements';
         if(IS_IPAD_REQUEST)
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
            else
        $this->load->view('layouts/client_view', $data);
    }

    function list_engagements_grid($interactionType = '') {

        $page = $_POST['page'];
        $limit = $_POST['rows']; // get how many rows we want to have into the grid
        $sidx = $_POST['sidx']; // get index row - i.e. user click to sort
        $sord = $_POST['sord']; // get the direction
        $start = $limit * ($page - 1); // do not put $limit*($page - 1) 
        $filterData = $_REQUEST['filters'];
        $gridPageParam = array("page" => $page, "limit" => $limit, "sidx" => $sidx, "start" => $start, "sord" => $sord);
        $interactionType = $this->interactonType[$interactionType];
        $arrCoachingResult = $this->customer_engagement->listEngagements(NULL, $filterData, $gridPageParam, false, $interactionType);
        $count = $this->customer_engagement->listEngagements(NULL, $filterData, $gridPageParam, true, $interactionType);
        foreach ($arrCoachingResult as $row) {
            $row['eAllowed'] = $this->common_helpers->isActionAllowed('coaching', 'edit', $row);
            $row['dAllowed'] = $this->common_helpers->isActionAllowed('coaching', 'delete', $row);
             $row['evaluatedBy'] = $this->common_helpers->getUserName($row['created_by']);
            $arrCoaching[] = $row;
        }
        $count = $count[0]['count'];
        //$count = sizeof($arrCoaching);

        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCoaching;
        echo json_encode($data);
    }

    function export_coaching_details($interactionType) {
        if ($interactionType == '')
            $interactionType = $this->input->post('type');
        
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $fileName = "Customer_Engagement_Form";
        $filters = $this->input->post('grid_filter');

        $arrFilters = stripslashes($filters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');




        $arrCoachings = array();
        if ($interactionType == "one") {
            $fileName = "Customer_Engagement_Form_1_1";
            $arrCoachings[0] = array('Id ', 'MSL/MML Name', 'Therapeutic Area', 'Engagement Status', 'Engagement Date','Recorded Date', 'KTL Name(s)', 'Evaluated By');
        } else {

            $fileName = "Customer_Engagement_Group";
            $arrCoachings[0] = array('Id ', 'MSL/MML Name', 'Therapeutic Area', 'No. of #HCP', 'Presentation Topic', 'Group Name','Engagement Date', 'Recorded Date',  'Evaluated By');
        }
        $coachingIds = $this->input->post('coaching_ids');

        $arrCoachingsIds = explode(',', $coachingIds);


        if ($arrCoachingsResults = $this->customer_engagement->exportCoaching($arrCoachingsIds, $arrFilters, $interactionType,$this->input->post('sd'),$this->input->post('ed'))) {
           
            if ($interactionType != "one") {
                foreach ($arrCoachingsResults as $arrCoachingsResult) {
                    $arrCoaching[0] = $arrCoachingsResult['generic_id'];
                    $arrCoaching[1] = $arrCoachingsResult['username'];
                    $arrCoaching[2] = $arrCoachingsResult['specialty'];
                    $arrCoaching[3] = $arrCoachingsResult['no_of_kols'];
                    $arrCoaching[4] = $arrCoachingsResult['presentation_topic'];
                    $arrCoaching[5] = $arrCoachingsResult['hco'];
                    $arrCoaching[6] = $arrCoachingsResult['date'];
                   $arrCoaching[7] = $arrCoachingsResult['created_on'];
                    $arrCoaching[8] = $arrCoachingsResult['evaluated_by'];
                    $arrCoachings[] = $arrCoaching;
                }
            } else {
                foreach ($arrCoachingsResults as $arrCoachingsResult) {
                    $arrCoaching[0] = $arrCoachingsResult['generic_id'];
                    $arrCoaching[1] = $arrCoachingsResult['username'];
                    $arrCoaching[2] = $arrCoachingsResult['specialty'];
                    $arrCoaching[3] = $arrCoachingsResult['status'];
                    $arrCoaching[4] = $arrCoachingsResult['date'];
                      $arrCoaching[5] = $arrCoachingsResult['created_on'];
                    $arrCoaching[6] = preg_replace('/<\/?a[^>]*>/', '', $arrCoachingsResult['kol_id']);
                    $arrCoaching[7] = $arrCoachingsResult['evaluated_by'];
                    

                    $arrCoachings[] = $arrCoaching;
                }
            }
        }
       
        //pr($arrInteractions);
        $this->load->plugin('phpxls/writer');

        if (IS_IPAD_REQUEST) {

            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $workbook = new Spreadsheet_Excel_Writer($path);
        } else {
            $workbook = new Spreadsheet_Excel_Writer();
        }

        $format_und = & $workbook->addFormat();
        $format_und->setBottom(2); //thick
        $format_und->setBold();
        $format_und->setColor('black');
        $format_und->setFontFamily('Calibri');
        $format_und->setAlign('centre');
        $format_und->setSize(12);

        $format_reg = & $workbook->addFormat();
        //	$format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);

        $excelFilters = $this->input->post('filters');
        $filters = array();
        if ($excelFilters != '')
            $arrFilters = explode(",", $excelFilters);
        $filterHeaders[0] = 'Filter Name';
        $filterHeaders[1] = 'Filter Value';
        $filters[] = $filterHeaders;
        foreach ($arrFilters as $filter) {
            if ($filter != '') {
                $filterRow = array();
                $filterRowElements = explode(":", $filter);
                $filterName = trim($filterRowElements[0]);
                $filterRow[0] = '';
                $filterNameElements = explode("_", $filterName);
                foreach ($filterNameElements as $value) {
                    $filterRow[0] .= ucfirst($value) . " ";
                }
                $filterRow[1] = trim($filterRowElements[1]);
                $filters[] = $filterRow;
            }
        }

        $arr = array(
            'Coaching Details' => $arrCoachings,
            'Filters' => $filters
        );

        foreach ($arr as $wbname => $rows) {

            $rowcount = count($rows);
            $colcount = count($rows[0]);

            $worksheet = & $workbook->addWorksheet($wbname);
            //Setting the column width for 'COMPANY OVERVIEW' Sheet
            if ($wbname == 'Coaching Details') {
                $worksheet->setColumn(0, 0, 40); //setColumn(startcol,endcol,float)
                $worksheet->setColumn(1, 1, 40.00);
                $worksheet->setColumn(2, 2, 20.00);
                $worksheet->setColumn(3, 3, 25.00);
                $worksheet->setColumn(4, 4, 25.00);
                $worksheet->setColumn(5, 5, 30.00);
            }
            if ($wbname == 'Filters') {
                $worksheet->setColumn(0, 0, 25);
                $worksheet->setColumn(1, 1, 25);
            }

            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;

                    if ($j == 0) {
                        $fmt = & $format_und;
                    }
                    if (isset($rows[$j][$i])) {
                        $data = $rows[$j][$i];
                        $worksheet->write($j, $i, $data, $fmt);
                    }
                }
            }
        }



        //if($kolId != null){
        //	$kolDetails = $this->kol->getKolName($kolId);
        //	$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
        //	$fileName = $userName."_".$kolName."_interactions";
        //}
        //for downloading the file

        if (IS_IPAD_REQUEST) {
            $workbook->close();
            return $path;
        } else {
            $workbook->send($fileName . '.xls');
        }
        $workbook->close();
    }

    function is_coaching_exist_for_user($userId, $interaction_type) {
        $latestCoachingId = $this->customer_engagement->getLatestCoachingIdByUser($userId, $interaction_type);
        $data['coaching_id'] = $latestCoachingId;
        echo json_encode($data);
    }

    function send_email_for_export() {
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
//    error_reporting(E_ALL);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        // $this->email->to("shrutip@aissel.com");
        $loggedInUserName = $this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of Customer Engagement report data from '.PRODUCT_NAME;
        $loggedInUserEmail = $this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $interactionType = $this->input->post('type');
        if ($interactionType == "one")
            $this->email->subject(PRODUCT_NAME.":Customer Engagement 1:1");
        else
            $this->email->subject(PRODUCT_NAME.":Customer Engagement Group");

        // $this->email->message("hjkh");
        $path = $this->export_coaching_details();

        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
            link($path);
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email Sent',
                'status' => 'success',
                'transaction_id' => '',
                'transaction_table_id' => CUSTOMER_ENGAGEMENTS,
                'transaction_name' => "Email",
                'module' => 'send_email_for_export_compliance',
                'parent_object_id' => '',
                'user_id' => $loggedInUserName,
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);

            log_user_activity($arrLogDetails, true);
        } else {
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email Sent',
                'status' => 'success',
                'transaction_id' => '',
                'transaction_table_id' => CUSTOMER_ENGAGEMENTS,
                'transaction_name' => "Email",
                'module' => 'send_email_for_export_compliance',
                'parent_object_id' => '',
                'user_id' => $loggedInUserName,
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);

            log_user_activity($arrLogDetails, true);
            $emailData['status'] = 'Mail not sent';
        }
//echo $this->email->print_debugger();
        echo $emailData['status'];
        // return $emailData;
    }

}
