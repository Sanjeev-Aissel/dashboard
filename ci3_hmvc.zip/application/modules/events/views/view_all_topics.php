<style>
#viewAllTopicsContainer select{
	width:275px;
}
#topicsHolder select{
	height: 75px;
}
</style>
<script type="text/javascript">
	function loadTopics(specialtyId){
		var specialtyId=$("#specialtyHolder select").val();
		$("#menu2 li a").each(function(){
			if($(this).hasClass('selectedTab')){
				$(this).removeClass('selectedTab')
			}
		});
		$("#topic_"+specialtyId+" a").addClass('selectedTab');
		$.ajax({
			type: "post",
			dataType:"json",
			url: '<?php echo base_url();?>events/events/get_topics_by_specialty/'+specialtyId,
			success: function(returnData){
				var selectOptions="";
				$.each(returnData,function(key,value){
					selectOptions+="<option value='"+key+"'>"+value+"</option>";
				});
				if(selectOptions=="")
					selectOptions="<option value='0'> No Topics Found</option>";				
				$("#topicsHolder select").html(selectOptions);
			}
		});
	}
	function showSelectedTopic(){
		var topicId=$("#topicsHolder select").val();
		var topicName=$("#topicsHolder select option:selected").text();
		if(topicId!=0)
			addSelectedTopicToList(topicId,topicName);
		$("#eventTopics").dialog("close");
	}
</script>
<div id="viewAllTopicsContainer">
	<h5 class="align_center">Topic(s) from Specialty</h5>
	 <table class="table no_border">
	 	<tr>
	 		<td class="align_right">Select Specialty:</td>
	 		<td><div id="specialtyHolder">
	 			<select onchange="loadTopics();">
					<option>Select Specialty</option>
					<?php  foreach($arrSpecialties as $key => $value){?>
						<option value="<?php echo $key;?>"> <?php echo $value;?></option>
					<?php }?>
				</select>
				</div>
	 		</td>
	 	</tr>
	 	<tr>
	 		<td class="align_right" style="vertical-align: top;">Select Topic(s):</td>
	 		<td>
 				<div id="topicsHolder">
					<select multiple="multiple"></select>
				</div>
	 		</td>
	 	</tr>
	 	<tr>
	 		<td colspan="2" class="align_center">
	 			<input type="button" class="btn custom-btn" value="Ok" onclick="showSelectedTopic();"/>
	 		</td>
	 	</tr>
	 </table>
</div>
