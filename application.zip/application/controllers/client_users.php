<?php
/**
 * Controller for Client Users operations
 * @author Vinayak Malladad
 * @since 1.5
 * @package application.controllers	
 * @created on 1-03-2011
 * 
 */

class Client_Users extends controller{
	
	function Client_Users(){
		parent::Controller();
		$this->load->model('Client_User');
		$this->load->model('Login_model');
		$this->load->library('SimpleLoginSecure');
		$this->load->model('common_helpers');
		$this->load->model('country_helper');
		$this->load->model('media_parser');
	}

	/*
	 *  Display 'Client users ' view page
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function add_client_users(){
		$this->load->view('client_users/add_client_users');
	}

	/*
	 *  Display 'Client ' view page
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function add_client(){
		$data['arrClients'] = null;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add Client Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add Client Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage'] 	=	'client_users/add_client';
		$this->load->view('layouts/analyst_view',$data);
		
	}

	/*
	 *  Saving Client Deatils 
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function save_client(){
		$arrClient['name']				=	$this->input->post('client_name');
		$arrClient['notes']				=	$this->input->post('client_notes');
		$arrClient['support_email_id']	=	$this->input->post('client_email');
		$arrClient['created_by']		=	$this->session->userdata('user_id');
		$arrClient['created_on']		=	date('Y-m-d H:i:s');
		
		//Check if client logo is uploaded and proceed
		if(!empty($_FILES['client_logo']['name'])) {
			$logoUploadPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/client_logos/logos";
			$config['upload_path'] = $logoUploadPath;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('client_logo')){
				echo 'fail';
			}else{
				$arrLogoUploadData = $this->upload->data();
				$logoName = $arrLogoUploadData['file_name'];
				$arrClient['client_logo'] = $logoName;
			}
		}
		//Check if client favicon is uploaded and proceed
		if(!empty($_FILES['client_favicon']['name'])) {
			$faviconUploadPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/client_logos/favicons";
			$config['upload_path'] = $faviconUploadPath;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['encrypt_name'] = true;
			//If file upload library is already loaded, then initialise, else load library 
			if(isset($logoName)){
				$this->upload->initialize($config);
			}else{
				$this->load->library('upload', $config);
			}
			if (!$this->upload->do_upload('client_favicon')){
				echo 'fail';
			}else{
				$arrFaviconUploadData = $this->upload->data();
				$faviconName = $arrFaviconUploadData['file_name'];
				$arrClient['client_favicon'] = $faviconName;
			}
		}
		if($lastInsertId = $this->Client_User->saveClient($arrClient)){
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Client Details',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Add Client Details",
					'form_data' => $formData,
					'parent_object_id' => $lastInsertId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			$this->session->set_flashdata('class', 'green');
			$this->session->set_flashdata('feedback', 'Saved SuccessFully');
  		}else{
  			$this->session->set_flashdata('feedback', 'Sorry! Client Name is Already Present in Database');
  			//Add Log activity
  			$formData = $_POST;
  			$formData = json_encode($formData);
  			$arrLogDetails = array(
  					'type' => ADD_RECORD,
  					'description' => 'Sorry! Client Name is Already Present in Database',
  					'status' => STATUS_FAIL,
  					'transaction_id' => $lastInsertId,
  					'transaction_table_id' => CLIENTS,
  					'transaction_name' => "Add Client Details",
  					'form_data' => $formData,
  					'parent_object_id' => $lastInsertId
  			);
  			$this->config->set_item('log_details', $arrLogDetails);
  			log_user_activity(null,true);
  		}
		redirect('client_users/add_client'); 
	}

	/*
	 *  Listing Client Deatils $data['contentPage'] 	=	'client_users/list_clients';
		$this->load->view('layouts/default',$data);
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function list_clients(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();		
		$arrClints = $this->Client_User->getClients();
		$data['arrClients'] = $arrClints;
		//$this->load->view('client_users/list_clients',$data);
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited List Clients Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List Clients Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage'] 	=	'client_users/list_clients';
		$this->load->view('layouts/analyst_view',$data);	
	}
	
	/*
	 *  To dispaly view page to edit Client Deatils 
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
 	*   @param $clientId
	 */	
	function edit_client($clientId){
		$arrClient = array();
		$arrClient=$this->Client_User->editClient($clientId);
		$data['arrClient']=$arrClient;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Edit Client View Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add Client Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage'] 	=	'client_users/add_client';
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/*
	 *  Updating Client Deatils 
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function update_client(){
		
		$arrClient['id']				=	$this->input->post('id');
		$arrClient['name']				=	$this->input->post('client_name');
		$arrClient['notes']				=	$this->input->post('client_notes');
		$arrClient['support_email_id']	=	$this->input->post('client_email');
		$arrClient['modified_by']		=	$this->session->userdata('user_id');
		$arrClient['modified_on']		=	date('Y-m-d H:i:s');
		
		//Check if client logo is uploaded and proceed
		if(!empty($_FILES['client_logo']['name'])) {
			$logoUploadPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/client_logos/logos/";
			$config['upload_path'] = $logoUploadPath;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('client_logo')){
				echo 'fail';
			}else{
				$arrLogoUploadData = $this->upload->data();
				$logoName = $arrLogoUploadData['file_name'];
				$arrClient['client_logo'] = $logoName;
				unlink($logoUploadPath.$this->input->post('client_logo_name'));
			}
		}
		//Check if client favicon is uploaded and proceed
		if(!empty($_FILES['client_favicon']['name'])) {
			$faviconUploadPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "images/client_logos/favicons/";
			$config['upload_path'] = $faviconUploadPath;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['encrypt_name'] = true;
			//If file upload library is already loaded, then initialise, else load library
			if(isset($logoName)){
				$this->upload->initialize($config);
			}else{
				$this->load->library('upload', $config);
			}
			if (!$this->upload->do_upload('client_favicon')){
				echo 'fail';
			}else{
				$arrFaviconUploadData = $this->upload->data();
				$faviconName = $arrFaviconUploadData['file_name'];
				$arrClient['client_favicon'] = $faviconName;
				unlink($faviconUploadPath.$this->input->post('client_favicon_name'));
			}
		}
		if($this->Client_User->updateClient($arrClient)){
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Client Details',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $arrClient['id'],
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Update Client Details",
					'form_data' => $formData,
					'parent_object_id' => $arrClient['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			$this->session->set_flashdata('class', 'green');
			$this->session->set_flashdata('feedback', 'Saved SuccessFully');
		}else{
			$this->session->set_flashdata('feedback', 'Sorry! Client Name is Already Present in Database');
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Sorry! Client Name is Already Present in Database',
					'status' => STATUS_FAIL,
					'transaction_id' => $arrClient['id'],
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Update Client Details",
					'form_data' => $formData,
					'parent_object_id' => $arrClient['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
		}
		redirect('client_users/add_client');
	}

	/*
	 *  To delete Client Deatils 
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 *  @param $clientId
	 */	
	function delete_client($clientId){
		$this->Client_User->deleteClient($clientId);
      	//redirect('kols/list_kols#ui-tabs-2');
	  }
	
	/*
	 *  Display 'client User ' view page
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
  	function add_user(){
  		$data['arrCountry']=$this->country_helper->listCountries();
  		$data['arrUsers']=null;
		$arrClints =$this->Client_User->getClients();
		$data['arrClients']=$arrClints;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add User Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add User"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('client_users/add_user',$data);
	}

	/*
	 *  Saving Client user detail
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function save_user(){
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$arrUser['client_id']		=	$this->input->post('client_id');
		$arrUser['user_name']		=	$this->input->post('user_name');
		$arrUser['manager_id']		=	$this->input->post('manager_id');
		$arrUser['territory']		=	$this->input->post('territory');
		$arrUser['first_name']		=	$this->input->post('first_name');
		$arrUser['last_name']		=	$this->input->post('last_name');
		$arrUser['title']		    =	$this->input->post('title');
		$arrUser['company_name']	=	$this->input->post('company_name');
		$arrUser['country']		    =	$this->input->post('country');
		$arrUser['password']		=	$hasher->HashPassword($this->input->post('password'));
		$arrUser['email']			=	$this->input->post('email');
		$arrUser['contact']			=	$this->input->post('contact');
		$arrUser['created_by']		=	$this->session->userdata('user_id');
		$arrUser['user_role_id']	=	$this->input->post('user_role_id');
		$arrUser['created_on']		=	date('Y-m-d H:i:s');
		$arrUser['user_from']		=	1; //indicates that users is from iProfile
		if(INTERNAL_CLIENT_ID == $arrUser['client_id']){
			$arrUser['is_analyst'] =1;
		}
		if($arrUser['manager_id'] == ''){
			$arrUser['manager_id']	= null;
		}
		if($lastInsertId= $this->Client_User->saveUser($arrUser)){
			$data['saved'] =true;
			$data['lastInsertId']   =$lastInsertId;
			$clientId = $arrUser['client_id'];
                        
			$arrUser['client_id']=$this->Client_User->getClientName($arrUser['client_id']);
			$data['arrUser']=$arrUser;
			
			//if user manager_id is blank then update himself a manager
			if($arrUser['manager_id'] == ''){
				$arrData = array();
				$arrData['id'] = $lastInsertId;
				$arrData['manager_id'] = $lastInsertId;
				$this->Client_User->updateUser($arrData);
			}
			
			$data['msg']  = "Saved Successfully";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Client User Details',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Add Client User",
					'form_data' => $formData,
					'parent_object_id' => $lastInsertId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
                        $this->media_parser->saveSettings("no",$lastInsertId);
			//$this->update->insertUpdateEntry(USER_ADD, $lastInsertId, MODULE_CLIENT_USERS, $clientId);
		}else{
			$data['saved'] =false;
			$data['msg']  = "sorry! Data is Already Present in Database";			
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => $data['msg'],
					'status' => STATUS_FAIL,
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Add Client User",
					'form_data' => $formData,
					'parent_object_id' => $lastInsertId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
		}
		echo json_encode($data);
	}

	/*
	 *  Listing Client user detail
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function list_users(){
		/*
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();		
		//$arrUsers = $this->Client_User->getUsers();
		//$data['arrUsers']=$arrUsers;
		$data['arrClients']=$this->Client_User->getClients();
		//$this->load->view('client_users/list_users',$data);
		//$data['contentPage'] 	=	'client_users/list_users';
		$data['contentPage'] 	=	'client_users/list_users_grid';
		$this->load->view('layouts/analyst_view',$data);
		*/
		//Analyst App to be accessed by only Aissel users. 
        $this->common_helpers->checkUsers();        
        $arrUsers = $this->Client_User->getUsers();
        $data['arrUsers']=$arrUsers;
        $data['arrClients']=$this->Client_User->getClients();
        //$this->load->view('client_users/list_users',$data);
        //Add Log activity
        $arrLogDetails = array(
        		'type' => LIST_RECORD,
        		'description' => "Visited List Client Users Page",
        		'status' => STATUS_SUCCESS,
        		'transaction_name' => "View List Users"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $data['contentPage']     =    'client_users/list_users';
        $this->load->view('layouts/analyst_view',$data);
	}

	/*
	 *  To display view page to edit user details
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 *   @param $userId
	 */	
	function edit_user($userId){ 
            
        $client_id =  $this->session->userdata('client_id');
		$data['arrCountry']=$this->country_helper->listCountries();
		$arrUsers = array();
		$arrUsers=$this->Client_User->editUser($userId);
		$arrClints =$this->Client_User->getClients($client_id);
		$arrManagers = $this->Client_User->getClientManagers($arrUsers['client_id']);
		$data['arrClients']=$arrClints;
		$data['arrUsers']=$arrUsers;
		$data['arrManagers']=$arrManagers;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Edit User Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Edit User"
		);
		$this->config->set_item('log_details', $arrLogDetails);
                $this->load->view('client_users/add_user',$data);	
                    
		
	}

	/*
	 *  Updating Client user detail
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function update_user(){
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$arrUser['id']				=	$this->input->post('id');
		$arrUser['client_id']		=	$this->input->post('client_id');
		$arrUser['user_name']		=	$this->input->post('user_name');
		$arrUser['manager_id']		=	$this->input->post('manager_id');
		$arrUser['territory']		=	$this->input->post('territory');
		$arrUser['first_name']		=	$this->input->post('first_name');
		$arrUser['last_name']		=	$this->input->post('last_name');
		$arrUser['title']		    =	$this->input->post('title');
		$arrUser['company_name']	=	$this->input->post('company_name');
		$arrUser['country']		    =	$this->input->post('country');
        if($this->session->userdata('client_id')==INTERNAL_CLIENT_ID)
			$arrUser['password']	=	$hasher->HashPassword($this->input->post('password'));
		$arrUser['email']			=	$this->input->post('email');
		$arrUser['contact']			=	$this->input->post('contact');
		$arrUser['modified_by']     =   $this->session->userdata('user_id');
		$arrUser['modified_on']		=	date('Y-m-d H:i:s');
		$arrUser['user_role_id']	=	$this->input->post('user_role_id');
		
		//if user manager_id is blank then update himself a manager
		if($arrUser['manager_id'] == ''){
			$arrUser['manager_id'] =$arrUser['id'];
		}
		
		if($this->Client_User->updateUser($arrUser)){
			$data['saved'] =true;
			$data['lastInsertId']   =$arrUser['id'];
			$clientId = $arrUser['client_id'];
			$arrUser['client_id']=$this->Client_User->getClientName($arrUser['client_id']);
			$data['arrUser']=$arrUser;
			$data['msg']  = "Updated Successfully";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Client User Details',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $arrUser['id'],
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Update Client User",
					'form_data' => $formData,
					'parent_object_id' => $arrUser['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			//$this->update->insertUpdateEntry(USER_UPDATE, $arrUser['id'], MODULE_CLIENT_USERS, $clientId);
		}else{
			$data['saved'] =false;
			$data['msg']  = "sorry! Data is Already Present in Database";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => $data['msg'],
					'status' => STATUS_FAIL,
					'transaction_id' => $arrUser['id'],
					'transaction_table_id' => CLIENTS,
					'transaction_name' => "Update Client User",
					'form_data' => $formData,
					'parent_object_id' => $arrUser['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
		}
		echo json_encode($data);
	}		

	function list1(){
		redirect('kols/list_kols#ui-tabs-3');
	}
	/*
	 *  To delete Client user detail
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 *  @param $userId
	 */	
	function delete_user($userId){
		$this->Client_User->deleteUser($userId);
		//$this->update->insertUpdateEntry(USER_DELETE, $userId, MODULE_CLIENT_USERS);
      	//redirect('kols/list_kols#ui-tabs-3');
	  }
	
	/*
	 *  To Show Clients Drop Down
	 *  @author Vinayak Malladad
	 *  @since 1.5.1
	 *  @created on 12-2-2011
	 *  @param 
	 */	
	function add_associated_kols(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();		
		$data['arrClients'] = $this->Client_User->getClients();
		//$this->load->view('client_users/add_associated_kol',$data);
		$data['contentPage'] 	=	'client_users/add_associated_kol';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add Associate Kols Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add Associate Kols Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);	
	}	  

	/*
	 * To show all Kols in drop down
	 *  @author Vinayak Malladad
	 *  @since 1.5.1
	 *  @created on 12-2-2011
	 * 
	 */
	function list_multiple_kols($id){
		$arrClientsKols = $this->Client_User->getKolsByClient($id);
		$data['arrClientsKols'] = $arrClientsKols;
		
		$data['arrKol'] =$this->Client_User->getAllClientsKols($id);
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List Multiple Kols Page",
				'status' => STATUS_SUCCESS,
				'client_id' => $id,
				'transaction_name' => "View List Multiple Kols Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['client_id'] = $id;
		$this->load->view('client_users/list_multiple_kols',$data);
	}

	/*
	 * To save all associated Kols of particular Client
	 *  @author Vinayak Malladad
	 *  @since 1.5.1
	 *  @created on 15-2-2011
	 * 
	 */
	function save_clients_kols(){
		$data =array();
		$arrKols = $this->input->post('selected_kols');
		$clientId = $this->input->post('client_id');
		$arrClientsKols = $this->Client_User->getAvilableKols($clientId);
		
		//Returns an array containing all the entries from array1 that are not present in any of the other arrays. 
		$deleteArrKol = array_diff($arrClientsKols,$arrKols);
		
		//Returns an array containing all the entries from array1 that are not present in any of the other arrays. 
		$addArrKol   =  array_diff($arrKols,$arrClientsKols);
		
		if($data =$this->Client_User->saveClientsKols($deleteArrKol,$addArrKol,$clientId)){
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Associated Kols of particular Client',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $clientId,
					'transaction_table_id' => CLIENTS_KOLS,
					'transaction_name' => 'Add Associated Kols of particular Client',
					'form_data' => $formData,
					'parent_object_id' =>  $clientId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			echo json_encode($data);
		}
	}		
	
	/*
	 * To show view page for 'User Registration'
	 *  @author Vinayak Malladad
	 *  @since 3.2
	 *  @created on 8-10-2011
	 * 
	 */
	function user_form($arrUserDetails=''){
		//Cache the login page for next 720 minutes i.e 1 day
		$this->output->cache(720);
		$data['arrUserDetails'] = $arrUserDetails;
		$data['arrCountry']=$this->country_helper->listCountries();
		$this->load->view('client_users/user_form',$data);
	}
	
	
	/*
	 * To save the user details
	 *  @author Vinayak Malladad
	 *  @since 3.2
	 *  @created on 8-10-2011
	 * 
	 */
	function save_user_registration_details(){
	
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);	
		$arrUserDetails['first_name']			= trim($this->input->post('first_name'));
		$arrUserDetails['last_name']			= trim($this->input->post('last_name'));
		$arrUserDetails['title']		 		= trim($this->input->post('title'));
		$arrUserDetails['phone'] 				= trim($this->input->post('phone'));
		$arrUserDetails['company_name']         = trim($this->input->post('company_name'));
		$arrUserDetails['email'] 				= trim($this->input->post('email'));
		$arrUserDetails['password']				= $hasher->HashPassword($this->input->post('password'));
		$arrUserDetails['country']				= trim($this->input->post('country'));
		$arrUserDetails['user_name']			= trim($this->input->post('user_name'));
		$arrUserDetails['user_role_id']			= ROLE_USER;
		$arrUserDetails['client_id']            = GUEST_CLIENT_ID;
		
		if($this->Client_User->saveUserRegistrationDetails($arrUserDetails)){
			
			$this->load->view('client_users/show_success_message');
		}else{
			$arrUserDetails['error'] ="User Name is already exists. Please provide Different User Name.";
			$this->user_form($arrUserDetails);
		}
		
	}
	
	/*
	 *  To show the Privacy and Terms and Service page
	 *  @author Vinayak Malladad
	 *  @since 3.2
	 *  @created on 8-10-2011
	 *  @param $pageType-Privacy or Terms and Service page
	 */
	function show_terms_page($pageType){
		//Cache the login page for next 720 minutes i.e 1 day
		$this->output->cache(720);
		$data['pageType'] = $pageType;
		$this->load->view('client_users/show_privacy_page',$data);
	}
	
	function privacy_policy($language = null){
	    $data['lang'] = $language;
	    $data['languages'] = $this->Client_User->getLanguages();
	    $this->load->view('privacy_policy',$data);
	}
	
	function change_language($language = null){
	    $this->session->set_userdata('lang',$language);
	    redirect('/client_users/privacy_policy/'.$language, 'refresh');
	}
	
	function change_password(){
		$this->load->view('client_users/change_password');
	}
	
	function update_password(){
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);	
		$oldPass = $this->input->post('old_password');
		$userId = $this->session->userdata('user_id');
		$arrUserDetail = $this->Client_User->getUserdetail($userId);
		
		if(!$hasher->CheckPassword($oldPass, $arrUserDetail['password'])){
			$data['status'] =false;
			$data['mes'] ="Entered Current Password is wrong";
			
		}else{
			$newPass = $this->input->post('new_password');
			$arrUserDetail['password'] =  $hasher->HashPassword($newPass);
			$arrUserDetail['id']       =  $userId;
			if($this->Client_User->updateUser($arrUserDetail)){
				$data['mes'] ="Password changed successfully";
				$data['status'] =true;
			}else{
				$data['status'] ="Not changed";
			}
		}
		
		echo json_encode($data);
	}
	
	function validate_current_password(){
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);	
		$oldPass = $this->input->post('old_password');
		$userId = $this->session->userdata('user_id');
		$arrUserDetail = $this->Client_User->getUserdetail($userId);
		if(!$hasher->CheckPassword($oldPass, $arrUserDetail['password'])){
			$data['status'] =false;
			$data['mes'] ="Entered Current Password is wrong";
		}else{
			$data['status'] =true;
		}
		echo json_encode($data);
	}
	
	function get_client_managers($clientId){
		$arrManagers = array();
		$arrManagers = $this->Client_User->getClientManagers($clientId);
		$returnData = "<option value=''>Select</option>";
		foreach ($arrManagers as $id => $name)
			$returnData .= "<option value='".$id."'>".$name."</option>";
			
		echo $returnData;
	}
	
	function change_users_client(){
		$data = array();
		if($this->Client_User->changeUsersClient($_POST)){
			$data["status"] = true;	
		}else{
			$data["status"] = false;
		}
		echo json_encode($data);
	}
	
/*
	 * Lists all Users for analyst application, it's for ajax pagination,search and sort version of jqgrid
	* @author Laxman K
	* @since 05-06-2014
	* @version KOLM CORE v6.0.9
	* @return JSON
	*/
	function list_users_grid(){
		$page		= $_REQUEST['page']; // get the requested page
		$limit 		= $_REQUEST['rows']; // get how many rows we want
		$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST['sord']; // get the direction
		if(!$sidx) $sidx =1;
		//if ($page > $total_pages) $page=$total_pages;
		//$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		//if ($start < 0) $start = 0;
		$filterData=$_REQUEST['filters'];
		$arrFilter=array();
		//error_reporting(E_ALL);
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);		
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];
		}
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
	
		$count	=	$this->Client_User->getUsersList($limit,$start,true,$sidx,$sord,$whereResultArray);
	
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
			
		$arrUserDetailResult = array();
		$data 				= array();
		//		pr($sidx);
		//		pr($whereResultArray);
		if($arrUserDetailResult = $this->Client_User->getUsersList($limit,$start,false,$sidx,$sord,$whereResultArray)){
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrUserDetailResult;
		}
		//echo $this->db->last_query();
		//ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	function update_user_status(){
		$userId = $this->input->post('user_id');
		$status = $this->input->post('status');
		$managerId = $this->input->post('manager_id');		
		echo $this->Client_User->updateUserStatus($userId,$status,$managerId);
		//echo $this->db->last_query();
	}

	function export_users($users){
		$this->load->plugin('phpxls/writer');
		$workbook 										= new Spreadsheet_Excel_Writer();
		// To allow more than 255 charecters.
		$workbook->setVersion(8);
		$format_und 									=& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setRight(1);
		$format_und->setBold();
		$format_und->setHAlign('centre');
		$format_und->setVAlign('vcentre');
		$format_und->setColor('black');
		$format_und->setFontFamily('Arial');
		$format_und->setSize(11);
		$format_reg 									=& $workbook->addFormat();
		$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		$data[0]=array('ID','User Full Name','Login Name','Email ID','Client Name','Company Name','Contact','Status');
		$i=1;
		
		$dataResult	= array();
		//$users		= $this->input->post('user_ids');
		$arrUsers	= explode(',',$users);
		$whereResultArray=array();
		$whereResultArray['user_ids']=$arrUsers;
		if($arrUserDetailResult = $this->Client_User->getUsersList(sizeof($arrUsers),0,false,'','',$whereResultArray)){
			foreach ($arrUserDetailResult as $row){
				$data[$i][]						= $row['id'];
				$data[$i][]						= $row['first_name']." ".$row['last_name'];
				$data[$i][]						= $row['user_name'];
				$data[$i][]						= $row['email'];
				$data[$i][]						= $row['name'];
				$data[$i][]						= $row['company_name'];
				$data[$i][]						= $row['contact'];
				$data[$i][]						= $row['status'];
				$data[$i][]						= $row['resp_first_name'].' '.$row['resp_last_name'];
				$i++;
			}
		}
		$arr 					= array();
		$arr['Users']	= $data;
		
		foreach($arr as $wbname=>$rows){
			$rowcount 									= count($rows);
			$colcount 									= count($rows[0]);
			$worksheet 									=& $workbook->addWorksheet($wbname);
			$worksheet->setColumn(0,0, 5);//setColumn(startcol,endcol,float)
			for( $j=0; $j<$rowcount; $j++ ){
				for($i=0; $i<$colcount;$i++){
					$fmt  								=& $format_reg;
					if ($j==0)
						$fmt 							=& $format_und;
					if (isset($rows[$j][$i])){
						$value							= utf8_decode($rows[$j][$i]);
						$worksheet->write($j, $i, $value, $fmt);
					}
				}
			}
		}		
		// Add log activity
		$arrLogDetails = array (
				'type' => 'Export Script',
				'description' => 'Exporting User details',
				'status' => SUCCESS,
				'file_name' => 'users',
				'transaction_name' => "Exporting User Data",
				'user_id' => $whereResultArray['user_ids']
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		$workbook->send('users.xls');
		$workbook->close();
	}
	
	function list_managers($status,$selectedUsers){
		$arrData['status']	= $status;
		$arrData['selected_users']	= $selectedUsers;
		$arrData['arrManagers']		= $this->Client_User->listManagers($selectedUsers);
		$this->load->view('client_users/swap_users_aligned_to_manager',$arrData);
	}
	
	function generateApiKeyForUsers(){
		// Generate global unique id
		function GUID()
			{
			    if (function_exists('com_create_guid') === true)
			    {
			        return trim(com_create_guid(), '{}');
			    }
			
			    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
			}
		$userArr = array();
		$resArr = $this->db->get("client_users");
		foreach ($resArr->result_array() as $key=>$row){
			$code = GUID();
			$this->db->where('id',$row['id']);
			$this->db->set('api_key',$code);
			$this->db->update('client_users');
		}
		echo "Done.";
	}
	
	function generateSecretKeyForUsers(){
		// Generate global unique id
		function GUID()
			{
			    if (function_exists('com_create_guid') === true)
			    {
			        return trim(com_create_guid(), '{}');
			    }
			
			    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
			}
		$userArr = array();
		$resArr = $this->db->get("client_users");
		foreach ($resArr->result_array() as $key=>$row){
			$code = GUID();
			$this->db->where('id',$row['id']);
			$this->db->set('secret_key',$code);
			$this->db->update('client_users');
		}
		echo "Done.";
	}
	
	function GUID()
		{
		    if (function_exists('com_create_guid') === true)
		    {
		        return trim(com_create_guid(), '{}');
		    }
		
		    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
		}
		
	function createInPoland($userArr){
		$param = array();
		$userArr['is_poland_user'] = 0;
		$userArr['app_key'] = APP_KEY;
		$param['userData'] = json_encode($userArr);
		$retData = $this->myapiconnect->get_api_response(API_URL."api/interfaces/create_new_user",'post',$param);
		$data = json_decode($retData,true);
		if($data['status']){
			return true;
		}else{
			return false;
		}
	}
	
	function deactivate_poland_by_user_id(){
		$retData = array(); 
		if($this->Client_User->deactivatePolandByUserId($this->input->post('userIds'))){
			$retData['status'] = true;
		}else{
			$retData['status'] = false;
		}
		echo json_encode($retData);
	}
	
	function activate_poland_by_user_id(){
		$retData = array(); 
		if($this->Client_User->activatePolandByUserId($this->input->post('userIds'))){
			$retData['status'] = true;
		}else{
			$retData['status'] = false;
		}
		echo json_encode($retData);
	}
	function sync_all_users_to_poland(){
		$allUsers = $this->Client_User->getAllUsers();
		$param = array();
		$param['userData'] = json_encode($allUsers);
		$param['appId'] = APP_KEY;
		$retData = $this->myapiconnect->get_api_response(API_URL."api/interfaces/sync_all_users_to_poland",'post',$param);
		$data = json_decode($retData,true);
		if($data['status']){
			echo "Done.";
		}else{
			echo "There is an error try once again.";
		}
	}
        function getClientUsers($clientId=0){
            if($clientId==0){
                $clientId= $this->session->userdata('client_id');
            }
            $data['arrUsers']	= $this->Client_User->getClientUsers($clientId);
            echo json_encode($data);
        }
        
     function show_message_view(){
     	$this->load->view('client_users/message_view');
     }
     
     function send_demo_mail(){
     	$config['protocol'] = PROTOCOL;
     	$config['smtp_host']= HOST;
     	$config['smtp_port']= PORT;
     	$config['smtp_user']= USER;
     	$config['smtp_pass']= PASS;
     	$config['mailtype']	= 'html';
     	$this->load->library('email', $config);
     	$this->email->set_newline("\r\n");
     	$this->email->initialize($config);
     	$this->email->clear();
     	$this->email->set_newline("\r\n");
     	$this->email->from(USER,'Aissel Support Team');
     	$arrUserDetails['user_name'] = $this->session->userdata('user_name');
     	$arrUserDetails['user_full_name'] = $this->session->userdata('user_full_name');
     	$arrUserDetails['email'] = $this->session->userdata('email');
//      	$arrUserDetails['company_name'] = $this->session->userdata('company_name');
     	$arrEmails = $this->Client_User->getUserEmailIds();
     	//pr($arrEmails);
     	$emailids = implode(',',$arrEmails);
     	//	pr($this->session->userdata);;
     	$this->email->to($emailids);
     	//$this->email->to('vinayakm@aissel.com');
     	$tab = $this->input->post('tabname');
     	$demo = $this->input->post('demo');
     	$arrUserDetails['tab'] = $tab;
     	$arrUserDetails['demo'] = $demo;
     	$data	= array('data'=>$arrUserDetails);
     	$html 	= $this->load->view('client_users/demo_email_content',$data,true);
     	$this->email->message($html);
     
     
     	if($demo=='Yes'){
     		$this->email->subject("Request for a demo");
     	}else{
     		$this->email->subject("No request for a demo");
     	}
     	if($this->email->send()){
     		$emailData['status'] 	= 'Your message has been sent';
     	}else{
     		$emailData['status'] 	= 'Mail not sent';
     	}
     		return $emailData;
     	}
     	/*
     	 *  Listing Client Deatils $data['contentPage'] 	=	'client_users/list_clients';
     	 $this->load->view('layouts/default',$data);
     	 *  @author Vinayak Malladad
     	 *  @since 1.5
     	 *  @created on 28-2-2011
     	 */
     	function activity_chart_client_list(){
     		//Analyst App to be accessed by only Aissel users.
     		$this->common_helpers->checkUsers();
     		$arrClints = $this->Client_User->getClients();
     		$data['arrClients'] = $arrClints;
     		//$this->load->view('client_users/list_clients',$data);
     		$this->load->view('client_users/activity_chart_client_list',$data);
     	}
     	function deactivate_date_change_client_users(){
     		$arrDeactiveteUsers = $this->Client_User->getDeactivatedUsers();
     		if(count($arrDeactiveteUsers) > 0){
     		foreach($arrDeactiveteUsers as $row){
     			$clientUserId = $row['clientUserId'];
     			$createdDate = $row['created_on'];
     			$this->Client_User->updateCreatedDateDeactiveUsers($clientUserId, $createdDate);
     			}
     			echo 'Status Modified Successfully!';	
     		}else{
     			echo 'No Users Available';
     		} 
     	}
     	// block user
     	function block_user() {
     		$id = $this->input->post ( 'user_id' );
     		// pr ( $ids );
     		// exit ();
     		$status = $this->Client_User->blockUser ( $id );  
     		echo json_encode ( $status );
     	}
     	// unblock user
     	function un_block_user() {
     		$id = $this->input->post ( 'user_id' );
     		// pr ( $id );
     		// exit ();
     		$status = $this->Client_User->unBlockUser ( $id );
     		echo json_encode ( $status );
     	}
     	
     	function alertPopCookeSession(){
     	    $this->load->view('client_users/alertPopCooke');
     	}
     	
     	function saveCookeConfirmation(){
     	    $res = $this->Client_User->updateCookeStatus();
     	    $data['status'] = $res;
     	    echo json_encode($data);
     	}
}