<?php
/**
 * File to 'view' kols Social media details
 *
 * @author: Ambarish
 * @created on: 22-12-10
 * @package application.views.kols
 */

?>
	<style type="text/css">
		#contentWrapper.span-23 {
			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
		    background-position: 135px 50%;
		    background-repeat: repeat-y;
	
		}
		
		#mediaLinks a p{
			text-decoration:none;
			text-align:left;
			color: #000099;
			width: 780px;
			word-wrap: break-word;
		}

	#kolSocialMedia > div{
		border: 5px solid #EEEEEE;
	    float: left;
	    margin-bottom: 11px;
	    margin-left: 5px;
	    width: 383px;
	}
	#kolSocialMedia > div > label{
		float:left;
	}
	#kolSocialMedia > div > h5{
		margin-bottom:5px;
		font-size:16px;
	}
	#kolSocialMedia > div > ul{
		border-top: 1px solid #EBEBEB;
	    list-style: none outside none;
	    margin-left: 20px;
    	margin-right: 20px;
	    padding-left: 0;
	    height: 500px;
	    overflow-y: scroll;
	}
	#kolSocialMedia > div > ul li{
		border-bottom: 1px solid #EBEBEB;
		overflow:hidden;
		position: relative;
		min-height: 50px;
		padding-bottom: 32px;
    	padding-top: 7px;
	}
	
	#kolSocialMedia > div > ul li:HOVER{
		background-color:#eeeeee;
	}
	#kolSocialMedia > div > ul li > p{
		margin-bottom:0px;
		overflow: hidden;
	}
	#kolSocialMedia span.human-time{
		bottom: 10px;
	    color: green;
	    float: right;
	    position: absolute;
	    right: 0;
	}
	#latest-facebook-updates li .storylink{
	    display: block;
	    padding-bottom: 5px;
	}
	#latest-facebook-updates li .storylink a{
		color: #3B5998;
		font-size: 11px;
		font-weight: bold;
	}
	#latest-facebook-updates li > div img{
		float: left;
	    margin-right: 5px;
	   	width: 130px;
	   	cursor:pointer;
	}
	#latest-facebook-updates li >div p{
		margin-bottom:0px;
	}
	#kolSocialMedia > div > ul li > div{
		overflow: hidden;
	}
	.additinal-links{
		bottom: 10px;
	    left: 0;
	    position: absolute;
	    width: 100%;
	}
	.sharesIcon {
	   	background-image: url("<?php echo base_url()?>images/fb-shares.png");
	    background-position: -4px -3px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 13px;
	    margin-bottom: -2px;
	    margin-left: 5px;
	    width: 12px;
	}
	.commentsIcon {
	    background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -14px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 16px;
	    width: 16px;
	}
	.likesIcon {
	   	background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -53px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 12px;
	    width: 14px;
	}
	#latest-youtube-updates ul{
		margin-left: 10px !important;
    	margin-right: 10px !important;
	}
	#latest-youtube-updates li{
		margin-bottom: 10px;
    	padding-bottom: 20px !important;
	}
	#fbImageContainer{
		text-align: center;
	}
	#latest-youtube-updates li a{
		font-weight:bold;
	}
	div.mediaIcon {
	    margin-left: 6px;
    	margin-right: 2px;
	}
	#latest-youtube-updates div.mediaIcon{
		margin-left: 10px;
	}
	#latest-youtube-updates ul li img{
		cursor: pointer;
	}
	#latest-youtube-updates ul li img{
		opacity:0.7;
		margin: 28px auto auto 42px;
	}
	#latest-youtube-updates ul li img:HOVER{
		opacity:1;
	}
/*	.ui-widget-overlay {
	    background: url("images/ui-bg_flat_0_aaaaaa_40x100.png") repeat-x scroll 50% 50% #000000;
	    opacity: 0.75;
	}
*/
	.start-from{
		display:none;
	}
	.load-more {
	    color: mediumturquoise;
	    cursor: pointer;
	    font-weight: bold;
	    margin-top: -15px;
	    padding-bottom: 4px;
	    text-align: center;
	}
	#latest-facebook-updates .additinal-links a{
		display: block;
	    height: 100%;
	    width: 100%;
	}
	#latest-youtube-updates{
		width:100% !important;
	}
	#latest-youtube-updates li .video-thumb{
		height: 111px;
	    width: 160px;
	    float:left;
	    margin-right: 5px;
	    background-size: 149px auto; 
	    background-repeat: no-repeat;
	}
	#latest-youtube-updates li a{
		color: #3B5998 !important;
	}
	#latest-youtube-updates .additinal-links{
		margin-left: 165px;
	}
	#latest-youtube-updates .additinal-links a{
		color: green !important;
	    font-size: 11px;
	    font-weight: normal;
	    text-decoration: none;
	}
	#latest-youtube-updates p.author{
		font-style: italic;
	}
	#latest-youtube-updates li .duration{
		background-color: black;
	    color: white;
	    left: 2px;
	    position: absolute;
	}
	div.loading{
		background-image: url("../../../images/ajax-loader-4.gif");
	    background-position: center center;
	    background-repeat: no-repeat;
	}
/*	.microView {
		padding:0px !important;
		border-radius:0px !important;
	}
*/
	#fbImageContainer{
		padding:0px !important;
	}
/*	.ui-dialog{
		padding:0px !important;
	}
*/
	#fbImageContainer object{
		display: block;
    	overflow: hidden;
	}
	.ui-dialog .ui-dialog-titlebar-close {
		width:17px !important;
	}
	div.facebookIcon {
	    background-position: -140px -88px;
	}
	div.youtubeIcon {
	    background-position: -248px -89px;
	}
        .bkmakr_container{
        float:left;
        font-weight: bold;
        color:#000;
    }
   
    .ignore_message{
          margin-top: 53px;
  margin-right: 22px;
    }
    
    .ignore_list{
        border:1px solid;
          margin-top: 48px;
    }
    #table_entity_val{
         float: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
    }
    .entity_mouse_hover{
        background-color: #BEBDBD;
    }
    .bkmakr_container{
        float:left;
        //font-weight: bold;
        color:#5F5C5C;
    }
    .book_mark_hide{
        color:#fff;
        border-color: #fff;
    }
/*    label:hover{
        background-color: #898989;
    }*/
    
    .display_more_entities{
       // overflow-y: auto;
        height:auto;
        border:1px solid #D0CCC9;
        border-color: #D0CCC9;
      
        width:600px;
    }
    .entity_highlight{
        background-color: #898989;
    }
    .sel_option{
        margin:0px;
        float:left;
        margin-left:34px;
        width:130px;
    }
    select{
        margin: 0px;
        //font-weight: bold;
        color:#000;
        
    }
    .pople_disease_top_border
    {
        border-top: 1px solid;
  border-color: #C3B8B0;
    }
    h2{
        margin:0;
    }
    #entity_name{
        float:left;
        margin:2px;
    }
    #entity_image{
        float:left;
        margin:4px;
    }
    #entity_val{
        float:left;
        
        
    }
    .book_img{
        float:right;
       // margin-left:20px;
         margin-top: 2px;
  margin-right: 3px;
    }
     .do_not_show_img{
        float:left;
        cursor:pointer;
        margin-left:27px;
        margin-top: 3px;
        
    }
    #entity_count{
        float: left;
  /* margin: 2px; */
  width: 77px;
  /* margin-left: 10px; */
  margin-right: -39px;
  margin-left: 43px;
   color: #847B7B;

    }
    
    .article_image{
         border-style: ridge;
       margin-right:16px;
       // margin:4px;
        width:100px;
        height:100px;
        border-color:#D0CCC9;
    }
    .entities_list{
        color:#000;
        
    }
    .fav_image{
        margin-right:5px;
        
    }
    #hyper{
        font-size: 15px;
    }
    .rss_feed{
        
       width:1327px;
       
        height:auto;
      
        margin-top:30px;
      
        
    }
    .refined_more_entities{
        border:1px solid;
        margin-top: 48px;
        
    }
    h5{
        cursor:pointer;
        margin:4px;
        float:left;
        color:#0000FF;
    }
    .filters{
        margin-left:21px;
        float:left;
        width:1251px;
    }
    .category_group{
        min-height:283px;
        height:auto;
        
        overflow: auto;
    }
    .book_mark{
       float:left;
       margin:10px;
         //width:620px;
        margin-left:15px;
       min-height:1000px;
        height:auto;
        margin-top:-59px;
        border-color:#D0CCC9;
     
    }
    .left_content{
        float:left;
        margin:10px;
         //width:620px;
         margin-top:9px;
        border-style: ridge;
        //border:2px solid #898989 ;
        height:auto;
      
        border-color:#D0CCC9;
        margin-left:20px;
    }
    .show_more{
        cursor: pointer;
        background-color: #D0CCC9;
       
        height:30px;
        text-align:center;
        margin:10px;
         border-style: ridge;
        
       
    }
    label{
        cursor: pointer;
        font-weight: normal;
              margin: 3px;
    }
    .showmore_table_header{
          margin-left: 370px;
    }
    .feed_url{
        margin:10px;
      
        border-bottom: 1px solid;
         border-color:#D0CCC9;
         text-wrap: normal;
         height:auto;
    }
    .article_content{
        height:auto;
        min-height: 150px;
    }
/*    .product{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
/*    .people{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
   .cat_class {
  float: left;
  width: 286px;
  height: auto;
  min-height: 283px;
  /* border: 2px solid #898989; */
  /* border-bottom: rgb(186, 169, 147); */
  border-bottom: 1px solid;
  //border-top: 1px solid;
  border-color: #C3B8B0;
  margin: 10px;
}
/*     .disease{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
     .organization{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .companies{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .technology{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
    .cat_name{
        cursor: pointer;
        color:#000;
        margin:5px;
        height:22px;
    }
    #count{
        float:right;
    }
    
    #rssfeed_content{
        border:1px solid #1A5C76;
        border-top:5px solid #1A5C76;
        padding-left:10px;
    }
    
    #tabs1 a{
        display:block;
        width:100px;
        float:left;
        border:1px solid #D0CCC9;
        text-align: center;
        margin-right:5px;
        background-color: #EFEFEF;
        padding: 5px 0;
        text-decoration: none;
        margin-right:0px;
        cursor: pointer;
    }
    
    #tabs1 div.divider{
        display: inline;
        width: 3px;
        border: 0px;
        border-bottom: 1px solid #D0CCC9;
        display: block;
        float: left;
        height: 29px;
    }
    #tabs1 a.current{
        background-color: #FFFFFF;
        border-bottom:1px solid #FFFFFF;
        z-index: 100;
        color:#1A5C76;
        font-weight: bold;
    }
/*    #tabs1 div.lastRight{
        width: 188px;
    }
*/
    #tabs1 div.firstRight{
        width: 20px;
    }
    #tabs1{
        padding-left:20px;
        z-index: 1;
        padding-bottom: 29px;
        border-bottom: 1px solid #D0CCC9;
        color:#898989;
        float: left;
        padding-bottom: 0px;
        border-bottom: 0px;
        padding-left:0px;
    }
   .ignore_message{
          margin-top: 53px;
  margin-right: 22px;
    }
    
    .ignore_list{
        border:1px solid;
          margin-top: 48px;
    }
    #table_entity_val{
         float: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
    }
    .entity_mouse_hover{
        background-color: #BEBDBD;
    }
    .bkmakr_container{
        color: #5f5c5c;
    float: unset;
    margin-left: 130px;
    margin-top: -21px;
    }
    .book_mark_hide{
        color:#fff;
        border-color: #fff;
    }
/*    label:hover{
        background-color: #898989;
    }*/
    
    .display_more_entities{
       // overflow-y: auto;
        height:auto;
        border:1px solid #D0CCC9;
        border-color: #D0CCC9;
      
        width:600px;
    }
    .entity_highlight{
        background-color: #898989;
    }
    .sel_option{
        margin:0px;
        float:left;
        margin-left:34px;
        width:130px;
    }
    select{
        margin: 0px;
        //font-weight: bold;
        color:#000;
        
    }
    
    .load_more_entity:hover{
        background-color: #D5DBEC;
    }
    .pople_disease_top_border
    {
        border-top: 1px solid;
  border-color: #C3B8B0;
    }
    h2{
        margin:0;
    }
    #entity_name{
        float:left;
        margin:2px;
    }
    #entity_image{
        float:left;
        margin:4px;
    }
    #entity_val{
        float:left;
        
        
    }
    .book_img{
        float:right;
       // margin-left:20px;
         margin-top: 2px;
  margin-right: 3px;
    }
     .do_not_show_img{
        float:left;
        cursor:pointer;
        margin-left:27px;
        margin-top: 3px;
        
    }
    #entity_count{
        float: left;
  /* margin: 2px; */
  width: 77px;
  /* margin-left: 10px; */
  margin-right: -39px;
  margin-left: 43px;
   color: #847B7B;

    }
    .table_all_cat_count{
     margin-top: 10px;
 text-align: center;
  font-weight: normal;
  color: rgb(124, 124, 124);
    }
    .table_cat_count_font{
        font-size: 16px;
        color: rgb(97, 96, 96);
        font-weight: normal;
    }
    .article_image{
         border-style: ridge;
       margin-right:16px;
       // margin:4px;
        width:100px;
        height:100px;
        border-color:#D0CCC9;
    }
    .entities_list{
        color:#000;
        
    }
    .fav_image{
        margin-right:5px;
        
    }
    #hyper{
        font-size: 15px;
    }
    .rss_feed{
        
       width:1327px;
       
        height:auto;
      
        margin-top:30px;
      
        
    }
    .refined_more_entities{
        border:1px solid;
        margin-top: 48px;
        
    }
    h5{
        cursor:pointer;
        margin:4px;
        float:left;
        color:#0000FF;
    }
    .filters{
        margin-left:21px;
        float:left;
        width:1251px;
    }
    .category_group{
        min-height:283px;
        height:auto;
          margin-top: -6px;
        overflow: auto;
    }
    .book_mark{
       float:left;
       margin:10px;
         //width:620px;
        margin-left:15px;
       min-height:1000px;
        height:auto;
        margin-top:-59px;
        border-color:#D0CCC9;
		position: relative;
    }
    .left_content{
        float:left;
        margin:10px;
         //width:620px;
         margin-top:0px;
        border-style: ridge;
        //border:2px solid #898989 ;
        height:auto;
      
        border-color:#D0CCC9;
        margin-left:20px;
    }
    .show_more{
        cursor: pointer;
        background-color: #D0CCC9;
       
        height:30px;
        text-align:center;
        margin:10px;
         border-style: ridge;
        
       
    }
    label{
        cursor: pointer;
        font-weight: normal;
              margin: 3px;
    }
    .showmore_table_header{
          margin-left: 370px;
    }
    .feed_url{
        margin:10px;
      
        border-bottom: 1px solid;
         border-color:#D0CCC9;
         text-wrap: normal;
         height:auto;
    }
    .article_content{
        height:auto;
        min-height: 100px;
    }
/*    .product{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
/*    .people{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
   .cat_class {
  float: left;
  width: 286px;
  height: auto;
  min-height: 242px;
  /* border: 2px solid #898989; */
  /* border-bottom: rgb(186, 169, 147); */
  border-bottom: 1px solid;
  //border-top: 1px solid;
  border-color: #C3B8B0;
  margin: 10px;
}
.show_more:hover{
    background-color: #D5DBEC;
}
/*     .disease{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
     .organization{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .companies{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .technology{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
    .cat_name{
        cursor: pointer;
        color:#000;
        margin:5px;
        height:22px;
    }
    #count{
        float:right;
    }
    
    #rssfeed_content{
        border:1px solid #1A5C76;
        border-top:5px solid #1A5C76;
        padding-left:10px;
    }
    
    #tabs1 a{
        display:block;
        width:100px;
        float:left;
        border:1px solid #D0CCC9;
        text-align: center;
        margin-right:5px;
        background-color: #EFEFEF;
        padding: 5px 0;
        text-decoration: none;
        margin-right:0px;
        cursor: pointer;
    }
    
    #tabs1 div.divider{
        display: inline;
        width: 3px;
        border: 0px;
        border-bottom: 1px solid #D0CCC9;
        display: block;
        float: left;
        height: 29px;
    }
    #tabs1 a.current{
        background-color: #FFFFFF;
        border-bottom:1px solid #FFFFFF;
        z-index: 100;
        color:#1A5C76;
        font-weight: bold;
    }
/*    #tabs1 div.lastRight{
        width: 188px;
    }
*/
    #tabs1 div.firstRight{
        width: 20px;
    }
    #tabs1{
        padding-left:20px;
        z-index: 1;
        padding-bottom: 29px;
        border-bottom: 1px solid #D0CCC9;
        color:#898989;
        float: left;
        padding-bottom: 0px;
        border-bottom: 0px;
        padding-left:0px;
    }
    #rssfeed_content1 p{
        display: none;
    }
    #rssfeed_content1 ul{
        padding-left: 5px;
        list-style: none;
    }
    #rssfeed_content1 ul{
        list-style: none;
    }
    #rssfeed_content1{
        min-height: 300px;
    }
    
    .rssFeed{
        border:1px solid #D0CCC9;
        border-top:0px;
        padding-left:20px;
        padding-top: 10px;
    }
    #RSSFEED4 map img{
        display: none;
    }
        .submit{
            float:left;
            display:inline-block;
        }
        .date_picker1 label,.date_picker1 input{
            float:left;
            width:130px;
            
            display:inline-block;
           
        }
        .date_picker2 label,.date_picker2 input{
           float: left;
            margin-left: 0px;
            width: 130px;
            display: inline-block;
        }
       .date_picker1 label{
            margin:0px;
            width:50px;
           font-weight: bold;
        }
        .date_picker2 label{
            margin:0px;
            width:50px;
            margin-left:10px;
            font-weight: bold;
        }
        .load_more_entity{
         cursor: pointer;
        background-color: #D0CCC9;
       height:31px;
        margin:10px;
        margin-top:17px;
        text-align:center;
       
         border-style: ridge;
      
        }
           .load_more_user_entity{
         cursor: pointer;
        background-color: #D0CCC9;
        border-color: #1A5C76;
        margin:10px;
        margin-top:166px;
        text-align:center;
       
         border-style: ridge;
        border:2px solid #1A5C76 ;
        }
        h6{
            margin:0;
        }
        #book_mark_content{
        height:auto;
          margin-top: 9px;
        }
        textarea{
            margin:2px;
            resize: vertical;
            
           width: 579px;
        }
        .previous_comments
        {   margin:8px;
            margin-left:5px;
             width: 579px;
             height:auto;
             border:1px solid;
             min-height: 50px;
             border-color: #D0CCC9;
        }
        .comments{
            display:none;
            
        }
        #comment_click{
            cursor:pointer;
            font-size: 15px;
             color: #ABABBD;
               margin-left: 13px;
               //margin-top: 32px;
        }
        #comment_submit{
            
            position:relative;
        }
        .comment_info{
            font-size: 10px;
            color: #898989;
            //margin-top:28px;
        }
         .comment_info b{
            font-size: 10px;
            color: #1A5C76;
            margin:4px;
           
        }
        .selected_entity{
              background-color: rgb(209, 220, 234);
           
        }
        .arrowMarkIcon{
            transform: rotate(90deg);
        }
         .arrowMarkIconTags{
            transform: rotate(90deg);
        }
        .ignore_settings{
            float:left;
            margin-left:580px;
        }
        .tags:hover{
            cursor:pointer;
            color: #0000FF;
        }
        .applied_filters{
           width: 623px;
            margin-top: 14px;
            min-height: 27px;
            margin-bottom: -10px;
            margin-left: 20px;
            color: #C8BFBF;
           border-bottom: 2px solid;
          
            
        }
        .arrowMarkIconTags {
        background: url("../images/kolm-sprite-image.png") repeat scroll -86px -87px transparent;
        width: 23px;
        height: 30px;
      }
      #statForm{
          height:auto;
      }
      a{
          cursor:pointer;
      }
      .show_tags tr{
           border:1px solid greenyellow;
           border-style: ridge;
           
           color:#000;
      }
      .bk_horizontal_line {
  width: 601px;
  height: 2px;
  background-color: #C8BFBF;
    
}
#showStatForm > div {
    margin-bottom: 8px;
   // margin-left: 140px;
}
.table_entity_name {
   display: inline-block;
   width: 375px;
   text-wrap: normal;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
    margin: -3px;
  margin-left: 2px;
  margin-top:1px;
}
.table_show_more {
    height: 29px;
    width: 335px;
}
.table_cat_show_more {
   
    cursor: pointer;
    display: inline-table;
    
    font-weight: normal;
    margin-right: 11px;
    margin-top: 5px;
}
.table_entity_count {
    color:#847B7B;
   display: inline-block;
   width: 52px;
}
.entity_name {
   display: inline-block;
   width: 142px;;
   text-wrap: normal;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
    margin: -3px;
  margin-left: 2px;
  margin-top:1px;
}


.entity_count {
    color:#847B7B;
   display: inline-block;
   width: 52px;
}
.cat_show_more:hover{
    color:#847B7B;
}
.cat_show_more{
     margin-top: 5px;
  font-weight: normal;
  display: inline-table;
  /* margin-right: 28px; */
  float: right;
  margin-right: 11px;
  color:#0000FF;
  cursor:pointer;
}
.show_more_feeds{
      margin-top: 5px;
  font-weight: normal;
  display: inline-table;
  /* margin-right: 28px; */
  
  margin-right: 11px;
  color:#0000FF;
  cursor:pointer;
}
.unbookmark{
    margin-top:20px;
      margin-left: 123px;
      cursor:pointer;
}
.ignore_restore{
      margin-top: 10px;
  margin-left: 5px;
  height: 30px;
}
h5 img{
      margin: 4px;
  margin-left: 5px;
}
h6 input{
    width:270px;
}
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	
	}
	.med{
		border: 1px solid #dddddd;
	    float: left;
	    height: 130px;
	    margin: 10px;
	    width: 100%;
	    padding: 5px;
	    overflow: hidden;
	}
	.medTd{
		vertical-align: top;
	}
	.ftchtitle{
		color: blue; 
		font-size: 15px;
	}
	.fltLft{
		float: left;
	}
	#show_more{
		background: none repeat scroll 0 0 #ebebeb;
	    border: 1px solid #dddddd;
	    cursor: pointer;
	    float: left;
	    font-weight: bold;
	    margin-left: 13px;
	    width: 93%;
	    height: 20px;
	}

</style>
</style>
<script src="<?php echo base_url();?>js/chosen.jquery.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<script type="text/javascript">
	var kolId=<?php echo $arrKol['id'];?>;

	$(document).ready(function(){
		var fbImageOptions = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 'auto',
				draggable:false,
				position: ['center', 'center'],
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				},
				close:function(){
					$("#fbImageContainer").dialog('option','width','auto');
					$("#fbImageContainer").dialog('option','position',['center', 'center']);
				}
			};
		$('#fbImageContainer').dialog(fbImageOptions);


		$("#latest-facebook-updates div > .fb-image").live("click",function(){
			var imgSrc = $(this).attr('src');
			imgSrc = imgSrc.replace("_s","_n"); 
			$("#fbImageContainer").dialog('option','width',750);
			$("#fbImageContainer").dialog('option','position',['center', 20]);
			$("#fbImageContainer").html('<div width="750px">&nbsp;.<img width="750px" alt="" src="'+imgSrc+'"></div>');
			$("#fbImageContainer").dialog("open");
		});

		$("#latest-youtube-updates ul li .video-thumb").live("click",function(){
			var videoSrc = $(this).attr('vsrc');
			var embedHtml = ' <object width="550" height="375">';
				embedHtml +='	<param name="movie" value="'+videoSrc+'"</param>';
				embedHtml +='	<param name="allowFullScreen" value="true"></param>';
				embedHtml +='	<param name="allowScriptAccess" value="always"></param>';
				embedHtml +='	<embed src="'+videoSrc+'"';
				embedHtml +='		type="application/x-shockwave-flash"';
				embedHtml +='		allowfullscreen="true"';
				embedHtml +='		allowscriptaccess="always"';
				embedHtml +='		wmode="opaque"';
				embedHtml +='		width="550" height="375">';
				embedHtml +='	</embed>';
				embedHtml +='</object>';
			$("#fbImageContainer").html(embedHtml);
			$("#fbImageContainer").dialog("open");
		});

		$(".ui-widget-overlay").live("click",function(){
			$(".ui-icon-closethick").click();
		});

		//Load more updates
		$(".load-more").click(function(){
			var thisEle = $(this);
			var categoryId 	= $(this).parent().attr("id");
			var mediaSection= $(this).parent().children("h5").children("a").html();
			var mediaUrl	= $(this).parent().children("h5").children("a").attr('href');
			var startFrom	= $(this).parent().children("ul").children(".start-from").last().html();
			var data = {};
			data['mediaSection']= mediaSection;
			data['mediaUrl'] 	= mediaUrl;
			data['startFrom'] 	= startFrom;
			//Show loading indicator
			$(thisEle).addClass("loading");
			$.ajax({
				type: "post",
				dataType:"text",
				data:data,
				url: base_url+'organizations/load_more_media_updates/',
				success: function(returdData){
					$("#"+categoryId+" ul").append(returdData);
					//hide loading indicator
					$(thisEle).toggleClass("loading");
				}
			});
		});

		$('#kolSocialMedia ul').bind('scroll', function(){
	        if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight){
		        if(!$(this).next().hasClass("loading"))
	       			$(this).next().click();
	        }
		});
                
	});
        var init_offset=10;
    var i=1;
    var datewise_init_offset=10;
    var d_i=1;
    var start_date,end_date;
    var flag=0;
    var reset_values=0;
     var option;
     var commentResult=0;

    function loadRssFeeds(offset,filter){
        
       var filterData = {};
       var topFilters = $("#topFilters").serialize();
       if(topFilters != null && topFilters != '')
           filterData += '&'+topFilters;
       var statFilters = $("#statForm").serialize();
       if(statFilters != null && statFilters != '')
           filterData += '&'+statFilters;
         var showStatFilters = $("#showStatForm").serialize();
       if(showStatFilters != null && showStatFilters != '')
           filterData += '&'+showStatFilters;
       if(offset != null)
           filterData += '&offset='+offset;

       var sel_option=$( "#select_feed_type option:selected" ).val();

          $('.feed_url').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7 ',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
       $.ajax({
           url:'<?php echo base_url();?>media_intel_extractions/get_feeds/',
           type:'POST',
           dataType :'JSON',
           data:filterData,
           success:function(returnData){
               if(returnData==null)
               {
                   $('.show_more').hide();
                   
                   $('.left_content').append("<center><h3>No more data to load<center></h3>");
                   $('.feed_url').unblock();
               }
               else
               {
                   if(offset == null)
                   $(".left_content").empty();
                   for(var result in returnData)
                   {
                       //alert("hi");

                       var html,feed_id;
                       html="<div class=\"feed_url\">";
                       if(returnData[result].bookmarks!==null){
                            html+= "<div class='bkmakr_container'>("+returnData[result].bookmarks+")<img class='fav_image' src='"+base_url+"/css/images/fav.png' align='right' /></div>";
                       }
                       if(sel_option==1)
                           html+= "<div class='bkmakr_container'>("+returnData[result].entity_name+")<img class='fav_image' src='"+base_url+"/css/images/fav.png' align='right' /></div>";
                       
                        html+= "<img class='article_image' src='"+returnData[result].img_url+"' align='left' />";
                      
                       html+=  "<div class='article_content'>";
                       html+=    "<a id='hyper' target='_blank' href='"+returnData[result].rss_feed_url+"'><b>'"+returnData[result].title+"'</b></a><br/>";
                       html+=  "<b>Publisher:</b><br/>";
                       html+=   "<b>Published on:</b>"+returnData[result].date+"<br/>";
                       html+=   "<p><b>Description:</b>"+returnData[result].description+"</p><br/>";
                       html+= "</div>";
                       if(sel_option==1)
                       {
                          feed_id= returnData[result].rss_feed_url_id;
                        }
                        if(sel_option==0 && filter==1)
                        {
                           feed_id= returnData[result].rss_feed_url_id;
                        }
                        if(sel_option==0 && filter!=1)
                        {
                            feed_id= returnData[result].id;
                        }
                        $.ajax({                    
                            url:'<?php echo base_url();?>media_intel_extractions/get_comment_count/',
                            type:'POST',
                            dataType :'JSON',
                            async: false,
                            data:{feed_id:feed_id},
                            success:function(commentCount){
                                if(commentCount!='')
                                    commentResult=commentCount[0].comment_count;
                                
                            }
                        });
                       html+="<div id='comment_click' onclick=\"userComments('"+feed_id+"')\">Comments("+commentResult+")</div>";
                       html+="<div id='"+feed_id+"' class='comments'><textarea  name='comments' rows='4' cols='10'></textarea><input  id='comment_submit' value='submit' type='button'/></div><div class='"+feed_id+"'></div>";
                       html+= " </div>";
                       commentResult=0;
                       if(offset==null)
                       {
                           $(".left_content").append(html);
                           
                       }
                       else
                       {
                            $('.show_more').before(html);
                           
                       }
                      $('.feed_url').unblock(); 
                   }
                       if(offset==null)
                           $('.left_content').append("<div id='load_more'   class='show_more'><h3>Show More</h3></div>");
                      
                           
               }
           }
          });
   }

    function loadDataDatewise(){
    	loadRssFeeds();
    	loadStats();
    }


        
        
    $(document).ready(function(){
        
        
      
        $('#select_feed_type').change(function(){
            $('.display_more_entities').hide();
            $('#book_mark_content').show();
                
             option=  $( "#select_feed_type option:selected" ).val();
             if(option=="0")
             {  
                 
                flag=0;
                $('#empty_disease').empty();
                $('#empty_product').empty();
                $('#empty_technology').empty();
                $('#empty_organization').empty();
                $('#empty_company').empty();
                $('#Person').show();
                $('#MedicalCondition').show();
                $('#Product').show();
                $('#technology').show();
                $('#Organization').show();
                $('#Company').show();
                $('.load_more_user_entity').hide();
                
                loadStats();
           
             }
             else
             { 
                 
                 loadStats();

             }
            
        });
        
        
       
       
         $('#comment_submit').live("click",function(){
            var feed_id= $(this).closest('div').attr('id');
            var comment=  $("#"+feed_id+" textarea").val();
            if(comment=='')
            {
                 $('#'+feed_id+"error").empty();
                $('#'+feed_id+"error").append("<b style='color:#ff0000'>Comment cannot be left blank</b>");
            }
            else
            {
                $('#'+feed_id+"error").empty();
                $.ajax({                    
                    url:'<?php echo base_url();?>media_intel_extractions/user_comments/',
                    type:'POST',
                    dataType :'JSON',
                    data:{feed_id:feed_id,comment:comment},
                    success:function(returnData){
                        $("."+feed_id).prepend("<div class='previous_comments'><div class='comment_info'><b>Posted by"+" "+returnData.first_name+"&nbsp;"+returnData.last_name+"</b></div>"+"<p style='margin:4px;  margin-bottom: -18px;'>"+comment+"</p>"+"<br/> "+"<p style='font-size:9px;margin:4px'>"+returnData.date+"</p>"+"</div>"); 
                        $("#"+feed_id+" textarea").val('');
                    }
                });

               }
             
             
         });
        
      
       
        $("#datepicker1").click(function(){
            $('#datepicker1').datepicker({ dateFormat: 'yy-mm-dd' });
            $('#datepicker1').datepicker("show");
            
            
                        
        });
        $("#datepicker2").click(function(){
            $('#datepicker2').datepicker({ dateFormat: 'yy-mm-dd' });
            $('#datepicker2').datepicker("show");
           
           
           
        });
        
        
        
});
      $('#load_more').live('click',function(){
          
            var offset = init_offset * i;
            loadRssFeeds(offset);
            i++;
        });
    
        function load_more_datewise()
        {
          
            var offset = datewise_init_offset * d_i;
            loadRssFeeds(offset);
            d_i++;
        
       
        };
        
        var filter=[];
        
        function entity_refine(thisEle)
        {
            loadRssFeeds(null,1);
          $(thisEle).addClass('.entity_highlight');
           $(thisEle).attr('checked', true);

           loadStats();         
       
        }
        function load_more_entity(cat_name){
        //var bookarray = new Array();
            var category;
           
            if(cat_name=="people")
                category="Person";
            if(cat_name=="disease")
                category="MedicalCondition";
            if(cat_name=="product")
               category="Product";
            if(cat_name=="organization")
               category="Organization";
            if(cat_name=="technology")
               category="Technology";
            if(cat_name=="company")
               category="Company";
             $('.book_mark').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
              $.ajax({                    
                    url:'<?php echo base_url();?>media_intel_extractions/ajax_show_more_cats/',
                    type:'POST',
                    dataType :'JSON',
                    data: { cat_name: category},
                    success:function(returnData){
                        if(returnData=='')
                        {
                            
                        }
                        else
                        {
                           $('#book_mark_content').hide();
                            var html;
                            html="<form action='' name='showStatForm' id='showStatForm'>";
                            html+="<div class='display_more_entities '>";
                             html+="<b>"+cat_name+"</b>";
                             html+="<h5  onclick=\"hide_more_entities()\">Close</h5>";
                           
                            html+="<table class='entities_list'>";
                            html+="<tr><th>Entity Name</th><th>Articles</th><th></th><th></th></tr>";
                            for(var result in returnData)
                            {
                                
                                if(((returnData[result].isblacklisted!=true)&&option!=1)||((returnData[result].isblacklisted!=true)&&(returnData[result].isbookmarked==true)&&option==1))
                                {
                                html+="<tr class='cat_name'><td><div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData[result].entity_name+"  name='"+cat_name+"[]' hidden value='"+returnData[result].entity_name+"'/><label id='$values->entity_name' for="+returnData[result].entity_name+">"+returnData[result].entity_name+" </label></div></td>";
                                 html+="<td>"+returnData[result].numc+"</td>";
                                if(option!=1)
                                {
                                if(returnData[result].isbookmarked==true)
                                     html+= "<td><img  onclick=\"bookmark_entity("+returnData[result].id+")\" class="+returnData[result].id+ " src=\""+base_url+"/css/images/fav.png\"  /> </td>";
                                else
                                    html+= "<td width='20px'><img  onclick=\"bookmark_entity("+returnData[result].id+")\" class="+returnData[result].id+ " src=\""+base_url+"/css/images/unfav.png\"  /> </td>";
                                }
                                else
                                {
                                    html+= "<td><img  onclick=\"bookmark_entity("+returnData[result].id+")\" class="+returnData[result].id+ " src=\""+base_url+"/css/images/fav.png\"  /> </td>";
                                }
                               
                                html+="<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData[result].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div>     </td></tr>"
                                }
                            } 
                            html+="</table>";
                           html+="</div>";
                           html+="</form>"
                            $('.book_mark').append(html);
                            $( "tr:odd" ).css( "background-color", "#E9E9E9" );
                             $('.book_mark').unblock();
                           
                        }
                    }
            });
            
       
       }

	function loadStats(){
		 var filterData = {};
         var topFilters = $("#topFilters").serialize();
         if(topFilters != null && topFilters != '')
         filterData += '&'+topFilters;
         var statFilters = $("#statForm").serialize();
         if(statFilters != null && statFilters != '')
         filterData += '&'+statFilters;
      var showStatFilters = $("#showStatForm").serialize();
       if(showStatFilters != null && showStatFilters != '')
           filterData += '&'+showStatFilters;
  
     
     //filter.push($('input:checkbox:checked').val());
       $('.feed_url').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

   	
		$.ajax({                    
            url:'<?php echo base_url();?>media_intel_extractions/ajax_entity_filters/',
            type:'POST',
            dataType :'JSON',
             data: filterData,
            success:function(returnData){
                if(returnData=='')
                {
                    alert("no data");
//                    $('.show_more').hide();
//                    $('.left_content').append("<center><h3>No more data to load<center></h3>");
//                    $('.feed_url').unblock();
                }
                else
                {   //$('.feed_url').hide();
                    //$('.show_more').hide();
                        flag=0;
                        $('#empty_person').empty();
                        $('#empty_disease').empty();
                        $('#empty_product').empty();
                        $('#empty_technology').empty();
                        $('#empty_organization').empty();
                        $('#empty_company').empty();
                        var count_person=0;
                        var count_disease=0;
                        var count_product=0;
                        var count_organization=0;
                        var count_technology=0;
                        var count_company=0;
                        var article_count_person=0;
                        var article_count_disease=0;
                        var article_count_product=0;
                        var article_count_organization=0;
                        var article_count_technology=0;
                        var article_count_company=0;
                     var i=0;
                    for(var result in returnData)
                    {
                    if((result!="Person")&&(result!="Technology")&&(result!="MedicalCondition")&&(result!="Product")&&(result!="Organization")&&(result!="Company"))
                     {
                         
                        
                    }
                    } 
                    $('.load_more_entity').hide();
                    
                     if(returnData.hasOwnProperty('People'))
                            { $('#empty_person').empty();
                                
                               
                             var i=0;
                                for(var cat_res in returnData['People'])
                                {
                                       // alert(returnData['person'][cat_res].img_url);
                                       if((returnData['People'][cat_res]!="No entities")&&(returnData['People'][cat_res].isblacklisted!=true))
                                       {
                                            count_person++;
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['People'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['People'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['People'][cat_res].id+")\" class="+returnData['People'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['People'][cat_res].id+")\" class="+returnData['People'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['People'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        article_count_person=article_count_person+parseInt(returnData['People'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_person').append(html);
                                        //flag=1;
                                         i++;
                                        if(i>=5)
                                        {
                                             $('.people').append("<div id='people' onclick=\"load_more_entity('people')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                        
                                    }
                                     if(i==0)
                                    {
                                        $('#empty_person').empty();
                                        $('#empty_person').append("No entities found");
                                       
                                    }
                                }
                                $('.person_header').empty();
                                if(option==1)
                                {   
                                    $('.person_header').append("<h2>People</h2>("+count_person+"People in"+" "+article_count_person+")");
                                }
                                else
                                {
                                     $('.person_header').append("<h2>People</h2>("+returnData['People'].length+"People in"+" "+returnData["count"][4].num+")");
                                }
                            }
                            if(returnData.hasOwnProperty('MedicalCondition'))
                            {
                                $('#empty_disease').empty();
                                //$('.load_more_entity').hide();
                                
                                var i=0;
                                
                                for(var cat_res in returnData['MedicalCondition'])
                                {
                                   if((returnData['MedicalCondition'][cat_res]!="No entities")&&(returnData['MedicalCondition'][cat_res].isblacklisted!=true))
                                {     //alert(returnData['person'][cat_res].img_url);
                                        count_disease++;
                                         article_count_disease=article_count_disease+parseInt(returnData['MedicalCondition'][cat_res].numc);
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                            //count_disease++;
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['MedicalCondition'][cat_res].entity_name+" value='"+returnData['MedicalCondition'][cat_res].entity_name+"' name='disease[]' hidden  /><label id='$values->entity_name' for="+returnData['MedicalCondition'][cat_res].entity_name+">"+returnData['MedicalCondition'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['MedicalCondition'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['MedicalCondition'][cat_res].id+")\" class="+returnData['MedicalCondition'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['MedicalCondition'][cat_res].id+")\" class="+returnData['MedicalCondition'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['MedicalCondition'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_disease').append(html);
                                        //flag=1;
                                         i++;
                                        //}
                                        if(i>=5)
                                        {
                                            $('.disease').append("<div id='disease' onclick=\"load_more_entity('disease')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                }
                                
                            }
                            if(i==0)
                                {
                                    $('#empty_disease').empty();
                                    $('#empty_disease').append("<center>No entities found</center>");
                                }
                                $('.disease_header').empty();
                                if(option==1)
                                {  
                                    $('.disease_header').append("<h2>Disease</h2>("+count_disease+"Diseases in"+" "+article_count_disease+")");
                                }
                                else
                                {
                                    $('.disease_header').append("<h2>Disease</h2>("+returnData['MedicalCondition'].length+"Diseases in"+" "+returnData["count"][2].num+")");
                                }
                            }
                            if(returnData.hasOwnProperty('Technology'))
                            {
                                $('#empty_technology').empty();
                                //$('.load_more_entity').hide();
                                
                                
                               
                                var i=0;
                                for(var cat_res in returnData['Technology'])
                                {
                                    if((returnData['Technology'][cat_res]!="No entities")&&(returnData['Technology'][cat_res].isblacklisted!=true))
                                    {  
                                    // alert(returnData['person'][cat_res].img_url);
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        count_technology++;
                                           article_count_technology=article_count_technology+parseInt(returnData['Technology'][cat_res].numc);
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['Technology'][cat_res].entity_name+"  name='technology' hidden value='"+returnData['Technology'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['Technology'][cat_res].entity_name+">"+returnData['Technology'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['Technology'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['Technology'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Technology'][cat_res].id+")\" class="+returnData['Technology'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Technology'][cat_res].id+")\" class="+returnData['Technology'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['Technology'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_technology').append(html);
                                        i++;
                                        if(i>=5)
                                        {
                                            $('.technology').append("<div id='technology' onclick=\"load_more_entity('technology')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                    }
                                    
                                }
                                if(i==0)
                                {
                                        $('#empty_technology').empty();
                                        $('#empty_technology').append("No entities found");
                                }
                                $('.technology_header').empty(); 
                                if(option==1)
                                {
                                    
                                    $('.technology_header').append("<h2>Technology</h2>("+count_technology+"Technologies in"+" "+article_count_technology+")");
                                }
                                else
                                {
                                    $('.technology_header').append("<h2>Technology</h2>("+returnData['Technology'].length+"Technologies in"+" "+returnData["count"][17].num+")");
                                }
                            }
                            if(returnData.hasOwnProperty('Organization'))
                            {
                            $('#empty_organization').empty();
                           // $('.load_more_entity').hide();
                           
                            
                            var i=0;
                                for(var cat_res in returnData['Organization'])
                                {
                                        //alert(returnData['person'][cat_res].img_url);
                                         if(returnData['Organization'][cat_res]!="No entities")
                                    { 
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                            count_organization++;
                                            article_count_organization=article_count_organization+parseInt(returnData['Organization'][cat_res].numc);
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['Organization'][cat_res].entity_name+"  name='organization' hidden value='"+returnData['Organization'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['Organization'][cat_res].entity_name+">"+returnData['Organization'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['Organization'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['Organization'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Organization'][cat_res].id+")\" class="+returnData['Organization'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Organization'][cat_res].id+")\" class="+returnData['Organization'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['Organization'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_organization').append(html);
                                        i++;
                                        if(i>=5)
                                        {
                                            $('.organization').append("<div id='organization' onclick=\"load_more_entity('organization')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                    }
                                   
                                }
                                 if(i==0)
                                    {
                                        $('#empty_organization').empty();
                                        $('#empty_organization').append("No entities found");
                                    }
                                $('.organization_header').empty();  
                                if(option==1)
                                {
                                    
                                    $('.organization_header').append("<h2>Organization</h2>("+count_organization+"Organizations in"+" "+article_count_organization+")");
                                }
                                else
                                {
                                     $('.organization_header').append("<h2>Organization</h2>("+returnData['Organization'].length+"Organizations in"+" "+returnData["count"][3].num+")");
                                }
                            }
                            if(returnData.hasOwnProperty('Company'))
                            {
                            var i=0;
                                $('#empty_company').empty();
                                // $('.load_more_entity').hide();
                            
                                for(var cat_res in returnData['Company'])
                                {
                                        //alert(returnData['person'][cat_res].img_url);
                                         if((returnData['Company'][cat_res]!="No entities")&&(returnData['Company'][cat_res].isblacklisted!=true))
                                        { 
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                           count_company++;
                                           article_count_company=article_count_company+parseInt(returnData['Company'][cat_res].numc);
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['Company'][cat_res].entity_name+"  name='company' hidden value='"+returnData['Company'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['Company'][cat_res].entity_name+">"+returnData['Company'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['Company'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['Company'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Company'][cat_res].id+")\" class="+returnData['Company'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Company'][cat_res].id+")\" class="+returnData['Company'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['Company'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_company').append(html);
                                        i++;
                                        if(i>=5)
                                        {
                                            $('.companies').append("<div id='company' onclick=\"load_more_entity('company')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                        }
                                        
                                        
                                }
                                if(i==0)
                                {
                                            
                                    $('#empty_company').append("No entities found");
                                }
                                 $('.company_header').empty(); 
                                if(option==1)
                                {
                                   
                                    $('.company_header').append("<h2>Company</h2>("+count_company+"Companies in"+" "+article_count_company+")");
                                }
                                else
                                {
                                    $('.company_header').append("<h2>Company</h2>("+returnData['Company'].length+"Companyies in"+" "+returnData["count"][18].num+")");
                                }
                            }
                            if(returnData.hasOwnProperty('Product'))
                            {
                              var i=0;
                                $('#empty_product').empty();
                               //  $('.load_more_entity').hide();
                           
                                for(var cat_res in returnData['Product'])
                                {
                                        //alert(returnData['person'][cat_res].img_url);
                                         if((returnData['Product'][cat_res]!="No entities")&&(returnData['Product'][cat_res].isblacklisted!=true))
                                        { 
                                         var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                            count_product++;
                                            article_count_product=article_count_product+parseInt(returnData['Product'][cat_res].numc);
                                        html="<div class='cat_name'>";
                                        html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['Product'][cat_res].entity_name+"  name='product' hidden value='"+returnData['Product'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['Product'][cat_res].entity_name+">"+returnData['Product'][cat_res].entity_name+" </label></div>";
                                        html+="<div id='entity_count'><b >("+returnData['Product'][cat_res].numc+"&nbsp;articles)</b> </div>"
                                        if(returnData['Product'][cat_res].isbookmarked==true)
                                            html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Product'][cat_res].id+")\" class="+returnData['Product'][cat_res].id+" src=\""+base_url+"/css/images/fav.png\"  /> </div>";
                                        else
                                             html+="<div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['Product'][cat_res].id+")\" class="+returnData['Product'][cat_res].id+" src=\""+base_url+"/css/images/unfav.png\"  /> </div>";
                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['Product'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                        html+="</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if(i<=5)
                                        $('#empty_product').append(html);
                                        i++;
                                        if(i>=5)
                                        {
                                            $('.product').append("<div id='product' onclick=\"load_more_entity('product')\" class='load_more_entity'> Show More </div>");
                                            break;
                                        }
                                        }
                                        
                                        
                                }
                                if(i==0)
                                {
                                            
                                    $('#empty_company').append("No entities found");
                                }
                                 $('.product_header').empty(); 
                                if(option==1)
                                {
                                   
                                    $('.product_header').append("<h2>Product</h2>("+count_product+"Products in"+" "+article_count_product+")");
                                }
                                else
                                {
                                    $('.product_header').append("<h2>Product</h2>("+returnData['Product'].length+"Products in"+" "+returnData["count"][13].num+")");
                                }
                            }
                   // $('.left_content').append("<div id='load_more_filterd_feeds' onclick=''  class='show_more'><h3>Show More</h3></div>");
                }
            }
    });
	}
        
        function hide_more_entities(){
            $('.display_more_entities').hide();
            $('#book_mark_content').show();
            $('h5').hide();
        }
        function bookmark_entity(ent_id)
        {
            //alert(ent_id);
            //$("."+ent_id).attr('src','<?php echo base_url();?>/css/images/unfav.png');
            $.ajax({                    
                    url:'<?php echo base_url();?>media_intel_extractions/user_bookmarks/',
                    type:'POST',
                    dataType :'JSON',
                     data: { entity_id: ent_id},
                    success:function(returnData){
                    if(returnData.status=="bookmarked")
                    {
                         $("."+ent_id).attr('src','<?php echo base_url();?>/css/images/unfav.png');
                    $.ajax({                    
                    url:'<?php echo base_url();?>media_intel_extractions/remove_bookmarks/',
                    type:'POST',
                    dataType :'JSON',
                     data: { entity_id: ent_id},
                    success:function(returnData){
                        
                       
                      
                    }
                    });
                        
                    }
                    else
                        $("."+ent_id).attr('src','<?php echo base_url();?>/css/images/fav.png');
                        
                    }
            });
        
        }
        function do_not_show_entity(do_not_show_ent_id)
        {
            
              $.ajax({                    
                    url:'<?php echo base_url();?>media_intel_extractions/blacklist_entities/',
                    type:'POST',
                    dataType :'JSON',
                     data: { entity_id: do_not_show_ent_id},
                    success:function(returnData){
                        //alert(returnData);
                     $("."+do_not_show_ent_id).parents(".cat_name").hide();;
                     

                    }
            });
            
            
            
            
        }
        var commentExpanded=false;
        var idArray=new Array();
        
        function userComments(id)
        {
            
            var i=0;
            for ( i; i <idArray.length; i++) {
                if (idArray[i] == id) {
                    idArray.splice(i, 1);
                    $('#'+id).slideUp().hide();
                    $('.'+id).empty(); 
                    return false;
                }
                
            }
            var result;
            $('#'+id).slideDown().show();
            idArray.push(id);
              $.ajax({                    
                  
                    url:'<?php echo base_url();?>media_intel_extractions/get_comments/',
                    type:'POST',
                    dataType :'JSON',
                    data:{feed_id:id},
                    success:function(returnData){
                        //alert(returnData);
                      $('.'+id).empty();  
                    for( result in returnData)
                        $('.'+id).append("<div class='previous_comments'><div class='comment_info'><b>Posted by"+" "+returnData[result].first_name+"&nbsp;"+returnData[result].last_name+"</b></div>"+"<p style='margin:4px;  margin-bottom: -18px;'>"+returnData[result].comment+"</p>"+"<br/> "+"<p style='font-size:9px;margin:4px'>"+returnData[result].date+"</p>"+"</div>");

                    }
            });
             
           
        }
     
        function reset_filters()
        {

            reset_value=1;
         $( "#select_feed_type").val("0").change();
         $("#select_feed_type").click();
         $(".cat_name").removeClass("selected_entity");
        
        }
        	<?php if(count($articles)>0)?>
	var arr = <?php echo json_encode($articles);?>;
       
	$(document).ready(function(){
		if(arr != false){
			loadMedia();
		}else{
			$("#actContainer").hide();
			$("#medContainer").css("text-align","center");
			$("#medContainer").html("There are no media");
		}
		if(arr.length <= 10){
			$("#show_more").hide();
		}
	});                                                                                                  
	var limit = 10;
	var total = arr.length;
	var totalPage = Math.ceil(total/10);
	var eachPage = 1;
	var j=0;
	var s=0;
	function loadMedia(){
           
		var arrNew = arr;
               
		for(var i=0; i<arrNew.length; i++){
			var htmlString = '<div id="med_'+s+'" class="med">';
			htmlString += '<div class="fltLft"><div style="margin-right: 5px;" class="fltLft image"></div>';
			htmlString += '<a class="ftchtitle" href="" target="_new">'+arrNew[i].article_title+'</a>';
			htmlString += '<div><label class="publisher">Publisher: </label>'+arrNew[i].publisher_name+'</div>';
			htmlString += '<div class="date"><label>Published on: </label>'+arrNew[i].date+'</div>';
			htmlString += '<div class="description"><label>Description: </label></div>';
			htmlString += '</div></div>';
			$("#medContainer").append(htmlString);
			parse_link(arrNew[i]['url'],"med_"+s);
			s++;
		}
		$("#total").text(total);
		$("#limit").text(s);
		if(arrNew.length == 0 || eachPage >= totalPage){
			$("#show_more").hide();
		}
		eachPage++;
		j = j+10;
		limit = limit+10;
	}
        function parse_link (url,id){
	if(!isValidURL(url)){
		alert('Please enter a valid url.');
		return false;
	}else{
		var urlss = url;//$('#url').val();
		var link = url; 
		var url = escape(urlss);
		// Call API to get a video oEmbed JSON response
		var key = '808c668a99a811e19fef4040aae4d8c9';
		//http://vimeo.com/api/oembed.json?url=http%3A//vimeo.com/7100569
		
		if(urlss.toLowerCase().indexOf("vimeo.com") >= 0)
			$('#videoType').val(2); // vimeo link
		else
			$('#videoType').val(1); // youtube link
			
		var api_url = 'http://api.embed.ly/1/oembed?key=' + key + '&url=' + url + '&callback=?';
		//jQuery JSON call
		$.getJSON( api_url, function(response) {
			//Set Content
//			$("#"+id+' .ftchtitle').html(response.title);
//			$("#"+id+' .publisher').append(response.provider_name);
			$("#"+id+' .ftchtitle').attr("href",link);
			$("#"+id+' .description').append(response.description);
			
			$("#"+id+' .ftchimgz').html(' ');
			if(response.thumbnail_url != undefined ){
				$("#"+id+' .image').append('<img src="'+response.thumbnail_url+'" width="100" height="100" id="1">');
				$("#"+id+' .cur_image').val(1);
			}
		});
	}
}

function isValidURL(url)
{
	var RegExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	
	if(RegExp.test(url)){
		return true;
	}else{
		return false;
	}
}

</script>

 <div class="left_content">
                <?php
                $commentFlag=0;
                $base=base_url();
                if(count($articleArr)>0 || count($articles)>0)
                {
                    if(count($articleArr)>0 )
                    {
                    foreach($articleArr as $value)
                    {
//                        pr($value);
                        $old_date_timestamp = strtotime($value['date']);
                    $new_date = date('M d,Y ', $old_date_timestamp);   
                    echo "<div class=\"feed_url\">";
                    echo "<img class=\"article_image\" src=".$value["img_url"]." align=\"left\" />";
                    
                    
                    echo "<div class=\"article_content\">";
                    echo "<a id=\"hyper\" target=\"_blank\" href=".$value["rss_feed_url"]."><b>".$value['title']."</b></a><br/>";
                    echo "<b>".$value["publisher"].":</b> ".$new_date."<br/>";
                    echo "<p><b></b>".$value["description"]."</p><br/>";
                    echo "</div>";
                        
                       
                        if(count($value['bookmarks'])>0)
                        { 
//                       var_dump($value['bookmarks']['entName']);
//                       exit;
                            echo "<div class='bkmakr_container'>";
                            echo "</div><br/>";
                            echo "<img class=\"fav_image\" src=\"$base/css/images/fav.png\"  /><b style='color:#0F5FFD'>Fav's:</b>";
                            foreach($value['bookmarks']['entName'] as $bookmark){
                               foreach($bookmark as $key=>$values)
                               {
                                    $entityIdName= explode("_", $key);
                                    $id=$entityIdName[0];
                                    $entName=$entityIdName[1];
                                   echo $entName.",&nbsp;";
                               }
                            }
                            echo "<b style='color:#0F5FFD'>Tags:</b>"." ";
                           foreach($value['bookmarks']["tags"] as $tags)
                           {
                             echo  "<i onclick=\"showTags(this)\" class='tags'>#".$tags.",</i> ";
                           }
                           echo "<br/><br/>";
                        }
                   
                    echo "<div id='comment_click' onclick=\"userComments('".$value["rss_feed_url_id"]."')\"><img  style='margin-right:5px' src=\"$base/css/images/Coment.png\"  />Comments(";
                    foreach($comment_count as $commentCount)
                    {
                        if($value["rss_feed_url_id"]==$commentCount["feed_id"])
                        {
                            echo $commentCount["comment_count"];
                            $commentFlag=1;
                        }
                        
                    }
                    if($commentFlag!=1)
                    {
                        echo "0";
                    }
                    echo ")</div>";
                    echo "<span id='".$value["rss_feed_url_id"]."error'></span>";
                      echo "<div class='".$value["rss_feed_url_id"]."'></div><div id='".$value["rss_feed_url_id"]."' class='comments'/><textarea  name='comments' rows='2' cols='10'></textarea><input  id='comment_submit' value='Post' type='button'/>&nbsp;&nbsp;<input  id='cancel_submit' value='Cancel' style='background-color:#ff0000 !important' type='button'/></div>";
                    echo " </div>";
                    $commentFlag=0;
                
                }
                }
                if(count($articles)>0)
                {
                //  pr($articles);
                       
                    echo "<div id='medContainer' class=\"feed_url\">";
                   
                    echo "</div>";
                     
                }
                }
                else
                {
                    echo "No articles found";
                }
                ?>
                
         
            </div>

