<?php
/*
 * To display generated seed data for particular survey
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.18
 * Created on	: 18-06-2013
 *  
 */
?>
<div>
	<table id="surveyDetails">
		<?php echo $textData;?>
			<?php /*
				$i=0; 
				foreach($arrSurveys as $categoryName => $arrSurveys){
				 foreach($arrSurveys as $key => $arrRow){
					$i++;
				?>
					<tr class="tableSubHeader">
						<th class="alignTop borderBottom"><?php echo $i;?>)</th>
						<th class="borderBottom" colspan="6"><?php echo $arrRow['question'];?> ( Tags: <?php echo $arrTypes[$arrRow['type_id']].', '.$categoryName.', '.$arrRow['role'];?> )</th>
					</tr>
					<tr>
						<th></th>
						<th class="alignCenter">Respondent</th>
						<th class="alignCenter">Influencer</th>
						<th class="alignCenter">Organization</th>
						<th class="alignCenter">City</th>
						<th class="alignCenter">State</th>
						<th class="alignCenter">Country</th>
						<th class="alignCenter">Postal Code</th>
					</tr>
			<?php
					foreach($arrRespondents as $key=>$arrRow){
						$rand_keys = array_rand($arrInfluencers, 5);
						foreach($rand_keys as $index=>$influencersIndex){
							if($arrRow['name']==$arrInfluencers[$influencersIndex]['name']){
								$influencersIndex++;
							}
				?>
								<tr>
									<td></td>
									<td><?php echo $arrRow['name'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['name'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['orgname'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['city'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['state'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['country'];?></td>
									<td><?php echo $arrInfluencers[$influencersIndex]['postal'];?></td>
								</tr>
				<?php 		}
					}
				}
			}*/ ?>
		</table>
		<?php //pr($arrInfluencers);?>
</div>