<script src="http://localhost/hmvc/assets/js/jquery.validate1.9.min.js"></script>
<script type="text/javascript">
var base_url = "<?php echo base_url(); ?>";
var orgId = '<?php echo $orgId;?>';
$(document).ready(function(){
	
});

</script>
<script>


	$(document).ready(function(){
		<?php 
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
				$this->output->set_header("Pragma: no-cache"); 
			?>
		
		$("#keyPeopleForm").validate({
			debug:false,
			onkeyup:false,
			rules: validationRules,
			messages: validationMessages
		});
	});


	var validationRules	=  {
			role_id: {
				required:true
			},
			salutation: {
				required:true
			}, 
			first_name: {
				required:true
			},			
			email: "email"
		};

		var validationMessages = {
			role_id: {
					required:"Required"
				},
			salutation: {
				required:"Required"
			},
			first_name: {
					required: "Required"
			}		
		};
	function save(){
		if(!$("#keyPeopleForm").validate().form()){
			return false;
		}
		$('.uniMsgBox').removeClass('success');
		$('.uniMsgBox').addClass('notice');
		$('.uniMsgBox').show();

		$('.uniMsgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

		var id = $('#id').val();
		
		if(id==''){
			var action  ='<?php echo base_url()?>organizations/save_key_people/'+orgId;
		}else{
			var action  ='<?php echo base_url()?>organizations/update_key_people/'+orgId;
		}
		$.ajax({
			url:action,
			data:$('#keyPeopleForm').serialize(),
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved){
					$('div.uniMsgBox').removeClass('error');
					$('div.uniMsgBox').addClass('success');
					$('.uniMsgBox').html("Saved Successfully.")
				}
			}

		});

	}
</script>
<style>
label.error {
    color: #ff0000 !important;
}
.object-name {
    display: inline-block;
}
.panel{
border-radius:0px !important;
}
.panel-group .panel+.panel {
    margin-top: 0px !important;
}
.panel-title {
    font-size: 13px !important;
    font-weight: bold;
}
.title{
	font-size: 14px;
	margin-top: 20px;
    font-weight: bold;
    border-bottom:1px dashed #ccc;
}
.box-background{
	background: #f4f4f4;

}
.top-buttons{
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 5px;
    font-size: 12px;
}
.glyphicon { margin-right:10px; }
.panel-body { padding:0px; }
.panel-body table tr td { padding-left: 15px }
.panel-body .table {margin-bottom: 0px; }
.org-box{margin-bottom:10px;padding :10px; min-height: 190px;}
.border-box{ border:1px solid #ccc;} 
.subnotes{margin-top:10px;}
input[type=file] {
    display: inline !important;
}
.organization-container-head{
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,f4f4f4+47,c9c9c9+100 */
background: #ffffff; /* Old browsers */
background: -moz-linear-gradient(top,  #f0f0f0 0%, #f4f4f4 47%, #c9c9c9 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f0f0f0', endColorstr='#c9c9c9',GradientType=0 ); /* IE6-9 */
	
}
p.profileName {
    margin-bottom: 0px;
    font-weight: bold;
    text-align: center;
}
#organizationShortDetails {
    text-align: center;
    width: 100%;
    background: #ffffff;
    padding: 10px 0;
    color: #000000;
    font-weight: bold;
    border-top: 1px solid #ccc;
}
.top-header{
	padding:5px 0;
}
.margin-zero{
	margin-top:0 !important;
}
/*key people css */
.tab-pane{
	border-left:1px solid #ccc;
	border-right:1px solid #ccc;
	border-bottom:1px solid #ccc;
	padding: 10px;
	height: 100%;
}
.content{
	min-height: 600px;
}
</style>
<script>

$(document).ready(function(){
	$("#subOrgForm").validate({
		debug:false,
		onkeyup:false,
		rules: validationRules,
		messages: validationMessages
	});
});


var validationRules	=  {
		name: {
			required:true
		},
		
		socialUrl: {
			url: true
		},

		email: "email"
	};

	var validationMessages = {
		name: {
				required: "Required"
		},
		url: "Please enter a valid URL address"
	};
	function saveSubOrg(){
		if(!$("#subOrgForm").validate().form()){
			return false;
		}
		$('.uniMsgBox').removeClass('success');
		$('.uniMsgBox').addClass('notice');
		$('.uniMsgBox').show();

		$('.uniMsgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');
		var country = $('#countryId1 option:selected').text();
		var state = $('#stateId1 option:selected').text();
		var city = $('#cityId1 option:selected').text();
		if($('#countryId1').val()==''){
			country='';
		}
		if($('#stateId1').val()==''){
			state='';
		}
		if($('#cityId1').val()==''){
			city='';
		}

		var id = $('#id').val();
		
		if(id==''){
			var url = '<?php echo base_url()?>organizations/save_sub_org/'+orgId;
		}else{
			var url = '<?php echo base_url()?>organizations/update_sub_org/';
		}
		$.ajax({
			url:url,
			data:$('#subOrgForm').serialize(),
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.status=='Saved'){
					
					$('div.uniMsgBox').removeClass('error');
					$('div.uniMsgBox').addClass('success');
					$('.uniMsgBox').html("Saved Successfully.");
					setTimeout(closeDialog,1000);
				}else{

					$('div.uniMsgBox').removeClass('success');
					$('div.uniMsgBox').addClass('error');
					$('.uniMsgBox').html("Entered Organization is already exists.");
				}
				
			}

		});

	}

	function closeDialog(){
		$('#addSubOrg').dialog("close");
		subOrgListView();
		setTimeout(function(){ $('#toggleKeyPeopleGrouping').click(); }, 200);
	}

	function getStatesByCountryId(idName){
		var countryId=$('#countryId' + idName).val();
		var params = "country_id="+countryId;	
		var selectedStateId = '';
		$("#stateId" + idName).html("<option value=''>-- Select State --</option>");
		$("#cityId" + idName).html("<option value=''>-- Select City--</option>");
		var states = document.getElementById('stateId' + idName);
		$.ajax({
			url: "<?php echo base_url()?>helpers/country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){		
				var selectedIndex	= '';			
				$.each(responseText, function(key, value) {					
					/* var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev); */	
					 selectedIndex	= '';
						if(states>0 && states===value.state_id){
							selectedIndex	= ' selected="selected"';
						}
						$("#stateId" + idName).append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>'); 			
					});
                                        
             /*    $("#stateId option[value='']").remove();
                $("#stateId").prepend("<option value=''>-- Select State --</option>");
                $("#stateId").val(""); */
			}		
		});		
		
	}

	function getCitiesByStateId(idName){
		
		var stateId=$('#stateId' + idName).val();
		
		$("#cityId" + idName).html("<option value=''>-- Select City --</option>");	
		var cities = document.getElementById('cityId' + idName);
		var params = "state_id="+stateId;	
		var selectedCityId = '';
		$.ajax({
			url: "<?php echo base_url()?>helpers/country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){
				var selectedIndex	= '';					
				$.each(responseText, function(key, value) {	
							
				/* var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);	 */	
					selectedIndex	= '';
 					if(selectedCityId>0 && selectedCityId===value.city_id){
 						selectedIndex	= ' selected="selected"';
 					} 
 					$("#cityId" + idName).append('<option value="'+value.city_id+'"'+selectedIndex+'>'+value.city_name+'</option>');		
				});		
				/* $("#cityId option[value='']").remove();
                    $("#cityId").prepend("<option value=''>-- Select City --</option>");
                    $("#cityId").val(""); */
			}		
		});		
		
	}

</script>
<div class="row top-header">
	<?php $this->load->view('organizations/organization_header_bar'); ?>
</div>
<div class="row">
		<div class="secondary-menu col-md-2" style="padding-right: 0px;padding-left: 0px;">
			<?php $this->load->view('organizations/organization_left_side_bar'); ?>
		</div>
		<div class="content col-md-10" style="border-left: 1px solid #ccc;">
<div class="container box">
	<div class="msgBoxContainer"><div class="uniMsgBox"></div></div>
	<form action="save_sub_org" method="post" id="subOrgForm" name="universityForm" class="validateForm form-horizontal">
	        <input type="hidden" name="id" id="id" value="<?php if($arrDetail!='') echo $arrDetail['id'] ?>"/>
				<h4 class="page-header" style="margin-top:0px;"><?php if($arrDetail!='') echo 'Edit'; else echo 'New';?> Affiliate</h4>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Institute Name <span class="error">*</span>  :</label>
						<div class="col-sm-4">
							<input type="hidden" name="institute_id" id="uniNameId"/>
							<input type="text" name="name" id="name" class="required form-control" value="<?php if($arrDetail!='') echo $arrDetail['name'] ?>" placeholder="First Name"/>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Country :</label>
						<div class="col-sm-4">
							<select name="country_id" id="countryId1" class="form-control" onchange="getStatesByCountryId(1);">
							<option value="">-- Select country --</option>
							<?php foreach( $arrCountry as $country ){ 
									if($country['country_id']==$arrDetail['country_id']){
								?>
									<option value="<?php echo $country['country_id'];?>" selected="selected">
										<?php echo $country['country_name'];?>
									</option>
							<?php }else{?>
							
								<option value="<?php echo $country['country_id'];?>" >
										<?php echo $country['country_name'];?>
									</option>
								
							<?php }}?>
							</select>
						</div>
						<label class="col-sm-2 control-label">State / Province :</label>
						<div class="col-sm-4">
							<select name="state_id" id="stateId1" class="form-control" onchange="getCitiesByStateId(1);">		
								<option value="">--Select State--</option>
								<?php foreach( $arrStates as $state){
									if($state['state_id'] == $arrDetail['state_id'])
										echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
									else
										echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
								}
								?>
                            </select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">City :</label>
						<div class="col-sm-4">
							<select name="city_id" id="cityId1" class="form-control">
								<option value=""> --Select City--</option>
								<?php 
									foreach( $arrCities as $city){
										if($city['city_id'] == $arrDetail['city_id'])
											echo '<option value="'.$city['city_id'].'" selected="selected">'.$city['city_name'].'</option>';
										else
											echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
									}
								?>	
                            </select>
						</div>
						<label class="col-sm-2 control-label">Postal Code :</label>
						<div class="col-sm-4">
							<input type="text" name="postal_code" value="<?php if($arrDetail!='') echo $arrDetail['postal_code'] ?>" id="postalCode" class="form-control" placeholder="Title"/>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Phone :</label>
						<div class="col-sm-4">
							<input type="text" name="phone" id="phone" value="<?php if($arrDetail!='') echo $arrDetail['phone'] ?>" class="form-control" placeholder="Email Id"/>
						</div>
						<label class="col-sm-2 control-label">NPI Number :</label>
						<div class="col-sm-4">
							<input type="text" name="npi_num" id="npiNum" value="<?php if($arrDetail!='') echo $arrDetail['npi_num'] ?>" class="form-control" placeholder="Department"/>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label">Address :</label>
						<div class="col-sm-4">
							<input type="text" name="address" id="address" value="<?php if($arrDetail!='') echo $arrDetail['address'] ?>" class="form-control" placeholder="Email Id"/>
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-sm-offset-5  col-sm-2">
							<button type="button" name="submit" id="saveSubOrg1" onclick="saveSubOrg()" class="btn btn-primary btn-label-left">
							<span><i class="fa fa-clock-o"></i></span>
								Save
							</button>
							<button type="cancel" class="btn btn-default btn-label-left">
							<span><i class="fa fa-clock-o txt-danger"></i></span>
								Cancel
							</button>
						</div>
					</div>
	</form>
</div>
		</div>
</div>