<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<script type="text/javascript">
function list_module_grid(){
    var client_id = $('#client_id').val();
	$('#gridModuleListing').html('');
    $('#gridModuleListing').html('<div class="gridWrapper"><div id="gridModuleListingPagintaion"></div><table id="gridModuleListingResultSet"></table><div>');
    grid = $("#gridModuleListingResultSet");
    grid.jqGrid({
		url:'<?php echo base_url();?>configurations/configurations/load_grid_modules/'+client_id,
		datatype: "json",
		colNames:['Id','Module_Name','Version','Author','Assigned?'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'module_name',index:'module_name', search:true},
	   		{name:'version',index:'version', search:true},
	   		{name:'author',index:'author', search:true},
	   		{name:'assigned',index:'assigned', search:false,align:'center'}	   		
	   	],       
	   	rowNum:10,
	   	multiselect: true,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	height: "auto",		 
	   	pager: '#gridModuleListingPagintaion',
	   	mtype: "POST",
	   	sortname: 'module_name',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    gridComplete: function(){	
	    	var arrIds = jQuery("#gridModuleListingResultSet").jqGrid('getDataIDs'); 
	    	for(var i=0;i < arrIds.length;i++){ 
		    	signal='';
		    	var id = arrIds[i];
		    	var arrId =  jQuery('#gridModuleListingResultSet').jqGrid ('getRowData', arrIds[i]);
		    	var is_assigned = arrId.assigned;
		    	if(is_assigned==1)
		    		signal='<span class="glyphicon glyphicon-stop module_assigned_green_signal"></span>';
		    	else
			    	signal='<span class="glyphicon glyphicon-stop module_assigned_red_signal"></span>';
		    		jQuery("#gridModuleListingResultSet").jqGrid('setRowData',id,{assigned:signal});
		    } 
	    },
	    caption:"List Modules"
	});
	grid.jqGrid('navGrid','#gridModuleListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
}
$(document).ready(function(){	
	var moduleClientsDialogOpts = {
			title: "Associate Clients",
			modal: true,
			autoOpen: false,
			resizable: true,
			height:'auto',
			width: 350,
			dialogClass: "microView",
			open: function() {
			},
			close:function(){
			}
	};
	$("#moduleContainer").dialog(moduleClientsDialogOpts);
	list_module_grid();	
	jQuery("#associate_btn").click( function() {
		var s;
		s = jQuery("#gridModuleListingResultSet").jqGrid('getGridParam','selarrrow');
		if(s.length>=1){
			associateClients(s,1);
		}
        else
        	alert("please select one or more modules");
	});	
	jQuery("#dissociate_btn").click( function() {
		var s;
		s = jQuery("#gridModuleListingResultSet").jqGrid('getGridParam','selarrrow');
		if(s.length>=1){
			associateClients(s,0);
		}
        else
        	alert("please select one or more modules");
	});	
});
function closeModal(){
	$("#moduleContainer").dialog("close");
}

function modal_to_instal_module(){
	$(".addModuleclientContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#moduleContainer").dialog("open");
	$('#ui-dialog-title-moduleContainer').html('Instal module');
	$(".addModuleclientContent").load('<?php echo base_url().'configurations/configurations/install_module'?>');
}
function save_module()
{
	var isValid = true;
	isValid=$("#moduleImportForm").validate().form();
	if(!isValid){
		return isValid;
	}
	var form = $('#moduleImportForm')[0];
	var data = new FormData(form);
      $.ajax({
   	  url:'<?php echo base_url();?>configurations/configurations/upload_zip_file',
        type: "POST",
        data:  new FormData(form),
        dataType:'json',
        enctype: 'multipart/form-data',
        processData: false,  // Important!
        contentType: false,
        cache: false,
        success:function(returnData){ 
            	if(returnData.status==true){
                	list_module_grid();
                	closeModal();
                	showMessageInSnackbar(returnData.message);
            	}
            	else
            	{
            		$('#responseMessageOfModuleInstal').html(returnData.message);
            	}
		 	},
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error in adding / update data');
        }
    });
}
function associateClients(module_ids,is_associate){
	client_id = $('#client_id').val();
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>configurations/configurations/associate_or_disassociate_module',
		data:"module_ids="+module_ids+"&client_id="+client_id+"&is_associate="+is_associate,
		datatype:'json',
		success:function(returnData){
			if(!status){
				showMessageInSnackbar("Selected modules are successfully changed");
			} else {
				showMessageInSnackbar("Operation failed");
			}
			list_module_grid();
	 	},
	 	error:function(){
	 		showMessageInSnackbar("Operation failed");
		}
	 });		
}
</script>
<div style="margin:10px 0px;">
	<p style="display: inline">Select Client:</p>
	<select name="client_id" id="client_id" class="form-control required" onchange="list_module_grid();" style="width:12%;display: inline">
			<?php foreach($arrClients as $client){	?>
			<option value="<?php echo $client['id'];?>">
					<?php echo $client['name'];?>
				</option>
			<?php }?>
	</select>
	<div class="pull-right">
		<a class="btn btn-default " id="associate_btn" >Associate Module</a>
		<a class="btn btn-default " id="dissociate_btn" >Dissociate Module</a>
		<a class="btn btn-default" onclick="modal_to_instal_module()">Install-Module</a>
	</div>
</div>
<div id="gridModuleListing" class="gridWrapper">
		<div id="gridModuleListingPagintaion"></div>
		<table id="gridModuleListingResultSet"></table>
</div>
<div id="moduleContainer" class="microViewLoading">
	<div class="addModuleclientContent"></div>
</div>