<?php
/**
* Description: Lists the Clients
* Created by:Vinayak
* Created on:March 4, 2011
* @since 1.5
*/
?>
	<!-- 2nd Plugin for Validation -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	<style type="text/css">
			div a{	
				text-decoration:none;
				text-align:left;
				float:right;
				}
		p.addLink{
			margin:0px;
			text-align: right;
		}
		p.addLink a{
			text-decoration:none;
			text-align:right;
			font-size:95%;
			clear:both;
		}
		tr.selectedRow {
		    background-color: #D8DFEA !important;
		}
	</style>
	<script language="javascript" >
	$(document).ready(function(){
		
			$('#listClients table tbody tr').each(function (index){
				$(this).bind('click',function(){
					$('#listClients table tbody tr.selectedRow').removeClass('selectedRow');
					$(this).addClass('selectedRow');
				});
				$(this).bind('mouseover',function(){
					$(this).css('background',"#D0E5F5");
				});
				$(this).bind('mouseout',function(){
					$(this).css('background','#ffffff');
				});
			});
		});
	</script>
	<script type="text/javascript">


 	function saveClient(){
			
			if(!$('#saveClientForm').validate().form()){
				return false;
	 		}

			$('div.clientMsgBox').removeClass('success');
			$('div.clientMsgBox').addClass('notice');
			$('div.clientMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			var id=$('#clientId').val();
	 		if(id==''){
		 		formAction ='<?php echo base_url()?>client_users/save_client';

	 		}else{
	 			formAction ='<?php echo base_url()?>client_users/update_client';
	 		}

			$.ajax({
				url:formAction,
				type:'post',
				dataType:'json',
				data:$('#saveClientForm').serialize(),
				success:function(returnData){
				$('div.clientMsgBox').text(returnData.msg);
						if(returnData.saved==true){
						if(id==''){
								$("tr.recentlyAddedRow").removeClass('recentlyAddedRow');
									//$newRecord = "<tr class='recentlyAddedRow' id='U_"+returnData.lastinsertId+"'>";
								$newRecord="<tr class='recentlyAddedRow' id='c_"+returnData.lastInsertId+"'>";
								$newRecord+="<td>"+returnData.arrClient.name+"</td>";
								$newRecord+="<td>"+returnData.arrClient.notes+"</td>";
								$newRecord+="<td><a onclick='editClient("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url();?>images/edit.png'></a></td>";
								$newRecord+="<td><a onclick='editClient("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url();?>images/delete.png'></a></td>";
								$newRecord+="</tr>";
								$('.listClientResultSet').prepend($newRecord);

								$('div.clientMsgBox').show();
								$('div.clientMsgBox').fadeOut(3000);
								setTimeout(closeDialogAdd,1000);	
						}else{
								$("#c_"+id).removeClass('recentlyAddedRow');
								var newRecord='';
								newRecord+="<td>"+returnData.arrClient.name+"</td>";
								newRecord+="<td>"+returnData.arrClient.notes+"</td>";
								newRecord+="<td><a onclick='editClient("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url();?>images/edit.png'></a></td>";
								newRecord+="<td><a onclick='editClient("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url();?>images/delete.png'></a></td>";
								$('#c_'+returnData.lastInsertId).html(newRecord);
								$('div.clientMsgBox').show();
								$('div.clientMsgBox').fadeOut(3000);
								setTimeout(closeDialogEdit,1000);	
						}
						
					}else{
						$('div.clientMsgBox').show();
						$('div.clientMsgBox').fadeOut(10000);
						}

				}
			});
	 	}





		function closeDialogAdd(){
			$("#clientContainer").dialog("close");
		}

		function closeDialogEdit(){
			$("#clientContainer").dialog("close");
		}

		function addClient(){
			$(".addClientContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#clientContainer").dialog("open");
			//$("#clientContainer").dialog({autoOpen: true, position: "top"}).dialog("widget").css({"position":"fixed", "top":"0"}).animate({top:"40%"}, 1000);
			$(".addClientContent").load('<?php echo base_url().'client_users/add_client/'?>');
			return false;	
		}

		function editClient(clientId){
			window.location = '<?php echo base_url().'client_users/edit_client/'?>'+clientId;
			return false;
		}
		

		function deleteClient(id){
			jConfirm("Are you sure to remove this event","Please confirm",function(r){
					if(r){
						$('#c_'+id).remove();
						$.ajax({
							url:'<?php echo base_url()?>client_users/delete_client/'+id,
							type:'post',
							dataType:'json',
							sucess:function(){
							}
						});
						}else{
								return false;
							}
				});
		}


		$(document).ready(function(){
			var clientProfileDialogOpts1 = {
					title: "Add Client",
					modal: true,
					autoOpen: false,
					height: 250,
					width: 450,
					dialogClass: "microView",
					open: function() {
				
				//display correct dialog content
					}
			};
			$("#clientContainer").dialog(clientProfileDialogOpts1);


			var clientEditProfileDialogOpts = {
					title: "Edit Client",
					modal: true,
					autoOpen: false,
					height: 250,
					width: 450,
					open: function() {
						//display correct dialog content
					}
			};
			$("#clientEditContainer").dialog(clientEditProfileDialogOpts);
		});


		

	</script>
<div id="listClients">		
	<p class="addLink clear">
		 <!-- <a href="#" onclick="addClient();"><img style="height: 30px;vertical-align: middle;"  src="<?php echo base_url();?>images/bullet_add.png" border="0" />Add New Client</a> -->
		 <a href="<?php echo base_url()?>client_users/add_client"><img style="height: 30px;vertical-align: middle;"  src="<?php echo base_url();?>images/bullet_add.png" border="0" />Add New Client</a>
	</p>
	

	<table class="listResultSet listClientResultSet">
		<caption>List of Clients</caption>
		<thead>
			<tr>
				
				<th width="30%">Name</th>
				<th width="30%">Notes</th>
				<th width="30%">Support Email ID</th>
				<th width="10%" colspan="2">Action</th>
			</tr>
		</thead>	
			<?php 
			foreach($arrClients as $i => $row){
				$rowId="c_".$row['id'];
			?>
				<tr id='<?php echo $rowId;?>'>
					
					<td><?php echo $row['name'];?></td>
					<td><?php echo $row['notes'];?></td>
					<td><?php echo $row['support_email_id'];?></td>
					<?php echo '<td><a href="#" onclick="editClient('.$row['id'].')"><img title="Edit" src="'.base_url().'images/edit.png"></a></td>'?>
				<?php echo '<td><a href="#" onclick="deleteClient('.$row['id'].')"><img title="Delete" src="'. base_url().'images/delete.png"></a></td>'?>
				</tr>
			<?php }?>
	</table>	
</div>	
<!-- modal content -->
		
	<!--End of content -->	
	<!-- Container for the 'Edit Payments' modal box -->
	<div id="dailog3">	
		<div id="clientContainer" class="microProfileDialogBox">
			<div class="addClientContent"></div>
		</div>
	</div>