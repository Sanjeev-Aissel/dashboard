<?php 
/**
 * 
 * View page contains List of Rejected KOls
 * @author Vinayak
 * @since 4.2
 * @package application.view.requested_kols
 * @created 13-6-2012
 */
?>
<p>Hello,</p><p>Your KOL request has been rejected by your Manager.</p>

<p>Following are the rejected KOL'S</p>
<?php foreach($arrKols as $row){
	
?><li>
<p><b>KTL Name: <?php echo $row['first_name']." ".$row['middle_name']." ".$row['last_name'];?></b></p>
<br /></li>
<?php }?>

<p>Thanks,</p>
<p>KOLM Support</p>