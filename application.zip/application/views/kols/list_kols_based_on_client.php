<style>
.form-table{
	margin-top: 15px;
	margin-bottom: 15px;
}
input[type=checkbox]{
	top: 0.19em;
}
.btn{
	margin-bottom: 3px;
	float: right;
	display:none;
}
.msg{
	float: right;
    margin-right: 10px;
    margin-top: 5px;
}
.setting-dorpdowns{
	float: left;
	display: inline;
	margin-right: 20px;
	display: none;
}
.setting-dorpdowns button{
	top: 0;
	margin-left: 5px;
}
.horizontal-line{
	width: 100%;
    height: 1px;
    background-color: #ddd;
    margin-top: 15px;
    margin-bottom: 15px;
}
</style>

<table class="form-table">
		<tbody>
			<tr>
				<td style="width: 50px;"><label for="client">Client <span class="required">*</span></label></td>
				<td style="width: 150px;">
					<select name="client" id="client">
						<option value="">--Select Client--</option>
						<?php 
							foreach ($arrClientList as $arrList){
						?>
						<option value="<?php echo $arrList['id'];?>"
							<?php 
								if(isset($previouslySelectedClientId)){
									if($previouslySelectedClientId == $arrList['id']){
										echo 'selected';
									}
								}
							?>
						><?php echo $arrList['name']; ?></option>
						<?php 
							}
						?>
					</select>
				</td>
				<td><button style="top: 0;" onclick="get_kols_associated_with_client();">Submit</button></td>
			</tr>
			<tr>
				<td>&nbsp;<input type="hidden" name="kol_id" id="kol_id"/></td>
				<td><span style="display: none;" id="errorMsg"></span></td>
			</tr>
		</tbody>
</table>

<div class="horizontal-line" style="display: none;"/></div>
<button class="btn" onclick="associateOrDisassociateKols('#JQBlistClientKolsDetails');">Disassociate</button>

<?php $userRoleId = $this->session->userdata('user_role_id');?>
<div class="setting-dorpdowns">
	<label>Set Status:</label>
	<select name="update_kol_status" id="updateKolStatus">
		<option value="">Select</option>
		<option value="<?php echo New1?>">New</option>
		<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
		<option value="<?php echo APPROVED?>">Approved</option>
		<?php }?>
		<option value="<?php echo PROFILING?>">Profiling</option>
		<option value="<?php echo REVIEW?>">Review</option>
			<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
		<option value="<?php echo COMPLETED?>">Completed</option>
		<?php }?>
	</select>
	<button onclick="updateStatus('#JQBlistClientKolsDetails','updateKolStatus')">Save</button>
</div>

<div class="setting-dorpdowns">
	<label>Pubmed Status:</label>
	<select name="update_pubmed_status" id="updatePubmedStatus">
		<option value="">Select</option>
		<option value="0">No</option>
		<option value="1">Yes</option>
		<option value="2">Recrawl</option>
	</select>
	<button onclick="updateStatus('#JQBlistClientKolsDetails','updatePubmedStatus')">Save</button>
</div>

<div class="setting-dorpdowns">
	<label>Trial Status:</label>
	<select name="update_trial_status" id="updateTrialStatus">
		<option value="">Select</option>
		<option value="0">No</option>
		<option value="1">Yes</option>
	</select>
	<button onclick="updateStatus('#JQBlistClientKolsDetails','updateTrialStatus')">Save</button>
</div>


<div id="disassociateMsg" class="msg">&nbsp;<span></span></div>
<div class="gridWrapper" id="gridClientKolsContainer">
	<table id="JQBlistClientKolsDetails"></table>
	<div id="listClientKolsDetailsPage"></div>
</div>

<div class="spaceBtwList">&nbsp;</div>
<div class="horizontal-line" style="display: none;"/></div>
<button class="btn" onclick="associateOrDisassociateKols('#JQBlistNotClientKolsDetails');">Associate</button>

<div class="setting-dorpdowns">
	<label>Set Status:</label>
	<select name="update_kol_status1" id="updateKolStatus1">
		<option value="">Select</option>
		<option value="<?php echo New1?>">New</option>
		<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
		<option value="<?php echo APPROVED?>">Approved</option>
		<?php }?>
		<option value="<?php echo PROFILING?>">Profiling</option>
		<option value="<?php echo REVIEW?>">Review</option>
			<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
		<option value="<?php echo COMPLETED?>">Completed</option>
		<?php }?>
	</select>
	<button onclick="updateStatus('#JQBlistNotClientKolsDetails','updateKolStatus1')">Save</button>
</div>

<div class="setting-dorpdowns">
	<label>Pubmed Status:</label>
	<select name="update_pubmed_status1" id="updatePubmedStatus1">
		<option value="">Select</option>
		<option value="0">No</option>
		<option value="1">Yes</option>
		<option value="2">Recrawl</option>
	</select>
	<button onclick="updateStatus('#JQBlistNotClientKolsDetails','updatePubmedStatus1')">Save</button>
</div>

<div class="setting-dorpdowns">
	<label>Trial Status:</label>
	<select name="update_trial_status1" id="updateTrialStatus1">
		<option value="">Select</option>
		<option value="0">No</option>
		<option value="1">Yes</option>
	</select>
	<button onclick="updateStatus('#JQBlistNotClientKolsDetails','updateTrialStatus1')">Save</button>
</div>

<div id="associateMsg" class="msg">&nbsp;<span></span></div>
<div class="gridWrapper" id="gridNotClientKolsContainer">
	<table id="JQBlistNotClientKolsDetails"></table>
	<div id="listNotClientKolsDetailsPage"></div>
</div>

<div class="spaceBtwList">&nbsp;</div>

<div id="exportKolsDialog">	
	<div id="exportKolsContainer" class="microProfileDialogBox">
		<div class="profileContent" id="exportKolsProfileContent"></div>
	</div>
</div>



<script>

$(document).ready(function(){
	// Settings for the Dialog Box
	var modalBoxAddOpts = {
			title: "",
			modal: true,
			autoOpen: false,
			width: 600,
			dialogClass: "microView",
			position: ['center', 160],
			open: function() {
				//display correct dialog content
			}
	};
	$("#exportKolsContainer").dialog(modalBoxAddOpts);

<?php if($previouslySelectedClientId){?>
getKolsAssociatedWithClient(<?php echo $previouslySelectedClientId?>);
getKolsNotAssociatedWithClient(<?php echo $previouslySelectedClientId?>);
<?php } ?>
});

function get_kols_associated_with_client(){
	var clientId = $("#client").val();
	if(clientId=='')
	{
		$("#errorMsg").css('color','red');
		$("#errorMsg").text('Please choose client');
		$("#errorMsg").show();
	}
	else
	{
		$("#errorMsg").hide();
		getKolsAssociatedWithClient(clientId);
	}
	return false;
}

function getKolsAssociatedWithClient(clientId){
	$("#gridClientKolsContainer").html("");
	$("#gridClientKolsContainer").html('<table id="JQBlistClientKolsDetails"></table><div id="listClientKolsDetailsPage"></div>');

	var ele=document.getElementById('gridClientKolsContainer');
	
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridClientKolsContainer').width();
	jQuery("#JQBlistClientKolsDetails").jqGrid({
		url: base_url + 'kols/get_kols_associated_with_client/'+clientId,
		datatype: "json",
		colNames:['Id','Name','Speciality','Gender','Organization','Pubmed ?','Trials ?','Created By','Pin','Status', 'Action'],
		colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'kol_link',index:'kol_link', search:true},
					{name:'kol_speciality',index:'kol_speciality', width:100, search:true},
					{name:'kol_gender',index:'kol_gender', width:50, search:true, resizable:false},
			   		{name:'kol_org',index:'kol_org', search:true},
			   		{name:'is_pubmed_processed',index:'is_pubmed_processed', width:50, resizable:false},
			   		{name:'is_clinical_trial_processed',index:'is_clinical_trial_processed', width:50, resizable:false},
			   		{name:'kol_created_by',index:'kol_created_by', width:80, search:true},
			   		{name:'kol_pin',index:'kol_pin', width:100, search:true},
			   		{name:'kol_status',index:'kol_status', width:60, search:true},
			   		{name:'action',index:'action',width:30, align:'center',search:false, resizable:false}
			   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listClientKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"KOLs Associated With Client",
   		rowList:paginationValues,
		gridComplete: function(){ 
						
						var pubmedValue = '';
						var trialValue = '';
						var ids = jQuery("#JQBlistClientKolsDetails").jqGrid('getDataIDs');
	         			for (var i = 0; i < ids.length; i++) {
	        				var rowId = ids[i];
	        				var isPubmedProcessed = jQuery('#JQBlistClientKolsDetails').jqGrid ('getCell',rowId,'is_pubmed_processed');
							if(isPubmedProcessed == '1'){
								pubmedValue = 'Yes';
							}else{
								pubmedValue = 'No';
							}
	        				jQuery("#JQBlistClientKolsDetails").jqGrid('setRowData', ids[i], {is_pubmed_processed: pubmedValue});

	        				var isTrialProcessed = jQuery('#JQBlistClientKolsDetails').jqGrid ('getCell',rowId,'is_clinical_trial_processed');
							if(isTrialProcessed == '1'){
								trialValue = 'Yes';
							}else{
								trialValue = 'No';
							}
	        				jQuery("#JQBlistClientKolsDetails").jqGrid('setRowData', ids[i], {is_clinical_trial_processed: trialValue});

	        				var kolId = jQuery('#JQBlistClientKolsDetails').jqGrid ('getCell',rowId,'id');
	        				var act = '';
	        				
							act += '<div class="actionIcon editIcon"><a href="'+base_url+'kols/edit_kol/'+kolId+'" title="Edit">&nbsp;</a></div>';
							act += '<div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols('+kolId+',1);" href="#" title="Delete">&nbsp;</a></div>';

							jQuery("#JQBlistClientKolsDetails").jqGrid('setRowData', ids[i], {action: act});
	        				
	         			}
	         			getKolsNotAssociatedWithClient(clientId);
	    }
	});
	
	jQuery("#JQBlistClientKolsDetails").jqGrid('navGrid','#listClientKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistClientKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistClientKolsDetails").jqGrid('navButtonAdd',"#listClientKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistClientKolsDetails").jqGrid('setGridWidth',gridWidth); 

}


function getKolsNotAssociatedWithClient(clientId){
	$("#gridNotClientKolsContainer").html("");
	$("#gridNotClientKolsContainer").html('<table id="JQBlistNotClientKolsDetails"></table><div id="listNotClientKolsDetailsPage"></div>');
	var ele=document.getElementById('gridNotClientKolsContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridNotClientKolsContainer').width();
	jQuery("#JQBlistNotClientKolsDetails").jqGrid({
		url: base_url + 'kols/get_kols_not_associated_with_client/'+clientId,
		datatype: "json",
		mtype: 'POST',
		colNames:['Id','Name','Speciality','Gender','Organization','Pubmed ?','Trials ?','Created By','Pin','Status', 'Action'],
		colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'kol_link',index:'kol_link', search:true},
					{name:'kol_speciality',index:'kol_speciality', width:100, search:true},
					{name:'kol_gender',index:'kol_gender', width:50, search:true, resizable:false},
			   		{name:'kol_org',index:'kol_org', search:true},
			   		{name:'is_pubmed_processed',index:'is_pubmed_processed', width:50, resizable:false},
			   		{name:'is_clinical_trial_processed',index:'is_clinical_trial_processed', width:50, resizable:false},
			   		{name:'kol_created_by',index:'kol_created_by', width:80, search:true},
			   		{name:'kol_pin',index:'kol_pin', width:100, search:true},
			   		{name:'kol_status',index:'kol_status', width:60, search:true},
			   		{name:'action',index:'action',width:30, align:'center',search:false, resizable:false}
			   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listNotClientKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"KOLs Not Associated With Client",
   		rowList:paginationValues,
		gridComplete: function(){ 
						$(".btn").show();
						$(".setting-dorpdowns").show();
						$(".horizontal-line").show();
						
						var pubmedValue = '';
						var trialValue = '';
						var ids = jQuery("#JQBlistNotClientKolsDetails").jqGrid('getDataIDs');
	         			for (var i = 0; i < ids.length; i++) {
	        				var rowId = ids[i];
	        				var isPubmedProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_pubmed_processed');
							if(isPubmedProcessed == '1'){
								pubmedValue = 'Yes';
							}else{
								pubmedValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_pubmed_processed: pubmedValue});

	        				var isTrialProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_clinical_trial_processed');
							if(isTrialProcessed == '1'){
								trialValue = 'Yes';
							}else{
								trialValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_clinical_trial_processed: trialValue});

	        				var kolId = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'id');
	        				var act = '';
	        				
							act += '<div class="actionIcon editIcon"><a href="'+base_url+'kols/edit_kol/'+kolId+'" title="Edit">&nbsp;</a></div>';
							act += '<div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols('+kolId+',2);" href="#" title="Delete">&nbsp;</a></div>';

							jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {action: act});
	         			}
	    }
	});

	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navGrid','#listNotClientKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navButtonAdd',"#listNotClientKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('setGridWidth',gridWidth); 
}

function associateOrDisassociateKols(gridName){
	grid = $(gridName);
	var clientId = $("#client").val();
	var kolId	= grid.getGridParam('selarrrow');
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}
	else
	{
		if(gridName == "#JQBlistClientKolsDetails"){
			associationFlag = 'disassociate';
			$("#disassociateMsg span").css('color','#000099');
			$("#disassociateMsg").show();
		}else{
			associationFlag = 'associate';
			$("#associateMsg span").css('color','#000099');
			$("#associateMsg").show();
		}
		var client = $("#client").val();
		var kol_id = kolId.join();
		var dataString = 'client='+ client +'&kol_id='+kol_id +'&associationFlag='+associationFlag;
		// AJAX Code To Submit Form.
		$.ajax({
			type: "POST",
			url: "<?php echo base_url()?>/kols/save_kol_client_association",
			data: dataString,
			cache: false,
			success: function(result){
				if(gridName == "#JQBlistClientKolsDetails"){
					if(result){
						$("#disassociateMsg").show();
						getKolsAssociatedWithClient(clientId);
						getKolsNotAssociatedWithClient(clientId);
					}else{
						$("#disassociateMsg span").css('color','red');
						$("#disassociateMsg span").text('Unable to process request');
						$("#disassociateMsg").show();
						setTimeout(function(){ $("#disassociateMsg").hide(); }, 3000);
					}
				}else{
					if(result){
						$("#associateMsg").show();
						getKolsAssociatedWithClient(clientId);
						getKolsNotAssociatedWithClient(clientId);
					}else{
						$("#associateMsg span").css('color','red');
						$("#associateMsg span").text('Unable to process request');
						$("#associateMsg").show();
						setTimeout(function(){ $("#associateMsg").hide(); }, 3000);
					}
				}
			}
		});
	}
	return false;	
}

function updateStatus(gridName,id){
	grid = $(gridName);
	var kolId	= grid.getGridParam('selarrrow');
	var updateStatus = $("#"+id).val();
	var clientId = $("#client").val();
	if(updateStatus==''){
		jAlert("Please select status");
		return false;
	}
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}else{
		var kol_id = kolId.join();
		var dataString = 'where='+ id +'&kol_id='+kol_id +'&update_status='+updateStatus;
		// AJAX Code To Submit Form.
		$.ajax({
			type: "POST",
			url: "<?php echo base_url()?>/kols/update_kols_status_within_client_visibility",
			data: dataString,
			cache: false,
			success: function(result){
				var result = JSON.parse(result);
				if(gridName == "#JQBlistClientKolsDetails"){
					if(result.status == 'success'){
						$("#disassociateMsg").show();
						getKolsAssociatedWithClient(clientId);
						$("#"+id).val('');
					}else{
						$("#disassociateMsg span").css('color','red');
						$("#disassociateMsg span").text('Unable to process request');
						$("#disassociateMsg").show();
						setTimeout(function(){ $("#disassociateMsg").hide(); }, 3000);
					}
				}else{
					if(result.status == 'success'){
						$("#associateMsg").show();
						getKolsNotAssociatedWithClient(clientId);
						$("#"+id).val('');
					}else{
						$("#associateMsg span").css('color','red');
						$("#associateMsg span").text('Unable to process request');
						$("#associateMsg").show();
						setTimeout(function(){ $("#associateMsg").hide(); }, 3000);
					}
				}
			}
		});
	}
	return false;	
}

function deleteSelectedKols(kolId, grid){
	var clientId = $("#client").val();
	jConfirm("Are you sure you want to delete selected KOL's?","Please confirm",function(r){
		if(r){
			$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#exportKolsContainer").dialog("open");
			$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/show_kol_delete_opts/'+kolId+'/1/'+clientId);
		}else{
			return false;
		}
	});
}
</script>