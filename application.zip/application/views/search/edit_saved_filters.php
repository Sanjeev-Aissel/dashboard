<script type="text/javascript">
var filterId;
var textVal;
	$(document).ready(function(){
//		var savedFilterId = $("#savedFilterValue").val();
//		if(savedFilterId != ''){
//			edit(savedFilterId);
//			$( "#"+savedFilterId ).find('td').eq(1).children("input").focus();
//			}
		});
	function edit(id) {
		$("#"+filterId).find('td').eq(1).replaceWith("<td>"+textVal+"</td>");
		var dataEditElements = "<div class='actionIcon editIcon tooltip-demo tooltop-left' onclick='edit("+filterId+"); return false;' style='float: left;'>";
			dataEditElements += "<a data-original-title='Edit' href='#' class='tooltipLink' rel='tooltip'></a></div>";
			$("#"+filterId).find('td').eq(2).children("div").eq(0).replaceWith(dataEditElements);		
			textVal = $("#"+id).find('td').eq(1).html();
			$("#"+id).find('td').eq(1).replaceWith("<td><input type='text' value='"+textVal+"' maxlength='64'></td>");
		var dataUpdateElements = "<div class='actionIcon saveIcon' onclick='updateFilter("+id+");return false;' style='float: left;'><a data-original-title='Save Changes' href='#' class='tooltipLink' rel='tooltip'>&nbsp;</a></div>";
			$("#"+id).find('td').eq(2).children("div").eq(0).replaceWith(dataUpdateElements);
			filterId = id;
	}

	function updateFilter(id) {
		data = {};
		data['id'] = id;
		data['filterName'] =  $("#"+id).find('td').eq(1).children("input").val();		
		if($.trim(data['filterName'])!=''){
			$('.addCustomFilters').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
    		$.ajax({
    			type: "post",
    			data: data,
    			dataType:"json",
    			url: base_url+"kols/update_saved_filter",
    			success: function(returnData){
    				if(returnData.status == true){
    					$('.addCustomFilters').unblock();
    					$("#"+id).find('td').eq(1).replaceWith("<td>"+data['filterName']+"</td>");
    					var dataEditElements = "<div class='actionIcon editIcon tooltip-demo tooltop-left' onclick='edit("+id+"); return false;' style='float: left;'>";
    					dataEditElements += "<a data-original-title='Edit' href='#' class='tooltipLink' rel='tooltip'></a></div>";
    					$("#savedFilterValue option[value='"+id+"']").text(data['filterName']);
    //					$("#savedFilterValue option[value='"+id+"']").attr("selected","selected");
    					$('#savedFilterValue').trigger('liszt:updated');
    					$('#addFilters').text($('#savedFilterValue option:selected').text()+', ');
    					$("#"+id).find('td').eq(2).children("div").eq(0).replaceWith(dataEditElements);
    					filterId = id;
    					textVal = data['filterName'];
    				}
    		}
    		});
		}else{			
			jAlert("Please enter filter name");
		}
	}
</script>
<style type="text/css">
.saveIcon {
    background: url("<?php echo base_url()?>images/kolm-sprite-image.png") repeat scroll -223px -30px rgba(0, 0, 0, 0) !important;
}
</style>
<div class="formHeader">
	<h5>Saved Filters</h5>
</div>
<div>
	<form id="deleteSavedFilterForm" method="post"action="<?php echo base_url()?>kols/deleteCustomFilters">
	<table>
		<tbody>
			<tr>
				<th>Sl.No</th>
				<th>Query name</th>
				<th>Action</th>
			</tr>
			<?php $i = 1;foreach ($savedFilters as $savedFilter){?>
			<tr id="<?php echo $savedFilter['id']?>">
				<td><?php echo $i;?></td>
				<td><?php echo $savedFilter['name'];?></td>
				<td>
					<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="edit('<?php echo $savedFilter['id']?>'); return false;" style="float: left;">
						<a data-original-title="Edit" href="#" class="tooltipLink" rel="tooltip"></a>
					</div>
					<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteFilter('<?php echo $savedFilter['id']?>'); return false;" style="float: left;">
						<a data-original-title="Delete" href="#" class="tooltipLink" rel="tooltip"></a>
					</div>
				</td>
			</tr>
			<?php $i++; }?>
		</tbody>
	</table>
	</form>
</div>