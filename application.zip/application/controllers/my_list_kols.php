<?php

/**
 * This is Controller file of 'list_kols'
 * @package application.controllers	
 * @author Vinayak
 * @since 2.0
 * @created  28-02-11
 */


class My_list_kols extends Controller{
	
	function My_list_kols(){
		parent::Controller();
			$this->load->model('My_list_kol');
	}
	
	/*
	 * To show list of categories when Clicked 'My list tab'
	 * $author Vinayak
	 * @since 2.0
	 */
	function show_list(){
		redirect('my_list_kols/list_categories_and_names');
	} 	
	
	/*
	 * To show list of categories when Clicked 'List' tab
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 */
	function list_categories($subContentPage=''){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrCategories=$this->My_list_kol->listCategories($user_id,$client_id);
		$data['arrCategories']	=	$arrCategories;
		$arrCategoriesAndNames=$this->My_list_kol->listCategoriesAndNamesPrivate($user_id,$client_id);
		foreach($arrCategoriesAndNames as $row){
			$arrCatagoriesPrivate[$row['category']][$row['id']]=$row['list_name'];
		}
		$arrkolsresult			= $this->My_list_kol->countOfKolsPrivate();
		$data['arrKols']		= $arrkolsresult;
		$data['arrCatagoriesPrivate']	= $arrCatagoriesPrivate;
		$data['contentPage'] 	=	'my_list_kols/list_categories';
		$data['subContentPage']	=	$subContentPage;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited list category Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View list category page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
   	 	
	}
	
	/*
	 *  Display 'Add Category' Model Box
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function add_category(){
		$data['arrCategory']=null;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add category Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'transaction_name' => "View Add category page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('my_list_kols/add_category',$data);
	}
	
	/*
	 *  To save  'Categories' details 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function save_category(){
		$arrCategory['category'] = trim($this->input->post('category'));
		$arrCategory['user_id']= $this->session->userdata('user_id');
		$arrCategory['client_id']= $this->session->userdata('client_id');
		$arrCategory['is_public']= $this->input->post('is_public');

		$arrResult=array();
		if($lastinsertId=$this->My_list_kol->saveCategory($arrCategory)){
			$arrResult['saved']=true;
			$arrResult['data']=$arrCategory;
			$arrResult['lastinsertId']			= $lastinsertId;
			$arrResult['msg']="Saved Sucessfully";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Category',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $lastinsertId,
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => 'Add New Category',
					'form_data' => $formData,
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$arrResult['saved']=false;
			$arrResult['msg']="Sorry! Category Name is Already Present in Database";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Category',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $lastinsertId,
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => 'Add New Category',
					'form_data' => $formData,
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			
		}
		echo json_encode($arrResult);
	}

	/*
	 *  To Editing  'Categories' details 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function edit_category($id){
		$arrCategory=$this->My_list_kol->editCategory($id);
		$data['arrCategory']=$arrCategory;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Edit category Page",
				'status' => STATUS_SUCCESS,
		        'transaction_id' => $id,
		        'transaction_table_id' => LIST_CATEGORIES,
				'transaction_name' => "View Edit category page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('my_list_kols/add_category',$data);
	}

	/*
	 *  To Update 'Categories' details 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function update_category(){
		$arrCategory['id']         = $this->input->post('id');
		$arrCategory['category']   = trim($this->input->post('category'));
		$arrCategory['user_id']    = $this->session->userdata('user_id');
		$arrCategory['client_id']  = $this->session->userdata('client_id');
		$arrCategory['is_public']  = $this->input->post('is_public');
		
		$arrResult=array();
		if($this->My_list_kol->updateCategory($arrCategory)){
			$arrResult['saved']=true;
			$arrResult['lastinsertId']=$arrCategory['id'];
			$arrResult['data']=$arrCategory;
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Upadte Category',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrCategory['id'],
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => 'Upadte Category',
					'form_data' => $formData,
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			
		}else{
			$arrResult['saved']=false;
			$arrResult['msg']="Already present in Database";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Upadte Category',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrCategory['id'],
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => 'Upadte Category',
					'form_data' => $formData,
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}
		echo json_encode($arrResult);
	}

	/*
	 *  To Delete  'Categories' details 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function delete_category($categoryId){
		if($this->My_list_kol->daleteCategory($categoryId)){
			$data['mes'] = 'deleted';
		}else{
			$data['mes'] = 'not deleted';
		}
		echo json_encode($data);
	}
	
/*
	 *  To Delete  'Categories' details 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function delete_list_name($listNameId){
		$this->My_list_kol->deleteListName($listNameId);
	
		//redirect('my_list_kols/list_categories#');
	}
	
	/*
	 *  To Dispaly  'Add Category view' page 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function add_list($kols=0){
		//$arrKols = explode(',',$kols);
		//$arrCategory=array();
		//$arrCategoryReasult=$this->db->get('list_categories');
		//foreach($arrCategoryReasult->result_array() as $row){
			//$arrCategory[]=$row;
		//}
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrCategory=$this->My_list_kol->listCategories($user_id,$client_id);
		$data['arrCetgory']=$arrCategory;
		
		$data['arrKols'] = $kols;
		//pr($data);
		$this->load->view('my_list_kols/add_list',$data);
		
	}

	/*
	 *  Saving  'Category' its associated List name and Kols 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function save_list_kols(){
		$kols=$this->input->post('kol_id');
		$arrCatgory['category']=trim($this->input->post('category'));
		$arrCatgoryId['category_id']=$this->input->post('category_id');
		$arrListName['list_name']   =trim($this->input->post('list_name'));
		$arrListNameId['list_name_id']   =$this->input->post('list_name_id');
		$arrCatgory['is_public']=$this->input->post('is_public');
			
		
		if($arrCatgory['category']!=''){
				$arrCatgory['user_id'] = $this->session->userdata('user_id');
				$arrCatgory['client_id'] = $this->session->userdata('client_id');
				if($lastInsertId = $this->My_list_kol->saveCategory($arrCatgory)){
				
					$data['cat_saved']=true;
					$data['msg']="Saved Successfully";
				}else{
					$data['msg']="Sorry! Name is Already Present in Databse";
					$data['cat_saved']=false;
				}
				//echo json_encode($data);
		}else{
				$this->db->set('is_public',$arrCatgory['is_public']);
				$this->db->where('id',$arrCatgoryId['category_id']);
				$this->db->update('list_categories');
				$lastInsertId=$arrCatgoryId['category_id'];
				$data['msg']="Saved Successfully";
				$data['cat_saved']=true;
			}	
		$arrListName['category_id']=$lastInsertId;
		
		if($arrListName['list_name'] !=''){
			$arrListName['user_id'] = $this->session->userdata('user_id');
			if($lastInsertId = $this->My_list_kol->saveListName($arrListName)){
					$data['list_saved']=true;
					$data['msg1']="Saved Successfully";
				}else{
					$data['msg1']="Sorry! Name is Already Present in Databse";
					$data['list_saved']=false;
				}
			//echo json_encode($data);
		}else{
			$lastInsertId=$arrListNameId['list_name_id'];
			$data['list_saved']=true;
		}	
		
		$arrKols = explode(',',$kols);
		$this->My_list_kol->saveListOfKols($arrKols,$lastInsertId);
		echo json_encode($data);
		//$this->db->query("delete from list_names where category_id=0");
		//$this->db->query("delete from list_kols where list_name_id=0");
	}

	/*
	 *  To get  'list names' of particular Category 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function get_list_names($categoryId){
		$arrlist=$this->My_list_kol->getListNames($categoryId);
		
		echo json_encode($arrlist);
	}
	
	/*
	 *  To show List of category and its associated list names in tree structure 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 11-4-2011
	 */	
	function list_categories_and_names($subContentPage=''){
		$arrCatagoriesPrivate=array();
		$arrCatagoriesPublic=array();
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		
		$arrCategoriesAndNames=$this->My_list_kol->listCategoriesAndNamesPrivate($user_id,$client_id);
		
		foreach($arrCategoriesAndNames as $row){
			$arrCatagoriesPrivate[$row['category']][$row['id']]=$row['list_name'];
		}
	
		$arrkolsresult=$this->My_list_kol->countOfKolsPrivate();
		$data['arrKols']=$arrkolsresult;
		
		$arrkolsresult=$this->My_list_kol->countOfKolsPublic();
		$data['arrKolsPublic']=$arrkolsresult;
		
		$data['arrCatagoriesPrivate']=$arrCatagoriesPrivate;
		$arrCategoriesAndNamesPublic=$this->My_list_kol->listCategoriesAndNamesPublic($user_id,$client_id);
		foreach($arrCategoriesAndNamesPublic as $row){
			$arrCatagoriesPublic[$row['category']][$row['id']]=$row['list_name'];
		}
		$data['arrCatagoriesPublic']=$arrCatagoriesPublic;		
		$data['arrListCategoryKols'] = $this->My_list_kol->getListCategoryKolsCount($subContentPage);
		$data['contentPage'] 	=	'my_list_kols/list_categories_and_names';
		$data['subContentPage']	= $subContentPage;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited list categories and names Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View list categories and names Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	}
	
	/*
	 *  To show 'kol' details of particular category  
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 11-4-2011
	 */	
	function list_kols_of_cetagory($listNameId,$listType){
		$arrKolDetail=$this->My_list_kol->listKolsOfCategory($listNameId);
		$data['arr']=$arrKolDetail;
		$data['list_name_id']=$listNameId;
		$data['listType'] = $listType;
		$this->load->view('my_list_kols/list_kols_of_category',$data);		
	}
 	
	/*
	 *  To show list names of passed category
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 11-4-2011
	 */	
	
	function get_list_names_by_category($categoryId){
		$arrListNames=$this->My_list_kol->getListNamesBycategory($categoryId);
		$data['category_id']=$categoryId;
		$data['arrListNames']=$arrListNames;
		//pr($data);
		$this->load->view('my_list_kols/list_names',$data);
    
	}

	/*
	 * To display modal box to add list names
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 12-4-2011
	 */	
	function add_list_name($id){
		$data['arrListName']=null;
		$data['arrCategoryName'] = $this->My_list_kol->getCatergoryNameById($id);
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add list name Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add list name Payments"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('my_list_kols/add_list_name',$data);
	}

	/*
	 * To save list names to database
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 12-4-2011
	 */	
	function save_list_name($category_id){
		$arrListName['category_id'] = $category_id;
		$arrListName['list_name'] = trim($this->input->post('list_name'));
		$arrListName['user_id']= $this->session->userdata('user_id');
		$arrResult=array();
		if($lastinsertId=$this->My_list_kol->saveListName($arrListName)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New list names',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $lastinsertId,
					'transaction_table_id' =>LIST_NAMES,
					'transaction_name' => 'Add list names',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$arrResult['saved']=true;
			$arrResult['data']=$arrListName;
			$arrResult['lastinsertId']			= $lastinsertId;
			$arrResult['msg']="Saved Successfully";
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New list names',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $lastinsertId,
					'transaction_table_id' => LIST_NAMES,
					'transaction_name' => 'Add list names',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$arrResult['saved']=false;
			$arrResult['msg']="Sorry! List Name is Already Present in Database";
		}
		echo json_encode($arrResult);
	}

	/*
	 * To edit list name
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 12-4-2011
	 */	
	function edit_list_name($listId){
		$arrListNames=$this->My_list_kol->editListName($listId);
		
		$data['arrCategories']=$this->My_list_kol->listCategoriesOfuser($arrListNames['category_id']);
		$data['arrListName']=$arrListNames;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add list name Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View add list name page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('my_list_kols/add_list_name',$data);
	}

	/*
	 * To update list name
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 12-4-2011
	 */	
	function update_list_name($category_id){
		
		$arrListName['category_id'] =$this->input->post('category_id');
		$arrListName['id'] = $this->input->post('id');
		$arrListName['list_name'] = trim($this->input->post('list_name'));
		$arrListName['user_id']= $this->session->userdata('user_id');
		$arrResult=array();
		if($this->My_list_kol->updateListName($arrListName)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update list name',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $arrListName['id'],
					'transaction_table_id' => LIST_NAMES,
					'transaction_name' => 'Update list name',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);			
			$arrResult['saved']=true;
			$arrResult['data']=$arrListName;
			$arrResult['lastinsertId']			= $arrListName['id'];
			$arrResult['msg']="Updated Successfully";
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update list name',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $arrListName['id'],
					'transaction_table_id' => LIST_NAMES,
					'transaction_name' => 'Update list name',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$arrResult['saved']=false;
			$arrResult['msg']="Already present in Database";
		}
		echo json_encode($arrResult);
	}

	
	/*
	 * To delete kols beloging to particular list name
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 12-4-2011
	 */	
	function delete_kols($kols){
		$kolsId=explode(',',$kols);
		$list_name_id=$this->input->post('list_name_id');
	
		foreach($kolsId as $kol){
			$this->db->where('list_name_id',$list_name_id);
			$this->db->where('kol_id',$kol);
			$this->db->delete('list_kols');
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete kols beloging to particular list name',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kol,
			    	'transaction_id' =>  $list_name_id,
					'transaction_table_id' => LIST_KOLS,
					'transaction_name' => "Delete KOLS",
					'parent_object_id' =>  $list_name_id
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}
		
		//redirect('my_list_kols/list_kols_name');
	}
	
	/*
	 *  Retrives all the list names and also there respective category names
	 *  @author Ramesh B
	 *  @since 2.2
	 *  @created on 3-5-2011
	 */	
	function get_list_names_with_category($listName){
		$listName	= utf8_urldecode($this->input->post($listName));
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrListDetails=$this->My_list_kol->getListNameAndCategoryName($listName,$user_id,$client_id);
		$arrSuggestLists	= array();
		//$arrListNameWithCategory=array();
		//foreach($arrListDetails as $row){
		//	$arrListNameWithCategory[]=$row['list_name']." (".$row['category'].")";
		//}
		if(sizeof($arrListDetails)==0){
			$arrSuggestLists[0]			= 'No results found for '.$listName;
		}else{
			$flag	= 1;
			foreach($arrListDetails as $id=>$row){
				if($flag){
					$arrSuggestLists[]='<div class="autocompleteHeading">Lists</div><div class="dataSet"><label name="'.$id.'" class="lists" style="display:block">'.$row['list_name']."</label><label>".$row['category']."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestLists[]='<div class="dataSet"><label name="'.$id.'" class="lists" style="display:block">'.$row['list_name']."</label><label>".$row['category']."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $listName;
		$arrReturnData['suggestions']	= $arrSuggestLists;
		echo json_encode($arrReturnData);
	}
	
	function pre_config_lists(){
		$catId = '';
		$this->db->select('id');
		$this->db->where('category','Profile Type');
		$catIdResult = $this->db->get('list_categories');
		$catId = $catIdResult->result_array();
		$catId = $catId[0]['id'];
		
		$ListId = '';
		$this->db->select('id,list_name');
		$this->db->where('((list_name="Basic" or list_name="Basic Plus" or list_name="Full Profile")and category_id=7)');
		//$this->db->or_where('list_name','Basic Plus');
		//$this->db->or_where('list_name','Full Profile');
		//$this->db->where('category_id',9);
		$ListIdResult = $this->db->get('list_names');
		
		$ListId = $ListIdResult->result_array();
	
		$basicId = $ListId[0]['id'];
		$basicPlus = $ListId[1]['id'];
		$fullProfile = $ListId[2]['id'];
		
		
		$this->db->select('id,profile_type');
		$this->db->where('status',COMPLETED);
		$arrKoslId = $this->db->get('kols');
		foreach($arrKoslId->result_array() as $row){
			if($row['profile_type'] == 'Basic'){
				$insertList['list_name_id'] = $basicId;
				$insertList['kol_id'] = $row['id'];
				$insertList['user_id'] = 105;
				
			}
		
			if($row['profile_type'] == 'Basic Plus'){
				$insertList['list_name_id'] = $basicPlus;
				$insertList['kol_id'] = $row['id'];
				$insertList['user_id'] = 105;
				
			}
			
		if($row['profile_type'] == 'Full Profile'){
				$insertList['list_name_id'] = $fullProfile;
				$insertList['kol_id'] = $row['id'];
				$insertList['user_id'] = 105;
				
			}
			
			$this->db->insert('list_kols',$insertList);
			
		}
		
	}
	
	/**
	 * load view page for adding ktl to listing
	 *
	 * @author Sanjeev
	 * @created 07-06-2017
	 * @since	3.4
	 * 
	 */
	function add_ktl_listing($listNameId){		
		$listing_details	= $this->My_list_kol->getListingCategoryDetailsByID($listNameId);
		$data["listing_details"]	= $listing_details;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add ktl listing Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View add ktl listing Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('my_list_kols/add_ktl_listing', $data);
	}
	function save_ktls_list(){
		$kols=$this->input->post('kol_id');
		$kols = $this->common_helpers->getKolidOrUniqueId($kols);
		$listId  =	$this->input->post('list_name_id');

		//$arrKols = explode(',',$kols);
		$result	= $this->My_list_kol->saveKtlList($kols,$listId);
		if($result == true){
			$data['msg']	= "Saved Successfully";
			$data['list_name_id']=$listId;
			$data['kol_saved']=true;
		}else{
			$data['msg']	= "Sorry! Name is Already Present in Listing";
			$data['list_name_id']=$listId;
			$data['kol_saved']=false;
		}
		echo json_encode($data);
		//$this->db->query("delete from list_names where category_id=0");
		//$this->db->query("delete from list_kols where list_name_id=0");
	}
	/* function export_list($kolIds,$ipad=0){
	    $kolIds = explode(",", $kolIds);
        $arrKols = $this->My_list_kol->listKolsByIds($kolIds);
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        $objWorksheet->setTitle('KTL List');
        //Add header
    
        $objWorksheet->setCellValue('A1', 'Name')
        ->setCellValue('B1', 'Speciality')
        ->setCellValue('C1', 'Country')
        ->setCellValue('D1', 'Phone')
        ->setCellValue('E1', 'Email');
        
        $i = 2;
        foreach ($arrKols as $row) {
            $objWorksheet->setCellValue('A'.$i, (isset($row['first_name'])?$row['first_name'].' '.$row['middle_name'].' '.$row['last_name']:''))
            ->setCellValue('B'.$i, (isset($row['specialty'])?$row['specialty']:''))
            ->setCellValue('C'.$i, (isset($row['country'])?$row['country']:''))
            ->setCellValue('D'.$i, (isset($row['primary_phone'])?$row['primary_phone']:''))
            ->setCellValue('E'.$i, (isset($row['primary_email'])?$row['primary_email']:''));
            
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
    
        $styleArray = array(
                'borders' => array(
                        'bottom' => array(
                                'style' => PHPExcel_Style_Border::BORDER_THICK,
                                'color' => array('argb' => '0000000'),
                        ),
                ),
        );
    
        $arrStyles = array(
                'font' => array(
                        'bold' => true,
                        'italic' => false
                ),
                'borders' => array(
                        'bottom' => array(
                                'style' => PHPExcel_Style_Border::BORDER_THICK,
                                'color' => array(
                                        'rgb' => '000000'
                                )
                        ),
                        'quotePrefix' => true
                )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'E') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($arrStyles);
        }
        $objPHPExcel->setActiveSheetIndex(0);
        if(!$ipad){
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="KTL_lists.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }else{
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $fileName = "Events ".date("m-d-Y_His");
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xlsx";
            $objWriter->save($path);
            $mail = $this->send_email_as_export($path);
            $emailData['status'] = $mail; 
            echo json_encode($emailData);
        }
  	}
  	function send_email_as_export($path) {
  	    $config['protocol'] = PROTOCOL;
  	    $config['smtp_host'] = HOST;
  	    $config['smtp_port'] = PORT;
  	    $config['smtp_user'] = USER;
  	    $config['smtp_pass'] = PASS;
  	    $config['mailtype'] = 'html';
  	    $this->load->library('email', $config);
  	    $this->email->set_newline("\r\n");
  	    $this->email->initialize($config);
  	    $this->email->clear();
  	    $this->email->set_newline("\r\n");
  	    $this->email->from(USER, SENDER);
  	    $loggedInUserName = $this->session->userdata('user_full_name');
  	
  	    $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
  	    $messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export report data from '.PRODUCT_NAME.'.';
  	
  	    $loggedInUserEmail = $this->session->userdata('email');
  	    $this->email->to($loggedInUserEmail);
  	    $this->email->message($messageBody);
  	    $this->email->subject(PRODUCT_NAME.":Kols List");
  	    $this->email->attach($path,'attachment');
  	    $this->email->set_crlf("\r\n");
  	    if ($this->email->send()) {
  	    	//Add Log activity
  	    	$arrLogDetails = array(
  	    			'type' => LOG_ACTIVITY_EMAIL,
  	    			'description' => $messageBody,
  	    			'status' => STATUS_SUCCESS,
  	    			'miscellaneous1' =>"To-".$loggedInUserEmail,
  	    			'transaction_name' => "Excel has been mailed"
  	    	);
  	    	$this->config->set_item('log_details', $arrLogDetails);
  	    	log_user_activity(null,true);
  	        $emailData['status'] = 'Excel has been mailed successfully';
  	        unlink($path);
  	    } else {
  	    	//Add Log activity
  	    	$arrLogDetails = array(
  	    			'type' => LOG_ACTIVITY_EMAIL,
  	    			'description' => $messageBody,
  	    			'status' => STATUS_FAIL,
  	    			'miscellaneous1' =>"To-".$loggedInUserEmail,
  	    			'transaction_name' => "Excel has been mailed"
  	    	);
  	    	$this->config->set_item('log_details', $arrLogDetails);
  	    	log_user_activity(null,true);
  	        $emailData['status'] = 'Mail not sent';
  	        unlink($path);
  	    }
  	    $this->email->clear(TRUE);
  	    return $emailData['status'];
  	} */
} 
