<?php
/*
 * To display searched names
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 07-05-2013
 *  
 */
?>
<style type="text/css">
	#searchedNames{
		min-height: 250px !important;
	}
	.ui-pg-input{ width: 80px; }
</style> 
<script type="text/javascript">
function addSelectedRecords(){
	var thisObj	= jQuery("#listNamesResultSet");
	var selectedRowId	= $(thisObj).getGridParam('selarrrow');
	var isRespondentOrInfluencer = '<?php echo $isRespondentOrInfluencer;?>';
	var appendId = '<?php echo $appendId; ?>';

	if(selectedRowId!=''){
		
		if(isRespondentOrInfluencer==='true'){
			if(selectedRowId.length > 1){
				jAlert("Only one respondent can be selected, please select any one respondent");
				return false;	
			}
			var rowData = jQuery("#listNamesResultSet").jqGrid('getRowData', selectedRowId[0]);
			$("#respondentId").val(rowData.id);
			$('#respondentName').val(rowData.full_name);
			$('#respCity').text(rowData.city);
			$('#respState').text(rowData.state);
			$('#respCountry').text(rowData.country);
			$('#respPostalCode').text(rowData.postal_code);

			$('#respondent_first_name').val(rowData.first_name);
			$('#respondent_middle_name').val(rowData.middle_name);
			$('#respondent_last_name').val(rowData.last_name);
			$('#respondent_country').val(rowData.country);
			$('#respondent_state').val(rowData.state);
			$('#respondent_city').val(rowData.city);
			$('#respondent_postal_code').val(rowData.postal_code);
			$('#respondent_speciality').val(rowData.specialty_name);
			$('#respondent_organization').val(rowData.org_name);
				
			$("#showHiderespondentDetails").show();
			closeModalBox();
		}else{
			for(var i=0;i<selectedRowId.length;i++){
				var rowData = jQuery("#listNamesResultSet").jqGrid('getRowData', selectedRowId[i]);
				var html = '';
				var getQuestionId = appendId.split(/\s*\-\s*/g);
				var questionId = getQuestionId[1];
				if(rowData.id == $("#respondentId").val()){
					jAlert('Respondent cannot nominate himself');
				}else{
					html += '<div>';
					html += '<div class="influencerDetails"><label>Name:</label> <span>'+rowData.full_name+'</span></div>';
					html += '<div class="influencerDetails"><label>City:</label> <span>'+rowData.city+'</span></div>';
					html += '<div class="influencerDetails"><label>State:</label> <span>'+rowData.state+'</span></div>';
					html += '<div class="influencerDetails"><label>Country:</label> <span>'+rowData.country+'</span></div>';
					html += '<div class="influencerDetails"><label>Postal Code:</label> <span>'+rowData.postal_code+'</span></div>';
					html += '<div class="influencerDetails" style="width: 5%;"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></div>';

					html += '<input type="hidden" name="influencer_kolid_'+questionId+'[]" id="influencer_kolid" value="'+rowData.id+'"/>';
					html += '<input type="hidden" name="influencer_first_name_'+questionId+'[]" id="influencer_first_name" value="'+rowData.first_name+'"/>';
					html += '<input type="hidden" name="influencer_middle_name_'+questionId+'[]" id="influencer_middle_name" value="'+rowData.middle_name+'"/>';
					html += '<input type="hidden" name="influencer_last_name_'+questionId+'[]" id="influencer_last_name" value="'+rowData.last_name+'"/>';
					html += '<input type="hidden" name="influencer_country_'+questionId+'[]" id="influencer_country" value="'+rowData.country+'"/>';
					html += '<input type="hidden" name="influencer_state_'+questionId+'[]" id="influencer_state" value="'+rowData.state+'"/>';
					html += '<input type="hidden" name="influencer_city_'+questionId+'[]" id="influencer_city" value="'+rowData.city+'"/>';
					html += '<input type="hidden" name="influencer_postal_code_'+questionId+'[]" id="influencer_postal_code" value="'+rowData.postal_code+'"/>';
					html += '<input type="hidden" name="influencer_speciality_'+questionId+'[]" id="influencer_speciality" value="'+rowData.specialty_name+'"/>';
					html += '<input type="hidden" name="influencer_organization_'+questionId+'[]" id="influencer_organization" value="'+rowData.org_name+'"/>';
					html += '</div>';
					$("#"+appendId).find(".answers").append(html);
				}
				closeModalBox();
			}
		}
	}else{
		jAlert('Please select at least one Name');
	}
}
	
	function closeModalBox(){
		$("#searchedNames").dialog("close");
	}

	var firstTime = true;
	function listSearchResults(){
		var name = '<?php echo $name;?>';
		var orgName = '<?php echo $orgname;?>';
		var country = '<?php echo $country;?>';
		var state = '<?php echo $state;?>';
		var city = '<?php echo $city;?>';
		var postal = '<?php echo $postal;?>';
		var resp_id = $("#respondentId").val();
		
		var ele=document.getElementById('gridContainer');
		var gridWidth=ele.clientWidth;
		$('#gridContainer').html('');
	    $('#gridContainer').html('<div id="listNamesPage"></div><table id="listNamesResultSet"></table>');
		jQuery("#listNamesResultSet").jqGrid({
			url:base_url+'surveys/load_all_kols/'+resp_id,
			datatype: "json",
			colNames:['unique_id','id','','Name','State','City','Postal Code','Country','First Name','Middle Name', 'Last Name','Speciality','Organization'],
		   	colModel:[
				{name:'unique_id',index:'unique_id', hidden:true},
				{name:'id',index:'id', hidden:true},
				{name:'kol_id',index:'kol_id', hidden:true},
				{name:'full_name',index:'first_name',search:true,searchoptions: { defaultValue:name }},
		   		{name:'state',index:'state',width:60,search:true,searchoptions: { defaultValue:state }},
		   		{name:'city',index:'city',width:60,search:true,searchoptions: { defaultValue:city }},
//		   		{name:'country_name',index:'country_name',width:60,search:true,searchoptions: { defaultValue:country }},
		   		{name:'postal_code',index:'postal_code',width:60,search:true,searchoptions: { defaultValue:postal }},
		   		{name:'country',index:'country',width:60,hidden:true},
		   		{name:'first_name',index:'first_name',width:60,hidden:true},
		   		{name:'middle_name',index:'middle_name',width:60,hidden:true},
		   		{name:'last_name',index:'last_name',width:60,hidden:true},
		   		{name:'specialty_name',index:'specialty_name',width:60,hidden:true},
		   		{name:'org_name',index:'org_name',width:60,hidden:true}
		   	],
		  	postData:{"name":"<?php echo $name;?>","orgname":"<?php echo $orgname;?>","country":"<?php echo $country;?>","state":"<?php echo $state;?>","city":"<?php echo $city;?>","postal":"<?php echo $postal;?>"},
		   	rowNum:10,
		   	multiselect: true,
		   	rownumWidth:"60",
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	gridview: true,
		   	pager: '#listNamesPage',
		   	mtype: "POST",
		   	sortname: 'name',
		   	sortorder: "asc",
		    viewrecords: true,
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Search Result",
		    grouping: false, 
	   		rowList:paginationValues
		});
		jQuery("#listNamesResultSet").jqGrid('navGrid','#listNamesPage',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		jQuery("#listNamesResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
		
		//Toggle Toolbar Search
		jQuery("#listNamesResultSet").jqGrid('navButtonAdd',"#listNamesPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}
			}
		});
		jQuery("#listNamesResultSet").jqGrid('setGridWidth',gridWidth);
		initilizeGridSearchPlaceholder();
	}
	$(document).ready(function (){
		listSearchResults();
	});
</script>
<div>
	<br />
	<div class="gridWrapper" id="gridContainer">
		<div id="listNamesPage"></div>
		<table id="listNamesResultSet"></table>
	</div>
	<br />
	<div style="text-align: center;">
		<input type="button" value="Add as answer(s)" onclick="addSelectedRecords();" />
		<input type="button" value="Cancel" onclick="closeModalBox();" />
	</div>
	<br />
</div>