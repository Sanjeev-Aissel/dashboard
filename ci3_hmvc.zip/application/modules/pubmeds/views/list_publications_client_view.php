<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<link href="<?php echo base_url().ASSETS;?>c3js/c3.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url().ASSETS;?>bootstrap_slider/bootstrap-slider.css" rel="stylesheet">
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'c3js/c3.min',
			'c3js/d3.c3.min',
			'jit/jit',
			'js/custom_js/jqgridExportToExcel',
			'modules/pubmeds/js/list_publications_client_view',
			'bootstrap_slider/bootstrap-slider',
			'alerts/jquery.alerts'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
#coAuthorsFreqChart {
    position: relative;
    width: 400px;
    height:350px;
    margin: auto;
    overflow: hidden;
}
.progress {
    height: 15px;
        margin-bottom: 0px;
}
.no_bottom_margin {
    margin-bottom: 0px;
}
</style>
<script>
var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';

var arrExcludeColumnsInExcelExport = new Array('micro','act'); 
var arrExcludeHeaderColumnsInExcelExport = new Array('Id','ClientId','kp_id','UserId','Manual','last_name');	
var subContentPage='<?php echo $subContentPage?>';
var kolId = '<?php echo $arrKol['kols_client_visibility_id']?>'; 
var kol_unique_id 	= '<?php echo $arrKol['kols_client_visibility_unique_id']?>'; 
var minYear='<?php if($arrYearRange['min_year']!='')echo $arrYearRange['min_year']; else echo '0';?>';
var maxYear='<?php if($arrYearRange['max_year']!='')echo $arrYearRange['max_year']; else echo '0';?>';
var startYear=minYear;
var endYear=maxYear;
$(document).ready(function(){
	setrangevalues();
	document.getElementById("ex6SliderVal").textContent=minYear+','+maxYear;
	var slider = new Slider('#yearRangeSlider',{});
	slider.on("slide", function(sliderValue) {
		document.getElementById("ex6SliderVal").textContent = sliderValue;
		loadSelectedTabChart(sliderValue[0],sliderValue[1]);
	});
	loadSelectedTabChart(startYear,endYear);
});
</script>
<div style="margin:10px 0px;">
	<p style="display: inline">Keywords:</p>
	<form style="display: inline" class="form-inline" action="" name="pubAdvSearchForm" method="post" id="pubSearchForm">
		<input  name="pubKeywords" id="pubKeywords" value="" type="text" class="form-control" style="width:20%;display: inline">
		<a  class="btn custom-btn" onclick="loadSelectedTabChart()">submit</a>
	</form>
	
	<div style="display:inline;margin-left:2%;">
		<b>Year Range</b>(<b><span id="ex6SliderVal"></span></b>):
		<input id="yearRangeSlider" type="text" class="span2" value="" data-slider-min="1990" data-slider-max="2018" data-slider-step="1" data-slider-value="[2000,2010]"/> 
	</div>
	<div class="pull-right">
		<?php if($role_permissions[$module_id]["add"]==1){?>
			<a class="btn custom-btn"  href="<?php echo base_url().'pubmeds/pubmeds/add_publication/'.$arrKol['kols_client_visibility_unique_id'];?>">Add New Publication</a>
		<?php }?>		
		<div data-toggle="tooltip" data-placement="left" title="Export Publications Details into Excel format" class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistSearchResultSet','publications');">
		     <a href="#">&nbsp;</a>
		</div>
	</div>
</div>
<?php switch($subContentPage){
	case 'reports':?>
						<div class="pubChartContainer">
							<div class="row">
								<div class="col-sm-12">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Publications by Year</h3>
									  </div>
									  <div class="panel-body">
										<div id="pubByTime" class="eachChart">
											<div id="pubsChart"></div>
										</div>
									  </div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-6">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Publications by Authorship Position</h3>
									  </div>
									  <div class="panel-body">
										<div id="pubAuthPos" class="eachChart">
											<div id="pubAuthPosChart">
											</div>
										</div>	
									  </div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="panel panel-default">
										  <div class="panel-heading">
											<h3 class="panel-title">Top 20 Co-authors</h3>
										  </div>
										  <div class="panel-body">
											<div id="pubCoAuthors" class="eachChart">
												<div id="coAuthorsFreqChart">
												</div>
											</div>
										  </div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-6">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Top 20 Journals</h3>
									  </div>
									  <div class="panel-body">
										<div id="pubJournals" class="eachChart">
											<div id="pubJournalsChart">
											</div>
										</div>
									  </div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="panel panel-default">
										  <div class="panel-heading">
											<h3 class="panel-title">Top 20 Publication Types</h3>
										  </div>
										  <div class="panel-body">
											<div id="pubTypes" class="eachChart">
												<div id="pubTypeChart">
												</div>
											</div>
										  </div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-12">
									<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">topConcepts</h3>
									  </div>
									  <div class="panel-body">
										<div id="topConcepts" class="eachChart">
											<div id="topConceptsData"></div>
										</div>
									  </div>
									</div>
								</div>
							</div>
						</div>
			<?php break;
			case 'search':?><div id="pubSearch">
								<div class="gridWrapper" id="gridContainer1">
									<div id="serchPublicationPage"></div>
									<table id="JQBlistSearchResultSet"></table>
								</div>	
						   </div>
			<?php break;
			default:?>
			<?php break;
}?>