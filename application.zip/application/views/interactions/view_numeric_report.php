<?php
/**
 * Interactions numeric report view page
 * 
 * @author Ramesh Binput[type="button"], input[type="submit"], input[type="reset"], button, a.blueButton
 * @Created on: 13-10-12
 * @since 
 */

$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min','CalendarControl','jquery/jquery-ui-1.8.16.slider','jquery/jquery-ui-1.8.16.datepicket',
            'jquery/date',
        'jquery/daterangepicker.jQuery','jquery.validate','chosen.jquery');    
    
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	$autoSearchOptions = "width: 269, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
	$controllerName = $this->uri->segment(1);
	$userId = $this->session->userdata('user_id');
	$userRole = $this->session->userdata('user_role_id');
        $reportFlag =  $this->uri->segment(5);
        //echo $reportFlag;
?>
<script>	
	var chartColors=<?php echo CHART_COLOR_CODES ?>;
</script>
<!--<script src='<?php echo base_url();?>js/CalendarControl.js'></script>
<script src='<?php echo base_url();?>js/highcharts2_2_2/highcharts3.0.5.js'></script>
<script src='<?php echo base_url();?>js/highcharts2_2_2/modules/exporting3.0.5.js'></script>
<script src='<?php echo base_url();?>js/jquery/jquery-ui-1.8.16.slider.js'></script>
<script src='<?php echo base_url();?>js/jquery/date.js'></script>
<script src='<?php echo base_url();?>js/jquery/jquery-ui-1.8.16.datepicket.js'></script>
<script src='<?php echo base_url();?>js/jquery/daterangepicker.jQuery.js'></script>
<script src='<?php echo base_url();?>js/jquery/jquery-ui-1.8.16.datepicket.js'></script>
<script src='<?php echo base_url();?>js/jquery.validate.js'></script>-->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url();?>css/StyleCalender.css" />
<link rel="stylesheet" href="<?php echo base_url();?>css/ui.daterangepicker.css" type="text/css" />
<link href='<?php echo base_url();?>css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url();?>css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='<?php echo base_url();?>js/moment.min.js'></script>
<script src='<?php echo base_url();?>js/fullcalendar.min.js'></script>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />

<!-- Load c3.css -->
<link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">

<!-- Load d3.js and c3.js -->
<script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
<script src="<?php echo base_url();?>c3js/c3.min.js"></script>
<?php 
	$fromDate	= date('m/01/Y');
	if($fromFilterData > 0){
		$fromDate	= date('m/01/Y', strtotime("last day of -$fromFilterData month"));
	}
	$toDate	= date('m/d/Y');
?>
<style>
    .fc-prev-button, .fc-next-button {
        min-width: 30px;
        margin-left: 6px !important;
    }
    .fc-toolbar .fc-center {
        float: left !important;
    }
    .fc-toolbar .fc-center h2 {
        margin-left: 10px !important;
        margin-top: -5px;
    }
    .fc th, .fc td {
        border-width: 2px;
        border-color: #2b9af3 !important;
    }
    .fc-row:first-child table {
        margin-bottom: 0px;
    }
    #calendarId thead th {
        background-color: #2b9af3 !important;
        height: 34px;
        color: #ffffff;
        vertical-align: middle;
        font-size: 12px;
        text-transform: uppercase;
        font-weight: normal;
    }
    .fc-basic-view td.fc-week-number span, .fc-basic-view td.fc-day-number {
        padding-top: 5px;
        padding-left: 9px;
        font-size: 14px;
        padding-bottom: 2px;
        font-weight: bold;
    }
    .fc-ltr .fc-basic-view .fc-day-number {
    	text-align: left;
    }
    .fc-event{
        border: 1px solid #2b9af3;
        background-color: #2b9af3;
        font-size: 12px;
    }
     #calendarId thead th::first-letter {
       font-size: 16px;
   }
</style>
<script type="text/javascript">

var kolId = '<?php echo $kolId?>';


var chartsHeight = 400;

var viewType	= 'tabular';

var chartBackgroundColor = "transparent";

jqgridIds	= new Array('listInteractionsResultSet');
var todayDate = "<?php echo date("m/d/Y");?>";

var monthFirstDate = "<?php echo $fromDate;?>";

var yearFirstDate = "<?php echo date("01/01/Y");?>";

function showAction(id){

	

	$('#show_'+id).show();

}



function hideAction(id){

	

	$('#show_'+id).hide();

}

var interactionsTitle = "<?php echo lang("Track.Interactions");?>";

var date = "<?php echo lang("Overview.Date");?>";

var action = "<?php echo lang("Overview.Action");?>";

var type = "<?php echo lang("Overview.Type");?>";

var recordedBy = "<?php echo lang("track.RecordedBy");?>";

var channel = "<?php echo lang("Overview.Channel");?>";

var product = "<?php echo lang("Overview.Product");?>";

var paymentsTitle = "<?php echo lang("Overview.Payments");?>";

var requestedBy = "<?php echo lang("Overview.requestedBy");?>";

var paidBy = "<?php echo lang("Overview.paidBy");?>";

var amount = "<?php echo lang("Overview.amount");?>";

jqgridIds	= new Array('listInteractionsResultSet');
var chartsHeight = 400;
var chartBackgroundColor = "transparent";
chartBackgroundColor	= '#ffffff';
var currentChartId = "list";

// Autocomplet Options for the 'Organizer' field 
    var organizationNameAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names',
<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#organization').val(selText);
                    $('#org_institution_id').val(selId);

                    $('#org_institution_id').val(selId).trigger('change');
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#organization').val(trim(split(' ', selText)[4]));
                            return false;
                        } else {
                            //doSearchFilter1( - 1);
                        }
                    } else {
                        //doSearchFilter1( - 1);
                    }
                }
    };
	$(document).ready(function(){
        // Trigger the Autocompleter for 'organizer' field of  Event'
        a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);		

		var kolId = '<?php echo $kolId;?>';
		$('#startDate, #endDate').daterangepicker();
		if(kolId>0){
			$('#startDate').val(yearFirstDate);
		}else{
			$('#startDate').val(monthFirstDate);
		}
		 
         // $('#endDate').val(todayDate);
         var cdate = get_currentdate();
         $('#endDate').val(cdate);
		a= $('#kol-name').autocomplete(kolNameAutoCompleteOptions);

		$("#kol-name").blur(function(){
			if($(this).val() == '')
				$("#kol-id").val('');
		});

		$("#interactionsFilterForm #organization").blur(function(){
			if($(this).val() == '')
				$("#org_institution_id").val('');
		});


		$("#list").click(function(){
			currentChartId = "list";
			$("#numericReportContainer").css("display","none");
			$("#pageChartContainer").css("display","none");
			$("#calenderContent").css("display","none");
			$('#gridTabContainer').css("display","block");
		
			$("#gridContainer").html("");
			// Append the required div and table
			$("#gridContainer").html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');
			listInteractions();
		});
		$("#report").click(function(){
			currentChartId = "report";
			$("#numericReportContainer").css("display","block");
			$("#pageChartContainer").css("display","none");
			$("#calenderContent").css("display","none");
			$('#gridTabContainer').css("display","none");
		
			
			generateNumericReport();
		});
		$("#chart").click(function(){
			currentChartId = "chart";
			$("#numericReportContainer").css("display","none");
			$("#calenderContent").css("display","none");
			$("#pageChartContainer").css("display","block");
			$('#gridTabContainer').css("display","none");
			generateChartReport();
		});
               
		$('.tabsWrapper ul.tabsContainer li').click(function (){
			var currentTab	= $(this).attr('name');
			$('.tabsWrapper ul.tabsContainer li').removeClass('current');
			$('.tabsWrapper .tabsContent div.tabContent').hide();
			$(this).addClass('current');
			$('.tabsWrapper .tabsContent div.'+currentTab).show();
		});

		//interaction Pad dialogBox config
        var interactionDialogConf = {
				title: "Interaction Snapshot",
				modal: true,
				autoOpen: false,
				width: 410,
				height:340,
				draggable:false,
				position: ['center', 210],
				dialogClass: "microView calmicro",
				open: function() {
					//display correct dialog content
				}
		};

		$("#interactionDialoge").dialog(interactionDialogConf);		

		
	});
	
	var kolNameAutoCompleteOptions = {
		<?php 
        if(KOL_CONSENT){?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1/1',
		<?php }else{ ?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1',
		<?php } ?>
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			selText=selText.replace(/\&amp;/g,'&');
			$('#kol-name').val(selText);
			$('#kol-id').val(kolId);
		}
	}

	function openCalenderSnapshotBox(calEvent){
		var snapshotText = "";
		snapshotText +="<table id='snap-details'>";
		snapshotText +="	<tr>";
		snapshotText +="		<th>Interaction Id :</th>";
		snapshotText +="		<td>"+calEvent.generic_id+"</td>";
		snapshotText +="	</tr>";
		snapshotText +="	<tr>";
		snapshotText +="		<th>Attendees :</th>";
		snapshotText +="		<td>"+calEvent.kol_name+"</td>";
		snapshotText +="	</tr>";
		snapshotText +="	<tr>";
		snapshotText +="		<th>Date :</th>";
		snapshotText +="		<td>"+calEvent.date+"</td>";
		snapshotText +="	</tr>";
		snapshotText +="	<tr>";
		snapshotText +="		<th>"+product+" :</th>";
		snapshotText +="		<td>"+calEvent.product_name+"</td>";
		snapshotText +="	</tr>";
		snapshotText +="</table>";
		snapshotText +="<table id='snap-actions'>";
		
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			snapshotText +="	<tr>";
			snapshotText +=" 		<td class='action'><a class='blueButton' href='#' onclick='$(\"#interactionDialoge\").dialog(\"close\");viewInteractionMicroProfile("+calEvent.id+"); return false;'>View Interaction</a></td>";
//			snapshotText +=" 		<td class='action'><a class='blueButton' href='"+base_url+"coachings/compliance/0/"+calEvent.id+"'>Add Compliance Monitoring</a></td>";
			snapshotText +="	</tr>";
//                                snapshotText +="	<tr>";
//			snapshotText +=" 		<td class='action'><a class='blueButton' href='"+base_url+"customer_engagements/add/one/0/"+calEvent.id+"'>Add  Engagement 1:1</a></td>";
//			snapshotText +=" 		<td class='action'><a class='blueButton' href='"+base_url+"customer_engagements/add/group/0/"+calEvent.id+"'>Add  Engagement Group</a></td>";
//			snapshotText +="	</tr>";
		}else{
			snapshotText +="	<tr>";
			snapshotText +=" 		<td class='action'><a class='blueButton' href='#' onclick='$(\"#interactionDialoge\").dialog(\"close\");viewInteractionMicroProfile("+calEvent.id+"); return false;'>View Interaction</a></td>";
			snapshotText +="	</tr>";
		}
		snapshotText +="</table>";
        $(".interactionDialoge").html("");
		$(".interactionDialoge").html(snapshotText);
		$("#interactionDialoge").dialog("open");
	}
	
	function generateCalenderEvents(){
		currentChartId = "calender";
		$("#calenderContent").css("display","block");
      
            $('#calendarId').fullCalendar( 'refetchEvents' );
             
	$('#calendarId').fullCalendar({
			height:600,
			width:900,
            eventClick: function(calEvent, jsEvent, view) {
		        //alert('kolid: ' + calEvent.id);  
		        // change the border color just for fun
		        //$(this).css('border-color', 'red');
		
            	openCalenderSnapshotBox(calEvent);
		
		    },
		    columnFormat : 'dddd',
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			buttonText: {
			    today: 'Today',
			    month: 'Month',
			    week: 'Week',
			    day: 'Day'
			},
			editable: false,
			eventLimit: true, // allow "more" link when too many events
                        timeFormat: '',
                        
			events: {
				url: '<?php echo base_url()?>interactions/list_events_by_date_range',
                                data:function() {
									var data = {};
									var sd = $('#startDate').val();
									if(sd!=''){
									var sdSplits = sd.split("/");
										data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

									}
									var ed = $('#endDate').val();
									if(ed!=''){
										var edSplits = ed.split("/");
										data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
									}
									data['grouping'] = $('#grouping').val();
									data['mode'] = $('#mode').val();
									data['type'] = $('#objective').val();
									data['product'] = $('#product').val();
									data['topic'] = $('#topic').val();
									data['subtopic'] = $('#subtopic').val();
									data['kol_id'] = $('#kol-id').val();
									data['org_id'] = $('#org_institution_id').val();
									data['user_id'] = $('#user-name').val();
					
                                    return data;
                                },
                                type:'post',
				error: function() {
					$('#script-warning').show();
				},
                                        success: function(returnData) {

				}
			},
                                
			loading: function(bool) {
				$('#loading').toggle(bool);
			}
		});
		setTimeout(function(){
			  //alert($(".fc-month-view").html());
			  $(".fc-month-button").click();
			}, 100); 
    }
	function generateInteractionReport(){
			
			$("#"+currentChartId).trigger("click");
                        //generateCalenderEvents();
		}
	function generateNumericReport(){
		if(!$("#interactionsFilterForm").validate().form()){
			return false;
		}else{
			$('label.error').remove();
			$('#numericReportContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			var data = {};
			var sd = $('#startDate').val();
			if(sd!=''){
			var sdSplits = sd.split("/");
				data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			}
			var ed = $('#endDate').val();
			if(ed!=''){
				var edSplits = ed.split("/");
				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
			}
			data['grouping'] = $('#grouping').val();
			data['mode'] = $('#mode').val();
			data['type'] = $('#objective').val();
			data['product'] = $('#product').val();
			data['topic'] = $('#topic').val();
			data['subtopic'] = $('#subtopic').val();
			data['kol_id'] = $('#kol-id').val();
			data['org_id'] = $('#org_institution_id').val();
			data['user_id'] = $('#user-name').val();
			$.ajax({
				url: base_url+'interactions/interactions_numeric_report',
				dataType: 'text',
				data:data,
				type:'post',
				success: function(returnData) {
					$("#numericReportContainer").html(returnData);
					$('#numericReportContainer').unblock();
				}
			});
			return true;
		}
	}

	function getProduct(proObject){
		$('#loadingProduct').show();
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		var typeId = $(proObject).val();
		var productId = 'product';
		var topicId = 'topic';

		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		$('#'+productId+" option" ).remove();
		$('#'+productId).append('<option value="">Select</option>');
		$.ajax({
			url:'<?php echo base_url()?>interactions/get_product_by_type/'+typeId,
			dataType:'json',
			success:function(returndata){
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
	  				  $('#'+productId).append($("<option></option>")
		                    .attr("value",key)
		                    .text(value));
			
				});
			},
			complete:function(){
				$('#loadingProduct').hide();
				}
		});
	}

	var interactionsByTopicData;
	var interactionsByChannelData;
	var interactionsByEmployeeData;
	var interactionsByMonthData;
	function generateChartReport() {
		if(!$("#interactionsFilterForm").validate().form()){
			return false;
		}else{
			$('label.error').remove();
			$('#chartTable').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			var data = {};
			var sd = $('#startDate').val();
			if(sd!=''){
			var sdSplits = sd.split("/");
				data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			}
			var ed = $('#endDate').val();
			if(ed!=''){
				var edSplits = ed.split("/");
				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
			}
			data['grouping'] = $('#grouping').val();
			data['mode'] = $('#mode').val();
			data['type'] = $('#objective').val();
			data['product'] = $('#product').val();
			data['topic'] = $('#topic').val();
			data['kol_id'] = $('#kol-id').val();
			data['org_id'] = $('#org_institution_id').val();
			data['user_id'] = $('#user-name').val();
/*
			$.ajax({
				url: base_url+'interactions/interactions_chart_report',
				dataType: 'json',
				data:data,
				type:'post',
				success: function(returnData) {
							var interByTopic 	= returnData.arrByTopic;
							var interByChannel 	= returnData.arrByChannel;
							var interByEmployee = returnData.arrByEmployee;
							var totalCount = 0;

							$.each(interByTopic,function(key, value){
								totalCount = totalCount + value[1];
							});
							interactionsByTopic(interByTopic,totalCount);
							interactionsByTopicData.redraw();
							totalCount = 0;
							$.each(interByChannel,function(key, value){
								totalCount = totalCount + value[1];
							});
							interactionsByChannel(interByChannel,totalCount);
							interactionsByChannelData.redraw();
							
							totalCount = 0;
							$.each(interByEmployee,function(key, value){
								totalCount = totalCount + value[1];
							});				
							interactionsByEmployee(interByEmployee,totalCount);
							interactionsByEmployeeData.redraw();
							
							interactionsByMonth(returnData.arrByMonth,returnData.arrMonths);
							interactionsByMonthData.redraw();
							
				}
			});
			*/

			$.ajax({
				url: base_url+'interactions/interactions_by_topic',
				dataType: 'json',
				data:data,
				type:'post',
				success: function(returnDataTopic) {
						var interByTopic 	= returnDataTopic.arrByTopic;
						var totalCount1 = 0;
						$.each(interByTopic,function(key, value){
							totalCount1 = totalCount1 + value[1];
						});
						interactionsByTopic(interByTopic,totalCount1);
				}
			});

			$.ajax({
				url: base_url+'interactions/interactions_by_channel',
				dataType: 'json',
				data:data,
				type:'post',
				success: function(returnDataChannel) {
						var interByChannel 	= returnDataChannel.arrByChannel;
						var totalCount2 = 0;
						$.each(interByChannel,function(key, value){
							totalCount2 = totalCount2 + value[1];
						});
						interactionsByChannel(interByChannel,totalCount2);
				}
			});

			$.ajax({
				url: base_url+'interactions/interactions_by_employee',
				dataType: 'json',
				data:data,
				type:'post',
				success: function(returnDataEmployee) {
						var interByEmployee = returnDataEmployee.arrByEmployee;
						var totalCount3 = 0;
						$.each(interByEmployee,function(key, value){
							totalCount3 = totalCount3 + value[1];
						});				
						interactionsByEmployee(interByEmployee,totalCount3);
				}
			});

			$.ajax({
				url: base_url+'interactions/interactions_by_month',
				dataType: 'json',
				data:data,
				type:'post',
				success: function(returnDataMonth) {										
						interactionsByMonth(returnDataMonth.arrByMonth,returnDataMonth.arrMonths);						
				}
			});
		}
		$("#chartTable").unblock();		
		return true;
	}

	function interactionsByTopic(data,totalCount){   
	     var chart = c3.generate({
	     	bindto: '#interactionsByTopic',
	 	    data: {
	 	        // iris data from R
	 	        columns: data,
	 	        type : 'pie'	       
	 	    },	    
	 	    size: {
	 	    	  width: 250
	 	    },
	 	    color: {
	 	    	  pattern: chartColors
	     	},
	 	    pie: {
	 	        label: {
	 	            format: function (value, ratio, id) {
	 	                return d3.format(".0%")(ratio);
	 	            	//return value+'-'+d3.format('%')(ratio)
	 	            }
	 	        }
	 	    },
	 	    tooltip: {
	 	        format: {	            
	 	            value: function (value, ratio, id) {           
	 	            	return value+' ('+d3.format('.0%')(ratio)+')';
	 	            }	            
	 	        }
	 	    },
		    legend: {
		        show: false
		    }
	 	});
	    var dataLegend=new Array();
	 	$.each(data, function(i, item) {
	 		dataLegend.push(item[0]);
	 	});
	     d3.select('#interactionsByTopic').insert('div', '.chart').attr('class', 'legend').selectAll('h5')
	     .data(dataLegend)
	     .enter().append('h5')
	     .attr('data-id', function (id) { return id; })
	     .html(function (id) { return id; })
	     .each(function (id) {
	         d3.select(this).style('background-color', chart.color(id));
	     })
	     .on('mouseover', function (id) {
	         chart.focus(id);
	     })
	     .on('mouseout', function (id) {
	         chart.revert();
	     })
	     .on('click', function (id) {
	         chart.toggle(id);
	     });
				
	}

	function interactionsByChannel(data,totalCount){		
		var chart = c3.generate({
	    	bindto: '#interactionByChannel',
		    data: {
		        // iris data from R
		        columns: data,
		        type : 'pie'	       
		    },	    
		    size: {
		    	  width: 250
		    },
		    color: {
		    	  pattern: chartColors
	    	},
		    pie: {
		        label: {
		            format: function (value, ratio, id) {
		                return d3.format(".0%")(ratio);
		            	//return value+'-'+d3.format('%')(ratio)
		            }
		        }
		    },
		    tooltip: {
	 	        format: {	            
	 	            value: function (value, ratio, id) {           
	 	            	return value+' ('+d3.format('.0%')(ratio)+')';
	 	            }	            
	 	        }
	 	    },
		    legend: {
		        show: false
		    }
	 	});
	    var dataLegend=new Array();
	 	$.each(data, function(i, item) {
	 		dataLegend.push(item[0]);
	 	});
	     d3.select('#interactionByChannel').insert('div', '.chart').attr('class', 'legend').selectAll('h5')
	     .data(dataLegend)
	     .enter().append('h5')
	     .attr('data-id', function (id) { return id; })
	     .html(function (id) { return id; })
	     .each(function (id) {
	         d3.select(this).style('background-color', chart.color(id));
	     })
	     .on('mouseover', function (id) {
	         chart.focus(id);
	     })
	     .on('mouseout', function (id) {
	         chart.revert();
	     })
	     .on('click', function (id) {
	         chart.toggle(id);
	     }); 
	}

	function interactionsByEmployee(interByEmployee,totalCount){	
		var chart = c3.generate({
	    	bindto: '#interactionsByEmployee',
		    data: {
		        // iris data from R
		        columns: interByEmployee,
		        type : 'pie'	       
		    },	    
		    size: {
		    	  width: 250
		    },
		    color: {
		    	  pattern: chartColors
	    	},
		    pie: {
		        label: {
		            format: function (value, ratio, id) {
		                return d3.format(".0%")(ratio);
		            	//return value+'-'+d3.format('%')(ratio)
		            }
		        }
		    },
		    tooltip: {
	 	        format: {	            
	 	            value: function (value, ratio, id) {           
	 	            	return value+' ('+d3.format('.0%')(ratio)+')';
	 	            }	            
	 	        }
	 	    },
		    legend: {
		        show: false
		    }
	 	});
	    var dataLegend=new Array();
	 	$.each(interByEmployee, function(i, item) {
	 		dataLegend.push(item[0]);
	 	});
	     d3.select('#interactionsByEmployee').insert('div', '.chart').attr('class', 'legend').selectAll('h5')
	     .data(dataLegend)
	     .enter().append('h5')
	     .attr('data-id', function (id) { return id; })
	     .html(function (id) { return id; })
	     .each(function (id) {
	         d3.select(this).style('background-color', chart.color(id));
	     })
	     .on('mouseover', function (id) {
	         chart.focus(id);
	     })
	     .on('mouseout', function (id) {
	         chart.revert();
	     })
	     .on('click', function (id) {
	         chart.toggle(id);
	     }); 
	}

	function interactionsByMonth(arrByMonth,arrMonths){	
		var data =arrByMonth;
		var DataValues = [];
        var DataGroups = [];
		$.each(data, function (key, value) {  	
        	DataValues[key]=data[key].data;
        	DataGroups[key]=data[key].name;
        	DataValues[key].unshift(data[key].name);
        });	
		arrMonths.unshift("x");
		DataValues.unshift(arrMonths);
		//console.log(JSON.stringify(DataGroups));  
		  var chart = c3.generate({
		    	bindto: '#interactionsByMonth',
		    	data: {
		    	 x : 'x',
		            columns: DataValues,        	
		            groups: [DataGroups],
		            type: 'bar'
		        },
		        size: {
			    	  width: 400
			    },
		        axis: {
		            x: {
		                type: 'category', // this needed to load string x value
		                tick: {
		           	     count:3 ,multiline: false          	    
		           	    },
		           	    label: {
		              	        text: 'Year',
		              	        position: 'outer-center',
		              	     }	
		            },
		            y:{
		            	/*tick: {	        	  
		  	        	  count:4,
		  	        	  format: d3.format('.0f')
		  	        	},*/
		            	label: {
		          	        text: product,
		          	        position: 'outer-middle',
		          	     }
		            }
		        },
		        color: {
			    	  pattern: chartColors
		        }
		   }); 
		  removeFloatingTicks('#interactionsByMonth');
	}

	function resetDropDowns(){
		$('#loaderType').show().hide(2000);	
	}
	

	function getTopic(){
		$('#loadingTopic').show().hide(2000);
	}
	
	function get_currentdate(){
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();
		if(dd<10) {
		    dd='0'+dd
		} 
		if(mm<10) {
		    mm='0'+mm
		} 
		today = mm+'/'+dd+'/'+yyyy;
		return today;
	}
	function listInteractions(){
		$('#gridContainer').html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');
		var data = {};

		data['grouping'] = $('#grouping').val();

		data['mode'] = $('#mode').val();

		data['type'] = $('#objective').val();

		data['product'] = $('#product').val();

		data['topic'] = $('#topic').val();

		data['kol_id'] = $('#kol-id').val();
                
		data['org_id'] = $('#org_institution_id').val();

		data['user_id'] = $('#user-name').val();
		data['manager_id'] = $('#manager_id').val();

		var sd = $('#startDate').val();



		if(sd!=''){

		var sdSplits = sd.split("/");

			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

		}



		var ed = $('#endDate').val();

		if(ed!=''){

			var edSplits = ed.split("/");

			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

		}

		
		var ele=document.getElementById('test');
		var gridWidth=ele.clientWidth - 15;
		var orgName = ' / Org';
		if(kolId>0){
			orgInteractionAction =  true;
		}else{
			orgInteractionAction =  false;
		} 
	//	gridWidth+=10;
		jQuery("#listInteractionsResultSet").jqGrid({
			url:base_url+'interactions/list_interactions_by_date_range/',
			datatype: "json",
		   	colNames:['Id','','','<?php echo lang("HCP");?>'+orgName+' Name',"Interaction Date","Employee Name",'Interaction Type','Discussion Type',product,recordedBy,'Quality',"<div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off\-Label Question'>UOQ</span></div>",action,'','','','','','','client_id','data_type_indicator'],
		   	colModel:[
				{name:'generic_id',index:'generic_id', hidden:false,width:90},
				{name:'save_later',index:'save_later', hidden:true},
				{name:'micro',width:30, search:false,align:'center',sortable:false},
				{name:'kol_name',index:'kol_name',width:170, resizable:false},
				{name:'date',index:'date',width:120,sorttype:'date',formatoptions: {newformat:'m/d/Y'}, datefmt: 'm/d/Y'},
		   		{name:'recorded_by_name',index:'recorded_by_name',width:100, resizable:false},
		   		{name:'mode_name',index:'mode_name',width:100, resizable:false},
				{name:'objective_name',index:'objective_name',width:180, resizable:false},
		   		{name:'product_name',index:'product_name',width:150, resizable:false},
		   		{name:'recorded_by',index:'recorded_by',width:100, resizable:false},
		   		{name:'quality_interaction',index:'quality_interaction',width:100, resizable:false,hidden:true},
		   		{name:'mirf',width:60,align:'center',align:'left',search:true,sortable:true,hidden:true, formatter: function (cellvalue, options, rowObject) {
			   		var mirfText = '';
			   		if(rowObject.mirfAllowed){
						if(cellvalue =="Add"){
							mirfText = "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"</a>";
						}else{
							if(rowObject.save_later == 1)
								mirfText = "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"Edit</a>"+" "+"<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
							else
								mirfText = "<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
							//mirfText += "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"</a>"+" "+"<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"Edit"+"</a>";
						}
					}else{
						if(rowObject.mirf_id != null)
							mirfText = "<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
                                   }
	            return mirfText;
	            }},
	            {name:'act',width:120,align:'center',search:false,sortable:false},
	            {name:'mirfAllowed',width:60,align:'center',hidden:true},
		   		{name:'mirf_id',width:60,align:'center',hidden:true},
		   		{name:'eAllowed',width:100,index:'eAllowed', hidden:true,search:false},
		   		{name:'id',index:'id', hidden:true},
				{name:'msl_id',index:'msl_id', hidden:true},
				{name:'is_org_interaction',index:'is_org_interaction', hidden:true},
				{name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
		   	],
			postData:data,
		   	rowNum:10,
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#listInteractionsPage',
		   	mtype: "POST",
		   	sortname: 'date',
		    viewrecords: true,
		    sortorder: "desc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:interactionsTitle,
		    grouping: false, 
			groupingView : { 
				groupField : ['kol_name'], 
				groupColumnShow : [false], 
				groupText : ['<b>{0}</b>  ({1})'], 
				groupCollapse : false, 
				groupOrder: ['asc'], 
			//	groupSummary : [true], 
				groupDataSorted : true 
			},
			gridComplete: function(){
				
				//Get array of id'f from jqgrid			   
		    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 
		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
		    	for(var i=0;i < arrIds.length;i++){ 
		    		var actionLink = '';
			    	var id = arrIds[i];
			    	var isAnalyst = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'client_id');
			    	 var createdByName = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'recorded_by_name');
			    	var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', id);

			    	if(isAnalyst != 1){                    
                		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
                     }else{
                     //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
                     	var dataTypeIndicator = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'data_type_indicator');
                     	actionLink += data_type_indicator(dataTypeIndicator);		    		
                     }
			    	//Edit and Delete labels 	
		    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
//		    		if(rowData.save_later == '1'){
//				    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"></div></div>";
//	
//			    		jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
//		    		}
                        <?php if($controllerName != 'interactions') {?>
								if(rowData.is_org_interaction == 0 && orgInteractionAction){
    								var lock = '';
    								<?php if($this->session->userdata("user_id") == 2322){?>
    									if(rowData.save_later == '1')
    	                                	lock = "<a href='javascript:void(0)' onclick='unlock_interaction("+rowData.id+",0,\""+rowData.generic_id+"\","+rowData.msl_id+")'>Lock</a>";
    									else
    										lock = "<a href='javascript:void(0)' onclick='unlock_interaction("+rowData.id+",1,\""+rowData.generic_id+"\","+rowData.msl_id+")'>Unlock</a>";									
    								<?php }?>    
    	                                if((rowData.eAllowed == 'true')){
    						    	  		actionLink += "<div>"+lock+"</div><div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\"></a></div>";
    						    	  		actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
    									}else{
    										actionLink += "<div>"+lock+"</div>";			
    									}
    	                                if((rowData.dAllowed == 'true')){
    						    	 		//actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
    	                                } 
								}
                        <?php } ?> 
			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
		    		

		    		//Microview label	

			    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";
			    	if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN)
		    			microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfileCalenderView('"+rowData.id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";
		    		else
		    			microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+rowData.id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";	

			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 

			    	}
		    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");
		    	//Initialize the tooltips
		    	initializeCustomToolTips();
		    	//if(preloadAddInteractionData){
		    	//	$("#addInteractionContainer").load(base_url+'interactions/add_interaction');
		    		//preloadAddInteractionData	= false;
		    	//}

		    	var postParams = $('#listInteractionsResultSet').getGridParam("postData");
	        	//alert(postParams.toSource());
	        	postParams = JSON.stringify(postParams);
	        	$("#excel-filters").val(postParams);
		    },
	   		rowList:paginationValues
		});

		//Hide the column recorded by if the logged in user role is not manager
	   	var userRole=userRoleId;
	   	var managerRoleId=ROLE_MANAGER;
	   	var adminRoleId=ROLE_ADMIN;
	   	
	   	//if(userRole!=managerRoleId)	 
	   		//jQuery("#listInteractionsResultSet").hideCol("recorded_by"); 
			
		jQuery("#listInteractionsResultSet").jqGrid('navGrid','#listInteractionsPage',{edit:false,add:false,del:false,search:false,refresh:false});

		//Toolbar search bar below the Table Headers
		jQuery("#listInteractionsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#listInteractionsResultSet").jqGrid('navButtonAdd',"#listInteractionsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 
		jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth); 
	}

	function generateReport(){

		
		
		if($('#orgIntaerctionContainer').css('display')=='block'){

			//$("#report").trigger("click");

			generateListReport();

			}else{
				
				showGrid();

			}

		}



	function generateListReport(){



		$('#orgIntaerctionContainer').show();

		$('#interactionsList').hide();

		

		

			$('label.error').remove();

			$('#orgIntaerctionContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			var data = {};

			

			var sd = $('#startDate').val();

			if(sd!=''){

					var sdSplits = sd.split("/");

					data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			}



			var ed = $('#endDate').val();

			if(ed!=''){

				var edSplits = ed.split("/");

				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

			}

			data['grouping'] = $('#grouping').val();

			data['mode'] = $('#mode').val();

			data['type'] = $('#objective').val();

			data['product'] = $('#product').val();

			data['topic'] = $('#topic').val();

			data['subtopic'] = $('#subtopic').val();

			//data['kol_id'] =kolId;

			data['user_id'] = $('#user-name').val();

			data['startFrom'] = 0;

			

			$.ajax({

				url: base_url+'kols/view_interactions/'+kolId,

				dataType: 'text',

				data:data,

				type:'post',

				success: function(returnData) {

					

					if(returnData==' '){

							alert("No Interactions found");

						}

					$("#orgIntaerctionContainer").html(returnData);

					$('#orgIntaerctionContainer').unblock();

				}

			});

			return true;



			

	}

	var isRequest=false;

	function generateLazyLoadReport(){

		$('div#lastPostsLoader').show();

		 if(!(isRequest)){

			 isRequest=true;

			$('label.error').remove();

			//$('#orgIntaerctionContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			var data = {};

			var sd = $('#startDate').val();

			if(sd!=''){

					var sdSplits = sd.split("/");

					data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			}



			var ed = $('#endDate').val();

			if(ed!=''){

				var edSplits = ed.split("/");

				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

			}

		

			//data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			//data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

			data['grouping'] = $('#grouping').val();

			data['mode'] = $('#mode').val();

			data['type'] = $('#objective').val();

			data['product'] = $('#product').val();

			data['topic'] = $('#topic').val();

			data['kol_id'] = $('#kol-id').val();

                        data['org_id'] = $('#org_institution_id').val();
                        
			data['user_id'] = $('#user-name').val();

			data['startFrom'] = $('.expand:last').attr('id');

			data['interaction_ids'] =  $('#ids').val();

			

			$.ajax({

				url: base_url+'kols/view_interactions/'+kolId,

				dataType: 'text',

				data:data,

				type:'post',

				success: function(returnData) {

					if(returnData==' '){

							alert("No Interactions found");

						}

					$("#orgIntaerctionContainer").append(returnData);

				//	$('#orgIntaerctionContainer').unblock();

					isRequest=false;

					$('div#lastPostsLoader').hide();

				}

			});

			return true;

		 }

			

	}
	function addInteraction(){
	
		//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");

		//	$("#interactionAddContainer").dialog("open");

		//	$("#interactinAddProfileContent").load(base_url+'interactions/add_interaction/'+kolId);

			$('#interactionsContainer').hide();

			$("#addInteractionContainer").show();

			//if($("#addInteractionContainer").html()==''){

				$("#editInteractionContainer").html('');
				//alert("Ss");
				//$("#addInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#container").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#addInteractionContainer").load(base_url+'interactions/add_interaction/'+kolId,function( response, status, xhr ) {
					$("#container").unblock();
				});

			//}

			return false;	

		}

		function cancelAddInteraction(){
			$('#addInterButton').show();
			$('#addInteractionContainer').hide();

			$('#editInteractionContainer').hide();

			$("#interactionsContainer").show();

			$("#addInteractionContainer").html('');
			$("#interactionForm").html('');

			var interactionContainer	= $("#listInteractionsResultSet").html();
			$("html, body").animate({ scrollTop: 0 }, "slow");
			if(interactionContainer==''){

				listInteractions();

			}

		}

		/**

		* Opens the Modal Box with the Form to Edit ineraction details

		* @author 

		* @since

		* @param: kolId

		*/

		function editInteraction(interactionId){

		//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");

		//	$("#interactionEditContainer").dialog("open");

		//	$("#interactinEditProfileContent").load(base_url+'interactions/edit_interaction/'+interactionId+'/'+kolId);

			$('#interactionsContainer').hide();

			$('#addInteractionContainer').html('');

			$("#editInteractionContainer").html('').show();

			$("#container").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			//$("#editInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'50%',cursor:'default'}});

			$("#editInteractionContainer").load(base_url+'interactions/edit_interaction/'+interactionId+'/'+kolId,function( response, status, xhr ) {
				$("#container").unblock();
			});

			return false;	

		}



		function export_excel(){



			

			var excelFilters = '';



			var sd = $('#startDate').val();



			if(sd != ''){

				var sdSplits = sd.split("/");

				var from_month_year = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

				excelFilters += "Start Month : "+from_month_year+",";

			}



			var ed = $('#endDate').val();

			if(ed != ''){

				

				var edSplits = ed.split("/");

				var to_month_year = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

				excelFilters += "End Month : "+to_month_year+",";

			}

		

				$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

					if($(this).val() != ''){

						var filterName = $(this).attr('name');

						var filterValue = $(this).val();

						excelFilters += filterName+" : "+filterValue+",";

					}

				});

				//$("#excel-filters").val(excelFilters);

				var selectedOPtion = $(".ui-pg-selbox").val();

				$(".ui-pg-selbox option:last").attr('selected','selected');

		    	$('.ui-pg-selbox').trigger('change');

		    	if($("#listInteractionsResultSet").html() != null )

		    		var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs');

		    	else

		    		var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');

		    if($('#orgIntaerctionContainer').css('display')!='block'){

	    	

	    		$('#ids').val(arrIds);

	    	}



	    	

	    	

	    	var kol_name = $('#kol-name').val();

	    	if(kol_name !=''){

	    		var filterName = "KTL Name";

	    		excelFilters += filterName+" : "+kol_name.replace(",", "")+",";

		    //	$('#kolNameExport').val(kol_name );



	    	}

	    	var grouping = $('#grouping').val();

	    	

	    	if(grouping !=''){

	    		var filterName = "Interaction Category";

	    		excelFilters += filterName+" : "+$('#grouping option:selected').text()+",";



	    	}

	    	var mode = $('#mode').val();



	    	if(mode !=''){

	    		var filterName = "Interaction Type";

	    		excelFilters += filterName+" : "+$('#mode option:selected').text()+",";



	    	}

	    	var userName = $('#user-name').val();



	    	if(userName !=''){

	    		var filterName = "Employee Name";

	    		excelFilters += filterName+" : "+$('#user-name option:selected').text()+",";



	    	}

	    	var type = $('#objective').val();



	    	if(type !=''){

	    		var filterName = "Discussion Type";

	    		excelFilters += filterName+" : "+$('#objective option:selected').text()+",";

		    	

		    //	$('#typeExport').val($('#objective option:selected').text());



	    	}

	    	var product = $('#product').val();



	    	if(product !=''){

	    		var filterName = '<?php echo lang("Overview.Product");?>';

	    		excelFilters += filterName+" : "+$('#product option:selected').text()+",";

	    	}

	    	var topic = $('#topic').val();



	    	if(topic!=''){

	    		var filterName = "Topic";

	    		excelFilters += filterName+" : "+$('#topic option:selected').text();



	    	}
                
//                 var subTopic = $('#subtopic').val();



	    	/*if(subTopic!=''){

	    		var filterName = "Sub Topic";

	    		excelFilters += filterName+" : "+$('#subtopic option:selected').text()+",";



	    	}*/

	    	$("#excel-filters1").val(excelFilters);

	    //	return false;

	    	$('#export').submit();

	    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

	    	$('.ui-pg-selbox').trigger('change');

		}


		function viewInteractionMicroProfileCalenderView(interactionId){
                    viewInteractionMicroProfile(interactionId);
//			var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', interactionId);
//			openCalenderSnapshotBox(rowData);

			return false;
		}

		function viewInteractionMicroProfile(interactionId){
			showHideSidebar(1);
			$("#showHideSidebar").hide();			
			$('#interactionsContainer').hide();

			$("#viewInteractionContainer").show();

			$("#viewInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			$("#viewInteractionContainer").load(base_url+'interactions/view_micro_interaction/'+interactionId);

		}	



		function showIntarctionTable(){

			$('#interactionsContainer').show();

			$('#viewInteractionContainer').hide();

		}



		function showAction(id){

			

			$('#show_'+id).show();

		}



		function hideAction(id){
        $('#show_' + id).hide();
    }
	
		
	$(document).ready(function(){
			var dd = "<?php echo $this->uri->segment(5); ?>";
			if(dd){
				addInteraction();
			}else{
				$("#interactionsContainer").css("display","block");
			}
			
		$('#manager_id').chosen({
            placeholder_text: "Click to Select Manager",
            allow_single_deselect: true
        });
        
		$('#grouping').chosen({
            placeholder_text: "Click to Select Interaction Category",
            allow_single_deselect: true
        });

		$('#mode').chosen({
            placeholder_text: "Click to Select Interaction Type",
            allow_single_deselect: true
        });

		$('#user-name').chosen({
            placeholder_text: "Click to Select Employee Name",
            allow_single_deselect: true
        });

		$('#product').chosen({
            placeholder_text: "Click to Select "+product,
            allow_single_deselect: true
        });

		$('#objective').chosen({
            placeholder_text: "Click to Select Discussion Type",
            allow_single_deselect: true
        });

		$('#topic').chosen({
            placeholder_text: "Click to Select Topic",
            allow_single_deselect: true
        });

		});			

	function changeView(thisEle){

		$('.tooltip.in').hide();

  		if(viewType=='list'){

  			viewType	= 'tabular';

  			$('#toggleViewIcon').removeClass('listView');

  			generateListReport();

  		}else{

  			viewType	= 'list';

  			$('#toggleViewIcon').addClass('listView');

  			showGrid();

  		}

	}



	function test(event){

		 event.stopPropagation();



	}
function showView(){

		

		generateNumericReport();

	}

	function showGrid(){

		$('#hide').hide();

		$('#interactionsList').show();



		$('#gridContainer').html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');

		$('#orgIntaerctionContainer').hide();

		$('#gridContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});



		var data = {};

		

		data['grouping'] = $('#grouping').val();

		data['mode'] = $('#mode').val();

		data['type'] = $('#objective').val();

		data['product'] = $('#product').val();

		data['topic'] = $('#topic').val();

		data['kol_id'] = kolId;
                
		data['org_id'] = $('#org_institution_id').val();

		data['user_id'] = $('#user-name').val();

		var sd = $('#startDate').val();



		if(sd!=''){

		var sdSplits = sd.split("/");

			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

		}



		var ed = $('#endDate').val();

		if(ed!=''){

			var edSplits = ed.split("/");

			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

		}

		

		var ele=document.getElementById('gridContainer');

		var gridWidth=ele.clientWidth;

	//	gridWidth+=10;

		jQuery("#listInteractionsResultSet").jqGrid({

			url:base_url+'interactions/list_interactions_by_date_range/',

			datatype: "json",

		   	colNames:['Id','','<?php echo lang("KOL");?> Name','Date','Recorded By','Interaction Type','Discussion Type',product,"<div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off\-Label Question'>UOQ</span></div>",'Action',''],

		   	colModel:[

				{name:'id',index:'id', hidden:true},

				{name:'micro',width:30, search:false,align:'center',sortable:false},

				{name:'kol_name',index:'kol_name',width:170, resizable:false},

				{name:'date',index:'date', width:70, resizable:false},

		   		{name:'recorded_by',index:'recorded_by',width:170, resizable:false},

		   		{name:'mode_name',index:'mode_name',width:100, resizable:false},

				{name:'objective_name',index:'objective_name',width:210, resizable:false},

		   		{name:'product_name',index:'product_name',width:150, resizable:false},

		   		{name:'mirf',width:100,align:'center',search:false,sortable:false},
		   		{name:'act',width:40,align:'center',search:false,sortable:false},
		   		{name:'eAllowed',index:'eAllowed', hidden:true},   		

		   	],

		   	postData:data,

		   	rowNum:10,

		   	rownumbers: true,

		   	autowidth: false, 

		   	loadonce:true,

		   	ignoreCase:true,

		   	hiddengrid:false,

		   	height: "auto",		 

		   	pager: '#listInteractionsPage',

		   	mtype: "POST",

		   	sortname: 'kol_name',

		    viewrecords: true,

		    sortorder: "desc",

		    shrinkToFit:true,

		    jsonReader: { repeatitems : false, id: "0" }, 

		    caption:"Interactions",

		    grouping: true, 

			groupingView : { 

				groupField : ['kol_name'], 

				groupColumnShow : [false], 

				groupText : ['<b>{0}</b>  ({1})'], 

				groupCollapse : false, 

				groupOrder: ['asc'], 

			//	groupSummary : [true], 

				groupDataSorted : true 

			},

			gridComplete: function(){

				

				//Get array of id'f from jqgrid			   

		    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 

		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row

		    	for(var i=0;i < arrIds.length;i++){ 
		    		actionLink = '';
			    	var id = arrIds[i];		    	
			    	var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', id);
			    	//Edit and Delete labels 	
		    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
//		    		if(rowData.save_later == '1'){
//				    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"></div></div>";
//	
//			    		jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
//		    		}
                                var actionLink;
                                        if((rowData.eAllowed == 'true')){
					    	  actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";
					}
                                        if((rowData.dAllowed == 'true')){
//					    	 actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                                        } 
			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
		    		

		    		//Microview label	

			    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";

		    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";

			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 

			    	} 

		    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");

		    	//Initialize the tooltips

		    	initializeCustomToolTips();

		    	$('#gridContainer').unblock();

		    	//if(preloadAddInteractionData){

		    	//	$("#addInteractionContainer").load(base_url+'interactions/add_interaction');

		    		//preloadAddInteractionData	= false;

		    	//}

		    },

	   		rowList:[10,50,150]

		});



		//Hide the column recorded by if the logged in user role is not manager

	   	var userRole=userRoleId;

	   	var managerRoleId=ROLE_MANAGER;
	   	var adminRoleId=ROLE_ADMIN;
	   	

	   	if(userRole!=managerRoleId || userRole!=adminRoleId)	 

	   		jQuery("#listInteractionsResultSet").hideCol("recorded_by"); 

			

		jQuery("#listInteractionsResultSet").jqGrid('navGrid','#listInteractionsPage',{edit:false,add:false,del:false,search:false,refresh:false});



		//Toolbar search bar below the Table Headers

		jQuery("#listInteractionsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		

		

		//Toggle Toolbar Search 

		jQuery("#listInteractionsResultSet").jqGrid('navButtonAdd',"#listInteractionsPage",{

			caption:"Search",title:"Toggle Search",

			onClickButton:function(){ 			

				if(jQuery(".ui-search-toolbar").css("display")=="none") {

					jQuery(".ui-search-toolbar").css("display","");

				} else {

					jQuery(".ui-search-toolbar").css("display","none");

				}							

			} 

		}); 

		jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth); 

	}

	
	function expand(id,thisEle){

		

		if($(thisEle).attr('class')=='expand'){

			

			$(thisEle).removeClass('expand');

			$(thisEle).addClass('collapse');

			$('#expand_'+id).show();

				

			$.each($('#interactionid_'+id).find('tr.hide'),function(){

									$(this).css('display','table-row');

			});

		}else{

			

			$(thisEle).removeClass('collapse');

			$(thisEle).addClass('expand');

			$('#expand_'+id).hide();

			$.each($('#interactionid_'+id).find('tr.hide'),function(){

				$(this).hide();

			});

		}



	}

	$(document).ready(function(){
		var dd = "<?php echo $this->uri->segment(5); ?>";
		
		if(dd){
			//addInteraction();
		}else{
			$("#interactionsContainer").css("display","block");
			listInteractions();
			
		}
	});
	
	$(document).ready(function() {
		var addLockUnlock = {
				 title: "Unlock Interaction",
				 modal: true,
				 autoOpen: false,
				 width: 500,
//				 height: 400,
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
		$("#addLockUnlock").dialog(addLockUnlock);
	});
	var lockInterId,lockInterflag,lockInterGenericId,lockMslId;
	function unlock_interaction(interId,flag,interGenericId,Msl){ 
		lockInterId = interId;
		lockInterflag = flag;
                lockInterGenericId=interGenericId;
                lockMslId=Msl;
		if(flag == '1'){
			$(".addLockUnlockContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#addLockUnlock').dialog("open");
			$('.addLockUnlockContent').load(base_url+'interactions/add_lock_unlock/');
			return false;
		}else{
			process_unlock_interaction(interId,flag,interGenericId,Msl);
		}
	}

	function process_unlock_interaction(interId,flag,interGenericId,Msl){ 
		if(flag == '0'){
			var textMsg = 'Are you sure you want to lock the interaction';
			jConfirm(textMsg,"Confirm box", function(r){
				if(r){
					$.ajax({
						url: "<?php echo base_url();?>interactions/unlock_interactions_by_id/"+kolId+"/"+interId+"/"+flag+"/"+interGenericId+"/"+Msl,
						dataType: "json",
						success: function(retData){
							if(retData.status)
								$("#listInteractionsResultSet").trigger('reloadGrid');
							else
								alert("Failed try again");
						}
					});
				}else{
					return false;
				}
			});
		}else{
			var data = $("#lockUnlckForm").serialize();
			$.ajax({
				url: "<?php echo base_url();?>interactions/unlock_interactions_by_id/"+kolId+"/"+lockInterId+"/"+lockInterflag+"/"+lockInterGenericId+"/"+lockMslId,
				dataType: "json",
				data: data,
				type: "post",
				success: function(retData){
					if(retData.status){
						$('#addLockUnlock').dialog("close");
						$("#listInteractionsResultSet").trigger('reloadGrid');
					}else{
						alert("Failed try again");
					}
				}
			});
		}
		
	}

	function deleteInteraction(id){
		jConfirm("Are you sure you want to delete the interaction?","Confirm box", function(r){
			if(r){
				$.ajax({
					url: "<?php echo base_url();?>interactions/delete_interactions_by_id/"+id,
					dataType: "json",
					type: "post",
					success: function(retData){
						if(retData.status){
							$("#listInteractionsResultSet").trigger('reloadGrid');
						}else{
							alert("Failed deleting, Try again");
						}
					}
				});
			}
		});
	}	

	function showHideSidebar(val){
		var widthLeft = $("#left").width();
		if(widthLeft == 855){
			$("#left").css('width','1171px');
			$("#showHideSidebar").text("Show Sidebar");
		}else{
			$("#left").css('width','855px');
			$("#showHideSidebar").text("Hide Sidebar");
		}
		if(val == '1' && $("#showHideSidebar").text() == 'Hide Sidebar'){
			
		}else{
			$("#right").toggle();
		}
		listInteractions();
	}	

	function formReset(){
		var currentController = '<?php echo $this->uri->segment(1);?>';
		var kolId = $("#kol-id").val();
		document.getElementById("interactionsFilterForm").reset();
		//$('option').prop('selected', false);
		$('#user-name').prop('selected', true);
	    $('select').trigger('liszt:updated');
	   
	    if(currentController == 'kols'){
	    	$("#kol-id").val(kolId);
		}else{
			$("#kol-id").val('');
			kolId = 0;
		}
	    if(kolId>0){
			$('#startDate').val(yearFirstDate);
		}else{
			$('#startDate').val(monthFirstDate);
		}
		 
         // $('#endDate').val(todayDate);
         var cdate = get_currentdate();
         $('#endDate').val(cdate);
	    listInteractions();
	    generateNumericReport();
	    $("#chart").trigger("click");
	    $("#list").trigger("click");
	}
	function addNewKolProfile(KolId,thisEle){
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		jConfirm(profileRequestConfirmMessage,"Confirm message",function (r){
			if(r){
				requestProfile(KolId,thisEle);
				return false;
			}else{
				return false;
			}
		});
	}

	function requestProfile(KolId,thisEle){
		var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
// 					$(thisEle).remove();
					$('.requestKolId'+KolId).attr('onclick','').unbind('click');
					$('.requestKolId'+KolId).removeAttr('data-original-title');
					$('.requestKolId'+KolId).css('pointer-events','none');
					$('.requestKolId'+KolId).css('cursor','default');
					$('.requestKolId'+KolId).css('text-decoration','none');
					$('.requestKolId'+KolId).css('background','#bbbbbb none repeat scroll 0 0');
					$('.requestKolId'+KolId).css('border','1px solid #bbbbbb');
					$('.requestKolId'+KolId).text('Requested');
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
	}
	
</script>
<style>
    #container {
        min-height: 500px !important;
    }
    .fc-event-time{
   display : none;
}
    #calenderContent{
    	height:650px;
    	overflow:auto;
    	width: 100%;
    }
    #calender{
    	width: 95%;
    }
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	#interactionsContainer{
		/*width: 805px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;*/
	}

	#filtersContainer{
		height: 175px;
	}
	#numericReportContainer{
		min-height:500px;
	}
	#numericReportContainer > label{
		display:block;
		background-color: #D4EAAC;
		text-align:left;
		height: 25px;
   		padding-top: 5px;
   		padding-left: 6px;
	}
	#numericReportContainer table{
		border:1px solid #eeeeee;
	}
	#numericReportContainer table th{
		background-color: #E5E5E5;
		border-left:2px solid #eeeeee;
		border-bottom:1px solid #eeeeee;
		color:black;
		width:70px;
		text-align: center;
	}
	#numericReportContainer table td{
		border-left:2px solid #eeeeee;
		border-bottom:1px solid #eeeeee;
		text-align:center;
	}
	#numericReportContainer table a{
		color:#76A2CF;
		font-weight:bold;
		text-decoration: none;
	}
	.reportLabels{
		width:150px;
		text-align:left !important;
		color: black;
	}
	.lastColumn td{
		text-align:left !important;
		border-left:0px !important;
	}
	.ui-jqgrid-titlebar{
		background: url("../images/kolm-sprite-image.png") repeat-x scroll 2px -237px transparent;
	    border-bottom: 0 none;
	    color: #111111;
	    height: 23px;
	    letter-spacing: 1px;
	    padding-top: 5px;
	    vertical-align: middle;
    }
    tr.even td{
    	background-color: #F4F4F4 !important;
    }
     #interactionsFilterForm label{
     	/* display: inline-table;
	    text-align: right;
	    width: 129px; */
	    display: block;
     }
    #interactionsFilterForm p{
    	float: left;
   	 	/* width: 310px; */
   	 	width: 100%;
   	 	margin: 0;
    }
    p#submitButton{
    	text-align: center;
    	width: 100%;
    }
    label.error {
	    display: inline !important;
	    font-weight: normal;
	    margin-left: 103px;
	}
	#lastSelect{
		width:auto !important;
	}
	#lastSelect label{
		width:auto !important;
	}
	#interactionsFilterForm select{
		/* width:142px; */
		width: 100%;
	}
	#interactionsFilterForm input[type="text"]{
		/* width:134px; */
		width: 98%;
	}
	input.error{
		padding:0px;
	}
	.top{
		margin-right:20px !important;
	}
	 .ui-daterangepicker li{
    	text-align: left;
    }
	.ui-daterangepicker ul{
		width: 175px !important;
	}
	.ui-daterangepicker button.btnDone{
		font-size: 12px !important;
		color:#FFF !important;
		padding-bottom: 22px;
		background: -moz-linear-gradient(center top , #5689DB 0%, #4D7BD6 100%) repeat scroll 0 0 transparent !important;
	    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#5689DB),color-stop(100%,#4D7BD6)) !important;
		background: -webkit-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		background: -o-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		background: -ms-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#5689db,endColorstr=#4d7bd6,GradientType=0) !important;
		background: linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
	}
	
	#reportTypeTabs{
		padding-left: 20px;
		border-bottom: 1px solid #ECECEC;
    	padding-left: 20px;
	}
	#reportTypeTabs a{
		background: none repeat scroll 0 0 #ECECEC;
	    border: 1px solid #D0CCC9;
	    padding: 0 15px;
	    text-decoration: none;
	}
	.eachChart{
		width: 380px; 
		height: 400px;
	}
	#contentWrapper{
		min-height: 1000px;
	}
	
	
	#interactionDialoge td.action{
		text-align: center;
	}
	#interactionDialoge #snap-details{
		width: 90%;
		text-align: center;
	}
	#interactionDialoge #snap-details th,#interactionDialoge #snap-details td{
		padding-bottom: 5px;
	}
	#interactionDialoge #snap-details th{
		width: 45%;
		text-align: right;
		color: #626262;
	}
	#interactionDialoge #snap-details td{
		width: 55%;
		text-align: left;
		font-weight: bold;
	}
	#interactionDialoge #snap-actions td{
		text-align: center;
	}
	.microView.calmicro{
		border-radius:0px;
		background: #ffffff;
	}
	#interactionDialoge .blueButton::before{
		display: none;
	}
	
	
	.microView.calmicro{
		border: none !important;
	}
	div.toggleBtnWrapper{

			text-align:right;	

			margin-right: 9px;

		}

		  /* Enable Verticle separator between content and side menu list  By Laxman   */

		#contentWrapper.span-23 {

			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");

		    background-position: 135px 50%;

		    background-repeat: repeat-y;

		}

		.ui-tabs-vertical .ui-widget-content{

			margin-left:0px;

		}

		#orgIntaerctionContainer{

			

		}

		

		#orgIntarcationTable  tr td{

			border:0px solid red;	

		}

		.about{

			padding-bottom:5px;

			margin:0;

			

		}

		

		.alignTop{

			vertical-align:top;	

			text-align: center;	

		}

		

		#orgIntarcationTable tr{

			border:1px solid gray;

		

		}

		

		.topicDetail{

		}

		.facetoFace,.facetoFace:hover{

	  		 background:#1B9ED1;

			 border: 1px solid #1285B2;

    	}

    	.phone,.phone:hover{

			background:#A0E04E;

			border: 1px solid #00A717;

    	}

    	.web,.web:hover{

			background:#ec8732;

			border: 1px solid #D84914;

    	}

    	

    	.orgIntarcationTable{

			    border-bottom: 1px solid #DDDDDD;

			    margin-bottom: 0;

			    padding: 10px 0;

		}

		.orgIntarcationTable:HOVER{

			    background-color: #D3DFED;

		}

		.space{

			margin-right: 28px;		

			font-weight: lighter;

		}

		.notes{

		 

		}

		th, td, caption {

    		padding: 4px 10px 0 0;

		}

		.toggleViewIcon {

			background: url("<?php echo base_url()?>/images/toggle_view.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);

	

		}

		.toggleGridIcon {

			background: url("<?php echo base_url()?>/images/toggle_view.png") no-repeat scroll -41px rgba(0, 0, 0, 0);

	

		}

		.togle{

			float:right;		

		}

		

		input[type="button"], input[type="submit"], input[type="reset"], button, a.blueButton{

			line-height: 19px;

			min-width: 90px;

		}

		

		div.actionIconsContainer{

			/*margin-left: 21px;*/

		}

		

		.bold{

			font-weight:bold;

		}

		.inline{

			display:inline;		

		}

		
		#container{
			min-height: 100px;
		}
	#interactionDialoge .action a.blueButton{
		width:90%;
	}
	.fc-content{
		cursor: pointer;
	}
	.btnDone.ui-state-default.ui-corner-all {
	    background: #2b9af3 none repeat scroll 0 0 !important;
	    height: 25px;
	}
	#left{
		width: 855px;
		float: left;
		display: inline;
	}
	#right{
		width: 300px;
		float: right;
		display: inline;
		border: 1px solid #ccc;
	}
	.right-form{
		margin-bottom: 0;
	}
	.right-form tr td{
		padding: 10px 15px;
    	border-bottom: 1px solid #ccc;
	}
	.right-form h3{
		color: #2b9af3;
		font-size: 12px;
    	font-weight: bold;
    	margin: 0;
	}
	.right-form .funnelIcon{
		margin: 0;
	}
	#resetBttn {
    	margin: 0;
	}
	.ui-th-column, .ui-jqgrid .ui-jqgrid-htable th.ui-th-column{
		white-space: pre-line;
	}
	.gridWrapper .ui-jqgrid .ui-jqgrid-htable th div{
		height: 35px;
	}
	.dataTypeIndicator{
	   margin-right: 10px;
	}
	div.actionIconsContainer{
	   width: 90px !important;
	}
</style>

<div id="container">
<div style="width: 100%; text-align: right;margin-bottom: 5px;">

	<a href="#" class="blueButton" id="showHideSidebar" onclick="showHideSidebar();">Hide Sidebar</a>
</div>
<div id="left">
	    <div id="interactionsContainer" <?php if($reportFlag==1){?> style="display:none" <?php }?>>
		<div class="tabsWrapper" id="test">
			<ul class="tabsContainer">
				<li class="current" name="tab0"><a id="list" href="#">List</a></li>
				<li name="tab1"><a id="report" href="#">Report</a></li>
				<li name="tab2"><a id="chart" href="#">Chart</a></li>
                <li name="tab3"><a id="calender" onclick="generateCalenderEvents()" href="#">Calendar</a></li>
			</ul>
			<div class="tabsContent" style="overflow: auto;">
				<div class="tab0 tabContent" style="display:block;">
					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;
    top: -27px;">

					<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>

				</div>
						<!--				
						<div id="toggleView" class="tooltip-demo tooltop-left">
					
								<div id="toggleViewIcon"><a class="list" rel='tooltip' title="Change View" href="#" onclick="changeView(this);return false;">&nbsp;</a></div>
					
							</div>
					
					
					
					<div id="orgIntaerctionContainer" class="clear" style="display:block">
			
					
					</div>
					
					<?php if($count>10){?>
					
					<div class="loadMore" id="hide" onclick="generateLazyLoadReport();return false">
					
					<a class="load"  style="text-decoration:none" >Show More</a>
					
					</div>
					
					<?php }?>-->
										<div id="gridTabContainer" style="margin-top: 20px;">
											<div class="gridWrapper" id="gridContainer">
								
												<div id="listInteractionsPage"></div>
								
												<table id="listInteractionsResultSet"></table>
								
											</div>
										</div>
				</div>
			
				<div class="tab1 tabContent" style="display:block;">
					<div id="numericReportContainer"></div>
				</div>
				<div class="tab2 tabContent">
					<div id="pageChartContainer" style="">
						<table id="chartTable" class="tableSections">
							<tr class="tableHeader">
								<th class="rightBorder">Interactions By Topic</th>
								<th>Interactions By Type</th>
							</tr>
							<tr>
								<td class="rightBorder">
									<div class="">
										<div id="interactionsByTopic"></div>
									</div>
								</td>
								<td>
									<div class="">
										<div id="interactionByChannel"></div>
									</div>
								</td>
							</tr>
							<tr class="tableHeader">
								<th class="rightBorder">Interactions By Employees</th>
								<th>Interactions By Month</th>
							</tr>
							<tr>
								<td class="rightBorder">
									<div class="">
										<div id="interactionsByEmployee"></div>
									</div>
								</td>
								<td>
									<div class="">
										<div id="interactionsByMonth"></div>
									</div>
								</td>
							</tr>
						</table>
					</div>
				</div>
                <div  style="display:block;" class="tab3 tabContent">
					<div class="calenderContent" id="calenderContent"><div id='calendarId'></div></div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="right">
	<div id="filtersContainer">
		<form action="<?php echo base_url()?>interactions/export_interaction_details/<?php echo $arrKol['id']?>" method='post' id="export">
			<input type="hidden" id="ids" name="interaction_ids" value="<?php echo $interactionIds;?>"></input>
			<input type="hidden" name="filters" id="excel-filters" />
			<input type="hidden" name="filters1" id="excel-filters1" />
			<input type="hidden" name="monthlyfrom_export"  id="monthlyfromExport"/>
			<input type="hidden" name="monthto_export" id="monthlyToExport"/>
			<input type="hidden" name="kol_name_export" id="kolNameExport"/>
			<input type="hidden" name="category_export" id="categoryExport"/>
			<input type="hidden" name="mode_export" id="modeExport"/>
			<input type="hidden" name="user_name_export" id="userNameExport" />
			<input type="hidden" name="type_export" id="typeExport"/>
			<input type="hidden" name="product_export" id="productExport"/>
			<input type="hidden" name="topic_export" id="topicExport" />
		</form>

		<form action="" name="interactionsFilterForm" id="interactionsFilterForm">
			<table class="table right-form">
				<tr>
					<td>
						<h3 style="width: 100px;float: left; display: inline;"><div class="funnelIcon sprite_iconSet"></div>Refine By</h3>
						<h3 style="width: 60px;float: right; display: inline;cursor: pointer;" onclick="formReset();"><div id="resetBttn" class="sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Reset Filters">&nbsp;</a></div>Reset</h3>
					</td>
				</tr>
				<tr>
					<td>
						<p id="submitButton">
							<input type="button" value="Apply Filters" onclick="generateInteractionReport();"/>
							<!-- <input type="reset" value="Reset Filters" /> -->
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<label for=monthlyreport style="display: inline;">From </label><input type="text" name="start_date" id="startDate" style="width: 34%;">
						<label for=monthlyreport style="display: inline;">To </label><input type="text" name="end_date" id="endDate"  style="width: 34%;"/>
					</td>
				</tr>
				<!-- <tr>
					<td>
						<p>
						<label for=monthlyreport>Start Date</label>
							<input type="text" name="start_date" id="startDate" >
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for=monthlyreport>End Date</label>
							<input type="text" name="end_date" id="endDate" />
						</p>
					</td>
				</tr> -->
				<tr>
					<td>
						<p>
							<label for="manager">Manager</label>
							<?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
								<select class="" name="manager_id[]" id="manager_id" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrManager as $key=>$val){ ?>
	                               		<option value="<?php echo $key?>"><?php echo $val?></option>
	                               	<?php }?>
	                            </select>
							<?php } else{
							    echo $managerName;
							}?>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="grouping">Interaction Category</label>
							<select name="grouping[]"  id="grouping" class="chosenMultipleSelect" multiple="multiple">
								<!-- option value="">Select</option>  -->	
								<?php foreach($arrGroupings as $row){?>
									<option value="<?php echo $row['id'];?>">
										<?php echo $row['name'];?>
									</option>
								<?php }?>
							</select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for=mode>Interaction Type</label>
							<select name="mode[]"  id="mode" class="chosenMultipleSelect" multiple="multiple">
								<!-- option value="">Select</option>  -->
								<?php foreach($arrModes as $mode){?>
									<option value="<?php echo $mode['id'];?>">
										<?php echo $mode['name'];?>
									</option>
								<?php }?>
							</select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="user-name">Employee Name</label>
							<?php $client_id = $this->session->userdata("client_id"); ?>
					<select name="user_name[]"  id="user-name" class="chosenMultipleSelect" multiple="multiple" <?php  if($userRole == ROLE_USER && $controllerName == 'interactions'){ echo 'disabled="disabled" style="background-color: #d3d3d3;"';}  ?> >
						<!-- option value="">Select</option>  -->
						<?php foreach($arrUsers as $key=>$user){?>
							<option value="<?php echo $key;?>" <?php if($userRole == ROLE_USER && $userId == $key && $controllerName == 'interactions' && $client_id != INTERNAL_CLIENT_ID) echo "selected = 'selected'";?>>
								<?php echo $user;?>
							</option>
						<?php } ?>
							</select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="product"><?php echo lang("Overview.Product");?></label>
							<select name="product[]"  id="product" onchange="resetDropDowns()" class="chosenMultipleSelect" multiple="multiple">
							<!-- option value="">Select</option>  -->
								<?php foreach($arrProduct as $product){?>
									<option value="<?php echo $product['id'];?>">
										<?php echo $product['name'];?>
									</option>
								<?php }?>
							</select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="objective">Discussion Type</label>
							<select name="objective[]"  id="objective" onchange="getTopic(this)" class="chosenMultipleSelect" multiple="multiple">
								<!-- option value="">Select</option>  -->	
								<?php foreach($arrDiscussionType as $row){?>
									<option value="<?php echo $row['type_id'];?>">
										<?php echo $row['name'];?>
									</option>
								<?php }?>
							</select>
							<img id="loaderType" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="topic">Topic</label>
							<select name="topic[]"  id="topic" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->	
									<?php foreach($arrDiscussionTopic as $row){?>
										<option value="<?php echo $row['id'];?>" >
											<?php echo $row['name'];?>
										</option>
									<?php }?>
							</select>
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
				</tr>
				<tr>
					<td>
					<p>
						<label for="kol-name">KTL</label>
						<input type="text" name="kol_name" id="kol-name" placeholder="Enter KTL" class="autocompleteInputBox" <?php echo (isset($arrKolInfo))?'value="'.$arrKolInfo['kol_name'].'" readonly="readonly"':'';?>"/>
						<input type="hidden" name="kol_id" id="kol-id" value="<?php echo (isset($arrKolInfo))?$arrKolInfo['kol_id']:'';?>" ></input>
					</p>
					</td>
				</tr>
			</table>
			<p id="submitButton">
				<!-- <input type="button" value="Apply Filters" onclick="generateInteractionReport();"/>
				<input type="reset" value="Reset Filters" /> -->
			</p>
		</form>
		</div>

</div>
<div id="addEditInteractionWrapper" class="clear" style="min-height 400px;">

		<div id="addInteractionContainer"></div>

		<div id="editInteractionContainer"></div>

		<div id="viewInteractionContainer"></div>

	</div>
</div>
<div id="interactionDialoge" class="microProfileDialogBox">
	<div class="interactionDialoge profileContent"></div>
</div>
<div id="addLockUnlock" class="microProfileDialogBox">
	<div class="addLockUnlockContent"></div>
</div>

