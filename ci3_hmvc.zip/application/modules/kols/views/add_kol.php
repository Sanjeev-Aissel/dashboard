<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";

$queued_js_scripts = array('modules/kols/js/kols','js/chosen.jquery','jqgrid/i18n/grid.locale-en',
		'jqgrid/jquery.jqGrid.min_3.8','jquery_validator/dist/jquery.validate','alerts/jquery.alerts',
		'js/jquery.autocomplete'
);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jquery_validator/css/screen.css">
<link  href="<?php echo base_url().MODULES_ASSETS;?>kols/css/kols.css" rel="stylesheet">
<style>
.action_icons{
    font-size: 16px;
    padding: 0px 5px;
}
.gridWrapper .ui-jqgrid tr.jqgrow td div.microViewIcon {
    height:22px !important;
    margin-bottom: 0px;
    width: 20px;
    background: rgba(0, 0, 0, 0) url("<?php echo base_url().MODULES_ASSETS;?>kols/images/microview_inactive.png") no-repeat scroll 0 2px / 20px auto;
}
.caption {
    background: linear-gradient(#ffffff, #cbcbcb);
    padding:2px;
    font-weight: 900;
    border: 1px solid #aaaaaa;
}
.gridWrapper{
width:100%;
padding-right:0px;
}
</style>
<script>
var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
var add_permission='<?php echo $role_permissions[$module_id]["add"];?>';
var emailCount=0;
var organizationNameAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/kols/get_organization_names/1',
		<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    $('#organization').val(selText);
                    $('#org_institution_id').val(selId);
                    $('#org_institution_id').val(selId).trigger('change');
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#organization').val(trim(split(' ', selText)[4]));
                            return false;
                        } 
                    }
                }
};
$(document).ready(function(){
		var a='';
		a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);
		$('#sub_specialty').chosen({
		    placeholder_text: "Click to Select Sub Speciality"
		});
	    $('#title').chosen({
	        placeholder_text: "Click to Select Position",
	        allow_single_deselect: true
	    });
	    $('#prof_suffix').chosen({
	        placeholder_text: "Click to Select Suffix",
	        allow_single_deselect: true
	    });
	    $('#products').chosen({
	        placeholder_text: 'Click to Select Product',
	        allow_single_deselect: true
	    });
		load_grids();
	});
function load_grids(){
	var kolId ='<?php echo $arrKolData['kols_client_visibility_id'];?>';
	if(kolId>0){
       getLocationDataOnPageLoad();
       getPhoneNumberData();       
       getStaffsData();
       getEmailsData();
       getStateLicenceData();
       getAssignedData();	
	}
}
var validationRules = {
        first_name: {
            required: true
        },
        last_name: {
            required: true
        },
        specialty: {
            required: true
        },
        address1: {
            required: true
        },
        country_id: {
            required: true
        },
        organization: {
            required: true
        }
    };
    var validationMessages = {
        first_name: {
            required: "Required"
        },
        last_name: {
            required: "Required"
        },
        specialty: {
            required: "Required"
        },
        address1: {
            required: "Required"
        },
        country_id: {
            required: "Required"
        },
        organization: {
            required: "Required"
        }      
    };
$(function () {
	$("#kol_form").validate({
        debug: false,
        onkeyup: false,
        rules: validationRules,
        messages: validationMessages
    });
});
</script>
<div class="container-fluid row">
<div id="msgBox">
<?php //pr($module_id);?>
</div>
<?php switch ($sub_content_page){
	case 'details':?><div class="caption">
						Short Details
					</div>
		<div class="form-group row">
				<input type="hidden" id="kol_id" name="kol_id" value="<?php echo $arrKolData['kols_client_visibility_id'];?>"/>
				<label class="col-sm-3 col-form-label">First Name:</label>
				<div class="col-sm-3">
					<?php echo $arrKolData['first_name'];?>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Professional Suffix:</label>
				<div class="col-sm-3">
				    <?php  echo $arrKolData['suffix'];?>
				</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Middle Name:</label>
				<div class="col-sm-3">
					<?php echo $arrKolData['middle_name'];?>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Position:</label>
				<div class="col-sm-3">
				<?php echo $arrKolData['title'];?>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Last Name:</label>
				<div class="col-sm-3">
					<?php echo $arrKolData['last_name'];?>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Indication:</label>
				<div class="col-sm-3">
	            <?php      
	            	$prodString = "";
                    foreach ($arrKolProducts as $value) {
                        $prodString .= $value['name'].", ";
                    }
                    echo trim($prodString, ", ");
                ?>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Specialty:</label>
				<div class="col-sm-3">
				<?php if($arrKolData['specialty']==0) echo 'Non-medical / Others'; else echo $arrKolData['specialty_name']; ?>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Email:</label>
				<div class="col-sm-3">
					<?php echo $arrKolData['primary_email'];?>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Sub Specialty:</label>
				<div class="col-sm-3">
                	<?php
                    	echo implode(", ",$arrSubSpecialties); 
                   ?>
				</div>
		    	<label class="col-sm-3 col-form-label">CRM#:</label>
				<div class="col-sm-3">
					<?php echo $arrKolData['external_profile_id'];?>
		    	</div>
		</div>
						
		<?php break;
	default: ?>
	<form action=""   method="post" name="kol_form" id="kol_form" class="validateForm">
		<input type="hidden" id="kol_id" name="kol_id" value="<?php echo $arrKolData['kols_client_visibility_id'];?>"/>
		<div class="form-group row caption">
		Short Details
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">First Name:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
		    		<input type="text" name="first_name" id="first_name" class="required form-control" value="<?php echo $arrKolData['first_name'];?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">Professional Suffix:</label>
				<div class="col-sm-3">
		    	   <select class="chosenMultipleSelect" multiple="multiple"  name = "prof_suffix[]" id = 'prof_suffix' <?php echo $disabled?>>
                   <?php foreach ($arrProfessionalSuffixes as $suffix) {?>
                       <option value="<?php echo $suffix['suffix']; ?>" 
                       <?php  if (in_array($suffix['suffix'], $selectedSuffixes)){
                                            	echo 'selected=selected';
								}?>>
                       <?php echo $suffix['suffix']; ?>
                       </option>
                    <?php } ?>   
                    </select> 
               </div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Middle Name:</label>
				<div class="col-sm-3">
					<input type="text" name="middle_name" id="middle_name" class="form-control" value="<?php echo $arrKolData['middle_name'];?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">Position:</label>
				<div class="col-sm-3">
		    	    <select name="title" id="title" class="chosenMultipleSelect required form-control">
                                <option value = ""> --Select--</option>
                                <?php  foreach ($arrTitles as $title) {?>
                                    <option value="<?php echo $title['id']; ?>" 
                                 	   <?php if ($arrKolData['title_id'] == $title['id'])  echo 'selected=selected';?>><?php echo $title['title']; ?>
                                    </option>
                                 <?php }?>
                            </select>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Last Name:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
					<input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo $arrKolData['last_name'];?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">Indication:</label>
				<div class="col-sm-3">
				 <select class="form-control required chosenMultipleSelect" multiple="multiple"  name="products[]" id="products">
                 <?php foreach ($arrProducts as $product) {?>
                      <option value="<?php echo $product['id'];?>" 
                      <?php	foreach ($arrKolProducts as $kolProduct) {
                      		if ($product['id'] == $kolProduct['id'])
                      			echo 'selected=selected';
                      }
                      ?> 
                      >
                       <?php echo $product['name']; ?>
                       </option>
                  <?php } ?>
                  </select>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Specialty:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
					 <select name="specialty" id="specialty" class="form-control required">
							<option value =""> --Select--</option>
							<?php foreach($arrSpecialties as $key => $value){?>
								<option value="<?php echo $key;?>" <?php if($arrKolData['specialty']!='' && $arrKolData['specialty']==$key){?> selected="selected"<?php }?>>
									<?php echo $value;?>
								</option>
							<?php }?>
						</select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Email:</label>
				<div class="col-sm-3">
		    		<input type="text" name="email" id="email" class="required form-control" value="<?php echo $arrKolData['primary_email'];?>">
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Sub Specialty:</label>
				<div class="col-sm-3">
		    		<select multiple="multiple" id="sub_specialty" name="sub_specialty[]" class="chosenMultipleSelect form-control required">
							<option value =""> --Select--</option>
							<?php foreach ($arrSpecialties as $key => $value){?>
								<option value="<?php echo $key;?>" <?php if($arrKolData['specialty']!='' && $arrSubSpecialties[$key]==$value){?> selected="selected"<?php }?>>
									<?php echo $value;?>
								</option>
							<?php }?>
					</select>
				</div>
		    	<label class="col-sm-3 col-form-label">CRM#:</label>
				<div class="col-sm-3">
		    		<input type="text" name="crm_id" id="crm_id" class="form-control" value="<?php echo $arrKolData['external_profile_id'];?>">
		    	</div>
		</div>
		<div class="form-group row caption">
		Address
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Institution:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
		    		<input type="text" name="organization" id="organization" placeholder="Enter Institution" class="autocompleteInputBox required form-control" 
		    		value="<?php if ($arrLocationData['org_institution_name'] != "0"){echo $arrLocationData['org_institution_name'];}?>">
		    		<input name="org_institution_id" id="org_institution_id" value="<?php echo $arrLocationData['org_institution_id'];?>" type="hidden">
		        </div>
		    	<label class="col-sm-3 col-form-label">Postal Code:</label>
				<div class="col-sm-3">
		    		<input type="text" name="postal_code" id="postal_code" class="form-control" value="<?php echo $arrLocationData['postal_code'];?>">
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Institution Type:</label>
				<div class="col-sm-3">
					<input type="hidden" name="private_practice" id="private_practice" value="1"/>                      	
				    <select name="org_type" id='org_type' class="form-control" onchange="changeAutoComplete();">
                    	<option value = ""> --Select--</option>
				        <?php foreach ($arrOrganizationTypes as $key => $value) { ?>
				        	<option value="<?php echo $key; ?>" <?php if (!empty($orgTypeId) && $orgTypeId == $key) echo "selected=selected";?>>
					       	<?php echo $value; ?>
					       	</option>
				       <?php }?>
				    </select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Country:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
					<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required form-control">
						<option value="">-- Select Country--</option>
						<?php foreach($arrCountries as $country ){ ?>
							<option value="<?php echo $country['country_id']?>" <?php if($arrLocationData['country_id']==$country['country_id']){?> selected="selected"<?php }?>>
							<?php echo $country['country_name']?>
							</option>
						<?php }?>
					</select>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Address Line 1:<span class="reqd-field-indicator">*</span></label>
				<div class="col-sm-3">
		    		<input type="text" name="address1" id="address1" class="required form-control" value="<?php echo $arrLocationData['address1']?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">State / Province:</label>
				<div class="col-sm-3">
		    		<select  name="state_id" id="state_id" class="form-control" onchange="getCitiesByStateId();">
						<option value='0'>-- Select State --</option>
						<?php foreach($arrStates as $state ){ ?>
							<option value="<?php echo $state['state_id']?>" <?php if($arrLocationData['state_id']==$state['state_id']){?> selected="selected"<?php }?>>
							<?php echo $state['state_name']?>
							</option>
						<?php }?>
					</select>
				</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Address Line 2:</label>
				<div class="col-sm-3">
		    		<input type="text" name="address2" id="address2" class="form-control" value="<?php echo $arrLocationData['address2']?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">City:</label>
				<div class="col-sm-3">
		    		<select name="city_id" id="city_id"  class="form-control">
						<option value='0'>-- Select City --</option>
						<?php foreach($arrCities as $city ){ ?>
							<option value="<?php echo $city['city_id']?>" <?php if($arrLocationData['city_id']==$city['city_id']){?> selected="selected"<?php }?>>
							<?php echo $city['city_name']?>
							</option>
						<?php }?>
					</select>
				</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Department:</label>
				<div class="col-sm-3">
		    		<input type="text" name="department_loc" id="department_loc" class="form-control" value="<?php echo $arrLocationData['division']?>">
		    	</div>
		    	<label class="col-sm-3 col-form-label">Phone Type:</label>
				<div class="col-sm-3">
		    		<select name="phone_type_loc" id="phone_type" class="form-control" <?php echo $disabled?>>
						<option value="">--Select--</option>
			            <?php foreach ($arrPhoneType as $key=>$type){?>
			            <option value="<?php echo $key?>" <?php if(isset($arrLocationData['phone_type']) && $arrLocationData['phone_type']==$key) echo "selected='selected'";?>><?php echo $type;?></option>
			            <?php }?>
					</select>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
				<div class="col-sm-3">
		    	</div>
		    	<label class="col-sm-3 col-form-label">Phone Number:</label>
				<div class="col-sm-3">
		    		<input type="text" name="phone_number_loc" id="phone_number_loc" class="required form-control" value="<?php echo $arrLocationData['phone_number'];?>">
		    	</div>
		</div>
		<div class="form-group row" style="text-align:center;">
			<input type="button" value="Save" name="submit" onclick="checkDuplicatesAndSave();" class="btn custom-btn">
			<a type="button" onclick="goBack();return false;" class="btn custom-btn">Cancel</a>
		</div>
	</form>
<?php }?>



<?php if($arrKolData['id']>0){?>
	<div id="location">
		<div class="gridWrapper" id="gridWrapperLocation">
			<div id="listLocationDetailsPage"></div>
			<table id="JQBlistLocationResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addLocation();return false;">Add-Location</button>
		</div>
	</div>
	
	<div id="phone">
		<div class="gridWrapper" id="gridWrapperPhone">
			<table id="JQBlistPhoneNumberResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addPhoneNumber();return false;">Add-Phone</button>
		</div>
	</div>
	
	<div id="staff">
		<div class="gridWrapper" id="gridWrapperStaff">
	    	<table id="JQBlistStaffResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addStaffs();return false;">Add-Staff</button>
		</div>
	</div>
	
	<div id="email">
		<div class="gridWrapper" id="gridWrapperEmails">
	    	<table id="JQBlistEmailResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addEmails();return false;">Add-Email</button>
		</div>
	</div>
	
	<div id="stateLicense">
		<div class="gridWrapper" id="gridWrapperStateLicense">
			<table id="JQBliststateLicenseResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addLicenses();return false;">Add-License</button>
		</div>
	</div>
	<?php if($this->common_helper->check_module("align_users")){ ?>
	<div id="assignClients">
		<div class="gridWrapper" id="gridWrapperAssign">
			<table id="JQBlistassignResultSet"></table>
		</div>
	</div>
	
	<div class="row">
		<div class="pull-right row_padding">
		<button type="button" class="btn custom-btn" onclick="addAssign();return false;">Add-Assign</button>
		</div>
	</div>
	<?php }?>
	<?php }?>	
</div>
<div id="modalContainer" class="microViewLoading">
	<div class="modalContent"></div>
</div>