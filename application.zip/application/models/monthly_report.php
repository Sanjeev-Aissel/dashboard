<?php
/**
 * Model class for report related methods
 * 
 * @package application.models	
 * @author Laxman K
 * @since  3.4
 * @created: 23-11-11
 */


class Monthly_report extends Model {
	/**
	 * constructor
	 * @return unknown_type
	 */
	 
	function Monthly_report()
	{
		parent::Model();
	}
	
	/**
	 * Fetch all records from the table where logged in user belongs to respective client
	 * 
	 * @author Laxman
	 * @since 3.4
	 * @param $clientId,$month_year
	 * @created 23-11-11 
	 */
	function getAllMonthlyEvents($clientId,$fromMonth=null,$toMonth=null){
		$arrModes=array();

		$this->db->where('client_id',$clientId);
		
		if($toMonth!=null && $fromMonth!=null){
			$this->db->where("event_date BETWEEN '".$fromMonth."-01' AND '".$toMonth."-31'");
		}else if($fromMonth!=null){
			$this->db->like('event_date',$fromMonth);
		}
		$arrModeResults=$this->db->get('client_events');
		foreach($arrModeResults->result_array() as $row){
			$arrModes[]=$row;
		}
		return $arrModes;
	}
	
	/**
	 * Saves the given Client event record
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @param $arrClientEventDatails
	 * @created 24-11-11 
	 */
	function saveClientEvent($arrClientEventDatails){
		if($this->db->insert('client_events',$arrClientEventDatails))
			return $this->db->insert_id();
		else
			return false;
	}
	
	/**
	 * Retrives the 'Client event'for a given '$eventId'
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @param $eventId
	 * @created 24-11-11 
	 */
	function getClentEvent($eventId){
		$arrClientEventDatails=array();
		$this->db->where('id',$eventId);
		$arrResults=$this->db->get('client_events');
		$arrClientEventDatails=$arrResults->row_array();
		return $arrClientEventDatails;
	}
	
	/**
	 * Updates the given Client event record details
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @param $arrClientEventDatails
	 * @created 24-11-11 
	 */
	function updateClientEvent($arrClientEventDatails){
		$this->db->where('id',$arrClientEventDatails['id']);
		if($this->db->update('client_events',$arrClientEventDatails))
			return true;
		else
			return false;
	}
	
	/**
	 * Deletes the client event with the given id
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @param $eventId
	 * @created 24-11-11 
	 */
	function deleteClientEvent($eventId){
		$arrEventPayments = $this->getClentEventPayments($eventId);
		$arrPaymentIds = array();
		foreach ($arrEventPayments as $payment){
			$arrPaymentIds[] = $payment['id'];
		}
		//First delete referenced payments
		if(sizeof($arrPaymentIds) > 0){
			$this->db->where_in('id', $arrPaymentIds);
			$this->db->delete('payments');
		}
		//Delete event
		$this->db->where('id', $eventId);
		if($this->db->delete('client_events'))
			return true;
		else
			return false;
	}
	
	/**
	 * Saves the given event payment details
	 * 
	 * @author Ramesh B
	 * @since 4.7
	 * @param $eventPayment
	 * @created 26-07-12 
	 */
	function eventPayment($eventPayment){
		if($this->db->insert('client_event_payments',$eventPayment))
			return true;
		else
			return false;
	}
	
	/**
	 * Retrives all the payments logged for given client event
	 * 
	 * @author Ramesh B
	 * @since 4.7
	 * @param $eventId
	 * @created 26-07-12 
	 */
	function getClentEventPayments($eventId){
		$arrEventPayments = array();
		$this->db->select('payments.*,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.status as kol_status');
		$this->db->where('client_event_id',$eventId);
		$this->db->join('payments','payments.id = client_event_payments.payment_id','left');
		$this->db->join('kols','kols.id = payments.kol_id','left');
		$results = $this->db->get('client_event_payments');
		foreach ($results->result_array() as $row){
			$arrEventPayments[] = $row;
		}
		return $arrEventPayments;
	}
	
	function getEventPaymentTypeId(){
		$eventId = 1;
		$this->db->select('id');
		$this->db->where('name','Event');
		$results = $this->db->get('payment_types');
		foreach ($results->result_array() as $row){
			$eventId = $row['id'];
		}
		return $eventId;
	}
	
	/**
	 * Fetch all records from the table where logged in user belongs to respective client
	 * 
	 * @author Vinayak
	 * @since 3.4
	 * @param $clientId,$month_year
	 * @created 23-11-11 
	 */
	function getEventReportDetail($ids){
		$arrModes=array();

		$this->db->where_in('client_events.id',$ids);
		$arrModeResults=$this->db->get('client_events');
		foreach($arrModeResults->result_array() as $row){
			$arrModes[]=$row;
		}
		return $arrModes;
	}
	
}