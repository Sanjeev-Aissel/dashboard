<?php
/**
*Model for update operations
*@author Ramesh B
*@since 4.2
*@package application.controllers	
*@created on 05-07-2012
*/

class Update extends Model{
	
	function Update(){
		 parent::Model();
                  $this->load->model('common_helpers');
	}
	
	/**
	 * Inserts a update entry in to updates table
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.1
	 * @params 
	 * @return unknown_type
	 */	
	function insertUpdateEntry($updateType, $objectId, $module_id = null, $parentObjectId = null,$statusId=null){
		$updateEntry = array();
		$updateEntry['update_type_id'] = $updateType;
		$updateEntry['object_id'] = $objectId;
		$updateEntry['module_id'] = $module_id;
		$updateEntry['parent_object_id'] = $parentObjectId;
		$updateEntry['status_id'] = $statusId;
		$updateEntry['created_by'] = $this->session->userdata('user_id');
		
		$clientId = $this->session->userdata('client_id');
		//If the client is not internal client then by default update should be published and the published time will be same as created_time
		if($clientId != INTERNAL_CLIENT_ID){
			$updateEntry['is_published'] = 1;
		}
		$updateEntry['published_time'] = date("Y-m-d H:i:s");
		
		if($this->db->insert('updates',$updateEntry)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	/**
	 * Lists all the updates by grouping common activities by day
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.1
	 * @params 
	 * @return unknown_type
	 */	
	function listUpdates($startFrom, $limit, $categoryId,$kolId = null, $viewType = null, $userId=null, $startDate=null, $endDate=null,$arrExlcudeTypes=array()){
        $arrUpdates = array();
        $userIdSession = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userIdSession);
        $teamName = $this->common_helpers->getUserTeamName($userId);
		$clientId = $this->session->userdata('client_id');
		//For the client users show only the updates on 'completed profiles'
		if($clientId != INTERNAL_CLIENT_ID ){		    
			//$arrCompletedKolIds = $this->getCompletedKolIds();
//			$this->db->where_in('kol_id',$arrCompletedKolIds);
			//if($categoryId != '')
				//$this->db->where("module",$categoryId);	
			$this->db->where("client_users.client_id",$clientId);
			if($userId > 0)
				$this->db->where("log_activities.created_by",$userId);
			if($startDate == null && $endDate != null){
				$wherBetween="(DATE(log_activities.created_on) < '$endDate')";
				$this->db->where($wherBetween);
			}
			if($startDate != null && $endDate == null){
				$wherBetween="(DATE(log_activities.created_on) > '$startDate')";
				$this->db->where($wherBetween);
			}
			if($startDate != null && $startDate!= '' && $endDate != null && $endDate != ''){
				$wherBetween="(DATE(log_activities.created_on) BETWEEN '$startDate' AND '$endDate')";
				$this->db->where($wherBetween);
			}
// 			if($kolId >0){
// 				$this->db->where("log_activities.transaction_id",$kolId);
// 			}
//			$this->db->where("updates.is_published", 1);
		}
		
		$this->db->select("COUNT(DISTINCT(method)) AS method_count, transaction_name AS update_type_id, transaction_id AS object_id,parent_object_id, module as module_id, COUNT(*) AS number, DATE(log_activities.created_on) as created_day,log_activities.created_by,log_activities.created_on AS published_time,client_users.first_name,client_users.last_name,log_activities.user_id,log_activities.manager_id,log_activities.transaction_id");
		$this->db->join('client_users','log_activities.created_by = client_users.id','left');
		$this->db->group_by("transaction_name,log_activities.created_by,parent_object_id,DAY(log_activities.created_on)");
		$this->db->order_by("log_activities.created_on desc");
		if($categoryId != '0' && $categoryId != ''){
		    $categoryId = "'$categoryId'";
// 			$this->db->where("module",$categoryId);			
		    $this->db->where("(log_activities.module = $categoryId or log_activities.controller = $categoryId)" ,'',false);
		}
		if($userId >0)
			$this->db->where("log_activities.created_by",$userId);
		if($startDate == null && $endDate != null){
			$wherBetween="(DATE(log_activities.created_on) < '$endDate')";
			$this->db->where($wherBetween);
		}
		if($startDate != null && $endDate == null){
			$wherBetween="(DATE(log_activities.created_on) > '$startDate')";
			$this->db->where($wherBetween);
		}
		if($startDate != null && $startDate!= '' && $endDate != null && $endDate != ''){
			$wherBetween="(DATE(log_activities.created_on) BETWEEN '$startDate' AND '$endDate')";
			$this->db->where($wherBetween);
		}
		if(isset($kolId) && $kolId != null){
			$this->db->where("log_activities.parent_object_id",$kolId);
		}
		 if ($userRole == ROLE_USER) {
                     $this->db->where('log_activities.created_by', $userIdSession);
                }
                if ($clientId != INTERNAL_CLIENT_ID && ($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office") {
                    $this->db->where_in('log_activities.created_by', $userIds);
                }
//		if($kolId == null && sizeof($viewType) > 0){
//			$this->db->where_in('log_activities.kol_id',$viewType);
//		}
		
		//Put this condition at the last as it is 'OR' condition
		//if($clientId != INTERNAL_CLIENT_ID)
			//$this->db->or_where('module_id',MODULE_KOL_REQUEST);
		$ignore_types_in_recent_activity	= $this->config->item('ignore_types_in_recent_activity');
		$arrExlcudeTypes = array_merge($arrExlcudeTypes,$ignore_types_in_recent_activity);
		if(sizeof($arrExlcudeTypes>0)){
		    $this->db->where_not_in('log_activities.transaction_name', $arrExlcudeTypes);
            $this->db->where("log_activities.transaction_name is not null",'',false);
		}
		if($startFrom != null)
			$this->db->limit($limit, $startFrom);
		$result = $this->db->get("log_activities");
		//pr($this->db->last_query());exit;
		foreach($result->result_array() as $row){
			$row['is_published'] = 1;
			$arrUpdates[] = $row;
		}
// 	echo $this->db->last_query();exit;
		return $arrUpdates;
	}
	
	/**
	 * Fetches the updates matching the given , Select the same activities on given parent object on perticular date 
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.1
	 * @params 
	 * @return unknown_type
	 */
	function getUpdatesByParam($updateType, $parentObjectId, $createdDay, $createdBy){
		$arrUpdates = array();
		$this->db->select("transaction_name AS update_type_id, transaction_id AS object_id,parent_object_id, DATE(log_activities.created_on) as created_day,log_activities.created_by,log_activities.created_on AS published_time");
		$this->db->where("transaction_name",$updateType);
		$this->db->where("parent_object_id",$parentObjectId);
		$this->db->where("DATE(log_activities.created_on)",$createdDay);
		$this->db->where("created_by",$createdBy);
		$this->db->order_by("log_activities.created_on desc");
		
		$result = $this->db->get("log_activities");
		foreach($result->result_array() as $row){
			$arrUpdates[] = $row;
		}
		//echo $this->db->last_query();
		return $arrUpdates;
	}
	
	function getCompletedKolIds(){
		$arrKolIds = array();
		$this->db->select('id');
		$this->db->where("status",COMPLETED);
		$arrResults = $this->db->get("kols");
		foreach($arrResults->result_array() as $row){
			$arrKolIds[]=(int)$row['id'];
		}
		return $arrKolIds;
	}
	
    function getUserNameById(){
		$arrUsers = array();
		$this->db->select('client_users.client_id,client_users.user_name');
		$arrUserResultSet = $this->db->get('client_users');
		foreach($arrUserResultSet->result_array() as $row){
			$arrUsers[$row['client_id']] = $row['username'];
		}
		return $arrUsers;
    }
    
	/**
	 * Delete a update entry
	 * 
	 * @author 	Ramesh B
	 * @since Sep 6 2012
	 * @version 5.2
	 * @params 
	 * @return unknown_type
	 */	
	function deleteUpdateEntry($updateType, $objectId, $module_id = null, $parentObjectId = null,$statusId=null){
		$this->db->where('update_type_id', $updateType);
		$this->db->where('object_id', $objectId);
		if($module_id != null)
			$this->db->where('module_id', $module_id);
		if($parentObjectId != null)
			$this->db->where('parent_object_id', $parentObjectId);
		if($this->db->delete('updates')){
			return true;
		}else{
			return false;
		}
	}
	
	function deleteKolRelatedUpdates($kolId){
		$this->db->where('parent_object_id', $kolId);
		if($this->db->delete('updates')){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Fetches the updates matching the given , Select the same activities on given parent object on perticular date 
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.1
	 * @params 
	 * @return unknown_type
	 */
	function updateActivityStatus($updateType, $parentObjectId, $createdDay, $createdBy, $publishStatus){
		$arrUpdates = array();
		$this->db->where("update_type_id",$updateType);
		$this->db->where("parent_object_id",$parentObjectId);
		$this->db->where("DATE(created_time)",$createdDay);
		$this->db->where("created_by",$createdBy);
		
		$arrUpdates['is_published'] = $publishStatus;
		$arrUpdates['published_time'] = date("Y-m-d H:i:s");
		if($this->db->update("updates",$arrUpdates))
			return true;
		else
			return false;
	}
	
	function deleteActivitiesByParam($updateType, $parentObjectId, $createdDay, $createdBy){
		$arrUpdates = array();
		$this->db->where("update_type_id",$updateType);
		$this->db->where("parent_object_id",$parentObjectId);
		$this->db->where("DATE(created_time)",$createdDay);
		$this->db->where("created_by",$createdBy);
		
		if($this->db->delete("updates"))
			return true;
		else
			return false;
	}
        
        function listUpdatesForDashboard($startFrom, $limit, $categoryId,$kolId = null, $viewType = null, $userId=null, $startDate=null, $endDate=null){
		$arrUpdates = array();
		$userRole = $this->session->userdata('user_role_id');
		$clientId = $this->session->userdata('client_id');
		$userIdSession = $this->session->userdata('user_id');
		//For the client users show only the updates on 'completed profiles'
		if($clientId != INTERNAL_CLIENT_ID){
			$arrCompletedKolIds = $this->getCompletedKolIds();
			$this->db->where("client_users.client_id",$clientId);
			if(count($arrCompletedKolIds) > 0)
				$this->db->where_in('parent_object_id',$arrCompletedKolIds);
			if($categoryId != 0)
				$this->db->where("module_id",$categoryId);			
			if($userId != null && $userId != 0)
				$this->db->where("updates.created_by",$userId);
			if($startDate == null && $endDate != null){
				$wherBetween="(DATE(created_time) < '$endDate')";
				$this->db->where($wherBetween);
			}
			if($startDate != null && $endDate == null){
				$wherBetween="(DATE(created_time) > '$startDate')";
				$this->db->where($wherBetween);
			}
			if($startDate != null && $startDate!= '' && $endDate != null && $endDate != ''){
				$wherBetween="(DATE(created_time) BETWEEN '$startDate' AND '$endDate')";
				$this->db->where($wherBetween);
			}
			if(isset($kolId) && $kolId != null){
				$this->db->where("updates.object_id",$kolId);
			}
			$this->db->where("updates.is_published", 1);
		}else{
			if($this->input->post('is_analyst_app') == null)
				$this->db->where("updates.is_published", 1);			
		}
		
		$this->db->select("updates.*, client_users.first_name,client_users.last_name,client_users.user_name, client_users.client_id, COUNT(*) AS number, DATE(created_time) as created_day");
		$this->db->join('client_users','updates.created_by = client_users.id','left');
		$this->db->group_by("update_type_id,updates.created_by,parent_object_id,status_id,DAY(created_time)");
		$this->db->order_by("published_time desc");
		if($categoryId != 0)
			$this->db->where("module_id",$categoryId);			
		if($userId != null && $userId != 0)
			$this->db->where("updates.created_by",$userId);
		if($startDate == null && $endDate != null){
			$wherBetween="(DATE(created_time) < '$endDate')";
			$this->db->where($wherBetween);
		}
		if($startDate != null && $endDate == null){
			$wherBetween="(DATE(created_time) > '$startDate')";
			$this->db->where($wherBetween);
		}
		if($startDate != null && $startDate!= '' && $endDate != null && $endDate != ''){
			$wherBetween="(DATE(created_time) BETWEEN '$startDate' AND '$endDate')";
			$this->db->where($wherBetween);
		}
		if(isset($kolId) && $kolId != null){
			$this->db->where("updates.parent_object_id",$kolId);
		}
		
		if($kolId == null && sizeof($viewType) > 0){
			$this->db->where_in('updates.parent_object_id',$viewType);
		}
		if ($userRole == ROLE_USER) {
		    $this->db->where('updates.created_by', $userIdSession);
		}
		
		//Put this condition at the last as it is 'OR' condition
		//if($clientId != INTERNAL_CLIENT_ID)
			//$this->db->or_where('module_id',MODULE_KOL_REQUEST);
		if($startFrom != null)
			$this->db->limit($limit, $startFrom);
		$result = $this->db->get("updates");
		foreach($result->result_array() as $row){
			$arrUpdates[] = $row;
		}
// 		echo $this->db->last_query();
		return $arrUpdates;
	}
        
}