<script type="text/javascript">
$(document).ready(function(){
	a = $('#orgType').autocomplete(orgTypeAutoCompleteOptions);
	$('#orgType').focus(function(){
		$('#orgType').val('');
	});       
	$('#orgType').blur(function(){
		$('#orgType').val('Enter Type ');	
	});
});
</script>
<style>
.sprite_iconSet.navLinkOverview {
    background: url(../images/over_view_inactive.svg) no-repeat;
}
.sprite_iconSet.keyPeople {
    background: url(../images/key_ppl_inactive.svg) no-repeat;
}
#secondaryNav .navLinkTrack {
    background: url(../images/track_inactive.svg) no-repeat;
    background-position: 0 3px !important;
}
#secondaryNav .navLinkAffiliation {
    background: url(../images/affiliaions_inactive.svg) no-repeat;
}
#secondaryNav .active .orgNetMap {
    background: url(../images/org_network_active_white.svg) no-repeat scroll 0 0;
}
</style>
<div class="filterDiv">
	<table class="table no_bottom_margin no">
		<tr>
			<td width="30%">Assigned</td>
			<td width="70%">
				<select class="form-control input_hight_for_filters">
				    <option>1</option>
				    <option>2</option>
				    <option>3</option>
				    <option>4</option>
				  </select>
			</td>
		</tr>
		<tr>
			<td>Saved Filters</td>
			<td>
				<select class="form-control input_hight_for_filters" id="sel1">
				    <option>1</option>
				    <option>2</option>
				    <option>3</option>
				    <option>4</option>
				  </select>
			</td>
		</tr>
		<tr>
			<td>Profile Type</td>
			<td>
				<select class="form-control input_hight_for_filters" id="sel1">
				    <option>1</option>
				    <option>2</option>
				    <option>3</option>
				    <option>4</option>
				  </select>
			</td>
		</tr>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Global Region-------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Global Region</caption>
		<tr class="filter_fonts">
			<td width="40%">All Regions</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
			 	foreach($arrRegionCount as $regionCountDetails){ ?>
			 	<?php if($regionCountDetails['region_type_id']>0 && $regionCountDetails['GlobalRegion']!=''){?>
				 	<tr class="filter_fonts regionType<?php echo $regionCountDetails['region_type_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $regionCountDetails['region_type_id'];?>" value="<?php echo $regionCountDetails['GlobalRegion'];?>" onclick="doSearchFilter1(-1,this)" 
							<?php
								if(isset($selectedRegionTypes[$regionCountDetails['GlobalRegion']])){
									unset($selectedRegionTypes[$regionCountDetails['GlobalRegion']]);
									echo 'checked="checked"';
								}
							?>
							/><?php echo $regionCountDetails['GlobalRegion'];?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$allRegionCount)*100)."%)";?>" 
				  						style="width: <?php if(isset($allRegionCount)) echo round(($regionCountDetails['count']/$allRegionCount)*100); else echo 0;?>%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php echo $regionCountDetails['count'];?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Country-------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Country</caption>
		<tr class="filter_fonts">
			<td width="40%">All Countries</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		foreach($arrKolsByCountryCount as $countryCountDetails){ ?>
			 		<?php if($countryCountDetails['country']!=''){?>
				 	<tr class="filter_fonts country<?php echo $countryCountDetails['country_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $countryCountDetails['country_id'];?>" value="<?php echo $countryCountDetails['country_id'];?>" onclick="doSearchFilter1(-1,this)" 
							<?php
								if(isset($selectedCountries[$countryCountDetails['country_id']])){
									unset($selectedCountries[$countryCountDetails['country_id']]);
									echo 'checked="checked"';
								}
							?> 
							/><?php echo $countryCountDetails['country'];?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allRegionCount)*100)."%)";?>" 
				  						style="width:<?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php echo $countryCountDetails['count'];?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Position-------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Position</caption>
		<tr class="filter_fonts">
			<td width="40%">All Positions</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allkolTypeCount)) echo $allkolTypeCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
				foreach($arrKolByTypeCount as $kolTypeCountDetails){?>
			 		<?php if($kolTypeCountDetails['kol_type_id']!='' && $kolTypeCountDetails['title']!='' && $kolTypeCountDetails['kol_type_id']>0){  ?>					 	
				 	<tr class="filter_fonts kolType<?php echo $kolTypeCountDetails['kol_type_id'];?>">
				 		<td class="textAlignRight">
				 			<input type="checkbox" name="kolType_ids[]" class="kolTypeElement hideCheckbox" id="kolType<?php echo $kolTypeCountDetails['title'];?>" value="<?php echo $kolTypeCountDetails['title'];?>" onclick="doSearchFilter1(-1,this)" 
							<?php if(isset($selectedKolTypes[$kolTypeCountDetails['title']])){
											unset($selectedKolTypes[$kolTypeCountDetails['title']]);
											echo 'checked="checked"';
										}
									?>
							/><?php								
								echo $kolTypeCountDetails['title'];									
							?>
				 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $kolTypeCountDetails['count']."(".round(($kolTypeCountDetails['count']/$allkolTypeCount)*100)."%)";?>" 
				  						style="width: <?php if(isset($allkolTypeCount)) echo round(($kolTypeCountDetails['count']/$allkolTypeCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if(isset($kolTypeCountDetails['count'])) echo $kolTypeCountDetails['count']; else echo 0;?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Opt-in/Opt-out-------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Opt-in/Opt-out</caption>
		<tr class="filter_fonts">
			<td width="40%">All</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allOptInOutCount)) echo $allOptInOutCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		foreach($arrOptInOutCount as $optInCountDetails){ ?>
		 	<?php if($optInCountDetails['opt_in_out_id']>0 && $optInCountDetails['opt_name']!=''){?>
				<tr class="filter_fonts optType<?php echo $optInCountDetails['opt_in_out_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="optInOut_ids[]" class="optInOutElement hideCheckbox" id="optInOut<?php echo $optInCountDetails['opt_in_out_id'];?>" value="<?php echo $optInCountDetails['opt_in_out_id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
									if(isset($selectedOptInOut[$optInCountDetails['opt_in_out_id']])){
									    unset($selectedOptInOut[$optInCountDetails['opt_in_out_id']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $optInCountDetails['opt_name'];?>
						 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $optInCountDetails['count']."(".round(($optInCountDetails['count']/$allOptInOutCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allOptInOutCount)) echo round(($optInCountDetails['count']/$allOptInOutCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if(isset($optInCountDetails['count'])) echo $optInCountDetails['count']; else echo 0;?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Specialty------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Specialty</caption>
		<tr class="filter_fonts">
			<td width="40%">All Specialties</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allSpecialtyCount)) echo $allSpecialtyCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsBySpecialtyCount as $specialtyCountDetails){ ?>
		 	<?php if($specialtyCountDetails['specialty']!='' && $specialtyCountDetails['specialty']!= 0){?>
				<tr class="filter_fonts specialty<?php echo $specialtyCountDetails['specialty'];?>">
					 	<td class="textAlignRight">
			 				<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $specialtyCountDetails['specialty'];?>" value="<?php echo $specialtyCountDetails['specialty'];?>" onclick="doSearchFilter1(-1,this)" 
							<?php
								if(isset($selectedSpecialties[$specialtyCountDetails['specialty']])){
									unset($selectedSpecialties[$specialtyCountDetails['specialty']]);
									echo 'checked="checked"';
								}
							?> 
							/><?php echo $specialtyCountDetails['specs'];?>
					 	</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						title="<?php echo $specialtyCountDetails['count']."(".round(($specialtyCountDetails['count']/$allSpecialtyCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allSpecialtyCount)) echo round(($specialtyCountDetails['count']/$allSpecialtyCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if(isset($specialtyCountDetails['count'])) echo $specialtyCountDetails['count']; else echo 0;?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Org Type------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Org Type</caption>
		<tr class="filter_fonts">
			<td width="40%">All Org Types</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allOrgTypeCount)) echo $allOrgTypeCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrOrgByTypeCount as $orgTypeCountDetails){ ?>
		 	<?php if($orgTypeCountDetails['org_type_id']>0){ ?>
			 	<tr class="filter_fonts orgType<?php echo $orgTypeCountDetails['org_type_id'];?>">
			 		<td class="textAlignRight">
			 			<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>" value="<?php echo $orgTypeCountDetails['org_type_id'];?>" onclick="doSearchFilter1(-1,this)" 
						<?php
							if(isset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']])){
								unset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']]);
								echo 'checked="checked"';
							}
						?>
						/><?php echo $orgTypeCountDetails['type'];?>
			 		</td>
				 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $orgTypeCountDetails['count']."(".round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allOrgTypeCount)) echo round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if(isset($orgTypeCountDetails['count'])) echo $orgTypeCountDetails['count']; else echo 0;?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn">
	       	 <i class="glyphicon glyphicon-search"></i>
	        </button>
     	</div>
      	<input type="text" name="org_type" class="form-control input_hight_for_filters autocompleteInputBox" id="orgType" value="Enter Org Type" title="" />
		<input type="hidden" name="org_type_id" id="orgTypeId" value="" />
    </div>
</div>
<!-- --------------------------State------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>State</caption>
		<tr class="filter_fonts">
			<td width="40%">All States</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" style="width:100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  	<?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByStateCount as $key=>$arrStateCountDetails){ ?>
		 	<?php if($arrStateCountDetails['state']!='' && $arrStateCountDetails['state_id']>0){?>
		 	<tr class="filter_fonts state<?php echo $arrStateCountDetails['state_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $arrStateCountDetails['state_id'];?>" value="<?php echo $arrStateCountDetails['state_id'];?>" onclick="doSearchFilter1(-1,this)" 
					<?php
						if(isset($selectedStates[$arrStateCountDetails['state_id']])){
							unset($selectedStates[$arrStateCountDetails['state_id']]);
							echo 'checked="checked"';
						}
					?> 
					/><?php echo $arrStateCountDetails['state'];?>
		 		</td>
	 		<td>
				 			<div class="progress no_bottom_margin">
				  				<div class="progress-bar" role="progressbar" 
				  						 title="<?php echo $arrStateCountDetails['count']."(".round(($arrStateCountDetails['count']/$allStateCount)*100)."%)";?>"
				  						style="width: <?php if(isset($allStateCount)) echo round(($arrStateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"
				  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
				  				<?php if(isset($arrStateCountDetails['count'])) echo $arrStateCountDetails['count']; else echo 0;?>
				  				</div>
							</div>
						</td>
					</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Lists------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>List</caption>
		<tr class="filter_fonts">
			<td width="40%">All Lists</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				  style="width: <?php if(isset($allListCount)) echo round(($listCountDetails['count']/$allListCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  <?php if(isset($allListCount)) echo $allListCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByListCount as $listCountDetails){ ?>
		 	<?php if($listCountDetails['list_name']!=''){?>
		 	<tr class="list<?php echo $listCountDetails['list_name_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo $listCountDetails['list_name_id'];?>" value="<?php echo $listCountDetails['list_name_id'];?>" onclick="doSearchFilter1(-1,this)"
		 				<?php 
		 				if(isset($selectedLists[$listCountDetails['list_name_id']])){
							unset($selectedLists[$listCountDetails['list_name_id']]);
							echo 'checked="checked"';
						}
						?> 
					/><?php echo $listCountDetails['list_name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $arrKolsByListCount[$key]['count']."(".round(($arrKolsByListCount[$key]['count']/$allListCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allListCount)) echo round(($arrKolsByListCount[$key]['count']/$allListCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				<?php if(isset($arrStateCountDetails['count'])) echo $arrStateCountDetails['count']; else echo 0;?>
	  				</div>
				</div>
			</td>
		</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Organization------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Organization</caption>
		<tr class="filter_fonts">
			<td width="40%">All Organizations</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allOrgCount)) echo round(($allOrgCount/$allOrgCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				  <?php if(isset($allOrgCount)) echo $allOrgCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;
		 	foreach($arrKolsByOrgCount as $orgCountDetails){ ?>
		 	<?php
		 		if($orgCountDetails['name']!=''){?>
		 	<tr class="filter_fonts org<?php echo $orgCountDetails['org_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgCountDetails['org_id'];?>" value="<?php echo $orgCountDetails['org_id'];?>" onclick="doSearchFilter1(-1,this)" 
					<?php if(isset($selectedOrgs) && sizeof($selectedOrgs)>0 && $selectedOrgs!=null){
							if((in_array($orgCountDetails['name'], $selectedOrgs))||(in_array($orgCountDetails['org_id'], $selectedOrgs))) {
								if(isset($selectedOrgs[$orgCountDetails['org_id']])){
									unset($selectedOrgs[$orgCountDetails['org_id']]);
								}
								?>
								checked="checked"
						<?php 
							$key = array_search($orgCountDetails['name'], $selectedOrgs);
							if(array_key_exists($key, $selectedOrgs))
								unset($selectedOrgs[$key]);
							//$selectedOrgs=array_values($selectedOrgs);
				 			}
				 		}?>
					/><?php echo $orgCountDetails['name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $orgCountDetails['count']."(".round(($orgCountDetails['count']/$allOrgCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allOrgCount)) echo round(($orgCountDetails['count']/$allOrgCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				<?php if(isset($orgCountDetails['count'])) echo $orgCountDetails['count']; else echo 0;?>
	  				</div>
				</div>
			</td>
		</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Education------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Education</caption>
		<tr class="filter_fonts">
			<td width="40%">All Educations</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allEduCount)) echo round(($allEduCount/$allEduCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				 <?php if(isset($allEduCount)) echo $allEduCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
		<?php $i=0;//pr($selectedEdus);pr($arrKolsByEduCount);
		 	foreach($arrKolsByEduCount as $eduCountDetails){ ?>
		 	<?php if($eduCountDetails['institute_id']!=''){?>
		 	<tr class="filter_fonts edu<?php echo $eduCountDetails['institute_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="edu_ids[]" class="eduElement hideCheckbox" id="edu<?php echo $eduCountDetails['institute_id'];?>" value="<?php echo $eduCountDetails['institute_id'];?>" onclick="doSearchFilter1(-1,this)" 
					<?php if(isset($selectedEdus) && sizeof($selectedEdus)>0 && $selectedEdus!=null){if(in_array($eduCountDetails['institute_name'], $selectedEdus)) {?>
						checked="checked"
					<?php $key = array_search($eduCountDetails['institute_name'], $selectedEdus);if(array_key_exists($key, $selectedEdus))unset($selectedEdus[$key]);$selectedEdus=array_values($selectedEdus);}}?>
					/><?php echo $eduCountDetails['institute_name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $eduCountDetails['count']."(".round(($eduCountDetails['count']/$allEduCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allEduCount)) echo round(($eduCountDetails['count']/$allEduCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				<?php if(isset($eduCountDetails['count'])) echo $eduCountDetails['count']; else echo 0;?>
	  				</div>
				</div>
			</td>
		</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>
<!-- --------------------------Event------------------------------------------------------------------------------------- -->
<div class="filterDiv">
	<table class="table no_bottom_margin no">
	<caption>Event</caption>
		<tr class="filter_fonts">
			<td width="40%">All Events</td>
			<td width="60%">
				<div class="progress no_bottom_margin">
				  <div class="progress-bar" role="progressbar" 
				 style="width: <?php if(isset($allEventCount)) echo round(($allEventCount/$allEventCount)*100); else echo 0;?>%;"
				  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
				<?php if(isset($allEventCount)) echo $allEventCount; else echo 0;?>
				  </div>
				</div>
			</td>
		</tr>
 	<?php $i=0;
	 	foreach($arrKolsByEventCount as $eventCountDetails){ ?>
	 	<?php if($eventCountDetails['event_id']!=''){?>
		 <tr class="filter_fonts event<?php echo $eventCountDetails['event_id'];?>">
		 		<td class="textAlignRight">
		 			<input type="checkbox" name="event_ids[]" class="eventElement hideCheckbox" id="event<?php echo $eventCountDetails['event_id'];?>" value="<?php echo $eventCountDetails['event_id'];?>" onclick="doSearchFilter1(-1,this)" 
					<?php if(isset($selectedEvents) && sizeof($selectedEvents)>0 && $selectedEvents!=null){if(in_array($eventCountDetails['event_name'], $selectedEvents)) {?>
						checked="checked"
					<?php $key = array_search($eventCountDetails['event_name'], $selectedEvents);if(array_key_exists($key, $selectedEvents))unset($selectedEvents[$key]);$selectedEvents=array_values($selectedEvents);}}?>
					/><?php echo $eventCountDetails['event_name'];?>
		 		</td>
	 		<td>
	 			<div class="progress no_bottom_margin">
	  				<div class="progress-bar" role="progressbar" 
	  						title="<?php echo $eventCountDetails['count']."(".round(($eventCountDetails['count']/$allEventCount)*100)."%)";?>"
	  						style="width: <?php if(isset($allEventCount)) echo round(($eventCountDetails['count']/$allEventCount)*100); else echo 0;?>%;"
	  						 aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
	  				<?php if(isset($eventCountDetails['count'])) echo $eventCountDetails['count']; else echo 0;?>
	  				</div>
				</div>
			</td>
		</tr>
			<?php $i++; if($i>3) break; }}?>
	</table>
    <div class="input-group">
    	<div class="input-group-btn">
	        <button class="btn btn-default right_side_bar_btn" type="submit" title="Advance search">
	        <i class="glyphicon glyphicon-search"></i></button>
     	</div>
      	<input type="text" class="form-control input_hight_for_filters" placeholder="Enter KTL name" name="search">
    </div>
</div>