<?php
/**
 * This is Modle file of 'my_list_kol'
 * @author Vinayak
 * @since 2.0
 * @created on 28-02-11
 * 
 */



class My_list_kol extends model{
	
	function My_list_kol(){
		parent::model();
		$this->load->model('common_helpers');
	}
	
	/*
	 * To get list of categories 
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -$arrCategories(array) 
	 */
	function listCategories($userId,$clientId){
		$arrCategories=array();
		$this->db->where('user_id',$userId);
		$this->db->where('client_id',$clientId);
		$arrCategoriesResult=$this->db->get('list_categories');
		foreach($arrCategoriesResult->result_array() as $row){
			$row['count']=$arrCategoriesResult->num_rows();
			$arrCategories[]=$row;
		}
		return $arrCategories;
	}	

	/*
	 * To save cetegory into 'list_categories' table
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -$lastInsertId
	 */
	function saveCategory($arrCategory){
		if($this->db->insert('list_categories',$arrCategory)){
			return $this->db->insert_id();
		}else{
			return false;
		}
		
	}
	
	/*
	 * To Editing category
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -$arrCategory
	 */
	function editCategory($catId){
		$arrCategory=array();
		$this->db->where('id',$catId);
		$arrCategoryResult=$this->db->get('list_categories');
		foreach($arrCategoryResult->result_array() as $row){
			$arrCategory=$row;
		}
		return $arrCategory;
	}
	
	/*
	 * To update category
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -True
	 */
	function updateCategory($arrCategory){
		$this->db->where('id',$arrCategory['id']);
		if($this->db->update('list_categories',$arrCategory)){
			return true;
		}else{
			return false;
		}
	}

	/*
	 * To save List names to table
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -True
	 */
	function saveListName($arrListNames){
		
		if($this->db->insert('list_names',$arrListNames)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	/*
	 * To save ' List kols Id and list_name_id'  of particular User,Category
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -True
	 */
	function saveListOfKols($arrKols,$lastInsertId){
		foreach($arrKols as $kols){
			//$kols1['category_id']=$lastInsertId;
			$arrKol['user_id']=$this->session->userdata('user_id');
			$arrKol['kol_id']=$kols;
			$arrKol['list_name_id']=$lastInsertId;
			$this->db->insert('list_kols',$arrKol);
		}
		return true;
		
	}
	
	function saveKtlList($kol,$listId){
		
		$arrKol['user_id']=$this->session->userdata('user_id');
		$arrKol['kol_id']=$kol;
		$arrKol['list_name_id']=$listId;
		
		$result = $this->db->insert('list_kols',$arrKol);
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	/*
	 * To get list of categories and its assocaited list names
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -$arrCategories(array) 
	 */
	function listCategoriesAndNamesPrivate($userId,$clientId){
		$arrCategories=array();
		
		$arrResult=$this->db->query("select list_categories.category,list_names.list_name,list_names.id
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where  is_public=0 and list_categories.client_id=$clientId and list_categories.user_id=$userId");
//		$this->db->last_query();									
		foreach($arrResult->result_array() as $row){
			$arrCategories[]=$row;
		}
                
		return $arrCategories;
	}
        
        function listCategoriesAndNamesPrivateIpad($userId,$clientId){
		$arrCategories=array();
		
		$arrResult=$this->db->query("select list_categories.id, list_categories.category,list_names.list_name,list_names.id as listId
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where  is_public=0 and list_categories.client_id=$clientId and list_categories.user_id=$userId");
//		$this->db->last_query();									
		foreach($arrResult->result_array() as $row){
			$arrCategories[]=$row;
		}
                
		return $arrCategories;
	}
        
        function listCategoriesAndNamesPrivateIpadSubID($userId,$clientId,$id){
		$arrCategories=array();
		
		$arrResult=$this->db->query("select list_categories.id, list_categories.category,list_names.list_name,list_names.id as listId
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where  is_public=0 and list_categories.client_id=$clientId and list_categories.user_id=$userId and list_categories.id=$id" );
//		$this->db->last_query();									
		foreach($arrResult->result_array() as $row){
			$arrCategories[]=$row;
		}
	
		return $arrCategories;
	}
	
	function listCountKolsIDPrivate($id,$userId){
		
		$query = $this->db->query("select count(list_name_id) as count from list_kols where list_name_id='$id' and user_id = '$userId'");
		$result = $query->result();
//		echo $this->db->last_query();
		return $result[0]->count;
	}
	function listCountKolsIDPublic($id){
	
		$query = $this->db->query("select count(list_name_id) as count from list_kols where list_name_id='$id'");
		$result = $query->result();
		//		echo $this->db->last_query();
		return $result[0]->count;
	}
	/*
	 * To get list of categories and its assocaited list names
	 * $author Vinayak
	 * @since 2.0
	 * Created on 7/4/2011
	 * @return Type -$arrCategories(array) 
	 */
	function listCategoriesAndNamesPublic($userId,$clientId){
		$arrCategories=array();
		$arrResult=$this->db->query("select list_categories.category,list_names.list_name,list_names.id
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where list_categories.is_public=1 and list_categories.client_id=$clientId");
											
		foreach($arrResult->result_array() as $row){
			
			$arrCategories[]=$row;
		}
		return $arrCategories;
	}
	
	function listCategoriesAndNamesPublicIpad($userId,$clientId){
		$arrCategories=array();
		$arrResult=$this->db->query("select list_categories.id, list_categories.category,list_names.list_name,list_names.id as listId
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where list_categories.is_public=1 and list_categories.client_id=$clientId");
									
		foreach($arrResult->result_array() as $row){
			
			$arrCategories[]=$row;
                       
		}
		return $arrCategories;
	}
	function listCategoriesAndNamesPublicIpadSubID($userId,$clientId,$id){
		$arrCategories=array();
		$arrResult=$this->db->query("select list_categories.id, list_categories.category,list_names.list_name,list_names.id as listId
									from list_categories
									left join  list_names on  list_categories.id=list_names.category_id
									where list_categories.is_public=1 and list_categories.client_id=$clientId and list_categories.id=$id" );
									
		foreach($arrResult->result_array() as $row){
			
			$arrCategories[]=$row;
                       
		}
		return $arrCategories;
	}
	/*
	 * To get list names of passed category
	 * $author Vinayak
	 * @since 2.0
	 * Created on 12/4/2011
	 * @return Type -$arrLists(array) 
	 */
	function getListNamesBycategory($id){
		$arrLists=array();
		$arrResult=$this->db->query("
									select list_categories.category,list_names.list_name,list_names.id,list_names.category_id,list_categories.user_id
									from list_names
									left join list_categories on list_names.category_id=list_categories.id
									where list_names.category_id=$id");
			foreach($arrResult->result_array() as $row){
				
			
			$arrLists[]=$row;
		}
		if(empty($arrResult->result_array())){
			$this->db->select('category');
			$this->db->where('id',$id);
			$arrResult = $this->db->get('list_categories');
			$arrLists = $arrResult->result_array();
		}
		
		//pr($arrCAtegories);exit;
		return $arrLists;
		
	}
	function getCatergoryNameById($id){
		$this->db->select('category');
		$this->db->where('id',$id);
		$arrResult = $this->db->get('list_categories');
		$arrName = $arrResult->result_array();
		return $arrName;
	}
	/*
	 * To edit list name
	 * $author Vinayak
	 * @since 2.0
	 * Created on 12/4/2011
	 * @return Type -$arrLists(array) 
	 */
	function editListName($listId){
		$this->db->select('list_names.*,list_categories.category');
		$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
		$this->db->where('list_names.id',$listId);
		$arrResult=$this->db->get('list_names');
		foreach($arrResult->result_array() as $row){
			$arrListName=$row;
		}
		return $arrListName;
	}
	
	/*
	 * To update list name
	 * $author Vinayak
	 * @since 2.0
	 * Created on 12/4/2011
	 * @return Type -$arrLists(array) 
	 */
	function updateListName($arrListName){
		$this->db->where('id',$arrListName['id']);
		if($this->db->update('list_names',$arrListName)){
			return true;
		}else{
			return false;
		}
	}

	/*
	 * To get kold detail of particualr list name and category
	 * $author Vinayak
	 * @since 2.0
	 * Created on 12/4/2011
	 * @return Type -$arrLists(array) 
	 */
	function listKolsOfCategory($listNameId){
		$arrKolDetail=array();
		/* $arrResult=$this->db->query("
										select kols.first_name,kols.middle_name,kols.last_name,kols.org_id,kols.title,kols.primary_phone,kols.primary_email,kols.gender,kols.profile_type,list_kols.*,list_names.list_name,
										list_categories.category,organizations.name,specialties.specialty,kols.country_id,countries.country,list_categories.user_id
										from list_kols 
										left join list_names on list_names.id=list_kols.list_name_id
										left join list_categories on list_names.category_id=list_categories.id
										left join kols on  kols.id=list_kols.kol_id
										left join organizations on kols.org_id=organizations.id
										left join specialties on kols.specialty=specialties.id
										left join countries on countries.countryId=kols.country_id
										left join kols_client_visibility on kols_client_visibility.kol_id = kols.id
										where list_names.category_id!=0 and list_kols.list_name_id!=0 and list_kols.list_name_id=$listNameId and list_kols.kol_id in(kols.id) and kols_client_visibility.client_id = 10" );
		 */
		$this->db->select("kols.deleted_by,kols.opt_in_out_status,kols.first_name,kols.middle_name,kols.last_name,kols.org_id,kols.title,kols.primary_phone,kols.primary_email,kols.gender,kols.profile_type,kols.unique_id,list_kols.*,list_names.list_name,
										list_categories.category,organizations.name,specialties.specialty,kols.country_id,countries.country,list_categories.user_id");
		
		$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		$this->db->join('kols','kols.id=list_kols.kol_id','left');
		$this->db->join('organizations','kols.org_id=organizations.id','left');
		$this->db->join('specialties','kols.specialty=specialties.id','left');
		$this->db->join('countries','countries.countryId=kols.country_id','left');
		$this->db->where('list_names.category_id!=','0',false);
		$this->db->where('list_kols.list_name_id!=','0',false);
		$this->db->where('list_kols.list_name_id',$listNameId);
		//$this->db->where_in('list_kols.kol_id','kols.id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrResult = $this->db->get("list_kols");
		
		foreach($arrResult->result_array() as $row){
			$arrKolDetail[]=$row;
		}
	//	pr($arrKolDetail);
		return 	$arrKolDetail;	
	}
	
	function listKolsByIds($arrIds){
	    $arrKolDetail=array();
	    $this->db->select("kols.first_name,kols.middle_name,kols.last_name,kols.address1,kols.address2,kols.org_id,kols.title,kols.primary_phone,kols.primary_email,kols.gender,kols.postal_code,kols.profile_type,kols.unique_id,specialties.specialty,countries.country,regions.Region,cities.City");
	    $this->db->select('opt_inout_statuses.name as opt_status_name');
	    $this->db->join('organizations','kols.org_id=organizations.id','left');
	    $this->db->join('specialties','kols.specialty=specialties.id','left');
	    $this->db->join('countries','countries.countryId=kols.country_id','left');
	    $this->db->join('regions', 'regions.RegionId = kols.state_id', 'left');
	    $this->db->join('cities', 'cities.cityId = kols.city_id', 'left');
	    $this->db->join('opt_inout_statuses', 'opt_inout_statuses.id = kols.opt_in_out_status', 'left');
	    
	    $this->db->where_in('kols.id',$arrIds);
	    $arrResult = $this->db->get("kols");
	    // 	pr($this->db->last_query());
	    foreach($arrResult->result_array() as $row){
	        $arrKolDetail[]=$row;
	    }
	    // 	    	pr($arrKolDetail);exit;
	    return 	$arrKolDetail;
	}
	
	
	/*
	 * To get count of kols
	 * $author Vinayak
	 * @since 2.0
	 * Created on 26/4/2011
	 * @return Type -$arrLists(array) 
	 */
	function countOfKolsPrivate(){
		$clientId=$this->session->userdata('client_id');
		$userId=$this->session->userdata('user_id');
		$arrKolDetail=array();
		$arrKols=$this->db->query("select list_categories.category,list_names.list_name, count(list_kols.list_name_id) as count,list_kols.list_name_id
									from list_kols
									left join list_names on list_kols.list_name_id=list_names.id
									left join list_categories on list_names.category_id=list_categories.id
									where  list_categories.client_id=$clientId and list_categories.user_id=$userId and list_categories.is_public=0 and list_kols.kol_id in (select id from kols)
									group by list_kols.list_name_id");
		foreach($arrKols->result_array() as $row){
			$arrKolDetail[] = $row;
			
		}
		return 	$arrKolDetail;
	}
	
	function countOfKolsPublic(){
		$clientId=$this->session->userdata('client_id');
		$userId=$this->session->userdata('user_id');
		$arrKolDetail=array();
		$arrKols=$this->db->query("select list_categories.category,list_names.list_name, count(list_kols.list_name_id) as count,list_kols.list_name_id
									from list_kols
									left join list_names on list_kols.list_name_id=list_names.id
									left join list_categories on list_names.category_id=list_categories.id
									where  list_categories.client_id=$clientId and list_categories.is_public=1 and list_kols.kol_id in (select id from kols)
									group by list_kols.list_name_id");
		foreach($arrKols->result_array() as $row){
			$arrKolDetail[] = $row;
			
		}
		return 	$arrKolDetail;
	}
	
	
	/*
	 *  To get  'list names' of particular Category 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 7-4-2011
	 */	
	function getListNames($categoryId){
		
		$arrlist=array();
		$arrListResult=$this->db->query('select list_names.*,list_categories.is_public 
											from list_names
											left join list_categories on list_categories.id=list_names.category_id
											where list_names.category_id='.$categoryId.'');
		 if($arrListResult->num_rows()!=0){
			foreach($arrListResult->result_array() as $row){
				$arrlist[]=$row;
			}

			return $arrlist;
		 }else{
			$this->db->where('id',$categoryId);
			$reult=$this->db->get('list_categories');
			foreach($reult->result_array() as $row){
				
				$arrlist[]=$row;
			}
			return $arrlist;
		 }
		
	}
	
	
	/*
	 *  To get  'list categories of particular user 
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 13-4-2011
	 *  @return type array->$arrCategories
	 */	
	function listCategoriesOfUser($categoryId){
		$arrCategories=array();
		$user_id=$this->session->userdata('user_id');
		$this->db->where('user_id',$user_id);
		//$this->db->where_not_in('id',$categoryId);
		$arrCategoriesResult=$this->db->get('list_categories');
		foreach($arrCategoriesResult->result_array() as $row){
			$arrCategories[]=$row;
		}
		return $arrCategories;
	
	}
	
	/*
	 *  To delete category from databse
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 13-4-2011
	 *  
	 */	
	function daleteCategory($categoryId){
		$this->db->where('id',$categoryId);
		if($this->db->delete('list_categories')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Category',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $categoryId,
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => "Delete Category",
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Category',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $categoryId,
					'transaction_table_id' => LIST_CATEGORIES,
					'transaction_name' => "Delete Category",
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}	
	
	
	/*
	 *  To delete List name from databse
	 *  @author Vinayak Malladad
	 *  @since 2.0
	 *  @created on 13-4-2011
	 *  
	 */	
	function deleteListName($listNameId){
		$this->db->where('id',$listNameId);
		$this->db->delete('list_names');
		//Add Log activity
		$arrLogDetails = array(
				'type' => DELET_RECORD,
				'description' => 'Delete list names',
				'status' => STATUS_SUCCESS,
				'transaction_id' =>  $listNameId,
				'transaction_table_id' => LIST_NAMES,
				'transaction_name' => "Delete list names"
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	
	/*
	 *  Retrives all the list names and also there respective category names
	 *  @author Ramesh B
	 *  @since 2.2
	 *  @created on 3-5-2011
	 */	
	function getListNameAndCategoryName($listName,$user_id,$client_id){
		$arrListDetails=array();
		
		$this->db->select("DISTINCT(list_kols.list_name_id),list_kols.list_name_id,list_names.list_name,list_categories.category");
		$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
		$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
		$this->db->like('list_names.list_name',$listName);
		$this->db->where('list_categories.client_id',$client_id);
		$where="(list_categories.user_id=$user_id OR list_categories.is_public=1)";
		$this->db->where($where);
		$results=$this->db->get('list_kols');
		foreach($results->result_array() as $row){
			$arrListDetails[$row['list_name_id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrListDetails;
	}
	
	/*
	 *  Returns the id of the given list name and category name
	 *  @author Ramesh B
	 *  @since 2.2
	 *  @created on 3-5-2011
	 */	
	function getListName($listName,$categoryName){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$this->db->select("list_names.id");
		$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
		$this->db->where('list_names.list_name',$listName);
		$this->db->where('list_categories.category',$categoryName);
		$this->db->where('list_categories.client_id',$client_id);
		$where="(list_categories.user_id=$user_id OR list_categories.is_public=1)";
		$this->db->where($where);
		$results=$this->db->get('list_names');
		$resutlRow=$results->row();
		if(isset($resutlRow))
			return $resutlRow->id;
		else 
			return 0;
	}
	
	function getAllListNamesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNameIds=0,$reportSection,$chartType=0,$arrStatesIds=0,$profileType,$viewType,$arrGlobalRegionIds,$arrFilterFields){
		$arrListNameAndCount = array();
		$userId = $this->session->userdata('user_id');
		$clientId = $this->session->userdata('client_id');
		
		$this->db->select('list_names.list_name,list_names.id,list_kols.kol_id,count(list_names.id) as count');
		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
		$this->db->join('kols','kols.id=list_kols.kol_id','left');
		if($arrSpecialityIds!=''&& $arrSpecialityIds!=0 ){
			$this->db->where_in('kols.specialty',$arrSpecialityIds);
		}
		
		if($arrCountriesIds!=''&& $arrCountriesIds!=0 ){
			$this->db->where_in('kols.country_id',$arrCountriesIds);
		}
		if($arrStatesIds!=''&& $arrStatesIds!=0 ){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
		if($arrKolIds!=''&& $arrKolIds!=0 ){
			$this->db->where_in('list_kols.kol_id',$arrKolIds);
		}
		if($arrListNameIds!='' && $arrListNameIds!=0 && !empty($arrListNameIds)){
			//$this->db->where_in('list_names.id',$arrListNameIds);
		}
		if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
		    $this->db->where_in('kols.id', $arrFilterFields['viewType']);
		}
		if ($profileType != ''){
		    if($profileType == DISCOVERY){
		        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
		    }else{
		        $this->db->where('kols.profile_type', $profileType);
		        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		    }
		    //             $this->db->where('kols.profile_type', $arrProfileType);
		}else{
		    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		}
		/*if(isset($viewType) && sizeof($viewType) > 0){
			$this->db->where_in("kols.id",$viewType);
		}*/
		$this->db->where('list_categories.client_id',$clientId);
		$this->db->where("(list_categories.user_id=$userId or list_categories.is_public=1)");
		$this->db->group_by('list_names.id');
		$this->db->order_by('count desc');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		
		$arrListNameResult = $this->db->get('list_kols');
		foreach($arrListNameResult->result_array() as $row){
			$arrListNameAndCount[$row['id']]=$row;
			
		}
		//echo $this->db->last_query();
		return $arrListNameAndCount;
	}
	
	function getListNameId($list_name){
		//echo $list_name;
		$this->db->select('id');
		$this->db->where('list_name',$list_name);
		$arrIdResult=$this->db->get('list_names');
		foreach($arrIdResult->result_array() as $row){
			$id=$row['id'];
		}
		return $id;
	}
	function getListsById($arrId){	    
		$arrLists	= array();
		if(!empty($arrId)){
    		$this->db->select('id,list_name');
    		$this->db->where_in('id',$arrId);
    		$arrIdResult=$this->db->get('list_names');
    		foreach($arrIdResult->result_array() as $row){
    			$arrLists[$row['id']]=$row['list_name'];
    		}
		}
		return $arrLists;
	}
	function getKOLIdsByListId($listId=0){
		$arrLists	= array();
		if(is_array($listId)){
			$this->db->where_in('list_name_id',$listId);
		}
		$arrIdResult=$this->db->get('list_kols');
		//echo $this->db->last_query();
		foreach($arrIdResult->result_array() as $row){
			$arrLists[$row['kol_id']]=$row['kol_id'];
		}
		return $arrLists;
	}
        
    /**
     * Retrieves all lists
     * 
     * @author Sumati K
     * @since 
     * @updated 30 April 2015
     * 
     */
        function getAllLists() {
		$this->db->select('list_names.*');
                $query = $this->db->get('list_names');
        
                return $query->result_array();
        }
        
        function getExcludedKolsLists($arrIds){

            $this->db->select(array('distinct list_names.id', 'list_names.list_name', '0 as kol_list_count'), false);
            $this->db->join('list_kols','list_kols.kol_id=kols.id');
            $this->db->join('list_names','list_names.id=list_kols.list_name_id');
            $this->db->where('kols.status',COMPLETED);
            if(count($arrIds) !=0)
                $this->db->where_not_in('list_names.id', $arrIds);
            $this->db->group_by('list_names.id');
            $this->db->order_by("list_names.list_name", "asc"); 
            $client_id = $this->session->userdata('client_id');
            if($client_id !== INTERNAL_CLIENT_ID){
            	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = list_kols.kol_id', 'left');
            	$this->db->where('kols_client_visibility.client_id', $client_id);
            }
            $query = $this->db->get('kols');
            //pr($this->db->last_query());exit;
			return $query->result_array();
        }
    function editListNameWithCategoryId($listId){
		$this->db->select('list_names.*,list_categories.category');
		$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
		$this->db->where('list_names.category_id',$listId);
		$arrResult=$this->db->get('list_names');
		
		foreach($arrResult->result_array() as $row){
			$arrListName=$row;
		}
		return $arrListName;
	}
	function getListCategoryKolsCount($subContentPage){
	    $clientId = $this->session->userdata('client_id');
	    $userId = $this->session->userdata('user_id');
	    
	    $this->db->select("list_categories.category,list_categories.id as cat_id,list_categories.is_public, list_names.list_name,list_names.id as list_id, count(list_kols.kol_id) as no_of_kols");
	    $this->db->join("list_names","list_names.id=list_kols.list_name_id");
	    $this->db->join("list_categories","list_categories.id=list_names.category_id");
	    $this->db->where("list_categories.client_id",$clientId);
	    if($subContentPage=="my_list"){
	        $this->db->where("list_categories.user_id",$userId);
	    }
	    $this->db->group_by("list_kols.list_name_id");
	    $this->db->order_by("list_categories.is_public","desc");
	    $this->db->limit(1);
	    $get = $this->db->get("list_kols");
	    /*$get = $this->db->query("SELECT list_categories.category,list_categories.id as cat_id,list_categories.is_public, list_names.list_name,list_names.id as list_id, count(list_kols.kol_id) as no_of_kols FROM list_kols 
        left join list_names on list_names.id=list_kols.list_name_id
        left join list_categories on list_categories.id=list_names.category_id
        WHERE list_categories.client_id=$clientId group by list_kols.list_name_id order by list_categories.is_public desc limit 1 ");*/	    
	    $this->db->last_query();
	    if($get->num_rows()>0){
	        return $get->result_array();
	    }
	    return false;
	}
	
	function getListingCategoryDetailsByID($listNameId){
		$client_id = $this->session->userdata('client_id');
		//$user_id   = $this->session->userdata('user_id');
		$this->db->select("list_names.id as listId, list_names.list_name, list_categories.id as catId, list_categories.category");
		$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
		$this->db->where('list_names.id',$listNameId);
		$this->db->where('list_categories.client_id',$client_id);
		//$where="(list_categories.user_id=$user_id OR list_categories.is_public=1)";
		//$this->db->where($where);
		$results=$this->db->get('list_names');
		$resutlRow=$results->row();
		if(isset($resutlRow))
			return $resutlRow;
			else
				return 0;
	}
        
}