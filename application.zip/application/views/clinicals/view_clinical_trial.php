<?php
/**
*
* Created By:
* Created On:12:50:04 AM
* @package application.views.clinicals
*/
?>
<head>
<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<?php //echo link_tag('images/favicon.ico', 'shortcut icon', 'image/ico'); ?>
	<?php echo $this->load->view('elements/favicon');?>
</head>
<style>
/*
#background{
}
#header{
    font-family: Sans-Serif;
    font-size: large;
    font-weight: bolder;
}
.header1,.header2{
	background-color: #EEEEFF;
}
.header1{
	width:50%;
}
#clinicalTable{
	border-top: 1px solid;
	border-right :1px solid;
	border-left: 1px solid;
	border-bottom:1px solid;
	margin-bottom: 20px;
	margin-left:27px;
}
#clinicalTable th{
	text-align:right;
}
#purposeTable{
	border-top: 1px solid;
	border-right :1px solid;
	border-left: 1px solid;
	border-bottom:1px solid;
	margin-bottom: 20px;
	margin-top: 10px;
	margin-left: 27px;
}
#imge{
	margin-top:20px;
}
.title{
    margin-left: 27px;
    margin-top: -14px;
}
.purpose{
    margin-left: 27px;
    margin-top: 6px;
}
.headings{
	font-family: Sans-Serif;
    font-size: medium;
    font-weight: bolder;
}*/
block {
    background: none repeat scroll 0 0 #EEEEEE;
    display: block;
    font-weight: bold;
    padding: 5px;
    border: 1px solid #CCCCCC;
}
.ctDetails{
	width: 100%;
	clear: both;
}
.ctDetails th, .ctDetails td{
	text-align: left;
	vertical-align: top;
}
.ctDetails th{
	background-color:#eee; 
}
.ctDetails td{
	color:#333;
}
.ctSection{
	clear: both;
    color: #333333;
    min-height: 20px;
    padding-bottom: 10px;
}
.ctSection strong{
	clear: both;
    display: block;
    float: left;
    padding-right: 5px;
    text-align: right;
    width: 100px;
}
</style>
	
<div id="background">
<?php 
/*
	<p class="trialName">
		<strong id="header">
			<?php 
				echo $ctDetailsResult['trial_name'];
			?>
		</strong>
	<p/> 
	
	<p class="status">
		<img src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">Status</strong><br />		
				
				<?php 
					echo  "&nbsp &nbsp &nbsp &nbsp".$ctDetailsResult['status'];
				?>		
	</p>
	<table  border="1" cellspacing="0" cellpadding="5" id="clinicalTable">
		<tr>
			<th class="header1" width="10%">
			Sponsor:
			</th>
			<td>
				<?php foreach($arrSponsors as $sponsor){
					//if($sponsor['type']=='lead sponsor')
						echo $sponsor['agency'];
				}?>
			</td>
		</tr>	
		<tr>
			<th class="header1" width="30%">
			Collabolator:
			</th>
			<td>
				<?php foreach($arrSponsors as $sponsor){
					if($sponsor['type']=='collaborator')
						echo $sponsor['agency'];
				}?>
			</td>
		</tr>	
		<tr>
			<th class="header1" width="40%">
			Information provided by: 
			</th>
			<td>
			<?php foreach($arrSponsors as $sponsor){
					echo $sponsor['agency'];
				}?>
			</td>
		</tr>	
		<tr>
			<th class="header1" width="40%">
			ClinicalTrials.gov Identifier:  
			</th>
			<td>
				<?php 
					echo $ctDetailsResult['ct_id'];
				?>
			</td>
		</tr>	
	</table>
		<img id="imge" src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">Purpose</strong>
		<br />
		<p class="purpose">
			<?php 
				echo $ctDetailsResult['purpose'];
			?>	
		</p>
		<table  border="1" cellspacing="0" cellpadding="5" id="purposeTable" width="80%">
			<tr>
				<th class="header2">
				Condition
				</th>
				<th class="header2">
				Intervention
				</th >
				<th class="header2">
				Phase
				</th>
			</tr>
			<tr>
				<td>
					<?php 
						echo $ctDetailsResult['condition'];
					?>	
				</td>
				<td>
				<?php foreach($arrInterventions as $inetrVention){
							echo $inetrVention['name'].'<br />';
					
				}?>
				</td>
				<td>
					<?php 
						echo $ctDetailsResult['phase'];
					?>	
				</td>
			</tr>
		</table>
		<p class="studyType">
				<img src="<?php echo base_url()?>images/triangle.gif"/>
			<strong class="headings">Study Type</strong>
			<?php 
				echo $ctDetailsResult['study_type'];
			?>
		</p>
		<p class="officialTitle">
		<img src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">Official Title</strong><br />
			<p class="title">
				<?php 
					echo "".$ctDetailsResult['official_title'];
				?>
			</p>
		</p>
	
	<p class="keywords">
		<img src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">Keywords</strong><br />		
		<?php foreach($arrKeyWords as $keyWord){				
					echo "&nbsp &nbsp &nbsp &nbsp".$keyWord['name']."<br />";
		}?>			
	</p>
	<p class="meshTerms">
		<img src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">MeSH terms</strong><br />		
		<?php foreach($arrMeshTerms as $meshTerm){				
					echo  "&nbsp &nbsp &nbsp &nbsp".$meshTerm['term_name']."<br />";
		}?>			
	</p>
	
	<p class="investigators">
		<img src="<?php echo base_url()?>images/triangle.gif"/>
		<strong class="headings">Investigators</strong><br />		
		<?php foreach($arrInvestigators as $investigator){				
					echo  "&nbsp &nbsp &nbsp &nbsp".$investigator['last_name']."<br />";
		}?>			
	</p>
	*/ 
?>
	<block><strong><?php echo $ctDetailsResult['trial_name'];?></strong></block>
	<div class="ctSection">
		<strong>Status: </strong>
		<?php echo $ctDetailsResult['status'];?>
	</div>
	<div class="ctSection">
		<strong>Study Type: </strong>
		<?php echo $ctDetailsResult['study_type'];?>
	</div>
	<div class="ctSection">
		<strong>Sponsor: </strong>
		<?php 
			$separator	= '';
			foreach($arrSponsors as $sponsor){
				if($sponsor['type']=='lead sponsor'){
				echo $separator.$sponsor['agency'];
				$separator	= ', ';
				}
			}
		?>
	</div>
	<div class="ctSection">
		<strong>Collaborator: </strong>
		<?php echo $ctDetailsResult['collaborator'];?>
	</div>
	<div class="ctSection">
		<strong>CT ID: </strong>
		<?php echo $ctDetailsResult['ct_id'];?>
	</div>
	<!--<div class="ctSection">
		<strong>KOL Role: </strong>
		<?php //echo $ctDetailsResult['kol_role'];?>
	</div>
	--><div class="ctSection">
		<strong>Purpose: </strong>
		<?php echo $ctDetailsResult['purpose'];?>
	</div>
	<div class="ctSection">
		<strong>Official Title: </strong>
		<?php echo $ctDetailsResult['official_title'];?>
	</div>
	<div>
		<table class="ctDetails">
			<tr>
				<th>Condition(s)</th>
				<th>Intervention(s)</th>
				<th>Phase</th>
			</tr>
			<tr>
				<td><?php 
						echo str_replace(',','<br />',$ctDetailsResult['condition']);
				?></td>
				<td><?php foreach($arrInterventions as $inetrVention){
							echo $inetrVention['name'].'<br />';
					
				}?></td>
				<td><?php 
						echo $ctDetailsResult['phase'];
				?></td>
			</tr>
			<tr>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Study Type</th>
			</tr>
			<tr>
				<td><?php 
						echo $ctDetailsResult['start_date'];
				?></td>
				<td><?php 
						echo $ctDetailsResult['end_date'];
				?></td>
				<td><?php 
						echo $ctDetailsResult['study_type'];
				?></td>
			</tr>
			<tr>
				<th>Minimum Age</th>
				<th>Maximum Age</th>
				<th>Gender</th>
			</tr>
			<tr>
				<td><?php 
						echo $ctDetailsResult['min_age'];
				?></td>
				<td><?php 
						echo $ctDetailsResult['max_age'];
				?></td>
				<td><?php 
						echo $ctDetailsResult['gender'];
				?></td>
			</tr>
			<tr>
				<th>Keywords</th>
				<th>MeSh Terms</th>
				<th>Investigator(s)</th>
			</tr>
			<tr>
				<td><?php foreach($arrKeyWords as $key=>$arrRow){
					echo $arrRow['name'].'<br />';
				}?></td>
				<td><?php foreach($arrMeshTerms as $key=>$arrRow){
					echo $arrRow['term_name'].'<br />';
				}?></td>
				<td><?php foreach($arrInvestigators as $key=>$arrRow){
					echo $arrRow['last_name'].' '.$arrRow['role'].'<br />';
				}?></td>
			</tr>
		</table>
	</div>
</div>