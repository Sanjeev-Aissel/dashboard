<?php
/**
 * Payment micro view page
 *
 * @author: Ramesh B
 * @Created 12 June 2012
 */
	$date	= $arrPayment['date'];
	if($date!="0000-00-00" && $date!=""){ 
		$date = explode('/',$date);
		$date = "of ".date("M d, Y", mktime(0, 0, 0, $date[0], $date[1], $date[2])).' ';
	}
?>
<script>
<?php 
			/** @Author Vinayak
			 ** @since  22 Aug 2012
		 	**The following code is used to disable caching in IE
		 	**/	
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
</script>
<style type="text/css">
	#paymentTbl th{
		color:#626262;
		text-align: right;
		padding-right: 2px;
	}
	#paymentTbl caption h3{
		margin: 5px 0px;
		text-align: center;
	}
</style>
	<!-- Table for Payment -->
	<table class="analystForm" id="paymentTbl">
	<caption><h3><?php echo $arrPayment['kol_name'];?>'s payment details <?php echo $date;?></h3></caption>
	<!--<tr>
		<td>		
			<p>
				<label for="paymentDuration">KOL:</label>
				<?php echo $arrPayment['kol_name'];?>
			</p>	
		</td>
		<td>		
			<p>
				<label for="paymentDuration">Date:</label>
				<?php echo $arrPayment['date'];?>
			</p>	
		</td>
	</tr>
		-->
		<tr>
			<th>Reason:</th>
			<td>
				<?php echo $arrPayment['reason'];?>
			</td>
			<th>Recorded By:</th>
			<td>
				<?php echo $arrPayment['created_by_full_name'];?>
			</td>
		</tr>
		<tr>
			<th>Requested By:</th>
			<td><?php echo $arrPaymentRequestBy[$arrPayment['requested_by']];?></td>
			<th>Paid By:</th>
			<td><?php echo $arrPaymentPaidBy[$arrPayment['paid_by']];?></td>
		</tr>
		<?php 
			foreach($arrPayment['arrTypesAndAmount'] as $key1=>$arrAmounts){
		?>
		<tr>
			<th>Type:</th>
			<td><?php echo $arrPaymentTypes[$arrAmounts['type']];?></td>
			<th>Amount:</h>
			<td><?php echo $arrPaymentCurrencies[$arrAmounts['currency']]['currency_symbol'].' '.$arrAmounts['indAmount'];?></td>
		</tr>
		<?php }?>
		<tr style="background-color: #eee;padding-bottom: 0px;">
			<td></td><td></td>
			<th style="vertical-align: top;">Total Amount: </th>
			<th style="text-align:left"> 
			<?php 
			foreach($arrPayment['arrGroupTypesAndAmount'] as $seperateAmountKey=>$seperateAmountValue){
				echo $arrPaymentCurrencies[$seperateAmountKey]['currency_symbol'].' '.$seperateAmountValue.'<br/>';
				//echo ;
			} ?>
			</th>
		</tr>
	</table>		
	<!-- End of Payment table -->