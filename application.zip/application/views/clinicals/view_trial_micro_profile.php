<style type="text/css">
	#trialMicroviewWrapper table caption h3{
		margin: 5px 0px;
	}
	#trialMicroviewWrapper table tr td{
		vertical-align: top;
	}
	#trialMicroviewWrapper table tr td.alignRight {
    	padding-right: 0;
    }
</style>
<div id="trialMicroviewWrapper">
	<table>
		<caption><h3><?php echo $ctDetailsResult['trial_name'];?></h3></caption>
		<tr>
			<td width="100" class="alignRight"><strong>Condition:</strong></td>
			<td><?php echo $ctDetailsResult['condition'];?></td>
		</tr>
		<tr>
			<td class="alignRight"><strong>Phase:</strong></td>
			<td><?php echo $ctDetailsResult['phase'];?></td>
		</tr>
		<tr>
			<td class="alignRight"><strong>Intervention:</strong></td>
			<td colspan="2">
				<?php
					$separator	= ''; 
					foreach($arrInterventions as $intervention){				
						echo $separator.$intervention['name'];
						$separator	= ', ';
					}
				?>
			</td>	
		</tr>
		<tr>
			<td class="alignRight"><strong>Role:</strong></td>
			<td colspan="2"><?php /* 	
						$separator	= '';
						foreach($arrInvestigators as $key=>$row){
							echo $separator.$row['role'];
							$separator	= ', ';
						}
						*/
					echo $ctDetailsResult['kol_role'];
			?></td>
		</tr>
		<tr>
			<td class="alignRight"><strong>Sponsor:</strong></td>
			<td colspan="2"><?php echo $sponsors;?></td>
		</tr>
	</table>
</div>

<!--<div id="trailMicroProfileContent">
	<h3><?php echo $ctDetailsResult['trial_name'];?></h3>

	<table class="microViewTbl">
		<tr>
			<th><span class="addrHeading">Role:</span></th>
			<td><?php 	
						$separator	= '';
						foreach($arrInvestigators as $key=>$row){
							echo $separator.$row['role'];
							$separator	= ',';
						}
			?></td>
		</tr>						
		<tr>
			<th><span class="addrHeading">Sponsor:</span></th>
			<td><?php /*foreach($arrSponsors as $sponsor){
					if($sponsor['type']=='lead sponsor')
						echo $sponsor['agency'];
					}*/
					
					echo $sponsors;
				?>
			</td>
		</tr>						
	
		<tr>
			<th><span class="addrHeading">Condition:</span></th>
			<td><?php echo $ctDetailsResult['condition'];?></td>
		</tr>						
	
		<tr>
			<th><span class="addrHeading">Intervention:</span></th>
			<td>
				<?php foreach($arrInterventions as $intervention){				
					echo $intervention['name']."<br />";
				}?>
			</td>	
		</tr>						
	
		<tr>
			<th><span class="addrHeading">Phase:</span></th>
			<td><?php echo $ctDetailsResult['phase'];?></td>
		</tr>						
	
		<tr>
			<th><span class="addrHeading">Key words:</span></th>
			<td>
				<?php foreach($arrKeyWords as $keyWord){				
					echo $keyWord['name']."<br />";
				}?>
			</td>	
		</tr>
	</table>
</div>						

-->