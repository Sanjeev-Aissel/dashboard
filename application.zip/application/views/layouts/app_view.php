<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" manifest="<?php echo base_url()?>example.manifest">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW" />
	<meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'unsafe-eval' <?php echo base_url()?>" />
	<title><?php echo APP_PRODUCT_INFO_HEADER; ?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<?php echo $this->load->view('elements/favicon');?>
	<link type="text/css" href="<?php echo base_url()?>css/login.css"  rel="stylesheet" />
		<script>
			sessionStorage.clear();
		</script>
		
</head>
<style>
html, body{
	margin:auto;
	font-family:"Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
	font-size:12px;
	color:#333;
}
a{
	color:#4A85BE;	
}
.productNameContainer{
	border-bottom: 1px solid;
	color:#4A85BE;
}
h2.productName {
    margin: 0;
    padding: 7px;
    text-align: left;
}
#loginFooter {
    clear: right;
    text-align: right;
    height: 61px;
}
.footerContainer{
	border-top: 1px solid;
}
.pageWrapper{
    background-color: #EEEEEE;
    background-image: linear-gradient(to bottom, #DDDDDD, #FFFFFF);
}
#pageContainer{
	min-height: 500px;
}
</style>
<body>
	<div>
		<table style="width:100%;border-collapse: collapse;">
			<tr>
				<td class="productNameContainer"><h2 class="productName"><?php echo PRODUCT_NAME;?></h2></td>
			</tr>
			<tr class="pageWrapper">
				<td><div id="pageContainer">
						<?php echo $this->load->view($contentPage, $data);?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td class="footerContainer">
					<div id="loginFooter">
						&nbsp;&nbsp;&nbsp;&nbsp;
						<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | <?php echo APP_PRODUCT_INFO_FOOTER;?> Copyright &copy; <?php echo COPYRIGHT;?> <a href="http://www.aissel.com" target="new">Aissel</a> Technologies | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
					</div>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>
