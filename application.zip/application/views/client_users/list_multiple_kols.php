<?php
/*
 * To show drop down of all Kols
 * @author Vinayak
 * @since 1.5.1
 * @created on 12/3/2011
 * 
 * 
 */
?>
<script type="text/javascript" src="<?php echo base_url()?>js/multiple_select_option_selectors.js"></script>



<style type="text/css">
	#avlKols{
	height:180px;
	width:180px;
	}

	#selectedKols{
	height:180px;
	width:180px;
	}
	.form{
		text-align:center;
	}	
	table, td, th {
		border:0;
	}

</style>
<script type="text/javascript">

	/*
	* To save Associted Kols
	* @author Vinayak K Malladad
	* @since 1.5.1
	* @created on 16/3/2011
	*
	*/
	function save(){
			//$('.msgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			formAction="<?php echo base_url()?>/client_users/save_clients_kols";
			$('div.msgBox').removeClass('success');
			$('div.msgBox').addClass('notice');
			$('div.msgBox').show();
			$('div.msgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
			$.ajax({
				type:'post',
				data:$("#clientKolsForm").serialize(),
				url:formAction,
				dataType:'json',
				success: function(returnData){
				//$('.msgBox').text(returnData.msg);
						if(returnData==true){
							$('.msgBox').fadeOut('100000');
						}
				}
			});
	}
		
</script>
	
	
	<div class="msgBox"></div>
	<label>Client Name:<?php echo $arrClientsKols[0]['name']?></label>
	<form action="<?php echo base_url()?>/client_users/save_clients_kols" method="post" onclick="return (selectAll(document.getElementById('selectedKols')));"  id="clientKolsForm">	
		 <input type="hidden" name="client_id" value="<?php echo $client_id;?>"></input>
		<table align="left" width="60%">
				   
				    <tr>
				        <td width="45%" class="label"><div align="Center">Available Kols</div></td>
				        <td width="10%" class="label" align="center"></td>
				        <td width="45%" class="label"><div align="Center">Selected Kols</div></td>
				    </tr>
				    <tr> 
						<td width="45%">
							<div align="Center">
					        	<select id="avlKols" name="avil_kols" size="20" multiple="multiple" ondblclick="javascript:moveItemLeftToRight();">
					        		<?php foreach ($arrKol as $kol)
											echo '<option value="'.$kol["id"].'">'.$kol["first_name"].' '.$kol["middle_name"].' '.$kol["last_name"].'</option>';
									?>
								</select>
							</div>
						</td>
						<td width="10%">
							<div align="center">
								<input type="button" value=" > " class="button" onClick="javascript:moveItemLeftToRight();"><br>
								<input type="button" value=" < " class="button" onClick="javascript:moveItemRightToLeft();"><br>
							</div>
						</td>
						<td width="45%">
							<div align="center">
					        	<select id="selectedKols" name="selected_kols[]" size="20" multiple="multiple" ondblclick="javascript:moveItemRightToLeft();">
					        	
									<?php foreach ($arrClientsKols as $kol)
										echo '<option value="'.$kol["kol_id"].'">'.$kol["first_name"].' '.$kol["middle_name"].' '.$kol["last_name"].'</option>';
									?>
					        	</select>
							</div>
						</td>
					 </tr>
					 <tr>
					 	<td>
					 	</td>
					 	<td>
				 			<div class="form">
					 			<input name="btn_Save" type="button" value="Associate" onclick="save();" >
				 			</div>
					 	</td>
					 </tr>
				</table>
	
			</form>
			
				
				