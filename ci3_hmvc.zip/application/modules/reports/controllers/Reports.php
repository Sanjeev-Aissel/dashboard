<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class reports extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('report');
		$this->load->model('kols/kol');
		$this->load->model('helpers/common_helper');
	}
	function get_event_types_timeline_chart() {
		$viewTypeMyKols 	= $this->input->post("viewTypeMyKols");
		$fromYear 			= $this->input->post('from_year');
		$toYear 			= $this->input->post('to_year');
		$arrKolNames 		= ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
		$arrSelectedKol 	= ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
		$arrGlobalRegions 	= ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
		$arrSpecialities 	= ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
		$arrCountries 		= ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
		$arrStatesIds 		= ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
		$arrListNames 		= ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
		$profileType 		= ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
		if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
			if (!is_array($arrGlobalRegions))
				$arrGlobalRegionIds = explode(",", $arrGlobalRegions);
			else
				$arrGlobalRegionIds = $arrGlobalRegions;
		}
		
		if ($arrSpecialities != 0 && $arrSpecialities != '') {
			if (!is_array($arrSpecialities))
				$arrSpecialityIds = explode(",", $arrSpecialities);
			else
				$arrSpecialityIds = $arrSpecialities;
		}
		if ($arrCountries != 0 && $arrCountries != '') {
			if (!is_array($arrCountries))
				$arrCountriesIds = explode(",", $arrCountries);
				else
					$arrCountriesIds = $arrCountries;
		}
		if ($arrStatesIds != 0 && $arrStatesIds != '') {
			if (!is_array($arrStatesIds))
				$arrStatesIds = explode(",", $arrStatesIds);
			else
				$arrStatesIds = $arrStatesIds;
		}
		if ($arrKolNames != '0' && $arrKolNames != '') {
			if (!is_array($arrKolNames))
				$kolIds = $arrSelectedKol;
			else
				$kolIds = $arrKolNames;
		}else {
			$kolIds = $arrSelectedKol;
		}
		if ($arrListNames != '0' && $arrListNames != '') {
			if (!is_array($arrListNames))
				$arrListNamesIds = explode(",", $arrListNames);
			else
				$arrListNamesIds = $arrListNames;
		}
		$congressData = array();
		$conferenceData = array();
		$grData = array();
		$amData = array();
		$cmeData = array();
		$webcastData = array();
		$webinarData = array();
		$podcastData = array();
		if ($viewTypeMyKols == MY_RECORDS) {
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if (sizeof($viewMyKols) > 0) {
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			} else {
				$viewType = array(0);
				$viewTypeMyKols = MY_RECORDS;
			}
		} else {
			$viewTypeMyKols = ALL_RECORDS;
		}
		$arrEventTypeDetails = $this->kol->getEventTypesCountByTimeLine($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
		$arrUniqueYears = $this->get_unique_years($arrEventTypeDetails);
		$arrEventTypeCount = array();
		$arrEventTypes = array();
		$arrEventTypesData = array();
		$arrUniqueYear = array();
		foreach ($arrEventTypeDetails as $eventTypeDetail) {
			$arrEventTypeCount[$eventTypeDetail['year']][$eventTypeDetail['event_type']] += (int) $eventTypeDetail['count'];
			$arrEventTypes[$eventTypeDetail['event_type']] = 1;
		}
		ksort($arrEventTypeCount);
		foreach ($arrEventTypeCount as $year => $arrRow) {
			$arrUniqueYear[substr($year, 2)] = $year; //"'".substr($year,2);
			$arrYears[substr($year, 2)] = $year;
			foreach ($arrEventTypes as $eventType => $value) {
				if (isset($arrRow[$eventType])) {
					$arrEventTypesData[$eventType][] = $arrRow[$eventType];
				} else {
					$arrEventTypesData[$eventType][] = 0;
				}
			}
		}
		$arrTypesData = array();
		$arrData[] = array_values($arrUniqueYear);
		foreach ($arrEventTypes as $eventType => $value) {
			$arrTypesData[] = array('name' => $eventType, 'data' => $arrEventTypesData[$eventType]);
		}
		$arrData[] = $arrTypesData;
		$arrData[] = $arrYears;
		echo json_encode($arrData);
	}
	function get_unique_years($arrEventTypeDetails) {
		$arrYears = array();
		foreach ($arrEventTypeDetails as $eventTypeDetail) {
			$arrYears[] = $eventTypeDetail['year'];
		}
		$arrUniqueYears = array_unique($arrYears);
		sort($arrUniqueYears);
		return $arrUniqueYears;
	}
	function get_kol_co_auth($id, $fromYear, $toYear){
		$kolName = $this->kol->getKolName($id);
		$arrKolName = $this->kol->getKolName($id);
		
		$firstName	= trim($arrKolName['first_name'],".");
		$middleName	= trim($arrKolName['middle_name'],".");
		$lastName	= trim($arrKolName['last_name'],".");
		
		$fullName	= $firstName;
		if(!empty($middleName))
			$fullName	.= ' '. $middleName;
		if(!empty($lastName))
			$fullName	.= ' '. $lastName;
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		
		$arrAuth=$this->kol->getKolCoAuthFreqency($id, $fromYear, $toYear,$arrKolName,null,$keyWord);
		//		echo $this->db->last_query();
		$nodeData=array();
		$nodeData['$lineWidth']= 5;
		$nodeData['$color']="#ddeeff";
		$nodeData['$dim']= 0;
		$influenceData=array();
		$centerNode = array();
		$influenceData['id']='kol-'.$id;
		$influenceData['name']=$fullName;
		$influenceData['data']=$nodeData;
		$influenceData['children'] = array();
		$x=1;
		foreach($arrAuth as $key => $row){
			$authorName = '';
			//based on the name avilability, construct a proper name
			if($row['last_name']!='' && $row['fore_name']!='')
				$authorName =$row['last_name']." ".$row['fore_name'];
			else if($row['fore_name']=='')
				$authorName =$row['last_name']." ".$row['initials'];
			else if($row['last_name']=='')
				$authorName =$row['fore_name']." ".$row['initials'];
				
			$names = array();
			$count = array();
			$arrIds = array();
			if($authorName != $fullName){
				$name = $authorName;
				$count1 = (int)$row['count'];
				$arrId = $row['id'];
				$nodeData =array();
				$nodeData['$color']="#555555";
				$nodeData['connections']=$count1;
				$nodeDetails=array();
				$nodeDetails['id']= $x."_".$arrId;
				//				$nodeDetails['pmid']=$arrId;
				$nodeDetails['name']=$name."(".$count1.")";
				$nodeDetails['data']=$nodeData;
				$arrAdjecencies=array();
				$nodeDetails['children']=$arrAdjecencies;
				$influenceData['children'][]=$nodeDetails;
			}
			if($authorName != $fullName){
				$names[] = $authorName;
				$count[]=(int)$row['count'];
				$arrIds[]=$row['id'];
			}
			$x++;
		}
		$retunData['connectionData'] = $influenceData;
		//		$retunData['coAuthorsKOLIds'] = array();
		$data[]=$names;
		$data[]=$count;
		$data[]=$arrIds;
		$data['influenceData'] = $retunData;
		echo json_encode($data);
	}
	function pjc_score_chart(){
		$data['journalsCategories'] = $_POST['a'];
		$data['journalsData'] = $_POST['b'];
		$this->load->view('pjc_score_chart',$data);
	}
	function pt_score_chart(){
		$data['journalsCategories'] = $_POST['a'];
		$data['journalsData'] = $_POST['b'];
		$this->load->view('pt_score_chart',$data);
	}
}
?>