<?php
/**
 * Extending the date Helpers
 *
 *
 * @package		application.helpers
 * @author		Vinayak
 * @since		Version 3.1
 */

// ------------------------------------------------------------------------


/**
 * 
 *
 * Convert the Date to empty if it is 'zero'
 *
 * @access	public
 * @param	array
 * @return	$date
 * @since		Version 3.1
 */
if ( ! function_exists('date_display'))
{
	function date_display($date)
	{
		
		if($date == 0){
			
			$date=' ';
		}
		return $date;
	}
}

/**
 * 
 *
 * Convert the mysql date to date specified in the constants 'APP_DATE_FORMAT'
 *
 * @access	public
 * @param	array
 * @return	$date
 * @since		Version 3.1
 */
if ( ! function_exists('sql_date_to_app_date'))
{
	function sql_date_to_app_date($sqlDate)
	{
		$sqlDateEl = explode(" ",$sqlDate);
		$sqlDate = $sqlDateEl[0];
		$date = $sqlDate;
		if($sqlDate != ""){
			$arrDateDate = explode("-",$sqlDate);
			if(APP_DATE_FORMAT == "MM/DD/YYYYY"){
				return $arrDateDate[1]."/".$arrDateDate[2]."/".$arrDateDate[0];
			}
		}
		return $date;
	}
}

/**
 * 
 *
 * Convert the mysql date to date specified in the constants 'APP_DATE_FORMAT'
 *
 * @access	public
 * @param	array
 * @return	$date
 * @since		Version 3.1
 */
if ( ! function_exists('app_date_to_sql_date'))
{
	function app_date_to_sql_date($appDate)
	{
		$date = $appDate;
		if($appDate != ""){
			if(APP_DATE_FORMAT == "MM/DD/YYYYY"){
				$arrDateDate = explode("/",$appDate);
				return $arrDateDate[2]."-".$arrDateDate[0]."-".$arrDateDate[1];
			}
		}
		return $date;
	}
}

if ( ! function_exists('dateParseFromFormat'))
{
	function dateParseFromFormat($stFormat, $stData)
	{
	    $aDataRet = array();
	    $aPieces = split('[:/.\ \-]', $stFormat);
	    $aDatePart = split('[:/.\ \-]', $stData);
	    foreach($aPieces as $key=>$chPiece)   
	    {
	        switch ($chPiece)
	        {
	            case 'd':
	            case 'j':
	                $aDataRet['day'] = $aDatePart[$key];
	                break;
	               
	            case 'F':
	            case 'M':
	            case 'm':
	            case 'n':
	                $aDataRet['month'] = $aDatePart[$key];
	                break;
	               
	            case 'o':
	            case 'Y':
	            case 'y':
	                $aDataRet['year'] = $aDatePart[$key];
	                break;
	           
	            case 'g':
	            case 'G':
	            case 'h':
	            case 'H':
	                $aDataRet['hour'] = $aDatePart[$key];
	                break;   
	               
	            case 'i':
	                $aDataRet['minute'] = $aDatePart[$key];
	                break;
	               
	            case 's':
	                $aDataRet['second'] = $aDatePart[$key];
	                break;           
	        }
	       
	    }
	    return $aDataRet;
	}
}

if ( ! function_exists('changeDateFormat'))
{
	function changeDateFormat($stDate,$stFormatFrom,$stFormatTo)
	{
	  // When PHP 5.3.0 becomes available to me
	  //$date = date_parse_from_format($stFormatFrom,$stDate);
	  //For now I use the function above
	  $date = dateParseFromFormat($stFormatFrom,$stDate);
	  return date($stFormatTo,mktime($date['hour'],
	                                    $date['minute'],
	                                    $date['second'],
	                                    $date['month'],
	                                    $date['day'],
	                                    $date['year']));
	}
}

if ( ! function_exists('humanTiming'))
{
	function humanTiming ($timestamp)
	{
		$difference = time() - $timestamp;
		$periods = array("sec", "min", "hour", "day", "week",
		"month", "year", "decade");
		$lengths = array("60","60","24","7","4.35","12","10");
		
		if ($difference > 0) { // this was in the past
		$ending = "ago";
		} else { // this was in the future
		$difference = -$difference;
		$ending = "ago";
		}
		for($j = 0; $difference >= $lengths[$j]; $j++)
		$difference /= $lengths[$j];
		$difference = round($difference);
		if($difference != 1) $periods[$j].= "s";
		$text = "$difference $periods[$j] $ending";
		return $text;
	}
}

/**
 * Convert number of seconds into hours, minutes and seconds
 * and return an array containing those values
 *
 * @param integer $seconds Number of seconds to parse
 * @return array
 */
if ( ! function_exists('secondsToTime'))
{
function secondsToTime($seconds)
{
    $h = (int)($seconds / 3600);
	$m = (int)(($seconds - $h*3600) / 60);
	$s = (int)($seconds - $h*3600 - $m*60);
	if($h == '0' || $h == '00')
		return (($m)?(($m<10)?("0".$m):$m):"00").":".(($s)?(($s<10)?("0".$s):$s):"00");
	else
		return (($h)?(($h<10)?("0".$h):$h):"00").":".(($m)?(($m<10)?("0".$m):$m):"00").":".(($s)?(($s<10)?("0".$s):$s):"00");
}
}

/**
 * Convert given date to match all time zones
 * @param date value
 * @return converted date
 */

if ( ! function_exists('convert_date'))
{
	function convert_date($date)
	{
		if($date != ''){
			$currentTimeZone = date_default_timezone_get();
			date_default_timezone_set('UTC');
			$date = date("Y-m-d H:i:s",strtotime($date));
			date_default_timezone_set($currentTimeZone);
			return $date;
		}
	}
}