<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code{
    	width: 192px;
    }
    #org_type{
    	width: 207px;
    }
</style>
<script type="text/javascript">
    var validationRules = {
    	
    	email_type: {
            required: true
        },
        email: {
            required: true,
            officialemail: true
        }
    };
    var validationMessages = {
    	email_type: {
            required: "Required"
        },
        email: {
            required: "Required"
        }
    };
    $(function () {
    	jQuery.validator.addMethod("officialemail", function (value, element) {
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(value);
        }, "Invalid email");
        
    	$("#emailForm").validate({
            debug: true,
            onkeyup: true,
            rules: validationRules,
            messages: validationMessages
        });
    });
    $('#saveKolEmails').click(function () {
        if (!$("#saveKolEmailForm").validate().form()) {
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $id = '<?php if($displayContent) echo $getSavedDetails['id'];?>';
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_email/'+$id,
            type: 'post',
            dataType: 'json',
            data: $('#saveKolEmailForm').serialize(),
            beforeSend: function(){
    			$("#saveKolEmails").attr("disabled", "disabled");
            },
            success: function (returnData) {
                if (returnData.status == true) {
                    $('.msgBox').html('<?php echo lang("KOL"); ?> Email saved successfully');
                    $('.msgBox').fadeOut(1500);
                    
                    if(returnData.details!=''){
                    	$('.primaryEmail').attr('value',returnData.details);
                    }
                    ReloadGrid();
                } else {
                    $('.msgBox').html('Error saving <?php echo lang("KOL"); ?> location');
                    $('.msgBox').fadeOut(1500);
                }
            }
        });
    });
    function ReloadGrid() {
    	$('#saveKolEmails').removeAttr("disabled");
        $("#addEmailForKols").dialog("close");
        getEmailsData();
    }

</script>
<div class="msgBox"></div>

<div id="similarNames">

</div>
<?php 
$arrType = array();
$arrType['Work']= 'Work'; 
$arrType['Other']= 'Other';
?>
<h4 style="border-bottom: 1px solid #bbbbbb;">Email</h4>

<form action="save_kol_email" method="post" id="saveKolEmailForm" name="saveKolEmailForm">
    <table class="requestedKols">
        <tbody>
            <tr>
                <td style="width: 50%;">
                    <table style="te">
						<tr>
							<td class="alignRight"><label for="email_type">Type<span class="required">*</span> :</label></td>
							<td>
								<select name="email_type" class="required" id='email_type'>
						            <option value="">--Select--</option>
						            <!--<option value="Home">Home</option>-->
						            <?php foreach ($arrType as $key=>$type){?>
						            <option value="<?php echo $key?>" <?php if(isset($getSavedDetails['type']) && $getSavedDetails['type']==$key) echo "selected='selected'";?>><?php echo $type;?></option>
						            <?php }?>
						        </select>
							</td>
						</tr>
                        <tr>
                            <td class="alignRight"><label for="email_is_primary">Is Primary :</label></td>
                            <td>
						        <input type="checkbox" name="email_is_primary" id='email_is_primary' <?php if($displayContent && $getSavedDetails['is_primary']=='1') echo "checked class='ui-disabled'";?>/>
						        <input type="hidden" name="contact" value="<?php echo $kolId; ?>"/>
						        <input type="hidden" name="contact_type" value="kol"/>
                            </td>
                        </tr>
                    </table>
                </td>

                <td>
                    <table>
                        <tr>
                            <td class="alignRight">
                                <label for="email">Email<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <input type="text" name='email' class="required officialemail" id='email' value="<?php if(isset($getSavedDetails['email'])) echo $getSavedDetails['email'];?>"/>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- End of Personal and Professional Information -->
        </tbody>
    </table>
<table>
	<tbody>
	    <tr>
	        <td colspan="2">
	            <div class="formButtons">	
	            <?php if($displayContent){?>
	                    <input type="button" value="Update" name="submit" id="saveKolEmails"></input>
	            <?php } else {?>
	            		<input type="button" value="Save" name="submit" id="saveKolEmails"></input>
	           	<?php } ?>
	            </div>
	        </td>
	    </tr>
	</tbody>
</table>

</form>