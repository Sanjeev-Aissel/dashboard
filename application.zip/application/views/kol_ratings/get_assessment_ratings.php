
<table>
<?php
	foreach($arrAsmtRatings as $categoryName=>$arrCriteria){
		$displayCatName	= 1;
		foreach($arrCriteria as $criteriaName=>$arrRatings){
?>
				<tr>
					<td><?php if($displayCatName){
									echo $categoryName;
									$displayCatName	= 0;
								}
						?></td>
					<td>
						<?php echo $criteriaName;?>
					</td>
					<td>
						<select name="<?php echo $arrRatings[0]['category_id'].'_'.$arrRatings[0]['criteria_id'];?>">
							<option value="">Select Rating</option>
						
						<?php 
							foreach($arrRatings as $key=>$row){
								echo '<option value="'.$row['rating_id'].'">'.$row['rating'].'</option>';
							}
						?>
						</select>
					</td>
				</tr>
<?php 		
			}
	}
?>
</table>