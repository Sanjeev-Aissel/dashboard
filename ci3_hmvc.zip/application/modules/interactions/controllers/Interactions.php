<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class interactions extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('interaction');
		$this->load->model('helpers/common_helper');
		$this->load->model('helpers/country_helper');
		$this->load->model('kols/kol');
	}
	function list_interactions_by_date_range($startDate = null, $endDate = null, $kolId = null) {
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		
		$page = $_REQUEST['page']; // get the requested page
		$limit = $_REQUEST['rows']; // get how many rows we want
		$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST['sord']; // get the direction
		if (!$sidx)
			$sidx = 1;
		if ($_REQUEST['filters']) {
			$filterData = $_REQUEST['filters'];
			$arrFilter = array();
			$arrFilter = json_decode(stripslashes($filterData));
			$field = 'field';
			$op = 'op';
			$data = 'data';
			$groupOp = 'groupOp';
			$searchGroupOperator = $this->common_helper->search_nested_arrays($arrFilter, $groupOp);
			$searchString = $this->common_helper->search_nested_arrays($arrFilter, $data);
			$searchOper = $this->common_helper->search_nested_arrays($arrFilter, $op);
			$searchField = $this->common_helper->search_nested_arrays($arrFilter, $field);
			$whereResultArray = array();
			foreach ($searchField as $key => $val) {
				$whereResultArray[$val] = $searchString[$key];
			}
			$searchGroupOperator = $searchGroupOperator[0];
			$searchResults = array();
		}
		//pr($arrFilter);
		$arrInteractions = array();
		$data = array();
		$arrFilters['end_date'] = $this->input->post('ed');
		$arrFilters['start_date'] = $this->input->post('sd');
		if($arrFilters['end_date'] != '')
			$arrFilters['end_date'] = date("Y-m-d",strtotime($arrFilters['end_date']));
		if($arrFilters['start_date'] != '')
			$arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if($arrUserId != 'null' && !empty($arrUserId)){
			if(!is_array($arrUserId)){
				$arrUserId = explode(",", $arrUserId);
			}
		}
		$arrFilters['objective_id'] = $arrType;
		$arrFilters['product_id'] = $arrProduct;
		$arrFilters['topic_id'] = $arrTopic;
		$arrFilters['mode'] = $arrMode;
		$arrFilters['grouping'] = $arrGrouping;
		$arrFilters['user_id'] = $arrUserId;
		$arrFilters['org_id'] = $this->input->post('org_id');
		$arrFilters['manager_id'] = $this->input->post('manager_id');
		$arrFilters['plan_id'] = $this->input->post('plan_id');
		if ($kolId == null){
			$kolId	=	$this->input->post('kol_id');
			if(!(is_numeric($kolId))){//its kol_unique id, get kol_id
				$kolId 	= 	$this->common_helper->getFieldValueByEntityDetails('kols','unique_id',$kolId,'id');
			}
		}
		$clientId = $this->session->userdata('client_id');
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId = 0;
		
		if ($this->session->userdata('role_type') == ROLE_USER)
			$userId = $this->session->userdata('user_id');
		
		$arrFilters['interactionFor'] = $this->input->post('interaction_for');
		if($arrFilters['interactionFor'] == 'org'){
			$kolId = $this->input->post('kol_id');
			$arrFilters['org_id'] = $kolId;
		}
		$arrInteractions = array();
		
		$count = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit = 'all', $start, true, $sidx, $sord, $whereResultArray);
		
		$limit = $_REQUEST['rows']; // get how many rows we want
		
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		if ($start < 0)
			$start = 0;
		
		$arrInteractionsResults = array();
		$data = array();
		$arrInteractions = array();
		if ($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit, $start, false, $sidx, $sord, $whereResultArray)) {
			foreach ($arrInteractionsResults as $arrInteractionResult) {
				$arrTypes = array();
				$arrProduct = array();
				$arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
				if ($arrInteraction['date'] == "00/00/0000")
					$arrInteraction['date'] = '';
				$arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
				$arrInteraction['id'] = $arrInteractionResult['id'];
				$arrInteraction['int_id'] = $arrInteractionResult['id'];
				$arrInteraction['generic_id'] = $arrInteractionResult['generic_id'];
				$arrInteraction['is_org_interaction'] = $arrInteractionResult['orgInteractionAction'];
				$arrInteraction['objective_name'] = $arrInteractionResult['type'];
				$arrInteraction['product_name'] = $arrInteractionResult['product'];
				$arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
				if ($arrInteraction['follow_up_on'] == "00/00/0000")
					$arrInteraction['follow_up_on'] = '';
				//	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
				$arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
				$arrInteraction['kol_unique_id'] = $arrInteractionResult['unique_id'];
				//$arrUserDetails						= $this->client_user->editUser($arrInteractionResult['created_by']);
				$arrInteraction['recorded_by'] = $arrInteractionResult['first_name'] . " " . $arrInteractionResult['last_name'];
				$arrInteraction['recorded_by_name'] = $arrInteractionResult['first_name'] . " " . $arrInteractionResult['last_name'];
				//                                $arrInteraction['mirf_add'] = $this->common_helper->isActionAllowed('mirf','add',$arrInteraction);
				$arrInteraction['msl_id'] = $arrInteractionResult['employee_id'];
				$isMirfAllowed = $this->common_helper->isActionAllowed('mirf', 'add', $arrInteractionResult);
				if ($isMirfAllowed) {
					if ($arrInteractionResult['mirf_id'] != null && $arrInteractionResult['mirf_id'] != '')
					{
						$arrInteraction['mirf'] = "";
					}
					else
						$arrInteraction['mirf'] = "Add";
				}else {
					$arrInteraction['mirf'] = "";
				}
				$arrInteraction['mirfAllowed'] = $isMirfAllowed;
				$arrInteraction['mirf_id'] = $arrInteractionResult['mirf_id'];
				$arrInteraction['save_later'] = $arrInteractionResult['save_later'];
				if(isset($arrFilters['org_id']) && $arrFilters['org_id']!=''){
					$arrInteraction['eAllowed'] = $this->common_helper->isActionAllowed('org_interaction', 'edit', $arrInteractionResult);
				}else{
					$arrInteraction['eAllowed'] = $this->common_helper->isActionAllowed('interaction', 'edit', $arrInteractionResult);
				}
				if ($arrInteractionResult['quality_interaction'] == 1)
					$arrInteraction['quality_interaction'] = 'Yes';
				else
					$arrInteraction['quality_interaction'] = 'No';
					
				$arrInteraction['dAllowed'] = $this->common_helper->isActionAllowed('interaction', 'delete', $arrInteractionResult);
				//				$arrInteraction['save_later']	= $arrInteraction['eAllowed'];
				$arrInteraction['emp_name'] = $arrInteractionResult['emp_first_name'] . " " . $arrInteractionResult['emp_last_name'];
				$arrInteraction['client_id'] = $arrInteractionResult['client_id'];
				$arrInteraction['data_type_indicator'] = $arrInteractionResult['data_type_indicator'];
				$arrInteractions[] = $arrInteraction;
			}
			if ($count > 0) {
				$total_pages = ceil($count / $limit);
			} else {
				$total_pages = 0;
			}
			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrInteractions;
		}else{
			$data['records'] = 0;
		}
		echo json_encode($data);
	}
	function interactions_by_topic() {
		$arrData['start_date'] = $this->input->post('sd');
		$arrData['end_date'] = $this->input->post('ed');
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if(!is_array($arrUserId)){
			$arrUserId	= str_replace('null',null,$arrUserId);
			$arrUserId = explode(",", $arrUserId);
			unset($arrUserId[array_search('null', $arrUserId)]);
		}
		$arrData['grouping'] = $arrGrouping;
		$arrData['mode'] = $arrMode;
		$arrData['objective_id'] = $arrType;
		$arrData['product_id'] = $arrProduct;
		$arrData['topic_id'] = $arrTopic;
		$arrData['user_id'] = $arrUserId;
		$kol_id = $this->input->post('kol_id');
		$arrData['interaction_for'] = $this->input->post('interaction_for');
		$arrData['kol_id'] = $kol_id;
		if($arrData['interaction_for']!='org'){
			if(!is_numeric($kol_id)){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kol_id,'unique_id');
			}
		}
		$arrData['client_id'] = $this->session->userdata('client_id');
		$arrData['org_id'] = $this->input->post('org_id');
		if($arrData['kol_id'] == ''){
			if ($this->session->userdata('role_type') == ROLE_USER){
				$arrData['user_id'][] = $this->session->userdata('user_id');
			}
		}
		$arrTopic = $this->interaction->interacionByTopic($arrData);
// 		pr($arrTopic);exit;
		foreach ($arrTopic as $key => $row) {
			$arrTopicData = array();
			$arrTopicData[] = $row['name'];
			$arrTopicData[] = (int) $row['count'];
			$interacionByTopic[] = $arrTopicData;
		}
		if (sizeof($interacionByTopic) > 0) {
			$data['status'] = true;
			$data['arrByTopic'] = $interacionByTopic;
		} else {
			$arrTopicData = array();
			$arrTopicData[] = 'No Data';
			$arrTopicData[] = 0;
			$interacionByTopic[] = $arrTopicData;
			$data['arrByTopic'] = $interacionByTopic;
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	function interactions_by_channel() {
		$arrData['start_date'] = $this->input->post('sd');
		$arrData['end_date'] = $this->input->post('ed');
		
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if(!is_array($arrUserId)){
			$arrUserId	= str_replace('null',null,$arrUserId);
			$arrUserId = explode(",", $arrUserId);
		}
		$arrData['grouping'] = $arrGrouping;
		$arrData['mode'] = $arrMode;
		$arrData['objective_id'] = $arrType;
		$arrData['product_id'] = $arrProduct;
		$arrData['topic_id'] = $arrTopic;
		$arrData['user_id'] = $arrUserId;
		$kol_id = $this->input->post('kol_id');
		$arrData['interaction_for'] = $this->input->post('interaction_for');
		$arrData['kol_id'] = $kol_id;
		if($arrData['interaction_for']!='org'){
			if(!is_numeric($kol_id)){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kol_id,'unique_id');
			}
		}
		$arrData['client_id'] = $this->session->userdata('client_id');
		$arrData['org_id'] = $this->input->post('org_id');
		if($arrData['kol_id'] == ''){
			if ($this->session->userdata('user_role_id') == ROLE_USER){
				$arrData['user_id'][] = $this->session->userdata('user_id');
			}
		}
		$arrChannel = $this->interaction->interacionByChannel($arrData);
		foreach ($arrChannel as $key => $row) {
			$arrChannelData = array();
			$arrChannelData[] = $row['name'];
			$arrChannelData[] = (int) $row['count'];
			$interacionByChannel[] = $arrChannelData;
		}
		if (sizeof($interacionByChannel) > 0) {
			$data['status'] = true;
			$data['arrByChannel'] = $interacionByChannel;
		} else {
			$arrChannelData = array();
			$arrChannelData[] = 'No Data';
			$arrChannelData[] = 0;
			$interacionByChannel[] = $arrChannelData;
			$data['arrByChannel'] = $interacionByChannel;
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function interactions_by_employee() {
		$arrData['start_date'] = $this->input->post('sd');
		$arrData['end_date'] = $this->input->post('ed');
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if(!is_array($arrUserId)){
			$arrUserId	= str_replace('null',null,$arrUserId);
			$arrUserId = explode(",", $arrUserId);
		}
		$arrData['grouping'] = $arrGrouping;
		$arrData['mode'] = $arrMode;
		$arrData['objective_id'] = $arrType;
		$arrData['product_id'] = $arrProduct;
		$arrData['topic_id'] = $arrTopic;
		$arrData['user_id'] = $arrUserId;
		$kol_id = $this->input->post('kol_id');
		$arrData['interaction_for'] = $this->input->post('interaction_for');
		$arrData['kol_id'] = $kol_id;
		if($arrData['interaction_for']!='org'){
			if(!is_numeric($kol_id)){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kol_id,'unique_id');
			}
		}
		$arrData['client_id'] = $this->session->userdata('client_id');
		$arrData['org_id'] = $this->input->post('org_id');
		if($arrData['kol_id'] == ''){
			if ($this->session->userdata('user_role_id') == ROLE_USER){
				$arrData['user_id'][] = $this->session->userdata('user_id');
			}
		}
		$arrEmp = $this->interaction->interacionByEmployee($arrData);
		foreach ($arrEmp as $key => $row) {
			$arrEmployeeData = array();
			$arrEmployeeData[] = $row['username'];
			$arrEmployeeData[] = (int) $row['count'];
			$interacionByEmployee[] = $arrEmployeeData;
		}
		if (sizeof($interacionByEmployee) > 0) {
			$data['status'] = true;
			$data['arrByEmployee'] = $interacionByEmployee;
		} else {
			$arrEmployeeData = array();
			$arrEmployeeData[] = 'No Data';
			$arrEmployeeData[] = 0;
			$interacionByEmployee[] = $arrEmployeeData;
			$data['arrByEmployee'] = $interacionByEmployee;
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function interactions_by_month() {
		$arrData['start_date'] = $this->input->post('sd');
		$arrData['end_date'] = $this->input->post('ed');
		
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if(!is_array($arrUserId)){
			$arrUserId	= str_replace('null',null,$arrUserId);
			$arrUserId = explode(",", $arrUserId);
		}
		$arrData['grouping'] = $arrGrouping;
		$arrData['mode'] = $arrMode;
		$arrData['objective_id'] = $arrType;
		$arrData['product_id'] = $arrProduct;
		$arrData['topic_id'] = $arrTopic;
		$arrData['user_id'] = $arrUserId;
		$kol_id = $this->input->post('kol_id');
		$arrData['interaction_for'] = $this->input->post('interaction_for');
		$arrData['kol_id'] = $kol_id;
		if($arrData['interaction_for']!='org'){
			if(!is_numeric($kol_id)){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kol_id,'unique_id');
			}
		}
		$arrData['client_id'] = $this->session->userdata('client_id');
		$arrData['org_id'] = $this->input->post('org_id');
		if($arrData['kol_id'] == ''){
			if ($this->session->userdata('user_role_id') == ROLE_USER){
				$arrData['user_id'][] = $this->session->userdata('user_id');
			}
		}
		$arrResult = $this->interaction->interactionByMonth($arrData);
		$arrData['get_count'] = true;
		$interacionByMonths = array();
		$arrMonths = array(1 => 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
		foreach ($arr['interacionByMonth'] as $key => $row) {
			$arrIntByMonthData[$row['month']][$row['name']] = (int) $row['count'];
		}
		foreach ($arrIntByMonthData as $month => $arrRow) {
			$interacionByMonths[] = $arrMonths[$month];
			$arrMonthProductsData['name'] = array_keys($arrRow);
			
			foreach ($arrRow as $product => $count) {
				$arrMonthData['name'] = $product;
				$arrMonthData['data'] = $count;
				$interacionByMonth[] = $arrMonthData;
			}
		}
		$arr1 = $arrResult[0];
		$arrYear = $arrResult[1];
		$arrResult[1] = $arrYear;
		
		$arrUniuue = array_unique($arrYear);
		foreach ($arrUniuue as $value1) {
			foreach ($arr1 as $ky => $value) {
				
				if ($value1 == $value['month_year']) {
					$arr3[$value['name']]['data'][$value1][] = (int) $value['count'];
				}
			}
		}
		foreach ($arr3 as $key => $value) {
			foreach ($value['data'] as $ky1 => $val1) {
				$arr3[$key]['data'][$ky1] = $val1[0];
			}
		}
		foreach ($arr3 as $key => $val) {
			foreach ($arrUniuue as $row) {
				if (array_key_exists($row, $val['data'])) {
				} else {
					$arr3[$key]['data'][$row] = 0;
				}
			}
			ksort($arr3[$key]['data']);
		}
		foreach ($arr3 as $key => $value) {
			foreach ($value['data'] as $row) {
				$arr8[$key]['data'][] = $row;
			}
		}
		foreach ($arr8 as $key3 => $value3) {
			$arr = array();
			$arr['name'] = $key3;
			$arr['data'] = $value3['data'];
			$arr9[] = $arr;
		}
		foreach ($arrUniuue as $key => $month) {
			//$arrMonthYear		= explode('_',$month);
			$year = substr($month, -4, 4);
			$month1 = str_replace($year, '', $month);
			//	echo $month1;
			$arrMonthNames[] = $arrMonths[$month1] . " '" . $year;
		}
		$data = array();
		if (sizeof($arrMonthNames) > 0) {
			$data['status'] = true;
			$data['arrByMonth'] = $arr9;
			$data['arrMonths'] = $arrMonthNames;
		} else {
			$arr = array();
			$arr['name'] = array("No Data");
			$arr['data'] = array(0);
			$arr9[] = $arr;
			$arrMonthNames = array("Month Year");
			$data['status'] = false;
			$data['arrByMonth'] = $arr9;
			$data['arrMonths'] = $arrMonthNames;
		}
		echo json_encode($data);
	}
	function interactions_numeric_report() {
		$arrFilters 		= array();
		$arrMode 			= $this->input->post('mode');
		$arrGrouping 		= $this->input->post('grouping');
		$arrType 			= $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct 		= $this->input->post('product');
		$arrTopic 			= $this->input->post('topic');
		$arrSubtopic 		= $this->input->post('subtopic');
		$arrUserId 			= $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if(!is_array($arrUserId)){
			$arrUserId	= str_replace('null',null,$arrUserId);
			$arrUserId = explode(",", $arrUserId);
			//unset($arrUserId[array_search('null', $arrUserId)]);
		}
		$kol_id 						= $this->input->post('kol_id');
		$arrFilters['sd'] 				= $this->input->post('sd');
		$arrFilters['ed'] 				= $this->input->post('ed');
		$arrFilters['interaction_for'] 	= $this->input->post('interaction_for');
		$arrData['kol_id'] 				= $kol_id;
		if($arrData['interaction_for']!='org'){
			if(!is_numeric($kol_id)){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kol_id,'unique_id');
			}
		}
		$arrFilters['mode'] 			= $arrMode;
		$arrFilters['grouping'] 		= $arrGrouping;
		$arrFilters['type'] 			= $arrType;
		$arrFilters['product'] 			= $arrProduct;
		$arrFilters['topic'] 			= $arrTopic;
		$arrFilters['subtopic'] 		= $arrSubtopic;
		$arrFilters['user_id'] 			= $arrUserId;
		$arrFilters['org_id'] 			= $this->input->post('org_id');
		$userId = 0;
		if($arrFilters['kol_id'] == ''){
			if ($this->session->userdata('role_type') == ROLE_USER)
				$arrFilters['user_id'][] = $this->session->userdata('user_id');
		}
		$arrTypeResults 				= $this->interaction->getModeNumericReportData($arrFilters,'type');
		$arrModeResults 				= $this->interaction->getModeNumericReportData($arrFilters,'mode');
// 		echo $this->db->last_query();exit;
		$arrGroupingResults 			= $this->interaction->getModeNumericReportData($arrFilters,'grouping');
		$arrProductResults 				= $this->interaction->getModeNumericReportData($arrFilters,'product');
		$arrTopicResults 				= $this->interaction->getModeNumericReportData($arrFilters,'topic');
		if($arrFilters['interaction_for'] == 'org'){
			$arrFilters['mode'] 		= $this->input->post('mode');
			$arrFilters['grouping'] 	= $this->input->post('grouping');
			$arrFilters['type'] 		= $this->input->post('type');
			$arrFilters['product'] 		= $this->input->post('product');
			$arrFilters['topic'] 		= $this->input->post('topic');
			$arrFilters['subtopic'] 	= $this->input->post('subtopic');
			$arrFilters['user_id'] 		= $this->input->post('user_id');
		}else{
			$arrFilters['mode'] 		= implode(":",$this->input->post('mode'));
			$arrFilters['grouping'] 	= implode(":",$this->input->post('grouping'));
			$arrFilters['type'] 		= implode(":",$this->input->post('type'));
			$arrFilters['product'] 		= implode("",$this->input->post('product'));
			$arrFilters['topic'] 		= implode(":",$this->input->post('topic'));
			$arrFilters['subtopic'] 	= implode(":",$this->input->post('subtopic'));
			$arrFilters['user_id'] 		= implode(":",$this->input->post('user_id'));
		}
		$arrFilters['interaction_for'] = $this->input->post('interaction_for');
		$urlFilterSuffix = '';
		foreach ($arrFilters as $key => $value) {
			if ($value != '') {
				$urlFilterSuffix .= $key . "=" . $value . "_";
			}
		}
		$data['arrModeResults'] 		= $arrModeResults;
		$data['arrGroupingResults'] 	= $arrGroupingResults;
		$data['arrTypeResults'] 		= $arrTypeResults;
		$data['arrProductResults'] 		= $arrProductResults;
		$data['arrTopicResults'] 		= $arrTopicResults;
		$data['urlFilterSuffix'] 		= substr($urlFilterSuffix, 0, -1);
		$data['interaction_for'] 		= $this->input->post('interaction_for');
		$this->load->view('numeric_report', $data);
	}
	function export_numeric_report($type, $filters = '') {
		$sheets=array();
		$arrFilters = array();
		$arrFilters['sd'] = '';
		$arrFilters['ed'] = '';
		$arrFilters['mode'] = '';
		$arrFilters['grouping'] = '';
		$arrFilters['type'] = '';
		$arrFilters['product'] = '';
		$arrFilters['topic'] = '';
		$arrFilters['kol_id'] = '';
		$arrFilters['user_id'] = $arrUserId;
		$arrFilters['org_id'] = '';
		$userId = 0;
		$arrFilters['interaction_for'] = $this->input->post('interaction_for');
		if ($filters != '') {
			$filtersSplit = explode('_', $filters);
			foreach ($filtersSplit as $filter) {
				$filterSplit = explode('=', $filter);
				$arrFilters[$filterSplit[0]] = explode(':',$filterSplit[1]);
			}
		}
		if($arrFilters['kol_id'][0] == ''){
			if ($this->session->userdata('role_type') == ROLE_USER)
				$arrFilters['user_id'][] = $this->session->userdata('user_id');
		}
		$arrResults = array();
		$nameExtension='';
		$sheet=array();
		$sheet['title']					='Interaction Details';
		if ($type == 'mode') {
			$arrResults = $this->interaction->getModeNumericReportData($arrFilters,'mode');
			krsort($arrResults);
			$arrResults[sizeof($arrResults) - 1]['name'] = "Interaction Type(All)";
			$nameExtension = "Interaction Type";
		}
		if ($type == 'grouping') {
			$arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'grouping');
			krsort($arrResults);
			$arrResults[sizeof($arrResults) - 1]['name'] = "Interaction(All)";
			$nameExtension = "Category";
		}
		if ($type == 'type') {
			$arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'type');
			krsort($arrResults);
			$arrResults[sizeof($arrResults) - 1]['name'] = "Discussion Type(All)";
			$nameExtension = "Discussion Type";
		}
		if ($type == 'product') {
			$arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'product');
			krsort($arrResults);
			$arrResults[sizeof($arrResults) - 1]['name'] = "Indication Type(All)";
			$nameExtension = "Indication";
		}
		if ($type == 'topic') {
			$arrResults = $this->interaction->getModeNumericReportData($arrFilters, 'topic');
			krsort($arrResults);
			$arrResults[sizeof($arrResults) - 1]['name'] = "Topic(All)";
			$nameExtension = "Topic";
		}
		$sheet['content']				=$arrResults;
		$sheets[]=$sheet;
		$arrData = array();
		if ($filters != '') {
			$clientId = $this->session->userdata('client_id');
			$arrGroupings = $this->interaction->getAllGroupings($clientId);
			$arrModes = $this->interaction->getAllModesOfClient($clientId);
			$arrType = $this->interaction->getAllTypesOfClient();
			
			$filtersSplit = explode(',', $filters);
			foreach ($filtersSplit as $filter) {
				$filterSplit = explode('=', $filter);
				$filterName = $filterSplit[0];
				$filterValue = $filterSplit[1];
				if ($filterName == 'sd') {
					$filterName = 'Start Date';
					$filterValue = sql_date_to_app_date($filterValue);
				}
				if ($filterName == 'ed') {
					$filterName = 'End Date';
					$filterValue = sql_date_to_app_date($filterValue);
				}
				if ($filterName == 'mode') {
					$filterName = 'Interaction Channel';
					$filterValue = $arrModes[$filterValue]['name'];
				}
				if ($filterName == 'grouping') {
					$filterName = 'Interaction Category';
					$filterValue = $arrGroupings[$filterValue]['name'];
				}
				if ($filterName == 'type') {
					$filterName = 'Type';
					$filterValue = $arrType[$filterValue]['name'];
				}
				if ($filterName == 'product') {
					$filterName = 'Product';
					$filterValue = $this->interaction->getProductById($filterValue);
				}
				if ($filterName == 'topic') {
					$filterName = 'Topic';
					$filterValue = $this->interaction->getTopicById($filterValue);
				}
				if ($filterName == 'kol_id') {
					$arrSalutations = array(0 => '', 1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
					$filterName = lang("KOL").' Name';
					$kolDetails = $this->kol->getKolName($filterValue);
					$fullName = $arrSalutations[$kolDetails['salutation']] . " " . $kolDetails['first_name'] . ' ' . $kolDetails['middle_name'] . ' ' . $kolDetails['last_name'];
					$filterValue = $fullName;
				}
				if ($filterName == 'user_id') {
					$filterName = 'Employee Name';
					$filterValue = $this->client_user->getUserNameById($filterValue);
				}
				$row[0] = $filterName . " : " . $filterValue;
				$row[1] = '';
				$row[2] = '';
				$row[3] = '';
				$row[4] = '';
				$row[5] = '';
				$row[6] = '';
				$arrData[] = $row;
			}
		}
		$arrData = array();
		$headerColumn = sizeof($arrData);
		$arrData[] = array('','Given Period','Q1','Q2','Q3','Q4','YTD');
		foreach ($arrResults as $row) {
			$rowData = array();
			$rowData[0] = $row['name'];
			$rowData[1] = $row['gp'];
			$rowData[2] = $row['q1'];
			$rowData[3] = $row['q2'];
			$rowData[4] = $row['q3'];
			$rowData[5] = $row['q4'];
			$rowData[6] = $row['ytd'];
			$arrData[] = $rowData;
		}
		$arr = array(
				'Interaction Details' => $arrData
		);
		$sheets[0]['content']=$arrData;
		$fileName = "Interaction Reports - " . $nameExtension. '.xls';
		$arr_export_details['file_name']	=$fileName;
		$arr_export_details['sheets']		=$sheets;
// 		pr($arr_export_details);exit;
		export_as_xls($arr_export_details);
	}
	function export_interaction_details($kolId = null) {
		$sheets=array();
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time", 0);
		$clientId = $this->session->userdata('client_id');
		$userId = 0;
		if ($this->session->userdata('user_role_id') == ROLE_USER)
			$userId = $this->session->userdata('user_id');
		$arrFilters = $this->input->post('filters');
		$arrFilters = stripslashes($arrFilters);
		$arrFilters = str_replace('"{', '{', $arrFilters);
		$arrFilters = str_replace('}"', '}', $arrFilters);
		$arrFilters = trim($arrFilters, '"');
		$arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
// 		pr($arrFilters);exit;
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$arrFilter = $arrFilters['filters'];
		$whereResultArray = array();
		$whereResultArray = $arrFilters;
		if (isset($arrFilters['filters'])) {
			$searchGroupOperator = $this->common_helper->search_nested_arrays($arrFilter, $groupOp);
			$searchString = $this->common_helper->search_nested_arrays($arrFilter, $data);
			$searchOper = $this->common_helper->search_nested_arrays($arrFilter, $op);
			$searchField = $this->common_helper->search_nested_arrays($arrFilter, $field);
			foreach ($searchField as $key => $val) {
				$whereResultArray[$val] = $searchString[$key];
			}
		}
		$sidx = $arrFilters['sidx'];
		$sord = $arrFilters['sord'];
		$whereResultArray['sidx'] = $sidx;
		$whereResultArray['sord'] = $sord;
		$whereResultArray['interactionFor'] = $arrFilters['interaction_for'];
		$whereResultArray['end_date'] = $whereResultArray['ed'];
		$whereResultArray['start_date'] = $whereResultArray['sd'];
		if ($kolId == null)
			$kolId = $arrFilters['kol_id'];
		$arrInteractions = array();
		$secName = 'KOL/ Org Name';
		if($this->input->post('org_name') >0 ){
			$secName = 'Organization Name';
		}
		if($secName!='Organization Name'){
			if(!(is_numeric($kolId))){
				$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kolId,'unique_id');
			}
		}
		$sheet['title']					='Payments';
		$arrInteractions[0] = array('Interaction ID',$secName,'Specialty','Interaction Date','Interaction Month','Interaction Type','Interaction Category','Discussion Type','Indication','Topic','Location Type','Employee Name','Division','Total Attendees Added by User','Recorded By','Recorded On');
		$interactionIds = $this->input->post('interaction_ids');
		$arrInteractionIds = explode(',', $interactionIds);
		
		$whereResultArray['objective_id'] = $whereResultArray['type'];
		$whereResultArray['product_id'] = $whereResultArray['product'];
		$whereResultArray['topic_id'] = $whereResultArray['topic'];
		$whereResultArray['is_export'] = true;
		
// 		pr($whereResultArray);
// 		exit;
		$arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $whereResultArray, $limit = '', $start, true, $sidx, $sord, $whereResultArray);
// 		echo $this->db->last_query();
// 		pr($arrInteractionsResults);
// 		exit();
		if($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $whereResultArray, $limit = '', $start, true, $sidx, $sord, $whereResultArray)){
		foreach ($arrInteractionsResults as $arrInteractionResult) {
				$arrInteraction[0] = $arrInteractionResult['generic_id'];
				if ($arrInteractionResult['org_id'] != null && $arrInteractionResult['org_id'] != '') {
					$arrInteraction[1] = $arrInteractionResult['org_name'];
				}else {
					$arrInteraction[1] = $this->common_helper->get_name_format($arrInteractionResult['kol_first_name'], $arrInteractionResult['kol_middle_name'], $arrInteractionResult['kol_last_name']);
				}
				$arrInteraction[2] = $arrInteractionResult['specialty'];
				$arrInteraction[3] = sql_date_to_app_date($arrInteractionResult['date']);
				if ($arrInteraction[3] == "00/00/0000") {
					$arrInteraction[3] = '';
				}
				$arrInteraction[4] = date("M-Y",strtotime($arrInteractionResult['date']));
				$arrInteraction[5] = $arrInteractionResult['mode_name'];
				$arrInteraction[6] = $arrInteractionResult['grouping_name'];
				$arrInteraction[7] = $arrInteractionResult['type'];
				$arrInteraction[8] = $arrInteractionResult['product'];
				$arrInteraction[9] = $arrInteractionResult['topic'];
				$arrInteraction[10] = $arrInteractionResult['interaction_location_type_name'];
				$arrInteraction[11] = $arrInteractionResult['emp_first_name']." ".$arrInteractionResult['emp_last_name'];
				$arrInteraction[12] = $this->common_helper->getUserTeamName($arrInteractionResult['employee_id']);
				$arrInteraction[13] = $arrInteractionResult['total_attendies'];
				$arrUserDetails = $this->common_helper->getEntityById('client_users',array('id'=>$arrInteractionResult['created_by']));
				$arrUserDetails =$arrUserDetails[0];
				$arrInteraction[14] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
				$arrInteraction[15] = date("m-d-Y",strtotime($arrInteractionResult['created_on']));
				$arrInteractions[] = $arrInteraction;
				$specialties = explode(', ', $arrInteractionResult['area_name']);
				$temp = "";
				foreach ($specialties as $value) {
					if (!empty($value)) {
						if ($temp == "")
							$temp = $value;
						else
							$temp = $temp . ", " . $value;
					}
				}
			}
		}
		$sheet['content']				=$arrInteractions;
		$sheets[]=$sheet;
		$arr_export_details['file_name']	="interactions_" . date('m/d/y').'.xls';
		$arr_export_details['sheets']		=$sheets;
// 		pr($arr_export_details);exit;
		export_as_xls($arr_export_details);
	}
	function list_events_by_date_range($startDate = null, $endDate = null, $kolId = null) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrInteractions = array();
		$data = array();
		$arrFilters['end_date'] = $this->input->post('end');
		$arrFilters['start_date'] = $this->input->post('start');
		
		$arrMode = $this->input->post('mode');
		$arrGrouping = $this->input->post('grouping');
		$arrType = $this->input->post('type');
		if($arrType == 'Select'){
			$arrType = '';
		}
		$arrProduct = $this->input->post('product');
		$arrTopic = $this->input->post('topic');
		$arrUserId = $this->input->post('user_id');
		if($arrMode != 'null' && !empty($arrMode)){
			if(!is_array($arrMode)){
				$arrMode = explode(",", $arrMode);
			}
		}
		if($arrGrouping != 'null' && !empty($arrGrouping)){
			if(!is_array($arrGrouping)){
				$arrGrouping = explode(",", $arrGrouping);
			}
		}
		if($arrType != 'null' && !empty($arrType)){
			if(!is_array($arrType)){
				$arrType = explode(",", $arrType);
			}
		}
		if($arrProduct != 'null' && !empty($arrProduct)){
			if(!is_array($arrProduct)){
				$arrProduct = explode(",", $arrProduct);
			}
		}
		if($arrTopic != 'null' && !empty($arrTopic)){
			if(!is_array($arrTopic)){
				$arrTopic = explode(",", $arrTopic);
			}
		}
		if($arrUserId != 'null' && !empty($arrUserId)){
			if(!is_array($arrUserId)){
				$arrUserId = explode(",", $arrUserId);
			}
		}
		$arrFilters['objective_id'] = $arrType;
		$arrFilters['product_id'] = $arrProduct;
		$arrFilters['topic_id'] = $arrTopic;
		$arrFilters['mode'] = $arrMode;
		$arrFilters['grouping'] = $arrGrouping;
		$arrFilters['user_id'] = $arrUserId;
		
		if ($kolId == null){
				$kolId = $arrFilters['kol_id'];
// 			$kolId = $this->common_helper->getKolidOrUniqueId($this->input->post('kol_id'));
		}
		$clientId = $this->session->userdata('client_id');
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId = 0;
		if ($this->session->userdata('user_role_id') == ROLE_USER)
			$userId = $this->session->userdata('user_id');
			
		$arrFilters['interactionFor'] = $this->input->post('interaction_for');
		if($arrFilters['interactionFor'] == 'org'){
			$kolId = $this->input->post('kol_id');
			$arrFilters['org_id'] = $kolId;
		}
		$arrInteractions = array();
		if ($arrInteractionsResults = $this->interaction->getKolInteractions($clientId, $kolId, $userId, $arrFilters, null, null)){
			//pr($arrInteractionsResults);
			foreach ($arrInteractionsResults as $arrInteractionResult) {
				$arrTypes = array();
				$arrProduct = array();
				$arrInteraction['generic_id'] = '';
				$arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
				if ($arrInteraction['date'] == "00/00/0000")
					$arrInteraction['date'] = '';
				$arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
				$arrInteraction['id'] = $arrInteractionResult['id'];
				$arrInteractionResult['generic_id'] = trim($arrInteractionResult['generic_id']);
				if (!empty($arrInteractionResult['generic_id']))
					$arrInteraction['generic_id'] = $arrInteractionResult['generic_id'];
					$arrInteraction['objective_name'] = $arrInteractionResult['type'];
					$arrInteraction['product_name'] = $arrInteractionResult['product'];
					$arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
					if ($arrInteraction['follow_up_on'] == "00/00/0000")
						$arrInteraction['follow_up_on'] = '';
					//	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
					$arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
					//$arrUserDetails						= $this->client_user->editUser($arrInteractionResult['created_by']);
					$arrInteraction['recorded_by'] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
					//$arrInteraction['mirf'] = $this->common_helper->isActionAllowed('mirf','add',$arrInteractionResult);
					$isMirfAllowed = $this->common_helper->isActionAllowed('mirf', 'add', $arrInteractionResult);
					if ($isMirfAllowed) {
						if ($arrInteractionResult['mirf_id'] != null && $arrInteractionResult['mirf_id'] != '')
							$arrInteraction['mirf'] = "Edit";
							else
								$arrInteraction['mirf'] = "Add";
					}else {
						$arrInteraction['mirf'] = "";
					}
					$arrInteraction['mirfAllowed'] = $isMirfAllowed;
					$arrInteraction['mirf_id'] = $arrInteractionResult['mirf_id'];
					$arrInteraction['save_later'] = $arrInteractionResult['save_later'];
					//$arrInteraction['eAllowed']	= $this->common_helper->isActionAllowed('interaction','edit',$arrInteractionResult);
					//$arrInteraction['dAllowed']	= $this->common_helper->isActionAllowed('interaction','delete',$arrInteractionResult);
					
					$arrInteraction['title'] = preg_replace('#<a.*?>([^>]*)</a>#i', '$1', $arrInteractionResult['kol_name']);
					$arrInteraction['allDay'] = true;
					$arrInteractions[] = $arrInteraction;
			}
		}
			echo json_encode($arrInteractions);
	}
	function get_type_by_product($productid, $isFromEditInteraction = false) {
		$arrTypeName = $this->interaction->getTypeByProduct($productid);
		if($isFromEditInteraction){
			return $arrTypeName;
		}else{
			echo json_encode($arrTypeName);
		}
	}
	function get_topic_by_type($typeId = "", $productId = "") {
		$arrPrducts['arrTopics'] = $this->interaction->getTopicByType($typeId, $productId);
		echo json_encode($arrPrducts);
	}
	function prepare_discussion_topic_data($row) {
		$arrType = $this->get_type_by_product($row['product_id'],true);
		$arr = array();
		$arr['arrProducts'] = $this->common_helper->getUserProducts();
		$arr['arrTypes'] = $arrType;//$this->interaction->getAllTypesOfClient();
		$arr['arrTopics'] = $this->interaction->getTopicByType($row['interaction_type'], $row['product_id']);
		$arr['row'] = $row;
		return $arr;
	}
	// add interaction for KOL or Org
	function add_interaction($type='kols',$kol_or_org_id,$interaction_id=null){
		$data = array();
		$data['interactionDetails'] = array();
		
		$clientId = $this->session->userdata('client_id');
		if ($type =='kols'){
			//get KOL details
			if(!(is_numeric($kol_or_org_id))){
				$kol_or_org_id		= $this->common_helper->getKolClientVisiblityId($kol_or_org_id);
			}
			$arrKolDetail = $this->kol->editKol($kol_or_org_id);
			$data['plans'] = $this->interaction->getPlanNames($kol_or_org_id);
		}
		$data['kolId']				=$kol_or_org_id;
		$data['interactionFor'] 	= $type;
		///////////////////
		$data['arrGroupings'] 		= $this->interaction->getAllGroupings($clientId,$type);
		$data['arrModes'] 			= $this->interaction->getAllModesOfClient($clientId,$type);
		$data['arrCountry'] 		= $this->country_helper->listCountries();
		$data['arrProduct'] 		= $this->common_helper->getUserProducts();
		$locationType 				= $this->interaction->getInteractionLocationTypes();
		$arrInteractionLocationTypesTemp = array();
		foreach ($locationType as $key => $value) {
			$arrInteractionLocationTypesTemp[$value['id']] = ($value['name']);
		}
		$data['locationType'] = $arrInteractionLocationTypesTemp;
		
		$this->load->model('specialities/speciality');
		$data['arrSpecialties'] = $this->speciality->getAllSpecialties('all');
		
		if ($interactionFor == 'org'){
			$data['arrKolDetails'] = $this->organization->getOrgNames();
		}else{
			$data['arrKolDetails'] 	= $arrKolDetail;
			$data['kolSpecialty1'] 	= $data['arrSpecialties'][$arrKolDetail['specialty']];
			$data['kolTitle'] 		= $arrKolDetail['title'];
		}

		///////////////////////////get interaction details
		if($interaction_id!=null){
			$interactionDetails 	= $this->interaction->getInteractionDetails($interaction_id);
			$arrTopics 				= $this->interaction->getInteractionDiscussionTopics($interaction_id);
			foreach ($arrTopics as $row) {
				$arrDiscussion[] = $this->prepare_discussion_topic_data($row);
			}
			$data['arrDiscussion'] 	= $arrDiscussion;
			$data['arrDocs'] 		= $this->interaction->getInteractionDocs($interaction_id);
			$interactionDetails['otherAttendisData'] =  $this->interaction->getOtherAttendisDataById($interaction_id);
			$interactionDetails['attendies']		 = $this->interaction->getInteractionAttendis($interaction_id);
			
			if ($interactionDetails['location_type'] != -1) {
				if($interactionDetails['country_id'] != '')
					$data['arrStates'] = $this->country_helper->getStatesByCountryId($interactionDetails['country_id']);
				else
					$data['arrStates'] = $this->country_helper->getStatesByCountryId($interactionDetails['country_id']);
					
				if (isset($interactionDetails['city_id']) && $interactionDetails['city_id'] != '') {
					$data['arrCities'] = $this->country_helper->getCitiesByStateId($interactionDetails['state_id']);
				}
			}
			$arrIds = "";
			if( $data['interactionFor'] == 'org'){
				foreach($interactionDetails['attendies'] as $aRow)
					$arrIds[] = $aRow['org_id'];
				$this->load->model('organizations/organization');
				$data['arrOrgDetails'] = $this->organization->getOrgNames($arrIds);
			}else{
				foreach($interactionDetails['attendies'] as $aRow)
					$arrIds[] = $aRow['kol_id'];
				$data['arrKolDetails'] = $this->kol->getKolNames($arrIds);
			}
		}

		//Location details
		if( $data['interactionFor'] == 'org'){
			$OrgContactDetails = $this->kol->getOrgDetailsById($kol_or_org_id);
			$arrPrimaryContact = array();
			$arrPrimaryContact[0] = array(
					'id' => -1,
					'location' => 'Primary',
					'address' => $OrgContactDetails[0]['address'],
					'state' => $OrgContactDetails[0]['Region'],
					'city' => $OrgContactDetails[0]['City'],
					'country' => $OrgContactDetails[0]['Country']
			);
			$data['kolLocations'] = array_merge($arrPrimaryContact);
		}else{
			if (!empty($kol_or_org_id)) {
				$kolContactDetails = $this->kol->getKolDetailsById($kol_or_org_id);
				$arrPrimaryContact = array();
				$arrPrimaryContact[0] = array(
						'id' => -1,
						'location' => 'Primary',
						'address' => $kolContactDetails[0]['address1'] . ' ' . $kolContactDetails[0]['address2'],
						'state' => $kolContactDetails[0]['Region'],
						'city' => $kolContactDetails[0]['City'],
						'country' => $kolContactDetails[0]['Country']
				);
				$arrSecondaryContact = $this->kol->listAdditionalContacts($kolId);
				$data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
			} else {
				//	pr($interactionDetails);
				$kolContactDetails = $this->kol->getKolDetailsById($interactionDetails['attendies'][0]['kol_id']);
				$arrPrimaryContact = array();
				$arrPrimaryContact[0] = array(
						'id' => -1,
						'location' => 'Primary',
						'address' => $kolContactDetails[0]['address1'] . ' ' . $kolContactDetails[0]['address2'],
						'state' => $kolContactDetails[0]['Region'],
						'city' => $kolContactDetails[0]['City'],
						'country' => $kolContactDetails[0]['Country'],
				);
				$arrSecondaryContact = $this->kol->listAdditionalContacts($interactionDetails['attendies'][0]['id']);
				$data['kolLocations'] = array_merge($arrPrimaryContact, $arrSecondaryContact);
			}
		}
		$data['interactionDetails']		= $interactionDetails;
		$data['contentPage']			='interactions/add_interaction';
		$data['contentData']			=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function delete_document($documentId) {
		$fileName = $this->interaction->deleteDocuments($documentId);
		if ($fileName != false) {
			unlink(APPPATH . "/documents/kol_interactions_documents/" . $fileName);
			echo true;
		} else {
			echo false;
		}
	}
	function get_all_kol_org_names_for_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0,$id,$kolName) {
		$kolName = urldecode($this->input->post($kolName));
		$arrKolNames1 = array();
		//     	echo $kolName;exit;
		$arrKolNames = $this->interaction->getAllKolNamesForAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);
		$arrKeyNames = $this->interaction->getAllKeyPeoplesForAutocomplete($kolName,$id);
		$flag = 1;
		foreach ($arrKolNames['customers'] as $key => $row) {
			if ($flag) {
				$arrKolNames1[] = "<div class='autocompleteHeading'>KTL's</div><div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><span style='display:none' class='id1'>$key</span></div>";
				$flag = 0;
			} else {
				$arrKolNames1[] = "<div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><label style='color: red;display:block'>" . $row['do_not_call_flag'] . "</label><span style='display:none' class='id1'>$key</span></div>";
			}
		}
		$flag = 1;
		foreach($arrKeyNames as $arrKeyPeople){
			$arrKeyPeople['role_id'] = $arrKeyPeople['role'];
			$arrKeyPeople['name'] = $arrKeyPeople['first_name'] . ' ' . $arrKeyPeople['middle_name'] . ' ' . $arrKeyPeople['last_name'];
			if($arrKeyPeople['salutation'] !='0'){
				$arrKeyPeople['salutation'] = $arrSalutations[$arrKeyPeople['salutation']];
			}
			if ($flag) {
				$arrKolNames1[] = '<div class="autocompleteHeading">Key People</div><div class="dataSet"><label name="' . $arrKeyPeople['id'] . '" type="key" class="organizations" style="display:block">' .$arrKeyPeople['name']. "</label><p class='orgName'>".$arrKeyPeople['department']."</p></div>";
				$flag = 0;
			} else {
				$arrKolNames1[] = '<div class="dataSet"><label name="' . $arrKeyPeople['id'] . '" type="key" class="organizations" style="display:block">' . $arrKeyPeople['name'] . "</label><p class='orgName'>".$arrKeyPeople['department']."</p></div>";
			}
		}
		$arr['query'] = $kolName;
		$arr['suggestions'] = $arrKolNames1;
		echo json_encode($arr);
	}
	function get_key_people_details($keyId = null) {
		$arrKolDetails = $this->interaction->getKepPeopleTitle($keyId);
		$data['title'] = $arrKolDetails[0]['title'];
		echo json_encode($data);
	}
	function save_interaction(){
		$arrDetails['id']				=$_POST['interaction_id'];
		$interactionFor					=$_POST['interaction_for'];
		$kol_org_id						=$_POST['kol_id'];
		
		$interaction_id					=$arrDetails['id'];
		////calender event
		if($interaction_id!=null){
			//edit calender event
			$arrInteractionDetails=$this->common_helper->getEntityById('interactions',array('id'=>$interaction_id));
			$arrDetails['calendar_event_id']= $this->interaction->addUpdateEvent($arrInteractionDetails[0]['calendar_event_id']);
		}
		//add calender event
		$arrDetails['calendar_event_id']	=$this->interaction->addUpdateEvent();
		
		$arrDetails['date']					=app_date_to_sql_date($_POST['interaction_date']);
		$arrDetails['location_category']	=$_POST['location_category'];
		$arrDetails['plan_name']			=$_POST['plan_id'];
		$arrDetails['mode']					=$_POST['mode'];
		$arrDetails['grouping']				=$_POST['grouping'];
		$arrDetails['notes']				=$_POST['notes'];
		$arrDetails['total_attendies']		=$_POST['total_attendies'];
		$arrDetails['client_id']			=$this->session->userdata('client_id');
		$arrDetails['generic_id']			=$this->common_helper->getGenericId("Interactions Name");
		$arrDetails['location_type']		=$this->input->post('selectedLocation');
		if ($interactionFor == 'org') {
			$orgId = $this->input->post('org_within_id');
			if ($arrDetails['location_type'] == -1) {
				$OrgContactDetails 			= $this->interaction->getOrgLocaionDetailsById($kol_org_id);
				$arrDetails['location'] 	= 'Primary';
				$arrDetails['address'] 		= $OrgContactDetails[0]['address'];
				$arrDetails['city_id'] 		= $OrgContactDetails[0]['city_id'];
				$arrDetails['state_id'] 	= $OrgContactDetails[0]['state_id'];
				$arrDetails['country_id'] 	= $OrgContactDetails[0]['country_id'];
				$arrDetails['postal_code']	= $OrgContactDetails[0]['postal_code'];
			}else {
				$arrDetails['location'] 	= 'Other';
				$arrDetails['address'] 		= $this->input->post('address1');
				$arrDetails['address2'] 	= $this->input->post('address2');
				$arrDetails['city_id'] 		= $this->input->post('city');
				$arrDetails['state_id'] 	= $this->input->post('state');
				$arrDetails['postal_code'] 	= $this->input->post('postal_code');
				$arrDetails['country_id'] 	= $this->input->post('country_id');
			}
		}else{
			if ($arrDetails['location_type'] == -1) {
				$kolContactDetails 			= $this->kol->getKolDetailsById($kol_org_id);
				$arrDetails['location'] 	= 'Primary';
				$arrDetails['address'] 		= $kolContactDetails[0]['address1'];
				$arrDetails['address2'] 	= $kolContactDetails[0]['address2'];
				$arrDetails['city_id'] 		= $kolContactDetails[0]['city_id'];
				$arrDetails['state_id'] 	= $kolContactDetails[0]['state_id'];
				$arrDetails['country_id'] 	= $kolContactDetails[0]['country_id'];
				$arrDetails['postal_code'] 	= $kolContactDetails[0]['postal_code'];
			} else if($arrDetails['location_type'] > 0) {
				$arrKolLocations 			= $this->kol->getAdditionalContactByType($kol_org_id,$arrDetails['location_type']);
				$arrDetails['location'] 	= $arrKolLocations[0]['location'];
				$arrDetails['address'] 		= $arrKolLocations[0]['address'];
				$arrDetails['city_id'] 		= $arrKolLocations[0]['city_id'];
				$arrDetails['state_id'] 	= $arrKolLocations[0]['state_id'];
				$arrDetails['country_id'] 	= $arrKolLocations[0]['country_id'];
				$arrDetails['postal_code'] 	= '';
			}else{
				$arrDetails['location'] 	='Other';
				$arrDetails['address'] 		= $this->input->post('address1');
				$arrDetails['address2'] 	= $this->input->post('address2');
				$arrDetails['city_id'] 		= $this->input->post('city');
				$arrDetails['state_id'] 	= $this->input->post('state');
				$arrDetails['postal_code'] 	= $this->input->post('postal_code');
				$arrDetails['country_id'] 	= $this->input->post('country_id');
			}
		}
		//save interaction details 
		$interaction_id=$this->interaction->addUpdateInteraction($arrDetails);
				
		//Save Other attendees
		$arrOtherAttendees 								=array();
		$arrOtherAttendees['interaction_id']			=$interaction_id;
		$arrOtherAttendees['non_profiled_kol'] 			=$this->input->post('non_profiled_kol');
		$arrOtherAttendees['non_profifled_specialty']	=$this->input->post('non_profifled_specialty');
		$arrOtherAttendees['non_profiled_comment'] 		=$this->input->post('non_profiled_comment');
		$this->interaction->saveOtherAttendis($arrOtherAttendees);
		
		//save   Discussion Topics
		$arrTopicDetail['interaction_id']				=$interaction_id;
		$arrTopicDetail['product_id'] 					=$this->input->post('product');
		$arrTopicDetail['interaction_type'] 			=$this->input->post('objective');
		$arrTopicDetail['topic_id'] 					=$this->input->post('topic');
		$this->interaction->saveInteractionTopicDetail($arrTopicDetail);
		
		//Interactions documents path
		$target_path = APPPATH. "documents/kol_interactions_documents";
		$docDetails['name'] = $this->input->post('doc_name');
		$docDetails['description'] = $this->input->post('doc_description');
		//Loop trough each uploaded file name
		foreach ($docDetails['name'] as $key=>$doc_name){
			//Proceed only if the uploaded file name is not blank
			if ($_FILES['int_ref_file']['name'][$key]!= null && $_FILES['int_ref_file']['name'][$key]!= "") {
				//Get the file information, use for file validations like allowed file type, file size etc
				$path_info = pathinfo($_FILES['int_ref_file']['name'][$key]);
				$path_info['size'] =$_FILES['int_ref_file']['size'][$key];
				//Generate a randome name
				$newFileName = random_string('unique', 20) . "." . $path_info['extension'];
				$overview_file_target_path = $target_path . "/" . $newFileName;
// 				pr($overview_file_target_path);
				//Move uploaded file in to interactions document location
				if (move_uploaded_file($_FILES['int_ref_file']['tmp_name'][$key],$overview_file_target_path)){
					$arrDocDetails = array();
					$arrDocDetails['interaction_id'] = $interaction_id;
					$arrDocDetails['name'] = $_FILES['int_ref_file']['name'][$key];
					if(empty($arrDocDetails['name'])){
						$arrDocDetails['name'] = 'File'. $key;
					}
					$arrDocDetails['description'] = $docDetails['description'][$key];
					if(empty($arrDocDetails['description'])){
						$arrDocDetails['description'] = 'File'. $i;
					}
					$arrDocDetails['doc_path'] = $newFileName;
					$arrDocDetails['created_by'] = $this->session->userdata('user_id');
					$arrDocDetails['created_on'] = date('Y-m-d H:i:s');
					$this->common_helper->insertEntity('interaction_docs',$arrDocDetails);
				}
			}
		}
		//save attendees
		//kol_ids 
		$autocomplete_kol_ids=$_POST['kol_id_auto'];
		$attendee_types=$_POST['attendee_type'];
		foreach ($autocomplete_kol_ids as $key=>$kol_id_auto){
			$arrAttendeesDetail=array();
			$arrAttendeesDetail['interaction_id']=$interaction_id;
			if($interactionFor=='kols'){
				$arrAttendeesDetail['kol_id']=$kol_id_auto;
				$arrAttendeesDetail['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kol_id_auto);
			}else{
				$arrAttendeesDetail['org_id']=$_POST['org_within_id'];
				if($attendee_types[$key]=='kol_type')
					$arrAttendeesDetail['kol_id']=$kol_id_auto;
				else 
					$arrAttendeesDetail['key_id']=$kol_id_auto;
			}
			$arrAttendeesDetails[]=$arrAttendeesDetail;
		}
		$this->interaction->saveInteractionAttendis($arrAttendeesDetails);
		
		if($interaction_id>0){
			$arrRetData['status']=true;
			$arrRetData['message']="Interaction Details are successfully updated";
		}
		echo json_encode($arrRetData);
	}
	function delete_interaction_row($type,$id){
		$arrReturnData=$this->interaction->deleteInteractionOtherDetails($type,$id);
		echo json_encode($arrReturnData);
	}
	function download_doc($documentId) {
		$docs = $this->interaction->getInteractionDocs(null,$documentId);
		$fileName = $docs[0]['doc_path'];
		$this->load->helper('download');
		// Read the contents of the file
		$data = file_get_contents(APPPATH."documents/kol_interactions_documents/" . $fileName);
		$explodeFileName = explode('.', $docs[0]['doc_path']);
		//pr($explodeFileName);
		$fileName1 = $docs[0]['name'];
		$fileName1 = $fileName1 . "." . $explodeFileName[1];
		force_download($fileName1, $data);
	}
	function delete_interaction($interactionId) {
		//Delete the calender event if it has
		$arrInteractionDetails = $this->interaction->getInteractionDetails($interactionId);
		if ($arrInteractionDetails['calendar_event_id'] != 0)
			$this->interaction->deleteEvent($arrInteractionDetails['calendar_event_id']);
			//Delete interaction documents
			$arrinteractionDocs = $this->interaction->getInteractionDocs($interactionId);
			if (sizeof($arrinteractionDocs) >= 1) {
				foreach ($arrinteractionDocs as $interactionDoc) {
					//Deletes the doccument and returns its file name
					$fileName = $this->interaction->deleteDocuments($interactionDoc['id']);
					if ($fileName != '') {
						unlink($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_interactions_documents/" . $fileName);
					}
				}
			}
			//Delete Interaction record
			$isDeleated = $this->interaction->deleteInteraction($interactionId);
			echo $isDeleated;
	}
	function view_interactions($kol_id=null){
		$this->load->Model('interactions/interaction');
		$this->load->Model('clients/client');
		
		$clientId 							= $this->session->userdata('client_id');
		$userId 							= $this->session->userdata("user_id");
		$managerDetails						= $this->client->getUsermanager($userId);
		$data['managerDetails'] 			=$managerDetails[0];
		
		$module_name						='interactions';
		$data['module_id']					=$this->common_helper->getModuleIdByModuleName($module_name);
		
		if($kol_id!=null){
			//if it unique_id
			if(!(is_numeric($kol_id))){
				$kolId							= $this->common_helper->getKolClientVisiblityId($kol_id);
			}
			$arrKolDetail 						= $this->kol->editKol($kolId);
			//if it KOL within profile , show export options
			$arr_option_data['kol_id']			=$arrKolDetail['kols_client_visibility_id'];
			$arr_option_data['kol_unique_id']	=$arrKolDetail['kols_client_visibility_unique_id'];
			
			if($this->common_helper->check_module("align_users")){
				$this->load->model('align_users/align_user');
				$arr_option_data['assignedUsers'] 	=$this->align_user->getAssignedUsers($kolId);
			}
			//export options
			$data['options_page']				='kols/export_options_within_kol';
			$data['options_data']				=$arr_option_data;
			
			$arrKolInfo['kol_id'] 				= $arrKolDetail['kols_client_visibility_id'];
			$arrKolInfo['kol_unique_id']		=$arrKolDetail['kols_client_visibility_unique_id'];
			$arrKolInfo['kol_name'] 			= $this->common_helper->get_name_format($arrKolDetail['first_name'], $arrKolDetail['middle_name'], $arrKolDetail['last_name']);
			$data['arrKolInfo'] 				= $arrKolInfo;
		}
		
		$data['arrManager'] 				= $this->client->getClientManagers();
		$data['arrGroupings'] 				= $this->interaction->getAllGroupings($clientId);
		$data['arrModes'] 					= $this->interaction->getAllModesOfClient($clientId);
		$data['arrUsers'] 					= $this->client->getClientUsers($clientId);
		$data['arrProduct'] 				= $this->common_helper->getUserProducts();
		$data['arrDiscussionType']			= $this->interaction->getDiscussionTypeByProductIds($data['arrProduct']);
		$data['arrDiscussionTopic'] 		= $this->interaction->getTopicsByDiscussionTypesAndProductIds($data['arrProduct'],$data['arrDiscussionType']);
		
		$data['contentPage']				='view_numeric_report';
		$data['contentData']				=$data;
		
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function interactions_drilldown_list($type, $id, $seg, $filters = '') {
		$arrFilters = array();
		$arrFilters['sd'] = '';
		$arrFilters['ed'] = '';
		$arrFilters['mode'] = '';
		$arrFilters['grouping'] = '';
		$arrFilters['type'] = '';
		$arrFilters['product'] = '';
		$arrFilters['topic'] = '';
		if ($filters != '') {
			$filtersSplit = explode('_', $filters);
			foreach ($filtersSplit as $filter) {
				$filterSplit = explode('=', $filter);
				$arrFilters[$filterSplit[0]] = explode(':',$filterSplit[1]);
			}
		}
		if($arrFilters['type'][0]=='Select'){
			$arrFilters['type'] ='';
		}
		/*if ($this->session->userdata('user_role_id') == ROLE_USER)
		 $arrFilters['user_id'] = $this->session->userdata('user_id');*/
		
		$arrInteractionsResults = $this->interaction->listInteractionsByDrilldown($type, $id, $seg, $arrFilters);
		//echo '<br>Total : '.sizeof($arrInteractions).'<br>';
		//         pr($this->db->last_query());exit;
		
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrInteractions = array();
		$data = array();
		
		
		$clientId = $this->session->userdata('client_id');
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId = 0;
		if ($this->session->userdata('role_type') == ROLE_USER)
			$userId = $this->session->userdata('user_id');
		
		$arrInteractions = array();
		foreach ($arrInteractionsResults as $arrInteractionResult) {
			$arrInteraction['date'] = sql_date_to_app_date($arrInteractionResult['date']);
			if ($arrInteraction['date'] == "00/00/0000")
				$arrInteraction['date'] = '';
			$arrInteraction['mode_name'] = $arrInteractionResult['mode_name'];
			$arrInteraction['id'] = $arrInteractionResult['id'];
			$arrInteraction['objective_name'] = $arrInteractionResult['objective_name'];
			$arrInteraction['product_name'] = $arrInteractionResult['product_name'];
			$arrInteraction['follow_up_on'] = sql_date_to_app_date($arrInteractionResult['follow_up_on']);
			if ($arrInteraction['follow_up_on'] == "00/00/0000")
				$arrInteraction['follow_up_on'] = '';
		//	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
			$arrInteraction['kol_name'] = $arrInteractionResult['kol_name'];
// 			$arrUserDetails = $this->client_user->editUser($arrInteractionResult['created_by']);
			$arrUserDetails=$this->common_helper->getEntityById('client_users', array ('id' => $arrInteractionResult['created_by']));
			$arrUserDetails=$arrUserDetails[0];
			
			$arrInteraction['recorded_by'] = $arrUserDetails['first_name'] . " " . $arrUserDetails['last_name'];
			$arrInteractions[] = $arrInteraction;
		}
		$count = sizeof($arrInteractions);
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		$data['records'] = $count;
		$data['total'] = $total_pages;
		$data['page'] = $page;
		$data['rows'] = $arrInteractions;
		echo json_encode($data);
	}
	function view_interaction_details($interactionId, $isAjax='', $calEventId = null) {
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		if ($calEventId == null) {
			$interactionDetails = $this->interaction->getInteractionDetails($interactionId);
		} else {
			$interactionDetails = $this->interaction->getInteractionByCalEventId($calEventId);
			$interactionId = $interactionDetails['id'];
		}
		
		$interactionDetails['other_attendees'] = $this->interaction->getOtherAttendisDataById($interactionId);
		$interactionDetails['created_by_name'] =$this->common_helper->getUserName($interactionDetails['created_by']);

		$data['docs'] = $this->interaction->getInteractionDocs($interactionId);
		$data['interactionDetails'] = $interactionDetails;
		$this->load->model('plannings/planning');
		$data['plans'] = $this->planning->getPlanNames();
		$data['plan_id']=$interactionDetails['plan_name'];

	
// 		$data['arrHistories'] = $this->find_history($interactionId);
// 		$formData = $_POST;
// 		$formData = json_encode($formData);
// 		$arrLogDetails = array(
// 				'type' => LOG_VIEW,
// 				'description' => 'View interaction',
// 				'status' => 'success',
// 				'transaction_id' => $interactionId,
// 				'transaction_table_id' => INTERACTIONS,
// 				'transaction_name' => "View interaction",
// 				'form_data' => $formData
// 		);
// 		$this->config->set_item('log_details', $arrLogDetails);		
// 		log_user_activity($arrLogDetails, true);
		if ($isAjax != "") {
			if($isAjax=='plan'){
				$data['fromPlan']=true;
			}
			$data['contentPage'] = 'interactions/view_interaction_micro_profile';
			$this->load->view(CLIENT_LAYOUT,$data);
		}
		if ($isAjax == "") {
			$this->load->view('interactions/view_interaction_micro_profile', $data);
		}		
	}
}
?>