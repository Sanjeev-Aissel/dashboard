<?php
/**
 * Contains fucntion required for "Client Requested Kols" feature
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.controllers	
 * @created 13-6-2012
 */
 
class requested_kols extends Controller{
 	
 	private $loggedUserId	= null;
 	private $isApprover	= false;
 	
 	//Constructor
	function requested_kols(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model("Country_helper");
		$this->load->model("Event_helper");
		$this->load->model("Specialty");
		$this->load->model('common_helpers');
		$this->load->model('Client_User');
		$this->load->model('align_user');
		$this->load->model("requested_kol");	
		$this->load->model('organization');
		$this->loggedUserId = $this->session->userdata('user_id');	
		//$this->isApprover	= IS_APPROVER;
	}
	
	/**
	 * Laod the Form to add Kol Deatils
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function add_cleint_kol(){
		$this->load->model('Specialty');
		$arrSpecialties	= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
 		
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
			$data['arrCountry']=$this->Country_helper->listCountries();
		$this->load->view('kols/add_client_kol',$data);
	}
	
	/**
	 * Allow user to choose what to do f profile is not present
	 * @author Laxman K
	 * @version KOLM Otsuka v2.2
	 * @since 10-06-2014
	 *
	 */
	function user_profileview_option(){
		$this->load->view('kols/user_profileview_option',array());
	}
	/**
	 * Save the Kol detila added by Client
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function save_client_requested_kol(){
		$this->isApprover	= IS_APPROVER;
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$arrKol['salutation']	 	=	$this->input->post('salutation');
    	$arrKol['first_name']	 	=	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 	=	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     	=	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 	=	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']		=	$this->input->post('specialty');
		$arrKol['primary_phone']	=	ucwords(trim($this->input->post('primary_phone')));
    	$arrKol['primary_email']	=	trim($this->input->post('primary_email'));
   		$arrKol['fax']				=	$this->input->post('fax');
		$arrKol['address1']        	=	$this->input->post('address1');
		$arrKol['npi_num']        	=	$this->input->post('npi_num'); 
       	$arrKol1['name']        	=	$this->input->post('org_id'); 
      
        if($arrKol1['name'] !=''){
           	$arrKol1['status']	= "Requested";
			$arrKol['org_id']	= $this->organization->saveOrganization($arrKol1);
		}
		
		$arrKol['country_id']	=	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']      =	$this->input->post('city_id');
       	
       	$arrKol['title']     	=	$this->input->post('title');
       	$arrKol['division']     =	$this->input->post('division');
		$arrKol['profile_type'] =	$this->input->post('profile_type');
       	
       	$arrKol['is_pubmed_processed']        =	1;
		$arrKol['created_by']	 = 	$this->loggedUserId;
		$arrKol['created_on']	 =	date("Y-m-d H:i:s");
		$arrKol['status']		 =	New1;
		
		if($this->isApprover)
			$arrKol['status']		 =	APPROVED;
		
       	//ending post details
		
		$kolId = $this->kol->saveKol($arrKol);
       	if($kolId){
       		$updateData['id'] 	=  $kolId;  
       		$updateData['pin'] 	=  $kolId;  
       		$this->kol->updateKol($updateData);
          	//$this->session->set_flashdata('message','New Kol Saved Sucessfully');
          	$arrKol['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
       		if($arrKol['specialty']!=0){
       			$arrKol['specialty'] 	= $this->Specialty->getSpecialtyById($arrKol['specialty']);
			}else{
				$arrKol['specialty']	= '';
			}
          	$arrKol['country'] 		= $this->Country_helper->getCountryById($arrKol['country_id']);
          	$arrKol['user_name'] 	= $this->session->userdata('user_name');
          	$arrKol['user_full_name'] = $this->session->userdata('user_full_name');
          	$arrKol['kol_id'] = $kolId;
          		$arrKol['approved_by'] = '';
          	if($arrKol1['name'] !=''){
          		$arrKol['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
          	}
          	$data['arrKol'] = $arrKol;
          	$data['saved'] = true;
          	$data['msg'] ='New KOL Saved Sucessfully';
          	$data['user_role_id'] = $this->session->userdata('user_role_id');
          	
          
        	/* $config['protocol'] 	= PROTOCOL;
			$config['smtp_host'] 	= HOST;         
			$config['smtp_port'] 	= PORT;
			$config['smtp_user'] 	= USER;
			$config['smtp_pass'] 	= PASS;
			$config['mailtype']		= 'html'; */
          	$config = email_config_initializer('profile_request');
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->initialize($config);
			$this->email->clear();
			//$config['mailtype'] = 'html';
		
			$this->email->set_newline("\r\n");
		
			$clientId = $this->session->userdata('client_id');
          	
			//send mail to Analyst Managers if the request is from Client manager
			if($this->isApprover){
				$arr =array();
				$arr[$kolId] = $this->kol->editKol($kolId);
				
				$clientId = $this->session->userdata('client_id');
				$clientName = $this->Client_User->getClientName($clientId);
				$data1['clientName'] = $clientName;
				$data1['arrKols'] = $arr;
		
	           	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	           	foreach($analystMangerEmailId as $email=>$ids){
	           		$emailIds[]=$ids['email'];
	           	}
				//pr($analystMangerEmailId);
				$analystMangerEmailIds = implode(',',$emailIds);
				$this->email->subject(PRODUCT_NAME.': New Profiling Request');
	          	$userNAme = $this->session->userdata('user_full_name');
	            $this->email->from($config['smtp_user'],$userNAme);
				$html = $this->load->view('requested_kols/approved_kols',$data1,true);
				
	          	$this->email->message($html);
	          	$this->email->to($analystMangerEmailIds);
// 	          	$this->email->send();
	          	if($this->email->send()){
	          	    //Log Activity
	          	    $arrLogDetails = array(
	          	        'description'=>$html,
	          	        'type' => LOG_ACTIVITY_EMAIL,
	          	        'status' => STATUS_SUCCESS,
	          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
	          	    );
	          	    $this->config->set_item('log_details', $arrLogDetails);
	          	    log_user_activity(null,true);
	          	    $status	=  true;
	          	}else{
	          	    //Log Activity
	          	    $arrLogDetails = array(
	          	        'description'=>$html,
	          	        'type' => LOG_ACTIVITY_EMAIL,
	          	        'status' => STATUS_FAIL,
	          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
	          	    );
	          	    $this->config->set_item('log_details', $arrLogDetails);
	          	    log_user_activity(null,true);
	          	    $status	=  false;
	          	}
	          	$this->email->clear(TRUE);
			}else{
				//Send mail to  Client manager
				$userId = $this->session->userdata('user_id');
				$managerEmailId	= $this->Client_User->getUserManagerEmailId($userId);
				$approverIds	= explode(',',APPROVER_IDS); 
				$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
	         	$clientMangerEmailIds[]	= $managerEmailId;
	          	$this->email->from($config['smtp_user'],$arrKol['user_full_name']);
				$this->email->subject(PRODUCT_NAME.': New Profiling Request');
				$baseUrl = base_url().'requested_kols/show_client_requested_kols';
				$target = "_NEW";
				$this->email->message("<p>
										Hello,</p><p>
										
										There are new KOL Profile content curation requests pending your approval. 
										The profiling requests will be processed by Aissel Content team once you approve the requests. To approve/reject the requests, please click on the link below and login to KOLM.</p>
										<p>
										<p><a title='Requested KOL'S' href='".$baseUrl."'login target='".$target."'>Requested KOL'S</a><p>
										<p>
										<p>Thanks,<br /></p>
									  <p>".PRODUCT_NAME." Support</p>");
	          
	          	$this->email->to($clientMangerEmailIds);
// 	          	$this->email->send();
	          	if($this->email->send()){
	          	    //Log Activity
	          	    $arrLogDetails = array(
	          	        'description'=>$html,
	          	        'type' => LOG_ACTIVITY_EMAIL,
	          	        'status' => STATUS_SUCCESS,
	          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	          	        'miscellaneous2'=>"To-".$clientMangerEmailIds
	          	    );
	          	    $this->config->set_item('log_details', $arrLogDetails);
	          	    log_user_activity(null,true);
// 	          	    $status	=  true;
	          	}else{
	          	    //Log Activity
	          	    $arrLogDetails = array(
	          	        'description'=>$html,
	          	        'type' => LOG_ACTIVITY_EMAIL,
	          	        'status' => STATUS_FAIL,
	          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	          	        'miscellaneous2'=>"To-".$clientMangerEmailIds
	          	    );
	          	    $this->config->set_item('log_details', $arrLogDetails);
	          	    log_user_activity(null,true);
// 	          	    $status	=  false;
	          	}
// 	          	$this->email->clear(TRUE);
	          	//Send mail to  Client manager
	          	//$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	          	//$this->email->from('iPROfile@aissel.com',$arrKol['user_name']);
				//$this->email->message("<p>Clinet1 user has submitted ".$arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name']."  kol for processing please approve it.</p>");
	          	//$this->email->to($analystMangerEmailId[0]);
	          	//$this->email->send();
	          	
	          	//Send mail to  User
	          	$userEmail = $this->session->userdata('email');
	          	$userRoleId = $this->session->userdata('user_role_id');
	         	if(!$this->isApprover){
		          	$this->email->subject(PRODUCT_NAME.': New Profiling Request');
		          	$this->email->from($config['smtp_user'],$arrKol['user_full_name']);
					$this->email->message("<p>Hello,</p><p>
											Your request for KTL Profile content curation has been sent to your Manager for approval and will be processed once approved.
										  </p>
										  <p>KTL Name<p>
										  <li>".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name'])."</li>
										  <p>Thanks,</p>
										  <p>KOLM Support</p>
										  ");
		          	$this->email->to($userEmail);
		          	if($this->email->send()){
		          	    //Log Activity
		          	    $arrLogDetails = array(
		          	        'description'=>$html,
		          	        'type' => LOG_ACTIVITY_EMAIL,
		          	        'status' => STATUS_SUCCESS,
		          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
		          	        'miscellaneous2'=>"To-".$userEmail
		          	    );
		          	    $this->config->set_item('log_details', $arrLogDetails);
		          	    log_user_activity(null,true);
// 		          	    $status	=  true;
		          	}else{
		          	    //Log Activity
		          	    $arrLogDetails = array(
		          	        'description'=>$html,
		          	        'type' => LOG_ACTIVITY_EMAIL,
		          	        'status' => STATUS_FAIL,
		          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
		          	        'miscellaneous2'=>"To-".$userEmail
		          	    );
		          	    $this->config->set_item('log_details', $arrLogDetails);
		          	    log_user_activity(null,true);
// 		          	    $status	=  false;
		          	}
	         	}
			}
          	echo json_encode($data);
        }else{
       		$data['saved'] = false;
       		$data['msg'] = "This KOL is already present in the database.";
         	echo json_encode($data);

       }
	}
	
	
	/**
	 * List the Requested Kol detail
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function list_requested_kols(){
		
		$this->common_helpers->checkUsers();
		//$arrKolDetailResult = $this->kol->getRequestedKolDetail();
		$arrKolDetailResult = $this->requested_kol->listAll();
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
   	 	
   	 	// To show the pubmed and CT Links for Autorised users right now for user id=5
   	 	$data['user_id'] = $this->session->userdata('user_id');
   	 	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		// Get the list of Specialties
		$this->load->model('Specialty');
		$arrSpecialties	= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
				
		$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'kols/list_requested_kols';
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited List Requested KOL's Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "List Requested KOL's"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/**
	 * Update the KOL Status and send Mail to Users
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function update_status(){
		$this->isApprover	= IS_APPROVER;
		/* $config['mailtype'] = 'html';
		$config['protocol']  = PROTOCOL;
		
		$config['smtp_host'] = HOST;         
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS; */
		$config = email_config_initializer('profile_request');
			$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		
		
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');
	
		$arr['modified_by'] =$this->loggedUserId;
		
		$status = 100;
	
		if($arr['status']==COMPLETED){
				foreach($arr['kolId'] as $kolId){
					$userId = $this->requested_kol->getRequestedUserId($kolId);
					$userEmailId  = $this->requested_kol->getUserEmailId($userId);
					$data[$kolId] = $this->kol->editKol($kolId);
					$data[$kolId]['email_id'] =$userEmailId;
				}	
				$data =  $this->requested_kol->getKolDetail($arr['kolId']);		
				$arrKolData =array();
				foreach($data as $row){
					$arrKolData[$row['created_by']][] = $row;
					
				}
				//pr($arrKolData);
				foreach($arrKolData as $key=>$row){
					$userEmailId  = $this->requested_kol->getUserEmailId($key);
					$data2['arrKols']=	$row;
					$this->email->subject(PRODUCT_NAME.': New Profiling Request Completion');
					$userNAme = $this->session->userdata('user_full_name');
					$this->email->from($config['smtp_user'],$userNAme); 	
					$html = $this->load->view('requested_kols/processed_kols',$data2,true);
					$this->email->message($html);
							//$this->email->from('kolm');
					$this->email->to($userEmailId);
					if($this->email->send()){
					    //Log Activity
					    $arrLogDetails = array(
					        'description'=>$html,
					        'type' => LOG_ACTIVITY_EMAIL,
					        'status' => STATUS_SUCCESS,
					        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
					        'miscellaneous2'=>"To-".$userEmailId
					    );
					    $this->config->set_item('log_details', $arrLogDetails);
					    log_user_activity(null,true);
					    // 							    $status	=  true;
					}else{
					    //Log Activity
					    $arrLogDetails = array(
					        'description'=>$html,
					        'type' => LOG_ACTIVITY_EMAIL,
					        'status' => STATUS_FAIL,
					        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
					        'miscellaneous2'=>"To-".$userEmailId
					    );
					    $this->config->set_item('log_details', $arrLogDetails);
					    log_user_activity(null,true);
					    // 							    $status	=  false;
					}
		        //  echo $this->email->print_debugger();
				}
				
				$arrKoldetail=array();
				$arrKoldetail = $this->requested_kol->getKolDetail($arr['kolId']);
				
				foreach($arrKoldetail as $kolDeatil){
					
					$arrKol[$kolDeatil['client_id']][]=$kolDeatil;
				}
				
				foreach($arrKol as $key=>$row2){
					$userNAme = $this->session->userdata('user_full_name');
					$data2['arrKols']=	$row2;
					foreach($row2 as $arrDetial){
						
						if($arrDetial['user_role_id']!=ROLE_MANAGER || $arrDetial['user_role_id']!=ROLE_ADMIN){
							$managerEmailId	= $this->Client_User->getUserManagerEmailId($arrDetial['created_by']);
							$approverIds	= explode(',',APPROVER_IDS); 
							$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
				         	$clientMangerEmailIds[]	= $managerEmailId;
							$this->email->subject(PRODUCT_NAME.': New Profiling Request Completion');
							$this->email->from($config['smtp_user'],$userNAme); 	
							$html1 = $this->load->view('requested_kols/processed_kols',$data2,true);
							$this->email->message($html1);
						
							$this->email->to($clientMangerEmailIds);
						
							if($this->email->send()){
							    //Log Activity
							    $arrLogDetails = array(
							        'description'=>$html,
							        'type' => LOG_ACTIVITY_EMAIL,
							        'status' => STATUS_SUCCESS,
							        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
							        'miscellaneous2'=>"To-".$clientMangerEmailIds
							    );
							    $this->config->set_item('log_details', $arrLogDetails);
							    log_user_activity(null,true);
// 							    $status	=  true;
							}else{
							    //Log Activity
							    $arrLogDetails = array(
							        'description'=>$html,
							        'type' => LOG_ACTIVITY_EMAIL,
							        'status' => STATUS_FAIL,
							        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
							        'miscellaneous2'=>"To-".$clientMangerEmailIds
							    );
							    $this->config->set_item('log_details', $arrLogDetails);
							    log_user_activity(null,true);
// 							    $status	=  false;
							}
							$this->email->clear(TRUE);
						}
					}
					
				}
					
			$status = STATUS_COMPLETED;
		}
		
		if($arr['status']==APPROVED){
			
				$data =  $this->requested_kol->getKolDetail($arr['kolId']);		
				$arrKolData =array();
				foreach($data as $row){
					$arrKolData[$row['created_by']][] = $row;
					
				}
				foreach($arrKolData as $key=>$row){
					$userEmailId  = $this->requested_kol->getUserEmailId($key);
					$data2['arrKols']=	$row;
					$this->email->subject(PRODUCT_NAME.': New Profiling Request Approved');
					$userNAme = $this->session->userdata('user_full_name');
					$this->email->from($config['smtp_user'],$userNAme); 	
					$html = $this->load->view('requested_kols/kols_appr_by_analyst_man',$data2,true);
					$this->email->message($html);
							//$this->email->from('kolm');
					$this->email->to($userEmailId);
// 					$this->email->send();
					if($this->email->send()){
					    //Log Activity
					    $arrLogDetails = array(
					        'description'=>$html,
					        'type' => LOG_ACTIVITY_EMAIL,
					        'status' => STATUS_SUCCESS,
					        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
					        'miscellaneous2'=>"To-".$userEmailId
					    );
					    $this->config->set_item('log_details', $arrLogDetails);
					    log_user_activity(null,true);
					    // 							    $status	=  true;
					}else{
					    //Log Activity
					    $arrLogDetails = array(
					        'description'=>$html,
					        'type' => LOG_ACTIVITY_EMAIL,
					        'status' => STATUS_FAIL,
					        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
					        'miscellaneous2'=>"To-".$userEmailId
					    );
					    $this->config->set_item('log_details', $arrLogDetails);
					    log_user_activity(null,true);
					    // 							    $status	=  false;
					}
// 					$this->email->clear(TRUE);
		        //  echo $this->email->print_debugger();
				}
			
				foreach($data as $row1){
					$arrKolDataToManager[$row1['client_id']][] = $row1;
					
				}
				foreach($arrKolDataToManager as $clientId=>$arrKols){
					$userNAme = $this->session->userdata('user_full_name');
					$data2['arrKols']=	$arrKols;
					$emilIds1=array();
					foreach($arrKols as $arrDetial){
						if(!$this->isApprover){
							//$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($arrDetial['created_by']);
							$managerEmailId	= $this->Client_User->getUserManagerEmailId($arrDetial['created_by']);
							$approverIds	= explode(',',APPROVER_IDS); 
							$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
							$clientMangerEmailIds[]	= $managerEmailId;
							$this->email->subject(PRODUCT_NAME.': New Profiling Request Approved');
							$this->email->from($config['smtp_user'],$userNAme); 	
							$html1 = $this->load->view('requested_kols/kols_appr_by_analyst_man',$data2,true);
							$this->email->message($html1);
							
							$this->email->to($clientMangerEmailIds);
// 							$this->email->send();
							if($this->email->send()){
							    //Log Activity
							    $arrLogDetails = array(
							        'description'=>$html,
							        'type' => LOG_ACTIVITY_EMAIL,
							        'status' => STATUS_SUCCESS,
							        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
							        'miscellaneous2'=>"To-".$clientMangerEmailIds
							    );
							    $this->config->set_item('log_details', $arrLogDetails);
							    log_user_activity(null,true);
							    // 							    $status	=  true;
							}else{
							    //Log Activity
							    $arrLogDetails = array(
							        'description'=>$html,
							        'type' => LOG_ACTIVITY_EMAIL,
							        'status' => STATUS_FAIL,
							        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
							        'miscellaneous2'=>"To-".$clientMangerEmailIds
							    );
							    $this->config->set_item('log_details', $arrLogDetails);
							    log_user_activity(null,true);
							    // 							    $status	=  false;
							}
							$this->email->clear(TRUE);
						}
					}
					
					
				}
				$arr['approved_by'] =$this->loggedUserId;
				$status = STATUS_APPROVED;
		}
		
		if($arr['status'] == PROFILING)
			$status = STATUS_PROFILING;
		if($arr['status'] == REVIEW)
			$status = STATUS_REVIEW;
		if($arr['status'] == New1)
			$status = STATUS_NEW;
		
		$this->kol->updateStatus($arr);
		foreach($arr['kolId'] as $kolId){
			$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $kolId,$status);
		}
	}
	
	/**
	 * Load the Pahe contais List of Requested KOls
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function show_client_requested_kols($urlString = null){
		$data			=	array();
		$arrKolDetailResult1	=	array();
		
		if($urlString != null)
			$data['urlString'] = json_encode($this->filters_to_array($urlString));
		//$this->common_helpers->checkUsers();
		$arrKolDetailResult = $this->kol->getRequestedKolDetail();
		
		foreach($arrKolDetailResult as $row){
			if($row['approved_by']!=''){
			$row['approved_by']=$this->Client_User->getUserNameById($row['approved_by']);
			
			}
			$arrKolDetailResult1[]=$row;
		}
		
		$data['arrKol']	=	$arrKolDetailResult1;
   	 	
   	 	// To show the pubmed and CT Links for Autorised users right now for user id=5
   	 	$data['user_id'] = $this->session->userdata('user_id');
   	 	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
   	 	
		
		// Get the list of Specialties
		$this->load->model('Specialty');
		$arrSpecialties	= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
				
		$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
		//pr($data);
		$data['contentPage'] = 'kols/client_requested_kols';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited client requested kols Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View client requested kols Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
			
	}
	
	
	/**
	 * Update the KOL status as Approved and send mail as Approved to Requsted users
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return
	 * 
	 */
	function update_kol_status_as_approved(){
		$arrKolIds 	= $this->input->post('arrKolId');
		/* $config['protocol']  = PROTOCOL;
		
		$config['smtp_host'] = HOST;         
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS;
		$config['mailtype'] = 'html';
		$config['mailtype'] = 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
	
		
		$this->email->set_newline("\r\n");
		$arr =array();
		foreach($arrKolIds as $kolId){
			$arr[$kolId] = $this->kol->editKol($kolId);
		}
		
		$clientId = $this->session->userdata('client_id');
		$clientName = $this->Client_User->getClientName($clientId);
		$data1['clientName'] = $clientName;
		$data1['arrKols'] = $arr;
          	
        //send mail to Analyst Manager
       	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
       	foreach($analystMangerEmailId as $email=>$ids){
       		$emailIds[]=$ids['email'];
        }
		//pr($analystMangerEmailId);
		$analystMangerEmailIds = implode(',',$emailIds);
		
		$this->email->subject(PRODUCT_NAME.': New Profiling Request');
	    $userNAme = $this->session->userdata('user_full_name');
	    $this->email->from($config['smtp_user'],$userNAme);
		$html = $this->load->view('requested_kols/approved_kols',$data1,true);
		
		$this->email->message($html);
        $this->email->to($analystMangerEmailIds);
        $this->email->send();
          	
          	
		$approvedBy = $this->session->userdata('client_id');; 
		$this->requested_kol->updateKolStatusAsApproved($arrKolIds,APPROVED,$approvedBy);
		foreach($arrKolIds as $kolId){
			$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,STATUS_APPROVED, MODULE_KOL_REQUEST, $kolId,STATUS_APPROVED);
		}
		$data['status'] = "Success";
		$data['approved_by'] = $this->session->userdata('user_name');
		echo json_encode($data);
	}
	
	/**
	 * Update the KOL status as Completed and send mail as Completed to Users who requested Kols
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param 
	 * @return Json data
	 * 
	 */
	function update_kol_status_as_completed(){
		
		$arr['status'] = COMPLETED;
		$arr['kolId'] = $this->input->post('kolIds');
	
		$arr['modified_by'] =$this->loggedUserId;
		if($this->kol->updateStatus($arr)){
			$data['status'] = true;
			foreach($arr['kolId'] as $kolId){
				$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,STATUS_COMPLETED, MODULE_KOL_REQUEST, $kolId);
			}
		}else{
			$data['status'] = false;
		}
		
		echo json_encode($data);
	}

	/**
	 * Delete kols
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param $kolId
	 * @return Json data
	 * 
	 */
	function delete_requested_kol($kolId){
		$arr[]=$kolId;
		if($this->requested_kol->deleteRequestedKol($arr)){
			$data['deleted'] = true;
			$this->update->deleteKolRelatedUpdates($kolId);
		}else{
			$data['deleted'] = false;
		}
		
		echo json_encode($data);
	}
	
	/**
	 * Set status as Rejected and send mail as Rejected to Users who requested Kols
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param $kolId
	 * @return Json data
	 * 
	 */
	function reject_kols(){
		/* $config['protocol']  = PROTOCOL;
		
		$config['smtp_host'] = HOST;         
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS;
		$config['mailtype'] = 'html';
		$config['mailtype'] = 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
	
		
		$this->email->set_newline("\r\n");	
		$arr['kolId'] = $this->input->post('arrKolId');
		
		
		$data =  $this->requested_kol->getKolDetail($arr['kolId']);		
		$arrKolData =array();
		foreach($data as $row){
			$arrKolData[$row['created_by']][] = $row;
			
		}
		
		foreach($arrKolData as $key=>$row){
			
			$userEmailId  = $this->requested_kol->getUserEmailId($key);
			
			$data2['arrKols']=	$row;
			$this->email->subject(PRODUCT_NAME.": Rejecting of Requestd KOL's");
			$userNAme = $this->session->userdata('user_full_name');
			$this->email->from($config['smtp_user'],$userNAme); 	
			$html = $this->load->view('requested_kols/rejected_kols',$data2,true);
			$this->email->message($html);
					//$this->email->from('kolm');
			$this->email->to($userEmailId);
			$this->email->send();
		}
		
		$arr['status'] = REJECT;
		$arr['modified_by'] =$this->loggedUserId;
		
		if($this->kol->updateStatus($arr)){
			$status['status'] = true;
		}else{
			$status['status'] = false;
		}
		echo json_encode($status);
	}
	
	function show_basic_page($pageTepe){
		$data['pageType'] = $pageTepe;
		$this->load->view("requested_kols/show_basic_kol_info",$data);
	}
	
	function show_non_profiled_kols(){
		$clientId		= $this->session->userdata('client_id');
		$profileStatus  = PRENEW;
		$arrData		= array();
		$arrData['arrKol']		= $this->requested_kol->getNonProfiledKols($profileStatus,$clientId);
		$arrData['userId']		= $this->session->userdata('user_id');
		$arrData['contentPage'] = 'kols/non_profiled_kols';
		$this->load->view('layouts/client_view', $arrData);
	}
	
	function add_client_pre_kol($kolId, $pageFlag = 0){
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrCountry']				=	$this->Country_helper->listCountries();
		$arrStates 						= array();
		$arrCities						= array();
		if($arrKolDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
		}
		if($arrKolDetail['state_id'] 	!= 0){
			$arrCities 					= $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
		}
		$data['arrStates']				= $arrStates;
		$data['arrCities']				= $arrCities;
		
		$this->load->model('Specialty');
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']			= $arrSpecialties;
		if($arrKolDetail['org_id']!=0){
			$arrKolDetail['org_name'] = $this->organization->getOrgNameByOrgId($arrKolDetail['org_id']);
		}
		$data['arrKols'] = $arrKolDetail;
		$data['kolId'] = $kolId;
		$data['pageFlag'] = $pageFlag;
		$this->load->view('kols/client_pre_kol',$data);
		
	}
	
	function updete_client_pre_kol(){
		$this->isApprover	= IS_APPROVER;
		$arrKol['id']            =  $this->input->post('kol_id');
		$arrKol['salutation']	 =	$this->input->post('salutation');
    	$arrKol['first_name']	 =	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 =	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     =	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 =	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']     =	$this->input->post('specialty');
		$arrKol['npi_num']        =	$this->input->post('npi_num'); 
       	$arrKol1['name']        =	$this->input->post('org_id'); 
    
		$arrKol['primary_phone']     =	ucwords(trim($this->input->post('primary_phone')));
    	$arrKol['primary_email']      	 =	trim($this->input->post('primary_email'));
   		$arrKol['fax']     =	$this->input->post('fax');
		$arrKol['address1']        =	$this->input->post('address1');
        if($arrKol1['name'] !=''){
           	$arrKol1['status'] = "Requested";
           	// org type
           	$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']= $this->organization->saveOrganization($arrKol1);
		}
		
		$arrKol['country_id']      	 =	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']        =	$this->input->post('city_id');
       	
       	$arrKol['title']     =	$this->input->post('title');
       	$arrKol['division']        =	$this->input->post('division');
       	$arrKol['is_pubmed_processed']        =	0;
		$arrKol['modified_by']	 = 	$this->loggedUserId;
		$arrKol['created_by']	 = 	$this->loggedUserId;
		$arrKol['modified_on']	 =	date("Y-m-d H:i:s");
		$arrKol['profile_type']	 =$this->input->post('profile_type');
		$arrKol['status']	 =	New1;
		$kolId = $arrKol['id'];
		
		if($this->isApprover)
			$arrKol['status']		 =	APPROVED;
			
		if($this->requested_kol->updateClientPreKol($arrKol)){
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
			$data['arrSalutations']	= $arrSalutations;
			$updateData['id'] 	=  $kolId;  
       		$updateData['pin'] 	=  $kolId;  
       		$this->kol->updateKol($updateData);
          	//$this->session->set_flashdata('message','New Kol Saved Sucessfully');
          	$arrKol['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
       		if($arrKol['specialty']!=0){
       			$arrKol['specialty'] = $this->Specialty->getSpecialtyById($arrKol['specialty']);
			}else{
				$arrKol['specialty']='';
			}
          	$arrKol['user_name'] = $this->session->userdata('user_name');
          	$arrKol['country_id']      	 =	trim($this->input->post('country_id'));
          	$arrKol['kol_id'] = $kolId;
          		$arrKol['approved_by'] = '';
          	if($arrKol1['name'] !=''){
          		$arrKol['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
          	}
          	$data['arrKol'] = $arrKol;
          	$data['saved'] = true;
          	$data['msg'] ='New KOL Saved Sucessfully';
          	$data['user_role_id'] = $this->session->userdata('user_role_id');
          	
          
          	/* $config['protocol']  = PROTOCOL;
		
			$config['smtp_host'] = HOST;         
			$config['smtp_port'] = PORT;
			$config['smtp_user'] = USER;
			$config['smtp_pass'] = PASS;
			$config['mailtype'] = 'html'; */
          	$config = email_config_initializer('profile_request');
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->initialize($config);
			$this->email->clear();
			//$config['mailtype'] = 'html';
			
			$this->email->set_newline("\r\n");
			
			$clientId = $this->session->userdata('client_id');

			//send mail to Analyst Managers if the request is from Client manager
			if($this->isApprover){
				$arr =array();
				//$arr[$kolId] = $this->kol->editKol($kolId);
				$arr[$kolId]['first_name']	= $arrKol['first_name'];
				$arr[$kolId]['middle_name']	= $arrKol['middle_name'];
				$arr[$kolId]['last_name']	= $arrKol['last_name'];
				$clientId = $this->session->userdata('client_id');
				$clientName = $this->Client_User->getClientName($clientId);
				$data1['clientName'] = $clientName;
				$data1['arrKols'] = $arr;
		
	           	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	           	foreach($analystMangerEmailId as $email=>$ids){
	           		$emailIds[]=$ids['email'];
	           	}
				//pr($analystMangerEmailId);
				$analystMangerEmailIds = implode(',',$emailIds);
				$this->email->subject(PRODUCT_NAME.': New Profiling Request');
	          	$userNAme = $this->session->userdata('user_full_name');
	            $this->email->from($config['smtp_user'],$userNAme);
				$html = $this->load->view('requested_kols/approved_kols',$data1,true);
				
	          	$this->email->message($html);
	          	$this->email->to($analystMangerEmailIds);
	          	$this->email->send();
			}else{
				//Send mail to  Client manager
				$userId = $this->session->userdata('client_id');;
				$managerEmailId = $this->Client_User->getUserManagerEmailId($userId);
				$approverIds	= explode(',',APPROVER_IDS); 
				$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
				$clientMangerEmailIds[]	= $managerEmailId;
	          	$this->email->from($config['smtp_user'],$arrKol['user_name']);
				$this->email->subject(PRODUCT_NAME.': New Profiling Request');
				$baseUrl = base_url().'requested_kols/show_client_requested_kols';
				$target = "_NEW";
				$this->email->message("<p>
										Hello,</p><p>
										
										There are new KOL Profile content curation requests pending your approval. 
										The profiling requests will be processed by Aissel Content team once you approve the requests. To approve/reject the requests, please click on the link below and login to KOLM.</p>
										<p>
										<p><a title='Requested KOL'S' href='".$baseUrl."'login target='".$target."'>Requested KOL'S</a><p>
										<p>
										<p>Thanks,<br /></p>
									  <p>KOLM Support</p>");
	          
	          	$this->email->to($clientMangerEmailIds);
	          	$this->email->send();
	          	
	          	//Send mail to  Client manager
	          	//$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	          	//$this->email->from(USER,$arrKol['user_name']);
				//$this->email->message("<p>Clinet1 user has submitted ".$arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name']."  kol for processing please approve it.</p>");
	          	//$this->email->to($analystMangerEmailId[0]);
	          	//$this->email->send();
	          	
	          	//Send mail to  User
	          	$userEmail = $this->session->userdata('email');
	          	$userRoleId = $this->session->userdata('user_role_id');
	         	if(!$this->isApprover){
		          	$this->email->subject(PRODUCT_NAME.': New Profiling Request');
		          	$this->email->from($config['smtp_user'],$arrKol['user_name']);
					$this->email->message("<p>Hello,</p><p>
											Your request for KTL Profile content curation has been sent to your Manager for approval and will be processed once approved.
										  </p>
										  <p>KTL Name<p>
										  <li>".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name'])."</li>
										  <p>Thanks,</p>
										  <p>KOLM Support</p>
										  ");
		          	$this->email->to($userEmail);
		          	$this->email->send();
	         	}
			}
			
			         	
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function list_pre_requested_kols(){
		$this->common_helpers->checkUsers();
		$clientId = $this->session->userdata('client_id');
		$status = PRENEW;
		$arrKolDetailResult = $this->requested_kol->getNonProfiledKols($status,$clientId);
	
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
   	 	
   	 	// To show the pubmed and CT Links for Autorised users right now for user id=5
   	 	$data['user_id'] = $this->session->userdata('user_id');
   	 	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		// Get the list of Specialties
		$this->load->model('Specialty');
		$arrSpecialties	= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
				
		$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'kols/list_pre_requested_kols';
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List Requested Kols Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List Requested Kols Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	function updete_client_pre_kol_by_analyst(){
		$arrKol['id']            =  $this->input->post('kol_id');
		$arrKol['salutation']	 =	$this->input->post('salutation');
    	$arrKol['first_name']	 =	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 =	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     =	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 =	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']     =	$this->input->post('specialty');
		$arrKol['npi_num']        =	$this->input->post('npi_num'); 
       	$arrKol1['name']        =	$this->input->post('org_id'); 
      
        if($arrKol1['name'] !=''){
           	$arrKol1['status'] = "Requested";
           	// org type
           	$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']= $this->organization->saveOrganization($arrKol1);
		}
		
		$arrKol['country_id']      	 =	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']        =	$this->input->post('city_id');
       	
       	$arrKol['title']     =	$this->input->post('title');
       	$arrKol['division']        =	$this->input->post('division');
       	$arrKol['is_pubmed_processed']        =	0;
		$arrKol['modified_by']	 = 	$this->loggedUserId;
		$arrKol['modified_on']	 =	date("Y-m-d H:i:s");
		$arrKol['status']	 =	New1;
		$kolId = $arrKol['id'];
		if($this->requested_kol->updateClientPreKol($arrKol)){
			$updateData['id'] 	=  $kolId;  
       		$updateData['pin'] 	=  $kolId;  
       		$this->kol->updateKol($updateData);
       		$data['status'] = 'Saved';
		}else{
			$data['status'] = 'Not Saved ';
		}
		
	}
	function list_requested_kols_grid(){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrKolDetailResult = $this->kol->getRequestedKolDetail();
		$data				= array();
		$arrKolDetailResult1= array();
		foreach($arrKolDetailResult as $row){
			if($row['approved_by']!=''){
				$row['approved_by']	= $this->Client_User->getUserNameById($row['approved_by']);
			}
			$arrKolDetailResult1[]	= $row;
		}
		$data['arrKol']			= $arrKolDetailResult1;
   	 	// To show the pubmed and CT Links for Autorised users right now for user id=5
   	 	$data['user_id']		= $this->session->userdata('user_id');
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		$this->load->model('Specialty');
		$arrSpecialties			= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
		$data['clientUser'] 	= $this->Client_User->getUserDetail($this->session->userdata('user_id'));
		$arrMembershipResult 	= array();
		$data					= array();
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
	       foreach($arrKolDetailResult1 as $row){
	       		$row['kol_name'] = $arrSalutations[$row['salutation']]." ".$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']);
	       		$row['specialty'] = $arrSpecialties[$row['specialty']];
	       		$row['user_full_name'] = $row['user_first_name']." ".$row['user_last_name'];
	       		if($row['status']!=APPROVED){
	       			$row['approved_by']='';
	       		}
	       		
	       		$requestedKols[] = $row;
	       }
			$count				= sizeof($requestedKols);				
			if( $count >0 ){ 
				$total_pages    = ceil($count/$limit); 
			}else{ 
				$total_pages 	= 0; 
			} 
			$data1['records'] 	= $count;
			$data1['total']  	= $total_pages;
			$data1['page']	 	= $page;				
			$data1['rows']    	= $requestedKols;  
			//pr($arrKolDetailResult1);
			echo json_encode($data1);
	}
	
	function list_not_requested_kols_grid(){
		ini_set('memory_limit','-1');
		$clientId	=	$this->session->userdata('client_id');
		$page		= $_REQUEST['page']; // get the requested page 
		$limit 		= $_REQUEST['rows']; // get how many rows we want
		$sidx 		= $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord 		= $_REQUEST['sord']; // get the direction
//		if(!$sidx) $sidx =1;
//		
		$filterData=$_REQUEST['filters'];
//		echo $page." - ".$limit." - ".$sidx." - ".$sord;
//		echo $filterData;
//		pr($filterData);
		
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
//		pr($arrFilter);
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];		
		}
//		$searchGroupOperator=$searchGroupOperator[0];
//		pr($whereResultArray);
//		exit();
		
//		ini_set('memory_limit','-1');
//		$page					= (int)$this->input->post('page'); // get the requested page 
//		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
//		$clientId				= $this->session->userdata('client_id');
		//$status 				= PRENEW; $limit,$start,true,$sidx,$sord,$whereResultArray
		
		$status 				= array(PRENEW,REQUESTED,New1,REJECT,RE_REQUEST,APPROVED,PROFILING,REVIEW);
		$count					 = $this->requested_kol->getNonProfiledKols($status,$clientId,$limit,$start,true,$sidx,$sord,$whereResultArray);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit); 
		} else { 
			$total_pages = 0; 
		} 
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
		
		$arrKolDetailResult		 = $this->requested_kol->getNonProfiledKols($status,$clientId,$limit,$start,false,$sidx,$sord,$whereResultArray);
		$data					= array();
		$arrKolDetail			= array();
		$data['arrKol']			= $arrKolDetailResult;
   	 	// To show the pubmed and CT Links for Autorised users right now for user id=5
   	 	$data['user_id'] 		= $this->session->userdata('user_id');
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		$data['clientUser'] 	= $this->Client_User->getUserDetail($this->session->userdata('user_id'));
		foreach($arrKolDetailResult as $row){
       		/* if($row['salutation']!=0){
				$row['kol_name']	 = $arrSalutations[$row['salutation']]." ".$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
				$row['kol_name']	 = '<a target="_NEW" href="'.base_url().'kols/view/'.$row['kol_id'].'">'.$arrSalutations[$row['salutation']]." ".$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
       		}else{
       			$row['kol_name']	 = '<a target="_NEW" href="'.base_url().'kols/view/'.$row['kol_id'].'">'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
       		} */
			$row['request_profile'] = 0;
			$row['user_full_name'] 	= ucwords($row['user_first_name']." ".$row['user_last_name']);
			$row['kol_name']		 = trim($arrSalutations[$row['salutation']]." ".$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']));
			$row['k_name']		 = trim($this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']));
			if($row['status']==New1){
				$row['status']=REQUESTED;
			}
			if($row['status']==PRENEW || $row['status']==REJECT){
				$row['kol_name']	 = '<a target="_NEW" href="'.base_url().'kols/view/'.$row['kol_id'].'">'.$row['kol_name'].'</a>';
			}
			if($row['status']==PRENEW || $row['status']==REJECT){
				$row['request_profile'] = 1;
       			//$row['request_profile'] = '<button onclick="addNewKolProfile('.$row['kol_id'].')">Request Profile</button>';
			}else{
				$row['request_profile'] = '';
			}
       		if($row['client_id']==INTERNAL_CLIENT_ID){
       			$row['user_full_name']= "Aissel Analyst";
       		}
       		$requestedKols[] = $row;
		}
//		if($sidx == 'kol_name'){
//			$this->sortaasort($requestedKols,"k_name",$sord);
//		}
//		if($sidx == 'user_full_name'){
//			$this->sortaasort($requestedKols,"user_full_name",$sord);
//		}
//		pr($requestedKols);
//		exit();
		$data1['records'] 	= $count;
		$data1['total']  	= $total_pages;
		$data1['page']	 	= $page;				
		$data1['rows']    	= $requestedKols;  
		//pr($arrKolDetailResult1);
		ob_start('ob_gzhandler');
		echo json_encode($data1);
	}
	
	function add_my_customer_kol(){
		$data['arrKols'] = '';
		$arrSpecialties	= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
 		
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$data['arrCountry']=$this->Country_helper->listCountries();
		$this->load->view('mycustomers/add_my_customer_kol',$data);
	}
	
	function save_my_customer_kol(){
		$arrKol['salutation']	 =	$this->input->post('salutation');
    	$arrKol['first_name']	 =	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 =	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     =	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 =	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']     =	$this->input->post('specialty');
		$arrKol['npi_num']     		=	$this->input->post('npi_num'); 
		$arrKol['primary_phone']	=	ucwords(trim($this->input->post('primary_phone')));
    	$arrKol['primary_email']	=	trim($this->input->post('primary_email'));
   		$arrKol['fax']     =	$this->input->post('fax');
		$arrKol['address1']        =	$this->input->post('address1'); 
       	$arrKol1['name']        =	$this->input->post('org_id'); 
      
        if($arrKol1['name'] !=''){
           	$arrKol1['status'] = "Requested";
           	// org type
           	$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']= $this->organization->saveOrganization($arrKol1);
		}
		
		$arrKol['country_id']      	 =	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']        =	$this->input->post('city_id');
       	
       	$arrKol['title']     =	$this->input->post('title');
       	$arrKol['division']        =	$this->input->post('division');
       	$arrKol['is_pubmed_processed']        =	1;
		$arrKol['created_by']	 = 	$this->loggedUserId;
		$arrKol['created_on']	 =	date("Y-m-d H:i:s");
		$arrKol['status']	 =	PRENEW;
		$arrKol['profile_type'] = 'Basic';
       	//ending post details
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$kolId = $this->kol->saveKol($arrKol);
       	if($kolId){ 
       		$updateData['id'] 	=  $kolId;  
       		$updateData['pin'] 	=  $kolId;  
       		$this->kol->updateKol($updateData);
          	//$this->session->set_flashdata('message','New Kol Saved Sucessfully');
          	$arrKol['kol_name'] = "<a target='_NEW' href='".base_url()."kols/view/".$kolId."'>".$arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name'])."</a>";
       		if($arrKol['specialty']!=0){
       			$arrKol['specialty'] = $this->Specialty->getSpecialtyById($arrKol['specialty']);
			}else{
				$arrKol['specialty']='';
			}
			$arrKol['country'] = $this->Country_helper->getCountryById($arrKol['country_id']);
          	$arrKol['user_name'] = $this->session->userdata('user_name');
          	$arrKol['user_full_name'] = $this->session->userdata('user_full_name');
          	$clientId = $this->session->userdata('client_id');
      	 	if($clientId==INTERNAL_CLIENT_ID){
	       			$arrKol['user_full_name'] ='Aissel Analyst';
	       			
	       		}
          	
          	$arrKol['request_profile'] = '<button onclick="addNewKolProfile('.$kolId.')">Request</button>';
          	$arrKol['kol_id'] = $kolId;
          		$arrKol['approved_by'] = '';
          	if($arrKol1['name'] !=''){
          		$arrKol['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
          	}
          	$data['arrKol'] = $arrKol;
          	$data['saved'] = true;
          	$data['msg'] ='New KOL Saved Sucessfully';
       	}else{
       		$data['saved'] = false;
       		$data['msg'] = "This KOL is already present in the database.";
         	
       	}
          
       	echo json_encode($data);
	}
	
	function edit_my_customer($kolId){
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrCountry']				=	$this->Country_helper->listCountries();
		$arrStates 						= array();
		$arrCities						= array();
		if($arrKolDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
		}
		if($arrKolDetail['state_id'] 	!= 0){
			$arrCities 					= $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
		}
		$data['arrStates']				= $arrStates;
		$data['arrCities']				= $arrCities;
		
		$this->load->model('Specialty');
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']			= $arrSpecialties;
		if($arrKolDetail['org_id']!=0){
			$arrKolDetail['org_name'] = $this->organization->getOrgNameByOrgId($arrKolDetail['org_id']);
		}
		$data['arrKols'] = $arrKolDetail;
		$data['kolId'] = $kolId;
		$this->load->view('mycustomers/add_my_customer_kol',$data);
	
	}
	
	function update_my_customer_kol(){
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;	
		$arrKol['id']	 =	$this->input->post('kol_id');
		$arrKol['salutation']	 =	$this->input->post('salutation');
    	$arrKol['first_name']	 =	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 =	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     =	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 =	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']     =	$this->input->post('specialty');
		$arrKol['npi_num']        =	$this->input->post('npi_num'); 
		$arrKol['primary_phone']     =	ucwords(trim($this->input->post('primary_phone')));
    	$arrKol['primary_email']      	 =	trim($this->input->post('primary_email'));
   		$arrKol['fax']     =	$this->input->post('fax');
		$arrKol['address1']        =	$this->input->post('address1');
       	$arrKol1['name']        =	$this->input->post('org_id'); 
        if($arrKol1['name'] !=''){
           	$arrKol1['status'] = "Requested";
           	// org type
           	$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']= $this->organization->saveOrganization($arrKol1);
		}
		
		$arrKol['country_id']      	 =	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']        =	$this->input->post('city_id');
       	
       	$arrKol['title']     =	$this->input->post('title');
       	$arrKol['division']        =	$this->input->post('division');
       	$arrKol['is_pubmed_processed']        =	1;
		$arrKol['modified_by']	 = 	$this->loggedUserId;
		$arrKol['modified_on']	 =	date("Y-m-d H:i:s");
		
		
       	//ending post details
		$kolId = $arrKol['id'];
		$this->kol->updateKol($arrKol);
          $arrKol['kol_name'] = "<a href='".base_url()."kols/view/".$kolId."'>".$arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name'])."</a>";
       	if($arrKol['specialty']!=0){
       		$arrKol['specialty'] = $this->Specialty->getSpecialtyById($arrKol['specialty']);
		}else{
			$arrKol['specialty']='';
		}
		
		$arrKol['country'] = $this->Country_helper->getCountryById($arrKol['country_id']);
		$arrKol['user_name'] = $this->session->userdata('user_name');
		$arrKol['user_full_name'] = $this->session->userdata('user_full_name');
		$clientId = $this->session->userdata('client_id');
		if($clientId==INTERNAL_CLIENT_ID){
			$arrKol['user_full_name'] ='Aissel Analyst';
		}
          $arrKol['kol_id'] = $kolId;
          $arrKol['approved_by'] = '';
          if($arrKol1['name'] !=''){
          	$arrKol['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
          }
          $data['arrKol'] = $arrKol;
          $data['saved'] = true;
          $data['msg'] ='Updated Sucessfully';
       	
          
       	echo json_encode($data);
	}
	
	/**
	 * Update the KOL Status and send Mail to Users
	 * @author Ramesh B
	 * @version otsuka 1.0.7
	 * @since Dec 8 2012
	 * @param 
	 * @return
	 * 
	 */
	function update_status_analyst(){
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');

		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		$requestStatusKol = '';
		if($arr['status']==COMPLETED){
		    $requestStatusKol = 8;
			$status = STATUS_COMPLETED;
		}
		
		if($arr['status']==APPROVED){
		    $requestStatusKol = 3;
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
		}
		
		if($arr['status'] == PROFILING){
		    $requestStatusKol = 4;
			$status = STATUS_PROFILING;
		}
		if($arr['status'] == REVIEW){
		    $requestStatusKol = 5;
			$status = STATUS_REVIEW;
		}
		if($arr['status'] == New1){
		    $requestStatusKol = 1;
			$status = STATUS_NEW;
		}
		$arr['request_status'] = $requestStatusKol;
		$this->kol->updateStatus($arr);
		foreach($arr['kolId'] as $kolId){
			$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $kolId,$status);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => "Updated ".lang('HCP')." Profile Request to ".$arr['status']." for ".$kolId,
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Kol',
			    'kols_or_org_id' => $kolId,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => lang('HCP')." Profile Requested for ".$arr['status']."to ".$kolId,
			    'parent_object_id' =>   $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
		}
		if($arr['status']==COMPLETED){
			$arrUsers = $this->align_user->getRquetsterOfKol($arr['kolId']);
			foreach($arrUsers as $row){
				//$this->align_user->assignKolsToUser($row);
			}
		}
		
	}
	function request_kol_profile($kolId=0){
		$this->isApprover	= IS_APPROVER;
		$dataFound	= false;
		$data['msg'] = "Error in requesting profile";
		$data['saved'] = false;
		$arrKol	= array();
		if($kolId==0){
			$arrData = $this->session->flashdata('arrData');
			$dataFound	= true;
			//if($arrData['kol_id']==0){
				$arrKol['first_name']	 	=	ucwords(trim($arrData['first_name']));
				$arrKol['middle_name']	 	=	ucwords(trim($arrData['middle_name']));
				$arrKol['last_name']     	=	ucwords(trim($arrData['last_name']));
				$orgDetails['name']        	=	ucwords(trim($arrData['org_name']));
				if($orgDetails['name'] !=''){
					$orgDetails['status']	= "Requested";
					// org type
					$orgDetails['profile_type'] = BASIC;
					$arrKol['org_id']	= $this->organization->saveOrganization($orgDetails);
				}
				$arrKol['country_id']	=	$arrData['country_id'];
				$arrKol['state_id']     =	$arrData['state_id'];
				$arrKol['city_id']      =	$arrData['city_id'];
				$arrKol['is_pubmed_processed']        =	1;
				$arrKol['created_by']	 = 	$this->loggedUserId;
				$arrKol['created_on']	 =	date("Y-m-d H:i:s");
				$arrKol['status']		 =	New1;
				$arrKol['request_status'] = 1;
				//$arrKol['profile_type'] = 'Full Profile';
				
				//if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
				if($this->isApprover){
					$arrKol['status']		 =	APPROVED;
					$arrKol['request_status'] = 3;
				}
				//Save KOL and Get Id
				$kolId = $this->kol->saveKolNoDuplicateCheck($arrKol);
				/* if($kolId){
					//Update pin as kolid
					$updateData['id'] 			=  $kolId;
					$updateData['pin'] 			=  $kolId;
					$updateData['profile_type'] =  'Full Profile';
					$this->kol->updateKol($updateData);
				} */
			//}else{
				// is KOL profile with modified values while adding survey data
			//	$arrKol	= $arrData;
			//	$kolId	= $arrData['id'];
			//}
		}else if($kolId>0){
			$arrKol	=$this->kol->editKol($kolId);
			/* if($kolId){
				//Update pin as kolid
				$updateData['id'] 			=  $kolId;
				$updateData['pin'] 			=  $kolId;
				$updateData['profile_type'] =  'Full Profile';
				$this->kol->updateKol($updateData);
			} */
			$dataFound	= true;
		}
		if($dataFound){
			$arrUpdateKol['id'] 			=  $kolId;
// 			$arrUpdateKol['pin'] 			=  $kolId;
			//$arrUpdateKol['profile_type'] =  'Full Profile';
			$arrUpdateKol['id']	=	$kolId;
			$arrUpdateKol['is_pubmed_processed']	=	1;
			$arrUpdateKol['status']		=	New1;
			$arrUpdateKol['request_status'] = 1;
			if($this->isApprover){
				$arrUpdateKol['status']	=	APPROVED;
				$arrUpdateKol['request_status'] = 3;
			}
			$this->requested_kol->updateClientPreKol($arrUpdateKol);
			//Save Profile Request
			$userRequest = array();
			$userRequest['kol_id'] = $kolId;
			$userRequest['requested_by'] = $this->loggedUserId;
			$userRequest['requested_on'] = date("Y-m-d H:i:s");
			$userRequest['status']		 =	New1;
			if($this->isApprover){
				$userRequest['status']		 =	APPROVED;
				$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
				$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
			}
			$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
			$userRequest['profile_type'] = 'Full Profile';
			$isSaved = $this->requested_kol->save($userRequest);
			$arrLogDetails = array(
			    'type' => ADD_RECORD,
			    'description' => lang('HCP').' Profile Request for '.$userRequest['status'],
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Kol',
			    'kols_or_org_id' => $kolId,
			    'transaction_id' =>  $isSaved,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => lang('HCP').' Profile Request for '.$userRequest['status'],
			    'parent_object_id' =>   $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
			$data['msg'] = "Request saved succefully";
			$data['saved'] = true;
			$data['is_manager'] = false;
			if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
				$data['is_manager'] = true;
			
			$rowData = array();
			$rowData['id'] =  $isSaved;
			$rowData['kol_id'] = $userRequest['kol_id'];
			$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);;
			$rowData['org_name'] = $arrKol['org_id'];
			$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
			$rowData['status'] = $userRequest['status'];
			$rowData['user_full_name'] = $this->session->userdata('user_full_name');
			$data['arrKol'] = $rowData;
			
			//Send mails
			$mailSent = $this->send_user_request_mails($arrKol);
			if(!$mailSent){
				$data['msg'] = "Error in sending mail";
				$data['saved'] = false;
			}
		}
		echo json_encode($data);
	}
	function request_profile($arrData){
		$this->isApprover	= IS_APPROVER;
		//Prepare KOL details
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrKol['salutation']	=	$arrData['salutation'];
		$arrKol['suffix']     =	ucwords(trim($arrData['suffix']));
		$arrKol['first_name']	=	ucwords(trim($arrData['first_name']));
		$arrKol['middle_name']=	ucwords(trim($arrData['middle_name']));
		$arrKol['last_name']  =	ucwords(trim($arrData['last_name']));
		$arrKol['specialty']	=	$arrData['specialty'];
		$arrKol['fax']		=	$arrData['fax'];
		$arrKol['address1']   =	$arrData['address1'];
		$arrKol['npi_num']    =	$arrData['npi_num'];
		$arrKol['title']     	=	$arrData['title'];
		$arrKol['division']   =	$arrData['division'];
		$arrKol['primary_phone']	=	ucwords(trim($arrData['primary_phone']));
		$arrKol['primary_email']	=	trim($arrData['primary_email']);
		$orgDetails['org_name']   	=	$arrData['org_name'];
		if($orgDetails['name'] !=''){
			$orgDetails['status']	= "Requested";
			// org type
			$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']	= $this->organization->saveOrganization($orgDetails);
		}
		$arrKol['country_id']	=	trim($arrData['country_id']);
		$arrKol['state_id']     =	$arrData['state_id'];
		$arrKol['city_id']      =	$arrData['city_id'];
		$arrKol['profile_type'] =	$this->input->post('profile_type');
		$arrKol['is_pubmed_processed']        =	1;
		$arrKol['created_by']	 = 	$this->loggedUserId;
		$arrKol['created_on']	 =	date("Y-m-d H:i:s");
		$arrKol['status']		 =	New1;
		if($this->isApprover)
			$arrKol['status']		 =	APPROVED;
		//Save KOL and Get Id
		$kolId = $this->kol->saveKolNoDuplicateCheck($arrKol);
		if($kolId){
			//Update pin as kolid
			$updateData['id'] 			=  $kolId;
			$updateData['pin'] 			=  $kolId;
			$this->kol->updateKol($updateData);
		}
		//Save Profile Request
		$userRequest = array();
		$userRequest['kol_id'] = $kolId;
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}
		$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
		$userRequest['profile_type'] = $this->input->post('profile_type');
		$isSaved = $this->requested_kol->save($userRequest);
		$arrLogDetails = array(
		    'type' => ADD_RECORD,
		    'description' => "New ".lang('HCP')." Profile Request",
		    'status' => STATUS_SUCCESS,
		    'kols_or_org_type' => 'Kol',
		    'kols_or_org_id' => $kolId,
		    'transaction_id' =>  $isSaved,
		    'transaction_table_id' => USER_REQUESTS,
		    'transaction_name' => lang('HCP')." Profile Requested",
		    'parent_object_id' =>   $kolId
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
			
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['kol_id'] = $userRequest['kol_id'];
		$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
		$rowData['org_name'] = $this->input->post('org_id');
		if($arrKol['profile_type'] == '')
			$arrKol['profile_type'] = 'Basic';
		if($arrKol['profile_type'] == 'Basic Plus')
			$arrKol['profile_type'] = 'Basic+';
		if($arrKol['profile_type'] == 'Full Profile')
			$arrKol['profile_type'] = 'Full';
		if($userRequest['request_for'] == REQUEST_TYPE_PROFILE)
			$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
		else
			$rowData['request_for'] = 'Upgrade - '.ucwords($arrKol['profile_type']);
		$rowData['status'] = $userRequest['status'];
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		$data['arrKol'] = $rowData;
		
		//Send mails
		$mailSent = $this->send_user_request_mails($arrKol);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
		echo json_encode($data);
	}
	function save_profile_request(){
		$this->isApprover	= IS_APPROVER;
		//Prepare KOL details
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrKol['salutation']	 	=	$this->input->post('salutation');
    	$arrKol['first_name']	 	=	ucwords(trim($this->input->post('first_name')));
   		$arrKol['middle_name']	 	=	ucwords(trim($this->input->post('middle_name')));
    	$arrKol['last_name']     	=	ucwords(trim($this->input->post('last_name')));
    	$arrKol['suffix']      	 	=	ucwords(trim($this->input->post('suffix')));
   		$arrKol['specialty']		=	$this->input->post('specialty');
		$arrKol['primary_phone']	=	ucwords(trim($this->input->post('primary_phone')));
    	$arrKol['primary_email']	=	trim($this->input->post('primary_email'));
   		$arrKol['fax']				=	$this->input->post('fax');
		$arrKol['address1']        	=	$this->input->post('address1');
		$arrKol['npi_num']        	=	$this->input->post('npi_num');
		$arrKol['profile_type'] =	$this->input->post('profile_type');
		
		$orgDetails['name']        	=	$this->input->post('org_id');
		$korg_id = '';
        if($orgDetails['name'] !=''){
           	$orgDetails['status']	= "Requested";
           	// org type
           	$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']	= $this->organization->saveOrganization($orgDetails);
			$korg_id = $arrKol['org_id'];
		}
		
		$arrKol['country_id']	=	trim($this->input->post('country_id'));
   		$arrKol['state_id']     =	$this->input->post('state_id');
       	$arrKol['city_id']      =	$this->input->post('city_id');
		$arrKol['title'] = ucwords(trim($this->input->post('title')));
       	if($arrKol['title']!=''){
       	    $arrKol['title'] = $this->kol->saveTitle($arrKol['title']); // save title if not exists / if exsits get id
       	}
       	$arrKol['division']     =	$this->input->post('division');
			
		//Check is the name exists in 'Not Requested' status lists, if yest then, update the same and use the same ID
		$notRequestedProfile = $this->kol->isNotRequestedProfileExists($arrKol);
		if($notRequestedProfile != false){
			$kolId = $notRequestedProfile['id'];
			$updateData = array();
			//Get the aditional information given if any
			if($arrKol['middle_name'] != '' && $notRequestedProfile['middle_name'] == '')
				$updateData['middle_name'] = $arrKol['middle_name'];
			if($arrKol['title'] != '' && $notRequestedProfile['title'] == '')
				$updateData['title'] = $arrKol['title'];
			if($arrKol['division'] != '' && $notRequestedProfile['division'] == '')
				$updateData['division'] = $arrKol['division'];
			if($arrKol['primary_phone'] != '' && $notRequestedProfile['primary_phone'] == '')
				$updateData['primary_phone'] = $arrKol['primary_phone'];
			if($arrKol['primary_email'] != '' && $notRequestedProfile['primary_email'] == '')
				$updateData['primary_email'] = $arrKol['primary_email'];
			if($arrKol['address1'] != '' && $notRequestedProfile['address1'] == '')
				$updateData['address1'] = $arrKol['address1'];
			if($arrKol['fax'] != '' && $notRequestedProfile['fax'] == '')
				$updateData['fax'] = $arrKol['fax'];
			if($arrKol['npi_num'] != '' && $notRequestedProfile['npi_num'] == '')
				$updateData['npi_num'] = $arrKol['npi_num'];
			if($arrKol['org_id'] != '' && $arrKol['org_id']!= null && $notRequestedProfile['org_id'] == null)
				$updateData['org_id'] = $arrKol['org_id'];
			if($arrKol['country_id'] != '' && $arrKol['country_id'] != 0 && $notRequestedProfile['country_id'] == 0)
				$updateData['country_id'] = $arrKol['country_id'];
			if($arrKol['state_id'] != '' && $arrKol['state_id'] != 0 && $notRequestedProfile['state_id'] == 0)
				$updateData['state_id'] = $arrKol['state_id'];
			if($arrKol['city_id'] != '' && $arrKol['city_id'] != 0 && $notRequestedProfile['city_id'] == 0)
				$updateData['city_id'] = $arrKol['city_id'];
				
			//update with new status
			$updateData['id'] 			=  $kolId;
			$updateData['specialty']  	=	$arrKol['specialty']; 
			$updateData['status']		 =	New1;
			$updateData['request_status'] =	1;
			if($this->isApprover){
			    $updateData['request_status'] =	3;
				$updateData['status']		 =	APPROVED;
			}
			$updateData['modified_by']	 = 	$this->loggedUserId;
			$updateData['modified_on']	 =	date("Y-m-d H:i:s");
			
       		$this->kol->updateKol($updateData);
		}else{
		    $key_people_id	 	=	$this->input->post('key_people_id');
		    if(!empty($key_people_id)){
		      $arrKol['key_people_id'] =  $key_people_id;
		    }
		    $arrKol['org_id'] = $this->input->post('org_id');
		    $arrKol['profile_type'] =	USER_ADDED;
	       	$arrKol['is_pubmed_processed']        =	1;
			$arrKol['created_by']	 = 	$this->loggedUserId;
			$arrKol['created_on']	 =	date("Y-m-d H:i:s");
			$arrKol['status']		 =	New1;
			$arrKol['request_status'] = 1;
			if($this->isApprover){
				$arrKol['status']		 =	APPROVED;
				$arrKol['request_status'] = 3;
			}	
			//Save KOL and Get Id
			$kolId = $this->kol->saveKolNoDuplicateCheck($arrKol);
			$this->save_kol_client_association($kolId,'fromKol');
			
			$dataType = 'User Added';
			$client_id =$this->session->userdata('client_id');
			if($client_id == INTERNAL_CLIENT_ID){
			    $dataType = 'Aissel Analyst';
			}
			//Assign User
			$arrData = array();
			$arrData['created_by'] = $this->loggedUserId;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			$arrData['user_id'] = $this->loggedUserId;
			$arrData['kol_id'] = $kolId;
			$arrData['data_type_indicator'] = $dataType;
			$arrData['type'] = 1;
			$saveAssignId = $this->kol->saveAssignClient($arrData);
			
			if($kolId){		    
			    if($this->input->post('country_id')!=''){
			        $arrLocationData = array();
			        $arrLocationData['org_institution_id'] = $this->input->post('org_id');
			        $arrLocationData['address1'] =$this->input->post('address1');
			        $arrLocationData['address2'] =$this->input->post('address2');
			        $arrLocationData['division'] = $arrKol['division'];
			        $arrLocationData['title'] = $arrKol['title'];
			        $arrLocationData['validation_status'] = '';
			        $arrLocationData['address_type'] = $this->input->post('org_address_type');
			        $arrLocationData['country_id']	=	trim($this->input->post('country_id'));
			        $arrLocationData['state_id']     =	$this->input->post('state_id');
			        $arrLocationData['city_id']      =	$this->input->post('city_id');
			        $arrLocationData['postal_code'] = $this->input->post('postal_code');
			        $arrLocationData['is_primary'] = 1;
			        $arrLocationData['phone_type'] = $this->input->post('primary_phone_type');
			        $arrLocationData['phone_number'] = $this->input->post('primary_phone');
			        $arrLocationData['created_by'] = $this->loggedUserId;
			        $arrLocationData['created_on'] = date('Y-m-d H:i:s');
			        $arrLocationData['modified_by'] = $this->loggedUserId;
			        $arrLocationData['modified_on'] = date('Y-m-d H:i:s');
			        $arrLocationData['kol_id'] = $kolId;
			        $dataType = 'User Added';
			        $client_id =$this->session->userdata('client_id');
			        if($client_id == INTERNAL_CLIENT_ID){
			            $dataType = 'Aissel Analyst';
			        }
			        $arrLocationData['data_type_indicator'] = $dataType;
			        $lastLocId = $this->kol->saveKolLocation($arrLocationData); // insert in kol_location
			        $arrLogDetails = array(
			            'type' => ADD_RECORD,
			            'description' => 'Save Location',
			            'status' => STATUS_SUCCESS,
			            'kols_or_org_type' => 'Kol',
			            'kols_or_org_id' => $kolId,
			            'transaction_id' =>  $lastLocId,
			            'transaction_table_id' => KOL_LOCATIONS,
			            'transaction_name' => "Save Location",
			            'parent_object_id' =>  $kolId
			        );
			        $this->config->set_item('log_details', $arrLogDetails);
			        log_user_activity(null,true);
			    }
			    if($arrKol['primary_email']!=''){
			        $arrEmailData = array();
			        $arrEmailData['type'] = 'Work';
			        $arrEmailData['email'] = $arrKol['primary_email'];
			        $arrEmailData['is_primary'] = 1;
			        $arrEmailData['contact'] = $kolId;
			        $arrEmailData['created_by'] = $this->loggedUserId;
			        $arrEmailData['created_on'] = date('Y-m-d H:i:s');
			        $arrEmailData['modified_by'] = $this->loggedUserId;
			        $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
			        $dataType = 'User Added';
			        $client_id =$this->session->userdata('client_id');
			        if($client_id == INTERNAL_CLIENT_ID){
			            $dataType = 'Aissel Analyst';
			        }
			        $arrEmailData['data_type_indicator'] = $dataType;
			        $lastEmailId = $this->kol->saveKolEmails($arrEmailData); // insert in email
			        $arrLogDetails = array(
			            'type' => ADD_RECORD,
			            'description' => 'Save Email',
			            'status' => STATUS_SUCCESS,
			            'kols_or_org_type' => 'Kol',
			            'kols_or_org_id' => $kolId,
			            'transaction_id' => $lastEmailId,
			            'transaction_table_id' => EMAILS,
			            'transaction_name' => 'Save Email',
			            'parent_object_id' => $kolId,
			        );
			        $this->config->set_item('log_details', $arrLogDetails);
			        log_user_activity(null,true);
			    }
			    if(trim($this->input->post('primary_phone'))!=''){
			        $arrPhoneData = array();
			        $arrPhoneData['number'] = trim($this->input->post('primary_phone'));
			        $arrPhoneData['type'] = trim($this->input->post('primary_phone_type'));
			        $arrPhoneData['is_primary'] = 1;
			        $arrPhoneData['contact'] = $kolId;
			        $arrPhoneData['location_id'] = $lastLocId;
			        $arrPhoneData['contact_type'] = "location";
			        $arrPhoneData['created_by'] = $this->loggedUserId;
			        $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
			        $arrPhoneData['modified_by'] = $this->loggedUserId;
			        $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
			        $dataType = 'User Added';
			        $client_id =$this->session->userdata('client_id');
			        if($client_id == INTERNAL_CLIENT_ID){
			            $dataType = 'Aissel Analyst';
			        }
			        $arrPhoneData['data_type_indicator'] = $dataType;
			        $phonLastId = $this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
			        $arrLogDetails = array(
			            'type' => ADD_RECORD,
			            'description' => 'Save Phone',
			            'status' => STATUS_SUCCESS,
			            'kols_or_org_type' => 'Kol',
			            'kols_or_org_id' => $kolId,
			            'transaction_id' =>  $phonLastId,
			            'transaction_table_id' => PHONE_NUMBERS,
			            'transaction_name' => "Save Phone",
			            'parent_object_id' =>   $kolId
			        );
			        $this->config->set_item('log_details', $arrLogDetails);
			        log_user_activity(null,true);
			    }
			     
			    if($arrKol['fax']!=''){
			        $arrPhoneData['is_primary'] = 0;
			        $arrPhoneData['number']=$arrKol['fax'];
			        $arrPhoneData['type'] = 'Fax';
			        $this->kol->saveKolPhones($arrPhoneData); // insert fax in phone_number
			    }
				//Update pin as kolid
				$updateData['id'] 			=  $kolId;  
	       		$updateData['pin'] 			=  $kolId;  
	       		$this->kol->updateKol($updateData);			
	       		
			}
		}
		//Save Profile Request
		$userRequest = array();
		$userRequest['kol_id'] = $kolId;
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}
		$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
		$userRequest['profile_type'] = $this->input->post('profile_type');
		$isSaved = $this->requested_kol->save($userRequest);
		$arrLogDetails = array(
		    'type' => ADD_RECORD,
		    'description' => "New ".lang('HCP')." Profile Request",
		    'status' => STATUS_SUCCESS,
		    'kols_or_org_type' => 'Kol',
		    'kols_or_org_id' => $kolId,
		    'transaction_id' =>  $isSaved,
		    'transaction_table_id' => USER_REQUESTS,
		    'transaction_name' => lang('HCP')." Profile Requested",
		    'parent_object_id' =>   $kolId
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
			
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['kol_id'] = $userRequest['kol_id'];
		$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
		$rowData['org_name'] = $this->input->post('org_id');
		if($arrKol['profile_type'] == '')
       		$arrKol['profile_type'] = 'Basic';
       	if($arrKol['profile_type'] == 'Basic Plus')
       		$arrKol['profile_type'] = 'Basic+';
       	if($arrKol['profile_type'] == 'Full Profile')
       		$arrKol['profile_type'] = 'Full';
       if($userRequest['request_for'] == REQUEST_TYPE_PROFILE)
       		$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
       	else
       		$rowData['request_for'] = 'Upgrade - '.ucwords($arrKol['profile_type']);	
		$rowData['status'] = $userRequest['status'];
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		$data['arrKol'] = $rowData;
		
		//Send mails
		$arrKol['id'] = $kolId;
		$mailSent = $this->send_user_request_mails($arrKol);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
       	echo json_encode($data);
	}
	
	function send_user_request_mails($arrKol){
		$this->isApprover	= IS_APPROVER;
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		//$config['mailtype'] = 'html';
	
		$this->email->set_newline("\r\n");
		$this->email->set_crlf( "\r\n" );
		$clientId = $this->session->userdata('client_id');
          
		//send mail to Analyst Managers if the request is from Client manager
		if($this->isApprover){
			$arr =array();
			$arr[$arrKol['id']] = $this->kol->editKol($arrKol['id']);
			
			$clientId = $this->session->userdata('client_id');
			$clientName = $this->Client_User->getClientName($clientId);
			$data1['clientName'] = $clientName;
			$data1['arrKols'] = $arr;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
	
           	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
           	foreach($analystMangerEmailId as $email=>$ids){
           		$emailIds[]=$ids['email'];
           	}
			//pr($analystMangerEmailId);
			$analystMangerEmailIds = implode(',',$emailIds);
			$this->email->subject(PRODUCT_NAME.': New Profiling Request');
          	$userNAme = $this->session->userdata('user_full_name');
            $this->email->from($config['smtp_user'],$userNAme);
            $arrKol['org_id']			= $this->kol->getOrgId($arrKol['org_id']);
			
			$arrKol['specialty']=$arrSpecialties[$arrKol['specialty']];
            $arrKol['country_name']		= $this->Country_helper->getCountryById($arrKol['country_id']);
				//Getting  the name of the specified 'state'  By passing The Id
			if($arrKol['state_id']!='' && $arrKol['state_id']!=0){
				$arrKol['state_name']			= $this->Country_helper->getStateById($arrKol['state_id']);
			}
			
			if($arrKol['city_id']!='' && $arrKol['city_id']!=0){
				//Getting  the name of the specified 'city'  By passing The Id
				$arrKol['city_name']			= $this->Country_helper->getCityeById($arrKol['city_id']);
			}
			//pr($arrKol);
            $data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
			
          	$this->email->message($html);
          	$this->email->to($analystMangerEmailIds);
          	$this->email->reply_to($analystMangerEmailIds);
          	if($this->email->send()){
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_SUCCESS,
          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  true;
          	}else{
          	    //Log Activity
          	    $arrLogDetails = array(
          	        'description'=>$html,
          	        'type' => LOG_ACTIVITY_EMAIL,
          	        'status' => STATUS_FAIL,
          	        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
          	        'miscellaneous2'=>"To-".$analystMangerEmailIds
          	    );
          	    $this->config->set_item('log_details', $arrLogDetails);
          	    log_user_activity(null,true);
          	    $status	=  false;
          	}
          	$this->email->clear(TRUE);
          	return $status;
		}else{
			//Send mail to  Client manager
			$userId = $this->session->userdata('user_id');
			//$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($userId);
        	$managerEmailId = $this->Client_User->getUserManagerEmailId($userId);
			$approverIds	= explode(',',APPROVER_IDS); 
			$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
			//$clientMangerEmailIds[]	= $managerEmailId;
			$baseUrl = base_url().'requested_kols/show_client_requested_kols';
			$data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'USER_REQUEST_MANAGER';
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);	
			$emailStatus = $this->send_mail($clientMangerEmailIds,$managerEmailId,'New Profiling Request',$html);
          	
          	//Send mail to  User
          	$userEmail = $this->session->userdata('email');
          	$userRoleId = $this->session->userdata('user_role_id');
          	$data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'USER_REQUEST_USER';
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
          	//$this->email->reply_to($userEmail);
			$emailStatus = $this->send_mail($userEmail,'','New Profiling Request',$html);
			return $emailStatus;
		}
	}
	function send_mail($receipients,$additionalemailids,$subject,$html){
	    $to    = $receipients;
	    if(!is_array($receipients)){
	        $to  = explode(",",$receipients);
	    }
	    $managerEmailId    = $additionalemailids;
	    if(!is_array($additionalemailids)){
	        $managerEmailId  = explode(",",$additionalemailids);
	    }
	    $emailDescription = "To- ".implode(",",$to)."<br/> CC- ".implode(",",$managerEmailId);
	    $userNAme = $this->session->userdata('user_full_name');
	    $config = email_config_initializer('profile_request');
	    $this->load->library('email', $config);
	    $this->email->set_newline("\r\n");
	    $this->email->initialize($config);
	    $this->email->set_newline("\r\n");
	    $this->email->from($config['smtp_user'],$userNAme);
	    $this->email->subject(PRODUCT_NAME.': '.$subject); 
	    $this->email->message($html);
	    $this->email->to($to);
	    $this->email->cc($managerEmailId);
	    $this->email->set_crlf("\r\n");
	    //$this->email->reply_to($clientMangerEmailIds);
	    if($this->email->send()){
	        //Log Activity
	        $arrLogDetails = array(
	            'description'=>$html,
	            'type' => LOG_ACTIVITY_EMAIL,
	            'status' => STATUS_SUCCESS,
	            'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	            'miscellaneous2'=>$emailDescription
	        );
	        $this->config->set_item('log_details', $arrLogDetails);
	        log_user_activity(null,true);
	        $status	=  true;
	    }else{
	        //Log Activity
	        $arrLogDetails = array(
	            'description'=>$html,
	            'type' => LOG_ACTIVITY_EMAIL,
	            'status' => STATUS_FAIL,
	            'transaction_name'=>lang('HCP')." Profile Request Email Sent",
	            'miscellaneous2'=>$emailDescription
	        );
	        $this->config->set_item('log_details', $arrLogDetails);
	        log_user_activity(null,true);
	        $status	=  false;
	    }
	    $this->email->clear(TRUE);
	    return $status;
	}
	function check_similar_names($kolId=0){
		$arrData = array();
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		if($kolId>0){
			$arrKol = $this->kol->editKol($kolId);
		}else{
			$arrKol['salutation']	 	=	$this->input->post('salutation');
			$arrKol['first_name']	 	=	ucwords(trim($this->input->post('first_name')));
			$arrKol['middle_name']	 	=	ucwords(trim($this->input->post('middle_name')));
			$arrKol['last_name']     	=	ucwords(trim($this->input->post('last_name')));
			$arrKol['suffix']      	 	=	ucwords(trim($this->input->post('suffix')));
			$arrKol['specialty']		=	$this->input->post('specialty');
		}
		$arrKols = $this->kol->checkSimilarKols($arrKol);
		if(sizeof($arrKols) > 0){
			$arrData['similarKols'] = $arrKols;
			$arrData['arrSalutations'] = $arrSalutations;
			$data['duplicates'] = $this->load->view('requested_kols/show_similar_names',$arrData,true);
			$data['hasDuplicates'] = true;
		}else{
			$data['hasDuplicates'] = false;
		}
		echo json_encode($data);
	}
	
	function save_upgrade_request(){
		$this->isApprover	= IS_APPROVER;
		//Save Upgrade Request
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$userRequest['kol_id'] = $this->input->post('kol_id');
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		if($userRequest['kol_id'] != ''){
			if($this->isApprover){
				$userRequest['status']		 =	APPROVED;
				$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
				$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
			}
			$userRequest['request_for'] = REQUEST_TYPE_UPGRADE;
			$userRequest['profile_type'] = $this->input->post('profile_type');
			$isSaved = $this->requested_kol->save($userRequest);
			if ($isSaved) {
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Upgrade user request',
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $userRequest['kol_id'],
						'transaction_id' =>  $userRequest['kol_id'],
						'transaction_table_id' => USER_REQUESTS,
						'transaction_name' => 'Upgrade user request',
						'parent_object_id' =>  $userRequest['kol_id']
				);
				$this->config->set_item('log_details', $arrLogDetails);
			}else{
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Upgrade user request',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $userRequest['kol_id'],
						'transaction_id' =>  $userRequest['kol_id'],
						'transaction_table_id' => USER_REQUESTS,
						'transaction_name' => 'Upgrade user request',
						'parent_object_id' =>  $userRequest['kol_id']
				);
				$this->config->set_item('log_details', $arrLogDetails);
			}
			$data['msg'] = "Request saved succefully";
			$data['saved'] = true;
			$data['is_manager'] = false;
			if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
				$data['is_manager'] = true;
				
			//Send mails
			$arrKol = $this->kol->editKol($userRequest['kol_id']);
			$mailSent = $this->send_user_request_mails($arrKol);
			if(!$mailSent){
				$data['msg'] = "Error in sending mail";
				$data['saved'] = false;
			}
			$rowData = array();
			$rowData['id'] =  $isSaved;
	       	$rowData['request_for'] = 'Upgrade';
			$rowData['kol_id'] = $userRequest['kol_id'];
			$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
			$rowData['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
			$rowData['status'] = $userRequest['status'];
			$rowData['user_full_name'] = $this->session->userdata('user_full_name');
			if($userRequest['profile_type'] == '')
       			$userRequest['profile_type'] = 'Basic';
	       	if($userRequest['profile_type'] == 'Basic Plus')
	       		$userRequest['profile_type'] = 'Basic+';
	       	if($userRequest['profile_type'] == 'Full Profile')
	       		$userRequest['profile_type'] = 'Full';
	        if($userRequest['request_for'] == REQUEST_TYPE_PROFILE)
	       		$rowData['request_for'] = 'Profile - '.ucwords($userRequest['profile_type']);
	       	else
	       		$rowData['request_for'] = 'Upgrade - '.ucwords($userRequest['profile_type']);
			$data['arrKol'] = $rowData;
		}else{
			$data['msg'] = "Sorry ! There are no matching KOLs. Please select a name from autocomplete";
			$data['saved'] = false;
		}
		
       	echo json_encode($data);
	}
	
	function list_my_pending_approvals(){
	    $page = (int) $this->input->post('page'); // get the requested page
	    $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$userId = $this->session->userdata('user_id');
		$arrData = $this->requested_kol->listMyPendingApprovals($userId);
		$requestedKols = array();
		$data = array();
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		foreach($arrData as $row){
//			$row['kol_name'] = $arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
			$row['kTL_name'] = $arrSalutations[$row['salutation']]." ".$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$row['kTL_name'] = preg_replace("/[[:blank:]]+/"," ",$row['kTL_name']);
       		$row['specialty'] = $arrSpecialties[$row['specialty']];
       		$row['user_full_name'] = $row['user_first_name']." ".$row['user_last_name'];
       		$row['org_name'] = $row['name'];
       		$row['approve_allow'] = $this->common_helpers->isActionAllowed('profile_request','approve',array("kol_id"=>$row['kol_id'])); 
       		if( $row['is_re_request'] == 1 && $row['status'] == New1)
       			$row['status'] = RE_REQUEST;
       		
       		if($row['profile_type'] == '')
       			$row['profile_type'] = 'Basic';
       		if($row['profile_type'] == 'Basic Plus')
       			$row['profile_type'] = 'Basic+';
       		if($row['profile_type'] == 'Full Profile')
       			$row['profile_type'] = 'Full';
   			if($row['profile_type'] == USER_ADDED)
   			    $row['profile_type'] = USER_ADDED;
       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
       			$row['request_type'] = 'Profile - '.ucwords($row['profile_type']);
       		else
       			$row['request_type'] = 'Upgrade - '.ucwords($row['profile_type']);

       		if($row['requested_on'] != '')	
       			$row['requested_on'] = date("m-d-Y",strtotime($row['requested_on']));
       		if($row['rej_or_appr_on'] != '')
       			$row['approved_/_rejected_on'] = date("m-d-Y",strtotime($row['rej_or_appr_on']));	
			$requestedKols[] = $row;
		}
		$count				= sizeof($requestedKols);				
		if( $count >0 ){ 
			$total_pages    = ceil($count/$limit); 
		}else{ 
			$total_pages 	= 0; 
		} 
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $requestedKols;  
//		exit;
		echo json_encode($data);
	}
	
	function list_all_profile_requests(){
	    $page = (int) $this->input->post('page'); // get the requested page
	    $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrData = $this->requested_kol->listAll();
		$requestedKols = array();
		$data = array();
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		foreach($arrData->result_array() as $row){
//			$row['kol_name'] = $arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
			$row['kTL_name'] = $arrSalutations[$row['salutation']]." ".$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$row['kTL_name'] = preg_replace("/[[:blank:]]+/"," ",$row['kTL_name']);
//        		$row['specialty'] = $arrSpecialties[$row['specialty']];
       		$row['user_full_name'] = $row['user_first_name']." ".$row['user_last_name'];
       		$row['org_name'] = $row['name'];
       		//Add reject reason as title text
       		//if($row['status'] == REJECT)
       			//$row['status'] = "<span class='reject-reason' title='".$row['comments']."'>".$row['status']."</span>";
       		$row['approver_/_rejector']= $row['approver_first_name']." ".$row['approver_last_name'];
       		if($row['status'] == New1){
       			$row['approver_/_rejector']='';
       		}
       		if($row['profile_type'] == '')
       			$row['profile_type'] = 'Basic';
       		if($row['profile_type'] == 'Basic Plus')
       			$row['profile_type'] = 'Basic+';
       		if($row['profile_type'] == 'Full Profile')
       			$row['profile_type'] = 'Full';
       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
       			$row['request_type'] = 'Profile - '.ucwords($row['profile_type']);
       		else
       			$row['request_type'] = 'Upgrade - '.ucwords($row['profile_type']);
       		if ($row ['requested_on'] != '') {
       			$row ['requested_on'] = date ( "m-d-Y", strtotime ( $row ['requested_on'] ) );
       		}
       		if ($row ['rej_or_appr_on'] != '') {
       			$row ['approved_/_rejected_on'] = date ( "m-d-Y", strtotime ( $row ['rej_or_appr_on'] ) );
       		}
			$requestedKols[] = $row;
		}
		$count				= sizeof($requestedKols);				
		if( $count >0 ){ 
			$total_pages    = ceil($count/$limit); 
		}else{ 
			$total_pages 	= 0; 
		} 
		$data['records'] 	= $count;
		$data['total']  	= $total_pages;
		$data['page']	 	= $page;				
		$data['rows']    	= $requestedKols;  
//		pr($data);
//		exit;
		echo json_encode($data);
	}
	
	function approve(){
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arrIds = $this->input->post('arrIds');
		foreach($arrIds as $id){
			$rowData = array();
			$arrRequestData = $this->requested_kol->get($id, 'userRequestId');
			$arrKol = $this->kol->editKol($arrRequestData['kol_id']);
			//Update user request
			$rowData['id'] = $id;
			$rowData['status'] = APPROVED;
			$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
			$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			$isUpdated = $this->requested_kol->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => lang('HCP').' Profile Request update to '.APPROVED,
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Kol',
			    'kols_or_org_id' => $arrRequestData['kol_id'],
			    'transaction_id' =>  $id,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => lang('HCP').' Profile Request update to '.APPROVED,
			    'parent_object_id' =>   $arrRequestData['kol_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
			//Update KOL status
			if($arrRequestData['request_for'] == REQUEST_TYPE_PROFILE && $arrKol['status'] == New1){
				$kolDetails = array();
				$kolDetails['id'] = $arrRequestData['kol_id'];
				$kolDetails['status'] = APPROVED;
				$kolDetails['request_status'] = 3;
				$this->kol->updateKol($kolDetails);
			}
			
			//Send mail to user
			$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
			$data1['requestAction'] = 'MANAGER_APPROVE_USER';
			$data1['arrKol']=	$arrKol;
			$data1['arrRequestData']=	$arrRequestData;
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
			$isMailSent = $this->send_mail($userEmailId,'', 'Profiling Request - Approved', $html); 
			
			$emailIds = array();
			//send mail to Analyst Manager
	       	$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
	       	foreach($analystMangerEmailId as $email=>$ids){
	       		$emailIds[]=$ids['email'];
	        }
			$analystMangerEmailIds = implode(',',$emailIds);
			$data1['requestAction'] = 'MANAGER_APPROVE_ANALYST';
			$arrKol['org_id']			= $this->kol->getOrgId($arrKol['org_id']);
			
			$arrKol['specialty']=$arrSpecialties[$arrKol['specialty']];
			
			
			$arrKol['country_name']		= $this->Country_helper->getCountryById($arrKol['country_id']);
				//Getting  the name of the specified 'state'  By passing The Id
			if($arrKol['state_id']!='' && $arrKol['state_id']!=0){
				$arrKol['state_name']			= $this->Country_helper->getStateById($arrKol['state_id']);
			}
			
			if($arrKol['city_id']!='' && $arrKol['city_id']!=0){
				//Getting  the name of the specified 'city'  By passing The Id
			$arrKol['city_name']			= $this->Country_helper->getCityeById($arrKol['city_id']);
			}
			$data1['arrKol']=	$arrKol;
			//pr($arrKol);
			$data1['arrRequestData']=	$arrRequestData;
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
	        $isMailSent = $this->send_mail($analystMangerEmailIds,'', 'Profiling Request - Approved', $html);
        
		}
		
		$data = array();
		$data['status'] = true;
		$data['approved_by'] = $this->session->userdata('user_full_name');
		echo json_encode($data);
	}
	
	function reject(){
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arrIds = $this->input->post('arrIds');
		$comments = $this->input->post('comments');
		foreach($arrIds as $id){
			//Update request
			$rowData = array();
			$arrRequestData = $this->requested_kol->get($id, 'userRequestId');
			$arrKol = $this->kol->editKol($arrRequestData['kol_id']);
			$rowData['id'] = $id;
			$rowData['status'] = REJECT;
			$rowData['comments'] = $comments;
			$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
			$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			$isUpdated = $this->requested_kol->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => lang('HCP').' Profile Request updated to '.REJECT,
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Kol',
			    'kols_or_org_id' => $arrRequestData['kol_id'],
			    'transaction_id' =>  $id,
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => lang('HCP').' Profile Request updated to '.REJECT,
			    'parent_object_id' =>   $arrRequestData['kol_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			//Update KOL status
			if($arrRequestData['request_for'] == REQUEST_TYPE_PROFILE){
				$kolDetails = array();
				$kolDetails['id'] = $arrRequestData['kol_id'];
				$kolDetails['status'] = REJECT;
				$kolDetails['request_status'] = 9;
				$this->kol->updateKol($kolDetails);
			}
			
			//Send mail
			$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
			$data1['arrKol']=	$arrKol;
			$data1['arrRequestData']=	$arrRequestData;
			$data1['comments'] = $comments;
			$this->email->subject(PRODUCT_NAME.": Profiling Request - Rejected");
			$userNAme = $this->session->userdata('user_full_name');
			$this->email->from($config['smtp_user'],$userNAme); 	
			$data1['requestAction'] = MANAGER_REJECT_USER;
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
			$this->email->message($html);
			$this->email->to($userEmailId);
			if($this->email->send()){
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => LOG_ACTIVITY_EMAIL,
			        'status' => STATUS_SUCCESS,
			        'transaction_name'=>lang('HCP'). "Profile Request Email Sent",
			        'miscellaneous2'=>$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    $status	=  true;
			}else{
			    //Log Activity
			    $arrLogDetails = array(
			        'description'=>$html,
			        'type' => 'Email',
			        'status' => STATUS_FAIL,
			        'transaction_name'=>lang('HCP'). "Profile Request Email Sent",
			        'miscellaneous2'=>$userEmailId
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    $status	=  false;
			}
			$this->email->clear(TRUE);
		}
		$data = array();
		$data['status'] = true;
		$data['approved_by'] = $this->session->userdata('user_full_name');
		echo json_encode($data);
	}
	
	function delete($id){
		$arrRequestData = $this->requested_kol->get($id, 'userRequestId');
		//Delete request
		$isUpdated = $this->requested_kol->delete($arrRequestData['kol_id']);
		
		//Delete KOL
		if($arrRequestData['request_for'] != REQUEST_TYPE_UPGRADE && $arrRequestData['is_re_request'] != 1){
			$this->kol->deleteKol($arrRequestData['kol_id']);
		}
		echo $isUpdated;
	}
	
	function upgrade_request_page(){
		echo $this->load->view('requested_kols/upgrade_request_page');
	}
	
	function update_request_status_analyst(){
		/* $config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');

		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		$requestStatusKol = '';
		if($arr['status']==COMPLETED){
			$status = STATUS_COMPLETED;
			$requestStatusKol = 8;
		}
		
		if($arr['status']==APPROVED){
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
			$requestStatusKol = 3;
		}
		
		if($arr['status'] == PROFILING){
			$status = STATUS_PROFILING;
			$requestStatusKol = 4;
		}
		if($arr['status'] == REVIEW){
			$status = STATUS_REVIEW;
			$requestStatusKol = 5;
		}
		if($arr['status'] == New1){
			$status = STATUS_NEW;
			$requestStatusKol = 1;
		}
		foreach($arr['kolId'] as $id){
			//Update request
			$rowData = array();
			$arrRequestData = $this->requested_kol->get($id,'userRequestId');
			$arrKol = $this->kol->editKol($arrRequestData['kol_id']);
			$rowData['id'] = $arrRequestData['id'];
			$rowData['status'] = $arr['status'];
			if($arr['status'] == APPROVED || $arr['status'] == REJECT){			
				$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
				$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
			}
			$isUpdated = $this->requested_kol->update($rowData);
			$arrLogDetails = array(
			    'type' => EDIT_RECORD,
			    'description' => lang('HCP').' Profile Request updated to '.$arr['status'],
			    'status' => STATUS_SUCCESS,
			    'kols_or_org_type' => 'Kol',
			    'kols_or_org_id' => $arrRequestData['kol_id'],
			    'transaction_id' =>  $arrRequestData['id'],
			    'transaction_table_id' => USER_REQUESTS,
			    'transaction_name' => lang('HCP').' Profile Request updated to '.$arr['status'],
			    'parent_object_id' =>   $arrRequestData['kol_id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
			//Update KOL status
			if(($arrRequestData['request_for'] == REQUEST_TYPE_PROFILE && $arrKol['status'] == New1) || $arr['status'] == COMPLETED ){
				$kolDetails = array();
				$kolDetails['id'] = $arrRequestData['kol_id'];
				$kolDetails['status'] = $arr['status'];
				$kolDetails['request_status'] = $requestStatusKol;
				if($arr['status'] == COMPLETED)
					$kolDetails['profile_type'] = $arrRequestData['profile_type'];
				$this->kol->updateKol($kolDetails);
			}
			
			if($arr['status'] == APPROVED || $arr['status'] == REJECT || $arr['status'] == COMPLETED){
				//Send mail
				$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
				$data1['arrKol']=	$arrKol;
				$data1['arrRequestData']=	$arrRequestData;
// 				$userNAme = $this->session->userdata('user_full_name');
				$userNAme = 'Aissel Analyst';
				$this->email->from($config['smtp_user'],$userNAme);
				if($arr['status'] == APPROVED){
					$this->email->subject(PRODUCT_NAME.': Profiling Request - Approved');
					$data1['requestAction'] = ANALYST_APPROVE_USER;
				}else if($arr['status'] == REJECT){
					$this->email->subject(PRODUCT_NAME.": Profiling Request - Rejected");
					$data1['requestAction'] = ANALYST_REJECT_USER;
				}else if($arr['status'] == COMPLETED){
					$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
					$data1['requestAction'] = ANALYST_COMPLETE_USER;
				}
				$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
				$this->email->message($html);
				$this->email->to($userEmailId);
				if($this->email->send()){
				    //Log Activity
				    $arrLogDetails = array(
				        'description'=>$html,
				        'type' => LOG_ACTIVITY_EMAIL,
				        'status' => STATUS_SUCCESS,
				        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
				        'miscellaneous2'=>$userEmailId
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity(null,true);
				}else{
				    //Log Activity
				    $arrLogDetails = array(
				        'description'=>$html,
				        'type' => 'Email',
				        'status' => STATUS_FAIL,
				        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
				        'miscellaneous2'=>$userEmailId
				    );
				    $this->config->set_item('log_details', $arrLogDetails);
				    log_user_activity(null,true);
				}
				if($arr['status'] != COMPLETED)
				    $this->email->set_crlf("\r\n");
				
				//Send mail to user manager if the status is completed
				if($arr['status'] == COMPLETED){
					$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($arrRequestData['requested_by']);
					$clientMangerEmailIds = str_replace($userEmailId, "", $clientMangerEmailIds);
					$clientMangerEmailIds = str_replace(",,", ",", $clientMangerEmailIds);
					$clientMangerEmailIds = trim($clientMangerEmailIds,',');
					if($clientMangerEmailIds != ''){
						$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
						$this->email->message($html);
						$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
						$this->email->to($clientMangerEmailIds);
						if($this->email->send()){
						    //Log Activity
						    $arrLogDetails = array(
						        'description'=>$html,
						        'type' => LOG_ACTIVITY_EMAIL,
						        'status' => STATUS_SUCCESS,
						        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
						        'miscellaneous2'=>$clientMangerEmailIds
						    );
						    $this->config->set_item('log_details', $arrLogDetails);
						}else{
						    //Log Activity
						    $arrLogDetails = array(
						        'description'=>$html,
						        'type' => 'Email',
						        'status' => STATUS_FAIL,
						        'transaction_name'=>lang('HCP')." Profile Request Email Sent",
						        'miscellaneous2'=>$clientMangerEmailIds
						    );
						    $this->config->set_item('log_details', $arrLogDetails);
						}
						$this->email->clear(TRUE);
					}
				}
				
			}
			
			$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $kolId,$status);
		}
		
		
		if($arr['status']==COMPLETED){
			foreach($arr['kolId'] as $id){
				$arrRequestData = $this->requested_kol->get($id);
				$arrIds[]=$arrRequestData['kol_id'];
			}
			$arrUsers = $this->align_user->getRquetsterOfKol($arrIds);
			foreach($arrUsers as $row){
				//$this->align_user->assignKolsToUser($row);
			}
		}
		
	}
	
	function re_request(){
		$this->isApprover	= IS_APPROVER;
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$kolId = $this->input->post("kol_id");
		$arrKol = $this->kol->editKol($kolId);
		//Save Profile Request
		$userRequest = array();
		$userRequest['kol_id'] = $kolId;
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		$userRequest['is_re_request'] = 1;
		$requestStatus = 1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$requestStatus = 3;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}
		$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
		$userRequest['profile_type'] = $this->input->post('current_profile_type');
		$isSaved = $this->requested_kol->save($userRequest);
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
		
		//Update KOL status
		$kolDetails = array();
		$kolDetails['id'] = $userRequest['kol_id'];
		$kolDetails['status'] = $userRequest['status'];
		$kolDetails['request_status'] = $requestStatus;
		$this->kol->updateKol($kolDetails);
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['kol_id'] = $userRequest['kol_id'];
		$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']);
		$rowData['org_name'] = $this->organization->getOrgNameByOrgId($arrKol['org_id']);
		$rowData['status'] = $userRequest['status'];
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		if($arrKol['profile_type'] == '')
       		$arrKol['profile_type'] = 'Basic';
       	if($arrKol['profile_type'] == 'Basic Plus')
       		$arrKol['profile_type'] = 'Basic+';
       	if($arrKol['profile_type'] == 'Full Profile')
       		$arrKol['profile_type'] = 'Full';
        if($userRequest['request_for'] == REQUEST_TYPE_PROFILE)
       		$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
       	else
       		$rowData['request_for'] = 'Upgrade - '.ucwords($arrKol['profile_type']);
		$data['arrKol'] = $rowData;
		
		//Send mails
		$mailSent = $this->send_user_request_mails($arrKol);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
       	echo json_encode($data);
	}
	
	function export_kol_detail_old(){
		$clientId = $this->session->userdata('client_id');
		$type = $this->input->post('type');
		$arrKolIds = $this->input->post('exportIds');
		
		$arrKolIds = explode(',',$arrKolIds);
		//pr($arrKolIds);
		$arrKolDeatil = $this->requested_kol->getUserRequestDetails($arrKolIds);
		//pr($arrKolDeatil);
		//echo $this->db->last_query();
		//pr($arrKolDeatil);
		if($type==1){
			if($clientId==INTERNAL_CLIENT_ID){
				$arrDetails[0] = array('Status','KOL Name','Request Type','Organization Name','Created By','Country','PIN','Specialty');
			}else{
				$arrDetails[0] = array('Status','KOL Name','Request Type','Organization Name','Created By','Country');
			}
			foreach($arrKolDeatil as $row){
				
				if($row['request_for'] == REQUEST_TYPE_PROFILE)
       				$row['request_for'] = 'Profile';
       			else
       				$row['request_for'] = 'Upgrade';
				$arrDetail[0] = $row['status'];
				$arrDetail[1] = $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']);
				$arrDetail[2] = $row['request_for'];
				$arrDetail[3] = $row['name'];
				$arrDetail[4] = $row['user_first_name']." ".$row['user_last_name'];
				$arrDetail[5] = $row['country'];
				if($clientId==INTERNAL_CLIENT_ID){
					$arrDetail[6] = $row['pin'];
					$arrDetail[7] = $row['spec'];
				}
				$arrDetails[]=$arrDetail;
			}
		}else{
			if($clientId==INTERNAL_CLIENT_ID){
				$arrDetails[0] = array('Status','KOL Name','Approver','Organization Name','Created By','Request Type','Country','PIN','Specialty');
			}else{
				$arrDetails[0] = array('Status','KOL Name','Approver','Organization Name','Created By','Request Type','Country');
			}
			
			foreach($arrKolDeatil as $row){
				if($row['profile_type'] == '')
	       			$row['profile_type'] = 'Basic';
	       		if($row['profile_type'] == 'Basic Plus')
	       			$row['profile_type'] = 'Basic+';
	       		if($row['profile_type'] == 'Full Profile')
	       			$row['profile_type'] = 'Full';
	       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
	       			$row['request_for'] = 'Profile - '.ucwords($row['profile_type']);
	       		else
	       			$row['request_for'] = 'Upgrade - '.ucwords($row['profile_type']);
				$arrDetail[0] = $row['status'];
				$arrDetail[1] = $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']);
				$arrDetail[2] = $row['approver_first_name']." ".$row['approver_last_name'];
				if($row['status'] == New1){
	       			$arrDetail[2] = '';
	       		}
				$arrDetail[3] = $row['name'];
				$arrDetail[4] = $row['user_first_name']." ".$row['user_last_name'];
				$arrDetail[5] = $row['request_for'];
				$arrDetail[6] = $row['country'];
				if($clientId==INTERNAL_CLIENT_ID){
					$arrDetail[7] = $row['pin'];
					$arrDetail[8] = $row['spec'];
				}
				$arrDetails[]=$arrDetail;
			}
		}
		//pr($arrDetails);
		$this->load->plugin('phpxls/writer');
		$workbook = new Spreadsheet_Excel_Writer();
		
		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
		$format_und->setAlign('centre');
		$format_und->setSize(12);
			
		$format_reg =& $workbook->addFormat();
	//	$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
	//	$excelFilters = 'Appoved By:Vinayak';
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		$filterHeaders[0] = 'Filter Name';
		$filterHeaders[1] = 'Filter Value';
		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != '' && $filter != 'Search'){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
		//pr($filters);
		$arr = array(
		      	'Profiles Requested' => $arrDetails,
				'Filters'=>$filters
		      );

		foreach($arr as $wbname=>$rows)
		{
		    
			$rowcount = count($rows);
			$colcount = count($rows[0]);
			
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='Profiles Requested'){
				$worksheet->setColumn(0,0, 20);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 40.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,4, 30.00);
				$worksheet->setColumn(5,5, 30.00);
				
			}
			if($wbname == 'Filters'){
				$worksheet->setColumn(0,0,25);
			    $worksheet->setColumn(1,1,25);
			}

			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
			          
					if ($j==0){
						$fmt =& $format_und;
					                    
					}
					if (isset($rows[$j][$i]))
					{
						$data=$rows[$j][$i];
						$worksheet->write($j, $i, $data, $fmt);
					}
				}
			}
		}
		
		//$userId=$this->session->userdata('user_id');
		//$userName = $this->client_user->getUserNameById($userId);
		//$fileName = $userName."_interactions";
		//if($kolId != null){
			//$kolDetails = $this->kol->getKolName($kolId);
			//$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
			//$fileName = $userName."_".$kolName."_interactions";
		//}
		//for downloading the file
		if($type=='1'){
			$fileName ='MyPendingApprovals';
		}else{
			$fileName ='AllProfileRequests';
			
		}
		
		$workbook->send($fileName.'.xls');
		$workbook->close();
	}
	
	function save_customer_profile_request(){
		$this->isApprover	= IS_APPROVER;
		//Prepare KOL details
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrKol['id']	 	=	$this->input->post('kol_id');
		$arrKolData = $this->kol->editKol($arrKol['id']);
		$orgDetails['name']        	=	$this->input->post('org_id');
		 
		if($orgDetails['name'] !=''){
			$orgDetails['status']	= "Requested";
			// org type
			$orgDetails['profile_type'] = BASIC;
			$arrKol['org_id']	= $this->organization->saveOrganization($orgDetails);
		}
		$page_type	= $this->input->post('page_type');
		if($page_type == 'complex'){
			$arrKol['salutation']	 	=	$this->input->post('salutation');
	    	$arrKol['first_name']	 	=	ucwords(trim($this->input->post('first_name')));
	   		$arrKol['middle_name']	 	=	ucwords(trim($this->input->post('middle_name')));
	    	$arrKol['last_name']     	=	ucwords(trim($this->input->post('last_name')));
	    	$arrKol['suffix']      	 	=	ucwords(trim($this->input->post('suffix')));
	   		$arrKol['specialty']		=	$this->input->post('specialty');
			$arrKol['primary_phone']	=	ucwords(trim($this->input->post('primary_phone')));
	    	$arrKol['primary_email']	=	trim($this->input->post('primary_email'));
	   		$arrKol['fax']				=	$this->input->post('fax');
			$arrKol['address1']        	=	$this->input->post('address1');
			$arrKol['npi_num']        	=	$this->input->post('npi_num'); 
			$arrKol['country_id']	=	trim($this->input->post('country_id'));
	   		$arrKol['state_id']     =	$this->input->post('state_id');
	       	$arrKol['city_id']      =	$this->input->post('city_id');
	       	
	       	$arrKol['title']     	=	$this->input->post('title');
	       	$arrKol['division']     =	$this->input->post('division');
	       	$arrKol['profile_type'] =	$this->input->post('profile_type');
		}
		
       	$arrKol['is_pubmed_processed']        =	1;
		//$arrKol['created_by']	 = 	$this->loggedUserId;
		//$arrKol['created_on']	 =	date("Y-m-d H:i:s");
		$arrKol['status']		 =	New1;
		$arrKol['request_status']		 =	1;
		if($this->isApprover){
			$arrKol['status']		 =	APPROVED;
			$arrKol['request_status']		 =	3;
		}
			$this->requested_kol->updateClientPreKol($arrKol);
			//Save KOL and Get Id
		/*$kolId = $this->kol->saveKolNoDuplicateCheck($arrKol);
		if($kolId){
			//Update pin as kolid
			$updateData['id'] 			=  $kolId;  
       		$updateData['pin'] 			=  $kolId;  
       		$this->kol->updateKol($updateData);
		}*/
			
			
		
		//Save Profile Request
		$userRequest = array();
		$userRequest['kol_id'] = $arrKol['id'];
		$userRequest['requested_by'] = $this->loggedUserId;;
		$userRequest['requested_on'] = date("Y-m-d H:i:s");
		$userRequest['status']		 =	New1;
		if($this->isApprover){
			$userRequest['status']		 =	APPROVED;
			$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
			$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
		}
		$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
		$userRequest['profile_type'] = $this->input->post('profile_type');
		$isSaved = $this->requested_kol->save($userRequest);
		$arrLogDetails = array(
		    'type' => EDIT_RECORD,
		    'description' => lang('HCP').' Profile Request updated to '.$userRequest['status'],
		    'status' => STATUS_SUCCESS,
		    'kols_or_org_type' => 'Kol',
		    'kols_or_org_id' => $arrKol['id'],
		    'transaction_id' =>  $isSaved,
		    'transaction_table_id' => USER_REQUESTS,
		    'transaction_name' => lang('HCP').' Profile Request updated to '.$userRequest['status'],
		    'parent_object_id' =>   $arrKol['id']
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		
		$data['msg'] = "Request saved succefully";
		$data['saved'] = true;
		$data['is_manager'] = false;
		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
			$data['is_manager'] = true;
			
		
		$rowData = array();
		$rowData['id'] =  $isSaved;
		$rowData['kol_id'] = $userRequest['kol_id'];
		$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);
		$rowData['org_name'] = $this->input->post('org_id');
		if($arrKol['profile_type'] == '')
       		$arrKol['profile_type'] = 'Basic';
       	if($arrKol['profile_type'] == 'Basic Plus')
       		$arrKol['profile_type'] = 'Basic+';
       	if($arrKol['profile_type'] == 'Full Profile')
       		$arrKol['profile_type'] = 'Full';
       if($userRequest['request_for'] == REQUEST_TYPE_PROFILE)
       		$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
       	else
       		$rowData['request_for'] = 'Upgrade - '.ucwords($arrKol['profile_type']);	
		$rowData['status'] = $userRequest['status'];
		$rowData['user_full_name'] = $this->session->userdata('user_full_name');
		$data['arrKol'] = $rowData;
		//Send mails
		$mailSent = $this->send_user_request_mails($arrKolData);
		if(!$mailSent){
			$data['msg'] = "Error in sending mail";
			$data['saved'] = false;
		}
       	echo json_encode($data);
	}
	
	/**
	 * 
	 * @author 	Ramesh B 
	 * @since	
	 * @return 
	 * @created 15 Jan 2014
	 */
	function filters_to_array($reportFilters){
		$filters = array();
		if($reportFilters != ''){
			$reportFiltersElements = explode(':',$reportFilters);
			foreach ($reportFiltersElements as $filterElement){
				$filterElements = explode('=',$filterElement);
				$filterName = $filterElements[0];
				$filterValues = array();
				if(isset($filterElements[1]) && $filterElements[1] != ''){
					$arrFilterValues = explode(',',$filterElements[1]);
					$filterValues = $arrFilterValues;
				}
				if(sizeof($filterValues) > 0)
					$filters[$filterName] = $filterValues;
			}
		}
		return $filters;
	}
	
	function test(){
		$arrData = $this->session->flashdata('arrData');
		if ($arrData)
		{
			pr($arrData);
		}
	}
	
	function export_kol_detail(){
	    ini_set('memory_limit',"-1");
	    ini_set("max_execution_time",0);
	    $this->load->plugin('php_excel/classes/phpexcel.php');	   
		$clientId = $this->session->userdata('client_id');
		$type = $this->input->post('type');
		$arrKolIds = $this->input->post('exportIds');
		
		$arrKolIds = explode(',',$arrKolIds);
		//pr($arrKolIds);
		$arrKolDeatil = $this->requested_kol->getUserRequestDetails($arrKolIds);	
		
// 		pr($arrKolDeatil);
// 		exit();
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Profile Requested');
		//Add header
		if($type==1){
			$objWorksheet->setCellValue('A1', 'Status')
						->setCellValue('B1', 'KTL Name')
						->setCellValue('C1', 'Request Type')
						->setCellValue('D1', 'Organization Name')
						->setCellValue('E1', 'Created By')
						->setCellValue('F1', 'Country')
						->setCellValue('G1', 'Requested On')
						->setCellValue('H1', 'Approved / Rejected On');
			
				if($clientId==INTERNAL_CLIENT_ID){
					$objWorksheet->setCellValue('I1', 'PIN')
								->setCellValue('J1', 'Specialty');
				}
			
				$i	=	2;
				foreach($arrKolDeatil as $row){
					/* if($row['request_for'] == REQUEST_TYPE_PROFILE)
	       				$row['request_for'] = 'Profile';
	       			else
	       				$row['request_for'] = 'Upgrade'; */
	       			
	       			if($row['profile_type'] == '')
	       				$row['profile_type'] = 'Basic';
	       			if($row['profile_type'] == 'Basic Plus')
	       				$row['profile_type'] = 'Basic+';
	       			if($row['profile_type'] == 'Full Profile')
	       				$row['profile_type'] = 'Full';
	       			if($row['request_for'] == REQUEST_TYPE_PROFILE)
	       				$row['request_for'] = 'Profile - '.ucwords($row['profile_type']);
	       			else
	       				$row['request_for'] = 'Upgrade - '.ucwords($row['profile_type']);
	       			
	       			$rej_or_appr_on = ' ';
	       			if($row['rej_or_appr_on']!=null){
	       			    $rej_or_appr_on = date("m-d-Y",strtotime($row['rej_or_appr_on']));
	       			}
					$objWorksheet->setCellValue('A'.$i, $row['status'])
								->setCellValue('B'.$i, $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']))
								->setCellValue('C'.$i, $row['request_for'])
								->setCellValue('D'.$i, $row['name'])
								->setCellValue('E'.$i, $row['user_first_name']." ".$row['user_last_name'])
								->setCellValue('F'.$i, $row['country'])
								->setCellValue('G'.$i, date("m-d-Y",strtotime($row['requested_on'])))
								->setCellValue('H'.$i, $rej_or_appr_on);
	
					if($clientId==INTERNAL_CLIENT_ID){
						$objWorksheet->setCellValue('I'.$i, $row['pin'])
									->setCellValue('J'.$i, $row['spec']);
					}
					$i++;
				}
		}else{
				$objWorksheet->setCellValue('A1', 'Status')
						->setCellValue('B1', 'KTL Name')
						->setCellValue('C1', lang("ProfileRequest.Approver"))
						->setCellValue('D1', 'Request Type')
						->setCellValue('E1', 'Organization Name')
						->setCellValue('F1', 'Created By')
						->setCellValue('G1', 'Country')
						->setCellValue('H1', 'Requested On')
						->setCellValue('I1', 'Approved / Rejected On');
			
				if($clientId==INTERNAL_CLIENT_ID){
					$objWorksheet->setCellValue('J1', 'PIN')
								->setCellValue('K1', 'Specialty');
				}
			
				$i	=	2;
				foreach($arrKolDeatil as $row){
					if($row['profile_type'] == '')
		       			$row['profile_type'] = 'Basic';
		       		if($row['profile_type'] == 'Basic Plus')
		       			$row['profile_type'] = 'Basic+';
		       		if($row['profile_type'] == 'Full Profile')
		       			$row['profile_type'] = 'Full';
		       		if($row['request_for'] == REQUEST_TYPE_PROFILE)
		       			$row['request_for'] = 'Profile - '.ucwords($row['profile_type']);
		       		else
		       			$row['request_for'] = 'Upgrade - '.ucwords($row['profile_type']);
	       				
					$objWorksheet->setCellValue('A'.$i, $row['status'])
								->setCellValue('B'.$i, $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'], $row['last_name']));
								if($row['status'] == New1){
					       			$objWorksheet->setCellValue('C'.$i, '');
					       		}else{
					       			$objWorksheet->setCellValue('C'.$i, $row['approver_first_name']." ".$row['approver_last_name']);
					       		}
		       		$rej_or_appr_on = '';
		       		if($row['rej_or_appr_on']!=null){
		       		    $rej_or_appr_on = date("m-d-Y",strtotime($row['rej_or_appr_on']));
		       		}       		
					$objWorksheet->setCellValue('D'.$i, $row['request_for'])
								->setCellValue('E'.$i, $row['name'])
								->setCellValue('F'.$i, $row['user_first_name']." ".$row['user_last_name'])
								->setCellValue('G'.$i, $row['country'])
								->setCellValue('H'.$i, date("m-d-Y",strtotime($row['requested_on'])))
								->setCellValue('I'.$i, $rej_or_appr_on);
	
					if($clientId==INTERNAL_CLIENT_ID){
						$objWorksheet->setCellValue('J'.$i, $row['pin'])
									->setCellValue('K'.$i, $row['spec']);
					}
					$i++;
				}
		}
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
	//	$excelFilters = 'Appoved By:Vinayak';
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
//		$filterHeaders[0] = 'Filter Name';
//		$filterHeaders[1] = 'Filter Value';
//		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != '' && $filter != 'Search'){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
//		pr($filters);
//		exit;
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('Filters');
			$objWorksheet->setCellValue('A1', 'Filter Name')
								->setCellValue('B1', 'Filter Value');
			$i	=	2;
			foreach($filters as $row){
				$objWorksheet->setCellValue('A'.$i, $row[0])
							->setCellValue('B'.$i, $row[1]);
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
		if($type==1){
			foreach(range('A','J') as $columnID) {
			    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
			}
        	$objPHPExcel->getSheet(0)->getStyle('A1:J1')->applyFromArray($arrStyles); 
		}else{
			foreach(range('A','K') as $columnID) {
			    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
			}
        	$objPHPExcel->getSheet(0)->getStyle('A1:K1')->applyFromArray($arrStyles); 
		}
		foreach(range('A','B') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(1)->getStyle('A1:B1')->applyFromArray($arrStyles); 
		if($type=='1'){
			$fileName ='MyPendingApprovals';
		}else{
			$fileName ='AllProfileRequests';
			
		}
		
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');		
		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=$fileName.xlsx");
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	
	/**
	 * 
	 * @author 	Sanjeev K 
	 * @since	
	 * @return 
	 * @created 10 July 2017
	 */
	function update_kol_data_status(){ 
			$status = $this->input->post('status');
			$arrKolIds = $this->input->post('kolId');
			$date = $this->input->post('user_date');
			$user_date = date("Y-m-d", strtotime($date));
			if(($key = array_search("undefined", $arrKolIds)) !== false) {
				unset($arrKolIds[$key]);
			}
			foreach($arrKolIds as $kolId){
				$isDetailsAdded = $this->requested_kol->changeKolUpdateDataStatus($kolId, $status, $user_date);
			}
			if($isDetailsAdded)
					echo "true";
				else
					echo "false";
	}
	
	//Function to save association or disassociation KOLs to particular client
	function save_kol_client_association($kolId=null,$fromKol=''){
	    if($kolId == null){
	        $arrAssociationData['kol_id'] = $this->input->post('kol_id');
	        $arrAssociationData['client_id'] = $this->input->post('client');
	        $arrAssociationData['associationFlag'] = $this->input->post('associationFlag');
	    }else{
	        $arrAssociationData['kol_id'] = $kolId;
	        $arrAssociationData['client_id'] = $this->session->userdata('client_id');
	        $arrAssociationData['associationFlag'] = 'associate';
	    }
	    $returnData = $this->kol->saveKolClientAssociation($arrAssociationData);
	    if($returnData){
	        $status = true;
	    }else{
	        $status = false;
	    }
	    if($fromKol==''){
	        echo json_encode($status);
	    }else{
	        return $status;
	    }
	}
	function list_kols_grid() {
	    $this->common_helpers->checkUsers();
	    ini_set('memory_limit', '-1');
	    $page = $_REQUEST['page']; // get the requested page
	    $limit = $_REQUEST['rows']; // get how many rows we want
	    $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
	    $sord = $_REQUEST['sord']; // get the direction
	    if (!$sidx)
	        $sidx = 1;
	        
	        //if ($page > $total_pages) $page=$total_pages;
	        //$start = $limit*$page - $limit; // do not put $limit*($page - 1)
	        //if ($start < 0) $start = 0;
	        $filterData = $_REQUEST['filters'];
	        $arrFilter = array();
	        $arrFilter = json_decode(stripslashes($filterData));
	        $field = 'field';
	        $op = 'op';
	        $data = 'data';
	        $groupOp = 'groupOp';
	        $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
	        $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
	        $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
	        $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
	        $whereResultArray = array();
	        foreach ($searchField as $key => $val) {
	            $whereResultArray[$val] = $searchString[$key];
	        }
	        $searchGroupOperator = $searchGroupOperator[0];
	        $searchResults = array();
	        
	        $count = $this->requested_kol->listAll($limit, $start, true, $sidx, $sord, $whereResultArray);
	        if ($count > 0) {
	            $total_pages = ceil($count / $limit);
	        } else {
	            $total_pages = 0;
	        }
	        if ($page > $total_pages)
	            $page = $total_pages;
	            $start = $limit * $page - $limit; // do not put $limit*($page - 1)
	            if ($start < 0)
	                $start = 0;
	                
            $arrKolDetailResult = array();
            $data = array();
            $arrKolDetail = array();
            //		pr($sidx);
            //		pr($whereResultArray);
            if ($arrKolDetailResult = $this->requested_kol->listAll($limit, $start, false, $sidx, $sord, $whereResultArray)) {
                foreach ($arrKolDetailResult->result_array() as $row) {
                    $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
                    $kolName = $arrSalutations[$row['salutation']] . ' ' . $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                    $row['kol_name'] = $kolName;
                    $row['id'] = $row['id'];
                    if($row['request_for'] == REQUEST_TYPE_PROFILE)
                        $row['request_for'] = 'Profile';
                    else
                        $row['request_for'] = 'Upgrading';
                        $row['requested_on'] = sql_date_to_app_date($row['requested_on']);
                    $arrKolDetail[] = $row;
                }
                
                $data['records'] = $count;
                $data['total'] = $total_pages;
                $data['page'] = $page;
                $data['rows'] = $arrKolDetail;
            }
            ob_start('ob_gzhandler');
            echo json_encode($data);
	}
	
}