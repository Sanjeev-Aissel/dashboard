<?php
/**
 * This is HTML page which lists all the Contract
 * 
 * @author Vinayak
 * @created 24-11-2011
 * @since  3.4	
 */

?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('contracts/list_contracts',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min',
							'jquery.autocomplete',
							'jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.datepicket',
							'chosen.jquery',
	                        'jqgridExportToExcel'   
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<script type="text/javascript">
    var contractType = "org";
    var org_contract = '<?php echo ORGS_CONTRACT;?>';
	var contractsTitle = "<?php //echo lang("track.Contracts");?>";
	var contractName = "<?php echo lang("track.ContractName");?>";
	var kolName = "<?php echo lang("Contracts.OrgName");?>";
	var description = "<?php echo lang("track.Description");?>";
	var startDate = "<?php echo lang("track.StartDate");?>";
	var endDate = "<?php echo lang("track.EndDate");?>";
	var download = "<?php echo lang("track.Download");?>";
	var action = "<?php echo lang("Overview.Action");?>";
	jqgridIds	= new Array('listContractResultSet');	
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','Download');
    var arrExcludeColumnsInExcelExport = new Array('act','contract_file'); 
    var kolId = "<?php echo $orgId;?>";
</script>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />
	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
	.myclass td {
	   	font-weight:bold;
	    color: #ff0000 !important;
	}	
	.expire{
		margin-bottom: 4px;
	    margin-left: 10px;
	    padding-top: 3px;
	    width: 100px;
	}
	.ui-jqgrid {
	    font-size: 13px;
	}

	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("../images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.ui-tabs-vertical .ui-tabs-nav {
		margin-left: 0px;
	}
	.listResultSet a{
		text-decoration:none;
		text-align:left;
		float:left;
	}
	tr.selectedRow {
	    background-color: #D8DFEA !important;
	}
	.addLink {
		width:auto;
		float: right;
		margin-top: -25px;
		margin-right: 9px;
	}
	.toggleBtnWrapper{
		margin-bottom: 10px;
    	width: 500px;
	}
	#contractsTernaryNav{
		width: 124px;
	}
/*	#contractsContainer{
		width: 1100px;
		float: right;
	}*/
	#timeLineSliderContainer{
		width: 110px;
	}
	#timeLineSliderContainer p {
		margin-top: -20px;
	}
	#contractsList{
		border:0px;
	}
	button#expiredButton{
		width:30px;
		height:18px;
		margin-right:7px;
		float:left;
		background: -moz-linear-gradient(center top , #FF0000 0%, #FF0000 100%) repeat scroll 0 0 transparent;
	    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#FF0000),color-stop(100%,#FF0000));
		background: -webkit-linear-gradient(top,#FF0000 0%,#FF0000 100%);
		background: -o-linear-gradient(top,#FF0000 0%,#FF0000 100%);
		background: -ms-linear-gradient(top,#FF0000 0%,#FF0000 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#FF0000,endColorstr=#FF0000,GradientType=0);
		background: linear-gradient(top,#FF0000 0%,#FF0000 100%);
	}
	span.contractExpired{
		background-color: red;
	    float: left;
	    height: 25px;
	    margin-right: 5px;
	    width: 20px;
	}
	.dataTypeIndicator, .iconCreatedByUser{
	   margin-right: 10px;
	}
</style>

<div id="container">
	<div id="contractsContainer">
<?php /*		<div class="exportOptionsContainer">
			<ul class="pageRightOptions">
				<li style="color:red;"><span class="contractExpired"></span>Contract Expired</li>
				<li><label class="link" onclick="addContract();" id="addButton"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add Contract</label></li>
			</ul>
		</div>
	*/ ?>	
		<div id="contractsList" class="clear">
			<div class="gridWrapper" id="gridContainer">
				<div id="listContractPage"></div>
				<table id="listContractResultSet"></table>
			</div>
			<!-- Container for the 'Interaction Add' modal box -->
			<div id="dailog2">	
				<div id="contractAddContainer" class="microProfileDialogBox">
					<div class="profileContent" id="contractAddProfileContent"></div>
				</div>
			</div>
			<!--End of  Container for the 'Interaction Add' modal box -->
			<!-- Container for the 'Interaction Micro Edit' modal box -->
			<div id="dailog3">	
				<div id="contractEditContainer" class="microProfileDialogBox">
					<div class="profileContent" id="contractEditProfileContent"></div>
				</div>
			</div>
			<!--End of  Container for the 'Interaction Edit' modal box -->
		</div>
		
	</div>
</div>
