<?php
    // prepare array of JS files to insert into queue
    $queued_js_scripts = array('index/client_index','jquery/jquery-ui-1.8.16.datepicket');
    // add the JS files into queue i.e Append to the existing queue
    $this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<html>
    <head>
        <script type="text/javascript">
            function updateSource()
            {
               var  data=$("form").serialize();
              
                $.ajax({                    
                        url:'<?php echo base_url();?>media_intel_extractions/update_source/',
                        type:'POST',
                        dataType :'TEXT',
                        data:data,
                        success:function(returnData){

                        if(returnData==1){
                            jAlert("Source updated successfully");
                        	window.location = "<?php echo base_url()?>media_intel_extractions/analystSourceGrid";
                        }else
                            jAlert("There was a problem in updating the source.");

                        }
                    });
            }
        </script>
        <style>
           
            label{
                margin-right: 10px;
            }
           .box_style{
                width:500px;
                height:25px;
            }
        </style>
    </head>
    <div class="container_details">
        <fieldset>
            <legend>Edit Source Details</legend>
            <form name="details" method="post">
                <input class='text' hidden value="<?php echo $content["id"]?>" type="text" name="id" />
                <table>
                    <tr><td>Source</td><td><input  class='box_style ' value="<?php echo $content["link"]?>" type="text" name="link" /></td></tr>
                    <tr><td>Attribute Name</td><td><input  class='box_style ' type="text" name="attribute_name"  value="<?php echo $content["attribute_name"]?>" /></td></tr>
                    <tr><td>Attribute Value</td><td><input  class='box_style ' type="text" name="attribute_value"  value="<?php echo $content["attribute_value"]?>" /></td></tr>
                    <tr><td>Tag name</td><td><input  class='box_style ' type="text" name="tag_name"  value="<?php echo $content["tag_name"]?>" /></td></tr>
                    <tr><td>Publisher</td><td><input  class='box_style ' type="text" name="publisher"  value="<?php echo $content["publisher"]?>" /></td></tr>
                    <tr><td></td><td><input type="button" onclick="updateSource()" name="update" value='Update' /><input type="reset" name="reset" value='Reset' /></td></tr>
                </table>



            </form>
        </fieldset>
    
    </div>
    
    
    
    
    
    
    
    
</html>
