
			<?php
				$surveyIds	= '';
				$separator	= '';
				$count	= 1;
				$i		= 0;
				foreach($arrSurveys as $categoryName => $arrSurveys){
			?>
				<tr class="tableHeader">
					<th class="alignLeft" colspan="4"><?php echo $categoryName;?></th>
				</tr>
				<?php foreach($arrSurveys as $key => $arrRow){
						$totalAnswersCount	= sizeof($arrSurveyAnswers[$arrRow['id']]);
						$surveyIds .= $separator.$arrRow['id'];
						$separator	= ',';
						$i++;
						if($totalAnswersCount<1){
							$totalAnswersCount	= 1;
						}
					?>
					<tr class="tableSubHeader">
						<th class="alignTop borderBottom"><?php echo $i;?>)</th>
						<th class="borderBottom" colspan="3">
							<?php echo $arrRow['question'];?> &nbsp;
							<span class="tags">( Tags: <?php echo $arrTypes[$arrRow['type_id']].', '.$categoryName.', '.$arrRow['role'];?> )</span>
							<input type="hidden" id="count_<?php echo $arrRow['id'];?>" name="count_<?php echo $arrRow['id'];?>" value="<?php echo $totalAnswersCount;?>" />
							<input type="hidden" id="uniqueCount_<?php echo $arrRow['id'];?>" name="unique_count_<?php echo $arrRow['id'];?>" value="<?php echo $totalAnswersCount;?>" />
						</th>
					</tr>
					<tr class="<?php echo $arrRow['id'];?>">
						<td></td>
						<td class="tooltip-demo tooltop-top">
							<div class="influencerName alignInline">
								<p class="surveyname tooltip-demo tooltop-top">
									<label>Name:<span class="required">*</span></label>
									<input type="hidden" name="kol_id" value="<?php echo $arrAnswers['kol_id'];?>" id="kolId" class="test" />
									<input type="hidden" name="kol_name_auto[]" value="<?php echo $arrAnswers['name'];?>" id="kolNameAuto_<?php echo $arrRow['id'].'_'.$answersCount;?>" class="checkAboveInputValue" />
									<input type="hidden" name="kol_id_<?php echo $arrRow['id'];?>[]" value="<?php echo $arrAnswers['kol_id'];?>" id="kolIdAuto_<?php echo $arrRow['id'].'_'.$answersCount;?>"  />
									<input rel="tooltip" title="<?php echo $arrAnswers['name'];?>" type="text" name="kol_name_<?php echo $arrRow['id'];?>[]" value="<?php echo $arrAnswers['name'];?>" id="kolName_<?php echo $arrRow['id'].'_'.$answersCount;?>" class="autocompleteInputBox kolNameAutoComplete" />
								</p>
							</div>
							<div class="influencerOrgName alignInline">
								<label>Organization:</label>
								<input rel="tooltip" title="<?php echo $arrAnswers['org_name'];?>" type="text" class="autocompleteInputBox organizationNameAutoComplete" value="<?php echo $arrAnswers['org_name'];?>" id="org_<?php echo $arrRow['id'].'_'.$answersCount;?>" name="org_<?php echo $arrRow['id'];?>[]" />
							</div>
							<div class="influencerActions">
								<div class="tooltip-demo tooltop-left exapndCollapseSlider">
									<a class="tooltipLink" rel="tooltip" href="#" onclick="return false;" title="Expand/Collapse Influencer information"> </a>
								</div>
								<!-- div class="advSearchIcon sprite_iconSet tooltip-demo tooltop-left">
									<a href="#" onclick="searchNames(this);return false;" rel="tooltip" class="tooltipLink" title="Search Names">&nbsp;</a>
								</div-->
								<label onclick="addMore(<?php echo $arrRow['id'];?>);"><div class="addNewAnswer actionIcon addIcon tooltip-demo tooltop-left"><a href="#" onclick="return false;" rel="tooltip" class="tooltipLink" title="Add another name">&nbsp;</a></div></label>
							</div>
							<div class="otherInfo">
								<div class="influencerCountry alignInline">
									<label>Country: </label><input type="text" class="country" id="country_<?php echo $arrRow['id'].'_'.$count;?>" name="country_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerState alignInline">
									<label>State:<span class="required">*</span> </label><input type="text" class="state" id="state_<?php echo $arrRow['id'].'_'.$count;?>" name="state_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerCity alignInline">
									<label>City:<span class="required">*</span> </label><input type="text" class="city" id="city_<?php echo $arrRow['id'].'_'.$count;?>" name="city_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerZipcode alignInline">
									<label>Postal Code: </label><input type="text" class="zipcode" id="postal_<?php echo $arrRow['id'].'_'.$count;?>" name="postal_<?php echo $arrRow['id'];?>[]" />
								</div>
							</div>
						</td>
					</tr>
				<?php 
				}
			}?>
			<input type="hidden" name="surveyIds" value="<?php echo $surveyIds;?>" />