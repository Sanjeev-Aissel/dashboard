<?php
/**
*Controller for pubmed operations
*@author Ramesh B
*@since
*@package application.controllers	
*@created on 06-01-2011
*/

class Pubs extends Controller{
	var $maxScriptTime		= 86400;
	var $logFileName		= '';
	var $startTime			= '';
	var $logFile			= '';
	var $logText			= '';
	var $pmidBatchSize		= 10;
	var $sleepTime			= 2;
	var $safeTime			= 10;
	var $logLastPmidFile 	= '';
	
	var $logFileNamePmidSkipped		= '';
	var $logFilePmidSkipped			= '';
	var $observerEmailId	= ANALYST_EMAIL_ID;
	
	//Constructore
	function Pubs(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('pubmed');
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		$this->logFilePath	= $this->config->item('app_folder_path').'system/logs/pubmed';
		//$this->load->libraries('');	
		//$this->_is_logged_in();	

		$observerEmail =  $this->input->post("observer_email");
		if($observerEmail != null && $observerEmail != '')
			$this->observerEmailId = $observerEmail;
		if($this->session->userdata('logged_in') == 1)
			$this->observerEmailId = $this->session->userdata('email');
	}
	
	function bulk_insert_test(){
		$this->db->cache_on();
		$this->startTime = microtime(true);
		error_reporting(E_ALL);
		$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=23945945,23991810,19902481";
		$response = $this ->retrieve_page_get($url);
		
		$xml = new DOMDocument();
		
		if(!$xml->loadXML($response['response'])){
			echo "error";
			return;
		}
		$publications = $xml->getElementsByTagName('PubmedArticle');
		echo sizeof($publications);				
		foreach($publications as $publication){
			//parse and save publication details
			$pubDetails=$this->parse_pub_details($publication);	
			$pubId=$this->save_publications($pubDetails, 615);
			//echo "PubId: ".$pubId."<br>";
			//pr($pubDetails);
			
			//parse and save 'publication-authors'
			$arrAuthors=$this->parse_pub_authors($publication);
			$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
			
			//Calculate Authorship position and save
			//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
			//$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
			
			//parse and save MeshTerms
			$arrMeshTerms=$this->parse_pub_meshterms($publication);
			$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
			
			//parse and save 'Substances(chemicals)'
			$arrSubstances=$this->parse_pub_substances($publication);
			$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
			
			//parse and save 'Publication types'
			$arrPubTypes=$this->parse_pub_types($publication);
			$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
			
			//parse and save 'CommentsCorrections(CC)'
			$arrCC=$this->parse_pub_CC($publication);
			$isSaved=$this->save_pub_CC($arrCC, $pubId);
			
			//parse and save 'Pubmed History'
			$arrHistory=$this->parse_pub_history($publication);
			$isSaved=$this->save_pub_history($arrHistory, $pubId);
			
			//parse and save 'Publication Article IDs'
			$arrPubArticleIds=$this->parse_pub_article_ids($publication);
			$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
			
			echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- <br>";
		}
		$this->db->cache_off();
		$timeDiff = microtime(true) - $this->startTime;
		echo "Time Taken :".$timeDiff;
	}
	
	/**
	 * Parse Publication details
	 * @ACL1-Alias Process
	 * @ACL1-Discription Parse Publication details
	 * @ACL1-Category Publications
	 * @ACL1-SubApp analyst
	 */
	function process_pubmeds($indvisKolId = null){
		//Analyst App to be accessed by only Aissel users. 
		//$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;	
		// Open the LogFile to write		
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		fwrite($this->logFile, $this->logText);
		
		$this->logFileNamePmidSkipped	=$this->logFilePath . "/skipped/" . "pmids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
		
		ini_set("max_execution_time",$this->maxScriptTime);
		//$this->maxScriptTime = ini_get("max_execution_time");

		//Process the last crawled PMID
		$lastPmid = file_get_contents($this->logFilePath . "/last_pmid.txt");
		if(isset($lastPmid) && $lastPmid != '') {
			echo "Processing last PMID : ".$lastPmid."<br>";
			flush(); 
			$this->logText	= "Processing last PMID : ".$lastPmid."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->recrawl_pmid($lastPmid);
		}
		//$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
		
		$this->logText	= "Processing KOLs with status Recrawl..  \r\n";
		fwrite($this->logFile, $this->logText);
		$this->processPubmedRecrawlKols();
		$this->logText	= "Recrawl Status KOLs processing completed..  \r\n";
		fwrite($this->logFile, $this->logText);
		
		//get the PubmedUnprocessed kol's
		if($indvisKolId != null)
			$arrKolDetails[] = $this->kol->editKol($indvisKolId);
		else
			$arrKolDetails=$this->pubmed->getPubmedUnprocessedKols();
		if(sizeof($arrKolDetails)<1){
			$this->logText	= "There are No Unprocessed KOL ids, Terminating Process..  \r\n";
			fwrite($this->logFile, $this->logText);
			$this->send_status_mail($this->logText);
			die("Sorry! There are No Unprocessed KOL ids, Terminating Process..");
		}
		$this->logText	= "Following are the Unprocessed KOL ids  \r\n";
		fwrite($this->logFile, $this->logText);
		foreach($arrKolDetails as $arrKolDetail){
			$this->logText	= $arrKolDetail['id']."  \r\n";
			fwrite($this->logFile, $this->logText);
		}		
		$firstName='';
		$midleName='';
		$lastName='';
		$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
		fwrite($this->logFile, $this->logText);	
		//Start of loop trought each kol, generate name combinations, gather PMID's, get publications, parse and save data			
		foreach($arrKolDetails as $arrKolDetail){
			$kolStartTime=microtime(true);			
			$this->logText	= "\r\nStarting pubmed processing for KolId ".$arrKolDetail['id']." \r\n";
			fwrite($this->logFile, $this->logText);		
			
			// get the name details			
			$firstName=$arrKolDetail['first_name'];
			$midleName=$arrKolDetail['middle_name'];
			$lastName=$arrKolDetail['last_name'];
			$kolId=$arrKolDetail['id'];
			
			//get the different combinations of names
			if($indvisKolId != null)
				$arrNameCombinations = $this->pubmed->getKolNameCombinations($kolId);
			else
				$arrNameCombinations=$this->pubmed->generate_name_combinations($firstName, $midleName, $lastName);
			
			
			
			$this->logText	= "Kol Name: ".$firstName." ".$midleName." ".$lastName."  \r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "Following are the Name combinations genarated  \r\n";
			fwrite($this->logFile, $this->logText);
			foreach($arrNameCombinations as $nameCombination){
				$this->logText	= $nameCombination."  \r\n";
				fwrite($this->logFile, $this->logText);
			}		
			
			//Get the list of PubMed ID's for each possible Author name and store it in a array
			$this->logText	= "\r\nStarting getting pmid's  \r\n";
			fwrite($this->logFile, $this->logText);
			$arrPMIDs=array();
			$count=0;	
			$gathPMIDTime=microtime(true);		
			foreach($arrNameCombinations as $authName){	
				//Notes about url
				//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results			
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=1000&usehistory=y&retmode=xml&term=".str_replace(" ", "%20", $authName)."[author";
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
			
				$this->logText	= "Url Created ".$url."\r\n";
				fwrite($this->logFile, $this->logText);
									
				$xml = new DOMDocument();
				
			if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}
				
				$idListObj = $xml->getElementsByTagName('IdList')->item(0);
				$idList=$idListObj->getElementsByTagName('Id');
				foreach($idList as $idObj){
					$arrPMIDs[]=$idObj->nodeValue;
				}	
				$this->logText	= "No of PMID's found for name '".$authName."': ".(sizeof($arrPMIDs)-$count)."\r\n";
				fwrite($this->logFile, $this->logText);
				$count=sizeof($arrPMIDs);
				sleep($this->sleepTime);
			}
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			$timeTaken=microtime(true)-$gathPMIDTime;
			$this->logText	= "Time taken to gather PMIDs: ".(microtime(true)-$gathPMIDTime)."\r\n";
			fwrite($this->logFile, $this->logText);
										
			$arrUniquePMIDs = array_unique($arrPMIDs);	
			$arrUniquePMIDs=array_values($arrUniquePMIDs);	
			$this->logText	= "\r\nTotal No of PMIDs found after removing duplicates: ".sizeof($arrUniquePMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);					
			//End of getting the PubMed ID's
			// Reconnect the Database, to ensure that the DB connection is alive
	        // On Jan 26, 2012, we faced an issue where the Publications were not getting crawled
	        // MySQL idel timeout is 15-20 seconds
	        $this->db->close();
	        $this->db->initialize();
			//Check for already existing publication's and associate them with kol
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId,$arrKolDetail);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);

				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}
				
				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						$this->send_status_mail($this->logText);
						redirect(base_url()."pubmeds_org/process_pubmeds");											
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $kolId);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						fwrite($this->logFile, $this->logText);
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
					$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
				$this->logText = "PMIDs Remainig: ".(sizeof($arrFilteredPMIDs) - $i)."\r\n";
				fwrite($this->logFile, $this->logText);	
			}
			//End of loop trough ecah publication, parsjing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
			$arrKolDetail['is_pubmed_processed']=1;
			$this->pubmed->updatePubmedProcessedKol($arrKolDetail);	
			$this->logText	= "Pubmed Processing of KolId :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			
			$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
		}
		
		$this->send_status_mail("Pubmed Processing Ended");
		// End of loop trought each kol	
	}	
	
	
	/**
	 * Parses the publication details from XML Object and returns publication details in an array
	 * @param $publication, XML Object
	 * @return Array
	 */	
	function parse_pub_details($publication){
		$pubDetails=array();
		
		$pmid='';
		$pmIdVersion='';
		$dateCreated=array();
		$dateCompleted=array();
		$dateRevised=array();
		$pubModel='NA';
		$issnNumber='NA';
		$issnType='NA';
		$citedMedium='NA';
		$volume='NA';
		$pubDate=array();
		$journalName='';
		$isoAbbreviation='NA';
		$articleTitle='NA';
		$abstractText='NA';
		$pagination='NA';
		$affiliation='NA';
		$authListComplete='';
		$language='NA';
		$articleDate=array();
		$citationSubset='NA';
		$numberOfReferences='NA';
		$otherID='';
		$status='NA';		
		$link='';
		$isDeleted=0;		
		
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
	
		//$journalName=$medlineCitation->getElementsByTagName('Title')->item(0)->nodeValue;		
		//$articleName=$medlineCitation->getElementsByTagName('ArticleTitle')->item(0)->nodeValue;	
		$pmidObj=$medlineCitation->getElementsByTagName('PMID')->item(0);
		if($pmidObj!=null){
		$pmid=$pmidObj->nodeValue;
		if($pmidObj->hasAttributes()){			
			$pmIdVersion=$pmidObj->attributes->item(0)->value;
			}	
		}
		
		//get the date created
		
		$dateCreatedObj=$medlineCitation->getElementsByTagName('DateCreated')->item(0);	
		if($dateCreatedObj!=null){
			$dateCreated['day']=$dateCreatedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCreated['month']=$dateCreatedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCreated['year']=$dateCreatedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date completed
		
		$dateCompletedObj=$medlineCitation->getElementsByTagName('DateCompleted')->item(0);	
		if($dateCompletedObj!=null){
			$dateCompleted['day']=$dateCompletedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCompleted['month']=$dateCompletedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCompleted['year']=$dateCompletedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date revised
		
		$dateRevisedObj=$medlineCitation->getElementsByTagName('DateRevised')->item(0);	
		if($dateRevisedObj!=null){
			$dateRevised['day']=$dateRevisedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateRevised['month']=$dateRevisedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateRevised['year']=$dateRevisedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		
		// Start Parsing article related data
		$articleObj=$medlineCitation->getElementsByTagName('Article')->item(0);
		if($articleObj!=null){
			if($articleObj->hasAttributes()){			
				$pubModel=$articleObj->attributes->item(0)->value;
				}
			$issnObj=$articleObj->getElementsByTagName('ISSN')->item(0);	
			if($issnObj!=null){	
			$issnNumber=$issnObj->nodeValue;
			if($issnObj->hasAttributes()){			
				$issnType=$issnObj->attributes->item(0)->value;
				}
			}
			$journalIssueObj=$articleObj->getElementsByTagName('JournalIssue')->item(0);
			if($journalIssueObj!=null){
				if($journalIssueObj->hasAttributes()){			
					$citedMedium=$journalIssueObj->attributes->item(0)->value;
					//echo " citedMedium:".$citedMedium;   		 
					}
				$volumeObj=$journalIssueObj->getElementsByTagName('Volume')->item(0);
				if($volumeObj!=null)
					$volume=$volumeObj->nodeValue;
				//get the PubDate
				
				$pubDateObj=$journalIssueObj->getElementsByTagName('PubDate')->item(0);
				if($pubDateObj!=null){
					$dayObj=$pubDateObj->getElementsByTagName('Day')->item(0);
					$pubDate['day']='';
					if($dayObj!=null)
						$pubDate['day']=$dayObj->nodeValue;
					$monthObj=$pubDateObj->getElementsByTagName('Month')->item(0);
					$pubDate['month']='';
					if($monthObj!=null)
						$pubDate['month']=$monthObj->nodeValue;
					$yearObj=$pubDateObj->getElementsByTagName('Year')->item(0);
					$pubDate['year']='';
					if($yearObj!=null)
						$pubDate['year']=$yearObj->nodeValue;
				}
			}			
			$journalNameObj=$articleObj->getElementsByTagName('Title')->item(0);
			if($journalNameObj!=null)
				$journalName=$journalNameObj->nodeValue;
			$isoAbbreviationObj=$articleObj->getElementsByTagName('ISOAbbreviation')->item(0);
			if($isoAbbreviationObj!=null)
				$isoAbbreviation=$isoAbbreviationObj->nodeValue;
			$articleTitleObj=$articleObj->getElementsByTagName('ArticleTitle')->item(0);
			if($articleTitleObj!=null)
				$articleTitle=$articleTitleObj->nodeValue;			
			//get the Abstract text
			$abstractTextObj=$articleObj->getElementsByTagName('AbstractText')->item(0);
			if($abstractTextObj!=null)
				$abstractText=$abstractTextObj->nodeValue;					
			$paginationObj=$articleObj->getElementsByTagName('MedlinePgn')->item(0);
			if($paginationObj!=null)
				$pagination=$paginationObj->nodeValue;					
			$affiliationObj=$articleObj->getElementsByTagName('Affiliation')->item(0);
			if($affiliationObj!=null)
				$affiliation=$affiliationObj->nodeValue;				
			$authorListObj=$articleObj->getElementsByTagName('AuthorList')->item(0);
			if($authorListObj1=null){
				if($authorListObj->hasAttributes()){			
					$authListComplete=$authorListObj->attributes->item(0)->value;
					//echo $authListComplete;   		 
				}
			}
			$languageObj=$articleObj->getElementsByTagName('Language')->item(0);
			if($languageObj!=null)
				$language=$languageObj->nodeValue;	

			$articleDateObj=$articleObj->getElementsByTagName('ArticleDate')->item(0);
			if($articleDateObj!=null){
					$dayObj=$articleDateObj->getElementsByTagName('Day')->item(0);
					$articleDate['day']='';
					if($dayObj!=null)
						$articleDate['day']=$dayObj->nodeValue;
					$monthObj=$articleDateObj->getElementsByTagName('Month')->item(0);
					$articleDate['month']='';
					if($monthObj!=null)
						$articleDate['month']=$monthObj->nodeValue;
					$yearObj=$articleDateObj->getElementsByTagName('Year')->item(0);
					$articleDate['year']='';
					if($yearObj!=null)
						$articleDate['year']=$yearObj->nodeValue;
			}
		}
		// End Parsing article related data
		$citationSubsetObj=$articleObj->getElementsByTagName('CitationSubset')->item(0);
			if($citationSubsetObj!=null)
				$citationSubset=$citationSubsetObj->nodeValue;
		$numberOfReferencesObj=$articleObj->getElementsByTagName('NumberOfReferences')->item(0);
			if($numberOfReferencesObj!=null)
				$numberOfReferences=$numberOfReferencesObj->nodeValue;	
		$otherIDObj=$articleObj->getElementsByTagName('OtherID')->item(0);
			if($otherIDObj!=null)
				$otherID=$otherIDObj->nodeValue;			
		$link="http://www.ncbi.nlm.nih.gov/pubmed/".$pmid;
		$statusObj=$articleObj->getElementsByTagName('PublicationStatus')->item(0);
			if($statusObj!=null)
				$status=$statusObj->nodeValue;		
		
		//Prepare array represinting Publication details	
		$pubDetails['pmid']=$pmid;
		//echo "</br>PMID: ".$pmid."</br>";
		$pubDetails['pmid_version']=$pmIdVersion;
		$pubDetails['created_date']=$this->array_to_date($dateCreated);
		$pubDetails['completed_date']=$this->array_to_date($dateCompleted);
		$pubDetails['revised_date']=$this->array_to_date($dateRevised);
		$pubDetails['pub_model']=$pubModel;
		$pubDetails['issn_number']=$issnNumber;
		$pubDetails['issn_type']=$issnType;
		$pubDetails['cited_medium']=$citedMedium;
		$pubDetails['volume']=$volume;
		//save the JournalName and get it's id
		//echo "</br>Journal Name: ".$journalName."</br>";
		$pubDetails['journal_id']=$this->pubmed->savejournalName($journalName);
		$pubDetails['iso_abbreviation']=$isoAbbreviation;
		$pubDetails['pub_date']=$this->array_to_date($pubDate);
		$pubDetails['article_title']=$articleTitle;
		$pubDetails['abstract_text']=$abstractText;
		$pubDetails['pagination']=$pagination;
		$pubDetails['affiliation']=$affiliation;
		$pubDetails['auth_list_complete']=$authListComplete;
		$pubDetails['language']=$language;
		$pubDetails['article_date']=$this->array_to_date($articleDate);
		$pubDetails['citation_subset']=$citationSubset;
		$pubDetails['Num_of_references']=$numberOfReferences;
		$pubDetails['other_id']=$otherID;
		$pubDetails['status']=$status;
		$pubDetails['link']=$link;		
		$pubDetails['is_deleted']=$isDeleted;	
		//End of preparing array 
		
		return $pubDetails;
	}
	
	/**
	 * Saves the Publication and returns the id of it
	 * @param Array $pubDetails
	 * @param Integer $kolId
	 * @return Integer $pubId
	 */
	function save_publications($pubDetails, $kolId, $isVerified = 0){					
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo $this->db->last_query();
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';		
		//prepare the kol-to-publication association object
		$kolPublication=array();
		$kolPublication['kol_id']=$kolId;
		$kolPublication['pub_id']=$pubId;
		$kolPublication['is_deleted']=0;	
		$kolPublication['is_verified']= $isVerified;
										
		//save the kol-to-publication record
		$isSaved=$this->pubmed->saveKolPublication($kolPublication);
		$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $pubId, MODULE_KOL_PUBLICATION, $kolId);
		//return the publication Id	
		return $pubId;
	}
	
	
	/**
	 * Parses the publication Authors details from XML Object and returns Authors details in an array
	 * @param XML Object $publication
	 * @param Integer $pubId
	 * @return Array
	 */
	function parse_pub_authors($publication){		
		$arrAuthors=array();	
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$authors=$medlineCitation->getElementsByTagName('Author');
		if($authors!=null){
			foreach($authors as $authorObj){
				if($authorObj!=null){
					$author=array();
					$lastName='Not Available';
					$foreName='Not Available';
					$initials='Not Available';
					$suffix='Not Available';
					$is_name_valid='';
					
					$lastNameObj=$authorObj->getElementsByTagName('LastName')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$foreNameObj=$authorObj->getElementsByTagName('ForeName')->item(0);
					if($foreNameObj!=null)
						$foreName=$foreNameObj->nodeValue;
					$initialsObj=$authorObj->getElementsByTagName('Initials')->item(0);
					if($initialsObj!=null)
						$initials=$initialsObj->nodeValue;
					$suffixObj=$authorObj->getElementsByTagName('Suffix')->item(0);
					if($suffixObj!=null)
						$suffix=$suffixObj->nodeValue;
					if($authorObj->hasAttributes()){			
						$is_name_valid=$authorObj->attributes->item(0)->value;
					}
					$author['last_name']=$lastName;
					$author['fore_name']=$foreName;
					$author['initials']=$initials;
					$author['suffix']=$suffix;
					$author['is_name_valid']=$is_name_valid;
					$arrAuthors[]=$author;	
				}	
			}	
		}
		return $arrAuthors;
	}
	
	/**
	 * Saves the array of authers one by one
	 * @param Array $arrAuthors
	 * @param Integer $pubId
	 * @return boolean
	 */
	function save_pub_authors($arrAuthors, $pubId){
		$position=1;
		//Insert batch of authors,  i.e bulk insert
		//$this->db->insert_batch('pubmed_authors', $arrAuthors);
		$query= array(); 
		foreach( $arrAuthors as $row ) {
		    $query[] = '("'.mysql_real_escape_string($row['last_name']).'", "'.$row['fore_name'].'", "'.$row['initials'].'", "'.$row['suffix'].'", "'.$row['is_name_valid'].'")';
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_authors");
			$result = $result->first_row();
			$authId=$result->id;
			$authId = $authId - (sizeof($arrAuthors)-1);
			$arrPubAuthors = array();
			foreach($arrAuthors as $author){
				$pubAuthor = array();			
				$pubAuthor['pub_id']=$pubId;
				$pubAuthor['author_id']=$authId;
				$pubAuthor['position']=$position;
				$pubAuthor['alias_id']=$authId;
				$position++;
				$authId++;
				$arrPubAuthors[] = $pubAuthor;
			}
	
			//Insert batch of  pub authors,  i.e bulk insert
			//$this->db->insert_batch('publications_authors', $arrPubAuthors);
			$query= array(); 
			foreach( $arrPubAuthors as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['author_id'].', '.$row['position'].', '.$row['alias_id'].')';
			}
			$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES '.implode(',', $query));
			
		}
	}
	
	/**
	 * Parses the publication MeshTerms  from XML Object and returns MeshTerms in an array
	 * @param XML Object $publication
	 * @return Array, 
	 */
	function parse_pub_meshterms($publication){
		$arrMeshTerms=array();	
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0); 
		$meshTerms=$medlineCitation->getElementsByTagName('MeshHeading'); 
		foreach($meshTerms as $meshTermObj){
			if($meshTermObj!=null){
				$meshTerm=array();
				$discriptNameObj=$meshTermObj->getElementsByTagName('DescriptorName')->item(0);
				if($discriptNameObj!=null){
					$discriptName=$discriptNameObj->nodeValue;
					if($discriptNameObj->hasAttributes()){			
						$isMajor=$discriptNameObj->attributes->item(0)->value;												   		 
					}
					$meshTerm['term_name']=$discriptName;
					$meshTerm['is_major']=$isMajor;
				}
				
				$arrQualifier=array();
				$qualifierNames=$meshTermObj->getElementsByTagName('QualifierName');				
				foreach($qualifierNames as $qualifierNameObj){
					$isMajor="";
					$arrQualifierNames[]=$qualifierNameObj->nodeValue;				
					if($qualifierNameObj!=null){
						$qualifier=array();					
						$qualifierName=$qualifierNameObj->nodeValue;
						if($qualifierNameObj->hasAttributes()){			
							$isMajor=$qualifierNameObj->attributes->item(0)->value;												   		 
						}
						$qualifier['term_name']=$qualifierName;
						$qualifier['is_major']=$isMajor;
						$arrQualifier[]=$qualifier;
					}														
				}	
				$meshTerm['arr_qualifier']=$arrQualifier;	
				$arrMeshTerms[]=$meshTerm;		
			}			
		}
		return $arrMeshTerms;
	}
	
	/**
	 * saves the array of MeshTerms one by one
	 * @param $arrMeshTerms
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_meshterms($arrMeshTerms, $pubId){
		$query= array();
		foreach($arrMeshTerms as $meshTerm){
			if($meshTerm!=null){
				$termId=0;
				$term=array();
				$term['term_name']=$meshTerm['term_name'];
				$term['parent_id']=$termId;
				// save parent MeshTerm into pubmed_meshTerm
				$termId=$this->pubmed->savePubmedMeshTerm($term);
				
				$pubTerm=array();
				$pubTerm['pub_id']=$pubId;
				$pubTerm['term_id']=$termId;
				$pubTerm['is_major']=($meshTerm['is_major']=='Y') ? 1:0 ;
				$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';
				
				$arrQualifier=array();
				$arrQualifier=$meshTerm['arr_qualifier'];
				$parentId=$termId;
				foreach($arrQualifier as $qualifier){										
					$term=array();
					$term['term_name']=$qualifier['term_name'];
					$term['parent_id']=$parentId;
					// save parent MeshTerm into pubmed_meshTerm
					$termId=$this->pubmed->savePubmedMeshTerm($term);
					
					$pubTerm=array();
					$pubTerm['pub_id']=$pubId;
					$pubTerm['term_id']=$termId;
					$pubTerm['is_major']=($qualifier['is_major']=='Y') ? 1:0 ;
					$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';					
				}				
			}		
		}
		
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_mesh_terms (pub_id, term_id, is_major) VALUES '.implode(',', $query));
		
		
	}
	
	/**
	 * Parses the publication Substance details from XML Object and returns Substances in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_substances($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrSubstances=array();	
		$substances=$medlineCitation->getElementsByTagName('Chemical'); 
		if($substances!=null){
			foreach($substances as $substanceObj){
				if($substanceObj!=null){
					$substance=array();
					$regNumObj=$substanceObj->getElementsByTagName('RegistryNumber')->item(0);
					if($regNumObj!=null)
						$regNum=$regNumObj->nodeValue;
					$substanceNameObj=$substanceObj->getElementsByTagName('NameOfSubstance')->item(0);
					if($substanceNameObj!=null)
						$substanceName=$substanceNameObj->nodeValue;
					$substance['reg_num']=$regNum;
					$substance['name']=	$substanceName;
					$arrSubstances[]=$substance;	
				}	
			}
		}
		return $arrSubstances;
	}
	
	/**
	 * saves the array of Substances one by one
	 * @param $arrSubstances
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_substances($arrSubstances, $pubId){
		$query= array();
		foreach($arrSubstances as $substance){
			if($substance!=null){
				$substanceId=$this->pubmed->savePubmedSubstance($substance);
				
				$pubSubstance=array();
				$pubSubstance['pub_id']=$pubId;
				$pubSubstance['substance_id']=$substanceId;
				
				$query[] = '('.$pubSubstance['pub_id'].', '.$pubSubstance['substance_id'].')';
			}
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_substances (pub_id, substance_id) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * Parses the Publication types from XML Object and returns Publication types in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_types($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrPubTypes=array();	
		$publicationTypes=$medlineCitation->getElementsByTagName('PublicationType'); 
		if($publicationTypes!=null){
			foreach($publicationTypes as $publicationType){				
				if($publicationType!=null){
					$pubType=array();
					$pubType['type']=$publicationType->nodeValue;	
					$arrPubTypes[]=$pubType;	
				}	
			}	
		}
		return $arrPubTypes;
	}
	
	/**
	 * saves the array of Publication types one by one
	 * @param Array $arrPubTypes
	 * @param Integer $pubId
	 * @return boolean
	 */
	function save_pub_types($arrPubTypes, $pubId){
		$query= array();
		foreach($arrPubTypes as $type){
			if($type!=null){
				$typeId=$this->pubmed->savePubmedPubType($type);
				
				$pubType=array();
				$pubType['pub_id']=$pubId;
				$pubType['pub_type_id']=$typeId;
				
				$query[] = '('.$pubType['pub_id'].', '.$pubType['pub_type_id'].')';
			}			
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publications_types (pub_id, pub_type_id) VALUES '.implode(',', $query));
				
	}
	
	/**
	 * Parses the Comments and Corrections from XML Object and returns Comments and Corrections in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_CC($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrCC=array();
		$arrCCObj=$medlineCitation->getElementsByTagName('CommentsCorrections'); 
		if($arrCCObj!=null){
			foreach($arrCCObj as $ccObj){
				if($ccObj!=null){
					$cc=array();
					$reftype='';
					$refSource='';
					$ccPMID='';
					$ccPMIDVersion='';
					if($ccObj->hasAttributes()){			
						$reftype=$ccObj->attributes->item(0)->value;												   		 
					}
					$refSourceObj=$ccObj->getElementsByTagName('RefSource')->item(0); 
					if($refSourceObj!=null)
						$refSource=$refSourceObj->nodeValue;
					$ccPMIDObj=$ccObj->getElementsByTagName('PMID')->item(0); 
					if($ccPMIDObj!=null){
						$ccPMID=$ccPMIDObj->nodeValue;
						if($ccPMIDObj->hasAttributes()){			
							$ccPMIDVersion=$ccPMIDObj->attributes->item(0)->value;												   		 
						}
					}
					$cc['ref_type']=$reftype;
					$cc['ref_source']=$refSource;
					$cc['cc_pmid']=$ccPMID;
					$cc['cc_pmid_version']=$ccPMIDVersion;
					$arrCC[]=$cc;
				}
			}
		}
		return $arrCC;
	}
	
	/**
	 * saves the array of Comments and Corrections one by one
	 * @param $arrCC
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_CC($arrCC, $pubId){
		$query= array(); 
		foreach( $arrCC as $row ) {
			if($row!=null){
		   		$query[] = '("'.mysql_real_escape_string($row['ref_type']).'", "'.$row['ref_source'].'", "'.$row['cc_pmid'].'", "'.$row['cc_pmid_version'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_cc (ref_type, ref_source, cc_pmid, cc_pmid_version) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_cc");
			$result = $result->first_row();
			$ccId=$result->id;
			$ccId = $ccId - (sizeof($arrCC)-1);
			
			$arrPubCCs = array();
			foreach($arrCC as $cc){
				if($cc!=null){
					$pubCC=array();
					$pubCC['pub_id']=$pubId;
					$pubCC['cc_id']=$ccId;
					$arrPubCCs[] = $pubCC;
					$ccId++;
				}			
			}
			$query= array();
			foreach( $arrPubCCs as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['cc_id'].')';
			}
			$this->db->query('INSERT INTO publications_cc (pub_id, cc_id) VALUES '.implode(',', $query));
			
		}		
	}
	
	/**
	 * 
	 * @param unknown_type $publication
	 * @return unknown_type
	 */
	function parse_pub_history($publication){
		$arrHistory=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$historyObj=$pubmedData->getElementsByTagName('History')->item(0);
		if($historyObj!=null){
			$histories=$historyObj->getElementsByTagName('PubMedPubDate');
			if($histories!=null){
				foreach($histories as $historyObj){
					if($historyObj!=null){
						$pubHistory=array();
						$status='';
						$arrDateTime=array();
						if($historyObj->hasAttributes()){			
							$status=$historyObj->attributes->item(0)->value;												   		 
						}
						$yearObj=$historyObj->getElementsByTagName('Year')->item(0);
						if($yearObj!=null)
							$arrDateTime['year']=$yearObj->nodeValue;
						$monthObj=$historyObj->getElementsByTagName('Month')->item(0);
						if($monthObj!=null)
							$arrDateTime['month']=$monthObj->nodeValue;
						$dayObj=$historyObj->getElementsByTagName('Day')->item(0);
						if($dayObj!=null)
							$arrDateTime['day']=$dayObj->nodeValue;
						$hourObj=$historyObj->getElementsByTagName('Hour')->item(0);
						if($hourObj!=null)
							$arrDateTime['hour']=$hourObj->nodeValue;
						$minuteObj=$historyObj->getElementsByTagName('Minute')->item(0);
						if($minuteObj!=null)
							$arrDateTime['minute']=$minuteObj->nodeValue;
							
						$pubHistory['status']=$status;
						$pubHistory['date']=$this->array_to_dattime($arrDateTime);
						$arrHistory[]=$pubHistory;
					}
				}
			}
		}
		return $arrHistory;
	}
	
	/**
	 * 
	 * @param $arrHistory
	 * @param $pubId
	 * @return unknown_type
	 */
	function save_pub_history($arrHistory, $pubId){
		$query= array(); 
		foreach($arrHistory as $pubHistory){
			if($pubHistory!=null){	
				$query[] = '("'.mysql_real_escape_string($pubId).'", "'.$pubHistory['status'].'", "'.$pubHistory['date'].'")';
			}			
		}
		$this->db->query('INSERT INTO publication_history (pub_id, status, date) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * 
	 * @param $publication
	 * @return unknown_type
	 */
	function parse_pub_article_ids($publication){
		$arrPubArticleIds=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$articleIds=$pubmedData->getElementsByTagName('ArticleId');
		foreach($articleIds as $articleIdObj){
			if($articleIdObj!=null){
				$PubArticleId=array();
				$type='';
				$idValue='';
				if($articleIdObj->hasAttributes()){			
					$type=$articleIdObj->attributes->item(0)->value;												   		 
				}
				$idValue=$articleIdObj->nodeValue;
				$PubArticleId['type']=$type;
				$PubArticleId['id_value']=$idValue;
				$arrPubArticleIds[]=$PubArticleId;
			}
		}
		return $arrPubArticleIds;
	}
				
	/**
	 * 
	 * @param $arrPubArticleIds
	 * @param $pubId
	 * @return unknown_type
	 */		
	function save_pub_article_ids($arrPubArticleIds, $pubId){
		$query= array(); 
		foreach( $arrPubArticleIds as $row ) {
			if($row!=null){
		   		$query[] = '("'.mysql_real_escape_string($row['type']).'", "'.$row['id_value'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_article_ids (type, id_value) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_article_ids");
			$result = $result->first_row();
			$id=$result->id;
			$id = $id - (sizeof($arrPubArticleIds)-1);
		
			$arrPublicationArticleIds =array();
			foreach($arrPubArticleIds as $articleId){
				if($articleId!=null){
					$PubArticleId=array();
					$PubArticleId['pub_id']=$pubId;
					$PubArticleId['pub_article_id']=$id;
					$id++;
					
					$arrPublicationArticleIds[] = $PubArticleId;
				}
			}
			$query= array();
			foreach( $arrPublicationArticleIds as $row ) {
				if($row!=null){
			   		$query[] = '('.$row['pub_id'].', '.$row['pub_article_id'].')';
				}
			}
			$this->db->query('INSERT INTO publication_article_ids (pub_id, pub_article_id) VALUES '.implode(',', $query));
			
		}
	}
	
	/**
	 * coverts the date in array format to sql date
	 * @param $arrayDate
	 * @return unknown_type
	 */
	function array_to_date($arrayDate){	
		if(isset($arrayDate['month']) && $arrayDate['month']!=null)	
			$arrayDate['month']=$this->month_to_integer($arrayDate['month']);
		$date='';
		if($arrayDate!=null){
			$date=$arrayDate['year']."-".$arrayDate['month']."-".$arrayDate['day'];			
		}			
		return $date;
	}	
	
	function array_to_dattime($arrDateTime){
		$date='';
		if($arrDateTime!=null){
			$date=$arrDateTime['year']."-".$arrDateTime['month']."-".$arrDateTime['day']." ".$arrDateTime['day'].":".$arrDateTime['day'].":00";			
		}	
		return $date;
	}
	
	
	function processPubmedRecrawlKols(){
		ini_set("max_execution_time",$this->maxScriptTime);
		//Get all the KOLs having the pubmed status 'Recrawl'
		$arrKols = $this->pubmed->getPubmedRecrawlKols();
		
		//Loop trough each KOL
		foreach($arrKols as $arrKolDetail){
			$kolId = $arrKolDetail['id'];
			$this->logText	= "\r\nStarting pubmed processing for KolId ".$kolId." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Get the PMIDs for this KOL
			$arrPMIDs = $this->pubmed->getPMIDs($kolId);
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Check for already existing publication's and associate them with kol
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $kolId,$arrKolDetail,1);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);
								
				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}

				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						$this->send_status_mail($this->logText);
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						//redirect(base_url()."pubmeds_org/process_pubmeds");										
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $kolId, 1);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						fwrite($this->logFile, $this->logText);
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logLastPmidFile,$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
					$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
			$arrKolDetail['is_pubmed_processed']=1;
			$this->pubmed->updatePubmedProcessedKol($arrKolDetail);	
			$this->logText	= "Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			
			$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
		}
	}
	
	function process_pmids($kolId){
		ini_set("max_execution_time",$this->maxScriptTime);
		$arrPMIDs = null;
		$returnData = array();
		$arrPMIDStatuses = array();
		if($arrPMIDs == null){
			$arrPMIDs = array();
			$arrPMIDs = $this->input->post('pmids');
		}
		$arrKolDetail=$this->pubmed->getKolDetail($kolId);
		$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $kolId,$arrKolDetail);
		$associatedPmids = array_diff($arrPMIDs, $arrFilteredPMIDs);
		foreach ($associatedPmids as $pmid){
			$arrPMIDStatuses[$pmid] = 'exist';
		}
		$this->startTime	= microtime(true);
		$pmidsList = implode(',',$arrFilteredPMIDs);
		if($pmidsList != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmidsList;
			if($pmidsList!='')
				$content = $this ->retrieve_page_get($url);	
			if(!$content['response'])	return false;
			$xml = new DOMDocument();
			if(!$xml->loadXML($content['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
				fwrite($this->logFile, $this->logText);	
				//continue;
				die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
			}
	
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				if($remTime<$this->safeTime){
					$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}					
				$pubStartTime=microtime(true);	
				//parse and save publication details
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId=$this->save_publications($pubDetails, $kolId);
				if($pubId!=null){
					//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
					//fwrite($this->logFile, $this->logText);	
				}else{
					$arrPMIDStatuses[$pubDetails['pmid']] = 'error';
					$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
					fwrite($this->logFile, $this->logText);
					continue;
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
				
				$arrPMIDStatuses[$pubDetails['pmid']] = 'done';
			}
			sleep($this->sleepTime);
		}
		$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
		$returnData['status'] = true;
		$returnData['pmidstatuses'] = $arrPMIDStatuses;
		echo json_encode($returnData);
	}
	
//Delete the associations of the PMId and recrawl the details and save the associations
	function recrawl_pmid($pmid){
		if($pmid != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmid;
			
			$response = $this ->retrieve_page_get($url);
			//Try once again if the response of the status is false	
			if($response['status'] == false){
				//give 2 second delay
				sleep($this->sleepTime);
				$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
				fwrite($this->logFile, $this->logText);
				//try once again
				$response = $this ->retrieve_page_get($url);
			}
			// Skipp this and log the details if still respons is false
			if($response['status'] == false){
				//log the details
				$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
				fwrite($this->logFile, $this->logText);
				
				$this->logText = "Recralw : PMID : ".$pmid."\r\n";
				fwrite($this->logFilePmidSkipped, $this->logText);
				//continue to next step
				continue;
			}
			
			$xml = new DOMDocument();
			if(!$xml->loadXML($response['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
				fwrite($this->logFile, $this->logText);	
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				if(!$xml->loadXML($response['response'])){
					//log the details and continue
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);	
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					continue;
					//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
				}										
			}
			
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				$pubId=$this->pubmed->checkPubExist($pmid);
				if($pubId ==null || $pubId == ''){
					//die("Publication with PMID:".$pmid."  not exist.\r\n");	
					$this->logText	= "Publication with PMID:".$pmid."  not exist. \r\n";
					fwrite($this->logFile, $this->logText);										
					continue;
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				$this->logText	= "PMID : ".$pmid."	PubID :".$pubId." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
				$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
					
				//Delete all the initiall associations first
				$this->pubmed->deletePublicationAssociationDetails($pubId);
				
				//pr($arrAuthors);
				//$arrAuthors = array_slice($arrAuthors,0, 2);
				//pr($arrAuthors);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				//$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
			}
			
		}
	}
	
	
	//Identify the partially crawled publications and recrawl them
	function recrawl_partial_pmids(){
		$this->startTime	= microtime(true);
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;	
		$this->logFileName	=$this->logFilePath . "/" . "logfile_partial_pmids_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		
		$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
		
		//Get all the pmids from given date and greater than given publication id
		$arrPMIDs = array();
		$arrPMIDs[] = '22566560';
		for($i=0; $i<sizeof($arrPMIDs);$i=$i+10){
			$authListText='';
			$arrAuthList = array();
			for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
				if( $arrPMIDs[$j]!='')
					$arrAuthList[] = $arrPMIDs[$j];
			}
			$authListText = implode(",",$arrAuthList);
							
			$pubFetchStartTime=microtime(true);				
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
			$this->logText	= "Url generated: ".$url."\r\n";
			fwrite($this->logFile, $this->logText);	
			if($authListText!='')
				$content = $this ->retrieve_page_get($url);	
			if(!$content['response'])	return false;
			$timeTaken=microtime(true)-$pubFetchStartTime;		
			$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);	
			$xml = new DOMDocument();
			if(!$xml->loadXML($content['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
				fwrite($this->logFile, $this->logText);	
				//continue;
				die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
			}

			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
			fwrite($this->logFile, $this->logText);
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				/*if($remTime<$this->safeTime){
					$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}*/					
				$pubStartTime=microtime(true);	
				//parse and save publication details
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId=$this->pubmed->checkPubExist($pubDetails['pmid']);
				if($pubId!=null){
					//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
					//fwrite($this->logFile, $this->logText);	
				}else{
					$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
					fwrite($this->logFile, $this->logText);
					continue;
				}
				//log the last PMID parsed
				file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
				
				//parse 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				echo $numAuthorsPresent;
				if(sizeof($arrAuthors) > $numAuthorsPresent){
					$this->logText	= "PMID : ".$pubDetails['pmid']."	PubID :".$pubId." \r\n ";;
					fwrite($this->logFile, $this->logText);
					$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";;
					fwrite($this->logFile, $this->logText);
					
					//Delete all the initiall associations first
					$this->pubmed->deletePublicationAssociationDetails($pubId);
					pr($arrAuthors);
					//Save the authors
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Get the associated KOLs detais in order to calculate the authorship position
					$arrAssociatedKols = $this->pubmed->getAssociatedKols($pubId);
					$textKolsAssociatedAndPosition = "KOLs Associated and there Positions[kolid,position] : ";
					foreach($arrAssociatedKols as $arrKolDetail){
						pr($arrKolDetail);
						$kolId = $arrKolDetail['id'];
						//Calculate Authorship position and save
						$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
						echo "<br>Position".$position;
						$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
						$textKolsAssociatedAndPosition .= " [".$kolId.",".$position."]";
					}
					$textKolsAssociatedAndPosition .= " \r\n ";
					fwrite($this->logFile, $textKolsAssociatedAndPosition);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$this->logText	= "------------------------------------------ \r\n";
					fwrite($this->logFile, $this->logText);
				}
			}
			sleep($this->sleepTime);
		}
		$this->logText	= "Partial PMIDs processing completed  \r\n";
		fwrite($this->logFile, $this->logText);
	}
	
	private function send_status_mail($message, $mailId = null){
		$config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html';

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear(true);
		
		if($mailId == null)
			$mailId = $this->observerEmailId;
			
		//Send mail to  User
        $this->email->subject($this->logFileName);
        $this->email->from(USER,"Pub Crawling");
		$this->email->message($message);
        $this->email->to($mailId);
		$this->email->attach($this->logFileName,'attachment');
		$this->email->attach($this->logFileNamePmidSkipped,'attachment');
        $this->email->send();
	}
	
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.15'){
			$aContext = array(
			    'http' => array(
			        'proxy' => 'tcp://192.168.1.90:808',
			        'request_fulluri' => true,
			    ),
			);		
			$cxContext = stream_context_create($aContext);
			
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$data = array();
			$res = null;
			$data['status'] = false;
			if(!$res = file_get_contents($url)){
				//$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				//fwrite($this->logFile, $this->logText);	
				//die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
				$data['status'] = false;											
			}else{
				$data['status'] = true;
			}			
			if(!$res){	
				//echo 'Error in connecting to url'.$url;
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
			
			$data['response'] = $res;
			return $data;
		}
	}
	
	function month_to_integer($month){		
		if($month=='Jan')
			return 01;		
		if($month=='feb')
			return 02;
		if($month=='mar')
			return 03;
		if($month=='apr')
			return 04;
		if($month=='may')
			return 05;	
		if($month=='jun')
			return 06;
		if($month=='jul')
			return 07;
		if($month=='aug')
			return 08;
		if($month=='sep')
			return 09;
		if($month=='oct')
			return 10;
		if($month=='nov')
			return 11;
		if($month=='dec')
			return 12;		
			
		return (int)$month;
	}
}