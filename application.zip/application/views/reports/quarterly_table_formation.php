 

<?php

$yearWiseArray = array();
foreach ($data as $values) {
    if (!in_array($values['year'], $yearWiseArray, true)) {
        array_push($yearWiseArray, $values['year']);
    }
}
?>
<thead>
   

</thead>

<?php

foreach ($data as $values) {



    if ($values['month'] == 1 || $values['month'] == 2 || $values['month'] == 3) {
        $finalData[] = array("year" => $values["year"], "data" => $values['month']."_".$values['total']);
    }



    if ($values['month'] == 4 || $values['month'] == 5 || $values['month'] == 6) {
        $finalData[] = array("year" => $values["year"], "data" => $values['month']."_".$values['total']);
    }



    if ($values['month'] == 7 || $values['month'] == 8 || $values['month'] == 9) {
        $finalData[] = array("year" => $values["year"], "data" => $values['month']."_".$values['total']);
    }


    if ($values['month'] == 10 || $values['month'] == 11 || $values['month'] == 12) {
        $finalData[] = array("year" => $values["year"], "data" => $values['month']."_".$values['total']);
    }
}
// pr($yearWiseArray);

foreach ($yearWiseArray as $datas) {

    foreach ($finalData as $yearExtract) {
        if ($yearExtract['year'] == $datas) {
            $quarterData[$datas][] = $yearExtract['data'];
        }
    }
}

foreach ($quarterData as $key => $monthData) {

    echo "<tbody>";


    echo "<tr>";
    echo "<th>Q1-" . $key . "</th>";
    foreach ($monthData as $months) {
        $monthDataQ1=explode("_",$months);
        if ($monthDataQ1[0] == 1 || $monthDataQ1[0] == 2 || $monthDataQ1[0] == 3) {
            echo "<td>" . $monthDataQ1[1] . "</td>";
        }
    }
    echo "</tr>";

    echo "<tr>";
    echo "<th>Q2-" . $key . "</th>";
    foreach ($monthData as $months) {
        $monthDataQ2=explode("_",$months);
        if ($monthDataQ2[0] == 4 || $monthDataQ2[0] == 5 || $monthDataQ2[0] == 6) {
            echo "<td>" . $monthDataQ2[1] . "</td>";
        }
    }
    echo "</tr>";
    echo "<tr>";
    echo "<th>Q3-" . $key . "</th>";
    foreach ($monthData as $months) {
        $monthDataQ3=explode("_",$months);
        if ($monthDataQ3[0] == 7 || $monthDataQ3[0] == 8 || $monthDataQ3[0] == 9) {
            echo "<td>" . $monthDataQ3[1] . "</td>";
        }
    }
    echo "</tr>";
    echo "<tr>";
    echo "<th>Q4-" . $key . "</th>";
   foreach ($monthData as $months) {
        $monthDataQ4=explode("_",$months);
        if ($monthDataQ4[0] == 10 || $monthDataQ4[0] == 11 || $monthDataQ4[0] == 12) {
            echo "<td>" . $monthDataQ4[1] . "</td>";
        }
    }
    echo "</tr>";
    echo "</tbody>";
}
?>
 