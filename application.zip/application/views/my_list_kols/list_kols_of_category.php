<?php
/**
 * File to 'List' kols details of particular category and list name
 * @author: Vinayak
 * @since :2.0
 * @Created on: 11-4-11
 */
	//$queued_js_scripts = array('my_lists/list_kols_of_category');
	// add the JS files into queue i.e Append to the existing queue
	//$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		
?>
<style type="text/css">

	.displayModelBox{
		float:left;
		text-align:right;
		background-color:#000099;
		-moz-border-radius-bottomleft:5px;
		-moz-border-radius-bottomright:5px;
		-moz-border-radius-topleft:5px;
		-moz-border-radius-topright:5px;
		cursor: pointer;
		color: white;
		font-weight: bold;
		font-size:11px;
		margin-left:-2px;
		margin-right:8px;
	}
	
	#listKols label img.micro_view_icon, label img.micro_view_icon {
		cursor:pointer;
		vertical-align:text-top;
		width:18px;
	}
	
	.ui-jqgrid-btable tr.selectedRow{
		background:#d8dfea repeat-x scroll 50% 50% !important;
	}
	tr.rowhover{
		background: #D3DFED;
	    border: 1px solid #79B7E7;
	 /*   color: #1D5987; */
	    font-weight: bold;
	}
	#listKols table{
		margin-top: 2px;
	}
	#listKols tbody tr td{
	/*	border: 1px solid #EEEEEE !important;*/
		border-bottom: 1px solid #dddddd;
		color:#333333;
	    font-size: 11px;
	    padding: 0px 2px 0px 3px;
	    vertical-align: middle;
	}
	#listKols thead th{
	/*	background-color:#ffffff;*/
		border:1px solid #dddddd;
		border-left:0px;
		border-right:0px;
		/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -236px transparent;*/
		color: white;
		color: #000000;
		color: #333333;
	/*	border-right:1px solid #EEEEEE; */
	/*	text-align:center;*/
	}
	#exportOptions{
		float: right;
	}
	.extraOptions{
	    height: 23px;
	}
</style>
	<div class="exportOptionsContainer tooltip-demo tooltop-left">
		<ul class="pageRightOptions">
			<?php 
			if($list_name_id!=NULL && $list_name_id!=0){?>
				<li><div id="addKtlListing"><a href="#" onclick="viewKtlList(<?php echo $list_name_id; ?>);" class="blueButton" rel="tooltip" data-original-title="Add KTL's List " >Add <?php echo lang("KOL");?>'s to List</a></div></li>
			<?php }
			$userId = $arr[0]['user_id'];
			if($this->session->userdata('user_id')==$userId || $listType=='my_list'){?>
				<li><div ><a href="#" class="blueButton" onclick="deleteKols();" rel="tooltip" data-original-title="Remove from the list" >Remove from the list</a></div></li>
			<?php }?>
			<li>
				<div class="excelExportIcon sprite_iconSet" onclick="showExportBox();">
					<a href="#" rel="tooltip" data-original-title="Export profiles into Excel format">&nbsp;</a>
				</div>
			</li>
			<li>
				<div class="pdfExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportPdfProfile();">
					<form action="<?php echo base_url()?>kols/export_pdf" id="kolPdfExport" method="post">
						<a  rel='tooltip' title="Export profile into PDF format" href="#">&nbsp;</a>
					</form>
				</div>
			</li>
			<li>
				<div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBoxInOvearllPage()">
					<a  rel="tooltip" title="Email Profile" href="#">&nbsp;</a>
				</div>
			</li>
		</ul>
	</div>
	<form id="listKols" class="clear">
		<table>
				<thead>
					<tr class="headerBg">
						<th width="2%"><input type='checkbox' name='checkall' onclick='checkedAll(this);'></th>
						<th></th>
						<th width="25%"><?php echo lang("MyLists.Name");?></th>
						<th width="15%"><?php echo lang("track.Specialty");?></th>
						<th width="15%"><?php echo lang("MyLists.Country");?></th>
						<th width="15%"><?php echo lang("Overview.Phone");?></th>
						<th width="15%"><?php echo lang("Overview.Email");?></th>
					</tr>
				</thead>
				<tbody>
				
					<?php 
					$evenOrOddRow	= true;
					foreach($arr as $kolDetails) {
						if(!empty($kolDetails['primary_phone']) && sizeof($kolDetails['primary_phone'])>10){
							$kolDetails['primary_phone']	= (($kolDetails['primary_phone'][0]=="+")?'':'+').$kolDetails['primary_phone'];
						}
						if($evenOrOddRow){
							$evenOrOddRow	= false;
						}else{
							$evenOrOddRow	= true;
						}
						if($kolDetails['gender']==''){
							$kolDetails['gender']	= 'kolMicroViewIcon';
						}
						$kolId="kol_".$kolDetails['kol_id'];
					?>
							
						<tr id="<?php echo $kolId;?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
							<!-- <td><?php echo $kolDetails['id']?><a href="#" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>');">click</a></td> -->
							<td>
								<input type="hidden" id="pdf_<?php echo $kolDetails['kol_id'];?>" value="<?php echo $kolDetails['profile_type'];?>"></input>
								<input type="checkbox" name="list[]" value="<?php echo $kolDetails['kol_id']?>" id="listKols"></input>
							</td>
							<td><div class="tooltip-demo tooltop-left microViewIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['kol_id'];?>',event);return false;"><a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a></div></td>
							<td><span class="record_name"><a  href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>" target="_NEW"><?php  echo $this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);?></a></span></td>
						
							<td><?php echo $kolDetails['specialty']?></td>
							<td><?php echo $kolDetails['country']?></td>
							<td><?php echo '<a class="linkClickToCall" href="callto:'.$kolDetails['primary_phone'].'" >'.$kolDetails['primary_phone'].'</a>';?></td>
							<td><a href="mailto:<?php echo $kolDetails['primary_email']; ?>" id="emailHolder"><?php echo $kolDetails['primary_email']; ?></a></td>
						</tr>
					<?php }?>
						
				</tbody>
			</table>
		</form>
		
		
	<!-- Container for the 'Kol Micro Profile' modal box -->
	<div id="dailog1">	
		<div id="kolMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<div>	
		<div id="addListKtls" class="microProfileDialogBox">
			<div class="profileContent" id="addListKtlsContent"></div>
		</div>
	</div>
	<!-- End of the Container for the 'Kol Micro Profile' modal box -->
<script type="text/javascript">
/*
* To selecte all checkbox with a single check box
* @author vianyak
* @since 2.0
* @created on 12-4-2011
*/
checked=false;
function checkedAll (thisEle) {
	var check =$(thisEle).attr("checked");
	if(check=='checked'){
		check=true;
	}
	
	if(check){
		$.each($('input[name="list[]"]'),function(){
			$('input[name="list[]"]').attr("checked","checked");
		});
	}else{
			$.each($('input[name="list[]"]'),function(){
			$('input[name="list[]"]').removeAttr("checked");
		});
	}
  }

/*
* To delete all selected kols
* @author vianyak
* @since 2.0
* @created on 12-4-2011
*/
function deleteKols(){
	var kolsId = new Array();
	$.each($("input[name=list[]]:checked"),function(){
		kolsId.push($(this).val());
	});
	 var lengthOfArray = kolsId.length;
	
	jConfirm('Are you sure you want to remove selected <?php echo lang("KOL"); ?>s from the list?', 'Please Confirm', function(r) {
		
			if(r){
		
			data={};
			data['list_name_id']='<?php echo $list_name_id;?>';
			$.ajax({
					url:base_url+'my_list_kols/delete_kols/'+kolsId,
					type:'post',
					data:data,
					success:function(returnData){
							$('#listKolsOfcategory').load(base_url+'my_list_kols/list_kols_of_cetagory/'+data['list_name_id']);
							
							var listName = $('#listNameId_'+data['list_name_id']).html();
							var indexOfFirstBracket = listName.indexOf('(');
							var indexOfLastBracket = listName.indexOf(')');

							//Get the value of bracket content
							var subString = listName.substring(indexOfFirstBracket+1,indexOfLastBracket);
							if(subString<lengthOfArray){
								lengthOfArray=lengthOfArray-1;
							}
							//Calculate the count after Removing Kols
							
							var remaningCount = subString-lengthOfArray;
							
							var replace =listName.replace('('+subString+')','('+remaningCount+')');
							
							$('#listNameId_'+data['list_name_id']).html(replace);
					}
				});
			}
		
	});


	if(kolsId!=''){

		
	}else{
		jAlert("No <?php echo lang("KOL");?>s selected to remove from the list");
	}
}


$(document).ready(function(){
	// Added by laxman for IE6 to change background color of tr on mouse over	
	$('#listKols tbody tr').hover (function () {
	  $(this).addClass ("rowhover");
	}, function () {
	  $(this).removeClass ("rowhover");
	});
	//   End 

	$('#listKols tbody tr').click(function(){
		$('#listKols tbody tr').each(function(){
			if($(this).hasClass('selectedRow')){
				$(this).removeClass('selectedRow')
			}
		});
		$(this).addClass('selectedRow');
	});
	
	// Settings for the Dialog Box
	var kolMicroProfileDialogOpts = {
			title: "Profile Snapshot",
			modal: true,
			autoOpen: false,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	$("#kolMicroProfile").dialog(kolMicroProfileDialogOpts);
	var addListKtls = {
            title: "Add KTL's to List",
            modal: true,
            autoOpen: false,
            width: 500,
            height: 'auto',
            draggable: false,
            dialogClass: "microView",
            position: ['center', 170],
            open: function () {
                //display correct dialog content
            }
        };
        $("#addListKtls").dialog(addListKtls);
			
});

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewKolMicroProfile_old(kolId){
	$("#kolMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#kolMicroProfile").dialog("open");
	$("#kolMicroProfile .profileContent").load(base_url+'kols/view_kol_micro/'+kolId);
	return false;
}

function viewKtlList(listingId){
	$("#addListKtls .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#addListKtls").dialog("open");
 	$("#addListKtlsContent").load(base_url + 'my_list_kols/add_ktl_listing/'+listingId);
	return false;
}

function closeKolProfile(){
	$("#arraouHolder").hide();
	$(".profileContent").html("");
	$("#contentHolder").hide();
}

function viewKolMicroProfile(kolId, e){
	var elmt=document.getElementById("kol_"+kolId);	
	var pos = getElementAbsolutePos(elmt);
	var offset = $("#kol_"+kolId).offset();
	var height = $("#kol_"+kolId).height();
	var xPos=pos.x+62;
	var yPos=offset.top + height - 60;//pos.y-27;
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	$("#arraouHolder").css({'position': 'absolute','top':yPos-22,'left':xPos});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+11});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$(".profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		
	$(".profileContent").load(base_url+'kols/view_kol_micro/'+kolId,{},
		function(){	$('#contentHolder .profileContent').unblock(); }
	);
	
	return false;
}
</script>
	