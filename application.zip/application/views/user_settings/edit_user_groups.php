<style type="text/css">

	.userList{
		list-style: none outside none;
	    margin: 0 25px 5px 0;
	    padding: 0;
	}
	.userList li{
		display: inline;
	}
	.groups{
		border-bottom: 1px solid #CCCCCC; 
		cursor: pointer; 
		padding: 5px;
	}
	.groups:hover{
		background-color: #d3dfed;
	}
	.actBtn{
		float: right;
	}
	.a{
		display: none;
	}
	td, th{
		vertical-align: top;
	}
	p{
		margin: 0px;
	}
	td.manangers{
		background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
		background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
		background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		margin-top:2px;
		border-color: #CCCCCC;
	    border-style: solid none;
	    border-width: 1px 0 1px 0;
	}
	td.manangers span{
		color: #333390;
	}
	td.clients{
		background: #DDE7F5;
		background: -moz-linear-gradient(top, #ffffff 0%, #77A4E4 100%);
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ffffff), color-stop(100%,#77A4E4));
		background: -webkit-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -o-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: -ms-linear-gradient(top, #ffffff 0%,#77A4E4 100%);
		background: linear-gradient(to bottom, #ffffff 0%,#77A4E4 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#77A4E4',GradientType=0 );
	}
	td.clients span{
		color: #333390;
	}
	#collapseExpandButton, #scSliderButton{
		margin-top:0px;
		border: 0px; 
	}
	td.noPadding{
		padding: 0px;
		width: 25px;
	}
	td.userInfo:hover, td.userSelected{
		background-color: #d3dfed;
	}
	td.userInfo{
		border: 1px solid #fff;
	}
</style>
<script type="text/javascript">
	var group_type = "<?php echo $groupsOrTeams; ?>";
	function addGroupData(){
		if($("#newGroup").val() == ''){
				jAlert("Group name can not be empty ?");
				return false;
			}else if($('.userCheckBox:checked').length < 1){
				jAlert("Atleast one user should be present for each group");
				return false;
				}
			var data = $("#groupsData").serialize();
			$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$.ajax({
				url:base_url+"user_settings/save_user_group",
				data:data,
				type:"post",
				dataType:"json",
				success: function(returnData){
					if(returnData.status){
						//$("#settingsContentHolder .profileContent").load(base_url+"user_settings/get_all_users_groups");
						call_selected_setting(group_type+"s");
					}else{
						jAlert("Entered group name already exist please enter different name");
						}
					$("#settingsContentHolder").unblock();
				}
				});
		}

	function addUserGroups(){
			$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$("#settingsContentHolder .profileContent").load(base_url+"user_settings/add_user_groups/"+group_type);
		}
		/*$(".groups").mouseover(function(){
				$(this).find(".actBtn").css("display","block");
			});
		$(".groups").mouseout(function(){
			$(this).find(".actBtn").css("display","none");
		});

		$(".groups").click(function(){
			$(this).find(".halfText").toggleClass("a");
			$(this).find(".fullText").toggleClass("a");
		});*/	
	function editGroup(id){
		$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#settingsContentHolder .profileContent").load(base_url+"user_settings/edit_users_groups_by_id/"+id+"/"+group_type);
		$("#settingsContentHolder").unblock();
	}

	function updateGroupData() {
		if($("#newGroup").val() == ''){
			jAlert("Group name can not be empty ?");
			return false;
		}else if($('.userCheckBox:checked').length < 1){
			jAlert("Atleast one user should be present for each group");
			return false;
			}
		var data = $("#groupsData").serialize();
		$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
			url:base_url+"user_settings/update_user_group",
			data:data,
			type:"post",
			dataType:"json",
			success: function(returnData){
				if(returnData.status){
					call_selected_setting(group_type+"s");
				}else{
					jAlert("Entered group name already exist please enter different name");
					}
				$("#settingsContentHolder").unblock();
			}
			});
	}
	function deleteGroup(id){
		jConfirm('Are you sure you want to delete this group ?','Please Confirm',function(r){
				if(r){
					$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$.ajax({
						url:base_url+"user_settings/delete_user_group/"+id,
						type:"post",
						dataType:"json",
						success: function(returnData){
							if(returnData.status){
								$("#"+id).remove();
							}
//							$("#settingsContentHolder .profileContent").load(base_url+"user_settings/get_all_users_groups");
							$("#settingsContentHolder").unblock();
						}
						});
					}
			});
		
	}
	function selectOne(thisEle){
		var checkBox	= $(thisEle).find(".userCheckBox");
		if($(checkBox).attr("checked")=="checked" || $(checkBox).attr("checked")=="undefined"){
			$(checkBox).removeAttr("checked");
			$(thisEle).removeClass("userSelected");
		}else{
			$(checkBox).attr("checked","checked");
			$(thisEle).addClass("userSelected");
		}
	}
	function selectAll(thisEle) {
		if($(thisEle).attr("checked") == "checked"){
			$(".userCheckBox").each(function(){
				$(this).attr("checked","checked");
				$(this).parent().parent().addClass("userSelected");
			});
		}else{
			$(".userCheckBox").each(function(){
				$(this).removeAttr("checked");
				$(this).parent().parent().removeClass("userSelected");
			});
		}
	}
	function selectAllAlignedToManager(thisEle){
		if($(thisEle).attr("checked") == "checked"){
			$(".m"+$(thisEle).attr("id")).each(function(){
					$(this).attr("checked","checked");
					$(this).parent().parent().addClass("userSelected");
				});
		}else{
			$(".m"+$(thisEle).attr("id")).each(function(){
				$(this).removeAttr("checked");
				$(this).parent().parent().removeClass("userSelected");
			});
		}
	}
	function selectAllAlignedToClient(thisEle){
		if($(thisEle).attr("checked") == "checked"){
			$(".c"+$(thisEle).attr("id")).each(function(){
					$(this).attr("checked","checked");
					$(this).parent().parent().addClass("userSelected");
				});
		}else{
			$(".c"+$(thisEle).attr("id")).each(function(){
				$(this).removeAttr("checked");
				$(this).parent().parent().removeClass("userSelected");
			});
		}
	}
	function toggleGroup(thisEle,groupId){
		$('tr.group'+groupId).toggle();
		$(thisEle).parent().parent().find('div.collapseSlider').toggleClass('expandSlider');
	}
	function cancelGroupData(type) {
		call_selected_setting(type+"s");
	}
	$(document).ready(function(){
		$("td.userInfo").click(function(event) {
			var thisEle		= this;
			var checkBox	= $(thisEle).find(".userCheckBox");
			if($(checkBox).attr("checked")=="checked" || $(checkBox).attr("checked")=="undefined"){
				$(checkBox).removeAttr("checked");
				$(thisEle).removeClass("userSelected");
			}else{
				$(checkBox).attr("checked","checked");
				$(thisEle).addClass("userSelected");
			}
		});
		$("td.userInfo input.userCheckBox:checkbox").click(function(event) {
			$(this).parent().parent().toggleClass("userSelected");
			event.stopPropagation();
		});
	});
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage">			
			<?php if($groupsOrTeams=='group'){
    			 if(isset($arrUserData)){?>
    				<input class="addNewGroup" type="button" onclick="addUserGroups();"  value="Add new user group" style="float: right;">
    			<?php } ?>
				<h3>Manage User Groups</h3>
			<?php } else{
			    if(isset($arrUserData)){ ?>
        				<input class="addNewGroup" type="button" onclick="addUserGroups();"  value="Add new team" style="float: right;">
        		<?php } ?>
				<h3>Manage User Teams</h3>
			<?php } ?>
		</div>
	</div>
</div>
<div style="width: 85%; margin: auto;">
	<?php
	$i=0;
	$noOfColumns	= 4;
	$noOfColumnsForGroups	= 1;
	if(isset($arrUserData)){
	?>
		<div>
			<table>
				<tr>
				<?php
				foreach($arrUserData as $key=>$rowData){ 
					if($i%$noOfColumnsForGroups==0){
						echo '</tr><tr>';
					}
					?>
					<td>
					<div class="groups" id="<?php echo $key;?>">
						<div>
							<div style="font-weight: bold; margin-bottom: 8px;"><?php echo $rowData['group_name']." (".sizeof($rowData['name']).")";?>
							<div class="actBtn">
                                                            <?php if($this->common_helpers->isActionAllowed('user group','edit')){ ?>
								<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="editGroup(<?php echo $key;?>); return false;">
								</div>
                                                            <?php }?>
                                                            <?php if($this->common_helpers->isActionAllowed('user group','delete')){ ?>
								<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteGroup(<?php echo $key;?>); return false;">
								</div>
                                                            <?php }?>
							</div>
							</div>
						</div>
						<?php 
							$userNames = implode(',  ',$rowData['name']);
							if(strlen($userNames) >= 340){
						?>
						<div class="halfText" style="margin-bottom: 5px;">
							<?php echo substr($userNames,0,340)."...";?>
						</div>
						<div class="fullText a" style="margin-bottom: 5px;">
							<?php echo $userNames;?>
						</div>
						<?php }else{?>
						<div style="margin-bottom: 5px;">
							<?php echo substr($userNames,0,340);?>
						</div>
						<?php }?>
					</div>
					</td>				
				<?php $i++;
				}?>
				</tr>
			</table>
		</div>
	<?php }?>
	<?php if(isset($arrUsers)){
	    ?>
		<div style="">
			<form id="groupsData" method="post">
				<input type="hidden" name="group_type" value="<?php echo $groupsOrTeams; ?>" />
				<table class="userDetails">
					<tr>
						<?php if($groupsOrTeams=='group'){ ?>
							<th>New Group Name :</th>
						<?php }else{ ?>
							<th>New Team Name :</th>
						<?php } ?>	
						<td>
							<?php if(isset($arrExistUserData['group_id']) && $arrExistUserData['group_id'] != ''){?> 
								<input type="hidden" name="group_id" value="<?php echo $arrExistUserData['group_id'];?>">
							<?php }?>
							<input id="newGroup" type="text" name="group_name" size="30" maxlength="64" <?php if(isset($arrExistUserData['group_name']) && $arrExistUserData['group_name'] != ''){?> value="<?php echo $arrExistUserData['group_name'];?>"<?php }?>></input>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<?php
								$i=0;
								$mangerId	= $arrUsers[0]['m_id'];
								$clientId	= $arrUsers[0]['client_id'];
							?>
							<table class="userDetails alignLeft" style="border: 1px solid #EEEEEE;">
								<tr><td colspan="2"><input type="checkbox" onclick="selectAll(this);"></input><strong>Select All Users</strong></td></tr>
								<tr>
									<td colspan="4" class="clients">
										<input id="<?php echo $clientId?>" type="checkbox" onclick="selectAllAlignedToClient(this);"></input><strong>Select all users of <span class="clientsName"><?php echo $arrUsers[0]['client_name']?></span></strong>
										<div id="collapseExpandButton" class="expandSlider collapseSlider">
											<a class="tooltipLink" rel="tooltip" href="#" onclick="toggleGroup(this,<?php echo $clientId?>);return false;" data-original-title="Expand/Collapse"> </a>
										</div>
									</td>
								</tr>
								<tr class="group<?php echo $clientId?>">
									<td colspan="4" class="manangers"><input class="c<?php echo $clientId?>" id="<?php echo $mangerId?>" type="checkbox" onclick="selectAllAlignedToManager(this);"></input><strong>Select all users aligned to Manager <span class="managersName"><?php echo $arrUsers[0]['m_fname'].' '.$arrUsers[0]['m_lname']?></span></strong></td>
								</tr>
								<tr class="group<?php echo $clientId?>">
								<?php 
								foreach($arrUsers as $user){
									if(($i%$noOfColumns==0) || ($mangerId!=$user['m_id']) || ($clientId!=$user['client_id'])){
										$i=0;
										if(($clientId!=$user['client_id'])){
											$clientId	= $user['client_id'];
											echo '</tr><tr><td colspan="4" class="clients"><input id="'.$clientId.'" type="checkbox" onclick="selectAllAlignedToClient(this);"></input><strong>Select all users of <span class="clientsName">'.$user['client_name'].'</span></strong>';
											echo '<div id="collapseExpandButton" class="expandSlider collapseSlider">
													<a class="tooltipLink" rel="tooltip" href="#" onclick="toggleGroup(this,'.$clientId.');return false;" data-original-title="Expand/Collapse"> </a>
												</div>';
											echo '</td>';
										}
										if(($mangerId!=$user['m_id'])){
											$mangerId	= $user['m_id'];
											echo '</tr><tr class="group'.$clientId.'"><td colspan="4" class="manangers"><input class="c'.$clientId.'" id="'.$mangerId.'" type="checkbox" onclick="selectAllAlignedToManager(this);"></input><strong>Select all users aligned to Manager <span class="managersName">'.$user['m_fname'].' '.$user['m_lname'].'</span></strong></td>';
										}
										echo '</tr><tr class="group'.$clientId.'">';
									}
									?>
									<td class="userInfo <?php if(in_array($user['id'],$arrExistUserData['name'])) echo 'userSelected';?>">
										<div>
											<input type="checkbox" class="userCheckBox <?php echo 'm'.$mangerId.' c'.$clientId;?>" name="users_id[]" value="<?php echo $user['id']?>" <?php if(in_array($user['id'],$arrExistUserData['name'])) echo 'checked="checked"';?> />
											<?php if($user['mem_pic'] != ''){?>
												<img height="50" src="<?php echo base_url()?>images/user_profile_images/<?php echo $user['mem_pic'];?>" />
											<?php }else{?>
												<img src="<?php echo base_url()?>images/user3.png" />
											<?php  }?>
											<p><strong><?php echo $user['first_name']." ".$user['last_name']?></strong></p>
											<p><?php echo $user['title']?></p>
											<p><?php echo $user['department']?></p>
										</div>
									</td>
									<!-- td class="noPadding"><input type="checkbox" class="userCheckBox <?php echo 'm'.$mangerId.' c'.$clientId;?>" name="users_id[]" value="<?php echo $user['id']?>" <?php if(in_array($user['id'],$arrExistUserData['name'])) echo 'checked="checked"';?> ></input></td>
									<td class="noPadding">
										<?php if($user['mem_pic'] != ''){?>
										<img height="50" src="<?php echo base_url()?>images/user_profile_images/<?php echo $user['mem_pic'];?>" />
										<?php }else{?>
										<img src="<?php echo base_url()?>images/user3.png" />
										<?php  }?>
									</td>
									<td>
										<p><strong><?php echo $user['first_name']." ".$user['last_name']?></strong></p>
										<p><?php echo $user['title']?></p>
										<p><?php echo $user['department']?></p>
									</td-->
									<?php
									$i++;
								}?>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" style="text-align:center">
							<div id="submitBtn">
							<?php if(isset($arrExistUserData['group_id']) && $arrExistUserData['group_id'] != ''){?>
								<?php if($groupsOrTeams=='group'){ ?>
									<input type="button" onclick="cancelGroupData('group');" value="Cancel" >
									<input type="button" onclick="updateGroupData();" value="Update Group" >
								<?php }else{ ?>
									<input type="button" onclick="cancelGroupData('team');" value="Cancel" >
									<input type="button" onclick="updateGroupData();" value="Update Team" >
								<?php } ?>
							<?php }else{?>
								<?php if($groupsOrTeams=='group'){ ?>
									<input type="button" onclick="cancelGroupData('group');" value="Cancel" >
									<input type="button" onclick="addGroupData();" value="Create Group" >
								<?php }else{ ?>
									<input type="button" onclick="cancelGroupData('team');" value="Cancel" >
									<input type="button" onclick="addGroupData();" value="Create Team" >
								<?php } ?>
							<?php }?>
							</div>
						</td>
					</tr>
				</table>
			</form>
		</div>
	<?php }?>
</div>