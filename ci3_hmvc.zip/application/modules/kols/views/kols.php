 <link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" />
 <link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
 <link rel="stylesheet" href="<?php echo base_url().ASSETS;?>modules/kols/css/kols.css" />
<?php 
$queued_js_scripts = array('modules/kols/js/export_options',
		'modules/kols/js/kols',
		'alerts/jquery.alerts',
		'jquery_validator/dist/jquery.validate',
		'js/chosen.jquery'
);
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
 div.defaultProfileIcon {
    background: rgba(0, 0, 0, 0) url(../assets/images/KOL_No_image.svg) no-repeat scroll 0 0 / 40px 40px;
    height: 40px;
    width: 40px;
/*     margin-top: 20%; */
}
.defaultProfileIcon.Male {
    background: url("../assets/modules/kols/images/male_kol_profile.svg") no-repeat scroll 0 0 / 40px 40px !important;
}
.defaultProfileIcon.Female {
    background: url("../assets/modules/kols/images/female_kol_profile.svg") no-repeat scroll 0 0 / 40px 40px !important;
}
.displayBlock{
display:block;
font-size:10px;
}
.filtersApplied{
    border: 1px solid;
    padding: 7px 12px;
    background: #ffeedd;
    border-radius: 8px;
    font-size: 11px;
}
 </style>
 <script>
 $(document).ready(function (){
	    display_kol_records_range();
});
 function display_kol_records_range(){
	 var kols_count		='<?php echo $kols_count;?>';
	 var cur_page		='<?php echo $this->ajax_pagination->cur_page;?>';
	 var records_per_page='<?php echo $this->ajax_pagination->per_page?>';
	 var startRecordIndex=((cur_page-1)*records_per_page)+1;
	 var endRecordIndex	=parseInt(startRecordIndex)+parseInt(records_per_page)-1;
	 if(endRecordIndex>kols_count)
	 	endRecordIndex=kols_count;
	 $("#display_records_count").html('Showing '+startRecordIndex+' to '+endRecordIndex+' of '+kols_count);
 }
 function selectAll(thisEle) {
     if($(thisEle).prop("checked") == true){
	         $('input[name="list[]"]').attr("checked","checked");
     }
     else if($(thisEle).prop("checked") == false){
	         $('input[name="list[]"]').removeAttr("checked");
     }
 }
 </script>
 <div id="kolsListing">
 <table class="table table-hover">
       <tr>
        <td width="2%">
         	<div class="displayBlock">
         		<input type="checkbox" onclick='selectAll(this);'>
         	</div>
		</td>
		<td width="8%">
			<p>Select All</p>
		</td>
		<td colspan="3">
		 <div class="filtersApplied">
			 Refined By:&nbsp;
			 <?php echo $filtersApplied;?>
			 |&nbsp;<?php echo $savedQueryFilterApplied;?>&nbsp;
			<a onclick="reset_filters();return false;">
			 	<span class="glyphicon glyphicon-refresh" title="Reset Filters"></span> Reset Filter
			 </a>
		 </div>
		</td>
		<td class="align_right">
			<div id="display_records_count"></div>
		</td>
      </tr>
    <tbody style="font-weight: 100">
    <?php foreach($kol_details as $kol){ ?>
      <tr>
        <td>
         	<label><input name="list[]" value="<?php echo $kol['kols_client_visibility_id'];?>" type="checkbox"></label>
		</td>
        <td>
        	<?php if(($kol['profile_image']== '') && ($kol['gender']=='Male')){?>
           		<div class="defaultProfileIcon Male" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>
           	<?php } elseif (($kol['profile_image']== '') && ($kol['gender']=='Female')){?>
           		<div class="defaultProfileIcon Female" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>  
           	<?php }elseif($kol['profile_image']!= ''){?>    
           		<img class="defaultProfileIcon img-responsive" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);" src="<?php echo base_url().'images/kol_images/resized/'.$kol['profile_image'];?>">
           	<?php }else{?>    
           		<div class="defaultProfileIcon" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>  
           	<?php }?>
        </td>
        <td>
        	<div class="displayBlock">
        		<a href="<?php echo base_url()."kols/kols/view/". $kol['unique_id'];?>">
        			<?php echo $this->common_helper->get_name_format($kol['first_name'],$kol['middle_name'],$kol['last_name']);?>
        		</a>
        	</div>
        	<div class="displayBlock"><?php echo $kol['specs']?></div>
        </td>
        <td>
        	<div class="displayBlock"><?php echo $kol['name']?></div>
        	<div class="displayBlock"><?php echo $kol['city'],','.$kol['state'].','.$kol['country']?></div>
        </td>
        <td>
            <div class="displayBlock"><?php echo $kol['speciality']?></div>
        	<div class="displayBlock">Created BY:<?php echo $kol['created_by']?></div>
        	<div class="displayBlock">Created on :<?php echo $kol['created_on']?></div>
        </td>
        <td>
				<a type="button" class="btn custom-btn requestProfileIcon" style="float:right;" onclick="addNewKolProfile(<?php echo $kol['kols_client_visibility_id']?>,this);return false;" title="Request">
					Request
				</a	>
		        <?php 
		        $role_permissions=$this->config->item('role_permissions');
		        if(($role_permissions[$module_id]['delete'])==1){?>
		        	<a onclick="showKolDeleteModalBox('<?php echo $kol['unique_id'];?>');return false;">
						<span class="glyphicon glyphicon-remove-circle"></span>
					</a>
				<?php }?>
				<?php if(($role_permissions[$module_id]['edit'])==1){?>
					<a href="<?php echo base_url()."kols/kols/add_kol/". $kol['unique_id'];?>">
						<span class="glyphicon glyphicon-edit"></span>
					</a>
				<?php }?>
		</td>
      </tr>
      <?php }?>
		<tr class="searchPagination" style="background-color: white;">
            <td colspan="<?php echo ($viewType=='list')?'7':'6';?>">
              <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="doSearchFilter();">
                <?php $arrPaginationValues = explode(',', PAGINATION_VALUES);
                foreach($arrPaginationValues as $key =>$value){
                    if($value==$this->ajax_pagination->per_page){
                        echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
                    }else{
                        echo '<option value="'.$value.'" >'.$value.'</option>';
                    }
                }?>
                 </select> Records Per Page 
            <?php
            $config['base_url'] = base_url()."kols/kols/reload_filters";
            $config['total_rows'] = $kols_count;
            $config['per_page'] =$this->ajax_pagination->per_page;
            $config['postVar'] = 'page';
            $this->ajax_pagination->initialize($config);
            print $this->ajax_pagination->create_links();
            ?>        
            </td>
        </tr>
    </tbody>
  </table>
 </div>