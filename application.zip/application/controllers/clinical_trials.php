<?php
/**
*Controller for Clinical Trials operations
*@author Ambarish N
*@since 
*@package application.controllers	
*@created on 10-01-2011
*
*/

class Clinical_trials extends Controller{
	
	var $maxScriptTime		= 1200;
	var $logFileName		= '';
	var $startTime			= '';
	var $logFile			='';
	var $logText			='';
	var $pmidBatchSize		=10;
	var $sleepTime			=2;
	var $safeTime			=10;

	//Constructore
	function Clinical_trials(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('clinical_trial');
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		$this->logFilePath		= $this->config->item('app_folder_path').'system/logs/clinical';
		//$this->_is_logged_in();	
	}
	
	/*
	 * Processes the kols for Clinical Trials and saves related data into database
	 */
	function process_clinical_trials(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		fwrite($this->logFile, $this->logText);
		
		ini_set("max_execution_time",$this->maxScriptTime);			
		//get the ClinicalTrialsUnprocessed kol's
		$arrKolDetails=$this->clinical_trial->getClinicalTrialsUnprocessedKols();
		if(sizeof($arrKolDetails)<1){
			$this->logText	= "There are No Unprocessed KOL ids, Terminating Process..  \r\n";
			fwrite($this->logFile, $this->logText);
			die("Sorry! There are No Unprocessed KOL ids, Terminating Process..");
		}
		$this->logText	= "Following are the Unprocessed KOL ids  \r\n";
		fwrite($this->logFile, $this->logText);
		foreach($arrKolDetails as $arrKolDetail){
			$this->logText	= $arrKolDetail['id']."  \r\n";
			fwrite($this->logFile, $this->logText);
		}		
		$firstName='';
		$midleName='';
		$lastName='';
		$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
		fwrite($this->logFile, $this->logText);	
		//Start of loop trought each kol, generate name combinations, gather CTID's, get Clinical Trials, parse and save data 
		foreach($arrKolDetails as $arrKolDetail){
			$kolStartTime=microtime(true);			
			$this->logText	= "\r\nStarting Clinical Trials processing for KOLId ".$arrKolDetail['id']." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			// get the name details			
			$firstName=$arrKolDetail['first_name'];
			$midleName=$arrKolDetail['middle_name'];
			$lastName=$arrKolDetail['last_name'];
			$kolId=$arrKolDetail['id'];
			//get the different combinations of names
			$arrNameCombinations=$this->generate_name_combinations($firstName, $midleName, $lastName);
			$this->logText	= "KOL Name: ".$firstName." ".$midleName." ".$lastName."  \r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "Following are the Name combinations genarated  \r\n";
			fwrite($this->logFile, $this->logText);
			foreach($arrNameCombinations as $nameCombination){
				$this->logText	= $nameCombination."  \r\n";
				fwrite($this->logFile, $this->logText);
			}
			
			//Get the list of Clinical Trials ID's for each possible Author name and store it in a array
			$this->logText	= "\r\nStarting getting CTID's  \r\n";
			fwrite($this->logFile, $this->logText);
			$arrCTIDs=array();
			$count=0;	
			$gathCTIDTime=microtime(true);
			foreach($arrNameCombinations as $authName){
				//Search by sponseri.e institution name
				//http://clinicaltrials.gov/search?spons=National%20Institute%20of%20Mental%20Health?&displayxml=true
				//With first received from filter
				//http://clinicaltrials.gov/search?spons=Cooper%20University%20Hospital?&displayxml=true&rcv_s=01%2F01%2F2012&rcv_e=01%2F01%2F2013
				$url = "http://clinicaltrials.gov/ct2/results?&displayxml=true&term=".$authName."[author";
				$content = $this ->retrieve_page_get($url);	
				if(!$content)	return false;
				//$content = str_replace(array('&lt;','&gt;'),array('<','>'),$content);
				
				//echo $content;
				$xml = new DOMDocument();
				if(!$xml->loadXML($content)){
					$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}		
				
				$searchResultsObj = $xml->getElementsByTagName('search_results')->item(0);
				$idList=$searchResultsObj->getElementsByTagName('nct_id');
				foreach($idList as $idObj){
					$arrCTIDs[]=$idObj->nodeValue;					
				}
				$this->logText	= "No of CTID's found for name '".$authName."': ".(sizeof($arrCTIDs)-$count)."\r\n";
				fwrite($this->logFile, $this->logText);
				$count=sizeof($arrCTIDs);
				sleep($this->sleepTime);
			}
			$this->logText	= "Total No of CTIDs found: ".sizeof($arrCTIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			$timeTaken=microtime(true)-$gathCTIDTime;
			$this->logText	= "Time taken to gather CTIDs: ".(microtime(true)-$gathCTIDTime)."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$arrUniqueCTIDs = array_unique($arrCTIDs);	
			$arrUniqueCTIDs=array_values($arrUniqueCTIDs);
			$this->logText	= "\r\nTotal No of CTIDs found after removing duplicates: ".sizeof($arrUniqueCTIDs)." \r\n";
			fwrite($this->logFile, $this->logText);
			//End of getting the Clinical trial ID's
			
			//Check for already existing Clinical Trial's and associate them with kol
			$arrFilteredCTIDs=$this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId);
			$this->logText	= "Total No of CTIDs found after removing already existing Clinical Trials in database: ".sizeof($arrFilteredCTIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			//End of checking and associating already existing Clinical Trials

		
			//Get the Clinical Trial details for all the CTID's
			$this->logText	= "\r\nStart of getting the Clinical Trials details for each CTID \r\n";
			$this->logText	= "Following Clinical Trials with CTID's are parsed and saved sucessfully\r\n ";
			fwrite($this->logFile, $this->logText);
			fwrite($this->logFile, $this->logText);
			foreach($arrFilteredCTIDs as $uniqueCTID){
				$ctFetchStartTime=microtime(true);	
				$url = "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true";
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);
				$content = $this ->retrieve_page_get($url);		
				if(!$content)	return false;
				$timeTaken=microtime(true)-$ctFetchStartTime;		
				$this->logText	= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);				
				$xml = new DOMDocument();
				if(!$xml->loadXML($content)){
					$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
					fwrite($this->logFile, $this->logText);	
					//continue;
					die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}			
				
				//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
				$clinicalStudys = $xml->getElementsByTagName('clinical_study');
				foreach($clinicalStudys as $clinicalStudy){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
					}
					
					$ctStartTime=microtime(true);
					//getting the parsed values for Clinical trial 
					$ctDetails=$this->parse_ct_details($clinicalStudy);					
					//echo "</br><pre>";
						
					//saves the Clinical trial details
					$ctId=$this->save_clinical_trials($ctDetails, $kolId);	
					if($ctId!=null){
						//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);						
					}else{
						$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
						fwrite($this->logFile, $this->logText);
						continue;	
					}	
					
					//getting the parsed values for sponsers
					$arrSponsers=$this->parse_clinicle_sponsers($clinicalStudy);
					
					//saves sponser details and returns bollean value
					$isSaved=$this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
					
					//getting the parsed values for Intervention
					$arrIntervention=$this->parse_clinicle_intervention($clinicalStudy);
					
					//saves Intervention details and returns bollean value
					$isSaved=$this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
					
					//getting the parsed values for Keywords
					$arrKeyword=$this->parse_clinicle_keyword($clinicalStudy);
					
					//saves Keyword details and returns bollean value
					$isSaved=$this->save_keyword($arrKeyword, $ctId);	
					
					//getting the parsed values for Meshterms
					$arrMeshterms=$this->parse_clinicle_meshterms($clinicalStudy);
					
					//saves Meshterms details and returns bollean value
					$isSaved=$this->save_meshterms($arrMeshterms, $ctId);	
					
					//getting and parsed values for Investigators
					$arrInvestigators=$this->parse_clinicle_investigators($clinicalStudy,$arrNameCombinations);
					
					//saves $arrInvestigators details and returns bollean value
					$isSaved=$this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
				
					$timeTaken=microtime(true)-$ctStartTime;
					$this->logText	= "CTID '".$ctDetails['ct_id']."'	Time taken for: ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah Clinical Trial, parsing and saving
			$this->logText	= "End of Procesing all the CTID's \r\n";
			fwrite($this->logFile, $this->logText);		
			echo "</br>KOLID :".$arrKolDetail['id']." Clinical Trial Processed</br>";
			$arrKolDetail['is_clinical_trial_processed']=1;
			$this->clinical_trial->updateClinicalTrialProcessedKol($arrKolDetail);
			$this->logText	= "Clinical Trial Processing of KOLID :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);		
		}
		// End of loop trough each kol	
	}
	
	
	/**
	 * parse the values for Clinical Trial
	 * 
	 * @param $clinicalStudy
	 * @return Array $ctDetails
	 */
	function parse_ct_details($clinicalStudy,$arrKolNameCombination=array()){
		$ctDetails = array();
		$trialName = ''; 
		$statusId = '';
		$ctId='';
		$purpose = ''; 
		$condition = '';
		$phase='';
		$officialTitle = ''; 
		$studyType = '';
		$startDate='';
		$endDate = ''; 
		$link = '';
		
		//getting the Trial Name
		$breifTitleObj= $clinicalStudy->getElementsByTagName('brief_title')->item(0);
		if($breifTitleObj !=''){
			$trialName = $breifTitleObj->nodeValue;
		}
	 	//pr($trialName);
		
		//getting the Status
		$statusObj = $clinicalStudy->getElementsByTagName('overall_status')->item(0);
		$statusName = '';
		if($statusObj!=''){
			$statusName = $statusObj->nodeValue;
			if($statusName == ''){
				$statusName = 'NotAvailable';
			}
			$statusId=$this->clinical_trial->saveStatus($statusName);
		}
		//pr($statusId);
			
		//getting the CTID
		$ctIdObj = $clinicalStudy->getElementsByTagName('id_info')->item(0);
		if($ctIdObj != ''){
			$nctIdObj = $ctIdObj->getElementsByTagName('nct_id')->item(0);
			$ctId = $nctIdObj->nodeValue;
		}
		// pr($ctId);	
		
		//getting the Purpose of Trial
		$purposeObj = $clinicalStudy->getElementsByTagName('brief_summary')->item(0);
		$textObj = $purposeObj->getElementsByTagName('textblock')->item(0);
		if($textObj !=''){
			$purpose = $textObj->nodeValue;
		}
		//pr($purpose);		
		
		//getting the Condition
		$arrCondition	= array();
		foreach($clinicalStudy->getElementsByTagName('condition') as $conditionObj){
			if($conditionObj!=''){
				$arrCondition[]=$conditionObj->nodeValue;
			}
		}
		
		//getting the Phase
		$phaseObj = $clinicalStudy->getElementsByTagName('phase')->item(0);
		if($phaseObj!=''){
			$phase = $phaseObj->nodeValue;
		}
		//pr($phase);		
		
		//getting the Official Title
		$officialTitleObj = $clinicalStudy->getElementsByTagName('official_title')->item(0);
		if($officialTitleObj!=''){
			$officialTitle=$officialTitleObj->nodeValue;
		}
		//pr($officialTitle);
		
		//getting the Study Type
		$studyTypeObj = $clinicalStudy->getElementsByTagName('study_type')->item(0);
		if($studyTypeObj!=''){
			$studyType=$studyTypeObj->nodeValue;
		}
		//echo 'StudyType</br>'; pr($studyType);	

		//getting the Start Date
		$startDateObj = $clinicalStudy->getElementsByTagName('start_date')->item(0);
		if($startDateObj!=''){
			$startDate=$startDateObj->nodeValue;
		}
		//echo 'StartDate</br>'; pr($startDate);
		
		//getting the End Date
		$endDateObj = $clinicalStudy->getElementsByTagName('completion_date')->item(0);
		if($endDateObj!=''){
			$endDate=$endDateObj->nodeValue;
		}
		//echo 'EndDate</br>';pr($endDate);
		
		$arrCollaborators		= '';
		//getting the gender
	/*	$collaboratorObj	= $clinicalStudy->getElementsByTagName('collaborator')->item(0);
		if($collaboratorObj!=''){
			$collaborator	= $collaboratorObj->getElementsByTagName('agency')->item(0)->nodeValue;
		}
	*/
		$sponsorsObj = $clinicalStudy->getElementsByTagName('sponsors')->item(0);
		$collaborators = $sponsorsObj->getElementsByTagName('collaborator');
		foreach($collaborators as $collaboratorObj){
			if($collaboratorObj!=null){
				$agencyObj = $collaboratorObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){							
					$arrCollaborators[]= $agencyObj->nodeValue;
				}
			}
		}
		
		//getting the gender
		$genderObj	= $clinicalStudy->getElementsByTagName('gender')->item(0);
		if($genderObj!=''){
			$gender	= $genderObj->nodeValue;
		}
		
		//getting the minimum_age
		$minimumAgeObj		= $clinicalStudy->getElementsByTagName('minimum_age')->item(0);
		if($minimumAgeObj!=''){
			$minimumAge		= $minimumAgeObj->nodeValue;
			if($minimumAge=="N/A"){
				$minimumAge	= '';
			}
		}
		
		//getting the minimum_age
		$maximumAgeObj		= $clinicalStudy->getElementsByTagName('maximum_age')->item(0);
		if($maximumAgeObj!=''){
			$maximumAge		= $maximumAgeObj->nodeValue;
			if($maximumAge=="N/A"){
				$maximumAge	= '';
			}
		}
		
		//getting the enrollment
		$enrollmentObj	= $clinicalStudy->getElementsByTagName('enrollment')->item(0);
		if($enrollmentObj!=''){
			$enrollment	= $enrollmentObj->nodeValue;
		}
		$no_of_trial_sites	= 0;
		$kolRole			= '';
		$overallOfficialObj	= $clinicalStudy->getElementsByTagName('overall_official');
		foreach($overallOfficialObj as $investigatorsObj){
			if(sizeof($arrKolNameCombination)>0){
				$last_nameObj	= $investigatorsObj->getElementsByTagName('last_name')->item(0);
				$lastname		= explode(',',$last_nameObj->nodeValue);
				if (in_array(str_replace('.','',$lastname[0]), str_replace('  ',' ',$arrKolNameCombination))){
					//getting the role
					$roleObj	= $investigatorsObj->getElementsByTagName('role')->item(0);
					if($roleObj!=''){
						$kolRole	= $roleObj->nodeValue;
					}
				}
			}
		}
		$locationsObj		= $clinicalStudy->getElementsByTagName('location');
		$no_of_trial_sites	= $locationsObj->length;
		//pr($locationsObj);
		//echo $locationsObj->length.'<br />'.sizeof($locationsObj);
		if(empty($kolRole)){
			foreach($locationsObj as $locationObj){
				//$no_of_trial_sites++;
				if(sizeof($arrKolNameCombination)>0){
				//	$last_nameObj	= $locationObj->getElementsByTagName('last_name')->item(0);
					foreach($locationObj->getElementsByTagName('last_name') as $last_nameObj){
						$lastname		= explode(',',$last_nameObj->nodeValue);
						if (in_array(str_replace('.','',$lastname[0]), str_replace('  ',' ',$arrKolNameCombination))){
							//getting the role
							$roleObj	= $locationObj->getElementsByTagName('role')->item(0);
							if($roleObj!=''){
								$kolRole	= $roleObj->nodeValue;
							}
						}
					}
				}
			}
		}
		//getting the Link
		$link="http://clinicaltrials.gov/ct2/show/$ctId";
		//echo 'Link</br>';pr($link);		
		
		//Prepare array represinting Clinical Trials details	
		$ctDetails['ct_id']				= $ctId;
		$ctDetails['trial_name']		= $trialName;
		$ctDetails['status_id']			= $statusId;
		$ctDetails['purpose']			= $purpose;
		$ctDetails['condition']			= implode(', ',$arrCondition);
		$ctDetails['phase']				= $phase;
		$ctDetails['official_title']	= $officialTitle;
		$ctDetails['study_type']		= $studyType;
		$ctDetails['start_date']		= $startDate;
		$ctDetails['end_date']			= $endDate;
		$ctDetails['collaborator']		= implode(', ',$arrCollaborators);
		$ctDetails['gender']			= $gender;
		$ctDetails['min_age']			= $minimumAge;
		$ctDetails['max_age']			= $maximumAge;
		$ctDetails['no_of_enrollees']	= $enrollment;
		$ctDetails['no_of_trial_sites']	= $no_of_trial_sites;
		$ctDetails['kol_role']			= $kolRole;
		$ctDetails['link']				= $link;
		//End of preparing array

		return $ctDetails;
	}

	/**
	 * Saves the Clinical Trials and returns the id of it
	 * @param Array $ctDetails
	 * @param Integer $kolId
	 * @return Integer $ctId
	 */
	function save_clinical_trials($ctDetails, $kolId, $isVerified = 0){					
		//save the Clinical Trials and get the Clinical Trials id
		$ctId=$this->clinical_trial->saveClinicalTrials($ctDetails);		
		//prepare the kol-to-Clinical Trials association object
		$kolClinicalTrials=array();
		$kolClinicalTrials['kol_id']=$kolId;
		$kolClinicalTrials['cts_id']=$ctId;
		$kolClinicalTrials['is_deleted']=0;	
		$kolClinicalTrials['is_verified']= $isVerified;
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$kolClinicalTrials['client_id'] = $this->session->userdata('client_id');
		$kolClinicalTrials['user_id']   = $this->session->userdata('user_id');
		//save the kol-to-Clinical Trials record
		$isSaved=$this->clinical_trial->saveKolClinicalTrials($kolClinicalTrials);
		$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctId, MODULE_KOL_TRIAL, $kolId);
		//return the Clinical Trials Id	
		return $ctId;
	}	
	
	
	/**
	 * parse the values for Sponsers
	 * 
	 * @param $clinicalStudy
	 * @return Array $arrSponsers
	 */
	function parse_clinicle_sponsers($clinicalStudy){
		//getting the Sponsers
		$arrSponsers=array();
		$sponsorsObj = $clinicalStudy->getElementsByTagName('sponsors')->item(0);
		$leadSponsers=$sponsorsObj->getElementsByTagName('lead_sponsor');
		foreach($leadSponsers as $leadSponserObj){
				if($leadSponserObj!=null){	
					$leadSponser=array();
					$type='lead sponsor';
					$agency='';
					$agencyClass='';																	
					$agencyObj = $leadSponserObj->getElementsByTagName('agency')->item(0);
					if($agencyObj!=null){							
						$agency= $agencyObj->nodeValue;
					}
					$agencyClassObj = $leadSponserObj->getElementsByTagName('agency_class')->item(0);
					if($agencyClassObj!=null){							
						$agencyClass= $agencyClassObj->nodeValue;
					}
					$leadSponser['type']=$type;
					$leadSponser['agency']=$agency;
					$leadSponser['agency_class']=$agencyClass;	
					$arrSponsers[]=$leadSponser;
				}
			}
		
		$collaborators = $sponsorsObj->getElementsByTagName('collaborator');
		foreach($collaborators as $collaboratorObj){
			if($collaboratorObj!=null){	
				$collaborator=array();
				$type='collaborator';
				$agency='';
				$agencyClass='';																	
				$agencyObj = $collaboratorObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){							
					$agency= $agencyObj->nodeValue;
				}
				$agencyClassObj = $collaboratorObj->getElementsByTagName('agency_class')->item(0);
				if($agencyClassObj!=null){							
					$agencyClass= $agencyClassObj->nodeValue;
				}
				$collaborator['type']=$type;
				$collaborator['agency']=$agency;
				$collaborator['agency_class']=$agencyClass;	
				$arrSponsers[]=$collaborator;
			}
		}
		return $arrSponsers;	
	}
	
	/**
	 * parse the values for Interventions
	 * 
	 * @param $clinicalStudy
	 * @return Array $arrIntervention
	 */
	function parse_clinicle_intervention($clinicalStudy){
		//getting the Interventions
		$arrIntervention=array();
		$interventions = $clinicalStudy->getElementsByTagName('intervention');
		
		foreach($interventions as $interventionObj){
				if($interventionObj!=null){	
					$intervention=array();
					$type='';
					$name='';
					$description = '';	
					$armGroupLabel='';	
					$othrName='';															
					$interventionTypeObj = $interventionObj->getElementsByTagName('intervention_type')->item(0);
					if($interventionTypeObj!=null){							
						$type= $interventionTypeObj->nodeValue;
					}
					
					$interventionNameObj = $interventionObj->getElementsByTagName('intervention_name')->item(0);
					if($interventionNameObj!=null){							
						$name= $interventionNameObj->nodeValue;
					}
					
					$descriptionObj = $interventionObj->getElementsByTagName('description')->item(0);
					if($descriptionObj!=null){							
						$description= $descriptionObj->nodeValue;
					}
					
					$armGroupLabels = $interventionObj->getElementsByTagName('arm_group_label');
					$armGroupLabelValue;
					foreach ($armGroupLabels as $armGroupLabelObj){
						if($armGroupLabelObj!=null){							
						 	$armGroupLabelValue= $armGroupLabelObj->nodeValue;
						}
						$armGroupLabel=$armGroupLabel+$armGroupLabelValue+",";
					}
//					//Right now saving all the Array of Arm groups as one String
//					foreach ($armGroupLabelArr as $armGroup){
//						$armGroupLabel=$armGroupLabel+$armGroup.",";
//					}
					
					$othrNameObj = $interventionObj->getElementsByTagName('other_name')->item(0);
					if($othrNameObj!=null){							
						$othrName= $othrNameObj->nodeValue;
					}

					$intervention['type']=$type;
					$intervention['name']=$name;
					$intervention['description']=$description;	
					$intervention['arm_group_label']=$armGroupLabel;	
					$intervention['other_name']=$othrName;
					$arrIntervention[]=$intervention;
				}
				
			}
		return  $arrIntervention;
	}	

	
	/**
	 * parse the values for keywords
	 * 
	 * @param $clinicalStudy
	 * @return Array $arrKeywords
	 */
	function parse_clinicle_keyword($clinicalStudy){
		//getting the Keywords
		$arrKeyword=array();
		$keywords = $clinicalStudy->getElementsByTagName('keyword');
		foreach ($keywords as $keywordObj){
			$keywordName=array();
			if($keywordObj!=null){							
			 	$keywordName['name']= $keywordObj->nodeValue;
			}
			$arrKeyword[]=$keywordName;
		}
		return  $arrKeyword;
	}
	
	/**
	 * Saves the array of Keyword one by one
	 * 
	 * @param Array $arrKeyword
	 * @param Integer $ctId
	 * @return boolean
	 */
	function save_keyword($arrKeyword, $ctId){
		$isSaved=false;	
		foreach($arrKeyword as $keyword){			
			$keywordId=$this->clinical_trial->saveKeyword($keyword);
			
			$ctKeyword=array();
			$ctKeyword['cts_id']=$ctId;
			$ctKeyword['keyword_id']=$keywordId;
			
			$isSaved=$this->clinical_trial->saveCtKeyword($ctKeyword);
		}
		return $isSaved;
	}	
	/**
	 * parse the values for Meshterms
	 * 
	 * @param $clinicalStudy
	 * @return Array $arrMeshterms
	 */
	function parse_clinicle_meshterms($clinicalStudy){
		//getting the Meshterms
		$arrMeshterms=array();
		//For Condition Browse
		$conditionBrowseObj = $clinicalStudy->getElementsByTagName('condition_browse')->item(0);
		if($conditionBrowseObj!=null){
			$conditionBrowse=array();
			$type='condition_browse';
			$name='';	
			$meshterms = $conditionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){							
					$name= $meshtermsObj->nodeValue;
				}	
				$conditionBrowse['term_name']=$name;
				$conditionBrowse['type']=$type;	
				$arrMeshterms[]=$conditionBrowse;					
			}			
		}
	
		//For Intervention Browse
		$interventionBrowseObj = $clinicalStudy->getElementsByTagName('intervention_browse')->item(0);
		if($interventionBrowseObj!=null){
			$interventionBrowse=array();
			$type='intervention_browse';
			$name='';	
			$meshterms = $interventionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){							
					$name= $meshtermsObj->nodeValue;
				}
				$interventionBrowse['term_name']=$name;
				$interventionBrowse['type']= $type;
				$arrMeshterms[]=$interventionBrowse;
			}
		}
		return  $arrMeshterms;
	}
	
	function save_meshterms($arrMeshterms, $ctId){
		$isSaved=false;
		foreach($arrMeshterms as $meshterms){
			$meshtermId=$this->clinical_trial->saveMeshterms($meshterms);
			$ctMeshterms=array();
			$ctMeshterms['cts_id']=$ctId;
			$ctMeshterms['term_id']=$meshtermId;
			$isSaved=$this->clinical_trial->saveCtMeshterms($ctMeshterms);
		}
		return $isSaved;
	}
	
	function parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination=array()){
		//getting the Investigators(
		$arrInvestigators=array();
		
		$investigators = $clinicalStudy->getElementsByTagName('overall_official');
		if($investigators!=null){
			foreach($investigators as $investigatorObj){
				if($investigatorObj!=null){
					$investigator=array();					
					$lastName='NA';
					$role='Investigator';
					$affiliation='NA';
					$lastNameObj=$investigatorObj->getElementsByTagName('last_name')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$roleObj=$investigatorObj->getElementsByTagName('role')->item(0);
					if($roleObj!=null)
						$role=$roleObj->nodeValue;
					$affiliationObj=$investigatorObj->getElementsByTagName('affiliation')->item(0);
					if($affiliationObj!=null)
						$affiliation=$affiliationObj->nodeValue;
					$investigator['last_name']=$lastName;
					$investigator['role']=$role;	
					$investigator['affiliation']=$affiliation;
					$arrInvestigators[$investigator['last_name']]=$investigator;
				}
			}
		}
		$overallInvestigatorObj	= $clinicalStudy->getElementsByTagName('investigator');
		foreach($overallInvestigatorObj as $investigatorsObj){
			$investigator	= array();	
			$last_nameObj	= $investigatorsObj->getElementsByTagName('last_name')->item(0);
			$roleObj		= $investigatorsObj->getElementsByTagName('role')->item(0);
			if($last_nameObj!=''){
				$investigator['last_name']	= $last_nameObj->nodeValue;
			}
			if($roleObj!=''){
				$investigator['role']		= $roleObj->nodeValue;
			}
			$arrInvestigators[$investigator['last_name']]=$investigator;
		}
		$kolnameExists	= false;
		if(sizeof($arrKolNameCombination)>0){
			foreach($arrInvestigators as $investigators){
				if (in_array(str_replace('.','',$investigator['last_name']), str_replace('  ',' ',$arrKolNameCombination))){
					$kolnameExists	= true;
				}
			}
		}
		if(!$kolnameExists){
			$investigator	= array();
			$investigator['last_name']	= $arrKolNameCombination[sizeof($arrKolNameCombination)-1];
			$investigator['role']		= 'Principal Investigator';	
			$investigator['affiliation']= '';
			$arrInvestigators[]			= $investigator;
		}
		return  $arrInvestigators;
	}
	
		
	/**
	 * returns different combinations on names 
	 * @param $firsName
	 * @param $midleName
	 * @param $lastName
	 * @return Array,   Example Array('0'=>'JV  Heymach','1'=>'Heymach  J');
	 */
	function generate_name_combinations($firsName, $midleName, $lastName){
	
		$firstName = $firsName;
		$middleName = $midleName;
		$lastName = $lastName;
		
		$firstNameInitial = substr($firstName, 0, 1);		
		$middleNameInitial = substr($middleName, 0, 1);
		$middleNameLength = strlen($middleName);		
		
		$lastNameInitial = substr($lastName, 0, 1);
		
		$arrName= array();
			
			if($firstName!="" && $middleName=="" && $lastName!=""){
				//echo "<h3>Case : 1 </h3>";
				 $arrName[] = $firstName." ".$lastName;
				 $arrName[] = $lastName." ".$firstName;
			}
			if($firstName!="" && $middleNameLength==1 && $lastName!=""){
				//echo "<h3>Case : 2 </h3>";
				 $arrName[] = $lastName." ".$firstName;
				 $arrName[] = $firstName." ".$lastName;
				 $arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			}
			
			if($firstName!="" && $middleNameLength!=1 &&$middleName!="" && $lastName!=""){
				//echo "<h3>Case : 3 </h3>";
				$arrName[] = $lastName." ".$firstName;
				$arrName[] = $firstName." ".$middleName." ".$lastName;
				$arrName[] = $firstName." ".$lastName;
				$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
			}
			
		return $arrName;	
	}

	/**
	 * Prepares the data required to display the Clinical Trials page and redirects to 'view_clinical_trials'
	 * @return unknown_type
	 */
	function view_clinical_trials($kolId){
		$data['isClientView']	= false;
		$clientId				= $this->session->userdata('client_id');
		if($clientId==INTERNAL_CLIENT_ID){
			$data['enableEdit']	= true;
		}
		// Get the KOL details
      	$arrKolDetail 			= $this->kol->editKol($kolId);
    	$data['arrKol']			= $arrKolDetail;
		
    	//$arrSalutations		= array(1 => 'Mr.', 'Mrs.', 'Miss.', 'Ms.', 'Dr.', 'Prof.');
		$arrSalutations			= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
    	$data['arrSalutations']	= $arrSalutations;
	
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$data['contentPage']	= 'clinicals/list_clinical_trials';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List Clinical Trails Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View Clinical Trails"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view', $data);
		//$this->load->view('clinicals/list_clinical_trials', $data);
	
	}
	
	/**
	 * returns the list of Clinical Trials belongs to perticular kolId
	 * @return unknown_type
	 */
	function list_clinical_trials_details($kolId,$type = 'verified'){
		
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrClinicalTrials	= array();
		$data				= array();
		
		if($arrClinicalTrialsResults=$this->clinical_trial->listClinicalTrialsDetailsByType($kolId,$type)){
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['asoc_id'];
				$arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				$arrClinicalTrial['is_analyst']	= $arrClinicalTrialsResult['is_analyst'];
				$arrClinicalTrial['first_name']	= $arrClinicalTrialsResult['first_name'];
				$arrClinicalTrial['last_name']	= $arrClinicalTrialsResult['last_name'];
				//$arrClinicalTrial['ct_id']	= '<a href=\''. $arrClinicalTrialsResult['link'].'\' target="_new">'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['trial_id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
				
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
				$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
				$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
				$arrClinicalTrial['eAllowed']							= $this->common_helpers->isActionAllowed('kol_details','edit',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
//				$arrClinicalTrial['dAllowed']							= $this->common_helpers->isActionAllowed('trial','delete',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
				if($arrClinicalTrialsResult['is_industry_trial'] == 1){
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1' checked='checked'></input>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'></input>";
				}else if($arrClinicalTrialsResult['is_industry_trial'] == 2){
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'  checked='checked'></input>";
				}else{ 
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'></input>";
				}
				$arrClinicalTrial['data_type_indicator']	= $arrClinicalTrialsResult['data_type_indicator'];;
				$arrClinicalTrials[]			= $arrClinicalTrial;				
			}
			$count				= sizeof($arrClinicalTrials);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrClinicalTrials;  
		}
		echo json_encode($data);
	}
	
	/**
	 * Deletes the Clinical Trials, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 */
	function delete_clinical_trials(){
		$selectedRows = $_POST['slr'];
		$kolId=$this->session->userdata('kolId');
		foreach($selectedRows as $ctsId){
			$kolClinicalTrial=array();
			$kolClinicalTrial['kol_id']=$kolId;
			$kolClinicalTrial['cts_id']=$ctsId;
			$kolClinicalTrial['is_deleted']=1;
			//$isDeleted=$this->clinical_trial->updateClinicalTrialsAsDeleted($kolClinicalTrial);
			$isDeleted=$this->clinical_trial->deleteClinicalTrial($ctsId);
			//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_DELETE, $ctsId, MODULE_KOL_TRIAL, $kolId);
		}		
		return true;
	}
	
	/**
	 * Deletes the Clinical Trials, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 */
	function delete_clinical_trial($ctsId){		
		$kolId=$this->session->userdata('kolId');		
			$kolClinicalTrial=array();
			$kolClinicalTrial['kol_id']=$kolId;
			$kolClinicalTrial['cts_id']=$ctsId;
			//$kolClinicalTrial['is_deleted']=1;
			//$isDeleted=$this->clinical_trial->updateClinicalTrialsAsDeleted($kolClinicalTrial);
			$isDeleted=$this->clinical_trial->deleteClinicalTrial($ctsId);				
			//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_DELETE, $ctsId, MODULE_KOL_TRIAL, $kolId);
			$this->update->deleteUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctsId, MODULE_KOL_TRIAL);
			$this->update->deleteUpdateEntry(KOL_PROFILE_TRIAL_UPDATE, $ctsId, MODULE_KOL_TRIAL);
			return true;
	}
	
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.55'){
			$aContext = array(
			    'http' => array(
			        'proxy' => 'tcp://192.168.1.90:808',
			        'request_fulluri' => true,
			    ),
			);		
			$cxContext = stream_context_create($aContext);
			
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$res=null;
			if(!$res = file_get_contents($url)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}
	}
	
	function get_sponsers($ctId){		
		$sponsersNames='';
		$arrSponsers=$this->clinical_trial->listCTSponsors($ctId);
		foreach($arrSponsers as $sponser){
			$sponserName=$sponser['agency'];
			if($sponsersNames==''){
				$sponsersNames=$sponserName;
			}else{
				$sponsersNames=$sponsersNames.", ".$sponserName;
			}
		}			
		return $sponsersNames;		
	}
	
	function get_interventions($ctId){		
		$interventionsNames='';
		$arrInterventions=$this->clinical_trial->listCTInterventions($ctId);
		foreach($arrInterventions as $intervention){
			$interventionName=$intervention['name'];
			if($interventionsNames==''){
				$interventionsNames=$interventionName;
			}else{
				$interventionsNames=$interventionsNames.", ".$interventionName;
			}
		}			
		return $interventionsNames;		
	}
	
	function get_investigators($ctId){		
		$investigatorsNames = '';
		$arrInvestigators=$this->clinical_trial->listCTInvestigators($ctId);
		foreach($arrInvestigators as $investigator){
			$investigatorName=$investigator['last_name'];
			if($investigatorsNames == ''){
				$investigatorsNames=$investigatorName;
			}else{
				$investigatorsNames=$investigatorsNames.", ".$investigatorName;
			}
		}			
		return $investigatorsNames;		
	}
	
	function view_clinical_trial($ctId){
		$ctDetailsResult=$this->clinical_trial->getClinicalTrial($ctId);
		$ctDetailsResult['status']=$this->clinical_trial->getStatusNameById($ctDetailsResult['status_id']);
		$arrSponsors=$this->clinical_trial->listCTSponsors($ctId);
		$arrInterventions=$this->clinical_trial->listCTInterventions($ctId);
		$arrKeyWords=$this->clinical_trial->listCTIKeyWords($ctId);
		$arrMeshTerms=$this->clinical_trial->listCTMeshTerms($ctId);
		$arrInvestigators=$this->clinical_trial->listCTInvestigators($ctId);
		
		$data['ctDetailsResult']=$ctDetailsResult;
		$data['arrSponsors']=$arrSponsors;
		$data['arrInterventions']=$arrInterventions;
		$data['arrKeyWords']=$arrKeyWords;
		$data['arrMeshTerms']=$arrMeshTerms;
		$data['arrInvestigators']=$arrInvestigators;
	
		$data['contentPage'] 	=	'clinicals/view_clinical_trial';
		//$this->load->view('layouts/kol_profile',$data);
		$this->load->view('clinicals/view_clinical_trial',$data);
		
	}
	
  	/**
	 * Searches the intervention Names and returns interventions Names matched
	 * 
	 * @param String	$interventionName
	 * @return unknown_type
	 */
	function get_interventions_name($interventionName){
		
		$arrInterventionNames = $this->clinical_trial->getCTInterventionsName($interventionName);
		
		$arrReturnData['query'] = $interventionName;
		$arrReturnData['suggestions']	= $arrInterventionNames;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the condition Names and returns condition Names matched
	 * 
	 * @param String	$conditionName
	 * @return unknown_type
	 */
	function get_condition_name($conditionName){
		
		$arrCondition = $this->clinical_trial->getCTConditionName($conditionName);
		
		$arrReturnData['query'] = $conditionName;
		$arrReturnData['suggestions']	= $arrCondition;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the Investigators Names and returns Investigators Names matched
	 * 
	 * @param String	$investigatorName
	 * @return unknown_type
	 */
	function get_investigators_name($investigatorName){
		
		$arrInvestigators = $this->clinical_trial->getCTInvestigatorsName($investigatorName);
		
		$arrReturnData['query'] = $investigatorName;
		$arrReturnData['suggestions']	= $arrInvestigators;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the meshTerm Names and returns meshTerm Names matched
	 * 
	 * @param String	$meshTermName
	 * @return unknown_type
	 */
	function get_mesh_term_name($meshTermName){
		
		$arrMeshTerms = $this->clinical_trial->getCTMeshTermsName($meshTermName);
		
		$arrReturnData['query'] = $meshTermName;
		$arrReturnData['suggestions']	= $arrMeshTerms;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the Sponsors Names and returns Sponsors Names matched
	 * 
	 * @param String	$sponsorsName
	 * @return unknown_type
	 */
	function get_sponsors_name($sponsorsName){
		
		$arrSponsorsName = $this->clinical_trial->getCTSponsorsName($sponsorsName);
		
		$arrReturnData['query'] = $sponsorsName;
		$arrReturnData['suggestions']	= $arrSponsorsName;
		echo json_encode($arrReturnData);
	}
	
	//-----Start of search function for "Clinical Trails"
	/**
	 *  returns the simple search results for Clinical Trails, matching the keyword with Trail name
	 *  
	 * @return unknown_type
	 */
	function search_trials(){
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$category		=	$this->input->post('category');
		$keyword		=	trim($this->input->post('keyword'));
		$searchType		= 	'simple';
		$arrTrials		=	array();
	
		
		$arrTrialsResultSet	=$this->clinical_trial->getMatchingTrials($keyword,$limit,$startFrom,false);
		$count				=$this->clinical_trial->getMatchingTrials($keyword,$limit,$startFrom,true);
		foreach ($arrTrialsResultSet as $arrTrialsResult){
			$arrTrialsResult['sponsors'] 		=	$this->get_sponsers($arrTrialsResult['id']);
			$arrTrialsResult['interventions']	=	$this->get_interventions($arrTrialsResult['id']);
			$arrTrials[]						=	$arrTrialsResult;
		}
		
		$filterData['keyword']				=	$keyword;
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	"";
		$trialsResultsData['trialsCount']	=$count;
		$trialsResultsData['arrClinicalTrial']=$arrTrials;
		$trialsResultsData['searchType']="simple";
		$trialsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['trialsResultsPage']		=	'search/trials_search_results';
		$details['trialsResultsData']		=	$trialsResultsData;
		
		$details['arrClinicalTrial']		=	$arrTrials;
		$details['filterPage']				=	'search/trials_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/trials_results';
		$this->load->view('layouts/client_view',$data);
		
	}
	
	function view_trials_adv_search(){
		$data['contentPage'] 	=	'search/trials_adv_search';
		$this->load->view('layouts/client_view',$data);
	}
	/**
	 * returns the "advance"  search results for Clinical Trials
	 * @author 	Ambarish N
	 * @since	2.4
	 * @return 
	 * @created 07-06-2011
	 * @return unknown_type
	 */
	function adv_search_trials(){
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$arrFilterFields	=	array();
		$arrFilterFields['condition']='';
		$arrFilterFields['sponsor']='';
		$arrFilterFields['intervention']='';
		$arrFilterFields['meshterm']='';
		$arrFilterFields['investigator']='';
		$arrTrials	=	array();
		$searchType	=	$this->input->post('search_type');
		$this->session->unset_userdata('arrFilterFields');
		
		// Getting the POST details of Trials Advance search
		$arrAdvSearchFields = array('keyword'			=>	trim($this->input->post('keyword')),
									'interventions'     =>	trim($this->input->post('interventions')),
									'condition' 		=> 	trim($this->input->post('condition')),
									'investigators'		=>	trim($this->input->post('investigators')),
									'mesh_term' 		=> 	trim($this->input->post('mesh_term')),
									'sponsors'			=> 	trim($this->input->post('sponsors')));
		
		$arrTrialsResultSet	= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false);
		$count				= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,true);
		
		//Get count of Trials grouping by category(for each category)
		$arrTrialsByConditionCount		= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'condition');
		$arrTrialsBySponsorCount		= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'sponsor');
		$arrTrialsByInterventionCount	= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'intervention');
		$arrTrialsByMeshtermCount		= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'meshterm');
		$arrTrialsByInvestigatorCount	= $this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'investigator');
		
		//Preparing the Trials by category results as required by the filter page and aso getting the total count for category
		$allConditionCount=0;
		$assoArrTrialsByConditionCount=array();
		foreach($arrTrialsByConditionCount as $row){
			$assoArrTrialsByConditionCount[$row['condition']]=$row;
			$allConditionCount+=$row['count'];
		}
		
		$allSponsorCount=0;
		$assoArrTrialsBySponsorCount=array();
		foreach($arrTrialsBySponsorCount as $row){
			$row['sponsor'] = $row['sponsors'];
			$assoArrTrialsBySponsorCount[$row['sponsor']]=$row;
			$allSponsorCount+=$row['count'];
		}
		
		$allInterventionCount=0;
		$assoArrTrialsByInterventionCount=array();
		foreach($arrTrialsByInterventionCount as $row){
			$row['intervention'] = $row['interventions'];
			$assoArrTrialsByInterventionCount[$row['intervention']]=$row;
			$allInterventionCount+=$row['count'];
		}
		
		$allMeshtermCount=0;
		$assoArrTrialsByMeshtermCount=array();
		foreach($arrTrialsByMeshtermCount as $row){
			$assoArrTrialsByMeshtermCount[$row['meshterm']]=$row;
			$allMeshtermCount+=$row['count'];
		}
		
		$allInvestigatorCount=0;
		$assoArrTrialsByInvestigatorCount=array();
		foreach($arrTrialsByInvestigatorCount as $row){
			$assoArrTrialsByInvestigatorCount[$row['investigator']]=$row;
			$allInvestigatorCount+=$row['count'];
		}
		
		foreach ($arrTrialsResultSet as $arrTrialsResult){
			$arrTrialsResult['sponsors']		=	$this->get_sponsers($arrTrialsResult['id']);
			$arrTrialsResult['interventions']	=	$this->get_interventions($arrTrialsResult['id']);
			$arrTrials[]						=	$arrTrialsResult;
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allConditionCount']=$allConditionCount;
		$filterData['allSponsorCount']=$allSponsorCount;
		$filterData['allInterventionCount']=$allInterventionCount;
		$filterData['allMeshtermCount']=$allMeshtermCount;
		$filterData['allInvestigatorCount']=$allInvestigatorCount;
		
		$filterData['arrTrialsByConditionCount']=$assoArrTrialsByConditionCount;
		$filterData['arrTrialsBySponsorCount']=$assoArrTrialsBySponsorCount;
		$filterData['arrTrialsByInterventionCount']=$assoArrTrialsByInterventionCount;
		$filterData['arrTrialsByMeshtermCount']=$assoArrTrialsByMeshtermCount;
		$filterData['arrTrialsByInvestigatorCount']=$assoArrTrialsByInvestigatorCount;
			
		$filterData['keyword']				=	$arrAdvSearchFields['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	"";
		$trialsResultsData['trialsCount']	=$count;
		$trialsResultsData['arrClinicalTrial']=$arrTrials;
		$trialsResultsData['searchType']="simple";
		$trialsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrAdvSearchFields);
		$details['trialsResultsPage']		=	'search/trials_search_results';
		$details['trialsResultsData']		=	$trialsResultsData;
		
		$filterData['arrAdvSearchFields']	= 	$arrAdvSearchFields;
		$details['arrClinicalTrial']		=	$arrTrials;
		$details['filterPage']				=	'search/trials_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data ['contentPage'] 				=	'search/trials_results';
		$this->load->view('layouts/client_view',$data);
		
	}
	
	/**
	 * Retrives the data required for the kols checkbox's kind of filters
	 * @author 	Ambarish N
	 * @since	2.4
	 * @return 
	 * @created 07-06-2011
	 */
	function reload_trial_filters(){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count =0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		
		$arrConditions	=array();
		$arrSpecialties	=array();
			
		if((int)$page>-1){
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrFilterFields');	
		}
		else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			$sponsor		=	trim($this->input->post('sponsor'));		
			$condition		=	trim($this->input->post('condition'));
			$intervention	=	trim($this->input->post('intervention'));
			$meshterm		=	trim($this->input->post('meshterm'));
			$investigator	=	trim($this->input->post('investigator'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrConditions	=	$this->input->post('conditions');
			if($arrConditions!='')
				$arrConditions	=explode(",",$arrConditions);
			if($condition!='')
				$arrConditions[]	=	$condition;
			//echo $sponsor;
			$arrSponsors	=	$this->input->post('sponsors');
			if($arrSponsors!='')
				$arrSponsors	=explode(",",$arrSponsors);
			if($sponsor!=''){
				$arrSponsors[]	=	$sponsor;
			}
			$arrInterventions	=	$this->input->post('interventions');
			if($arrInterventions!='')
				$arrInterventions	=explode(",",$arrInterventions);
			if($intervention!=''){
				$arrInterventions[]	=	$intervention;
			}
			
			$arrMeshterms	=	$this->input->post('meshterms');
			if($arrMeshterms!='')
				$arrMeshterms	=explode(",",$arrMeshterms);
			if($meshterm!=''){
				$arrMeshterms[]	=	$meshterm;
			}
			
			$arrInvestigators	=	$this->input->post('investigators');
			if($arrInvestigators!='')
				$arrInvestigators	=explode(",",$arrInvestigators);
			if($investigator!=''){
				$arrInvestigators[]	=	$investigator;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['sponsor']=$arrSponsors;		
			$arrFilterFields['condition']=$arrConditions;
			$arrFilterFields['intervention']=$arrInterventions;
			$arrFilterFields['meshterm']=$arrMeshterms;
			$arrFilterFields['investigator']=$arrInvestigators;
		}
		
		//Split the keyword by 'comma' or '+' or 'space'	
		$arrKeywords=explode("+",$keyword);	
		
		// We can modify the below logic so as to use the single 'or' and 'and' methods by 
		//sending the array of keyword names and enbling the where condition based on the 
		//size of the array in those methods
		if(sizeof($arrKeywords)==1){
			$name=$keyword;
			
			// Getting the POST details of Trials Advance search
			$arrAdvSearchFields = array('keyword'			=>	trim($this->input->post('keyword')),
										'interventions'     =>	trim($this->input->post('trialInterventions')),
										'condition' 		=> 	trim($this->input->post('trialCondition')),
										'investigators'		=>	trim($this->input->post('trialInvestigators')),
										'mesh_term' 		=> 	trim($this->input->post('trialMesh_term')),
										'sponsors'			=> 	trim($this->input->post('trialSponsors')));
			
			//Get count of Trials grouping by category(for each category)
			$arrTrialsByConditionCount =$this->clinical_trial->getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'condition');
			$arrTrialsBySponsorCount =$this->clinical_trial->getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'sponsor');
			$arrTrialsByInterventionCount =$this->clinical_trial->getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'intervention');
			$arrTrialsByMeshtermCount =$this->clinical_trial->getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'meshterm');
			$arrTrialsByInvestigatorCount =$this->clinical_trial->getMatchingTrials($keyword,$arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'investigator');
		}
		
		//Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrFilterFields',$arrFilterFields);
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		//Preparing the Trials by category results as required by the filter page and aso getting the total count for category
		$allConditionCount=0;
		$assoArrTrialsByConditionCount=array();
		foreach($arrTrialsByConditionCount as $row){
			$assoArrTrialsByConditionCount[$row['condition']]=$row;
			$allConditionCount+=$row['count'];
		}
		
		//Preparing the Trials by category results as required by the filter page and aso getting the total count for category
		$allSponsorCount=0;
		$assoArrTrialsBySponsorCount=array();
		foreach($arrTrialsBySponsorCount as $row){
			$row['sponsor'] = $row['sponsors'];
			$assoArrTrialsBySponsorCount[$row['sponsor']]=$row;
			$allSponsorCount+=$row['count'];
		}
		
		$allInterventionCount=0;
		$assoArrTrialsByInterventionCount=array();
		foreach($arrTrialsByInterventionCount as $row){
			$row['intervention'] = $row['interventions'];
			$assoArrTrialsByInterventionCount[$row['intervention']]=$row;
			$allInterventionCount+=$row['count'];
		}
		
		$allMeshtermCount=0;
		$assoArrTrialsByMeshtermCount=array();
		foreach($arrTrialsByMeshtermCount as $row){
			$assoArrTrialsByMeshtermCount[$row['meshterm']]=$row;
			$allMeshtermCount+=$row['count'];
		}
		$allInvestigatorCount=0;
		$assoArrTrialsByInvestigatorCount=array();
		foreach($arrTrialsByInvestigatorCount as $row){
			$assoArrTrialsByInvestigatorCount[$row['investigator']]=$row;
			$allInvestigatorCount+=$row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allConditionCount']=$allConditionCount;
		$filterData['allSponsorCount']=$allSponsorCount;
		$filterData['allInterventionCount']=$allInterventionCount;
		$filterData['allMeshtermCount']=$allMeshtermCount;
		$filterData['allInvestigatorCount']=$allInvestigatorCount;
		
		$filterData['arrTrialsByConditionCount']=$assoArrTrialsByConditionCount;
		$filterData['arrTrialsBySponsorCount']=$assoArrTrialsBySponsorCount;
		$filterData['arrTrialsByInterventionCount']=$assoArrTrialsByInterventionCount;
		$filterData['arrTrialsByMeshtermCount']=$assoArrTrialsByMeshtermCount;
		$filterData['arrTrialsByInvestigatorCount']=$assoArrTrialsByInvestigatorCount;
		
		
		$filterData['selectedConditions']=$arrConditions;
		$filterData['selectedSponsors']=$arrSponsors;
		$filterData['selectedInterventions']=$arrInterventions;
		$filterData['selectedMeshterms']=$arrMeshterms;
		$filterData['selectedInvestigators']=$arrInvestigators;
		
		$filterData['keyword']=$keyword;
		$filterData['arrAdvSearchFields']=$arrAdvSearchFields;
		$filterData['arrFilterFields']=$arrFilterFields;
		$filterData['searchType']=$searchType;
		$kolResultsData['arrSalutations']=$arrSalutations;
		$kolResultsData['searchType']="simple";
		$kolResultsData['eventsCount']=$count;
		$kolResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['filterPage']	=	'search/trials_filters';
		$details['kolResultsPage']	=	'search/trials_search_results';
		$details['kolResultsData']	=	$kolResultsData;
		$details['filterData']	= $filterData;
		$data['data']=$details;
		$data['contentPage'] 	=	'search/trials_results';
		//echo json_encode($data);
		$this->load->view('search/trials_filters',$filterData);
	}
	
	/**
	 * returns the Filterd result for the Trials
	 * @author 	Ambarish N
	 * @since	2.4
	 * @return 
	 * @created 07-06-2011
	 * @return unknown_type
	 */
	function  filter_search_trials(){
		$page=$this->input->post('page');
		$count=0;
		$noOfRecordsPerPage	= $this->uri->segment(3);
		if(!empty($noOfRecordsPerPage)){
			$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		}
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
	
		$searchType	=	$this->input->post('search_type');
		$keyword	=	$this->input->post('keyword');	
			
		$arrTrials=array();
		$searchType = $this->input->post('search_type');
		if((int)$page>-1){
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrFilterFields');	
		}else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			$sponsor		=	trim($this->input->post('sponsor'));		
			$condition		=	trim($this->input->post('condition'));
			$intervention	=	trim($this->input->post('intervention'));
			$meshterm		=	trim($this->input->post('meshterm'));
			$investigator	=	trim($this->input->post('investigator'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrConditions	=	$this->input->post('conditions');
			if($arrConditions!='')
				$arrConditions	=explode(",",$arrConditions);
			if($condition!='')
				$arrConditions[]	=	$condition;
				
			$arrSponsors	=	$this->input->post('sponsors');
			if($arrSponsors!='')
				$arrSponsors	=explode(",",$arrSponsors);
			if($sponsor!=''){
				$arrSponsors[]	=	$sponsor;
			}	
			
			$arrInterventions	=	$this->input->post('interventions');
			if($arrInterventions!='')
				$arrInterventions	=explode(",",$arrInterventions);
			if($intervention!=''){
				$arrInterventions[]	=	$intervention;
			}
			
			$arrMeshterms	=	$this->input->post('meshterms');
			if($arrMeshterms!='')
				$arrMeshterms	=explode(",",$arrMeshterms);
			if($meshterm!=''){
				$arrMeshterms[]	=	$meshterm;
			}
			
			$arrInvestigators	=	$this->input->post('investigators');
			if($arrInvestigators!='')
				$arrInvestigators	=explode(",",$arrInvestigators);
			if($investigator!=''){
				$arrInvestigators[]	=	$investigator;
			}
				
			$arrFilterFields['condition']=$arrConditions;
			$arrFilterFields['sponsor']=$arrSponsors;
			$arrFilterFields['intervention']=$arrInterventions;
			$arrFilterFields['meshterm']=$arrMeshterms;
			$arrFilterFields['investigator']=$arrInvestigators;
		}
		// Getting the POST details of Trials Advance search
		$arrAdvSearchFields = array('keyword'			=>	trim($this->input->post('keyword')),
									'interventions'     =>	trim($this->input->post('trialInterventions')),
									'condition' 		=> 	trim($this->input->post('trialCondition')),
									'investigators'		=>	trim($this->input->post('trialInvestigators')),
									'mesh_term' 		=> 	trim($this->input->post('trialMesh_term')),
									'sponsors'			=> 	trim($this->input->post('trialSponsors')));
		
		
		$arrTrialsResultSet =$this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false);
		$count				=$this->clinical_trial->getAdvSearchMatchingTrials($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,true);
		foreach ($arrTrialsResultSet as $arrTrialsResult){
			$arrTrialsResult['sponsors']=$this->get_sponsers($arrTrialsResult['id']);
			$arrTrialsResult['interventions']=$this->get_interventions($arrTrialsResult['id']);
			$arrTrials[]=$arrTrialsResult;
		}
		
		
		$filterData['keyword']				= $keyword;
		$filterData['searchType']			= $searchType;
		$filterData['arrFilterFields']		= $arrFilterFields;
		$filterData['arrAdvSearchFields']	= $arrAdvSearchFields;
		$trialsResultsData['trialsCount']	= $count;
		$trialsResultsData['arrClinicalTrial']=$arrTrials;
		$trialsResultsData['searchType']	= "simple";
		$trialsResultsData['msg']			= $this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrAdvSearchFields);
		$details['trialsResultsPage']		= 'search/trials_search_results';
		$details['trialsResultsData']		= $trialsResultsData;
		
		$details['arrClinicalTrial']		= $arrTrials;
		$details['filterPage']				= 'search/trials_filters';
		$details['filterData']				= $filterData;
		$data['data']						= $details;
		$data['contentPage'] 				= 'search/trials_results';
		$this->load->view('search/trials_search_results',$trialsResultsData);
	}
	
	//-----------End of search function for "Clinical Trails"-----------
	
	function view_micro_trial($ctId){
		$arrKeyWords				= '';
		$ctDetailsResult			= $this->clinical_trial->getClinicalTrial($ctId);
		$ctDetailsResult['status']	= $this->clinical_trial->getStatusNameById($ctDetailsResult['status_id']);
		//$arrSponsors=$this->clinical_trial->listCTSponsors($ctId);
		$arrSponsors				= $this->get_sponsers($ctId);
		$arrInterventions			= $this->clinical_trial->listCTInterventions($ctId);
//		$arrKeyWords				= $this->clinical_trial->listCTIKeyWords($ctId);
		$arrMeshTerms				= $this->clinical_trial->listCTMeshTerms($ctId);
		$arrInvestigators			= $this->clinical_trial->listCTInvestigators($ctId);
		
		$data['ctDetailsResult']	= $ctDetailsResult;
		//$data['arrSponsors']		= $arrSponsors;
		$data['sponsors']			= $arrSponsors;
		$data['arrInterventions']	= $arrInterventions;
		$data['arrKeyWords']		= $arrKeyWords;
		$data['arrMeshTerms']		= $arrMeshTerms;
		$data['arrInvestigators']	= $arrInvestigators;
		
		$this->load->view('clinicals/view_trial_micro_profile',$data);
	}
	
	/**
	 * Display the page to Add Clinical Trial manually
	 * 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function add_clinical_trial($kolId){
		$this->add_client_clinical_trial($kolId);
		/*
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		
		$arrClinicalTrialDetails = array(	'id'                =>	'',
											'trial_name'		=>	'',
											'status_id'			=>	'',
											'sponsor'	 		=> 	'',
											'condition'			=> 	'',
											'intervention'	 	=> 	'',
											'phase'	 			=> 	'',
											'investigators'	 	=> 	'',
											'keyword'			=>	'',
											'meshterm'			=>	'',
											'official_title'	=>	'',
											'link'				=>	'',
											'study_type'		=>	'',
											'collaborator'		=>	'',
											'start_date'		=>	'',
											'end_date'			=>	'',
											'no_of_enrollees'	=>	'',
											'no_of_trial_sites'	=>	'',
											'min_age'			=>	'',
											'max_age'			=>	'',
											'purpose'			=>	'',
											'kol_role'			=>	'',
											'gender'			=>	'');
		
		$arrClinicalTrialDetails['no_of_sponsors']=1;
		$manualSponsor['id'] = '';
		$manualSponsor['sponsor'] = $arrClinicalTrialDetails['sponsor'];
		
		$arrClinicalTrialDetails['no_of_intervention']=1;
		$manualIntervention['id'] = '';
		$manualIntervention['intervention'] = $arrClinicalTrialDetails['intervention'];
		
		$arrClinicalTrialDetails['no_of_investigators']=1;
		$manualInvestigator['id'] = '';
		$manualInvestigator['investigators'] = $arrClinicalTrialDetails['investigators'];
		
		$data['arrSponsor'] = $manualSponsor;
		$data['arrIntervention'] = $manualIntervention;
		$data['arrInvestigator'] = $manualInvestigator;
		$data['kolId'] = $kolId;
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$this->load->view('clinicals/add_clinical_trials',$data);
		*/
	}
	
	/**
	 * Display the page to Add Clinical Trial manually
	 * 
	 * @author Ambarish
	 * @since 2.2
	 * @Created-on 05-May-11
	 * 
	 * @return unknown_type
	 */
	function add_client_clinical_trial($kolId){
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		$arrClinicalTrialDetails	= array('id'                =>	'',
											'trial_name'		=>	'',
											'status_id'			=>	'',
											'sponsor'	 		=> 	'',
											'condition'			=> 	'',
											'intervention'	 	=> 	'',
											'phase'	 			=> 	'',
											'investigators'	 	=> 	'',
											'keyword'			=>	'',
											'meshterm'			=>	'',
											'official_title'	=>	'',
											'link'				=>	'',
											'study_type'		=>	'',
											'collaborator'		=>	'',
											'start_date'		=>	'',
											'end_date'			=>	'',
											'no_of_enrollees'	=>	'',
											'no_of_trial_sites'	=>	'',
											'min_age'			=>	'',
											'max_age'			=>	'',
											'purpose'			=>	'',
											'kol_role'			=>	'',
											'gender'			=>	''
										);
		
		$arrClinicalTrialDetails['no_of_sponsors']=1;
		$manualSponsor['id'] = '';
		$manualSponsor['sponsor'] = $arrClinicalTrialDetails['sponsor'];
		
		$arrClinicalTrialDetails['no_of_intervention']=1;
		$manualIntervention['id'] = '';
		$manualIntervention['intervention'] = $arrClinicalTrialDetails['intervention'];
		
		$arrClinicalTrialDetails['no_of_investigators']=1;
		$manualInvestigator['id'] = '';
		$manualInvestigator['investigators'] = $arrClinicalTrialDetails['investigators'];
		
		$arrClinicalTrialDetails['no_of_meshterms']=1;
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = $arrClinicalTrialDetails['meshterm'];
		
		$arrClinicalTrialDetails['no_of_keywords']=1;
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = $arrClinicalTrialDetails['keyword'];
		
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
		
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['kolId'] = $kolId;
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited ".lang('HCP')."Add Clinical Trials Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View ".lang('HCP')."Add Clinical Trials Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		$this->load->view('clinicals/add_clinical_trials',$data);
	}
	
	/**
	 * Saves the Manual Clinical Trial Detail to DB 
	 * 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * @return unknown_type
	 */
	function save_clinical_trial_manual(){
		// Getting the POST details of Clinical Trial
		$arrClinicalTrial  = array(	
									'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
									'status_id' 		=> 	$this->input->post('status_id'),
									'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
									'phase'	 			=> 	$this->input->post('phase'),
									'study_type'	 	=> 	$this->input->post('study_type'),
									'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
									'link'	 			=> 	$this->input->post('trial_link'),
									'kol_role'	 		=> 	$this->input->post('kol_role'),
									'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
									'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
									'start_date'	 	=> 	$this->input->post('start_date'),
									'end_date'	 		=> 	$this->input->post('end_date'),
									'min_age'	 		=> 	$this->input->post('min_age'),
									'max_age'	 		=> 	$this->input->post('max_age'),
									'gender'	 		=> 	$this->input->post('gender'),
									'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
									'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites'),
									'is_industry_trial'	=> 	$this->input->post('is_industry_trial')
								);
			
		$arrSponsers = array();
		if(empty($arrClinicalTrial['no_of_enrollees'])){
		    $arrClinicalTrial['no_of_enrollees']=NULL;
		}
		if(empty($arrClinicalTrial['no_of_trial_sites'])){
		    $arrClinicalTrial['no_of_trial_sites']=NULL;
		}
		$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'));
		if($arrSponser['agency'] != ''){
			$arrSponsers[] = $arrSponser;
		}
		
		$arrInterventions =array();
		$arrIntervention['name']			= 	trim($this->input->post('intervention'));
		if($arrIntervention['name'] !=''){
			$arrInterventions[] = $arrIntervention;
		}
		
		$arrInvestigators = array();
		$arrInvestigator['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		if($arrInvestigator['last_name'] !=''){
			$arrInvestigators[]  = $arrInvestigator;
		}
		
		$kolId			=	$this->input->post('kol_id');
		
		$arrClinicalTrial['is_manual']= 1;
		$arrClinicalTrial['ct_id'] = $this->clinical_trial->getManualCtid();
		$ctId	= $this->clinical_trial->saveClinicalTrialsManualAndFlags($arrClinicalTrial,$kolId);
		//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctId, MODULE_KOL_TRIAL, $kolId);
		$isSaved = false;
		if($ctId){
			$isSaved = true;
		}
		
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			$value = trim($this->input->post('sponsor'.$i));
			if($value !=''){
				$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
				$arrSponsers[] = $arrSponser;
			}else
				continue;
		}		
		//saves sponsers details and returns bollean value
		if(sizeof($arrSponsers) >=1){
			$isSaved =$this->clinical_trial->saveSponsers( $arrSponsers, $ctId);
		}
		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			$value = trim($this->input->post('intervention'.$i));
			if($value !=''){
				$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
				$arrInterventions[] = 	$arrIntervention;
			}else
				continue;
		}
		//saves Interventions details and returns bollean value
		if(sizeof($arrInterventions) >=1){
			$isSaved=$this->clinical_trial->saveInterventions($arrInterventions, $ctId);
		}
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
			$value = trim($this->input->post('investigators'.$i));
			if($value !=''){
				$arrInvestigator['last_name']	 			= 	trim($this->input->post('investigators'.$i));
				$arrInvestigators[] = 	$arrInvestigator;
			}else
				continue;
		}
		//saves Investigators details and returns bollean value
		if(sizeof($arrInvestigators) >=1){
			$isSaved=$this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);
		}
		$i=2;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=2;$i<=$noOfKeywords;$i++){
			$value = trim($this->input->post('keywords'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $ctId;
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}else
				continue;
		}
		
		$i=2;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=2;$i<=$noOfMeshterms;$i++){
			$value = trim($this->input->post('meshterms'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value;
				}
				if(!empty($meshTermId)){
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $ctId;
					$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
				}
			}else
				continue;
		}
		
		// Create an array to return the result
		$arrResult = array();
	
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $ctId;
			if($arrClinicalTrial['is_industry_trial'] == 1){
				$arrCtData = array();
				$arrCtData[]['id'] = $ctId;
				$this->add_ct_to_affiliations($kolId,$arrCtData);		
			}
//			$arrResult['msg']			= "Successfully saved the Clinical Trial details";
			
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		
		$currentMethod	= $this->input->post('methodName');
		$kolId = $this->kol->getUniqueIdByKolId($kolId);
		if($currentMethod == 'add_client_clinical_trial'){
			//For client appplication
			redirect('kols/view_clinical_trials/'.$kolId);
		}else{
			//For analyst appplication
			//	echo json_encode($arrResult);
			redirect('clinical_trials/view_clinical_trials/'.$kolId);
		}
	}
	
	/**
	 * Updates the Manual Clinical Trial Detail to DB 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function update_clinical_trial_manual(){
		$kolId	=	$this->input->post('kol_id');
		// Getting the POST details of Clinical Trial
		$arrClinicalTrial  = array(	'id'                =>	$this->input->post('id'),
									'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
									'status_id' 		=> 	$this->input->post('status_id'),
									'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
									'phase'	 			=> 	$this->input->post('phase'),
									'study_type'	 	=> 	$this->input->post('study_type'),
									'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
									'link'	 			=> 	$this->input->post('trial_link'),
									'kol_role'	 		=> 	$this->input->post('kol_role'),
									'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
									'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
									'start_date'	 	=> 	$this->input->post('start_date'),
									'end_date'	 		=> 	$this->input->post('end_date'),
									'min_age'	 		=> 	$this->input->post('min_age'),
									'max_age'	 		=> 	$this->input->post('max_age'),
									'gender'	 		=> 	$this->input->post('gender'),
									'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
									'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites'));
			
		$isSaved=$this->clinical_trial->updateClinicalTrialManual($arrClinicalTrial);
		//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_UPDATE, $arrClinicalTrial['id'], MODULE_KOL_TRIAL, $kolId);
		$arrLogDetails = array(
		        'controller' => 'kols',
				'type' => EDIT_RECORD,
				'description' => 'Update Clinical Trails',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_id' => $arrClinicalTrial['id'],
				'transaction_table_id' => KOL_CLINICAL_TRIALS,
				'transaction_name' => 'Update Clinical Trails',
				'form_data' => json_encode($arrClinicalTrial),
				'parent_object_id' => $kolId,
		);
		
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		
		
		/*Sponsor*/
		$arrClinicalTrial['agency']	 		= 	trim($this->input->post('sponsor'));
		$arrClinicalTrial['sponsorId']	 	= 	trim($this->input->post('sponsorId'));
		if($arrClinicalTrial['sponsorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtSponcers($arrClinicalTrial);
			$arrSponsorToExclude[]	= $arrClinicalTrial['sponsorId'];
		}else{
		    $newArrSponsor['agency']			= $arrClinicalTrial['agency'];
			$newArrCtSponsor['sponser_id']	= $this->clinical_trial->saveSponser($newArrSponsor);
			$arrSponsorToExclude[]				= $newArrCtSponsor['sponser_id'];
			$newArrCtSponsor['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtSponser($newArrCtSponsor);			
		}		
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
		    if($this->input->post('sponsor'.$i)){
    			$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
    			$arrSponser['sponsorId']			= 	trim($this->input->post('sponsorId'.$i));
    			$arrSponser['id'] 					= 	$arrClinicalTrial['id'];
    			if($arrSponser['sponsorId'] !=''){
    				//Updates sponser details and returns bollean value
    				$isSaved=$this->clinical_trial->updateCtSponcers($arrSponser);
    				$arrSponsorToExclude[]				= $arrSponser['sponsorId'];
    			}else{
    			    $newArrSponsor['agency']			= $arrSponser['agency'];
    			    $newArrCtSponsor['sponser_id']	= $this->clinical_trial->saveSponser($newArrSponsor);
    			    $arrSponsorToExclude[]				= $newArrCtSponsor['sponser_id'];
    			    $newArrCtSponsor['cts_id']				= $arrClinicalTrial['id'];
    			    $this->clinical_trial->saveCtSponser($newArrCtSponsor);
    			}
		    }
		}
		$this->clinical_trial->deleteSponsersAssoc($arrClinicalTrial['id'],$arrSponsorToExclude);
		/*Sponsor End*/
		/* Interventions */
	    $arrClinicalTrial['name']			= 	trim($this->input->post('intervention'));
		$arrClinicalTrial['interventionId'] = 	trim($this->input->post('interventionId'));
		if($arrClinicalTrial['interventionId'] != ''){
			$isSaved=$this->clinical_trial->updateCtIntervention($arrClinicalTrial);
			$arrInterventionToExclude[]	= $arrClinicalTrial['interventionId'];
		}else{
		    $newArrIntervention['name']			= $arrClinicalTrial['name'];
			$newArrCtIntervention['intervention_id']	= $this->clinical_trial->saveIntervention($newArrIntervention);
			$arrInterventionToExclude[]				= $newArrCtIntervention['intervention_id'];
			$newArrCtIntervention['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtIntervention($newArrCtIntervention);
		}		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
		    if($this->input->post('intervention'.$i)){
    			$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
    			$arrIntervention['interventionId']		= 	trim($this->input->post('interventionId'.$i));
    			$arrIntervention['id'] 					= 	$arrClinicalTrial['id'];
    			if($arrIntervention['interventionId'] != ''){
    				//Updates Intervention details and returns bollean value
    				$isSaved=$this->clinical_trial->updateCtIntervention($arrIntervention);
    				$arrInterventionToExclude[]	= $arrIntervention['interventionId'];
    			}else{
    			    $newArrIntervention['name']			= $arrIntervention['name'];
    			    $newArrCtIntervention['intervention_id']	= $this->clinical_trial->saveIntervention($newArrIntervention);
    			    $arrInterventionToExclude[]				= $newArrCtIntervention['intervention_id'];
    			    $newArrCtIntervention['cts_id']				= $arrClinicalTrial['id'];
    			    $this->clinical_trial->saveCtIntervention($newArrCtIntervention);    			    
    			}
		    }
		}
		$this->clinical_trial->deleteInterventionsAssoc($arrClinicalTrial['id'],$arrInterventionToExclude);
		/* End of Interventions */
		$arrClinicalTrial['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		$arrClinicalTrial['investigatorId'] = 	trim($this->input->post('investigatorId'));
		if($arrClinicalTrial['investigatorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtInvestigator($arrClinicalTrial);
			$arrInvestigatorsToExclude[]	= $arrClinicalTrial['investigatorId'];
		}else{
			$newArrInvestigator['last_name']			= $arrClinicalTrial['last_name'];
			$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
			$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
			$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
			//echo $this->db->last_query();
			//exit();
		}
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
		    if($this->input->post('investigators'.$i)){
    			$arrInvestigator['last_name']	 		= 	trim($this->input->post('investigators'.$i));
    			$arrInvestigator['investigatorId']		= 	trim($this->input->post('investigatorId'.$i));
    			$arrInvestigator['id'] 					= 	$arrClinicalTrial['id'];
    			if($arrInvestigator['investigatorId'] != ''){
    				$arrInvestigatorsToExclude[]	= $arrInvestigator['investigatorId'];
    				//Updates Investigator details and returns bollean value
    				$isSaved=$this->clinical_trial->updateCtInvestigator($arrInvestigator);
    			}else{
    				$newArrInvestigator['last_name']			= $arrInvestigator['last_name'];
    				$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
    				$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
    			//	echo $this->db->last_query();
    				$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
    				$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
    			//	echo $this->db->last_query();
    			//	exit();
    			}
		    }
		}
		$this->clinical_trial->deleteInvestigatorsAssoc($arrClinicalTrial['id'],$arrInvestigatorsToExclude);
		$i=1;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=1;$i<=$noOfKeywords;$i++){
			if($i==1){
				$value 				= trim($this->input->post('keywords'));
				$existingKeywordId	= trim($this->input->post('keywordId'));
			}else{
				$value 				= trim($this->input->post('keywords'.$i));
				$existingKeywordId	= trim($this->input->post('keywordId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}				
				if(!empty($keywordId) && ($keywordId!=$existingKeywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $arrClinicalTrial['id'];
					$update = $this->clinical_trial->updateCtKeyword($existingKeywordId,$arrAssociateKeyword);					
					if(!$update){
					    $this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
					    $arrKeywordsToExclude[] = $keywordId;
					}					
				}
				$arrKeywordsToExclude[]	= $existingKeywordId;
			}else
				continue;
		}	
		//pr($arrKeywordsToExclude);exit;
		$this->clinical_trial->deleteKeywordsAssoc($arrClinicalTrial['id'],$arrKeywordsToExclude);
		$i=1;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=1;$i<=$noOfMeshterms;$i++){
			if($i==1){
				$value 			= trim($this->input->post('meshterms'));
				$existingTermId	= trim($this->input->post('meshtermsId'));
			}else{
				$value 			= trim($this->input->post('meshterms'.$i));
				$existingTermId	= trim($this->input->post('meshtermId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value.'-'.$meshTermId;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value.'-'.$meshTermId;
				}
				if(!empty($meshTermId) && ($meshTermId!=$existingTermId)){
				//	echo $value.'-'.$existingTermId.'-'.$meshTermId;
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $arrClinicalTrial['id'];
					$update = $this->clinical_trial->UpdateCtMeshterms($existingTermId,$arrAssociateMeshTerm);
				//	echo $this->db->last_query();
					if(!$update){
					    $this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
					    $arrTermsToExclude[] = $meshTermId;
					}
				}
				$arrTermsToExclude[]	= $existingTermId;
			}else
				continue;
		}
		$this->clinical_trial->deleteTermsAssoc($arrClinicalTrial['id'],$arrTermsToExclude);
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			=  true;
			$arrResult['lastInsertId']	=  $arrClinicalTrial['id'];
			$arrResult['msg']			=  "Successfully Updated the Clinical Trial details";
		}else{
			$arrResult['saved']			=  false;
			$arrResult['msg']			=  "Sorry! Error in Updating";
		}
		
		//$kolId = $this->input->post('kol_id');
		$kolId = $this->kol->getUniqueIdByKolId($kolId);
		//	echo json_encode($arrResult);
		//redirect('kols/edit_kol/'.$this->session->userdata('kolId').'#ui-tabs-6');
		redirect('kols/view_clinical_trials/'.$kolId);
		//redirect('clinical_trials/view_clinical_trials/'.$kolId);
	}
	
	/**
	 * Populates the $ctId Data to the Manual form
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @param unknown_type $ctId
	 * @return unknown_type
	 */
	function edit_clinical_trial_manual($ctId,$kolId){
		$ctDetailsResult	= $this->clinical_trial->getClinicalTrial($ctId);
		$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
		$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
		$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
		$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
		$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';		
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
		
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
		
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
		
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
		
		$i=0;
		foreach ($arrMeshterms as $meshterms){
			$i++;
			if($i == 2)
				break;
			$manualMeshterms['meshterms']	= $meshterms['term_name'];
			$manualMeshterms['id'] 			= $meshterms['id'];
		}
		$i=0;
		foreach ($arrKeywords as $keywords){
			$i++;
			if($i == 2)
				break;
			$manualKeywords['keywords']  = $keywords['name'];
			$manualKeywords['id']		 = $keywords['id'];
		}
		$i=0;
		foreach ($arrSponsors as $sponsors){
			$i++;
			if($i == 2)
				break;
			$manualSponsors['sponsor']  = $sponsors['agency'];
			$manualSponsors['id'] = $sponsors['id'];
		}
		$i=0;
		foreach ($arrInterventions as $interventions){
			$i++;
			if($i == 2)
				break;
			$manualInterventions['intervention'] = $interventions['name'];
			$manualInterventions['id'] = $interventions['id'];
		}
		$i=0;
		foreach ($arrInvestigators as $investigators){
			$i++;
			if($i == 2)
				break;
			$manualInvestigators['investigators'] = $investigators['last_name'];
			$manualInvestigators['id'] = $investigators['id'];
		}
		
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$ctDetailsResult['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
		
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$ctDetailsResult['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
		
		
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$ctDetailsResult['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
		
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$ctDetailsResult['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
		
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$ctDetailsResult['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;
		
		$data['arrClinicalTrial'] = $ctDetailsResult;
		
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		
		$data['kolId'] = $kolId;
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited ".lang('HCP')."Add Clinical Trials Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View ".lang('HCP')."Add Clinical Trials Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		$this->load->view('clinicals/add_clinical_trials',$data);
		
	}
	
	/**
	 * Prepares the DropDoen Values for clinical trial manual Page
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function clinical_trial_manual_dropdowns(){
		$arrStatusIds = array(	4		 => COMPLETED,
								1		 => 'Recruiting',
								3 	 	 => 'Terminated',
								12		 => 'Ongoing',
								13 		 => 'Others');
		
		$arrPhaseIds = array(	'I'	 	=> 'I',
								'II'	=> 'II',
								'III' 	=> 'III',
								'IV'	=> 'IV');
		
		$arrGenders = array(	'male'	=> 'Male',
								'female'=> 'Female',
								'both' 	=> 'Both');
		
		$arrKOLRoles = array(	'Co-investigator'		=> 'Co-investigator',
								'Principal Investigator'=> 'Principal Investigator',
								'Study Director' 		=> 'Study Director',
								'Sub-investigator' 		=> 'Sub-investigator');
		
		$data['arrStatusIds']	= $arrStatusIds;
		$data['arrPhaseIds']	= $arrPhaseIds;
		$data['arrKOLRoles']	= $arrKOLRoles;
		$data['arrGenders']		= $arrGenders;
		return $data;
	}
	
	function processCTIDs($kolId=''){
		$ctIds		= trim($this->input->post('ctids'));
		$arrCtIds	= array();
		$arrData	= array();
		if(!empty($kolId) && !empty($ctIds)){
			
			//Analyst App to be accessed by only Aissel users. 
			$this->common_helpers->checkUsers();
			$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
			$this->startTime	= microtime(true);
			$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
			$this->logFile	= fopen($this->logFileName, "w");
			$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
			$this->logText	= "Starting Crawling of CT IDs: " . $ctIds . " for KOL Id ".$kolId."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$arrCtIds	= explode(',',$ctIds);
			//Check for already existing Clinical Trial's and associate them with kol
			$arrCtIds		= $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrCtIds, $kolId);
			$this->logText	= "Total No of CTIDs found after associating with existing trials: ".sizeof($arrCtIds)." \r\n";
			$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
			fwrite($this->logFile, $this->logText);	
			//End of checking and associating already existing Clinical Trials
			if(sizeof($arrCtIds)>0){
				foreach($arrCtIds as $key=>$ctID){
					$uniqueCTID	= trim($ctID);
					if(!empty($uniqueCTID)){
						// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
						$ctFetchStartTime	= microtime(true);	
						$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
						$this->logText		= "Url generated: ".$url."\r\n";
						fwrite($this->logFile, $this->logText);
						$content 			= $this ->retrieve_page_get($url);		
						if(!$content)	return false;
						$timeTaken			= microtime(true)-$ctFetchStartTime;		
						$this->logText		= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
						fwrite($this->logFile, $this->logText);				
						$xml 				= new DOMDocument();
						if(!$xml->loadXML($content)){
							$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
							fwrite($this->logFile, $this->logText);	
							//continue;
							die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
						}			
						
						//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
						$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
						foreach($clinicalStudys as $clinicalStudy){
							$timeElapsed	= (microtime(true) - $this->startTime);
							$remTime		= $this->maxScriptTime-$timeElapsed;
							//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
							if($remTime<$this->safeTime){
								$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
								fwrite($this->logFile, $this->logText);	
								die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
							}
							$ctStartTime	= microtime(true);
							$arrKolName		= $this->kol->getKolName($kolId);
							//get the different combinations of names
							$arrKolNameCombination	= $this->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
							//getting the parsed values for Clinical trial 
							$ctDetails		= $this->parse_ct_details($clinicalStudy,$arrKolNameCombination);					
							//saves the Clinical trial details
							$ctId			= $this->save_clinical_trials($ctDetails, $kolId);	
							if($ctId!=null){
								//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
								//fwrite($this->logFile, $this->logText);						
							}else{
								$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
								fwrite($this->logFile, $this->logText);
								continue;
							}	
							
							//getting the parsed values for sponsers
							$arrSponsers	= $this->parse_clinicle_sponsers($clinicalStudy);
							
							//saves sponser details and returns bollean value
							$isSaved		= $this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
							
							//getting the parsed values for Intervention
							$arrIntervention= $this->parse_clinicle_intervention($clinicalStudy);
							
							//saves Intervention details and returns bollean value
							$isSaved		= $this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
							
							//getting the parsed values for Keywords
							$arrKeyword		= $this->parse_clinicle_keyword($clinicalStudy);
							
							//saves Keyword details and returns bollean value
							$isSaved		= $this->save_keyword($arrKeyword, $ctId);	
							
							//getting the parsed values for Meshterms
							$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
							
							//saves Meshterms details and returns bollean value
							$isSaved		= $this->save_meshterms($arrMeshterms, $ctId);	
							
							//getting and parsed values for Investigators
							$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination);
							
							//saves $arrInvestigators details and returns bollean value
							$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
						
							$timeTaken		= microtime(true)-$ctStartTime;
							$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
							$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
							fwrite($this->logFile, $this->logText);
						}
						sleep($this->sleepTime);
						$arrData['message']	= 'Completed processing';
					}
				}
				
				$this->logText	= "End of Procesing all the CTID's \r\n";
				fwrite($this->logFile, $this->logText);		
			}else{
				$arrData['message']	= 'Terminated';
			}
		}else{
			$arrData['message']	= 'KOL ID and CT ID are mandatory and should not be empty';
			$this->logText	= $arrData['message']."\r\n";
			fwrite($this->logFile, $this->logText);	
		}
		$arrData['status']	= 'success';
		$arrData['info']	= 'CT ID(s) processed is '.sizeof($arrCtIds);
		echo json_encode($arrData);
	}
	
	
	function update_kol_trial_status(){
		$status = $this->input->post('status');
		$arrKolIds = $this->input->post('kolId');
		
		foreach($arrKolIds as $kolId){
			$isUpdated = $this->clinical_trial->changeKolTrialStatus($kolId, $status);
		}
		
		if($isUpdated)
			echo "true";
		else
			echo "false";
	}
	
	function process_CITDs_only_KOLs(){
		//Get all the KOLs having the CTIDs only
		$arrKols = $this->clinical_trial->getClinicalTrialsUnprocessedKols();
		
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
		$this->startTime	= microtime(true);
		$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
			
		if(sizeof($arrKols) > 0){
			//Loop trough each KOL
			foreach($arrKols as $arrKolDetail){
				$kolId = $arrKolDetail['id'];
				$this->logText	= "Starting Crawling of CT IDs for KOL Id ".$kolId."\r\n";
				fwrite($this->logFile, $this->logText);
				
				//Get the CTIDs for this KOL
				$arrCtIds = $this->clinical_trial->getCTIDs($kolId);
				//Check for already existing Clinical Trial's and associate them with kol
				$arrCtIds		= $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrCtIds, $kolId);
				$this->logText	= "Total No of CTIDs found after associating with existing trials: ".sizeof($arrCtIds)." \r\n";
				fwrite($this->logFile, $this->logText);	
				$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
				fwrite($this->logFile, $this->logText);	
				//End of checking and associating already existing Clinical Trials
				if(sizeof($arrCtIds)>0){
					foreach($arrCtIds as $key=>$ctID){
						$uniqueCTID	= rtrim(trim($ctID),',');
						if(!empty($uniqueCTID)){
							// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
							$ctFetchStartTime	= microtime(true);	
							$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
							$this->logText		= "Url generated: ".$url."\r\n";
							fwrite($this->logFile, $this->logText);
							$content 			= $this ->retrieve_page_get($url);		
							if(!$content)	return false;
							$timeTaken			= microtime(true)-$ctFetchStartTime;		
							$this->logText		= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
							fwrite($this->logFile, $this->logText);				
							$xml 				= new DOMDocument();
							if(!$xml->loadXML($content)){
								$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
								//Log Activity
								$arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Clinical Trail Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true);
								fwrite($this->logFile, $this->logText);	
								//continue;
								die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
							}			
							
							//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
							$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
							foreach($clinicalStudys as $clinicalStudy){
								$timeElapsed	= (microtime(true) - $this->startTime);
								$remTime		= $this->maxScriptTime-$timeElapsed;
								//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
								if($remTime<$this->safeTime){
									$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
									fwrite($this->logFile, $this->logText);	
									die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
								}
								$ctStartTime	= microtime(true);
								$arrKolName		= $this->kol->getKolName($kolId);
								//get the different combinations of names
								$arrKolNameCombination	= $this->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
								//getting the parsed values for Clinical trial 
								$ctDetails		= $this->parse_ct_details($clinicalStudy,$arrKolNameCombination);					
								//saves the Clinical trial details
								$ctId			= $this->save_clinical_trials($ctDetails, $kolId, 1);	
								if($ctId!=null){
									//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
									//fwrite($this->logFile, $this->logText);						
								}else{
									$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
									//Log Activity
									$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Clinical Trail Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);
									fwrite($this->logFile, $this->logText);
									continue;
								}	
								
								//getting the parsed values for sponsers
								$arrSponsers	= $this->parse_clinicle_sponsers($clinicalStudy);
								
								//saves sponser details and returns bollean value
								$isSaved		= $this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
								
								//getting the parsed values for Intervention
								$arrIntervention= $this->parse_clinicle_intervention($clinicalStudy);
								
								//saves Intervention details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
								
								//getting the parsed values for Keywords
								$arrKeyword		= $this->parse_clinicle_keyword($clinicalStudy);
								
								//saves Keyword details and returns bollean value
								$isSaved		= $this->save_keyword($arrKeyword, $ctId);	
								
								//getting the parsed values for Meshterms
								$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
								
								//saves Meshterms details and returns bollean value
								$isSaved		= $this->save_meshterms($arrMeshterms, $ctId);	
								
								//getting and parsed values for Investigators
								$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination);
								
								//saves $arrInvestigators details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
							
								$timeTaken		= microtime(true)-$ctStartTime;
								$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
								$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
								fwrite($this->logFile, $this->logText);
							}
							sleep($this->sleepTime);
							$arrData['message']	= 'Completed processing';
						}
						$arrStatusData['id'] = $kolId;
						$arrStatusData['is_clinical_trial_processed'] = 1;
						$this->clinical_trial->updateClinicalTrialProcessedKol($arrStatusData);
					}
						
				}else{
					$arrData['message']	= 'Terminated';
				}
				
				$this->logText	= "End of Procesing all the CTID's \r\n";
				//Log Activity
				$arrLogDetails = array(
						'type'=>CRON_JOBS,
						'description'=>$this->logText,
						'status' => STATUS_SUCCESS,
						'transaction_table_id'=>'',
						'transaction_name'=>'Clinical Trial Processing',
						'miscellaneous1'=>$url
				);
				$this->config->set_item('log_details', $arrLogDetails);
				fwrite($this->logFile, $this->logText);	
			}
		}else{
			echo "No Unprocessed KOL ids";
			$this->logText	= "No Unprocessed KOL ids \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Clinical Trial Processing',
					'miscellaneous1'=>$url
			);
			$this->config->set_item('log_details', $arrLogDetails);
			fwrite($this->logFile, $this->logText);	
		}
		echo "Completed processing ";
		$this->logText	= "Completed processing \r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Clinical Trial Processing',
				'miscellaneous1'=>$url
		);
		$this->config->set_item('log_details', $arrLogDetails);
		fwrite($this->logFile, $this->logText);	
		$this->logText	= "Processing Ended on: " . date("d-m-Y H:i:s") . "\r\n";
		echo $this->logText; 
		fwrite($this->logFile, $this->logText);
	}
	function getTrialsAssociatedWithKol($startFrom,$endTo){
		$arrKOLTrials	= array();
		$resultSet	= $this->db->query("select k.id as kol_id,group_concat(kct.cts_id) as trial_id, group_concat(ct.ct_id) as cts_id  
										from kol_clinical_trials kct, clinical_trials ct, kols k 
										where ct.id=kct.cts_id
										and kct.kol_id=k.id
										group by kct.kol_id
										order by k.id limit $startFrom,$endTo");
		foreach($resultSet->result_array() as $row){
			$arrKOLTrials[$row['kol_id']]['cts_id']		= $row['cts_id'];
			$arrKOLTrials[$row['kol_id']]['trial_id']	= $row['trial_id'];
		}
		return $arrKOLTrials;
	}
	function updateMeshTermsByCrawling($startFrom=0,$endTo=50){
		ini_set("max_execution_time",$this->maxScriptTime);	
		$arrKolTrials	= $this->getTrialsAssociatedWithKol($startFrom,$endTo);
		$separator		= "\r\n------------------------------------------------------------------------- \r\n\r\n";
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
		$this->startTime	= microtime(true);
		$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		fwrite($this->logFile, $this->logText);
		if(sizeof($arrKolTrials) > 0){
			//Loop trough each KOL
			foreach($arrKolTrials as $kolId => $trials){
				fwrite($this->logFile, $separator);	
				$this->logText	= "Starting Crawling of CT IDs for KOL Id ".$kolId."\r\n";
				fwrite($this->logFile, $this->logText);
				fwrite($this->logFile, $separator);
				
				//Get the CTIDs for this KOL
				$arrCtIds = explode(',',$trials['cts_id']);
				$arrTrialIds = explode(',',$trials['trial_id']);
				if(sizeof($arrCtIds)>0){
					foreach($arrCtIds as $key=>$ctID){
						$uniqueCTID	= trim($ctID);
						if(!empty($uniqueCTID) && (substr($uniqueCTID,0,3)=='NCT')){
							// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
							$ctFetchStartTime	= microtime(true);	
							$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
							$this->logText		= "Url generated: ".$url."\r\n";
							fwrite($this->logFile, $this->logText);
							$content 			= $this->retrieve_page_get($url);		
							if(!$content)	return false;
							$timeTaken			= microtime(true)-$ctFetchStartTime;		
							$this->logText		= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
							fwrite($this->logFile, $this->logText);				
							$xml 				= new DOMDocument();
							if(!$xml->loadXML($content)){
								$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
								fwrite($this->logFile, $this->logText);	
								//die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
								$this->logText	= "Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName."\r\n ";
								fwrite($this->logFile, $this->logText);
								echo $this->logText	.'<br />';	
								continue;
							}
							
							//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
							$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
							$this->db->query("DELETE FROM ct_mesh_terms WHERE cts_id=$arrTrialIds[$key]");
							foreach($clinicalStudys as $clinicalStudy){
								$timeElapsed	= (microtime(true) - $this->startTime);
								$remTime		= $this->maxScriptTime-$timeElapsed;
								//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
								if($remTime<$this->safeTime){
									$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
									fwrite($this->logFile, $this->logText);	
									die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
								}
								$ctStartTime	= microtime(true);
								$arrKolName		= $this->kol->getKolName($kolId);
								//get the different combinations of names
								$arrKolNameCombination	= $this->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);

								//getting the parsed values for Meshterms
								$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
								//saves Meshterms details and returns bollean value
								$isSaved		= $this->save_meshterms($arrMeshterms, $arrTrialIds[$key]);	
								
								//getting and parsed values for Investigators
								$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination);
								//pr($arrInvestigators);
								//saves $arrInvestigators details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
							
								$timeTaken		= microtime(true)-$ctStartTime;
								$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
								fwrite($this->logFile, "\r\n");	
							}
							sleep($this->sleepTime);
							$arrData['message']	= 'Completed processing';
						}
					}
				}else{
					$arrData['message']	= 'Terminated';
				}
				$this->logText	= "End of Procesing all the CTID's \r\n";
				fwrite($this->logFile, $this->logText);	
			}
		}
		$this->logText	= "Completed processing.. \r\n";
		$this->logText	.= "Total time taken to complete : ".(microtime(true)-$this->startTime)." \r\n";
		echo $this->logText;
		fwrite($this->logFile, $this->logText);
		$this->logText	= "Processing Ended on: " . date("d-m-Y H:i:s") . "\r\n";
		fwrite($this->logFile, $this->logText);	
	}
	
	
	/**
	 * Updates the given trials as verified
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function verified_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolTrial=array();			
			$kolTrial['is_verified']=1;
			$kolTrial['is_deleted']=0;
			$isDeleted=$this->clinical_trial->updateTrialAsVerified($id,$kolTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_VERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);			
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Updates the given trials as un-verified
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function un_verified_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		//pr($selectedRows);
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolTrial=array();			
			$kolTrial['is_verified']=0;
			$kolTrial['is_deleted']=0;
			$isDeleted=$this->clinical_trial->updateTrialAsVerified($id,$kolTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Updates the given trials as deleted
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function deleted_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		//pr($selectedRows);
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolTrial=array();			
			$kolTrial['is_verified']=0;
			$kolTrial['is_deleted']=1;
			$isDeleted=$this->clinical_trial->updateTrialAsVerified($id,$kolTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	function delete_client_clinical_trial($ctId,$ctsId,$kolId1 = ''){		
		$kolId=$this->session->userdata('kolId');		
			$kolClinicalTrial=array();
			$kolClinicalTrial['kol_id']=$kolId;
			$kolClinicalTrial['cts_id']=$ctsId;
			//$kolClinicalTrial['is_deleted']=1;
			//$isDeleted=$this->clinical_trial->updateClinicalTrialsAsDeleted($kolClinicalTrial);
			$isDeleted=$this->clinical_trial->deleteClientClinicalTrial($ctsId);		
			//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_DELETE, $ctsId, MODULE_KOL_TRIAL, $kolId);
			$this->update->deleteUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctsId, MODULE_KOL_TRIAL);
			$this->update->deleteUpdateEntry(KOL_PROFILE_TRIAL_UPDATE, $ctsId, MODULE_KOL_TRIAL);
			if($kolId1 != '')
				$this->kol->deleteIndusAffiliation($ctId,$kolId,'trial');
			return true;
	}
	
	function export_all_trials(){
	    ini_set('memory_limit',"-1");
	    ini_set("max_execution_time",0);
	    $this->load->plugin('php_excel/classes/phpexcel.php');
	
	    $arrTrialData = $this->clinical_trial->getUnprocessedTrials(2);
	    //		pr($arrTrialData);
	    //		exit;
	    $objPHPExcel = new PHPExcel();
	    $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
	    $objWorksheet->setTitle('Clinical Trials');
	    $objWorksheet->setCellValue('A1', 'CT ID')
	    ->setCellValue('B1', 'Trail Name')
	    ->setCellValue('C1', 'Status')
	    ->setCellValue('D1', 'Sponsors')
	    ->setCellValue('E1', 'Condition')
	    ->setCellValue('F1', 'Intervention')
	    ->setCellValue('G1', 'Phase')
	    ->setCellValue('H1', 'Investigators')
	    ->setCellValue('I1', 'Is Industry');
	    $i	=	2;
	    foreach($arrTrialData as $row){
	        $status = $this->clinical_trial->getStatusNameById($row['status_id']);
	        $sponsors = $this->get_sponsers($row['id']);
	        $interventions = $this->get_interventions($row['id']);
	        $investigators = $this->get_investigators($row['id']);
	        if($row['is_industry_trial'] == 1)
	            $isIdustryTrail = 'YES';
	            else if($row['is_industry_trial'] == 2)
	                $isIdustryTrail = 'NO';
	                else
	                    $isIdustryTrail = '';
	
	                    //			echo $status." - ".$sponsors." - ".$interventions." - ".$investigators." - ".$isIdustryTrail;
	                    //			pr($row);
	                    $objWorksheet->setCellValue('A'.$i, $row['ct_id'])
	                    ->setCellValue('B'.$i, $row['trial_name'])
	                    ->setCellValue('C'.$i, $status)
	                    ->setCellValue('D'.$i, $sponsors)
	                    ->setCellValue('E'.$i, $row['condition'])
	                    ->setCellValue('F'.$i, $interventions)
	                    ->setCellValue('G'.$i, $row['phase'])
	                    ->setCellValue('H'.$i, $investigators)
	                    ->setCellValue('I'.$i, $isIdustryTrail);
	                    $i++;
	    }
	    $objPHPExcel->addSheet($objWorksheet);
	    //		exit;
	    $arrStyles =  array(
	            'font'    => array(
	                    'bold'      => true,
	                    'italic'    => false
	            ),
	            'borders' => array(
	                    'bottom'     => array(
	                            'style' => PHPExcel_Style_Border::BORDER_THICK,
	                            'color' => array(
	                                    'rgb' => '000000'
	                            )
	                    ),
	                    'quotePrefix'    => true
	            )
	    );
	
	    // remove first sheet
	    $objPHPExcel->removeSheetByIndex(0);
	    // iterate each sheet and add the style for each sheet
	    foreach ($objPHPExcel->getWorksheetIterator() as $sheet){
	        $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
	        foreach(range('A','I') as $columnID) {
	            $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(50);
	        }
	        $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($arrStyles);
	    }
	
	    $objPHPExcel->setActiveSheetIndex(0);
	
	    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	    //Add Log activity
	    $arrLogDetails = array(
	    		'type' => EXPORT_RECORD,
	    		'description' => 'exporting all clinical trails',
	    		'status' => STATUS_SUCCESS,
	    		'transaction_name' => EXPORT_RECORD,
	    );
	    $this->config->set_item('log_details', $arrLogDetails);
	    log_user_activity ( null, true );
	    
	    // Redirect output to a clientâ€™s web browser (Excel2007)
	    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	    header("Content-Disposition: attachment;filename=Trial_list.xlsx");
	    header('Cache-Control: max-age=0');
	    // If you're serving to IE 9, then the following may be needed
	    header('Cache-Control: max-age=1');
	
	    // If you're serving to IE over SSL, then the following may be needed
	    header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	    header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	    header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	    header ('Pragma: public'); // HTTP/1.0
	
	    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	    $objWriter->save('php://output');
	    exit;
	
	}	
	function get_unprocessed_trials($processedOrUnprocessed = ''){
	    ini_set('memory_limit',"-1");
	    ini_set("max_execution_time",0);
	    $page				= (int)$this->input->post('page'); // get the requested page
	    $limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
	    $arrClinicalTrials	= array();
	    $data				= array();
	    if($arrClinicalTrialsResults=$this->clinical_trial->getUnprocessedTrials($processedOrUnprocessed)){
	        //			echo $this->db->last_query();
	        //			exit;
	        foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
	            $arrClinicalTrial['id']			= $arrClinicalTrialsResult['id'];
	            $arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
	            $arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
	            $arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
	            //$arrClinicalTrial['ct_id']	= '<a href=\''. $arrClinicalTrialsResult['link'].'\' target="_new">'.$arrClinicalTrialsResult['ct_id'].'</a>';
	            $trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['trial_id'];
	            $arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
	            $arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
	
	            if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
	                $trialLink					= $arrClinicalTrialsResult['link'];
	                $arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
	                $arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
	                $arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
	                $arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
	                $arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
	                $arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
	                $arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
	                $arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
	                //				$arrClinicalTrial['eAllowed']							= $this->common_helpers->isActionAllowed('trial','edit',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
	                //				$arrClinicalTrial['dAllowed']							= $this->common_helpers->isActionAllowed('trial','delete',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
	                if($arrClinicalTrialsResult['is_industry_trial'] == 1)
	                    $arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1' checked='checked'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2'></input>";
	                    else if($arrClinicalTrialsResult['is_industry_trial'] == 2)
	                        $arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2' checked='checked'></input>";
	                        else
	                            $arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2'></input>";
	
	                            $arrClinicalTrials[]			= $arrClinicalTrial;
	        }
	        $count				= sizeof($arrClinicalTrials);
	        if( $count >0 ){
	            $total_pages	= ceil($count/$limit);
	        }else{
	            $total_pages	= 0;
	        }
	        $data['records']	= $count;
	        $data['total']		= $total_pages;
	        $data['page']		= $page;
	        $data['rows']		= $arrClinicalTrials;
	    }
	    ob_start('ob_gzhandler');
	    echo json_encode($data);
	}
	
	function update_trial_industries(){
		$data = array();
		$arrData = $this->input->post("data");
		if($this->clinical_trial->updateTrialIndustries($arrData)){
			$this->add_ct_to_affiliations('',$arrData);
			$data['status'] = true;
			echo json_encode($data);
		}
	}
	
	function add_ct_to_affiliations($kolId = '',$ctIds = array()){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$arrCtIds = array();
		$arrKolId = $this->input->post("kolIds");
		if(count($ctIds) > 0){
			foreach ($ctIds as $row){
				$arrCtIds[] = $row["id"];
			}
			$this->db->where_in("kol_clinical_trials.cts_id",$arrCtIds);
		}
		if($kolId != ''){
			$this->db->where("kol_clinical_trials.kol_id",$kolId);
		}
		$this->db->where("clinical_trials.is_industry_trial !=",0);
		$this->db->select("clinical_trials.*,kol_clinical_trials.id as kol_cts_id,kol_clinical_trials.client_id,kol_clinical_trials.user_id,kol_clinical_trials.id AS asoc_id,kol_clinical_trials.kol_id");
		$this->db->join("kol_clinical_trials","kol_clinical_trials.cts_id = clinical_trials.id","left");
		$this->db->where("is_verified",1);
		$arr = $this->db->get("clinical_trials");
		//		echo $this->db->last_query();
		//		exit;
		$arrData = array();
		$arrNotIndus = array();
		foreach ($arr->result_array() as $row){
			if($row['is_industry_trial'] == 2)
				$arrTrialDelete[$row["kol_id"]][] = $row["kol_cts_id"];
		}
		if(count($arrTrialDelete) > 0){
			foreach ($arrTrialDelete as $kolId => $id){
				$this->db->where('kol_id',$kolId);
				$this->db->where_in('source_row_id',$id);
				$this->db->delete('kol_memberships');
			}
		}
		foreach ($arr->result_array() as $row){
			//			pr($row);
			if($row['is_industry_trial'] == 1){
				$orgname = $this->get_sponsers($row['id']);
				$row["organizer"] = $orgname;
				$row["sponsers"] = $orgname;
				if (strpos($row["start_date"], '/') !== FALSE){
					$row["start"] = $this->getYear($row["start_date"]);
				}else{
					$row["start"] = $this->common_helpers->getOnlyYearByDate($row["start_date"]);
				}
				if (strpos($row["end_date"], '/') !== FALSE){
					$row["end"] = $this->getYear($row["end_date"]);
				}else{
					$row["end"] = $this->common_helpers->getOnlyYearByDate($row["end_date"]);
				}
				$row["start1"] = $row["start"];
				$row["end1"] = $row["end"];
				$arrMembershipResult = $this->kol->getAllAffiliationsTypeIndustry('industry',$row);
				//			echo $this->db->last_query();
				if(!$arrMembershipResult){
					$arrAffData = array();
					$row["organizer"] = custom_escape_string($row["organizer"]);
					$orgName["name"] = $row["organizer"];
					$instiId 						= $this->kol->getInstituteIdElseSave($orgName);
					$arrAffData["kol_id"] 			= $row["kol_id"];
					$arrAffData["engagement_id"] 	= 15; //Clinical Research
					$arrAffData["engagement_id"] 	= 16; //Clinical Study
					$arrAffData["type"] 			= "industry";
					$arrAffData["institute_id"] 	= $instiId;
					$arrAffData["start_date"] 		= $row["start"];
					$arrAffData["end_date"] 		= $row["end"];
					$arrAffData["role"] 			= $row["trial_name"];//"Speaker";
					$arrAffData["created_by"] 		= $this->session->userdata('user_id');
					$arrAffData["created_on"] 		= date("Y-m-d H:i:s");
					$arrAffData["client_id"] 		= $this->session->userdata('client_id');
					$arrAffData['data_type_indicator'] = 'Aissel Analyst';
					$arrAffData["added_from"] 		= 2;
					$arrAffData["source_row_id"] 	= $row["kol_cts_id"];
					//					pr($arrAffData);
					$this->db->insert('kol_memberships',$arrAffData);
// 					pr($this->db->last_query());exit;
				}
			}
		}
		return true;
	
	}
	
	function getYear($monYear){
		$monYear = explode("/",$monYear);
		if(count($monYear) == 2)
			return $monYear[1];
			if(count($monYear) == 3)
				return $monYear[2];
	}
}