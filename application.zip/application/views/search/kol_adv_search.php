<?php
/**
*File To Know Basics.
*Created By:
*Created On:4:14:27 PM
*/
?>

<div id="advSearchFieldsContainer">
	<div class="msgBoxContainer">
		<div class="advSearchMsgBox">
		</div>
	</div>
	<form action="<?php echo base_url()?>kols/adv_search_kols" name="advSearchForm" method="post" id="advSearchForm">
		<fieldset>
		<legend>KOL Advanced Search</legend>
		<table>
			<tr>
				<td> 
					<p>
						<label>Keywords </label>
						<input type="text" name="keywords " id="keywords"/>
					</p>
				</td>
				<td>
					<p>
						<label>Title </label>
						<input type="text" name="title" id="title"/>
					</p>
				</td>
			</tr>
			<tr>
				<td> 
					<p>
						<label>First Name</label>
						<input type="text" name="first_name" id="firstName"/>
					</p>
				</td>
				<td>
					<p>
						<label>Middle Name</label>
						<input type="text" name="middle_name" id="middleName"/>
					</p>
				</td>
			</tr>
			<tr>
				<td> 
					<p>
						<label>LastName</label>
						<input type="text" name="last_name" id="lastName"/>
					</p>
				</td>
				<td>
					<p>
						<label>Specialty</label>
						<input type="text" name="specialty" id="specialty"/>
					</p>
				</td>
			</tr>
			<tr>
				<td> 
					<p>
						<label>Country</label>
						<input type="text" name="country" id="country"/>
					</p>
				</td>
				<td>
					<p>
						<label>Sub-Specialty</label>
						<input type="text" name="sub_specialty" id="subSpecialty"/>
					</p>
				</td>
			</tr>
			<tr>
				<td> 
					<p>
						<label>Organization</label>
						<input type="text" name="organization" id="organization"/>
					</p>
				</td>
				<td>
					<p>
						<label>Postal Code</label>
						<input type="text" name="postal_code" id="postalCode"/>
					</p>
				</td>
			</tr>
		</table>
		<input type="button" name="do_earch" id="doSearch" onclick="validateAdvSearchForm()" value="search"/>		
		</fieldset>
	</form>
</div>