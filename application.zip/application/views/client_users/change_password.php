<?php
?>
<style>
	.error{
		color: red;
	}
	
	.passwordTable{
		width:100%;
	
	}
	.alignRight{
		text-align: right;
	}
	.alignLeft{
		text-align: left;
	}
	
	.passwordTable .error {
	    background-position: 10px center;
	    background-repeat: no-repeat;
	    padding:0px !important;
	}
	
	#changePassForm input[type='text'],input[type='password']{
		width:200px;
		margin-right: 11px;
	}
	
	#changePassForm input[type='button']{
		
		margin-left: 260px;
	}
	
	#changePassForm .passwordTable tr td{
		padding:1px;
	}
	
	.passwordContainer {
	    color: #626262;
	    font-size: 12px;
	}
	
	.passwordContainer .passwordTable .cp_label{
		float:right;
		color: #626262;
	    font-size: 11px;
	    padding-right:10px;
	}
	
	.passwordContainer #changePassForm input[type="password"]{
		display:block;
	}
	#display_error {
		font-size:11px;
		color:red;
	}
</style>
<script src="<?php echo base_url()?>js/jquery/jquery.validate1.9.min.js" type="text/javascript"></script>

<script type="text/javascript">
var validationRules	=  {
		old_password: {
			required:true
		},
		new_password: {
			required:true,
			 minlength:8
		},
		confirm_password:{
			required:true
			}
	};

	var validationMessages = {
			old_password: {
				required: "This field is Required"
			},
			new_password: {
				required: "This field is Required"
			},
			confirm_password: {
				required: "This field is Required"
			}
	};
	function updatePassword(){

		if(!$("#changePassForm").validate().form()){
			return false;
		}
		 // Regular ecpression for Vhecking white space
		 reWhiteSpace       = new RegExp(/^\s+$/);
		 var password        = $('#newPass').val();
		 var confirmPassword = $('#confirmPass').val();

	     // Check for white space
	     if (password.indexOf(' ') > 0) {
	          jAlert("Please Check Your Password Fields For Spaces");
	          return false;
	     }

			
	     $('#errorBox').text('');
		 if(password !== confirmPassword){
				$('#newPass').val('');
			 	$('#confirmPass').val('');
				$('#errorBox').text('Passwords do not match.');
				$('#errorBox').css({'color':'red'});
				return false;
		 }
		   $('#errorBox').text('');

		$('.msgContainer').removeClass('success');
		$('.msgContainer').addClass('notice');
		$('.msgContainer').show();

		$('.msgContainer').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');
	

		$.ajax({
			url:'<?php echo base_url()?>client_users/update_password',
			type:'post',
			data:$('#changePassForm').serialize(),
			dataType:'json',
			success:function(returnData){
				if(returnData.status){
					$('.msgContainer').html('<div class="mes"></div>');

					$('.mes').html(returnData.mes);
					//$('div.uniMsgBox').fadeIn("fast");
					$('.msgContainer').removeClass('error');
					$('.msgContainer').addClass('success');
					$('.msgContainer').fadeOut(1500);
					setTimeout(closeDialog,1500);
				}else{
					$('.msgContainer').removeClass('success');
					$('.msgContainer').addClass('error');
					$('.msgContainer').html('<div class="mes"></div>');
					$('.mes').html(returnData.mes);
					
				}
			}
		});
	}

		$(document).ready(function(){
			$("#changePassForm").validate({
				//debug:true,
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});
			$('#newPass').focus(function(){
				$('#errorBox').text('');
			});
			
		});

		function closeDialog(){
			$('#changePasswordContainer').dialog('close');
		}
		function validatingCurrentPassword(){
			var data = {};
			var oldPass = $('#oldPass').val();
			data['old_password'] = oldPass;
			$.ajax({
				url:'<?php echo site_url();?>client_users/validate_current_password',
				dataType:'json',
				data:data,
				type:'post',
				success:function(returnData){
					if(returnData.status==false){
						$('#display_error').css('display', 'block');
						$('#display_error').html('<div>Entered Current Password is wrong</div>');
					}else if(returnData.status==true){
						$('#display_error').css('display', 'none');
						$('#display_error').fadeOut(5000);
					}
				} 
			});
		}
</script>
<div class="passwordContainer">
	<div class="formHeader">
		<button>Change Password</button>
	</div>
	<div class="msgContainer">
		<div class="mes"></div>
	</div>
	
	<form id="changePassForm" autocomplete="off" action="#" method="post">
		<table class="passwordTable">
			<tr>
				<td class="alignRight"><label class="cp_label">Current Password:<span class="required">*</span></label></td>
				<td class="alignLeft">
					<input type="password" name="old_password" class="required" id="oldPass" onblur="validatingCurrentPassword();"></input>
					<div id="display_error" style="display: none;"></div>
				</td>
			</tr>
			<tr>
				<td class="alignRight"><label class="cp_label">New Password:<span class="required">*</span></label></td>
				<td class="alignLeft">
					<input type="password" name="new_password" class="required" id="newPass"></input>
					<div id="errorBox"></div>
				</td>
			</tr>
			<tr>
				<td class="alignRight"><label class="cp_label">Confirm Password:<span class="required">*</span></label></td>
				<td class="alignLeft">
					<input type="password" name="confirm_password" class="required" id="confirmPass"></input>
				</td>
			</tr>
			<tr>
				<td class="" colspan="2">
					<input type="button" value="Change" onclick="updatePassword()"></input>
				</td>
			</tr>
		</table>
	</form>
</div>