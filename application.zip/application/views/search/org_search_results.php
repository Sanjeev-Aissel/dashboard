
		<div class="searchResultsMsg">
			<?php 	if($orgsCount==0) 
						echo "No Organizations found";
					else{
						if(trim($msg['resFor']) != "Search results for")
							echo "<div id='resFor'>".$msg['resFor']." </div>";
						echo "<div id='countMsg'>".$msg['countMsg']." </div>";
					}
			?>
		</div>
		<?php if($orgsCount!=0){?>
		<table>
			<thead>
				<tr>
					<!--<th></th>-->
					<th>Organization Name</th>
					<th>Organization Type</th>
					<th>Country</th>
				</tr>
			</thead>
			<tbody>
			<!-- Sart of loop trough each search result, and displaying as a row result -->
				<?php foreach($arrOrganiations as $orgDetails) {?>
					<tr class="ui-widget-content">
						<!--<td><a href="#" onClick="viewOrgMicroProfile('<?php echo $orgDetails['id'];?>');">click</a></td>-->
						<td><a href="#" onClick="viewOrgMicroProfile('<?php echo $orgDetails['id'];?>');"><img class="micro_view_icon" src="<?php echo base_url().'images/user3.png'?>" /></a> &nbsp; <span class="record_name"><a href="<?php echo base_url();?>organizations/view/<?php echo $orgDetails['id'];?>"><?php echo $orgDetails['name'];?> </a></span></td>
						<td><?php echo $orgDetails['type']?></td>
						<td><?php echo $orgDetails['country']?></td>
						
					</tr>
				<?php }?>
					<tr class="searchPagination">
						<td colspan="4">
								<?php
								$config['first_link'] = 'First';
								$config['div'] = 'searchResultsContainer'; //Div tag id
								$urlPrfix="";
								if($searchType=='simple')
									$urlPrfix="filter_search_organizations";
								$config['base_url'] = base_url()."organizations/".$urlPrfix;
								$config['total_rows'] = $orgsCount;
								$config['per_page'] = $this->ajax_pagination->per_page;
								$config['postVar'] = 'page';
								
								$this->ajax_pagination->initialize($config);
								print $this->ajax_pagination->create_links();
								
								?>		
						</td>
					</tr>
			</tbody>		
		</table>
	<?php }?>