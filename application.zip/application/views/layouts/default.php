<?php
/**
* The Basic layout file used for the 'KOL Profile' module
* 
* Created By: Vinod S.T.
* Created on:Dec 13, 2010
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">

<head>
	<meta charset="UTF-8" />
	<title>Key Opinion Leader Management</title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link rel="shortcut icon" href="<?php echo base_url()?>favicon.ico" >
	
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	
	<!-- jQuery CSS for the UI features -->
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.all.css" rel="stylesheet" />
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.tabs.css" rel="stylesheet" />
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.theme.css" rel="stylesheet" />
	
	<!-- Style for the Horizontal and Vertical Menu -->
	<link type="text/css" href="<?php echo base_url()?>css/demos.css" rel="stylesheet" />

	<!-- jQuery Core File -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
	
	<!-- jQuery files for the UI Core and UI Tabs -->
	<!-- jQuery UI File -->
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>	
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.core.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.tabs.js"></script>
	
	<!-- Load the JS and CSS files for the Vertical Tabs -->
	<script type="text/javascript" src="<?php echo base_url()?>js/verticaltabs.js"></script> 
	<link rel="stylesheet" href="<?php echo base_url()?>css/verticaltabs.css" />
	
	<!-- Validator Plugin Files -->
	<link type="text/css" href="<?php echo base_url()?>css/validationEngine.jquery.css" rel="Stylesheet" />
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine-en.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine.js"></script>

	<!--  Autocomplete Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>/js/jquery.autocomplete.js"></script>

	<!--  Search page css -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/search_page.css" />			
	
	<!-- Stylesheet for the Vertical Tabs -->
	<style type="text/css" title="">
		.ui-tabs-vertical { width: 55em; }
		.ui-tabs-vertical .ui-tabs-nav { padding: .2em .1em .2em .2em; float: left; width: 12em; }
		.ui-tabs-vertical .ui-tabs-nav li { clear: left; width: 100%; border-bottom-width: 1px !important; border-right-width: 0 !important; margin: 0 -1px .2em 0; }
		.ui-tabs-vertical .ui-tabs-nav li a { display:block; }
		.ui-tabs-vertical .ui-tabs-nav li.ui-tabs-selected { padding-bottom: 0; padding-right: .1em; border-right-width: 1px; border-right-width: 1px; }
		.ui-tabs-vertical .ui-tabs-panel { padding: 1em; float: right; width: 40em;}	

	</style>

	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/default_layout.css" />
	
	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	<!--[if IE 8]>
		<link type="text/css" href="<?php echo base_url()?>css/ie8_only.css" rel="stylesheet" />
	<![endif]-->

</head>
<body>
<!-- Start of the WRAPPER div -->
<div id="wrapper" class="span-24">
	<!-- The Sliding Div -->
	<div id="searchableKeywords">
	Searchable Keywords
	</div>
	<!-- End of Sliding Div -->
	
	<!-- Start of HEADER div -->
	<?php echo $this->load->view('elements/kolm_header');?>
	<!-- End of HEADER div -->
	
	
	<!--  Star of Content Wrapper Div -->
	<div id="contentWrapper">
		
		<div id="contents">
			
			<?php echo $this->load->view($contentPage,$data);?>
			
		</div>
		<!-- End of Contents Div -->
				
	</div>
	<!--  End of Content Wrapper Div -->
	
	<div id="footer">
		Copyright 2010
	</div>
	
</div>
<!-- End of the WRAPPER div -->				
</body>
</html>