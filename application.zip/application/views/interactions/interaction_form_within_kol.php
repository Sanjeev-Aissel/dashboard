<?php
/**
 * This is HTML form for Adding or Editing the Interation details
 * 
 * @author Ramesh B
 * @Created on: 28-02-11
 * @since  1.5	
 * @package application.views.interactions
 */
// pr($interactionDetails['otherAttendisData']); exit;
$interactionKolAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen"
	rel="stylesheet">
<!--<script type="text/javascript" src="<?php echo base_url();?>js/chosen.jquery.js"></script>
-->
<style type="text/css">
.interactionAddModalContainer .ui-dialog-titlebar {
	float: right;
	height: 20px;
	margin-bottom: -44px;
	width: 25px;
	z-index: 100;
}

.interactionAddModalContainer .analystForm td {
	padding-bottom: 0px;
}

.interactionAddModalContainer .formHeader {
	padding-bottom: 12px;
}

#interactionForm textarea {
	width: 90%;
}

#notesLable {
	width: 12%;
}

label span.mandatory {
	color: red;
}

.interactionAddModalContainer .analystForm label {
	width: 25%;
	margin: 0.2em 0;
}

#clientInteractionNotes table.jqTransformTextarea {
	width: 80%;
}

#clientInteractionNotes table.jqTransformTextarea td {
	border: 0px solid red;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-tl
	{
	width: 1% !important;
	background-position: 2px top;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-ml
	{
	width: 1% !important;
	background-position: 2px top;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-bl
	{
	width: 1% !important;
	background-position: 2px top;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-mr
	{
	width: 1% !important;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-tr
	{
	width: 1% !important;
}

#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-br
	{
	width: 1% !important;
}
/*	
	#interactionForm input, #interactionForm select, #interactionForm textarea{
		padding:3px;	
	}
*/
#interactionForm input[type="text"] {
	width: 167px;
}

#interactionForm select {
	width: 175px;
}

#interactionForm .error {
	background-color: #FFFFFF;
	border: 1px solid #BBBBBB;
	background-image: none;;
	padding: 0px;
	color: gray;
	border: 1px solid red;
}

#interactionForm label.error {
	float: none;
	color: red;
	padding-left: .5em;
	vertical-align: top;
	border: 0px;
	padding: 0px;
	font-weight: normal;
	margin-left: 0px;
}

#interactionForm p {
	float: none;
	margin-bottom: 0px;
}

#addMoreFile img {
	vertical-align: top;
}

.timePicker {
	width: 25px !important;
}

.timeap {
	width: 50px !important;
}

#interactionForm table.analystForm {
	margin-bottom: 0px;
}

#importOrgContainer .profileContent .microViewLoading {
	background-image: url("../images1/ajax-loader-round.gif") !important;
	background-position: center center;
	background-repeat: no-repeat;
	height: 0px !important;
	margin-top: 0px !important;
	text-align: center !important;
}

#docsList p span {
	display: block;
	float: left;
	margin-left: 2px;
	width: 177px;
}

#docsList p label {
	float: left;
}

fieldset {
	padding: 4px !important;
	margin-bottom: 15px;
}

legend {
	color: #626262;
	font-size: 12px;
	padding: 0px 5px;
}

.chzn-choices {
	height: 60px;
	width: 100%;
}

#interactionForm table tr th, #interactionForm table tr td {
	padding-right: 1px;
	padding-bottom: 1px;
	vertical-align: top;
}

#interactionForm table.highlightHeadings tr th {
	background-color: #eee;
}

#interactionForm table tr th label {
	font-size: 11px;
	color: #626262;
}

#interactionForm #date, #interactionForm #followUpOn, #interactionForm #anttendies
	{
	/*width:80px;*/
	
}

#interactionForm #mode {
	/*width:150px;*/
	
}

#interactionForm #intLocation {
	width: 270px;
}

#interactionForm .arrKolNames {
	width: 168px;
}
/*	#interactionForm input, #interactionForm select, #interactionForm textarea{
		padding: 0px;
	}
*/
.ui-dialog .ui-dialog-content {
	overflow: visible;
}

.microView .profileContent {
	margin-top: 0px;
	padding: 4px 6px 6px;
}

.formHeader {
	margin-top: 0px;
	margin-bottom: 0px;
	width: 200px;
	padding-bottom: 5px;
	padding-top: 0;
}

td.TextAlignCenter {
	text-align: center;
}

#interactionForm input.kolSpecialty {
	width: 150px;
	background: #ededed !important;
}

#suggestions1 {
	background-color: #999999;
	border-radius: 0 0 5px 5px;
	height: auto;
	margin-top: -4px;
	position: absolute;
	display: none;
	z-index: 1;
	border: 1px solid #999999;
}

#suggestions2 {
	background-color: #999999;
	border-radius: 0 0 5px 5px;
	height: auto;
	margin-top: -4px;
	margin-left: 31px;
	position: absolute;
	display: none;
	z-index: 1;
	border: 1px solid #999999;
}

.searchterm {
	clear: both;
	display: block;
	float: left;
	text-align: center;
	width: 25px;
	cursor: default;
}

.searchterm:HOVER, .selectedData {
	background-color: white;
}

numericReportContainer .chzn-container {
	width: 705px !important;
}

numericReportContainer .chzn-container .chzn-drop {
	width: 200px !important;
}

.chzn-container-multi .chzn-choices .search-field .default {
	width: 230px !important;
}

table.tabularGrid caption {
	background: url("<?php echo base_url();?>images/kolm-sprite-image.png")
		repeat-x scroll -2px -236px transparent;
}

.interactionWrapper {
	padding-left: 10px;
	padding-right: 10px;
}

h5.heading {
	/* background: none repeat scroll 0 0 #D8E5F4;
	    color: #2D53AF;
	    margin-bottom: 2px;
	    padding: 5px; */
	
}

.test1 {
	vertical-align: bottom;
}

<?php if (isset ( $subContentPage )) {
		?> .interactionWrapper { padding-left:140px;
	width: 800px;
}

#contentWrapper.span-23 {
	background-image:
		url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	background-position: 135px 50%;
	background-repeat: repeat-y;
}

<?php } ?>
.advSearchIcon {
	background:
		url("<?php echo base_url();?>images/ipad/header/search_active.svg")
		no-repeat scroll 0 0/16px auto;
	height: 20px !important;
	width: 22px !important;
}

#addInteractionContainer .heading {
	color: #2b9af3;
	border: 1px solid #cccccc;
	background: #ffffff;
	margin-bottom: 5px;
	text-align: center;
}

#container form table.tabularGrid caption {
	background: #ececec;
	padding-left: 10px;
	color: #626262;
	padding-top: 0px;
	box-shadow: 0 0 4px #d1d1d1 inset;
	font-size: 13px;
	padding-bottom: 3px;
	padding-top: 3px;
}

table .highlightHeadings tr th {
	background: none !important;
}

#interactionForm table.highlightHeadings tr .alignCenter {
	text-align: left;
}

#interactionForm .alignRight {
	text-align: left;
}

#interactionForm>div>table {
	padding-left: 40px;
	padding-bottom: 10px;
	/*margin-bottom: 10px;*/
	border: 1px solid #ececec;
}

input[type="text"], input[type="password"], select {
	border: 1px solid #d3d3d3;
}

#interactionForm table tr th label {
	font-size: 12px !important;
}

#interactionForm table tr th {
	width: 25%;
}

#interactionForm table tr td {
	padding-bottom: 5px !important;
}

table#locations th {
	width: auto !important;
}

#numericReportContainer>LABEL:FIRST-CHILD {
	background: #ececec !important;
	box-shadow: 0 0 4px #d1d1d1 inset;
}

#numericReportContainer>label {
	background: #ffffff !important;
}

#numericReportContainer table th {
	background: #ececec !important;
	box-shadow: 0 0 4px #d1d1d1 inset;
}

.error.postalerror {
	display: block !important;
	text-align: left !important;
	color: green !important;
}

.alignRight {
	vertical-align: top !important;
}

.heading {
	color: #2b9af3;
	border: 1px solid #cccccc;
	background: #ffffff;
	margin-bottom: 5px;
	text-align: center;
	padding: 8px;
}
</style>


<script type="text/javascript">

//	$(function(){
//		$('#interactionForm').jqTransform({imgPath:'<?php echo base_url()?>js/jqtransform/img/'});
//	});
var specType = '';
var orgId = '<?php if($this->uri->segment(2) =='edit_interaction') echo $this->uri->segment(4); else echo $this->uri->segment(3);?>';
	$(document).ready(function (){
		getKolSpecialty();
		getKolOtherDetails();
		$('#addInterButton').hide();
		$('#ui-datepicker-div').hide();//hide datepicker on load to avoid displaying calender, because of pre-set value in date field.
	});
   var kolAutoCompleteId ='';
   var globalId='';
   <?php if($interactionFor == 'org') { ?>
   var interactionKolAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>interactions/get_all_kol_org_names_for_autocomplete/1/1/'+orgId,
			<?php echo $interactionKolAutoCompleteOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.organizations').html();
				var selId = $(event).children('.organizations').attr('name');
				specType = $(event).children('.organizations').attr('type');
				selText=selText.replace(/\&amp;/g,'&');
				/*var kolId = $(event).children('.id1').html();
				var selText = $(event).children('.kolName').html();
				selText=selText.replace(/\&amp;/g,'&');*/
				$('#'+globalId).val(selText);
				$('#'+globalId).prev('input').prev('input').val(selText);
				$('#'+globalId).prev('input').val(selId);
				$('#'+globalId).next('img').show().attr('onclick','showMicroProfileOrg("'+selId+'")');
				//getKolSpecialty();
				getKolOtherDetails();
			 }
		};
	<?php }else{ ?>
	var interactionKolAutoCompleteOptions = {
			<?php 
	        if(KOL_CONSENT){ ?>
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1/1',
			<?php } else {?>
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1',
			<?php }?>
			<?php echo $interactionKolAutoCompleteOptions;?>,
			onSelect : function(event, ui) {
				var kolId = $(event).children('.id1').html();
				var selText = $(event).children('.kolName').html();
				selText=selText.replace(/\&amp;/g,'&');
				$('#'+globalId).val(selText);
				$('#'+globalId).prev('input').prev('input').val(selText);
				$('#'+globalId).prev('input').val(kolId);
				$('#'+globalId).next('img').show().attr('onclick','showMicroProfile("'+kolId+'")');
				//getKolSpecialty();
				getKolOtherDetails();
			 }
		};
	
	<?php } ?>

	var maxPastDate = new Date();
	maxPastDate.setMonth(maxPastDate.getMonth()-1);
	
	 jQuery.validator.addMethod("maxPastDateValidate",
             function (value, element, params) {
                 var curDate = maxPastDate;
                 curDate.setHours(00);
                 curDate.setMinutes(00);
                 curDate.setSeconds(00);
                 //alert('hi');
                 var inputDate = new Date(value);
                 if(inputDate.toString() == curDate.toString())
                     return true;
                 if (inputDate >= curDate)
                     return true;
                 return false;
             }, 'Past Dates not allowed');

	
	$('#date').datepicker({
		changeMonth: true,
        changeYear: true,
		dateFormat: 'mm/dd/yy',
		maxDate:new Date(),
		minDate: maxPastDate
	});

	$('#followUpOn').datepicker({
		changeMonth: true,
        changeYear: true,
		dateFormat: 'mm/dd/yy'
	});

	$(document).ready(function(){

		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#micro").dialog(addNewKol);



	
		var interactionKolAutoComplete	= $('#kolName').autocomplete(interactionKolAutoCompleteOptions);
		
		//Adds the another upload link below the current upload field //'not working here'
		$("#addMoreFile").click(function(){
			//jAlert('hi');
			var noOfFiles=0;
			noOfFiles=$("#noOfFiles").val();
			noOfFiles++;
		//	var newUpload="<p id='docContainer"+noOfFiles+"'><label for=docName"+noOfFiles+"> Doc name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\"> Description: </label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\"> Upload: </label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input><label onclick='cancelFileUpload("+noOfFiles+");'><img src='<?php echo base_url();?>images/delete_active.png' alt='Cancel' title='Cancel'/></label></p>";
			var newUpload	= "<tr id=docContainer"+noOfFiles+"><td><input type=text name=doc_name"+noOfFiles+" id=docName"+noOfFiles+" /></td><td><input type=text name=description"+noOfFiles+" id=description"+noOfFiles+" /></td><td><input type=file name=int_ref_file"+noOfFiles+" id=intRefFile"+noOfFiles+" /></td><td class=TextAlignCenter><label onclick='cancelFileUpload("+noOfFiles+");'><img src='<?php echo base_url();?>images/delete_active.png' alt='Delete' title='Delete'/></label></td></tr>";
			$("#fileUploadContainer").append(newUpload);
			$("#noOfFiles").val(noOfFiles);
			//var interactionKolAutoComplete	= $('#kolName').autocomplete(interactionKolAutoCompleteOptions);
		});

		/*$('#date').datepicker({
			dateFormat: 'mm/dd/yy'
		});*/

		//set current date by default
		
		$('#date').focus(function(){
			$('table.ui-datepicker-calendar').show();
		});

		/*$('#followUpOn').datepicker({
			dateFormat: 'mm/dd/yy'
		});*/
		$('#followUpOn').focus(function(){
			$('table.ui-datepicker-calendar').show();
		});

		
		//Validate the interactions form using jquery plugin
		$("#addPlansForm").validate({
			debug:true,
			onkeyup:true
		});
		
		
		$("#interactionForm").validate();

		
		$("#timefmhr").focus(function(){
			$("#suggestions1").show();
			$("#suggestions2").hide();
	     });
                
	      $("#timefmmin").focus(function(){
	    	  $("#suggestions2").show();
	    	  $("#suggestions1").hide();
	      });

	    $("#timefmap").focus(function(){
	    	$("#suggestions1").hide();
	    	 $("#suggestions2").hide();
	     });
		$("#followUpOn").focus(function(){
			$("#suggestions1").hide();
	    	 $("#suggestions2").hide();
	     });

		$('html').click(function() {
	    	  $("#suggestions1").hide();
	    	  $("#suggestions2").hide();
	 	 });

	 	 $('#suggestions1 .searchterm').click(function(event){
		 	 var selectedVal = $(this).html();
		 	 $("#timefmhr").val(selectedVal);
		 	 $("#suggestions1").hide();
	 	     event.stopPropagation();
	 	 }); 
	 	$('#suggestions2 .searchterm').click(function(event){
	 		 var selectedVal = $(this).html();
	 		 $("#timefmmin").val(selectedVal);
		 	 $("#suggestions2").hide();
	 	     event.stopPropagation();
	 	 });
	 	$('#timefmhr').click(function(event){
	 		$("#suggestions2").hide();
	 	     event.stopPropagation();
	 	 });
	 	$('#timefmmin').click(function(event){
	 		$("#suggestions1").hide();
	 	     event.stopPropagation();
	 	 });  

	 	$('#timefmhr').keydown(function(event) {
	 		$("#suggestions1").show();
		 	var selectedObj = $("#suggestions1 .selectedData");
	 		if (event.keyCode === 40) { //Down arrow
		 		if(selectedObj != null){
					var nextObj = $(selectedObj).next();
					if($(nextObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(nextObj).addClass("selectedData");
						$(this).val($(nextObj).html());
					}else{
						var firstObj = $("#suggestions1 .searchterm:first");
						var lastObj = $("#suggestions1 .searchterm:last");
						$(lastObj).removeClass("selectedData");
						$(firstObj).addClass("selectedData");
						$(this).val($(firstObj).html());
					}
			 	}
	 		}	 	       
	 		else if (event.keyCode === 38) { //Up arrow
	 			if(selectedObj != null){
					var prevObj = $(selectedObj).prev();
					if($(prevObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(prevObj).addClass("selectedData");
						$(this).val($(prevObj).html());
					}else{
						var firstObj = $("#suggestions1 .searchterm:first");
						var lastObj = $("#suggestions1 .searchterm:last");
						$(lastObj).addClass("selectedData");
						$(firstObj).removeClass("selectedData");
						$(this).val($(lastObj).html());
					}
			 	}
	 		}else if (event.keyCode === 13){
	 			$(this).val($(selectedObj).html());
	 			$("#suggestions1").hide();
	 			event.stopPropagation();
		 	}
	 	});

	 	$('#timefmmin').keydown(function(event) {
	 		$("#suggestions2").show();
		 	var selectedObj = $("#suggestions2 .selectedData");
	 		if (event.keyCode === 40) { //Down arrow
		 		if(selectedObj != null){
					var nextObj = $(selectedObj).next();
					if($(nextObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(nextObj).addClass("selectedData");
						$(this).val($(nextObj).html());
					}else{
						var firstObj = $("#suggestions2 .searchterm:first");
						var lastObj = $("#suggestions2 .searchterm:last");
						$(lastObj).removeClass("selectedData");
						$(firstObj).addClass("selectedData");
						$(this).val($(firstObj).html());
					}
			 	}
	 		}	 	       
	 		else if (event.keyCode === 38) { //Up arrow
	 			if(selectedObj != null){
					var prevObj = $(selectedObj).prev();
					if($(prevObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(prevObj).addClass("selectedData");
						$(this).val($(prevObj).html());
					}else{
						var firstObj = $("#suggestions2 .searchterm:first");
						var lastObj = $("#suggestions2 .searchterm:last");
						$(lastObj).addClass("selectedData");
						$(firstObj).removeClass("selectedData");
						$(this).val($(lastObj).html());
					}
			 	}
	 		}else if (event.keyCode === 13){
	 			$(this).val($(selectedObj).html());
	 			$("#suggestions2").hide();
	 			event.stopPropagation();
		 	}
	 	});

	 	$("#anttendies").on("focusout",function(){
		 	if(add_interaction!=='org'){
				validateAttendiesCount(this);
		 	}
		});

	 	//------------------- Start of Postal code focusout ----------
        $("#postal_code").on("focusout",function(){
            var postalEle = $(this);
			var postalCode = $(this).val();
			if(postalCode != ''){
				$("#loadingStates").show();
				$.ajax({
		            url: '<?php echo base_url() ?>country_helpers/get_zip_code_details/'+postalCode,
		            type: 'post',
		            dataType: 'json',
		            success: function (returnData) {
		            	$(postalEle).parent().find("label.error").remove();
		              if(returnData.status == 1){
						$("#country_id").val(returnData.details.country_id);

						$("#loadingStates").show();
				        var countryId = $('#country_id').val();
				        var params = "country_id=" + countryId;
				        $("#state_id").html("<option value=''>-- Select State --</option>");
				        $("#city_id").html("<option value=''>-- Select City --</option>");
				        var states = document.getElementById('state_id');
				        $.ajax({
				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
				            dataType: "json",
				            data: params,
				            type: "POST",
				            success: function (responseText) {
				                $.each(responseText, function (key, value) {
				                    var newState = document.createElement('option');
				                    newState.text = value.state_name;
				                    newState.value = value.state_id;
				                    var prev = states.options[states.selectedIndex];
				                    states.add(newState, prev);
				                });
				                $("#state_id option[value='']").remove();
				                $("#state_id").prepend("<option value=''>-- Select State --</option>");
				                $("#state_id").val("");
				            },
				            complete: function () {
				                $("#loadingStates").hide();
				                $("#state_id").val(returnData.details.region_id);
								//$("#city_id").val(returnData.details.city_id);
								var stateId = $('#state_id').val();
		                        $("#city_id").html("<option value=''>-- Select City</option>");
		                        var cities = document.getElementById('city_id');
		                        var params = "state_id=" + stateId;
		                        $("#loadingCities").show();
								 $.ajax({
		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
		                            dataType: "json",
		                            data: params,
		                            type: "POST",
		                            success: function (responseText) {
		                                $.each(responseText, function (key, value) {

		                                    var newCity = document.createElement('option');
		                                    newCity.text = value.city_name;
		                                    newCity.value = value.city_id;
		                                    var prev = cities.options[cities.selectedIndex];
		                                    cities.add(newCity, prev);
		                                });

		                                $("#city_id").val(returnData.details.city_id);
		                            },
		                            complete: function () {
		                                $("#loadingCities").hide();
		                            }
		                        });				                
				            }
				        });
						
	                        //if(returnData.details.city_id == '')
						 		//$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
			          }else{
			        	  	$('#state_id').prop('selectedIndex',0);
				          	$('#city_id option[value!=""]').remove();
				          	$('#country_id').prop('selectedIndex',0);
							//$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror">Unable to populate City, State for given Postal Code.</label>');
				      }
		            },
		            complete: function () {
                        $("#loadingStates").hide();
                    }
		        });
			}
        });
		// ------------------- End of Postal code focusout ----------
		
});

	function validateAttendiesCount(thisEle){
		//Validate for attendies
		var numAttendies = $("#interactionForm #anttendies").val();
	    var grouppping = $("#interactionForm #grouping").val();
	    if(grouppping == 1){
			if(numAttendies > 1 || numAttendies < 1){
				$("#interactionForm #anttendies").next().remove();
				//$("#interactionForm #anttendies").parent().append('<label for="anttendies" generated="true" class="error">If Interaction Category is One-on-One, then Number of Attendees has to be 1.</label>');
				alert('If Interaction Category is One-on-One, then Number of Attendees has to be 1.');
				 return false;
			}
		}
	    if(grouppping == 2){
			if(numAttendies < 2 || numAttendies < 1){
				$("#interactionForm #anttendies").next().remove();
				//$("#interactionForm #anttendies").parent().append('<label for="anttendies" generated="true" class="error">If Interaction Category is Group, then Number of Attendees has to be 2 or higher.</label>');
				alert('If Interaction Category is Group, then Number of Attendees has to be 2 or higher.');
				 return false;
			}
		}
	    $("#interactionForm #anttendies").next().remove();
		return true;
	}

	function validateAttendiesFreeText(thisEle){
		//alert($('input.selectedKolId[value=""]').length);
		//if($('input.selectedKolId [value=""]').length) return false;
		//Validate kol name for free text
		var numKolsFreeText = 0;
		$('#kolsTable .autocompleteInputBox').each(function(){
			$(this).parent().children("label.error").remove();
			var thisVal = $(this).val();
			//alert($(this).val());
			if(thisVal == ""){
				$(this).parent().append('<label for="anttendies" generated="true" class="error">Select from Auto Suggestions</label>');
				numKolsFreeText++;
			}
		});
		if(numKolsFreeText != 0)
			return false;

		return true;
	}
	
	function showMicroProfile(kolId){

		$("#micro .microViewProfile").html("<div class='microViewLoading'>Loading...</div>");
		$("#micro").dialog("open");
		$("#micro .microViewProfile").load(base_url+'kols/view_kol_micro/'+kolId);
		return false;	
	}

	function showMicroProfileOrg(kolId){

		$("#micro .microViewProfile").html("<div class='microViewLoading'>Loading...</div>");
		$("#micro").dialog("open");
		$("#micro .microViewProfile").load(base_url+'organizations/view_micro_org/'+kolId);
		return false;	
	}
		
	//deletes the document with given document id
	function deleteDocument(documentId){
		$.ajax({
			url:'<?php echo base_url();?>interactions/delete_document/'+documentId,
			dataType:'json',
			success:function(returnData){
				if(returnData==true)
					$("#doc"+documentId).remove();
			}
		});
	}

	$(".test1").live("focus",function(){
		 kolAutoCompleteId = $(this).attr('id');
		//jAlert(id);
	});

	$(".test1").live("focus",function(){
		 globalId = $(this).attr('id');
		 $(this).parent().children("label.error").remove();
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
	});

	$(".test1").live("focusout",function(){
		$(this).parent().children("label.error").remove();
		var thisEle = $(this);
		setTimeout(function(){
		 if($(thisEle).val() != ""){
			var selectedId = $(thisEle).prev().val();
			if(selectedId == ''){
				$(thisEle).parent().append('<label for="anttendies" generated="true" class="error">Select from Auto Suggestions</label>');
			}
		 }else{
			 $(thisEle).prev().val("");
		 }
		}, 100);
	});

	$(".test1").live("blur",function(){
		
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
		 
	});
	
	//get the kol specialty and make it as selected in thereapetic are.
	function getKolSpecialty(){
		
		var kolId	= $("#"+kolAutoCompleteId).prev().val();
		var kolName=$("#"+kolAutoCompleteId).val();
		var data = {};
		data['kol_name'] = kolName;
		if(kolName!=''){
			if(!kolId){
				kolId = '<?php echo $kolId;?>';
			}
			$.ajax({
				url:'<?php echo base_url()?>kols/get_kol_specialty_id/'+kolId,
				type:'post',
				data:data,
				dataType:"json",
				success:function(returndData){
					var speccialtyId=returndData.specialtyId;
					var specialtyName=returndData.specialtyName;
					$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(2).find('input').val(specialtyName);
					$("#therapeuticArea").val(specialtyName);
				}
			});
		}else{
			$("#therapeuticArea").val("");
		}
	}

	//get the kol other detaiols.
	function getKolOtherDetails(){
		var kolId	= $("#"+kolAutoCompleteId).prev().val();
		var kolName=$("#"+kolAutoCompleteId).val();
		var data = {};
		data['kol_name'] = kolName;
		if(!kolId){
			kolId = '<?php echo $kolId;?>';
		}
		var otherDetailsUrl = '<?php echo base_url()?>interactions/get_kol_other_details/'+kolId;
		<?php if($interactionFor =='org'){?>
		if(specType=='key'){
			otherDetailsUrl = '<?php echo base_url()?>interactions/get_key_people_details/'+kolId;
		}else{
			otherDetailsUrl = '<?php echo base_url()?>interactions/get_kol_other_details/'+kolId;
		}
		<?php }?>
		
		if(kolName!=''){
			$.ajax({
				url:otherDetailsUrl,
				type:'post',
				data:data,
				dataType:"json",
				success:function(returndData){
					var speccialtyId=returndData.specialtyId;
					var specialtyName=returndData.specialtyName;
					var last_interaction=returndData.title;
					<?php if($interactionFor =='org'){?>
					if(specType=='key'){
						$('#'+globalId).prev('input').prev('input').prev('input').val('key_type');
						$('#'+globalId).prev('input').prev('input').prev('input').prev('input').val('key_type');
					}else{
						$('#'+globalId).prev('input').prev('input').prev('input').val('kol_type');
						$('#'+globalId).prev('input').prev('input').prev('input').prev('input').val('kol_type');
					}
						$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(1).find('input').val(last_interaction);
					<?php }else{ ?>
						$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(2).find('input').val(specialtyName);
						$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(3).find('input').val(last_interaction);
					<?php } ?>
					
				}
			});
		}else{
			$("#therapeuticArea").val("");
		}
	}

	//Validates the interaction form using jquery plugin
	function validateAndSubmitInteractionForm(){
		$("#saveInteraction").hide();
		$("#interactionForm label.error").remove();
		$.each($('.checkAboveInputValue'),function(){
			var kolName =$(this).val();
			var  mainkol=$(this).next('input').next('input').val();
			//jAlert(kolName);
		
			if(kolName != mainkol){
				$(this).next('input').val('');
			}
		});
	
		if(!$("#interactionForm").validate({
			  rules: {
			    field: {
			      required: true,
			      maxlength: 4
			    },
			    date:{
					date:true,
					reqired:true,
// 					maxPastDateValidate:true
			    }
			  }
			}).form()){
			$('html, body').animate({
                scrollTop: $("#interactionForm .error").first().offset().top-30
            });
   			 $("#interactionForm .error").first().focus();
   			$("#saveInteraction").show();
			return false;
		}else{
			var value = $("#date").val();
			$("#date").next().remove();
			//validate for Future date
			 var curDate = maxPastDate;
	             curDate.setHours(00);
	             curDate.setMinutes(00);
	             curDate.setSeconds(00);
	             var inputDate = new Date(value);
	             if(inputDate.toString() == curDate.toString()){
		             	return true;
	             }                     
	             if(inputDate <= curDate){
	                 //alert("More than 30 day Past not allowed");
	                 $("#date").parent().append('<label for="date" generated="true" class="error">Past date not allowed, Max 30 days.</label>');
	                 $("#saveInteraction").show();
	                 return false;
	             }

	             curDate = new Date();
	             curDate.setHours(00);
	             curDate.setMinutes(00);
	             curDate.setSeconds(00);
	             var inputDate = new Date(value);
	             if(inputDate > curDate){
	                 //alert("Future date not allowed");
	                 $("#date").parent().append('<label for="date" generated="true" class="error">Future date not allowed.</label>');
	                 $("#saveInteraction").show();
	                 return false;
	             }

	 			if(validateAttendiesCount() == false){
	 				$("#saveInteraction").show();
		 			return false;
	 			}	
	 			//if(validateAttendiesFreeText() == false)
		 			//return false;

			var status;
			/*$.each($('.test1'),function(){
				
				var kolName = $(this).val();
				kolName = $.trim(kolName);
				if(kolName.indexOf(' ')>=1){
				}else if(kolName.indexOf(',')>=1){
				}else{
					status='False';
					jAlert("Single word KOL not allowed, please enter first and last name");
					return false;
				}
				
			});*/
			if(status=='False'){
				$("#saveInteraction").show();
				return false;
			}
			var noOfattndis = $('#anttendies').val();
			var noOfKols  =0;
			$.each($('.test1'),function(){
				noOfKols=parseInt(noOfKols)+1;
			});
		
			var noOfUsers=0;
			$.each($('.chosenMultipleSelect option:selected'),function(){
				noOfUsers=parseInt(noOfUsers)+1;
			});
			var totlAttendis = parseInt(noOfUsers)+parseInt(noOfKols);
			/*
			var r = confirm("Are you sure you want to save this interaction? Interactions once saved will be locked for editing.");
			if (r == true) {
			    return true;
			} else {
				return false;
			}
			
			jConfirm("Are you sure you want to submit?",'Please Confirm',function(r){
            	if (r == true) {                      
                    return true;
                 } else {
                     return false;
                 }
			});*/
			}
	}

	function validateToFromTime(){

		//Validate for time boudaries
		var fromHr=$( "#timefmhr" ).val();
		var fromMin=$( "#timefmmin" ).val();
		var toHr=$( "#timetohr" ).val();
		var toMin=$( "#timetomin" ).val();
		var timefmap = $('#timefmap').val();
		var timetoap = $('#timetoap').val();

		//validate hour bondries
		if(fromHr < 0 || fromHr > 12){
			jAlert("Invalid time");
			return false;
		}

		if(fromHr < 0 || fromHr > 12){
			jAlert("Invalid time");
		}

		//Validate for reqired
		if($( "#timefmhr" ).hasClass("required")){
			if(fromHr == "00" && toHr == "00"){
				if(fromMin == "00" && toMin == "00"){
					jAlert("time required");
					return false;
				}
			}
			
		}
		
		if(fromHr > toHr && timefmap == timetoap){
			jAlert("you can't end interaction before interaction starts. So enter interaction end time properly.");
			return false;
		}
		if((fromHr == toHr && timefmap == timetoap )&& fromMin > toMin){
			jAlert("you can't end interaction before interaction starts. So enter interaction end time properly.");
			return false;
		}

		//Validate for interaction date and folloupdate
		var interactionDate = new Date();
		var interactionDateText = $('#date').val();
		var followUpdate=new Date();
		var followUpdateText = $('#followUpOn').val();
		if(followUpdateText != ''){
			interactionDate.setFullYear(interactionDateText.split("/")[2], interactionDateText.split("/")[0], interactionDateText.split("/")[1])
			followUpdate.setFullYear(followUpdateText.split("/")[2], followUpdateText.split("/")[0], followUpdateText.split("/")[1])
			if(interactionDate > followUpdate){
				jAlert('Follow up date should be greater than Interaction date');
				return false;
			}
		}
		
		return true;
	}
	
	//If remindme is checked the add required for 'time' and 'followupon' else remove the same fro those
	function modifyValidations(){
		var reminder=$("#reminder:checked").val();
		if(reminder==1){
			//add required
			$("#timefmhr").addClass('required');
			$("#followUpOn").addClass('required');
			$("label[for='time']").append('<span class="required">*</span>');
			$("label[for='followUpOn']").append('<span class="required">*</span>');
			
		}else{
			//remove required
			$("#timefmhr").removeClass('required');
			$("#followUpOn").removeClass('required');
			$("label[for='time'] span").remove();
			$("label[for='followUpOn'] span").remove();
		}
	}

	//Removes the file upload row of the given row number
	function cancelFileUpload(fileNumber){
		$('#docContainer'+fileNumber).remove();
	}
	/**
	* Returns the list of Cities of the Selected State
	*/
	function getCitiesByStateId(){
		// Show the Loading Image
		$("#loadingCities").show();
		$("#postal_code").parent().find("label.error").remove();
		var stateId=$('#state_id').val();
		$("#city_id").html("<option value=''>Select City</option>");	
		var cities = document.getElementById('city_id');
		var params = "state_id="+stateId;	
		if(stateId == ''){
			$("#loadingCities").hide();
			return false;
		}
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {	
							
				var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);				
				});
                                $("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				
			},
			complete: function(){
				$("#loadingCities").hide();
			}		
		});		
		
	}
	$(document).ready(function(){
		$('#addMoreKols').click(function(){
			var kolSHtml = 	$('#kols').html();
			var noofKols = $('#noOfKols').val();
			var numRows = $('#noOfKols').parent().children().length;
			var grouppping = $("#interactionForm #grouping").val();
			if(grouppping == 1 && numRows > 2){
				jAlert("You can only enter 1 for a One-to-One interaction");
				return false;
			}
			$('#kolsTable').append("<tr>"+kolSHtml+"</tr>");
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfKols').val(noOfFields);
			var kolFieldName = 'kol_name'+noOfFields;
			var kolFieldId = 'kolName'+noOfFields;
			$('#kolsTable tr:last td:eq(0) input:last').removeAttr('readonly');
			$('#kolsTable tr:last td:eq(0) input:last').val('');
			$('#kolsTable tr:last td:eq(0) input:last').attr('name',kolFieldName);
			$('#kolsTable tr:last td:eq(0) input:last').attr('id',kolFieldId);
			$('#kolsTable tr:last td:eq(0) input:last').addClass('autocompleteInputBox');
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').prev('input').attr('id','attendeeType'+noOfFields).val('');
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').prev('input').attr('name','attendee_type'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').attr('id','attendeeTypes'+noOfFields).val('');
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').attr('name','attendee_types'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('id','kolNameAuto'+noOfFields).val('');
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('name','kol_name_auto'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('name','kol_id_auto'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('id','kolIdAuto'+noOfFields).val('');
			//Hide the image
			$('#kolsTable tr:last td:eq(0) input:last').next('img').hide();
			$('#kolsTable tr:last td:eq(0) input:last').next('img').removeAttr('onClick');
			
			

			<?php if($interactionFor =='org'){?>
			var last_interaction = 'last_interaction'+noOfFields;
			$('#kolsTable tr:last td:eq(1) p input').attr('name',last_interaction);
			$('#kolsTable tr:last td:eq(1) p input').attr('id',last_interaction).val('');
			<?php }else{ ?>
			var status = 'status'+noOfFields;
			$('#kolsTable tr:last td:eq(1) p select').attr('name',status);
			$('#kolsTable tr:last td:eq(1) p select').attr('id',status).val('');	
			
			var therapeutic_area = 'therapeutic_area'+noOfFields;
			$('#kolsTable tr:last td:eq(2) p input').attr('name',therapeutic_area);
			$('#kolsTable tr:last td:eq(2) p input').attr('id',therapeutic_area).val('');
			
			var last_interaction = 'last_interaction'+noOfFields;
			$('#kolsTable tr:last td:eq(3) p input').attr('name',last_interaction);
			$('#kolsTable tr:last td:eq(3) p input').attr('id',last_interaction).val('');
			<?php } ?>
			

			//var attendee_note = 'attendee_note'+noOfFields;
			//$('#kolsTable tr:last td:eq(2) p textarea').attr('name',attendee_note);
			//$('#kolsTable tr:last td:eq(2) p textarea').attr('id',attendee_note);
			
			var interactionKolAutoComplete	= $('#'+kolFieldId).autocomplete(interactionKolAutoCompleteOptions);
			//$("#"+kolFieldId).parent().parent().parent().find('td').eq(1).find('input').val('');
			<?php if($interactionFor =='org'){?>
				$('#kolsTable tr:last td:eq(2) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete_active.png' onclick='deleteRow(this)'>");
			<?php }else{?>
				$('#kolsTable tr:last td:eq(4) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete_active.png' onclick='deleteRow(this)'>");
			<?php } ?>	
		});

		$('#addMoreNonAttendeeKols').click(function(){
			var kolSHtml = 	$('#nonProfiledKols').html();
			$('#nonProfiledkolsTable').append("<tr>"+kolSHtml+"</tr>");
			var noofKols = $('#noOfNonProfiledKols').val();
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfNonProfiledKols').val(noOfFields);
			
			var non_profiled_kol = 'non_profiled_kol'+noOfFields;
			$('#nonProfiledkolsTable tr:last td:eq(0) input').attr('name',non_profiled_kol);
			$('#nonProfiledkolsTable tr:last td:eq(0) input').attr('id',non_profiled_kol).val('');

			var non_profifled_specialty = 'non_profifled_specialty'+noOfFields;
			$('#nonProfiledkolsTable tr:last td:eq(1) select').attr('name',non_profifled_specialty);
			$('#nonProfiledkolsTable tr:last td:eq(1) select').attr('id',non_profifled_specialty);
			$("#nonProfiledkolsTable tr:last td:eq(1) select option").prop("selected", false);
			$("#nonProfiledkolsTable tr:last td:eq(1) select").val(0).click();
			
                        var non_profiled_comment = 'non_profiled_comment'+noOfFields;
			$('#nonProfiledkolsTable tr:last td:eq(2) textarea').attr('name',non_profiled_comment);
			$('#nonProfiledkolsTable tr:last td:eq(2) textarea').attr('id',non_profiled_comment).val('');
			//var interactionKolAutoComplete	= $('#'+kolFieldId).autocomplete(interactionKolAutoCompleteOptions);
			//$("#"+kolFieldId).parent().parent().parent().find('td').eq(1).find('input').val('');

			$('#nonProfiledkolsTable tr:last td:eq(3) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete_active.png' onclick='deleteRow(this)'>");
		});	

		$('#addMoreObjectives').click(function(){			
			var kolSHtml = 	$('#trobjective').html();
			$('#objectiveTable').append("<tr>"+kolSHtml+"</tr>");
			var noofKols = $('#noOfObjectives').val();
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfObjectives').val(noOfFields);

			var order = 'product'+noOfFields;
			$('#objectiveTable tr:last td:eq(0) select').attr('name',order);
			$('#objectiveTable tr:last td:eq(0) select').attr('id',order);
			var selProduct = $('#'+order+' option:selected').val();
			$("#"+order+" option[value='"+selProduct+"']").removeAttr('selected', false);
			$('#objectiveTable tr:last td:eq(0) select option:first').attr('selected','selected').val('').text('Select');
			$('#objectiveTable tr:last td:eq(0) .is_primary').remove();
			
			var objectFieldName = 'objective'+noOfFields;
			$('#objectiveTable tr:last td:eq(1) select').attr('name',objectFieldName);
			$('#objectiveTable tr:last td:eq(1) select').attr('id',objectFieldName);
			var selObject = $('#'+objectFieldName+' option:selected').val();
			$("#"+objectFieldName+" option[value='"+selObject+"']").removeAttr('selected', false);
			$('#objectiveTable tr:last td:eq(1) select option:first').attr('selected','selected').val('').text('Select');
			
			
			var topic = 'topic'+noOfFields;
			$('#objectiveTable tr:last td:eq(2) select').attr('name',topic);
			$('#objectiveTable tr:last td:eq(2) select').attr('id',topic);
			$('#objectiveTable tr:last td:eq(2) select option:first').attr('selected','selected').val('').text('Select');
			$('#objectiveTable tr:last td:eq(2) select').find("option:gt(0)").remove();

			var product = 'subtopic'+noOfFields;
			$('#objectiveTable tr:last td:eq(3) select').attr('name',product);
			$('#objectiveTable tr:last td:eq(3) select').attr('id',product);
			$('#objectiveTable tr:last td:eq(3) select option:first').attr('selected','selected').val('').text('Select');
			$('#objectiveTable tr:last td:eq(3) select').find("option:gt(0)").remove();
	
			
		//	var brand = 'brand'+noOfFields;
		//	$('#objectiveTable tr:last td:eq(3) select').attr('name',brand);
		//	$('#objectiveTable tr:last td:eq(3) select').attr('id',brand);
			//alert();
			$('#objectiveTable tr td:last label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete_active.png' onclick='deleteRow(this)'>");
			

		});


		<?php if($interactionDetails!=''){?>

		var noOfKols = $('#noOfKols').val();
		for(var i=1;i<=noOfKols;i++){
			var interactionKolAutoComplete	= $('#kolName'+i).autocomplete(interactionKolAutoCompleteOptions);
		}
		<?php }?>
	});

	function getBrandName(proObject){
		var pId = $(proObject).val();
	
		var brandId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_brands_by_product/'+pId,
			dataType:'json',
			success:function(returndata){
			
				$('#'+brandId+" option" ).remove();
				$('#'+brandId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
				
		  				  $('#'+brandId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			}
		});
	}
	function getProduct(proObject){
		//$('#loadingProduct').show();
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		var typeId = $(proObject).val();
	
		var productId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');

		var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_product_by_type/'+typeId,
			dataType:'json',
			success:function(returndata){
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				$('#'+productId+" option" ).remove();
				$('#'+productId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
				
		  				  $('#'+productId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
			//	$('#loadingProduct').hide();
				}
		});
	}

	function getTopic(proObject){
		//$('#loadingTopic').show();
		//var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();

		var groupId =  $('#grouping').val();
		var productId =  $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();
		var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
                    var typeId = $(proObject).val();
		var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
		var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		if(typeId == "" || productId == ""){
			$('#'+topicId+" option" ).remove();
			$('#'+topicId).append('<option value="">Select</option>');
			$('#'+subTopicId+" option" ).remove();
			$('#'+subTopicId).append('<option value="">Select</option>');
		}else{
		$('#'+topicId).parent().find("#loadingTopic").show();
		$.ajax({
				url:'<?php echo base_url()?>/interactions/get_topic_by_type/'+typeId+'/'+productId,
			dataType:'json',
			success:function(returndata){
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				$('#'+subTopicId+" option" ).remove();
				$('#'+subTopicId).append('<option value="">Select</option>');
				// .each loops through the array
                  for (var result in returndata.arrTopics) {
                       $('#'+topicId).append("<option  id='" + returndata.arrTopics[result].id + "' value='" + returndata.arrTopics[result].id + "'>" + returndata.arrTopics[result].name + "</option>");
                  }
                               
//				$.each(returndata.arrTopics, function(key,value){
//				
//		  				  $('#'+topicId).append($("<option></option>")
//			                    .attr("value",key)
//			                    .text(value));
//			
//				});
			},
			complete:function(){
				$('#'+topicId).parent().find("#loadingTopic").hide();
				}
		});
	}
	}

	function getSubTopic(proObject){
		var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();
		var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
		var topicId =  $(proObject).val();
		var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$('#'+subTopicId).parent().find("#loadingSubTopic").show();
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_sub_topics/'+productId+'/'+typeId+'/'+topicId,
			dataType:'json',
			success:function(returndata){
			
				$('#'+subTopicId+" option" ).remove();
				$('#'+subTopicId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrSubTopics, function(key,value){
				
		  				  $('#'+subTopicId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
				$('#'+subTopicId).parent().find("#loadingSubTopic").hide();
				}
		});
	}

	function resetDropDowns(proObject){
//                var productid = $(proObject).val();
            getTypeByProduct(proObject);
		var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
		var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
                    var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').attr('id');
		$('#'+topicId+" option" ).remove();
                    $('#interactionForm select#' + typeId + ' option').remove();
                    $('select#' + typeId).append('<option value="">Select</option>');
		$('#'+topicId).append('<option value="">Select</option>');
		$('#'+subTopicId+" option" ).remove();
		$('#'+subTopicId).append('<option value="">Select</option>');
		var typeObject = $(proObject).parent().parent().parent().find('td').eq(1).find('select');
//		getTopic(typeObject);
            }
            function getTypeByProduct(proObject) {
            productid = $(proObject).val();
                    var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').attr('id');
                    $('#' + typeId).parent().find("#loaderType").show();
                    $.ajax({
                    url: '<?php echo base_url() ?>interactions/get_type_by_product/' + productid,
                            type: 'POST',
                            dataType: 'JSON',
                            success: function (returnData) {
                            $('select#' + typeId + ' option').remove();
                                    $('select#' + typeId).append('<option value="">Select</option>');
                                    for (var result in returnData) {
//                  $('#objectiveTable select#' +typeId).append("<option  id='" + returnData[result].id + "' value='" + returnData[result].id + "'>" + returnData[result].name + "</option>");
                            $('#objectiveTable select#' + typeId).append($("<option></option>")
                                    .attr("value", returnData[result].id)
                                    .text(returnData[result].name));
                            }
                            $('#' + typeId).parent().find("#loaderType").hide();
                            }
                    });
                    return true;
	}
	
	function deleteRow(thisObj){
		$(thisObj).parent().parent().parent().remove();
		return false;
	}
	function toggleLocation(thisObj){
//		if($(thisObj).val()!=1){
//			$('#locationContainer').hide();
//		}else{
//			$('#locationContainer').show();
//		}
	}
	function restrictAttendees(thisObj){
		if($(thisObj).val()!=1){
			$('#addMoreKols').show();
			//$('#anttendies').removeAttr('readonly');
			//Hide non-profiled attendies if its one-on-one
			$("#nonProfiledkolsTable").show(); 
		}else{
			$('#addMoreKols').hide();
			//$('#anttendies').val('1').attr('readonly','readonly');
			$("#nonProfiledkolsTable").hide(); 
		}
	}
	 $(document).ready(function(){
		
		var groupingObj	= $('#grouping');
		var modeObj	= $('#mode');
		restrictAttendees(groupingObj);
		//toggleLocation(modeObj);
	 	$('.chosenSelect').chosen({allow_single_deselect: true});
	    $('.chosenMultipleSelect').chosen({
	    		no_results_text: "You can add new name from My Customers, Match not found in Non Profiled Attendees list for ",
				placeholder_text : "Click to Select Non Profiled Attendees",
				allow_single_deselect: true
	    });
	    $('table.tabularGrid caption div.collapseSlider').click(function (){
        	if($(this).attr('class')!="collapseSlider"){
        		$(this).parent().parent().find('tr').hide();
        		$(this).find('a').attr('data-original-title','Expand');
	        }else{
    	    	$(this).parent().parent().find('tr').show();
        		$(this).find('a').attr('data-original-title','Collapse');
        	}
	        $(this).toggleClass('expandSlider');
    	});
    });

	$(document).ready(function(){
				
		$("#nonProfiledkolsTable").hide(); 
		var searchedNames = {
				title: "Search Result",
				modal: true,
				autoOpen: false,
				width: 650,
				draggable:false,
				position: ['center', 80],
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#searchedNames").dialog(searchedNames);

		
	});	
	function getTerritory(){
		$(".searchedNamesContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#searchedNames").dialog("open");
		$.ajax({
			type: "post",
			dataType:"text",
			//data:data,
			url: '<?php echo base_url();?>interactions/search_territories/',
			success: function(returnData){
				$('#searchedNames .profileContent').unblock();
				$(".searchedNamesContent").html(returnData);
			}
		});
	}

	function saveLater(){
		$("#save_later").val(1);
		$("#saveInteraction").click();
	}
	function getStatesByCountryId(){
		// Show the Loading Image
		$("#loadingStates").show();
		$("#postal_code").parent().find("label.error").remove();
		var countryId=$('#country_id').val();
		var params = "country_id="+countryId;	
		$("#state_id").html("<option value=''>-- Select State --</option>");
		$("#city_id").html("<option value=''>-- Select City --</option>");
		var states = document.getElementById('state_id');
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {					
					var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);				
					});
				var lastOPtion = $('#state_id option:last').val();
				if(lastOPtion==''){
					$('#state_id option:last').remove();
					$('#state_id').prepend("<option value='' selected='selected'>-- Select State --</option>");
				}
				
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});		
	}
	function limitText(limitField, limitCount, limitNum) {
		if (limitField.value.length > limitNum) {
			limitField.value = limitField.value.substring(0, limitNum);
		} else {
			$('#'+limitCount).html(limitNum - limitField.value.length);
		}
	}


	function cancelAddInteractionAction(){
		<?php if($interactionFor == 'org') { ?>
			location.href = '<?php echo base_url()?>organizations/view_interactions/'+kolId+'/interaction';
		<?php }else {?>
			location.href = '<?php echo base_url()?>kols/view/'+kolId+'/interaction_report';
		<?php }?>
	}

	$("select").change(function() {
		var selectedId = $(this).attr('id');
		var toolTipVal = $('#'+selectedId+' :selected').text();
		$('#'+selectedId).attr('title',toolTipVal);
	});
	
</script>
<?php if($hideSidebar){ ?>
<script>
	$("#showHideSidebar").hide(); 	
	if (typeof showHideSidebar !== 'undefined') {
		showHideSidebar();
	}
</script>
<?php } ?>
<?php if(!$editInteraction){ ?>
<script>
	$("#date").datepicker().datepicker("setDate", new Date());
</script>
<?php } ?>
<?php if($interactionDetails['grouping'] == 2){?>
<script>
	$("#nonProfiledkolsTable").show(); 
</script>
<?php } ?>
<div class="interactionWrapper">
	<div class="msgBoxContainer">
		<div class="eventMsgBox"></div>
	</div>
	<div class="formHeader">
		<!--<button>Record Interaction</button>
-->
	</div>
	<div>

		<h5 class="heading"><?php if($editInteraction){echo $editInteraction;}else{echo 'Record New Interaction';}?></h5>
		<form action="<?php echo base_url();?>interactions/save_interaction"
			id="interactionForm" name="interactionForm" method="post"
			enctype="multipart/form-data"
			onsubmit="return validateAndSubmitInteractionForm();">
			<input type="hidden" name="is_from" value="kol" /> <input
				type="hidden" name="interaction_id"
				value="<?php if($interactionDetails!=null) echo $interactionDetails['id'];?>"
				id="interactionId"> <input type="hidden" name="calendar_event_id"
				value="<?php if($interactionDetails!=null) echo $interactionDetails['calendar_event_id'];?>"
				id="calendarEventId"> <input type="hidden" name="save_later"
				id="save_later" value="0" /> <input type="hidden"
				name="interaction_for" value="<?php echo $interactionFor;?>"
				id="interactionFor">
			<div>
				<table id="paymentTbl1" class="analystForm1 tabularGrid">
					<caption>
						<strong>Interaction Details : <?php if($interactionFor == 'org'){ echo $org_name; } ?></strong>
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<th class="alignRight"><label for="date">Interaction Date:<span
								class="required">*</span></label></th>
						<th class="alignRight"><label for=location_category>Interaction
								Location:<span class=""></span>
						</label></th>
						<th class="alignRight"><label for=location_category>Plan Name:<span
								class=""></span></label></th>

					</tr>
					<tr>


						<td><input type="text" name="date"
							value="<?php
							
$this->load->model ( 'common_helpers' );
							if ($interactionDetails != null && $interactionDetails ['date'] != '0000-00-00')
								echo $this->common_helpers->convertDateToMM_DD_YYYY ( $interactionDetails ['date'] );
							?>"
							id="date" class="required maxPastDateValidate"></input></td>
						<td><select name="location_category" id="location_category"
							data-toggle="tooltip" title="In Office">
                                    <?php
																																				foreach ( $locationType as $key => $value ) {
																																					$selected = '';
																																					if ($key == $interactionDetails ['location_category']) {
																																						echo '<option value="' . $key . '" selected="selected">' . $value . '</option>';
																																					} else {
																																						echo '<option value="' . $key . '">' . $value . '</option>';
																																					}
																																				}
																																				?> 
					</select></td>
						<td><select name="plan_name">
								<option value=''>Select Plan</option>
                                    <?php
																																				foreach ( $plans as $key => $value ) {
																																					$selected = '';
																																					if ($key == $plan_id) {
																																						echo '<option value="' . $key . '" selected="">' . $value . '</option>';
																																					} else {
																																						echo '<option value="' . $key . '">' . $value . '</option>';
																																					}
																																				}
																																				?> 
					</select></td>
					</tr>
					<tr>

						<th class="alignRight"><label for=mode>Interaction Type:<span
								class="required">*</span></label></th>
						<th class="alignRight"><label for="grouping">Interaction Category:<span
								class="required">*</span></label></th>
						<th class="alignRight"><label for=anttendies>Number of Attendees:<span
								class="required">*</span></label></th>
					</tr>
					<tr>

						<td><input type="hidden" name="reminder" value="1" id="reminder"></input>
							<select name="mode" id="mode" class="required"
							onchange="toggleLocation(this);" data-toggle="tooltip"
							title="Face to Face">
						<?php foreach($arrModes as $mode){ //if($mode['id'] == 2){ continue;}?>
							<option value="<?php echo $mode['id'];?>"
									<?php if($interactionDetails!=null) if($mode['id']==$interactionDetails['mode']) echo 'SELECTED';?>>
								<?php echo $mode['name'];?>
							</option>
						<?php }?>
					</select></td>
						<td><select name="grouping" id="grouping" class="required"
							onchange="restrictAttendees(this);" data-toggle="tooltip"
							title="One-on-One">
						<?php foreach($arrGroupings as $row){?>
							<option value="<?php echo $row['id'];?>"
									<?php if($interactionDetails!=null) if($row['id']==$interactionDetails['grouping']) echo 'SELECTED';?>>
								<?php echo $row['name'];?>
							</option>
						<?php }?>
					</select></td>
						<td><input type="text" name="total_attendies"
							value="<?php if($interactionDetails!=null){echo $interactionDetails['total_attendies'];}else{echo '1';}?>"
							id="anttendies" class="required number"></input></td>
					</tr>
				</table>
				<table id="objectiveTable" class="highlightHeadings tabularGrid">
					<caption>
						Discussion Topic
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<th class="alignCenter"><label for="product"><?php echo lang("Overview.Product");?><span
								class="required">*</span></label></th>
						<th class="alignCenter"><label for="objective">Discussion Type<span
								class="required">*</span></label></th>
						<th class="alignCenter"><label for=topic>Topic<span
								class="required">*</span></label></th>
						<th class="alignCenter">
							<!--<label for="subtopic">Sub Topic</label>-->
						</th>
						<th></th>
						<th>&nbsp;</th>
					</tr>
			<?php if($interactionDetails==''){	?>
			<input type="hidden" id="noOfObjectives" value="0"
						name="noOfObjectives"></input>
					<tr id="trobjective">
						<td class="alignCenter">
							<p>
								<span class="is_primary"
									style="display: inline-block; margin-left: -25px;">&nbsp;</span>
								<select name="product" id="product" class="required"
									onchange="resetDropDowns(this);" data-toggle="tooltip"
									title="Select">
									<option value="">Select</option>
								<?php foreach($arrProduct as $row){?>
									<option title="Tooltip" value="<?php echo $row['id'];?>"
										<?php if($interactionDetails!=null) if($row['id']==$interactionDetails['type_id']) echo 'SELECTED';?>>
										<?php echo $row['name'];?>
									</option>
								<?php }?>
							</select> <img id="loadingProduct"
									src="<?php echo base_url()?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p>
						</td>
						<td class="alignCenter">
							<p>
								<select name="objective" id="objective"
									onchange="getTopic(this)" class="required typeSelectBox"
									data-toggle="tooltip" title="Select">
									<option value="">Select</option>

								</select> <img id="loaderType"
									src="<?php echo base_url() ?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p>
						</td>
						<td class="alignCenter">
							<p>
								<select name="topic" id="new_topic" onchange="getSubTopic(this)"
									class="required" data-toggle="tooltip" title="Select">
									<option value="">Select</option>
								</select> <img id="loadingTopic"
									src="<?php echo base_url()?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p>
						</td>
						<!--<td class="alignCenter">
						<p>
							<select name="subtopic"  id="subtopic" >
								<option value="">Select</option>
 								<option value="1">Disease State</option> 
 								<option value="2">MML</option> 
 								<option value="3">Frameworks</option>	 
							</select>
							<img id="loadingSubTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td>
						<p></p>
					</td>-->
						<td class="TextAlignCenter"><label id="addMoreObjectives"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label></td>
					</tr>
			<?php }else{?>
				<input type="hidden" id="noOfObjectives"
						value="<?php echo $interactionDetails['noOfObjectives']?>"
						name="noOfObjectives"></input>
				<?php
				
$objectiveNo = '';
				foreach ( $arrDiscussion as $topicKey => $arrDiscussionData ) {
					
					?>
				<tr id="trobjective">
						<td class="alignCenter">
							<p>
							<?php if($objectiveNo == ''){?>
								<span class="is_primary"
									style="display: inline-block; margin-left: -25px;">&nbsp;</span>
							<?php }?>
							<select name="product<?php echo $objectiveNo?>"
									id="product<?php echo $objectiveNo?>"
									onchange="resetDropDowns(this)" class="required"
									data-toggle="tooltip" title="Select">
									<option value="">Select</option>	
								<?php foreach($arrDiscussionData['arrProducts'] as $product){?>
									<option value="<?php echo $product['id'];?>"
										<?php  if($product['id']==$arrDiscussionData['row']['product_id']) echo 'SELECTED';?>>
										<?php echo $product['name'];?>
									</option>
								<?php }?>
							</select> <img id="loadingProduct"
									src="<?php echo base_url()?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p>
						</td>
						<td><p>
								<select name="objective<?php echo $objectiveNo ?>"
									id="objective<?php echo $objectiveNo ?>"
									onchange="getTopic(this)" class="required typeSelectBox"
									data-toggle="tooltip" title="Select">
									<option value="">Select</option>	
								<?php  foreach($arrDiscussionData['arrTypes'] as $key=>$objective){?>
									<option value="<?php echo $objective['id'];?>"
										<?php if($objective['id']==$arrDiscussionData['row']['interaction_type']) echo 'SELECTED';?>>
										<?php echo $objective['name']?>
									</option>
								<?php }?>
							</select> <img id="loaderType"
									src="<?php echo base_url() ?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p></td>
						<td>
							<p>
								<select name="topic<?php echo $objectiveNo?>"
									id="new_topic<?php echo $objectiveNo?>"
									onchange="getSubTopic(this)" class="required"
									data-toggle="tooltip" title="Select">
									<option value="">Select</option>	
								<?php foreach($arrDiscussionData['arrTopics'] as $key=>$value){?>
									<option value="<?php echo $value['id'];?>"
										<?php  if($value['id']==$arrDiscussionData['row']['topic_id']) echo 'SELECTED';?>>
										<?php echo $value['name'];?>
									</option>
								<?php }?>
							</select> <img id="loadingTopic"
									src="<?php echo base_url()?>/images/ajax_loader_black.gif"
									style="display: none" />
							</p>
						</td>
						<td><p>
								<!--							<select style="width: 100px;" name="subtopic<?php echo $objectiveNo?>"  id="subtopic<?php echo $objectiveNo?>">
								<option value="">Select</option>
								<?php foreach($arrDiscussionData['arrSubTopics'] as $key=>$value){?>
									<option value="<?php echo $key;?>" <?php  if($key==($arrDiscussionData['row']['sub_topic_id'])) echo 'SELECTED';?>>
										<?php echo $value;?>
									</option>
								<?php }?>	
							</select>
							<img id="loadingSubTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>-->
							</p></td>
						<td>
							<p></p>
						</td>
						<td class="TextAlignCenter">
					<?php if($topicKey==0){?>
								<label id="addMoreObjectives"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label>
							<?php }else{?>
								<label id="deleteMoreObjectives"><img
								src="<?php echo base_url();?>images/delete_active.png"
								alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
						<?php }?>
					</td>
					</tr>
        <?php
					
$objectiveNo ++;
				}
			}
			?>
		</table>

				<table id="kolsTable" class="highlightHeadings tabularGrid">
					<caption>
						Attendees
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<th class="alignCenter"><label for="kolName">
					<?php if($interactionFor == 'org'){?>
						<?php echo lang("HCP");?> / Key People Name
					<?php }else{?>
						<?php echo lang("HCP");?> Name
					<?php }?>
					<span class="required">*</span>
						</label></th>
						<th class="alignCenter" style="display: none;"><label
							for=therapeuticArea>Status</label></th>
							<?php if($interactionFor == 'org'){?>
						<th class="alignCenter"><label for=attendee_note>Title</label></th>
					<?php }else{?>
						<th class="alignCenter"><label for=therapeuticArea>Specialty</label></th>
						<th class="alignCenter"><label for=attendee_note>Title</label></th>
					<?php }?>
						
						<th>&nbsp;</th>
					</tr>
			<?php if($interactionDetails==''){?>
			<input type="hidden" id="noOfKols" value="1" name="noOfKols"></input>
			<?php if($interactionFor == 'org'){?> <input type="hidden" id="orgWithinID" value="<?php echo $kolId;?>" name="org_within_id"></input> <?php }?>
					<tr id="kols">
						<td class="alignCenter">
							<p id="pkolName">
								<input type="hidden" name="kol_id" value="<?php echo $kolId;?>"
									id="kolId" class="test">
						<?php if($interactionFor == 'org'){?>
							<?php
					
/*foreach ( $arrKolDetails as $kolDetails ) {
						if ($kolDetails ['id'] == $kolId) {
							?>
									<input type="hidden" name="kol_name_auto"
									value="<?php echo $kolDetails['name'];?>" id="kolNameAuto"
									class="checkAboveInputValue"></input> <input type="hidden"
									name="kol_id_auto" value="<?php echo $kolId;?>" id="kolIdAuto"
									class="selectedKolId"></input> <input type="text"
									name="kol_name" value="<?php echo $kolDetails['name'];?>"
									id="kolName" readonly="readonly" class="required test1"></input>
								<img class="image"
									src="<?php echo base_url();?>images/microview_inactive.png"
									title="Organization Profile Snapshot" alt="profile"
									onclick="showMicroProfileOrg('<?php echo $kolId;?>')"></img>
									
								<?php
						
}
					}*/
							
					?>
						<input type="hidden" name="kol_id" value="" id="kolId" class="test">
						<input type="hidden" name="attendee_type1" value="" id="attendeeType1"></input>
						<input type="hidden" name="attendee_types1" value="" id="attendeeTypes1"></input>
						<input type="hidden" name="kol_name_auto1" value="" id="kolNameAuto1" class="checkAboveInputValue"></input>
						<input type="hidden" name="kol_id_auto1" value="" id="kolIdAuto1"  ></input>
						<input type="text" name="kol_name1" value="" id="kolName" class="required test1 autocompleteInputBox"></input>
						
						<?php }else{?>
							<?php
					
foreach ( $arrKolDetails as $kolDetails ) {
						if ($kolDetails ['id'] == $kolId) {
							?>
									<input type="hidden" name="kol_name_auto"
									value="<?php echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>"
									id="kolNameAuto" class="checkAboveInputValue"></input> <input
									type="hidden" name="kol_id_auto" value="<?php echo $kolId;?>"
									id="kolIdAuto" class="selectedKolId"></input> <input
									type="text" name="kol_name"
									value="<?php echo $this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);//echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>"
									id="kolName" readonly="readonly" class="required test1"></input>
								<img class="image"
									src="<?php echo base_url();?>images/microview_inactive.png"
									title="KOL Profile Snapshot" alt="profile"
									onclick="showMicroProfile('<?php echo $kolId;?>')"></img>
									
								<?php
						
}
					}
					?>
						<?php }?>
					</p>
						</td>
						<?php if($interactionFor == 'org'){?>
						<td class="alignCenter">
							<p>
								<input type="text" readonly="readonly" name="last_interaction"
									id="last_interaction" value="<?php echo $kolTitle;?>" />
							</p>
						</td>
						<?php }else {?>
						<td class="alignCenter" style="display: none;">
							<!-- <p>
						<select name="status" id="status">
							<option value="Invited">Invited</option>
							<option value="Accepted" SELECTED>Accepted</option>
							<option value="Declined">Declined</option>
							<option value="Attended">Attended</option>
							<option value="No Show">No Show</option>
							<option value="Cancelled Late">Cancelled Late</option>
							<option value="Closed">Closed</option>
						</select>
					</p> -->
						</td>
						<td class="alignCenter">
							<p>
								<input class="kolSpecialty" type="text" readonly="readonly"
									name="therapeutic_area" value="<?php echo $kolSpecialty1;?>" />
							</p>
						</td>
						<td class="alignCenter">
							<p>
								<input type="text" readonly="readonly" name="last_interaction"
									id="last_interaction" value="<?php echo $kolTitle;?>" />
							</p>
						</td>
						<?php }?>
						
						<!-- 
				<td>
					<p>
						<textarea name="attendee_note" id="attendee_note" style="height: 16px;"></textarea>
					</p>
				</td>
				 -->
						<td class="TextAlignLeft"><label id="addMoreKols"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label></td>
					</tr>
			<?php }else{?>
			<?php if($interactionFor != 'org'){?>
					<input type="hidden" id="noOfKols"
						value="<?php echo $interactionDetails['noOfKols']?>"
						name="noOfKols"></input>
						
						<?php } else { ?>
						<input type="hidden" id="noOfKols"
						value="<?php echo sizeOf ( $interactionDetails ['attendies']);?>"
						name="noOfKols"></input>
						<input type="hidden" id="orgWithinID" value="<?php echo $kolId1;?>" name="org_within_id"></input>
						<?php } ?>
    <?php
				$no = '';
				$noOrg = 1;
				$arr = array ();
				if($interactionFor != 'org'){
					if (sizeOf ( $interactionDetails ['attendies'] ) > 1) {
						foreach ( $interactionDetails ['attendies'] as $id => $value ) {
							if ($value ['kol_id'] == $kolId1) {
								$arr = $interactionDetails ['attendies'] [$id];
								unset ( $interactionDetails ['attendies'] [$id] );
								break;
							}
						}
						$interactionDetails ['attendies'] [] = $arr;
						$interactionDetails ['attendies'] = array_reverse ( $interactionDetails ['attendies'] );
					}
				}
				foreach ( $interactionDetails ['attendies'] as $key1 => $kols ) {
					?>
					<tr id="kols">
						<input type="hidden" name="kol_id" value="<?php echo $kolId1;?>"
							id="kolId" />
						<td class="alignCenter">
							<p id="kolName">
							<?php if($kols['org_id'] != null && $kols['org_id'] != '') {?>
								<?php //foreach($attendies as $orgDetails){?>
								
									<?php if ($kols['kol_id']!=''){?>
										<input type="hidden" name="kol_name_auto<?php echo $noOrg?>"
									value="<?php echo $kols['first_name'].' '.$kols['middle_name'].' '.$kols['last_name'];?>" id="kolNameAuto<?php echo $noOrg?>"
									class="checkAboveInputValue"></input>
									<input type="hidden" name="attendee_type<?php echo $noOrg?>" value="<?php echo $kols['attType'];?>" id="attendeeType<?php echo $noOrg?>"></input>
									<input type="hidden" name="attendee_types<?php echo $noOrg?>" value="<?php echo $kols['attType'];?>" id="attendeeTypes<?php echo $noOrg?>"></input>
									 <input type="hidden"
									name="kol_id_auto<?php echo $noOrg?>" value="<?php echo $kols['kol_id'];?>"
									id="kolIdAuto<?php echo $noOrg?>" class="selectedKolId"></input> <input
									type="text" name="kol_name<?php echo $noOrg?>"
									value="<?php echo $this->common_helpers->get_name_format($kols['first_name'],$kols['middle_name'],$kols['last_name']);?>" id="kolName<?php echo $noOrg?>"
									readonly="readonly" class="required test1"></input> 
									<!-- <img
									class="image"
									src="<?php echo base_url();?>images/microview_inactive.png"
									title="Organization Profile Snapshot" alt="profile"
									onclick="showMicroProfile('<?php echo $kols['kol_id'];?>')"></img> -->
									
									<?php }else{?>
										<input type="hidden" name="kol_name_auto<?php echo $no?>"
									value="<?php echo $kols['key_fn'].' '.$kols['key_mn'].' '.$kols['key_ln'];?>" id="kolNameAuto<?php echo $noOrg?>"
									class="checkAboveInputValue"></input> 
									<input type="hidden" name="attendee_type<?php echo $noOrg?>" value="<?php echo $kols['attType'];?>" id="attendeeType<?php echo $noOrg?>"></input>
									<input type="hidden" name="attendee_types<?php echo $noOrg?>" value="<?php echo $kols['attType'];?>" id="attendeeTypes<?php echo $noOrg?>"></input>
									<input type="hidden"
									name="kol_id_auto<?php echo $noOrg?>" value="<?php echo $kols['key_id'];?>"
									id="kolIdAuto<?php echo $noOrg?>" class="selectedKolId"></input> <input
									type="text" name="kol_name<?php echo $noOrg?>"
									value="<?php echo $this->common_helpers->get_name_format($kols['key_fn'],$kols['key_mn'],$kols['key_ln']);?>" id="kolName<?php echo $noOrg?>"
									readonly="readonly" class="required test1"></input> 
									<!-- <img
									class="image"
									src="<?php echo base_url();?>images/microview_inactive.png"
									title="Organization Profile Snapshot" alt="profile"
									onclick="showMicroProfileOrg('<?php echo $kols['org_id'];?>')"></img> -->
									<?php }?>
								<?php //}?>
							<?php }else{ ?>
								<?php   foreach($arrKolDetails as $kolDetails){?>
                                                                              
									<?php if ($kolDetails['id']==$kols['kol_id']){?>
										<input type="hidden" name="kol_name_auto<?php echo $no?>"
									value="<?php echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>"
									id="kolNameAuto<?php echo $no?>" class="checkAboveInputValue"></input>
								<input type="hidden" name="kol_id_auto<?php echo $no?>"
									value="<?php echo $kolDetails['id'];?>"
									id="kolIdAuto<?php echo $no?>" class="selectedKolId"></input> <input
									type="text" class="required test1"
									name="kol_name<?php echo $no?>"
									value="<?php echo $this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);//echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>"
									id="kolName<?php echo $no;?>"
									<?php if($key1==0) echo "readonly=''readonly";?>></input> <img
									class="image"
									src="<?php echo base_url();?>images/microview_inactive.png"
									title="KOL Profile Snapshot" alt="profile"
									onclick="showMicroProfile('<?php echo $kolDetails['id'];?>')"></img>
									<?php }?>
								<?php }?>
							<?php }?>
							</p>

						</td>
						<?php if($kols['org_id'] != null && $kols['org_id'] != '') {?>
						<?php }else {?>
						<td class="alignCenter" style="display: none;">
							<p>
								<select name="status<?php echo $no?>"
									id="status<?php echo $no?>" data-toggle="tooltip"
									title="Select">
									<option value="Invited"
										<?php
					
if ($kols ['status'] == "Invited") {
						echo 'SELECTED';
					}
					?>>Invited</option>
									<option value="Accepted"
										<?php
					
if ($kols ['status'] == "Accepted") {
						echo 'SELECTED';
					}
					?>>Accepted</option>
									<option value="Declined"
										<?php
					
if ($kols ['status'] == "Declined") {
						echo 'SELECTED';
					}
					?>>Declined</option>
									<option value="Attended"
										<?php
					
if ($kols ['status'] == "Attended") {
						echo 'SELECTED';
					}
					?>>Attended</option>
									<option value="No Show"
										<?php
					
if ($kols ['status'] == "No Show") {
						echo 'SELECTED';
					}
					?>>No Show</option>
									<option value="Cancelled Late"
										<?php
					
if ($kols ['status'] == "Cancelled Late") {
						echo 'SELECTED';
					}
					?>>Cancelled Late</option>
									<option value="Closed"
										<?php
					
if ($kols ['status'] == "Closed") {
						echo 'SELECTED';
					}
					?>>Closed</option>
								</select>
							</p>
						</td>
						<td class="alignCenter">
							<p>
								<input class="kolSpecialty" type="text" readonly="readonly"
									name="therapeutic_area"
									value="<?php echo $kols['specialty'];?>" />
							</p>
						</td>
						<?php }?>
						<?php if($kols['org_id'] != null && $kols['org_id'] != '') {?>
									<?php if ($kols['kol_id']!=''){?>
									<td class="alignCenter">
										<p>
											<input type="text" readonly="readonly" name="last_interaction"
												id="last_interaction" value="<?php echo $kols['title'];?>" />
										</p>
									</td>
								<?php }else{?>
									<td class="alignCenter">
										<p>
											<input type="text" readonly="readonly" name="last_interaction"
												id="last_interaction" value="<?php echo $kols['key_title'];?>" />
										</p>
									</td>
								<?php }?>
						<?php }else{?>
								<td class="alignCenter">
										<p>
											<input type="text" readonly="readonly" name="last_interaction"
												id="last_interaction" value="<?php echo $kols['title'];?>" />
										</p>
									</td>
						<?php }?>
						<td class="TextAlignLeft">
							<?php if($key1==0){?>
								<label id="addMoreKols"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label>
							<?php }else{?>
								<label id="deleteMoreKols"><img
								src="<?php echo base_url();?>images/delete_active.png"
								alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
							<?php }?>
						</td>
					</tr>
			<?php
					$no ++;
					$noOrg ++;
				}
			}
			?>
		</table>

				<table id="locationContainer" class="tabularGrid">
					<caption>
						Location
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<td style="padding: 0px;">
							<table class="highlightHeadings" id="locations">
								<tr>
									<th></th>
									<th>Location</th>
									<th>Address</th>
									<th>Country</th>
									<th>State</th>
									<th>City</th>
									
								</tr>
						<?php
						$isChecked = 0;
						if (isset ( $kolLocations )) {
							foreach ( $kolLocations as $key => $row ) {
								$selectedLocation = '';
								if ($interactionDetails ['location_type'] == $row ['id'] && $row ["location"] == 'Primary') {
									$selectedLocation = ' checked="checked"';
									$isChecked = 1;
								}
								if (! isset ( $interactionDetails ['location_type'] ) && $row ["location"] == 'Primary') {
									$selectedLocation = ' checked="checked"';
									$isChecked = 1;
								}
								?>
									<tr>
									<td><input type="radio" name="selectedLocation"
										value="<?php echo $row['id'];?>"
										<?php echo $selectedLocation;?> /></td>
										<?php
								echo '<td>' . $row ['location'] . '</td>';
								echo '<td>' . $row ['address'] . '</td>';
								echo '<td>' . $row ['country'] . '</td>';
								echo '<td>' . $row ['state'] . '</td>';
								echo '<td>' . $row ['city'] . '</td>';
							
								?>
									</tr>
                                <?php
							}
						}
						?>
					</table>
						</td>
					</tr>
					<tr>
						<td style="padding: 0px;">
					<?php
					$selectedLocation = '';
					if (! $isChecked) {
						if ($interactionDetails ['location_type'] == 0) {
							$selectedLocation = ' checked="checked"';
						}
					}
					?>
					<table>
								<caption style="background: #eee; line-height: 15px;">Other</caption>
								<tr>
									<td><input type="radio" name="selectedLocation" value="0"
										<?php echo $selectedLocation;?> /></td>
									<th class="alignRight"><label>Address1:</label></th>

									<td><input name="address1" type="text"
										value="<?php echo (isset($interactionDetails['address'])?$interactionDetails['address']:'');?>" /></td>
									<th class="alignRight"><label>Country:</label></th>
									<td>
										<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="" data-toggle="tooltip" title="Select">
											<option value="">-- Select Country --</option>
                                            <?php if ($interactionDetails['country_id'] == "") {
											         foreach ( $arrCountry as $country ) {?>
                                						<option value="<?php echo  $country['country_id']; ?>">
                                    				<?php echo  $country['country_name']; ?></option>
                                    			<?php }
										      } else {
											         foreach ( $arrCountry as $country ) {
												        $selected = '';
												        if ($country['country_id'] == $interactionDetails['country_id']) {
        													if ($interactionDetails['location_type'] == 0) {
        														echo '<option value="' . $country ['country_id'] . '" selected="selected">' . $country ['country_name'] . '</option>';
        													} else {
        														echo '<option value="' . $country ['country_id'] . '">' . $country ['country_name'] . '</option>';
        													}
        												} else {
        													echo '<option value="' . $country ['country_id'] . '">' . $country ['country_name'] . '</option>';
        												}
											         }?>                 
                                			<?php } ?>     				
										</select>
									</td>
								</tr>
								<tr>
									<td></td>
									<th class="alignRight"><label>Address2:</label></th>
									<td><input name="address2" type="text"
										value="<?php if($interactionDetails['location_type']==0 && isset($interactionDetails['address2'])){echo $interactionDetails['address2']; }//echo (isset($interactionDetails['address2'])?$interactionDetails['address2']:'');?>" /></td>
									<th class="alignRight"><label>State:</label></th>


									<td><select name="state" id="state_id"
										onchange="getCitiesByStateId();" data-toggle="tooltip"
										title="Select">
											<option value="">-- Select State --</option>
									<?php
									foreach ( $arrStates as $key => $row ) {
										$selected = '';
										if ($interactionDetails ['state_id'] == $row ['state_id']) {
											$selected = ' selected="selected"';
										}
										echo '<option value="' . $row ['state_id'] . '"' . $selected . '>' . $row ['state_name'] . '</option>';
									}
									?>
								</select> <img id="loadingStates"
										src="<?php echo base_url()?>/images/ajax_loader_black.gif"
										style="display: none" /></td>
								</tr>

								<tr>
									<td></td>
									<th class="alignRight"><label>Postal Code:</label></th>
									<td><input name="postal_code" type="text" id="postal_code"
										value="<?php echo (isset($interactionDetails['postal_code'])?$interactionDetails['postal_code']:'');?>" /></td>
									<th class="alignRight"><label>City:</label></th>
									<td><select name="city" id="city_id" data-toggle="tooltip"
										title="Select">
											<option value="">-- Select City --</option>
									<?php
									if (isset ( $arrCities )) {
										foreach ( $arrCities as $key => $row ) {
											$selected = '';
											if ($interactionDetails ['city_id'] == $row ['city_id']) {
												$selected = ' selected="selected"';
											}
											echo '<option value="' . $row ['city_id'] . '"' . $selected . '>' . $row ['city_name'] . '</option>';
										}
									}
									?>
								</select> <img id="loadingCities"
										src="<?php echo base_url()?>images/ajax_loader_black.gif"
										style="display: none" /></td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<?php if($interactionFor != 'org'){?>
				<table id="nonProfiledkolsTable"
					class="highlightHeadings tabularGrid">
					<caption>
						Non-Profiled Attendees
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<th class="alignCenter"><label for=therapeuticArea>Attendee Name</label></th>
						<th class="alignCenter"><label for=therapeuticArea>Specialty</label></th>
						<th class="alignCenter"><label for=therapeuticArea>Comments</label></th>
						<th>&nbsp;</th>
					</tr>
			<?php if(count($interactionDetails['otherAttendisData']) > 0){ ?>
				<input type="hidden" id="noOfNonProfiledKols"
						value="<?php echo count($interactionDetails['otherAttendisData']); ?>"
						name="noOfNonProfiledKols"></input>
			<?php
				$otherAttendisObj = '';
				foreach ( $interactionDetails ['otherAttendisData'] as $key1 => $otherAttendis ) {
					?>
				<tr id="nonProfiledKols">
						<td class="alignCenter"><input type="text"
							name="non_profiled_kol<?php echo $otherAttendisObj?>"
							id="non_profiled_kol<?php echo $otherAttendisObj?>"
							value="<?php echo $otherAttendis['name'];?>"></td>
						<td class="alignCenter"><select
							name="non_profifled_specialty<?php echo $otherAttendisObj?>"
							id="non_profifled_specialty<?php echo $otherAttendisObj?>"
							data-toggle="tooltip" title="Select">
								<option>Select Specialty</option>
							<?php foreach ($arrSpecialties as $key => $specialty){ ?>
                                            <option
									value="<?php echo $key; ?>"
									<?php
						
if ($otherAttendis ['specialty_id'] == $key) {
							echo "selected='selected'";
						}
						?>><?php echo $specialty; ?></option>
							<?php }?>
						</select></td>
						<td class="alignCenter"><textarea cols="" rows="2"
								name="non_profiled_comment<?php echo $otherAttendisObj?>"
								id="non_profiled_comment<?php echo $otherAttendisObj?>"><?php echo $otherAttendis['comments'];?>	</textarea>
						</td>
						<td class="TextAlignCenter">
						<?php if($key1==0){?>
							<label id="addMoreNonAttendeeKols"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label>
						<?php }else{?>
							<label id="deleteMoreNonAttendeeKols"><img
								src="<?php echo base_url();?>images/delete_active.png"
								alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
						<?php }?>
					</td>
					</tr>
                            <?php
					
$otherAttendisObj ++;
				}
			} else {
				?>
				<input type="hidden" id="noOfNonProfiledKols" value="0"
						name="noOfNonProfiledKols"></input>
					<tr id="nonProfiledKols">
						<td class="alignCenter"><input type="text" name="non_profiled_kol"
							id="non_profiled_kol"></td>
						<td class="alignCenter"><select name="non_profifled_specialty"
							id="non_profifled_specialty" data-toggle="tooltip" title="Select">
								<option>Select Specialty</option>
							<?php foreach ($arrSpecialties as $key => $specialty){ ?>
							<option value="<?php echo $key;?>"><?php echo $specialty;?></option>
							<?php }?>
						</select></td>
						<td class="alignCenter"><textarea cols="" rows="2"
								name="non_profiled_comment" id="non_profiled_comment"></textarea>
							<!--						<input type="text" name="non_profiled_comment" id="non_profiled_comment" >				-->
						</td>
						<td class="TextAlignCenter">
						<?php if($key1==0){?>
							<label id="addMoreNonAttendeeKols"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label>
						<?php }else{?>
							<label id="deleteMoreNonAttendeeKols"><img
								src="<?php echo base_url();?>images/delete_active.png"
								alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
						<?php }?>
					</td>
					</tr>
			<?php }?>
			<!-- 
			<tr>
				<td>
					<select class="chosenMultipleSelect" style="width: 50%;height:60px; display: none;" multiple="multiple"  name="users[]">
                <?php
																$userId = $this->session->userdata ['user_id'];
																if ($interactionDetails == '') {
																	
																	foreach ( $arrUsers as $key => $user ) {
																		if ($userId == $key) {
																			?>
										<option value="<?php echo $key;?>" selected="selected"><?php echo $user;?></option>
										
            <?php
																			unset ( $arrUsers [$key] );
																		}
																	}
																} else {
																	foreach ( $arrUsers as $key => $user ) {
																		foreach ( $internalUsers as $user1 ) {
																			?>
										
												<?php if($user1==$key){?>
														<option value="<?php echo $user1;?>"  selected="selected"><?php echo $user;?></option>
														<?php unset($arrUsers[$key])?>
											
											<?php
																			
}
																		}
																		?>
                                                                            
    <?php
																	
}
																}
																?>
									
									<?php foreach($arrUsers as $key=>$user){?>
											<option value="<?php echo $key;?>" ><?php echo $user;?></option>
											
									<?php }?>
						
					</select>
				</td>
			</tr>
			 -->
				</table>
			<?php }?>
				<table id="fileUploadContainer"
					class="highlightHeadings tabularGrid">
					<input type="hidden" name="no_of_files" id="noOfFiles" value="1" />
					<caption>
						Attach Document(s)
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<th class="alignCenter"><label for=docName1>Document Name</label></th>
						<th class="alignCenter"><label for=description1>Description</label></th>
						<th class="alignCenter"><label for=intRefFile1>File</label></th>
						<th>&nbsp;</th>
					</tr>
			<?php if(isset($arrDocs) && sizeof($arrDocs)>=1){?>
				<div id="docsList">
					<?php foreach($arrDocs as $doc){?>
					 	<tr id="doc<?php echo $doc['id'];?>">
							<td><span><a
									href="<?php echo base_url(); ?>interactions/download_doc/<?php echo $doc['id']; ?>"><?php
					
if ($doc ['name'] != '')
						echo $doc ['name'];
					else
						echo 'File' . $doc ['name'];
					?></a></span></td>
							<td><span><?php echo $doc['description'];?></span></td>
							<td class="TextAlignCenter"><a href="#"
								onclick="deleteDocument(<?php echo $doc['id'];?>);">remove</a></td>
						</tr>
					<?php }?>
				</div>
			<?php }?>
				<tr id="docContainer1">
						<td><input type="text" name="doc_name1" id="docName1" /></td>
						<td><input type="text" name="description1" id="description1" /></td>
						<td><input type="file" name="int_ref_file1" id="intRefFile1" /></td>
						<td class="TextAlignCenter"><label id="addMoreFile"><img
								src="<?php echo base_url();?>images/add_active.png" alt="Add"
								title="Add" /></label></td>
					</tr>
				</table>
				<table class="tabularGrid">
					<caption>
						Notes
						<div id="collapseExpandButton" class="expandSlider collapseSlider">
							<a onclick="return false;" href="#" class="tooltipLink"
								rel='tooltip' title="Collapse">&nbsp;</a>
						</div>
					</caption>
					<tr>
						<td>					
					<?php
					
$notes = '';
					$ncount = 200;
					if ($interactionDetails != null) {
						$notes = $interactionDetails ['notes'];
						$ncount = 200 - strlen ( $notes );
					}
					?>
					<textarea onKeyDown="limitText(this,'notesCountDown',200);"
								onKeyUp="limitText(this,'notesCountDown',200);" rows="2"
								cols="700" name="notes" id="notes"><?php  echo $notes;?></textarea>
							<div>
								You have <span id="notesCountDown"><?php echo $ncount;?></span>
								characters left. <font size="1">(Maximum characters: 200)</font>
							</div>
						</td>
					</tr>
				</table>
				<p style="float: right;">
					<label for="kolName">Recorded By:
<?php

if ($interactionDetails != null)
	echo $interactionDetails ['user_name'];
else
	echo $this->session->userdata ( 'user_full_name' );
?>
			</label>
				</p>
				<!-- 
		<div style="display: block; text-align: center; margin-left: 11%; padding-bottom: 10px; font-size: 14px;">
			<input type="checkbox" id="qualityInteraction" name="quality_interaction" value="1" <?php if($interactionDetails!=null && $interactionDetails['quality_interaction'] == 1) echo "checked='checked'";?>>
			<label for="qualityInteraction" style="color: #626262">Quality Interaction</label>
		</div>
		 -->
				<div class="formButtons">
					<input type="submit" name="saveInteraction" id="saveInteraction"
						value="<?php echo SUBMIT_BUTTON_LABEL?>" />
					<!-- <input type="button" name="saveLaterInteraction" id="saveLaterInteraction" onclick="saveLater();" value="Save For Later" /> -->
					<input type="button" name="cancelInteraction" value="Cancel"
						onclick="cancelAddInteractionAction();" />
				</div>
			</div>

		</form>
	</div>
</div>

<div id="micro" class="microProfileDialogBox">
	<div class="microViewProfile profileContent"></div>
</div>

<div id="searchedNames" class="microProfileDialogBox">
	<div class="searchedNamesContent profileContent"></div>
</div>
