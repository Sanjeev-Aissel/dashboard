<div class="panel panel-info">
	<div class="panel-heading align_center">
		intearaction details
	</div>
	<div class="panel-body">
	<div class="row alert alert-success" id="responseMessageOfSaveInteraction" role="alert" style="display:none"></div>
			<!-- -------------------------------------Interaction Details starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Interaction Details:</div>
			  <div class="panel-body no_padding">
				  <div class="row_padding">
				  	<div class="form-group row">
						<label class="col-sm-3 col-form-label">Interaction ID:</label>
						<div class="col-sm-3">
						<?php echo $interactionDetails['generic_id']?>
				    	</div>
				    	<label class="col-sm-3 col-form-label">Number of Attendees:</label>
						<div class="col-sm-3">
						<?php echo $interactionDetails['total_attendies'];?>
				    	</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label">Interaction Date:</label>
						<div class="col-sm-3">
						<?php echo sql_date_to_app_date($interactionDetails['date']); ?>
				    	</div>
				    	<label class="col-sm-3 col-form-label">Interaction Category:</label>
						<div class="col-sm-3">
						<?php if ($interactionDetails['group_name'] != "") echo $interactionDetails['group_name']; ?>
				    	</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label">Interaction Type:</label>
						<div class="col-sm-3">
						<?php echo $interactionDetails['mode_name']; ?>
				    	</div>
				    	<label class="col-sm-3 col-form-label">Interaction Location:</label>
						<div class="col-sm-3">
						<?php echo $interactionDetails['location_category_name']; ?>
				    	</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label">Plan Name:</label>
						<div class="col-sm-3">
						<?php foreach ($plans as $key => $value) {
								$selected	= '';
								if($key == $plan_id){
									echo $value;
								}
                            } ?>
				    	</div>
					</div>					
				  </div>
			  </div>
			</div>
			<!-- -------------------------------------Interaction Details ends------------------------------------------------------ -->
			<!-- -------------------------------------Discussion Topics ends------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Discussion Topic:</div>
			  <div class="panel-body">
				  	<div class="row">
					<div class="col-sm-12">
					<table class="table no_border" style="margin-bottom:0px;">
						<tr>
							<td width="5%"></td>
							<td width="20%">
								<label>Indication:</label>
							</td>
							<td width="20%">
								<label>Discussion Type:</label>
							</td>
							<td width="55%">
								<label>Topic:</label>
							</td>
						</tr>
						<?php foreach ($interactionDetails['aboutTopics']['objective_names'] as $key => $value) {?>
			            <tr>
			                <td>
			                    <?php if ($key == 0) { ?>
			                        <span class="is_primary">&nbsp;</span>
			                    <?php } else { ?>
			                        &nbsp;
			                    <?php } ?>
			                </td>
			                <td><?php echo $interactionDetails['aboutTopics']['product_names'][$key]; ?></td>
			                <td><?php echo $value; ?></td>
			                <td><?php echo $interactionDetails['aboutTopics']['topic_names'][$key]; ?></td>
			            </tr>
			            <?php } ?>
						</table>
			    	</div>
				</div>
			  </div>
			</div>
			<!-- -------------------------------------Discussion Topics ends------------------------------------------------------ -->
			<!-- -------------------------------------Attendees starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Attendees:</div>
			  <div class="panel-body ">
			    <table class="table no_border" style="margin-bottom:0px;">
			        <tr>
			            <th>
			                <?php if ($interactionDetails['is_org_interaction'])
			                    echo "Organization Name";
			                else
			                    echo "HCP Name" ?>
			            </th>
			            <th>Specialty</th>
			        </tr>
			        <?php  foreach ($interactionDetails['attendees']['kol_names'] as $key => $value) { ?>
			            <tr>
			                <td><?php echo $value;?></td>
			                <td><?php echo $interactionDetails['attendees']['specialties'][$key]; ?></td>
			            </tr>
		            <?php  }  ?>
			    </table> 
			  </div>
			</div>
			<!-- -------------------------------------Attendees ends------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Location:</div>
			  <div class="panel-body  no_padding">
			  <table class="table no_border" style="margin-bottom:0px;">
			  <tr>
                    <th width="20px">&nbsp;</th>	
                    <th>Location</th>
                    <th>Address</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>State</th>
                </tr>
                <tr>
                    <td width="20px">&nbsp;</td>	
                    <td><?php echo $interactionDetails['location']; ?></td>
                    <td><?php echo $interactionDetails['address'].' '.$interactionDetails['address2']; ?></td>
                    <td><?php if ($interactionDetails['country'] != "") echo $interactionDetails['country']; ?></td>
                    <td><?php if ($interactionDetails['city'] != "") echo $interactionDetails['city']; ?></td>
                    <td><?php if ($interactionDetails['state'] != "") echo $interactionDetails['state']; ?></td>
                </tr>
                </table>
			  </div>
			</div>
			<!-- -------------------------------------Non-Profiled Attendees starts------------------------------------------------------ -->
			 <?php if ($interactionDetails['group_name'] != 'One-on-One') { ?>
				<div class="panel panel-default">
				  <div class="panel-heading">Non-Profiled Attendees:</div>
				  <div class="panel-body  no_padding">
				  	<table class="table no_border" style="margin-bottom:0px;">
			            <tr>
			                 <th width="40px">&nbsp;</th>
			                <th>Name</th>
			                <th>Specialty</th>
			                <th>Comments</th>
			            </tr>
			            <?php foreach ($interactionDetails['other_attendees'] as $key => $row) { ?>
			                <tr>
			                    <td width="40px">&nbsp;</td>
			                    <td><?php echo $row['name']; ?></td>
			                    <td><?php echo $row['specialty']; ?></td>
			                    <td><?php  echo $row['comments']; ?></td>
			                </tr>
			                <?php } ?>
			        </table>
				  </div>
				</div>
	    <?php } ?>
			<!-- -------------------------------------Non-Profiled Attendees ends------------------------------------------------------ -->
			<!-- -------------------------------------Attach documents starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Document(s):</div>
			  <div class="panel-body">
			   <?php if (empty($docs)) {
			             echo 'Documents not added';
			         } else {?>
			         <table class="table no_border">
			         <tr>
						<th width="3%">&nbsp;</th>	
						<th width='30%'>Name</th>
						<th width='30%'>Description</th>
						<th width='30%'>Download</th>
			        </tr>
			        <?php 
				        foreach ($docs as $doc){
				        	$find_doc_extn = explode(".",$doc['doc_path']);
				        	echo "
			 					<tr>
						        	<td width='3%'>&nbsp;</td>	
									<td width='30%'>".$doc['name']."</td>
									<td width='30%'>".$doc['description']."</td>
									<td width='30%'><a href='".base_url()."/interactions/download_interaction_document/".$doc['doc_path']."'>".$doc['name'].'.'.$find_doc_extn[1]."</a></td>
						        </tr>
			 				";
				        }?>
				        </table>
			          <?php } ?>
			  </div>
			</div>
			<!-- -------------------------------------Attach documents Ends------------------------------------------------------ -->
			<!-- -------------------------------------Notes section starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Notes:</div>
			  <div class="panel-body">
		                <?php
		                if (empty($interactionDetails['notes'])) {
		                    echo 'Notes not added';
		                } else {
		                    echo $interactionDetails['notes'];
		                }
		                ?>
			  </div>
			</div>
		</form>
	</div>
</div>