<?php
/*
		$listLink = "#";
                if ($interactionFor == 'org'){
                    if (IS_IPAD_REQUEST) 
                         $uoqLink = base_url().IPAD_URL_SEGMENT . "/interactions/add_mirf/".$interactionId.'/'.$kolId."/org";
                    else
                        $uoqLink = base_url()."interactions/add_mirf/".$interactionId.'/'.$kolId."/org";
                }
                else{
                    if (IS_IPAD_REQUEST) 
                         $uoqLink = base_url().IPAD_URL_SEGMENT . "/interactions/add_mirf/".$interactionId.'/'.$kolId;
                    else
                        $uoqLink = base_url()."interactions/add_mirf/".$interactionId.'/'.$kolId;
                }
		if ($interactionFor == 'org'){
                if (IS_IPAD_REQUEST)
                    $listLink = IPAD_URL_SEGMENT . '/organizations/view_interactions/' . $kolId;
                else
                    $listLink = 'organizations/view_interactions/' . $kolId . '/interaction_report';
                } else {
                if (IS_IPAD_REQUEST) {
                    $listLink = IPAD_URL_SEGMENT . '/kols/interaction_report/' . $kolId;
                } else {
                    $listLink = 'kols/view/' . $kolId . '/interaction_report';
                }
            }
*/
?>
<!-- 
<div class="row">
<h3 style="text-align: center;" <?php   if (IS_IPAD_REQUEST){ ?> style="font-size:8px;" <?php }?>>
	<?php if(isset($isMirfUpdate) && $isMirfUpdate == true){?>
		Interaction sucessfully updated.
	<?php } else {?>
	    Interaction sucessfully submitted.
    <?php }?>
</h3>
	<div class="row">
		<div class="formButtons">
			<center>
			<a style="width: 160px; margin-right: 30px;" href="<?php echo base_url().$listLink;?>" class="btn btn-default  <?php   if (!IS_IPAD_REQUEST){ ?> blueButton <?php }?>">Back to Interactions</a>
			<a style="width: 130px" href="<?php echo $uoqLink;?>" class="btn btn-default  <?php   if (!IS_IPAD_REQUEST){ ?> blueButton <?php }?>">
				<?php if(isset($isMirfUpdate) && $isMirfUpdate == true){?>
					Edit UOQ
				<?php } else {?>
				    Add UOQ
			    <?php }?>
			</a>
			</center>
		</div>
	</div>
</div>
 -->
 
 <?php if (IS_IPAD_REQUEST){ 
	 if($interactionFor=='org'){?>
		 <script>
			location.href = '<?php echo base_url().IPAD_URL_SEGMENT?>/organizations/view_interactions/<?php echo $orgInteractionId?>';
		 </script>
	 <?php }else{?>
		 <script>
			location.href = '<?php echo base_url().IPAD_URL_SEGMENT?>/kols/interaction_report/<?php echo $kolId?>';
		 </script>
	 <?php }?>
 <?php }else{
 	if($interactionFor=='org'){?>
		 <script>
			location.href = '<?php echo base_url()?>organizations/view_interactions/<?php echo $orgInteractionId?>/interaction_report';
		 </script>
 <?php }else {?> 
 		 <script>
			location.href = '<?php echo base_url()?>kols/view/<?php echo $kolId?>/interaction_report/';
		 </script>
	 <?php } }?>
