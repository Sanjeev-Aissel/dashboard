<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>

<script type="text/javascript">
    var filters;
            var mainFilter = 0;
            var mainFilterId = '';
            var mainCateogry = '';
            if (!js_files_loaded){
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
    }
</script>
<style type="text/css">
    .hasDatepicker{
        width: 141px !important;
        margin-left: 36px !important;
    }
    .selectBoxMsl
    {
        width: 165px;
    }
    #timeLineSliderContainer {
        padding-left: 10px;
        padding-right: 8px;
    }
    #timeLineSlider{
        margin-right:10px;
    }
    #searchLeftBar li.category{
        border-top: 0px;
    }
    #searchLeftBar{
        /*	margin-top:-40px; */
    }
    <?php
    if (IS_IPAD_REQUEST == 1) {
        echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
    }
    ?>
    .chzn-container-multi .chzn-choices{
        padding-left: 0px !important;
    }
    .chzn-container{
        font-size: 12px;
    }
    .chzn-container-single .chzn-single{
        border-radius: 2px;
        height: 18px;
        padding: 0 0 0 5px;		
    }
    .chzn-container-single .chzn-single span{
        margin-top: -3px;
    }
    .chzn-container .chzn-results{
        padding-left: 0px !important;
        margin: 0px;
    }
    #profileType_chzn .chzn-single span{
        /*margin-top: 0px;*/
    }
    #savedFilterValue_chzn .chzn-drop .chzn-search input{
        border-radius: 2px;
    }
    .highlighted{
        background: #5A86B8 !important;
        color: white;
    }
    .chzn-container-single .chzn-search input{
        padding: 2px 20px 2px 4px;
    }
    .chzn-search li input[type="text"]{
        border-radius: 2px !important;
    }
    div.actionIcon{
        float: right;
    }
    .chzn-container-single .chzn-single div{
        top: -3px !important;
    }
    /*	.chzn-container .chzn-results li{
                    padding: 3px 4px !important;
                    line-height: 12px !important;
            }
    */
    .chzn-drop{
        min-width: 106px !important;
    }
    .ui-widget-content, #timeLineSliderContainer p, #yearRange {
        background: inherit;
    }
</style>
<?php
$arrfilterdata = $this->session->userdata('filterContent');
$selectedKolId = $arrfilterdata['selected_kol_id'];
if (!empty($selectedKolId) && $selectedKolId != 0) {
    foreach ($arrKolDetails as $key => $rowData) {
        if ($key == $selectedKolId) {
            $selectedKol[$key] = $rowData['name'];
        }
    }
} else {
    $selectedKol = $arrfilterdata['arrKolNames']; //$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
}
if ($arrfilterdata['profileType'] != '') {
    $profileType = $arrfilterdata['profileType'];
}
if ($arrfilterdata['savedFilterId'] != '') {
    $savedFilterId = $arrfilterdata['savedFilterId'];
}
if (!empty($arrfilterdata['arrSpecialities'])) {
    if (!is_array($arrfilterdata['arrSpecialities'])) {
        $arrfilterdata['arrSpecialities'] = explode(',', $arrfilterdata['arrSpecialities']);
    }
    $selectedSpecialty = $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
} else {
    $selectedSpecialty = array();
}
if (sizeof($arrfilterdata['arrCountries']) > 0) {
    if (!is_array($arrfilterdata['arrCountries'])) {
        $arrfilterdata['arrCountries'] = explode(',', $arrfilterdata['arrCountries']);
    }
    $selectedCountry = $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
} else {
    $selectedCountry = array();
}
//$selectedState		= $arrfilterdata['arrStates'];
if (!empty($arrfilterdata['arrStates'])) {
    if (!is_array($arrfilterdata['arrStates'])) {
        $arrfilterdata['arrStates'] = explode(',', $arrfilterdata['arrStates']);
    }
    $selectedState = $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
} else {
    $selectedState = array();
}
if (sizeof($arrfilterdata['arrListNames']) > 0) {
    if (!is_array($arrfilterdata['arrListNames'])) {
        $arrfilterdata['arrListNames'] = explode(',', $arrfilterdata['arrListNames']);
    }
    $CI = & get_instance();
    $CI->load->model("My_list_kol");
    //$selectedListName	= $arrfilterdata['arrListNames'];
    $selectedListName = $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
} else {
    $selectedListName = array();
}
?>
<script type="text/javascript">
    $(document).ready(function(){
    // Trigger the Autocompleter for 'education' field of  Event'
    a = $('#msl').autocomplete(MslNameAutoCompleteOptions);
//		// Trigger the Autocompleter for 'country' field of  Event'
            a = $('#product').autocomplete(productNameAutoCompleteOptions);
//
//		// Trigger the Autocompleter for 'country' field of  Event'
            a = $('#topic').autocomplete(topicNameAutoCompleteOptions);
//
//		a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
//
//		// Trigger the Autocompleter for 'list' field of  Event'
            a = $('#source').autocomplete(sourceNameAutoCompleteOptions);
            // Binding the function for slidechange event 
//		$( "#timeLineSlider" ).bind( "slidechange", filterChart);

    });
            $(document).ready(function (){
    $('#from').datepicker({
    dateFormat: 'yy-mm-dd',
            onSelect: function(date, instance) {
            filters += "&from=" + date;
                    filter();
            }
    });
            $('#to').datepicker({
    dateFormat: 'yy-mm-dd',
            onSelect: function(date, instance) {
            filters += "&to=" + date;
                    filter();
            }
    });
            //$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
//		$('#categoriesContainer input:checked').each(function (index){
//			$(this).parent().parent().css('background-color','#D3DFED');
//		});

//		$('#searchFiltersElements ul li table tr').click(function (){
//			if($('#'+$(this).attr('class')).attr('checked')=="checked"){
//				$(this).css('background-color','#ffffff');
//				$('#'+$(this).attr('class')).removeAttr('checked');
//				displaySelectedChart($('#'+$(this).attr('class')));
//			}else{
//				$(this).css('background-color','#D3DFED');
//				$('#'+$(this).attr('class')).attr('checked','checked');
//				displaySelectedChart($('#'+$(this).attr('class')));
//			}
//			
//		});
            initializeCustomToolTips();
    });
            var options, a;
            // Autocomplet Options for the 'role' field 
            var MslNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_msl_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.msl').html();
                            var selId = $(event).children('.msl').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#msl').val(selText);
                            $('#mslId').val(selId);
                            filter(this, 'msl');
                            $('#mslId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var productNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_product_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.products').html();
                            var selId = $(event).children('.products').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#product').val(selText);
                            $('#productId').val(selText);
                            filter(this, 'product');
                            $('#productId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var topicNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_topic_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var stateId = $(event).children('.topics').html();
                            var selText = $(event).children('.topics').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#topic').val(selText);
                            $('#topicId').val(selText);
                            filter(this, 'topics');
                            $('#topicId').val("");
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }
            };
            var kolNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var kolId = $(event).children('.id1').html();
                            //var selText = $(event).children('.kolName').html();
                            var selText = $(event).children('.kolName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#kolName').val(selText);
                            $('#kolIdForReport').val(kolId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var sourceNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>reports/get_suggestions_for_source_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.source').html();
                            var selId = $(event).children('.source').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#source').val(selText);
                            $('#sourceId').val(selText);
                            filter(this, 'source');
                            $('#sourceId').val("");
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            /*		
             $(document).ready(function(){
             
             // Trigger the Autocompleter for 'education' field of  Event'
             a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'country' field of  Event'
             a = $('#country').autocomplete(countryNameAutoCompleteOptions);
             
             a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'list' field of  Event'
             a = $('#listName').autocomplete(listNameAutoCompleteOptions);
             
             // Binding the function for slidechange event 
             $( "#timeLineSlider" ).bind( "slidechange", filterChart);
             
             });
             */
            //Initiallize the Timeline slider
<?php $date = date('Y'); ?>
    //	var minYear=<?php echo ($date - 35); ?>;
    var minYear =<?php echo ($date - 60); ?>;
            var maxYear =<?php echo $date; ?>;
            var startDate = '<?php
if (isset($startDate))
    echo $startDate;
else
    echo 0;
?>';
            var endDate = '<?php
if (isset($endDate))
    echo $endDate;
else
    echo 0;
?>';
            var rangeValue1 = minYear;
            var rangeValue2 = maxYear;
            if (startDate != null && startDate != 0)
            rangeValue1 = startDate;
            if (endDate != null && endDate != 0)
            rangeValue2 = endDate;
            /*			
             $(function() {
             $( "#timeLineSlider" ).slider({
             range: true,
             min: minYear,
             max: maxYear,
             values: [ rangeValue1, rangeValue2 ],
             step:1,
             slide: function( event, ui ) {
             $( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
             }
             });
             
             $( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
             });
             
             
             
             
             
             // Hide or Show the Category checkbox's 
             function toggleCategory(toggleFlag,thisEle){
             //	jAlert("Ds");
             if($(thisEle).parent().attr('id')=='categotySpecialty'){
             $('#specialtyCheckBox').slideToggle();	
             
             }else if($(thisEle).parent().attr('id')=='categotyCountry'){
             $('#countryCheckBox').slideToggle();	
             }else if($(thisEle).parent().attr('id')=='categotyLists'){
             
             $('#listCheckBox').slideToggle();
             }else{
             $('#kolsCheckBox').slideToggle();
             }
             
             }
             
             $(document).ready(function(){
             $('#kolName').css({color:"gray"});
             $('#specialty').css({color:"gray"});
             $('#country').css({color:"gray"});
             $('#listName').css({color:"gray"});
             
             
             $('#kolName').focus(function(){
             
             var name=$('#kolName').val();
             if(name=='Enter KOL Name'){
             $('#kolName').val(" ");
             }
             });
             
             $('#kolName').blur(function() {
             var name=$('#kolName').val();
             if(name==' '){
             $('#kolName').val('Enter KOL Name');
             }
             });
             
             $('#specialty').focus(function(){
             
             var name=$('#specialty').val();
             if(name=='Enter Specialty'){
             $('#specialty').val(" ");
             }
             });
             
             $('#specialty').blur(function() {
             var name=$('#specialty').val();
             if(name==' '){
             $('#specialty').val('Enter Specialty');
             }
             });
             
             $('#country').focus(function(){
             
             var name=$('#country').val();
             if(name=='Enter Country'){
             $('#country').val(" ");
             }
             });
             
             $('#country').blur(function() {
             var name=$('#country').val();
             if(name==' '){
             $('#kolName').val('Enter Country');
             }
             });
             
             $('#listName').focus(function(){
             
             var name=$('#listName').val();
             if(name=='Enter List Name'){
             $('#listName').val(" ");
             }
             });
             
             $('#listName').blur(function() {
             var name=$('#listName').val();
             if(name==' '){
             $('#listName').val('Enter List Name');
             }
             });
             });
             */
            if (js_files_loaded){

    // Hide or Show the Category checkbox's 
    function toggleCategory(toggleFlag, thisEle){
    //	jAlert("Ds");
    /*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
     $('#specialtyCheckBox').slideToggle();	
     
     }else if($(thisEle).parent().attr('id')=='categotyCountry'){
     $('#countryCheckBox').slideToggle();	
     }else if($(thisEle).parent().attr('id')=='categotyLists'){
     $('#listCheckBox').slideToggle();
     }else{
     $('#kolsCheckBox').slideToggle();
     }
     */
    $(thisEle).next().slideToggle('slow');
            $(thisEle).toggleClass('expanded');
            $(thisEle).toggleClass('collapsed');
    }



    $(document).ready(function(){
    $('#kolName').css({color:"gray"});
            $('#specialty').css({color:"gray"});
            $('#country').css({color:"gray"});
            $('#state').css({color:"gray"});
            $('#listName').css({color:"gray"});
            $('#kolName').focus(function(){

    //	var name=$('#kolName').val();
    //	if(name=='Enter KOL Name'){
    $('#kolName').val(" ");
            //	}
    });
            $('#kolName').blur(function() {
    //	var name=$('#kolName').val();
    //	if(name==' '){
    $('#kolName').val('Enter KOL Name');
            //	}
    });
            $('#specialty').focus(function(){

    //	var name=$('#specialty').val();
    //	if(name=='Enter Specialty'){
    $('#specialty').val(" ");
            //	}
    });
            $('#specialty').blur(function() {
    //	var name=$('#specialty').val();
    //	if(name==' '){
    $('#specialty').val('Enter Specialty');
            //	}
    });
            $('#country').focus(function(){

    //	var name=$('#country').val();
    //	if(name=='Enter Country'){
    $('#country').val(" ");
            //	}
    });
            $('#country').blur(function() {
    //	var name=$('#country').val();
    //	if(name==' '){
    $('#country').val('Enter Country');
            //	}
    });
            $('#state').focus(function(){

    //	var name=$('#state').val();
    //	if(name=='Enter State'){
    $('#state').val(" ");
            //	}
    });
            $('#state').blur(function() {
    //	var name=$('#state').val();
    //	if(name==' '){
    $('#state').val('Enter State');
            //	}
    });
            $('#listName').focus(function(){

    //	var name=$('#listName').val();
    //	if(name=='Enter List Name'){
    $('#listName').val(" ");
            //	}
    });
            $('#listName').blur(function() {
    //	var name=$('#listName').val();
    //	if(name==' '){
    $('#listName').val('Enter List Name');
            //	}
    });
    });
            /*
             $('#rightSideBarSliderShow').click(function() {
             $('#searchLeftBar').show(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
             });
             $("#rightSideBarSliderHide").show();
             $("#rightSideBarSliderShow").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             
             $('#rightSideBarSliderHide').click(function() {
             $('#searchLeftBar').hide(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
             $("#rightSideBarSliderShow").show(500);
             });
             $("#rightSideBarSliderHide").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             */
    }
    $(document).ready(function(){
//        alert();
//        $("#msl").click(function(){
//              alert("kjkj");
//       filter(this,'msl');
//    });

//	$("#savedFilterValue").chosen().change(function(){
//		activeCustmFilters(this);
//	});
//	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
//		displaySelectedChart(this);
//	});
//	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
//		if($("#savedFilterValue").val()){
//			activeCustmFilters($("#savedFilterValue").val());
//			return true;
//			}
////		doSearchFilter1(-1,this);
//		displaySelectedChart(this);
//	});
    });
            function filter(thisEle, category){
            filters = {};
                    mainCategory = category;
                    if (mainFilter == 0){
            mainFilterId = $(thisEle).children().val();
                    mainFilter = 1;
            }
            if ($(thisEle).children().attr('checked') == "checked"){

            if (mainFilterId == $(thisEle).children().val()){
            mainFilterId = '';
                    mainFilter = 1;
                    mainCategory = '';
            }

            $(thisEle).css('background-color', '#fff')
                    $(thisEle).children().removeAttr("checked");
            }
            else{
            $(thisEle).css('background-color', '#D3DFED')
                    $(thisEle).children().attr("checked", "checked");
            }
//           if($(thisEle).children().attr('checked') == "checked"){
//              $(thisEle).css('background-color', '#fff')
//               $(thisEle).children().removeAttr("checked");
//           }
//           else{
//              $(thisEle).css('background-color', '#D3DFED')
//                $(thisEle).children().attr("checked","checked");
//           }

            var data = $("form").serialize();
                    filters += data;
                    list_medical_insight_grid();
                    get_filter_content(category);
            }

    function get_filter_content(category){
//        alert(filters);

    $.ajax({
    url:base_url + "reports/medical_report_filter/" + category,
            type: "Post",
            dataType:'json',
            data:filters,
            async:false,
            success:function(returnData){
            if (returnData.noFilter)
                    category = '';
//                               alert(mainCategory);if (returnData.noFilter || mainCategory != "therp" ){
                    // if (returnData.noFilter || mainCategory != "therp"){

                    $("#therpData").empty();
                    // }
                    //    if (returnData.noFilter || mainCategory != "msl"){
                    $("#mslData").empty();
                    // }
                    //   if (returnData.noFilter || mainCategory != "agent"){
                    $("#agentData").empty();
                    // }
                    //  if (returnData.noFilter || mainCategory != "sphere"){
                    $("#sphereData").empty();
                    //  }
                    // if (returnData.noFilter || mainCategory != "source"){
                    $("#sourceData").empty();
                    //   }
                    //    if (returnData.noFilter || mainCategory != "product"){
                    $("#productData").empty();
                    //   }
//            if (returnData.noFilter || mainCategory != "topics"){
                    $("#topicData").empty();
//            }
                    mainCategory = '';
                    for (var result in returnData){
            if (returnData[result] != ''){
            for (var innerResult in returnData[result]){
            if (result == "therp"){

            var data = returnData[result][innerResult].split("_");
                    var state = data[0];
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    if (state == "true"){
            var htmlTherp;
                    htmlTherp += '<tr class="allTherpys" style="background-color:#D3DFED">';
                    htmlTherp += '<td onclick="filter(this,\'therp\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="thrp_name[]" checked="checked" id="mslName"  value="' + name + '"  "/>' + name + '</td>';
                    htmlTherp += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlTherp += '</tr>'; }
            else{
            htmlTherp += '<tr class="allTherpys">';
                    htmlTherp += '<td onclick="filter(this,\'therp\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="thrp_name[]"  id="mslName"  value="' + name + '"  "/>' + name + '</td>';
                    htmlTherp += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlTherp += '</tr>';
            }
            // alert(htmlTherp);
            }
            if (result == "msl"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1] + " " + data[2];
                    var id = data[3];
                    var count = data[4];
                    var htmlMsl;
                    if (state == "true"){
            htmlMsl += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlMsl += '<td onclick="filter(this,\'msl\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="msl[]" checked="checked" id="mslName"  value="' + id + '"  "/>' + name + '</td>';
                    htmlMsl += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlMsl += '</tr>'; }
            else{
            htmlMsl += '<tr class="allTherpys">';
                    htmlMsl += '<td onclick="filter(this,\'msl\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="msl[]"  id="mslName"  value="' + id + '"  "/>' + name + '</td>';
                    htmlMsl += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlMsl += '</tr>';
            }
            }
            if (result == "agent"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    var htmlStatus;
                    if (state == "true"){
            htmlStatus += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlStatus += '<td onclick="filter(this,\'agent\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="agent[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlStatus += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlStatus += '</tr>'; }
            else{
            htmlStatus += '<tr class="allTherpys">';
                    htmlStatus += '<td onclick="filter(this,\'agent\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="agent[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlStatus += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlStatus += '</tr>';
            }
            }
            if (result == "sphere"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    var htmlSphere;
                    if (state == "true"){
            htmlSphere += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlSphere += '<td onclick="filter(this,\'sphere\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="sphere_influencers[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlSphere += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlSphere += '</tr>'; }
            else{
            htmlSphere += '<tr class="allTherpys">';
                    htmlSphere += '<td onclick="filter(this,\'sphere\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="sphere_influencers[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlSphere += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlSphere += '</tr>';
            }
            }
            if (result == "source"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    var htmlSource;
                    if (state == "true"){
            htmlSource += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlSource += '<td onclick="filter(this,\'source\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="source_type[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlSource += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlSource += '</tr>'; }
            else{
            htmlSource += '<tr class="allTherpys">';
                    htmlSource += '<td onclick="filter(this,\'source\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="source_type[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlSource += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlSource += '</tr>';
            }
            }
            if (result == "product"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    var htmlProduct;
                    if (state == "true"){
            htmlProduct += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlProduct += '<td onclick="filter(this,\'product\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="product[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlProduct += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlProduct += '</tr>'; }
            else{
            htmlProduct += '<tr class="allTherpys">';
                    htmlProduct += '<td onclick="filter(this,\'product\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="product[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlProduct += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlProduct += '</tr>';
            }
            }
            if (result == "topics"){
            var data = returnData[result][innerResult].split("_");
                    var state = data[0]
                    var name = data[1];
                    var id = data[2];
                    var count = data[3];
                    var htmlTopic;
                    if (state == "true"){
            htmlTopic += '<tr class="allTherpys"  style="background-color:#D3DFED">';
                    htmlTopic += '<td onclick="filter(this,\'topics\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="topics[]" checked="checked" id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlTopic += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlTopic += '</tr>'; }
            else{
            htmlTopic += '<tr class="allTherpys">';
                    htmlTopic += '<td onclick="filter(this,\'topics\')" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="topics[]"  id=""  value="' + name + '"  "/>' + name + '</td>';
                    htmlTopic += '<td class="histoGram"><div class="filterBar"><div class="progress" title="100%"><div class="bar" style="width: ' + count + '%;"></div></div></div></td><td>' + count + '</td>';
                    htmlTopic += '</tr>';
            }
            }
            }
            }

            }
//                
            if (mainCategory != "therp"){


            $("#therpData").append(htmlTherp);
            }
            if (mainCategory != "msl"){

            $("#mslData").append(htmlMsl);
            }
            if (mainCategory != "agent"){

            $("#agentData").append(htmlStatus);
            }
            if (mainCategory != "sphere"){

            $("#sphereData").append(htmlSphere);
            }
            if (mainCategory != "source"){

            $("#sourceData").append(htmlSource);
            }
            if (mainCategory != "product"){

            $("#productData").append(htmlProduct);
            }
            if (mainCategory != "topics"){

            $("#topicData").append(htmlTopic);
            }

            }





    });
    }

    function resetFilters(){
    $.each($("input[type='checkbox']:checked"), function() {
    $(this).removeAttr('checked');
    });
            $.each($("input[type='text']"), function() {
            $(this).val('');
            });
            filter("", 'source');
    }
</script>


<div id="searchFiltersContainer">
    <div id="searchFiltersElements">

        <form action="<?php echo base_url() ?>kols/" name="searchFilterForm" method="post" id="searchFilterForm">
            <ul id="categoriesContainer">
                <!--							<li class="">
                                                                                <div>
                                                                                        <div class="assigned sprite_iconSet" id="assignedIcon"></div>
                                                                                        <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
                                                                                        <div style="">
                                                                                                <select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
                                                                                                        <option value="1" <?php if ($viewType == MY_RECORDS) echo 'selected="selected"'; ?>>My Contacts</option>
                                                                                                        <option value="2" <?php if ($viewType == ALL_RECORDS) echo 'selected="selected"'; ?>>All Contacts</option>
                                                                                                </select>
                                                                                        </div>
                                                                                </div>
                                                                        </li>
                                                                        <li id="customFilters" class="">
                                                                                <div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
                                                                                <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 5px;">Saved Filters </label>
                                                                                <div style="">
                                                                                        <select id="savedFilterValue" data-placeholder="Choose saved queries..." style="width:150px;" class="chosen-select">
                                                                                                <option></option>
                <?php foreach ($customFilters as $customFilter) { ?>
                                                                                                                    <option value='<?php echo $customFilter['id']; ?>' <?php
                    if ($savedFilterId == $customFilter['id']) {
                        echo 'selected="selected"';
                    }
                    ?> ><?php echo $customFilter['name']; ?></option>
<?php } ?>
                                                                                        </select>
                                                                                        <div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
                                                                                                <a data-original-title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
                                                                                        </div>
                                                                                </div>
                                                                        </li>
                                                                        <li class="">
                                                                                <div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
                                                                                <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">Profile Type </label>
                                                                                <div style="">
                                                                                        <select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
                                                                                                <option value="">All Profiles</option>
                                                                                                <option value="Full Profile" <?php if ($profileType == "Full Profile") echo "selected='selected'"; ?>>Full Profiles</option>
                                                                                                <option value="Basic Plus" <?php if ($profileType == "Basic Plus") echo "selected='selected'"; ?>>Basic+ Profiles</option>
                                                                                                <option value="Basic" <?php if ($profileType == "Basic") echo "selected='selected'"; ?>>Basic Profiles</option>
                                                                                        </select>
                                                                                </div>
                                                                        </li>-->
                <li id="categotyKols" class="category" style="display:none;">
                    <!--								<div class="kolName sprite_iconSet"></div><label class="categoryName">KOL Name</label>-->
                    <!--								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>-->
                    <div>
                        <table>
                            <?php
                            if (isset($selectedKol) && $selectedKol != null && $selectedKol != 0) {
                                foreach ($selectedKol as $k => $kol) {
                                    ?>
                                    <tr class="kol<?php echo str_replace(' ', '', $kol); ?>">
                                        <td class="textAlignRight">
                                            <input type="checkbox" name="kol_ids[]" class="kolElement hideCheckbox" id="kol<?php echo str_replace(' ', '', $kol); ?>" checked="checked" value="<?php echo $k; ?>" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $kol; ?>
                                        </td>
                                        <td class="histoGram"><div class="filterBar">
                                                <div class="progress" title="1(<?php echo round((1 / 1) * 100); ?>%)">
                                                    <div class="bar" style="width: <?php
                                                    if (isset($kol))
                                                        echo round((1 / 1) * 100);
                                                    else
                                                        echo 0;
                                                    ?>%;"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
                                            //	if($reportSection=='activity'){
                                            if (array_key_exists($kol, $arrKolDetails)) {
                                                if (isset($arrKolDetails[$kol]['count']))
                                                    echo '(' . $arrKolDetails[$kol]['count'] . ')';
                                            }
                                            else {
                                                if (isset($arrKolDetails[$kol]['count']))
                                                    echo '(' . '0' . ')';
                                            }
                                            //	}
                                            ?>
                                        </td>
                                    </tr>
    <?php
    }
}
?>
                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="kol_ids1" class="autocompleteInputBox" id="kolName" value="Enter KOL Name" title=""/>
                        <input type="hidden" id="kolIdForReport" value="<?php echo $selectedKolId; ?>" name="kol_id1"></input>
                    </div>
                </li>


                <li id="coaching" class="category">

                    <!--<div class="refineBySecialtyImage sprite_iconSet"></div><label class="categoryName">MSL Name</label>-->
                    <!--<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>-->


                    <div>
                        <div class="assigned sprite_iconSet" id="assignedIcon"></div>
                        <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">From Date </label>
                        <div style="">
                            <input type="text" name="from" id="from" value="<?php
                                   if (isset($mirfDetails[0]['date_of_request']))
                                       echo $mirfDetails[0]['date_of_request'];
                                   else
                                       echo '';
                                   ?>">
                        </div>
                    </div><br/>

                    <div>
                        <div class="assigned sprite_iconSet" id="assignedIcon"></div>
                        <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">To Date </label>
                        <div style="">
                            <input type="text" name="to" id="to" value="<?php
                                   if (isset($mirfDetails[0]['date_of_request']))
                                       echo $mirfDetails[0]['date_of_request'];
                                   else
                                       echo '';
                                   ?>">
                        </div>
                    </div><br/>


                </li>
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">MSL Name</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="mslData">

                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
                                       echo '';
                                   else
                                       echo "checked='checked'"
                                       ?> onclick="displaySelectedChart(this)"/>All Agent</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
                                        echo round(($mslCount / $mslCount) * 100);
                                    else
                                        echo 0;
                                   ?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $arrClientUsers['entry_count'];
                                   ?>
                                </td>
                            </tr>
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($arrClientUsers as $key => $row) {
//    pr($row);
    ?>

                                <tr class="allTherpys">
                                    <td onclick="filter(this, 'msl')"  class="textAlignRight">
                                        <input type="checkbox" name="msl[]" class="countryElement hideCheckbox" id="<?php echo $row['id']; ?>" value="<?php echo $row['id']; ?>" 

                                               />&nbsp;<?php echo $row['first_name'] . ' ' . $row['last_name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="100%">
                                                <div class="bar" style="width: <?php echo $row['entry_count']; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $row['entry_count']; ?> </td>
                                </tr>
<?php } ?>


                        </table>
                        <div class="filterSearchIcon"></div><input   type="text" name="msl_ids" class="autocompleteInputBox" id="msl"  title=""/><input type="hidden" name="automsl" id="mslId" value="" />
                    </div>
                </li> 
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Therapeutic Area</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="therpData">
                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
    echo '';
else
    echo "checked='checked'"
    ?> onclick="displaySelectedChart(this)"/>All Therapeutic Area</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
                                echo round(($mslCount / $mslCount) * 100);
                            else
                                echo 0;
?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $therapCount;
?>
                                </td>
                            </tr>

<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($arrSpecialties as $key => $row) {
    ?>

                                <tr class="allTherpys">
                                    <td onclick="filter(this, 'therp')"  class="textAlignRight">
                                        <input type="checkbox" name="thrp_name[]" class="countryElement hideCheckbox" id="<?php echo $row['id']; ?>" value="<?php echo $row['name']; ?>" 

                                               />&nbsp;<?php echo $row['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $row['num']; ?></td>
                                </tr>
<?php } ?>


                        </table>
                </li> 
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Investigational Agent</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="agentData">
                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
    echo '';
else
    echo "checked='checked'"
    ?> onclick="displaySelectedChart(this)"/>All Agent</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
    echo round(($mslCount / $mslCount) * 100);
else
    echo 0;
?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $agentCount;
?>
                                </td>
                            </tr>
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($investigationalAgent as $key => $val) {
    ?>

                                <tr class="allTherpys">
                                    <td onclick="filter(this, 'agent')" class="textAlignRight">
                                        <input type="checkbox" name="agent[]" class="countryElement hideCheckbox" id="<?php echo $val['id']; ?>" value="<?php echo $val['name']; ?>" 

                                               />&nbsp;<?php echo $val['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $val['num']; ?></td>
                                </tr>
<?php } ?>


                        </table>

                </li>
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Sphere of Influence</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="sphereData">
                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
    echo '';
else
    echo "checked='checked'"
    ?> onclick="displaySelectedChart(this)"/>All Sphere of Influence</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
    echo round(($mslCount / $mslCount) * 100);
else
    echo 0;
?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $sphereCount;
?>
                                </td>
                            </tr>
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($sphereOfInfluence as $key => $val) {
    ?>

                                <tr class="allTherpys">
                                    <td class="textAlignRight" onclick="filter(this, 'sphere')">
                                        <input type="checkbox" name="sphere_influencers[]" class="countryElement hideCheckbox" id="<?php echo $val['id']; ?>" value="<?php echo $val['name']; ?>" 

                                               />&nbsp;<?php echo $val['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $val['num']; ?></td>
                                </tr>
<?php } ?>


                        </table>

                </li> 
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Source Type</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="sourceData">
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($sourceType as $key => $val) {
    ?>

                                <tr class="allTherpys">
                                    <td class="textAlignRight" onclick="filter(this, 'source')">
                                        <input type="checkbox" name="source_type[]" class="countryElement hideCheckbox" id="<?php echo $val['id']; ?>" value="<?php echo $val['name']; ?>" 

                                               />&nbsp;<?php echo $val['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $val['num']; ?></td>
                                </tr>
                            <?php } ?>


                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="source_ids" class="autocompleteInputBox" id="source"  title=""/><input type="hidden" name="autosource" id="sourceId" value="" />
                    </div>
                </li> 
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Product</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="productData">
                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
                                echo '';
                            else
                                echo "checked='checked'"
                                ?> onclick="displaySelectedChart(this)"/>All Agent</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
                                echo round(($mslCount / $mslCount) * 100);
                            else
                                echo 0;
                            ?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $productCount;
                            ?>
                                </td>
                            </tr>
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($product as $key => $val) {
    ?>

                                <tr class="allTherpys">
                                    <td class="textAlignRight" onclick="filter(this, 'product')">
                                        <input type="checkbox" name="product[]" class="countryElement hideCheckbox" id="<?php echo $val['id']; ?>" value="<?php echo $val['name']; ?>" 

                                               />&nbsp;<?php echo $val['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $val['num']; ?></td>
                                </tr>
<?php } ?>


                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="product_ids" class="autocompleteInputBox" id="product"title=""/><input type="hidden" name="autoproduct" id="productId" value="" />
                    </div>
                </li> 
                <li id="categotyCountry" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Key Insight Topics</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div>
                        <table id="topicData">
                            <tr class="allCountries">
                                <td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  value="country" <?php if (isset($selectedCountry) && $selectedCountry != null && $selectedCountry != 0)
    echo '';
else
    echo "checked='checked'"
    ?> onclick="displaySelectedChart(this)"/>All Key Insight Topics</td>
                                <td class="histoGram">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $mslCount . "(" . round(($mslCount / $mslCount) * 100) . "%)"; ?>">
                                            <div class="bar" style="width: <?php if (isset($mslCount))
    echo round(($mslCount / $mslCount) * 100);
else
    echo 0;
?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $topicCount;
?>
                                </td>
                            </tr>
<?php
$i = 0;
//pr($selectedCountry);pr($arrCountries);
foreach ($keyInsightTopic as $key => $val) {
    ?>

                                <tr class="allTherpys">
                                    <td class="textAlignRight" onclick="filter(this, 'topics')">
                                        <input type="checkbox" name="topics[]" class="countryElement hideCheckbox" id="<?php echo $val['id']; ?>" value="<?php echo $val['name']; ?>" 

                                               />&nbsp;<?php echo $val['name']; ?>
                                    </td>
                                    <td class="histoGram">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $arrCountriesDetails['count'] . "(" . round(($arrCountriesDetails['count'] / $totalKolsCount) * 100) . "%)"; ?>">
                                                <div class="bar" style="width: <?php echo 100; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $val['num']; ?></td>
                                </tr>
<?php } ?>


                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="topic_ids" class="autocompleteInputBox" id="topic"  title=""/><input type="hidden" name="autotopic" id="topicId" value="" />
                    </div>
                </li>  

            </ul>
        </form>

    </div>
</div>
