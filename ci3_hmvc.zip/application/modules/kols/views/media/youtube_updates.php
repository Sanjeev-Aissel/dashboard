<?php
/**
 * Play lists
 * @author Yuvaraj M
 * @version 3.0
 * 
 */

?>

<style>
    .img-properties{
        width:100px;
        height:100px;
    }
    .img-container{
        float:left;
        padding-right: 11px;
    } 
    .contents{
       
        margin:10px;
            margin-top: -88px;
    }
    .overlay{
      
         margin-left: -89px;
    margin-top: 21px;
    padding-top: -4px;
    z-index: 100000;
    }
    
</style>
<?php foreach ($list['items'] as $values) { 
    
    $publishedOn = $values->snippet->publishedAt;
    $title = $values->snippet->title;
    $description = $values->snippet->description;
    $thumbnail = $values->snippet->thumbnails->default->url;
    $videoId = $values->snippet->resourceId->videoId;

?>
<div class="media-container">
    <div class="img-container">
        <img class="img-properties" src="<?php echo $thumbnail  ?>" /> 
    </div>
    
    <a target="_new" href="https://www.youtube.com/watch?v=<?php echo $videoId  ?>"> <img class="overlay"  src="<?php echo base_url()  ?>/images/youtube_play_icon.png" /></a>
   
    <div class="contents">
        <a  target="_new" href="https://www.youtube.com/watch?v=<?php echo $videoId  ?>"><?php echo $title ?></a><br/>
        
        <p><?php echo $description ?></p><br/>
        <span style="float:right;color:green">
            <?php echo  humanTiming(strtotime(changeDateFormat($publishedOn,DATE_ATOM,"Y-m-d h:m:s"))); ?>
        </span>
    </div>
</div><hr/><br/><br/>
   
<?php } ?>