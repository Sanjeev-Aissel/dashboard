<?php
/**
 *Clients Index/Home page
 *Created By: Ramesh B
 *Created On:11:33:36 AM
 */
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array('index/client_index');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!-- RSS Feeds CSS and JS -->

<style>
/*	#rssfeed_content{
		border:1px solid #1A5C76;
		border-top:5px solid #1A5C76;
		padding-left:10px;
	}
	
	#tabs1 a{
		display:block;
		width:100px;
		float:left;
		border:1px solid #D0CCC9;
		text-align: center;
		margin-right:5px;
		background-color: #EFEFEF;
		padding: 5px 0;
		text-decoration: none;
		margin-right:0px;
		cursor: pointer;
	}
	
	#tabs1 div.divider{
		display: inline;
		width: 3px;
		border: 0px;
		border-bottom: 1px solid #D0CCC9;
		display: block;
	    float: left;
	    height: 29px;
	}
	#tabs1 a.current{
		background-color: #FFFFFF;
		border-bottom:1px solid #FFFFFF;
		z-index: 100;
		color:#1A5C76;
		font-weight: bold;
	}
	#tabs1 div.lastRight{
		width: 188px;
	}

	#tabs1 div.firstRight{
		width: 20px;
	}
	#tabs1{
		padding-left:20px;
		z-index: 1;
		padding-bottom: 29px;
		border-bottom: 1px solid #D0CCC9;
		color:#898989;
		float: left;
		padding-bottom: 0px;
		border-bottom: 0px;
		padding-left:0px;
	}
	#rssfeed_content1 p{
		display: none;
	}
	#rssfeed_content1 ul{
		padding-left: 5px;
		list-style: none;
	}
	#rssfeed_content1 ul{
		list-style: none;
	}
	#rssfeed_content1{
		min-height: 300px;
	}
	
	.rssFeed{
		border:1px solid #D0CCC9;
		border-top:0px;
		padding-left:20px;
		padding-top: 10px;
	}
	#RSSFEED4 map img{
		display: none;
	}*/

.rssFeed{
    border: 1px solid #D0CCC9 !important;
    /* border-top: 0px; */
     padding-left: 0px !important; 
    padding-top: 10px;
    height: 413px !important;
    width: 1329px !important;
    overflow-y: scroll;
    overflow-x: hidden ;
}
#rssfeed_content1 p{
    display:block !important;
}
</style>
<div>
	<div class="indexLeftSide">
		<div id="summaryIcon"></div><div class="activityHeading"><label><?php echo lang('Home.Summary');?></label></div>		
		<div id="loadSummaryDetails">
			<img alt="loader" src="<?php echo base_url()?>images/ajax-loader-round.gif" style=" margin-left: 250px;margin-top: 58px;">
		</div>
	
	</div>
	<div class="indexRightSide">
		<div class="navLinkRecentActivity sprite_iconSet" style="margin-top: 0px;cursor: default;float:left;"></div><label style="float:left;"><?php echo lang('Home.RecentActivity') ?></label>
		<img alt="loader" src="<?php echo base_url()?>images/ajax-loader-round.gif" style=" margin-left: 158px;margin-top: 78px;">
	</div>
	<?php 
// 		$this->load->view('updates/recent_updates_home');
	?>
	</div>
	<!--  Start of RSS Feed Links -->
	<br />
<!--	<div id="tabs1">
		<div class="divider firstRight">&nbsp;</div>
		<a onclick="display_rssfeed_content('1');"><?php echo lang('Home.MedicalNews');?></a><div class="divider">&nbsp;</div>
		<a onclick="display_rssfeed_content('2');"><?php echo lang('Home.WorldPharma');?></a><div class="divider" >&nbsp;</div>
		<a onclick="display_rssfeed_content('4');"><?php echo lang('Home.BioSpace');?></a><div class="divider">&nbsp;</div>
		<a onclick="display_rssfeed_content('5');"><?php echo lang('Home.Pharmaceutical');?></a><div class="divider">&nbsp;</div>
		<a onclick="display_rssfeed_content('6');"><?php echo lang('Home.PharmaTimes');?></a><div class="divider">&nbsp;</div>
		<a onclick="display_rssfeed_content('7');"><?php echo lang('Home.PharmaTech');?></a><div class="divider">&nbsp;</div>
		<a onclick="display_rssfeed_content('8');"><?php echo lang('Home.AHAJournals');?></a><div class="divider lastRight">&nbsp;</div>
	</div>-->
	<div class="clear rssFeed">
		<div id="rssfeed_content1">
                   <?php  $this->load->view('media_inteligence/rss_feed_view', $data); ?>
		</div>
	</div>
</div>
<!--  End of RSS Feed Links -->