<script type="text/javascript">
$('.save_oioo').click(function () {	
        var id = $(this).attr('id');
           
        $.ajax({
            url: '<?php echo base_url() ?>user_settings/save_update_oioo_settings',
            type: 'post',
            dataType: 'json',
            data: $('#oioo_form_'+id).serialize(),
            beforeSend: function(){
    			$("#user_settings").attr("disabled", true);
            },
            success: function (returnData) {
            	jAlert('Opt-in Process Duration saved successfully');
            }
        });
        return false;
    });
 $(".number").keyup(function(){	
	 this.value = this.value.replace(/[^0-9\.]/g,'5');
});
 $(".number").focusout(function(){	
	 if(this.value==''){
		 this.value ='';
		 this.value = 5;
	 }
 });
function myFunction() {
	$("select option").removeAttr("selected", false);
	//$("#user_settings").click();
}
$("select").change(function(){
	if($(this).val()==1){
		$(this).css("background","lightgreen");
	}else{
		$(this).css("background","#f19b9b");
	}
});

</script>
<style>
.individualRegion {
    width: 190px;
    border: 1px solid #ccc;
    text-align: center;
    padding: 0px 0px 10px 0px;
    float: left;
    margin: 0px 10px 5px 10px;
}
.individualRegion  .tableCaption{
     border-bottom: 1px solid #ccc;
     margin-bottom: 5px;
     background: #e8ebef;
     padding: 5px;
     text-align: center;
}
</style>
<div class="msgBox"></div>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Opt-in Opt-out Settings</h3></div>
	</div>
</div>
<div>
    <?php foreach($region as $regionId=>$row){
        $optInOutData = $this->user_setting->getOptInOutByRegion($regionId);
        ?>    
    	<div class="individualRegion selected" id="NorthAmerica">
    	<form id="oioo_form_<?php echo $regionId;?>">
    		
    		<table style="margin-bottom: 0">
    			<caption class="tableCaption"><h6><?php echo $row['group_name'];?></h6></caption>
    		<?php if(!$optInOutData){?>	
    			<tr>
    				<td><label>Opt-in </label></td>
    				<td>
    					<select name="process" id="process_<?php echo $regionId;?>" style="background: #f19b9b;">
                			<option value="0">Not Required</option>
                		  	<option value="1">Required</option>	            
            			</select>
            		</td>
    			</tr>
    			<tr>
    				<td><label>Duration </label>	</td>
    				<td><input type="text" class="number" name="duration" id="duration_<?php echo $regionId;?>" value = "5" style="width: 35px;"/> Year(s)</td>
    			</tr>    		
    		<?php }else{ ?>
    			<tr>
    				<td><label>Opt-in </label></td>
    				<td>
    					<?php $bcolor = "lightgreen"; 
    					if($optInOutData['isEnabled']==0){
    					    $bcolor = "#f19b9b";
                        }?>
    					<select name="process" id="process_<?php echo $regionId;?>" style="background:<?php echo $bcolor?>">
                			<option value="0" <?php if($optInOutData['isEnabled']==0) echo "selected"?> >Not Required</option>
                		  	<option value="1" <?php if($optInOutData['isEnabled']==1) echo "selected"?> >Required</option>	            
            			</select>
            		</td>
    			</tr>
    			<tr>
    				<td><label>Duration </label>	</td>
    				<td><input class="number" type="text" name="duration" id="duration_<?php echo $regionId;?>" value="<?php echo $optInOutData['duration']?>" style="width: 35px;"/> Year(s)</td>
    			</tr>
    		<?php } ?>
    			<tr>
        			<td colspan="2" style="text-align: center;">
        				<input type="hidden" name="region" value="<?php echo $regionId;?>" />
    					<input type="button" value="Save" id=<?php echo $regionId;?>  class="btn btn-info save_oioo" />
    				</td>
    			</tr>
    		</table>
   		</form>	
    	</div>
    <?php } ?>				
	
</div>
