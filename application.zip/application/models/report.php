<?php

/**
 * Model class for report related methods
 * 
 * @package application.models	
 * @author Ramesh B
 * @since  3.1.2
 * @created: 21-10-11
 */
class Report extends Model {

    /**
     * constructor
     * @return unknown_type
     */
	function __construct()
    {
         parent::__construct();
        $this->load->model('kol');
        $this->load->model('common_helpers');
    }

    /**
     * Based on the parameters passed calculate the segmentation data and return
     * 
     * @author Ramesh B
     * @since 3.1.2
     * @param 
     * @return Array
     * @created 21-10-11 
     */
    function getSegmentationData($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsX, $affWeightX, $eventParamsX, $eventWeightX, $pubParamsX, $pubWeightX, $trialX, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds) {
        $arrSegmentationData = array();

//		if($arrSpecialities!='0' && $arrSpecialities!=''){
//			foreach($arrSpecialities as $key=>$value)
//			$arrSpecialityIds[]=$this->kol->getSpecialtyId($value);
//		}else{
//			$arrSpecialityIds=$arrSpecialities;
//		}
//		
//		if($arrCountries!='0' && $arrCountries!=''){
//			foreach($arrCountries as $key=>$value)
//			$arrCountriesIds[]=$this->country_helper->getConcountryId($value);
//		}else{
//			$arrCountriesIds=$arrCountries;
//		}
//		
//		if($arrKolNames!='0' && $arrKolNames!=''){
//			foreach($arrKolNames as $key=>$kolName){
//				//$kolName1=str_replace(" ","",$kolName);
//				$arrKolIds[]=$this->kol->getKolId($kolName);
//			}
//		}else{
//			$arrKolIds=$arrKolNames;
//		}
//		
//		if($arrListNames!=0 && $arrListNames!=''){
//			foreach($arrListNames as $key=>$value)
//			$arrListNamesIds[]=$this->my_list_kol->getListNameId($value);
//		}else{
//			$arrListNamesIds=$arrListNames;
//		}
        $arrSpecialityIds = $arrSpecialities;
        $arrCountriesIds = $arrCountries;
        $arrKolIds = $arrKolNames;
        $arrListNamesIds = $arrListNames;

        //Statrt: Calulate the count for X - Axis------------------------------------------------------------------------
        $arrKolsCountX = array();
        //check is there any affiliation is selected as a parameter, if yes then get there count and apply weightage and prepare count
        if ($affParamsX[0] != 0 || $affParamsX[1] != 0 || $affParamsX[2] != 0 || (sizeof($affParamsX) > 3 && $affParamsX[3] != null) || (sizeof($affParamsX) > 4 && $affParamsX[4] != null)) {
            $arrEngTypes = '';
            $arrOrgType = '';
            //If main Affiliation getegory is 'not' selected as a parameter, get the sub category parameters, and store them in a array
            if ($affParamsX[0] != 1) {
                if (sizeof($affParamsX) > 3 && $affParamsX[1] != 1)
                    $arrEngTypes = $affParamsX[3];
                if (sizeof($affParamsX) > 4 && $affParamsX[2] != 1)
                    $arrOrgType = $affParamsX[4];
            }
            //If main or sub Affiliation getegory is selected as a parameter
            if ($affParamsX[0] != 0 || $affParamsX[1] != 0 || $affParamsX[2] != 0) {
                $weight = $affWeightX[0];
                //If Sub Categories are selected as a parameter then combine the weightage of both, it is equevalent to selecting main category
                if ($affParamsX[1] != 0 || $affParamsX[2] != 0)
                    $weight = $affWeightX[1] + $affWeightX[2];
                //Get the count of affiliations for all the kols and apply weightages...	
                $arrAffsCountResultsX = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType, $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrAffsCountResultsX as $aff) {
                    if (array_key_exists($aff['kol_id'], $arrKolsCountX)) {
                        $count = ($weight * (int) $aff['count']) / 100;
                        $arrKolsCountX[$aff['kol_id']]['total_count'] = $arrKolsCountX[$aff['kol_id']]['total_count'] + $count;
                        $arrKolsCountX[$aff['kol_id']]['aff']['total_count'] = $arrKolsCountX[$aff['kol_id']]['aff']['total_count'] + $count;
                        $arrKolsCountX[$aff['kol_id']]['total_weight'] = $arrKolsCountX[$aff['kol_id']]['total_weight'] + $weight;
                        $arrKolsCountX[$aff['kol_id']]['aff']['total_weight'] = $arrKolsCountX[$aff['kol_id']]['aff']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $aff['count']) / 100;
                        $arrKolsCountX[$aff['kol_id']]['total_count'] = $count;
                        $arrKolsCountX[$aff['kol_id']]['aff']['total_count'] = $count;
                        $arrKolsCountX[$aff['kol_id']]['total_weight'] = $weight;
                        $arrKolsCountX[$aff['kol_id']]['aff']['total_weight'] = $weight;
                    }
                }
            } else {//If any of the sub category values are selected as parrmaters, do the followings
                if (sizeof($affParamsX) > 3 && $affParamsX[3] != '') {
                    //If Any Engagement Type is selected
                    //Get the count of affiliations for each kol for each selected parameter
                    $arrAffsCountResultsX = $this->kol->affTempRenameLater($arrEngTypes, 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                    //Apply the weightages and get the count and store it in a array, for each KOL
                    foreach ($arrAffsCountResultsX as $kolId => $arrEngCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrEngCounts as $engId => $engCount) {
                                $weight = $weight + $affWeightX[3][array_search($engId, $arrEngTypes)];
                                $count = $count + (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['eng'][$engId]['count'] = (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['eng'][$engId]['weight'] = $affWeightX[3][array_search($engId, $arrEngTypes)];
                            }
                            $arrKolsCountX[$kolId]['aff']['total_count'] = $arrKolsCountX[$kolId]['aff']['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                            $arrKolsCountX[$kolId]['aff']['total_weight'] = $arrKolsCountX[$kolId]['aff']['total_weight'] + $weight;
                        } else {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrEngCounts as $engId => $engCount) {
                                $weight = $weight + $affWeightX[3][array_search($engId, $arrEngTypes)];
                                $count = $count + (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['eng'][$engId]['count'] = (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['eng'][$engId]['weight'] = $affWeightX[3][array_search($engId, $arrEngTypes)];
                            }
                            $arrKolsCountX[$kolId]['aff']['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $weight;
                            $arrKolsCountX[$kolId]['aff']['total_weight'] = $weight;
                        }
                    }
                }
                //pr($arrKolsCountX);
                if (sizeof($affParamsX) > 4 && $affParamsX[4] != null) {
                    //If Any Org Type is selected
                    //Get the count of affiliations for each kol for each selected parameter
                    $arrAffsCountResultsX = $this->kol->affTempRenameLater(0, $arrOrgType, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                    //pr($arrAffsCountResultsX);
                    foreach ($arrAffsCountResultsX as $kolId => $arrOrgCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrOrgCounts as $orgId => $orgCount) {
                                $weight = $weight + $affWeightX[4][array_search($orgId, $arrOrgType)];
                                $count = $count + (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['org'][$orgId]['count'] = (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['org'][$orgId]['weight'] = $affWeightX[4][array_search($orgId, $arrOrgType)];
                            }
                            $arrKolsCountX[$kolId]['aff']['total_count'] = $arrKolsCountX[$kolId]['aff']['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                            $arrKolsCountX[$kolId]['aff']['total_weight'] = $arrKolsCountX[$kolId]['aff']['total_weight'] + $weight;
                        } else {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrOrgCounts as $orgId => $orgCount) {
                                $weight = $weight + $affWeightX[4][array_search($orgId, $arrOrgType)];
                                $count = $count + (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['org'][$orgId]['count'] = (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                                $arrKolsCountX[$kolId]['aff']['params']['org'][$orgId]['weight'] = $affWeightX[4][array_search($orgId, $arrOrgType)];
                            }
                            $arrKolsCountX[$kolId]['aff']['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $weight;
                            $arrKolsCountX[$kolId]['aff']['total_weight'] = $weight;
                        }
                    }
                }
            }
        }
        //pr($arrKolsCountX);

        if ($eventParamsX[0] != 0 || $eventParamsX[1] != 0 || $eventParamsX[2] != 0 || (sizeof($eventParamsX) > 3 && $eventParamsX[3] != null) || (sizeof($eventParamsX) > 4 && $eventParamsX[4] != null)) {
            $arrSessionTypes = 0;
            $arrRoles = 0;
            if ($eventParamsX[0] != 1) {
                if (sizeof($eventParamsX) > 3 && $eventParamsX[1] != 1)
                    $arrSessionTypes = $eventParamsX[3];
                if (sizeof($eventParamsX) > 4 && $eventParamsX[2] != 1)
                    $arrRoles = $eventParamsX[4];
            }
            //$arrEventsCountResultsX		= $this->kol->getEventsByParam($fromYear=1900,$toYear=2011,$arrKolIds=0,$arrSessionTypes,$arrRoles,$arrCountries=0,$arrSpecialties=0,$groupBy='kolId');

            if ($eventParamsX[0] != 0 || $eventParamsX[1] != 0 || $eventParamsX[2] != 0) {
                $weight = $eventWeightX[0];
                if ($eventParamsX[1] != 0 || $eventParamsX[2] != 0)
                    $weight = $eventWeightX[1] + $eventWeightX[2];


                $arrEventsCountResultsX = $this->kol->getEventsByParam($fromYear, $toYear, $arrKolIds, $arrSessionTypes, $arrRoles, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrEventsCountResultsX as $event) {
                    if (array_key_exists($event['kol_id'], $arrKolsCountX)) {
                        $count = ($weight * (int) $event['count']) / 100;
                        $arrKolsCountX[$event['kol_id']]['total_count'] = $arrKolsCountX[$event['kol_id']]['total_count'] + $count;
                        $arrKolsCountX[$event['kol_id']]['event']['total_count'] = $arrKolsCountX[$event['kol_id']]['event']['total_count'] + $count;
                        $arrKolsCountX[$event['kol_id']]['total_weight'] = $arrKolsCountX[$event['kol_id']]['total_weight'] + $weight;
                        $arrKolsCountX[$event['kol_id']]['event']['total_weight'] = $arrKolsCountX[$event['kol_id']]['event']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $event['count']) / 100;
                        $arrKolsCountX[$event['kol_id']]['total_count'] = $count;
                        $arrKolsCountX[$event['kol_id']]['event']['total_count'] = $count;
                        $arrKolsCountX[$event['kol_id']]['total_weight'] = $weight;
                        $arrKolsCountX[$event['kol_id']]['event']['total_weight'] = $weight;
                    }
                }
            } else {
                if (sizeof($eventParamsX) > 3 && $eventParamsX[3] != '') {
                    $arrEventsCountResultsX = $this->kol->eventTempRenameLater($arrSessionTypes, 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                    //pr($arrEventsCountResultsX);
                    foreach ($arrEventsCountResultsX as $kolId => $arrSesCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrSesCounts as $sesId => $sesCount) {
                                $weight = $weight + $eventWeightX[3][array_search($sesId, $arrSessionTypes)];
                                $count = $count + (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['session'][$sesId]['count'] = (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['session'][$sesId]['weight'] = $eventWeightX[3][array_search($sesId, $arrSessionTypes)];
                            }
                            $arrKolsCountX[$kolId]['event']['total_count'] = $arrKolsCountX[$kolId]['event']['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                            $arrKolsCountX[$kolId]['event']['total_weight'] = $arrKolsCountX[$kolId]['event']['total_weight'] + $weight;
                        } else {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrSesCounts as $sesId => $sesCount) {
                                $weight = $weight + $eventWeightX[3][array_search($sesId, $arrSessionTypes)];
                                $count = $count + (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['session'][$sesId]['count'] = (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['session'][$sesId]['weight'] = $eventWeightX[3][array_search($sesId, $arrSessionTypes)];
                            }
                            $arrKolsCountX[$kolId]['event']['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $weight;
                            $arrKolsCountX[$kolId]['event']['total_weight'] = $weight;
                        }
                    }
                }
                //pr($arrKolsCountX);
                if (sizeof($eventParamsX) > 4 && $eventParamsX[4] != null) {
                    $arrEventsCountResultsX = $this->kol->eventTempRenameLater(0, $arrRoles, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                    //pr($arrAffsCountResultsX);
                    foreach ($arrEventsCountResultsX as $kolId => $arrRolCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrRolCounts as $rolId => $rolCount) {
                                $weight = $weight + $eventWeightX[4][array_search($rolId, $arrRoles)];
                                $count = $count + (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['role'][$rolId]['count'] = (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['role'][$rolId]['weight'] = $eventWeightX[4][array_search($rolId, $arrRoles)];
                            }
                            $arrKolsCountX[$kolId]['event']['total_count'] = $arrKolsCountX[$kolId]['event']['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                            $arrKolsCountX[$kolId]['event']['total_weight'] = $arrKolsCountX[$kolId]['event']['total_weight'] + $weight;
                        } else {
                            $count = 0;
                            $weight = 0;
                            foreach ($arrRolCounts as $rolId => $rolCount) {
                                $weight = $weight + $eventWeightX[4][array_search($rolId, $arrRoles)];
                                $count = $count + (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['role'][$rolId]['count'] = (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                                $arrKolsCountX[$kolId]['event']['params']['role'][$rolId]['weight'] = $eventWeightX[4][array_search($rolId, $arrRoles)];
                            }
                            $arrKolsCountX[$kolId]['event']['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_count'] = $count;
                            $arrKolsCountX[$kolId]['total_weight'] = $weight;
                            $arrKolsCountX[$kolId]['event']['total_weight'] = $weight;
                        }
                    }
                }
            }
        }

        if ($pubParamsX[0] != 0) {
            $weight = $pubWeightX[0];
            $arrPubCounts = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limt =0,$profileType, $viewMyKols, $arrGlobalRegionIds);
            foreach ($arrPubCounts as $pub) {
                if (array_key_exists($pub['kol_id'], $arrKolsCountX)) {
                    $count = ($weight * (int) $pub['count']) / 100;
                    $arrKolsCountX[$pub['kol_id']]['total_count'] = $arrKolsCountX[$pub['kol_id']]['total_count'] + $count;
                    $arrKolsCountX[$pub['kol_id']]['pub']['total_count'] = $arrKolsCountX[$pub['kol_id']]['pub']['total_count'] + $count;
                    $arrKolsCountX[$pub['kol_id']]['total_weight'] = $arrKolsCountX[$pub['kol_id']]['total_weight'] + $weight;
                    $arrKolsCountX[$pub['kol_id']]['pub']['total_weight'] = $arrKolsCountX[$pub['kol_id']]['pub']['total_weight'] + $weight;
                } else {
                    $count = ($weight * (int) $pub['count']) / 100;
                    $arrKolsCountX[$pub['kol_id']]['total_count'] = $count;
                    $arrKolsCountX[$pub['kol_id']]['pub']['total_count'] = $count;
                    $arrKolsCountX[$pub['kol_id']]['total_weight'] = $weight;
                    $arrKolsCountX[$pub['kol_id']]['pub']['total_weight'] = $weight;
                }
            }
        } else if (sizeof($pubParamsX > 1 && $pubParamsX[1] != null)) {
            if ($pubWeightX[1][1] != 0) {
                $weight = $pubWeightX[1][1];
                $arrPubCounts = $this->getFirstAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $arrKolsCountX[$kolId]['pub']['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['params']['first']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['first']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $arrKolsCountX[$kolId]['pub']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['first']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['first']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $weight;
                    }
                }
            }
            if ($pubWeightX[1][2] != 0) {
                $weight = $pubWeightX[1][2];
                $arrPubCounts = $this->getSingleAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $arrKolsCountX[$kolId]['pub']['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['params']['single']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['single']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $arrKolsCountX[$kolId]['pub']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['single']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['single']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $weight;
                    }
                }
            }
            if ($pubWeightX[1][3] != 0) {
                $weight = $pubWeightX[1][3];
                $arrPubCounts = $this->getMiddleAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $arrKolsCountX[$kolId]['pub']['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['params']['middle']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['middle']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $arrKolsCountX[$kolId]['pub']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['middle']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['middle']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $weight;
                    }
                }
            }
            if ($pubWeightX[1][4] != 0) {
                $weight = $pubWeightX[1][4];
                $arrPubCounts = $this->getLastAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $arrKolsCountX[$kolId]['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $arrKolsCountX[$kolId]['pub']['total_count'] + $count;
                        $arrKolsCountX[$kolId]['pub']['params']['last']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['last']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $arrKolsCountX[$kolId]['total_weight'] + $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $arrKolsCountX[$kolId]['pub']['total_weight'] + $weight;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId]['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['total_count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['last']['count'] = $count;
                        $arrKolsCountX[$kolId]['pub']['params']['last']['weight'] = $weight;
                        $arrKolsCountX[$kolId]['total_weight'] = $weight;
                        $arrKolsCountX[$kolId]['pub']['total_weight'] = $weight;
                    }
                }
            }
        }

        //pr($arrKolsCountX);
        if ($trialX != null && $trialX != '' && $trialX != 0) {
            $arrTrialsCountResultsX = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds, $profileType, $viewMyKols, $arrGlobalRegionIds);
            foreach ($arrTrialsCountResultsX as $trial) {
                if (array_key_exists($trial['kol_id'], $arrKolsCountX)) {
                    $count = ($trial['count'] * $trialX) / 100;
                    $arrKolsCountX[$trial['kol_id']]['total_count'] = $arrKolsCountX[$trial['kol_id']]['total_count'] + $count;
                    $arrKolsCountX[$trial['kol_id']]['total_weight'] = $arrKolsCountX[$trial['kol_id']]['total_weight'] + $trialX;
                    $arrKolsCountX[$trial['kol_id']]['trial']['total_count'] = $count;
                    $arrKolsCountX[$trial['kol_id']]['trial']['total_weight'] = $trialX;
                } else {
                    $count = ($trial['count'] * $trialX) / 100;
                    $arrKolsCountX[$trial['kol_id']]['total_count'] = $count;
                    $arrKolsCountX[$trial['kol_id']]['total_weight'] = $trialX;
                    $arrKolsCountX[$trial['kol_id']]['trial']['total_count'] = $count;
                    $arrKolsCountX[$trial['kol_id']]['trial']['total_weight'] = $trialX;
                }
            }
        }

        //pr($arrKolsCountX);
        return $arrKolsCountX;
    }

    /**
     * Prepares KolId NameCombinations for given array of KOL ids
     * @author 	Ramesh B
     * @Created on: 16-02-11
     * @since	
     * @return Array
     */
    function prepareKolIdNameCombinations($arrTopKols, $arrKolDetails) {
        $arrSalutations = array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $arrKolIdName = array();
        $arrTopKolNames = array();

        foreach ($arrKolDetails as $kolDetail) {
            //$arrKolIdName[$kolDetail['id']]= $kolDetail['last_name']." ".$kolDetail['middle_name']." ".$kolDetail['first_name'];
//			$arrKolIdName[$kolDetail['id']]= $arrSalutations[$kolDetail['salutation']].' '.$kolDetail[FIRST_ORDER].' '.$kolDetail[SECOND_ORDER].' '.$kolDetail[THIRD_ORDER];
            $arrKolIdName[$kolDetail['id']] = $arrSalutations[$kolDetail['salutation']] . ' ' . $this->common_helpers->get_name_format($kolDetail['first_name'], $kolDetail['middle_name'], $kolDetail['last_name']);
        }

        foreach ($arrTopKols as $kolId) {
            if (array_key_exists($kolId, $arrKolIdName)) {
                $arrTopKolNames[$kolId] = $arrKolIdName[$kolId];
            }
        }
        return $arrTopKolNames;
    }

    function getFirstAuthPubsCount($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialties = 0, $arrListNamesIds = 0, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrKolsPubCount = array();
        $arrFirstAuthPubs = $this->pubmed->getKolPubsWithFirstAuthorship($kolId = 0, $fromYear, $toYear, $arrKolIds, $arrCountries, $arrSpecialties, $arrListNamesIds, '', $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        foreach ($arrFirstAuthPubs as $authPub) {
            if (array_key_exists($authPub['kol_id'], $arrKolsPubCount))
                $arrKolsPubCount[$authPub['kol_id']] = $arrKolsPubCount[$authPub['kol_id']] + 1;
            else
                $arrKolsPubCount[$authPub['kol_id']] = 1;
        }
        if (sizeof($arrKolsPubCount > 1))
            return $arrKolsPubCount;
    }

    function getSingleAuthPubsCount($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialties = 0, $arrListNamesIds, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {

        $arrKolsPubCount = array();
        $arrSingleAuthPubs = $this->pubmed->getKolPubsWithSingleAuthor($kolId = 0, $fromYear, $toYear, $arrKolIds, $arrCountries, $arrSpecialties, $arrListNamesIds, '', $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        foreach ($arrSingleAuthPubs as $authPub) {
            if (array_key_exists($authPub['kol_id'], $arrKolsPubCount))
                $arrKolsPubCount[$authPub['kol_id']] = $arrKolsPubCount[$authPub['kol_id']] + 1;
            else
                $arrKolsPubCount[$authPub['kol_id']] = 1;
        }
        if (sizeof($arrKolsPubCount > 1))
            return $arrKolsPubCount;
    }

    function getMiddleAuthPubsCount($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialties = 0, $arrListNamesIds = 0, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrKolsPubCount = array();
        $arrMiddleAuthPubs = $this->pubmed->getKolPubsWithMiddleAuthorship($kolId = 0, $fromYear, $toYear, $arrKolIds, $arrCountries, $arrSpecialties, $arrListNamesIds, '', $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        foreach ($arrMiddleAuthPubs as $authPub) {
            if ($authPub['auth_pos'] != $authPub['max_pos']) {
                if (array_key_exists($authPub['kol_id'], $arrKolsPubCount))
                    $arrKolsPubCount[$authPub['kol_id']] = $arrKolsPubCount[$authPub['kol_id']] + 1;
                else
                    $arrKolsPubCount[$authPub['kol_id']] = 1;
            }
        }
        if (sizeof($arrKolsPubCount > 1))
            return $arrKolsPubCount;
    }

    function getLastAuthPubsCount($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialties = 0, $arrListNamesIds = 0, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrKolsPubCount = array();
        $arrLastAuthPubs = $this->pubmed->getKolPubsWithLastAuthorship($kolId = 0, $fromYear, $toYear, $arrKolIds, $arrCountries, $arrSpecialties, '', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        foreach ($arrLastAuthPubs as $authPub) {
            if ($authPub['auth_pos'] == $authPub['max_pos'] && $authPub['max_pos'] != 1) {
                if (array_key_exists($authPub['kol_id'], $arrKolsPubCount))
                    $arrKolsPubCount[$authPub['kol_id']] = $arrKolsPubCount[$authPub['kol_id']] + 1;
                else
                    $arrKolsPubCount[$authPub['kol_id']] = 1;
            }
        }
        if (sizeof($arrKolsPubCount > 1))
            return $arrKolsPubCount;
    }

    function sortKolIdsOnCount($arrUniqueKolIds, $arrKolsCountX) {
        $newContArray = array();
        foreach ($arrKolsCountX as $kolId => $row) {
            $newContArray[$kolId] = $row['total_count'];
        }
        arsort($newContArray);
        $arrKolIds = array_keys($newContArray);
        foreach ($arrUniqueKolIds as $kolId) {
            if (!in_array($kolId, $arrKolIds))
                $arrKolIds[] = $kolId;
        }
        return $arrKolIds;
    }

    function prepare_segmentation_table_data($arrKolsCountX, $arrKolsCountY) {
        $arrKolIdX = array_keys($arrKolsCountX);
        $arrKolIdY = array_keys($arrKolsCountY);
        $arrKolIds = array_merge($arrKolIdX, $arrKolIdY);

        $arrUniqueKolIds = array_unique($arrKolIds);
        $arrUniqueKolIds = $this->sortKolIdsOnCount($arrUniqueKolIds, $arrKolsCountX);

        $arrKolDetails = $this->kol->getKolNames();
        $arrKolNames = $this->report->prepareKolIdNameCombinations($arrUniqueKolIds, $arrKolDetails);

        $arrEngagementTypes = $this->kol->getEngagementTypesFromLookUp();
        $arrSessionTypes = $this->kol->getSessionTypesFromLookUp();
        $data1[0] = array('', '', '', '', '', '');
        $data1[1] = array('SN', 'KTL Name', 'X - Parameter', 'X - Count', 'X - Weightage', 'Y - Count', 'Y - Weightage');
        $emtyRow = array('', '', '', '', '', '');
        $sn = 1;
        foreach ($arrUniqueKolIds as $kolId) {
            $xRow = $arrKolsCountX[$kolId];
            $yRow = $arrKolsCountY[$kolId];
            $xlsRow = array();
            $xlsRow[] = $sn;
            $xlsRow[] = $arrKolNames[$kolId];
            $xlsRow[] = 'Total';
            $xlsRow[] = round($xRow['total_count']);
            $xlsRow[] = round($xRow['total_weight']) . '%';
            $xlsRow[] = round($yRow['total_count']);
            $xlsRow[] = round($yRow['total_weight']) . '%';
            $data1[] = $xlsRow;
            if (isset($xRow['aff'])) {
                $xlsRow = array();
                $xlsRow[] = '';
                $xlsRow[] = '';
                $xlsRow[] = 'Affiliations';
                $xlsRow[] = round($xRow['aff']['total_count']);
                $xlsRow[] = round($xRow['aff']['total_weight']) . '%';
                $xlsRow[] = '';
                $xlsRow[] = '';
                $data1[] = $xlsRow;
                //Print all the parameter selected under 'Affiliations'
                if (isset($xRow['aff']['params'])) {
                    //Print all the parameter selected under 'EngagementType'
                    if (isset($xRow['aff']['params']['eng'])) {
                        foreach ($xRow['aff']['params']['eng'] as $engId => $row) {
                            $xlsRow = array();
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $xlsRow[] = '----Engagement Type: ' . $arrEngagementTypes[$engId]['type'];
                            $xlsRow[] = round($row['count']);
                            $xlsRow[] = round($row['weight']) . '%';
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $data1[] = $xlsRow;
                        }
                    }
                    //Print all the parameter selected under 'Organization Type'
                    if (isset($xRow['aff']['params']['org'])) {
                        foreach ($xRow['aff']['params']['org'] as $orgType => $row) {
                            $xlsRow = array();
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $xlsRow[] = '----Organization Type: ' . ucwords($orgType);
                            $xlsRow[] = round($row['count']);
                            $xlsRow[] = round($row['weight']) . '%';
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $data1[] = $xlsRow;
                        }
                    }
                }
            }
            if (isset($yRow['aff'])) {
            	$xlsRow = array();
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = 'Affiliations';
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = round($yRow['aff']['total_count']);
            	$xlsRow[] = round($yRow['aff']['total_weight']) . '%';
            	$data1[] = $xlsRow;
            	//Print all the parameter selected under 'Affiliations'
            	if (isset($yRow['aff']['params'])) {
            		//Print all the parameter selected under 'EngagementType'
            		if (isset($yRow['aff']['params']['eng'])) {
            			foreach ($yRow['aff']['params']['eng'] as $engId => $row) {
            				$xlsRow = array();
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = '----Engagement Type: ' . $arrEngagementTypes[$engId]['type'];
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = round($row['count']);
            				$xlsRow[] = round($row['weight']) . '%';
            				$data1[] = $xlsRow;
            			}
            		}
            		//Print all the parameter selected under 'Organization Type'
            		if (isset($yRow['aff']['params']['org'])) {
            			foreach ($yRow['aff']['params']['org'] as $orgType => $row) {
            				$xlsRow = array();
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = '----Organization Type: ' . ucwords($orgType);
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = round($row['count']);
            				$xlsRow[] = round($row['weight']) . '%';
            				$data1[] = $xlsRow;
            			}
            		}
            	}
            }
            if (isset($xRow['event'])) {
                $xlsRow = array();
                $xlsRow[] = '';
                $xlsRow[] = '';
                $xlsRow[] = 'Events';
                $xlsRow[] = round($xRow['event']['total_count']);
                $xlsRow[] = round($xRow['event']['total_weight']) . '%';
                $xlsRow[] = '';
                $xlsRow[] = '';
                $data1[] = $xlsRow;
                //Print all the parameter selected under 'Events'
                if (isset($xRow['event']['params'])) {
                    //Print all the parameter selected under 'Session Type'
                    if (isset($xRow['event']['params']['session'])) {
                        foreach ($xRow['event']['params']['session'] as $sesId => $row) {
                            $xlsRow = array();
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $xlsRow[] = '----Session Type: ' . $arrSessionTypes[$sesId]['type'];
                            $xlsRow[] = round($row['count']);
                            $xlsRow[] = round($row['weight']) . '%';
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $data1[] = $xlsRow;
                        }
                    }
                    //Print all the parameter selected under 'Role'
                    if (isset($xRow['event']['params']['role'])) {
                        foreach ($xRow['event']['params']['role'] as $role => $row) {
                            $xlsRow = array();
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $xlsRow[] = '----Role: ' . $role;
                            $xlsRow[] = round($row['count']);
                            $xlsRow[] = round($row['weight']) . '%';
                            $xlsRow[] = '';
                            $xlsRow[] = '';
                            $data1[] = $xlsRow;
                        }
                    }
                }
            }
            if (isset($yRow['event'])) {
            	$xlsRow = array();
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = 'Events';
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = round($yRow['event']['total_count']);
            	$xlsRow[] = round($yRow['event']['total_weight']) . '%';
            	$data1[] = $xlsRow;
            	//Print all the parameter selected under 'Events'
            	if (isset($yRow['event']['params'])) {
            		//Print all the parameter selected under 'Session Type'
            		if (isset($yRow['event']['params']['session'])) {
            			foreach ($yRow['event']['params']['session'] as $sesId => $row) {
            				$xlsRow = array();
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = '----Session Type: ' . $arrSessionTypes[$sesId]['type'];
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = round($row['count']);
            				$xlsRow[] = round($row['weight']) . '%';
            				$data1[] = $xlsRow;
            			}
            		}
            		//Print all the parameter selected under 'Role'
            		if (isset($yRow['event']['params']['role'])) {
            			foreach ($yRow['event']['params']['role'] as $role => $row) {
            				$xlsRow = array();
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = '----Role: ' . $role;
            				$xlsRow[] = '';
            				$xlsRow[] = '';
            				$xlsRow[] = round($row['count']);
            				$xlsRow[] = round($row['weight']) . '%';
            				$data1[] = $xlsRow;
            			}
            		}
            	}
            }
            if (isset($xRow['pub'])) {
                $xlsRow = array();
                $xlsRow[] = '';
                $xlsRow[] = '';
                $xlsRow[] = 'Publications';
                $xlsRow[] = round($xRow['pub']['total_count']);
                $xlsRow[] = round($xRow['pub']['total_weight']) . '%';
                $xlsRow[] = '';
                $xlsRow[] = '';
                $data1[] = $xlsRow;
                //Print all the parameter selected under 'Publications'
                if (isset($xRow['pub']['params'])) {
                    //Print all the parameter selected under 'Session Type'
                    foreach ($xRow['pub']['params'] as $position => $row) {
                        $xlsRow = array();
                        $xlsRow[] = '';
                        $xlsRow[] = '';
                        $xlsRow[] = '----Position: ' . $position;
                        $xlsRow[] = round($row['count']);
                        $xlsRow[] = round($row['weight']) . '%';
                        $xlsRow[] = '';
                        $xlsRow[] = '';
                        $data1[] = $xlsRow;
                    }
                }
            }
            if (isset($yRow['pub'])) {
            	$xlsRow = array();
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = 'Publications';
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = round($yRow['pub']['total_count']);
            	$xlsRow[] = round($yRow['pub']['total_weight']) . '%';
            	$data1[] = $xlsRow;
            	//Print all the parameter selected under 'Publications'
            	if (isset($yRow['pub']['params'])) {
            		//Print all the parameter selected under 'Session Type'
            		foreach ($yRow['pub']['params'] as $position => $row) {
            			$xlsRow = array();
            			$xlsRow[] = '';
            			$xlsRow[] = '';
            			$xlsRow[] = '----Position: ' . $position;
            			$xlsRow[] = '';
            			$xlsRow[] = '';
            			$xlsRow[] = round($row['count']);
            			$xlsRow[] = round($row['weight']) . '%';
            			$data1[] = $xlsRow;
            		}
            	}
            }
            if (isset($xRow['trial'])) {
                $xlsRow = array();
                $xlsRow[] = '';
                $xlsRow[] = '';
                $xlsRow[] = 'Trials';
                $xlsRow[] = round($xRow['trial']['total_count']);
                $xlsRow[] = round($xRow['trial']['total_weight']) . '%';
                $xlsRow[] = '';
                $xlsRow[] = '';
                $data1[] = $xlsRow;
            }
            if (isset($yRow['trial'])) {
            	$xlsRow = array();
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = 'Trials';
            	$xlsRow[] = '';
            	$xlsRow[] = '';
            	$xlsRow[] = round($yRow['trial']['total_count']);
            	$xlsRow[] = round($yRow['trial']['total_weight']) . '%';
            	$data1[] = $xlsRow;
            }
            $data1[] = $emtyRow;
            $sn++;
        }

        return $data1;
    }

    function getSegmentationDataForChart($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsX, $affWeightX, $eventParamsX, $eventWeightX, $pubParamsX, $pubWeightX, $trialX, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrSpecialityIds = $arrSpecialities;
        $arrCountriesIds = $arrCountries;
        $arrKolIds = $arrKolNames;
        $arrListNamesIds = $arrListNames;
        //Statrt: Calulate the count for X - Axis------------------------------------------------------------------------
        $arrKolsCountX = array();
        //check is there any affiliation is selected as a parameter, if yes then get there count and apply weightage and prepare count
        if ($affParamsX[0] != 0 || $affParamsX[1] != 0 || $affParamsX[2] != 0 || (sizeof($affParamsX) > 3 && $affParamsX[3] != null) || (sizeof($affParamsX) > 4 && $affParamsX[4] != null)) {
            $arrEngTypes = '';
            $arrOrgType = '';
            
            //If main Affiliation getegory is 'not' selected as a parameter, get the sub category parameters, and store them in a array
            if ($affParamsX[0] != 1) {
                if (sizeof($affParamsX) > 3 && $affParamsX[1] != 1)
                    $arrEngTypes = $affParamsX[3];
                if (sizeof($affParamsX) > 4 && $affParamsX[2] != 1)
                    $arrOrgType = $affParamsX[4];
            }
            
            //If main or sub Affiliation getegory is selected as a parameter
            if ($affParamsX[0] != 0 || $affParamsX[1] != 0 || $affParamsX[2] != 0) {
                $weight = $affWeightX[0];
                //If Sub Categories are selected as a parameter then combine the weightage of both, it is equevalent to selecting main category
                if ($affParamsX[1] != 0 || $affParamsX[2] != 0)
                    $weight = $affWeightX[1] + $affWeightX[2];
                //Get the count of affiliations for all the kols and apply weightages...	
                $arrAffsCountResultsX = $this->kol->getAffiliationsByParam($fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType, $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                
                foreach ($arrAffsCountResultsX as $aff) {
                    if (array_key_exists($aff['kol_id'], $arrKolsCountX)) {
                        $count = ($weight * (int) $aff['count']) / 100;
                        $arrKolsCountX[$aff['kol_id']] = $arrKolsCountX[$aff['kol_id']] + $count;
                    } else {
                        $count = ($weight * (int) $aff['count']) / 100;
                        $arrKolsCountX[$aff['kol_id']] = $count;
                    }
                }
               
            } else {//If any of the sub category values are selected as parrmaters, do the followings
                if (sizeof($affParamsX) > 3 && $affParamsX[3] != '') {
                    //If Any Engagement Type is selected
                    //Get the count of affiliations for each kol for each selected parameter
                    $arrAffsCountResultsX = $this->kol->affTempRenameLater($arrEngTypes, 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                    //Apply the weightages and get the count and store it in a array, for each KOL
                    foreach ($arrAffsCountResultsX as $kolId => $arrEngCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            foreach ($arrEngCounts as $engId => $engCount) {
                                $count = $count + (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                            }
                            $count+=$arrKolsCountX[$kolId];
                            $arrKolsCountX[$kolId] = $count;
                        } else {
                            $count = 0;
                            foreach ($arrEngCounts as $engId => $engCount) {
                                $count = $count + (($engCount * $affWeightX[3][array_search($engId, $arrEngTypes)]) / 100);
                            }
                            $arrKolsCountX[$kolId] = $count;
                        }
                    }
                }
                //pr($arrKolsCountX);
                if (sizeof($affParamsX) > 4 && $affParamsX[4] != null) {
                    //If Any Org Type is selected
                    //Get the count of affiliations for each kol for each selected parameter
                    $arrAffsCountResultsX = $this->kol->affTempRenameLater(0, $arrOrgType, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                    //pr($arrAffsCountResultsX);
                    foreach ($arrAffsCountResultsX as $kolId => $arrOrgCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            foreach ($arrOrgCounts as $orgId => $orgCount) {
                                $count = $count + (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                            }
                            $count+=$arrKolsCountX[$kolId];
                            $arrKolsCountX[$kolId] = $count;
                        } else {
                            $count = 0;
                            foreach ($arrOrgCounts as $orgId => $orgCount) {
                                $count = $count + (($orgCount * $affWeightX[4][array_search($orgId, $arrOrgType)]) / 100);
                            }
                            $arrKolsCountX[$kolId] = $count;
                        }
                    }
                }
            }
        }
        
        //pr($arrKolsCountX);

        if ($eventParamsX[0] != 0 || $eventParamsX[1] != 0 || $eventParamsX[2] != 0 || (sizeof($eventParamsX) > 3 && $eventParamsX[3] != null) || (sizeof($eventParamsX) > 4 && $eventParamsX[4] != null)) {
            $arrSessionTypes = 0;
            $arrRoles = 0;
            if ($eventParamsX[0] != 1) {
                if (sizeof($eventParamsX) > 3 && $eventParamsX[1] != 1)
                    $arrSessionTypes = $eventParamsX[3];
                if (sizeof($eventParamsX) > 4 && $eventParamsX[2] != 1)
                    $arrRoles = $eventParamsX[4];
            }
            //$arrEventsCountResultsX		= $this->kol->getEventsByParam($fromYear=1900,$toYear=2011,$arrKolIds=0,$arrSessionTypes,$arrRoles,$arrCountries=0,$arrSpecialties=0,$groupBy='kolId');

            if ($eventParamsX[0] != 0 || $eventParamsX[1] != 0 || $eventParamsX[2] != 0) {
                $weight = $eventWeightX[0];
                if ($eventParamsX[1] != 0 || $eventParamsX[2] != 0)
                    $weight = $eventWeightX[1] + $eventWeightX[2];


                $arrEventsCountResultsX = $this->kol->getEventsByParam($fromYear, $toYear, $arrKolIds, $arrSessionTypes, $arrRoles, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                foreach ($arrEventsCountResultsX as $event) {
                    if (array_key_exists($event['kol_id'], $arrKolsCountX)) {
                        $count = ($weight * (int) $event['count']) / 100;
                        $arrKolsCountX[$event['kol_id']] = $arrKolsCountX[$event['kol_id']] + $count;
                    } else {
                        $count = ($weight * (int) $event['count']) / 100;
                        $arrKolsCountX[$event['kol_id']] = $count;
                    }
                }
            } else {
                if (sizeof($eventParamsX) > 3 && $eventParamsX[3] != '') {
                    $arrEventsCountResultsX = $this->kol->eventTempRenameLater($arrSessionTypes, 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                    //pr($arrEventsCountResultsX);
                    foreach ($arrEventsCountResultsX as $kolId => $arrSesCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            foreach ($arrSesCounts as $sesId => $sesCount) {
                                $count = $count + (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                            }
                            $count+=$arrKolsCountX[$kolId];
                            $arrKolsCountX[$kolId] = $count;
                        } else {
                            $count = 0;
                            foreach ($arrSesCounts as $sesId => $sesCount) {
                                $count = $count + (($sesCount * $eventWeightX[3][array_search($sesId, $arrSessionTypes)]) / 100);
                            }
                            $arrKolsCountX[$kolId] = $count;
                        }
                    }
                }
                //pr($arrKolsCountX);
                if (sizeof($eventParamsX) > 4 && $eventParamsX[4] != null) {
                    $arrEventsCountResultsX = $this->kol->eventTempRenameLater(0, $arrRoles, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                    //pr($arrAffsCountResultsX);
                    foreach ($arrEventsCountResultsX as $kolId => $arrRolCounts) {
                        if (array_key_exists($kolId, $arrKolsCountX)) {
                            $count = 0;
                            foreach ($arrRolCounts as $rolId => $rolCount) {
                                $count = $count + (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                            }
                            $count+=$arrKolsCountX[$kolId];
                            $arrKolsCountX[$kolId] = $count;
                        } else {
                            $count = 0;
                            foreach ($arrRolCounts as $rolId => $rolCount) {
                                $count = $count + (($rolCount * $eventWeightX[4][array_search($rolId, $arrRoles)]) / 100);
                            }
                            $arrKolsCountX[$kolId] = $count;
                        }
                    }
                }
            }
        }
        //pr($arrKolsCountX);
        if ($pubParamsX[0] != 0) {
            $weight = $pubWeightX[0];
            $arrPubCounts = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, 0, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
            foreach ($arrPubCounts as $pub) {
                if (array_key_exists($pub['kol_id'], $arrKolsCountX)) {
                    $count = ($weight * (int) $pub['count']) / 100;
                    $arrKolsCountX[$pub['kol_id']] = $arrKolsCountX[$pub['kol_id']] + $count;
                } else {
                    $count = ($weight * (int) $pub['count']) / 100;
                    $arrKolsCountX[$pub['kol_id']] = $count;
                }
            }
        } else if (sizeof($pubParamsX > 1 && $pubParamsX[1] != null)) {
            if ($pubWeightX[1][1] != 0) {
                $weight = $pubWeightX[1][1];
                $arrPubCounts = $this->getFirstAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $arrKolsCountX[$kolId] + $count;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $count;
                    }
                }
            }
            if ($pubWeightX[1][2] != 0) {
                $weight = $pubWeightX[1][2];
                $arrPubCounts = $this->getSingleAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $arrKolsCountX[$kolId] + $count;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $count;
                    }
                }
            }
            if ($pubWeightX[1][3] != 0) {
                $weight = $pubWeightX[1][3];
                $arrPubCounts = $this->getMiddleAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $arrKolsCountX[$kolId] + $count;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $count;
                    }
                }
            }
            if ($pubWeightX[1][4] != 0) {
                $weight = $pubWeightX[1][4];
                $arrPubCounts = $this->getLastAuthPubsCount($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
                foreach ($arrPubCounts as $kolId => $pubCount) {
                    if (array_key_exists($kolId, $arrKolsCountX)) {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $arrKolsCountX[$kolId] + $count;
                    } else {
                        $count = ($weight * (int) $pubCount) / 100;
                        $arrKolsCountX[$kolId] = $count;
                    }
                }
            }
        }

        //pr($arrKolsCountX);
        if ($trialX != null && $trialX != '' && $trialX != 0) {
            $arrTrialsCountResultsX = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
            foreach ($arrTrialsCountResultsX as $trial) {
                if (array_key_exists($trial['kol_id'], $arrKolsCountX)) {
                    $count = ($trial['count'] * $trialX) / 100;
                    $arrKolsCountX[$trial['kol_id']] = $arrKolsCountX[$trial['kol_id']] + $count;
                } else {
                    $count = ($trial['count'] * $trialX) / 100;
                    $arrKolsCountX[$trial['kol_id']] = $count;
                }
            }
        }

        return $arrKolsCountX;
    }

    function getMSLActivityReportData($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = '', $data = '') {

        $arrData = array();
        if (!empty($data['manager_id']))
                $users=$this->common_helpers->getManagerAlignedUsers($data['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        if (!$doCount) {
            //$this->db->select("client_users.id,client_users.first_name,client_users.last_name, COUNT(DISTINCT interactions.id) AS intc, COUNT(DISTINCT medical_insight.id) AS mic, COUNT(DISTINCT interaction_mirf.id) AS uoq, COUNT(DISTINCT speaker_evaluations.id) AS speaker_eval,,COUNT(DISTINCT survey_answers.survey_id,survey_answers.respondent_id) AS soi");
            $this->db->select('client_users.id,client_users.first_name,client_users.last_name,COUNT(CASE WHEN activity_name = "Interaction" THEN activity_id END) AS intc,COUNT(CASE WHEN activity_name = "Survey" OR activity_name = "Survey Staging" THEN activity_id END) AS survey,COUNT(CASE WHEN activity_name = "Speaker Survey" THEN activity_id END) AS speaker_eval,COUNT(CASE WHEN activity_name = "Medical Insight" THEN activity_id END) AS mic,COUNT(CASE WHEN activity_name = "UOQ" THEN activity_id END) AS uoq');
        }

        $dateString = "";
        if ($data['start_date'] != '' && $data['end_date'] != '')
            $dateString = ' BETWEEN "' . $data['start_date'] . '" AND "' . $data['end_date'] . '"';
        else if ($data['start_date'] != '')
            $dateString = ' >= "' . $data['start_date'] . '"';
        else if ($data['end_date'] != '')
            $dateString = ' <= "' . $data['end_date'] . '"';

        $this->db->join('msl_activity_report_data', "client_users.id = msl_activity_report_data.activity_by", 'left');
        if ($dateString != "") {
        	$this->db->where("DATE(activity_date) ".$dateString);
        }
            
        /*if ($dateString != "") {
            $this->db->join('interactions', "client_users.id = interactions.employee_id AND interactions.date" . $dateString, 'left');
            $this->db->join('medical_insight', "client_users.id = medical_insight.created_by AND medical_insight.created_on" . $dateString, 'left');

            $this->db->join('interaction_mirf', "client_users.id = interaction_mirf.created_by  AND interaction_mirf.date_of_request" . $dateString, 'left');
            $this->db->join('speaker_evaluations', "client_users.id = speaker_evaluations.created_by  AND speaker_evaluations.program_date" . $dateString, 'left');
            
            $this->db->join('survey_answers', "client_users.id = survey_answers.created_by AND survey_answers.created_on" . $dateString, 'left');
        } else {
            $this->db->join('interactions', "client_users.id = interactions.employee_id", 'left');
            $this->db->join('medical_insight', "client_users.id = medical_insight.created_by", 'left');

            $this->db->join('interaction_mirf', "client_users.id = interaction_mirf.created_by ", 'left');
            $this->db->join('speaker_evaluations', "client_users.id = speaker_evaluations.created_by", 'left');
            
            $this->db->join('survey_answers', "client_users.id = survey_answers.created_by", 'left');
        }*/
        
        
            
        if (!empty($data['msl'])) {
            $this->db->where_in("client_users.id", $data['msl']);
        }
        if (!empty($data['team'])) {
            $this->db->join('user_groups', 'user_groups.user_id=client_users.id', 'left');
            $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');

            $this->db->where_in('user_groups.group_id ', $data['team']);
        }
        if (!empty($data['manager_id'])) { 
            $this->db->where_in("client_users.id", $users);
        }
if (!empty($where['name']))
                    $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $where['name']);  
//          if (!empty($where['last_name']))
//                    $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $where['last_name']);  
       
if($userRole == ROLE_USER){
            $this->db->where('client_users.id', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('client_users.id', $userIds);
       }
        $clientId = $this->session->userdata('client_id');
        ///if($clientId != INTERNAL_CLIENT_ID){
        $this->db->where('client_users.client_id', $clientId);
        $this->db->where('is_test_user', 0);
        $this->db->where_in('client_users.user_from', array(1, 2, 3));
        //}

        $this->db->group_by('client_users.id');
        $res = $this->db->get('client_users');
//      echo $this->db->last_query(); exit;
        return $res->result_array();
    }

    function getMsl($msl) {
        $arrMsl = array();
        $this->db->select('CONCAT(client_users.first_name, " ", client_users.last_name) as name, client_users.id', false);
        $this->db->like('CONCAT(client_users.first_name,  client_users.last_name)', $msl);
        $this->db->join('client_users', 'client_users.id=medical_insight.created_by', 'left');
        $this->db->group_by('medical_insight.created_by');
        $arrMSLResult = $this->db->get('medical_insight');
        foreach ($arrMSLResult->result_array() as $arrMsls) {
            $arrMsl[$arrMsls['id']] = $arrMsls['name'];
        }
        return $arrMsl;
    }

    function getProduct($product) {
        $arrProduct = array();
        $this->db->select('products.id,products.name');
        $this->db->like('products.name', $product);
        $this->db->join('products', 'products.name=medical_insight.product', 'left');
        $this->db->group_by('medical_insight.product');
        $arrProductResult = $this->db->get('medical_insight');
        foreach ($arrProductResult->result_array() as $arrProducts) {
            $arrProduct[$arrProducts['id']] = $arrProducts['name'];
        }
        // echo $this->db->last_query();
        return $arrProduct;
    }

    function getTopic($topic) {
        $arrTopic = array();
        $this->db->select('key_insight_topics.id,key_insight_topics.name');
        $this->db->like('key_insight_topics.name', $topic);
        $this->db->join('key_insight_topics', 'key_insight_topics.name=medical_insight.topics', 'left');
        $this->db->group_by('medical_insight.topics');
        $arrTopicResult = $this->db->get('medical_insight');
        foreach ($arrTopicResult->result_array() as $arrTopics) {
            $arrTopic[$arrTopics['id']] = $arrTopics['name'];
        }
//                echo $this->db->last_query();
        return $arrTopic;
    }

    function getSource($source) {
        $arrSource = array();
        $this->db->select('source_type.id,source_type.name');
        $this->db->like('source_type.name', $source);
        $this->db->join('source_type', 'source_type.name=medical_insight.source_type', 'left');
        $this->db->group_by('medical_insight.source_type');
        $arrProductResult = $this->db->get('medical_insight');
        foreach ($arrProductResult->result_array() as $arrProducts) {
            $arrSource[$arrProducts['id']] = $arrProducts['name'];
        }
//                echo $this->db->last_query();
        return $arrSource;
    }

    function listCustomerSeenReport($data,$Details) {

        $originalDate = $data['start_date'];
        if ($data['start_date'] != '') {
            $data['start_date'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $data['end_date'];
        if ($data['end_date'] != '') {
            $data['end_date'] = date("Y-m-d", strtotime($originalDate1));
        }
        $this->db->query('SET SESSION group_concat_max_len = 1000000');
        $arrCustomer = array();
        $users=$this->common_helpers->getManagerAlignedUsers($data['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('client_users.id,client_users.is_activated, client_users.first_name,client_users.last_name,groups.group_name,
        COUNT(DISTINCT user_kols.kol_id) AS targetseen,
        COUNT(DISTINCT target_kols.kol_id) AS target,
        (COUNT(DISTINCT target_kols.kol_id)-COUNT(DISTINCT user_kols.kol_id)) AS not_seen,
        COUNT(DISTINCT interactions_attendees.kol_id) AS allseen,
        (COUNT(DISTINCT interactions_attendees.kol_id)-COUNT(DISTINCT user_kols.kol_id)) as oneof,
        GROUP_CONCAT(DISTINCT target_kols.kol_id) AS target_kols,
        GROUP_CONCAT(DISTINCT interactions_attendees.kol_id) AS allseen_kols,
        GROUP_CONCAT(DISTINCT user_kols.kol_id) AS targetseen_kols',false);
        $this->db->join('interactions', 'client_users.id = interactions.employee_id', 'left');
        $this->db->join('interactions_attendees', 'interactions.id=interactions_attendees.interaction_id', 'left');
        $this->db->join('user_kols', 'interactions_attendees.kol_id = user_kols.kol_id AND user_kols.user_id = client_users.id', 'left');
        $this->db->join('user_kols AS target_kols', 'client_users.id = target_kols.user_id', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        if (!empty($Details['username']))
           $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $Details['username']);  
        if (!empty($Details['group_name']))
           $this->db->like('groups.group_name', $Details['group_name']);  
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        $dateString = "";
        if ($data['start_date'] != '' && $data['end_date'] != '')
            $dateString = ' BETWEEN "' . $data['start_date'] . '" AND "' . $data['end_date'] . '"';
        else if ($data['start_date'] != '')
            $dateString = ' >= "' . $data['start_date'] . '"';
        else if ($data['end_date'] != '')
            $dateString = ' <= "' . $data['end_date'] . '"';
        if ($dateString != '') {
            $this->db->where('interactions.date' . $dateString);
        }
        if (!empty($data['msl'])) {
            $this->db->where_in("client_users.id", $data['msl']);
        }
        if (!empty($data['team'])) {
            $this->db->where_in('user_groups.group_id ', $data['team']);
        }
        if (!empty($data['manager_id'])) { 
               $this->db->where_in("client_users.id", $users);
        }
         if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('client_users.id', $userIds);
       }
       $this->db->group_by('client_users.id');
        $arrResult = $this->db->get('client_users');
      
            
        foreach ($arrResult->result_array() as $arrResultCustomer ) {
            if ($arrResultCustomer['is_activated'] == 1)
                $arrResultCustomer['is_activated'] = 'Yes';
            else
                $arrResultCustomer['is_activated'] = 'No';
            $arrResultCustomer['username'] = $arrResultCustomer['first_name'] . ' ' . $arrResultCustomer['last_name'];
            $arrCustomer[$arrResultCustomer['id']]=$arrResultCustomer;
           
           
           
        }
         $allSeenOverAll = $this->customerSeenOverAllSeen($data);
         $arrSeenOverAll=array_intersect_key($allSeenOverAll,$arrCustomer);
         $mergedArrayResult = array();

        $arrayMergered = array_merge($arrCustomer, $arrSeenOverAll);
        foreach ( $arrayMergered as $value ) {
          $id = $value['id'];
          if ( !isset($mergedArrayResult[$id]) ) {
            $mergedArrayResult[$id] = array();
          }
          $mergedArrayResult[$id] = array_merge($mergedArrayResult[$id], $value);

        }

          foreach ( $mergedArrayResult as $key => $value) {
         $targetseen_kols = explode(",", $value['target_kols']);
                    $target_kols = explode(",", $value['allseenOverAll_kols']);
                    $kolidExploded = array_intersect($targetseen_kols, $target_kols);
                    foreach ($kolidExploded as $keysKol => $valuesKol) {
                        if (!empty($valuesKol))
                            $arr[$key]['overAllSeenTarget']=sizeof($kolidExploded);
                        else 
                             $arr[$key]['overAllSeenTarget']=0;
                    }
                    if(empty($arr[$key]['overAllSeenTarget']))
                        $arr[$key]['overAllSeenTarget']=0;
                   
                    $overAllSeenTargetkols = implode(',',$kolidExploded);
                    $arr[$key]['id']=$key;
                    $arr[$key]['overAllSeenTargetkols']=$overAllSeenTargetkols;
          }

 
  
   $arrCustomerResult = array();

$resultantArray = array_merge($mergedArrayResult, $arr);
foreach ( $resultantArray as $value1 ) {
  $id = $value1['id'];
  if ( !isset($arrCustomerResult[$id]) ) {
    $arrCustomerResult[$id] = array();
  }
    $arrCustomerResult[$id] = array_merge($arrCustomerResult[$id], $value1);
    $arrCustomerResult[$id]['notseen']=$arrCustomerResult[$id]['target']-$arrCustomerResult[$id]['overAllSeenTarget'];
    $arrCustomerResult[$id]['OneOff']=$arrCustomerResult[$id]['allseenOverAll']-$arrCustomerResult[$id]['overAllSeenTarget'];
}
        return $arrCustomerResult;
    }

    
//     function listInstitutionSeenReport($data,$Details) {
//
//        $originalDate = $data['start_date'];
//        if ($data['start_date'] != '') {
//            $data['start_date'] = date("Y-m-d", strtotime($originalDate));
//        }
//        $originalDate1 = $data['end_date'];
//        if ($data['end_date'] != '') {
//            $data['end_date'] = date("Y-m-d", strtotime($originalDate1));
//        }
//        $this->db->query('SET SESSION group_concat_max_len = 1000000');
//        $arrInstitution = array();
//        $userId = $this->session->userdata('user_id');
//        $userRole = $this->session->userdata('user_role_id');
//        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
//        $teamName = $this->common_helpers->getUserTeamName($userId);
//        $this->db->select('client_users.id, client_users.is_activated, client_users.first_name, 
//	client_users.last_name, groups .group_name, COUNT(DISTINCT user_orgs.org_id) AS
//	targetseen, COUNT(DISTINCT target_orgs.org_id) AS target , (COUNT(DISTINCT
//	target_orgs.org_id)-COUNT(DISTINCT user_orgs.org_id)) AS not_seen,
//	COUNT(DISTINCT interactions_attendees .org_id) AS allseen, (COUNT(DISTINCT
//	interactions_attendees.org_id)-COUNT(DISTINCT user_orgs.org_id) ) as oneof,
//	GROUP_CONCAT(DISTINCT target_orgs.org_id) AS target_orgs, GROUP_CONCAT(DISTINCT
//	interactions_attendees .org_id) AS allseen_orgs, GROUP_CONCAT(DISTINCT
//	user_orgs.org_id) AS targetseen_orgs', false);
//        $this->db->join('interactions', 'client_users.id = interactions.employee_id', 'left');
//        $this->db->join('interactions_attendees', 'interactions.id=interactions_attendees.interaction_id', 'left');
//        $this->db->join('user_orgs', 'interactions_attendees.org_id = user_orgs.org_id AND user_orgs.user_id = client_users.id', 'left');
//        $this->db->join('user_orgs AS target_orgs', 'client_users.id = target_orgs.user_id', 'left');
//        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
//        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
//
//        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
//        if (!empty($Details['username']))
//           $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $Details['username']);  
//        if (!empty($Details['group_name']))
//           $this->db->like('groups.group_name', $Details['group_name']);  
//        $clientId = $this->session->userdata('client_id');
//        if ($clientId != INTERNAL_CLIENT_ID) {
//            $this->db->where('client_users.client_id', $clientId);
//            $this->db->where_in('client_users.user_from', array(1, 2, 3));
//        }
//        $dateString = "";
//        if ($data['start_date'] != '' && $data['end_date'] != '')
//            $dateString = ' BETWEEN "' . $data['start_date'] . '" AND "' . $data['end_date'] . '"';
//        else if ($data['start_date'] != '')
//            $dateString = ' >= "' . $data['start_date'] . '"';
//        else if ($data['end_date'] != '')
//            $dateString = ' <= "' . $data['end_date'] . '"';
//        if ($dateString != '') {
//            $this->db->where('interactions.date' . $dateString);
//        }
//        if (!empty($data['msl'])) {
//            $this->db->where_in("client_users.id", $data['msl']);
//        }
//        if (!empty($data['team'])) {
//            $this->db->where_in('user_groups.group_id ', $data['team']);
//        }
//         if($userRole == ROLE_USER){
//           $this->db->where('client_users.id', $userId);
//       }
//       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
//           $this->db->where_in('client_users.id', $userIds);
//       }
//        $this->db->group_by('client_users.id');
//        $arrResult = $this->db->get('client_users');
//        foreach ($arrResult->result_array() as $arrResultInstitution) {
//            if ($arrResultInstitution['is_activated'] == 1)
//                $arrResultInstitution['is_activated'] = 'Yes';
//            else
//                $arrResultInstitution['is_activated'] = 'No';
//            $arrResultInstitution['username'] = $arrResultInstitution['first_name'] . ' ' . $arrResultInstitution['last_name'];
//            $arrInstitution[] = $arrResultInstitution;
//        }
////                echo $this->db->last_query(); exit;
//        return $arrInstitution;
//    }
    
    
        function listInstitutionSeenReport($data,$Details) {

        $originalDate = $data['start_date'];
        if ($data['start_date'] != '') {
            $data['start_date'] = date("Y-m-d", strtotime($originalDate));
        }
        $originalDate1 = $data['end_date'];
        if ($data['end_date'] != '') {
            $data['end_date'] = date("Y-m-d", strtotime($originalDate1));
        }
        $this->db->query('SET SESSION group_concat_max_len = 1000000');
        $arrInstitution = array();
        $users=$this->common_helpers->getManagerAlignedUsers($data['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('client_users.id, client_users.is_activated, client_users.first_name, 
	client_users.last_name, groups .group_name, COUNT(DISTINCT user_orgs.org_id) AS
	targetseen, COUNT(DISTINCT target_orgs.org_id) AS target , (COUNT(DISTINCT
	target_orgs.org_id)-COUNT(DISTINCT user_orgs.org_id)) AS not_seen,
	COUNT(DISTINCT interactions_attendees .org_id) AS allseen, (COUNT(DISTINCT
	interactions_attendees.org_id)-COUNT(DISTINCT user_orgs.org_id) ) as oneof,
	GROUP_CONCAT(DISTINCT target_orgs.org_id) AS target_orgs, GROUP_CONCAT(DISTINCT
	interactions_attendees .org_id) AS allseen_orgs, GROUP_CONCAT(DISTINCT
	user_orgs.org_id) AS targetseen_orgs', false);
        $this->db->join('interactions', 'client_users.id = interactions.employee_id', 'left');
        $this->db->join('interactions_attendees', 'interactions.id=interactions_attendees.interaction_id', 'left');
        $this->db->join('user_orgs', 'interactions_attendees.org_id = user_orgs.org_id AND user_orgs.user_id = client_users.id', 'left');
        $this->db->join('user_orgs AS target_orgs', 'client_users.id = target_orgs.user_id', 'left');
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
        if (!empty($Details['username']))
           $this->db->like('CONCAT(client_users.first_name,client_users.last_name)', $Details['username']);  
        if (!empty($Details['group_name']))
           $this->db->like('groups.group_name', $Details['group_name']);  
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        $dateString = "";
        if ($data['start_date'] != '' && $data['end_date'] != '')
            $dateString = ' BETWEEN "' . $data['start_date'] . '" AND "' . $data['end_date'] . '"';
        else if ($data['start_date'] != '')
            $dateString = ' >= "' . $data['start_date'] . '"';
        else if ($data['end_date'] != '')
            $dateString = ' <= "' . $data['end_date'] . '"';
        if ($dateString != '') {
            $this->db->where('interactions.date' . $dateString);
        }
        if (!empty($data['msl'])) {
            $this->db->where_in("client_users.id", $data['msl']);
        }
        if (!empty($data['team'])) {
            $this->db->where_in('user_groups.group_id ', $data['team']);
        }
        if (!empty($data['manager_id'])) { 
               $this->db->where_in("client_users.id", $users);
        }
         if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('client_users.id', $userIds);
       }
        $this->db->group_by('client_users.id');
        $arrResult = $this->db->get('client_users');
        foreach ($arrResult->result_array() as $arrResultInstitution) {
            if ($arrResultInstitution['is_activated'] == 1)
                $arrResultInstitution['is_activated'] = 'Yes';
            else
                $arrResultInstitution['is_activated'] = 'No';
            $arrResultInstitution['username'] = $arrResultInstitution['first_name'] . ' ' . $arrResultInstitution['last_name'];
            $arrInstitution[$arrResultInstitution['id']] = $arrResultInstitution;
        }
       
        $allSeenOverAll = $this->institutionSeenOverAllSeen($data);
      
        $arrSeenOverAll=array_intersect_key($allSeenOverAll,$arrInstitution);  
        $mergedArrayResult = array();
        $arrayMergered = array_merge($arrInstitution, $arrSeenOverAll);
        foreach ( $arrayMergered as $value ) {
            $id = $value['id'];
            if ( !isset($mergedArrayResult[$id]) ) {
              $mergedArrayResult[$id] = array();
            }
            $mergedArrayResult[$id] = array_merge($mergedArrayResult[$id], $value);

        }
        foreach ( $mergedArrayResult as $key => $value) {
         $targetseen_Orgs = explode(",", $value['target_orgs']);
                    $target_Orgs = explode(",", $value['allseenOverAll_Orgs']);
                    $OrgidExploded = array_intersect($targetseen_Orgs, $target_Orgs);
                    foreach ($OrgidExploded as $keysOrg => $valuesOrg) {
                        if (!empty($valuesOrg))
                            $arr[$key]['overAllSeenTarget']=sizeof($OrgidExploded);
                        else 
                             $arr[$key]['overAllSeenTarget']=0;
                    }
                     if(empty($arr[$key]['overAllSeenTarget']))
                        $arr[$key]['overAllSeenTarget']=0;
                    $overAllSeenTargetkols = implode(',',$OrgidExploded);
                    $arr[$key]['id']=$key;
                    $arr[$key]['overAllSeenTargetOrgs']=$overAllSeenTargetkols;
          }
    
   $arrInstitutionResult = array();

$resultantArray = array_merge($mergedArrayResult, $arr);
foreach ( $resultantArray as $value1 ) {
  $id = $value1['id'];
  if ( !isset($arrInstitutionResult[$id]) ) {
    $arrInstitutionResult[$id] = array();
  }
    $arrInstitutionResult[$id] = array_merge($arrInstitutionResult[$id], $value1);
    $arrInstitutionResult[$id]['notseen']=$arrInstitutionResult[$id]['target']-$arrInstitutionResult[$id]['overAllSeenTarget'];
    $arrInstitutionResult[$id]['OneOff']=$arrInstitutionResult[$id]['allseenOverAll']-$arrInstitutionResult[$id]['overAllSeenTarget'];
}
        return $arrInstitutionResult;
//                echo $this->db->last_query(); exit;
//        return $arrInstitution;
    }

    function getkolDetails($arrParams,$Details){ 
        if (isset($arrParams['kolIds'])) {
            $kolIds=($arrParams['kolIds']); 
            $kolidExploded = explode(",", $kolIds);
        }
        if (isset($arrParams['allseenOverAll_kols']) && isset($arrParams['overAllSeenTargetkols'])) {
            $targetseen_kols = explode(",", $arrParams['allseenOverAll_kols']);
            $allseen_kols = explode(",", $arrParams['overAllSeenTargetkols']);
            $kolidExploded = array_diff($targetseen_kols,$allseen_kols);
        }
        if (isset($arrParams['target_kols']) && isset($arrParams['overAllSeenTargetkols'])) {
            $targetseen_kols = explode(",", $arrParams['overAllSeenTargetkols']);
            $target_kols = explode(",", $arrParams['target_kols']);
            $kolidExploded = array_diff($target_kols, $targetseen_kols);
        }
        foreach ($kolidExploded as $key => $value) {
            $arrKolDetails	= array();
                $this->db->select('kols.*, titles.title as title_name, specialties.specialty as specialty_name, degrees.degree,countries.Country,regions.Region,cities.City');
		$this->db->where('kols.id',$value);
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
		$this->db->join('degrees', 'kols.degree_id = degrees.id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
		$this->db->join('regions','RegionId = state_id','left');
		$this->db->join('cities','cityId = city_id','left');
                if (!empty($Details['kolname']))
                    $this->db->like('CONCAT(kols.first_name,kols.middle_name,kols.last_name)', $Details['kolname']);  
                if (!empty($Details['Region']))
                    $this->db->like('regions.Region', $Details['Region']);  
                if (!empty($Details['City']))
                    $this->db->like('cities.City', $Details['City']);  
                if (!empty($Details['primary_phone']))
                    $this->db->like('kols.primary_phone', $Details['primary_phone']);  
                if (!empty($Details['specialty_name']))
                    $this->db->like('specialties.specialty', $Details['specialty_name']);  
		if($arrKolDetailResult	=	$this->db->get('kols')){
			// If the results are not available
//			if($arrKolDetailResult->num_rows() == 0){
//				return false;
//			}

			foreach($arrKolDetailResult->result_array() as $arrKol){
				
					//$arrKolDetails['kolname']=$arrKolDetails['first_name'].' '.$arrKolDetails['last_name'];
                                 if (!empty($Details['isexcel'])){
                                      $arrKol['kolname'] =  $this->common_helpers->get_name_format($arrKol['first_name'], $arrKol['middle_name'], $arrKol['last_name']);
                                 $arrKolDetailRes[]	= $arrKol;
                                      
                                 }else{
                                    $arrKolDetails	= $arrKol;
				if(is_numeric($arrKolDetails['title']))
					$arrKolDetails['title'] = $arrKolDetails['title_name'];
                                 if (IS_IPAD_REQUEST) {
                    $arrKolDetails['kolname'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $arrKolDetails['id'] . '">' . $this->common_helpers->get_name_format($arrKolDetails['first_name'], $arrKolDetails['middle_name'], $arrKolDetails['last_name']) . '</a>';
                } else {
                    $arrKolDetails['kolname'] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $arrKolDetails['id'] . '">' . $this->common_helpers->get_name_format($arrKolDetails['first_name'], $arrKolDetails['middle_name'], $arrKolDetails['last_name']) . '</a>';
                } 
			}
                        }
		}  
               if (empty($Details['isexcel']))
          $arrKolDetailRes[]=$arrKolDetails;
        }
        
       return $arrKolDetailRes;
    }
    
     function getOrgDetails($arrParams,$Details){
        if (isset($arrParams['orgIds'])) {
            $orgIds=($arrParams['orgIds']); 
            $OrgidExploded = explode(",", $orgIds);
        }
        if (isset($arrParams['allseenOverAll_Orgs']) && isset($arrParams['overAllSeenTargetOrgs'])) {
            $targetseen_orgs = explode(",", $arrParams['allseenOverAll_Orgs']);
            $allseen_orgs = explode(",", $arrParams['overAllSeenTargetOrgs']);
            $OrgidExploded = array_diff($targetseen_orgs,$allseen_orgs);
        }
        if (isset($arrParams['target_orgs']) && isset($arrParams['overAllSeenTargetOrgs'])) {
            $targetseen_orgs = explode(",", $arrParams['overAllSeenTargetOrgs']);
            $target_orgs = explode(",", $arrParams['target_orgs']);
            $OrgidExploded = array_diff($target_orgs, $targetseen_orgs);
        }
        foreach ($OrgidExploded as $key => $value) {
           $arrReturnData 				= array();
		$this->db->select('organizations.*,specialties.specialty as specialty_name,countries.Country,regions.Region,cities.City',false);
//		if(!empty($value)){
			$this->db->where('organizations.id',$value);
//		}
                $this->db->join('specialties', 'organizations.specialty = specialties.id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
		$this->db->join('regions','RegionId = state_id','left');
		$this->db->join('cities','cityId = city_id','left');
                if (!empty($Details['name']))
                    $this->db->like('organizations.name', $Details['name']);  
                if (!empty($Details['Region']))
                    $this->db->like('regions.Region', $Details['Region']);  
                if (!empty($Details['City']))
                    $this->db->like('cities.City', $Details['City']);  
                if (!empty($Details['phone']))
                    $this->db->like('organizations.phone', $Details['phone']);  
                if (!empty($Details['specialty_name']))
                    $this->db->like('specialties.specialty', $Details['specialty_name']);  
		$this->db->order_by('organizations.id','desc');
		$arrOrgResultSet		= $this->db->get('organizations');
//		echo $this->db->last_query(); 
		foreach($arrOrgResultSet->result_array() as $row){
                      if (!empty($Details['isexcel'])){
                                      
                                 $arrOrgDetailRes[]	= $row;
                                      
                                 }else{
			$arrReturnData	= $row;
                        
                if (IS_IPAD_REQUEST) {
                    $arrReturnData['name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/organizations/view/' . $arrReturnData['id'] . '">' . $arrReturnData['name'] . '</a>';
                } else {
                    $arrReturnData['name'] = '<a target="_NEW" href="' . base_url() . 'organizations/view/' . $arrReturnData['id'] . '">' . $arrReturnData['name'] . '</a>';
                }
		}
                }
                 if (empty($Details['isexcel']))
          $arrOrgDetailRes[]=$arrReturnData;
          
        }
        
       return $arrOrgDetailRes;
    }
    
    
    function  customerSeenOverAllSeen($data){
        $this->db->query('SET SESSION group_concat_max_len = 1000000');
        $arrCustomer = array();
        $users=$this->common_helpers->getManagerAlignedUsers($data['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('client_users.id, client_users.is_activated, client_users.first_name, 
	client_users.last_name, groups .group_name,
        COUNT(DISTINCT interactions_attendees.kol_id) AS allseenOverAll,
       
        GROUP_CONCAT(DISTINCT interactions_attendees.kol_id) AS allseenOverAll_kols',false);
        $this->db->join('interactions', 'client_users.id = interactions.employee_id', 'left');
        $this->db->join('interactions_attendees', 'interactions.id=interactions_attendees.interaction_id', 'left');
       
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
     
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        
        if (!empty($data['msl'])) {
            $this->db->where_in("client_users.id", $data['msl']);
        }
        if (!empty($data['team'])) {
            $this->db->where_in('user_groups.group_id ', $data['team']);
        }
        if (!empty($data['manager_id'])) { 
               $this->db->where_in("client_users.id", $users);
        }
         if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('client_users.id', $userIds);
       }
        $this->db->group_by('client_users.id');
        $arrResult = $this->db->get('client_users');
        foreach ($arrResult->result_array() as $arrResultCustomer) {
            $arrCustomer[$arrResultCustomer['id']] = $arrResultCustomer;
        }
        return $arrCustomer;
    }
    
    
     function  institutionSeenOverAllSeen($data){
        $this->db->query('SET SESSION group_concat_max_len = 1000000');
        $arrCustomer = array();
        $users=$this->common_helpers->getManagerAlignedUsers($data['manager_id']);
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('client_users.id, client_users.is_activated, client_users.first_name, 
	client_users.last_name, groups .group_name,
        COUNT(DISTINCT interactions_attendees.org_id) AS allseenOverAll,
       
        GROUP_CONCAT(DISTINCT interactions_attendees.org_id) AS allseenOverAll_Orgs',false);
        $this->db->join('interactions', 'client_users.id = interactions.employee_id', 'left');
        $this->db->join('interactions_attendees', 'interactions.id=interactions_attendees.interaction_id', 'left');
       
        $this->db->join('user_groups', 'client_users.id = user_groups.user_id', 'left');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');

        $this->db->where("(groups.group_type = 'Team' OR groups.group_type IS NULL)");
     
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        
        if (!empty($data['msl'])) {
            $this->db->where_in("client_users.id", $data['msl']);
        }
        if (!empty($data['team'])) {
            $this->db->where_in('user_groups.group_id ', $data['team']);
        }
        if (!empty($data['manager_id'])) { 
               $this->db->where_in("client_users.id", $users);
        }
         if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('client_users.id', $userIds);
       }
        $this->db->group_by('client_users.id');
        $arrResult = $this->db->get('client_users');
        foreach ($arrResult->result_array() as $arrResultInstitution) {
            $arrInstitution[$arrResultInstitution['id']] = $arrResultInstitution;
        }
        return $arrInstitution;
    }
    function getUsersToAccessReports(){
    	$clientId	= $this->session->userdata('client_id');
    	$this->db->select('user_groups.user_id');
    	$this->db->join('user_groups', 'groups.group_id = user_groups.group_id', 'left');
    	$this->db->where('groups.group_type', 'group');
    	$this->db->where('groups.group_name', 'AnalyticsReports');
	    	if ($clientId !== INTERNAL_CLIENT_ID){
	    		$this->db->join('client_users', 'user_groups.user_id = client_users.id', 'left');
	    		$this->db->where('client_users.client_id', $clientId);
	    	}
    	$arrResult = $this->db->get('groups');
    	foreach ($arrResult->result_array() as $arrUsersIds) {
    		$arrUsers[] = $arrUsersIds['user_id'];
    	}
    	return $arrUsers;
    }
    function getListOfRestrictedUsers(){
    	$group_name = 'RestrictedUsers';
    	$this->db->select('user_groups.user_id');
    	$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'join');
    	$this->db->where("groups.group_name",$group_name);
    	$res = $this->db->get('user_groups');
    	if (is_object($res) && $res->num_rows() > 0) {
    		foreach ($res->result_array() as $key => $value){
    			$arrUserIds[$key] = $value['user_id'];
    		}
    	}
    	return $arrUserIds;
    }
    function getAllUsersOfClient($clientId, $arrFilters, $limit, $start, $sidx, $sord, $where=''){
    	$restricted_users = $this->getListOfRestrictedUsers();
    	$clientId	= $this->session->userdata('client_id');
    	$this->db->select("client_users.id, CONCAT(client_users.first_name, ' ', client_users.last_name) as primary_user_name, CONCAT(cu1.first_name, ' ', cu1.last_name) as secondary_level_user, countries.GlobalRegion as GlobalRegion, client_users.created_on, client_users.user_last_login, client_users.status", false);
    	if ($arrFilters['division_id'] != '' && $arrFilters['division_id'] != 0) {
    		$this->db->join('user_groups', 'user_groups.user_id = client_users.id', 'join');
    		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'join');
    		$this->db->join('countries', 'groups.group_name = countries.GlobalRegion', 'join');
    		$this->db->where_in("groups.group_name", $arrFilters['division_id']);
    	}else{
    		//$this->db->join('user_groups', 'user_groups.user_id = client_users.id', 'left');
    		$this->db->join('(SELECT ug.group_id as user_requests_tbl_id, ug.user_id  from user_groups ug 
          	LEFT JOIN groups gps ON ug.group_id = gps.group_id
			JOIN countries cs ON gps.group_name = cs.GlobalRegion) as user_requests_tbl', 'user_requests_tbl.user_id = client_users.id', 'left');
    		$this->db->join('groups', 'user_requests_tbl.user_requests_tbl_id = groups.group_id', 'left');
    		$this->db->join('countries', 'groups.group_name = countries.GlobalRegion', 'left');
    	}
    	$this->db->join('client_users cu1', 'client_users.manager_id = cu1.id', 'left');
    	
    	if ($arrFilters['manager_id'] != '' && $arrFilters['manager_id'] != 0) {
    		$this->db->where_in("cu1.id", $arrFilters['manager_id']);
    	}
    	
    	/*
    	 * This is to get data for grid filter search
    	 */
    	if(isset($where['user_name'])){
    		$this->db->like("concat(client_users.first_name,' ',client_users.last_name)", $where['user_name']);
    	}
    	if(isset($where['manager'])){
    		$this->db->like("concat(cu1.first_name,' ',cu1.last_name)", $where['manager']);
    	}
    	if(isset($where['division'])){
    		$this->db->like("countries.GlobalRegion", $where['division']);
    	}
    	if(isset($where['registered'])){
    		$this->db->like("DATE_FORMAT(client_users.created_on,'%m/%d/%Y')", $where['registered']);
    	}
    	//print_r($where);
    	if(isset($where['user_status'])){
    		$status = str_split($where['user_status']);
    		if($status[0] == 'n'){
    			$user_status = "> 0";
    		}else{
    			$user_status = "= 0";
    		}
    		$this->db->where("client_users.status ".$user_status);
    	} 
    	
    	if ($clientId != INTERNAL_CLIENT_ID) {
    		if($restricted_users != '' && $restricted_users != 0)
    			$this->db->where_not_in("client_users.id", $restricted_users);
    		
    		$this->db->where("client_users.client_id", $clientId);
    	}
    	$this->db->group_by("client_users.id");
    	$this->db->order_by("client_users.user_last_login", 'desc');
 //   	$this->db->where("client_users.user_role_id", 1);
    	$arrResult = $this->db->get('client_users');
    	/* print_r($this->db->last_query());
    	exit; */
    	/* foreach ($arrResult->result_array() as $arrResultUserDetails) {
    		$arrUserDetails[$arrResultUserDetails['id']] = $arrResultUserDetails;
    	}
    	return $arrUserDetails; */
    	return $arrResult->result_array();
    }
function userTotalLoginCount($userId, $arrFilters){
    	$this->db->select('count(log_activities.id) as login_count', false);
    	$this->db->where("((log_activities.module = 'login' OR log_activities.controller = 'login') AND (log_activities.controller != 'logout' OR log_activities.controller != 'login_failed'))");
    	$this->db->where("log_activities.created_by", $userId);
    	$this->db->where("log_activities.transaction_name", 'login');
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$this->db->where("log_activities.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("log_activities.created_on", $startDate);
    	}
    	$loggedInuserClientId = $this->session->userdata('client_id');
    	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
    		$this->db->join('client_users', 'log_activities.created_by = client_users.id', 'join');
    	    $this->db->where("client_users.client_id", $loggedInuserClientId);
    	}
    	$loginCountResult = $this->db->get('log_activities');
    	$result = $loginCountResult->result();
    	return $result[0]->login_count;
    }
    function userTotalKolAccess($userId, $arrFilters, $doCount){
    	if($doCount == true){
    	$this->db->select('count(DISTINCT kols.id) as totalktlaccess', false);
    	//$this->db->join('kols', 'log_activities.method = kols.id OR log_activities.method = kols.unique_id', 'left');
    	$this->db->join('kols', 'log_activities.miscellaneous2 = kols.id', 'left');
    	}else{
    	//$this->db->join('kols', 'log_activities.method = kols.id OR log_activities.method = kols.unique_id', 'left');
    	$this->db->join('kols', 'log_activities.miscellaneous2 = kols.id', 'left');
    	$this->db->select('DISTINCT(kols.id) as kolId, CONCAT(kols.first_name,"\, ",kols.last_name) as kol_name, specialties.specialty, countries.Country', false);
    	$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
    	$this->db->join('countries', 'kols.country_id = countries.CountryId', 'left');
    	}
    	$this->db->where("log_activities.created_by", $userId);
    	/* $this->db->where("log_activities.module", 'kols');
    	$this->db->where("log_activities.controller", 'view'); */
    	$this->db->where("log_activities.miscellaneous1", 'kols');
    	$this->db->where("kols.id >0");
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$this->db->where("log_activities.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("log_activities.created_on", $startDate);
    	}
    	$loggedInuserClientId = $this->session->userdata('client_id');
    	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
    		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
    		$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
    	}
    	
    	$arrResult = $this->db->get('log_activities');
    	if($doCount == true){
    		$result = $arrResult->result();
    		return $result[0]->totalktlaccess;
    	}else{
    		return $arrResult->result();
    	}
    }
    function userTotalPaymentCreated($userId, $arrFilters){
    	$this->db->select('count(id) as totalpayments', false);
    	$this->db->where("created_by", $userId);
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$this->db->where("payments.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("payments.created_on", $startDate);
    	}
    	$arrResult = $this->db->get('payments');
    	$result = $arrResult->result();
    	return $result[0]->totalpayments;
    }
    function userTotalInteractionCreated($userId, $arrFilters){
    	$this->db->select('count(id) as totalinteractions', false);
    	$this->db->where("created_by", $userId);
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$arrFilters['end_date'] = date("Y-m-d",strtotime("-1 day", strtotime($arrFilters['end_date'])));
    		$this->db->where("interactions.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("interactions.created_on", $startDate);
    	}
    	$arrResult = $this->db->get('interactions');
    	$result = $arrResult->result();
    	return $result[0]->totalinteractions;
    }
    function userTotalContractsCreated($userId, $arrFilters){
    	$this->db->select('count(id) as totalcontracts', false);
    	$this->db->where("created_by", $userId);
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$this->db->where("contracts.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("contracts.created_on", $startDate);
    	}
    	$arrResult = $this->db->get('contracts');
    	$result = $arrResult->result();
    	return $result[0]->totalcontracts;
    }
    function userTotalPlansCreated($userId, $arrFilters){
    	$this->db->select('count(id) as totalplans', false);
    	$this->db->where("created_by", $userId);
    	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
    		$this->db->where("plan_details.created_at BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
    	}else if ($startDate != null) {
    		$this->db->like("plan_details.created_at", $startDate);
    	}
    	$arrResult = $this->db->get('plan_details');
    	$result = $arrResult->result();
    	return $result[0]->totalplans;
    }
    function getAllKolsAnalyticsReport($clientId, $arrFilters, $limit, $startFrom, $doCount=null, $sidx='', $sord ='', $where=''){
    	$restricted_users = $this->getListOfRestrictedUsers();
    	$clientId	= $this->session->userdata('client_id');
    	$loggedInuserClientId	= $clientId;
    	$condition = '';
    	if($doCount){
    		$this->db->select("COUNT(DISTINCT(kols.id)) AS numrows");
    	}else{
    	$this->db->select("user_requests.kol_id, kols.id, kols.unique_id, CONCAT(kols.last_name, '\, ', kols.first_name, ' ', kols.middle_name) as ktl_name, countries.GlobalRegion as ktl_region,
    			 kols.profile_type as ktl_profile_type, client_users.client_id as user_client_id, CONCAT(client_users.first_name, ' ', client_users.last_name) as created_by, kols.created_on as created_on, kols.modified_on as last_updated, CONCAT(cu1.first_name, ' ', cu1.last_name) as request_by, 
    			user_requests.requested_on as last_requested, user_requests.status, CONCAT(cu2.first_name, ' ', cu2.last_name) as approve_by, user_requests.rej_or_appr_on as approve_on", false);
    	}
    	$this->db->join('countries', 'kols.country_id = countries.CountryId', 'left');
    	$this->db->join('client_users', 'kols.created_by = client_users.id', 'left');
    	
    	
    	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
    		$condition .= "JOIN client_users cu_ur ON cu_ur.id=user_requests.requested_by";
    		$condition .= " WHERE cu_ur.client_id = ".$loggedInuserClientId;
    		if($restricted_users != '' && $restricted_users != 0){
    			$seperator = '';
    			foreach($restricted_users as $row){
    				$restrictedUsers .= $seperator."'".$row."'";
    				$seperator = ',';
    			}
    			$condition .= " AND cu_ur.id NOT IN (".$restrictedUsers.")";
    		}
    	}
    	
    	if($arrFilters['request_for']==1){
    		$this->db->join('(select max(user_requests.id) as request_id,user_requests.kol_id from user_requests '.$condition.' group by kol_id) as user_requests_tbl', 'kols.id = user_requests_tbl.kol_id', 'left');
    		$this->db->join('user_requests', 'user_requests.id=user_requests_tbl.request_id');
    	}else{
    		$this->db->join('(select max(user_requests.id) as request_id,kol_id from user_requests '.$condition.' group by kol_id) as user_requests_tbl', 'kols.id = user_requests_tbl.kol_id', 'left');
    		$this->db->join('user_requests', 'user_requests.id=user_requests_tbl.request_id', 'left outer');
    	}
    	
    	$this->db->join('client_users cu1', 'user_requests.requested_by = cu1.id', 'left outer');
    	$this->db->join('client_users cu2', 'user_requests.rej_or_appr_by = cu2.id', 'left outer');
    	
   		/* if($arrFilters ['end_date'] != null && $arrFilters ['start_date'] != null) {
			$this->db->where ("((kols.modified_on BETWEEN '".$arrFilters['start_date']."' AND '".$arrFilters['end_date']."') OR 
(kols.modified_on='0000-00-00' AND kols.created_on BETWEEN '".$arrFilters['start_date']."' AND '".$arrFilters['end_date']."'))" );
		} elseif($arrFilters['start_date'] != null) {
			$this->db->like("kols.modified_on", $arrFilters['start_date']);
		} */
    	
    	if ($arrFilters['kol_id'] != '' && $arrFilters['kol_id'] != 0) {
    		$this->db->where("kols.id", $arrFilters['kol_id']);
    	}
    	if ($arrFilters['division_id'] != '' && $arrFilters['division_id'] != 0) {
    		$this->db->where_in("countries.GlobalRegion", $arrFilters['division_id']);
    	}
    	if ($arrFilters['profile_type'] != '' && $arrFilters['profile_type'] != 0) {
    		$this->db->where_in("kols.profile_type", $arrFilters['profile_type']);
    	}
    	if ($arrFilters['reuqest_user_id'] != '' && $arrFilters['reuqest_user_id'] != 0) {
    		$this->db->where_in("user_requests.requested_by", $arrFilters['reuqest_user_id']);
    	}
    	if ($arrFilters['approved_user_id'] != '' && $arrFilters['approved_user_id'] != 0) {
    		$this->db->where_in("user_requests.rej_or_appr_by", $arrFilters['approved_user_id']);
    	}
    	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
    		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
    		$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
    	}
    	/*
    	 * This is to get data for grid filter search
    	 */
    	if(isset($where['ktl_name'])){
    		$this->db->like("concat(kols.first_name,' ',kols.last_name)", $where['ktl_name']);
    	}
    	if(isset($where['ktl_region'])){
    		$this->db->like("countries.GlobalRegion", $where['ktl_region']);
    	}
    	if(isset($where['ktl_profile_type'])){
    		$this->db->like("kols.profile_type", $where['ktl_profile_type']);
    	}
    	if(isset($where['created_by'])){
    		$this->db->like("concat(client_users.first_name,' ',client_users.last_name)", $where['created_by']);
    	}
    	if(isset($where['created_on'])){
    		$this->db->like("DATE_FORMAT(kols.created_on,'%m/%d/%Y')", $where['created_on']);
    	}
    	if(isset($where['last_updated'])){
    		$this->db->where("(DATE_FORMAT(kols.modified_on,'%m/%d/%Y')  LIKE '%".$where['last_updated']."%' OR DATE_FORMAT(kols.created_on,'%m/%d/%Y')  LIKE '%".$where['last_updated']."%')");
    	}
    	if(isset($where['approve_on'])){
    		$this->db->like("DATE_FORMAT(user_requests.rej_or_appr_on,'%m/%d/%Y')", $where['approve_on']);
    	}
    	if(isset($where['request_by'])){
    		$this->db->like("concat(cu1.first_name, ' ', cu1.last_name)", $where['request_by']);
    	}
    	if(isset($where['last_requested'])){
    		$this->db->like("DATE_FORMAT(user_requests.requested_on,'%m/%d/%Y')", $where['last_requested']);
    	}
    	if(isset($where['status'])){
    		$this->db->like("user_requests.status", $where['status']);
    	}
    	if(isset($where['approve_by'])){
    		$this->db->like("concat(cu2.first_name, ' ', cu2.last_name)", $where['approve_by']);
    	}
    	if(isset($where['last_requested'])){
    		$this->db->like("DATE_FORMAT(user_requests.requested_on,'%m/%d/%Y')", $where['last_requested']);
    	}
  
    	if ($sidx != '' && $sord != ''){
    		switch ($sidx) {
    			case 'ktl_name':
    				$this->db->order_by("kols.first_name", $sord);
    				break;
    			case 'ktl_region':
    				$this->db->order_by("countries.GlobalRegion", $sord);
    				break;
    			case 'ktl_profile_type' :
    				$this->db->order_by("kols.profile_type", $sord);
    				break;
    			case 'created_by':
    				$this->db->order_by("client_users.first_name", $sord);
    				break;
    			case 'created_on':
    				$this->db->order_by("kols.created_on", $sord);
    				break;
    			case 'request_by':
    				$this->db->order_by("cu1.first_name", $sord);
    				break;
    			case 'last_requested':
    				$this->db->order_by("user_requests.requested_on", $sord);
    				break;
    			case 'status':
    				$this->db->order_by("user_requests.status", $sord);
    				break;
    			case 'approve_by':
    				$this->db->order_by("cu2.first_name", $sord);
    				break;
    			case 'approve_on':
    				$this->db->order_by("user_requests.rej_or_appr_on", $sord);
    				break;
    		}
    		// $this->db->order_by($sidx,$sord);
    	}else{
    		$this->db->order_by("kols.modified_on", 'desc');
    	}
    	if ($doCount){
    		$arrResult = $this->db->get('kols');
    		$count = $arrResult->result();
    		return $count[0]->numrows;
    	}else{
    		$this->db->group_by('kols.id');
    		$arrResult = $this->db->get('kols',$limit,$startFrom);
    		//pr($this->db->last_query());exit;
    		/*
    		 * foreach ($arrResult->result_array() as $arrResultKolsDetails) {
    		 * if ($arrResultKolsDetails ['user_client_id'] === INTERNAL_CLIENT_ID) {
    		 * $arrResultKolsDetails ['created_by'] = 'Aissel Analyst';
    		 * }
    		 * $arrKolsDetails[$arrResultKolsDetails['id']] = $arrResultKolsDetails;
    		 * }
    		 * return $arrKolsDetails;
    		 */
    		return $arrResult->result_array();
    	}
    }
    
    function userTotalAccessKtl($ktlId,$uniqueId, $arrFilters, $doCountUser){
    	$restricted_users = $this->getListOfRestrictedUsers();
    	if($doCountUser == true){
    		$this->db->select('count(DISTINCT(log_activities.created_by)) as totalCount');
    		$this->db->join('client_users', 'log_activities.created_by = client_users.id', 'join');
    	}else{
    		
    		$this->db->select("DISTINCT(log_activities.created_by) as user_id, CONCAT(client_users.first_name,' ',client_users.last_name) as user_name,
CONCAT(cu1.first_name,' ',cu1.last_name) as manager_name, countries.GlobalRegion as division", false);
    		$this->db->join('client_users', 'log_activities.created_by = client_users.id', 'join');
    		$this->db->join('client_users cu1', 'client_users.manager_id = cu1.id', 'left');
    		$this->db->join('countries', 'client_users.country = countries.CountryId', 'left');
    		
    	}
    	/* $this->db->where("(log_activities.module = 'kols' or log_activities.module = 'i' or log_activities.module = 'm')");
    	$this->db->where("(log_activities.controller = 'view' or log_activities.controller = 'kols')");
    	$this->db->where("((log_activities.method = '".$ktlId."' or log_activities.method = '".$uniqueId."') or
  log_activities.method = 'view')");
    	$this->db->where("((log_activities.param = '/kols/view/".$ktlId."' or log_activities.param = '/kols/view/".$uniqueId."') or (log_activities.param = '/i/kols/view/".$ktlId."' or log_activities.param = '/i/kols/view/".$uniqueId."')
 or (param = '/m/kols/view/".$ktlId."' or log_activities.param = '/m/kols/view/".$uniqueId."'))"); */
    	$this->db->where("log_activities.miscellaneous1", 'kols');
    	$this->db->where("log_activities.miscellaneous2", $ktlId);
    	$this->db->where('log_activities.created_by > 0');
    	if($arrFilters['end_date'] != null && $arrFilters['start_date'] != null){
    		$this->db->where("log_activities.created_on BETWEEN '".$arrFilters['start_date']."' AND '".$arrFilters['end_date']."'");
    	}else if ($startDate != null) {
    		$this->db->like("log_activities.created_on", $startDate);
    	}
    	$loggedInuserClientId	= $this->session->userdata('client_id');
    	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
    		if($restricted_users != '' && $restricted_users != 0)
    			$this->db->where_not_in("client_users.id", $restricted_users);
    		
    	    $this->db->where("client_users.client_id", $loggedInuserClientId);
    	}
    	$arrResult = $this->db->get('log_activities');
    	if($doCountUser == true){
    	$totalCount = $arrResult->result();
    		return $totalCount[0]->totalCount;
    	}else{
    		return $arrResult->result();
    	}
    }
    
   function getListOfAllManagerAnalytics(){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$clientId	= $this->session->userdata('client_id');
   	$this->db->select('client_users.id,client_users.first_name,client_users.last_name,client_users.email,client_users.user_name');
   	$this->db->where_in('client_users.user_role_id', array(ROLE_MANAGER,ROLE_ADMIN,ROLE_READONLY_USER));
	   	if ($clientId != INTERNAL_CLIENT_ID) {
	   		if($restricted_users != '' && $restricted_users != 0)
	   			$this->db->where_not_in("client_users.id", $restricted_users);
	   		$this->db->where("client_users.client_id", $clientId);
	   	}
	$arrResult = $this->db->get('client_users');
	foreach ($arrResult->result_array() as $arrResultAllManagerAnalyticsDetails) {
		$arrManagerDetails[$arrResultAllManagerAnalyticsDetails['id']] = $arrResultAllManagerAnalyticsDetails;
	}
	return $arrManagerDetails;
	
   } 
   function getListOfAllDivisionAnalytics(){
   	$clientId	= $this->session->userdata('client_id');
   	$this->db->select('countries.GlobalRegion');
   	$this->db->join('countries', 'client_users.country = countries.CountryId', 'left');
   	$this->db->join('groups', 'groups.group_name = countries.GlobalRegion', 'join');
   	if ($clientId != INTERNAL_CLIENT_ID) {
   		$this->db->where("client_users.client_id", $clientId);
   	}
   	$this->db->group_by('countries.GlobalRegion');
   	$arrResult = $this->db->get('client_users');
   	foreach ($arrResult->result_array() as $arrResultAllDivisionAnalyticsDetails) {
   		$arrDivisionDetails[] = $arrResultAllDivisionAnalyticsDetails;
   	}
   	return $arrDivisionDetails;
   	
   }
   function getListOfAllRequestedUsers(){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$clientId	= $this->session->userdata('client_id');
   	$this->db->select('client_users.id, client_users.first_name, client_users.last_name');
   	$this->db->join('client_users', 'client_users.id = user_requests.requested_by', 'left');
   	if ($clientId != INTERNAL_CLIENT_ID) {
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("client_users.id", $restricted_users);
   		
   		$this->db->where("client_users.client_id", $clientId);
   	}
   	$this->db->group_by("user_requests.requested_by");
   	$arrResult = $this->db->get('user_requests');
   	foreach ($arrResult->result_array() as $arrResultAllRequestedUsersDetails) {
   		$arrAllRequestedUsersDetails[$arrResultAllRequestedUsersDetails['id']] = $arrResultAllRequestedUsersDetails;
   	}
   	return $arrAllRequestedUsersDetails;
   }
   function getListOfAllApprovedUsers(){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$clientId	= $this->session->userdata('client_id');
   	$this->db->select('client_users.id, client_users.first_name, client_users.last_name');
   	$this->db->join('client_users', 'client_users.id = user_requests.rej_or_appr_by', 'left');
   	if ($clientId != INTERNAL_CLIENT_ID) {
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("client_users.id", $restricted_users);
   			 
   		$this->db->where("client_users.client_id", $clientId);
   	}
   	$this->db->group_by("user_requests.rej_or_appr_by");
   	$arrResult = $this->db->get('user_requests');
   	foreach ($arrResult->result_array() as $arrResultAllApprovedUsersDetails) {
   		$arrAllApprovedUsersDetails[$arrResultAllApprovedUsersDetails['id']] = $arrResultAllApprovedUsersDetails;
   	}
   	return $arrAllApprovedUsersDetails;
   }
   function ktlTotalPaymentCreated($ktlId, $arrFilters){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$this->db->select('count(payments.id) as totalpayments', false);
   	$this->db->where("kol_id", $ktlId);
   	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
   		$this->db->where("payments.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
   	}else if ($startDate != null) {
   		$this->db->like("payments.created_on", $startDate);
   	}
   	$loggedInuserClientId	= $this->session->userdata('client_id');
   	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
   		$this->db->join('client_users', 'payments.created_by = client_users.id', 'left');
   		$this->db->where("client_users.client_id", $loggedInuserClientId);
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("payments.created_by", $restricted_users);
   	}
   	
   	$arrResult = $this->db->get('payments');
   	$result = $arrResult->result();
   	return $result[0]->totalpayments;
   }
   function ktlTotalInteractionCreated($ktlId, $arrFilters){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$this->db->select('count(interactions_attendees.id) as totalinteractions', false);
   	$this->db->where("kol_id", $ktlId);
   	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
   		$arrFilters['end_date'] = date("Y-m-d",strtotime("-1 day", strtotime($arrFilters['end_date'])));
   		$this->db->join("interactions", "interactions_attendees.interaction_id = interactions.id", "left");
   		$this->db->where("interactions.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
   	}else if ($startDate != null) {
   		$this->db->join("interactions", "interactions_attendees.interaction_id = interactions.id", "left");
   		$this->db->like("interactions.created_on", $startDate);
   	}
   	$loggedInuserClientId	= $this->session->userdata('client_id');
   	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
   		$this->db->join('client_users', 'interactions.created_by = client_users.id', 'left');
   		$this->db->where("client_users.client_id", $loggedInuserClientId);
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("interactions.created_by", $restricted_users);
   	}
   	
   	$arrResult = $this->db->get('interactions_attendees');
   	$result = $arrResult->result();
   	return $result[0]->totalinteractions;
   }
   function ktlTotalContractsCreated($ktlId, $arrFilters){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$this->db->select('count(contracts.id) as totalcontracts', false);
   	$this->db->where("kol_id", $ktlId);
   	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
   		$this->db->where("contracts.created_on BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
   	}else if ($startDate != null) {
   		$this->db->like("contracts.created_on", $startDate);
   	}
   	$loggedInuserClientId	= $this->session->userdata('client_id');
   	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
   		$this->db->join('client_users', 'contracts.created_by = client_users.id', 'left');
   		$this->db->where("client_users.client_id", $loggedInuserClientId);
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("contracts.created_by", $restricted_users);
   	}
   	
   	$arrResult = $this->db->get('contracts');
   	$result = $arrResult->result();
   	return $result[0]->totalcontracts;
   }
   function ktlTotalPlansCreated($ktlId, $arrFilters){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$this->db->select('count(plan_profiles.id) as totalplans', false);
   	$this->db->where("kol_id", $ktlId);
   	if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
   		$this->db->where("plan_profiles.created_at BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
   	}else if ($startDate != null) {
   		$this->db->like("plan_profiles.created_at", $startDate);
   	}
   	$loggedInuserClientId	= $this->session->userdata('client_id');
   	if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
   		$this->db->join('client_users', 'plan_profiles.user_id = client_users.id', 'left');
   		$this->db->where("client_users.client_id", $loggedInuserClientId);
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("plan_profiles.user_id", $restricted_users);
   	}
   	$arrResult = $this->db->get('plan_profiles');
   	$result = $arrResult->result();
   	return $result[0]->totalplans;
   }
   function getLastUpdated($kolId){
	   	$this->db->select('user_added_on');
	   	$this->db->where("kol_id", $kolId);
	   	$this->db->where("status", '2');
	   	$arrResult = $this->db->get('kol_update_status');
	   	$result = $arrResult->result();
	   	return $result[0]->user_added_on;
   }
   function transtionMonths($arrFilters) {
   	 $this->db->select('MONTHNAME(`created_on`) AS month, EXTRACT(YEAR FROM `created_on`)  AS year, EXTRACT(YEAR_MONTH FROM `created_on`) as monthYear', false);
   	 if($arrFilters['month']!='null' && isset($arrFilters['month'] ) && sizeof($arrFilters['month']) > 0){
   	 	$this->db->where_in('MONTH(created_on)', $arrFilters['month']);
   	 }
   	 if($arrFilters['year']!=''){
   	 	$this->db->where('YEAR(created_on)', $arrFilters['year']);
   	 }
   	 $this->db->group_by('month, year');
   	 $resultClient = $this->db->get('client_users');
   	 
   	 $this->db->select('MONTHNAME(`requested_on`) AS month, EXTRACT(YEAR FROM `requested_on`)  AS year, EXTRACT(YEAR_MONTH FROM `requested_on`) as monthYear', false);
   	 if($arrFilters['month']!='null' && isset($arrFilters['month'] ) && sizeof($arrFilters['month']) > 0){
   	 	$this->db->where_in('MONTH(requested_on)', $arrFilters['month']);
   	 }
   	 if($arrFilters['year']!=''){
   	 	$this->db->where('YEAR(requested_on)', $arrFilters['year']);
   	 }
   	 $this->db->group_by('month, year');
   	 $resultLogActivities = $this->db->get('user_requests');

   	 $this->db->select('MONTHNAME(`created_on`) AS month, EXTRACT(YEAR FROM `created_on`)  AS year, EXTRACT(YEAR_MONTH FROM `created_on`) as monthYear', false);
   	 if($arrFilters['month']!='null' && isset($arrFilters['month'] ) && sizeof($arrFilters['month']) > 0){
   	 	$this->db->where_in('MONTH(created_on)', $arrFilters['month']);
   	 }
   	 if($arrFilters['year']!=''){
   	 	$this->db->where('YEAR(created_on)', $arrFilters['year']);
   	 }
   	 $this->db->group_by('month, year');
   	 $resultRequest = $this->db->get('log_activities');
   	 
   	 $this->db->select('MONTHNAME(`created_on`) AS month, EXTRACT(YEAR FROM `created_on`)  AS year, EXTRACT(YEAR_MONTH FROM `created_on`) as monthYear', false);
   	 if($arrFilters['month']!='null' && isset($arrFilters['month'] ) && sizeof($arrFilters['month']) > 0){
   	 	$this->db->where_in('MONTH(created_on)', $arrFilters['month']);
   	 }
   	 if($arrFilters['year']!=''){
   	 	$this->db->where('YEAR(created_on)', $arrFilters['year']);
   	 }
   	 $this->db->group_by('month, year');
   	 $resultKols = $this->db->get('kols');

   	$listMonth = array ();
   	foreach ( $resultClient->result () as $row ) {
   		if ($row->month != null) {
   			$listMonth [] = $row->monthYear;
   		}
   	}
   	//pr($listMonth);
   	foreach ( $resultKols->result () as $row ) {
   		if ($row->month != null) {
   			$value = $row->monthYear;
   			if (! in_array ( $value, $listMonth )) {
   				$listMonth [] = $row->monthYear;
   			}
   		}
   	}
   	//pr($listMonth);
   	foreach ( $resultLogActivities->result () as $row ) {
   		if ($row->month != null) {
   			$value = $row->monthYear;
   			if (! in_array ( $value, $listMonth )) {
   				$listMonth [] = $row->monthYear;
   			}
   		}
   	}
   	//pr($listMonth);
   	foreach ( $resultRequest->result () as $row ) {
   		if ($row->month != null) {
   			$value = $row->monthYear;
   			if (! in_array ( $value, $listMonth )) {
   				$listMonth [] = $row->monthYear;
   			}
   		}
   	}
   	return $listMonth;
   }
   function getAllUserCountGlobalRegion() {
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$clientId	= $this->session->userdata('client_id');
   	$this->db->select('count(DISTINCT client_users.id) as totalUser, groups.group_name as GlobalRegion', false);
   	$this->db->join('user_groups', 'user_groups.user_id = client_users.id', 'join');
   	$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'join');
   	$this->db->join('countries', 'groups.group_name = countries.GlobalRegion', 'join');
   	
   	if ($clientId != INTERNAL_CLIENT_ID) {
   		if($restricted_users != '' && $restricted_users != 0)
   			$this->db->where_not_in("client_users.id", $restricted_users);
   		
   		$this->db->where("client_users.client_id", $clientId);
   		$this->db->where("client_users.status", '0');
   	}
   	$this->db->group_by('groups.group_name');
   	$arrResult = $this->db->get('client_users');
   	foreach ( $arrResult->result_array() as $arrResultAllUserCountGlobalRegionDetails) {
   		$arrAllApprovedUsersDetails[] = $arrResultAllUserCountGlobalRegionDetails;
   	}
   	return $arrAllApprovedUsersDetails;
   }
   
   function getPowerUsersCountGlobalRegion(){
   	$restricted_users = $this->getListOfRestrictedUsers();
   	$clientId	= $this->session->userdata('client_id');
   	if ($clientId !== INTERNAL_CLIENT_ID){
   		$conditionJoinInternalClient .= " WHERE client_users.client_id = ".$clientId;
   		if($restricted_users != '' && $restricted_users != 0){
	   		$seperator = '';
	   		foreach($restricted_users as $row){
	   			$restrictedUsers .= $seperator."'".$row."'";
	   			$seperator = ',';
	   		}
	   		$conditionJoinInternalClient .= " AND client_users.id NOT IN (".$restrictedUsers.")";
	   	}
   	}
   	$queryPowerUsers = "SELECT SUM(
		CASE WHEN
   		(user_role_id = ".ROLE_ADMIN."  AND status = 0)
		THEN 1
		ELSE 0
		END) AS Global_Admin,
		SUM(
		CASE WHEN
   		(user_role_id = ".ROLE_READONLY_USER."  AND status = 0)		
		THEN 1
		ELSE 0
		END) AS Read_Only,
   		SUM(
		CASE WHEN
   		(status > 0)		
		THEN 1
		ELSE 0
		END) AS Inactive,	
		SUM(
		CASE WHEN
   		(user_role_id != ".ROLE_ADMIN." AND user_role_id != ".ROLE_READONLY_USER." AND status = 0)		
		THEN 1
		ELSE 0
		END) AS Others
		FROM client_users".$conditionJoinInternalClient;
   	
   	$resultPowerUsers = $this->db->query($queryPowerUsers);
   	foreach ( $resultPowerUsers->result_array() as $row) {
   		$arrAllPowerUsersDetails[] = $row;
   	}
   	return $arrAllPowerUsersDetails;
   }
   
function getSummaryReport($date, $arrFilters = false){
		$restricted_users = $this->getListOfRestrictedUsers();
		$clientId = $this->session->userdata('client_id');
		$arrOverAllResult = array();
		$clientSpecific = '';
		$conditionJoinClientCountry = '';
		$conditionJoinKolCountry = '';
		$conditionJoinKolInternal = '';
		$clientSpecificUserRequest = '';
		
		if ($arrFilters['region']!='null' && isset($arrFilters['region'] ) && sizeof($arrFilters['region']) > 0){
			$seperator = '';
			foreach($arrFilters['region'] as $row){
				$regions .= $seperator."'".$row."'";
				$seperator = ',';
			}
			$conditionJoinClientCountry = " join user_groups on user_groups.user_id = client_users.id";
			$conditionJoinClientCountry .= " join groups on user_groups.group_id = groups.group_id";
			$conditionJoinClientCountry .= " join countries on groups.group_name = countries.GlobalRegion";
			$conditionJoinClientCountry .= " WHERE groups.group_name in (".$regions.")";
			
			$conditionJoinKolCountry .= " countries.GlobalRegion IN (".$regions.")";
		}
		if ($clientId != INTERNAL_CLIENT_ID) {
			$clientSpecificStatus = true;
			$clientSpecific .= "client_users.client_id = ".$clientId;
			if($restricted_users != '' && $restricted_users != 0){
			$seperator = '';
				foreach($restricted_users as $row){
					$restrictedUsersId .= $seperator."'".$row."'";
					$seperator = ',';
				}
				$clientSpecific .= " AND client_users.id NOT IN (".$restrictedUsersId.")";
			}
			if ($conditionJoinClientCountry != '') {
				$conditionJoinClientCountry .= " AND ".$clientSpecific;
			} else {
				$conditionJoinClientCountry = " WHERE ".$clientSpecific;
			}
		}
		
		$queryClientUsers = "SELECT 
        COUNT(DISTINCT
        CASE WHEN DATE(client_users.created_on) <= CONCAT('".$date['year']."','-','".$date['month']."','-31')
        		AND
        		(status = 0)
        THEN  client_users.id
        END) AS activeTotal,
        COUNT(DISTINCT
        CASE WHEN (YEAR(client_users.created_on) = '".$date['year']."' AND MONTH(client_users.created_on) = '".$date['month']."')
        		AND
        		(status > 0)
        THEN  client_users.id
        END) AS inactiveTotal,
        COUNT(DISTINCT CASE WHEN YEAR(client_users.created_on) = '".$date['year']."' AND MONTH(client_users.created_on) = '".$date['month']."'
        THEN client_users.id
        END) as createUsers
		FROM client_users" . $conditionJoinClientCountry;
		$resultClientUsers = $this->db->query($queryClientUsers);
		$arrOverAllResult['resultClientUsers'] = $resultClientUsers->result();
		
		/*
		 * Log Activities for user
		 */
		$this->db->select('count(distinct(log_activities.created_by)) as userAccess', false);
		$this->db->where("(YEAR(log_activities.created_on)='".$date['year']."' AND MONTH(log_activities.created_on) ='".$date['month']."')");
		$this->db->where("((log_activities.module = 'login' OR log_activities.controller = 'login') AND (log_activities.controller != 'logout' OR log_activities.controller != 'login_failed'))");
		$this->db->join('client_users', 'log_activities.created_by = client_users.id', 'left');
		$this->db->join('user_groups', 'client_users.id = user_groups.user_id ', 'left');
		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
		$this->db->join('countries', 'groups.group_name = countries.GlobalRegion', 'left');
		
		if ($arrFilters['region']!='null' && isset($arrFilters['region']) && sizeof($arrFilters['region']) > 0){
			$this->db->where_in("groups.group_name", $arrFilters['region']);
		}
		if ($clientSpecificStatus == true){
			$this->db->where("client_users.client_id", $clientId);
			if($restricted_users != '' && $restricted_users != 0)
				$this->db->where_not_in("client_users.id", $restricted_users);
		}
		$resultUserAccess = $this->db->get('log_activities');
		$arrOverAllResult ['resultUserAccess'] = $resultUserAccess->result();
		/*
		 * User's Accessed
		 */
		$this->db->select('count(DISTINCT(log_activities.created_by)) as uniqueCount', false);
		$this->db->where("(YEAR(log_activities.created_on)='".$date['year']."' AND MONTH(log_activities.created_on) ='".$date['month']."')");
		//$this->db->where("(log_activities.module = 'kols' AND log_activities.controller = 'view')");
		$this->db->where("log_activities.miscellaneous1", 'kols');
		$this->db->join('client_users', 'log_activities.created_by = client_users.id', 'left');
		$this->db->join('user_groups', 'client_users.id = user_groups.user_id ', 'left');
		$this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
		$this->db->join('countries', 'groups.group_name = countries.GlobalRegion', 'left');
		
		if ($arrFilters['region']!='null' && isset($arrFilters['region']) && sizeof($arrFilters['region'])>0){
			$this->db->where_in("groups.group_name", $arrFilters['region']);
		}
		if ($clientSpecificStatus == true){
			$this->db->where("client_users.client_id", $clientId);
			if($restricted_users != '' && $restricted_users != 0)
				$this->db->where_not_in("client_users.id", $restricted_users);
		}
		$resultUserUniqueCount = $this->db->get('log_activities');
		$arrOverAllResult['resultUserUniqueCount'] = $resultUserUniqueCount->result();
		
		/*
		 * KTL's report for 3 columns
		 */
		if ($clientId !== INTERNAL_CLIENT_ID){
			$conditionJoinKolInternal = " LEFT JOIN kols_client_visibility on kols_client_visibility.kol_id = kols.id";
			$conditionJoinKolInternal .= " WHERE kols_client_visibility.client_id = ".$clientId;
			
			if ($conditionJoinKolCountry != ""){
				$conditionJoinKolInternal .= " AND ".$conditionJoinKolCountry;
			}
		} elseif ($conditionJoinKolCountry != ""){
			$conditionJoinKolInternal .= " WHERE ".$conditionJoinKolCountry;
		}
		if($clientSpecificStatus == true){
			$clientSpecificUserRequest = " AND (".$clientSpecific.")"; 
		}
		$queryRequestktl = "SELECT COUNT(DISTINCT
        CASE WHEN 
   		(YEAR(kol_update_status.user_added_on) = '".$date['year']."' AND MONTH(kol_update_status.user_added_on) = '".$date['month']."')
   			AND
   		(kol_update_status.status = '1')	
        THEN  kol_update_status.kol_id
        END) AS crowled,
   		COUNT(DISTINCT
        CASE WHEN 
   		(YEAR(kol_update_status.user_added_on) = '".$date['year']."' AND MONTH(kol_update_status.user_added_on) = '".$date['month']."')
   			AND
   		(kol_update_status.status = '2')	
        THEN  kol_update_status.kol_id
        END) AS updatedKols,
		COUNT(DISTINCT
		CASE WHEN
   		(YEAR(user_requests.requested_on) = '".$date['year']."' AND MONTH(user_requests.requested_on) = '".$date['month']."')
   		".$clientSpecificUserRequest."
				THEN kols.id
		    END) AS requested
		FROM kols
   		Left JOIN kol_update_status on kol_update_status.kol_id = kols.id		
		Left JOIN user_requests on user_requests.kol_id = kols.id
   		Left JOIN client_users on client_users.id = user_requests.requested_by
   		LEFT JOIN countries on kols.country_id = countries.CountryId".$conditionJoinKolInternal;
		$resultRequestktls = $this->db->query($queryRequestktl);
		$arrOverAllResult['resultRequestKtls'] = $resultRequestktls->result();
		
		/*
		 * KTL's Accessed
		 */
		//$this->db->select('count(DISTINCT(log_activities.method)) as ktlAccess', false);
		$this->db->select('count(DISTINCT(log_activities.miscellaneous2)) as ktlAccess', false);
		$this->db->where("(YEAR(log_activities.created_on)='".$date['year']."' AND MONTH(log_activities.created_on) ='".$date['month']."')");
		//$this->db->where("(log_activities.module = 'kols' AND log_activities.controller = 'view')");
		$this->db->where("log_activities.miscellaneous1", "kols");
		$this->db->join('kols', 'log_activities.miscellaneous2 = kols.id', 'left');
		
		if ($arrFilters['region'] != 'null' && isset($arrFilters['region']) && sizeof($arrFilters['region'])>0){
			$this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
			$this->db->where_in("countries.GlobalRegion", $arrFilters['region']);
		}
		if ($clientId !== INTERNAL_CLIENT_ID){
			$this->db->join('client_users', 'client_users.id = log_activities.created_by', 'left');
			$this->db->where('client_users.client_id', $clientId);
			if($restricted_users != '' && $restricted_users != 0)
				$this->db->where_not_in("client_users.id", $restricted_users);
		}
		$resultKtlsAccess = $this->db->get('log_activities');
		$arrOverAllResult['resultKtlsAccess'] = $resultKtlsAccess->result();
		return $arrOverAllResult;
	}
}
