<?php
/**
 * Controller for download operations
 * @package application.controllers	
 * @author Vishwanath Tadahal
 * @created Oct 27,2016
 * 
 */


class download extends controller{
	
	function download(){
		parent::Controller();
	}	
	
    function jqgridExportToExcel($filename,$ipadOrDesktop = NULL){
    	$file=$filename."_".date('Y-m-d').".xlsx";
    	$content="<table border='1'>".$_POST['table']."</table>";
    	if($ipadOrDesktop === NULL){
    		header("Content-type: application/vnd.ms-excel");
    		header("Content-Disposition: attachment; filename=$file");
	        echo $content;
    	}else{    	
    		$directory	= $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.$this->config->item('app_folder_path').'documents';
    		$fullFilePath = $directory."/".$file;
    		file_put_contents($fullFilePath,$content);
    		if($_POST['table']=='<tr></tr>'){
    		    $emailData = 'empty_record';
    		    echo json_encode($emailData);
    		    exit;
    		}
    		$this->send_email_with_attachment($filename,$fullFilePath);
    	}
	}
	
	function send_email_with_attachment($filename,$fullFilePath) {
	    $emailData = array();
		$config['protocol'] = PROTOCOL;
		$config['smtp_host'] = HOST;
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS;
		$config['mailtype'] = 'html';
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_newline("\r\n");
		$this->email->from(USER, SENDER);
		$loggedInUserName = $this->session->userdata('user_full_name');
	
		$loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
		$messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of '.ucfirst($filename).' report data from '.PRODUCT_NAME.'.';
	
		$loggedInUserEmail = $this->session->userdata('email');
		$this->email->to($loggedInUserEmail);
		$this->email->message($messageBody);
		$this->email->subject(PRODUCT_NAME.': '.ucfirst($filename));
	
		$this->email->attach($fullFilePath);
		$this->email->set_crlf("\r\n");
		if ($this->email->send()) {
		    //Activity Log
		    $arrLogDetails = array(
		        'type' => LOG_ACTIVITY_EMAIL,
		        'description' => $messageBody,
		        'status' => STATUS_SUCCESS,
		        'transaction_name' => 'Email '.ucfirst($filename).' sent',
		        'miscellaneous2' => 'To: '.$loggedInUserEmail
		    );
		    $this->config->set_item('log_details', $arrLogDetails);
		    
			$emailData['status'] = true;
			unlink($fullFilePath);
		} else {
		    //Activity Log
		    $arrLogDetails = array(
		        'type' => LOG_ACTIVITY_EMAIL,
		        'description' => $messageBody,
		        'status' => STATUS_FAIL,
		        'transaction_name' => 'Email '.ucfirst($filename).' sent',
		        'miscellaneous2' => 'To: '.$loggedInUserEmail
		    );
		    $this->config->set_item('log_details', $arrLogDetails);
			$emailData['status'] = false;
		}
		echo json_encode($emailData['status']);
	}
}