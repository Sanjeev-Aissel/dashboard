<?php
/**
 * View -Invalid User error message page, specifically for SSO base loggin requests
 * @author Ramesh B
 * @since 0tsuka_1.0.10
 * @package application.view.login	
 * @created on 02 Feb 2013
 */
?>
<style>
	#container{
		background: none repeat scroll 0 0 transparent;
	    border: 0 solid #FFFFFF;
	    color: red;
	    font-size: 25px;
	    text-align: center;
	    text-shadow: 3px 2px 3px #969696;
	}
</style>
<?php
	echo $error_message;
?>
