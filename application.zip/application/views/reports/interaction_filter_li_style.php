<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */

$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts = array('reports/interaction_filter_li_style');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
	}
</script>
<style type="text/css">
	#timeLineSliderContainer {
	    padding-left: 10px;
    	padding-right: 8px;
	}
	#timeLineSlider{
		margin-right:10px;
	}
	#searchLeftBar li.category{
		border-top: 0px;
	}
	#searchLeftBar{
	/*	margin-top:-40px; */
	}
	<?php if(IS_IPAD_REQUEST == 1){
			echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
		}
	?>
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px;
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		/*margin-top: 0px;*/
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
	.chzn-container-single .chzn-single div{
		top: -3px !important;
	}
/*	.chzn-container .chzn-results li{
		padding: 3px 4px !important;
		line-height: 12px !important;
	}
*/
	.chzn-drop{
		min-width: 106px !important;
	}
	.ui-widget-content, #timeLineSliderContainer p, #yearRange {
		background: inherit;
	}
	#fromDate, #toDate{
		width: 100px;
	}
	
</style>
<?php 
		$arrfilterdata		= $this->session->userdata('filterContent');
		$selectedKolId		= $arrfilterdata['selected_kol_id'];
		if(!empty($selectedKolId) && $selectedKolId!=0){
			foreach($arrKolDetails as $key=>$rowData){
				if($key==$selectedKolId){
					$selectedKol[$key]	= $rowData['name'];
				}
			}
		}else{
			$selectedKol	= $arrfilterdata['arrKolNames'];//$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
		}
		if($arrfilterdata['profileType'] != ''){
			$profileType = $arrfilterdata['profileType'];
		}
		if($arrfilterdata['savedFilterId']!= ''){
			$savedFilterId = $arrfilterdata['savedFilterId'];
		}
		if(!empty($arrfilterdata['arrSpecialities'])){
			if(!is_array($arrfilterdata['arrSpecialities'])){
				$arrfilterdata['arrSpecialities'] = explode(',',$arrfilterdata['arrSpecialities']);
			}
			$selectedSpecialty	= $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
		}else{
			$selectedSpecialty = array();
		}
		if(sizeof($arrfilterdata['arrCountries'])>0){
			if(!is_array($arrfilterdata['arrCountries'])){
				$arrfilterdata['arrCountries'] = explode(',',$arrfilterdata['arrCountries']);
			}
			$selectedCountry	= $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
		}else{
			$selectedCountry = array();
		}
		//$selectedState		= $arrfilterdata['arrStates'];
		if(!empty($arrfilterdata['arrStates'])){
			if(!is_array($arrfilterdata['arrStates'])){
				$arrfilterdata['arrStates'] = explode(',',$arrfilterdata['arrStates']);
			}
			$selectedState	= $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
		}else{
			$selectedState = array();
		}
		if(sizeof($arrfilterdata['arrListNames'])>0){
			if(!is_array($arrfilterdata['arrListNames'])){
				$arrfilterdata['arrListNames'] = explode(',',$arrfilterdata['arrListNames']);
			}
			$CI =& get_instance();
			$CI->load->model("My_list_kol");
			//$selectedListName	= $arrfilterdata['arrListNames'];
			$selectedListName	= $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
		}else{
			$selectedListName	= array();
		}
?>
	<script type="text/javascript">
		$(document).ready(function (){
			$('#fromDate').datepicker({
				dateFormat: 'yy-mm-dd',
				onSelect: function(dateText, inst) {
			        var date = $(this).val();
			        doSearchFilter1();
//			        alert(date);
//			        var time = $('#time').val();
//			        alert('on select triggered');
			        //$("#start").val(date + time.toString(' HH:mm').toString());

			    }
			});
		});
		$(document).ready(function (){
			$('#toDate').datepicker({
				dateFormat: 'yy-mm-dd',
				onSelect: function(dateText, inst) {
			        var date = $(this).val();
			        doSearchFilter1();
			    }
			});
		});
	</script>
		<script type="text/javascript">

	$(document).ready(function (){
		//$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
		$('#categoriesContainer input:checked').each(function (index){
			$(this).parent().parent().css('background-color','#D3DFED');
		});
	
		$('#searchFiltersElements ul li table tr').click(function (){
			var input = $(this).children('td:first').children('input');
			if($(input).attr('checked')=="checked"){
				$(this).css('background-color','#ffffff');
				$(input).removeAttr('checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}else{
				$(this).css('background-color','#D3DFED');
				$(input).attr('checked','checked');
				doSearchFilter1(-1,$('#'+$(this).attr('class')));
			}
		});
//		initializeCustomToolTips();
	});
			var options, a;
			
			// Autocomplet Options for the 'role' field 
		  	var SpecialtyNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.specialties').html();
						var selId = $(event).children('.specialties').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#specialty').val(selText);
						$('#specialtyId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};	
		
			// Autocomplet Options for the 'country' field
			var countryNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.countries').html();
						var selId = $(event).children('.countries').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#country').val(selText);
						$('#countryId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};
			// Autocomplet Options for the 'country' field
			var stateNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var stateId = $(event).children('.autocompleteStateId').html();
						var selText = $(event).children('.stateName').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#state').val(selText);
						$('#stateIdForAutocomplete').val(stateId);
						if(selText.length>20){
							if(selText.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
				};
		
			var kolNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_autocomplete_refineby',
					<?php echo $autoSearchOptions;?>,
							onSelect : function(event, ui) {
								var kolId = $(event).children('.id1').html();
								//var selText = $(event).children('.kolName').html();
								var selText = $(event).children('.kolName').attr('name');
								selText=selText.replace(/\&amp;/g,'&');
								$('#kolName').val(selText);
								$('#kolIdForReport').val(kolId);
								if(selText.length>20){
									if(selText.substring(0,21)=="No results found for "){
										return false;
									}else{
										displaySelectedChart(true);
									}
								}else{
								displaySelectedChart(true);
							}
							}
					
				};

			// Autocomplet Options for the 'country' field
			var listNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>my_list_kols/get_list_names_with_category',
					<?php echo $autoSearchOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.lists').html();
						var selId = $(event).children('.lists').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#listName').val(selText);
						$('#listNameId').val(selId);
						if(event.length>20){
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								displaySelectedChart(true);
							}
						}else{
							displaySelectedChart(true);
						}
					}
					
				};		
/*		
			$(document).ready(function(){
		
				// Trigger the Autocompleter for 'education' field of  Event'
				a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
		
				// Trigger the Autocompleter for 'country' field of  Event'
				a = $('#country').autocomplete(countryNameAutoCompleteOptions);
		
				a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
		
				// Trigger the Autocompleter for 'list' field of  Event'
				a = $('#listName').autocomplete(listNameAutoCompleteOptions);

				// Binding the function for slidechange event 
				$( "#timeLineSlider" ).bind( "slidechange", filterChart);
		
			});
*/		
			//Initiallize the Timeline slider
			<?php $date=date('Y');?>
		//	var minYear=<?php echo ($date-35);?>;
			var minYear=<?php echo ($date-60);?>;
			var maxYear=<?php echo $date;?>;
			var startDate='<?php if(isset($startDate))echo $startDate; else echo 0;?>';
			var endDate='<?php if(isset($endDate))echo $endDate; else echo 0;?>';
			var rangeValue1=minYear;
			var rangeValue2=maxYear;
				if(startDate!=null && startDate!=0)
					rangeValue1=startDate;
				if(endDate!=null && endDate!=0)
					rangeValue2=endDate;
/*			
			$(function() {
				$( "#timeLineSlider" ).slider({
					range: true,
					min: minYear,
					max: maxYear,
					values: [ rangeValue1, rangeValue2 ],
					step:1,
					slide: function( event, ui ) {
						$( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
					}
				});
		
				$( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
			});
			

			


			// Hide or Show the Category checkbox's 
			function toggleCategory(toggleFlag,thisEle){
				//	jAlert("Ds");
				if($(thisEle).parent().attr('id')=='categotySpecialty'){
						$('#specialtyCheckBox').slideToggle();	
					
				}else if($(thisEle).parent().attr('id')=='categotyCountry'){
					$('#countryCheckBox').slideToggle();	
				}else if($(thisEle).parent().attr('id')=='categotyLists'){

					$('#listCheckBox').slideToggle();
				}else{
					$('#kolsCheckBox').slideToggle();
				}
				
			}

			$(document).ready(function(){
				$('#kolName').css({color:"gray"});
				$('#specialty').css({color:"gray"});
				$('#country').css({color:"gray"});
				$('#listName').css({color:"gray"});


				$('#kolName').focus(function(){
						
						var name=$('#kolName').val();
						if(name=='Enter KOL Name'){
							$('#kolName').val(" ");
						}
					});

					$('#kolName').blur(function() {
						var name=$('#kolName').val();
						if(name==' '){
							$('#kolName').val('Enter KOL Name');
						}
					});

					$('#specialty').focus(function(){
						
						var name=$('#specialty').val();
						if(name=='Enter Specialty'){
							$('#specialty').val(" ");
						}
					});

					$('#specialty').blur(function() {
						var name=$('#specialty').val();
						if(name==' '){
							$('#specialty').val('Enter Specialty');
						}
					});

					$('#country').focus(function(){
						
						var name=$('#country').val();
						if(name=='Enter Country'){
							$('#country').val(" ");
						}
					});

					$('#country').blur(function() {
						var name=$('#country').val();
						if(name==' '){
							$('#kolName').val('Enter Country');
						}
					});

					$('#listName').focus(function(){
						
						var name=$('#listName').val();
						if(name=='Enter List Name'){
							$('#listName').val(" ");
						}
					});

					$('#listName').blur(function() {
						var name=$('#listName').val();
						if(name==' '){
							$('#listName').val('Enter List Name');
						}
					});
			});
*/
//if(js_files_loaded){

	// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
			//	jAlert("Ds");
		/*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
					$('#specialtyCheckBox').slideToggle();	
				
			}else if($(thisEle).parent().attr('id')=='categotyCountry'){
				$('#countryCheckBox').slideToggle();	
			}else if($(thisEle).parent().attr('id')=='categotyLists'){
				$('#listCheckBox').slideToggle();
			}else{
				$('#kolsCheckBox').slideToggle();
			}
		*/
			$(thisEle).next().slideToggle('slow');
			$(thisEle).toggleClass('expanded');
			$(thisEle).toggleClass('collapsed');
		}
		
		
	$(document).ready(function(){
			
		// Trigger the Autocompleter for 'education' field of  Event'
		a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'country' field of  Event'
		a = $('#country').autocomplete(countryNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'country' field of  Event'
		a = $('#state').autocomplete(stateNameAutoCompleteOptions);

		a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);

		// Trigger the Autocompleter for 'list' field of  Event'
		a = $('#listName').autocomplete(listNameAutoCompleteOptions);

		// Binding the function for slidechange event 
//		$( "#timeLineSlider" ).bind( "slidechange", filterChart);

	});
	$(document).ready(function(){
		$('#kolName').css({color:"gray"});
		$('#specialty').css({color:"gray"});
		$('#country').css({color:"gray"});
		$('#state').css({color:"gray"});
		$('#listName').css({color:"gray"});


		$('#kolName').focus(function(){
				alert("dd");
			//	var name=$('#kolName').val();
			//	if(name=='Enter KOL Name'){
					$('#kolName').val(" ");
			//	}
			});

			$('#kolName').blur(function() {
			//	var name=$('#kolName').val();
			//	if(name==' '){
					$('#kolName').val('Enter KOL Name');
			//	}
			});

			$('#channel').focus(function(){
				
			//	var name=$('#specialty').val();
			//	if(name=='Enter Specialty'){
					$('#channel').val(" ");
			//	}
			});

			$('#channel').blur(function() {
			//	var name=$('#specialty').val();
			//	if(name==' '){
					$('#channel').val('Enter Channel');
			//	}
			});

			$('#country').focus(function(){
				
			//	var name=$('#country').val();
			//	if(name=='Enter Country'){
					$('#country').val(" ");
			//	}
			});

			$('#country').blur(function() {
			//	var name=$('#country').val();
			//	if(name==' '){
					$('#country').val('Enter Country');
			//	}
			});

			$('#state').focus(function(){
				
			//	var name=$('#state').val();
			//	if(name=='Enter State'){
					$('#state').val(" ");
			//	}
			});

			$('#state').blur(function() {
			//	var name=$('#state').val();
			//	if(name==' '){
					$('#state').val('Enter State');
			//	}
			});

			$('#listName').focus(function(){
				
			//	var name=$('#listName').val();
			//	if(name=='Enter List Name'){
					$('#listName').val(" ");
			//	}
			});

			$('#listName').blur(function() {
			//	var name=$('#listName').val();
			//	if(name==' '){
					$('#listName').val('Enter List Name');
			//	}
			});
	});
	
/*
	$('#rightSideBarSliderShow').click(function() {
		$('#searchLeftBar').show(1000, function() 
			{
				$('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
			});
		$("#rightSideBarSliderHide").show();
		$("#rightSideBarSliderShow").hide();
		
  	//	$('#searchLeftBar').slideToggle('slow', function() {
  	//		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
	//	});
	});

	$('#rightSideBarSliderHide').click(function() {
		$('#searchLeftBar').hide(1000, function() 
			{
				$('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
				$("#rightSideBarSliderShow").show(500);
			});
		$("#rightSideBarSliderHide").hide();
		
  	//	$('#searchLeftBar').slideToggle('slow', function() {
  	//		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
	//	});
	});
*/
//}
$(document).ready(function(){
	$("#savedFilterValue").chosen().change(function(){
		activeCustmFilters(this);
	});
	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
		displaySelectedChart(this);
	});
	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
		if($("#savedFilterValue").val()){
			activeCustmFilters($("#savedFilterValue").val());
			return true;
			}
//		doSearchFilter1(-1,this);
		displaySelectedChart(this);
	});
});

	</script>
		<div id="searchFiltersContainer">
			<div id="searchFiltersElements">
					<form action="<?php echo base_url()?>reports/reload_interaction_filters" name="searchFilterForm" method="post" id="searchFilterForm">
						<ul id="categoriesContainer">
							<!--<li class="">
								<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">From </label>
								<div style="">
									<input type="text" name="fromDate" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="fromDate">
								</div>
							</li>
							<li class="">
								<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">To </label>
								<div style="">
									<input type="text" name="toDate" value="<?php if($toDate != ''){echo $toDate;}?>" id="toDate">
								</div>
							</li>
							--><table>
								<tr>
									<td>
										<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">From </label>
										<div style="">
											<input type="text" name="fromDate" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="fromDate">
										</div>
									</td>
									<td>
										<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">To </label>
										<div style="">
											<input type="text" name="toDate" value="<?php if($toDate != ''){echo $toDate;}?>" id="toDate">
										</div>
									</td>
								</tr>
							</table>
							<!-- 
							<li id="categotyKols" class="category">
								<div>
								<table>
									<?php
										if(isset($selectedKol) && $selectedKol!=null && $selectedKol!=0){
											foreach($selectedKol as $k => $kol){?>
												<tr class="kol<?php echo str_replace(' ','',$kol);?>">
													<td class="textAlignRight">
														<input type="checkbox" name="kol_ids[]" class="kolElement hideCheckbox" id="kol<?php echo str_replace(' ','',$kol);?>" checked="checked" value="<?php echo $k;?>" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $kol;?>
													</td>
													<td class="histoGram"><div class="filterBar">
															<div class="progress" title="1(<?php echo round((1/1)*100);?>%)">
																<div class="bar" style="width: <?php if(isset($kol)) echo round((1/1)*100); else echo 0;?>%;"></div>
															</div>
														</div>
													</td>
													<td>
													<?php 
													//	if($reportSection=='activity'){
															if (array_key_exists($kol, $arrKolDetails)){ 
																if(isset($arrKolDetails[$kol]['count']))
																	echo '('.$arrKolDetails[$kol]['count'].')';
															}
															else{
																if(isset($arrKolDetails[$kol]['count']))
																	echo '('.'0'.')';
															}
													//	}
													?>
													</td>
												</tr>
									<?php } }?>
									</table>
									<div class="filterSearchIcon"></div><input type="text" name="kol_ids1" class="autocompleteInputBox" id="kolName" value="Enter KOL Name" title=""/>
									<input type="hidden" id="kolIdForReport" value="<?php echo $selectedKolId;?>" name="kol_id1"></input>
								</div>
							</li>
							 -->
							
							<li id="categotyChannels" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName">Interaction Channels</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractionChannels">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_channels" id="allChannels" value="channel" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Channels</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allChannelCount."(".round(($allChannelCount/$allChannelCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allChannelCount)) echo round(($allChannelCount/$allChannelCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allChannelCount)) echo $allChannelCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;//pr($selectedSpecialties);pr($arrKolsBySpecialtyCount);
									 	foreach($arrInteractionsByChannelCount as $interactionChannelCountDetails){ ?>
									 	<?php if($interactionChannelCountDetails['interaction_channel_id']!='' && $interactionChannelCountDetails['interaction_channel_id']!= 0){?>
				
									 		<tr class="channel<?php echo $interactionChannelCountDetails['interaction_channel_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="channel_ids[]" class="channelElement hideCheckbox" id="channel<?php echo $interactionChannelCountDetails['interaction_channel_id'];?>" value="<?php echo $interactionChannelCountDetails['interaction_channel_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedChannels[$interactionChannelCountDetails['interaction_channel_id']])){
															unset($selectedChannels[$interactionChannelCountDetails['interaction_channel_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionChannelCountDetails['interaction_channel'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionChannelCountDetails['count']."(".round(($interactionChannelCountDetails['count']/$allChannelCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allChannelCount)) echo round(($interactionChannelCountDetails['count']/$allChannelCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionChannelCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; //if($i>3) break; 
									 	}}?>
									
									<?php if(isset($selectedChannels) && $selectedChannels!=null){foreach($selectedChannels as $id=>$specialtyName){?>
										<tr class="channel<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="channel_ids[]" class="channelElement hideCheckbox" id="channel<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allChannelCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allChannelCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allChannelCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="channel" class="autocompleteInputBox" id="channel" value="Enter Channel" title=""/><input type="hidden" name="channel_id" id="channelId" value="" />
									 -->
								</div>
							</li>
							<li id="categotyCategory" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName">Interaction Categories</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractionCategories">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_categories" id="allCategories" value="category" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Categories</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allCategoryCount."(".round(($allCategoryCount/$allCategoryCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allCategoryCount)) echo round(($allCategoryCount/$allCategoryCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allCategoryCount)) echo $allCategoryCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;
									 	foreach($arrInteractionsByCategoryCount as $interactionCategoryCountDetails){ ?>
									 	<?php if($interactionCategoryCountDetails['interaction_category_id']!='' && $interactionCategoryCountDetails['interaction_category_id']!= 0){?>
				
									 		<tr class="Categories<?php echo $interactionCategoryCountDetails['interaction_category_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="category_ids[]" class="CategoryElement hideCheckbox" id="category<?php echo $interactionCategoryCountDetails['interaction_category_id'];?>" value="<?php echo $interactionCategoryCountDetails['interaction_category_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedCategories[$interactionCategoryCountDetails['interaction_category_id']])){
															unset($selectedCategories[$interactionCategoryCountDetails['interaction_category_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionCategoryCountDetails['interaction_category'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionCategoryCountDetails['count']."(".round(($interactionCategoryCountDetails['count']/$allCategoryCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allCategoryCount)) echo round(($interactionCategoryCountDetails['count']/$allCategoryCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionCategoryCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; 
										//if($i>3) break; 
									 }}?>
									
									<?php if(isset($selectedCategories) && $selectedCategories!=null){foreach($selectedCategories as $id=>$specialtyName){?>
										<tr class="category<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="category_ids[]" class="categoryElement hideCheckbox" id="category<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allCategoryCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allCategoryCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allCategoryCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="category" class="autocompleteInputBox" id="category" value="Enter Category" title=""/><input type="hidden" name="category_id" id="categoryId" value="" />
									 -->
								</div>
							</li>
							<li id="categotyProduct" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName"><?php echo lang("Overview.Product");?></label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractTypescts">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_products" id="allProducts" value="product" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Products</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allProductCount."(".round(($allProductCount/$allProductCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allProductCount)) echo round(($allProductCount/$allProductCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allProductCount)) echo $allProductCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;
									 	foreach($arrInteractionsByProductCount as $interactionProductCountDetails){ ?>
									 	<?php if($interactionProductCountDetails['interaction_product_id']!='' && $interactionProductCountDetails['interaction_product_id']!= 0){?>
				
									 		<tr class="Products<?php echo $interactionProductCountDetails['interaction_product_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="product_ids[]" class="productElement hideCheckbox" id="product<?php echo $interactionProductCountDetails['interaction_product_id'];?>" value="<?php echo $interactionProductCountDetails['interaction_product_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedProducts[$interactionProductCountDetails['interaction_product_id']])){
															unset($selectedProducts[$interactionProductCountDetails['interaction_product_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionProductCountDetails['interaction_product'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionProductCountDetails['count']."(".round(($interactionProductCountDetails['count']/$allProductCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allProductCount)) echo round(($interactionProductCountDetails['count']/$allProductCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionProductCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; 
										//if($i>3) break; 
									 }}?>
									
									<?php if(isset($selectedProducts) && $selectedProducts!=null){foreach($selectedProducts as $id=>$specialtyName){?>
										<tr class="product<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="product_ids[]" class="productElement hideCheckbox" id="product<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allProductCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allProductCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allProductCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="product" class="autocompleteInputBox" id="product" value="Enter Product" title=""/><input type="hidden" name="product_id" id="productId" value="" />
									 -->
								</div>
							</li>
							<li id="categotyType" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName">Interaction Types</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractionTypes">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_types" id="allTypes" value="type" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Types</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allTypeCount."(".round(($allTypeCount/$allTypeCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allTypeCount)) echo round(($allTypeCount/$allTypeCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allTypeCount)) echo $allTypeCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;
									 	foreach($arrInteractionsByTypeCount as $interactionTypeCountDetails){ ?>
									 	<?php if($interactionTypeCountDetails['interaction_type_id']!='' && $interactionTypeCountDetails['interaction_type_id']!= 0){?>
				
									 		<tr class="Types<?php echo $interactionTypeCountDetails['interaction_type_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="type_ids[]" class="typeElement hideCheckbox" id="type<?php echo $interactionTypeCountDetails['interaction_type_id'];?>" value="<?php echo $interactionTypeCountDetails['interaction_type_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedTypes[$interactionTypeCountDetails['interaction_type_id']])){
															unset($selectedTypes[$interactionTypeCountDetails['interaction_type_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionTypeCountDetails['interaction_type'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionTypeCountDetails['count']."(".round(($interactionTypeCountDetails['count']/$allTypeCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allTypeCount)) echo round(($interactionTypeCountDetails['count']/$allTypeCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionTypeCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; 
										//if($i>3) break; 
									 }}?>
									
									<?php if(isset($selectedTypes) && $selectedTypes!=null){foreach($selectedTypes as $id=>$specialtyName){?>
										<tr class="Type<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="type_ids[]" class="typeElement hideCheckbox" id="type<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allTypeCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allTypeCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allTypeCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="type" class="autocompleteInputBox" id="type" value="Enter Type" title=""/><input type="hidden" name="type_id" id="typeId" value="" />
									 -->
								</div>
							</li>
							<li id="categotyType" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName">Interaction Topics</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractionTopics">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_topics" id="allTopics" value="topic" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Topics</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allTopicCount."(".round(($allTopicCount/$allTopicCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($allTopicCount/$allTopicCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allTopicCount)) echo $allTopicCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;
									 	foreach($arrInteractionsByTopicCount as $interactionTopicCountDetails){ ?>
									 	<?php if($interactionTopicCountDetails['interaction_topic_id']!='' && $interactionTopicCountDetails['interaction_topic_id']!= 0){?>
				
									 		<tr class="Topics<?php echo $interactionTopicCountDetails['interaction_topic_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="topic_ids[]" class="topicElement hideCheckbox" id="topic<?php echo $interactionTopicCountDetails['interaction_topic_id'];?>" value="<?php echo $interactionTopicCountDetails['interaction_topic_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedTopics[$interactionTopicCountDetails['interaction_topic_id']])){
															unset($selectedTopics[$interactionTopicCountDetails['interaction_topic_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionTopicCountDetails['interaction_topic'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionTopicCountDetails['count']."(".round(($interactionTopicCountDetails['count']/$allTopicCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($interactionTopicCountDetails['count']/$allTopicCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionTopicCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; 
										//if($i>3) break; 
									 }}?>
									
									<?php if(isset($selectedTopics) && $selectedTopics!=null){foreach($selectedTopics as $id=>$specialtyName){?>
										<tr class="Topic<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="topic_ids[]" class="topicElement hideCheckbox" id="topic<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allTopicCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allTopicCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="topic" class="autocompleteInputBox" id="topic" value="Enter Topic" title=""/><input type="hidden" name="topic_id" id="topicId" value="" />
									 -->
								</div>
							</li>
							<li id="categotyType" class="category">
<!--								<div class="refineBySecialtyImage sprite_iconSet"></div>-->
								<label class="categoryName">Interaction Sub Topics</label>
								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
								<div>
								<table class="clear">
									<tr class="allInteractionSubTopics">
										<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_sub_topics" id="allSubTopics" value="SubTopic" <?php if(isset($selectedChannels) && $selectedChannels!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Sub Topics</td>
										<td class="histoGram"><div class="filterBar">
												<div class="progress" title="<?php echo $allSubTopicCount."(".round(($allSubTopicCount/$allSubTopicCount)*100)."%)";?>">
													<div class="bar" style="width: <?php if(isset($allSubTopicCount)) echo round(($allSubTopicCount/$allSubTopicCount)*100); else echo 0;?>%;"></div>
												</div>
											</div>
										</td>
										<td><?php if(isset($allSubTopicCount)) echo $allSubTopicCount; else echo 0;?></td>
									</tr>
				
									<?php $i=0;
									 	foreach($arrInteractionsBySubTopicCount as $interactionSubTopicCountDetails){ ?>
									 	<?php if($interactionSubTopicCountDetails['interaction_sub_topic_id']!='' && $interactionSubTopicCountDetails['interaction_sub_topic_id']!= 0){?>
				
									 		<tr class="SubTopics<?php echo $interactionSubTopicCountDetails['interaction_sub_topic_id'];?>">
									 			<td class="textAlignRight">
									 				<input type="checkbox" name="sub_topic_ids[]" class="subTopicElement hideCheckbox" id="SubTopic<?php echo $interactionSubTopicCountDetails['interaction_sub_topic_id'];?>" value="<?php echo $interactionSubTopicCountDetails['interaction_sub_topic_id'];?>" onclick="doSearchFilter1(-1,this)" 
													<?php
														if(isset($selectedSubTopics[$interactionSubTopicCountDetails['interaction_sub_topic_id']])){
															unset($selectedSubSubTopics[$interactionSubTopicCountDetails['interaction_sub_topic_id']]);
															echo 'checked="checked"';
														}
													?> 
													/>&nbsp;<?php echo $interactionSubTopicCountDetails['interaction_sub_topic'];?>
									 			</td>
									 			<td class="histoGram">
										 			<div class="filterBar">
														<div class="progress" title="<?php echo $interactionSubTopicCountDetails['count']."(".round(($interactionSubTopicCountDetails['count']/$allSubTopicCount)*100)."%)";?>">
															<div class="bar" style="width: <?php if(isset($allSubTopicCount)) echo round(($interactionSubTopicCountDetails['count']/$allSubTopicCount)*100); else echo 0;?>%;"></div>
														</div>
													</div>
												</td>
									 			<td><?php echo $interactionSubTopicCountDetails['count'];?></td>
									 		</tr>
				
									<?php $i++; 
										//if($i>3) break; 
									 }}?>
									
									<?php if(isset($selectedSubSubTopics) && $selectedSubSubTopics!=null){foreach($selectedSubSubTopics as $id=>$specialtyName){?>
										<tr class="SubTopic<?php echo $id;?>">
											<td class="textAlignRight">
												<input type="checkbox" name="sub_topic_ids[]" class="subTopicElement hideCheckbox" id="SubTopic<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
											</td>
											<td class="histoGram">
									 			<div class="filterBar">
													<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allSubTopicCount)*100)."%)";?>">
														<div class="bar" style="width: <?php if(isset($allSubTopicCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allSubTopicCount)*100); else echo 0;?>%;"></div>
													</div>
												</div>
											</td>
											<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
										</tr>
									<?php }}?>
									</table>
<!--									<div class="filterSearchIcon"></div>-->
									<!-- 
									<input type="text" name="sub_topic" class="autocompleteInputBox" id="subTopic" value="Enter Sub Topic" title=""/><input type="hidden" name="SubTopic_id" id="subTopicId" value="" />
									 -->
								</div>
							</li>	
						</ul>
					</form>
			
			</div>
		</div>