<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Notification extends Model {

    //Constructor
    function Notification() {
        parent::Model();
        $this->load->model("Event_helper");
        $this->load->model("common_helpers");
        $this->load->model("interaction");
        $this->load->model('Country_helper');
        $this->load->model('Client_User');
        $this->load->model("pubmed");
    }

    function saveNotification($arrNotificationData) {
        if ($this->db->insert('notifications', $arrNotificationData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }
    
    // Eamil_status Will be Updated once email for the day  is triggered
    function updateEmailNotification(){
    	$today = date("Y-m-d");
    	$this->db->where('start_date',$today);
    	if($this->db->update('notifications',array('email_status'=>1))){
    		return true;
    	}else{
    		return false;
    	}
    	
    }

    function saveUserNotification($notificationData) {
        if ($this->db->insert('user_notifications', $notificationData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function getUserNotifications($userId,$type) {
        $this->db->select('notifications.*, user_notifications.has_seen, user_notifications.user_id, concat(client_users.first_name, " ", client_users.last_name) as name', false);
        $this->db->join('user_notifications', 'user_notifications.notification_id=notifications.id');
//            $this->db->join('client_users', 'client_users.id=user_notifications.user_id');
        $this->db->join('client_users', 'client_users.id=notifications.created_by');
        $todayDate = date('Y-m-d');
        $this->db->where('notifications.start_date <= "'.   $todayDate . '"');
        $this->db->where('notifications.end_date >= "'.   $todayDate . '"');
        $this->db->where('notifications.is_active', '1');
        if($type == 'notSeen')
        	$this->db->where('user_notifications.has_seen', '0');
        $this->db->where('user_notifications.user_id', $userId);
        $this->db->group_by('user_notifications.notification_id');
        $this->db->order_by('end_date');
        $res = $this->db->get('notifications');

        return $res->result_array();
    }

    function getAllNotifications() {
        $arrReturnData = array();
        $this->db->select('notifications.*, concat(client_users.first_name, " ", client_users.last_name) as cname', false);
        $this->db->join('client_users', 'client_users.id=notifications.created_by', 'left');
        $this->db->where('client_users.client_id', $this->session->userdata('client_id'));
        $this->db->order_by("notifications.start_date","desc");
        $res = $this->db->get('notifications');
		
        return $res->result_array();
    }

    function deleteNotification($id) {
        $this->db->where('id', $id);
        $this->db->delete('notifications');
        //Add Log activity
        $this->db->where('notification_id', $id);
        $this->db->delete('user_notifications');
        $arrLogDetails = array(
        		'type' => DELET_RECORD,
        		'description' => 'Delete notifications',
        		'status' => STATUS_SUCCESS,
        		'kols_or_org_type' => 'Kol',
        		'kols_or_org_id' => '',
        		'transaction_id' =>  $id,
        		'transaction_table_id' => NOTIFICATIONS,
        		'transaction_name' => "Delete notifications",
        		'parent_object_id' =>  ''
        );
        $this->config->set_item('log_details', $arrLogDetails);
    }

    function markNotificationSeen($notificationId, $userId) {
        $this->db->where('notification_id', $notificationId);
        $this->db->where('user_id', $userId);
        if ($this->db->update('user_notifications', array('has_seen' => 1))) {
            return true;
        } else {
            return false;
        }
    }

    function getNotificationById($id) {
        $this->db->where('id', $id);
        $res = $this->db->get('notifications');
        return $res->result_array();
    }

    function updateNotification($id, $arrData) {
        $this->db->where('id', $id);
        if ($this->db->update('notifications', $arrData)) {
            return true;
        } else {
            return false;
        }
    }
    
    function deleteAllNotificationUsers($id){
        $this->db->where('notification_id', $id);
        $this->db->delete('user_notifications');
        //Add Log activity
        $arrLogDetails = array(
        		'type' => DELET_RECORD,
        		'description' => 'Delete user notifications',
        		'status' => STATUS_SUCCESS,
        		'kols_or_org_type' => 'Kol',
        		'kols_or_org_id' => '',
        		'transaction_id' =>  $id,
        		'transaction_table_id' => USER_NOTIFICATIONS,
        		'transaction_name' => "Delete user notifications",
        		'parent_object_id' =>  ''
        );
        $this->config->set_item('log_details', $arrLogDetails);
    }
    
    //get sender emails
    function sender_email($sender){
    	$this->db->select("concat(client_users.first_name,' ',client_users.last_name) as username",false);
    	$this->db->join('notifications','notifications.created_by = client_users.id','left');
    	$this->db->where('notifications.created_by',$sender);
    	$senderEmail = $this->db->get('client_users');
    	return $senderEmail->result_array();
    	
    }
   
    function getAllUsersIds($notificationId){
        $returnData = array();
        $this->db->select('notifications.created_by,notifications.all_users,client_users.client_id,client_users.first_name,group_concat(groups.group_id) as GlobalRegionIds');
        $this->db->join('client_users','client_users.id = notifications.created_by');
        $this->db->join('user_groups','user_groups.user_id = client_users.id','left');
        $this->db->join('groups','groups.group_id = user_groups.group_id','left');
        $this->db->where('notifications.is_active',1);
        $this->db->where('notifications.id',$notificationId);
        $arrData = $this->db->get('notifications');
        foreach ($arrData->result_array() as $row)
        {
            if($row['GlobalRegionIds']!=null){
                $this->db->select('client_users.id');
                $this->db->join('user_groups','user_groups.user_id = client_users.id','left');
                $this->db->join('groups','groups.group_id = user_groups.group_id','left');
                $this->db->where('groups.group_id IN ('.$row['GlobalRegionIds'].')',NULL, false);
                $this->db->where('client_users.client_id',$row['client_id']);
                $arrNotificationAllUsers = $this->db->get('client_users');
                if(sizeof($arrNotificationAllUsers->result_array() > 0)){
                    foreach($arrNotificationAllUsers->result_array() as $arrAllUserRow){
                        $returnData[$arrAllUserRow['id']] = $arrAllUserRow['id'];
                    }
                }
            }else{
                $returnData[$row['created_by']] = $row['created_by'];
            }
        }
        return $returnData;
    }
    //Email Notifications for the Notifications
    function get_all_notifications_for_email(){
        $returnData = array();
    	$today = date("Y-m-d");
    		$this->db->select('notifications.users,notifications.groups,notifications.created_by,notifications.all_users,client_users.client_id,client_users.first_name,group_concat(groups.group_id) as GlobalRegionIds');
    		$this->db->join('client_users','client_users.id = notifications.created_by');
    		$this->db->join('user_groups','user_groups.user_id = client_users.id','left');
    		$this->db->join('groups','groups.group_id = user_groups.group_id','left');
    		$this->db->where('notifications.is_active',1);
    		$this->db->where('notifications.send_email',1);
    		$this->db->where('notifications.start_date',$today);
    		$this->db->group_by('notifications.id');
    		$arrData = $this->db->get('notifications');
    	$i = 0;
    	foreach ($arrData->result_array() as $row)
    	{
    	     if($row['all_users'] == 1){
    	         $this->db->select('distinct(client_users.email)');
    	         $this->db->join('user_groups','user_groups.user_id = client_users.id','left');
    	         $this->db->join('groups','groups.group_id = user_groups.group_id','left');
    	         $this->db->where('groups.group_id IN ('.$row['GlobalRegionIds'].')',NULL, false);
    	         $this->db->where('client_users.client_id',$row['client_id']);
    	         $this->db->group_by('email');
    	         $arrNotificationAllUsers = $this->db->get('client_users');
    	         if(sizeof($arrNotificationAllUsers->result_array() > 0)){
    	             foreach($arrNotificationAllUsers->result_array() as $arrAllUserRow){
    	                 $returnData[$row['first_name'].'*email*'.$arrAllUserRow['email']] = $arrAllUserRow['email'];
    	             }
    	         } 
    	    }else{
        	    if(!empty($row['users'])){
        	        $this->db->select('distinct(client_users.email)');
    	            $this->db->where('client_users.id IN ('.$row['users'].')',NULL, false);
        	        $this->db->group_by('email');
        	        $arrNotificationUsers = $this->db->get('client_users');
        	       // echo $this->db->last_query();
        	        if($arrNotificationUsers->num_rows() > 0){
        	            foreach($arrNotificationUsers->result_array() as $arrUserRow){
        	                $returnData[$row['first_name'].'*email*'.$arrUserRow['email']] = $arrUserRow['email'];
        	            }
        	        } 
        	    }
        	    if(!empty($row['groups'])){
            		$this->db->select('distinct(client_users.email)');
            		$this->db->join('user_groups','user_groups.user_id = client_users.id','left');
            		$this->db->where_in('user_groups.group_id',$row['groups']);
            		$this->db->group_by('email');
            		$arrNotification = $this->db->get('client_users');
            	//	echo $this->db->last_query();
            		if($arrNotification->num_rows() > 0){
            		    foreach($arrNotification->result_array() as $arrGroupUserRow){
            		        $returnData[$row['first_name'].'*email*'.$arrGroupUserRow['email']] = $arrGroupUserRow['email'];
                		}
            		} 
        	    }
    	    }
    	    $i++;
    	}
	    return $returnData;
    	
    }
    	// To get Deatils of Notification for the current day
    	function get_notification_for_current_day(){
    		$today = date("Y-m-d");
    		$this->db->select('notifications.*');
    		$this->db->where('notifications.start_date',$today);
    		$currentDay = $this->db->get('notifications');
    		$query = $currentDay->result_array();
    		return $query;
    	}
    	
    	function get_regions($userId){
    		$this->db->select('countries.GlobalRegion,client_users.id');
    		$this->db->join('client_users','client_users.id = notifications.created_by');
    		$this->db->join('countries','client_users.country =  countries.CountryId');
    		$this->db->group_by('client_users.id');
    		$arrUsers = $this->db->get('notifications');
    		$query = $arrUsers->result_array();
    		return $query;
    	}
    	
    	
    	function get_users_division($regionUsers){
    		$this->db->select('client_users.id');
    		$this->db->where('client_users.id',$regionUsers);
    		$arrDiv = $this->db->get('client_users');
    		$query = $arrDiv->result_array();
    		return $query;
    	}
    
	}
