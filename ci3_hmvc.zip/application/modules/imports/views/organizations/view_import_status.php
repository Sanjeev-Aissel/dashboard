<?php
/**
 * Organization Import Status page
 * 
 * @author Ramesh B
 * @since	2.4
 * @created: 31-05-2011
 */

function listRecordsPerPage($maxRecords=1000,$increament=100){
		$rowList="";
		for($i=100;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 
	
		$page						= 1; // get the requested page 
		$limit						= 100;
		$count					= sizeof($arrCounts);				
		if( $count >0 ){ 
			$total_pages 		= ceil($count/$limit); 
		}else{ 
			$total_pages 		= 0; 
		} 
		$data1['records'] 		= $count;
		$data1['total']   		= $total_pages;
		$data1['page']    		= $page;				
		$data1['rows']   	= $arrCounts;  
	
?>

<style>
	#orgImportStatusContiner label.errorStatus {
		font-weight: normal;
		color: red;
	}
	#orgImportStatusContiner label.successStatus {
		font-weight: normal;
		color: green;
	}
	#orgImportStatusContiner label.statusCategory {
		font-size: 14px;
	}
	#orgImportStatusContiner{
		border-bottom: 1px solid #BBBBBB;
	}
</style>

<div id="orgImportStatusContiner" class="content-box">
	<?php if($type=='Payer'){ 
			foreach($arrImportStatusMsg  as $key=>$arrMes){
				foreach($arrMes as $key1=>$arrMessage){ ?>
					<div class="col-md-12" style="text-align: center;">
						Status Of <?php echo $key1?>
					</div>
					<!-- Start of overview Status -->
					<?php if(isset($arrMessage['overview'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Overview Info Import Status</label> :
					<?php if(isset($arrMessage['overview']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['overview']['no_cin_num']) && sizeof($arrMessage['overview']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['overview']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['overview']['existingOrgs']) && sizeof($arrMessage['overview']['existingOrgs'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing Organizations : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['overview']['existingOrgs'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['overview']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['overview']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['overview']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of overview Status -->
				<hr size="10px;">
				<!-- Start of Address Status -->
					<?php if(isset($arrMessage['address'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Address Info Import Status</label> :
					<?php if(isset($arrMessage['address']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['address']['no_cin_num']) && sizeof($arrMessage['address']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['address']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['address']['no_matching_cin_num']) && sizeof($arrMessage['address']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['address']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['address']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['address']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['address']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of Address Status -->
				<hr size="10px;">
				<!-- Start of Social Media Status -->
					<?php if(isset($arrMessage['facts'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Facts Info Import Status</label> :
					<?php if(isset($arrMessage['facts']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['facts']['no_cin_num']) && sizeof($arrMessage['facts']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['facts']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['facts']['no_matching_cin_num']) && sizeof($arrMessage['facts']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['facts']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['facts']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['facts']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['facts']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>			
				</div>
				<?php }?>
				<!-- End of Social Media Status -->
				<hr size="10px;">
				<!-- Start of Key People Status -->
					<?php if(isset($arrMessage['key_people'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Key People Info Import Status</label> :
					<?php if(isset($arrMessage['key_people']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['key_people']['no_cin_num']) && sizeof($arrMessage['key_people']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['key_people']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['key_people']['no_matching_cin_num']) && sizeof($arrMessage['key_people']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['key_people']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['key_people']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['key_people']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['key_people']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>				
				</div>
				<?php }?>
				<!-- End of Key People Status -->
				<hr size="10px;">
				<!-- Start of enrollment Status -->
					<?php if(isset($arrMessage['enrollment'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Enrollment Import Status</label> :
					<?php if(isset($arrMessage['enrollment']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['enrollment']['no_cin_num']) && sizeof($arrMessage['enrollment']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['enrollment']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['enrollment']['no_matching_cin_num']) && sizeof($arrMessage['enrollment']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['enrollment']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['enrollment']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['enrollment']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['enrollment']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>					
				</div>
				<?php }?>
				<!-- End of enrollment Status -->
				<hr size="10px;">
				<!-- Start of Formulary Status -->
					<?php if(isset($arrMessage['formulary'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Formulary Import Status</label> :
					<?php if(isset($arrMessage['formulary']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['formulary']['no_cin_num']) && sizeof($arrMessage['formulary']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['formulary']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['formulary']['no_matching_cin_num']) && sizeof($arrMessage['formulary']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['formulary']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['formulary']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['formulary']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['formulary']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>					
				</div>
				<?php }?>
				<!-- End of formulary Status -->
				<hr size="10px;">
				<!-- Start of collabaration Status -->
					<?php if(isset($arrMessage['collabaration'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Collaboration Import Status</label> :
					<?php if(isset($arrMessage['collabaration']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['collabaration']['no_cin_num']) && sizeof($arrMessage['collabaration']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['collabaration']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['collabaration']['no_matching_cin_num']) && sizeof($arrMessage['collabaration']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['collabaration']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['collabaration']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['collabaration']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['collabaration']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>					
				</div>
				<?php }?>
				<!-- End of collabaration Status -->
				<hr size="10px;">
				<!-- Start of Disease Management Status -->
					<?php if(isset($arrMessage['disease_management'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Disease Management Import Status</label> :
					<?php if(isset($arrMessage['disease_management']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['disease_management']['no_cin_num']) && sizeof($arrMessage['disease_management']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['disease_management']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['disease_management']['no_matching_cin_num']) && sizeof($arrMessage['disease_management']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['disease_management']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['disease_management']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['disease_management']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['disease_management']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>					
				</div>
				<?php }?>
				<!-- End of Disease Management Status -->
				<hr size="10px;">
				<!-- Start of Publication Status -->
					<?php if(isset($arrMessage['publication'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Publication Import Status</label> :
					<?php if(isset($arrMessage['publication']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['publication']['no_cin_num']) && sizeof($arrMessage['publication']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['publication']['no_matching_cin_num']) && sizeof($arrMessage['publication']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>
					<?php if(isset($arrMessage['publication']['pmid_exist']) && sizeof($arrMessage['publication']['pmid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing publications : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['pmid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }			
						 } ?>
					<?php if(isset($arrMessage['publication']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['publication']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['publication']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>				
				</div>
				<?php }?>
				<!-- End of publication Status -->
				<hr size="10px;">
				<!-- Start of Trial Status -->
					<?php if(isset($arrMessage['trial'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Trial info Import Status</label> :
					<?php if(isset($arrMessage['trial']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['trial']['no_cin_num']) && sizeof($arrMessage['trial']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['trial']['no_matching_cin_num']) && sizeof($arrMessage['trial']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>
					<?php if(isset($arrMessage['trial']['ctid_exist']) && sizeof($arrMessage['trial']['ctid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing trails : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['ctid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }			
						 } ?>
					<?php if(isset($arrMessage['trial']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['trial']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['trial']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>				
				</div>
				<?php }?>
				<!-- End of Trails Status -->
				<?php }
			}	
		  }else{
		  	foreach($arrImportStatusMsg  as $key=>$arrMes){
		  		foreach($arrMes as $key1=>$arrMessage){ ?>
		  			<div class="col-md-12" style="text-align: center;">
						Status Of <?php echo $key1?>
					</div>
					<!-- Start of overview Status -->
					<?php if(isset($arrMessage['overview'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Overview Info Import Status</label> :
					<?php if(isset($arrMessage['overview']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['overview']['no_cin_num']) && sizeof($arrMessage['overview']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['overview']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['overview']['existingOrgs']) && sizeof($arrMessage['overview']['existingOrgs'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing Organizations : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['overview']['existingOrgs'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['overview']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['overview']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['overview']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of overview Status -->
				<hr size="10px;">
				<!-- Start of Address Status -->
					<?php if(isset($arrMessage['address'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Address Import Status</label> :
					<?php if(isset($arrMessage['address']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['address']['no_cin_num']) && sizeof($arrMessage['address']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['address']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['address']['no_matching_cin_num']) && sizeof($arrMessage['address']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing Organizations : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['address']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['address']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['address']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['address']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of Address Status -->
				<hr size="10px;">
				<!-- Start of Social Media Status -->
					<?php if(isset($arrMessage['social_media'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Social Media Import Status</label> :
					<?php if(isset($arrMessage['social_media']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['social_media']['no_cin_num']) && sizeof($arrMessage['social_media']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['social_media']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['social_media']['no_matching_cin_num']) && sizeof($arrMessage['social_media']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['social_media']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['social_media']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['social_media']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['social_media']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of Social Media Status -->
				<hr size="10px;">
				<!-- Start of Key People Status -->
					<?php if(isset($arrMessage['key_people'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Key People Import Status</label> :
					<?php if(isset($arrMessage['key_people']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['key_people']['no_cin_num']) && sizeof($arrMessage['key_people']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['key_people']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['key_people']['no_matching_cin_num']) && sizeof($arrMessage['key_people']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['key_people']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['key_people']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['key_people']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['key_people']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of key_people Status -->
				<hr size="10px;">
				<!-- Start of Affiliate Patnerships Status -->
					<?php if(isset($arrMessage['affiliate_patnership'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Affiliate Patnerships Import Status</label> :
					<?php if(isset($arrMessage['affiliate_patnership']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['affiliate_patnership']['no_cin_num']) && sizeof($arrMessage['affiliate_patnership']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['affiliate_patnership']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['affiliate_patnership']['no_matching_cin_num']) && sizeof($arrImportStatusMsg['affiliate_patnership']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['affiliate_patnership']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['affiliate_patnership']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['affiliate_patnership']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['affiliate_patnership']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of Affiliate Patnerships Status -->
				<hr size="10px;">
				<!-- Start of Mediacal Services Status -->
					<?php if(isset($arrMessage['mediacal_services'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Mediacal Services Import Status</label> :
					<?php if(isset($arrMessage['mediacal_services']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['mediacal_services']['no_cin_num']) && sizeof($arrMessage['mediacal_services']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['mediacal_services']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['mediacal_services']['no_matching_cin_num']) && sizeof($arrMessage['mediacal_services']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['mediacal_services']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['mediacal_services']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['mediacal_services']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['mediacal_services']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of Mediacal Services Status -->
				<hr size="10px;">
				<!-- Start of Other Locations Status -->
					<?php if(isset($arrMessage['other_locations'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Other Locations Import Status</label> :
					<?php if(isset($arrMessage['other_locations']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['other_locations']['no_cin_num']) && sizeof($arrMessage['other_locations']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['other_locations']['no_cin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['other_locations']['no_matching_cin_num']) && sizeof($arrMessage['other_locations']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['other_locations']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['other_locations']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['other_locations']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['other_locations']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>
				</div>
				<?php }?>
				<!-- End of Other Locations Status -->
				<hr size="10px;">
				<!-- Start of Stats Facts Services Status -->
					<?php if(isset($arrMessage['stats_facts'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Stats Facts Services Import Status</label> :
					<?php if(isset($arrMessage['stats_facts']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['stats_facts']['no_cin_num']) && sizeof($arrMessage['stats_facts']['no_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No CIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['stats_facts']['no_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['stats_facts']['no_matching_cin_num']) && sizeof($arrImportStatusMsg['stats_facts']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching CIN_NUM in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['stats_facts']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['stats_facts']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['stats_facts']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['stats_facts']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of Stats Facts Status -->
				<hr size="10px;">
				<!-- Start of Publication Services Status -->
					<?php if(isset($arrMessage['publication'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Publication info Import Status</label> :
					<?php if(isset($arrMessage['publication']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['publication']['no_cin_num']) && sizeof($arrMessage['publication']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['publication']['no_matching_cin_num']) && sizeof($arrMessage['publication']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>
					<?php if(isset($arrMessage['publication']['pmid_exist']) && sizeof($arrMessage['publication']['pmid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing Publication : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['pmid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }				
						 } ?>
					<?php if(isset($arrMessage['publication']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['publication']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['publication']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of Publication Status -->
				<hr size="10px;">
				<!-- Start of Trial Status -->
					<?php if(isset($arrMessage['trial'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Trial info Import Status</label> :
					<?php if(isset($arrMessage['trial']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['trial']['no_cin_num']) && sizeof($arrMessage['trial']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['trial']['no_matching_cin_num']) && sizeof($arrMessage['trial']['no_matching_cin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_matching_cin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>
					<?php if(isset($arrMessage['trial']['ctid_exist']) && sizeof($arrMessage['trial']['ctid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing Trials : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['ctid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }				
						 } ?>
					<?php if(isset($arrMessage['trial']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['trial']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['trial']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
				</div>
				<?php }?>
				<!-- End of Trials Status -->
		  		<?php }
		  	}
		  }
	?>
</div>
<div class="clearfix"></div>
<script>
	$(document).ready(function(){
		var data = <?php echo json_encode($data1);?>;
		//alert(data.toSource());
		
	<?php if($type=='Payer'){?>
		jQuery("#JQBlistAffResultSet").jqGrid({
		  
			datatype: "jsonstring",
	        datastr: data,
			colNames:['Id','Organization Name','enrollementCount','formularyCount','keyPeopleCount','diseaseCount'],
		   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'name',index:'name',width:500, resizable:false},
				   		{name:'enrollementCountAfterImport',index:'enrollementCountAfterImport',width:500, resizable:false},
				   		{name:'formularyCountAfterImport',index:'formularyCountAfterImport',width:500, resizable:false},
				   		{name:'keyPeopleCountAfterImport',index:'keyPeopleCountAfterImport',width:500, resizable:false},
				   		{name:'diseaseCountAfterImport',index:'diseaseCountAfterImport',width:500, resizable:false}
				   		
		   	],
		   	rowNum:100,
		   	rownumbers: true,
		   	autowidth: true, 
			
			gridComplete: function(){ 
	    		jQuery("#JQBlistAffResultSet").jqGrid('navGrid','hideCol',"id"); 
	    		var ALL = '<?php echo $count?>' ;
	    		$.each($('.ui-pg-selbox'),function(){
	    			$(this).children('option:last').val(ALL).text('All');
	    		});
	    	}, 
		   	loadonce:true,
		   	multiselect: false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",
		   	width: 800,  
		   	pager: '#listlistAffPage',
		   	toppager:true,
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
			rowList:paginationValues,
		    jsonReader: { repeatitems : false, id: "0" },
		    //toolbar: "top",
		    caption:"Imported Counts",
		    rowList:[<?php echo listRecordsPerPage()?>]
	   	
		});

		jQuery("#JQBlistAffResultSet").jqGrid('navGrid','#listlistAffPage',{edit:false,add:false,del:false,search:false,refresh:false});
		
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistAffResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistAffResultSet").jqGrid('navButtonAdd',"#listlistAffPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 
		

	        <?php }else{?>
		        jQuery("#JQBlistAffResultSet").jqGrid({
		  		  
					datatype: "jsonstring",
			        datastr: data,
					colNames:['Id','Organization Name','Medical Services','Key Peoples','Pmid','Ctid'],
				   	colModel:[
								{name:'id',index:'id', hidden:true},
						   		{name:'name',index:'name',width:500, resizable:false},
						   		{name:'medicalCountAfterImport',index:'medicalCountAfterImport',width:500, resizable:false},
						   		{name:'keyPeopleCountAfterImport',index:'keyPeopleCountAfterImport',width:500, resizable:false},
						   		{name:'pmidCountAfterImport',index:'pmidCountAfterImport',width:500, resizable:false},
						   		{name:'ctidCountAfterImport',index:'ctidCountAfterImport',width:500, resizable:false}
						   		
				   	],
				   	rowNum:100,
				   	rownumbers: true,
				   	autowidth: true, 
					
					gridComplete: function(){ 
			    		jQuery("#JQBlistAffResultSet").jqGrid('navGrid','hideCol',"id"); 
			    		var ALL = '<?php echo $count?>' ;
			    		$.each($('.ui-pg-selbox'),function(){
			    			$(this).children('option:last').val(ALL).text('All');
			    		});
			    	}, 
				   	loadonce:true,
				   	multiselect: false,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",
				   	width: 800,  
				   	pager: '#listlistAffPage',
				   	toppager:true,
				   	mtype: "POST",
				   	sortname: 'name',
				    viewrecords: true,
				    sortorder: "desc",
					rowList:paginationValues,
				    jsonReader: { repeatitems : false, id: "0" },
				    //toolbar: "top",
				    caption:"Imported Counts",
				    rowList:[<?php echo listRecordsPerPage()?>]
			   	
				});
	
				jQuery("#JQBlistAffResultSet").jqGrid('navGrid','#listlistAffPage',{edit:false,add:false,del:false,search:false,refresh:false});
				
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistAffResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistAffResultSet").jqGrid('navButtonAdd',"#listlistAffPage",{
					caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}							
					} 
				}); 
				
	        <?php }?>
		
	});
	//- End of DOCUMENT.READY function
	
	
</script>

<div id="affsListingContainer" class="content-box">
	<div id="searchResultsContainer" class="col-md-12">
		<div class="gridWrapper" id="gridContainer">
			<div id="listlistAffPage"></div>
			<table id="JQBlistAffResultSet"></table>
		</div>	
	</div>
</div>