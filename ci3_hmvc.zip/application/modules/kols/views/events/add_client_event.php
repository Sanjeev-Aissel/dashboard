<?php
 /**
* Description:File to create 'add'view for Client Event  module
* @author:Vinayak
* @since :2.2
* Created on:may 5, 2011
* @package application.views.events
*/

$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 300, noCache: true, minChars: 3";
?>

<!--  Autocomplete Plugin
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script> -->
<style type="text/css">
	.clientForm label {
		width:105px;
	}
	.clientForm input[type="text"]{
		width:126px;	
	}
	.clientForm select, .clientForm textarea{
		width:134px;	
	}
	.clientForm input.event_name{
		width:651px;
	}
	.clientForm .innerTable input{
		width:257px;
	}
	
	/* To reduce the Spacing, in the 'Modal Box' */
	table.innerTable{
		margin:0;
	}
	
	table.innerTable td{
		padding-bottom:0;
	}
	.clientForm label.error {
		padding: 0 0 0 56px;
	}
	#sponcerType{
		 width: 269px;	
	}
	.autocomplete label{
	   height: 100%;
	}
</style>
<script type="text/javascript">

	var otherTopicId=0;

	//validate month date,year and alos the validate for start and End year
	function isValidDate(date,isStartDate,otherDate,eventType){
		$("#"+eventType+"StartContainer .error").remove();
		$("#"+eventType+"EndContainer .error").remove();
		var month=date.substring(0,2);
		var day=date.substring(3,5);
		var year=date.substring(6);
		var isDateValid=true;
		
		if(month>12)
			isDateValid=false;
		if(day>31)
			isDateValid=false;
		if(year.length<4)
			isDateValid=false;
		if(date!='' && !isDateValid){
			var errorFiled="<label  class=\"error\">Invalid Date<\/label>";
			if(isStartDate)
				$("#"+eventType+"StartContainer").append(errorFiled);
			else
				$("#"+eventType+"EndContainer").append(errorFiled);
			return false;
		}
		else{
			if(!(date=='' || otherDate=='')){
				var date1=new Date(month+" "+ day+","+ year);
				var date2=new Date(otherDate.substring(0,2)+" "+ otherDate.substring(3,5)+","+ otherDate.substring(6));
				if(isStartDate){
					var difference = date2 - date1;
					if(difference<0){
						var errorFiled="<label  class=\"error\">Should be Less than End Year<\/label>";
						$("#"+eventType+"StartContainer").append(errorFiled);
						return false;
					}
				}
				else{
					var difference = date1 - date2;
					if(difference<0){
						var errorFiled="<label  class=\"error\">Should be Greater than Start Year<\/label>";
						$("#"+eventType+"EndContainer").append(errorFiled);
						return false;
					}
				}
			}
			return true;
		}
	}

	
	function validateDateFormat(e,src) {
		if (!e) var e = window.event
		if (e.keyCode) code = e.keyCode;
		else if (e.which) code = e.which;
	 
	 	if(src.value == null || src.value == "") {
	 		return true;
	 	}
	 
		if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
			jAlert("Please enter the date in mm/dd/yyyy format!");
			src.focus();
		}
	}
	
	function dateFormat(e,src) {		
		if (!e) var e = window.event
		if (e.keyCode) code = e.keyCode;
		else if (e.which) code = e.which;
		
		if(code != 37 && code != 38 && code != 39 && code != 40) { 
			if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
				src.value=src.value.replace(/[^0-9\/]/g,'');  
			
				if(code!=8 && code!=46) // not backspace or delete
				{	
					src.value=src.value.replace(/[^0-9]/g,'');
					
					if (src.value.length == 2) {
				        src.value += "/";
				    }
				    				
					if (src.value.length > 2) {
						if(src.value.indexOf('/') != 2) {
							src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
						}
					}
					
					if (src.value.length == 5) {
				        src.value += "/";
				    }
				    
					if (src.value.length > 5) {
						if(src.value.lastIndexOf('/') != 5) {
							src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
						}
					}
					
					if(src.value.length >= 10)
					{
						return false;
					}
				}  
			}
		}
		return true;
	}



	function getStatesByCountryId(idName){
	
		var countryId=$('#countryId' + idName).val();
		var params = "country_id="+countryId;	
		$("#stateId" + idName).html("<option>select state</option>");
		$("#cityId" + idName).html("<option>select city</option>");
		
		var states = document.getElementById('stateId' + idName);
		$.ajax({
			url: "<?php echo base_url()?>/country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){
				var selectedIndex	= '';					
				$.each(responseText, function(key, value) {				
					/*var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);	*/
					 selectedIndex	= '';
					if($('#stateIdHidden').val()>0 && $('#stateIdHidden').val()===value.state_id){
						selectedIndex	= ' selected="selected"';
					} 
					 $('#stateId' + idName).append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
				});
				//alert($('#stateIdHidden').val());
				getCitiesByStateId(idName);
			}		
		});		
		
	}
	
	function getCitiesByStateId(idName){
		var stateId=$('#stateId' + idName).val();
		
		$("#cityId" + idName).html("<option>select city</option>");	
		var cities = document.getElementById('cityId' + idName);
		var params = "state_id="+stateId;	
		
		$.ajax({
			url: "<?php echo base_url()?>/country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){
				var selectedIndex	= '';							
				$.each(responseText, function(key, value) {	
							
				/*var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);		*/
    				selectedIndex	= '';
    				if($('#cityIdHidden').val()>0 && $('#cityIdHidden').val()===value.city_id){
    					selectedIndex	= ' selected="selected"';
    				} 
    				 $('#cityId' + idName).append('<option value="'+value.city_id+'"'+selectedIndex+'>'+value.city_name+'</option>');	 		
				});		
				
			}		
		});		
		
	}

	var confEventNameAutoCompleteOptions={

			serviceUrl: '<?php echo base_url();?>kols/get_eventLookup_names/conference',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.educations').text();
				var selId = $(event).children('.educations').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#confEventName').val(selText);
				$('#confEventId').val(selId);
				if(event.length>20){
					//$('#orgIdForAutocomplete').val(kolId);
					if(event.substring(0,21)=="No results found for "){
						return false;
					}
				}
			}		
			

	};
	
	var validationRules	=  {
			event_name: {
				required:true
			},
			start_date: {
				fullYear: true
			},
			end_date: {
				fullYear: true
			},
			eduUrl1: {
				url: true
			},
			eduUrl2: {
				url: true
			},
			event_type: {
				required:true
			},
			session_type: {
				required:true
			}
		};

		var validationMessages = {
			event_name: {
				required: "Required."
			},
			start_date: "Only full year is allowed. Ex: 2010",
			end_date: "Only full year is allowed. Ex: 2010",
			url: "Please enter a valid URL address",
			event_type: {
				required:"Required."
			},
			session_type: {
				required:"Required."
			}
		};

		//Opens the tab based topics in a model box
		function showAllTopics(){
			//$( "#eventTopics" ).dialog({ position: [e.clientX,e.clientY-130] });
			$("#eventTopics .profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#eventTopics").dialog("open");
			$("#eventTopics .profileContent").load('<?php echo base_url().'kols/view_all_topics/'?>',{},
					function(){
				});
		}

		function addSelectedTopicToList(value,text){
			//remove the other specialty topics from the conference topics select box
			if(otherTopicId!=0)
				removeTopic(otherTopicId);
			var topics = document.getElementById('confTopic');
			var newTopic = document.createElement('option');
			newTopic.text = text;
			newTopic.value = value;
			 var prev = topics.options[topics.selectedIndex];
			 topics.add(newTopic, prev);
			 topics.value=value;
			 //set this as a other specialty topic
			 otherTopicId=value;
		}

		//Removes the given option from the conference topics select box
		function removeTopic(topicId){			
			$("#confTopic  option").each(function(){
				if($(this).val()==topicId)
					$(this).remove();
			});
		}
		
	$(document).ready(function(){

		// Trigger the Autocompleter for 'Event Name' field of type 'Conference Event'
    	a = $('#confEventName').autocomplete(confEventNameAutoCompleteOptions);	
    	$('#confEventName').attr("autocomplete",'on');
		$("#conferenceForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		$('#confStart').datepicker({
			dateFormat: 'mm/dd/yy'
		});

		$('#confEnd').datepicker({
			dateFormat: 'mm/dd/yy'
		});

		// Settings for the Dialog Box
		var eventAllTopicsDialogOpts = {
				title: "",
				modal: true,
				autoOpen: false,
				width:420,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};

		
		$("#eventTopics").dialog(eventAllTopicsDialogOpts);

		getStatesByCountryId(1);
		
	});

	//saveConference
	$("#saveConference").click(function(){		
		$(this).prop('disabled', true);	
		var address = $("#confAddress").val();
		var postalCode = $("#confPostalCode").val();
		var country = $("#countryId1 option:selected").text();
		var state = $("#stateId1 option:selected").text();
		var city = $("#cityId1 option:selected").text();
		var dataString = 'address='+address+'&country='+country+'&state='+state+'&city='+city+'&postalCode='+postalCode;
		$.ajax({
			type: "POST",
			url: "<?php echo base_url()?>kols/get_lat_long_dynamically",
			data: dataString,
			cache: false,
			success: function(jsonResult){
				var result = $.parseJSON(jsonResult);
				if(result){
					$("#latitude").val(result.lat);
					$("#longitude").val(result.lon);
				}else{
					//alert("Latitude and Longitude not found for given address");
					$("#latitude").val('');
					$("#longitude").val('');
				}
			},
			complete: function (jsonResult) {
				saveConferenceDetail();
		    }
		});
	});
	
</script>	
		<div class="formHeader"><h5>Events</h5></div>
		<div class="eventMsgBox"></div><div class="msgBoxContainer"></div>
		<form action="<?php if($arrEventData){echo 'update_event';}else{echo 'save_event';}?>" method="post" id="conferenceForm" name="conferenceForm" class="validateForm clientForm" onsubmit="return validateEvents();">
			<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId?>"></input>
			<table class="analystForm clientEventForm" id="conferenceTbl">
				<tr>	
					<td colspan="3">		
						<p>
							<label for="confEventName">Event Name:<span class="required">*</span></label>
							<input type="hidden" name="type" value="conference">
							<input type="hidden" name="id" id="confId" value="<?php if($arrEventData['id']){echo $arrEventData['id'];}?>"></input>
							<input type="hidden" name="event_id" id="confEventId" value="<?php if($arrEventData['id']){echo $arrEventData['id'];}?>"></input>
							<input type="text" name="event_name" value="<?php if($arrEventData['name']){echo $arrEventData['name'];}?>" id="confEventName" class="required event_name autocompleteInputBox"></input>
						</p>
					</td>
				</tr>
					<tr>
					<td colspan="3">
						<table class="innerTable">
							<tr>
								<td>
									<p>
										<label for="sponcerType">Sponsor Type:</label>
											<select name="sponsor_type" id="sponcerType">
									   			<option value="">--- Select ---</option>
												<?php 
													foreach($arrEventSponsorTypes as $key => $value){
														if($arrEventData['sponsor_type'] == $key){
															echo '<option value="'.$key.'" selected>'.$value.'</option>';
														}else{
															echo '<option value="'.$key.'">'.$value.'</option>';
														}
													}
												?>
					    				</select>
									</p>
								</td>
								<td>
									<p>
										<label for="sponcerType">Session Sponsor:</label>
										<input type="text" name="session_sponsor" value="<?php if($arrEventData['session_sponsor']){echo $arrEventData['session_sponsor'];}?>" id="sessionSponsor" class="session_sponsor"></input>
									</p>
								</td>
							</tr>
						</table>
					</td>
				</tr>	
				 <tr>
						<td>
							<p>
								<label for="confSessionName">Session Name:</label>
								<input type="text" name="session_name" value="<?php if($arrEventData['session_name']){echo $arrEventData['session_name'];}?>" id="confSessionName" class="session_name"></input>
							</p>
						</td>
						<td>
							<p>
								<label for="confOrganizer">Organizer:</label>
								<input type="text" name="organizer" value="<?php if($arrEventData['organizer']){echo $arrEventData['organizer'];}?>" id="confOrganizer" class="session_name"></input>
							</p>
						</td>
				
						<td>
							<p>
								<label for="organizerType">Organizer Type:</label>
									<select name="organizer_type" >
							   			<option value="">--- Select ---</option>
										<?php 
											foreach($arrEventOrganizerTypes as $key => $value){
												if($arrEventData['organizer_type'] == $key){
													echo '<option value="'.$key.'" selected>'.$value.'</option>';
												}else{
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												
											}
										?>
			    				</select>
							</p>
						</td>
			
				</tr>			
							
				<tr>	
					<td>	
						<p>
							<label for="confEventType">Event Type:<span class="required">*</span></label>
							<select name="event_type" id="confEventType" class="required">
					   			<option value="">--- Select ---</option>
								<?php 
									foreach($arrConfEventTypes as $key => $value){
										if($arrEventData['event_type'] == $key){
											echo '<option value="'.$key.'" selected>'.$value.'</option>';
										}else{
											echo '<option value="'.$key.'">'.$value.'</option>';
										}
									}
								?>
					    	</select>
						</p>
					</td>
			
					<td>	
						<p>
							<label for="confSessionType">Session Type:<span class="required">*</span></label>
							<select name="session_type" id="confSessionType" class="required">
					   			<option value="">--- Select ---</option>
								<?php 
									foreach($arrConfSessionTypes as $key => $value){
										if($arrEventData['session_type'] == $key){
											echo '<option value="'.$key.'" selected>'.$value.'</option>';
										}else{
											echo '<option value="'.$key.'">'.$value.'</option>';
										}
									}
								?>
					    	</select>								
						</p>
					</td>
					<td>	
						<p>
							<label for="confRole">Role:<span class="required">*</span></label>
							<select name="role" id="confRole" class="required">
						   			<option value="">--- Select ---</option>
									<?php 
										foreach($arrRoles as $key => $value){
											if($arrEventData['role'] == $value){
												echo '<option value="'.$value.'" selected>'.$value.'</option>';
											}else{
												echo '<option value="'.$value.'">'.$value.'</option>';
											}
										}
									?>
						    	</select>		
						</p>	
					</td>
				</tr>
				<tr>
					<td>	
						<p>
							<label for="confTopic">Topic:</label>
							<select name="topic" id="confTopic">
					     		<option value=0>--- Select ---</option>
								<?php 
									foreach($arrTopics as $key => $value){
										if($arrEventData['topic'] == $key){
											echo '<option value="'.$key.'" selected>'.$value['name'].'</option>';
										}else{
											echo '<option value="'.$key.'">'.$value['name'].'</option>';
										}
										
									}
								?>
					    	</select>
					    	<a id="allTopicBtn" href="#" onclick="showAllTopics();">all</a>
						</p>
					</td>
				
					<td>	
						<p id="confStartContainer">
							<label for="confStart">Start:</label>
							<input type="text" name="start" value="<?php if($arrEventData['start']){echo sql_date_to_app_date($arrEventData['start']);}?>" id="confStart" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,true,end.value,'conf')"></input>
						</p>
					</td>
					<td>	
						<p id="confEndContainer">
							<label for="confEnd">End:</label>
							<input type="text" name="end" value="<?php if($arrEventData['end']){echo sql_date_to_app_date($arrEventData['end']);}?>" id="confEnd" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,false,start.value,'conf')"></input>
						</p>																											
					</td>
				</tr>
				<tr>
					<td>	
						<p>
							<label for="confLocation">Location:</label>
							<input type="text" name="location" value="<?php if($arrEventData['location']){echo $arrEventData['location'];}?>" id="confLocation"></input>
						</p>
					</td>
					<td>	
						<p>
							<label for="confAddress">Address:</label>
							<input type="text" name="address" value="<?php if($arrEventData['address']){echo $arrEventData['address'];}?>" id="confAddress"></input>
						</p>
					</td>
					<td>	
						<p>
							<label for="confPostalCode">Postal Code:</label>
							<input type="text" name="postal_code" value="<?php if($arrEventData['postal_code']){echo $arrEventData['postal_code'];}?>" id="confPostalCode"></input>
						</p>
					</td>
				</tr>
					
				<tr>
					<td>	
						<p>
							<label for="countryId1">Country:</label>
							<select name="country_id" id="countryId1" onchange="getStatesByCountryId(1);">
								<option value="">-- Select --</option>
								<?php foreach( $arrCountry as $country ){ ?>
								<?php if($arrEventData['country_id']){ ?>
									<option value="<?php echo $country['country_id'];?>" <?php if($country['country_id']==$arrEventData['country_id']){?> selected="selected" <?php }?>>
								<?php echo $country['country_name'];?>
									</option>
								<?php }else{?>
									<option value="<?php echo $country['country_id'];?>" >
								<?php echo $country['country_name'];?>
									</option>
								<?php } }?>
							</select>
						</p>
					</td>
					<td>										
						<p>
							<label for="stateId1">State:</label>
							<input type="hidden" value="<?php echo $arrEventData['state_id']; ?>" id="stateIdHidden" name="stateIdHidden"/>
							<select name="state_id" id="stateId1" onchange="getCitiesByStateId(1);">		
								<option>Select State</option>
							</select>
						</p>
					</td>
					<td>
						<p>
							<label for="cityId1">City:</label>
							<input type="hidden" value="<?php echo $arrEventData['city_id']; ?>" id="cityIdHidden" name="cityIdHidden"/>
							<select name="city_id" id="cityId1">
								<option >Select City</option>		
							</select>
						</p>
					</td>
				</tr>
				<tr>
					<td colspan="3">
						<p>
							<label for="confUrl1">URL:</label>
							<input type="text" name="url1" value="<?php if($arrEventData['url1']){echo $arrEventData['url1'];}?>" id="confUrl1" class="url event_name"></input>
						</p>	
					</td>
				</tr>
				
				<tr>
					<td colspan="3">
						<div class="formButtons">
							<input type="hidden" name="latitude" id="latitude"/>
							<input type="hidden" name="longitude" id="longitude"/>
							<input type="submit" value="Save" name="submit" id="saveConference">
						</div>
					</td>
				</tr>
			</table>	
		</form>	
		
		<!-- Container for the 'All Topics' modal box -->
		<div id="dailog1">	
			<div id="eventTopics" class="microProfileDialogBox">
				<div class="profileContent"></div>
			</div>
		</div>
		<!-- End of the Container for the 'All Topics' modal box -->
