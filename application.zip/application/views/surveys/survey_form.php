<?php
$type;
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 14-03-2013
 *  
 */

	$autoSearchOptionsForKolName = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
	
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery/jquery.validate1.9.min',
							'chosen.jquery',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	.addNewAnswer{
		 margin-left: 17px;
	}
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	#addSurvey{
	/*	width: 805px;
		margin-top: -75px;*/
		margin-top: 0px;
	/*	float: right;*/
	}
	legend {
	    color: #626262;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		background-color:#C4D8EF;
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -274px transparent;
		color: #4D7BD6;
		background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
		background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
		background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		border: 1px solid #DADAEE;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	select.chosenSelect{
		width:200px;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.alignLeft{
		text-align: left;
	}
	.alignTop{
		vertical-align: top;
	}
	h5{
		background:url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
		padding:2px;
	}
	label.lblName{
		display: inline-block;
	    text-align: center;
	    width: 200px;
	}
	label.lblCountry,label.lblState,label.lblCity{
		display: inline-block;
	    text-align: center;
	}
	.organizationNameAutoComplete, .country, .state, .city, .zipcode,label.lblCountry,label.lblState,label.lblCity,.mdm{
	<?php 
			if(IS_IPAD_REQUEST == 1){
				echo 'width:100px;';
			}else{
				echo 'width:120px; padding-left: 5px;';
			}
		?>
	}
	label.lblZip{
		display: inline-block;
	    text-align: center;
	    width: 130px;
	}
	.chzn-container {
		vertical-align: sub;
		font-size: 13px;
	}
	input[type="text"]{
		height: 21px;
		height: auto;
		font-size: 12px;
	}
	th, td, caption {
	    padding: 4px 5px;
	    padding-right: 0px;
	}
	td p{
		margin: 0px;
	}
	td div.microViewIcon{
		margin: 0px;
	}
	div#contentHolder{
		width: auto !important;
		min-width: 260px;
		max-width: 600px;
	}
	th.borderBottom{
		border-bottom: 1px solid #aaa;
	}
	fieldset{
		border-color:#2b9af3;
		margin-top: 10px;
	}
	legend{
	    color: #2b9af3;
	    padding-bottom: 5px;
	    padding-top: 5px;
	}
	label{
		font-weight:normal;
	}
	span.required{
		color:red;
	}
	span.tags{
		font-weight: normal;
		color: #090;
	}
	#surveyContainer .advSearchIcon {
		background-image: url("<?php echo base_url();?>images/ipad/header/search_active.svg");
	    background-position: 9px 0;
	    background-repeat: no-repeat;
	    background-size: 18px auto;
	    padding-left: 8px !important;
	}
	.saveIcon{
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -219px -32px transparent !important;
	}
	.existingData input[type="text"]{
		border: 0px;
		background: none;
	}
	.microView{
		<?php 
			if(IS_IPAD_REQUEST == 1){
				echo 'left: 17% !important;';
			}else{
				//echo 'left: 28.7% !important;';
			}
		?>
	}
	#surveyContainer input.autocompleteInputBox {
		height: 23px !important;
		/*vertical-align: bottom !important;*/
	}
	#surveyContainer{
		position: relative;
	}
	#tooltip-resp-details{
		left: 120px;
    	position: absolute;
    	top: 32px;
	}
	#tooltip-survey-fill{
		float: right;
	    left: 3px;
	    position: relative
	}
	input[type="text"], input[type="password"], select{
		padding: 0;
	}
	.labelDelete{
		display: inline-block;
		width:20px;
		margin-top: 2px;
	}
	.autocomplete .address {
		color: #626262;
	    display: block;
	    font-size: 10px;
	    font-weight: normal;
	    line-height: 16px;
	}
	.autocomplete .orgName, .autocomplete label{
		display: block;
		line-height: 12px;
	}
	#respondent_mdm{
		border: 0;	
	}
	.mdm{
		border: 0 !important;	
	}
	.cust label{
		font-weight: bold;
		margin-right: 15px;
	}
	table#surveyDetails{
		border-collapse: collapse !important;
	}
	.cust{
		display: inline;
	}
	div.addIcon{
		background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>images/plus_blue.svg") no-repeat scroll 0 0 / 20px auto !important;
	}
	div.deleteIcon {
	    background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>images/cross_blue.svg") no-repeat scroll 0 0 / 20px auto !important;
	    margin-left: 5px !important;
	}
	.respondentDetails{
		width: 20%;
		float: left;
		display: inline;
	}
	.respondentDetails label {
		font-weight: bold;
	}
	
	.influencerDetails{
		width: 18%;
		float: left;
		display: inline;
	}
	.influencerDetails label {
		font-weight: bold;
	}
	
	.question-holder{
		margin-bottom: 10px;
	}
	.quest{
		background: #dedede;
    	padding-top: 5px;
    	padding-bottom: 5px;
    	padding-left: 10px;
    	padding-right: 10px;
    	font-weight: bold;
	}
	.quest .collapseTheDiv{
    	float: right;
    	display: inline;
	}
	.answer-holder{
		border: 1px solid #dedede;
		padding: 10px;
		display: <?php echo ($type=="update")?'block':'none';?>;
	}
	.question-holder .btns{
		margin-top: 10px;
	}
	.quest-tags{
		color: green;
		font-weight: normal;
	}
	.answerFieldHolder{
		margin-bottom: 10px;
		clear:both;
		border-top:1px solid #ece8e8;
	}
	.answerFieldHolder label{
		font-weight: bold;
	}
	.answer-section {
    clear: both;
}
}
</style>
<script type="text/javascript">
var customOk = "Yes";
var customCancel = "No";
var respondantHaveAnswers=1;
var reEscape = new RegExp("(\\"
		+ [ "/", ".", "*", "+", "?", "|", "(", ")", "[", "]", "{", "}",
				"\\" ].join("|\\") + ")", "g");
var searchedNameRow	= 0;
var globalId	= '';
var arrCount	= new Array();
var isValidatingRespondent	= false;
var surveyKolAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
	<?php echo $autoSearchOptionsForKolName;?>,
	onSelect : function (event, ui){
				var kolId = $(event).children('.id1').html();
				var selText =  $(event).children('.kolName').html();
				autocompleteOnSelect(kolId, selText);
			},

};

$(document).ready(function(){
	$(".collapseTheDiv").click(function(){
		var respodent = $("#respondentName").val();
		if(respodent == ''){
			jAlert("Please add a respondent before adding an influencer");
		}else{
			var id = $(this).attr('id');
			$(this).toggleClass('ui-icon-circle-triangle-s');
			$(this).toggleClass('ui-icon-circle-triangle-n');
		    $("#"+id+"-div").slideToggle("fast");
		}
	});

	$("#respondentName").keyup(function(){
		$("#showHiderespondentDetails").hide();
	});

	initializeInputTooltip();

	$('#respondentName').autocomplete(surveyKolAutoCompleteOptions);
	
	$('.kolNameAutoComplete').each(function (i){
		$('#'+$(this).attr('id')).autocomplete(surveyKolAutoCompleteOptions);
	}); 

	var searchedNames = {
			title: "Search Result",
			modal: true,
			autoOpen: false,
			width: 798,
			draggable:false,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	$("#searchedNames").dialog(searchedNames);

	var addNewKol = {
			title: "Add KOL",
			modal: true,
			autoOpen: false,
			width: 600,
			draggable:false,
			position: ['center', modalBoxTopPosition],
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};

	$("#addNewKol").dialog(addNewKol);
});	

function autocompleteOnSelect(kolId, selText) {
	selText=selText.replace(/\&amp;/g,'&');
	$("#"+globalId).val(selText);
	if(globalId=='respondentName'){
		getKolDetails(kolId,true,globalId);
		isInfluencerRespondentAlreadySurveyed()
	}else{
		getKolDetails(kolId,false,globalId);
	}
}

function isInfluencerRespondentAlreadySurveyed(){
	var thisObj	= $('#respondentName');
	var respondent	= $('#respondentName').val();
	//alert("<?php //echo $surveyId; ?>");
	$.ajax({
		type: "post",
		dataType:"json",
		data:{
	        'respondent_id':respondent
	    },
		url: '<?php echo base_url();?>surveys/isRespondentAlreadySurveyed/<?php echo $surveyId;?>/1',
		success: function(returnData){
			if(returnData.status=='exists'){
				$('#respondentName').val('');
				$('#respondent_org').val('');
				$('#respondent_country').val('');
				$('#respondent_state').val('');
				$('#respondent_city').val('');
				$('#respondent_postal').val('');
				$('#respondent_npi').val('');
				jConfirm("Survey for respondent already exists.. Do you want to view the existing survey?","Please confirm",function(r){
						if(r){
							var userId	= <?php echo $this->session->userdata('user_id');?>;
							respondentId	= 0;
							$.ajax({
								type: "post",
								dataType:"json",
								data:{
							        'respondent':respondent
							    },
								url: '<?php echo base_url();?>surveys/getRespondentIdNew',
								success: function(returnData){
									respondentId	= returnData.id;
									window.location	= base_url+"surveys/edit_survey_data/<?php echo $surveyId;?>/"+respondentId+"/"+userId;
								}
							});
							}else{
								return false;
								}
					});
			}else{
//				getKolDetails(thisObj,true);
			}
		}
	});
}

$(".respondentClass").live("keyup",function(){
	globalId = 'respondentName';
});

$(".kolNameAutoComplete").live("keyup",function(){
	var influencerTextFeildId = $(this).attr("id");
	globalId = influencerTextFeildId;
});

function getKolDetails(kolId,isRespondent,globalId){
	var kolId = kolId;
	$.ajax({
		type: "post",
		dataType:"json",
		data:{
	        'kol_id':kolId
	    },
		url: '<?php echo base_url();?>surveys/get_kol_data_for_survey',
		success: function(returnData){
			console.log(returnData);
			if(returnData){
				$("#"+globalId).val(returnData[0].first_name+' '+returnData[0].middle_name+' '+returnData[0].last_name);
				if(isRespondent){
					$("#respondentId").val(kolId);
					$('#respCity').text(returnData[0].city);
					$('#respState').text(returnData[0].state);
					$('#respCountry').text(returnData[0].country);
					$('#respPostalCode').text(returnData[0].postal_code);
					
					$('#respondent_first_name').val(returnData[0].first_name);
					$('#respondent_middle_name').val(returnData[0].middle_name);
					$('#respondent_last_name').val(returnData[0].last_name);
					$('#respondent_country').val(returnData[0].country);
					$('#respondent_state').val(returnData[0].state);
					$('#respondent_city').val(returnData[0].city);
					$('#respondent_postal_code').val(returnData[0].postal_code);
					$('#respondent_speciality').val(returnData[0].specialty_name);
					$('#respondent_organization').val(returnData[0].org_name);
					$("#showHiderespondentDetails").show();
				}else{
					if(returnData[0].id == $("#respondentId").val()){
						jAlert('Respondent cannot nominate himself');
					}else{
						var getQuestionId = globalId.split(/\s*\-\s*/g);
						var questionId = getQuestionId[1];
						var html = '';
						html += '<div class="answer-section">';
						html += '<div class="influencerDetails"><label>Name:</label> <span>'+returnData[0].first_name+' '+returnData[0].middle_name+' '+returnData[0].last_name+'</span></div>';
						html += '<div class="influencerDetails"><label>City:</label> <span>'+returnData[0].city+'</span></div>';
						html += '<div class="influencerDetails"><label>State:</label> <span>'+returnData[0].state+'</span></div>';
						html += '<div class="influencerDetails"><label>Country:</label> <span>'+returnData[0].country+'</span></div>';
						html += '<div class="influencerDetails"><label>Postal Code:</label> <span>'+returnData[0].postal_code+'</span></div>';
						html += '<div class="influencerDetails" style="width: 5%;"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></div>';

						html += '<input type="hidden" name="influencer_kolid_'+questionId+'[]" id="influencer_kolid" value="'+returnData[0].id+'"/>';
						html += '<input type="hidden" name="influencer_first_name_'+questionId+'[]" id="influencer_first_name" value="'+returnData[0].first_name+'"/>';
						html += '<input type="hidden" name="influencer_middle_name_'+questionId+'[]" id="influencer_middle_name" value="'+returnData[0].middle_name+'"/>';
						html += '<input type="hidden" name="influencer_last_name_'+questionId+'[]" id="influencer_last_name" value="'+returnData[0].last_name+'"/>';
						html += '<input type="hidden" name="influencer_country_'+questionId+'[]" id="influencer_country" value="'+returnData[0].country+'"/>';
						html += '<input type="hidden" name="influencer_state_'+questionId+'[]" id="influencer_state" value="'+returnData[0].state+'"/>';
						html += '<input type="hidden" name="influencer_city_'+questionId+'[]" id="influencer_city" value="'+returnData[0].city+'"/>';
						html += '<input type="hidden" name="influencer_postal_code_'+questionId+'[]" id="influencer_postal_code" value="'+returnData[0].postal_code+'"/>';
						html += '<input type="hidden" name="influencer_speciality_'+questionId+'[]" id="influencer_speciality" value="'+returnData[0].specialty_name+'"/>';
						html += '<input type="hidden" name="influencer_organization_'+questionId+'[]" id="influencer_organization" value="'+returnData[0].org_name+'"/>';
						html += '</div>';
						$("#"+globalId).parent().parent().parent().find(".answers").append(html);
					}
					$("#"+globalId).val('');
				}
			}
		}
	});
}

function initializeInputTooltip(){
	$('td.tooltip-demo').tooltip({
      selector: "input[rel=tooltip]",
      placement:'top'
    });
}

function searchNames(thisObj,isRespondentOrInfluencer,appendId){
	
	searchedNameRow	= $(thisObj).parent().parent().parent().attr('class');
	searchedNameRowId	= $(thisObj).parent().parent().parent().attr('id');
	var data	= '';
	var arrRow	= new Array('name','state','city','postal','mdm');
	$.each($(thisObj).parent().parent().parent().find('input[type="text"]'),function(index, elementObj){
		if(index>0){
			data += '&'+arrRow[index]+'='+$(elementObj).val();
		}else{
			data = arrRow[index]+'='+$(elementObj).val();
		}
	}); 
	$(".searchedNamesContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#searchedNames").dialog("open");
	$.ajax({
		type: "post",
		dataType:"text",
		data:data,
		url: '<?php echo base_url();?>surveys/search_names/'+isRespondentOrInfluencer+'/'+appendId,
		success: function(returnData){
			$('#searchedNames .profileContent').unblock();
			$(".searchedNamesContent").html(returnData);
		}
	});
}
function deleteRow(currentSelection){
	var todelele = $(currentSelection).attr('aid');	
	if(typeof todelele != "undefined"){
			jConfirm("Do you want to delete the existing Influencer from Respondent?","Please confirm",function(r){
				if(r){
					var userId	= <?php echo $this->session->userdata('user_id');?>;
					$.ajax({
						type: "post",
						dataType:"json",
						data:{
					        'todelele':todelele,
					        'user_id' :userId
					    },
						url: '<?php echo base_url();?>surveys/delete_influencer',
						success: function(returnData){
							if(returnData.status=='success'){
								$(currentSelection).parent().parent().remove();
								}
						}
					});
					}else{
						return false;
						}
			});
		}else{
			$(currentSelection).parent().parent().remove();
			}
	
	//$(currentSelection).parent().parent().remove();
}

function addNewKolProfile(thisEle,isRespo,appendId){
	whichOne = isRespo;
	if(isRespo == true || $('#respondentId').val() != ''){
		$(".addNewKolContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addNewKol").dialog("open");
		$(".addNewKolContent").load(base_url+'surveys/add_new_respodent',{},function(){});
	}else{
		appendId = appendId;
		$(".addNewKolContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addNewKol").dialog("open");
		$(".addNewKolContent").load(base_url+'surveys/add_new_respodent/'+appendId,{},function(){});
	}
}

function didNotProvideInfluencers(){
	var isChecked = $('#noInfluencers1').is(":checked");
	if(isChecked){
		$('#noInfluencers2').prop('checked',false);
		$(".fieldSet").hide('slow');
		$(".cust-holder").css("margin-top","15px");
		$(".answers").css("display","none");
		$("#noInfluencers").val('1');
	}else{
		$(".fieldSet").show('slow');
		$(".cust-holder").css("margin-top","0px");
		$(".answers").css("display","block");
		$("#noInfluencers").val('');
	}
}

function doesNotHaveInfluencers(){
	var isChecked = $('#noInfluencers2').is(":checked");
	if(isChecked){
		$('#noInfluencers1').prop('checked',false);
		$(".fieldSet").hide('slow');
		$(".cust-holder").css("margin-top","15px");
		$(".answers").css("display","none");
		$("#noInfluencers").val('2');
	}else{
		$(".fieldSet").show('slow');
		$(".cust-holder").css("margin-top","0px");
		$(".answers").css("display","block");
		$("#noInfluencers").val('');
	}
}

function submit_survey(){
	var pagetype = "<?php echo $type; ?>";
	if($("#respondentName").val() == ''){
		jAlert("Please add a respodent to submit survey");
		return false;
	}
	if($("#noInfluencers").val() == ''){
		if($(".answers").html().length == 0){
			jAlert("Please add an influencers or select checkbox accordingly");
			return false;
		}
	}
	var dataString = $("#survey_form").serialize();
	if(pagetype == 'update'){
		var url = "<?php echo base_url();?>/surveys/save_update_survey_response";
		}else{
		var url = "<?php echo base_url();?>/surveys/save_survey_response";
			}
	$.ajax({
		type: "POST",
		url : url,
		data: dataString,
		cache: false,
		success: function(result){
			result = JSON.parse(result);
			if(result.status == 'success'){
				jAlert("Survey submitted successfully");
				setTimeout(function(){ window.location = "<?php echo base_url()?>surveys/list_surveys"; }, 2500);
				
			}else{
				jAlert("Survey not submitted, please try again");
			}
		}
	});
}
</script>
<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/134479-filling-in-the-peer-nomination-survey-responses' target='_new'>View Additional Help</a>"; ?>
<div id="surveyContainer">
<div id="addSurvey">
<form name="survey_form" id="survey_form">	
	<div class="contentHeader"><span><?php echo $arrSurveyData['name'];?></span></div>
	<input type="hidden" name="survey_id" value="<?php echo $surveyId;?>"/>
	<div style="min-height: 60px;">
		<p style="font-weight: bold;background-color: #eeeeee;padding: 5px;margin-bottom: 10px;">
		Respondent Details
		<span id="tooltip-resp-details" class="map-info tooltop-bottom" style="top: 26px;"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Respondent is the individual who is nominating peers as influencers. Type in a few letters in the Name field to find & choose from matching names. <?php echo $helpLink;?></span>">&nbsp;</a></span>
		</p>
		<div class="respondentDetails">
			<label>Name<span class="required">*</span>:</label>
			<input type="text" name="respondent_name" value="<?php echo $arrRespondent[0]['respondent']; ?>" id="respondentName" class="autocompleteInputBox kolNameRespondantAutoComplete respondentClass" <?php echo ($type=='update')?'readonly':''; ?>/>
			<input type="hidden" name="respondent_id" value="<?php echo $arrRespondent[0]['source_table_id']; ?>" id="respondentId"/>
			<input type="hidden" name="respondent_survey_ans_id" value="<?php echo $arrRespondent[0]['id']; ?>" id="respondentId"/>
		</div>
		<div id="showHiderespondentDetails" style="display: <?php echo ($type=='update')?'block':'none'; ?>;">
			<div class="respondentDetails">
				<label>City:</label>
				<span id="respCity"><?php echo $arrRespondent[0]['respondent_city']; ?></span>
			</div>
			<div class="respondentDetails">
				<label>State:</label>
				<span id="respState"><?php echo $arrRespondent[0]['respondent_state']; ?></span>
			</div>
			<div class="respondentDetails">
				<label>Country:</label>
				<span id="respCountry"><?php echo $arrRespondent[0]['respondent_country']; ?></span>
			</div>
			<div class="respondentDetails">
				<label>Postal Code:</label>
				<span id="respPostalCode"><?php echo $arrRespondent[0]['respondent_postal']; ?></span>
			</div>
			<input type="hidden" name="respondent_first_name" id="respondent_first_name" value="<?php echo $arrRespondent[0]['respondent']; ?>"/>
			<input type="hidden" name="respondent_middle_name" id="respondent_middle_name" value="<?php echo $arrRespondent[0]['respondent']; ?>"/>
			<input type="hidden" name="respondent_last_name" id="respondent_last_name" value="<?php echo $arrRespondent[0]['respondent']; ?>"/>
			<input type="hidden" name="respondent_country" id="respondent_country" value="<?php echo $arrRespondent[0]['respondent_country']; ?>"/>
			<input type="hidden" name="respondent_state" id="respondent_state" value="<?php echo $arrRespondent[0]['respondent_state']; ?>"/>
			<input type="hidden" name="respondent_city" id="respondent_city" value="<?php echo $arrRespondent[0]['respondent_city']; ?>"/>
			<input type="hidden" name="respondent_postal_code" id="respondent_postal_code" value="<?php echo $arrRespondent[0]['respondent_postal']; ?>"/>
			<input type="hidden" name="respondent_speciality" id="respondent_speciality" value="<?php echo $arrRespondent[0]['speciality']; ?>"/>
			<input type="hidden" name="respondent_organization" id="respondent_organization" value="<?php echo $arrRespondent[0]['organization']; ?>"/>			
		</div>
	</div>
	<?php if($type!='update'){?>
	<div>
		<input type="button" value="Search Names" onclick="searchNames(this,true,'');return false;">
		<input type="button" value="Add Missing Respondent" onclick="addNewKolProfile(this,true,'');return false;">
	</div>
	<?php } ?>

<!-- 
<fieldset>
  <legend>Chronic Myeloid Leukemia</legend>
	<div class="question-holder">
		<div class="quest">2) 	Who do you view as the National Opinion/Thought Leader(s) in Schizophrenia? 
		<span class="quest-tags">( Tags: Local, Schizophrenia, )</span>
		<span id="answerCollapse" class="ui-icon ui-icon-circle-triangle-n collapseTheDiv"></span></div>
		<div class="answer-holder" id="answerCollapse-div">
			<div class="">
				<label>Name<span class="required">*</span>:</label>
				<input type="text" name="influencer_name" value="" id="influencerName1" class="autocompleteInputBox kolNameAutoComplete" autocomplete="off">
			</div>
			<div class="answers"></div>
			<button class="btns" onclick="searchNames(this,false);return false;">Search Names</button>
			<button class="btns" onclick="addNewKolProfile(this,false);return false;">Add Missing Influencer</button>
		</div>
	</div>
	
	<div class="question-holder">
		<div class="quest">2) 	Who do you view as the National Opinion/Thought Leader(s) in Schizophrenia? 
		<span class="quest-tags">( Tags: Local, Schizophrenia, )</span>
		<span id="answerCollapse" class="ui-icon ui-icon-circle-triangle-n collapseTheDiv"></span></div>
		<div class="answer-holder" id="answerCollapse-div">
			<div class="">
				<label>Name<span class="required">*</span>:</label>
				<input type="text" name="influencer_name" value="" id="influencerName1" class="autocompleteInputBox kolNameAutoComplete" autocomplete="off">
			</div>
			<div class="answers"></div>
			<button class="btns" onclick="searchNames(this,false);return false;">Search Names</button>
			<button class="btns" onclick="addNewKolProfile(this,false);return false;">Add Missing Influencer</button>
		</div>
	</div>
 </fieldset>
 -->
<?php 
	foreach($arrSurveys as $categoryName => $arrSurveys){
		echo '<fieldset class="fieldSet">';
  		echo '<legend>'.$categoryName.'</legend>';
		foreach($arrSurveys as $key => $arrRow){
			$appendId  = "'answerCollapse-".$arrRow['id']."-div'";
			?>
			<div class="question-holder">
				<div class="quest"><?php echo $arrRow['question']; ?> 
				<span class="quest-tags">( Tags: <?php echo $arrTypes[$arrRow['type_id']].', '.$categoryName.', '.$arrRow['role']; ?> )</span>
				<span id="answerCollapse-<?php echo $arrRow['id']; ?>" class="ui-icon ui-icon-circle-triangle-s collapseTheDiv"></span></div>
				<div class="answer-holder" id="answerCollapse-<?php echo $arrRow['id']; ?>-div">
					<div class="answers"><?php 
					$count_of_total_answers = sizeof($arrSurveyAnswers[$arrRow['id']]);
					for($i=0;$i<$count_of_total_answers;$i++){
						?>
						<div class="answer-section">
						<div class="influencerDetails"><label>Name:</label> <span><?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?></span></div>
						<div class="influencerDetails"><label>City:</label> <span><?php echo $arrSurveyAnswers[$arrRow['id']][$i]['city']; ?></span></div>
						<div class="influencerDetails"><label>State:</label> <span><?php echo $arrSurveyAnswers[$arrRow['id']][$i]['state']; ?></span></div>
						<div class="influencerDetails"><label>Country:</label> <span><?php echo $arrSurveyAnswers[$arrRow['id']][$i]['country']; ?></span></div>
						<div class="influencerDetails"><label>Postal Code:</label> <span><?php echo $arrSurveyAnswers[$arrRow['id']][$i]['postal']; ?></span></div>
						<div class="influencerDetails" style="width: 5%;"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" aid="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['id']; ?>" alt="Delete" title="Delete"></div></div>
						
						<input type="hidden" name="influencer_first_name" id="influencer_first_name" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?>"/>
						<input type="hidden" name="influencer_middle_name" id="influencer_middle_name" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?>"/>
						<input type="hidden" name="influencer_last_name" id="influencer_last_name" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?>"/>
						<input type="hidden" name="influencer_country" id="influencer_country" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['city']; ?>"/>
						<input type="hidden" name="influencer_state" id="influencer_state" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['state']; ?>"/>
						<input type="hidden" name="influencer_city" id="influencer_city" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['country']; ?>"/>
						<input type="hidden" name="influencer_postal_code" id="influencer_postal_code" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['postal']; ?>"/>
						<input type="hidden" name="influencer_speciality" id="influencer_speciality" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?>"/>
						<input type="hidden" name="influencer_organization" id="influencer_organization" value="<?php echo $arrSurveyAnswers[$arrRow['id']][$i]['name']; ?>"/>
						</div>		
						<?php 
					}
					?></div>
					<div class="answerFieldHolder">
						<label>Name<span class="required">*</span>:</label>
						<input type="text" name="influencer_name" value="" id="influencerName-<?php echo $arrRow['id']; ?>" class="autocompleteInputBox kolNameAutoComplete" autocomplete="off">
						<input type="hidden" name="survey_question_id[]" value="<?php echo $arrRow['id']; ?>"/>
					<button class="btns" onclick="searchNames(this,false,<?php echo $appendId; ?>);return false;">Search Names</button>
					<button class="btns" onclick="addNewKolProfile(this,false,<?php echo $appendId; ?>);return false;">Add Missing Influencer</button>
				
					</div>
					</div>
			</div>
		<?php
		}
		
		echo '</fieldset>';
	}
?>
<div class="cust-holder" style="margin-bottom: 30px;">
	<div class="cust">
		<input id="noInfluencers1" onclick="didNotProvideInfluencers();" class="noNames" value="1" name="no_names" type="checkbox"><label> HCP did not provide influencers</label>
	</div>
	<div class="cust">
		<input id="noInfluencers2" onclick="doesNotHaveInfluencers();" class="noNames" value="2" name="no_names" type="checkbox"><label> HCP does not have influencers</label>
	</div>
	<input type="hidden" name="no_influencers" id="noInfluencers" value=""/>	
</div>

<center>
	<button type="button" onclick="submit_survey();">Submit Response</button> 
	<br>
	<span class="tags"><i style="color: #626262;">Please note: All data will be cleared on refresh or using the "Back" button.</i></span>
</center>

</form>
<div id="searchedNames" class="microProfileDialogBox">
	<div class="searchedNamesContent profileContent"></div>
</div>

<div id="addNewKol" class="microProfileDialogBox">
	<div class="addNewKolContent profileContent"></div>
</div>