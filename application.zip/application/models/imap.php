<?php
/**
 * iProfile Database related queries handles
 * 
 * @author Ramesh B
 * @package application.models	
 * @created 14-01-2015
 */

class iMap extends Model{
	
	var $ipdb = '';
 	
 	//Constructor
	function iMap(){
		parent::Model();
	}
	
	function geAllUsers($clientId){
		$arrData = array();
		$this->db->select("id,email,user_name");
		$this->db->where('client_id',12);
		$results = $this->db->get('client_users');
		if($results->num_rows() > 0){
			$arrData =	$results->result_array();
		}
		return $arrData;
	}
	
	function getUserIdByEmail($email){
		$this->db->select("id,email,user_name");
		$this->db->where('email',$email);
		$results = $this->db->get('client_users');
		if($results->num_rows() > 0){
			$row =	$results->first_row();
			return $row->id;
		}else
			return false;

	}
	
	function insertUser($arrData){
		if($this->db->insert('client_users',$arrData))
			return $this->db->insert_id();
		else
			return false;
	}

	
	function getKolMDMID($kolId){
		$this->db->select("mdmid");
		$this->db->where('id',$kolId);
		$results = $this->db->get('kols');
		if(is_object($results) && $results->num_rows() > 0){
			$row =	$results->first_row();
			return $row->mdmid;
		}else
			return false;
	}
	
	function getIcontactByMDMID($mdmid){
		$arrData = array();
		$this->db->where('master_customer_id',$mdmid);
		$this->db->where('present_address',1);
		$results = $this->db->get('additional_contacts');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0){
			$row =	(array)$results->first_row();
			return $row;
		}else
			return false;
	}
	
	function getIcontactByNPI($npiNum){
		$arrData = array();
		$this->db->where('npi',$npiNum);
		$this->db->where('present_address',1);
		$results = $this->db->get('additional_contacts');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0){
			$row =	(array)$results->first_row();
			return $row;
		}else
			return false;
	}
	
	function getSurveys(){
		$arrData = array();
		$results = $this->db->get('surveys');
		if($results->num_rows() > 0){
			$arrData =	$results->result_array();
		}
		return $arrData;
	}
	
	function saveStagingIContact($arrDetails){
		if($this->db->insert('staging_icontacts',$arrDetails))
			return $this->db->insert_id();
		else
			return false;
	}
	
	function saveSurvey($arrDetails){
		if($this->db->insert('survey_answers',$arrDetails))
			return true;
		else
			return false;
	}
	
	function getSurveyResponsesiProfile($surveyId){	
		$arrData = array();
		$this->db->select('survey_answers_iprofile.*,survey_kol_names_iprofile.name as resp_name,survey_kol_names_iprofile.kol_id as resp_kol_id,kols.first_name,kols.middle_name,kols.last_name,resporg.name as resp_org,nomorg.name as nom_org,specialties.specialty,kols.npi_num as nom_npi,influencer_npi,respondent_npi');
		$this->db->join('survey_kol_names_iprofile','survey_answers_iprofile.respondent_id = survey_kol_names_iprofile.id','left');
		$this->db->join('survey_org_names_iprofile as resporg','survey_answers_iprofile.respondent_org_id = resporg.id','left');
		$this->db->join('survey_org_names_iprofile as nomorg','survey_answers_iprofile.nominee_org_id = nomorg.id','left');
		$this->db->join('kols','survey_answers_iprofile.kol_id = kols.id','left');
		//$this->db->join('kols as respkols','survey_kol_names_iprofile.kol_id = kols.id','left');
		$this->db->join('specialties','kols.specialty = specialties.id','left');
		$this->db->where('survey_id',$surveyId);
		//$this->db->limit(100,$startIndex);
		$results = $this->db->get('survey_answers_iprofile');
		if($results->num_rows() > 0){
			foreach($results->result_array() as $row){
				$arrData[$row['respondent_id']][] =	$row;
				//if($arrData[$row['respondent_id']][0]['respondent_npi'] == null && $row['respondent_npi'] != null)
					//$arrData[$row['respondent_id']][0]['respondent_npi'] = $row['respondent_npi'];
			}
		}
		return $arrData;
	}
	
	
	function getNumberOfSurveyResposnsesiProfile($surveyId){
		$count = 0;
		$this->db->select('count(*) as numr');
		$res = $this->db->get('survey_answers_iprofile');
		if($res->num_rows() > 0){
			$row = $res->first_row();
			$count = $row->numr;
		}
		return $count;
	}
	
	function getKolNPI($kolId){
		$npiNum = '';
		$this->db->select('npi_num');
		$this->db->where('id',$kolId);
		$res = $this->db->get('kols');
		if($res->num_rows() > 0){
			$row = $res->first_row();
			$npiNum = $row->npi_num;
		}
		return $npiNum;
	}
	
	function getSurveyResponses($id){
		$arrResponses = array();
		$this->db->where('survey_id',$id);
		$res = $this->db->get('survey_answers');
		if($res->num_rows() > 0){
			$arrResponses = $res->result_array();
		}
		return $arrResponses;
	}
	
	function getNPIByAddressId($addressId){
		$npi='';
		$this->db->where('id',$addressId);
		$this->db->select('npi');
		$result=$this->db->get('additional_contacts');
		$data=$result->row();
		if($data!=null)
			$npi=$data->npi;
			
		//echo $this->db->last_query();
		return $npi;
	}
	
	function getMDMIDByAddressId($addressId){
		$master_customer_id='';
		$this->db->where('id',$addressId);
		$this->db->select('master_customer_id');
		$result=$this->db->get('additional_contacts');
		$data=$result->row();
		if($data!=null)
			$master_customer_id=$data->master_customer_id;
			
		//echo $this->db->last_query();
		return $master_customer_id;
	}
	
	function getKolIdByNPI($npi){
		$id=0;
		$this->db->where('npi_num',$npi);
		$this->db->select('id');
		$result=$this->db->get('kols');
		$data=$result->row();
		if($data!=null)
			$id=$data->id;
		return $id;
	}
	
	function getKolIdByMDMID($mdm_id){
		$id=0;
		$this->db->where('mdm_id',$mdm_id);
		$this->db->select('id');
		$result=$this->db->get('kols');
		$data=$result->row();
		if($data!=null)
			$id=$data->id;
		return $id;
	}
	
	function updateSurveyResponse($arrDetails){
		$this->db->where('id',$arrDetails['id']);
		if($this->db->update('survey_answers',$arrDetails))
			return true;
		else
			return false;
	
	}
	
	function getIcontactByName($arrStagingResp){
		$arrData = array();
		$this->db->where('first_name',$arrStagingResp['first_name']);
		$this->db->where('last_name',$arrStagingResp['last_name']);
		if(isset($arrStagingResp['middle_name']) && $arrStagingResp['middle_name'] != '')
			$this->db->where('middle_name',$arrStagingResp['middle_name']);
		$this->db->where('present_address',1);
		$results = $this->db->get('additional_contacts');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() == 1){
			$row =	(array)$results->first_row();
			echo $this->db->last_query();
			return $row;
		}else{
			if(is_object($results) && $results->num_rows() > 1){
				//echo $this->db->last_query();
				$this->db->where('first_name',$arrStagingResp['first_name']);
				$this->db->where('last_name',$arrStagingResp['last_name']);
				if(isset($arrStagingResp['middle_name']) && $arrStagingResp['middle_name'] != '')
					$this->db->where('middle_name',$arrStagingResp['middle_name']);
				if(isset($arrStagingResp['city']) && $arrStagingResp['city'] != '')
					$this->db->where('city_name',$arrStagingResp['city']);
				$this->db->where('present_address',1);
				$results = $this->db->get('additional_contacts');
				//echo $this->db->last_query();
				if(is_object($results) && $results->num_rows() == 1){
					$row =	(array)$results->first_row();
					return $row;
				}else{
					if(is_object($results) && $results->num_rows() > 1)
						//echo $this->db->last_query();
					return false;
				}
			}
			return false;
		}
	}
	
	function getSurveyResponsesiProfileAnup($surveyId){	
		$arrData = array();
		$this->db->select('survey_answers_anup.*');
		$this->db->where('survey_id',$surveyId);
		//$this->db->limit(100,$startIndex);
		$results = $this->db->get('survey_answers_anup');
		if($results->num_rows() > 0){
			foreach($results->result_array() as $row){
				$arrData[$row['respondent_id']][] =	$row;
				//if($arrData[$row['respondent_id']][0]['respondent_npi'] == null && $row['respondent_npi'] != null)
					//$arrData[$row['respondent_id']][0]['respondent_npi'] = $row['respondent_npi'];
			}
		}
		return $arrData;
	}
}