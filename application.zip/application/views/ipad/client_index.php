<?php
/**
 * Clients Index/Home page
 * Created By: Ramesh B
 * Created On:11:33:36 AM
 */
?>
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array(IPAD_APP_FOLDER . '/index/client_index');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
<!-- RSS Feeds CSS and JS -->

<script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>
<style>
    #rssfeed_content{
        border:1px solid #1A5C76;
        border-top:5px solid #1A5C76;
        padding-left:10px;
    }

    #tabs1 a{
        display:block;
        width:100px;
        float:left;
        border:1px solid #D0CCC9;
        text-align: center;
        margin-right:5px;
        background-color: #EFEFEF;
        padding: 5px 0;
        text-decoration: none;
        margin-right:0px;
        cursor: pointer;
    }

    #tabs1 div.divider{
        display: inline;
        width: 3px;
        border: 0px;
        border-bottom: 1px solid #D0CCC9;
        display: block;
        float: left;
        height: 29px;
    }
    #tabs1 a.current{
        background-color: #FFFFFF;
        border-bottom:1px solid #FFFFFF;
        z-index: 100;
        color:#1A5C76;
        font-weight: bold;
    }
    /*	#tabs1 div.lastRight{
                    width: 188px;
            }
    */
    #tabs1 div.firstRight{
        width: 20px;
    }
    #tabs1{
        padding-left:0px;
        z-index: 1;
        padding-bottom: 29px;
        border-bottom: 1px solid #D0CCC9;
        color:#898989;
        float: left;
        border-bottom: 0px;
    }
    #rssfeed_content1 p{
        display: none;
    }
    #rssfeed_content1 ul{
        padding-left: 5px;
        list-style: none;
    }
    #rssfeed_content1 ul{
        list-style: none;
    }
    #rssfeed_content1{
        min-height: 300px;
    }

    .rssFeed{
        border:1px solid #D0CCC9;
        border-top:0px;
        padding-left:40px;
        padding-right: 40px;
        padding-top: 10px;
    }
    #RSSFEED4 map img{
        display: none;
    }
    .activityHeading{
        font-size:12px;
    }
    .rssTabs {
        /*padding-left: 10px;*/
        padding-right: 10px;
    }
    .rssContent {
        padding-left: 20px;
        padding-right: 60px
    }
    .nav > li >a {
        color: #ffffff;
    }
    .rssContent {
        border: 1px;
    }
    
    .rssTabs > li{
        border-right: #FFF;
        border-left: #FFF;
        border-left-width:0.1px;
        border-top-width:0px;
        border-bottom-width:0px;
        border-style: solid;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
    }
    
.rssContent >div > ul >li {
    color: #555;
}
.rssContent >div > ul >li > a {
    text-decoration: underline;
}
#updates-list table{
	width:100%;
}
#updates-list table tr td{
	padding:7px;
}
.tab-pane {
    min-height: 200px;
    min-width: 80%;
}
.rssFeed{
    border: 1px solid #D0CCC9 !important;
    /* border-top: 0px; */
     padding-left: 0px !important; 
    padding-top: 10px;
    height: 413px !important;
    /*width: 1329px !important;*/
    overflow-y: scroll;
    overflow-x: hidden ;
}
#rssfeed_content1 p{
    display:block !important;
}
</style>
<?php
$userSettings = $this->session->userdata('userSettings');
if (!isset($userSettings['walkthrough'])) {
    $userSettings['walkthrough'] = 0;
}
?>
<div>
    <br/>
    <div class="indexLeftSide">
        <!-- <div id="summaryIcon"></div>  -->
        <div class="activityHeading"><label><?php echo lang('Home.Summary'); ?></label></div>		
        <p>
            <label><?php echo lang('Home.TotalKols'); ?> </label> 
            <span class="count">: <a href="<?php echo base_url() . IPAD_URL_SEGMENT ?>/kols/list_kols_client_view" style="text-decoration:none"><?php echo $noOfKols; ?></a></span>
            <?php if (isset($noOfOrgs)) { ?> 
                <!--
                	<label><?php echo lang('Home.TotalOrganizations'); ?> </label> 
                	<span  class="count">: <a href="<?php echo base_url() . IPAD_URL_SEGMENT ?>/organizations/list_organizations_client_view" style="text-decoration:none"><?php echo $noOfOrgs; ?></a></span>
               	 -->
            <?php } ?>
        </p>
        <br/>
        <div class="activityHeading" style="font-size: 12px;clear:both;"><label><?php echo lang('Home.Top5Specialties'); ?></label></div>
        <p>
            <?php
            foreach ($arrTopSpecialties as $key => $arrSpeciaties) {
                ?>
                <label><?php echo $arrSpeciaties['specialty']; ?> </label> 
                <span class="count">: <?php echo $arrSpeciaties['specilatycount']; ?></span>
                <?php
            }
            ?>
        </p>

    </div>
    <div class="indexRightSide">
        <?php
        $this->load->view(IPAD_APP_FOLDER . '/updates/recent_updates_home');
        ?>
    </div>
    <!--  Start of RSS Feed Links -->
    <br />

    <div class="clear rssFeed">
		<div id="rssfeed_content1">
                   <?php  $this->load->view(IPAD_APP_FOLDER . '/media_inteligence/rss_feed_view', $data); ?>
		</div>
	</div>






    <!--    <div id="tabs1">
            <div class="divider firstRight">&nbsp;</div>
            <a onclick="display_rssfeed_content('1');"><?php echo lang('Home.MedicalNews'); ?></a><div class="divider">&nbsp;</div>
            <a onclick="display_rssfeed_content('2');"></a><div class="divider" >&nbsp;</div>
            <a onclick="display_rssfeed_content('4');"></a><div class="divider">&nbsp;</div>
            <a onclick="display_rssfeed_content('5');"></a><div class="divider">&nbsp;</div>
            <a onclick="display_rssfeed_content('6');"></a><div class="divider">&nbsp;</div>
            <a onclick="display_rssfeed_content('7');"></a><div class="divider">&nbsp;</div>
            <a onclick="display_rssfeed_content('8');"></a><div class="divider lastRight">&nbsp;</div>
        </div>
        <div class="clear rssFeed">
            <div id="rssfeed_content1">
                <div id="RSSFEED1" style="display:none;"></div>
                <div id="RSSFEED2" style="display:none;"></div>
                <div id="RSSFEED4" style="display:none;"></div>
                <div id="RSSFEED5" style="display:none;"></div>
                <div id="RSSFEED6" style="display:none;"></div>
                <div id="RSSFEED7" style="display:none;"></div>
                <div id="RSSFEED8" style="display:none;"></div>
            </div>
        </div>-->
</div>
<!--  End of RSS Feed Links -->
