<?php
/**
 * @author	: Kishan Ravindra
 * @since	: V7.0
 * @package	: application.controllers
 * @created	: 27-07-2017
 */
class Master_data_controller extends Controller {
	private $loggedUser;
    //Constructor
    function Master_data_controller() {
        parent::Controller();
        $this->load->model('master_data_model');
        $this->load->model('specialty');
        $this->load->model('common_helpers');
        $this->load->model('country_helper');
        $this->loggedUser = $this->session->userdata['user_name'];
    }
    
    /*
     * @Author : Kishan Ravindra (00001111)
     * @Method : manage_titles
     * @Params : none
     * @Action : Calls 'Manage Titles UI'
     */
    function manage_titles(){
    	$data['contentPage'] = 'master_data/manage_titles';
    	//Add Log activity
    	$arrLogDetails = array(
    			'type' => VIEW_RECORD,
    			'description' => "Visited Manage Titles Page",
    			'status' => STATUS_SUCCESS,
    			'transaction_name' => "View Manage Titles Page"
    	);
    	$this->config->set_item('log_details', $arrLogDetails);
    	$this->load->view('layouts/analyst_view', $data);
    }
	
    /* 
     * @Author : Kishan Ravindra (00001111)
     * @Method : list_titles()
     * @Params : none
     * @Action : Returns data related to 'titles' to jQgrid
    */
    function list_titles(){
		$page = $_REQUEST['page'];
		$limit = $_REQUEST['rows'];
		$sidx = $_REQUEST['sidx'];
		$sord = $_REQUEST['sord'];
		if(!$sidx)	$sidx = 1;
		$filterData = $_REQUEST['filters'];
		$arrFilter = array();
		$arrFilter = json_decode(stripslashes($filterData));
		$field = 'field';
		$data = 'data';
		$searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray = array();
		foreach($searchField as $key => $val) {
			$whereResultArray[$val] = $searchString[$key];
		}
		$count = $this->master_data_model->getTitles( $limit, $start, true, $sidx, $sord, $whereResultArray);
		$total_pages = $count > 0 ? ceil ( $count / $limit ) : 0;
		if ($page > $total_pages) $page = $total_pages;
		$start = $limit * $page - $limit;
		if ($start < 0)	$start = 0;
		$data = array();
		$arrTitleResult = array();
		if($arrTitleResult = $this->master_data_model->getTitles($limit, $start, false, $sidx, $sord, $whereResultArray)) {
			$arrTitleDetail = array();
			foreach($arrTitleResult->result_array() as $row) {
				$row['id'] = $row['id'];
				$row['title'] = $row['title'];
				$row['abbr'] = $row['abbr'];
				$row['client_id'] = $row['client_id'];
				$row['is_active'] = $row['is_active'];
				$actions = '<div class="actionIcon editIcon"><a onclick="editTitle('.$row['id'].');" href="#" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteTitle('.$row['id'].');" href="#" title="Delete">&nbsp;</a></div>';
				$row ['action'] = $actions;
				$arrTitleDetail[] = $row;
			}
			$data ['records'] = $count;
			$data ['total'] = $total_pages;
			$data ['page'] = $page;
			$data ['rows'] = $arrTitleDetail;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : get_title_by_id()
	 * @Params : id => Titles Entity (By POST)
	 * @Action : Returns data related to 'titles' where id matches
	 */
	function get_title_by_id(){
		$id = $this->input->post('id');
		echo json_encode($this->master_data_model->getTitleDetailsById($id)->result_array());
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientIds()
	 * @Params : titleId => Titles Entity
	 * @Action : Returns only Client Ids (Comma Seperated)
	 */
	function getClientIds($titleId){
		$arrResultSet = $this->master_data_model->getArrClientIds($titleId)->result_array();
		return $arrResultSet[0]['client_ids'];
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientIdsToAJAX()
	 * @Params : titleId (By POST)
	 * @Action : Returns only Client Ids to AJAX Call (Comma Seperated) 
	 */
	function getClientIdsToAJAX(){
		$titleId = $this->input->post('titleId');
		echo $this->getClientIds($titleId);
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientDetails()
	 * @Params : id => Clients Entity (Optional By POST)
	 * @Action : Returns 'clients' details to AJAX Call (If 'id' matches : matched records, else : all records )
	 */
	function getClientDetails(){
		$id = $this->input->post('id');
		$resData = $this->master_data_model->getClientDetails($id);
		foreach ($resData as $row) {
			$clientRec['id'] = $row['id'];
			$clientRec['name'] = $row['name'];
			$arrClientRecs[] = $clientRec;
		}
		echo json_encode($arrClientRecs);
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : smartMergeTitle()
	 * @Params : id, title, abbrevation, status, clientIds (By POST)
	 * @Action : Insert / Update 'titles' and associate / deassociate clientIds
	 */
	function smartMergeTitle(){
		$id = $this->input->post('id');
		$title = $this->input->post('title');
		$abbrevation = $this->input->post('abbrevation');
		$status = $this->input->post('status');
		$clientIds = $this->input->post('clientIds');
		$data = array(
			'id'=>$id,
			'title'=>$title,
			'abbr'=>$abbrevation,
			'is_active'=>$status,
		);
		$respVal = $this->master_data_model->smartMergeTitle($data);		
		if($data['id'] == 0 && $respVal > 0){
			$arrConfig = $this->common_helpers->getMailConfig('','');
			$arrInfo = array (
				'FROM' => "kishanr@aissel.com",
				'FROM_NAME' => "Kishan Ravindra",
				'TO' => array("kumareshab@aissel.com"),
				'CC' => array(""),
				'SUBJECT' => "Notification about creation of new Title",
					'MAIL_BODY' => "<html>
										<head>
											<style>
												table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
												td, th { border: 1px solid #CCC; height: 30px; }
												th { background: #F3F3F3; font-weight: bold; }
												td { background: #FAFAFA; text-align: center;}
											</style>
										</head>
										<body>
											<div>
												Hi, Following information is added by ".$this->session->userdata['user_name']."<br><br>
												<table>
													<tr><th>Title</th><th>Abbrevation</th><th>Status</th></tr>
													<tr><td>".$data['title']."</td><td>".$data['abbr']."</td><td>".($data['is_active'] == 1 ? 'Active' : 'Inactive')."</td></tr>
												</table><br>Regards,<br>Aissel Technologies<br>
											</div>
										</body>
									</html>"
			);
			$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
		}
		// Add log activity
		$requestStatus = FAILURE;
		if ($respVal) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => ADD_RECORD,
				'description' => 'Add New Title',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $respVal,
				'transaction_table_id' => TITLES,
				'transaction_name' => "New Title",
				'form_data' => $formData,
				'parent_object_id' => $respVal
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		if($respVal <= 0){
			$respMsg = "Failed to Save";
		} else {
			$childStatus = $this->process_title_client_mappings($respVal,$clientIds);
			$respMsg = $childStatus ? "Saved Successfully" : "Failed to Process the Client Associations"; 
		}
		echo $respMsg;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : process_title_client_mappings()
	 * @Params : titleID, clientIds
	 * @Action : associate / deassociate clientIds to titleId
	 */
	function process_title_client_mappings($titleId, $clientIds){
		$arrDBClientIds = explode(",", $this->getClientIds($titleId));
		$arrOldClientIds = array_filter($arrDBClientIds, function($value) { return $value !== ''; });
		$arrUIClientIds = explode(",", $clientIds);
		$arrNewClientIds = array_filter($arrUIClientIds, function($value) { return $value !== ''; });
		$arrIntersect = array_intersect($arrOldClientIds, $arrNewClientIds);
		$toBeInserted = array_diff($arrNewClientIds, $arrIntersect);
		$toBeRemoved = array_diff($arrOldClientIds, $arrIntersect);
		$toBeProcessed = sizeof($toBeInserted) + sizeof($toBeRemoved);
		$insertCount = 0;
		foreach($toBeInserted as $rec){
			$currTimeStamp = Date("Y-m-d H:i:s");
			$data = array(
				'title_id' => $titleId,
				'client_id' => $rec,
				'created_by' => $this->session->userdata('user_id'),
				'created_on' => $currTimeStamp
			);
			$insStatus = $this->master_data_model->saveTitleClientMappings($data);
			$insertCount += $insStatus ? 1 : 0;
		}
		$deleteCount = 0;
		foreach($toBeRemoved as $rec){
			$data = array(
					'title_id' => $titleId,
					'client_id' => $rec
			);
			$remStatus = $this->master_data_model->deleteTitleClientMappings($data);
			$deleteCount += $remStatus ? 1 : 0;
		}
		$processed = $insertCount + $deleteCount;
		return $toBeProcessed == $processed ? true : false;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : deleteTitle()
	 * @Params : id => Titles Entity (By POST)
	 * @Action : Deletes from 'titles' where id matches 
	 */
	function deleteTitle(){
		$id = $this->input->post('id');
		$status = $this->master_data_model->deleteTitle($id);
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$arrLogDetails = array (
				'type' => DELETE_RECORD,
				'description' => 'deleting the title',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $id,
				'transaction_table_id' => TITLES,
				'transaction_name' => 'delete title',
				'parent_object_id' => $id
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		echo $status ? "Deleted Successfully" : "Failed to Delete";
	}
	
	// @Author: Kumaresha B
	function list_specialties() {
		$data ['contentPage'] = 'master_data/list_specialties';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List of Specialties Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List Specialties Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	
	function load_grid_specialties() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page'];
		$limit = $_REQUEST ['rows'];
		$sidx = $_REQUEST ['sidx'];
		$sord = $_REQUEST ['sord'];
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$data = 'data';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchResults = array ();
		$arrSpecialties = $this->specialty->getAllSpecialties ();
		$count = sizeof ( $arrSpecialties );
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit;
		if ($start < 0)
			$start = 0;
		$arrSpecialtyData = $this->master_data_model->getSpecialtyDetails ( $limit, $start, $sidx, $sord );
		foreach ( $arrSpecialtyData as $row ) {
			$arrSpecDetails [] = array (
					'id' => $row ['id'],
					'specialty' => $row ['specialty'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editSpecialties('" . $row ['id'] . "','" . addslashes ( $row ['specialty'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addSpecialtiesClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedSpecialties('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrSpecDetails;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	
	function edit_specialty() {
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited add specialty',
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View add specialty",
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );	
		$this->load->view ( 'master_data/add_specialty', $data );
	}
	
	function save_specialty() {
		$client_id = $this->session->userdata ( 'client_id' );
		$specialty = $this->input->post ( 'specialty' );
		$id = $this->input->post ( 'id' );
		$data = array (
				'specialty' => $specialty,
				'client_id' => $client_id,
		        'all' => 1
		);
		$isExistingRec = $this->master_data_model->checkSpecialty ( $specialty );
		if ($isExistingRec) {
			$statusMsg = "Speciality already exists";
		} else {
			$status = $this->master_data_model->saveSpecialty ( $data, $id );
			if($status){
				$arrConfig = $this->common_helpers->getMailConfig('','');
				$arrInfo = array (
						'FROM' => "kishanr@aissel.com",
						'FROM_NAME' => "Kishan Ravindra",
						'TO' => array("laxmank@aissel.com"),
						'CC' => array(""),
						'SUBJECT' => "Notification about creation of new Speciality",
						'MAIL_BODY' => "<html>
										<head>
											<style>
												table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
												td, th { border: 1px solid #CCC; height: 30px; }
												th { background: #F3F3F3; font-weight: bold; }
												td { background: #FAFAFA; text-align: center;}
											</style>
										</head>
										<body>
											<div>
												Hi, Following information is added by ".$this->loggedUser."<br><br>
												<table>
													<tr><th>Speciality Name</th><td>".$data['specialty']."</td></tr>
												</table><br>Regards,<br>Aissel Technologies<br>
											</div>
										</body>
									</html>"
				);
				$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
			}
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add Specialty',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $id,
					'transaction_table_id' => SPECIALTIES,
					'transaction_name' => "Add Specialty",
					'form_data' => $formData,
					'parent_object_id' => $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
		}
		echo $statusMsg;
	}
	
	function delete_specialty() {
		$id = $this->input->post ( 'id' );
		$status = $this->master_data_model->deleteSpecialty ( $id );
		//Add Log activity
		$arrLogDetails = array(
				'type' => DELET_RECORD,
				'description' => 'Delete Specialty',
				'status' => STATUS_SUCCESS,
				'transaction_id' =>  $id,
				'transaction_table_id' => SPECIALTIES,
				'transaction_name' => "Delete Specialty",
				'parent_object_id' =>  $id
		);
		$this->config->set_item('log_details', $arrLogDetails);
		echo $status ? "Deleted Successfully" : "Deletion Failed";
	}
	
	function add_specialty_clients($specId) {
		$arrClients = $this->master_data_model->getClientDetails();
		$arrSelected = $this->master_data_model->getSpecClients($specId);
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ($data ['arrSelected'] as $row){
			$arr[] =  $row["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited add specialty clients page',
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View add specialty clients page",
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );	
		$this->load->view ( 'master_data/add_specialties_clients', $data );
	}
	
	function save_client_specialty() {
		$specialty = $this->input->post ( 'specialty' );
		$client_ids = $this->input->post ( 'id' );
		$client_id = explode ( ",", $client_ids );
		$this->master_data_model->deleteClientSpecialty ( $specialty );
		$i = 0;
		$successCount = 0;
		while ( $client_id [$i] != null ) {
			$data = array (
					'specialty_id' => $specialty,
					'client_id' => $client_id [$i ++]
			);
			$status = $this->master_data_model->saveClientSpecialty ( $data );
			if ($status) {
				$successCount ++;
			}
		}
		//Add Log activity
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'type' => ADD_RECORD,
				'description' => 'Add Specialty Client Association',
				'status' => STATUS_SUCCESS,
				'transaction_id' => $client_ids,
				'transaction_table_id' => SPECIALTY_CLIENT_ASSOCIATION,
				'transaction_name' => "Add Specialty Client Association",
				'form_data' => $formData,
				'parent_object_id' => $client_ids
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		echo $i == $successCount ? "Saved Successfully" : "Saving Failed";
	}
	
	/**
	 * @Author: Soumya R S
	 * @Created on 27-07-2017
	**/
	
	//to load the view page with country,State and city jqgrids
	function list_region(){
		$data ['arrCountries'] = $this->country_helper->listCountries ();
		$data ['contentPage'] = 'master_data/list_regions';
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited List of Regions page',
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List of Regions page",
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );	
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	
	//loads contents to the jqgrid of country listing
	function country_jqgrid(){
		$field = 'field';
		$data = 'data';
		$responce = array ();
		$page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
		$limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
		$sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
		$sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
		$filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$start = $limit * $page - $limit;
		$start = ($start < 0) ? 0 : $start;
		$searchString = $this->common_helpers->search_nested_arrays( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		if (! $sidx)
			$sidx = 1;
			$count = $this->master_data_model->getCountriesList( $start, null, $sidx, $sord, $whereResultArray, true);
		$total_count = $count;
		if ($total_count > 0) {
			$total_pages = ceil ( $total_count / $limit );
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
		$query = $this->master_data_model->getCountriesList( $start, $limit, $sidx, $sord, $whereResultArray );
		$responce ['page'] = $page;
		$responce ['total'] = $total_pages;
		$responce ['records'] = $count;
		$responce ['rows'] = array ();
		$i = 0;
		foreach ( $query as $row ) {
			$row->action = '<div class="actionIcon editIcon"><a onclick="openCountryForm(' . $row->CountryId . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteCountry(' . $row->CountryId . ')"  title="delete">&nbsp;</a></div>';
			$responce ['rows'] [$i] ['id'] = $row->CountryId;
			$responce ['rows'] [$i] ['cell'] = array (
					$row->CountryId,
					$row->Country,
					$row->Capital,
					$row->NationalitySingular,
					$row->NationalityPlural,
					$row->Currency,
					$row->action 
			);
			$i ++;
		}
		echo json_encode ( $responce );
	}
	
	//loads contents to the jqgrid of State listing
	function states_jqgrid($q,$id){
		$field = 'field';
		$data = 'data';
		$responce = array ();
		$examp = $q; // query number
		$page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
		$limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
		$sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
		$sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
		$filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$searchString = $this->common_helpers->search_nested_arrays( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		if (! $sidx)
			$sidx = 1;
		if ($examp == 1) {
			$count = $this->master_data_model->getStatesList( $start, null, $sidx, $sord, $id, $whereResultArray, true);
			
			if ($count > 0) {
				$total_pages = ceil ( $count / $limit );
			} else {
				$total_pages = 0;
			}
			if ($page > $total_pages)
				$page = $total_pages;
			$start = $limit * $page - $limit; // do not put $limit*($page - 1)
			if ($start < 0)
				$start = 0;
			$query = $this->master_data_model->getStatesList( $start, $limit, $sidx, $sord, $id, $whereResultArray );
			$responce ['page'] = $page;
			$responce ['total'] = $total_pages;
			$responce ['records'] = $count;
			$responce ['rows'] = array ();
			$i = 0;
			foreach ( $query as $row ) {
				$row->action = '<div class="actionIcon editIcon"><a onclick="openStateForm(' . $row->RegionID . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteSstate(' . $row->RegionID . ')"  title="delete">&nbsp;</a></div>';
				$responce ['rows'] [$i] ['id'] = $row->RegionID;
				$responce ['rows'] [$i] ['cell'] = array (
						$row->RegionID,
						$row->Region,
						$row->Code,
						$row->action 
				);
				$i ++;
			}
		}
		echo json_encode ( $responce );
	}
	
	//loads contents to the jqgrid of City
	function cities_jqgrid($q,$id){
		$field = 'field';
		$data = 'data';
		$responce = array ();
		$examp = $q; // query number
		$page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
		$limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
		$sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
		$sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
		$filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$searchString = $this->common_helpers->search_nested_arrays( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ){
			$whereResultArray [$val] = $searchString [$key];
		}
		if (! $sidx){
			$sidx = 1;
		}
		if ($examp == 1) {
			$count = $this->master_data_model->getCitiesList( $start, null, $sidx, $sord, $id, $whereResultArray, true);
			if ($count > 0) {
				$total_pages = ceil ( $count / $limit );
			} else {
				$total_pages = 0;
			}
			if ($page > $total_pages)
				$page = $total_pages;
			$start = $limit * $page - $limit; // do not put $limit*($page - 1)
			if ($start < 0)
				$start = 0;
			$query = $this->master_data_model->getCitiesList( $start, $limit, $sidx, $sord, $id, $whereResultArray );
			$responce ['page'] = $page;
			$responce ['total'] = $total_pages;
			$responce ['records'] = $count;
			$responce ['rows'] = array ();
			$i = 0;
			foreach ( $query as $row ) {
				$row->action = '<div class="actionIcon editIcon"><a onclick="openCityForm(' . $row->CityId . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteCity(' . $row->CityId . ')"  title="delete">&nbsp;</a></div>';
				$responce ['rows'] [$i] ['id'] = $row->CityId;
				$responce ['rows'] [$i] ['cell'] = array (
						$row->CityId,
						$row->City,
						$row->Latitude,
						$row->Longitude,
						$row->TimeZone,
						$row->Code,
						$row->action 
				);
				$i ++;
			}
		}
		echo json_encode ($responce);
	}
	
	//Loads add_country view page (with details of selected country,if it is edit operation)
	function get_country_by_countryid($id = null){
		$table = 'countries';
		$column_name = 'CountryId';
		$data ['Countrydetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_country', $data );
	}
	
	//Loads add_state view page (with details of selected state,if it is edit operation)
	function get_state_by_stateid($id = null){
		$table = 'regions';
		$column_name = 'RegionID';
		$data ['Statedetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_state', $data );
	}
	
	//Loads add_city view page(with details of selected city,if it is edit operation)
	function get_city_by_cityid($id = null){
		$table = 'cities';
		$column_name = 'CityId';
		$data ['Citydetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$arrcitydetails = array ();
		foreach ( $data ['Citydetails'] as $key => $value )
			$arrcitydetails [$key] = $value;
		$data ['arrStates'] = $this->country_helper->getStatesByCountryId ( $arrcitydetails ['CountryID'] );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_city', $data );
	}
	
	// for adding/updating coutry details.
	function save_country() {
		$arrCountry ['CountryId'] = $this->input->post ( 'CountryId' );
		$arrCountry ['Country'] = $this->input->post ( 'Country' );
		$arrCountry ['Capital'] = $this->input->post ( 'Capital' );
		$arrCountry ['GlobalRegion'] = $this->input->post ( 'GlobalRegion' );
		$arrCountry ['NationalitySingular'] = $this->input->post ( 'NationalitySingular' );
		$arrCountry ['NationalityPlural'] = $this->input->post ( 'NationalityPlural' );
		$arrCountry ['Currency'] = $this->input->post ( 'Currency' );
		$arrCountry ['CurrencyCode'] = $this->input->post ( 'CurrencyCode' );
		$arrCountry ['Population'] = $this->input->post ( 'Population' );
		$table = 'countries';
		$column_name = 'CountryId';
		$column_value = $arrCountry ['CountryId'];
		if ($arrCountry ['CountryId'] > 0) {
				$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
				//Add Log activity
				$formData = $_POST;
				$formData = json_encode($formData);
				$arrLogDetails = array(
						'type' => EDIT_RECORD,
						'description' => 'Update Country',
						'status' => STATUS_SUCCESS,
						'transaction_id' => $arrCountry ['CountryId'],
						'transaction_table_id' => COUNTRIES,
						'transaction_name' => "Update Country",
						'form_data' => $formData,
						'parent_object_id' => $arrCountry ['CountryId']
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity(null,true);
				$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
				$data ['saved'] = $this->master_data_model->checkCountryIfExistElseAdd ( $arrCountry );
				if($data['saved']){
					$arrConfig = $this->common_helpers->getMailConfig('','');
					$arrInfo = array (
							'FROM' => "kishanr@aissel.com",
							'FROM_NAME' => "Kishan Ravindra",
							'TO' => array("laxmank@aissel.com"),
							'CC' => array(""),
							'SUBJECT' => "Notification about creation of new Country",
							'MAIL_BODY' => "<html>
										<head>
											<style>
												table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
												td, th { border: 1px solid #CCC; height: 30px; }
												th { background: #F3F3F3; font-weight: bold; }
												td { background: #FAFAFA; text-align: center;}
											</style>
										</head>
										<body>
											<div>
												Hi, Following information is added by ".$this->loggedUser."<br><br>
												<table>
													<tr><th>Country</th><td>".$arrCountry['Country']."</td></tr>
													<tr><th>Capital</th><td>".$arrCountry['Capital']."</td></tr>
													<tr><th>Global Region</th><td>".$arrCountry['GlobalRegion']."</td></tr>
													<tr><th>Nationality Singular</th><td>".$arrCountry['NationalitySingular']."</td></tr>
													<tr><th>Nationality Plural</th><td>".$arrCountry['NationalityPlural']."</td></tr>
													<tr><th>Currency</th><td>".$arrCountry['Currency']."</td></tr>
													<tr><th>Currency Code</th><td>".$arrCountry['CurrencyCode']."</td></tr>
													<tr><th>Population</th><td>".$arrCountry['Population']."</td></tr>
												</table><br>Regards,<br>Aissel Technologies<br>
											</div>
										</body>
									</html>"
					);
					$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
				}
				$data ['msg'] = $data ['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		//Add Log activity
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'type' => ADD_RECORD,
				'description' => 'Save Country',
				'status' => STATUS_SUCCESS,
				'transaction_id' => $arrCountry ['CountryId'],
				'transaction_table_id' => COUNTRIES,
				'transaction_name' => "Save Country",
				'form_data' => $formData,
				'parent_object_id' => $arrCountry ['CountryId']
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		echo json_encode ( $data );
	}
	
	//updates state details into db after editing.
	function save_state(){
		$arrCountry ['RegionID'] = $this->input->post ( 'RegionID' );
		$arrCountry ['CountryID'] = $this->input->post ( 'CountryID' );
		$arrCountry ['Region'] = $this->input->post ( 'Region' );
		$arrCountry ['Code'] = $this->input->post ( 'Code' );
		$table = 'regions';
		$column_name = 'RegionID';
		$column_value = $arrCountry ['RegionID'];
		if ($arrCountry ['RegionID'] > 0) {
			$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update State',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $arrCountry ['RegionID'],
					'transaction_table_id' => REGIONS,
					'transaction_name' => "Update State",
					'form_data' => $formData,
					'parent_object_id' => $arrCountry ['RegionID']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
			$data ['saved'] = $this->master_data_model->checkStateIfExistElseAdd( $arrCountry ['Region'], $arrCountry ['CountryID'], $arrCountry ['Code'] );
			if($data['saved']){
				$arrConfig = $this->common_helpers->getMailConfig('','');
				$arrInfo = array (
						'FROM' => "kishanr@aissel.com",
						'FROM_NAME' => "Kishan Ravindra",
						'TO' => array("laxmank@aissel.com"),
						'CC' => array(""),
						'SUBJECT' => "Notification about creation of new State",
						'MAIL_BODY' => "<html>
										<head>
											<style>
												table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
												td, th { border: 1px solid #CCC; height: 30px; }
												th { background: #F3F3F3; font-weight: bold; }
												td { background: #FAFAFA; text-align: center;}
											</style>
										</head>
										<body>
											<div>
												Hi, Following information is added by ".$this->loggedUser."<br><br>
												<table>
													<tr><th>Country</th><td>".$arrCountry['CountryID']."</td></tr>
													<tr><th>Region</th><td>".$arrCountry['Region']."</td></tr>
													<tr><th>Code</th><td>".$arrCountry['Code']."</td></tr>
												</table><br>Regards,<br>Aissel Technologies<br>
											</div>
										</body>
									</html>"
				);
				$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
			}
			$data ['msg'] = $data ['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		//Add Log activity
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'type' => ADD_RECORD,
				'description' => 'Add State',
				'status' => STATUS_SUCCESS,
				'transaction_id' => $arrCountry ['RegionID'],
				'transaction_table_id' => REGIONS,
				'transaction_name' => "Add State",
				'form_data' => $formData,
				'parent_object_id' => $arrCountry ['RegionID']
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		echo json_encode ( $data );
	}
	
	//updates city details into db after editing.
	function save_city(){
		$arrCountry ['CityId'] = $this->input->post ( 'CityId' );
		$arrCountry ['City'] = $this->input->post ( 'City' );
		$arrCountry ['CountryID'] = $this->input->post ( 'CountryID' );
		$arrCountry ['RegionID'] = $this->input->post ( 'state_id' );
		$arrCountry ['Latitude'] = $this->input->post ( 'Latitude' );
		$arrCountry ['Longitude'] = $this->input->post ( 'Longitude' );
		$arrCountry ['TimeZone'] = $this->input->post ( 'TimeZone' );
		$arrCountry ['Code'] = $this->input->post ( 'Code' );
		$table = 'cities';
		$column_name = 'CityId';
		$column_value = $arrCountry ['CityId'];
		if ($arrCountry ['CityId'] > 0) {
			$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update City',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $arrCountry ['CityId'],
					'transaction_table_id' => CITIES,
					'transaction_name' => "Update City",
					'form_data' => $formData,
					'parent_object_id' => $arrCountry ['CityId']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
			$data['saved'] = $this->master_data_model->addCity($arrCountry);
			if($data['saved']){
				$arrConfig = $this->common_helpers->getMailConfig('','');
				$arrInfo = array (
						'FROM' => "kishanr@aissel.com",
						'FROM_NAME' => "Kishan Ravindra",
						'TO' => array("laxmank@aissel.com"),
						'CC' => array(""),
						'SUBJECT' => "Notification about creation of new City",
						'MAIL_BODY' => "<html>
										<head>
											<style>
												table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
												td, th { border: 1px solid #CCC; height: 30px; }
												th { background: #F3F3F3; font-weight: bold; }
												td { background: #FAFAFA; text-align: center;}
											</style>
										</head>
										<body>
											<div>
												Hi, Following information is added by ".$this->loggedUser."<br><br>
												<table>
													<tr><th>City</th><td>".$arrCountry['City']."</td></tr>
													<tr><th>Country Id</th><td>".$arrCountry['CountryID']."</td></tr>
													<tr><th>Region Id</th><td>".$arrCountry['RegionID']."</td></tr>
													<tr><th>Latitude</th><td>".$arrCountry['Latitude']."</td></tr>
													<tr><th>Longitude</th><td>".$arrCountry['Longitude']."</td></tr>
													<tr><th>TimeZone</th><td>".$arrCountry['TimeZone']."</td></tr>
													<tr><th>Code</th><td>".$arrCountry['Code']."</td></tr>
												</table><br>Regards,<br>Aissel Technologies<br>
											</div>
										</body>
									</html>"
				);
				$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
			}
			$data['msg'] = $data['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		//Add Log activity
		$formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'type' => ADD_RECORD,
				'description' => 'Add City',
				'status' => STATUS_SUCCESS,
				'transaction_id' => $arrCountry ['CityId'],
				'transaction_table_id' => CITIES,
				'transaction_name' => "Add City",
				'form_data' => $formData,
				'parent_object_id' => $arrCountry ['CityId']
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		echo json_encode ( $data );
	}
	
	//deletes a selected country by its countryId
	function delete_country_by_countryid($id){
		$arraydetails ['column_name'] = 'CountryId';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'countries';
		$data ['status'] = $this->master_data_model->delete($arraydetails) ? 1 : 0;
		echo json_encode($data);
	}
	
	//deletes a selected state by its regionId
	function delete_state_by_stateid($id){
		$arraydetails ['column_name'] = 'RegionID';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'regions';
		$data ['status'] = $this->master_data_model->delete ( $arraydetails ) ? 1 : 0;
		echo json_encode ( $data );
	}
	
	//deletes a selected city by its cityId
	function delete_city_by_cityid($id){
		$arraydetails ['column_name'] = 'CityId';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'cities';
		$data ['status'] = $this->master_data_model->delete($arraydetails) ? 1 : 0;
		echo json_encode ( $data );
	}
}
