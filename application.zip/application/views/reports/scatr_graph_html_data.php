<?php
/**
 * Page to display the scattered graph data into html
 * 
 * @author Laxman K
 * @since 3.1.2
 * @created 22-10-2011
*/
?>
<script src="https://code.jquery.com/jquery-3.0.0.min.js" integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="
crossorigin="anonymous"></script>

<script type="text/javascript">
	$(document).ready(function(){

		//Expand or Collaps the subnode based on the current status
		$('.expander').click(function(){
			var parentTrId=$(this).parent().parent().attr('id');
			var parentTrClass=$(this).parent().parent().attr('class');
			//If current status is collapsed , then make it as expanded and show all its subnodes
			if($(this).parent().parent().hasClass('collapsed')){
				$(this).parent().parent().removeClass('collapsed');
				$(this).parent().parent().addClass('expanded');
				$(this).attr('title','collapse');
				$('.subNodeOf'+parentTrId).show();
			}else{
			//If current status is expanded , then make it as collapsed and hide all its subnodes
				$(this).parent().parent().removeClass('expanded');
				$(this).parent().parent().addClass('collapsed');
				$(this).attr('title','expand');
				$('.subNodeOf'+parentTrId).hide();
			}
			
		});
	});
</script>
<style>
	#scatrGraph{
		float: left;
		clear: left;
		width: 100%;
	}
	
	#scatrGraph td.nodeLevelTwo {
		padding-left: 50px;
		background: url("<?php echo base_url();?>images/tabletree-dots.gif") no-repeat scroll 36px 54% transparent;
	}
	
	#scatrGraph td.endNode {
		background: url("<?php echo base_url();?>images/tabletree-dots2.gif") no-repeat scroll 36px 50% transparent;
	}
	#scatrGraph tr.collapsed td .expander {
	    background-image: url("<?php echo base_url();?>images/toggle-expand-dark.png");
	    padding-left: 19px;
	    cursor: pointer;
	}
	#scatrGraph tr.expanded td .expander {
	    background-image: url("<?php echo base_url();?>images/toggle-collapse-dark.png");
	    padding-left: 19px;
	    cursor: pointer;
	}
	#scatrGraph .parentNode{
		color: #1A5C76;
		font-weight: bold;
	}
	#scatrGraph tr.parentNode {
		background: whiteSmoke;
	}
	
	#scatrGraph tr.subNode {
		background: wheat;
	}
	
	#planReportsContainer #leftReports{
		width: 60%;
		min-height: 565px;
		float: left;
	}
	#planReportsContainer #rightReports{
		width: 38%;
		min-height: 565px;
		float: left;
		border: 1px solid silver;
		margin-left: 10px;
		text-align: center;
	}
	
	#planReportsContainer .parentNode td {
		border-bottom: 1px solid black;
	}
	.alignCenter{
		text-align:center;
	}
</style>
<table width="50%" border="1" id="scatrGraph" >
<tr style="background: none repeat scroll 0 0 #2E6E9E;color: #FFFFFF">
	<th width="65px">SN</th>
	<th  width="400px"><?php echo lang("KOL"); ?> Name</th>
	<th>Parameter</th>
	<th width="100px" class="alignCenter">X - Count</th>
	<th width="100px" class="alignCenter">X - Weightage</th>
	<th width="100px" class="alignCenter">Y - Count</th>
	<th width="100px" class="alignCenter">Y - Weightage</th>
</tr>
<tr style="background: none repeat scroll 0 0 #2E6E9E;color: #FFFFFF">
	<th colspan="7">Year Range: <?php echo $this->session->userdata('fromYear');?>
		- <?php echo $this->session->userdata('toYear');?>
	</th>
	
</tr>
<?php
$prev_index=$data[0][0];
foreach($data as $key=>$values){
	//pr($data);exit;
	if(!empty($values[0])){
		$curIndex=$values[0];
		if($prev_index!=$curIndex)
			$prev_index=$curIndex;
	}
	
	if($curIndex!="SN" && (!empty($values[2]))){
?>
		<tr  id="<?php if($values[0]!='') echo 'Node'.$values[0];?>" class="<?php if($values[0]=='') echo 'subNode subNodeOfNode'.$curIndex; else echo 'collapsed parentNode';?>" style="<?php if($values[0]=='') echo 'display:none'?>">
			<td>
				<?php if($values[0]!=''){?>
					<span class="expander" title="expand"></span>
				<?php }?>
				<?php if($values[0]!='') echo $values[0];?>
			</td>
			<td class="<?php if($values[0]=='') echo 'nodeLevelTwo'; if($prev_index!=$curIndex) echo ' endNode'?>">
				<?php echo $values[1];?>
			</td>
			<td>
				<?php
					if($values[2]=='Affiliations' || $values[2]=='Publications' || $values[2]=='Events' || $values[2]=='Trials'){
						echo "<strong>".$values[2]."</strong>";
					}else{
						echo $values[2];
					} 
				?>
			</td>
			<td  class="alignCenter">
				<?php 
					if($values[2]=='Affiliations' || $values[2]=='Publications' || $values[2]=='Events' || $values[2]=='Trials'){
						echo "<strong>".$values[3]."</strong>";
					}else{
						echo $values[3];
					}
				?>
			</td>
			<td  class="alignCenter">
				<?php 
				if(isset($values[4])){
					if($values[2]=='Affiliations' || $values[2]=='Publications' || $values[2]=='Events' || $values[2]=='Trials'){
						echo "<strong>".$values[4]."</strong>";
					}else{
						echo $values[4];
					}	
				}
				?>&nbsp;
			</td>
			<td  class="alignCenter">
			<?php 
				if(isset($values[5])){					
					echo $values[5];						
				}
				?>&nbsp;
			</td>
			<td  class="alignCenter">
			<?php 
				if(isset($values[6])){					
					echo $values[6];						
				}
				?>&nbsp;
			</td>
		</tr>
<?php 
	}
}
?>
</table>
