<?php 

?>
	<!-- Load the Custom CSS file -->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/default_ie_only.css" rel="stylesheet" />
	<![endif]-->
<style>
	.title-bar-actions{
		float: right;
		margin-right: 20px;
	}
	.title-bar-actions a{
		margin: 10px;
	}
	.excelExportIcon{
		ma
	}
	.upBtn{
		background: #5282D9;
		color: white;
		text-align: center;
	}
	#b0,#b1{
		background: none;
		cursor: pointer;
	}
	.upCon{
		text-align: center;
		margin-bottom: 15px;
	}
</style>
<script>
	function list_unprocessed_trials(process){
		if(process == 0){
			var titleName = 'Unprocessed Clinical Trials';
			$("#b0").css("background","#FAD160");
			$("#b1").css("background","none");
		}else{
			var titleName = 'Processed Clinical Trials';
			$("#b0").css("background","none");
			$("#b1").css("background","#FAD160");
		} 
		var lastsel2;
		$('#gridKolsListing').html('');
	    $('#gridKolsListing').html('<div class="upCon"><button class="upBtn" onclick="update_industry_trial();">Update Industry Trial</button></div><div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
	    grid = $("#gridKolsListingResultSet"),
        grid.jqGrid({
			url:'<?php echo base_url();?>clinical_trials/get_unprocessed_trials/'+process,
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','',"Is Industry"],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'trial_id',index:'trial_id',hidden:true},
//		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>},
		   		{name:'is_industry1',index:'is_industry1',align:'center', search:false}	
		   	],           
		   	rowNum:10,
//		   	multiselect: true,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#gridKolsListingPagintaion',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:titleName,
		    gridComplete: function(){	
		    },
			rowList:paginationValues
		});
		
        grid.jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		//setSearchSelect('pubmed_processed');
		grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});

		var buttonsText = "<div class='title-bar-actions'>";
		buttonsText += "<div class='excelExportIcon'><a rel='tooltip' href='#' onclick='select_all_yes()' >Yes</a><a rel='tooltip' href='#' onclick='select_all_no()'>No</a><a rel='tooltip' href='#' onclick='reset_all()'>Reset</a></div>";
		buttonsText += "</div>";
		$("#gridKolsListing .ui-jqgrid-titlebar").append(buttonsText);
	}

	function toggleSearchToolbar(){ 			
		if(jQuery(".ui-search-toolbar").css("display")=="none") {
			jQuery(".ui-search-toolbar").css("display","");
		} else {
			jQuery(".ui-search-toolbar").css("display","none");
		}
	};
	
	$(document).ready(function (){
//		list_unprocessed_trials();
	});
	function update_industry_trial(){
		if(confirm("Are you sure want to update")){
			var selectedOPtion = $(".ui-pg-selbox").val();
			var arrIds1 = jQuery("#gridKolsListingResultSet").jqGrid('getDataIDs');
	    	var arrIds = new Array();
	    	for(var j=0; j<selectedOPtion;j++){
	    		var ids = jQuery("#gridKolsListingResultSet").jqGrid('getRowData',arrIds1[j]);
	    		if(ids.id){
					var idqw = ids.id;
					var name = "is_industry"+idqw;
		    		var checkVal = $("#"+idqw+" input[name="+name+"]:checked").val();
		    		if(checkVal){
		    			var indusArr = {"id":ids.id,"is_industry_trial":checkVal};
		    			arrIds.push(indusArr);
		    		}
				}
		    }
		    if(arrIds.length > 0){
			    var data = {};
			    data["data"] = arrIds;
			    $.ajax({
					url:'<?php echo base_url()?>clinical_trials/update_trial_industries/',
					type:'post',
					dataType:"json",
					data:data,
					success:function(returnMsg){
						if(returnMsg.status)
							location.reload();
					}
				});
		    }else{
		    	jAlert("Please select at least one Trial");
			}
		}else{
			return false;	
		}
	}

	function select_all_yes(){
		var selectedOPtion = $(".ui-pg-selbox").val();
		var arrIds1 = jQuery("#gridKolsListingResultSet").jqGrid('getDataIDs');
    	var arrIds = new Array();
    	for(var j=0; j<selectedOPtion;j++){
    		var ids = jQuery("#gridKolsListingResultSet").jqGrid('getRowData',arrIds1[j]);
    		if(ids.id){
				var idqw = ids.id;
				var name = "is_industry"+idqw;
				$("#"+name+"_2").prop("checked", false);
	    		$("#"+name+"_1").prop("checked", true);
			}
	    }
	}

	function select_all_no(){
		var selectedOPtion = $(".ui-pg-selbox").val();
		var arrIds1 = jQuery("#gridKolsListingResultSet").jqGrid('getDataIDs');
    	var arrIds = new Array();
    	for(var j=0; j<arrIds1.length;j++){
    		var ids = jQuery("#gridKolsListingResultSet").jqGrid('getRowData',arrIds1[j]);
    		if(ids.id){
				var idqw = ids.id;
				var name = "is_industry"+idqw;
				$("#"+name+"_1").prop("checked", false);
	    		$("#"+name+"_2").prop("checked", true);
			}
	    }
	}

	function reset_all(){
		var selectedOPtion = $(".ui-pg-selbox").val();
		var arrIds1 = jQuery("#gridKolsListingResultSet").jqGrid('getDataIDs');
    	var arrIds = new Array();
    	for(var j=0; j<arrIds1.length;j++){
    		var ids = jQuery("#gridKolsListingResultSet").jqGrid('getRowData',arrIds1[j]);
    		if(ids.id){
				var idqw = ids.id;
				var name = "is_industry"+idqw;
				$("#"+name+"_1").prop("checked", false);
	    		$("#"+name+"_2").prop("checked", false);
			}
	    }
	}

</script>
<div>
	<div style="margin-bottom: 15px;">
		<button id="b0" onclick="list_unprocessed_trials(0);">List Unprocessed</button>
		<button id="b1" onclick="list_unprocessed_trials(1);">List Processed</button>
		<a style="float: right;" href="<?php echo base_url()?>clinical_trials/export_all_trials" target="_new">Export all trials</a>
	</div>
	<div id="gridKolsListing">
		<div class="gridWrapper">
			<div id="gridKolsListingPagintaion"></div>
			<table id="gridKolsListingResultSet"></table>
		</div>
	</div>
</div>