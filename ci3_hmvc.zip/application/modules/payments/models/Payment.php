<?php
class Payment extends CI_Model {
	function getAllPaymentsPaidBy(){
		$clientId=$this->session->userdata('client_id');
		$arrData = array();
		$this->db->select('payments_paid_by_client_association.id,payments_paid_by.paid_by');
		$this->db->where('payments_paid_by_client_association.client_id',$clientId);
		$this->db->join('payments_paid_by_client_association','payments_paid_by_client_association.payments_paid_by_id=payments_paid_by.id');
		$resultSet = $this->db->get('payments_paid_by');
		foreach($resultSet->result_array() as $row){
			$arrData[$row['id']] = $row['paid_by'];
		}
		return $arrData;
	}
	function getAllPaymentsRequestedBy(){
		$arrData = array();
		$clientId=$this->session->userdata('client_id');
		$this->db->select('payments_requested_by_client_association.id,payments_requested_by.requested_by');
		$this->db->where('payments_requested_by_client_association.client_id',$clientId);
		$this->db->join('payments_requested_by_client_association','payments_requested_by_client_association.payments_requested_by_id=payments_requested_by.id');
		$resultSet = $this->db->get('payments_requested_by');
		foreach($resultSet->result_array() as $row){
			$arrData[$row['id']] = $row['requested_by'];
		}
		return $arrData;
	}
	function getAllPaymentTypes(){
		$arrPaymentTypes	= array();
		$clientId=$this->session->userdata('client_id');
		$this->db->select('payment_types_client_association.id,payment_types.name');
		$this->db->where('payment_types_client_association.client_id',$clientId);
		$this->db->join('payment_types_client_association','payment_types_client_association.payment_type_id=payment_types.id');
		$arrPaymentTypesResult = $this->db->get('payment_types');
		foreach($arrPaymentTypesResult->result_array() as $arrPaymentType){
			$arrPaymentTypes[$arrPaymentType['id']]	= $arrPaymentType['name'];
		}
		return $arrPaymentTypes;
	}
	function arrPaymentCurrencies(){
		$arrPaymentCurrencies	= array();
		$clientId=$this->session->userdata('client_id');
		$this->db->select('payments_currency_client_association.id,payments_currency.currency_name,payments_currency.currency_symbol');
		$this->db->where('payments_currency_client_association.client_id',$clientId);
		$this->db->join('payments_currency_client_association','payments_currency_client_association.payment_currency_id=payments_currency.id');
		$arrPaymentCurrencyResult = $this->db->get('payments_currency');
		foreach($arrPaymentCurrencyResult->result_array() as $arrPaymentCurrency){
			$arrPaymentCurrencies[$arrPaymentCurrency['id']]= $arrPaymentCurrency;
		}
		return $arrPaymentCurrencies;
	}
	function getAllInteractionIds($clientId,$userId){
		$arrInteractionIds	= array();
		if($this->session->userdata('user_role_id')!=ROLE_MANAGER || $this->session->userdata('user_role_id')!=ROLE_ADMIN)
			$this->db->where('created_by',$userId);
		$this->db->where('client_id',$clientId);
		$arrInteractionResult = $this->db->get('interactions');
		foreach($arrInteractionResult->result_array() as $interaction){
			$arrInteractionIds[$interaction['id']]	= $interaction['id'];
		}
		return $arrInteractionIds;
	}
	function getAllKolsName($restrictByRegion=0){
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrKol	= array();
		$this->db->select('kols.id as kol_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->order_by('first_name');
		if($restrictByRegion){
			$group_names = explode(',', $this->session->userdata('group_names'));
			$this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
			$this->db->where_in( 'countries.GlobalRegion', $group_names);
		}
		$arrKolResult = $this->db->get('kols');
		foreach($arrKolResult->result_array() as $kol){
			if( $kol['salutation']!=0){
				$kol['name']= $kol['first_name'].' '.$kol['middle_name'].' '.$kol['last_name'];
			}else{
				$kol['name']= $kol['first_name'].' '.$kol['middle_name'].' '.$kol['last_name'];
			}
			$arrKol[$kol['kol_id']]	= $kol['name'];
		}
		return $arrKol;
	}
	function listPaymentDetails($clientId,$kolId,$userId,$startDate=0,$endDate=0,$limit=0){
		$arrPaymentDetail	=	array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','kols.status','kols.unique_id','payments.requested_by','payments.paid_by','kols.deleted_by as kol_deleted','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		$this->db->select('CONCAT(COALESCE(CASE
									WHEN kols.salutation = 1 THEN "Dr."
									WHEN kols.salutation = 2 THEN "Prof."
									WHEN kols.salutation = 3 THEN "Mr."
									WHEN kols.salutation = 4 THEN "Ms."
									ELSE ""
									END ,""),COALESCE(kols.first_name,"")," ",COALESCE(kols.middle_name,"")," ",COALESCE(kols.last_name,"")) as kol_full_name,
	                              client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('kols_client_visibility', 'kols_client_visibility.id = payments.kol_id', 'left');
		$this->db->join('kols', 'kols.id = kols_client_visibility.kol_id','left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');
		if($clientId!=0){
			if($clientId!=INTERNAL_CLIENT_ID){
				$this->db->where('kols_client_visibility.client_id',$clientId);
			}
		}
		if($kolId!=null && $kolId!=-1){
			$this->db->where('payments.kol_id',$kolId);
		}
		if($startDate!=0 && $endDate!=0){
			$wherBetween="(payments.date  BETWEEN '".$startDate."-01' AND '".$endDate."-31')";
			$this->db->where($wherBetween);
		}
		if($kolId==null && $clientId!=INTERNAL_CLIENT_ID){
			if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
				$group_names = explode(',', $this->session->userdata('group_names'));
				$this->db->join('countries','countries.CountryId = kols.country_id','left' );
				$this->db->where_in('countries.GlobalRegion',$group_names);
			}
		}
		if($limit>0){
			$this->db->limit($limit);
		}
		$this->db->order_by('kol_full_name','asc');
		$this->db->order_by('payments.date','desc');
		$arrPaymentDetailResult	=	$this->db->get('payments');
		foreach ($arrPaymentDetailResult->result_array() as $paymentDetail){
			$paymentDetail['requested_by']		= $this->payment->getPaymentRequestedBy($paymentDetail['requested_by']);
			$paymentDetail['paid_by']			= $this->payment->getPaymentPaidBy($paymentDetail['paid_by']);
			$arrPaymentDetail[] = $paymentDetail;
		}
		return $arrPaymentDetail;
	}
	function getPaymentRequestedBy($requestedId){
		$reqBy	= '';
		$this->db->where('id',$requestedId);
		$arrResult = $this->db->get('payments_requested_by');
		foreach($arrResult->result_array() as $row){
			$reqBy = $row['requested_by'];
		}
		return $reqBy;
	}
	function getPaymentPaidBy($paidId){
		$paidBy	= '';
		$this->db->where('id',$paidId);
		$arrResult = $this->db->get('payments_paid_by');
		foreach($arrResult->result_array() as $row){
			$paidBy = $row['paid_by'];
		}
		return $paidBy;
	}
	function getPayementTypeAndAmount($paymentId){
		$arrPaymentTypesAndAmounts =array();
		$this->db->select('payment_split.type,payment_split.currency, payment_split.amount as indAmount');
		$this->db->where('payment_split.payment_id',$paymentId);
		$arrResult = $this->db->get('payment_split');
		foreach($arrResult->result_array() as $row){
			$arrPaymentTypesAndAmounts[]=$row;
		}
		return $arrPaymentTypesAndAmounts;
	}
	function getPaymentById($paymentId){
		$arrPaymentDetail	= array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		//$this->db->join('payment_split', 'payment_split.payment_id = payments.id', 'left');
		//	$this->db->join('payment_types', 'payment_types.id = payment_split.type', 'left');
		$this->db->join('kols', 'kols.id = payments.kol_id', 'left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');
		
		$this->db->where('payments.id',$paymentId);
		if($arrPaymentDetailResult	=	$this->db->get('payments')){
			// If the results are not available
			if($arrPaymentDetailResult->num_rows() == 0){
				return false;
			}
			foreach($arrPaymentDetailResult->result_array() as $arrPayment){
				$arrPayment['date'] = $this->convertDateToMM_DD_YYYY($arrPayment['date']);
				if($arrPayment['date']=='00/00/0000'){
					$arrPayment['date']='';
				}
				$arrPayment['kol_name']= $arrPayment['first_name'].' '.$arrPayment['middle_name'].' '.$arrPayment['last_name'];
// 				$arrPayment['kol_name']= nf($arrPayment['first_name'],$arrPayment['middle_name'],$arrPayment['last_name']);
				$arrPaymentDetail	= $arrPayment;
			}
			return $arrPaymentDetail;
		}else{
			return false;
		}
	}	
	function convertDateToMM_DD_YYYY($inputDate, $delimiter='/'){
		$ddDate	= substr($inputDate,8,2);
		$mmDate	= substr($inputDate,5,2);
		$yyDate	= substr($inputDate,0,4);
		return ($mmDate.$delimiter.$ddDate.$delimiter.$yyDate);
	}
	function deletePaymentById($paymentId){
		$this->db->select('kol_id');
		$this->db->where('id',$paymentId);
		$queryRes = $this->db->get('payments');
		$row = $queryRes->row();
		if (isset($row))
		{
			if($row->kol_id > 0){
				$transactionName = 'Delete payments';
				$kol_org_type = 'Kol';
				$kols_or_org_id = $row->kol_id;
				$parentObjectId = $row->kol_id;
			}
		}
		$this->db->where('id',$paymentId);
		if($query=$this->db->delete('payments')){
			return true;
		}else{
			return false;
		}
	}
	function exportPaymentDetails($clientId,$kolId,$userId,$startDate=0,$endDate=0,$paymentIds){
		$arrPaymentDetail	=	array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','kols_client_visibility.status','payments.requested_by','payments.paid_by','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		$this->db->join('kols_client_visibility', 'kols_client_visibility.id =  payments.kol_id ', 'left');
		$this->db->join('kols', 'kols.id =kols_client_visibility.kol_id', 'left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');
		//Setting kol_id = -1 when track is clicked
		if($kolId!=null && $kolId!=-1){
			$this->db->where('payments.kol_id',$kolId);
		}
		
		$this->db->where_in('payments.id',$paymentIds);
		$this->db->order_by('kols.first_name');
		$this->db->order_by('payments.date','desc');
		$arrPaymentDetailResult	=	$this->db->get('payments');
		foreach ($arrPaymentDetailResult->result_array() as $paymentDetail){
			$arrPaymentDetail[] = $paymentDetail;
		}
		
		return $arrPaymentDetail;
	}
	function getAllKolsName1($restrictByRegion=0){
		$arrkols=array();
		$this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name');
		//$status = COMPLETED;
		//$this->db->where('status',"$status");
		if($restrictByRegion){
			$group_names = explode(',', $this->session->userdata('group_names'));
			$this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
			$this->db->where_in( 'countries.GlobalRegion', $group_names);
		}
		$arrResult = $this->db->get('kols');
		// 		pr($this->db->last_query());exit;
		foreach($arrResult->result_array() as $row){
			if($row['middle_name']!=''){
							$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
// 				$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}else{
								$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER];
// 				$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}
		}
		return $arrkols;
	}
	function updatePayment($paymentDetails){
		$client_id= $this->session->userdata('client_id');
		if($paymentDetails['id']>0){
			$paymentDetails['modified_by']=$this->session->userdata('user_id');
			$paymentDetails['modified_on']=date('Y-m-d H:i:s');
			$this->db->where('id',$paymentDetails['id']);
			if($this->db->update('payments',$paymentDetails))
				return $paymentDetails['id'];
		}else{
			$dataType = 'User Added';
			if($client_id== INTERNAL_CLIENT_ID){
				$dataType = 'Aissel Analyst';
			}
			$paymentDetails['data_type_indicator']=$dataType;
			$paymentDetails['created_by']=$this->session->userdata('user_id');
			$paymentDetails['created_on']=date('Y-m-d H:i:s');
			if($this->db->insert('payments',$paymentDetails)){
				return $this->db->insert_id();
			}
		}
		return false;
	}
	function updateTypeAndAmount($payementId,$arrTypes){
		$this->db->where('payment_id',$payementId);
		$this->db->delete('payment_split');
		foreach($arrTypes as $arrType){
			$arrType['payment_id']=$payementId;
			$this->db->insert('payment_split', $arrType); 
		}
	}

	function saveTypeAndAmount($payementId,$arrTypesAndAmounts){
		$seperator='';
		$bulkInsert='';
		foreach($arrTypesAndAmounts as $row){
			$bulkInsert.=$seperator;
			//$bulkInsert.="($payementId,$row['type'],'".$row['amount']."')";
			$bulkInsert.="($payementId,".$row['type'].",".$row['currency'].",'".$row['amount']."')";
			$seperator=',';
		}
		$this->db->query("insert into payment_split(`payment_id`,`type`,`currency`,`amount`) values $bulkInsert");
	}
	function getAssignedUsersForType($id){
		$client_id = $this->session->userdata('client_id');
		$this->db->select("user_kols.user_id, client_users.email");
		$this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
		$this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
		$this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
		$this->db->where('user_kols.kol_id', $id);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->where('client_users.client_id', $client_id);
		}
		$query = $this->db->get('user_kols');
		$result = $query->result();
		foreach($result as $row){
			$typeName = $row->typename;
			$userEmails[] =  $row->email;
		}
		$arrUsersDetails['type_name'] = $typeName;
		$arrUsersDetails['user_details'] = $userEmails;
		return $arrUsersDetails;
	}
}
?>