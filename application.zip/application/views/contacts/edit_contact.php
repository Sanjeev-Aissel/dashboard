<?php
/**
* File to 'Edit' Contact details
*
* Created By: Ambarish
* Created On:10-12-2010
* 
*/
 
?>


<!--Edit Contact details-->
<?php foreach ($arrContactDetails as $contactInfo){ 
 ?>

<h1>Edit Contact details</h1>

<?php echo form_open('kols/update_education_detail'); ?>

	<p><input type="hidden" name="id" value="<?php echo $contactInfo['id'];?>"></p>
	
	<p><label for="related_to">Related To:</label>
		<input type="text" name="related_to" value="<?php echo $contactInfo['related_to'];?>" id="related_to"></input></p>

	<p><label for="phone">Phone No:</label>
		<input type="text" name="phone" value="<?php echo $contactInfo['phone'];?>" id="phone"></input></p>

	<p><label for="email">Email:</label>
		<input type="text" name="email" value="<?php echo $contactInfo['email'];?>" id="email"></input></p>
			
	<p><input type="submit" value="update"></p>

<?php }?>	
<!--End of Edit Contact details-->