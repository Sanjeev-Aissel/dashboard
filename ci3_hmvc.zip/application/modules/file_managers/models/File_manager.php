<?php
class file_manager extends CI_Model {
}
?>