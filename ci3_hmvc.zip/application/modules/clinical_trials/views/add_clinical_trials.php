<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"/>
<?php
	$queued_js_scripts = array('datepicker/js/daterangepicker.jQuery',
			'datepicker/js/date',
			'jquery_validator/dist/jquery.validate','alerts/jquery.alerts'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<div class="panel panel-default">
	<div class="panel-heading align_center"><?php if($arrClinicalTrial['id']>0)echo 'Update Clinical Trail Details';else echo 'Add Clinical Trail';?></div>
	<div class="panel-body">
	<div class="col-md-9 col-md-offset-3 ctManualMsgBox alert alert-success" role="alert"></div>
		<form action=""   method="post" name="createModule" id="ctManualForm" class="validateForm">
		<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId;?>"/>
		<input type="hidden" name="id"  value="<?php echo $arrClinicalTrial['id'];?>" id="ctManualId"/>
				<div class="form-group row" id="show_add_file_name" >
					<label class="col-sm-3 align_right">Trial Name:<span class="required">*</span></label>
					<div class="col-sm-9">
						  <input type="text" name="trial_name" value="<?php echo $arrClinicalTrial['trial_name'];?>" id="ctTrialName" class="required form-control"/>
			    	</div>
				</div>
				<div class="form-group row" id="show_add_file_name" >
					<label class="col-sm-3 align_right">Official Title:</label>
					<div class="col-sm-9">
						  <input type="text"  class="form-control" name="official_title" value="<?php echo $arrClinicalTrial['official_title'];?>" />
			    	</div>
				</div>				
				<div class="form-group row" id="show_add_file_name" >
					<label class="col-sm-3 align_right">Trial URL:</label>
					<div class="col-sm-9">
						  <input type="text"  class="form-control"  name="trial_link" value="<?php echo $arrClinicalTrial['link'];?>" id="ctTrialUrl"/>
			    	</div>
				</div>
				<div class="form-group row">
						<label class="col-sm-3 align_right">Role:</label>
						<div class="col-sm-3">
		 						<select name="kol_role" class="form-control">
									<option value="">--Select--</option> 
									<?php 
										foreach($arrKOLRoles as $key => $value){
											if($key == $arrClinicalTrial['kol_role'])
												echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
											else
												echo '<option value="'.$key.'">'.$value.'</option>';
										}
									?>
								</select>
				    	</div>
				    	<label class="col-sm-3 align_right">Study Type:</label>
						<div class="col-sm-3">
							  <input type="text"  class="form-control" name="study_type" value="<?php echo $arrClinicalTrial['study_type'];?>" id="ctStudyType" />
				    	</div>
				    	
				</div>
				<div class="form-group row">
						<label class="col-sm-3 align_right">Condition:</label>
						<div class="col-sm-3">
							  <input type="text"  class="form-control" name="condition" value="<?php echo $arrClinicalTrial['condition'];?>" id="ctCondition"/>
				    	</div>
				    	<label class="col-sm-3 align_right">Phase:</label>
						<div class="col-sm-3">
							  <input type="text"  class="form-control" name="phase" id="ctPhase" value="<?php echo $arrClinicalTrial['phase'];?>"/>
				    	</div>
				</div>
				<div class="form-group row" id="show_add_file_name" >
					<label class="col-sm-3 align_right">Purpose:</label>
					<div class="col-sm-3">
						  <textarea name="purpose" class="form-control" rows="" cols=""><?php echo $arrClinicalTrial['purpose'];?></textarea>
			    	</div>
		    		<label class="col-sm-3 align_right">Collaborator:</label>
					<div class="col-sm-3">
						  <input type="text"  class="form-control" name="collaborator" value="<?php echo $arrClinicalTrial['collaborator'];?>" id="ctCollaborator"/>
			    	</div>
				</div>
				<div class="panel panel-default">
				  <div class="panel-heading align_center">Recruitment Information</div>
				  <div class="panel-body">
					<div class="form-group row">
						<label class="col-sm-3 align_right">Status:</label>
						<div class="col-sm-3">
				    			<select class="form-control"  name="status_id" id="ctStatusId">
											<?php 
												foreach($arrStatusIds as $key => $value){
													if($key == $arrClinicalTrial['status_id'])
														echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
													else
														echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
								</select>
				    	</div>
				    	<label class="col-sm-3 align_right">Gender:</label>
						<div class="col-sm-3">
							  <input type="text"  class="form-control" name="gender" id="ctGender" value="<?php echo $arrClinicalTrial['gender'];?>"/>
				    	</div>
					</div>
					<div class="form-group row">
							<label class="col-sm-3 align_right">Start Date:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control"id="clinical_start_id" name="start_date" value="<?php echo $arrClinicalTrial['start_date'];?>"/>
					    	</div>
					    	<label class="col-sm-3 align_right">End Date:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control"  id="clinical_end_id" name="end_date" value="<?php echo $arrClinicalTrial['end_date'];?>"/>
					    	<label class="error" id="dateError" style="display: none;padding:0px">End date should be greater than start date</label>
					    	</div>
			    	</div>
					<div class="form-group row">
							<label class="col-sm-3 align_right">Minimum Age:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control" name="min_age" value="<?php echo $arrClinicalTrial['min_age'];?>" />
					    	</div>
					    	<label class="col-sm-3 align_right">Maximum Age:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control" name="max_age" value="<?php echo $arrClinicalTrial['max_age'];?>"/>
					    	</div>
					</div>
					<div class="form-group row">
							<label class="col-sm-3 align_right">No. of Enrollees:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control" name="no_of_enrollees" value="<?php echo $arrClinicalTrial['no_of_enrollees'];?>"/>
					    	</div>
					    	<label class="col-sm-3 align_right">Number of Trial Sites:</label>
							<div class="col-sm-3">
								  <input type="text"  class="form-control"  name="no_of_trial_sites" value="<?php echo $arrClinicalTrial['no_of_trial_sites'];?>"/>
					    	</div>
					</div>
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 align_right">Intervention:</label>
					<div class="col-sm-3" >
						<table style="width: 100%;max-width: 100%;" id="addInterventionContainer">
							<tr>
								<td width="90%">
								<input type="hidden" name="interventionId"  value="<?php echo $arrIntervention['id'];?>" id="ctInterventionId"/>
									<input type="text"  class="form-control" name="intervention" value="<?php echo $arrIntervention['intervention'];?>" id="ctIntervention"/>
									<input type="hidden" name="no_of_intervention" id="noOfInterventions" value="<?php echo $arrClinicalTrial['no_of_intervention'];?>"/>
								</td>
								<td>
								<div class="actionIcon addIcon" id="addMoreInterventions"><a href="#" onclick="return false;">&nbsp;</a></div></td>
							</tr>
							<?php //pr($arrMultipleInterventions);?>
								<?php if(isset($arrMultipleInterventions) && sizeof($arrMultipleInterventions)>=1){?>
									<?php 
										$i=0;
										foreach($arrMultipleInterventions as $intervention){
											$i++;
											if($i == 1)
												continue;?>
											<tr id="ctInterventionDelete<?php echo $i?>">	
											<td width="90%">
	    										<input type="hidden" name="interventionId<?php echo $i?>"  value="<?php echo $intervention['id'];?>" id="interventionId<?php echo $i?>"/>
	    										<input type="text"  class="form-control" name="intervention<?php echo $i?>" value="<?php echo $intervention['name'];?>" id="ctIntervention<?php echo $i?>"/>
	    									</td>
	    									<td>
	    										<a onclick="delete_tr_by_id('ctInterventionDelete<?php echo $i?>');return false;">
	    											<img title="Delete" alt="Delete" src="<?php echo base_url().ASSETS;?>/images/delete_active.png" width="20" height="20">
	    										</a>
											</td>
											</tr>
									<?php }?>
								<?php 	}?>
						</table>
			    	</div>
			    	<label class="col-sm-3 align_right">Sponsor:</label>
					<div class="col-sm-3" >
						<table style="width: 100%;max-width: 100%;" id="addSponsorContainer">
							<tr>
								<td width="90%">
									<input type="text"  class="form-control"  name="sponsor" value="<?php echo $arrSponsor['sponsor'];?>" id="ctSponsor"/>
									<input type="hidden" name="sponsorId"  value="<?php echo $arrSponsor['id'];?>" id="ctSponsorId"/>
									<input type="hidden" name="no_of_sponsors" id="noOfSponsors" value="<?php echo $arrClinicalTrial['no_of_sponsors'];?>"/>
								</td>
								<td><div class="actionIcon addIcon" id="addMoreSponsors"><a href="#" onclick="return false;">&nbsp;</a></div></td>
							</tr>
							<?php if(isset($arrMultipleSponsors) && sizeof($arrMultipleSponsors)>=1){
									$i=0;
									foreach($arrMultipleSponsors as $sponsor){
										$i++;
										if($i == 1)
											continue;?>
									<tr id="ctSponsorDelete<?php echo $i?>">	
										<td width="90%">
	    									<input type="hidden" name="sponsorId<?php echo $i?>"  value="<?php echo $sponsor['id'];?>" id="sponsorId<?php echo $i?>"/>
											<input type="text" class="form-control" name="sponsor<?php echo $i?>" value="<?php echo $sponsor['agency'];?>" id="ctSponsor<?php echo $i?>"/>
										</td>
	    								<td>			
											<a onclick="delete_tr_by_id('ctSponsorDelete<?php echo $i?>');return false;" href="#">
											<img title="Delete" alt="Delete" src="<?php echo base_url().ASSETS;?>/images/delete_active.png" width="20" height="20">
											</a>
										</td>
									</tr>	
								<?php }
								}?>
						</table>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 align_right">Keywords:</label>
					<div class="col-sm-3" >
						<table style="width: 100%;max-width: 100%;" id="addKeywordContainer">
							<tr>
								<td width="90%">
									<input type="text"  class="form-control" name="keywords" value="<?php echo $arrKeyword['keywords'];?>" id="ctKeywords"/>
									<input type="hidden" name="keywordId"  value="<?php echo $arrKeyword['id'];?>" id="ctKeywordId"/>
								<input type="hidden" name="no_of_keywords" id="noOfKeywords" value="<?php echo $arrClinicalTrial['no_of_keywords'];?>"/>
								</td>
								<td><div class="actionIcon addIcon" id="addMoreKeywords"><a href="#" onclick="return false;">&nbsp;</a></div></td>
							</tr>
							<?php if(isset($arrMultipleKeywords) && sizeof($arrMultipleKeywords)>=1){?>
									<?php 
										$i=0;
										foreach($arrMultipleKeywords as $key=>$keyword){
											$i++;
											if($i == 1)
												continue;?>
									<tr id="ctKeywordsDelete<?php echo $i?>">	
										<td width="90%">
	    									<input type="hidden" name="keywordId<?php echo $i?>"  value="<?php echo $keyword['id'];?>" id="ctKeywordId<?php echo $i?>"/>
	    									<input type="text" class="form-control" name="keywords<?php echo $i?>" value="<?php echo $keyword['name'];?>" id="ctKeywords<?php echo $i?>"/>
										</td>
	    								<td>			
											<a onclick="delete_tr_by_id('ctKeywordsDelete<?php echo $i?>');return false;" href="#">
											<img title="Delete" alt="Delete" src="<?php echo base_url().ASSETS;?>/images/delete_active.png" width="20" height="20">
											</a>
										</td>
									</tr>	
									<?php }?>
								<?php 	}?>
						</table>
			    	</div>
			    	<label class="col-sm-3 align_right">MeSH Terms:</label>
					<div class="col-sm-3" >
						<table style="width: 100%;max-width: 100%;" id="addMeshtermContainer">
							<tr>
								<td width="90%">
									<input type="hidden" name="meshtermsId"  value="<?php echo $arrMeshterm['id'];?>" id="ctMeshtermsId"/>
									<input type="hidden" name="no_of_meshterms" id="noOfMeshterms" value="<?php echo $arrClinicalTrial['no_of_meshterms'];?>"/>
									<input type="text"  class="form-control" name="meshterms" value="<?php echo $arrMeshterm['meshterms'];?>" id="ctMeshterms"/>
								</td>
								<td><div class="actionIcon addIcon" id="addMoreMeshterms"><a href="#" onclick="return false;">&nbsp;</a></div></td>
							</tr>
							<?php if(isset($arrMultipleMeshterms) && sizeof($arrMultipleMeshterms)>=1){?>
									<?php 
										$i=0;
										foreach($arrMultipleMeshterms as $meshterm){
											$i++;
											if($i == 1)
												continue;?>
												<tr id="ctMeshtermsDelete<?php echo $i?>">	
													<td width="90%">
				    									<input type="hidden" name="meshtermId<?php echo $i?>"  value="<?php echo $meshterm['id'];?>" id="ctMeshtermId<?php echo $i?>"/>
	    										<input type="text" class="form-control" name="meshterms<?php echo $i?>" value="<?php echo $meshterm['term_name'];?>" id="ctMeshterms<?php echo $i?>"/>
													</td>
				    								<td>			
														<a onclick="delete_tr_by_id('ctMeshtermsDelete<?php echo $i?>');return false;" href="#">
														<img title="Delete" alt="Delete" src="<?php echo base_url().ASSETS;?>/images/delete_active.png" width="20" height="20">
														</a>
													</td>
												</tr>	
									<?php }?>
								<?php 	}?>
						</table>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 align_right">Investigators:</label>
					<div class="col-sm-3" >
						<table style="width: 100%;max-width: 100%;" id="addInvestigatorContainer">
							<tr>
								<td width="90%">
								<input type="hidden" name="investigatorId"  value="<?php echo $arrInvestigator['id'];?>" id="ctInvestigatorId"/>
								<input type="hidden" name="no_of_investigators" id="noOfInvestigators" value="<?php echo $arrClinicalTrial['no_of_investigators'];?>"/>
								<input type="text"  class="form-control" name="investigators" value="<?php echo $arrInvestigator['investigators'];?>" id="ctInvestigators"/>
								</td>
								<td><div class="actionIcon addIcon" id="addMoreInvestigators"><a href="#" onclick="return false;">&nbsp;</a></div></td>
							</tr>
							<?php if(isset($arrMultipleInvestigators) && sizeof($arrMultipleInvestigators)>=1){?>
									<?php 
										$i=0;
										foreach($arrMultipleInvestigators as $investigator){
											$i++;
											if($i == 1)
												continue;?>
												<tr id="ctInvestigatorsDelete<?php echo $i?>">	
													<td width="90%">
														<input type="hidden" name="investigatorId<?php echo $i?>"  value="<?php echo $investigator['id'];?>" id="ctInvestigatorId<?php echo $i?>"/>
														<input type="text" class="form-control"  name="investigators<?php echo $i?>" value="<?php echo $investigator['last_name'];?>" id="ctInvestigators<?php echo $i?>"/>
													</td>
				    								<td>			
														<a onclick="delete_tr_by_id('ctInvestigatorsDelete<?php echo $i?>');return false;" href="#">
														<img title="Delete" alt="Delete" src="<?php echo base_url().ASSETS;?>/images/delete_active.png" width="20" height="20">
														</a>
													</td>
												</tr>	
									<?php }?>
								<?php 	}?>
						</table>
			    	</div>
				</div>
				<div class="form-group row" style="text-align: center;">
		   			<input type="button" value="Save" name="save" onclick="saveClinicalTtialManual();" class="btn btn-primary">
		            <input type="button" value="Cancel" onclick="goBack();" class="btn btn-primary">
				</div>
			</form>
	</div>
</div>

<script>
	$(document).ready(function(){
		$('.ctManualMsgBox').hide();
		//Adds the another Intervention input field below the current input field
		$("#addMoreInterventions").click(function(){
			//jAlert('hi');
			var noOfInterventions=0;
			noOfInterventions=$("#noOfInterventions").val();
			noOfInterventions++;
			var newIntervention="<tr id=\"ctInterventionDelete"+noOfInterventions+"\"><td width='90%'><input type='text' class='form-control' name=\"intervention"+noOfInterventions+"\" id=\"ctIntervention"+noOfInterventions+"\" /></td><td><a href='#' onclick=\"delete_tr_by_id('ctInterventionDelete"+noOfInterventions+"');return false;\"><img src=\"<?php echo base_url().ASSETS;?>/images/delete_active.png\" width='20'  height='20' alt='Delete' title='Delete'/></a></td></tr>";
			$("#addInterventionContainer").append(newIntervention);
			$("#noOfInterventions").val(noOfInterventions);
		});
		//Adds the another Author input field below the current input field
		$("#addMoreSponsors").click(function(){
			var noOfSponsors=0;
			noOfSponsors=$("#noOfSponsors").val();
			noOfSponsors++;
			var newSponsor="<tr id=\"ctSponsorDelete"+noOfSponsors+"\"><td width='90%'><input type='text' class='form-control' name=\"sponsor"+noOfSponsors+"\" id=\"ctSponsor"+noOfSponsors+"\" /></td><td><a href='#' onclick=\"delete_tr_by_id('ctSponsorDelete"+noOfSponsors+"');return false;\"><img src=\"<?php echo base_url().ASSETS;?>/images/delete_active.png\" width='20'  height='20' alt='Delete' title='Delete'/></a></td></tr>";
			//var newSponsor="<div id=\"ctSponsorDelete"+noOfSponsors+"\"><input type=\"text\" name=\"sponsor"+noOfSponsors+"\" id=\"ctSponsor"+noOfSponsors+"\" /><a href=\"#\" onclick=\"delete_tr_by_id("+noOfSponsors+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\"  width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
			$("#addSponsorContainer").append(newSponsor);
			$("#noOfSponsors").val(noOfSponsors);
		});
		$("#addMoreKeywords").click(function(){
			var noOfKeywords=0;
			noOfKeywords=$("#noOfKeywords").val();
			noOfKeywords++;
			var newKeyword="<tr id=\"ctKeywordsDelete"+noOfKeywords+"\"><td width='90%'><input type='text' class='form-control' name=\"keywords"+noOfKeywords+"\" id=\"ctKeywords"+noOfKeywords+"\" /></td><td><a href='#' onclick=\"delete_tr_by_id('ctKeywordsDelete"+noOfKeywords+"');return false;\"><img src=\"<?php echo base_url().ASSETS;?>/images/delete_active.png\" width='20'  height='20' alt='Delete' title='Delete'/></a></td></tr>";
			$("#addKeywordContainer").append(newKeyword);
			$("#noOfKeywords").val(noOfKeywords);
		});
		//Adds the another Investigator input field below the current input field
		$("#addMoreMeshterms").click(function(){
			var noOfMeshterms=0;
			noOfMeshterms=$("#noOfMeshterms").val();
			noOfMeshterms++;
			var newMeshterm="<tr id=\"ctMeshtermsDelete"+noOfMeshterms+"\"><td width='90%'><input type='text' class='form-control' name=\"meshterms"+noOfMeshterms+"\" id=\"ctMeshterms"+noOfMeshterms+"\" /></td><td><a href='#' onclick=\"delete_tr_by_id('ctMeshtermsDelete"+noOfMeshterms+"');return false;\"><img src=\"<?php echo base_url().ASSETS;?>/images/delete_active.png\" width='20'  height='20' alt='Delete' title='Delete'/></a></td></tr>";
			$("#addMeshtermContainer").append(newMeshterm);
			$("#noOfMeshterms").val(noOfMeshterms);
		});
		//Adds the another Investigator input field below the current input field
		$("#addMoreInvestigators").click(function(){
			var noOfInvestigators=0;
			noOfInvestigators=$("#noOfInvestigators").val();
			noOfInvestigators++;
			var newIntervention="<tr id=\"ctInvestigatorsDelete"+noOfInvestigators+"\"><td width='90%'><input type='text' class='form-control' name=\"investigators"+noOfInvestigators+"\" id=\"ctInvestigators"+noOfInvestigators+"\" /></td><td><a href='#' onclick=\"delete_tr_by_id('ctInvestigatorsDelete"+noOfInvestigators+"');return false;\"><img src=\"<?php echo base_url().ASSETS;?>/images/delete_active.png\" width='20'  height='20' alt='Delete' title='Delete'/></a></td></tr>";
			$("#addInvestigatorContainer").append(newIntervention);
			$("#noOfInvestigators").val(noOfInvestigators);
		});
		$('#clinical_start_id').datepicker({
			dateFormat: 'mm/dd/yy'
		});
		$('#clinical_end_id').datepicker({
			dateFormat: 'mm/dd/yy'
		});
	});
	function saveClinicalTtialManual(){
		if(!$("#ctManualForm").validate().form()){
			$('html, body').animate({
	            scrollTop: $(".error").first().offset().top-100
	        });
			return false;
		}
		id = $("#ctManualId").val();
		if(id == ''){
			formAction = '<?php echo base_url();?>clinical_trials/clinical_trials/save_clinical_trial_manual';
		}else{
			formAction = '<?php echo base_url();?>clinical_trials/clinical_trials/update_clinical_trial_manual';
		}
		if(!(compareStratEndDate()))
			return false;
		formData	= $("#ctManualForm").serialize();
		$.ajax({
			type:"post",
			dataType:"json",
			data: formData,
			url:formAction,
			beforeSend: function(){
				$("#saveCtManual").removeAttr("onclick", null);
	        },
			success:function(returnMsg){
				$('.ctManualMsgBox').show();
				$('div.ctManualMsgBox').fadeIn("fast");
				$('div.ctManualMsgBox').text(returnMsg.msg);
				$('html, body').animate({
		            scrollTop: $("div.ctManualMsgBox").first().offset().top-100
		        });
				if(returnMsg.saved){
					$('div.ctManualMsgBox').removeClass('alert-danger');
					$('div.ctManualMsgBox').addClass('alert-success');
				}else{
					$('div.ctManualMsgBox').removeClass('alert-success');
					$('div.ctManualMsgBox').addClass('alert-danger');
				}
				$('div.ctManualMsgBox').fadeOut(10000);
			},
			complete:function(){
				$('#saveCtManual').attr('onclick','savePayement()');
			}
		});
	}
	function compareStratEndDate(){		
		var startDate 	=$('#clinical_start_id').val(); //DD/MM/YYYY
		var endDate 	=$('#clinical_end_id').val();

		var split = startDate.split('/');
		// Month is zero-indexed so subtract one from the month inside the constructor
		var date = new Date(split[2], split[1] - 1, split[0]); //Y M D 
		var startDate = date.getTime();

		var split = endDate.split('/');
		// Month is zero-indexed so subtract one from the month inside the constructor
		var date = new Date(split[2], split[1] - 1, split[0]); //Y M D 
		var endDate = date.getTime();

		if(endDate!='' && startDate!=''){
			if(endDate < startDate){
				jAlert("End date should be greater or Equal than Start date");
				$('#clinical_end_id').val('');
				return false;
			}
		}
		return true;
	}
	function delete_tr_by_id(id){
		$('#'+id).remove();
	}
</script>