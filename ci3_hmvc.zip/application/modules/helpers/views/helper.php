<script src="<?php echo base_url().MODULES_ASSETS;?>helpers/js/helper.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>helpers/css/helper.css" rel="stylesheet">
<script type="text/javascript">
	var validationRules	=  {
			modal_file_name: {
				required:true
			},
			controller_file_name: {
				required:true
			}
		};
		var validationMessages = {
				modal_file_name: {
					required: "File name of Modal is required"
				},
				controller_file_name:{
					required: "File name of Controller is required"
				}
		};
		$( document ).ready(function() {
			get_table_fields();
			$("#createModule").validate({
				debug:true,
				rules: validationRules,
				messages: validationMessages
			});
		});
		$(function() {
			$('#module_name').change(function() {
			if($(this).val() == 'add'){
				addNewModule();
				}
			})
		})
function check_uncheck_fileds(){
	var thisObj	= $("#select_all_fields");
	var thisObjStatus	= $(thisObj).is(":checked" );
	$(".select_field_for_update").prop("checked",thisObjStatus);
}
		</script>
<h1 class="page_title">Create Module</h1>
<div class="container">
<form action=""   method="post" name="createModule" id="createModule" class="validateForm">
		<div class="form-group row">
			<label class="col-sm-3"></label>
			<div class="col-sm-9">
				<div id="responseBox"></div>
   		  	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Table:</label>
				<div class="col-sm-3">
					<select name="table_name" class="required form-control" id="table_name" onchange="get_table_fields();">
							<?php foreach ($tables as $table){?>
								<option value="<?php echo $table?>">
									<?php echo $table?>
								</option>
							<?php }?>
						</select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Module:</label>
				<div class="col-sm-3">
					<select name="module_name" class="required form-control" id="module_name">
						<option value="">---Select Module---</option>
						<option value="add">Create a new module</option>
							<?php foreach ($modules as $module){?>
								<option value="<?php echo $module['module_name']?>">
									<?php echo $module['module_name']?>
								</option>
							<?php }?>							
					</select>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Controller File Name:</label>
				<div class="col-sm-3">
					  <input type="text"  class="form-control" name="controller_file_name" />
		    	</div>
		    	<label class="col-sm-3 col-form-label">Modal File Name:</label>
				<div class="col-sm-3">
					  <input type="text"  class="form-control" name="modal_file_name" />
		    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-3 col-form-label">CRUD Operations:</label>
					<label>Add/Edit:</label>
					<input type="checkbox" name="add_edit_operation" value="1" id="add_edit_operation" onclick="ShowHideDiv(this,'show_add_file_name')"/>
					<label>Listing:</label>
					<input type="checkbox" name="list_operation" value="1" id="list_operation" onclick="ShowHideDiv(this,'show_listing_file_name')"/>
					<label>View:</label>
				 	<input type="checkbox" name="view_operation" value="1" id="view_operation" onclick="ShowHideDiv(this,'show_view_file_name')"/>
					<label>Delete:</label>
					<input type="checkbox" name="delete_operation" value="1" id="delete_operation"/>
		</div>
		<div class="form-group row" id="show_add_file_name" style="display: none">
			<label class="col-sm-3 col-form-label">File Name for Add/Edit:</label>
			<div class="col-sm-9">
				  <input type="text"  class="form-control" name="add_file_name" />
	    	</div>
		</div>
		<div class="form-group row" id="show_listing_file_name" style="display: none">
			<label class="col-sm-3 col-form-label">File Name for Listing:</label>
			<div class="col-sm-9">
				  <input type="text"  class="form-control" name="listing_file_name" />
	    	</div>
		</div>
		<div class="form-group row" id="show_view_file_name" style="display: none">
			<label class="col-sm-3 col-form-label">File Name for Viewing:</label>
			<div class="col-sm-9">
				  <input type="text"  class="form-control" name="view_file_name" />
	    	</div>
		</div>
		<div class="row" style="border:1px dashed black;padding:6px;">
			<h4 style="text-align:center">Select fields to include in update-form</h4>
			<br>
			<div id="fieldsListing1">
			  <table class="table table-bordered">
			    <thead>
			      <tr>
			      	<th><input type="checkbox" value="0" name="select_all_fields" id="select_all_fields" onchange="check_uncheck_fileds()"></th>
			        <th>Fields</th>
			        <th>Required?</th>
			        <th>Primary_key?</th>
			        <th>Input</th>
			        <th>Textarea</th>
			        <th>Dropdown</th>
			        <th>File</th>
			        <th>Radio</th>
			        <th>Checkbox</th>
			        <th>Date</th>
			        <th>Date Time</th>
			      </tr>
			    </thead>
			    <tbody id="load_table_fields">
			    </tbody>
			  </table>
			</div>			
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
		   		<div class="col-sm-9">
		   			<input type="button" value="Create Module" name="submit" onclick="saveDetails();" class="btn btn-primary">
             <!--   <a type="button" class="btn btn-primary" href="<?php echo base_url();?>clients/clients/list_users">Cancel</a>
          -->   </div> 
		</div>
	</form>
</div>
	<div id="userContainer" class="microViewLoading">
		<div class="modalcontent"></div>
	</div>