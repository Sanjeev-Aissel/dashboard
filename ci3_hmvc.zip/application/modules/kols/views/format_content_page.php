<table class="table table-hover">
      <tr> 
        <td width="2%">
         	<div class="displayBlock">
         		<input type="checkbox" onclick='selectAll(this);'>
         	</div>
		</td>
		<td width="8%">
			<p>Select All</p>
		</td>
		<td colspan="3">
		 <div class="filtersApplied">
			 Refined By:&nbsp;
			 <?php echo $filtersApplied;?>
			 |&nbsp;<?php echo $savedFilterName;?>&nbsp;
			 <a onclick="reset_filters();return false;">
			 	<span class="glyphicon glyphicon-refresh" title="Reset Filters"></span> Reset Filter
			 </a>
		 </div>
		</td>
		<td class="align_right">
			<div id="display_records_count"></div>
		</td>
      </tr>
    <tbody style="font-weight: 100">
    <?php foreach($kol_details as $kol){?>
      <tr>
        <td>
         	<label><input name="list[]" value="<?php echo $kol['kols_client_visibility_id'];?>" type="checkbox"></label>
		</td>
        <td>
        	<?php if(($kol['profile_image']== '') && ($kol['gender']=='Male')){?>
           		<div class="defaultProfileIcon Male" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>
           	<?php } elseif (($kol['profile_image']== '') && ($kol['gender']=='Female')){?>
           		<div class="defaultProfileIcon Female" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>  
           	<?php }elseif($kol['profile_image']!= ''){?>    
           		<img class="defaultProfileIcon img-responsive" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);" src="<?php echo base_url().'images/kol_images/resized/'.$kol['profile_image'];?>">
           	<?php }else{?>    
           		<div class="defaultProfileIcon" onclick="viewKolMicroProfile(this,<?php echo $kol['kols_client_visibility_id'];?>);"></div>  
           	<?php }?>
        </td>
        <td>
			<div class="displayBlock">
				<a href="<?php echo base_url()."kols/kols/view/". $kol['unique_id'];?>">
					<?php echo $this->common_helper->get_name_format($kol['first_name'],$kol['middle_name'],$kol['last_name']);?>
				</a>
			</div>
        	<div class="displayBlock"><?php echo $kol['specs']?></div>
        </td>
        <td>
        	<div class="displayBlock"><?php echo $kol['name']?></div>
        	<div class="displayBlock"><?php echo $kol['city'],','.$kol['state'].','.$kol['country']?></div>
        </td>
        <td>
            <div class="displayBlock"><?php echo $kol['speciality']?></div>
        	<div class="displayBlock">Created BY:<?php echo $kol['created_by']?></div>
        	<div class="displayBlock">Created on :<?php echo $kol['created_on']?></div>
        </td>
        <td>
			<a type="button" class="btn custom-btn requestProfileIcon" style="float:right;" onclick="addNewKolProfile(<?php echo $kol['kols_client_visibility_id']?>,this);return false;" title="Request">
				Request
			</a	>
	        <?php 
	        $permissions=$this->config->item('role_permissions');
	        if(($permissions[$module_id]['delete'])==1){?>
	        	<a onclick="showKolDeleteModalBox('<?php echo $kol['unique_id'];?>');return false;">
					<span class="glyphicon glyphicon-remove-circle"></span>
				</a>
			<?php }?>
			<?php if(($permissions[$module_id]['edit'])==1){?>
				<a href="<?php echo base_url()."kols/kols/add_kol/". $kol['unique_id'];?>">
					<span class="glyphicon glyphicon-edit"></span>
				</a>
			<?php }?>
		</td>
      </tr>
      <?php }?>
		<tr class="searchPagination" style="background-color:white;">
            <td colspan="<?php echo ($viewType=='list')?'7':'6';?>">
              <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="doSearchFilter();return false;">
                <?php
                $arrPaginationValues = explode(',', PAGINATION_VALUES);
                foreach($arrPaginationValues as $key =>$value){
                    if($value==$this->ajax_pagination->per_page){
                        echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
                    }else{
                        echo '<option value="'.$value.'" >'.$value.'</option>';
                    }
                }
            ?>
            </select> Records Per Page 
            <?php
            $config['base_url'] 		 = base_url()."kols/kols/reload_filters";
            $config['total_rows'] 		 = $kols_count;
            $config['per_page'] 		 =$this->ajax_pagination->per_page;
            $config['postVar'] 			 = 'page';
            $this->ajax_pagination->initialize($config);
            print $this->ajax_pagination->create_links();
            ?>        
            </td>
        </tr>
    </tbody>
  </table>
  <script>
$(document).ready(function (){
	display_kol_records_range();
});
  function display_kol_records_range(){
	 var kols_count		='<?php echo $kols_count;?>';
	 var cur_page		='<?php echo $this->ajax_pagination->cur_page;?>';
	 var records_per_page='<?php echo $this->ajax_pagination->per_page?>';
	 var startRecordIndex=((cur_page-1)*records_per_page)+1;
	 var endRecordIndex	=parseInt(startRecordIndex)+parseInt(records_per_page)-1;
	 if(endRecordIndex>kols_count)
	 	endRecordIndex=kols_count;
	 $("#display_records_count").html('Showing '+startRecordIndex+' to '+endRecordIndex+' of '+kols_count);
 }
  </script>