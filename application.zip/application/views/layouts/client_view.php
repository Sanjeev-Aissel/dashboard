<?php
$mobile = mobile_device_detect();
$kolNameAutoCompleteOptionsSearchTop = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {submitSearch('top');}";
$kolNameAutoCompleteOptionsSearchDock = "width: 317, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {submitSearch('dock');}";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<?php if($this->session->userdata('logged_in')) : ?>
        <meta http-equiv="refresh" content="<?php echo IDLE_SESSION_TIMEOUT;?>;url=<?php echo base_url();?>login/killIdleSession">
    <?php endif;?>
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<!-- meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'unsafe-eval' <?php echo base_url()?> http://ecn.dev.virtualearth.net" /-->
	<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<?php echo $this->load->view('elements/favicon');?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />

	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/client_layout.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/jquery.alerts.css" />

	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	<!--[if IE 8]>
		<link type="text/css" href="<?php echo base_url()?>css/ie8_only.css" rel="stylesheet" />
	<![endif]-->
	<link href="<?php echo base_url();?>css/tooltip/bootstrap.css" rel="stylesheet">
	<!-- link rel="stylesheet" type="text/css" href="<?php echo base_url();?>support/style.css"-->
	<script>
	var live_support_url	= '<?php echo LIVE_SUPPORT_URL; ?>';
	</script>
	<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<script type="text/javascript">
			if( !navigator.onLine){
				alert("offline");
				window.location = "<?php echo base_url();?>";
			}
	</script>
	<script type="text/javascript">
		var isiPad			= false;
		var base_url		= "<?php echo base_url()?>";
		var CONST_LANG_KOL	= "<?php echo lang('KOL');?>";
		var js_files_loaded = false;
		var clientId		= '<?php echo $this->session->userdata('client_id')?>';
	    var userId			= '<?php echo $this->session->userdata('user_id')?>';
	    var userRoleId		= '<?php echo $this->session->userdata('user_role_id')?>';
		var ROLE_MANAGER 	= '<?php echo ROLE_MANAGER?>';
		var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
		var ROLE_USER		= '<?php echo ROLE_USER?>';
		var INTERNAL_CLIENT_ID		= '<?php echo INTERNAL_CLIENT_ID?>';
		//var bottomDockVisibility	= $.cookie("bottom_dock");
		var bottomDockVisibility	= "hide";
		var paginationValues		= new Array();
		var modalBoxTopPosition		= <?php echo POSITION_TOP;?>;
		var chartColorCodes			= <?php echo CHART_COLOR_CODES;?>;
		var HIDE_CLINICAL_TRIALS	= <?php echo HIDE_CLINICAL_TRIALS;?>;
		var isTTmouseOver = false;
		var tooltipDelay = 1000;
		var tttimeOut;
		var jqgridIds	= new Array();
		var jqgridMinWidth	= 858;
		var jqgridMaxWidth	= 1148;
		var jqgridWidthForiPad	= 790;
		<?php  $mobile = mobile_device_detect();
		 if(isset($mobile[1])){	?>
		 	tooltipDelay = 0;	
		 <?php }?>
		 
				 
	</script>
	<style id="antiClickjack">body{display:none !important;}</style>
	<script type="text/javascript">
	   if (self === top) {
	       var antiClickjack = document.getElementById("antiClickjack");
	       antiClickjack.parentNode.removeChild(antiClickjack);
	   } else {
	       top.location = self.location;
	   }
	</script>
	<style>
        .ui-datepicker{
        z-index:10000;
        }
		.dockItTop{
			top:0px;
			display: block;
		}
		.dockItBottom{
			display: none;
		}
	    #advSearchAddContainer + .arrowAdjust{
	    	right: 69px;
	    	right: 230px;
	    	top:-1px;
	    }
	    td.flexiTable{
	    	padding:0px;
	    	vertical-align: top;
	    }
	    .dataTypeIndicator{
	        width: 17px;
            height: 17px;
            font-size: 11px;
            font-weight: bold;
            float: left;
            border: 1px solid #949393;
            margin-top: 2px;
            border-radius: 10px;
            background-color: lightgray;
	    }
	    .dataTypeIndicator a{
	       color: #363636 !important; 
	    }
  </style>
	<?php 
		if(IS_IPAD_REQUEST == 1){
			?>
			<script type="text/javascript">
				isiPad	= true;
			</script>
			<meta content='initial-scale=1.05;' name='viewport' />
			<link type="text/css" rel="stylesheet" media="only screen and (min-device-width: 481px) and (max-device-width: 1024px)" href="<?php echo base_url()?>css/ipad_only.css">
			<?php 
		}else{
			if (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== false) {
				// Chrome user agent string contains both 'Chrome' and 'Safari'
				if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== false) {
					// include CHROME CSS';
				} else {
					?>
					<link type="text/css" href="<?php echo base_url()?>css/safari5_1_only.css" rel="stylesheet" />
		<?php 	}
			}
		}
	?>
	<script src="<?php echo base_url();?>js/jquery.autocomplete.js"></script>
	<script type="text/javascript">
		
		<?php 
			$paginationValues	= explode(',',PAGINATION_VALUES);
			foreach($paginationValues as $key=>$value){
		?>
			paginationValues.push('<?php echo $value;?>');
		<?php
			}
		?>
		function submitSearch(source){
			$('#searchByAutoComplete').val('1');
			if(source=="top"){
				$('#header #searchForm').submit();
			}else if(source=="dock"){
				$('#bottomBar #searchForm').submit();
			}
		}

		var chartColors=<?php echo CHART_COLOR_CODES ?>;
		$(document).ready(function(){
			
			$(".autocomplete").live("mouseover",function(){
				var kolname = $(this).children('div.selected').find('label.kolName').text();
				var orgName = $(this).children('div.selected').find('label.orgName').text();
				 kolname+="\n"+orgName;
				$(this).children('div.selected').attr('title',kolname);
			
				 //kolAutoCompleteId = $(this).attr('id');
				//jAlert(id);
			});
			var kolNameAutoCompleteOptionsSearchTop = {
					<?php 
					if(KOL_CONSENT){?>
					serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/0/1',
					<?php }else{ ?>
					serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
					<?php }?>
					<?php echo $kolNameAutoCompleteOptionsSearchTop;?>,
							onSelect : function(event, ui) {
								var kolId = $(event).children('.id1').html();
								var selText = $(event).children('.kolName').attr('name');
								selText=selText.replace(/\&amp;/g,'&');
							
							
								$('#header #searchKeyword').val(selText);
								$('#kolIdTop').val(kolId);
								if(selText.length>20){
									if(selText.substring(0,21)=="No results found for "){
										return false;
									}else{
										//submitSearch('bottom');
										window.location.replace("<?php echo base_url();?>kols/view/"+kolId);
									}
								}else{
								//submitSearch('top');
								window.location.replace("<?php echo base_url();?>kols/view/"+kolId);
						}
						}
				};
			var kolNameAutoCompleteOptionsSearchDock = {
				serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_autocomplete',
				<?php echo $kolNameAutoCompleteOptionsSearchDock;?>,
						
						onSelect : function(event, ui) {
							var kolId = $(event).children('.id1').html();
							var selText = $(event).children('.kolName').attr('name');
							selText=selText.replace(/\&amp;/g,'&');
						
						
							$('#bottomBar #searchKeyword').val(selText);
							$('#kolIdTop').val(kolId);
							if(selText.length>20){
								if(selText.substring(0,21)=="No results found for "){
									return false;
								}else{
									//submitSearch('bottom');
									window.location.replace("<?php echo base_url();?>kols/view/"+kolId);
								}
							}else{
							//submitSearch('bottom');
							window.location.replace("<?php echo base_url();?>kols/view/"+kolId);
					}
					}
			};

			// Autocomplet Options for the 'org name' field
			var orgNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
					<?php echo $kolNameAutoCompleteOptionsSearchTop;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.organizations').html();
						var selId = $(event).children('.organizations').attr('name');
						selText=selText.replace(/\&amp;/g,'&');
						$('#header #searchKeyword2').val(selText);
						if(event.length>20){
							//$('#orgIdForAutocomplete').val(kolId);
							if(event.substring(0,21)=="No results found for "){
								return false;
							}else{
								window.location.replace("<?php echo base_url();?>organizations/view/"+selId);
							}
						}else{
							window.location.replace("<?php echo base_url();?>organizations/view/"+selId);
						}
					}
				};
			
			var autoSearchDataTop	= $('#header #searchKeyword').autocomplete(kolNameAutoCompleteOptionsSearchTop);
			var autoSearchDataDock	= $('#bottomBar #searchKeyword').autocomplete(kolNameAutoCompleteOptionsSearchDock);
			var autoSearchOrgTop	= $('#header #searchKeyword2').autocomplete(orgNameAutoCompleteOptions);
			var autoSearchOrgDock	= $('#bottomBar #searchKeyword2').autocomplete(orgNameAutoCompleteOptions);
			var left	= -25;
			if(isiPad){
				left	= -67;
			}
			$('#'+autoSearchDataTop.mainContainerId+' .autocomplete-w1').css('left',left+'px');
			$('#'+autoSearchDataTop.mainContainerId+' .autocomplete-w1').css('top','6px');
			$('#'+autoSearchOrgTop.mainContainerId+' .autocomplete-w1').css('left',left+'px');
			$('#'+autoSearchOrgTop.mainContainerId+' .autocomplete-w1').css('top','6px');
		//	$('#'+autoSearchDataDock.mainContainerId+' .autocomplete-w1 > div').css('height','300px');
			$('#'+autoSearchDataDock.mainContainerId+' .autocomplete-w1').css('top','10px').css('left',left+'px');
			$('#'+autoSearchOrgDock.mainContainerId+' .autocomplete-w1').css('top','10px').css('left',left+'px');
			
		});
		$(document).ready(function(){
			jQuery.fn.center = function () {
			    this.css("position","absolute");
			    this.css("top", ( $(window).height() - this.height() ) / 2+$(window).scrollTop() + "px");
			    this.css("left", ( $(window).width() - this.width() ) / 2+$(window).scrollLeft() + "px");
			    return this;
			}
		});

		var profileRequestConfirmMessage = 'Do you want to submit this request for a Full Profile to be built for this Contact?';
		var orgRequestConfirmMessage = 'Do you want to submit this request for a Profile to be built for this Organization?';

		function data_type_indicator(dataTypeIndicator){
			$UserAdded=0;		
	    	if(dataTypeIndicator == '' || dataTypeIndicator == 'Legacy'){
	    		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Legacy Data' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>L</a></div>";
	    	}else if(dataTypeIndicator == 'User Added'){
	    		//return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>U</a></div>";
	    		return '';
	    	}else if(dataTypeIndicator == 'Aissel Analyst'){
	    		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: Aissel Analyst' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>A</a></div>";
	    	}	
		}
</script>
	<?php flush();?>
	<?php 
		$this->config->set_item('js_files_to_load',''); // to reset the array for every new page
		// load initial js files which are essential and common for all pages
		$queued_js_scripts = array(
									'jquery/jquery-ui-1.8.16.for_all_pages',
								//	'search/search_box','hint/jquery.joyride','hint/modernizr.mq'
									'search/search_box' //,'hint/jquery.joyride','hint/modernizr.mq'
								);
		// initialise the array of js files into queue
		$this->config->set_item('js_files_to_load',$queued_js_scripts);
	?>
</head>
<body>
	<div id="maskbody" style="display: none;"></div>
	<!-- Start of the WRAPPER div -->
	<div id="wrapper" class="container">
		<!-- Start of HEADER div -->
		<?php 
			if(IS_IPAD_REQUEST == 1){
				echo $this->load->view('ipad/kolm_header_client_view');
			}else{
				echo $this->load->view('elements/kolm_header_client_view');
			}
		?>
		<!-- End of HEADER div -->
	<?php flush();?>	
	<?php 
		// To avoid the notice, if there is no variable set, set it as blank
		if(!isset($data)) $data = "";
		
	?>	
		<!--  Star of Content Wrapper Div -->
		<div id="contentWrapper" class="span-23 tooltip-demo tooltop-top">
			<div id="contents" class="verticalSeparator">
				<table style="display: block;">
					<tr>
						<td id="leftSideBar" class="flexiTable"><?php echo $this->load->view('elements/kolm_sidebar_client_view', $data);?></td>
						<td id="pageContentWrapper" class="flexiTable" style="width:100%"><?php echo $this->load->view($contentPage, $data);?></td>
						<td id="rightSideBar" class="flexiTable"><?php echo $this->load->view('elements/kolm_right_sidebar_client_view', $data);?></td>
					</tr>
				</table>
			</div>
			<!-- End of Contents Div -->
		</div>
		
		<!--  End of Content Wrapper Div -->
		
		<div id="footer">
			<div id="viewSwitcher">
				<?php $mobile = mobile_device_detect();
					if(IS_IPAD_REQUEST == 1){
						echo '<span class="switchView">Logged in as '.$this->session->userdata('user_full_name').'</span>';
					}else if(isset($mobile[1])){
				?>
				<span class="switchView">View as: <a href="<?php echo base_url().MOBILE_URL_SEGMENT."/login"?>">Mobile</a></span>
			<?php }?>
				 <div style="float: right;">
					 <a href="<?php echo base_url()?>client_users/change_language/english" style="text-decoration: none;" class="privacy" target="new">Privacy Policy</a> | <a href="<?php echo base_url()?>client_users/show_terms_page/terms" style="text-decoration: none;" class="privacy" target="new">Terms of Service</a> | <?php echo APP_PRODUCT_INFO_FOOTER;?> Copyright &copy; <?php echo COPYRIGHT;?> <a style="text-decoration: none;" href="http://www.aissel.com" target="new">Aissel</a> Technologies | Powered by <a style="text-decoration: none;" href="http://www.aissel.com" target="new">Aissel</a>
				</div> 
			</div>
		</div>
		<br /><br />
	</div>
	<!-- End of the WRAPPER div -->
	<!--Support script starts from below line. includes script-->

        <script>
        var client_name = "<?php //echo $this->session->userdata('client_name'); ?>"; 
        var user_name = "<?php echo $this->session->userdata('user_name'); ?>";
        var user_email = "<?php echo $this->session->userdata('email'); ?>";
        var device_info = "<?php echo $_SERVER['HTTP_USER_AGENT']; ?>";
        var user_full_name = "<?php echo $this->session->userdata('user_full_name'); ?>";
        
        </script>
        <!-- Support script ends on above below line -->
	<?php
		// 	Load all JS files from the queue		 
		foreach($this->config->item('js_files_to_load') as $key => $js_files){
			echo '<script type="text/javascript" src="'.base_url().'js/'.$js_files.'.js"></script>';
		}
	?>
	<script type="text/javascript">
		js_files_loaded = true;
		var toggleJqgridColumnsCaption	= 'Choose Columns';
		//  start of positioning of refined by filter section 
	//	var position = $("#contentWrapper").position();
		//jAlert( "left: " + position.left + ", top: " + position.top );
	//	$('#refinedByContainer').css('right',position.left+'px');
		//$('.refinedBySideBar').css('right',(position.left)+'px');
		if(isiPad===true){
			var position = $("#contentWrapper").position();
			//alert($("#contentWrapper").width());
			var distance	= "662px";
			if($("#contentWrapper").width()>945){
				distance	= "651px";
			}
			$('#rightSideBarWrapper').css('left',distance);
			//$('#rightSideBarWrapper').css('background-color','#eee');
		}
		//  end of positioning of refined by filter section

		$('#rightSideBarSlider').click(function(){
			$('#searchLeftBar').animate({width: 'toggle'}, 1000, function() 
				{
					$('#rightSideBarSlider').toggleClass('expandRightSideBar');
					$('#rightSideBarSlider').toggleClass('collapseRightSideBar');
					var currentTitle = $("#rightSideBarSlider .tooltipLink").attr('data-original-title');
					if(currentTitle != 'Show Key People' && currentTitle!= 'Hide Key People'){
						if($("#rightSideBarSlider").hasClass('collapseRightSideBar'))
							$("#rightSideBarSlider .tooltipLink").attr('data-original-title','Hide Refine By');
						else
							$("#rightSideBarSlider .tooltipLink").attr('data-original-title','Show Refine By');
					}else{
						if($("#rightSideBarSlider").hasClass('collapseRightSideBar'))
							$("#rightSideBarSlider .tooltipLink").attr('data-original-title','Hide Key People');
						else
							$("#rightSideBarSlider .tooltipLink").attr('data-original-title','Show Key People');
					}
				});
			
		});
		function initilizeGridSearchPlaceholder(){
			$(".ui-search-toolbar input[type='text']").each(function(){
				$(this).attr("placeholder","");
				$(this).attr("placeholder","Search");
		    });
	    	<?php 
	    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
				if(preg_match('/MSIE/i',$u_agent) && !preg_match('/MSIE 10/i',$u_agent)){
					
	    	?>
	    	$('.ui-search-toolbar th input[placeholder]').each(function(){
	    		$(this).parent().find('.jq-placeholder').remove();
	    		$(this).after("<span class='jq-placeholder'>"+$(this).attr('placeholder')+"</span>"); 
	            var input = $(this);       
	            $(input).focus(function(){
	                $(this).next().hide();
	            });
	            $(input).blur(function(){
	                 if (input.val() == '') {
	                	 $(this).next().show();
	                 }
	            });
	        });
	        $(".jq-placeholder").live("click",function(){
	        	$(this).hide();
	        	$(this).prev().focus();
		    });
	        <?php }?>
		}
		function initializeHelpToolTip(){
			$('.map-info.tooltop-top').tooltip({
		      selector: "a[rel=tooltip]",
		      placement:'top',
		      delay:tooltipDelay
		    });
		    $('.map-info.tooltop-bottom').tooltip({
		      selector: "a[rel=tooltip]",
		      placement:'bottom',
		      delay:tooltipDelay
		    });
		    $('.map-info.tooltop-right').tooltip({
		      selector: "a[rel=tooltip]",
		      placement:'right',
		      delay:tooltipDelay
		    });
		    $('.map-info.tooltop-left').tooltip({
		      selector: "a[rel=tooltip]",
		      placement:'left',
		      delay:tooltipDelay
		    });
		}
		var listView = '';
		$(document).ready(function(){
			listView = "<?php echo $listView;?>";
			if(listView>1){
				//$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			}
			//$('#rightSideBarSlider').trigger('click');
		// tooltip demo
		<?php $mobile = mobile_device_detect(); 
			if(!isset($mobile[1])){	?>			
				initializeCustomToolTips();
		<?php }else{?>
				$('#header .nav-box ul li a').css('padding','0 5px');
		<?php }?>
		    //initializeCustomToolTips();
		    initilizeGridSearchPlaceholder();
		    initializeHelpToolTip();

		    $(".tttext").live("mouseover",function(event){
		    	clearTimeout(tttimeOut);
		    	isTTmouseOver = true;
			});
		    $(".tttext").live("mouseout",function(event){
		    	isTTmouseOver = false;
			});
			$("body").click(function(event){
				if(isiPad){
				var curClass = $(event.target).attr('class');
				if(curClass != 'help-link' && curClass != 'tttext'  && curClass != 'tooltip-inner' && curClass!='tooltipLink')
					$(".tooltip.fade.in").remove();
				}
			}); 
		$(document).on('click','.c3 .legend h5',function(){
			if($(this).hasClass( "legdisable" )){
				$(this).removeClass('legdisable');
			}else{
				$(this).addClass('legdisable');
			}					
		});
		$(document).on('click','.c3-legend-item',function(){
			var id = $(this).parent().parent().parent().attr('id');
			removeFloatingTicks('#'+id);			
		});		
		var requestKolsProfiles = {
				title: "Request Profiles",
				modal: true,
				autoOpen: false,
				width: 500,
				height:200,
				draggable:false,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		$("#requestKolsProfiles").dialog(requestKolsProfiles);
		
		});
		function addNewKolProfileUAL(KolId,thisEle){
			$("#requestKolsProfiles .requestKolsProfiles").html("<div class='microViewLoading'>Loading...</div>");
			$("#requestKolsProfiles").dialog("open");
			$("#requestKolsContainer").load(base_url+'requested_kols/add_client_pre_kol/'+KolId+'/1');
		}
		$(window).scroll(function(){
			$('div.tooltip').hide();
		    if ($(this).scrollTop() > 100 && !$('#floatingSlider').hasClass('dockItTop')) {
		    	$('#floatingSlider').addClass('dockItTop').slideToggle('slow');
		    } else if($(this).scrollTop() < 100 && $('#floatingSlider').hasClass('dockItTop')) {
		    	$('#floatingSlider').removeClass('dockItTop').slideToggle('slow');
		    }
		});
		function  enableRefinedBySectionToggleButton(){
			$('.expandRightSideBar').show();
		}
		function initializeCustomToolTips(){
			<?php $mobile = mobile_device_detect(); 
			if(!isset($mobile[1])){	?>			
				$('.tooltip-demo.tooltop-top').tooltip({
			      selector: "a[rel=tooltip]",
			      placement:'top'
			    });
			    $('.tooltip-demo.tooltop-bottom').tooltip({
			      selector: "a[rel=tooltip]",
			      placement:'bottom'
			    });
			    $('.tooltip-demo.tooltop-right').tooltip({
			      selector: "a[rel=tooltip]",
			      placement:'right'
			    });
			    $('.tooltip-demo.tooltop-left').tooltip({
			      selector: "a[rel=tooltip]",
			      placement:'left'
			    });
			<?php } ?>
		}
		
		function accordionMenu(){
			$('.hintsMicroView .accordion h3').click(function (){
				$('.hintsMicroView .accordion h3').next().hide('slow');
				$(this).next().show('slow');
			});
		}
		function toggleGridColumns(){
			var id	= $(this).attr('id');
			var grid_id	= 'gbox_'+id;
			$(this).jqGrid('columnChooser', {modal: true});
			var ele=document.getElementById(grid_id);
			var gridWidth=ele.clientWidth;
			//alert(grid_id+'--'+gridWidth);
			$('#'+id).setGridWidth(gridWidth,true);
			id	= 'colchooser_'+$(this).attr('id');
			var value	= '';
			$('#'+id).find('select option').filter(function() {
				value	= $(this).html();
		        return !value || $.trim(value).length == 0;
		    }).remove();
			$('#'+id).find('select option').first().prop('selected', true);
		}
		function limitText(limitField, limitCount, limitNum) {
			if (limitField.value.length > limitNum) {
				limitField.value = limitField.value.substring(0, limitNum);
			} else {
				$('#'+limitCount).html(limitNum - limitField.value.length);
			}
		}
		function get_tickvalues(value){
			var tickValues = new Array;
			if(value>4){
				var n = Math.round(value/4);
				tickValues.push(0);
				for(i=1;i<=4;i++){
					tickValues.push(n * i);
				}
			}else{
				tickValues = [0,1,2,3,4]; 
			}
			return tickValues;
		}
		function removeFloatingTicks(id){
    		setTimeout(function(){ 
    			$(id+' .c3-axis-y .tick text tspan').each(function(){
    				var val = $(this).text();
    				if(val.indexOf(".")!=-1){
    					$(this).parent().parent().hide();
    				}
    			});
    		 }, 300);
		}

	</script>

	<script src="<?php echo base_url();?>js/tooltip/bootstrap-tooltip.js"></script>
			
	<!-- jQuery Block UI Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.blockUI.js"></script>
	
		<!-- javascript functions to calulate the absoluteposition of the given element -->
	<script type="text/javascript" src="<?php echo base_url()?>js/absolute_position_functions.js"></script>
	
	<!-- Jquery Alert Box Plugin -->	
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.alerts.js"></script>
	
<!-- Container for the 'Kol's Request' modal box -->
	<div id="requestKolsDialog">	
			<div id="requestKolsProfiles" class="requestKolsProfiles">
			<div class="requestKolsContainer" id="requestKolsContainer"></div>
		</div>
	</div>
	<!-- <div id="alertPopForCooke" class="microProfileDialogBox">
		<div class="profileContent" id="alertPopForCookeContent"></div>
	</div>
	<script type="text/javascript">
	<?php //if(COOKE_CONSENT){?>
    	var appAccess = '<?php //echo $this->session->userdata('cooke_consent')?>';
    	$(document).ready(function(){
    		if(appAccess == '0'){
    			alertPopCooke();
    		}
    		return false;
    	});
    	var alertPopForCooke = {
            title: "Cooke Session Data",
            modal: true,
            autoOpen: false,
            width: 900,
            height: 'auto',
            draggable: false,
            dialogClass: "microView",
            position: ['center', 80],
            open: function () {
                //display correct dialog content
            }
        };
    	function alertPopCooke() {
    	    $("#alertPopForCooke .profileContent").html("<div class='microViewLoading'>Loading...</div>");
    	    $("#alertPopForCooke").dialog("open");
    	    $("#alertPopForCookeContent").load(base_url + 'client_users/alertPopCookeSession');
    	    return false;
    	}
    	
        $("#alertPopForCooke").dialog(alertPopForCooke);
    <?php //}?>
    </script> -->
	<!--End of  Container for the 'Kol's Request' modal box -->
</body>
</html>