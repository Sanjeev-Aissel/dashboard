<?php

$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";

?>
<script type="text/javascript">

		var a,options;

		// Autocomplet Options for the 'country' field
		var countryNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		$(document).ready(function(){
			// Trigger the Autocompleter for 'Role' field of  Event'
		
			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#country').autocomplete(countryNameAutoCompleteOptions);
	});
</script>

<div id="searchFiltersElements">
<form action="<?php echo base_url()?>organizations/filter_search_organizations" name="searchForm" method="post" id="searchFilterForm">
		<input type="hidden" name="keyword" id="keyword" value="<?php echo $keyword; ?>"/>
		<input type="hidden" name="search_type" id="searchType" value="<?php echo $searchType; ?>"/>
		<input type="hidden" name="filterCategory" id="filterCategory" value="organization"/>		
		
		<p>
			<label>Country</label>
			<input type="text" name="country" id="country" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['country']; else echo '';?>"/>
		</p>
	
		<p>
			<label>Type</label>
			<input type="text" name="type" id="type" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['type']; else echo '';?>"/>
		</p>
		<input type="button" name="do_earch" id="doFilter" onClick="doSearchFilter(0)" value="Filter"/>
	</form>
</div>