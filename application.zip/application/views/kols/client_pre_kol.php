<?php 
/**
 * Contains Form file to add Neqw Kol request
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.requsted_kols
 * @created 13-6-2012
 */

/** Start of the FreshDesk SSO Section */
//With Trailing slashes
$userName	= $this->session->userdata('user_full_name');
$userMailId = $this->session->userdata('email');

 ?>
 <!-- 2nd Plugin for Validation -->
<script type="text/javascript" src="<?php echo base_url()?>js/jquery/jquery.validate1.9.min.js"></script>
<style type="text/css">
.requestedKols label {
	font-size: 11px;
}
/*
.requestedKols input[type="text"],select {
	height: 14px;
	width: 182px;
	margin: 4px;
}
*/
.requestedKols select {
	height: 20px;
	width: 182px;
	margin: 4px;
}

input.error {
	background-position: 10px center;
	background-repeat: no-repeat;
	padding: 0;
}

label.error {
	padding: 2px 0px !important;
	color: red !important;
	background: none !important;
	border-color:none !important;
	border: none !important;
}

select.error {
	border: 1px solid red !important;
}

screen.css  error,.notice,.success {
	border: red;
	margin-bottom: 1em;
	padding: 0.8em;
}
#requestKol{
	letter-spacing: 1px;
}
</style>
<script type="text/javascript">
var validationRules	=  {
		
		specialty: {
			required:true
		},
		first_name: {
			required:true
		},
		
		last_name: {
			required:true
		},
		country_id: {
			required:true
		},
		primary_phone: {
			 maxlength: 16,
			 minlength:6,
			  phoneUS: true
		}
		
	};

var validationMessages = {
		specialty: {
			required: "Required"
						
		},
		country_id: {
			required: "Required"
						
		},
		first_name: {
			required: "Required"
						
		},
		last_name: {
			required: "Required"
						
		}
		
};
	$('#requestKol').click(function(){

		if(!$("#requestKolForm").validate().form()){
			
			return false;
		}
		$('.msgBox').removeClass('success');
		$('.msgBox').addClass('notice');
		$('.msgBox').show();
			
		$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/save_customer_profile_request',
			type:'post',
			dataType:'json',
			data:$('#requestKolForm').serialize(),
			success:function(returnData){
						if(returnData.saved){
						$('.msgBox').html("Successfully updated");
						$('.msgBox').fadeOut(1500);
						<?php $refUrl = $_SERVER['HTTP_REFERER']; $arrSegs = explode("/",$refUrl); 
							if($arrSegs[sizeof($arrSegs)-2] == 'view') {?>
							$("#kolRequestButton").remove();
						<?php }else { ?>
							if(typeof(callback) == "function")
								notRequesetdKOls();
						<?php }?>
						setTimeout(closeDialog,1500);
						setTimeout(closeRequest,1500);
						if(returnData.user_role_id == ROLE_MANAGER || returnData.user_role_id == ROLE_ADMIN)
							jAlert("The <?php echo lang("KOL");?>  Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
						else
							jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
						
						}else{
							$('.msgBox').html("Not updated! Try Again ");
							$('.msgBox').fadeOut(1500);
						}
			}
		
			});
		

	});

	function closeDialog(){
		$("#newKolProfile").dialog("close");
		$("#modalBox").modal('hide');
	}	
	function closeRequest(){
		$(".ui-dialog-titlebar-close").trigger("click");
		$("#modalBox").modal('hide');
	}
	/**
	* Returns the list of States of the Selected Country ID
	*/
	function getStatesByCountryId(){
		// Show the Loading Image
		$("#loadingStates").show();
		
		var countryId=$('#countryId').val();
		var params = "country_id="+countryId;	
		$("#stateId").html("<option value=''>-- Select State --</option>");
		$("#cityId").html("<option value=''>-- Select City --</option>");
		var states = document.getElementById('stateId');
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {					
					var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);				
					});
				
                $("#stateId option[value='']").remove();
                $("#stateId").prepend("<option value=''>-- Select State --</option>");
                $("#stateId").val("");
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});		
	}

	/**
	* Returns the list of Cities of the Selected State
	*/
	function getCitiesByStateId(){
		// Show the Loading Image
		$("#loadingCities").show();
		
		var stateId=$('#stateId').val();
		$("#cityId").html("<option value=''>-- Select City</option>");	
		var cities = document.getElementById('cityId');
		var params = "state_id="+stateId;	
		
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {	
							
				var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);				
				});		
				$("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
			},
			complete: function(){
				$("#loadingCities").hide();
			}		
		});		
		
	}

	$(function(){
		$("#requestKolForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
		    phone_number = phone_number.replace(/\s+/g, ""); 
			return this.optional(element) || phone_number.length > 9 &&
				phone_number.match(/\(?[0-9]{2,}\)?(-?)\(?[0-9]{3,}?\)?(-?)[0-9]{4,}/);
		}, "Please specify a valid phone number");
	});

	function showBasicDetails(){
		var val = $('input:radio[name=type1]:checked').val();
		window.open("<?php echo base_url()?>requested_kols/show_basic_page/"+val);
		
	}
</script>


<div class="msgBox"></div>
				<div style="margin-left:75px">
					
					
				</div>
<?php if($pageFlag == 1){?>
	<form action="save_client_requested_kol" method="post" id="requestKolForm" name="persnoalForm">
	<table class="requestedKols" style="vertical-align: middle;">
		<input type="hidden" name="kol_id" value='<?php echo $kolId?>' id="kolId1"></input>
		<tbody>
				<tr>
				<td colspan="2">
	
					<div class="formButtons" style="margin-bottom: 20px;">	
						<h6>What kind of profile would you like to be built for this Contact?</h6>
					</div>
				    
					
				</td>
			</tr>
		</tr>
			<tr>
				<td>
					<div style="margin-left:75px">
							<input type="radio" name="profile_type" value="Basic" checked="checked" >Basic</input>					
					</div>
				</td>
				<td>
					<div style="margin-left:75px">
							<input type="radio" name="profile_type" value="Full Profile">Full Profile</input>					
					</div>
				</td>
			</tr>
		<tr>
			<tr>
				<td colspan="2">
	
				<div class="formButtons"  style="margin-top:20px;">	
					<input type="hidden" value="simple" name="page_type"></input>
					<input type="button" value="Submit" name="submit" id="requestKol"></input>
					<input type="button" value="Cancel" name="cancel" id="requestCancel" onclick="closeRequest();"></input>
				</div>
				    
					
				</td>
			</tr>
	  </tbody>
  </tabel>
	    
</form>
	<?php }else{?>	
<form action="save_client_requested_kol" method="post" id="requestKolForm" name="persnoalForm">
	<table class="requestedKols">
		<div style="margin-left:75px">
			<input type="radio" name="profile_type" value="Full Profile" <?php if($arrKols['profile_type']=='Full Profile'){?>checked="checked" <?php }?>>Full Profile</input>
			<input type="radio" name="profile_type" value="Basic Plus" <?php if($arrKols['profile_type']=='Basic Plus'){?>checked="checked" <?php }?>>Basic Plus </input>
			<input type="radio" name="profile_type" value="Basic" <?php if($arrKols['profile_type']=='Basic'){?>checked="checked" <?php }?>>Basic</input>					
			<a href="<?php echo getSSOUrl($userName, $userMailId);?>&redirect_to=/solution/articles/36123-what-is-the-difference-between-a-basic-basic-plus-and-a-full-profile-" target="_NEW">Compare</a>
		</div>
		<input type="hidden" name="kol_id" value='<?php echo $kolId?>' id="kolId1"></input>
		<tbody>
				<tr>
			<td class="alignRight">
			
				
			
			</td>
			<td class="alignRight1">
				
			</td>
			<td class="alignRight1">
			
			</td>
		</tr>
		<tr>
		
			<td class="alignRight">
				<label for="salutation">Salutation :</label>
			</td>
			<td>
				<select name="salutation" >
					<option value="0">--- Select ---</option>
						<?php 
						foreach($arrSalutations as $key => $value){
							if((isset($arrKols['salutation'])) && $key == $arrKols['salutation'])
								echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
							else
							echo '<option value="'.$key.'">'.$value.'</option>';
						}
						?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="alignRight"><label for="">First Name <span class="required">*</span>:</label></td>
			<td>
				<input type="text" name="first_name" id="first_name" value="<?php if(isset($arrKols['first_name'])) echo $arrKols['first_name']?>" maxlength="50" class="required"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="middle_name">Middle Name :</label>
			</td>
			<td>
				<input type="text" name="middle_name" id="middle_name" value="<?php if(isset($arrKols['middle_name'])) echo $arrKols['middle_name']?>"  maxlength="50"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="last_name">Last Name<span class="required">*</span> :</label>
			</td>
			<td>
				<input type="text" name="last_name" id="last_name" value="<?php if(isset($arrKols['last_name'])) echo $arrKols['last_name']?>"  maxlength="50" class="required"></input>
			</td>
		</tr>
		
		
		<tr>
			<td class="alignRight">
				<label for="specialty">Specialty<span class="required">*</span> :</label>
			</td>
			<td>
				<select name="specialty" id="specialty" class="required">
					<option value="">--- Select ---</option>
						<?php 
						foreach($arrSpecialties as $key => $value){
											if((isset($arrKols['specialty'])) && $key == $arrKols['specialty'])
												echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
											else
												echo '<option value="'.$key.'">'.$value.'</option>';
											}
											?>
					
				</select>
			</td>
		</tr>
		
		<tr>
			<td class="alignRight">
				<label for="orgName">Organization Name :</label>
			
			</td>
			<td>
				<input type="text" name="org_id" id="orgName" value="<?php if(isset($arrKols['org_name'])) echo $arrKols['org_name'];?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="title">Title :</label>
			
			</td>
			<td>
				<input type="text" name="title" id="title" value="<?php if(isset($arrKols['title'])) echo $arrKols['title']?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="division">Department Name :</label>
			
			</td>
			<td>
				<input type="text" name="division" id="division" value="<?php if(isset($arrKols['division'])) echo $arrKols['division']?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="address1">Address:</label>
			
			</td>
			<td>
				<input type="text" name="address1" id="address1" value="<?php if(isset($arrKols['address1'])) echo $arrKols['address1']?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="fax">Fax :</label>
			
			</td>
			<td>
				<input type="text" name="fax" id="fax" value="<?php if(isset($arrKols['fax'])) echo $arrKols['fax']?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="primaryPhone">Phone:</label>
			
			</td>
			<td>
				<input type="text" name="primary_phone" id="primaryPhone" value="<?php if(isset($arrKols['primary_phone'])) echo $arrKols['primary_phone']?>"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="primaryEmail">Email:</label>
			
			</td>
			<td>
				<input type="text" name="primary_email" id="primaryEmail" value="<?php if(isset($arrKols['primary_email'])) echo $arrKols['primary_email']?>" class="email"></input>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="countryId1">Country<span class="required">*</span> :</label>
			</td>
			<td>
				<select name="country_id" id="countryId" onchange="getStatesByCountryId();" class="required">
					<option value="">-- Select --</option>
					<?php 
					foreach( $arrCountry as $country){
														if($country['country_id'] == $arrKols['country_id'])
															echo '<option value="'.$country['country_id'].'" selected="selected">'.$country['country_name'].'</option>';
														else
															echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
													}
													?>
				</select>
		<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
			</td>
		</tr>
		<tr>
			<td class="alignRight">									
				<label for="stateId1">State / Province :</label>
			</td>
			<td>
				<select name="state_id" id="stateId" onchange="getCitiesByStateId();">		
					<option>Select state</option>
					<?php 
													foreach( $arrStates as $state){
														if($state['state_id'] == $arrKols['state_id'])
															echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
														else
															echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
													}
													?>
				</select>
				<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="cityId1">City :</label>
			</td>
			<td>
				<select name="city_id" id="cityId">
					<option >Select city</option>		
					<?php 
						foreach( $arrCities as $city){
							if($city['city_id'] == $arrKols['city_id'])
								echo '<option value="'.$city['city_id'].'" selected="selected">'.$city['city_name'].'</option>';
							else
								echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
						}
						?>			
				</select>
			</td>
		</tr>
		<tr>
			<td class="alignRight">
				<label for="npiNum">NPI Number :</label>
			</td>
			<td>
				<input type="text" name="npi_num" id="npiNum" value="" ></input>
			</td>
		</tr>
		<tr>
			<tr>
				<td colspan="2">
	
				<div class="formButtons">
					<input type="hidden" value="complex" name="page_type"></input>	
					<input type="button" value="Submit" name="submit" id="requestKol"></input>
				</div>
				    
					
				</td>
			</tr>
	  </tbody>
  </tabel>
	    
</form>
 <?php } ?>			              
		<!-- End of Personal and Professional Information -->