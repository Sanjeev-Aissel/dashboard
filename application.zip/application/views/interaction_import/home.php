<!DOCTYPE html>
<html>
<head>
<title>Add Interaction Data</title>

<style>
#adopter{
width:600px;
margin:0 auto;
}
#buttons{
margin:10 auto;
text-align: center;
border-top:1px solid #ccc;
padding: 20px 0px 0px 0px;
}
.lbl{
width:150px;
}
.error{
font-size:10px;
color:red;
text-align: center;
}
.clearfix{
margin:20px 0;
}
</style>
</head>
<body>
	<div id="adopter">
        <form id="interaction-upload" action="" method="post" enctype="multipart/form-data">
            <fieldset>
                <legend>Add a Interaction Import Data</legend>
                <?php if(isset($error)){ echo '<div class="error">'.$error.'</div>'; } ?>
                <p>
                    <label class="lbl" for="file">Upload File: </label>
                    <input type="file" name="afile"/>
                    <?php echo form_error('afile', '<div class="error">', '</div>'); ?>
                    
                </p>
                <p id="buttons">
                    <input id="reset" type="reset" tabindex="4"> 
                    <input id="submit" type="submit" name="interaction_upload" class="interaction_upload" value="Upload">
                </p>
            </fieldset>
        </form>
            <div class="clearfix"></div>
            <?php 
            if(isset($result)){
            ?>	
            <fieldset>
                <legend>Interaction Data Uploaded Details</legend>
                 <p><?php echo $result; ?></p>     
            </fieldset>
            <?php 	
            }
            ?>
     </div> 
</body>
</html>