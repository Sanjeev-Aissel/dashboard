<?php

/**
 * Page to show Advance search Modal box Contents
 * 
 * @author Ambarish
 * @Created on: 16-04-11
 * @since	2.0
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";

	$autoSearchOptionsFname = "width: 185, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {}";
	$autoSearchOptionsLname = "width: 185, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {}";
?>
<!--<script type="text/javascript" src="<?php echo base_url();?>js/jquery.autocomplete.js" ></script>
	--><script type="text/javascript">
                    var kolMemberShips = {
				serviceUrl: '<?php echo base_url();?>kols/get_key_members',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.kolTypes').html();
					var selId = $(event).children('.kolTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#autocomplete').val(selText);
					$('#members').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							
						}
					}else{
						
					}
				}
			};
		var kolFirstNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_kol_name_for_autocomplete/first_name',
			<?php echo $autoSearchOptionsFname;?>
		};
		var kolLastNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_kol_name_for_autocomplete/last_name',
			<?php echo $autoSearchOptionsLname;?>
		};
                
	  
		// To activate the Horizontal Tabs
		$(function() {
                  $('#autocomplete').autocomplete(kolMemberShips);
			$( "#horizontalTabs" ).tabs({
			//	selected:0,
				ajaxOptions: {
					error: function( xhr, status, index, anchor ) {
						$( anchor.hash ).html(
							"Couldn't load this tab. We'll try to fix this as soon as possible. " +
							"If this wouldn't be a demo." );
					}
				},
				spinner: 'Loading the data....',
				select: function(event, ui){ 
					//jAlert(ui.toSource());
					//jAlert("Selected Index is" + $("#tabs").tabs("option", "selected"));
					if(ui.index != 0){
						$("#pageLoader").show();
					}
				},
				load: function(event, ui){$("#pageLoader").hide();}
			});


			
		});


		// Validates for advanced search form for atleast one field to be enterd before trigger advanced search
		function validateAdvSearchForm(form){
			var formName=form;
			var noOfBlanks=0;
			if(formName == 'kolAdvSearchForm'){
				for(i=0; i<document.kolAdvSearchForm.elements.length; i++){
					if(document.kolAdvSearchForm.elements[i].value=="")
						noOfBlanks++;
				}
				if(noOfBlanks<document.kolAdvSearchForm.elements.length-1)
					//$('#'+form).submit(); 
					return true;
				else{
					$('.kolAdvSearchMsgBox').html("Enter at least one field");
					return false;
				}
			}

			if(formName == 'pubAdvSearchForm'){
				for(i=0; i<document.pubAdvSearchForm.elements.length; i++){
					if(document.pubAdvSearchForm.elements[i].value=="")
						noOfBlanks++;
				}
				if(noOfBlanks<document.pubAdvSearchForm.elements.length-1)
					//$('#'+form).submit();
					return true;
				else{
					$('.pubAdvSearchMsgBox').html("Enter at least one field");
					return false;
				}
			}

			if(formName == 'ctAdvSearchForm'){
				for(i=0; i<document.ctAdvSearchForm.elements.length; i++){
					if(document.ctAdvSearchForm.elements[i].value=="")
						noOfBlanks++;
				}
				if(noOfBlanks<document.ctAdvSearchForm.elements.length-1)
					//$('#'+form).submit();
					return true;
				else{
					$('.ctAdvSearchMsgBox').html("Enter at least one field");
					return false;
				}
			}

			if(formName == 'eventAdvSearchForm'){
				for(i=0; i<document.eventAdvSearchForm.elements.length; i++){
					if(document.eventAdvSearchForm.elements[i].value=="")
						noOfBlanks++;
				}
				if(noOfBlanks<document.eventAdvSearchForm.elements.length-1)
					//$('#'+form).submit();
					return true;
				else{
					$('.eventAdvSearchMsgBox').html("Enter at least one field");
					return false;
				}
			}
		}
                
                
	</script>
	
	<style type="text/css">
		.formButtons{
			padding-top: 3px;
		}
		input[type="text"], input[type="password"], input.text, input.title, textarea, select {
			background-color:#FFFFFF;
			border:1px solid #DDDDDD;
		}
		#advSearchAddContainer label{
			/*color:#aaaaaa;*/
			font-weight:normal;
			text-align: right;
			display: block;
		}
		#advSearchAddContainer .ui-tabs .ui-tabs-panel {
			border-width:1px 0 0 0;
			padding: 5px;
		}
		#advSearchAddContainer .ui-tabs {
			border:0 none;
			padding:0;
		}
		#advSearchAddContainer .ui-tabs .ui-tabs-nav {
			padding: 0px;
		}
		#advSearchAddContainer fieldset {
			color:#888888;
			font-size:110%;
			letter-spacing:1px;
			width:490px;
		}
		#advSearchAddContainer fieldset {
			margin: 0px;
		}
		#pplAdvSearchFieldsContainer td{
			padding-right: 0px;
		}
		#pplAdvSearchFieldsContainer table{
			margin-bottom: 0px;
		}
		#advSearchAddContainer .ui-tabs .ui-tabs-panel {
	    	border: 1px solid #1E7399;
	    }
	    #horizontalTabs fieldset {
	    	border:0px;
	    	padding-top:0px;
	    	padding-bottom:5px;
	    }
	    #horizontalTabs fieldset legend{
	    	border-bottom: 1px solid;
	    	text-align: center;
    		width: 100%;
    		margin-bottom: 5px;
	    }
	    #horizontalTabs input[type="text"],  #horizontalTabs select{
	    	width:100%;
	    }
	    #horizontalTabs p {
		    margin: 0 0 1.5em;
		}
		.advSearchTitle{
		    color: #555555;
		    font-weight: bold;
		    text-align: center;
		}
		.advSearchContent{
			padding:2px 15px;
		}
		#advSearchAddContainer .ui-tabs .ui-tabs-panel{
			padding:0px;
			border-radius: 0 4px 4px 4px;
		}
		/*
    	.ui-widget-header .ui-icon {
			background-image: url("../images/kolm-sprite-image.png");
			background-position: -148px -59px;
			padding-bottom: 1px;
		    padding-right: 1px;
		}
		
		.ui-state-hover .ui-icon{
			border:1px solid #79b7e7;
			-webkit-border-radius: 5px;
		    -moz-border-radius: 5px;
		    border-radius: 5px;
			background-color: #D0E5F6;
			background-position: -179px -59px;
		}
		*/
		.advSearchContent table.formPlaceHolder td {
			padding-right:2px;
		}
		.advSearchContent table.formPlaceHolder td input[type="text"]{
			width:90% !important;
		}
		
		.advSearchContent table.formPlaceHolder td select {
		    width: 92% !important;
		}
		.microView div.ui-dialog-titlebar{
		    float: right;
		    margin-bottom: -30px;
		    width: 31px;
		    z-index: 1000;
		}
		.ui-state-hover{
		  background: none !important;
		  background-color: none !important;
		  border :0 !important; 
		}
		.advSearchTitle {
		    background: white !important;
		}
		
		#horizontalTabs .ui-state-active, #horizontalTabs .ui-widget-content .ui-state-active, #horizontalTabs .ui-widget-header .ui-state-active, #horizontalTabs .ui-state-default:hover, #horizontalTabs .ui-widget-content .ui-state-default:hover, #horizontalTabs .ui-widget-header .ui-state-default:hover {
			background: none repeat scroll 0 0 white;
			border: 1px solid #74B4DD;
			background-color: #ffffff !important;
		}
		#horizontalTabs .ui-state-active a{
			font-weight: bold !important;
			color: #74B4DD !important;
		}
		#horizontalTabs .ui-state-active a, #horizontalTabs .ui-state-default a:hover, #horizontalTabs .ui-state-active a:link, #horizontalTabs .ui-state-active a:visited {
			/*color:black !important;*/
			font-weight: normal;
		}
	
		#advSearchAddContainer #advSearchAddProfileContent #horizontalTabs ul li a:hover{
			color:#2f86be !important;
		}
		
		#advSearchAddContainer .ui-tabs .ui-tabs-panel {
	   		 border: 1px solid #74B4DD;
		}
		#horizontalTabs .ui-state-default, #horizontalTabs .ui-widget-content .ui-state-default, #horizontalTabs .ui-widget-header .ui-state-default {
		    border: 1px solid #74B4DD !important;
		    border-bottom-color: #ffffff !important;
		    border-bottom: 0 none !important;
		}
		.advSearchFieldsContainer{
			display: none;
		}
	</style>
			
			<!--  Start of TABS div for the Horizontal Navigation -->
			<div id="horizontalTabs" class="analystView">	
				<ul>
					<li><a href="#peopleAdvSearchFieldsContainer">Contacts</a></li>
					<!--<li><a href="#pubAdvSearchFieldsContainer">Publications</a></li>
					<li><a href="#trailAdvSearchFieldsContainer">Trials</a></li>
					<li><a href="#eventAdvSearchFieldsContainer">Events</a></li>
				--></ul>
			<!--  End of TABS div for the Horizontal Navigation -->
				<div>
				
				<!-- Start of PEOPLE ADVANCE SEARCH -->
				<div id="peopleAdvSearchFieldsContainer" class="advSearchFieldsContainer">
					<div id="pplAdvSearchFieldsContainer">
						<div class="msgBoxContainer">
							<div class="kolAdvSearchMsgBox">
							</div>
						</div>
						<form action="<?php echo base_url()?>kols/adv_search" name="kolAdvSearchForm" method="post" id="kolAdvSearchForm" onsubmit="return validateAdvSearchForm(this.id);">
							<div class="advSearchTitle">Advanced Search</div>
							<div class="advSearchContent">
								<table class="formPlaceHolder">
									<tr>
										<td width="20%">Search</td>
										<td width="40%"><input type="text" name="first_name" id="kolFirstName" title="First Name" class="autocompleteInputBox"/></td>
										<td width="40%"><input type="text" name="last_name" id="kolLastName" title="Last Name"  class="autocompleteInputBox"/></td>
									</tr>
									<tr>
										<td>With Keywords</td>
										<td colspan="2"><input type="text" name="keywords" title="Enter Keywords"  id="advKeyword" style="width: 95% ! important;" /></td>
									</tr>
                                                                        <tr>
										<td>Key Memberships</td>
										<td colspan="2"><input type="text"  class="autocompleteInputBox" name="member_ships" title="Search Key Memberships"  id="autocomplete" style="width: 95% ! important;" /></td>
									</tr>
									<tr>
										<td class="alignRight">
											<select name="pqtype">
												<option value="0">Or</option>
												<option value="1">And</option>
											</select>
										</td>
										<td><input type="text" name="pkeywords" id="advPubKeyword" title="Publication Keywords" /></td>
										<td>
										<!-- <input type="text" name="pauthorposition" title="Authorship Position" /> -->
										<select name="pauthorposition" id="advAuthPos">
								   			<option value="">Select Authorship Position</option>
								   			<option value="1">First Author</option>
								   			<option value="2">Middle Author</option>
								   			<option value="3">Last Author</option>
								   			<option value="4">Single Author</option>
								   		</select>
										</td>
									</tr>
									<tr>
										<td class="alignRight">
											<select name="eqtype">
												<option value="0">Or</option>
												<option value="1">And</option>
											</select>
										</td>
										<td>
											<select name="etopic" id="advTopic">
								   			<option value="">Select Event Topic</option>
											<?php 
												foreach($arrEventTopics as $key => $value){
													echo '<option value="'.$value.'">'.$value.'</option>';
												}
											?>
								    	</select>								
										</td>
										<td>
										<select name="erole" id="advRole">
								   			<option value="">Select Event Role</option>
											<?php 
												foreach($arrEventRoles as $key => $value){
													echo '<option value="'.$value.'">'.$value.'</option>';
												}
											?>
								    	</select>	
										</td>
									</tr>
									<tr>
										<td class="alignRight">
											<select name="tqtype">
												<option value="0">Or</option>
												<option value="1">And</option>
											</select>
										</td>
										<td><input type="text" name="tkeywords" id="advTrilKeyword" title="Trial Keywords" /></td>
										<td>
										<!--<input type="text" name="trole" title="Role" />	-->
											<select name="trole" id="advTrilRole">
									   			<option value="">Select Trial Role</option>
												<?php 
													foreach($arrTrialRoles as $key => $value){
														echo '<option value="'.$value.'">'.$value.'</option>';
													}
												?>
									    	</select>
										</td>
									</tr>
									<tr>
										<td colspan="3" style="text-align: center;"><input type="button" name="kols" value="Search" onclick="validateEmtyFields()"/></td>
									</tr>
								</table>
							</div>
                                                                                <input type="hidden" name="members" id="members"  value=""/>

						</form>
					</div>
				</div>
				<!-- End of PEOPLE ADVANCE SEARCH -->
	<?php /* ?>			
				<!-- Start of PUBLICATIONS ADVANCE SEARCH -->
				<div id="pubAdvSearchFieldsContainer" class="advSearchFieldsContainer">
					<div id="kolPplAdvSearchFieldsContainer">
						<div class="msgBoxContainer">
							<div class="pubAdvSearchMsgBox">
							</div>
						</div>
						<form action="<?php echo base_url()?>pubmeds/adv_search_publications" name="pubAdvSearchForm" method="post" id="pubAdvSearchForm" onsubmit="return validateAdvSearchForm(this.id);">
							<div class="advSearchTitle">Publications Advanced Search</div>
							<div class="advSearchContent">
								<table class="formPlaceHolder">
									<tr>
										<td width="20%"><label for="authors">Article title</label></td>
										<td width="75%"><input type="text" name="article_title" id="article_title" title=""/></td>
									</tr>
									<tr>
										<td width="20%"><label for="authors">Authors</label></td>
										<td width="75%"><input type="text" name="authors" id="authors" title=""/></td>
									</tr>
									<tr>
										<td><label for="mesh_term">MeshTerms</label></td>
										<td><input type="text" name="mesh_term" id="mesh_term" title=""/></td>
									</tr>
									<tr>
										<td><label for="substances">Substances</label></td>
										<td><input type="text" name="substances" id="substances" title=""/></td>
									</tr>
									<tr>
										<td><label for="pubKeywords">Keywords</label></td>
										<td><input type="text" name="pubKeywords" id="pubKeywords" title=""/></td>
									</tr>
									
									<tr>
										<td colspan="2"><div class="formButtons">
											<input type="submit" name="do_earch" id="doSearch" onclick="validateAdvSearchForm('pubAdvSearchForm')" value="Search"/>	
										</div>
										</td>
									</tr>
								</table>		
							</div>
						</form>
					</div>
				</div>
				<!-- End of PUBLICATIONS ADVANCE SEARCH -->
				
				<!-- Start of CLINICAL TRIALS ADVANCE SEARCH -->
				<div id="trailAdvSearchFieldsContainer" class="advSearchFieldsContainer">
					<div id="kolPplAdvSearchFieldsContainer">
						<div class="msgBoxContainer">
							<div class="ctAdvSearchMsgBox">
							</div>
						</div>
						<form action="<?php echo base_url()?>clinical_trials/adv_search_trials" name="ctAdvSearchForm" method="post" id="ctAdvSearchForm" onsubmit="return validateAdvSearchForm(this.id);">
							<div class="advSearchTitle">Trials Advanced Search</div>
							<div class="advSearchContent">
								<table class="formPlaceHolder">
									<tr>
										<td width="20%"><label for="interventions">Intervention</label></td>
										<td>
											
											<input type="text" name="interventions" id="interventions"/>
										</td>
									</tr>
									<tr>
										<td><label  for="condition">Condition</label></td>
										<td>
											
											<input type="text" name="condition" id="condition"/>
										</td>
									</tr>
									<tr>
										<td><label for="investigators">Investigators</label></td>
										<td>
											<input type="text" name="investigators" id="investigators"/>
										</td>
									</tr>
									<tr>
										<td><label for="mesh_term">MeshTerms</label></td>
										<td>
											<input type="text" name="mesh_term" id="mesh_term"/>
										</td>
									</tr>
									<tr>
										<td><label for="sponsors">Sponsors</label></td>
										<td>
											<input type="text" name="sponsors" id="sponsors"/>
										</td>
									</tr>
									<tr>
										<td colspan="2">
											<div class="formButtons">
												<input type="submit" name="do_earch" id="doSearch" onclick="validateAdvSearchForm('ctAdvSearchForm')" value="Search"/>	
											</div>
										</td>
									</tr>
									
									
								</table>
							</div>
						</form>
					</div>
				</div>
				<!--   End of CLINICAL TRIALS ADVANCE SEARCH -->
				
				<!-- Start of EVENTS ADVANCE SEARCH -->
				<div id="eventAdvSearchFieldsContainer" class="advSearchFieldsContainer">
					<div id="kolPplAdvSearchFieldsContainer">
						<div class="msgBoxContainer">
							<div class="eventAdvSearchMsgBox">
							</div>
						</div>
						<form action="<?php echo base_url()?>kols/adv_search_events" name="eventAdvSearchForm" method="post" id="eventAdvSearchForm" onsubmit="return validateAdvSearchForm(this.id);">
							<div class="advSearchTitle">Events Advanced Search</div>
							<div class="advSearchContent">
								<table class="formPlaceHolder">
									<tr>
										<td width="20%"><label for="confEventType">Event Type</label></td>
										<td>
											<select name="type" id="confEventType">
									   			<option value="">--- Select ---</option>
												<?php 
													foreach($arrEventSessionTypes as $key => $value){
														echo '<option value="'.$value.'">'.$value.'</option>';
													}
												?>
								    		</select>
										</td>
									</tr>
									<tr>
										<td><label for="role">Role</label></td>
										<td>
											<!--<input type="text" name="role" id="role"/>
											-->
											<select name="role" id="role">
												<option value="">--- Select ---</option>
												<?php foreach($arrEventRoles as $key=>$roleName){
													echo '<option value="'.$roleName.'">'.$roleName.'</option>';
												}?>
											</select>
										</td>
									</tr>
									<tr>
										<td><label for="role">Country</label></td>
										<td>
											<input type="text" name="country" id="country"/>
										</td>
									</tr>
									<tr>
										<td><label for="organizer">Organizer</label></td>
										<td>
											<input type="text" name="organizer" id="organizer"/>
										</td>
									</tr>
									<tr>
										<td colspan="2">
										<div class="formButtons">
											<input type="submit" name="do_earch" id="doSearch" onclick="validateAdvSearchForm('eventAdvSearchForm')" value="Search"/>
										</div>	
										</td>
									</tr>
												
								</table>
							</div>
						</form>
					</div>
				</div>
				<!--   End of EVENTS ADVANCE SEARCH -->
		<?php */ ?>
			</div>	
		</div>
		<!-- End of Contents Div -->
	<script type="text/javascript">
	
	$(document).ready(function(){
		$('.formPlaceHolder input:text').focus(function (){
			if(($(this).attr('title'))==$(this).val()){
				$(this).val('');
			}
		});
		$('.formPlaceHolder input:text').blur(function (){
			if($(this).val()==''){
				$(this).val($(this).attr('title'));
			}
		});
		$('.formPlaceHolder input:text').each(function (){
			$(this).val($(this).attr('title'));
		});
		$('#kolAdvSearchForm').submit(function(){
			$('.formPlaceHolder').block({ message: '.',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$('#kolAdvSearchForm input:text').each(function (){
				if(($(this).attr('title'))==$(this).val()){
					$(this).val('');
				}
			});
			return true;
		});

		a= $('#kolFirstName').autocomplete(kolFirstNameAutoCompleteOptions);
		$('.autocomplete').click(function(){
			//doSearchFilter1(-1);
		});
		a= $('#kolLastName').autocomplete(kolLastNameAutoCompleteOptions);
		$('.autocomplete').click(function(){
			//doSearchFilter1(-1);
		});
	});

	function validateEmtyFields(){
		var advTrilRole = $('#advTrilRole').val();
		var kolFirstName = $('#kolFirstName').val();
		var lastName = $('#kolLastName').val();
		var advKeyword = $('#advKeyword').val();
		var advPubKeyword = $('#advPubKeyword').val();
		var advAuthPos = $('#advAuthPos').val();
		var advTopic = $('#advTopic').val();
		var advRole = $('#advRole').val();
		var advTrilKeyword = $('#advTrilKeyword').val();
                var advSearchKeyword = $('#autocomplete').val();
		
		
		if(advTrilRole=='' && kolFirstName=='First Name' && lastName=='Last Name' && advKeyword=='Enter Keywords' && advPubKeyword=='Publication Keywords' && advAuthPos=='' && advTopic=='' && advRole=='' && advTrilKeyword=='Trial Keywords' && advSearchKeyword==''){
			jAlert('Please enter at least one field ');
			return false;
		}
//                $("#members").remove();
$("#member_hidden").remove();
		$('#kolAdvSearchForm').submit();	
		
	}
	</script>