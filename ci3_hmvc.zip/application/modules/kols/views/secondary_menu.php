<?php 
$reportSection = $this->uri->segment(2); 
?>
<nav class="navbar-primary">
  <ul class="navbar-primary-menu">
  <?php 
  
  if($reportSection == 'kols' ||$reportSection == 'pubmeds' ||$reportSection == 'clinical_trials'){
  ?>
  	<li>
      <a href="<?php echo base_url(); ?>analysts/kols/edit_kol/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-user"></span><span class="nav-label">Overview</span></a>
      <a href="<?php echo base_url(); ?>analysts/kols/details_kol/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-th-list"></span><span class="nav-label">Details</span></a>
      <a href="<?php echo base_url(); ?>analysts/kols/add_education_detail/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-book"></span><span class="nav-label">Education</span></a>
      <a href="<?php echo base_url(); ?>analysts/kols/add_membership/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-move"></span><span class="nav-label">Alliliations</span></a>
      <a href="<?php echo base_url(); ?>analysts/kols/add_event/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-calendar"></span><span class="nav-label">Events</span></a>
      <a href="<?php echo base_url(); ?>analysts/kols/add_social_media/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-bullhorn"></span><span class="nav-label">Social Media</span></a>
      <a href="<?php echo base_url(); ?>analysts/pubmeds/view_publications/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-list-alt"></span><span class="nav-label">Publications</span></a>
      <a href="<?php echo base_url(); ?>analysts/clinical_trials/view_clinical_trials/<?php echo $arrKol['vid']?>"><span class="glyphicon glyphicon-object-align-bottom"></span><span class="nav-label">Clinical Trials</span></a>
    </li>
    <?php 
	}
	if($reportSection == 'organizations'){ ?>
	<li>
	  <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/about"><span class="glyphicon glyphicon-info-sign"></span><span class="nav-label">About</span></a>
      <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/address"><span class="glyphicon glyphicon-globe"></span><span class="nav-label">Address</span></a>
      <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/media"><span class="glyphicon glyphicon-bullhorn"></span><span class="nav-label">Social Media</span></a>
      <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/keyPeople"><span class="glyphicon glyphicon-user"></span><span class="nav-label">Key People</span></a>
      <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/publications"><span class="glyphicon glyphicon-list-alt"></span><span class="nav-label">Publications</span></a>
      <a href="<?php echo base_url(); ?>analysts/organizations/edit_organization/<?php echo $arrOrganization['ovid']?>/trials"><span class="glyphicon glyphicon-object-align-bottom"></span><span class="nav-label">Clinical Trials</span></a>
      </li>
	<?php } ?>
  </ul>
</nav>			
			