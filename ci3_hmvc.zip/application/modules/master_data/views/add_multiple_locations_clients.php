<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
	select.chosenMultipleSelect{
		width:200px;
	}
	
	.show{
		display:block;	
	}
	
	.hide{
		display:none;	
	}
	.microView .ui-dialog-content {
    background-color: white;
    }
    .users{
    	list-style-type: none;
    	margin:0;
    	padding:0
    	
    }
    .users li{
    	float:left;
    }
    
     .editIcon{
     margin-left: 3px;
    }
</style>
<div class="addClientsMsgBox"></div>
<script type="text/javascript">
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
});
</script>
<form>
	<div align="center">
		<caption><h4>Associate Clients</h4></caption>
	</div>
	<table class="anaylystForm client_specialtiesTbl">
		<tr>
			<td>
				<p>
				
				<div align="center">
					<span id="responseMessage"></span> <input type="hidden"
						id="hiddenSid" readonly="readonly">
				</div>
					<table><tr><td><label><h4>Clients:</h4></label></td>
					 <td><select name="clients[]" multiple="multiple" id="clientId" class="chosenMultipleSelect" data-placeholder="Select Clients">	
					<option disabled="disabled" value="">Select Clients</option>					
			            <?php foreach($arrClients as $clients){ ?>
			            <option value="<?php echo $clients['id'];?>"
			             <?php if(in_array($clients['id'],$arrSelected)){ echo "selected = selected";} ?>><?php echo $clients['name']; ?></option>
			            <?php } ?>
            			</select>
            			</td>
            			</tr>
            			</table>
				</p>
			</td>
		</tr>
		<tr>																												
			<td>
				<div class="formButton" align="center">
					<input type="hidden" id="specIds" value="<?php echo $arrSpecId;?>">					
					<input type="button" value="Save" name="submit"
						onclick="saveMultipleClientsLocations();"></input><input type="button"
						value="Cancel" name="submit" onclick="closeModal();"></input>						
				</div>
			</td>
		</tr>
	</table>
	<!-- End of Table -->
</form>
<!-- End of User Form -->