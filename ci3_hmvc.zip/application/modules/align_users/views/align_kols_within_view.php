<script>
function saveKolAlignment(){
	$('div.responseMsgBox').removeClass('alert-success');
	$('div.responseMsgBox').addClass('alert-warning');
	$('div.responseMsgBox').show();
	$('div.responseMsgBox').html('Saving the data... <img src="'+base_url+'assets/images/ajax_loader_black.gif" />');
	$.ajax({
		url:'<?php echo base_url()?>align_users/align_users/save_kol_alignment_within_profile',
		data:$('#alignKols').serialize(),
		type:'post',
		dataType:'json',
		success:function(returnData){
			$('.responseMsgBox').html(returnData.message);
			if(returnData.status){
				$('div.responseMsgBox').removeClass('alert-warning');
				$('div.responseMsgBox').removeClass('alert-danger');
				$('div.responseMsgBox').addClass('alert-success');				
	     	}else{
				$('div.responseMsgBox').removeClass('alert-success');
				$('div.responseMsgBox').removeClass('alert-warning');
				$('div.responseMsgBox').addClass('alert-danger');
		    }
			$('div.responseMsgBox').fadeOut(10000);
		}
	});
}
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
});
</script>
<?php $role_type= $this->session->userdata('role_type');?>
<?php $userId = $this->session->userdata('user_id');?>
<form method="post" class="validateForm" id="alignKols" name="alignKolsForm">
	<input type="hidden" name="kol_id" id="kolIds" value="<?php echo $arrKols?>"/>
	<input type="hidden" name="role" id="role" value="<?php echo $isManager?>"/>
	<div class="form-group row responseMsgBox alert alert-success" role="alert" style="display:none"></div>
	<div class="form-group row">
		<label class="col-sm-4 col-form-label">Select user(s) to assign:</label>
		<div class="col-sm-8">
			<select name="users[]" id="users" multiple="multiple" class="form-control chosenMultipleSelect" data-placeholder="Select Users">
			<option value=""></option>
			<?php $selected	= '';
			if($role_type == ROLE_MANAGER){
				foreach($arrUsers as $key=>$arrRow){ ?>
					<option value="<?php echo $arrRow['id']?>" <?php if(array_key_exists($arrRow['id'],$assignedUsers))echo "selected='selected'";?>>
						<?php echo $arrRow['first_name'].' '.$arrRow['last_name'];?>
					</option>
				<?php }
			}else{ 	?>
					<option value="<?php echo $userId?>" <?php if(array_key_exists($userId,$assignedUsers))echo "selected='selected'";?>>
						<?php echo $this->session->userdata['user_full_name'];?>
					</option>
				<?php }	?>
			</select>
	    </div>
	</div>
	<div class="form-group row" style="text-align: center;">
		<a type="button" onclick="saveKolAlignment();return false;" class="btn custom-btn">Save</a>
		<a type="button" onclick="close_dialog1();return false;" class="btn custom-btn">Cancel</a>
	</div>
</form>