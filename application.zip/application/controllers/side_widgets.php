<?php
/**
 *  Side bar widgets
 * @author Laxman K
 * @since KOLM CORE v6.0.6
 * @created on 27 DEC 2013
 * 
 */

class Side_widgets extends Controller{
	function Side_widgets(){
		parent::Controller();
			$this->load->model('Side_widget');
	}
	function get_similar_kols($kolId){
		$arrKols	= $this->Side_widget->getSimilarKols($kolId);
		ob_start('ob_gzhandler');
		echo json_encode($arrKols);
	}
	function get_similar_affiliated_people($kolId){
		$arrKols	= $this->Side_widget->getTopSimilarAffiliatedKols($kolId);
		ob_start('ob_gzhandler');
		echo json_encode($arrKols);
	}
	function get_similar_trial_kols($kolId){
		$arrKols	= $this->Side_widget->getKolsOfSimilarTrials($kolId);
		ob_start('ob_gzhandler');
		echo json_encode($arrKols);
	}
	function getSimilarOrgsBasedOnPublications($orgId){
		$arrOrgs	= $this->Side_widget->getSimilarOrgsBasedOnPublications($orgId);
		ob_start('ob_gzhandler');
		echo json_encode($arrOrgs);
	}
	function get_org_event_attendees($orgId){
		$arrKols	= $this->Side_widget->getTopKolEventAttendeesWithinOrg($orgId);
		ob_start('ob_gzhandler');
		echo json_encode($arrKols);
	}
	function get_org_trial_investigators($orgId){
		$arrInvestigators	= $this->Side_widget->getTopInvestigatorsWithinOrg($orgId);
		ob_start('ob_gzhandler');
		echo json_encode($arrInvestigators);
	}
}
