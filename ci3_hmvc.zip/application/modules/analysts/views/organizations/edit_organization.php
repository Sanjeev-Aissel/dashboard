<?php
/**
* Description:
*
*  @package application.views.kols
*  @author:Developer
*
*  @created on:Dec 13, 2010
*
*/
function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList; 
}
?>
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
<style type="text/css">
		#socialMediaForm label img{
			height:28px;
			vertical-align: text-top;
		}	
		.analystForm input[type="text"], .analystForm select {
		    width: 400px;
		}
		#contentWrapper.span-24 {
		    background-image: url("<?php echo base_url();?>images/verticlesep.jpg");
		    background-position: 168px 50%;
		    background-repeat: repeat-y;
		}
		button#saveOrgContact {
	    position: absolute;
	    top: 22px;
	}
	</style>
<script src="<?php echo base_url();?>assets/js/imgAreaSelect.js" type="text/javascript"></script>
<script>
	var options, a;
	// Autocomplet Options for the 'Oragnization Name'
	var orgNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>analysts/kols/get_org_names',
		width: 255,
		delimiter: /(,|;)\s*/,
		deferRequestBy: 800, //miliseconds
		noCache: true, //set to true, to disable caching
		minChars: 2,
		
		enable: false
	};	
	
	var validationRules	=  {
			name: { required:true }
		};
	
	var validationMessages = {
		name: { required: "Required"}
	};

	/**
	* Returns the list of States of the Selected Country ID
	*/
	function getStatesByCountryId(){
		// Show the Loading Image
		$("#loadingStates").show();
		
		var countryId=$('#country_id').val();
		var params = "country_id="+countryId;	
		$("#state_id").html("<option value=''>-- Select State --</option>");
		$("#city_id").html("<option value=''>-- Select City --</option>");
		var states = document.getElementById('state_id');
		$.ajax({
			url: "<?php echo base_url()?>helpers/country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {					
					var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);				
					});
				
	            $("#state_id option[value='']").remove();
	            $("#state_id").prepend("<option value=''>-- Select State --</option>");
	            $("#state_id").val("");
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});		
	}
	
	/**
	* Returns the list of Cities of the Selected State
	*/
	function getCitiesByStateId(){
		var stateId=$('#state_id').val();
		$("#city_id").html("<option value=''>-- Select City --</option>");	
		var cities = document.getElementById('city_id');
		var params = "state_id="+stateId;	
		
		$.ajax({
			url: "<?php echo base_url()?>helpers/country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {	
							
				var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);				
				});		
				$("#city_id option[value='']").remove();
	                $("#city_id").prepend("<option value=''>-- Select City --</option>");
	                $("#city_id").val("");
			}		
		});		
		
	}

	/**
	* Validate the text for 'Numeric Only'
	*/
	function allowNumericOnly(src) {
		if(!src.value.match(/^\d*$/)) {
			src.value=src.value.replace(/[^\+?0-9]/g,'');  
		}
	}
	
	$(document).ready(function(){
		a = $('#orgName').autocomplete(orgNameAutoCompleteOptions);	
		
		$("#saveAbout").click(function(){
			saveOrganization();
		});

		$("#saveAddress").click(function(){
			saveOrganization();
		});

		$("#saveMedia").click(function(){
			saveOrganization();
		});

		$("#organizationForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		/**
		* Save the 'KeyPeople Details'
		*/
		$("#saveKeyPeople").click(function(){
			var id = $("#keyPeopleId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>analysts/organizations/save_key_people';
			}else{
				formAction = '<?php echo base_url();?>analysts/organizations/update_key_people';
			}	
			$('.keyPplMsgBox').removeClass('success');
			$('.keyPplMsgBox').addClass('notice');
			$('.keyPplMsgBox').show();
			$('.keyPplMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			 $.post(formAction, $("#keyPeopleForm").serialize(),
					 function(returnData){
			     		if(returnData.saved == true){
							// Clear the existing form details
							$("#keyPeopleForm").val("");
							$("#keyRole").val("");
							$("#keySalutation").val("");
							$("#keyFirstName").val("");
							$("#keyLastName").val("");
							$("#keyMiddleName").val("");
							$("#keyTitle").val("");
							$("#keyEmail").val("");
							$("tr.ui-state-highlight").removeClass('ui-state-highlight');
							if(id == ''){									
								var datarow = {
										id				:	returnData.lastInsertId,
										role_id			:	returnData.data.role_id,
										salutation		:	returnData.data.salutation,
										first_name		:	returnData.data.first_name,
										middle_name		:	returnData.data.middle_name,
										last_name		:	returnData.data.last_name,
										title			:	returnData.data.title,
										email			:	returnData.data.email
										
									}; 
								var su=jQuery("#JQBlistKeyPeopleResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
								}
							else{
								//jQuery("#JQBlistKeyPeopleResultSet").trigger("reloadGrid");
								jQuery("#JQBlistKeyPeopleResultSet").jqGrid('setRowData',returnData.data.id,{
																			id				:	returnData.lastInsertId,
																			role_id			:	returnData.data.role_id,
																			salutation		:	returnData.data.salutation,
																			first_name		:	returnData.data.first_name,
																			middle_name		:	returnData.data.middle_name,
																			last_name		:	returnData.data.last_name,
																			title			:	returnData.data.title,
																			email			:	returnData.data.email
																		}); 
								$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}
							// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveKeyPeople").val("Add");
								// Re-Set the Hidden Eduction Id value
								$("#keyPeopleId").val("");									
							}
							$('.keyPplMsgBox').fadeOut(1500);
							$(".keyPplMsgBox").hide();
				     	}else{
							// Display Error Message
					     }
					},"json");
		});	

		/**
		* Save the 'Contact Details'
		*/
		$("#saveOrgContact").click(function(){
			id = $("#contactId").val();
			RelatedTo = $("#RelatedTo").val();
			var data = {};
			data['id'] = id;
			data['related_to']	= $("#contactRelatedTo").val();
			data['phone']		= $("#contactPhone").val();
			data['org_id']		= $("#orgId").val();
			$('.contactMsgBox').addClass('notice');
			$('.contactMsgBox').show();
			$('.contactMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			if(id == ''){
				formAction = '<?php echo base_url();?>analysts/organizations/save_contact';
			}else{
				formAction = '<?php echo base_url();?>analysts/organizations/update_contact';
			}					
			 $.post(formAction, data,
					 function(returnData){
			     		if(returnData.saved == true){
							// Clear the existing form details
							$("#contactRelatedTo").val("");
							$("#contactPhone").val("");
							//	$("#contactEmail").val("");
							$("tr.ui-state-highlight").removeClass('ui-state-highlight');
							if(id == ''){									
								var datarow = {
										id				:	returnData.lastInsertId,
										related_to		:	returnData.data.related_to,
										phone			:	returnData.data.phone
										//	email			:	returnData.data.email
									}; 
								var su=jQuery("#JQBlistContactsResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
								
								}
							else{
								//jQuery("#JQBlistContactsResultSet").trigger("reloadGrid");
								jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',returnData.data.id,{
																			id				:	returnData.lastInsertId,
																			related_to		:	returnData.data.related_to,
																			phone			:	returnData.data.phone
																			//email			:	returnData.data.email
																		}); 
								$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}
							// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#saveOrgContact").val("Add");

								// Re-Set the Hidden Eduction Id value
								$("#contactId").val("");									
							}
							$('.contactMsgBox').fadeOut(1500);
							$(".contactMsgBox");
				     	}else{
							// Display Error Message
					     }
					},"json");
		});	

		/*
		*jqgrid for Contacts table
		*/

		var orgId = '<?php echo $arrOrganization['id'];?>';
		jQuery("#JQBlistContactsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>analysts/organizations/list_contacts/'+orgId,
			datatype: "json",
		   	colNames:['Id','Related To','Phone','Action'],
		   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'related_to',index:'related_to', width:250,editable:true},
				   		{name:'phone',index:'phone',width:250,editable:true},
				   		{name:'act',width:60,search:false}		   			
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",	
		   	width:"95%",
		   	resizable:true,   
		   	pager: '#listContactsPager',
		   	mtype: "POST",
		   	sortname: 'id',
		    viewrecords: true,
		    toolbar : [true,"top"],
		    sortorder: "desc",
		    gridComplete: function(){ 
			    var ids = jQuery("#JQBlistContactsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];				    	
				    	be = "<a href='#' onclick=\"editContact('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
				    	be += "&nbsp; | &nbsp;";
				    	be += "<a href='#' onclick=\"deleteContact('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";				    	
				    	jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	},
			    	 
	    	loadComplete: function() {
	    	    $("option[value=100000000]").text('All');
					},       	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Additional Contacts"		    
		});
		jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','#listContactsPager',{edit:false,add:false,del:false,search:false,refresh:false});	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistContactsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistContactsResultSet").height(25).jqGrid('filterGrid',"JQBlistContactsResultSet",{gridModel:true,gridToolbar:true});
		jQuery("#JQBlistContactsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistContactsResultSet").jqGrid('navButtonAdd',"#listContactsPager",{caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}
				
			} 
		}); 
	
	

		/*
		*jqgrid for KeyPeople table
		*/
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid({
		   	url:'<?php echo base_url();?>analysts/organizations/list_key_peoples_analyst/'+orgId,
			datatype: "json",
		   	colNames:['Id','Role','Salutation', 'First Name', 'Middle Name','Last Name','Title','Email','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
		   		{name:'role_id',index:'role_id', width:140,editable:true},
		   		{name:'salutation',index:'salutation',width:50,editable:true},
		   		{name:'first_name',index:'first_name',width:130,editable:true},
		   		{name:'middle_name',index:'middle_name',width:50,resizable:true,editable:true},
		   		{name:'last_name',index:'last_name',width:80,resizable:true,editable:true},
		   		{name:'title',index:'title',width:100,editable:true},
		   		{name:'email',index:'email',width:100,resizable:true,editable:true},
		   		{name:'act',resizable:true, search:false,width:60, align:'center'}		   			
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",	
		   	width:"95%",
		   	resizable:true,   
		   	pager: '#listKeyPeoplePage',
		   	mtype: "POST",
		   	sortname: 'id',
		    viewrecords: true,/* 
		    toolbar : [true,"top"], */
		    sortorder: "desc",
		    gridComplete: function(){ 
			    var ids = jQuery("#JQBlistKeyPeopleResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];				    	
				    	be = "<a href='#' onclick=\"editKeyPeople('"+cl+"');\" title='Edit'><span class='icon edit glyphicon glyphicon-edit'></span></a>";
				    	be += "<a href='#' onclick=\"deleteKeyPeople('"+cl+"');\" title='Delete'><span class='icon delete glyphicon glyphicon-trash'></span></a>";				    	
				    	jQuery("#JQBlistKeyPeopleResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistKeyPeopleResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	},
			    	 
	    	loadComplete: function() {
	    	    $("option[value=100000000]").text('All');
					},       	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"<?php echo base_url();?>analysts/organizations/update_key_people",		   
		    caption:"KeyPeople Details"	
 
		});
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid('navGrid','#listKeyPeoplePage',{edit:false,add:false,del:false,search:false,refresh:false});	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistKeyPeopleResultSet").height(25).jqGrid('filterGrid',"JQBlistKeyPeopleResultSet",{gridModel:true,gridToolbar:true});
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid('navButtonAdd',"#listKeyPeoplePage",{caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}
				
			} 
		}); 
	});

	function saveOrganization(){
		if(!$("#organizationForm").validate().form()){
			return false;
		}
		id = $("#orgId").val();	

		$('.orgMsgBox').removeClass('success');
		$('.orgMsgBox').addClass('notice');
		$('.orgMsgBox').show();
		$('.orgMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		
		$.ajax({
			type: "post",
			dataType: "json",
			data: $("#organizationForm").serialize(),
			url: '<?php echo base_url();?>analysts/organizations/update_organization',
			success: function(returnData){
				$(".msgBox").text(returnData.msg);
				if(returnData.saved == true){
					$("#orgId").val(returnData.lastInsertId);
					$('.orgMsgBox').addClass('success');
					$('.orgMsgBox').text('Updated the data successfully');
				}else{
					$("div.msgBox").show();
					$("div.msgBox").fadeOut(5500);
				}
			},
			complete: function(){
				$('.orgMsgBox').fadeOut(1300);
				$(".orgMsgBox").hide();
				$('.formError').hide();
			}
			
		});
	};	
	/**
	* Edit the 'Contact Details'
	*/
	function editContact(id){
			var rd=jQuery("#JQBlistContactsResultSet").jqGrid('getRowData',id);
			
			// Get the values from TR - Table Row, which is under editing
			id 				= rd.id;
			relatedTo 		= rd.related_to;
			phone			= rd.phone;
			//email			= rd.email;

			// Add the values to the form
			$("#contactRelatedTo").val(relatedTo);
			$("#contactPhone").val(phone);
			//$("#contactEmail").val(email);

			// Modify the text of 'Button' from 'Add' to 'Update'
			$("#saveOrgContact").val("Update");

			// Set the Hidden Eduction Id value
			$("#contactId").val(id);
			

			// Remove the row from the Table
			$("tr").removeClass('ui-state-highlight');
			$("tr#"+id).addClass('ui-state-highlight');
	}

	/**
	* Edit the 'KeyPeople Details'
	*/
	function editKeyPeople(id){
			var rd=jQuery("#JQBlistKeyPeopleResultSet").jqGrid('getRowData',id);
			
			// Get the values from TR - Table Row, which is under editing
			id 				= rd.id;
			roleName 		= rd.role_id;
			salutationName	= rd.salutation;
			firstName		= rd.first_name;
			middleName		= rd.middle_name;
			lastName		= rd.last_name;
			title			= rd.title;
			email			= rd.email;

			method = '<?php echo base_url();?>analysts/organizations/get_key_people_types/'+roleName + '/' +salutationName;
		
			$.get(method,function(returnData){
				role		= returnData.role_id;
				salutation	= returnData.salutation;
	
				// Add the values to the form
				$("#keyRole").val(role);
				$("#keySalutation").val(salutation);
				$("#keyFirstName").val(firstName);
				$("#keyMiddleName").val(middleName);
				$("#keyLastName").val(lastName);
				$("#keyTitle").val(title);
				$("#keyEmail").val(email);
	
				// Modify the text of 'Button' from 'Add' to 'Update'
				$("#saveKeyPeople").val("Update");
	
				$("#keyPeopleId").val(id);			
				$("tr").removeClass('ui-state-highlight');
				$("tr#"+id).addClass('ui-state-highlight');
			},"json");	
	}

	/**
	* Delete the 'KeyPeople Details'
	*/
	function deleteKeyPeople(id){								
		var formAction = '<?php echo base_url();?>analysts/organizations/delete_key_people/'+id;
		jQuery("#JQBlistKeyPeopleResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});     
	}

	/**
	* Delete the 'KeyPeople Details'
	*/
	function deleteContact(id){								
		var formAction = '<?php echo base_url();?>analysts/organizations/delete_contact/'+id;
		jQuery("#JQBlistContactsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});     
	}
</script>

<script>
	function preview(img, selection) {
		var scaleX = 100 / selection.width; 
		var scaleY = 100 / selection.height; 
		$('#smallImage').css({ 
			width: Math.round(scaleX * 400) + 'px', 
			height: Math.round(scaleY * 300) + 'px',
			marginLeft: '-' + Math.round(scaleX * selection.x1) + 'px', 
			marginTop: '-' + Math.round(scaleY * selection.y1) + 'px' 
		});
		$('#x1').val(selection.x1);
		$('#y1').val(selection.y1);
		$('#x2').val(selection.x2);
		$('#y2').val(selection.y2);
		$('#w').val(selection.width);
		$('#h').val(selection.height);
	} 
	
	$(document).ready(function () { 
		$('#save_thumb').click(function() {
			var x1 = $('#x1').val();
			var y1 = $('#y1').val();
			var x2 = $('#x2').val();
			var y2 = $('#y2').val();
			var w = $('#w').val();
			var h = $('#h').val();
			if(x1=="" || y1=="" || x2=="" || y2=="" || w=="" || h==""){
				return false;
			}else{
				return true;
			}
		});
	}); 
	function uploadLogo(){
		$("#imageUploadProgressBar").show();
		$("#frmUploadLogo").submit();

		$("#imageUploaderFrame").load(function(){
			$("#imageUploadProgressBar").hide();
			$("#mediumImageContainer").show();
				
			up_output = $(this).contents().find("#output").text();
			if (up_output == "success"){
				up_output += '<br />' + $(this).contents().find("#message").html();

				$('#orgUploadLogo').val('');
				
				//$("#mediumImageContainer").html(up_output);
				imageSrc	= $(this).contents().find("#imageSrc").html();
				$('#thumbnail').attr('src', imageSrc);
				$('#smallImage').attr('src', imageSrc);
				$('#thumbImagePath').val(imageSrc);
				$('#thumbnail').imgAreaSelect({ aspectRatio: '1:1', onSelectChange: preview }); 
			}
		});
	}
</script>
<?php $this->load->view('kols/secondary_menu');?>
<div class="main-content">
	<div class="row">
		<div class="col-md-12">
		<?php 
			switch($reportSection){ 
			case 'about':
			?>	
        	   <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">About Organization</a></li>
               </ul>
			   <!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               		<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrOrganization['name']; ?></h5>
	               </div>
	        		<!-- Start Tab panels -->
	                  <div role="tabpanel" class="tab-pane active" id="prof_info">
	                  		<div class="col-md-3" style="padding-left:0px !important;">
	                  			<div class="panel panel-default"> 
		                  			<div class="panel-heading"> <h3 class="panel-title">Profile Picture</h3> </div> 
		                  			<div class="panel-body" style="min-height:540px;"> 
		                  				<div class="row"  style="text-align: center;">
											<img alt="Image" width="100" height="100" src="<?php echo base_url(); ?>images/organization_logo.png">
											<div onclick="uploadShow();" class="upload-btn">Image Upload</div>
										</div>	
										<div id="uploadLogo" class="imageUpload"">
											<form enctype="multipart/form-data" method="post" id="frmUploadLogo" action="<?php echo base_url(); ?>analysts/organizations/upload_organization_logo">
												<div class="form-group">
													<input type="file" name="organization_logo" id="orgUploadLogo" class="form-control" data-icon="false">
												</div>
												<div style="text-align:center">
													<button type="button" class="btn btn-danger btn-sm" onclick="uploadLogo()"><span class="glyphicon glyphicon-upload"></span> Upload Logo</button>
													<br/>
													<img src="http://localhost/demo/images/image_upload.gif" width="128" height="15" id="imageUploadProgressBar" style="display:none">
												</div>
											</form>	
											<br /><br />
											<div align="center" id="mediumImageContainer" style="display:none">
												<p class="imageUploadText">Thumbnail</p>
												<img id="thumbnail" src="upload_pic/resized_pic.jpg" style="float: left; margin-right: 10px;" alt="Create Thumbnail" />
												<div style="float:left; position:relative; overflow:hidden; width:100px; height:100px;">
													<p class="imageUploadText">Preview</p>
													<img id="smallImage" src="upload_pic/resized_pic.jpg" style="position: relative;" alt="Thumbnail Preview" />
												</div>
												<br style="clear:both;"/>
												<form name="thumbnail"  action="<?php echo base_url()?>analysts/organizations/crop_image" method="post">
													<input type="hidden" name="x1" value="" id="x1" />
													<input type="hidden" name="y1" value="" id="y1" />
													<input type="hidden" name="x2" value="" id="x2" />
													<input type="hidden" name="y2" value="" id="y2" />
													<input type="hidden" name="w" value="" id="w" />
													<input type="hidden" name="h" value="" id="h" />
													<input type="hidden" name="thumbImagePath" value="" id="thumbImagePath" />
													<input type="submit" class="button" name="upload_thumbnail" value="Save Thumbnail" id="save_thumb" />
												</form>
											</div>
										</div>
										<iframe id="imageUploaderFrame" name="imageUploaderFrame" style="display:none"></iframe>	
		                  			</div> 
		                  		</div>	
	                  		</div>
	                  		<div class="col-md-9">
	                  				<div class="panel panel-default"> 
										 <div class="panel-heading"> <h3 class="panel-title">Add New Organization Profile</h3> </div> 
										 <div id="editKolForm" class="panel-body">
										     <form action="save_organization" method="post" id="organizationForm" name="organizationForm" class="validateForm form-horizontal">      
										     <input type="hidden" name="org_id" id="orgId" value="<?php echo $arrOrganization['id'];?>"></input>
										     <input type="hidden" name="form_type" id="formType" value="form_org_info"></input>
										     <div class="msgBoxContainer"><div class="orgMsgBox"></div></div>
										            <div class="form-group">
														<div class="col-md-4">
															<label class="control-label">Profile Type <span class="required">*</span> :</label>
															<select name="profile_type" id="profile_type" class="form-control required">
																<option value="Basic"  <?php if($arrOrganization['profile_type']==BASIC){?>selected="selected" <?php }?>>Basic</option>
																<option value="Full Profile" <?php if($arrOrganization['profile_type']==FULL){?> selected="selected" <?php }?>>Full Profile</option>
											    			</select>
														</div>
													</div>
									                <div class="form-group">
														<div class="col-md-6">
															<label class="control-label">Name <span class="required">*</span> :</label>
															<input type="text" name="name" value="<?php echo $arrOrganization['name'];?>" id="orgName" maxlength="100" class="form-control required"/>
														</div>
														<div class="col-md-6">
															<label class="control-label">Type :</label>
															<select name="type_id" id="orgType" class="form-control">
															<option value="0">--- Select ---</option>
															<?php 
																foreach($arrOrganizationTypes as $key => $value){
																if($key == $arrOrganization['type_id'])
																	echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
																else
																	echo '<option value="'.$key.'">'.$value.'</option>';
																}
															?>
													    	</select>
														</div>
													</div>
													<div class="form-group">
														<div class="col-md-6">
															<label class="control-label">Founded :</label>
															<input type="text" name="founded" id="orgFounded" class="form-control" value="<?php echo $arrOrganization['founded'];?>"/>
															</div>
														<div class="col-md-6">
															<label class="control-label">Website :</label>
															<input type="text"  name="website" id="orgWebsite" class="url form-control" value="<?php echo $arrOrganization['website'];?>"/>
														</div>
													</div>
													<div class="form-group">
														<div class="col-md-6">
															<label class="control-label">Company Headquarters :</label>
															<input type="text" name="headquarters" id="orgHeadquarters" class="form-control" value="<?php echo $arrOrganization['headquarters'];?>"/>
														</div>
													</div>
													<div class="form-group">
														<div class="col-md-12">
															<label class="control-label">Products & Services :</label>
															<textarea name="products_services" id="orgProducts" class="form-control" rows="2" cols="3"><?php echo $arrOrganization['products_services'];?></textarea>
														</div>
													</div>
													<div class="form-group">
														<div class="col-md-12">
															<label class="control-label">Company Background :</label>
															<textarea name="background" id="orgBackground" class="form-control" rows="2" cols="3"><?php echo $arrOrganization['background'];?></textarea>
														</div>
													</div>
													<div class="form-group">
														<div class="col-md-12">
															<label class="control-label">Mission, Vision & Values :</label>
															<textarea name="mission_vision" id="orgMission" class="form-control" rows="2" cols="3"><?php echo $arrOrganization['mission_vision'];?></textarea>
														</div>
													</div>
													<div style="text-align: center;">
														<button type="button" name="submit" id="saveAbout" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-save"></span> Save</button>
													</div>
										        </form>
										  </div> 
									</div>
	                  		</div>
	                  </div>
	       			 <!-- End Tab panels -->      
               </div> 
          <?php
			break;
			case 'address':
				?>
        	   <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">Address</a></li>
               </ul>
			   <!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               		<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrOrganization['name']; ?></h5>
               </div>
        		<!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="prof_info">
                  			<div class="panel panel-default"> 
								 <div class="panel-heading"> <h3 class="panel-title">Company Address</h3> </div> 
								 <div class="panel-body">
								 <form action="save_organization" method="post" id="organizationForm" name="organizationForm" class="validateForm form-horizontal">
							    		<input type="hidden" name="org_id" id="orgId" value="<?php echo $arrOrganization['id'];?>"></input>
							    		<input type="hidden" name="form_type" id="formType" value="form_org_address"></input>
							    		<div class="msgBoxContainer"><div class="orgMsgBox"></div></div>
							    		<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Address :</label>
												<input type="text" name="address" value="<?php echo $arrOrganization['address'];?>" id="orgAddress" class="form-control"/>
											</div>
											<div class="col-md-6">
												<label class="control-label">Country :</label>
												<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="form-control">
													<option value="">-- Select --</option>
														<?php 
														foreach( $arrCountry as $country){
															if($country['country_id'] == $arrOrganization['country_id'])
																echo '<option value="'.$country['country_id'].'" selected="selected">'.$country['country_name'].'</option>';
															else
																echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
														}
														?>
												</select>
											</div>
										</div>
						                <div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Fax :</label>
												<input type="text" name="fax" value="<?php echo $arrOrganization['fax'];?>" id="orgFax" class="form-control" onkeyup="allowNumericOnly(this)"/>
											</div>
											<div class="col-md-6">
												<label class="control-label">State / Province :</label>
												<select name="state_id" id="state_id" class="form-control" onchange="getCitiesByStateId();">		
													<option>-- Select State --</option>
													<?php 
													foreach( $arrStates as $state){
														if($state['state_id'] == $arrOrganization['state_id'])
															echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
														else
															echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
													}
													?>
												</select>
												<img id="loadingStates" src="<?php echo base_url()?>images/ajax_loader_black.gif" style="display:none"/>
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Phone :</label>
												<input type="text" name="orgphone" value="<?php echo $arrOrganization['phone'];?>" id="orgPhone" class="form-control" onkeyup="allowNumericOnly(this)"/>
												</div>
											<div class="col-md-6">
												<label class="control-label">City :</label>
												<select name="city_id" id="city_id" class="form-control">
													<option>-- Select City --</option>
													<?php 
													foreach( $arrCities as $city){
														if($city['city_id'] == $arrOrganization['city_id'])
															echo '<option value="'.$city['city_id'].'" selected="selected">'.$city['city_name'].'</option>';
														else
															echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
													}
													?>												
												</select>
												<img id="loadingCities" src="<?php echo base_url()?>images/ajax_loader_black.gif" style="display:none"/>
											</div>
										</div>
										<div class="form-group">
											<div class="col-md-6">
												<label class="control-label">Postal Code :</label>
												<input type="text" name="postal_code" value="<?php echo $arrOrganization['postal_code'];?>" id="orgPostalCode" class="form-control"/>
											</div>
										</div>
										<div style="text-align: center;">
											<button type="button" name="submit" id="saveAddress" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-save"></span> Save</button>
										</div>
										</form>
								  </div> 
							</div>	
							<div class="panel panel-default"> 
	                  			<div class="panel-heading"> <h3 class="panel-title">Add Contact details</h3> </div> 
	                  			<div class="panel-body">
	                  				<div class="form-group">
									<div class="col-md-6">
										<label class="control-label">Related To <span class="required">*</span> :</label>
										<input type="hidden" name="id" id="contactId" value=""></input>
										<input type="text" name="related_to" value="" id="contactRelatedTo" class="form-control"/>
									</div>
									<div class="col-md-5">
										<label class="control-label">Phone No :</label>
										<input type="text" name="phone" value="" id="contactPhone" onkeyup="allowNumericOnly(this)"  class="form-control"/>
									</div>
									<div class="col-md-1">
										<button type="button" name="submit" id="saveOrgContact" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-plus-sign"></span> Add</button>
									</div>
								</div>
	                  			</div> 
                  		</div>	
                  		</div>
       			 <!-- End Tab panels -->      
               </div> 
          <?php
			break;
			case 'media':
				?>
        	   <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">Social Media Links</a></li>
               </ul>
			   <!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               		<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrOrganization['name']; ?></h5>
               </div>
        		<!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="prof_info">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading">
									<h3 class="panel-title"><a class="colpsible-panel" data-toggle="collapse" data-parent="#accordion" href="#collapse3" title="Click to Expand">Add Social Networking Links</a></h3> 
	                  				</a>
	                  			</div> 
	                  			<div id="collapse3" class="panel-collapse">
	                  			<div class="panel-body">
	                  				<div class="col-md-8 col-md-offset-2">
		                  				<form action="save_organization" method="post" id="organizationForm" name="organizationForm" class="validateForm form-horizontal">
									 	   	<input type="hidden" name="org_id" id="orgId" value="<?php echo $arrOrganization['id'];?>"></input>
									 	   	<input type="hidden" name="form_type" id="formType" value="form_org_social"></input>
											<div class="msgBoxContainer"><div class="orgMsgBox"></div></div> 	
											 	<div class="analystForm" id="socialTbl">
											 		<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/blogger.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="blog" value="<?php echo $arrOrganization['blog'];?>" id="mediaBlog" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/facebook.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="facebook" value="<?php echo $arrOrganization['facebook'];?>" id="mediaFacebook" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/twitter.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="twitter" value="<?php echo $arrOrganization['twitter'];?>" id="mediaTwitter" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/youtube.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="youtube" value="<?php echo $arrOrganization['youtube'];?>" id="mediaYouTube" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<button type="button" name="submit" id="saveMedia" class="btn btn-primary col-sm-offset-4"><span class="glyphicon glyphicon-save"></span> Save</button>
													</div>
											 	</div>
										 </form>
	                  				</div>
	                  			</div> 
	                  			</div>
	                  		</div>		
                  		</div>
       			 <!-- End Tab panels -->      
               </div> 
          <?php
			break;
			case 'keyPeople':
				?>
        	   <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Overview" class="active"><a href="#prof_info" aria-controls="prof_info" role="tab" data-toggle="tab">key People</a></li>
               </ul>
			   <!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               		<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrOrganization['name']; ?></h5>
               </div>
        		<!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="prof_info">
                  			<div class="panel panel-default"> 
								 <div class="panel-heading"> <h3 class="panel-title">Add Key People</h3> </div> 
								 <div id="editKolForm" class="panel-body">
								     <form action="<?php echo base_url()?>analysts/organizations/save_key_people" id="keyPeopleForm" name="keyPeopleForm" class="validateForm form-horizontal">      
								 			<div class="msgBoxContainer"><div class="keyPplMsgBox"></div></div>
								            <input type="hidden" name="org_id" id="orgId" value="<?php echo $arrOrganization['id'];?>"></input>
											<input type="hidden" name="id"  value="" id="keyPeopleId"></input>
								            <div class="form-group">
												<div class="col-md-6">
													<label class="control-label">Role :</label>
													<select name="role_id" id="keyRole" class="form-control required">
														<option value="">--- Select ---</option>
														<?php 
														foreach($arrKeyPeopleRoles as $key => $value){
														if($key == $arrOrganization['role'])
															echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
														else
															echo '<option value="'.$key.'">'.$value.'</option>';
														}
														?>
													</select>
												</div>
												<div class="col-md-6">
													<label class="control-label">Salutation :</label>
													<select name="salutation" id="keySalutation" class="form-control required">
														<option value="">--- Select ---</option>
														<?php 
														foreach($arrSalutations as $key => $value){
														if(isset($arrOrganization['salutation']) && $key == $arrOrganization['salutation'])
															echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
														else
															echo '<option value="'.$key.'">'.$value.'</option>';
														}
														?>
											    	</select>
												</div>
											</div>
							                <div class="form-group">
												<div class="col-md-6">
													<label class="control-label">First Name :</label>
													<input type="text" name="first_name" value="" id="keyFirstName" maxlength="30" class="form-control required"></input>
													
												</div>
												<div class="col-md-6">
													<label class="control-label">Middle Name :</label>
													<input type="text" name="middle_name" value="" id="keyMiddleName" class="form-control" maxlength="30"></input>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-6">
													<label class="control-label">Last Name :</label>
													<input type="text" name="last_name" value="" id="keyLastName" class="form-control" maxlength="30"></input>
													</div>
												<div class="col-md-6">
													<label class="control-label">Title :</label>
													<input type="text" name="title" value="" id="keyTitle" class="form-control"></input>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-6">
													<label class="control-label">Email :</label>
													<input type="text" name="email" value="" id="keyEmail" class="form-control email" maxlength="30"></input>
												</div>
											</div>
											<div style="text-align: center;">
												<button type="button" name="submit" id="saveKeyPeople" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-save"></span> Save</button>
							
											</div>
								        </form>
								  </div> 
							</div>	
							<!-- Generic Grid Panel to load all four respective grid content --> 
								<div class="col-md-12 gridData">
					                 <!-- Start of JQGrid based Table to list Key People Results -->
									<div class="gridWrapper">
										<table id="JQBlistKeyPeopleResultSet"></table>
										<div id="listKeyPeoplePage"></div>
									</div>
					            </div>
							 <!-- End of Grid Panel -->   	
                  		</div>
       			 <!-- End Tab panels -->      
               </div> 
          <?php
			break;
		} ?>   
        </div>
	</div>
</div>
