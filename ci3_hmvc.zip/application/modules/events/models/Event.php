<?php
class event extends CI_Model {
	function getAllConferenceEventTypes(){
		$arrEventTypes	= array();
		$this->db->order_by('event_type','asc');
		$arrEventTypesResult = $this->db->get('conf_event_types');
		$otherId	= 0;
		foreach($arrEventTypesResult->result_array() as $arrEventType){
			//check if the event type is 'Other' and add it last in the list
			if($arrEventType['event_type'] == 'Other'){
				$otherId	= $arrEventType['id'];
			}else{
				$arrEventTypes2[$arrEventType['id']]	= $arrEventType['event_type'];
			}
		}
		$arrEventTypes	= $arrEventTypes2;
		if($otherId>0){
			$arrEventTypes[$otherId]	= 'Other';
		}
		return $arrEventTypes;
	}
	function deleteEventById($id) {
		$this->db->where('id', $id);
		$this->db->select('kol_id,type');
		$this->db->where('id',$id);
		$queryRes = $this->db->get('kol_events');
		$row = $queryRes->row();
		if (isset($row))
		{
			$kolId = $row->kol_id;
			$type = $row->type;
		}
		$this->db->where('id',$id);
		if ($query = $this->db->delete('kol_events')){
			return true;
		}else{
			return false;
		}
	}
	function getEventLookupName($id) {
		$eventName = '';
		$this->db->select('name');
		$this->db->where('id', $id);
		$eventNameRusult = $this->db->get('events');
		foreach ($eventNameRusult->result_array() as $row) {
			$eventName = $row['name'];
		}
		return $eventName;
	}
	function getAllConferenceSessionTypes(){
		$arrSessionTypes	= array();
		$this->db->order_by('session_type','asc');
		$arrSessionTypesResult = $this->db->get('conf_session_types');
		foreach($arrSessionTypesResult->result_array() as $arrSessionType){
			$arrSessionTypes[$arrSessionType['id']]	= $arrSessionType['session_type'];
		}
		return $arrSessionTypes;
	}
	function getSponsorTypes(){
		$arrSponsorTypes	= array();
		
		$arrSponsorTypesResult = $this->db->get('event_sponsor_types');
		foreach($arrSponsorTypesResult->result_array() as $arrSponsorType){
			$arrSponsorTypes[$arrSponsorType['id']]	= $arrSponsorType['type'];
		}
		return $arrSponsorTypes;
	}
	function getOrganizerTypes(){
		$arrOrganizerTypes	= array();
		
		$arrOrganizerTypesResult = $this->db->get('event_organizer_types');
		foreach($arrOrganizerTypesResult->result_array() as $arrOrganizerType){
			$arrOrganizerTypes[$arrOrganizerType['id']]	= $arrOrganizerType['type'];
		}
		return $arrOrganizerTypes;
	}
	function getConferenceEventTypeById($eventTypeId){
		$eventType='';
		if($eventTypeId != ''){
			$this->db->where('id', $eventTypeId);
			$this->db->select('event_type');
			$eventType	= $this->db->get('conf_event_types');
			foreach($eventType->result_array() as $row){
				$eventType = $row['event_type'];
			}
		}
		return $eventType;
	}
	function getConferenceSessionTypeById($sessionTypeId){
		$sessionType='';
		if($sessionTypeId !=''){
			$this->db->where('id', $sessionTypeId);
			$this->db->select('session_type');
			$sessionType	= $this->db->get('conf_session_types');
			foreach($sessionType->result_array() as $row){
				$sessionType = $row['session_type'];
			}
		}
		return $sessionType;
	}	
	function getEventLookupNames($category, $eventName) {
		$this->db->select('events.id,events.name');
		//$this->db->where('category', $category);
		$this->db->like('name', $eventName);
		$this->db->join('kol_events', 'kol_events.event_id=events.id', 'inner');
		$this->db->join('kols', 'kol_events.kol_id=kols.id', 'inner');
		//         $this->db->where('kols.status', COMPLETED);
		$this->db->group_by('events.id');
		$arrResultSet = $this->db->get('events');
		
		$arrEventLookupNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrEventLookupNames[$arrRow['id']] = $arrRow['name'];
		}
		
		return $arrEventLookupNames;
	}
	function listEvents($type, $kolId = null, $startDate, $endDate, $startFrom = null, $limit = null,$sortByYear=false) {
		$clientId = $this->session->userdata('client_id');
		$arrEventsDetails = array();
		//Get the Events of KolId
		if ($kolId != null) {
			$this->db->where('kols_client_visibility.kol_id', $kolId);
			$this->db->where('kol_events.type', $type);
			if ($startDate != 0 && $endDate != 0) {
				$wherBetween = "(YEAR(start) BETWEEN '$startDate' AND '$endDate' OR YEAR(start)='0')";
				$this->db->where($wherBetween);
			}
			if ($type == 'conference') {
				$this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'states.name as Region', 'cities.City', 'conf_session_types.session_type', 'conf_event_types.event_type', 'event_topics.name as topic_name','client_users.first_name','client_users.last_name'));
				$this->db->join('events', 'events.id = event_id', 'left');
				$this->db->join('countries', 'CountryId = country_id', 'left');
				$this->db->join('states', 'states.id = state_id', 'left');
				$this->db->join('cities', 'cityId = city_id', 'left');
				$this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
				$this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
				$this->db->join('event_topics', 'kol_events.topic = event_topics.id', 'left');
				$this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
				$this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
			} else {
				$this->db->select(array('kol_events.*', 'online_event_types.event_type', 'events.name', 'kol_events.event_type as onEventTypeId'));
				$this->db->join('events', 'events.id = event_id', 'left');
				$this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
			}
			$this->db->join('client_users', 'client_users.id = kol_events.created_by',"left");
		}
		if ($limit != null)
			$this->db->limit($limit, $startFrom);
			
// 		if ($clientId != INTERNAL_CLIENT_ID) {
// 			$this->db->where("(kol_events.client_id=$clientId or kol_events.client_id=" . INTERNAL_CLIENT_ID . ")");
// 		}
			$this->db->join('kols_client_visibility', 'kols_client_visibility.id = kol_events.kol_id', 'left');
			$this->db->join('kols', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where("kols_client_visibility.client_id=$clientId");
		if($sortByYear){
			$this->db->order_by('kol_events.end','desc');
		}else{
			$this->db->order_by('conf_event_types.event_type','asc');
			$this->db->order_by('events.name','asc');
		}
		if ($arrEventsDetailsResult = $this->db->get('kol_events')) {
			foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
				$arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
				if ($arrEvent['start'] == '00/00/0000') {
					$arrEvent['start'] = '';
				}
				$arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
				if ($arrEvent['end'] == '00/00/0000') {
					$arrEvent['end'] = '';
				}
				if ($arrEvent['url1'] != '') {
					$arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
				}
				if ($arrEvent['url2'] != '') {
					$arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
				}
				$arrEvent['eAllowed'] =  $this->common_helper->isActionAllowed('kol_details', 'edit', $arrEvent);
				$arrEventsDetails[] = $arrEvent;
			}
			return $arrEventsDetails;
		} else {
			return false;
		}
	}
	function convertDateToMM_DD_YYYY($inputDate, $delimiter = '/') {
		$ddDate = substr($inputDate, 8, 2);
		$mmDate = substr($inputDate, 5, 2);
		$yyDate = substr($inputDate, 0, 4);
		return ($mmDate . $delimiter . $ddDate . $delimiter . $yyDate);
	}
	function getTopicName($topicId) {
		$topicName = "";
		$this->db->where('id', $topicId);
		$result = $this->db->get('event_topics');
		if ($result->num_rows() != 0) {
			$resultObject = $result->row();
			$topicName = $resultObject->name;
		}
		return $topicName;
	}
	function getEventById($eventId) {
		$arrEventDetails = array();
		$clientId = $this->session->userdata('client_id');
		$this->db->where('kol_events.id', $eventId);
		$this->db->select(array('event_sponsor_types.type as sponsor_type', 'event_sponsor_types.type as sponsor_type_name', 'kol_events.*', 'events.name as event_name', 'conf_event_types.event_type as conf_event_type', 'countries.country', 'event_topics.name as event_topic','event_topics.specialty_id as et_specialty_id', 'conf_session_types.session_type as conf_session_type', 'states.name','client_users.first_name','client_users.last_name'));
		//$this->db->select(array('event_sponsor_types.type as sponsor_type', 'event_sponsor_types.type as sponsor_type_name', 'kol_events.*', 'events.name', 'conf_event_types.event_type as conf_event_type', 'countries.country', 'event_topics.name as event_topic', 'conf_session_types.session_type as conf_session_type', 'regions.region'));
		$this->db->join('events', 'events.id = kol_events.event_id', 'left');
		//$this->db->join('conf_event_types','conf_event_types.id = kol_events.event_type', 'left');
		$this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
		$this->db->join('states', 'states.id = kol_events.state_id', 'left');
		$this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
		$this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
		$this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
		$this->db->join('event_sponsor_types', 'event_sponsor_types.id = kol_events.sponsor_type', 'left');
		$this->db->join('client_users', 'client_users.id = kol_events.created_by', 'left');
		if ($clientId != INTERNAL_CLIENT_ID) {
			//$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$arrEventDetailsResult = $this->db->get('kol_events');
		foreach ($arrEventDetailsResult->result_array() as $arrRow) {
			$arrEventDetails = $arrRow;
		}
		return $arrEventDetails;
	}
	function getEventRoles() {
		$this->db->order_by('role asc');
		$arrResultSet = $this->db->get('event_roles');
		foreach ($arrResultSet->result_array() as $row) {
			$arrRoles[$row['id']] = $row['role'];
		}
		return $arrRoles;
	}
	function getTopicsBySpecialty($specialtyId) {
		$arrTopics = array();
		$this->db->where('specialty_id', $specialtyId);
		$this->db->order_by("name", "asc");
		$result = $this->db->get('event_topics');
		foreach ($result->result_array() as $row) {
			$arrTopics[$row['id']] = $row;
		}
		return $arrTopics;
	}
	function getEventIdElseSave($eventDetails) {
		if ($eventDetails['name'] != null) {
			$this->db->select('id');
			$this->db->where('name', $eventDetails['name']);
			$arrResultSet = $this->db->get('events');
			if ($arrResultSet->num_rows() == 0) {
				$eventDetails['created_by'] = $this->session->userdata('user_id');
				$eventDetails['created_on'] = date("Y-m-d H:i:s");
				$this->db->insert('events', $eventDetails);
				return $this->db->insert_id();
			}
			$arrEventId = array();
			foreach ($arrResultSet->result_array() as $arrRow) {
				return $arrRow['id'];
			}
		}else
			return false;
	}
	function getEventsYearsRange($kolId) {
		$arrYears = array();
		$arrYears['min_year'] = '';
		$arrYears['max_year'] = '';
		$arrResults = $this->db->query("SELECT MIN(year(start)) AS min_year, max(year(start)) AS max_year
				FROM kol_events
				WHERE (year(start))!=0 AND kol_id=$kolId");
		foreach ($arrResults->result_array() as $row) {
			$arrYears['min_year'] = $row['min_year'];
			$arrYears['max_year'] = $row['max_year'];
		}
		return $arrYears;
	}
	function getEventsBySessionType($arrKolId = 0, $fromYear = 0, $toYear = 0, $role = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
		//pr($arrCountries);
		$arrEvents = array();
		$isKolsJoined = false;
		
		$this->db->select('conf_session_types.session_type,count(*) as count');
		$this->db->join('conf_session_types', 'conf_session_types.id=kol_events.session_type', 'left');
		$this->db->where_not_in('kol_events.session_type', 0);
		
		if (is_array($arrKolId)) {
			$this->db->where_in('kol_events.kol_id', $arrKolId);
		} else if ($arrKolId != 0) {
			$this->db->where('kol_events.kol_id', $arrKolId);
		}
		
		if ($role != '') {
			$this->db->where('kol_events.role', $role);
		}
		
		//Adding where condition for Country's if Exist
		if (is_array($arrCountries)) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where_in('kols.country_id', $arrCountries);
		} else if ($arrCountries != 0) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where('kols.country_id', $arrCountries);
		}
		if (is_array($arrStates)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.state_id', $arrStates);
		}else if ($arrStates != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.state_id', $arrStates);
		}
		
		//Adding where condition for Speciality's if Exist
		if (is_array($arrSpecialities)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.specialty', $arrSpecialities);
		}else if ($arrSpecialities != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.specialty', $arrSpecialities);
		}
		
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata('user_id');
			$clientId = $this->session->userdata('client_id');
			$this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
			$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
			$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
			$this->db->where_in('list_names.id', $arrListNamesIds);
			$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
		}
		
		if ($isKolsJoined) {
			//$this->db->where('kols.status', COMPLETED);
		} else {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			// $this->db->where('kols.status', COMPLETED);
		}
		if ($fromYear != 0 && $toYear != 0)
			$this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
			//	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
			$this->db->group_by('kol_events.session_type');
			
			$arrEventsresult = $this->db->get('kol_events');
			//echo $this->db->last_query();
			foreach ($arrEventsresult->result_array() as $row) {
				$arrEvents[] = $row;
			}
			return $arrEvents;
	}
	function getDataForEventsTopicChart($kolId, $startYear, $endYear) {
		$arrTopics = array();
		$this->db->select('event_topics.name,count(event_topics.name) as count,event_topics.id');
		$this->db->join('event_topics', 'kol_events.topic=event_topics.id', 'left');
		$this->db->where('kol_events.kol_id', $kolId);
		if ($startYear != 0 && $endYear != 0)
			$this->db->where("((year(start) between $startYear and $endYear) or year(start)=0)");
		$this->db->where('kol_events.topic !=', 'null');
		$this->db->where('event_topics.name !=', 'null');
		$this->db->group_by('event_topics.name');
		$this->db->order_by('count', 'desc');
		$arrResult = $this->db->get('kol_events');
		foreach ($arrResult->result_array() as $row) {
			$arrTopics[] = $row;
		}
		return $arrTopics;
	}
	function getEventsByRole($arrKolId = 0, $fromYear = 0, $toYear = 0, $sessionType = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
		$arrEvents = array();
		$isKolsJoined = false;
		
		$this->db->select('kol_events.role,COUNT(kol_events.role) as count');
		$this->db->where_not_in('kol_events.role', '');
		
		if (is_array($arrKolId)) {
			$this->db->where_in('kol_events.kol_id', $arrKolId);
		} else if ($arrKolId != 0) {
			$this->db->where('kol_events.kol_id', $arrKolId);
		}
		//Adding where condition for Country's if Exist
		if (is_array($arrCountries)) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where_in('kols.country_id', $arrCountries);
		} else if ($arrCountries != 0) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where('kols.country_id', $arrCountries);
		}
		
		if (is_array($arrStates)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.state_id', $arrStates);
		}else if ($arrStates != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.state_id', $arrStates);
		}
		
		//Adding where condition for Speciality's if Exist
		if (is_array($arrSpecialities)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.specialty', $arrSpecialities);
		}else if ($arrSpecialities != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.specialty', $arrSpecialities);
		}
		
		if ($sessionType != '') {
			$this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
			$this->db->where('conf_session_types.session_type', $sessionType);
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata('user_id');
			$clientId = $this->session->userdata('client_id');
			$this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
			$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
			$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
			$this->db->where_in('list_names.id', $arrListNamesIds);
			$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
		}
		
		if ($isKolsJoined) {
			// $this->db->where('kols.status', COMPLETED);
		} else {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			//$this->db->where('kols.status', COMPLETED);
		}
		if ($fromYear != 0 && $toYear != 0)
			$this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
			//	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
			$this->db->where_not_in('kol_events.role', '');
			$this->db->group_by('kol_events.role');
			
			if ($arrEventsresult = $this->db->get('kol_events')) {
				
				foreach ($arrEventsresult->result_array() as $row) {
					$arrEvents[] = $row;
				}
				//echo $this->db->last_query();
				return $arrEvents;
			}
	}
	function getEventsBySponsorType($arrKolId = 0, $fromYear = 0, $toYear = 0, $role = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
		//pr($arrCountries);
		$arrEvents = array();
		$isKolsJoined = false;
		
		$this->db->select('event_sponsor_types.type,count(*) as count');
		$this->db->join('event_sponsor_types', 'event_sponsor_types.id=kol_events.sponsor_type', 'left');
		$this->db->where_not_in('kol_events.sponsor_type', 0);
		
		if (is_array($arrKolId)) {
			$this->db->where_in('kol_events.kol_id', $arrKolId);
		} else if ($arrKolId != 0) {
			$this->db->where('kol_events.kol_id', $arrKolId);
		}
		
		if ($role != '') {
			$this->db->where('kol_events.role', $role);
		}
		
		//Adding where condition for Country's if Exist
		if (is_array($arrCountries)) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where_in('kols.country_id', $arrCountries);
		} else if ($arrCountries != 0) {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			$isKolsJoined = true;
			$this->db->where('kols.country_id', $arrCountries);
		}
		if (is_array($arrStates)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.state_id', $arrStates);
		}else if ($arrStates != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.state_id', $arrStates);
		}
		
		//Adding where condition for Speciality's if Exist
		if (is_array($arrSpecialities)) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where_in('kols.specialty', $arrSpecialities);
		}else if ($arrSpecialities != 0) {
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->where('kols.specialty', $arrSpecialities);
		}
		
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$userId = $this->session->userdata('user_id');
			$clientId = $this->session->userdata('client_id');
			$this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
			$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
			$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
			$this->db->where_in('list_names.id', $arrListNamesIds);
			$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
		}
		
		if ($isKolsJoined) {
			//$this->db->where('kols.status', COMPLETED);
		} else {
			$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
			//$this->db->where('kols.status', COMPLETED);
		}
		if ($fromYear != 0 && $toYear != 0)
			$this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
			//	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
			$this->db->group_by('kol_events.sponsor_type');
			
			$arrEventsresult = $this->db->get('kol_events');
			//		echo $this->db->last_query();
			foreach ($arrEventsresult->result_array() as $row) {
				$arrEvents[] = $row;
			}
			return $arrEvents;
	}
	function getEventLoaction($kolId) {
		$this->db->select('cities.city,cities.Latitude,cities.Longitude');
		$this->db->join('cities', 'cities.CityId=kol_events.city_id', 'inner');
		$this->db->where('kol_id', $kolId);
		$this->db->group_by('city');
		$this->db->order_by('kol_events.end', 'desc');
		//$this->db->limit(1,0);
		$arrResult = $this->db->get('kol_events');
		//print $this->db->last_query();exit;
		foreach ($arrResult->result_array() as $row) {
			$arrEvents[] = $row;
		}
		return $arrEvents;
	}
}
?>