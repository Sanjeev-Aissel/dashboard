<?php

?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php if(isset($title) && $title!=null) { echo $title; } else { echo PRODUCT_VERSION; }?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<!-- <link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/> -->
	<?php echo $this->load->view('elements/favicon');?>
	
	<link type="text/css" href="<?php echo base_url()?>css/login1.css"  rel="stylesheet" />
	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	<?php //flush();?>
</head>
<body>
<style type="text/css">
.password_reset_block {
	background: white; 
	border:2px solid #FFFFFF; 
	width: 550px; 
	height: 150px; 
	border-radius: 10px; 
	margin: 5% auto; 
	margin-left: auto; 
	margin-right: auto; 
	min-height: 200px;
}

.reset_message {
	color: #717072; 
	padding: 5px;
	margin: 0;
	font-family: arial;
    font-size: 11px;
}

.resetpwd_header{
    border-bottom: 1px solid #D7D9DA;
    color: #0070BD;
	font-family: trebuchet ms;
    font-size: 28px;
    margin-bottom: auto;
    margin-left: 4%;
    margin-right: 4%;
    margin-top: 1px;
    padding-bottom: 5px;
    padding-left: 0;
    padding-right: 5px;
    padding-top: 18px;
    width: 495px;
}

.content-inner{
	min-height: 435px;
}

#loginWrapper {
    background: none;
    height: 275px;
}

#container{background: none repeat scroll 0 0 white;
    border: 2px solid #FFFFFF;
    border-radius: 10px 10px 10px 10px;
    height: 150px;
    margin: 5% auto;
    min-height: 200px;
    width: 550px;
    
    }
    
    table{
    margin-left: 18px; 
    margin-top: 20px;
    }
    
   .forgot_pwd_msg{
 	  margin-left: 22px;
    margin-top: 5px;
    }
</style>
	<div>
		<div class="headerBG"><h2 class="productName"><?php echo PRODUCT_VERSION ?></h2></div>
			<div id="loginContainer">
				<div id="loginWrapper">
						<div id="container">
						
			
						<?php echo $this->load->view($contentPage)?>
			
					</div>
				</div>
			</div>
			<div class="headerBG"><h1>&nbsp;</h1></div>
			<div id="loginFooter">
				&nbsp;&nbsp;<img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" style="float:right;" />&nbsp;&nbsp;
				<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | <?php echo PRODUCT_NAME.' '.PRODUCT_VERSION;?> Copyright &copy; 2012 <a href="http://www.aissel.com" target="new">Aissel</a> Solutions | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
			</div>
	</div>
</body>
</html>






