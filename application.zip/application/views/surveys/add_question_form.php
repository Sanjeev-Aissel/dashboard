<?php 
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 21-03-2013
 *  
 */
?>
<style type="text/css">
	select.chosenSelect{
		width:200px;
	}
	#saveSurvey, #backToSurvey, #saveAndAssignToSurvey{
		padding: 4px 17px 23px;
	}
	th, td, caption {
	    padding: 4px 1px 4px 5px;
	}
	#msg{
    	text-align: center;
	}
	#surveyAddForm .contentHeader span{
		padding: 2px 10px;
	}
</style>
<script type="text/javascript">
function saveSurveyData(assignToSurvey){
	var categoryId	= $('#category').val();
	var roleId		= $('#role').val();
	var typeId		= $('#type').val();
	var question	= $('#question').val();
	var is_enabled	= $('input:radio[name="isEnabled"]:checked').val();
	if(roleId!='' && categoryId!='' && question!=''){
		$.ajax({
			type: "post",
			dataType:"json",
			data:{
		        'category_id':categoryId,
		        'role_id':roleId,
		        'type_id':typeId,
		        'question':question,
		        'is_enabled':is_enabled
		    },
			url: '<?php echo base_url();?>surveys/save_question<?php if(isset($arrData[0]))echo "/".$arrData[0]['id'];?>',
			success: function(returnData){
				if(returnData.status=="failed"){
					$('#msg').css('color','#55CC99').html('Unable to save');
				}else{
					if(returnData.status=="exist"){
						$('#msg').css('color','#FF9999').html('Question already exist');
					}else{
						$('#msg').css('color','#FF9999').html('Successfully saved');
						var appendData	= '<label class="group'+returnData.category_id+'"><input type="checkbox" name="question_ids[]" value="'+returnData.id+'" />'+returnData.question+'</label>';
						if(assignToSurvey!=0){
							appendData	= '<label class="group'+returnData.category_id+'"><input type="checkbox" checked="checked" name="question_ids[]" value="'+returnData.id+'" />'+returnData.question+'</label>';
						}
						$('#surveyData #selectedQuestions').append(appendData);
						//$(appendData).insertAfter($('#surveyData #selectedQuestions #group'+returnData.category_id));
					}
					$("#surveyQuestionForm").trigger( "reset" );
					$('#category').val('Select Category');
					$('#category').trigger('liszt:updated');
					$('#role').val('Select Role');
					$('#role').trigger('liszt:updated');
					$('#type').val('1');
					$('#type').trigger('liszt:updated');
				}
			}
		});
	}else{
		jAlert('Please fill all mandatory fields which are marked with *');
	}
}
function backToSurveyForm(){
	//$('#surveyData').show();
	//$('#surveyQuestionData').hide();
	$("#addSurveyContainer").dialog("close");
}
$(document).ready(function(){
	$('.chosenSelect').chosen({allow_single_deselect: true});
	<?php	
			if(isset($arrData[0]['type_id'])){	?>
				$('#type').val(<?php echo $arrData[0]['type_id'];?>);
				$('#type').trigger('liszt:updated');
	<?php	}
			if(isset($arrData[0]['category_id'])){	?>
				$('#category').val(<?php echo $arrData[0]['category_id'];?>);
				$('#category').trigger('liszt:updated');
	<?php	}
			if(isset($arrData[0]['role_id'])){	?>
				$('#role').val(<?php echo $arrData[0]['role_id'];?>);
				$('#role').trigger('liszt:updated');
	<?php	}	?>
	$("#category").chosen().change(function() {
		if($(this).val()==0){
			var newCategoryname	= jPrompt('Enter new Category name');
			if(newCategoryname!=null && newCategoryname!=''){
				$.ajax({
					type: "post",
					dataType:"json",
					data:{
				        'category_name':newCategoryname
				    },
					url: '<?php echo base_url();?>surveys/save_category',
					success: function(returnData){
						if(returnData.status=="saved"){
							$('#category').append('<option value="'+returnData.id+'" selected="selected">'+newCategoryname+'</option>');
							var appendData	= '<label id="group'+returnData.id+'" class="group"><a onclick="toggleGroup(this); return false;" href="#">Select/Deselect All </a>Category - '+newCategoryname+'</label>';
							$(appendData).appendTo('.multiselect');
						}else if(returnData.status=="exist"){
							$('#category').val(returnData.id);
						}else{
							$('#category').val('Select Category');
						}
						$('#category').trigger('liszt:updated');
					}
				});
			}else{
				$('#category').val('Select Category');
				$('#category').trigger('liszt:updated');
			}
		}
	});
	$("#role").chosen().change(function() {
		if($(this).val()==0){
			var newRolename	= jPrompt('Enter new Role');
			if(newRolename!=null && newRolename!=''){
				$.ajax({
					type: "post",
					dataType:"json",
					data:{
				        'role_name':newRolename
				    },
					url: '<?php echo base_url();?>surveys/save_role',
					success: function(returnData){
						if(returnData.status=="saved"){
							$('#role').append('<option value="'+returnData.id+'" selected="selected">'+newRolename+'</option>');
							//var appendData	= '<label id="group'+returnData.id+'" class="group"><a onclick="toggleGroup(this); return false;" href="#">Select/Deselect All </a>Role - '+newRolename+'</label>';
							//$(appendData).appendTo('.multiselect');
						}else if(returnData.status=="exist"){
							$('#role').val(returnData.id);
						}else{
							$('#role').val('Select Role');
						}
						$('#role').trigger('liszt:updated');
					}
				});
			}else{
				$('#role').val('Select Role');
				$('#role').trigger('liszt:updated');
			}
		}
	});
	$('#surveyQuestionForm').submit(function (event){
		saveSurveyData('0');
		return false;
	});
});
</script>
<div id="surveyAddForm">
	<div class="contentHeader"><span><?php echo (isset($arrData[0])?'Edit':'Add');?> Survey Question</span></div>
	<div id="msg"></div>
	<form id="surveyQuestionForm" name="surveyQuestionForm" action="#" method="post">
		<table>
			<tr>
				<th class="alignRight">Category<span class="required">*</span>:</th>
				<td>
					<select id="category" name="category" class="chosenSelect">
						<option value="">Select Category</option>
						<?php 
							foreach($arrCategories as $name=>$id){
								echo '<option value="'.$id.'">'.$name.'</option>';
							}
						?>
						<option value="0">Add New Category</option>
					</select>
				</td>
			</tr>
			<tr>
				<th class="alignRight">Role<span class="required">*</span>:</th>
				<td>
					<select id="role" name="role" class="chosenSelect">
						<option value="">Select Role</option>
						<?php 
							foreach($arrRoles as $name=>$id){
								echo '<option value="'.$id.'">'.$name.'</option>';
							}
						?>
						<option value="0">Add New Role</option>
					</select>
				</td>
			</tr>
			<tr>
				<th class="alignRight">Type:</th>
				<td>
					<select id="type" name="type" class="chosenSelect">
						<?php 
							foreach($arrTypes as $id=>$name){
								echo '<option value="'.$id.'">'.$name.'</option>';
							}
						?>
					</select>
				</td>
			</tr>
			<tr>
				<th class="alignRight" style="vertical-align: top;">Survey Question<span class="required">*</span>:</th>
				<td>
					<textarea rows="5" id="question" name="question" style="width: 450px;"><?php if(isset($arrData[0]['question'])) echo $arrData[0]['question'];?></textarea>
				</td>
			</tr>
			<?php 
			//	$enable	= 0;
			//	if(isset($arrData[0]['is_enabled']) && $arrData[0]['is_enabled']==1) 
			//		$enable	= 1;
			?>
			<!--<tr>
				<th class="alignRight"><input type="radio" name="isEnabled" value="1" <?php echo (($enable)?'checked="checked"':'');?> />Active</th>
				<th><input type="radio" name="isEnabled" value="0" <?php echo (($enable)?'':'checked="checked"');?> />In Active</th>
			</tr>
			--><tr>
				<td colspan="2" class="alignCenter">
					<input id="saveSurvey" type="submit" value="Save" />
					<input id="saveAndAssignToSurvey" type="button" value="Save and assign to Survey" onclick="saveSurveyData('1'); return false;" />
					<input id="backToSurvey" type="button" value="Back to Survey" onclick="backToSurveyForm(); return false;" />
				</td>
			</tr>
		</table>
	</form>
</div>