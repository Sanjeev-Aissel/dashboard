<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Kols extends MX_Controller {
	private $loggedUserId = null;
	public function __construct()
	{
		parent::__construct();
		$this->loggedUserId = $this->session->userdata('user_id');
		$this->clientId		=$this->session->userdata('client_id');
	}
}
