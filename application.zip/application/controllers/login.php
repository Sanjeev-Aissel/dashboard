<?php
/**
 * Controller for the 'Login' module
 * @author Vinod
 * @since
 * @package application.controllers	
 * @created on 
 */
class Login extends Controller {
	var $CI;
	var $user_table = 'client_users';
	function Login()
	{
		parent::Controller();	
		$this->load->model('login_model');
		$this->load->library('SimpleLoginSecure');
		$this->load->model('Client_User');
		$this->load->model('common_helpers');
		//$this->output->cache(60);
	}
	
	function index()
	{
		// If the user has already logged in
		if($this->session->userdata('logged_in')) {
//	    	redirect('/kols/client_index');
	    	redirect('/kols/list_kols_client_view');
		}else{
			//for the 'PingOne SSO Authentication'
			// Refernece: https://connect.pingidentity.com/web-portal/appintegration?x=11h7gPucKN8
			/*
			define("SAASID","14abbaf3-9ea3-411f-9286-45bd17d9af53");
			
			$idpId = urlencode($this->getIdpId());
			$saasId = urlencode(SAASID);
			
			header("Location: https://sso.connect.pingidentity.com/sso/sp/initsso?saasid=$saasId&idpid=$idpId");
			exit;*/
			//Cache the login page for next 720 minutes i.e 1 day
		    //$this->output->cache(1440);
		    $data['contentPage'] = 'login/login';
		    $this->load->view('layouts/app_view', $data);
		}
	}
	
	/**
	 * Look up idpId for SSO - implement me!
	 */
	function getIdpId()
	{
	    //return "testidp.connect.pingidentity.com";
		return "Otsuka-iReport";
	}
	
	/**
	 * Logs the user into the application
	 */
	function do_login()
	{
		$userId	= trim($this->input->post('userid'));
		$password	= trim($this->input->post('password'));
// 		$this->save_user_analytics(false,$userId);
		$this->db->where('user_name',$userId);
		$this->db->where('failed_attempts > ',BLOCK_ON_NO_OF_FAILED_ATTEMPTS);
		$arrData = $this->db->get("client_users");
		// If the user has already logged in
		if($this->session->userdata('logged_in')) {
			if($arrData->num_rows()>0){
    			$this->login_failed(true);
			}else{
				redirect('/kols/client_index');
			}
		}
		if(!empty($userId)){
		// If loging for the first time or freshly or after logout
			if($this->simpleloginsecure->login($userId, $password)) {
				log_message('info', 'User '. $userId. ' has logged in');
				$this->chkPasswordValidity();
				//Save the user analytics like user id, login and logout time etc.
				if($arrData->num_rows()!=0){
					$this->login_failed(true);
				}else{
// 					$this->save_user_analytics(false,$userId);
					$arrLogDetails = array(
							'type' => LOG_USER,
							'description' => 'logged in',
							'status' => 'success',
							'transaction_table_id' => CLIENT_USERS,
							'transaction_name' => "login",
							'form_data' => NULL
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity($arrLogDetails, true);
					$backUrl = $this->session->userdata('back_url');
		//			$backURLFromPost	= $this->input->post('back_url');
		//			if(!empty($backURLFromPost)){
		//				$backUrl	= $backURLFromPost;
		//			}
					//echo $_SESSION['back_url'].'--';
					//echo $backUrl;exit;
					if(isset($backUrl) && !empty($backUrl)){
						$this->session->unset_userdata('back_url');
						redirect($backUrl);
					}else{
						// Redirect to the 'KOL Profile' application
						redirect('/kols/client_index');
					}
				}
			}else{
				log_message('info', 'Unsuccessful Login Attempt with UserName: '. $userId);
				log_message('trace', $_POST);
				$formData = $_POST;
	            $formData = json_encode($formData);
	            $arrLogDetails = array(
	                'type' => LOG_USER,
	                'description' => 'loggin fail',
	                'status' => 'fail',
	                'transaction_table_id' => CLIENT_USERS,
	                'transaction_name' => "login",
	                'form_data' => $formData
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            log_user_activity($arrLogDetails, true);
				//Save the user analytics as login failed
// 				$this->save_user_analytics(true,$userId);
				if($arrData->num_rows()>0){
					$this->login_failed(true);
				}else{
					redirect('/login/login_failed');
				}
			}
		}else{
			log_message('info', 'Someone tried to login without credentials.');
			redirect('/login/login_failed');
		}
	}
	function chkPasswordValidity(){
		$this->db->select('last_created');
		$this->db->order_by('id','desc');
		$this->db->where('user_id',$this->session->userdata('user_id'));
		$this->db->limit(1);
		$arrResult  = $this->db->get('password_analytics');
		//echo $this->db->last_query();
		$arrDetails = $arrResult->result_array();
		/*$then = strtotime($arrDetails[0]['last_created']);
		$now = time();
		$minuts =  $now-$then;
		$hours = $minuts/(60*60);
		if($hours>24){
			$this->session->set_userdata('passwordStatus',true);
		}*/
		$currentTimeStamp = time();
		$lastLoginTimeStamp = strtotime($arrDetails[0]['last_created']);
		$numDays = abs($lastLoginTimeStamp - $currentTimeStamp)/60/60/24;
		if($numDays>RESET_PASSWORD_AFTER_NO_OF_DAYS){
			$this->session->set_userdata('passwordStatus',true);
		}
		//echo $minuts;
//		$this->login->chkLastPassowrdTime($userId);
		
	}
	
	function verify_user()
	{
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
		$arrData	= array('status'=>false);
		if($this->simpleloginsecure->login($this->input->post('userid'), $this->input->post('password'))){
			$userName	= $this->session->userdata('user_full_name');
			$userMailId = $this->session->userdata('email');
			//Save the user analytics like user id, login and logout time etc.
// 			$this->save_user_analytics(false,$this->input->post('userid'));
			$arrData['status']	= true;
			$arrData['url']	= getSSOUrl($userName, $userMailId);
			$this->session->sess_destroy();
		}else{
			//Save the user analytics as login failed
// 			$this->save_user_analytics(true,$this->input->post('userid'));
			$arrData['status']	= false;
		}
		echo json_encode($arrData);
	}
	
	/**
	 * Redirects to the Login page, with required message
	 */
	function login_failed($isBlocked=false)
	{
		$data['error_message'] = " Invalid username or password ";
		if($isBlocked){
			$data['error_message'] = "User has been blocked";
		}
		$data['contentPage'] = 'login/login';
		$this->load->view('layouts/app_view', $data);
		//$this->load->view('login/login',$data);
	}
	function login_failed1()
	{
		$data['error_message'] = "User has been blocked";
		$this->load->view('login/login',$data);
	}
	/**
	 * Logs out the user from the application
	 */
	function logout(){
		log_message('info', 'User '. $this->input->post('userid'). ' has logged out');
		 $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_USER,
                'description' => 'logged out',
                'status' => 'success',
                'transaction_table_id' => CLIENT_USERS,
                'transaction_name' => "logout",
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);

            log_user_activity($arrLogDetails, true);
		$this->session->unset_userdata('reportSection'); // clearing reports session filter data
		$this->session->unset_userdata('filterContent');
		$this->session->unset_userdata('arrFilterFields'); //// clearing maps session filter data

		$this->simpleloginsecure->logout();
		
		//Update User Analytics recod with logout time
// 		$this->update_user_analytics();
		session_unset();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		$this->output->set_header("Cache-Control: post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");
		//$this->load->view('login/logout');
		// Redirect to the Login Screen
		//redirect("http://otsuka-us.com");
		$this->load->view("login/logout_page_ireport");
	}
	
	/**
	 * Creates the user with specified UserName, Password and with other essential information
	 */
	function create_user(){
		$this->simpleloginsecure->create('test@test.com', 'test123', true,'Analyst 1');
	}
	
	/**
	 * Save the user analytics like user id, login and logout time etc.
	 * @author 	Ramesh B
	 * @since	3.0
	 * @return unknown_type
	 * @created 16-08-11
	 */
	function save_user_analytics($loginFailed=false,$username){
		$arrUserAnalytics=array();
		if(!$loginFailed){
			$arrUserAnalytics['user_id']	=$this->session->userdata('user_id');
			$arrUserAnalytics['is_login_failed']=0;
			$arrUserAnalytics['username'] =$this->session->userdata('user_name');
		}else{
			$userId=	$this->login_model->getUserIdByUserName($this->input->post('userid'));
			if($userId == 0)
				$arrUserAnalytics['user_id']	=43;
			else
				$arrUserAnalytics['user_id']	=$userId;
				
			$arrUserAnalytics['is_login_failed']=1;
			$arrUserAnalytics['username'] = $username;
		}
		$arrUserAnalytics['login_time']	=date("Y-m-d H:i:s");
		$arrUserAnalytics['user_from']	='iProfile';

		$userAnalyticsId=$this->login_model->saveUserAnalytics($arrUserAnalytics);
// 		$this->session->set_userdata('user_analytics_id',$userAnalyticsId);
	}
	
	/**
	 * Updates the user analytics record with logout time.
	 * @author 	Ramesh B
	 * @since	3.0
	 * @return unknown_type
	 * @created 16-08-11
	 */
	function update_user_analytics(){
// 		$arrUserAnalytics['id']				=$this->session->userdata('user_analytics_id');
		$arrUserAnalytics['logout_time']	=date("Y-m-d H:i:s");
		$this->login_model->updateUserAnalytics($arrUserAnalytics);
		
// 		$this->session->unset_userdata('user_analytics_id');
		$this->session->unset_userdata('logged_in');
	}
	
	function list_all_user_analytics(){
		$limit = 0;
		if($this->input->post('start_from') == null){
			$data['startFrom'] = 0;
			$arrUserAnalytics	=$this->login_model->getAllUserAnalytics(0,$limit);
			$data['arrUserAnalytics']=$arrUserAnalytics;
			$this->load->view('user_analytics',$data);
		}
		else{
			$startFrom = $this->input->post('start_from');
			$data['startFrom'] = $startFrom;
			$arrUserAnalytics	=$this->login_model->getAllUserAnalytics($startFrom,$limit);
			$data['arrUserAnalytics']=$arrUserAnalytics;
			$this->load->view('user_analytics_element', $data);
		}
		
	}
	
	function list_all_user_analytics_grid_view(){
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited list all user analytics grid view Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View list all user analytics grid view Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('user_analytics_grid_view');
	}
	
	function list_all_user_analytics_details() {
            ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
		$page		= $_REQUEST['page']; // get the requested page 
		$limit 		= $_REQUEST['rows']; // get how many rows we want
		$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST['sord']; // get the direction
		if(!$sidx) $sidx =1;
		
		$filterData=$_REQUEST['filters'];
		//pr($filterData);
		//exit;
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];		
		}
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
		
		$whereResultArray['start_date'] = $this->input->post("start_date");
		$whereResultArray['end_date'] = $this->input->post("end_date");
		$count	=	$this->login_model->getAllUserAnalyticsDetailsData($limit,$start,true,$sidx,$sord,$whereResultArray);
		
                if( $count >0 ) {
			$total_pages = ceil($count/$limit); 
		} else { 
			$total_pages = 0; 
		} 
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
			
		$arrKolDetailResult = array();
		$data 				= array();
		$arrKolDetail		= array();

		if($arrKolDetailResult = $this->login_model->getAllUserAnalyticsDetailsData($limit,$start,false,$sidx,$sord,$whereResultArray)){
		
                    foreach($arrKolDetailResult->result_array() as $row){
				$row['id']	= $row['id'];
				$row['name']	= $row['name'];
				if($row['is_login_failed'] == 1){
					$row['user_name'] = $row['username'];
				}else{
					$row['user_name'] = $row['user_name'];				
				}
				$sqlDateEl = explode(" ",$row['created_on']);
				$row['login_time']		= sql_date_to_app_date($row['created_on'])." ".$sqlDateEl[1];
				$row['logout_time']= $row['logout_time'];
				$row['user_from']= $row['user_from'];
				$arrKolDetail[]		= $row;
			}
	 
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrKolDetail;
		}
		ob_start('ob_gzhandler');
//                pr($data);
		echo json_encode($data);
//		echo $this->db->last_query();
//		pr($data);
	}
	
	function export_analytic_detail($isClient = "") {
		$arrKolIds = $this->input->post('exportIds');
		$arrFilters = $this->input->post('filters');
               
		$arrFilters = stripslashes($arrFilters);
		$arrFilters = str_replace('"{','{',$arrFilters);
		$arrFilters = str_replace('}"','}',$arrFilters);
		$arrFilters = trim($arrFilters,'"');
		$arrFilters = json_decode($arrFilters,JSON_UNESCAPED_SLASHES);
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$arrFilter = $arrFilters['filters'];
		if(isset($arrFilters['filters'])){
			$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
			$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
			$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
			$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
			$whereResultArray=array();
			foreach($searchField as $key=> $val){
				$whereResultArray[$val]=$searchString[$key];		
			}
                        
		}
               $whereResultArray['start_date']= $arrFilters['start_date'];
                     $whereResultArray['end_date']= $arrFilters['end_date'];
               
		$sidx = $arrFilters['sidx'];
		$sord = $arrFilters['sord'];
		$arrKolIds = explode(',',$arrKolIds);
		//pr($arrKolIds);
		//$arrKolDeatil = $this->login_model->getUserAnalyticDetails($arrKolIds);
//                pr($arrFilters);
		$arrKolDeatil = $this->login_model->getAllUserAnalyticsDetailsData(0,0,false,$sidx,$sord,$whereResultArray);
//		  echo $this->db->last_query();
//		exit;
                $arrKolDeatil = $arrKolDeatil->result_array();	
//                pr($arrKolDeatil);
//                exit;
		if($isClient == ""){
			$fileName ='UserAnalyticsData';
			$arrDetails[0] = array('Username','Client Name','Login Time','Browser','Device');
				
				foreach($arrKolDeatil as $row){
					$arrDetail[0] = $row['user_name'];
					$arrDetail[1] = $row['name'];
					$arrDetail[2] = $row['created_on'];
					$arrDetail[3] = $row['logout_time'];
                                        $arrDetail[4] = $row['browser'];
                                        $arrDetail[5] = $row['os'];
					$arrDetail[6] = $row['is_login_failed'];
					$arrDetails[]=$arrDetail;
				}
                              
		}else{
			$fileName ='UserAccessReport';
			$arrDetails[0] = array('Username','Team Name','Title','Login Time','Browser','Device');
				
				foreach($arrKolDeatil as $row){
					$arrDetail[0] = $row['user_name'];
					$arrDetail[1] = $row['group_name'];
					$arrDetail[2] = $row['title'];
					$arrDetail[3] = $row['created_on'];
                                        $arrDetail[4] = $row['browser'];
                                        $arrDetail[5] = $row['os'];
					$arrDetails[]=$arrDetail;
				}
		}
		$this->load->plugin('phpxls/writer');
                  if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $workbook = new Spreadsheet_Excel_Writer($path);
        }
        else{
             $workbook = new Spreadsheet_Excel_Writer();
        }
		
		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
		$format_und->setAlign('centre');
		$format_und->setSize(12);
			
		$format_reg =& $workbook->addFormat();
	//	$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		$format_reg1 =& $workbook->addFormat();
	//	$format_reg1->setBorder(1);
		$format_reg1->setHAlign('left');
		$format_reg1->setVAlign('vcentre');
		$format_reg1->setColor('red');
		$format_reg1->setFontFamily('Arial');
		$format_reg1->setSize(10);
		
//		$excelFilters = $this->input->post('filters');
//		$filters = array();
//	//	$excelFilters = 'Appoved By:Vinayak';
//		if($excelFilters != '')
//		$arrFilters = explode(",",$excelFilters);
//		$filterHeaders[0] = 'Filter Name';
//		$filterHeaders[1] = 'Filter Value';
//		$filters[]	= $filterHeaders;
//		foreach ($arrFilters as $filter){
//			if($filter != '' && $filter != 'Search'){
//				$filterRow = array();
//				$filterRowElements = explode(":",$filter);
//				$filterName = trim($filterRowElements[0]);
//				$filterRow[0] = '';
//				$filterNameElements = explode("_",$filterName);
//				foreach ($filterNameElements as $value){
//					$filterRow[0] .= ucfirst($value)." ";
//				}
//				$filterRow[1] = trim($filterRowElements[1]);
//				$filters[]	= $filterRow;
//			}
//		}
		//pr($filters);
		$arr = array(
		      	'Profiles Requested' => $arrDetails
//				'Filters'=>$filters
		      );

		foreach($arr as $wbname=>$rows)
		{
		    
			$rowcount = count($rows);
			$colcount = count($rows[0]);
			
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='Profiles Requested'){
				$worksheet->setColumn(0,0, 20);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 40.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,4, 30.00);
				$worksheet->setColumn(5,5, 30.00);
				
			}
			if($wbname == 'Filters'){
				$worksheet->setColumn(0,0,25);
			    $worksheet->setColumn(1,1,25);
			}

			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
			          
					if ($j==0){
						$fmt =& $format_und;
					                    
					}
					if (isset($rows[$j][$i]))
					{
						if($rows[$j][4] == 1)
							$fmt =& $format_reg1;
						$data=$rows[$j][$i];
						$worksheet->write($j, $i, $data, $fmt);
					}
				}
			}
		}
		
		//$userId=$this->session->userdata('user_id');
		//$userName = $this->client_user->getUserNameById($userId);
		//$fileName = $userName."_interactions";
		//if($kolId != null){
			//$kolDetails = $this->kol->getKolName($kolId);
			//$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
			//$fileName = $userName."_".$kolName."_interactions";
		//}
		//for downloading the file
			
//		$workbook->send($fileName.'.xls');
//		$workbook->close();
                if(!IS_IPAD_REQUEST){
                $workbook->send($fileName . '.xls');
                $workbook->close();
                }
                else{

                $workbook->close();
                    return $path;
                 }
	}
	
	function show_forgot_password_page(){
		if($this->session->userdata('logged_in')) {
	    		redirect('/kols/client_index');
			}
		$data['contentPage'] = 'login/show_forgot_password_page';
		$this->load->view('layouts/app_view', $data);
		//$this->load->view('login/show_forgot_password_page');
	}
	
	/**
	 * Reset the  password
	 * @author 	Vinayak
	 * @since	5.4
	 * @return unknown_type
	 * @created 6-12-2012
	 */
	function forgot_password(){
		
		$emilId = $this->input->post('email');
		//$emilId = 'vinayak.malladad@bilva.co.in';
		if($userDetails = $this->login_model->getUserId($emilId)){
			$userId = $userDetails['id'];
			$newPasswordkey = md5(rand().microtime());
			$this->login_model->updateNewPasswordKey($newPasswordkey ,$userId);
			
			$arrDetails['userId'] = $userId;
			$arrDetails['key']    = $newPasswordkey;
			$arrDetails['userName']    = $userDetails['first_name']." ".$userDetails['last_name'];
			$html = $this->load->view('email/forgot_password-html',$arrDetails,true);
			
			$config['protocol'] 	= PROTOCOL;
			$config['smtp_host'] 	= HOST;         
			$config['smtp_port'] 	= PORT;
			$config['smtp_user'] 	= USER;
			$config['smtp_pass'] 	= PASS;
			//$config['mailtype']		= 'html';
	
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->initialize($config);
			$this->email->clear();
				//$userNAme = $this->session->userdata('user_name');
			//$config['mailtype'] = 'html';
		
			$this->email->set_newline("\r\n");
		
			
			//send mail to Analyst Managers if the request is from Client manager
		
			
				$this->email->subject('Confirm your '.PRODUCT_VERSION.' Application password reset request');
	          
	            $this->email->from(USER,$arrDetails['userName']);
			
	          	$this->email->message($html);
	          	$this->email->to($emilId);
	          	$this->email->send();
	         // echo $this->email->print_debugger();
			$data['status'] =true;
			echo json_encode($data);
		}else{
			$data['status'] = false;
			echo json_encode($data);
		}
	}
	
	/**
	 * Reset the  password
	 * @author 	Vinayak
	 * @since	5.4
	 * @return unknown_type
	 * @created 6-12-2012
	 */
	function reset_password($userId,$newPassKey){

		$mobile = mobile_device_detect();
		
       	if(isset($mobile[1]) && $mobile[1] != 'Apple iPad'){
           redirect(base_url().MOBILE_URL_SEGMENT.'/logins/reset_password/'.$userId.'/'.$newPassKey);
        }
        if(isset($mobile[1]) && $mobile[1] == 'Apple iPad'){
        	redirect(base_url().IPAD_URL_SEGMENT.'/login/reset_password/'.$userId.'/'.$newPassKey);
        }
		$data['userId'] = $userId;
		$data['newPassKey'] = $newPassKey;
		if(!($this->login_model->checkExpirekey($data))){
			//$data['contentPage'] = 'email/show_expire_message';
			//$this->load->view('email/email_layout',$data);
			$data['contentPage'] = 'email/show_expire_message';
			$this->load->view('layouts/app_view', $data);
		}else{
			$data['contentPage'] = 'login/reset_password';
			$this->load->view('layouts/app_view', $data);
			//$this->load->view('login/reset_password',$data);
		}
	}

	function update_password(){
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$userId 	= $this->input->post('user_id');
		
		$newPassKey = $this->input->post('new_password_key');
		$newPassword = $this->input->post('password');
		$arrUser['password']		=	$hasher->HashPassword($newPassword);
		
		$arrPassword = $this->Client_User->getUserRecentPassword($userId);
		
		foreach($arrPassword as $row){
			if($hasher->CheckPassword($newPassword, $row['password'])){
				$password=1;
			}
		}
		if($password==0){
			$this->login_model->resetPassword($arrUser,$userId);
				
			$config['protocol'] 	= PROTOCOL;
			$config['smtp_host'] 	= HOST;
			$config['smtp_port'] 	= PORT;
			$config['smtp_user'] 	= USER;
			$config['smtp_pass'] 	= PASS;
			//$config['mailtype']		= 'html';
			
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->initialize($config);
			$this->email->clear();
			$this->email->set_newline("\r\n");
				
			$userDetail = $this->login_model->getUserdetail($userId);
			$arrDetails['userDetail'] = $userDetail;
			//send mail to Analyst Managers if the request is from Client manager
				
			$html = $this->load->view('email/confirm_message',$arrDetails,true);
			$this->email->subject('Your '.PRODUCT_VERSION.' Application password has been changed');
			$userName = $userDetail['first_name']." ".$userDetail['last_name'];
			$this->email->from(USER,$userName);
			
			$this->email->message($html);
			$this->email->to($userDetail['email']);
			$this->email->send();
			$data['contentPage'] ='login/show_success_message';
			
		}else{
			$data['contentPage'] ='login/show_fail_message';
			$data['user_id'] = $userId;
			$data['pass_key'] = $newPassKey;
		}
		$this->load->view('email/email_layout',$data);
}
	
	/*---------------------------- SSO based loggin methods -----------------------------------------------------------------*/
	/**
	 * Logs the user into the application based on the provided TokenID and AgentId
	 *
	 * @param	String	TokenID
	 * @param	String	AgenID
	 */
	function process_sso_login($userName)
	{
		$userName = base64_decode($userName);
		
		//Logg Server information information
		$this->logText	= "HTTP Referrer:". $_SERVER['HTTP_REFERER'] . " \n\n";
		fwrite($this->logFile, $this->logText);
		$this->logText	= "REMOTE_ADDR: ". $_SERVER['REMOTE_ADDR'] . " \n\n";
		fwrite($this->logFile, $this->logText);
		
		// If the user has already logged in
		if($this->session->userdata('logged_in')) {
			//Save User analytics
// 			$this->save_user_analytics(false,$userName);
			
			$backUrl = $this->session->userdata('back_url');
			if(isset($backUrl)){
				$this->session->unset_userdata('back_url');
				redirect($backUrl);
			}else{
				// Redirect to the 'KOL Profile' application
				redirect('/kols/client_index');
			}
		}
		
		//$userName = strip_tags($responseData['pingone.subject']);
		//$userName = trim(strtolower(strip_tags($userName)));
		
		$idpId = strip_tags($responseData['pingone.idp.id']);
		//echo " Username is " . $userName . " and ID Provider is : " . $idpId;
		//exit;

		// If loging for the first time or freshly or after logout
		if($this->is_valid_user($userName)) {
			//Save User analytics
// 			$this->save_user_analytics(false,$userName);
			
			$formData = $_POST;
			$formData['user_name'] = $userName;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_USER,
                'description' => 'logged in',
                'status' => 'success',
                'transaction_table_id' => CLIENT_USERS,
                'transaction_name' => "login",
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);

            log_user_activity($arrLogDetails, true);
			
			//Valid User and redirecting Now
			log_message('info', 'User '. $userName. ' has logged in');
			$this->logText	= "User '". $userName. "' has logged in \n\n";
			fwrite($this->logFile, $this->logText);
			$backUrl = $this->session->userdata('back_url');
			if(isset($backUrl)){
				$this->session->unset_userdata('back_url');
				redirect($backUrl);
			}else{
				// Redirect to the 'KOL Profile' application
				redirect('/kols/client_index');
			}
			exit;
		}else{
			//Save User analytics
// 			$this->save_user_analytics(true,$userName);
			$formData = $_POST;
			$formData['user_name'] = $userName;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_USER,
                'description' => 'loggin fail',
                'status' => 'fail',
                'transaction_table_id' => CLIENT_USERS,
                'transaction_name' => "login",
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);

            log_user_activity($arrLogDetails, true);
            
			
			//Loggin failed with the username
			$this->logText	= "Unsuccessful Login Attempt with UserName : ". $userName . " \n\n";
			fwrite($this->logFile, $this->logText);
			log_message('info', 'Unsuccessful Login Attempt with UserName: '. $userName);
			log_message('trace', $_POST);
			//redirect('/kols/client_index');
			redirect('/login/sso_login_failed');
			exit;
		}	
	}
	
	
	/**
	 * Create the User Session based on the Username Provided by Identity Provider
	 *
	 * @access	public
	 * @param	string
	 * @return	bool
	 */
	function is_valid_user($userName = '') 
	{
		//echo 'Username within the method: ' . $userName;
		$this->CI =& get_instance();

		if($userName == '')
			return false;

		$this->logText	= "Validating  User : '". $userName . "' \n\n";
		fwrite($this->logFile, $this->logText);

		//Check if already logged in
		//if($this->CI->session->userdata('email1') == $userName)
			//return true;
		
		//Check against user table
		$this->CI->db->where('email', $userName); 
		$this->CI->db->where_in('user_from', array(1,2)); 
		$query = $this->CI->db->getwhere($this->user_table);
		//echo $this->CI->db->last_query;
		//pr($query);
		
		if (is_object($query) &&  $query->num_rows() > 0) 
		{
			$this->logText	= "Matches found for User : '". $userName . "' \n\n";
			fwrite($this->logFile, $this->logText);
		
			$user_data = $query->row_array(); 

			//Destroy old session
			//pr( $this->CI->session->userdata);
			$back_url = $this->CI->session->userdata('back_url');
			//$back_url = "http://otsukaiprofile.com/kols/client_index/";
			$this->CI->session->sess_destroy();
			$this->logText	= "Session Destroyed  \n\n";
			fwrite($this->logFile, $this->logText);
			
			//Create a fresh, brand new session
			$this->CI->session->sess_create();
			$this->CI->session->set_userdata("back_url",$back_url);
			$this->CI->db->simple_query('UPDATE ' . $this->user_table  . ' SET user_last_login = NOW() WHERE id = ' . $user_data['id']);
			
			/* $this->CI->db->select('GROUP_CONCAT(user_groups.group_id) AS group_ids,GROUP_CONCAT(groups.group_name) AS group_names');
			$this->CI->db->join('groups','groups.group_id=user_groups.group_id');
			$this->CI->db->where('user_id', $user_data['id']);
			$this->CI->db->group_by('user_id');
			$query = $this->CI->db->getwhere('user_groups');
			$userGroups['group_ids']	= '';
			$userGroups['group_names']	= '';
			if ($query->num_rows() > 0) 
			{
				$userGroups = $query->row_array(); 
			} */
			
			//pr($user_data);
			//Set session data
			unset($user_data['password']);
			$sess_data['user_id'] = $user_data['id'];
			//$sess_data['user'] = $user_data['email']; // for compatibility with Simplelogin
			$sess_data['logged_in'] = true;
			$sess_data['user_name'] = $user_data['user_name'];
			$sess_data['user_last_login'] = $user_data['user_last_login'];
			$sess_data['user_role_id'] = $user_data['user_role_id'];
			$sess_data['is_analyst'] = $user_data['is_analyst'];
			$sess_data['client_id'] = $user_data['client_id'];
			$sess_data['email'] = $user_data['email'];
			$sess_data['user_full_name'] = $user_data['first_name']." ".$user_data['last_name'];
			$sess_data['name_order'] = $user_data['name_order'];
			$sess_data['mem_pic'] = $user_data['mem_pic'];
// 			$sess_data['company_name'] = $user_data['company_name'];
			$sess_data['title'] = $user_data['title'];
			/* $sess_data['group_ids'] = $userGroups['group_ids'];
			$sess_data['group_names'] = $userGroups['group_names']; */
			$sess_data['logged_in_on'] = strtotime(date("Y-m-d"));
			//$sess_data['user_from'] = $user_data['user_from'];
			//$sess_data['disc'] = 1;
            //$sess_data['user_territory'] = $user_data['territory'];
                        
			//pr($sess_data);
			$this->CI->session->set_userdata($sess_data);
			
			$this->logText	= "Session Data set  \n\n";
			fwrite($this->logFile, $this->logText);
			
			return true;
		} 
		else 
		{
			return false;
		}
	}
	
	/**
	 * Redirects to the Login page, with required message
	 */
	function sso_login_failed()
	{
		$data['error_message'] = "Invalid Username";
		$data['contentPage'] = 'login/invalid_user_page';
		$this->load->view('email/email_layout',$data);
	}
	
	function killIdleSession(){
	    $this->simpleloginsecure->logout ();
	    $this->load->view ("login/auto_session_timeout");
	}
}