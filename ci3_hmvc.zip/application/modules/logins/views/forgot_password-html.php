<html>
<head>
<style>
table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
td { background: #FAFAFA; text-align: left; border: 0px;}
</style>
</head>
	<body>
		<div>
			Hi <?php echo $userName?>,<br><br>
			<table>
				<tr><td>We have received a request to reset your <?php echo PRODUCT_VERSION;?> Application password. If you did not make this request, simply ignore this email. If you did make this request, just click the link below and follow the instructions.</td></tr>
				<tr><td><br><a href='<?php echo base_url()?>logins/logins/reset_password/<?php echo $key ?>'>Click Here</a> to reset your password.</td></tr>
				<tr><td><br>You'll need to click the link within 24 hours after receiving this email else the link will expire. If you have not requested for a password reset, simply ignore this email and your current password will be maintained.</td></tr>
				<tr><td><br>If you continue to have problem please feel free to contact us at support@aissel.com</td></tr>
			</table><br>Regards,<br><?php echo PRODUCT_VERSION;?> Support<br>
		</div>
	</body>
</html>