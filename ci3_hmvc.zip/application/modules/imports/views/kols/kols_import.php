<style type="text/css">
   	.container{
   	margin-top:30px;
   	}
   	.center{
    display: flex;
    justify-content: center;
    align-items: center;
   	background-color:#fbf9ee;
   	border: 1px solid #ccc;
   	border-radius:4px;
   	padding:20px;
	}
	.align-center{
		text-align: center;
		margin-top:20px;
	}
	label{
		margin-right: 5px;
	    margin-left: 3px;
	    vertical-align: middle;
	}
	.page-title{
		text-align: center;
		font-size:18px;
	}
    </style>
    <script type="text/javascript">
		function validateImportForm(thisEle){
			if($(thisEle).val() =="Upload"){
		
				if($('#profImport').val()==''){
				jAlert("Please select the file to Upload");
					
					return false;
				}else{
					var action ="<?php echo base_url()?>imports/upload_zip_file";
					$('#kolImportForm').attr('action',action);
					$('#kolImportForm').submit();
		
				}
			}else{
				$('#kolImportButton').attr('disabled', 'disabled');
				$('#wrapper').blockUI({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>/images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'100%',width:'100%',cursor:'default'}});
				var action ="<?php echo base_url()?>imports/list_all_uploaded_files";
				$('#kolImportForm').attr('action',action);
				$('#kolImportForm').submit();
			}
		}
</script>
<div class="container">
    <div class="row">
    	<h1 class="page-title">Kols Import</h1>
        <div id="kolImportContainer" class="col-md-8 col-md-offset-2 center">
        
				<form action="<?php echo base_url();?>imports/upload_zip_file" name="kolImportForm" id="kolImportForm" method="post" enctype="multipart/form-data">
                  <?php
					 $currentMethod		= $this->uri->segment(2);
					 if($currentMethod == 'analyst_kol_import_page'){?>
						<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="kolMethodName"></input>
				<?php }else{?>
						<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="kolMethodName"></input>
				<?php }?>
                  <div class="form-group">
                    <label for="file">Select a file to upload</label>
                    <input type="file" name="prof_import" id="profImport" class="form-control">
                    <p class="help-block pull-right" >Only '.xls' files is allowed.</p>
                  </div>
                  <input type="submit" value="Upload"  class="btn btn-sm btn-danger" id="kolImportButton" onclick="validateImportForm(this)"/>
           
                </form>
				<div id="importInstructions">
					
				</div>
		</div>
    </div>
    <div class="row align-center">
		<input type="button" value="List Uploaded Files" class="btn btn-sm btn-primary" id="kolImportButton" onclick="validateImportForm(this)">
	</div>
</div>
<!--/container-->