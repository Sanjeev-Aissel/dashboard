<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class My_list_kols extends MX_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('My_list_kol');
		$this->load->model('helpers/common_helper');
	}
	function index(){
		$data['contentPage']			='manage_kol_lists';
		$data['contentData']			=$arrcontentData;
		
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function add_list($kols=0){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrCategory=$this->My_list_kol->listCategories($user_id,$client_id);
		$data['arrCetgory']=$arrCategory;
		$data['arrKols'] = $kols;
		$this->load->view('add_list',$data);
		
	}
	function getCategories(){
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'id';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		
		if(!$sidx) $sidx =1;
		$count= $this->My_list_kol->getListCatogories($arrFilter,$start,$limit,$sidx,$sord,true);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		
		if ($start<0) $start = 0;
		$resultSet = $this->My_list_kol->getListCatogories($arrFilter,$start,$limit,$sidx,$sord,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['category'] =$row['category'];
			$row['lists_count'] =$row['lists_count'];
			$row['is_public'] =($row['is_public']==0)?'Private':'Public';
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function get_lists_by_category_id($category_id){
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'id';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		
		if(!$sidx) $sidx =1;
		$count= $this->My_list_kol->getListsByCatogoryId($category_id,$arrFilter,$start,$limit,$sidx,$sord,true);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		
		if ($start<0) $start = 0;
		$resultSet = $this->My_list_kol->getListsByCatogoryId($category_id,$arrFilter,$start,$limit,$sidx,$sord,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['category'] =$row['category'];
			$row['kols_count'] =$row['kols_count'];
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function get_kols_by_list_id($list_id){
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'id';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		
		if(!$sidx) $sidx =1;
		$count= $this->My_list_kol->getKolsByListId($list_id,$arrFilter,$start,$limit,$sidx,$sord,true);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		
		if ($start<0) $start = 0;
		$resultSet = $this->My_list_kol->getKolsByListId($list_id,$arrFilter,$start,$limit,$sidx,$sord,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] 			=$row['kols_client_visibility_id'];
			$row['kol_name'] 	=$this->common_helper->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$row['kol_name'] 	='<a href="'.base_url().'kols/kols/view/'.$row['kols_client_visibility_unique_id'] .'">'.$row['kol_name'].'</a>';
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function get_list_names($categoryId){
		$arrlist=$this->My_list_kol->getListNames($categoryId);
		echo json_encode($arrlist);
	}
	function save_list_kols(){
		$kols=$this->input->post('kol_id');
		$arrCatgory['category']=trim($this->input->post('category'));
		$arrCatgoryId['category_id']=$this->input->post('category_id');
		$arrListName['list_name']   =trim($this->input->post('list_name'));
		$arrListNameId['list_name_id']   =$this->input->post('list_name_id');
		$arrCatgory['is_public']=$this->input->post('is_public');
		if($arrCatgory['category']!=''){
			$arrCatgory['user_id'] = $this->session->userdata('user_id');
			$arrCatgory['client_id'] = $this->session->userdata('client_id');
			if($lastInsertId = $this->common_helper->insertEntity('list_categories',$arrCatgory)){
				$data['cat_saved']=true;
				$data['msg']="Saved Successfully";
			}else{
				$data['msg']="Sorry! Name is Already Present in Databse";
				$data['cat_saved']=false;
			}
		}else{
			$this->db->set('is_public',$arrCatgory['is_public']);
			$this->db->where('id',$arrCatgoryId['category_id']);
			$this->db->update('list_categories');
			$lastInsertId	=$arrCatgoryId['category_id'];
			$data['msg']	="Saved Successfully";
			$data['cat_saved']=true;
		}
		$arrListName['category_id']=$lastInsertId;
		
		if($arrListName['list_name'] !=''){
			$arrListName['user_id'] = $this->session->userdata('user_id');
			if($lastInsertId = $this->common_helper->insertEntity('list_names',$arrListName)){
				$data['list_saved']=true;
				$data['msg1']="Saved Successfully";
			}else{
				$data['msg1']="Sorry! Name is Already Present in Databse";
				$data['list_saved']=false;
			}
		}else{
			$lastInsertId=$arrListNameId['list_name_id'];
			$data['list_saved']=true;
		}
		$arrKols = explode(',',$kols);
		$this->My_list_kol->saveListOfKols($arrKols,$lastInsertId);
		echo json_encode($data);
	}
	function add_my_list_category($category_id=null){
		$arrCategoryDetails			=array();
		if($category_id!=null){
			$arrCategoryDetails		=$this->common_helper->getEntityById('list_categories',array('id'=>$category_id));
			$arrCategoryDetails		=$arrCategoryDetails[0];
		}
		$is_public					=($arrCategoryDetails['is_public']=='')?'0':$arrCategoryDetails['is_public'];
		$hidden_fields				=array('id'=>$category_id);
		$form_inputs_details[]		=array('type'=>'radio','label'=>array('label_name'=>'Privacy','required'=>0),'value'=>$is_public,'options'=>array('Private'=>'0','Public'=>'1'),'data'=>array('name'=>'is_public','id'=>'is_public'));
		$form_inputs_details[]		=array('type'=>'text','label'=>array('label_name'=>'Category name','required'=>1),'data'=>array('name'=>'category','id'=>'category','class'=>'form-control','value'=>$arrCategoryDetails['category']));
		$form_details				=array('form_inputs_details'=>$form_inputs_details,
											'hidden_ids'=>$hidden_fields,
											'form_id'=>'addCategoryForm',
											'submit_function'=>'save_category();',
											'cancel_function'=>'close_dialog();'
									);
		$data['html_form']			=get_html_form($form_details);///cals helper function to get html content
		$this->load->view('add_category',$data);
	}
	function add_my_list(){
		$arrListDetails			=array();
		$arrCategories			=array();
		$list_id				=$_POST['list_id'];
		$category_id			=$_POST['category_id'];
		if($list_id!=null){
			$arrListDetails=$this->common_helper->getEntityById('list_names',array('id'=>$list_id));
			$arrListDetails=$arrListDetails[0];
		}
		$arrCategoryDetails=$this->My_list_kol->listCategories($this->session->userdata('user_id'),$this->session->userdata('client_id'));
		foreach ($arrCategoryDetails as $category){
			$arrCategories[$category['id']]=$category['category'];
		}
		$hidden_fields				=array('id'=>$list_id,'old_category_id'=>$category_id);
		$form_inputs_details[]		=array('type'=>'select',   'label'=>array('label_name'=>'Category','required'=>0),'name'=>'category_id','data'=>array('id'=>'category_id','class'=>'form-control'),'options'=>$arrCategories,'selected'=>$category_id);
		$form_inputs_details[]		=array('type'=>'text','label'=>array('label_name'=>'List name','required'=>1),'data'=>array('name'=>'list_name','id'=>'list_name','class'=>'form-control','value'=>$arrListDetails['list_name']));
		$form_details				=array('form_inputs_details'=>$form_inputs_details,
											'hidden_ids'		=>$hidden_fields,
											'form_id'			=>'addListForm',
											'submit_function'	=>'save_my_list();',
											'cancel_function'	=>'close_dialog();'
									);
		$data['html_form']=get_html_form($form_details);///cals helper function to get html content
		$this->load->view('add_my_list',$data);
	}
	function add_kols_to_list(){
		$list_id					=$_POST['list_id'];
		$hidden_fields				=array('list_name_id'=>$list_id,'kol_id'=>'');
		$form_inputs_details[]		=array('type'=>'text','label'=>array('label_name'=>'KTL name','required'=>1),'data'=>array('name'=>'kol_name','id'=>'kol_name','class'=>'form-control autocompleteInputBox','value'=>$arrCategoryDetails['category']));
		$form_details				=array('form_inputs_details'=>$form_inputs_details,
				'hidden_ids'=>$hidden_fields,
				'form_id'=>'addKolToListForm',
				'submit_function'=>'save_kols_to_list();',
				'cancel_function'=>'close_dialog();'
		);
		$data['category_name']		='Cat';
		$data['list_name']			='List';
		$data['html_form']			=get_html_form($form_details);///cals helper function to get html content
		$this->load->view('add_kols_to_list',$data);
	}
	function save_category(){
		$data['msg']			="Error! Please try again after some time";
		$data['saved']			=false;
		$arrData				=$_POST;
		$arrData['user_id']		=$this->session->userdata('user_id');
		$arrData['client_id']	=$this->session->userdata('client_id');
		if($arrData['id']>0){
			$lastInsertId = $this->common_helper->updateEntity('list_categories',$arrData,array('id'=>$arrData['id']));
		}else{
			$lastInsertId = $this->common_helper->insertEntity('list_categories',$arrData);
		}
		if($lastInsertId>0){
			$data['saved']	=true;
			$data['msg']	="Saved Successfully";
		}
		echo json_encode($data);
	}
	function save_my_list(){
		$data['msg']			="Error! Please try again after some time";
		$data['saved']			=false;
		//needs oly to reload the current "lists"
		$data['old_category_id']=$_POST['old_category_id'];

		unset($_POST['old_category_id']);
		
		$arrData				=$_POST;
		$arrData['user_id']		=$this->session->userdata('user_id');
		if($arrData['id']>0){
			$lastInsertId = $this->common_helper->updateEntity('list_names',$arrData,array('id'=>$arrData['id']));
		}else{
			$lastInsertId = $this->common_helper->insertEntity('list_names',$arrData);
		}
		if($lastInsertId>0){
			$data['saved']	=true;
			$data['msg']	="Saved Successfully";
		}
		echo json_encode($data);
	}
	function save_kols_to_my_list(){
		$data['msg']			="Error! Please try again after some time";
		$data['saved']			=false;
		
		//needs to reload the current "kols list"
		$data['old_list_id']=$_POST['list_name_id'];
		
		//get category_id to reload the current lists
		$arrListDetails=$this->common_helper->getEntityById('list_names',array('id'=>$data['old_list_id']));
		$arrListDetails=$arrListDetails[0];
		$data['old_category_id']=$arrListDetails[category_id];
		
		unset($_POST['kol_name']);
		
		$arrData				=$_POST;
		$arrData['user_id']		=$this->session->userdata('user_id');

		$lastInsertId = $this->common_helper->insertEntity('list_kols',$arrData);
			
		if($lastInsertId>0){
			$data['saved']	=true;
			$data['msg']	="Saved Successfully";
		}
		echo json_encode($data);
	}
	function remove_kols_from_list($list_id){
		//get category_id to reload the current lists
		$arrListDetails=$this->common_helper->getEntityById('list_names',array('id'=>$list_id));
		$arrListDetails=$arrListDetails[0];
		$data['old_category_id']=$arrListDetails[category_id];
		
		$data['saved']=$this->My_list_kol->removeKolsFromMyList($_POST,$list_id);
		echo json_encode($data);
	}
	function delete_record(){
		$data['saved']=$this->My_list_kol->deleteRecord($_POST);
		echo json_encode($data);
	}
	function export_as_pdf(){
		$data['kol_ids']=implode(',',$_POST['ids']);
		$this->load->view('export_kols_as_excel_options',$data);
	}
	function myListExportKTLs($kol_ids){
		$kol_ids=explode("," , $kol_ids);
		$arrKolDetails			=$this->My_list_kol->exportKolsProfile($kol_ids);
		
		$data					=array();
		$data[0]				=array('Name','Speciality','Country','Phone','Email');
		$i=1;
		
		foreach ($arrKolDetails as $row) {
			$kol_name			=nf($row['first_name'],$row['middle_name'],$row['last_name']);
			$data[$i]			=array($kol_name,$row['specialty'],$row['country'],$row['primary_phone'],$row['primary_email']);
			$i++;
		}
		
		$sheet['title']			='KTL list';
		$sheet['content']		=$data;
		$sheets[]				=$sheet;
		
		$arr_export_details['file_name']	="Mailing_export".date("m-d-Y_His").'.xls';
		$arr_export_details['sheets']		=$sheets;
		export_as_xls($arr_export_details);
	}
}