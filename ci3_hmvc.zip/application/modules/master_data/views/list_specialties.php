<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<script type="text/javascript">
function list_specialty_grid(){
	$('#gridKolsListing').html('');
    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
    grid = $("#gridKolsListingResultSet")
    grid.jqGrid({
		url:'<?php echo base_url();?>master_data_controller/load_grid_specialties',
		datatype: "json",
		colNames:['Id','Specialty','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'specialty',index:'specialty',width:75, search:true},	   		
			{name:'action',index:'action',width:10, align:'center',search:false, resizable:false}
			
	   	],       
	   	rowNum:10,
	   	multiselect: true,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#gridKolsListingPagintaion',
	   	mtype: "POST",
	   	sortname: 'specialty',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"List Specialties",
		rowList:paginationValues
	});
	grid.jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	jQuery("#m1").click( function() {
		var s;
		s = jQuery("#gridKolsListingResultSet").jqGrid('getGridParam','selarrrow');
		addClientsToRequestedSpecialties(s);
	});
	grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Merge-Specialties",buttonicon : "ui-icon-circle-check", title:"Merge-Specialties",
		onClickButton:function (){
			var selectedSpec	= $(this).getGridParam('selarrrow');
			if(selectedSpec.length>0){
				mergeSpecialtiesById(selectedSpec);
			}else{
				jAlert('Please select at least one Specialty');
			}
		}
	});
	grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Associate-Clients",buttonicon : "ui-icon-circle-close", title:"Associate-Clients",
		onClickButton:function (){
			var s	= $(this).getGridParam('selarrrow');
			if(s.length>0){
				addClientsToRequestedSpecialties(s);
			}else{
				jAlert('Please select at least one Specialty');
			}
		}
	});
}

$(document).ready(function(){	
	var specialtyDialogOpts = {
			title: "Add/Edit Specialties",
			modal: true,
			autoOpen: false,
			height: 300,
			width: 350,
			dialogClass: "microView",
	};
	$("#specialtyContainer").dialog(specialtyDialogOpts);
	list_specialty_grid();	
});

function editSpecialties(id,specialty){
	$(".addSpecialtyContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#specialtyContainer").dialog("open");
	$(".addSpecialtyContent").load('<?php echo base_url().'master_data_controller/edit_specialty'?>',function(){
		$("#hiddenId").val(id);
		$("#specialty").val(specialty);
	});
	return false;
}

function addSpecialtiesClients(id){
	$(".addSpecclientContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#specclientContainer").dialog("open");
	$(".addSpecclientContent").load('<?php echo base_url().'master_data_controller/add_specialty_clients'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function mergeSpecialtiesById(id){	
	$(".addSpecclientContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#specclientContainer").dialog("open");
	$(".addSpecclientContent").load('<?php echo base_url().'master_data_controller/merge_specialty_modal_box'?>/'+id,function(){
		$("#hiddenSid").val(id);		
	});
	return false;
}
function saveSpecialty(){
	var specialty = $('#specialty').val();
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;		
	var url = 'master_data_controller/save_specialty';
	smartCRUD(id,specialty,url,false);
	
}

function deleteSelectedSpecialties(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	var url = 'master_data_controller/delete_specialty';
	var confirmed = confirm('Are you sure to proceed with Delete ?');
	if(confirmed){
		smartCRUD(id,'',url,true);
	} else {
		alert("Operation Cancelled");
	}
}

function smartCRUD(id,specialty,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialty+"&id="+id,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				alert(returnData);
			}
			list_specialty_grid();
	 	},
	 	error:function(){
		 	alert("already exist");
		}
	 });
}
function closeModal(){
	$("#specialtyContainer").dialog("close");
	
}
function closeModal1(){
	$("#specclientContainer").dialog("close");
	
}
$(document).ready(function(){	
	var specialtyClientsDialogOpts = {
			title: "Associate Clients",
			modal: true,
			autoOpen: false,
			height: 250,
			width: 300,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			},
			close:function(){
			}
	};
	$("#specclientContainer").dialog(specialtyClientsDialogOpts);
	list_specialty_grid();	
});
function saveClients(){	
	var specialty = $('#hiddenSid').val();
	var clientIds = $('#clientId').val();
	var clientId = new Array();
	if(clientIds == null){
		alert("Associate atleast one client");
		return;
	}
	for(i=0;i<clientIds.length;i++){
		clientId.push(clientIds[i]);
	}
	var url = 'master_data_controller/save_client_specialty';	
	smartCRUD(clientId.toString(),specialty,url,false);		
}
function mergeSpecialties(){
	var specialty = $('#hiddenSid').val();	
	var specialtyId = $('#specialtyId').val();
	var url = 'master_data_controller/merge_specialty';
	mergeSpecialtiesAssociateKols(specialty,specialtyId,url,false);	
}
function mergeSpecialtiesAssociateKols(specialty,specialtyId,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialty+"&id="+specialtyId,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				alert(returnData);
			}
			list_specialty_grid();
	 	},
	 	error:function(){
		 	alert("already exist");
		}
	 });		
}
function addClientsToRequestedSpecialties(s){
	$(".addSpecclientContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#specclientContainer").dialog("open");
	$(".addSpecclientContent").load('<?php echo base_url().'master_data_controller/add_miltiple_specialty_clients'?>/'+s);
	return false;
}
function saveMultipleClients(){
	var specialties = $('#specIds').val();
	var clientIds = $('#clientId').val();
	var url = 'master_data_controller/save_multiple_clients_specialties';	
	saveMultipleSpecialtiesClients(specialties,clientIds,url,false);
	//console.log(clientIds);
}
function saveMultipleSpecialtiesClients(specialties,clientIds,action,isDel){	
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"specialty="+specialties+"&id="+clientIds,
		success:function(returnData){
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				alert(returnData);
			}
			list_specialty_grid();
	 	},
	 	error:function(){
		 	alert("already exist");
		}
	 });		
}
function redirect(){
	//alert("false");		
	var page = $('#sel').val();
	alert(page);	
	//return false;
	window.location = "<?php echo base_url();?>master_data_controller/"+page;	
	}	
</script>
<style>
.ui-jqgrid .ui-jqgrid-btable{
        table-layout:auto;
    }
    .ui-jqgrid .ui-jqgrid-htable{
        table-layout:auto;
    }
</style>
<div class="gridWrapper">	
	<div class="extraOptions">
		<a class="addLink" style="cursor: pointer;"
			onclick="editSpecialties();return false;" align="left"><img
			src="<?php echo base_url();?>images/bullet_add.png" border="0"
			style="height: 30px; vertical-align: middle;" />Add Specialty</a> 			
	</div>
	<div id="gridKolsListing">
		<div class="gridWrapper">
			<div id="gridKolsListingPagintaion"></div>
			<table id="gridKolsListingResultSet"></table>
		</div>
	</div>
</div>
<!-- Modal content -->
<div id="specialtyContainer" class="microViewLoading">
	<div class="addSpecialtyContent"></div>
</div>
<div id="specclientContainer" class="microViewLoading">
	<div class="addSpecclientContent"></div>
</div>