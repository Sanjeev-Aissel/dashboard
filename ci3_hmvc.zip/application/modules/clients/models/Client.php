<?php
class Client extends CI_Model {
	function listClients($start,$limit,$sidx,$sord,$arrFilter,$count=false)
	{
		$this->db->select('*');
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('clients');
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('clients',$limit,$start);
		}
	}
	function saveClient($arrClient){
		$id = $arrClient['id'];
		if($id>0){
			$arrClient['modified_by']=$this->session->userdata('user_id');
			$arrClient['modified_on']=date('Y-m-d H:i:s');
			$this->db->where('id',$id);
			if($arrClient = $this->db->update('clients',$arrClient))
				return $id;
		}else{
			$arrClient['created_by']=$this->session->userdata('user_id');
			$arrClient['created_on']=date('Y-m-d H:i:s');
			if($this->db->insert('clients',$arrClient))
				return $this->db->insert_id();
		}
		return false;
	}
	function saveUser($arrUser){
// 		pr($arrUser);
		$id	= $arrUser['id'];
		$arrUser['modified_by']	= $this->session->userdata('user_id');
		$arrUser['modified_on']	= date('Y-m-d H:i:s');
		if(!($id>0)){
			$arrUser['id']	= null;
			$arrUser['created_by']	= $arrUser['modified_by'];
			$arrUser['created_on']	= $arrUser['modified_on'];
			if($this->db->insert('client_users',$arrUser)){
				$id	= $this->db->insert_id();
			}
		}
		unset($arrUser['id']);
		if($arrUser['is_manager']>0 && $arrUser['manager_id']<1){
			$arrUser['manager_id']	= $id;
		}
		$this->db->where('id',$id);
		$this->db->update('client_users',$arrUser);
		return $id;
	}
	function getUsersList($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		$clientId	= 0;
		$loggedInUserClientId	= $this->session->userdata('client_id');
		if($where['client_id']>0){
			$clientId	= $where['client_id'];
		}else if($loggedInUserClientId!=INTERNAL_CLIENT_ID){
			$clientId	= $loggedInUserClientId;
		}	
		$arrStatus	= array('Activated','Deactivated','Deleted');
		$arrUsers = array();
		$this->db->join('clients','clients.id=client_users.client_id','left');
		$this->db->join('client_users as responsible_users','responsible_users.id = client_users.status_modified_by','left');
		if($clientId>0){
			$this->db->where('client_users.client_id',$clientId);
		}
		if(isset($where['user_ids'])){
			$this->db->where_in('client_users.id',$where['user_ids']);
		}
		if(isset($where['user_full_name'])){
			$this->db->like("CONCAT_WS(' ',client_users.first_name,client_users.last_name)",$where['user_full_name']);
		}
		if(isset($where['email'])){
			$this->db->like('client_users.email',$where['email']);
		}
		if(isset($where['client'])){
			$this->db->like('clients.name',$where['client']);
		}
		if(isset($where['company_name'])){
			$this->db->like('client_users.company_name',$where['company_name']);
		}
		if(isset($where['contact'])){
			$this->db->like('client_users.contact',$where['contact']);
		}
		if(isset($where['status'])){
			$status	= 0;
			$pattern = '/^'.$where['status'].'/i';
			if(preg_match($pattern, "Activated")) {
				$status	= 0;
			}else if(preg_match($pattern,"Deactivated")) {
				$status	= 1;
			}else if(preg_match($pattern,"Deleted")) {
				$status	= 2;
			}
			$this->db->where('client_users.status',$status);
		}
		
		if($doCount){
			$this->db->select('client_users.id');
			$count=$this->db->count_all_results('client_users');
			return $count;
		} else {
			$this->db->select('client_users.*,clients.name,responsible_users.first_name as resp_first_name,responsible_users.last_name as resp_last_name');
			if($sidx!='' && $sord!=''){
				switch($sidx){
					case 'user_full_name' :$this->db->order_by("client_users.first_name",$sord);
					break;
					case 'email' :$this->db->order_by("client_users.email",$sord);
					break;
					case 'client' :$this->db->order_by("clients.name",$sord);
					break;
					case 'company_name' :$this->db->order_by("client_users.company_name",$sord);
					break;
					case 'status' :$this->db->order_by("client_users.status",$sord);
					break;
					case 'contact' :$this->db->order_by("client_users.contact",$sord);
					break;
				}
				//$this->db->order_by($sidx,$sord);
			}
			$this->db->order_by('client_users.first_name,client_users.last_name');
			$arrUsersResults	=	$this->db->get('client_users',$limit,$startFrom);
// 			echo $this->db->last_query();
			foreach($arrUsersResults->result_array() as $row){
				$active=false;
				$updateStatusTo	= 0;
				$iconClass	= 'iconForOn';
				$tooltip	= '';
				switch($row['status']){
					case 0: $updateStatusTo	= 1;
							$tooltip	= 'Deactivate User';
							$active=true;
					break;
					case 1: $updateStatusTo	= 0;
							$tooltip	= 'Activate User';
							
					break;
				}
				$row['user_role']	= 'User';
				switch($row['user_role_id']){
					case 2:$row['user_role']	= 'Manager';
					break;
				}
				$row['client'] = $row['name'];
				$row['action']	= '';
				
				if($row['status']!=2){
					$row['action']= '<label class="custom-control custom-checkbox" title="'.$tooltip.'"><input type="checkbox" class="actions custom-control-input" onclick="updateStatus('.$row['id'].','.$updateStatusTo.'); return false;" ';
					if($active)
						$row['action']	.= 'checked';
					$row['action']	.= '><span class="custom-control-indicator"></span></label>';
					$row['action'] .= '<a title="Edit User"  href="'.base_url().'clients/clients/add_user/'.$row['id'].'"><span class="glyphicon glyphicon-edit glyphIcon-class"></span></a>';
// 					if($clientId==INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') == ROLE_MANAGER){
						if($row['status']==1){
							$row['action']	.= '<a  title="Delete User" onclick="updateStatus('.$row['id'].',2,'.$row['user_role_id'].'); return false;"><span class="glyphIcon-class glyphicon glyphicon-trash"></span></a>';
						}					
// 					}
				}
				$row['user_full_name']	= $row['first_name']." ".$row['last_name'];
				$row['updated_by']	= $row['resp_first_name']." ".$row['resp_last_name'];
				$row['status']	= $arrStatus[$row['status']];
				if($row['find_experts'] == 1)
					$row['find_experts'] = 'Yes';
				else
					$row['find_experts'] = 'No';
				$arrUsers[] = $row;
			}
			return $arrUsers;
		}
		
	}
	function updateUserStatus($userId,$status,$managerId=0){
		if(is_array($userId)){
			$remove = array('undefined');
			$userId = array_diff($userId, $remove);
			$this->db->where_in('id',$userId);
		}else{
			$this->db->where('id',$userId);
		}
		$arrUser['status']	= $status;
			$this->db->where_in('client_users.status',array(ACTIVATED_USER,DEACTIVATED_USER));
		$arrUser['status_modified_by']	=   $this->session->userdata('user_id');
		$arrUser['status_modified_on']	=	date('Y-m-d H:i:s');
		if($arrUser = $this->db->update('client_users',$arrUser)){
			if(($status==DEACTIVATED_USER) && $managerId!=0){
				return $this->realignManager($userId,$managerId);
			}
			return true;
		}else
			return false;
	}
	function getClientManagers($clientId=null){
		if($clientId==null){
			$clientId = $this->session->userdata('client_id');
		}
		$arrManagers=array();
		$this->db->select('first_name,id,last_name');
		$this->db->where('client_id',$clientId);
		$this->db->where('is_manager',1);
		$this->db->order_by('first_name','asc');
		$result = $this->db->get('client_users');
		foreach($result->result_array() as $row){
			$manager['id']= $row['id'];
			$manager['name']= $row['first_name']." ".$row['last_name'];
			$arrManagers[]=$manager;
		}
		return $arrManagers;
	}
	function getClientRoles($clientId=NULL){
		$arrRole=array();
		$this->db->select('roles.id,roles.name');
		$this->db->where_in('roles.id',"select client_roles.role_id FROM client_roles WHERE client_roles.client_id=$clientId  AND client_roles.is_associated=1",false);
		$result = $this->db->get('roles');
		foreach($result->result_array() as $row){
			$role['id']= $row['id'];
			$role['name']= $row['name'];
			$arrRole[]=$role;
		}
		return $arrRole;
	}
	function getClientUsers($clientId){
		$userName=array();
		$group_ids = $this->session->userdata('group_ids');
		$clientId = $this->session->userdata('client_id');
		$this->db->select('client_users.first_name,client_users.id,client_users.last_name');
		$this->db->where('client_id',$clientId);
		$this->db->where('client_users.user_role_id !=',ROLE_READONLY_USER);
// 		$this->db->where_in('user_from', array(1,2));
		$this->db->order_by('first_name','asc');
		if(($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER)&& $clientId!=INTERNAL_CLIENT_ID){
			$this->db->join('user_groups','user_groups.user_id = client_users.id');
			$this->db->where("(user_groups.group_id in ($group_ids) OR client_users.user_role_id=0 OR client_users.user_role_id=3)");
			$this->db->group_by('client_users.id');
		}
		$result = $this->db->get('client_users');
		foreach($result->result_array() as $row){
			$userName[$row['id']] = $row['first_name']." ".$row['last_name'];
		}
		return $userName;
	}
	function getUserNameById($userId){
		$this->db->select('user_name,first_name,last_name');
		$this->db->where('id',$userId);
		$resultSet = $this->db->get('client_users');
		
		$data = $resultSet->row();
		return $data->first_name.' '.$data->last_name;
	}
	function getUserManagerEmailId($userId){
		$emaiId = $userId;
		$arrUserIds	= array();
		if(!is_array($userId)){
			$arrUserIds[]	= $userId;
		}
		$this->db->select('managers.email');
		$this->db->where_in('client_users.id',$arrUserIds);
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->join('client_users as managers','managers.id = client_users.manager_id');
		$results = $this->db->get('client_users');
		if($results->num_rows() > 0){
			$row = $results->row_array();
			$emaiId = $row['email'];
		}
		return $emaiId;
	}
	function getUserEmailIdById($arrUserIds=array()){
		$clientId	= $this->session->userdata('client_id');
		if(!is_array($arrUserIds)){
			$arrUserIds[]	= $arrUserIds;
		}
		$this->db->select('client_users.email');
		$this->db->where_in('client_users.id',$arrUserIds);
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->where("(client_users.client_id = $clientId OR client_users.client_id = ".INTERNAL_CLIENT_ID.")");
		$results = $this->db->get('client_users');
		foreach($results->result_array() as $row){
			$arrUsers[] = $row['email'];
		}
		return $arrUsers;
	}
	function getUsermanager($userId){
		$this->db->select('managers.*');
		$this->db->where_in('client_users.id',$userId);
		$this->db->join('client_users as managers','managers.id = client_users.manager_id');
		$results = $this->db->get('client_users');
		return $results->result_array();
	}
}