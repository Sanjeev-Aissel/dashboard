<?php

/**
 * This is Controller file of 'Opt_In_Out'
 *
 * @author Vinod R H
 * @since
 * @package application.controllers
 * @created on 23-06-2017
 */
class Kol_consents extends Controller {
    
    private $loggedUserId = null;
    
    //Constructor
    function Kol_consents() {
        parent::Controller();
        $this->load->model('kol_consent');
        $this->load->model("country_helper");
        $this->load->model('common_helpers');
        $this->load->model('organization');
        $this->load->model("Specialty");
        $this->load->model('align_user');
        $this->load->model("kol");
        $this->loggedUserId = $this->session->userdata('user_id');
    }
    
    function set_lang_url_link($kolId){
        $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
        $this->session->set_userdata('lang',$langName);
        $data['status'] = true;
        echo json_encode($data);
    }
    function generate_url_link($kolId){
        $data = array();
        $date = date('Y-m-d H:i:s');
        $arrLinkData = array();
        $arrLinkData['kol_id'] = $kolId;
        $arrLinkData['unique_id'] = md5($kolId.$date);
        $arrLinkData['status'] = 0;
        $arrLinkData['created_by'] = $this->loggedUserId;
        $arrLinkData['created_on'] = date("Y-m-d H:i:s");
        $arrLinkData['note'] = '';
        $arrLinkData['upload_file_content'] = '';
        $queryLink = $this->kol_consent->getUrlStatusByKolId($kolId);
        $kolName = $this->kol_consent->getKolNameByKolId($kolId);
        $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
        //     	if($langName==null){
        //     	    $langName = 'english';
        //     	}
        $ktlEmailId = $this->kol_consent->getKolEmailByKolId($kolId);
        $emailIds = '';
        $user_email = $this->kol_consent->getAssignedUserEmails($kolId);
        $seperator = '';
        foreach($user_email as $row){
            $emailIds .= $seperator."'".$row."'";
            $seperator = ',';
        }
        $landingContent = lang('OptInOutEmail.LandingContent');
        $landingMissionCaption = lang('OptInOutEmail.LandingMissionCaption');
        $landingMissionContent = lang('OptInOutEmail.LandingMissionContent');
        if(!$queryLink){
            $query = $this->kol_consent->generateUrlLink($arrLinkData);
            if($query == 'updated'){
                $arrLogDetails = array(
                    'module'=>"opt_in_out",
                    'description'=>'Requested Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$this->loggedUserId,
                    'type' => 'Requested Url',
                    'status' => STATUS_SUCCESS,
                    'user_id' => $this->loggedUserId,
                    'transaction_table_id'=>'',
                    'transaction_name'=>'Opt-in Requested',
                    'miscellaneous1'=>$kolId
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                
                //Email Notification
                $urlLink = base_url().'kol_consents/change_language/'.$arrLinkData['unique_id'].'/'.$langName.'/page';
                $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
                $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
                $img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
                $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
								$url
							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
								$content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
								$content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
								$content .="<tr><td align='center'>$img</td></tr>";
								$content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='font-size: 18px;margin:1em 0;'>$landingMissionContent</p></td></tr>";
								$content .="</table>";
								$emailStatus = $this->send_email_notification($subject,$content,$kolId,false);
								if($emailStatus){
								    $data['status'] = true;
								    $data['emailId'] = $emailIds.'<br/><br/>'.$popUpContent;
								}
            }else{
                if($query > 0){
                    $arrLogDetails = array(
                        'module'=>"opt_in_out",
                        'description'=>'New Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$this->loggedUserId,
                        'type' => 'New Url',
                        'status' => STATUS_SUCCESS,
                        'user_id' => $this->loggedUserId,
                        'transaction_table_id'=>'',
                        'transaction_name'=>'New',
                        'miscellaneous1'=>$kolId
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    log_user_activity(null, true);
                    //Email Notification
                    $urlLink = base_url().'kol_consents/change_language/'.$arrLinkData['unique_id'].'/'.$langName.'/page';
                    $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
                    $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
                    $img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
                    $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
								$url
							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
								$content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
								$content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
								$content .="<tr><td align='center'>$img</td></tr>";
								$content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='margin:1em 0;font-size: 18px;'>$landingMissionContent</p></td></tr>";
								$content .="</table>";
								$emailStatus = $this->send_email_notification($subject,$content,$kolId,false);
								if($emailStatus){
								    $data['status'] = true;
								    $data['emailId'] = $emailIds.'<br/><br/>'.$popUpContent;
								}
                }
            }
        }else{
            $updateDate = $this->kol_consent->updateKolModifiedDate($kolId);
            $arrLogDetails = array(
                'module'=>"opt_in_out",
                'description'=>'Requested Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$this->loggedUserId,
                'type' => 'Requested Url',
                'status' => STATUS_SUCCESS,
                'user_id' => $this->loggedUserId,
                'transaction_table_id'=>'',
                'transaction_name'=>'Opt-in Requested',
                'miscellaneous1'=>$kolId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
            //Email Notification
            $urlLink = base_url().'kol_consents/change_language/'.$queryLink.'/'.$langName.'/page';
            $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
            $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
            $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
								$url
							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
								$img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
								$content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
								$content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
								$content .="<tr><td align='center'>$img</td></tr>";
								$content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='margin:1em 0;font-size: 18px;'>$landingMissionContent</p></td></tr>";
								$content .="</table>";
								$emailStatus = $this->send_email_notification($subject,$content,$kolId,false);
								if($emailStatus){
								    $data['status'] = true;
								    $data['emailId'] = $emailIds.'<br/><br/>'.$popUpContent;
								}
        }
        $this->session->unset_userdata('lang',$langName);
        echo json_encode($data);
    }
    
    function change_language($uniqueId,$language = null,$type){
        $this->session->set_userdata('lang',$language);
        if($type =='form'){
            redirect('/kol_consents/edit_kol/'.$uniqueId.'/'.$language, 'refresh');
        }else{
            redirect('/kol_consents/process_selection/'.$uniqueId.'/'.$language.'/form', 'refresh');
        }
        
    }
    
    function process_selection($uniqueId,$language = null,$type = null){
        //Language
        //         if($language=='' || empty($language)){
        //             $language = 'english';
        //         }
        $this->lang->load('kolm',$langName);
        $this->session->set_userdata('lang',$language);
        $status = $this->kol_consent->getUrlStatusByUniqueId($uniqueId);
        $kolId = $this->kol_consent->getKolNameByUniqueId($uniqueId);
        $kolName = $this->kol_consent->getKolNameByKolId($kolId);
        $data = array();
        $data['kolName'] = $kolName;
        $data['languages'] = $this->kol->getLanguages();
        $data['lang'] = $language;
        $optSuccessMsgKolNameCaption = lang('OptInOut.KOlName');
        $optInSuccessMsgBodyContent = lang('OptInOutMsg.Optin');
        $optOutSuccessMsgBodyContent = lang('OptInOutMsg.Optout');
        if($language=='czech'){
            $dear = "$optSuccessMsgKolNameCaption";
        }elseif($language=='japan'){
            $dear = "$kolName $optSuccessMsgKolNameCaption";
        }elseif($language=='russia'){
            $dear = "$optSuccessMsgKolNameCaption $kolName!";
        }else{
            $dear = "$optSuccessMsgKolNameCaption $kolName";
        }
        //$optExpirySuccessMsgBodyContent = lang('OptInOutMsg.Optexpiry');
        if($status > 0){
            $arrLogDetails = array(
                'module'=>"opt_in_out",
                'description'=>'Visted on Opt-In / Opt-Out Page by '.$kolId.' - '.$kolName,
                'type' => 'Opt In / Opt Out Page',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'transaction_name'=>'Visited',
                'miscellaneous1'=>$kolId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            $data['kolId'] = $uniqueId;
            $this->load->view('kols/consent/process_selection',$data);
        }else{
            $statusValue = $this->kol_consent->getUrlStatusValue($uniqueId);
            
            if($type!=null && $type == 'form'){
                if(!$statusValue){
                    $arrLogDetails = array(
                        'module'=>"opt_in_out",
                        'description'=>'Visited on expired URL link by '.$kolId.' - '.$kolName,
                        'type' => 'Expired Url Links',
                        'status' => STATUS_FAIL,
                        'transaction_table_id'=>'',
                        'transaction_name'=>'Visited',
                        'miscellaneous1'=>$kolId
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    //     		    log_user_activity(null, true);
                    
                    $data['content'] = "This link is currently inactive. Please reach out to your Hill’s contact to send you a new Opt-in/Opt-out link.";
                }
                
                if($statusValue == 1){
                    $data['content'] = "$dear <br/><br/>
        			                    $optOutSuccessMsgBodyContent";
                }
                if($statusValue == 2){
                    $data['content'] = "$optInSuccessMsgBodyContent";
                }
            }else{
                $arrLogDetails = array(
                    'module'=>"opt_in_out",
                    'description'=>'Visited on expired URL link by '.$kolId.' - '.$kolName,
                    'type' => 'Expired Url Links',
                    'status' => STATUS_FAIL,
                    'transaction_table_id'=>'',
                    'transaction_name'=>'Visited',
                    'miscellaneous1'=>$kolId
                );
                $this->config->set_item('log_details', $arrLogDetails);
                //     		    log_user_activity(null, true);
                $data['content'] = "This link is currently inactive. Please reach out to your Hill’s contact to send you a new Opt-in/Opt-out link.";
                
            }
            $this->load->view('kols/consent/process_success',$data);
        }
    }
    
    
    
    function save_confirm_opt_in_out($optValue,$uniqueId){
        $kolId = $this->kol_consent->getUrlStatusByUniqueId($uniqueId);
        $kolName = $this->kol_consent->getKolNameByKolId($kolId);
        $ktlEmailId = $this->kol_consent->getKolEmailByKolId($kolId);
        $query = $this->kol_consent->updateStatusOfOptInOut($optValue,$uniqueId);
        $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
        //     	 if($langName==null){
        //     	     $langName = 'english';
        //     	 }
        $this->session->set_userdata('lang',$langName);
        if($query){
            $optOutKolNameCaption = lang('OptInOut.KOlName');
            $optOutSubjectContent = lang('OptInOutEmail.OptoutSubject');
            $optOutBodyContent = lang('OptInOutEmail.OptoutBody');
            
            if($langName=='czech'){
                $dear = "$optOutKolNameCaption";
            }elseif($langName=='japan'){
                $dear = "$kolName $optOutKolNameCaption";
            }elseif($langName=='russia'){
                $dear = "$optOutKolNameCaption $kolName!";
            }else{
                $dear = "$optOutKolNameCaption $kolName";
            }
            //$this->kol_consent->deleteKolVisibility($kolId);
            $data['id'] = $uniqueId;
            $arrLogDetails = array(
                'module'=>"opt_in_out",
                'description'=>'The request from KTL was Opted-Out by '.$kolId.' - '.$kolName,
                'type' => 'Opted Out',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'transaction_name'=>'Opt-out',
                'miscellaneous1'=>$kolId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
            //Email Notification
            $img = '<img src="'.base_url().'images/hills_logo.jpg" style="display:block;text-align:center;margin: 0 auto;" width="148" height="148">';
            $subject = "$optOutSubjectContent";
            $content = "$dear <br/>
                        $optOutBodyContent<br/><br/>
                        $img";
                        if(FUTURE_REQ_SET){
                            $emailStatus = $this->send_email_notification($subject,$content,$kolId,false);
                        }else{
                            $emailStatus = $this->send_email_notification($subject,$content,$kolId,true);
                        }
                        if($emailStatus){
                            $data['status'] = true;
                            $this->delete_created_ol($kolId);//Delete Kol Details Retaining FN,LN
                        }
        }else{
            $data['status'] = false;
        }
        echo json_encode($data);
    }
    
    function edit_kol($uniqueId,$language = null){
        //Language
        //$this->session->set_userdata('lang',$language);
        $status = $this->kol_consent->getUrlStatusByUniqueId($uniqueId);
        $kolId = $this->kol_consent->getUrlStatusByUniqueId($uniqueId);
        $kolName = $this->kol_consent->getKolNameByKolId($kolId);
        $data = array();
        $data['lang'] = $language;
        $data['kolName'] = $kolName;
        $data['languages'] = $this->kol->getLanguages();
        if($status > 0){
            //Log Activity
            $arrLogDetails = array(
                'module'=>"opt_in_out",
                'description'=>'Visited on Opt-In Form by '.$kolId.' - '.$kolName,
                'type' => 'Opt In Page',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'transaction_name'=>'Visited',
                'miscellaneous1'=>$kolId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
            $arrKolDetail = $this->kol_consent->getKolDetails($status);
            $data['arrSalutations'] = $arrSalutations;
            $data['arrKolData'] = $arrKolDetail;
            $data['uniqueId'] = $uniqueId;
            $this->load->view('kols/consent/optin_form', $data);
        }else{
            redirect('/kol_consents/process_selection/'.$uniqueId, 'refresh');
        }
    }
    
    function edit_kol_status($kolId){
        $data['statusName'] = $this->kol_consent->getOptInOutStatusNames();
        $data['kolData'] = $this->kol_consent->getKolStatusDetails($kolId);
        $this->load->view('kols/consent/edit_opt_in_out_status', $data);
    }
    
    function save_kol_details(){
        $newAddedContent = '';
        $uniqueId = $this->input->post('unique_id');
        $kolId = $this->kol_consent->getUrlStatusByUniqueId($uniqueId);
        $kolUniqueId = $this->common_helpers->getUniqueIdByKolId($kolId);
        $createdBy = $this->kol_consent->getCreatedByKolId($kolId);
        $clientId = $this->kol_consent->getClientIdByCreatedByIdOfKolId($kolId);
        $kolName = $this->kol_consent->getKolNameByKolId($kolId);
        $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
        // 	    	if($langName==null){
        // 	    	    $langName = 'english';
        // 	    	}
        $this->session->set_userdata('lang',$langName);
        $arrTitle = $this->kol_consent->getKolTitle();
        $arrKolDetails = array();
        $arrKolDetails['salutation'] = $this->input->post('salutation');
        $arrKolDetails['first_name'] = $this->input->post('first_name');
        $arrKolDetails['last_name'] = $this->input->post('last_name');
        $arrKolDetails['title'] = $this->input->post('title');
        $arrKolDetails['org_name'] = $this->input->post('org_name');
        $arrKolDetails['city'] = $this->input->post('city_name');
        $arrKolDetails['state'] = $this->input->post('state_name');
        $arrKolDetails['postal_code'] = $this->input->post('postal_code');
        $arrKolDetails['country'] = $this->input->post('country_name');
        $arrKolDetails['phone_number'] = $this->input->post('phone_number');
        $arrKolDetails['email'] = $this->input->post('primary_email');
        $arrKolDetails['note'] = $this->input->post('note');
        $expireYear = $this->kol_consent->getYearRange($kolId);
        if($expireYear > 0){
            $arrKolDetails['expire_date'] = date("Y-m-d", strtotime("+$expireYear years"));
        }
        $arrKolDetails['note'] = $this->input->post('note');
        $totalFilter = count(array_filter($_FILES['userfile']['name']));
        $total = count($_FILES['userfile']['name']);
        if($totalFilter>0){
            for($i=0; $i<$total; $i++) {
                if($_FILES['userfile']['name'][$i]==''){
                    continue;
                }
                    $arrNoteDetails = array();
                    $arrNoteDetails['note'] = trim($this->input->post('note'));
                    $arrNoteDetails['created_on'] = date("Y-m-d H:i:s");
                    $arrNoteDetails['created_by'] = $createdBy;
                    $arrNoteDetails['client_id'] = $clientId;
                    $arrNoteDetails['is_from_opt_in'] = 1;
                    $arrNoteDetails['kol_id'] = $kolId;
                    $arrNoteDetails['document']= '';
                    $arrNoteDetails['document_name']= '';
                    $target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/opt_in_out_files/";
                    $note_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
                    $path_info = pathinfo($_FILES['userfile']['name'][$i]);
                    $newFileName	= $arrKolDetails['first_name'].' '.$arrKolDetails['last_name'].' - '.random_string('unique', 20).".".$path_info['extension'];
                    $overview_file_target_path = $target_path ."/". $newFileName;
                    $note_file_target_path = $note_path ."/". $newFileName;
                    if(move_uploaded_file($_FILES['userfile']['tmp_name'][$i],$overview_file_target_path)){
                        copy($overview_file_target_path, $note_file_target_path);
                        $arrNoteDetails['document'] = $newFileName;
                        $fname = explode('.', $_FILES['userfile']['name'][$i]);
                        $arrNoteDetails['orginal_doc_name']= $_FILES['userfile']['name'][$i];
                        $arrNoteDetails['document_name']= $fname[0];
                        if(empty($arrNoteDetails['note'])){
                            $arrNoteDetails['note'] = $fname[0];
                        }else{
                            $arrNoteDetails['note'] = $arrNoteDetails['note'];
                        }
                    }
                    
                    $this->kol->saveNote($arrNoteDetails);
                    $arrKolDetails['upload_file_content'] = $newFileName;
            }
        }else{
            $arr['note'] = trim($this->input->post('note'));
            if(!empty($arr['note'])){
                $arr['created_on'] = date("Y-m-d H:i:s");
                $arr['created_by'] = $createdBy;
                $arr['client_id'] = $clientId;
                $arr['is_from_opt_in'] = 1;
                $arr['kol_id'] = $kolId;
                $arr['document']= '';
                $arr['document_name']= '';
                $this->kol->saveNote($arr);
            }
        }
        // 	    	$arrKolDetails['upload_file_content'] = $files['userfile']['name'];
        $arrKolDetails['status'] = 2;
        $query = $this->kol_consent->updateKolDetails($arrKolDetails,$uniqueId,$kolId);
        if($query){
            $arrKolData = array();
            $arrKolData['salutation'] = $arrKolDetails['salutation'];
            $arrKolData['first_name'] = $arrKolDetails['first_name'];
            $arrKolData['last_name'] = $arrKolDetails['last_name'];
            $arrKolData['primary_email'] = $arrKolDetails['email'];
            $arrKolData['primary_phone'] = $arrKolDetails['phone_number'];
            // 	    	    $arrKolData['title'] = array_search($arrKolDetails['title'], $arrTitle);
            if (!empty($arrKolDetails['title'])) {// save specialty if not exists
                $arrResTitle = $this->kol_consent->saveTitle($arrKolDetails['title'],$clientId);
                if($arrResTitle['status']){
                    $newAddedContent .= "<tr><th>Title</th><td>".$arrKolDetails['title']."</td></tr>";
                    $arrLogDetails = array(
                        'module'=>"opt_in_out",
                        'description'=>'New Title '.$arrKolDetails['title'].'has been added by '.$kolId.' - '.$kolName,
                        'type' => 'Opt-In process',
                        'status' => STATUS_SUCCESS,
                        'transaction_table_id'=>'',
                        'description'=>'New Title '.$arrKolDetails['title'].'has been added by '.$kolId.' - '.$kolName,
                        'miscellaneous1'=>$kolId
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    log_user_activity(null, true);
                }
                $arrKolData['title'] = $arrResTitle['id'];
            }else{
                $arrKolData['title'] = 0;
            }
            // Get the Country Id,State Id,City Id based on the provided Names
            $arrResCountry = $this->country_helper->checkCountryIfExistElseAdd($arrKolDetails['country'],true);
            if($arrResCountry['status']){
                $globalRegion = $this->input->post('global_region');
                $updateGlobalRegion = $this->kol_consent->updateGlobalRegionByCountryId($arrResCountry['id'],$globalRegion);
                $newAddedContent .= "<tr><th>Country</th><td>".$arrKolDetails['country']."</td></tr>";
                $arrLogDetails = array(
                    'module'=>"opt_in_out",
                    'description'=>'New Country '.$arrKolDetails['country'].'has been added by '.$kolId.' - '.$kolName,
                    'type' => 'Opt-In process',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'description'=>'New Country '.$arrKolDetails['country'].'has been added by '.$kolId.' - '.$kolName,
                    'miscellaneous1'=>$kolId
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
            }
            $arrKolData['country_id'] = $arrResCountry['id'];
            $arrResState = $this->country_helper->checkStateIfExistElseAdd($arrKolDetails['state'],$arrKolData['country_id'],true);
            if($arrResState['status']){
                $newAddedContent .= "<tr><th>State</th><td>".$arrKolDetails['state']."</td></tr>";
                $arrLogDetails = array(
                    'module'=>"opt_in_out",
                    'description'=>'New State '.$arrKolDetails['state'].'has been added by '.$kolId.' - '.$kolName,
                    'type' => 'Opt-In process',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'description'=>'New State '.$arrKolDetails['state'].'has been added by '.$kolId.' - '.$kolName,
                    'miscellaneous1'=>$kolId
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
            }
            $arrKolData['state_id'] = $arrResState['id'];
            if(!empty($arrKolDetails['city'])){
                $arrResCity = $this->country_helper->checkCityIfExistElseAdd($arrKolDetails['city'],$arrKolData['state_id'],$arrKolData['country_id'],true);
                if($arrResCity['status']){
                    $newAddedContent .= "<tr><th>City</th><td>".$arrKolDetails['city']."</td></tr>";
                    $arrLogDetails = array(
                        'module'=>"opt_in_out",
                        'description'=>'New City '.$arrKolDetails['city'].'has been added by '.$kolId.' - '.$kolName,
                        'type' => 'Opt-In process',
                        'status' => STATUS_SUCCESS,
                        'transaction_table_id'=>'',
                        'description'=>'New City '.$arrKolDetails['city'].'has been added by '.$kolId.' - '.$kolName,
                        'miscellaneous1'=>$kolId
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    log_user_activity(null, true);
                }
                $arrKolData['city_id'] = $arrResCity['id'];
            }
            $arrKolData['postal_code'] = ucwords($arrKolDetails['postal_code']);
            //Check whether Organization is Exist
            $org_id = $this->kol_consent->getOrgIdByOrgName($arrKolDetails['org_name']);
            if(!$org_id){
                $arrOrgData['name'] = $arrKolDetails['org_name'];
                $arrOrgData['city_id'] = $arrKolData['city_id'];
                $arrOrgData['state_id'] = $arrKolData['state_id'];
                $arrOrgData['country_id'] = $arrKolData['country_id'];
                $arrOrgData['postal_code'] = $arrKolData['postal_code'];
                $arrOrgData['created_by'] = $createdBy;
                $arrOrgData['created_on'] = date('Y-m-d H:i:s');
                $arrOrgData['modified_by'] = $createdBy;
                $arrOrgData['modified_on'] = date('Y-m-d H:i:s');
                $arrOrgData['type_id'] = 7;
                $arrOrgData['profile_type'] = 1;
                $arrOrgData['status_otsuka'] = "ACTV";
                $arrOrgData['status'] = "Completed";
                $org_id = $this->organization->saveOrganization($arrOrgData);
                //Save org visibility
                if(ORGS_VISIBILITY){
                	$orgVisibility = array();
                	$orgVisibility['org_id'] = $org_id;
                	$orgVisibility['client_id'] = $this->session->userdata('client_id');
                	$orgVisibility['associationFlag'] = 'associate';
                	$this->organization->saveOrgClientAssociation($orgVisibility);
                }
                $formData = $_POST;
                $formData = json_encode($formData);
                $arrLogDetails = array(
                    'module' => 'Organization',
                    'type' => LOG_ADD,
                    'description' => 'New Organization',
                    'status' => STATUS_SUCCESS,
                    'transaction_id' => $org_id,
                    'transaction_table_id' => ORGANIZATIONS,
                    'transaction_name' => "New Organization",
                    'form_data' => $formData,
                    'parent_object_id' => $org_id
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null,true);
                
                //If new organization added mail triggers
                $newAddedContent .= "<tr><th>Organization</th><td>".$arrKolDetails['org_name']."</td></tr>";
                $arrLogDetails = array(
                    'module'=>"opt_in_out",
                    'description'=>'New Organization '.$arrKolDetails['org_name'].'has been added by '.$kolId.' - '.$kolName,
                    'type' => 'Opt-In process',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'description'=>'New Organization '.$arrKolDetails['org_name'].'has been added by '.$kolId.' - '.$kolName,
                    'miscellaneous1'=>$kolId
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                //exit;
                $orgData['org_id'] 			= $org_id;
                $orgData['country_id'] 	= $arrOrgData['country_id'];
                $orgData['state_id'] 	= $arrOrgData['state_id'];
                $orgData['city_id'] 		= $arrOrgData['city_id'];
                $orgData['postal_code'] 	= $arrKolData['postal_code'];
                $orgData['phone_number_primary'] 	= $arrKolData['primary_phone'];
                $orgData['phone_type_primary'] 	= 10;
                $orgData['is_primary'] 			= 1;
                $orgData['created_by'] 		= $createdBy;
                $orgData['created_on'] 		= date('Y-m-d H:i:s');
                $orgData['modified_by'] 	= $createdBy;
                $orgData['modified_on'] 	= date('Y-m-d H:i:s');
                $orgLocLasId = $this->organization->saveLocation($orgData);
                if(isset($orgData['phone_type_primary']) && $orgData['phone_number_primary'] > 0){
                    $orgPhone = array();
                    $orgPhone['type'] = 10;
                    $orgPhone['number'] = $orgData['phone_number_primary'];
                    $orgPhone['contact_type'] = 'organization';
                    $orgPhone['contact'] = $org_id;
                    $orgPhone['is_primary'] = 1;
                    $orgPhone['location_id'] = $orgLocLasId;
                    $orgPhone['created_by'] = $createdBy;
                    $orgPhone['created_on'] = date('Y-m-d H:i:s');
                    $lastPhoneId = $this->kol->savePhone($orgPhone);
                }
            }
            $arrKolData['org_id'] = $org_id;
            $arrKolData['status'] = 'Completed';
            $arrKolData['profile_type'] = USER_ADDED;
            $arrKolData['modified_on'] 	= date('Y-m-d H:i:s');
            $arrKolData['opt_in_out_date'] = date('Y-m-d H:i:s');
            $this->kol->updateKolInfo($arrKolData, $kolId);//Update Kol Details
            
            //Kol location details
            $arrLocationData = array();
            $arrLocationData['org_institution_id'] = $org_id;
            // Get the Country Id,State Id,City Id based on the provided Names
            //$country_name = trim($reader->sheets[$k]["cells"][$row][18]);
            $arrLocationData['country_id'] = $arrKolData['country_id'];
            $arrLocationData['state_id'] = $arrKolData['state_id'];
            if(!empty($arrKolDetails['city'])){
                $arrLocationData['city_id'] = $arrKolData['city_id'];
            }
            
            if ($arrLocationData['state_id'] == '')
                unset($arrLocationData['state_id']);
                if ($arrLocationData['city_id'] == '')
                    unset($arrLocationData['city_id']);
                    $arrLocationData['postal_code'] = $arrKolData['postal_code'];
                    $arrLocationData['phone_type'] = 10;
                    $arrLocationData['phone_number'] = $arrKolData['primary_phone'];
                    $arrLocationData['is_primary'] = 1;
                    $arrLocationData['title'] = $arrKolData['title'];
                    $arrLocationData['created_by'] = $createdBy;
                    $arrLocationData['created_on'] = date('Y-m-d H:i:s');
                    $arrLocationData['modified_by'] = $createdBy;
                    $arrLocationData['modified_on'] = date('Y-m-d H:i:s');
                    $isPresentOrg = '';
                    $updatedId = '';
                    $arrLocationDataExist['kol_id'] = $kolId;
                    $arrLocationDataExist['org_institution_id'] = $org_id;
                    $isExist = $this->kol->getKolLocationByOrgInstId($arrLocationDataExist);
                    if($isExist > 0){
                        $updatedId = $isExist;
                        $isPresentOrg = true;
                        $lastId = $this->kol->updateKolPrimaryLocation($arrLocationData, $kolId);
                        $data['id'] = $kol_id;
                    }else{
                        $isPresentOrg = false;
                        $data['id'] = $kolId;
                        $arrLocationData['kol_id'] = $kolId;
                        $genericId = $this->common_helpers->getGenericId("Location Form");
                        $arrLocationData['generic_id'] = $genericId;
                        $lastId = $this->kol->saveLocation($arrLocationData);
                        $lastInsertedLocationId = $lastId;
                    }
                    //Primary Email
                    if ($this->input->post('primary_email') != '') {
                        $arrEmailData = array();
                        $arrEmailData['type'] = 'Work';
                        $arrEmailData['email'] = trim($arrKolDetails['email']);
                        $arrEmailData['is_primary'] = 1;
                        $arrEmailData['contact'] = $kolId;
                        $arrEmailData['created_by'] = $createdBy;
                        $arrEmailData['created_on'] = date('Y-m-d H:i:s');
                        $arrEmailData['modified_by'] = $createdBy;
                        $arrEmailData['modified_on'] = date('Y-m-d H:i:s');
                        $this->kol->updateOlEmail($arrEmailData);
                    }
                    //Primary Phone
                    if($isPresentOrg){
                        /* Update phone to phone_number table */
                        $arrPhoneDataExist['contact'] = $kolId;
                        if($updatedId ==''){
                            $arrPhoneDataExist['location_id'] = $lastInsertedLocationId;
                        }else{
                            $arrPhoneDataExist['location_id'] = $updatedId;
                        }
                        $isExist = $this->kol->getKoPhoneByLocationId($arrPhoneDataExist);
                        if($isExist > 0){
                            if ($this->input->post('phone_number') != '') {
                                $arrPhoneData = array();
                                $arrPhoneData['type'] = 10;
                                $arrPhoneData['number'] = trim($this->input->post('phone_number'));
                                $arrPhoneData['is_primary'] = 1;
                                $arrPhoneData['contact'] = $kolId;
                                $arrPhoneData['contact_type'] = "location";
                                if($updatedId ==''){
                                    $arrPhoneData['location_id'] = $lastInsertedLocationId;
                                }else{
                                    $arrPhoneData['location_id'] = $updatedId;
                                }
                                $arrPhoneData['created_by'] = $createdBy;
                                $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                                $arrPhoneData['modified_by'] = $this->loggedUserId;
                                $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                                $this->kol->updateOlPhone($arrPhoneData);
                            }
                        }else{
                            if ($this->input->post('phone_number') != '') {
                                $arrPhoneData = array();
                                $arrPhoneData['type'] = 10;
                                $arrPhoneData['number'] = trim($this->input->post('phone_number'));
                                $arrPhoneData['is_primary'] = 1;
                                $arrPhoneData['contact'] = $kolId;
                                if($updatedId ==''){
                                    $arrPhoneData['location_id'] = $lastInsertedLocationId;
                                }else{
                                    $arrPhoneData['location_id'] = $updatedId;
                                }
                                $arrPhoneData['contact_type'] = "location";
                                $arrPhoneData['created_by'] = $createdBy;
                                $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                                $arrPhoneData['modified_by'] = $this->loggedUserId;
                                $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                                $this->kol->savePhone($arrPhoneData);
                            }
                        }
                        
                    }else{
                        /* Save phone to phone_number table */
                        if ($this->input->post('phone_number') != '') {
                            $arrPhoneData = array();
                            $arrPhoneData['type'] = 10;
                            $arrPhoneData['number'] = trim($this->input->post('phone_number'));
                            $arrPhoneData['is_primary'] = 1;
                            $arrPhoneData['contact'] = $kolId;
                            $arrPhoneData['location_id'] = $lastId;
                            $arrPhoneData['contact_type'] = "location";
                            $arrPhoneData['created_by'] = $createdBy;
                            $arrPhoneData['created_on'] = date('Y-m-d H:i:s');
                            $arrPhoneData['modified_by'] = $this->loggedUserId;
                            $arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                            $this->kol->savePhone($arrPhoneData);
                        }
                    }
                    $arrLogDetails = array(
                        'module'=>"opt_in_out",
                        'description'=>'The request from KTL was Opted-In by '.$kolId.' - '.$kolName,
                        'type' => 'Opted In',
                        'status' => STATUS_SUCCESS,
                        'transaction_table_id'=>'',
                        'transaction_name'=>'Opt-in Approved',
                        'miscellaneous1'=>$kolId
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    log_user_activity(null, true);
                    if($newAddedContent!=''){
                        $urlLink = base_url().'kols/view/'.$kolUniqueId;
                        $linkUrlKtl	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">View KTL</a>';
                        $addedSubject = "Opt-in field value changes - Hill's";
                        $addedSubject = "Opt-in field value changes - Hill's";
                        $addedContent = "<html><head>";
                        $addedContent .= "<style>table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;} td, th { border: 1px solid #CCC; height: 30px; } th { background: #F3F3F3; font-weight: bold; }	td { background: #FAFAFA; text-align: center;}</style>";
                        $addedContent .= "</head><body><div>";
                        $addedContent .= "Hi, <br/><br/>For the KTL $kolName, below field values have been added which is not available in our application. Please verify the changes<br/><br/>$linkUrlKtl<br/><br/>";
                        $addedContent .=  "<table>$newAddedContent</table><br/><br/>Thanks</div></body></html>";
                        $mailStatus = $this->send_email_new_added_records($addedSubject,$addedContent);
                    }
                    //Email Notification
                    //$url	= '<a href="'.base_url().'opt_in_out/confirm_opt_in_out/'.$arrLinkData['unique_id'].'">View KTL</a>';
                    $optInKolNameCaption = lang('OptInOut.KOlName');
                    $optInSubjectContent = lang('OptInOutEmail.OptinSubject');
                    $optInBodyContent = lang('OptInOutEmail.OptinBody');
                    if($langName=='czech'){
                        $dear = "$optInKolNameCaption";
                    }elseif($langName=='japan'){
                        $dear = "$kolName $optInKolNameCaption";
                    }elseif($langName=='russia'){
                        $dear = "$optInKolNameCaption $kolName!";
                    }else{
                        $dear = "$optInKolNameCaption $kolName";
                    }
                    $img = '<img src="'.base_url().'images/hills_logo.jpg" style="display:block;text-align:center;margin: 0 auto;" width="148" height="148">';
                    $subject = "$optInSubjectContent";
                    $content = "$dear <br/>
                            $optInBodyContent<br/><br/>
                            $img";
                            $emailStatus = $this->send_email_notification($subject,$content,$kolId,true);
                            if($emailStatus){
                                $data = true;
                            }
        }else{
            $data = false;
        }
        echo $data;
    }
    /**
     * Sends a mail of success and faliure of the Opt In - Opt Out
     * @param string $subject
     * @param string $content
     * @param string $emailId
     */
    function send_email_notification($subject,$content,$kolId,$isSubmitted = false){
        $emailIds = '';
        $seperator = '';
        $user_email = $this->kol_consent->getAssignedUserEmails($kolId);
        foreach($user_email as $row){
            $emailIds .= $seperator."'".$row."'";
            $seperator = ',';
        }
        if($isSubmitted){
            $ktlEmail = $this->kol_consent->getKolEmailByKolId($kolId);
        }
        //     	$emailId = 'vhanagal@gmail.com';
        $fromEmail	= OPTINOUT_SENDER;
        $note = nl2br($content);
        /* $config['protocol']  = PROTOCOL;
         $config['smtp_host'] = HOST;
         $config['smtp_port'] = PORT;
         $config['smtp_user'] = USER;
         $config['smtp_pass'] = PASS;
         $config['mailtype'] 		= 'html'; */
        $config = email_config_initializer('optinout');
        $this->load->library('email', $config);
        $this->email->initialize($config);
        $this->email->from($config['smtp_user'],$fromEmail);
        if($isSubmitted){
            $this->email->to($ktlEmail);
            $this->email->cc($user_email);
        }else{
            $this->email->to($user_email);
        }
        $this->email->message($note);
        $this->email->subject($subject);
        if($this->email->send()){
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email sent to ".$emailIds,
                'type' => 'Email Notification',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'user_id' => $this->loggedUserId,
                'transaction_name'=>"Email sent to ".$emailIds
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status	=  true;
        }else{
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email Not sent to ".$emailIds,
                'type' => 'Email Notification',
                'status' => STATUS_FAIL,
                'transaction_table_id'=>'',
                'transaction_name'=>"Email Not sent to ".$emailIds
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status 	=  false;
        }
        $this->email->clear(TRUE);
        return $status;
    }
    function file_download($lang){
        $filePath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/data_consent_forms/data_consent_form_$lang.docx";
        $filename = "data_consent_form_$lang.docx";
        header('Content-Description: File Transfer');
        header('Cache-Control: public');
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header("Content-Transfer-Encoding: binary");
        header('Content-Disposition: attachment; filename='. basename($filePath));
        header('Content-Length: '.filesize($filePath));
        ob_clean(); #THIS!
        flush();
        readfile($filePath);
        exit;
    }
    /*
     * Opt out Kols By Expire Date
     */
    function opt_in_out_expire_status(){
        $kolIds = $this->kol_consent->getExpiredKolIds();
        if(sizeof($kolIds) > 0){
            foreach($kolIds as $key=>$value){
                $kolName = $this->kol_consent->getKolNameByKolId($value['kol_id']);
                $user_name = $value['user_name'];
                $email = $value['email'];
                $subject = "$kolName - Opt-in consent expired";
                $content = 'Dear '.$user_name.' <br/>
                        This email is to notify you that the Opt-in Consent provided by the KTL "'.$kolName.'" to feature in Hill’s KTL application has been expired.
                        If you wish to keep the KTL details in Hill’s KTL application, please create a new Opt-in link and send it to "'.$kolName.'" for consent.
                            
                            
                        Regards,
                            
                        Aissel Support Team';
                //Log Activity
                $arrLogDetails = array(
                    'type'=>CRON_JOBS,
                    'module'=>"opt_in_out",
                    'description'=>$content,
                    'type' => 'Expired',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'transaction_name'=>'Opt-in Expired',
                    'miscellaneous1'=>$value['kol_id']
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                $emailStatus = $this->send_email_notification_expiree($subject,$content,$email);
                
                $this->delete_created_ol($value['kol_id']);//Delete Kol Details Retaining FN,LN
            }
        }
    }
    
    
    /*
     * Opt out Kols Without responding to a link for 30 days when link is Generated
     */
    function opt_in_out_expire_without_respond(){
        $kolIds = $this->kol_consent->getWithOutResponseExpiredKolIds();
        if(sizeof($kolIds) > 0){
            foreach($kolIds as $row){
                    $setOptOut = $this->kol_consent->updateStatusOfOptInOut('1',$row['kol_id'],true);
                    if($setOptOut){
                        $kolName = $this->kol_consent->getKolNameByKolId($row['kol_id']);
                        //Opt out log
                        $arrLogDetails = array(
                            'module'=>"opt_in_out",
                            'description'=>'The request from KTL was Opted-Out by '.$row['kol_id'].' - '.$kolName,
                            'type' => 'Opted Out',
                            'status' => STATUS_SUCCESS,
                            'transaction_table_id'=>'',
                            'transaction_name'=>'Opt-out',
                            'miscellaneous1'=>$row['kol_id']
                        );
                        $this->config->set_item('log_details', $arrLogDetails);
                        log_user_activity(null, true);
                    }
//                 $kolName = $this->kol_consent->getKolNameByKolId($row['kol_id']);
                $user_name = $row['user_name'];
                $email = $row['email'];
                $subject = "$kolName - Opt-in consent No response";
                $content = 'Dear '.$user_name.' <br/>
                     This email is to notify you that the Opt-in Consent provided by the KTL "'.$kolName.'" to feature in Hill’s KTL application has not responded.
                     If you wish to keep the KTL details in Hill’s KTL application, please create a new Opt-in link and send it to "'.$kolName.'" for consent.
                         
                         
                     Regards,
                         
                     Aissel Support Team';
                //Log Activity
                $arrLogDetails = array(
                    'type'=>CRON_JOBS,
                    'module'=>"opt_in_out",
                    'description'=>$content,
                    'type' => 'No Response',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'transaction_name'=>'No Response',
                    'miscellaneous1'=>$row['kol_id']
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                $emailStatus = $this->send_email_notification_expiree($subject,$content,$email);
                
                $this->delete_created_ol($row['kol_id']);//Delete Kol Details Retaining FN,LN
            }
        }
    }
    
    /*
     * Opt out Kols Without responding to a link for 30 days without Link
     */
    function opt_in_out_expire_without_respond_no_link(){
        $kolIds = $this->kol_consent->getWithOutResponseExpiredNoLinkKolIds();
        if(sizeof($kolIds) > 0){
            foreach($kolIds as $row){
                $kolName = $this->kol_consent->getKolNameByKolId($row['id']);
                $user_name = $row['user_name'];
                $email = $row['email'];
                $subject = "$kolName - Opt-in consent No response";
                $content = 'Dear '.$user_name.' <br/>
                        This email is to notify you that the Opt-in Consent provided by the KTL "'.$kolName.'" to feature in Hill’s KTL application has not responded.
                        If you wish to keep the KTL details in Hill’s KTL application, please create a new Opt-in link and send it to "'.$kolName.'" for consent.
                            
                            
                        Regards,
                            
                        Aissel Support Team';
                //Log Activity
                $arrLogDetails = array(
                    'type'=>CRON_JOBS,
                    'module'=>"opt_in_out",
                    'description'=>$content,
                    'type' => 'No Response',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'transaction_name'=>'No Response',
                    'miscellaneous1'=>$row['id']
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                $emailStatus = $this->send_email_notification_expiree($subject,$content,$email);
                
                $this->delete_created_ol($row['id']);//Delete Kol Details Retaining FN,LN
            }
        }
    }
    
    function inimate_expired_kols_to_users(){
        $kolIds = $this->kol_consent->getToInimateExpiredKolIds();
        if(sizeof($kolIds) > 0){
            foreach($kolIds as $row){
                $kolName = $this->kol_consent->getKolNameByKolId($row['kol_id']);
                $user_name = $row['user_name'];
                $email = $row['email'];
                $subject = "$kolName - Opt-in consent expires in 30 days";
                $content = 'Dear '.$user_name.' <br/>
                            This email is to notify you that the Opt-in Consent provided by the KTL "'.$kolName.'" to feature in Hill’s KTL application is about to expire in next 30 days.
                            If you wish to keep the KTL details in Hill’s KTL application, please resend the Opt-in link to "'.$kolName.'" for consent.
                                
                                
                            Regards,
                                
                            Aissel Support Team';
                //Log Activity
                $arrLogDetails = array(
                    'type'=>CRON_JOBS,
                    'module'=>"opt_in_out",
                    'description'=>$content,
                    'type' => 'Intimate Expiree',
                    'status' => STATUS_SUCCESS,
                    'transaction_table_id'=>'',
                    'miscellaneous1'=>$row['kol_id']
                );
                $this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null, true);
                
                
                $emailStatus = $this->send_email_notification_expiree($subject,$content,$email);
            }
        }
    }
    
    function delete_created_ol($kolId){
        $this->kol->deleteLogActivity($kolId);
        $this->kol->deleteStaffByKolId($kolId);
        $this->kol->deleteLocationByKolId($kolId);
        $this->kol->deleteUserNotesKolId($kolId);
        $this->kol->deletePhoneByKolId($kolId);
        $this->kol->deleteKolSubSpecialty($kolId);
        $this->kol->deleteEmailByKolId($kolId);
        $this->kol->deleteStateLicenseByKolId($kolId);
        $this->kol->deleteTrialsByKolId($kolId);
        $this->kol->deletePublicationsByKolId($kolId);
        $this->kol->deleteKolOpt($kolId);
    }
    
    /**
     * Sends a mail of success and faliure of the Opt In - Opt Out
     * @param string $subject
     * @param string $content
     * @param string $emailId
     */
    function send_email_notification_expiree($subject,$content,$email){
        
        //     	$emailId = 'vhanagal@gmail.com';
        $fromEmail	= OPTINOUT_SENDER;
        $note = nl2br($content);
        /* $config['protocol']  = PROTOCOL;
         $config['smtp_host'] = HOST;
         $config['smtp_port'] = PORT;
         $config['smtp_user'] = USER;
         $config['smtp_pass'] = PASS;
         $config['mailtype'] 		= 'html'; */
        $config = email_config_initializer('optinout');
        $this->load->library('email', $config);
        //$this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from($config['smtp_user'],$fromEmail);
        $this->email->to($email);
        $this->email->message($note);
        $this->email->subject($subject);
        $this->email->set_crlf("\r\n");
        if($this->email->send()){
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email sent to ".$email,
                'type'=>CRON_JOBS,
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'user_id' => $this->loggedUserId,
                'transaction_name'=>"Email sent to ".$email
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status	=  true;
        }else{
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email Not sent to ".$email,
                'type'=>CRON_JOBS,
                'status' => STATUS_FAIL,
                'transaction_table_id'=>'',
                'transaction_name'=>"Email Not sent to ".$email
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status 	=  false;
        }
        $this->email->clear(TRUE);
        return $status;
    }
    
    
    /**
     * Sends a mail of New added fields/records for title,country,state,city and organization
     * @param string $subject
     * @param string $content
     */
    function send_email_new_added_records($subject,$content){
        $emailId = SUPPORT_USER;
        $fromEmail	= SUPPORT_SENDER;
        $note = nl2br($content);
        /* $config['protocol']  = PROTOCOL;
         $config['smtp_host'] = HOST;
         $config['smtp_port'] = PORT;
         $config['smtp_user'] = USER;
         $config['smtp_pass'] = PASS;
         $config['mailtype'] 		= 'html'; */
        $config = email_config_initializer('support');
        $this->load->library('email', $config);
        //$this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from($config['smtp_user'],$fromEmail);
        $this->email->to($emailId);
        $this->email->message($note);
        $this->email->subject($subject);
        $this->email->set_crlf("\r\n");
        if($this->email->send()){
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email Notification for New Added Records",
                'type' => 'Email Notification',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'user_id' => $this->loggedUserId,
                'transaction_name'=>"Email sent to ".$emailId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
            $status	=  true;
        }else{
            //Log Activity
            $arrLogDetails = array(
                'description'=>"Email Notification for New Added Records",
                'type' => 'Email Notification',
                'status' => STATUS_FAIL,
                'transaction_table_id'=>'',
                'transaction_name'=>"Email Not sent to ".$emailId
            );
            $this->config->set_item('log_details', $arrLogDetails);
            log_user_activity(null, true);
            $status 	=  false;
        }
        $this->email->clear(TRUE);
        return $status;
    }
    /**
     * Display 'list_campaigns' view page
     * @ACL-Discription Display All Campaign Deatil
     */
    function list_opt_in_out(){
        $this->common_helpers->checkUsers();
        $data['contentPage'] 	= 'kols/consent/list_opt_in_out_users';
        //Add Log activity
        $arrLogDetails = array(
        		'type' => LIST_RECORD,
        		'description' => "Visited list opt in out users Page",
        		'status' => STATUS_SUCCESS,
        		'transaction_name' => "View list opt in out users Page"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $this->load->view('layouts/analyst_view',$data);
    }
    
    function list_opt_in_out_users(){
        ini_set('memory_limit','-1');
        
        $page	= $_REQUEST['page']; // get the requested page
        
        $limit 	= $_REQUEST['rows']; // get how many rows we want
        
        $sidx 	= $_REQUEST['sidx']; // get index row - i.e. user click to sort
        
        $sord 	= $_REQUEST['sord']; // get the direction
        
        if(!$sidx) $sidx =1;
        
        // connect to the database
        
        $filterData=$_REQUEST['filters'];
        $arrFilter=array();
        $arrFilter=json_decode(stripslashes($filterData));
        $field='field';
        $op='op';
        $data='data';
        $groupOp='groupOp';
        $searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
        $searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
        $searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
        $searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
        $whereResultArray=array();
        foreach($searchField as $key=> $val){
            $whereResultArray[$val]=$searchString[$key];
        }
        $searchGroupOperator=$searchGroupOperator[0];
        $searchResults=array();
        $count	= $this->kol_consent->getOptInOutKols($limit,$start,true,$sidx,$sord,$whereResultArray);
        
        if( $count >0 )
        
        {
            
            $total_pages = ceil($count/$limit);
            
        }
        
        else { $total_pages = 0;
        
        }
        
        if ($page > $total_pages)
            
            $page=$total_pages;
            
            $start = $limit*$page - $limit; // do not put  $limit*($page - 1)
            
            $arrOptInOutKolDetailResult	= $this->kol_consent->getOptInOutKols($limit,$start,false,$sidx,$sord,$whereResultArray);
            
            $i = 0;
            $data = array();
            $arrOrgDetail = array();
            foreach($arrOptInOutKolDetailResult->result_array() as $row){
                $row['action']		= '<div class="actionIcon editIcon"><a href="#" onclick="editKolStatus('.$row['id'].'); return false;" title="Edit">&nbsp;</a></div>';
                $arrOrgDetail[] = $row;
                
            }
            $data['page'] = $page;
            
            $data['total'] = $total_pages;
            
            $data['records'] = $count;
            $data['rows']	= $arrOrgDetail;
            echo json_encode($data);
            
    }
    
    function update_opt_status(){
        $kolId = trim($this->input->post('kol_opt_id'));
        $statusId = trim($this->input->post('status_id'));
        $update_status = $this->kol_consent->updateStatusId($kolId,$statusId);
        $data['status'] = true;
        echo json_encode($data);
    }
}