<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class clinical_trials extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('clinical_trial');
		$this->load->model('kols/kol');
		$this->load->model('helpers/common_helper');
	}
	function list_clinical_trials_details($kolId,$type = 'verified'){

		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrClinicalTrials	= array();
		$data				= array();		
		if($arrClinicalTrialsResults=$this->clinical_trial->listClinicalTrialsDetailsByType($kolId,$type)){
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['asoc_id'];
				$arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				$arrClinicalTrial['is_analyst']	= $arrClinicalTrialsResult['is_analyst'];
				$arrClinicalTrial['first_name']	= $arrClinicalTrialsResult['first_name'];
				$arrClinicalTrial['last_name']	= $arrClinicalTrialsResult['last_name'];
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['trial_id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
// 				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="images/user3.png" /></label>';
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
				$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
				$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
				$arrClinicalTrial['eAllowed']							= $this->common_helper->isActionAllowed('kol_details','edit',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
				if($arrClinicalTrialsResult['is_industry_trial'] == 1){
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1' checked='checked'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'/>";
				}else if($arrClinicalTrialsResult['is_industry_trial'] == 2){
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'  checked='checked'/>";
				}else{
					$arrClinicalTrial['is_industry'] = "YES<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='1'/>NO<input type='radio' name='is_industry".$arrClinicalTrial['id']."' value='2'/>";
				}
				$arrClinicalTrial['data_type_indicator']	= $arrClinicalTrialsResult['data_type_indicator'];;
				$arrClinicalTrials[]			= $arrClinicalTrial;
			}
			$count				= sizeof($arrClinicalTrials);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrClinicalTrials;
		}
		echo json_encode($data);
	}
	function get_sponsers($ctId){
		$sponsersNames='';
		$arrSponsers=$this->clinical_trial->listCTSponsors($ctId);
		foreach($arrSponsers as $sponser){
			$sponserName=$sponser['agency'];
			if($sponsersNames==''){
				$sponsersNames=$sponserName;
			}else{
				$sponsersNames=$sponsersNames.", ".$sponserName;
			}
		}
		return $sponsersNames;
	}
	function get_interventions($ctId){
		$interventionsNames='';
		$arrInterventions=$this->clinical_trial->listCTInterventions($ctId);
		foreach($arrInterventions as $intervention){
			$interventionName=$intervention['name'];
			if($interventionsNames==''){
				$interventionsNames=$interventionName;
			}else{
				$interventionsNames=$interventionsNames.", ".$interventionName;
			}
		}
		return $interventionsNames;
	}
	function get_investigators($ctId){
		$investigatorsNames = '';
		$arrInvestigators=$this->clinical_trial->listCTInvestigators($ctId);
		foreach($arrInvestigators as $investigator){
			$investigatorName=$investigator['last_name'];
			if($investigatorsNames == ''){
				$investigatorsNames=$investigatorName;
			}else{
				$investigatorsNames=$investigatorsNames.", ".$investigatorName;
			}
		}
		return $investigatorsNames;
	}
	function delete_client_clinical_trial($ctId,$ctsId,$kolId1 = ''){
		$kolId=$this->session->userdata('kolId');
		$kolClinicalTrial=array();
		$kolClinicalTrial['kol_id']=$kolId;
		$kolClinicalTrial['cts_id']=$ctsId;
		$isDeleted=$this->clinical_trial->deleteClientClinicalTrial($ctsId);
		if($kolId1 != '')
			$this->kol->deleteIndusAffiliation($ctId,$kolId,'trial');
			return true;
	}
	function add_clinical_trial($kolId=null,$ctId=null){
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$arrClinicalTrialDetails	= array('id'=>	'',
											'trial_name'		=>	'',
											'status_id'			=>	'',
											'sponsor'	 		=> 	'',
											'condition'			=> 	'',
											'intervention'	 	=> 	'',
											'phase'	 			=> 	'',
											'investigators'	 	=> 	'',
											'keyword'			=>	'',
											'meshterm'			=>	'',
											'official_title'	=>	'',
											'link'				=>	'',
											'study_type'		=>	'',
											'collaborator'		=>	'',
											'start_date'		=>	'',
											'end_date'			=>	'',
											'no_of_enrollees'	=>	'',
											'no_of_trial_sites'	=>	'',
											'min_age'			=>	'',
											'max_age'			=>	'',
											'purpose'			=>	'',
											'kol_role'			=>	'',
											'gender'			=>	''
		);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';
		
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
		
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
		
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
		
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		if($ctId!=null){
			$arrClinicalTrialDetails= $this->clinical_trial->getClinicalTrial($ctId);
			$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
			$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
			$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
			$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
			$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
			$i=0;
			foreach ($arrMeshterms as $meshterms){
				$i++;
				if($i == 2)
					break;
				$manualMeshterms['meshterms']	= $meshterms['term_name'];
				$manualMeshterms['id'] 			= $meshterms['id'];
			}
			$i=0;
			foreach ($arrKeywords as $keywords){
				$i++;
				if($i == 2)
					break;
				$manualKeywords['keywords']  = $keywords['name'];
				$manualKeywords['id']		 = $keywords['id'];
			}
			$i=0;
			foreach ($arrSponsors as $sponsors){
				$i++;
				if($i == 2)
					break;
				$manualSponsors['sponsor']  = $sponsors['agency'];
				$manualSponsors['id'] = $sponsors['id'];
			}
			$i=0;
			foreach ($arrInterventions as $interventions){
				$i++;
				if($i == 2)
					break;
				$manualInterventions['intervention'] = $interventions['name'];
				$manualInterventions['id'] = $interventions['id'];
			}
			$i=0;
			foreach ($arrInvestigators as $investigators){
				$i++;
				if($i == 2)
					break;
				$manualInvestigators['investigators'] = $investigators['last_name'];
				$manualInvestigators['id'] = $investigators['id'];
			}
		}	
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$arrClinicalTrialDetails['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
		
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$arrClinicalTrialDetails['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
		
		
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$arrClinicalTrialDetails['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
		
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$arrClinicalTrialDetails['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
		
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$arrClinicalTrialDetails['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;		
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['kolId'] = $kolId;
		$data['contentPage'] 	= 'clinical_trials/add_clinical_trials';
		$data['contentData']	=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function edit_clinical_trial_manual($ctId,$kolId){
		$ctDetailsResult	= $this->clinical_trial->getClinicalTrial($ctId);
		$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
		$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
		$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
		$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
		$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
		
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
		
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
		
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
		
		$i=0;
		foreach ($arrMeshterms as $meshterms){
			$i++;
			if($i == 2)
				break;
				$manualMeshterms['meshterms']	= $meshterms['term_name'];
				$manualMeshterms['id'] 			= $meshterms['id'];
		}
		$i=0;
		foreach ($arrKeywords as $keywords){
			$i++;
			if($i == 2)
				break;
				$manualKeywords['keywords']  = $keywords['name'];
				$manualKeywords['id']		 = $keywords['id'];
		}
		$i=0;
		foreach ($arrSponsors as $sponsors){
			$i++;
			if($i == 2)
				break;
				$manualSponsors['sponsor']  = $sponsors['agency'];
				$manualSponsors['id'] = $sponsors['id'];
		}
		$i=0;
		foreach ($arrInterventions as $interventions){
			$i++;
			if($i == 2)
				break;
				$manualInterventions['intervention'] = $interventions['name'];
				$manualInterventions['id'] = $interventions['id'];
		}
		$i=0;
		foreach ($arrInvestigators as $investigators){
			$i++;
			if($i == 2)
				break;
				$manualInvestigators['investigators'] = $investigators['last_name'];
				$manualInvestigators['id'] = $investigators['id'];
		}
		
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$ctDetailsResult['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
		
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$ctDetailsResult['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
		
		
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$ctDetailsResult['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
		
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$ctDetailsResult['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
		
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$ctDetailsResult['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;
		
		$data['arrClinicalTrial'] = $ctDetailsResult;
		
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		
		$data['kolId'] = $kolId;
		$this->load->view('clinicals/add_clinical_trials',$data);
		
	}
	function clinical_trial_manual_dropdowns(){
		$arrStatusIds = array(	4		 => COMPLETED,
				1		 => 'Recruiting',
				3 	 	 => 'Terminated',
				12		 => 'Ongoing',
				13 		 => 'Others');
		
		$arrPhaseIds = array(	'I'	 	=> 'I',
				'II'	=> 'II',
				'III' 	=> 'III',
				'IV'	=> 'IV');
		
		$arrGenders = array(	'male'	=> 'Male',
				'female'=> 'Female',
				'both' 	=> 'Both');
		
		$arrKOLRoles = array(	'Co-investigator'		=> 'Co-investigator',
				'Principal Investigator'=> 'Principal Investigator',
				'Study Director' 		=> 'Study Director',
				'Sub-investigator' 		=> 'Sub-investigator');
		
		$data['arrStatusIds']	= $arrStatusIds;
		$data['arrPhaseIds']	= $arrPhaseIds;
		$data['arrKOLRoles']	= $arrKOLRoles;
		$data['arrGenders']		= $arrGenders;
		return $data;
	}
	function update_clinical_trial_manual(){
		$kolId	=	$this->input->post('kol_id');
		$arrClinicalTrial  = array(	'id' =>	$this->input->post('id'),
				'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
				'status_id' 		=> 	$this->input->post('status_id'),
				'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
				'phase'	 			=> 	$this->input->post('phase'),
				'study_type'	 	=> 	$this->input->post('study_type'),
				'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
				'link'	 			=> 	$this->input->post('trial_link'),
				'kol_role'	 		=> 	$this->input->post('kol_role'),
				'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
				'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
				'start_date'	 	=> 	$this->input->post('start_date'),
				'end_date'	 		=> 	$this->input->post('end_date'),
				'min_age'	 		=> 	$this->input->post('min_age'),
				'max_age'	 		=> 	$this->input->post('max_age'),
				'gender'	 		=> 	$this->input->post('gender'),
				'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
				'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites'));
		
		$isSaved=$this->clinical_trial->updateClinicalTrialManual($arrClinicalTrial);
		$arrClinicalTrial['agency']	 		= 	trim($this->input->post('sponsor'));
		$arrClinicalTrial['sponsorId']	 	= 	trim($this->input->post('sponsorId'));
		if($arrClinicalTrial['sponsorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtSponcers($arrClinicalTrial);
			$arrSponsorToExclude[]	= $arrClinicalTrial['sponsorId'];
		}else{
			$newArrSponsor['agency']			= $arrClinicalTrial['agency'];
			$newArrCtSponsor['sponser_id']	= $this->clinical_trial->saveSponser($newArrSponsor);
			$arrSponsorToExclude[]				= $newArrCtSponsor['sponser_id'];
			$newArrCtSponsor['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtSponser($newArrCtSponsor);
		}
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			if($this->input->post('sponsor'.$i)){
				$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
				$arrSponser['sponsorId']			= 	trim($this->input->post('sponsorId'.$i));
				$arrSponser['id'] 					= 	$arrClinicalTrial['id'];
				if($arrSponser['sponsorId'] !=''){
					//Updates sponser details and returns bollean value
					$isSaved=$this->clinical_trial->updateCtSponcers($arrSponser);
					$arrSponsorToExclude[]				= $arrSponser['sponsorId'];
				}else{
					$newArrSponsor['agency']			= $arrSponser['agency'];
					$newArrCtSponsor['sponser_id']	= $this->clinical_trial->saveSponser($newArrSponsor);
					$arrSponsorToExclude[]				= $newArrCtSponsor['sponser_id'];
					$newArrCtSponsor['cts_id']				= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtSponser($newArrCtSponsor);
				}
			}
		}
		$this->clinical_trial->deleteSponsersAssoc($arrClinicalTrial['id'],$arrSponsorToExclude);
		/*Sponsor End*/
		/* Interventions */
		$arrClinicalTrial['name']			= 	trim($this->input->post('intervention'));
		$arrClinicalTrial['interventionId'] = 	trim($this->input->post('interventionId'));
		if($arrClinicalTrial['interventionId'] != ''){
			$isSaved=$this->clinical_trial->updateCtIntervention($arrClinicalTrial);
			$arrInterventionToExclude[]	= $arrClinicalTrial['interventionId'];
		}else{
			$newArrIntervention['name']			= $arrClinicalTrial['name'];
			$newArrCtIntervention['intervention_id']	= $this->clinical_trial->saveIntervention($newArrIntervention);
			$arrInterventionToExclude[]				= $newArrCtIntervention['intervention_id'];
			$newArrCtIntervention['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtIntervention($newArrCtIntervention);
		}
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			if($this->input->post('intervention'.$i)){
				$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
				$arrIntervention['interventionId']		= 	trim($this->input->post('interventionId'.$i));
				$arrIntervention['id'] 					= 	$arrClinicalTrial['id'];
				if($arrIntervention['interventionId'] != ''){
					//Updates Intervention details and returns bollean value
					$isSaved=$this->clinical_trial->updateCtIntervention($arrIntervention);
					$arrInterventionToExclude[]	= $arrIntervention['interventionId'];
				}else{
					$newArrIntervention['name']			= $arrIntervention['name'];
					$newArrCtIntervention['intervention_id']	= $this->clinical_trial->saveIntervention($newArrIntervention);
					$arrInterventionToExclude[]				= $newArrCtIntervention['intervention_id'];
					$newArrCtIntervention['cts_id']				= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtIntervention($newArrCtIntervention);
				}
			}
		}
		$this->clinical_trial->deleteInterventionsAssoc($arrClinicalTrial['id'],$arrInterventionToExclude);
		/* End of Interventions */
		$arrClinicalTrial['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		$arrClinicalTrial['investigatorId'] = 	trim($this->input->post('investigatorId'));
		if($arrClinicalTrial['investigatorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtInvestigator($arrClinicalTrial);
			$arrInvestigatorsToExclude[]	= $arrClinicalTrial['investigatorId'];
		}else{
			$newArrInvestigator['last_name']			= $arrClinicalTrial['last_name'];
			$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
			$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
			$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
			//echo $this->db->last_query();
			//exit();
		}
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
			if($this->input->post('investigators'.$i)){
				$arrInvestigator['last_name']	 		= 	trim($this->input->post('investigators'.$i));
				$arrInvestigator['investigatorId']		= 	trim($this->input->post('investigatorId'.$i));
				$arrInvestigator['id'] 					= 	$arrClinicalTrial['id'];
				if($arrInvestigator['investigatorId'] != ''){
					$arrInvestigatorsToExclude[]	= $arrInvestigator['investigatorId'];
					//Updates Investigator details and returns bollean value
					$isSaved=$this->clinical_trial->updateCtInvestigator($arrInvestigator);
				}else{
					$newArrInvestigator['last_name']			= $arrInvestigator['last_name'];
					$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
					$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
					//	echo $this->db->last_query();
					$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
					//	echo $this->db->last_query();
					//	exit();
				}
			}
		}
		$this->clinical_trial->deleteInvestigatorsAssoc($arrClinicalTrial['id'],$arrInvestigatorsToExclude);
		$i=1;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=1;$i<=$noOfKeywords;$i++){
			if($i==1){
				$value 				= trim($this->input->post('keywords'));
				$existingKeywordId	= trim($this->input->post('keywordId'));
			}else{
				$value 				= trim($this->input->post('keywords'.$i));
				$existingKeywordId	= trim($this->input->post('keywordId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
// 						echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
// 						echo 'New Keyword '.$value;
				}
				if(!empty($keywordId) && ($keywordId!=$existingKeywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $arrClinicalTrial['id'];
					$update = $this->clinical_trial->updateCtKeyword($existingKeywordId,$arrAssociateKeyword);
					if(!$update){
						$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
						$arrKeywordsToExclude[] = $keywordId;
					}
				}
				$arrKeywordsToExclude[]	= $existingKeywordId;
			}else
				continue;
		}
		//pr($arrKeywordsToExclude);exit;
		$this->clinical_trial->deleteKeywordsAssoc($arrClinicalTrial['id'],$arrKeywordsToExclude);
		$i=1;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=1;$i<=$noOfMeshterms;$i++){
			if($i==1){
				$value 			= trim($this->input->post('meshterms'));
				$existingTermId	= trim($this->input->post('meshtermsId'));
			}else{
				$value 			= trim($this->input->post('meshterms'.$i));
				$existingTermId	= trim($this->input->post('meshtermId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
					//	echo 'Already exists '.$value.'-'.$meshTermId;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
					//	echo 'New Meshterm '.$value.'-'.$meshTermId;
				}
				if(!empty($meshTermId) && ($meshTermId!=$existingTermId)){
					//	echo $value.'-'.$existingTermId.'-'.$meshTermId;
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $arrClinicalTrial['id'];
					$update = $this->clinical_trial->UpdateCtMeshterms($existingTermId,$arrAssociateMeshTerm);
					//	echo $this->db->last_query();
					if(!$update){
						$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
						$arrTermsToExclude[] = $meshTermId;
					}
				}
				$arrTermsToExclude[]	= $existingTermId;
			}else
				continue;
		}
		$this->clinical_trial->deleteTermsAssoc($arrClinicalTrial['id'],$arrTermsToExclude);
		$arrResult = array();
		if($isSaved){
			$arrResult['saved']			=  true;
			$arrResult['lastInsertId']	=  $arrClinicalTrial['id'];
			$arrResult['msg']			=  "The Clinical Trial details are successfully updated. ";
		}else{
			$arrResult['saved']			=  false;
			$arrResult['msg']			=  "Sorry! Error in Updating";
		}
		$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kolId,'unique_id');
// 		pr($arrResult);exit;
		echo json_encode($arrResult);
// 		redirect('kols/view_clinical_trials/'.$kolId);
	}
	function save_clinical_trial_manual(){
		// Getting the POST details of Clinical Trial
		$arrClinicalTrial  = array(
				'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
				'status_id' 		=> 	$this->input->post('status_id'),
				'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
				'phase'	 			=> 	$this->input->post('phase'),
				'study_type'	 	=> 	$this->input->post('study_type'),
				'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
				'link'	 			=> 	$this->input->post('trial_link'),
				'kol_role'	 		=> 	$this->input->post('kol_role'),
				'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
				'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
				'start_date'	 	=> 	$this->input->post('start_date'),
				'end_date'	 		=> 	$this->input->post('end_date'),
				'min_age'	 		=> 	$this->input->post('min_age'),
				'max_age'	 		=> 	$this->input->post('max_age'),
				'gender'	 		=> 	$this->input->post('gender'),
				'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
				'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites'),
				'is_industry_trial'	=> ($this->input->post('is_industry_trial')==''?0:$this->input->post('is_industry_trial')),
		);
// 		pr($arrClinicalTrial);exit;	
		$arrSponsers = array();
		$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'));
		if($arrSponser['agency'] != ''){
			$arrSponsers[] = $arrSponser;
		}
		
		$arrInterventions =array();
		$arrIntervention['name']			= 	trim($this->input->post('intervention'));
		if($arrIntervention['name'] !=''){
			$arrInterventions[] = $arrIntervention;
		}
		
		$arrInvestigators = array();
		$arrInvestigator['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		if($arrInvestigator['last_name'] !=''){
			$arrInvestigators[]  = $arrInvestigator;
		}
		$arrInvestigators = array();
		$arrInvestigator['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		if($arrInvestigator['last_name'] !=''){
			$arrInvestigators[]  = $arrInvestigator;
		}
		$arrInvestigators = array();
		$arrInvestigator['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		if($arrInvestigator['last_name'] !=''){
			$arrInvestigators[]  = $arrInvestigator;
		}
		
		$kolId			=	$this->input->post('kol_id');
		
		$arrClinicalTrial['is_manual']= 1;
		$arrClinicalTrial['ct_id'] = $this->clinical_trial->getManualCtid();
		$ctId	= $this->clinical_trial->saveClinicalTrialsManualAndFlags($arrClinicalTrial,$kolId);
		//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctId, MODULE_KOL_TRIAL, $kolId);
		$isSaved = false;
		if($ctId){
			$isSaved = true;
		}
		
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			$value = trim($this->input->post('sponsor'.$i));
			if($value !=''){
				$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
				$arrSponsers[] = $arrSponser;
			}else
				continue;
		}
		//saves sponsers details and returns bollean value
		if(sizeof($arrSponsers) >=1){
			$isSaved =$this->clinical_trial->saveSponsers( $arrSponsers, $ctId);
		}
		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			$value = trim($this->input->post('intervention'.$i));
			if($value !=''){
				$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
				$arrInterventions[] = 	$arrIntervention;
			}else
				continue;
		}
		//saves Interventions details and returns bollean value
		if(sizeof($arrInterventions) >=1){
			$isSaved=$this->clinical_trial->saveInterventions($arrInterventions, $ctId);
		}
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
			$value = trim($this->input->post('investigators'.$i));
			if($value !=''){
				$arrInvestigator['last_name']	 			= 	trim($this->input->post('investigators'.$i));
				$arrInvestigators[] = 	$arrInvestigator;
			}else
				continue;
		}
		//saves Investigators details and returns bollean value
		if(sizeof($arrInvestigators) >=1){
			$isSaved=$this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);
		}
		
		
		//save Keywords
		$value = trim($this->input->post('keywords'));
		if($value !=''){
			$arrData = array();
			$arrData['name'] = $value;
			if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
			}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
			}
			if(!empty($keywordId)){
				$arrAssociateKeyword['keyword_id']	= $keywordId;
				$arrAssociateKeyword['cts_id']		= $ctId;
				$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
			}
		}
		$i=2;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=2;$i<=$noOfKeywords;$i++){
			$value = trim($this->input->post('keywords'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
					//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
					//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $ctId;
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}else
				continue;
		}
		//save mesh terms
		$value = trim($this->input->post('meshterms'));
		if($value !=''){
			$arrData = array();
			$arrData['term_name'] = $value;
			if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value;
			}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value;
			}
			if(!empty($meshTermId)){
				$arrAssociateMeshTerm['term_id']	= $meshTermId;
				$arrAssociateMeshTerm['cts_id']		= $ctId;
				$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
			}
		}
		
		$i=2;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=2;$i<=$noOfMeshterms;$i++){
			$value = trim($this->input->post('meshterms'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
					//	echo 'Already exists '.$value;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
					//	echo 'New Meshterm '.$value;
				}
				if(!empty($meshTermId)){
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $ctId;
					$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
				}
			}else
				continue;
		}
		$arrResult = array();
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $ctId;
			$arrResult['msg']			= "Clinical Trail data is successfully updated...";
			if($arrClinicalTrial['is_industry_trial'] == 1){
				$arrCtData = array();
				$arrCtData[]['id'] = $ctId;
				$this->add_ct_to_affiliations($kolId,$arrCtData);
			}
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		$currentMethod	= $this->input->post('methodName');
		$kolId = $this->common_helper->getFieldValueByEntityDetails('kols','id',$kolId,'unique_id');
// 		$kolId = $this->kol->getUniqueIdByKolId($kolId);
		
		echo json_encode($arrResult);
	}
	
	function view_clinical_trials($kolId, $subContentPage = '') {
		if (!$kolId) {
			return false;
		}
		// Getting the KOL details
		$this->load->model('kols/kol');
		$this->load->model('align_users/align_user');
		$kolId 									= $this->common_helper->getFieldValueByEntityDetails('kols','unique_id',$kolId,'id');
		$arrKolDetail = $this->kol->editKol($kolId);
		// If there is no record in the database
		if (!$arrKolDetail) {
			return false;
		}

		$module_name				='clinical_trials';
		$data['module_id']			=$this->common_helper->getModuleIdByModuleName($module_name);
		
		$data['arrKol'] = $arrKolDetail;
		$data['contentPage'] 			='list_clinical_trials_client_view';
		$data['contentData']			=$data;
		
		$arr_option_data['kol_id']			=$arrKolDetail['id'];
		$arr_option_data['assignedUsers'] 	= $this->align_user->getAssignedUsers($kolId);
		
		$data['options_page']				='kols/export_options_within_kol';
		$data['options_data']				=$arr_option_data;
		
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function view_clinical_trial($ctId){
		$ctDetailsResult=$this->clinical_trial->getClinicalTrial($ctId);
		$ctDetailsResult['status']=$this->clinical_trial->getStatusNameById($ctDetailsResult['status_id']);
		$arrSponsors=$this->clinical_trial->listCTSponsors($ctId);
		$arrInterventions=$this->clinical_trial->listCTInterventions($ctId);
		$arrKeyWords=$this->clinical_trial->listCTIKeyWords($ctId);
		$arrMeshTerms=$this->clinical_trial->listCTMeshTerms($ctId);
		$arrInvestigators=$this->clinical_trial->listCTInvestigators($ctId);
		
		$data['ctDetailsResult']=$ctDetailsResult;
		$data['arrSponsors']=$arrSponsors;
		$data['arrInterventions']=$arrInterventions;
		$data['arrKeyWords']=$arrKeyWords;
		$data['arrMeshTerms']=$arrMeshTerms;
		$data['arrInvestigators']=$arrInvestigators;
		
		$data['contentPage'] 	=	'clinicals/view_clinical_trial';
		//$this->load->view('layouts/kol_profile',$data);
		$this->load->view('view_clinical_trial',$data);
	}

	/*-------------Start of Clinical Trial functions(Analyst Application)-------------*/
	/**
	 * Show the page of Show Clinical Trial details
	 * @author Sanjeev K
	 * @since 28 March 2018
	 * @version KOLM-HMVC Version 1.0
	 * @desc Prepares the data required to display the Clinical Trials page and redirects to 'view_clinical_trials'
	 */
	function view_clinical_trials($kolId){
		$data['isClientView']	= false;
		$clientId				= $this->session->userdata('client_id');
		if($clientId==INTERNAL_CLIENT_ID){
			$data['enableEdit']	= true;
		}
		// Get the KOL details
		$arrKolDetail 			= $this->kol->editKol($kolId);
		$data['arrKol']			= $arrKolDetail;
			
		//$arrSalutations		= array(1 => 'Mr.', 'Mrs.', 'Miss.', 'Ms.', 'Dr.', 'Prof.');
		$arrSalutations			= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		$data['contentPage']	= 'clinical_trials/list_clinical_trials';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
			
	
	}
	/*-------------End of Clinical Trial functions(Analyst Application)-------------*/
	
	/*-------------Start of Industry Trials functions-------------*/
	/**
	 * Show the page of Add Social Media details
	 * @author Sanjeev K
	 * @since 06 April 2018
	 * @version KOLM-HMVC Version 1.0
	 */
	function list_unprocessed_trials(){
		$data = array();
		$data['contentPage'] = 'clinical_trials/unprocessed_trials';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	/*-------------End of Industry Trials functions-------------*/
	function get_unprocessed_trials($processedOrUnprocessed = ''){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrClinicalTrials	= array();
		$data				= array();
		if($arrClinicalTrialsResults=$this->clinical_trial->getUnprocessedTrials($processedOrUnprocessed)){
			//			echo $this->db->last_query();
			//			exit;
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				//$arrClinicalTrial['ct_id']	= '<a href=\''. $arrClinicalTrialsResult['link'].'\' target="_new">'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['trial_id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
	
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
					$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
					$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
					$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
					$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
					$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
					$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
					//				$arrClinicalTrial['eAllowed']							= $this->common_helpers->isActionAllowed('trial','edit',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
					//				$arrClinicalTrial['dAllowed']							= $this->common_helpers->isActionAllowed('trial','delete',array('created_by' => $arrClinicalTrialsResult['user_id'],'client_id' => $arrClinicalTrialsResult['client_id'],'kol_id' => $kolId));
					if($arrClinicalTrialsResult['is_industry_trial'] == 1)
						$arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1' checked='checked'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2'></input>";
						else if($arrClinicalTrialsResult['is_industry_trial'] == 2)
							$arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2' checked='checked'></input>";
							else
								$arrClinicalTrial['is_industry1'] = "YES<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='1' id='is_industry".$arrClinicalTrialsResult['id']."_1'></input>NO<input type='radio' name='is_industry".$arrClinicalTrialsResult['id']."' value='2' id='is_industry".$arrClinicalTrialsResult['id']."_2'></input>";
	
								$arrClinicalTrials[]			= $arrClinicalTrial;
			}
			$count				= sizeof($arrClinicalTrials);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrClinicalTrials;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	function add_clinical_trial_analyst($kolId=null,$ctId=null){
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$arrClinicalTrialDetails	= array('id'=>	'',
				'trial_name'		=>	'',
				'status_id'			=>	'',
				'sponsor'	 		=> 	'',
				'condition'			=> 	'',
				'intervention'	 	=> 	'',
				'phase'	 			=> 	'',
				'investigators'	 	=> 	'',
				'keyword'			=>	'',
				'meshterm'			=>	'',
				'official_title'	=>	'',
				'link'				=>	'',
				'study_type'		=>	'',
				'collaborator'		=>	'',
				'start_date'		=>	'',
				'end_date'			=>	'',
				'no_of_enrollees'	=>	'',
				'no_of_trial_sites'	=>	'',
				'min_age'			=>	'',
				'max_age'			=>	'',
				'purpose'			=>	'',
				'kol_role'			=>	'',
				'gender'			=>	''
		);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';
	
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
	
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
	
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
	
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		if($ctId!=null){
			$arrClinicalTrialDetails= $this->clinical_trial->getClinicalTrial($ctId);
			$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
			$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
			$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
			$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
			$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
			$i=0;
			foreach ($arrMeshterms as $meshterms){
				$i++;
				if($i == 2)
					break;
					$manualMeshterms['meshterms']	= $meshterms['term_name'];
					$manualMeshterms['id'] 			= $meshterms['id'];
			}
			$i=0;
			foreach ($arrKeywords as $keywords){
				$i++;
				if($i == 2)
					break;
					$manualKeywords['keywords']  = $keywords['name'];
					$manualKeywords['id']		 = $keywords['id'];
			}
			$i=0;
			foreach ($arrSponsors as $sponsors){
				$i++;
				if($i == 2)
					break;
					$manualSponsors['sponsor']  = $sponsors['agency'];
					$manualSponsors['id'] = $sponsors['id'];
			}
			$i=0;
			foreach ($arrInterventions as $interventions){
				$i++;
				if($i == 2)
					break;
					$manualInterventions['intervention'] = $interventions['name'];
					$manualInterventions['id'] = $interventions['id'];
			}
			$i=0;
			foreach ($arrInvestigators as $investigators){
				$i++;
				if($i == 2)
					break;
					$manualInvestigators['investigators'] = $investigators['last_name'];
					$manualInvestigators['id'] = $investigators['id'];
			}
		}
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$arrClinicalTrialDetails['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
	
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$arrClinicalTrialDetails['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
	
	
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$arrClinicalTrialDetails['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
	
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$arrClinicalTrialDetails['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
	
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$arrClinicalTrialDetails['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['kolId'] = $kolId;
		$data['contentData']	=$data;
		$this->load->view('clinical_trials/add_clinical_trials',$data);
	}
}
?>