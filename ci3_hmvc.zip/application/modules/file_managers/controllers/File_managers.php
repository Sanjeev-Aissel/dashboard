<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class file_managers extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('file_manager');
		$this->load->model('helpers/common_helper');
	}
	function jqgridExportToExcel($filename,$ipadOrDesktop = NULL){
		$file=$filename."_".date('Y-m-d').".xlsx";
		$content="<table border='1'>".$_POST['table']."</table>";
		if($ipadOrDesktop === NULL){
			header("Content-type: application/vnd.ms-excel");
			header("Content-Disposition: attachment; filename=$file");
			echo $content;
		}else{
			$directory	= $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.$this->config->item('app_folder_path').'documents';
			$fullFilePath = $directory."/".$file;
			file_put_contents($fullFilePath,$content);
			if($_POST['table']=='<tr></tr>'){
				$emailData = 'empty_record';
				echo json_encode($emailData);
				exit;
			}
			$this->send_email_with_attachment($filename,$fullFilePath);
		}
	}
}
?>