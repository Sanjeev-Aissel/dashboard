<?php
/**
 * Model file for the Engagement type'
 *
 * @package application.models
 * @author: Vinayak
 * @since
 * @created on  27-12-10
 */


class Engagement_type extends Model{
	
	function Engagement(){
		parent::Model();
	}
	
	
	/**
	 * Returns all the Engagement types
	 * @return array	- ID, and Name
	 */	

	function getAllEngagementTypes(){
		$arrEngagementTypes = array();
		$this->db->order_by('engagement_type','asc');
		$arrEngagementTypesResult=$this->db->get('engagement_types');
		foreach($arrEngagementTypesResult->result_array() as $arrEngagementType){
			$arrEngagementTypes[$arrEngagementType['id']]	= $arrEngagementType['engagement_type'];
		}
		return 	$arrEngagementTypes;
	}

	/*
	* Returns the name of the Engagement  ID
	*/
	function getEngagementName($id){
		$engagement='';
		$this->db->where('id',$id);
		$result = $this->db->get('engagement_types');
		foreach($result->result_array() as $row){
			$engagement=$row['engagement_type'];
		}
		return $engagement;
	}
	
	/**
	 * Returns the Engagement Id
	 * 
	 * @param String $engagementType
	 * @return Array $arrEngagementId
	 */
	function getEngagementId($engagementType){
		if($engagementType != ''){
			$this->db->select('id');
			$this->db->where('engagement_type', $engagementType);
			$arrResultSet = $this->db->get('engagement_types');
		
			if($arrResultSet->num_rows() == 0){
				return false;
			}
			foreach($arrResultSet->result_array() as $arrRow){
				return $arrRow['id'];
			}
		}else
			return false;
	}	
}


