<link href="<?php echo base_url().ASSETS;?>/c3js/c3.css" rel="stylesheet" type="text/css">
<link href='<?php echo base_url().ASSETS;?>/fullcalendar/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url().ASSETS;?>/fullcalendar/fullcalendar.print.css' rel='stylesheet' media='print' />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/chosen.css" media="screen"/>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"  rel="stylesheet"/>
<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter();}";
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
		'jqgrid/jquery.jqGrid.min_3.8',
		'js/chosen.jquery',
		'datepicker/js/daterangepicker.jQuery',
		'datepicker/js/date',
		'c3js/c3.min',
		'c3js/d3.c3.min',
		'alerts/jquery.alerts',
		'fullcalendar/lib/moment.min',
		'js/jquery.autocomplete',
		'fullcalendar/fullcalendar.min');    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.filterDiv{
    border: 1px solid #adadad;
}
.subFilterDiv{
border-bottom: 1px solid #adadad;
    padding-top: 7px;
    padding-bottom: 8px;
}
.form-group{
margin-bottom:0px;
}
.filter_table tbody>tr>td {
    padding: 0px 2px;
    padding-top: 0px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 0px solid #ddd;
    padding-bottom: 3px;
        font-size: 85%;
    font-weight: 100;
}
.chzn-container {
width:100% !important;
}
#submitButton {
    text-align: center;
}
#resetBttn {
    cursor: pointer;
    width: 15px !important;
}
.tab-pane{
    border-bottom: 1px solid #dddddd;
    border-left: 1px solid #dddddd;
    border-right: 1px solid #dddddd;
    }
#numericReportContainer td{
padding: 4px 10px 0 0;
}
</style>
<div class="row">
	<div class="col-sm-9" id="interaction_content_div">
	<div id="interaction_report_div">
			<ul class="nav nav-tabs" id="myTab" role="tablist">
		  <li class="nav-item active">
		    <a class="nav-link active" id="list-tab" data-toggle="tab" href="#list" role="tab" aria-controls="list" aria-selected="true">List</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="report-tab" data-toggle="tab" href="#report" role="tab" aria-controls="report" aria-selected="false">Report</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="chart-tab" data-toggle="tab" href="#chart" role="tab" aria-controls="chart" aria-selected="false">Chart</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="calender-tab" data-toggle="tab" href="#calender" role="tab" aria-controls="calender" aria-selected="false">Calendar</a>
		  </li>
		</ul>
		<div class="tab-content" id="myTabContent">
		  <div class="tab-pane fade active in" id="list" role="tabpanel" aria-labelledby="list-tab">
		  	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;top: -27px;">				<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
			</div>
			<div id="gridTabContainer" style="margin-top: 20px;">
				<div class="gridWrapper" id="gridContainer">
					<div id="listInteractionsPage"></div>
					<table id="listInteractionsResultSet"></table>
				</div>
			</div>
		  </div>
		  <div class="tab-pane fade" id="report" role="tabpanel" aria-labelledby="report-tab" style="padding: 2% 1%;">
		 	<div id="numericReportContainer"></div>
		  </div>
		  <div class="tab-pane fade row" id="chart" role="tabpanel" aria-labelledby="chart-tab">
		  					<div class="row">
		  					<div class="col-sm-6">
								<div class="panel panel-default">
								  <div class="panel-heading">
									<h3 class="panel-title">Interactions By Topic</h3>
								  </div>
								  <div class="panel-body">
									<div id="interactionsByTopic"></div>
								  </div>
								</div>
							</div>	
							<div class="col-sm-6">
								<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Interactions By Type</h3>
									  </div>
									  <div class="panel-body">
										<div id="interactionByChannel"></div>
									  </div>
								</div>
							</div>	
							</div>
							<div class="row">
							<div class="col-sm-6">
								<div class="panel panel-default">
									  <div class="panel-heading">
										<h3 class="panel-title">Interactions By Employees</h3>
									  </div>
									  <div class="panel-body">
										<div id="interactionsByEmployee"></div>
									  </div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="panel panel-default">
								  <div class="panel-heading">
									<h3 class="panel-title">Interactions By Month</h3>
								  </div>
								  <div class="panel-body">
									<div id="interactionsByMonth"></div>
								  </div>
								</div>
							</div>
							</div>
		  </div>
		  <div class="tab-pane fade" id="calender" role="tabpanel" aria-labelledby="calender-tab">
		 	 <div class="calenderContent" id="calenderContent">&nbsp;<div id='calendarId'></div></div>
		  </div>
		</div>
		<!--  div load dril down listing -->
		<div class="gridWrapper" id="drillDownListingGridContainer">
			<div id="drillDownListingPage"></div>
			<table id="drillDownListingResultSet"></table>
		</div>
	</div>
	<div id="interaction_details_content_div" style="display: none">
	  <div class="row_padding">
		<input type="button" value="Back to interactions" onclick="viewInteractionMicroProfile(0,true);" class="btn custom-btn">
		</div>
		<div id="interaction_details_div"></div>
	</div>
	</div>
	<div class="col-sm-3">
		<form action="<?php echo base_url()?>interactions/interactions/export_interaction_details/<?php echo (isset($arrKolInfo))?$arrKolInfo['kol_id']:'';?>" method='post' id="export">
			<input type="hidden" id="ids" name="interaction_ids" value="<?php echo $interactionIds;?>"/>
			<input type="hidden" name="filters" id="excel-filters" />
			<input type="hidden" name="filters1" id="excel-filters1" />
			<input type="hidden" name="monthlyfrom_export"  id="monthlyfromExport"/>
			<input type="hidden" name="monthto_export" id="monthlyToExport"/>
			<input type="hidden" name="kol_name_export" id="kolNameExport"/>
			<input type="hidden" name="category_export" id="categoryExport"/>
			<input type="hidden" name="mode_export" id="modeExport"/>
			<input type="hidden" name="user_name_export" id="userNameExport" />
			<input type="hidden" name="type_export" id="typeExport"/>
			<input type="hidden" name="product_export" id="productExport"/>
			<input type="hidden" name="topic_export" id="topicExport" />
		</form>
		<div class="filterDiv"  style="margin-right:-15px;">
		<form id="interactionsFilterForm">
			<table class="table">
				<tr>
					<td>
					<h6>
					<div class="funnelIcon sprite_iconSet"></div>
					Refine By
					<div id="resetBttnContainer" class="pull-right">
						<label class="tooltip-demo tooltop-left" id="resetBttn" onclick="formReset();">
							<a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a>
						</label>
						Reset
					</div>
					</h6>
					</td>
				</tr>
				<tr>
					<td id="submitButton">
						<input type="button" value="Apply Filters" onclick="generateInteractionReport();"  class="btn custom-btn">
					</td>
				</tr>
				<tr>
					<td>
						<label style="display: inline;">From </label><input name="start_date" id="startDate" style="width: 34%;" type="text">
						<label style="display: inline;">To </label><input name="end_date" id="endDate" style="width: 34%;" type="text">
					</td>
				</tr>
				<tr>
					<td>
						<label>Manager:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<?php if($this->session->userdata('role_type') == ROLE_USER){
										echo $managerDetails['first_name'].' '. $managerDetails['last_name'];
									}else{?>
									<select name="manager_id[]" id="manager_id" class="form-control chosenMultipleSelect" multiple="multiple">
		                               	<?php foreach($arrManager as $key=>$val){ ?>
		                               		<option value="<?php echo $val['id']?>"><?php echo $val['name'];?></option>
		                               	<?php }?>
		                            </select>
		                            <?php }?>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Interaction Category:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="grouping[]"  id="grouping" class="form-control chosenMultipleSelect" multiple="multiple">
										<?php foreach($arrGroupings as $row){?>
											<option value="<?php echo $row['id'];?>">
												<?php echo $row['name'];?>
											</option>
										<?php }?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Interaction Type:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="mode[]"  id="mode" class="form-control chosenMultipleSelect" multiple="multiple">
										<?php foreach($arrModes as $mode){?>
											<option value="<?php echo $mode['id'];?>">
												<?php echo $mode['name'];?>
											</option>
										<?php }?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Employee Name:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="user_name[]"  id="user-name" class="form-control chosenMultipleSelect" multiple="multiple" <?php  if($userRole == ROLE_USER && $controllerName == 'interactions'){ echo 'disabled="disabled" style="background-color: #d3d3d3;"';}  ?> >
									<?php foreach($arrUsers as $key=>$user){?>
										<option value="<?php echo $key;?>" <?php if($userRole == ROLE_USER && $userId == $key && $controllerName == 'interactions' && $client_id != INTERNAL_CLIENT_ID) echo "selected = 'selected'";?>>
											<?php echo $user;?>
										</option>
									<?php } ?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Indication:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="product[]"  id="product" onchange="resetDropDowns()" class="form-control chosenMultipleSelect" multiple="multiple">
										<?php foreach($arrProduct as $product){?>
											<option value="<?php echo $product['id'];?>">
												<?php echo $product['name'];?>
											</option>
										<?php }?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Discussion Type:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="objective[]"  id="objective" class="form-control chosenMultipleSelect" multiple="multiple">
										<?php foreach($arrDiscussionType as $row){?>
											<option value="<?php echo $row['type_id'];?>">
												<?php echo $row['name'];?>
											</option>
										<?php }?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>Topic:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<select name="topic[]"  id="topic" class="form-control chosenMultipleSelect" multiple="multiple">
									<?php foreach($arrDiscussionTopic as $row){?>
										<option value="<?php echo $row['id'];?>" >
											<?php echo $row['name'];?>
										</option>
									<?php }?>
									</select>
								</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<label>KTL:</label>
						<div class="form-group row">
								<div class="col-sm-12">
									<input type="text" name="kol_name" id="kol-name" placeholder="Enter KTL" class="form-control autocompleteInputBox" <?php echo (isset($arrKolInfo))?'value="'.$arrKolInfo['kol_name'].'" readonly="readonly"':'';?>"/>
									<input type="hidden" name="kol_id" id="kol-id" value="<?php echo (isset($arrKolInfo))?$arrKolInfo['kol_id']:'';?>" />
								</div>
						</div>
					</td>
				</tr>
			</table>
			</form>
		</div>
	</div>
</div>
<script>
var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
var product = "Indication";
var kolId ="<?php echo (isset($arrKolInfo))?$arrKolInfo['kol_id']:'';?>";
var kol_unique_id 	= '<?php echo $arrKolInfo['kol_unique_id']?>'; 
var currentChartId = "list-tab";
var todayDate = "<?php echo date("m/d/Y");?>";
var monthFirstDate = "<?php echo date("m/01/Y");?>";
var yearFirstDate = "<?php echo date("01/01/Y");?>";
var colSecName = '<?php if($interaction_from == 'org') echo 'Organization Name'; else echo lang("KOL").' / Org Name';?>';
var product = "<?php echo lang("Overview.Product");?>";
var kolNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>helpers/helpers/get_kol_names_for_all_autocomplete',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui){
			var isDuplicate	= false;
			var selText = $(event).children('.kolName').html();
			var kolId = $(event).children('.kolName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#kol-name').val(selText);
			$('#kol-id').val(kolId);
		}
};

$(document).ready(function(){
	var a= $('#kol-name').autocomplete(kolNameAutoCompleteOptions); 
	$('#startDate, #endDate').daterangepicker();
	setDateranges();
	$('#manager_id').chosen({
        placeholder_text: "Click to Select Manager",
        allow_single_deselect: true
    });
	$('#grouping').chosen({
        placeholder_text: "Click to Select Interaction Category",
        allow_single_deselect: true
    });
	$('#mode').chosen({
        placeholder_text: "Click to Select Interaction Type",
        allow_single_deselect: true
    });
	$('#user-name').chosen({
        placeholder_text: "Click to Select Employee Name",
        allow_single_deselect: true
    });
	$('#product').chosen({
        placeholder_text: "Click to Select "+product,
        allow_single_deselect: true
    });
	$('#objective').chosen({
        placeholder_text: "Click to Select Discussion Type",
        allow_single_deselect: true
    });
	$('#topic').chosen({
        placeholder_text: "Click to Select Topic",
        allow_single_deselect: true
    });
	listInteractions();
	$("#list-tab").click(function(){
		currentChartId = "list-tab";
		$("#numericReportContainer").css("display","none");
		$("#pageChartContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$('#gridTabContainer').css("display","block");
		listInteractions();
	});
	$("#report-tab").click(function(){
		currentChartId = "report-tab";
		$("#numericReportContainer").css("display","block");
		$("#pageChartContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$('#gridTabContainer').css("display","none");
		generateNumericReport();
	});
	$("#chart-tab").click(function(){
		currentChartId = "chart-tab";
		$("#numericReportContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$("#pageChartContainer").css("display","block");
		$('#gridTabContainer').css("display","none");
		generateChartReport();
	});
	$("#calender-tab").click(function(){
		currentChartId = "calender-tab";
		$("#numericReportContainer").css("display","none");
		$("#calenderContent").css("display","block");
		$("#pageChartContainer").css("display","none");
		$('#gridTabContainer').css("display","none");
		generateCalenderEvents();
	});
});
function setDateranges(){
	if(kolId>0){
		$('#startDate').val(yearFirstDate);
	}else{
		$('#startDate').val(monthFirstDate);
	}
    var cdate = get_currentdate();
    $('#endDate').val(cdate);
}
function get_currentdate(){
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
	if(dd<10) {
	    dd='0'+dd
	} 
	if(mm<10) {
	    mm='0'+mm
	} 
	today = mm+'/'+dd+'/'+yyyy;
	return today;
}
function listInteractions(){
	kol_id = $('#kol-id').val();
	var gridWidth=$(".tab-content").width();
	$("#gridContainer").html("");
	$("#gridContainer").html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');
	var data = {};
	data['grouping'] = $('#grouping').val();
	data['mode'] = $('#mode').val();
	data['type'] = $('#objective').val();
	data['product'] = $('#product').val();
	data['topic'] = $('#topic').val();
	data['kol_id'] = kol_id;
	data['org_id'] = $('#org_institution_id').val();
	data['user_id'] = $('#user-name').val();
	data['manager_id'] = $('#manager_id').val();
	var sd = $('#startDate').val();
	if(sd!=''){
	var sdSplits = sd.split("/");
		data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];
	}
	var ed = $('#endDate').val();
	if(ed!=''){
		var edSplits = ed.split("/");
		data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
	}
	if(kolId>0){
		orgInteractionAction =  true;
	}else{
		orgInteractionAction =  false;
	}
	jQuery("#listInteractionsResultSet").jqGrid({
		url:base_url+'interactions/interactions/list_interactions_by_date_range/',
		datatype: "json",
	   	colNames:['Id','','','KTL / Org Name',"Interaction Date","Employee Name",'Interaction Type','Discussion Type','Product','Recorded By','Quality',"<div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off\-Label Question'>UOQ</span></div>",'Action','','','','','','','','client_id','data_type_indicator'],
	   	colModel:[
			{name:'generic_id',index:'generic_id', hidden:false},
			{name:'save_later',index:'save_later', hidden:true},
			{name:'micro',width:50, search:false,align:'center',sortable:false},
			{name:'kol_name',index:'kol_name',resizable:false},
			{name:'date',index:'date',sorttype:'date',formatoptions: {newformat:'m/d/Y'}, datefmt: 'm/d/Y'},
	   		{name:'recorded_by_name',index:'recorded_by_name',resizable:false},
	   		{name:'mode_name',index:'mode_name',resizable:false},
			{name:'objective_name',index:'objective_name',resizable:false},
	   		{name:'product_name',index:'product_name',resizable:false},
	   		{name:'recorded_by',index:'recorded_by',resizable:false},
	   		{name:'quality_interaction',index:'quality_interaction',resizable:false,hidden:true},
	   		{name:'mirf',width:60,align:'center',align:'left',search:true,sortable:true,hidden:true, formatter: function (cellvalue, options, rowObject) {
		   		var mirfText = '';
		   		if(rowObject.mirfAllowed){
					if(cellvalue =="Add"){
						mirfText = "<a href='"+base_url+"interactions/interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"</a>";
					}else{
						if(rowObject.save_later == 1)
							mirfText = "<a href='"+base_url+"interactions/interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"Edit</a>"+" "+"<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
						else
							mirfText = "<a href='"+base_url+"interactions/interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
					}
				}else{
					if(rowObject.mirf_id != null)
						mirfText = "<a href='"+base_url+"interactions/interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
                }
            return mirfText;
            }},
            {name:'act',width:150,align:'center',search:false,sortable:false},
            {name:'mirfAllowed',align:'center',hidden:true},
	   		{name:'mirf_id',align:'center',hidden:true},
	   		{name:'eAllowed',index:'eAllowed', hidden:true,search:false},
	   		{name:'id',index:'id', hidden:true},
			{name:'kol_unique_id',index:'kol_unique_id', hidden:true},
			{name:'msl_id',index:'msl_id', hidden:true},
			{name:'is_org_interaction',index:'is_org_interaction', hidden:true},
			{name:'client_id',index:'client_id',resizable:false,search:false,hidden:true},
		   	{name:'data_type_indicator',index:'data_type_indicator', hidden:true}
	   	],
		postData:data,
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#listInteractionsPage',
	   	mtype: "POST",
	   	sortname: 'date',
	    viewrecords: true,
	    sortorder: "desc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:'Interactions',
	    grouping: false, 
		groupingView : { 
			groupField : ['kol_name'], 
			groupColumnShow : [false], 
			groupText : ['<b>{0}</b>  ({1})'], 
			groupCollapse : false, 
			groupOrder: ['asc'], 
		//	groupSummary : [true], 
			groupDataSorted : true 
		},
		gridComplete: function(){
			//Get array of id'f from jqgrid			   
	    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 
	    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
	    	for(var i=0;i < arrIds.length;i++){ 
	    		var actionLink = '';
		    	var id = arrIds[i];
		    	var isAnalyst = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'client_id');
		    	 var createdByName = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'recorded_by_name');
		    	var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', id);
		    	if(isAnalyst != 1){                    
            		 actionLink = "<a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'><div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"></div></a>";
                 }else{
                 	var dataTypeIndicator = jQuery("#listInteractionsResultSet").jqGrid('getCell',id,'data_type_indicator');
                 	actionLink += data_type_indicator(dataTypeIndicator);		    		
                 };
		        if(edit_permission==1){
		        	actionLink += "<a href=\""+base_url+"interactions/interactions/add_interaction/kols/"+rowData.kol_unique_id+"/"+rowData.id+"\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\"><div class='actionIcon editIcon'></div></a>";
				 }
				if(delete_permission==1){
	    	  		actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div>";
				}	
                    <?php if($controllerName != 'interactions') {?>
							if(rowData.is_org_interaction == 0 && orgInteractionAction){
								var lock = '';
								<?php if($this->session->userdata("user_id") == 2322){?>
									if(rowData.save_later == '1')
	                                	lock = "<a href='javascript:void(0)' onclick='unlock_interaction("+rowData.id+",0,\""+rowData.generic_id+"\","+rowData.msl_id+")'>Lock</a>";
									else
										lock = "<a href='javascript:void(0)' onclick='unlock_interaction("+rowData.id+",1,\""+rowData.generic_id+"\","+rowData.msl_id+")'>Unlock</a>";									
								<?php }?>    

							}
                    <?php } ?> 
		    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
// // 		    	if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN)
// // 	    			microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfileCalenderView('"+rowData.id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";
// 	    		else
	    			microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+rowData.id+"'); return false;\" ><a href=\""+base_url+"interactions/interactions/view_interaction_details/"+rowData.id+"\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";	
		    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
		    	}
	    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");
	    },
   		rowList:[10,20,50]
   		
	}); 
	jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth); 
	var postParams = $('#listInteractionsResultSet').getGridParam("postData");
	postParams = JSON.stringify(postParams);
	$("#excel-filters").val(postParams);
}
function generateChartReport() {
// 	if(!$("#interactionsFilterForm").validate().form()){
// 		return false;
// 	}else{
// 		$('label.error').remove();
// 		$('#chartTable').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var data = {};
		var sd = $('#startDate').val();
		if(sd!=''){
		var sdSplits = sd.split("/");
			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];
		}
		var ed = $('#endDate').val();
		if(ed!=''){
			var edSplits = ed.split("/");
			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
		}
		data['grouping'] = $('#grouping').val();
		data['mode'] = $('#mode').val();
		data['type'] = $('#objective').val();
		data['product'] = $('#product').val();
		data['topic'] = $('#topic').val();
		data['kol_id'] = $('#kol-id').val();
		data['org_id'] = $('#org_institution_id').val();
		data['user_id'] = $('#user-name').val();
		$.ajax({
			url: base_url+'interactions/interactions/interactions_by_topic',
			dataType: 'json',
			data:data,
			type:'post',
			success: function(returnDataTopic) {
					var interByTopic 	= returnDataTopic.arrByTopic;
					var div_id = 'interactionsByTopic';
					drawPieChart(interByTopic,div_id);
			}
		});
		$.ajax({
			url: base_url+'interactions/interactions/interactions_by_channel',
			dataType: 'json',
			data:data,
			type:'post',
			success: function(returnDataChannel) {
					var interByChannel 	= returnDataChannel.arrByChannel;
					var div_id = 'interactionByChannel';
					drawPieChart(interByChannel,div_id);
			}
		});
		$.ajax({
			url: base_url+'interactions/interactions/interactions_by_employee',
			dataType: 'json',
			data:data,
			type:'post',
			success: function(returnDataEmployee) {
					var interByEmployee = returnDataEmployee.arrByEmployee;
					var div_id = 'interactionsByEmployee';
					drawPieChart(interByEmployee,div_id);
			}
		});
		$.ajax({
			url: base_url+'interactions/interactions/interactions_by_month',
			dataType: 'json',
			data:data,
			type:'post',
			success: function(returnDataMonth) {										
					interactionsByMonth(returnDataMonth.arrByMonth,returnDataMonth.arrMonths);						
			}
		});
// 	}
// 	$("#chartTable").unblock();		
	return true;
}
function generateInteractionReport(){
	$("#"+currentChartId).trigger("click");
}
function drawPieChart(data,div_id){   
    var chart = c3.generate({
    	bindto: '#'+div_id,
	    data: {
	        columns: data,
	        type : 'pie'	       
	    },	    
	    size: {
	    	  width: 250
	    },
	    color: {
	    	  pattern: chartColors
    	},
	    pie: {
	        label: {
	            format: function (value, ratio, id) {
	                return d3.format(".0%")(ratio);
	            }
	        }
	    },
	    tooltip: {
	        format: {	            
	            value: function (value, ratio, id) {           
	            	return value+' ('+d3.format('.0%')(ratio)+')';
	            }	            
	        }
	    },
	    legend: {
	        show: false
	    }
	});
   var dataLegend=new Array();
	$.each(data, function(i, item) {
		dataLegend.push(item[0]);
	});
    d3.select('#'+div_id).insert('div', '.chart').attr('class', 'legend').selectAll('h5')
    .data(dataLegend)
    .enter().append('h5')
    .attr('data-id', function (id) { return id; })
    .html(function (id) { return id; })
    .each(function (id) {
        d3.select(this).style('background-color', chart.color(id));
    })
    .on('mouseover', function (id) {
        chart.focus(id);
    })
    .on('mouseout', function (id) {
        chart.revert();
    })
    .on('click', function (id) {
        chart.toggle(id);
    });
}
function interactionsByMonth(arrByMonth,arrMonths){	
	var data =arrByMonth;
	var DataValues = [];
    var DataGroups = [];
	$.each(data, function (key, value) {  	
    	DataValues[key]=data[key].data;
    	DataGroups[key]=data[key].name;
    	DataValues[key].unshift(data[key].name);
    });	
	arrMonths.unshift("x");
	DataValues.unshift(arrMonths);
	  var chart = c3.generate({
	    	bindto: '#interactionsByMonth',
	    	data: {
	    	 x : 'x',
	            columns: DataValues,        	
	            groups: [DataGroups],
	            type: 'bar'
	        },
	        size: {
		    	  width:300
		    },
	        axis: {
	            x: {
	                type: 'category', // this needed to load string x value
	                tick: {
	           	     count:3 ,multiline: false          	    
	           	    },
	           	    label: {
	              	        text: 'Year',
	              	        position: 'outer-center',
	              	     }	
	            },
	            y:{
	            	label: {
	          	        text: product,
	          	        position: 'outer-middle',
	          	     }
	            }
	        },
	        color: {
		    	  pattern: chartColors
	        }
	   }); 
// 	  removeFloatingTicks('#interactionsByMonth');
}
function generateNumericReport(){
// 	if(!$("#interactionsFilterForm").validate().form()){
// 		return false;
// 	}else{
// 		$('label.error').remove();
// 		$('#numericReportContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var data = {};
		var sd = $('#startDate').val();
		if(sd!=''){
		var sdSplits = sd.split("/");
			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

		}
		var ed = $('#endDate').val();
		if(ed!=''){
			var edSplits = ed.split("/");
			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
		}
		data['grouping'] = $('#grouping').val();
		data['mode'] = $('#mode').val();
		data['type'] = $('#objective').val();
		data['product'] = $('#product').val();
		data['topic'] = $('#topic').val();
		data['subtopic'] = $('#subtopic').val();
		data['kol_id'] = $('#kol-id').val();
		data['org_id'] = $('#org_institution_id').val();
		data['user_id'] = $('#user-name').val();
		$.ajax({
			url: base_url+'interactions/interactions/interactions_numeric_report',
			dataType: 'text',
			data:data,
			type:'post',
			success: function(returnData) {
				$("#numericReportContainer").html(returnData);
				//$('#numericReportContainer').unblock();
			}
		});
		return true;
// 	}
}
function generateCalenderEvents(){
	$('#calendarId').fullCalendar( 'refetchEvents' );
	$('#calendarId').fullCalendar({
		height:600,
		width:900,
        eventClick: function(calEvent, jsEvent, view) {
        	openCalenderSnapshotBox(calEvent);
	    },
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		buttonText: {
		    today: 'Today',
		    month: 'Month',
		    week: 'Week',
		    day: 'Day'
		},
		editable: false,
		eventLimit: true, // allow "more" link when too many events
        timeFormat: '',
		events: {
			url: '<?php echo base_url()?>interactions/interactions/list_events_by_date_range',
            data:function() {
			var data = {};
			var sd = $('#startDate').val();
			if(sd!=''){
				var sdSplits = sd.split("/");
				data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];
			}
			var ed = $('#endDate').val();
			if(ed!=''){
				var edSplits = ed.split("/");
				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
			}
			data['grouping'] = $('#grouping').val();
			data['mode'] = $('#mode').val();
			data['type'] = $('#objective').val();
			data['product'] = $('#product').val();
			data['topic'] = $('#topic').val();
			data['subtopic'] = $('#subtopic').val();
			data['kol_id'] = $('#kol-id').val();
			data['org_id'] = $('#org_institution_id').val();
			data['user_id'] = $('#user-name').val();
            return data;
            },
            type:'post',
			error: function() {
				$('#script-warning').show();
			},
             success: function(returnData) {	
			}
		},
		loading: function(bool) {
			$('#loading').toggle(bool);
		}
	});
	setTimeout(function(){
		  $(".fc-month-button").click();
		}, 100); 
}
function export_excel(){
	var excelFilters = '';
	var sd = $('#startDate').val();
	if(sd != ''){
		var sdSplits = sd.split("/");
		var from_month_year = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];
		excelFilters += "Start Month : "+from_month_year+",";
	}
	var ed = $('#endDate').val();
	if(ed != ''){
		var edSplits = ed.split("/");
		var to_month_year = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];
		excelFilters += "End Month : "+to_month_year+",";
	}
		$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
			if($(this).val() != ''){
				var filterName = $(this).attr('name');
				var filterValue = $(this).val();
				excelFilters += filterName+" : "+filterValue+",";
			}
		});
		var selectedOPtion = $(".ui-pg-selbox").val();
		$(".ui-pg-selbox option:last").attr('selected','selected');
    	$('.ui-pg-selbox').trigger('change');
    	if($("#listInteractionsResultSet").html() != null )
    		var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs');
    	else
    		var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
    if($('#orgIntaerctionContainer').css('display')!='block'){
		$('#ids').val(arrIds);
	}
	var kol_name = $('#kol-name').val();
	if(kol_name !=''){
		var filterName = "KTL Name";
		excelFilters += filterName+" : "+kol_name.replace(",", "")+",";
	}
	var grouping = $('#grouping').val();
	if(grouping !=''){
		var filterName = "Interaction Category";
		excelFilters += filterName+" : "+$('#grouping option:selected').text()+",";
	}
	var mode = $('#mode').val();
	if(mode !=''){
		var filterName = "Interaction Type";
		excelFilters += filterName+" : "+$('#mode option:selected').text()+",";
	}
	var userName = $('#user-name').val();
	if(userName !=''){
		var filterName = "Employee Name";
		excelFilters += filterName+" : "+$('#user-name option:selected').text()+",";
	}
	var type = $('#objective').val();
	if(type !=''){
		var filterName = "Discussion Type";
		excelFilters += filterName+" : "+$('#objective option:selected').text()+",";
	}
	var product = $('#product').val();
	if(product !=''){
		var filterName = 'Indication';
		excelFilters += filterName+" : "+$('#product option:selected').text()+",";
	}
	var topic = $('#topic').val();
	if(topic!=''){
		var filterName = "Topic";
		excelFilters += filterName+" : "+$('#topic option:selected').text();
	}
	$("#excel-filters1").val(excelFilters);
	$('#export').submit();
	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
	$('.ui-pg-selbox').trigger('change');
}
function deleteInteraction(interaction_id){
	jConfirm("Are you sure you want to delete the interaction?","Confirm box", function(r){
		if(r){
			var formAction = base_url+'interactions/interactions/delete_interaction/'+interaction_id;
			$.ajax({
				url: formAction,
				dataType: "json",
				type: "post",
				success: function(retData){
					listInteractions();
				}
			});
		}
	});
}
function formReset(){
	document.getElementById("interactionsFilterForm").reset();
	setDateranges();
    $('select').trigger('liszt:updated');
    generateInteractionReport()
}
function view_interaction_drilldown_list(type,id,seg,filters=''){
	console.log(type);
	console.log(id);
	console.log(seg);
	console.log(filters);
	$('html, body').animate({
        scrollTop: $("#drillDownListingGridContainer").first().offset().top-100
	    },
	    1000,
    );
	$('#drillDownListingGridContainer').html('');
    $('#drillDownListingGridContainer').html('<table id="drillDownListingResultSet"></table><div id="drillDownListingPage"></div>');
	grid = $("#drillDownListingResultSet");
	grid.jqGrid({
		url: base_url+'interactions/interactions/interactions_drilldown_list/'+type+'/'+id+'/'+seg+'/'+filters,
 		datatype: "json",
		colNames:['Id','',colSecName,'Date','Recorded By','Interaction Type','Discussion Type',product,'Action'],
		colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'micro',width:30, search:false,align:'center',sortable:false},
			{name:'kol_name',index:'kol_name',width:170, resizable:false},
			{name:'date',index:'date', width:70, resizable:false},
	   		{name:'recorded_by',index:'recorded_by',width:170, resizable:false},
	   		{name:'mode_name',index:'mode_name',width:100, resizable:false},
			{name:'objective_name',index:'objective_name',width:210, resizable:false},
	   		{name:'product_name',index:'product_name',width:150, resizable:false},
	   		{name:'act',width:100, hidden:true,align:'center',search:false}   		
	   	],
		rowNum:10,
		autowidth:true,
		rownumbers: true,
		pager: '#drillDownListingPage',
		sortname: 'id',
		mtype: "POST",
		recordpos:'left',
		width:'100%',
		height:'auto',
		viewrecords: true,
		sortorder: "asc",
		ignoreCase:true,
		loadonce: false,
		multiselect: true,
	    caption:"Interactions",
		jsonReader: { repeatitems : false, id: "0" },
		gridComplete: function(){	
			//Get array of id'f from jqgrid			   
	    	var arrIds = jQuery("#drillDownListingResultSet").jqGrid('getDataIDs'); 
	    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
	    	for(var i=0;i < arrIds.length;i++){ 
	    		var arrId =  jQuery('#drillDownListingResultSet').jqGrid ('getRowData',  arrIds[i]);
		    	var id = arrId.id;		    	
		    	//Edit and Delete labels 	
		    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
	    		jQuery("#drillDownListingResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
	    		//Microview label	
	    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";
		    	jQuery("#drillDownListingResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 
		    	} 
	    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");
	    },
	});
	grid.jqGrid('navGrid','#drillDownListingPage',{add:false,del:false,edit:false,position:'right',search:false});
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	grid.jqGrid('navButtonAdd',"#drillDownListingPage",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search", onClickButton:toggle_search_toolbar});
}
function toggle_search_toolbar(){
	if(jQuery(".ui-search-toolbar").css("display")=="none") {
		jQuery(".ui-search-toolbar").css("display","");
	} else {
		jQuery(".ui-search-toolbar").css("display","none");
	}
}
function viewInteractionMicroProfile(Id=null,back_to_reports=false){
	if(back_to_reports){
		$('#interaction_details_content_div').hide();
		$('#interaction_report_div').show();
	}else{
		$('#interaction_details_div').load(base_url+'interactions/interactions/view_interaction_details/'+Id);
		$('#interaction_details_content_div').show();
		$('#interaction_report_div').hide();
	}
}
</script>