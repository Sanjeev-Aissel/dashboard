<?php
/*
 * To extend survey
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 26-04-2013
 *  
 */
?>
<style type="text/css">
.contentHeader span{
	padding-bottom: 2px;
	padding-top: 4px;
}
</style>
<script type="text/javascript">
var actualEndDate		= '<?php echo $endDate;?>';
var tempActualEndDate 	=  new Date(actualEndDate.replace(/-/g, '/')).getTime();
function validate(){
	var endDate		= $('#endDate').val();
	var tempEndDate	=  new Date(endDate.replace(/-/g, '/')).getTime();
	if(tempEndDate > tempActualEndDate){
		$('#extendDateForm').submit();
	}else{
		jAlert('To extend survey, End date should be greater than Actual end date');
	}
}
function cancel(){
	$("#addSurveyContainer").dialog("close");
}
$(document).ready(function (){
	$('#endDate').datepicker({
		changeMonth: true,
    	changeYear: true,
		dateFormat: 'mm/dd/yy'
	});
});
</script>
<div id="extendDateContainer">
	<div class="contentHeader"><span>Extend Survey End Date</span></div><br />
	<div>
		<form name="extend_date_form" id="extendDateForm" method="post" action="<?php echo base_url();?>surveys/save_extended_date">
			<input type="hidden" name="survey_id" id="surveyId" value="<?php echo $id;?>" />
			<table>
				<tr>
					<td style="text-align: right;">End Date:</td>
					<td><input type="text" name="end_date" id="endDate" value="<?php echo $endDate;?>" /></td>
				</tr>
				<tr>
					<td colspan="2" style="text-align: center;">
						<input type="button" value="Extend Date" onclick="validate();" />
						<input type="button" value="Cancel" onclick="cancel();" />
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>