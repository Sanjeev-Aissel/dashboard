<?php
/**
 * This is HTML page to show Interation micro view profile
 * 
 * @author Ramesh B
 * @Created on: 04-03-11
 * @since  1.5	
 */
?>

<div id="interactionMicroProfileContent">
	<div class="microViewThumbnail">
		
	</div>
	<h3><?php echo $interactionDetails['salutation']." ".$interactionDetails['last_name']." ".$interactionDetails['middle_name']." ".$interactionDetails['first_name'];?></h3>
	<table class="microViewTbl">
		<tr>
			<th><span class="addrHeading">Date:</span></th>
			<td><?php echo $interactionDetails['date']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Time:</span></th>
			<td><?php echo $interactionDetails['time']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Mode:</span></th>
			<td><?php echo $interactionDetails['mode_name']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Location:</span></th>
			<td><?php echo $interactionDetails['location']; ?></td>
		</tr>	
		<tr>
			<th><span class="addrHeading">Topic:</span></th>
			<td><?php echo $interactionDetails['topic_name']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Brand:</span></th>
			<td><?php echo $interactionDetails['brand_name']; ?></td>
		</tr>
		
		
		
		<tr>
			<th><span class="addrHeading">Role:</span></th>
			<td><?php echo $interactionDetails['role_name']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Follow-Up On:</span></th>
			<td><?php echo $interactionDetails['follow_up_on']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Reminder:</span></th>
			<td><?php echo $interactionDetails['reminder']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Category:</span></th>
			<td><?php echo $interactionDetails['category_name']; ?></td>
		</tr>	
		<tr>
			<th><span class="addrHeading">Notes:</span></th>
			<td><?php echo $interactionDetails['notes']; ?></td>
		</tr>
		<tr>
			<th><span class="addrHeading">Therapeutic Area:</span></th>
			<td><?php echo $interactionDetails['therapeutic_area']; ?></td>
		</tr>
	</table>
</div>