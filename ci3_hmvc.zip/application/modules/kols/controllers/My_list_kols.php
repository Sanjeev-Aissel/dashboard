<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class My_list_kols extends MX_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('My_list_kol');
		$this->load->model('helpers/common_helper');
	}
	function add_list($kols=0){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrCategory=$this->My_list_kol->listCategories($user_id,$client_id);
		$data['arrCetgory']=$arrCategory;
		$data['arrKols'] = $kols;
		$this->load->view('my_list_kols/add_list',$data);
		
	}
	function get_list_names($categoryId){
		$arrlist=$this->My_list_kol->getListNames($categoryId);
		echo json_encode($arrlist);
	}
	function save_list_kols(){
		$kols=$this->input->post('kol_id');
		$arrCatgory['category']=trim($this->input->post('category'));
		$arrCatgoryId['category_id']=$this->input->post('category_id');
		$arrListName['list_name']   =trim($this->input->post('list_name'));
		$arrListNameId['list_name_id']   =$this->input->post('list_name_id');
		$arrCatgory['is_public']=$this->input->post('is_public');
		if($arrCatgory['category']!=''){
			$arrCatgory['user_id'] = $this->session->userdata('user_id');
			$arrCatgory['client_id'] = $this->session->userdata('client_id');
			if($lastInsertId = $this->common_helper->insertEntity('list_categories',$arrCatgory)){
				$data['cat_saved']=true;
				$data['msg']="Saved Successfully";
			}else{
				$data['msg']="Sorry! Name is Already Present in Databse";
				$data['cat_saved']=false;
			}
		}else{
			$this->db->set('is_public',$arrCatgory['is_public']);
			$this->db->where('id',$arrCatgoryId['category_id']);
			$this->db->update('list_categories');
			$lastInsertId=$arrCatgoryId['category_id'];
			$data['msg']="Saved Successfully";
			$data['cat_saved']=true;
		}
		$arrListName['category_id']=$lastInsertId;
		
		if($arrListName['list_name'] !=''){
			$arrListName['user_id'] = $this->session->userdata('user_id');
			if($lastInsertId = $this->common_helper->insertEntity('list_names',$arrListName)){
				$data['list_saved']=true;
				$data['msg1']="Saved Successfully";
			}else{
				$data['msg1']="Sorry! Name is Already Present in Databse";
				$data['list_saved']=false;
			}
		}else{
			$lastInsertId=$arrListNameId['list_name_id'];
			$data['list_saved']=true;
		}
		$arrKols = explode(',',$kols);
		$this->My_list_kol->saveListOfKols($arrKols,$lastInsertId);
		echo json_encode($data);
	}
}