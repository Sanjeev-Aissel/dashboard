<?php
/**
 * Model for ID Project
 * 
 * @package application.models
 * @author Laxman K
 * @since 3.7
 * @created on  01-03-2012
 */

class Id_project extends model{
	
	function Id_project(){
		parent::model();
	}
	
	/**
	 * Returns the distinct authors with publications count
	 * @author 	Laxman K
	 * @since	3.7
	 * @return Array
	 * @created 01-03-2012
	 */
	function get_all_authors_pubscount(){
		
		//$this->db->distinct();
		$this->db->select("id_unique_authors.id, id_unique_authors.last_name,id_unique_authors.fore_name,id_unique_authors.initials,id_analysis.auth_count,id_analysis.pubs_count,id_project.project_name");
		$this->db->join('id_unique_authors','id_unique_authors.id=id_analysis.author_id','inner');
		$this->db->join('id_project','id_project.id=id_analysis.project_id','inner');
		$this->db->order_by('id_analysis.pubs_count','desc');
		$resultSet	= $this->db->get('id_analysis');
		//echo $this->db->last_query();
		foreach($resultSet->result_array() as $row){
			$arrAuthors[]	= $row;
		}
		return $arrAuthors;
	}
	
	
	/*  
	 * get project details
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function get_project_details($projectId=''){
		$tableName	= 'id_project';
		if($projectId!=''){
			$this->db->where('id',$projectId);
			$resultSet	= $this->db->get($tableName);
			return $resultSet->result_array();
		}else{
			$resultSet	= $this->db->get($tableName);
			foreach($resultSet->result_array() as $row){
				$arrprojects[]	= $row;
			}
			return $arrprojects;
		}
	}
	
	/*  
	 * get author analysis data from DB Table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function get_unique_authors_analysis($projectId,$limit='',$orderByfieldName='', $authorId=''){
		$tableName			= 'id_analysis';
		$authorTableName	= 'id_unique_authors';
		$arrUniqueAuthors	= array();
		$query	= "select ia.author_id,a.last_name,a.fore_name,a.initials,ia.auth_count,ia.pubs_count from ".$tableName." as ia, ".$authorTableName." as a";
		$query	.= " where ia.project_id=".$projectId;
		$query	.= " and a.id=ia.author_id";
		if($authorId!=''){
			$query	.= " and ia.author_id=".$authorId;
		}
		if($orderByfieldName!=''){
			$query	.= " order by ia.".$orderByfieldName." desc";
		}else{
			$query	.= " order by ia.auth_count desc";
		}
		if($limit!='')
			$query	.= " limit ".$limit;
		$resultSet	= $this->db->query($query);
		if($resultSet->num_rows!=0){
			foreach($resultSet->result_array() as $row){
				$arrUniqueAuthors[]	= $row;
			}
		}
		return $arrUniqueAuthors;
	}
	
	/*  
	 * start analysing data
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function process_id_analysis($project_id,$input_query_id,$author_id,$pmid,$pubs_count=0){
		$tableName	= 'id_analysis';
		$resultSet	= $this->db->query("select id,auth_count from ".$tableName." where project_id=".$project_id." and pmid=".$pmid." and author_id=".$author_id);
		if($resultSet->num_rows==0){
			//echo "insert new";
			$arrAnalysis['project_id']	= $project_id;
			$arrAnalysis['query_id']	= $input_query_id;
			$arrAnalysis['author_id']	= $author_id;
			$arrAnalysis['pmid']		= $pmid;
			$arrAnalysis['auth_count']	= 1;
			$arrAnalysis['pubs_count']	= $pubs_count;
			if($this->db->insert($tableName,$arrAnalysis)){
				return $this->db->insert_id();
			}else{
				return false;
			}
			
		}else{
			//echo "updating existing";
			foreach($resultSet->result_array() as $row){
				//update pubs count by 1
				$updatePubsCount['auth_count']	= ($row['auth_count']+1);
				$this->db->where('id',$row['id']);
				$this->db->where('project_id',$project_id);
				//$this->db->where('query_id',$input_query_id);
				$this->db->where('author_id',$author_id);
				$this->db->where('pmid',$pmid);
				$this->db->update($tableName,$updatePubsCount);
				
			}
		}
		return true;
	}	//end of process_id_analysis function
	
	/*  
	 * save unique author in DB table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function save_author($arrAuthorName){
		$tableName	= 'id_unique_authors';
		$arrNewAuthorName['last_name']	= $arrAuthorName['last_name'];
		$arrNewAuthorName['fore_name']	= $arrAuthorName['fore_name'];
		$arrNewAuthorName['initials']	= $arrAuthorName['initials'];
		unset($arrNewAuthorName['unique_name']);
		if(!(empty($arrNewAuthorName['last_name']) && empty($arrNewAuthorName['fore_name']) && empty($arrNewAuthorName['initials']))){
			if($this->db->insert($tableName,$arrNewAuthorName)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}else{
			return false;
		}
		
	}//end of save_author function
	
	/*  
	 * get unique authors from DB table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function get_unique_authors(){
		$arrUniqueAuthors	= array();
		$tableName	= 'id_unique_authors';
		$resultSet	= $this->db->query("select id, concat(last_name,fore_name,initials) as unique_name from ".$tableName);
		if($resultSet->num_rows!=0){
			foreach($resultSet->result_array() as $row){
				$arrUniqueAuthors[str_replace(' ','',$row['unique_name'])]	= $row['id'];
			}
			return $arrUniqueAuthors;
		}else{
			return false;
		}
		
	}//end of get_unique_authors function
	
	/*  
	 *  save input queries/combinations in DB table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function save_project_inputs($projectId, $inputQuery, $pmid_count){
		$tableName	= 'id_project_inputs';
		$arrInputQuery['project_id']		= $projectId;
		$arrInputQuery['input_query']		= $inputQuery;
		$arrInputQuery['total_pmids']		= $pmid_count;
		if($this->db->insert($tableName,$arrInputQuery)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	//end of save_project_inputs function
	
	/*  
	 *  save author name combinations in DB table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.7
	 * Created on	: 06-03-2012
	 *  
	 */
	function save_auth_name_combinations($project_id,$input_query_id,$authName,$pubCount){
		$tableName	= 'id_project_name_combinations';
		$arrRow['project_id']		= $project_id;
		$arrRow['input_query_id']	= $input_query_id;
		$arrRow['combination']		= $authName;
		$arrRow['pubs_count']		= $pubCount;
		if($this->db->insert($tableName,$arrRow)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	/*  
	 * save unique PMID in Db table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function save_pmid($pmid){
		$tableName		= 'id_processed_pubs';
		$resultSet	= $this->db->query("select unique_pmid from ".$tableName." where unique_pmid=".$pmid."");
		if($resultSet->num_rows!=0){
			return false;
		}else{
			$arrPMID['unique_pmid']	= $pmid;
			if($this->db->insert($tableName,$arrPMID)){
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Save Unique PMID',
						'status' => STATUS_SUCCESS,
						'transaction_id' =>  $this->db->insert_id(),
						'transaction_table_id' => ID_PROCESSED_PUBS,
						'transaction_name' => 'Save Unique PMID',
						'parent_object_id' =>  $this->db->insert_id()
				);
				$this->config->set_item('log_details', $arrLogDetails);
				return $this->db->insert_id();
			}else{
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Save Unique PMID',
						'status' => STATUS_FAIL,
						'transaction_id' =>  $this->db->insert_id(),
						'transaction_table_id' => ID_PROCESSED_PUBS,
						'transaction_name' => 'Save Unique PMID',
						'parent_object_id' =>  $this->db->insert_id()
				);
				$this->config->set_item('log_details', $arrLogDetails);
				return false;
			}
		}
		
		
	}	//end of save_pmids function
	
	/*  
	 * save project name in DB table
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.6
	 * Created on	: 14-02-2012
	 *  
	 */
	function save_project($projectName){
		$tableName	= 'id_project';
		$arrProject['project_name']	= $projectName;
		$arrProject['created_on']	= date("Y-m-d H:i:s");
		$arrProject['created_by']	= $this->loggedUserId;
		if($this->db->insert($tableName,$arrProject)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	//end of save_project function
	
	/*  
	 * get project id from project name
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.7
	 * Created on	: 06-03-2012
	 *  
	 */
	function get_project_id($projectName){
		$tableName	= 'id_project';
		if($projectName!=''){
			$this->db->where('project_name',$projectName);
			$resultSet	= $this->db->get($tableName);
			return $resultSet->result_array();
		}else{
			return false;
		}
	}

	/*  
	 * get all inputs of particular project id
	 * @Author		: Laxman K
	 * @since 		: KOLM v3.7
	 * Created on	: 06-03-2012
	 *  
	 */
	function get_project_inputs($projectId){
		$tableName	= 'id_project_inputs';
		if($projectId!=''){
			$this->db->select($tableName.'.*, count(id_project_inputs.id) as authors_count, sum(id_analysis.pubs_count) as total_pubs_count');
			$this->db->join('id_analysis','id_analysis.query_id='.$tableName.'.id','left');
			$this->db->where($tableName.'.project_id',$projectId);
			$this->db->group_by($tableName.'.id');
			$resultSet	= $this->db->get($tableName);
			//echo $this->db->last_query();
			foreach($resultSet->result_array() as $row){
				$arrProjectInputs[]	= $row;
			}
			return $arrProjectInputs;
		}else{
			return false;
		}
	}
	
}