<?php
/**
*View file to display recent updates
*@author Ramesh B
*@since 4.2
*@package application.controllers	
*@created on 07-07-2012
*/
$sizeOfArrUpdate = sizeof($arrUpdates);
$html = "<div id='updates-list'>";
if($this->uri->segment(2) == 'analyst_index')
	$html .='<div class="activityHeading"><a id="all-updates-link" href="'.base_url().'updates/show_updates_analyst">'.lang("Home.ShowAll").'</a><div class="navLinkRecentActivity sprite_iconSet" style="margin-top: 0px;cursor: default;"></div><label>'.lang('Home.RecentActivity').'</label></div><table>';
else{
	if($sizeOfArrUpdate > 0){
		$html .='<div class="activityHeading">
			<a id="all-updates-link" href="'.base_url().'updates/show_updates">'.lang("Home.ShowAll").'</a>
			<div class="navLinkRecentActivity sprite_iconSet" style="margin-top: 0px;cursor: default;"></div>
			<label>'.lang('Home.RecentActivity').'</label>
			</div><table>';
	}else{
		$html .='<div class="activityHeading">
			<div class="navLinkRecentActivity sprite_iconSet" style="margin-top: 0px;cursor: default;"></div>
			<label>'.lang('Home.RecentActivity').'</label>
			</div><table>';
	}
	
}
//pr($arrUpdates);
//exit;
$i = 1;
$recentCount = 0;
// pr($arrUpdates);exit;

foreach($arrUpdates as $update){
    $isDefault = 0;
    $updateEntryhtml='';
	switch ($update['update_type_id']){
// 		case KOL_PROFILE_IMPORT : 	$kolName = $this->kol->getKolName($update['object_id']);
// 									$updateEntryhtml .= "Imported  KOL Profile ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_ADD : 		$kolName = $this->kol->getKolName($update['object_id']);
// 									$updateEntryhtml .="Added KOL Profile ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_DELETE : 	$updateEntryhtml .= "<div class='category-box category-overview' >KOL</div>";
// 									$updateEntryhtml .= "<div class='update-small-content' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
// 									$updateEntryhtml .="Deleted KOL";
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_OVERVIEW_UPDATE : 	$kolName = $this->kol->getKolName($update['object_id']);
// 									$updateEntryhtml .="Updated Overview information for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_CONTACT_ADD : 	 	$kolName = $this->kol->getKolName($update['object_id']);
// 									$updateEntryhtml .=$update['number']."new Contact(s) Added for  ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_CONTACT_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." Contact(s) updated for <a  href='".base_url()."kols/view/".$update['parent_object_id']."'>".getFullName($kolName)."</a>";
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_CONTACT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." Contact(s) information for <a href='".base_url()."kols/view/".$update['parent_object_id']."'>".getFullName($kolName)."</a>";
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_EDUCATION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> Added for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_EDUCATION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> Updated for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_EDUCATION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_AFFILITION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> Added for  ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_AFFILITION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> Updated for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_AFFILITION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_EVENT_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> Added for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_EVENT_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> Updated for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_EVENT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_SOCIAL_MEDIA_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Updated <a  class='update-aff' href='".base_url()."kols/view_social_media/".$update['parent_object_id']."'> Social Media </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_PUBLICATION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Added for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_PUBLICATION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;*/
// 		case KOL_PROFILE_PUBLICATION_VERIFY : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Verified for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_PUBLICATION_UNVERIFY : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Unverified for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_PUBLICATION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Updated for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_TRIAL_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Added for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PROFILE_TRIAL_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Updated for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		/*case KOL_PROFILE_TRIAL_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;*/
// 		case KOL_PERSONAL_INFO_ADD : 	$kolName = $this->kol->getKolName($update['object_id']);
// 									$updateEntryhtml .="Added  <a  class='update-aff' href='".base_url()."kols/view/".$update['object_id']."/personalinfo'> Personal Info </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;
// 		case KOL_PERSONAL_INFO_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 									$updateEntryhtml .="Updated  <a  class='update-aff' href='".base_url()."kols/view/".$update['object_id']."/personalinfo'> Personal Info  </a> information for ".getFullName($kolName);
// 								 	$recentCount++;break;

// 		case ORG_IMPORT : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 							$updateEntryhtml .="Imported Organization <a  href='".base_url()."organizations/view/".$update['object_id']."'>".$orgName."</a> ";
// 								 	$recentCount++;break;
// 		case ORG_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 							$updateEntryhtml .="Added Organization proifle <a  href='".base_url()."organizations/view/".$update['object_id']."'>".$orgName."</a> ";
// 								 	$recentCount++;break;
// 		case ORG_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 							$updateEntryhtml .="Deleted Organization ";
// 								 	$recentCount++;break;	
// 		case ORG_ABOUT_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 									$updateEntryhtml .="Updated Overview information of Organization proifle <a  href='".base_url()."organizations/view/".$update['object_id']."'>".$orgName."</a> ";
// 								 	$recentCount++;break;
// 		case ORG_ADDRESS_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 									$updateEntryhtml .="Updated Address information for organization <a  href='".base_url()."organizations/view/".$update['object_id']."'>".$orgName."</a> ";
// 								 	$recentCount++;break;	
// 		case ORG_CONTACT_ADD : 		$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Added ".$update['number']." Contact information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 								 	//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Contact(s) </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
									
// 									$recentCount++;break;
// 		case ORG_CONTACT_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Updated ".$update['number']." Contact information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									//$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Contact(s) </a> Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";			
// 									$recentCount++;break;	
// 		case ORG_CONTACT_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									$updateEntryhtml .="Deleted ".$update['number']." Contact information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 								 	$recentCount++;break;
// 		case ORG_SOCIAL_MEDIA_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
// 										$updateEntryhtml .="Updated Social Media information for organization <a  href='".base_url()."organizations/view/".$update['object_id']."'>".$orgName."</a> ";
// 								 		$recentCount++;break;
// 		case ORG_KEY_PEOPLE_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Added ".$update['number']." Key People information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 								$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_keypeople/".$update['parent_object_id']."'> Key People </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> "; 	
// 								$recentCount++;break;	
// 		case ORG_KEY_PEOPLE_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Updated ".$update['number']." Key People information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_keypeople/".$update['parent_object_id']."'> Key People </a> Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> "; 	
// 									$recentCount++;break;
// 		case ORG_KEY_PEOPLE_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										$updateEntryhtml .="Deleted ".$update['number']." Key People information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									 	$recentCount++;break;
							 	
// 	 	case ORG_ENROLLEMET_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									//$updateEntryhtml .="Added ".$update['number']." Enrollement information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 	 								$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Enrollment(s) </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$recentCount++;break;
										
// 		case ORG_ENROLLEMET_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									 $updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Enrollment(s) </a> Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									 	$recentCount++;break;
										
// 		case ORG_FORMULARY_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Formulary </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 	 								//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$recentCount++;break;
										
// 		case ORG_FORMULARY_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									 	//$updateEntryhtml .="Updated ".$update['number']." Formulary information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Formulary </a> information Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									 	$recentCount++;break;	
// 		case ORG_DISEASE_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Added ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Disease Management </a> information Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";		
// 									$recentCount++;break;
										
// 		case ORG_DISEASE_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									 	//$updateEntryhtml .="Updated ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Disease Management </a> information Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";		
// 									 	$recentCount++;break;
									 	
// 		case ORG_COLLABARATION_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									 	//$updateEntryhtml .="Updated ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$updateEntryhtml .="Added <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Collaboration Rating </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";		
// 									 	$recentCount++;break;							 	

// 		case ORG_NOTES_ADD : 		$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Added ".$update['number']." Notes for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Note(s) </a>  Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";			
// 									$recentCount++;break;
										
// 		case ORG_NOTES_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									 //	$updateEntryhtml .="Updated ".$update['number']." Notes for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Note(s) </a>  Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";	
// 									$recentCount++;break;	
// 		case ORG_PUBLICATION_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									//$updateEntryhtml .="Added ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 	 								//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a>  Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";		
// 									$recentCount++;break;
		
// 		case ORG_PUBLICATION_VERIFY : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
// 									//$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
// 									//$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
// 									//$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Verified for ".getOrgName($orgName);
// 								 	$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Verified for ".getOrgName($orgName);
									
// 									$recentCount++;break;
// 		case ORG_PUBLICATION_UNVERIFY : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
// 									//$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
// 									//$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
// 									//$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Unverified for ".getOrgName($orgName);
// 								 	$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Unverified for ".getOrgName($orgName);
// 									$recentCount++;break;							
// 		case ORG_PUBLICATION_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 									//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										//$updateEntryhtml .="Updated ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publications(s) </a>  Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";	
// 										$recentCount++;break;		
// 		case ORG_TRIAL_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									//$updateEntryhtml .="Added ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 	 								$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a>  Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";	
// 									//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$recentCount++;break;
// 		case ORG_TRIAL_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 										//$updateEntryhtml .="Updated ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a>  Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";	
// 									$recentCount++;break;										
																		
// 		case USER_ADD : $user = $this->Client_User->editUser($update['object_id']);	
// 						$updateEntryhtml .="Added User ".$user['first_name'];
// 								 	$recentCount++;break;
// 		case USER_UPDATE : 	$user = $this->Client_User->editUser($update['object_id']);	
// 						$updateEntryhtml .="Updated User ".$user['first_name'];
// 								 	$recentCount++;break;
// 		case USER_DELETE : 	$updateEntryhtml .="Deleted User";
// 								 	$recentCount++;break;		
// 		case CLIENT_ADD : 	$updateEntryhtml .="Added Client";
// 								 	$recentCount++;break;
// 		case CLIENT_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case CLIENT_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
														
// 		case KOL_LIST_CREATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case KOL_LIST_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case KOL_LIST_ADD : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;																		
// 		case KOL_LIST_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;

// 		case OBJECTIVE_ADD : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case OBJECTIVE_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;																		
// 		case OBJECTIVE_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;

// 		case PLAN_ADD : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case PLAN_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;																		
// 		case PLAN_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;

// 		case INTERACTION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 								if($arrKol['status']==PRENEW || $arrKol['status'] ==COMPLETED)
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/interaction'> Interaction(s) </a> Added for ".getFullName($kolName);
// 								else
// 									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."interactions/list_interactions'> Interaction(s) </a> Added for ".getFullName($kolName);
// 							 	$recentCount++;break;
// 		case INTERACTION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 								if($arrKol['status']==PRENEW || $arrKol['status'] ==COMPLETED)
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/interaction'> Interaction(s) </a> Updated for ".getFullName($kolName);
// 								else
// 									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."interactions/list_interactions'> Interaction(s) </a> Updated for ".getFullName($kolName);
// 							 	$recentCount++;break;																		
// 		/*case INTERACTION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 								$updateEntryhtml .="Deleted  ".$update['number']." <a class='update-aff' href='".base_url()."interactions/list_interactions'> Interaction(s) </a> information for ".getFullName($kolName);
// 							 	$recentCount++;break;*/

// 		case PAYMENT_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 							$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."payments/list_payments/payment'> Payment(s) </a> Added for ".getFullName($kolName);
// 							$recentCount++;break;
// 		case 'Update Payment' : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 		                         $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
// 								$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."payments/list_payments/payment'> Payment(s) </a> Updated for ".getFullName($kolName);
// 							 	$recentCount++;break;																	
// 		/*case PAYMENT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
// 								$updateEntryhtml .="Deleted  ".$update['number']." <a class='update-aff' href='".base_url()."payments/list_payments'> Payment(s) </a> information for ".getFullName($kolName);
// 							 	$recentCount++;break;*/

// 		case CONTRACT_ADD : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case CONTRACT_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;																		
// 		case CONTRACT_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
																
// 		case CALENDER_EVENT_ADD : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case CALENDER_EVENT_UPDATE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;																		
// 		case CALENDER_EVENT_DELETE : 	$updateEntryhtml .="Updated Client";
// 								$recentCount++;break;
// 		case KOL_STATUS_UPDATE : $kolName = $this->kol->getKolName($update['parent_object_id']);
// 								$statusString = "";
// 								if($update['object_id'] == STATUS_COMPLETED){
// 									$statusString = COMPLETED;
// 									$updateEntryhtml .= "Changed  KOL Profile <a  href='".base_url()."kols/view/".$update['parent_object_id']."'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_APPROVED){
// 									$statusString = APPROVED;
// 									$updateEntryhtml .= "Changed  KOL Profile <a  href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_NEW){
// 									$statusString = New1;
// 									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_PROFILING){
// 									$statusString = PROFILING;
// 									$updateEntryhtml .= "Changed  KOL Profile <a  href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}	
// 								if($update['object_id'] == STATUS_REVIEW){
// 									$statusString = REVIEW;		
// 									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_REJECTED){
// 									$statusString = REJECT;		
// 									$updateEntryhtml .= "Changed  KOL Profile <a  href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
// 								}		
// 							 	$recentCount++;break;									
// 		case ORG_STATUS_UPDATE : $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
// 								$statusString = "";
// 								if($update['object_id'] == STATUS_COMPLETED){
// 									$statusString = COMPLETED;
// 									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."kols/view/".$update['parent_object_id']."'>".$orgName."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_NEW){
// 									$statusString = New1;
// 									$updateEntryhtml .= "Changed  ORG Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".$orgName."</a> Status to ".$statusString."";
// 								}
// 								if($update['object_id'] == STATUS_PROFILING){
// 									$statusString = PROFILING;
// 									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."requested_kols/show_client_requested_kols'>".$orgName."</a> Status to ".$statusString."";
// 								}	
// 								if($update['object_id'] == STATUS_REQUESTED){
// 									$statusString = REJECT;		
// 									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."requested_kols/show_client_requested_kols'>".$orgName."</a> Status to ".$statusString."";
// 								}		
// 							 	$recentCount++;break;
// 		case SURVEY_STATUS_ADD : $surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
// 								$statusString = "";
// 								if($update['object_id'] == STATUS_CREATED){
// 									$statusString = CREATED;
// 									$updateEntryhtml .= "A new Survey <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a> has been ".$statusString."";
// 								}
// 							 	$recentCount++;break;
// 		case SURVEY_STATUS_UPDATE : $surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
// 								$statusString = "";
// 								if($update['object_id'] == STATUS_UPDATED){
// 									$statusString = UPDATED;
// 									$updateEntryhtml .= "A Survey <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a> has been ".$statusString."";
// 								}
// 							 	$recentCount++;break;
// 		case SURVEY_STATUS_RESPONDED :$surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
// 								$statusString = "";
// 								if($update['object_id'] == STATUS_RESPONDED){
// 									$statusString = RESPONDED;
// 									$updateEntryhtml .= "New survey response received for <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a>";
// 								}
// 							 	$recentCount++;break;
        case "New HCP" : 			$kolName = $this->kol->getKolName($update['object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= 'Added New KTL '.getFullName($kolName);
        }
        $recentCount++;break;
        
        case "Save Location" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= 'Added Location For KTL '.getFullName($kolName);
        }
        $recentCount++;break;
        
        case "Save Note" : 			$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= 'Added KTL Note For '.getFullName($kolName);
        }
        $recentCount++;break;
        case "Update Note" : 			$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' Note(s) Updated For KTL '.getFullName($kolName);
        }
        $recentCount++;break;
        case "Notifications" :
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' New Notification Added <a target="" href="'.base_url().'notifications/notifications_home">View</a>';
            $recentCount++;break;
        case "Update Notifications" :
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' Notification Updated <a target="" href="'.base_url().'notifications/notifications_home">View</a>';
            $recentCount++;break;
        case "Update Location" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= 'Updated details for KTL '.getFullName($kolName);
        }
        $recentCount++;break;
        
        case "Update HCP" : 		$kolName = $this->kol->getKolName($update['object_id']);
        
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= 'Updated details for KTL '.getFullName($kolName);
        }
        $recentCount++;break;
        case "New Organization" :
            $orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
            if($orgName !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= 'Added Organization <a href='.base_url().'organizations/view/'.$update['object_id'].'>'.$orgName.'</a>';
            }
            $recentCount++;break;
        
        case "Save Location Org" :
            $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
            if($orgName !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= 'Added Location For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a>';
            }
            $recentCount++;break;
        
        case "Update Location Org" :
            $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
            if($orgName !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= 'Updated Location For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a>';
            }
            $recentCount++;break;
        case "Update Organization" :
            $orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
            if($orgName !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= 'Updated Overview Information For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a>';
            }
            $recentCount++;break;
        case "New Interaction" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' new <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/interaction_report">Interaction(s)</a> Added for '.getFullName($kolName);
        }
        $recentCount++;break;
        
        case "Update Interaction" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
        if(getFullName($kolName) !== ''){
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/interaction_report">Interaction(s)</a> Updated for '.getFullName($kolName);
        }
        $recentCount++;break;
        
        
        case "New Payment" :
            $kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' new <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/payments"> Payment(s) </a> Added for '.getFullName($kolName);
            }
            $recentCount++;break;
		case 'Update Payment' : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
			 $updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/payments'> Payment(s) </a> Updated for ".getFullName($kolName);
		 	$recentCount++;break;
        case "New Contract" :
            $kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' new <a href="'.base_url().'contracts/show_contracts"> Contract(s) </a> Added for '.getFullName($kolName);
            }
            $recentCount++;break;
             
        case "New Planning" :
            $kolName = $this->kol->getKolName($update['parent_object_id']);
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' new Plan(s) Added <a href="'.base_url().'plannings/show_plans"> View</a>';
            $recentCount++;break;
        case "Update Planning" :
            $kolName = $this->kol->getKolName($update['parent_object_id']);
            $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
            $updateEntryhtml .= $update['number'].' Plan(s) Updated <a href="'.base_url().'plannings/show_plans"> View</a>';
            $recentCount++;break;
         case "Update Contract" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' Contract(s) Updated <a href="'.base_url().'contracts/show_contracts"> View</a>';
                $recentCount++;break;
            case "New Objective" :
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' new Objective(s) Added <a href="'.base_url().'plannings/show_plans/objectives"> View</a>';
                $recentCount++;break;
            case "Update Objective" :
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' Objective(s) Updated <a href="'.base_url().'plannings/show_plans/objectives"> View</a>';
                $recentCount++;break;
            case "Add Affilation" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New <a href="'.base_url().'kols/view_affiliations/'.$update['parent_object_id'].'"> Affiliation(s) </a> Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Affilation" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' <a href="'.base_url().'kols/view_affiliations/'.$update['parent_object_id'].'"> Affiliation(s) </a> Updated for '.getFullName($kolName);
                }
                $recentCount++;break;
                 
            case "New Events" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New <a href="'.base_url().'kols/view_events/'.$update['parent_object_id'].'"> Event(s) </a> Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Events" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' <a href="'.base_url().'kols/view_events/'.$update['parent_object_id'].'"> Event(s) </a> Updated for '.getFullName($kolName);
                }
                 
                $recentCount++;break;
            case "New Publications" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New <a href="'.base_url().'kols/view_publications/'.$update['parent_object_id'].'"> Publication(s) </a> Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Publications" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' <a href="'.base_url().'kols/view_publications/'.$update['parent_object_id'].'"> Publication(s) </a> Updated for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "New Clinical Trails" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New <a href="'.base_url().'kols/view_clinical_trials/'.$update['parent_object_id'].'"> Clinical Trail(s) </a> Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Clinical Trails" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' <a href="'.base_url().'kols/view_clinical_trials/'.$update['parent_object_id'].'"> Clinical Trail(s) </a> Updated for '.getFullName($kolName);
                }
                 
                $recentCount++;break;
            case "New Education" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New Education(s) Added for '.getFullName($kolName);
                }
                 
                $recentCount++;break;
            case "Update Education" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .=$update['number'].' Education(s) Updated for '.getFullName($kolName);
                }
            
                $recentCount++;break;
            
            case "New Training" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New Training(s) Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Training" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' Training(s) Updated for '.getFullName($kolName);
                }
                $recentCount++;break;
            
            case "New Board_certification" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New Board Certification(s) Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Board_certification" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' Board Certification(s) Updated for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "New Honors_awards" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' New Honors Award(s) Added for '.getFullName($kolName);
                }
                $recentCount++;break;
            case "Update Honors_awards" :
                $kolName = $this->kol->getKolName($update['parent_object_id']);
                if(getFullName($kolName) !== ''){
                    $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                    $updateEntryhtml .= $update['number'].' Honors Award(s) Updated for '.getFullName($kolName);
                }
                 
                $recentCount++;break;
            case "New Phone" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' New Phone(s) Added For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "Update Phone" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' Phone(s) Updated For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "New Email" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' New Email(s) Added For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "Update Email" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' Email(s) Updated For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "New Staff" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' New Staff(s) Added For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "Update Staff" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' Staff(s) Updated For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "New License" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' New License(s) Added For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
            case "Update License" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
            if(getFullName($kolName) !== ''){
                $updateEntryhtml = "<tr><td id='".$i."' class='update-row'>";
                $updateEntryhtml .= $update['number'].' License(s) Updated For KTL '.getFullName($kolName);
            }
            $recentCount++;break;
		default:  //$updateEntryhtml .="................";
		          $isDefault = 1;
				break;	
	}
	if(!$isDefault){
	   $time = strtotime($update['published_time']);
	   $updateEntryhtml .= "</td><td style='vertical-align: bottom;'><span class='human-time'> ".humanTiming($time)."</span></td>";
	}
	$updateEntryhtml .= '</tr>';
	$html .= $updateEntryhtml;
	$i++;
	if($recentCount>4){
	    break;
	}
//	pr($update);exit;
}
$html .='</table></div>';
echo $html;
//echo "<label id='load-more'>Load more</label>";

function getFullName($arrKol){
	/*$firstName	= $arrKol['first_name'];
	$middleName	= $arrKol['middle_name'];
	$lastName	= $arrKol['last_name'];
	
	$fullName	= $firstName;
	if(!empty($middleName))
		$fullName	.= ' '. $middleName;
	if(!empty($lastName))
		$fullName	.= ' '. $lastName;*/
	$arrSalutations	= array(0 => '', 1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
	if($arrKol['status']==PRENEW || $arrKol['status'] ==COMPLETED){
		$fullName = '<a  href="'.base_url().'kols/view/'.$arrKol['unique_id'].'">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
//		$fullName = '<a  href="'.base_url().'kols/view/'.$arrKol['id'].'">'.$arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	}elseif($arrKol['status']==New1 || $arrKol['status']=='Approved'){
		$fullName = '<a  href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
//		$fullName = '<a  href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	}elseif($arrKol['status']=='rejected' ){
		$fullName = '<a  href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
//		$fullName = '<a  href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	}else{
		$fullName = $arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']);
//		$fullName = $arrSalutations[$arrKol['salutation']]." ".$this->common_helpers->get_name_format($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']);
	}
				
	return $fullName;
}

function getOrgName($arrNames){
	if($arrNames['status'] == COMPLETED){
		$orgName = "<a  href='".base_url()."organizations/view/".$arrNames['id']."'>".$arrNames['name']."</a> ";
	}else{
		$orgName = $arrNames['name'];
	}
	 return $orgName;
}
?>
<style type="text/css">
.update-row{
    font-size: 12px;
    margin-bottom: 5px;
    margin-top: 3px;
}
.update-row a{
	font-size: 11px;
	text-decoration: none;
}
#updates-list table{
	margin-bottom: 0px;
}
#updates-list td{
	padding: 0px;
	border-bottom: 1px dotted #626262;
}
#updates-list td span{
	color: green;
    float: right;
    font-size: 11px;
    width:75px;
}

#all-updates-link{
	/*color: #2A88E6;*/
	color: #009;
    float: right;
    font-size: 11px;
    padding-top: 3px;
    text-decoration: none;
}

div#load-more{
	display: block;
	text-align: center;
}
.activityHeading{
	border-bottom: 1px solid;
	margin-bottom:5px;
}
#updates-list tr td{
	padding-top: 5px;
}
</style>

<script type="text/javascript">
$(document).ready(function(){
	$("label#load-more").click(function(){
		lastAddedLiveFunc();
	}); 
});

function lastAddedLiveFunc(){
	//$('div#lastPostsLoader').html('<img src="images/bigLoader.gif">');
	var data={};
	data['start_from']=$(".update-row:last").attr("id");
	$.ajax({
	 	type: 'POST',
  	  	data: data,
	  	url: base_url+'updates/show_updates',
	  	dataType: 'text',
      	success: function(returnData) {
			if (returnData != "") {
				$("#updates-list").append(returnData);
			}
			//$('div#lastPostsLoader').empty();
  		}	
	});
}
</script>