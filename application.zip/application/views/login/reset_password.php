<style type="text/css">
.password_reset_block {
	background: white; 
	border:2px solid #FFFFFF; 
	width: 550px; 
	height: 150px; 
	border-radius: 10px; 
	margin: 5% auto; 
	margin-left: auto; 
	margin-right: auto; 
	min-height: 200px;
}

.reset_message {
	color: #717072; 
	padding: 5px;
	margin: 0;
	font-family: arial;
    font-size: 11px;
}

.resetpwd_header{
    border-bottom: 1px solid #D7D9DA;
    color: #0070BD;
	font-family: trebuchet ms;
    font-size: 28px;
    margin-bottom: auto;
    margin-left: 4%;
    margin-right: 4%;
    margin-top: 1px;
    padding-bottom: 5px;
    padding-left: 0;
    padding-right: 5px;
    padding-top: 18px;
    width: 495px;
}

.content-inner{
	min-height: 435px;
}

#loginWrapper {
    background: none;
    height: 275px;
}

#container{
	background: none repeat scroll 0 0 white;
    border: 2px solid #FFFFFF;
    border-radius: 10px 10px 10px 10px;
    height: auto;
    margin: 5% auto;
    min-height: 220px;
    width: 845px;
    font-size: 13px; 
}
#container td{
	font-size: 13px;
}
#loginContainer #loginWrapper #container table{
	margin: 50px 11% auto;
    width: 78%;
}
input[type="button"]{
	margin-left:179px;    
}
    
input[type="text"]{
	width:150px;    
}
label.error {
	font-family: arial;
	color:red;
}
.invalid {
	background:url(<?php echo base_url()?>images/invalid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#ec3f41;
}
.valid {
	background:url(<?php echo base_url()?>images/valid.png) no-repeat 0 50%;
	padding-left:22px;
	line-height:24px;
	color:#3a7d34;
}
#match_fail{
	color: red;
	text-align: right;
	font-size: 0.8em; 
	margin: 0;
	padding: 0;
	margin-top: 5px;
	margin-bottom: 5px;
	display: none;
}
#loginContainer{
	width: 100%;
}
input[type="password"], input[type="text"]{
	width: 185px;
}
</style>

	<div>
			<div id="loginContainer">
				<div id="loginWrapper">
			
						<div id="container">
							<div class='masBox'>
			
							</div>
							<div style="width: 49%; min-height: 200px;float: left;display: inline;">
							
							<form action="<?php echo base_url()?>login/update_password" name="reset1Password" method="post" id="resettPasswordForm">
									<input type="hidden" name='user_id' value="<?php echo $userId ?>"></input>
									<input type="hidden" name='new_password_key' value="<?php echo $newPassKey ?>"></input>
									
									<table cellspacing="5px">
										<tr>
											<td>
												New Password
											</td>
											<td>
												<input type="password" name='password' value="" class="required" id='password' onkeyup="hide()"></input>
												
											</td>
										</tr>
										<tr>
											<td></td>
											<td><div id="errorBox"></div></td>
										</tr>
										<tr>
											<td>
												Confirm Password
											</td>
											<td>
												<input type="password" name='confPassword' value="" class="required" id="confPassword"></input>
											</td>
										</tr>
										<tr>
											<td></td>
											<td><div id="errorBox"></div></td>
										</tr>
										<tr>
											<td>
												Password Strength
											</td>
											<td>
												<span id="passstrength"></span>
											</td>
										</tr>
										
										<tr>
											<td colspan="2">
												<p id="match_fail">Passwords do not match!!</p>
												<input type="button" value="Reset" id="form_submit" onclick="resetPassword()" disabled="disabled"></input>
											</td>
											
										</tr>
									</table>
									
									<label>
									
									
									</label>
								
								
								</form>
							
							</div>
							<div style="width: 49%; min-height: 200px;float: left;display: inline;">
								<div class="ui-grid-solo" id="login_form_wrapper">
					      			<h4>Password must meet the following requirements:</h4>
						            <ul style="padding: 0; margin: 0; list-style: none;">
										<li id="letter" class="invalid">At least <strong>one small letter</strong></li>
										<li id="capital" class="invalid">At least <strong>one capital letter</strong></li>
										<li id="number" class="invalid">At least <strong>one number</strong></li>
										<li id="symbol" class="invalid">At least <strong>one symbol</strong></li>
										<li id="length" class="invalid">Be at least <strong>8 characters</strong></li>
									</ul>
					      		</div>
							</div>
							
						
						</div>
			
					
				</div>
			</div>
	</div>
	
	<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<script src="<?php echo base_url();?>js/jquery/jquery.validate1.9.min.js"></script>
	
	<script>
	$(document).ready(function() {
		$('#form_submit').prop('disabled',true); 
		//you have to use keyup, because keydown will not catch the currently entered value
		$('#password').keyup(function() { 
		
			var count = 0;
			// set password variable
			var pswd = $(this).val();
			
			//validate the length
			if ( pswd.length < 8 ) {
				$('#length').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			} else {
				$('#length').removeClass('invalid').addClass('valid');
				count = count+1;
			}
			
			//validate letter
			if ( pswd.match(/[a-z]/) ) {
				$('#letter').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#letter').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true);
			}
			
			//validate uppercase letter
			if ( pswd.match(/[A-Z]/) ) {
				$('#capital').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#capital').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true);
			}
			
			//validate number
			if ( pswd.match(/\d/) ) {
				$('#number').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#number').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true); 
			}

			//validate symbol
			if ( pswd.match(/[-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/) ) {
				$('#symbol').removeClass('invalid').addClass('valid');
				count = count+1;
			} else {
				$('#symbol').removeClass('valid').addClass('invalid');
				$('#form_submit').prop('disabled',true);
			}
			if(count == 5){
				$('#passstrength').css('color','green');
				$('#passstrength').text('Strong!!');
				$('#form_submit').prop('disabled',false);
			}else{
				$('#passstrength').css('color','red');
				$('#passstrength').text('Weak!!');
				$('#form_submit').prop('disabled',true);
			}
		});

		$("#form_submit").click(function(){
			var password = $('#password').val();
			var confPassword = $('#confPassword').val();
			if(password == confPassword){
				$("#resettPasswordForm").submit();
			}else{
				$('#match_fail').show();
			}
		});
	});
</script>






