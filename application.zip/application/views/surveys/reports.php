<?php 
$x=2;
$clientId = $this->session->userdata('client_id');
//if($clientId==INTERNAL_CLIENT_ID){
$userId	=$this->session->userdata('user_id');
$email	= $this->session->userdata('email');
if($showReports){

// prepare array of JS files to insert into queue
$queued_js_scripts =array('surveys/reports',
        
		'chosen.jquery',
		'highcharts2_2_2/highcharts3.0.5',
		'highcharts2_2_2/modules/exporting3.0.5',
		'i18n/grid.locale-en',
		'jquery.jqGrid.min',
		'jquery/jquery.validate1.9.min'
);
// add the JS files into queue i.e Append to the existing queue
$prevjs = $this->config->item('js_files_to_load');
if($prevjs == null)
	$prevjs = array();
$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<script src="<?php echo base_url();?>c3js/d3.v3.min.js"></script>
<script src="<?php echo base_url();?>c3js/c3.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>c3js/c3.min.css" />
 <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPwPj8G34QTdXihJzvRY4UJN2piezVAFY">
    </script>
<style>
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.tabsWrapper div.tabsContent{
		min-height: 630px;
	}
	#summaryTabContainer #counts{
		border: 0px !important;
	}
	.gridWrapper .ui-jqgrid tr.jqgrow td div.microViewIcon{
		background-position: 3px 2px;
	    height: 25px !important;
	    width: 25px;
	}
	#searchResultsContainer table td,#searchResultsContainer table th{
		padding: 0px !important;
	}
	#filtersApplied{
		margin-bottom: 5px;
	}
	#subChartContainer1, #subChartContainer2{
		    display: flex;
    width: 600px;
    margin: 0 auto;
	}
	#subChartContainer1{
		border-right: 0px solid #ddd !important;
	}
	#subChartContainer2{
		border-top: 1px solid #ddd;
		 margin-top: 6px;
	}
	#imageContenet{
	float:left;
}
	#mapsContent{
		float: left;
	}
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:13px;
	}
	#kolImage{
		vertical-align: bottom;
	}
	
	#surveyMap{
		position:relative; 
		width:805px; 
		height:450px;
	}
	.Infobox{
		width:356px !important;	
	}
	.MapPushpinBase img{

	 margin-top: 31px;
	 margin-left: 8px;
	}
	
	.kolInfo{
		min-height:46px;
		margin-top:-6px;
	}
	
	.Infobox{
		height: 82px !important;
	    top: 59px !important;
	    width: 239px !important;
	}
	.infobox-stalk{
		height:30px !important;
		top: 82px !important;
	}
	
	#imageContenet{
	float:left;
	margin-right: 4px;
	margin-top:3px;
	}
	
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:11px;
		
	}
	#tooltip-survey-select{
		/*left: 290px;
    	position: absolute;
    	top: 9px;*/
    	display: inline-block;
	    position: relative;
	    vertical-align: super;
	}
	#tooltip-report-type{
		/*position: absolute;
    	right: 77px;
    	top: 9px;*/
    	display: inline-block;
	    position: relative;
	    vertical-align: super;
	}
	#tooltip-apply-filters{
		position: absolute;
    	right: 33px;
    	top: 78px;
	}
	#tooltip-recent-query {
	    display: inline-block;
	    left: 1px;
	    position: relative;
	    top: 5px;
	}
	.NavBar_modeSelectorControlContainer{
		display: none;
	}
	.NavBar_compassControlContainer{
		display: none;
	}
	.NavBar_zoomControlContainer .NavBar_zoomDrop{
		display: none;
	}
	.NavBar_zoomControlContainer{
		background: none repeat scroll 0 0 #FAF7F5;
	    height: 30px;
	    left: 5px;
	    position: absolute;
	    top: 351px;
	    transform: rotate(270deg);
	    width: 52px;
	}
	.MicrosoftMap .OverlaysBR-logoAware{
		display: none;
	}
	#surveyMap{
		border: 1px solid #000080;
	}
	.disableNavigation{
		opacity: 0.30;
		-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)"; /* IE 8 */
		filter: alpha(opacity=30); /* older IEs */
		margin: 2px 3px 2px 2px;
	}
	.NavBar_zoomControlContainer .NavBar_zoomIn{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg); 
	}
	.NavBar_zoomControlContainer .NavBar_zoomOut{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg);
	}
	#indivisual-influence {
	    height: 450px;
	    width: 600px;
	}
	.filterSections{
		float: left;
	}
	
	#gridContainerOfInd .ui-jqgrid-htable tr th {
    width: !0 important;
	}
	.profileNameParent{
		margin:0;
		text-align:left;
	}
	.detailedInfo{
	margin:0;
	text-align:left;
	}
	.contentInfo{	
		 margin-left: 8px;
    margin-right: 6px;
	}
	div.tooltipMap {   
		position: absolute;           
		text-align: center;           
		width: auto;                  
		height: auto;                 
		padding: 2px;             
		font: 12px sans-serif;        
		background: lightsteelblue;   
		border: 1px solid green;     
		border-radius: 8px;           
		pointer-events: none;         
	}
	 .legend .legdisable{
        	color: #fff !important;
            opacity: 0.2;
        }
       	 .legend {
		      max-height: 225px;
		      max-width: 150px;        
		      overflow-y: scroll;
		      margin-top: 60px !important;
		      overflow-y: scroll;
		      position: absolute;
		      right: 0;
		      top: 0;
		  }
		  .legend h5{  
		      margin-bottom: 1px;
		      cursor: pointer;
		      font-family: "Droid Sans",Segoe UI,tahoma,arial,Trebuchet Ms !important;
		      color: #333 !important;
		      font-size: 13px;
		      padding: 0 2px;
		      font-weight:normal;
		      margin-top: 0px;
		  }
		  .legend .legdisable{
	        	color: #fff !important;
	            opacity: 0.2;
	        }
</style>
<script type="text/javascript">
var mobile_base_url = '<?php echo base_url().MOBILE_URL_SEGMENT;?>/';
jqgridIds	= new Array('listSurveyReportsResultSet','listSurveysResultSet');
var jqgridMaxWidth	= 1192;
var jqgridMinWidth	= 885;
var agent ='';
<?php 
	 $mobile = mobile_device_detect();
	 if(isset($mobile[1])){?>
	  	agent ='<?php echo $mobile[1]?>';
	 <?php }?>
var surveyId	= '<?php echo $filterData['arrSurveys'][0]['id'];?>';
$(document).ready(function(){
	//jAlert("<div style='border-bottom: 1px solid #1b1b1b;text-align:center;'>Disclaimer</div><div style='text-align:left;'> NOTICE: Data shown in the iMap tool are for internal Otsuka use only and are not to be shared outside of Otsuka. The data in this tool may be used for promotional speaker program development. This tool is not intended for call plan development; healthcare professionals appearing in this tool may not be on your call plan and may not be appropriate for call activity based on the product you promote. Existing call plan development and targeting policies and procedures must be followed at all times. Off-label promotion is prohibited.</div>");
	$('.tabsWrapper ul.tabsContainer li').click(function (){
		var currentTab	= $(this).attr('name');
		$('.tabsWrapper ul.tabsContainer li').removeClass('current');
		$('.tabsWrapper .tabsContent div.tabContent').hide();
		$(this).addClass('current');
		$('.tabsWrapper .tabsContent div.'+currentTab).show();
		load_selected_tab(currentTab);
	});
	load_selected_tab('summaryTab');
	displaySelectedFilters();
});

</script>
<div id="container">
	<div id="surveyReports">
		<div id="searchResultsContainer" class="maxWidth"  style="float:left;">
			<div class="tabsWrapper">
				<ul class="tabsContainer">
					<li class="current" name="summaryTab"><a id="summary" href="#">Summary</a></li>
					<li name="topInfluencersTab"><a id="topInfluencers" href="#">Top Influencers</a></li>
					<!--  <li name="reportsTab"><a id="reports" href="#">Influencers</a></li>-->
					<li name="influencersNetworkMapTab"><a id="influencersNetworkMap" href="#"><?php echo lang('Surveys.InfluenceMap');?></a></li>
					<li name="influencersGeoMapTab"><a id="influencersGeoMap" href="#"><?php echo lang('Surveys.InfluenceGeoMap');?></a></li>
					<li name="individualMap"><a id="ifluencerMap" href="#">Influencer Table</a></li>
				</ul>
				<div class="tabsContent">
					<div id="filtersApplied" class="tooltip-demo tooltop-bottom">
						<span class="filterSections"></span>
						<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a data-original-title="Reset Filters" href="#" class="tooltipLink" rel="tooltip">&nbsp;</a></label></div>
					</div>
					<div class="summaryTab tabContent" style="display:block;">
						<div id="summaryTabContainer">
							<table id="counts"><caption>Summary Details</caption>
								<tr>
									<th>
										<div class="tooltip-demo tooltop-right surveyRespondent sprite_iconSet">
											<a href="#" class="tooltipLink" rel="tooltip" title="The person who has given the response to the questions nominated their peers as influential people.A respondent is influenced by the Influencer">&nbsp;</a>
										</div>
										<a href="#" onclick="loadSummeryDetails('respondents');return false;"><span id="respondentsCount"></span> Respondents</a>
									</th>
									<th>
										<div class="tooltip-demo tooltop-right surveyInfluencer sprite_iconSet">
											<a href="#" class="tooltipLink" rel="tooltip" title="Influencers are people who have been nominated by the respondents. A respondent is influenced by the Influencer">&nbsp;</a>
										</div>
										<a href="#" onclick="loadSummeryDetails('influencers');return false;"><span id="influencersCount"></span> Influencers</a>
									</th>
									<th>
										<div class="tooltip-demo tooltop-right userIcon sprite_iconSet">
											<a href="#" class="tooltipLink" rel="tooltip" title="These are users/employees who filled the response on behalf of the respondent">&nbsp;</a>
										</div>
										<a href="#" onclick="loadSummeryDetails('users');return false;"><span id="usersCount"></span> Users</a>
									</th>
								</tr>
							</table>
							<div>
								<div id="summaryChartContainer">
									<div id="subChartContainer1"></div>
									<div id="subChartContainer2"></div>
									   <div class="gridWrapper" id="allAfiliationGridContainer">
										<div id="listSurveysPage1"></div><table id="JQBlistAllResultSet"></table>
										</div>
								</div>
								<div id="summaryGridContainer" style="display:none;">
									<input type="button" onclick="backtocharts();" value="Charts" />
									<div class="gridWrapper" id="gridContainer">
										<div id="listSurveysPage"></div><table id="listSurveysResultSet"></table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="topInfluencersTab tabContent">
						<div id="topInfluencersTabContainer">
							<div id="chartContainer"></div>
						</div>
					</div>
					<div class="reportsTab tabContent">
						<div id="reportsTabContainer">
							
						</div>
					</div>
					<div class="influencersNetworkMapTab tabContent">
						<div id="influencersNetworkMapTabContainer">
							<?php $this->load->view('surveys/network_map_element');?>
						</div>
					</div>
					<div class="influencersGeoMapTab tabContent">
						<div id="influencersGeoMapTabContainer">
							<div id="surveyMapsContent" class="span-20 last" >			
								<div id='surveyMap' style=""></div>
							</div>
						</div>
					</div>
					<div class="individualMap tabContent">
						<div id="individualMapTabContainer">
							<?php $this->load->view('surveys/influencer_report');?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="dailog2">
	<!-- Container for the 'Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		</div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
<div id="addNewKol" class="microProfileDialogBox">
	<div class="addNewKolContent profileContent"></div>
	
</div>
<div id="addNewOrg" class="microProfileDialogBox">
	<div class="addNewOrgProfileContent profileContent"></div>
</div>
<div id="addNewRespo" class="microProfileDialogBox">
	<div class="addNewRespoContent profileContent"></div>
	<div id="gridContainerOfIndRes" class="gridWrapper" ></div>
</div>

<form action="<?php echo base_url()?>surveys/excel_export" method="post" id="exportSurveyDetails">
	<input type="hidden" value="" name="exportIds" id="exportIds" />
	<input type="hidden" value="" name="filters" id="filters" />
	<input type="hidden" value="" name="type" id="type" />
	<input type="hidden" value="" name="rowName" id="rowName" />
</form>

<?php }else{?>

<script>
alert("Feature Coming Soon");
</script>

<?php }?>