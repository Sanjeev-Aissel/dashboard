<?php
/**
* Description: Lists and Manages all Titles and Client Associations
* Created by : Kishan Ravindra
* Created on : July 25, 2017
*/
?>
<script type="text/javascript" >
	var arrayClientIds = new Array();

	//Stack to store associated client ids
	function updateClientIds(thisPtr){
		arrayClientIds = [];
		$("input:checkbox[name="+thisPtr.name+"]:checked").each(function(){
			arrayClientIds.push($(this).val());
		});
		arrayClientIds = $.unique(arrayClientIds).sort();
		activateSave();
	}

	// On complete loading of document, loading the grid
	$(document).ready(function(){
		load_titles_grid();
		jQuery('#gs_title').focus();
	});

	// Function to load Titles grid
	function load_titles_grid(){
		$('#gridTitleListing').html('');
		$('#gridTitleListing').html('<div class="gridWrapper"><div id="gridTitleListingPagintaion"></div><table id="gridTitleListingResultSet"></table><div>');
		grid = $("#gridTitleListingResultSet"),
		grid.jqGrid({
			url:'<?php echo base_url();?>master_data_controller/list_titles',
			datatype: "json",
			colNames:['Id','Title','Abbrevation','Client ID', 'Status','Actions'],
		   	colModel:[
				{name:'id', index:'id', hidden:true, search:false},
				{name:'title', index:'title', search:true, firstsortorder:'asc'},
		   		{name:'abbr', index:'abbr', search:true},
		   		{name:'client_id', index:'client_id', hidden:true, search:true},
				{name:'is_active', index:'is_active', search:false, formatter: function (cellvalue, options, rowObject) {
					var arrStatus = ["Inactive","Active"];
	   				return arrStatus[cellvalue];
	   			}},
				{name:'action', index:'action', align:'center', search:false, resizable:false, width:25}
		   	],
			rowNum:10,
			multiselect: true,
			rownumbers: true,
			autowidth: true,
			loadonce:false,
			ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#gridTitleListingPagintaion',
		   	mtype: "POST",
		   	sortname: 'title',
		    viewrecords: true,
		    sortorder: "asc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Titles",
		    rowList:paginationValues
		});
		grid.jqGrid('navGrid','#gridTitleListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
		grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
		grid.jqGrid('navButtonAdd',"#gridTitleListingPagintaion",{caption:"Add Title", buttonicon:"ui-icon-plus", title:"Add New Title", onClickButton: function(){addTitle();}});
		grid.jqGrid('navButtonAdd',"#gridTitleListingPagintaion",{caption:"Search",	buttonicon:"ui-icon-search", title:"Toggle Search",
			onClickButton: function(){
				jQuery(".ui-search-toolbar").css("display",jQuery(".ui-search-toolbar").css("display") != "none" ? "none" : "");
				jQuery('#gs_title').focus();
			}
		});
	}
	
	//Prepare Dialogue box layout
	function getModalLayout(headerTitle){
		var modalBoxLayout = {
			title: headerTitle,
			modal: true,
 			width: 360,
			position: ['center', 90],
			resizable: false,
		}
		return modalBoxLayout;
	};

	//Function to Transform cases to upper
	function transformCase(thisPtr,toCase){
		switch(toCase.toUpperCase()){
		case "UPPER":
			thisPtr.value = thisPtr.value.toUpperCase();
			break;
		case "LOWER":
			thisPtr.value = thisPtr.value.toLowerCase();
			break;
		case "UCWORDS":
			thisPtr.value = thisPtr.value.toLowerCase().replace(/\b[a-z]/g, function(letter) { return letter.toUpperCase(); });
			break;
		}
		activateSave();
		return;
	}

	//Function to Activate Save Button
	function activateSave(){
		$('#infoMsg').html("");
		$('#saveBtn').attr("disabled",false);
	}

	//Function to Deactivate Save Button
	function deactivateSave(){
		$('#saveBtn').attr("disabled",true);
	}

	//Function to Activate / Deactivate Delete Button
	function confirmDel(thisPtr){
		if(thisPtr.checked){
			$('#delBtn').attr("disabled",false);
		} else {
			$('#delBtn').attr("disabled",true);
		}
		return;
	}

	//AJAX function to Handle CRUD
	function smartCRUD(clientData, handlerUrl){
		$("#loadingStates").show();
		var respObj = false;
		$.ajax({
			url: handlerUrl,
			data: clientData,
			async:false,
			type:'POST',
			success: function(serverResp){
				respObj = serverResp;
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});
		return respObj;
	}

	//Function to get Title Details for id passed as a param
	function getClientIds(titleId){
		url = '<?php echo base_url()?>master_data_controller/getClientIdsToAJAX';
		data = "titleId="+titleId;
		var response = smartCRUD(data,url);
		return response.toString();
	}

	//Function to get Title Details for id passed as a param
	function getTitleDetailsByID(id){
		url = '<?php echo base_url()?>master_data_controller/get_title_by_id';
		data = "id="+id;
		var respJSON = smartCRUD(data,url);
		return JSON.parse(respJSON);
	}

	//Function to get Client Details (if 'id' matches : matched records, else : all records)
	function getClientDetails(id){
		url = '<?php echo base_url()?>master_data_controller/getClientDetails';
		data = "id="+id;
		var response = smartCRUD(data,url);
		return JSON.parse(response);
	}
	
	//Function to open Add form
	function addTitle(){
		openDialog(0);
		$('#id').val('');
		$('#title').val('');
		$('#abbrevation').val('');
		$('#status').val('1');
		arrayClientIds = [];
		$.each(getClientDetails(null), function(key, value) {
			$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
		})
		activateSave();
		return;
	}

	//Function to open Edit form
	function editTitle(id){
		var response = getTitleDetailsByID(id)["0"];
		if(!response){
			console.log("Server Not Responding : Titles cannot be pulled");
			return;
		}
		var clientsIds = getClientIds(id);
		arrayClientIds = [];
		if(clientsIds){
			var existing = clientsIds.split(',');
			for(i=0;i<existing.length;i++){
				arrayClientIds.push(existing[i]);
			}
		}
		openDialog(1);
		$('#id').val(response.id);
		$('#title').val(response.title);
		$('#abbrevation').val(response.abbr);
		$('#status').val(response.is_active);
		var isChecked = '';
		$.each(getClientDetails(null), function(key, value) {
			isChecked = arrayClientIds.indexOf(value.id) >= 0 ? "checked" : "";
			$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+" "+isChecked+">"+value.name+"</label>");
		})
		return;
	}

	/*  Function to open Delete Confirmation Dialog
	 *	id - Record id to be deleted
	 *	isAction : TRUE / FALSE => Submit the record to delete / Just open the confirmation	 */
	function deleteTitle(id,isAction){
		if(!isAction){
			var response = getTitleDetailsByID(id)["0"];
			if(!response){
				$('#manageTitleContent').html("Server Error : Not Responding");
				return;
			}
			openDialog(2);
			$('#id').val(response.id);
			$('#title').html(response.title);
			$('#abbrevation').html(response.abbr);
			$('#status').html(response.is_active == 1 ? "Active" : "Inactive");
			return;
		}
		var data = "id="+$('#id').val().trim();
		var url = '<?php echo base_url()?>master_data_controller/deleteTitle';
		var respMsg = smartCRUD(data, url);
		$('#manageTitleContent').html(respMsg+"<br><br>Please Wait...");
		setTimeout(function(){closeTitleDialog();},2000);
		load_titles_grid();
	}

	// Function to Save the Title Details
	function saveTitle(){
		var id = $('#id').val().trim();
		var title = $('#title').val().trim();
		var abbrevation = $('#abbrevation').val().trim();
		var status = $('#status').val();
		if(title == ""){
			$('#title').focus();
			return;
		}
		if(abbrevation == ""){
			$('#abbrevation').focus();
			return;
		}
		var data = "id="+id+"&title="+title+"&abbrevation="+abbrevation.toUpperCase()+"&status="+status+"&clientIds="+arrayClientIds.toString();
		var url = '<?php echo base_url()?>master_data_controller/smartMergeTitle';
		var respMsg = smartCRUD(data, url);
		if(id == ''){
			$('#title').val('');
			$('#abbrevation').val('');
			$('#status').val('1');
			$('#multiClientIds').html("");
			arrayClientIds = [];
			$.each(getClientDetails(null), function(key, value) {
				$('#multiClientIds').append("<label><input type='checkbox' name='selectedClients' onclick='updateClientIds(this)' value="+value.id+"/>"+value.name+"</label>");
			})
		}
		deactivateSave();
		$('#infoMsg').html(respMsg);
		load_titles_grid();
	}

	//Function to prepare Add / Edit / Delete Dialogs
	function openDialog(dialogID){
		//Add / Edit Title Template
		var addTitleTemplate = "<input type='hidden' id='id' readonly>"+
		"<table style='width:100%'>"+
		"<tr>"+
			"<td><label>Title </label></td>"+
			"<td><input type='text' size='40' id='title' onkeyup=transformCase(this,'UCWORDS'); placeholder='Title'></td>"+
		"</tr>"+
		"<tr>"+
			"<td><label>Abbrevation </label></td>"+
			"<td><input type='text' size='40' id='abbrevation' onkeyup=transformCase(this,'UPPER'); placeholder='Abbrevation'></td>"+
		"</tr>"+

		"<tr><td><label>Clients</label></td><td><div class='multiselect' id='multiClientIds'></div></td>"+
		"<tr>"+
			"<td><label>Status </label></td>"+
			"<td><select id='status' onchange='activateSave();'>"+
				"<option value='1'>Active</option>"+
				"<option value='0'>Inactive</option>"+
			"</select>"+
			"&nbsp;&nbsp;&nbsp;<input type='button' id='saveBtn' value='Save' onclick='saveTitle();' disabled>"+
			"&nbsp;&nbsp;<input type='button' value='Close' onclick='closeTitleDialog();'></td>"+
		"</tr></table><span id='infoMsg'></span>";
		//End of Add / Edit Title Template
		//Delete Title Template
		var deleteTitleTemplate = "<input type='hidden' id='id' readonly>"+
		"<table style='width:100%'>"+
		"<tr colspan='2'>"+
			"<td><label>Title : </label><span id='title'></span> ( <span id='abbrevation'></span> )</td>"+
		"</tr>"+
		"<tr colspan='2'>"+
			"<td><label>Status : </label><span id='status'></span></td>"+
		"</tr>"+
		"<tr colspan='2'>"+
			"<td style='text-align:right;'><input type='checkbox' onchange='confirmDel(this);'> I Confirm"+
			"&nbsp;&nbsp;<input type='button' id='delBtn' value='Delete' onclick='deleteTitle(null,true);' disabled>"+
			"&nbsp;&nbsp;<input type='button' value='Cancel' onclick='closeTitleDialog();'></td>"+
		"</tr></table><span id='infoMsg'></span>";
		//Delete Title Template
		var arrDialogTitles = ["Add Title","Edit Title","Delete Title"];
		var arrDialogTemplates = [addTitleTemplate, addTitleTemplate, deleteTitleTemplate];
		$('#manageTitleContent').html(arrDialogTemplates[dialogID]);
		$('#manageTitleContainer').dialog(getModalLayout(arrDialogTitles[dialogID]));
	}

	//Function to close the Dialog
	function closeTitleDialog(){
		$('#manageTitleContainer').dialog("close");
	}
	
</script>
<style type="text/css">
	.ui-jqgrid .ui-jqgrid-btable{
		table-layout:auto;
	}
	.ui-jqgrid .ui-jqgrid-htable{
		table-layout:auto;
	}
	.multiselect {
		width:22.2em;
		height:6em;
    	border:solid 1px #c0c0c0;
    	overflow:auto;
    }
    .multiselect label {
    	display:block;
    }
</style>
	<p align="right">
		<a href='javascript:addTitle();' style='text-decoration: none;'>
			<img src="http://localhost/kolm_pfizer/images/bullet_add.png" border="0" style="height: 30px; vertical-align: middle;"> Add New Title
		</a>
	</p>
	<!-- Container for the 'Title Listing' -->
	<div id="gridTitleListing">
		<div class="gridWrapper">
			<div id="gridTitleListingPagintaion"></div>
			<table id="gridTitleListingResultSet"></table>
		</div>
	</div>
	<!-- End of Container for the 'Title Listing' -->
	
	<!-- Container for the modal box -->
	<div id="manageTitleContainer">	
		<span id="manageTitleContent"></span>
	</div>
	<!-- End of Container for the modal box' -->