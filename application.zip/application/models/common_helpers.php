<?php

/**
 * File To hold all the common functions that are not helfull for conversions or code refractoring
 *
 * @package application.models
 * @author Ramesh B
 * @since
 * @created on 
 */
class Common_helpers extends Model {

    function __construct() {
        parent::Model();
    }

    function genSearchResMsgs($startFrom, $perPage, $count, $anyMsg) {

        $searchMsgs = array();
        $msgText = "";
        
      // echo 'Start from'.$startFrom.'<br/>Per page'.$perPage.'<br/>Count'.$count;
       
        if (($startFrom + $perPage) < $count){
            $searchMsgs['countMsg'] = "Showing " . ($startFrom + 1) . " to " . ($startFrom + $perPage) . " of " . $count;
        }else{
            $searchMsgs['countMsg'] = "Showing " . ($startFrom + 1) . " to " . ($count) . " of " . $count;
        }
        
        //$searchMsgs['countMsg'] = "Showing " . ($startFrom + 1) . " to " . ($count) . " of " . $count;
        if (is_array($anyMsg) && sizeof($anyMsg) > 0) {
            if (!is_array($anyMsg) && $anyMsg != '') {
                $msgText = " '" . $anyMsg . "'";
            }
            foreach ($anyMsg as $key => $value) {
                if (!is_array($value) && $value != '') {
                    $msgText = $msgText . " '" . $value . "',";
                    //break;
                }
            }
        } else
            $msgText = "'" . $anyMsg . "'";

        $searchMsgs['resFor'] = "Search results for " . $msgText;

        if (substr($searchMsgs['resFor'], -1) == ',') {

            $searchMsgs['resFor'] = substr($searchMsgs['resFor'], 0, -1);
        }
        return $searchMsgs;
    }

    function getTotalSearchResMsg($startFrom, $perPage, $count, $anyMsg, $for = 'KTLs') {
		
        $searchMsgs = array();
        $msgText = "";
        $searchMsgs['countMsg'] = $count . " " . $for . " Found";

        if (is_array($anyMsg) && sizeof($anyMsg) > 0) {
            if (!is_array($anyMsg) && $anyMsg != '') {
                $msgText = " '" . $anyMsg . "'";
            }
            foreach ($anyMsg as $key => $value) {
                if (!is_array($value) && $value != '') {
                    $msgText = $msgText . " '" . $value . "',";
                    //break;
                }
            }
        } else
            $msgText = "'" . $anyMsg . "'";

        $searchMsgs['resFor'] = "Search results for " . $msgText;

        if (substr($searchMsgs['resFor'], -1) == ',') {

            $searchMsgs['resFor'] = substr($searchMsgs['resFor'], 0, -1);
        }
        return $searchMsgs;
    }

    /** Date function to convert the date from php format to mysql.
     *
     * @author Ambarish
     * @since 1.4.5
     * @Created-on 02-03-11
     *
     * @param date $inputDate Input date (format - MM/DD/YYYY)
     * @return date  Output date (format - YYYY-MM-DD).
     */
    function convertDateToYYYY_MM_DD($inputDate) {

        $mmDate = substr($inputDate, 0, 2);
        $ddDate = substr($inputDate, 3, 2);
        $yyDate = substr($inputDate, 6, 4);
        return ($yyDate . '-' . $mmDate . '-' . $ddDate);
    }

    /**
     * Date function to convert from mysql format to php.
     *
     * @author Ambarish
     * @since 1.4.5
     * @Created-on 02-03-11
     *
     * @param date $inputDate Input date (format - YYYY-MM-DD)
     * @param string $delimeter Delimeter you want afetr converted
     * @return date  Output date (format - MM/DD/YYYY).
     */
    function convertDateToMM_DD_YYYY($inputDate, $delimiter = '/') {

        $ddDate = substr($inputDate, 8, 2);
        $mmDate = substr($inputDate, 5, 2);
        $yyDate = substr($inputDate, 0, 4);
        return ($mmDate . $delimiter . $ddDate . $delimiter . $yyDate);
    }

    /**
     * Constructs the Comma separated elements for given array of elements 
     * @author 	Ramesh B
     * @Created on: 08-03-11
     * @since	1.5.1
     * @return Array
     */
    function convertArrayToCommaSeparatedElements($arrElements) {
        $commaSeparatedElements = "";
        if (sizeof($arrElements) > 0) {
            foreach ($arrElements as $element)
                $commaSeparatedElements.=$element . ",";
            $commaSeparatedElements = substr($commaSeparatedElements, 0, -1);
        }
        return $commaSeparatedElements;
    }

    function js_to_php_time($jsdate) {
        if (preg_match('@(\d+)/(\d+)/(\d+)\s+(\d+):(\d+)@', $jsdate, $matches) == 1) {
            $ret = mktime($matches[4], $matches[5], 0, $matches[1], $matches[2], $matches[3]);
            //echo $matches[4] ."-". $matches[5] ."-". 0  ."-". $matches[1] ."-". $matches[2] ."-". $matches[3];
        } else if (preg_match('@(\d+)/(\d+)/(\d+)@', $jsdate, $matches) == 1) {
            $ret = mktime(0, 0, 0, $matches[1], $matches[2], $matches[3]);
            //echo 0 ."-". 0 ."-". 0 ."-". $matches[1] ."-". $matches[2] ."-". $matches[3];
        }
        return $ret;
    }

    function php_to_js_time($phpDate) {
        return date("m/d/Y H:i", $phpDate);
    }

    function php_to_my_sql_time($phpDate) {
        return date("Y-m-d H:i:s", $phpDate);
    }

    function my_sql_to_php_time($sqlDate) {
        $arr = date_parse($sqlDate);
        return mktime($arr["hour"], $arr["minute"], $arr["second"], $arr["month"], $arr["day"], $arr["year"]);
    }

    /**
     * Checks the logged in Client.If the logged in Client is not the INTERNAL_CLIENT(Aissel users),
     * Then redirects to Client application home page  
     * @author 	Ambarish N
     * @since	2.8
     * @created August-02-2011
     * @return unknown_type
     */
    function checkUsers() {
        if ($this->session->userdata('client_id') != INTERNAL_CLIENT_ID) {
            redirect('kols/client_index');
        }
    }

    /**
     * Given a month as 'MM-YYYY' converts it to 'YYYY-MM-01' that is first day of goven month 
     * @author 	Ramesh B
     * @since	3.1
     * @param $monthYear  - MM-YYYY
     * @return date 'YYYY-MM-01'
     * @created 19-09-2011
     */
    function MM_YYYY_To_YYYY_MM_MonthFirstDay($monthYear) {
        if (strpos($monthYear, '-') !== false)
            $dateDetails = explode("-", $monthYear);
        if (strpos($monthYear, '/') !== false)
            $dateDetails = explode("/", $monthYear);
        $requiredDate = $dateDetails[1] . "-" . $dateDetails[0] . "-01";
        return $requiredDate;
    }

    /**
     * Given a month as 'MM-YYYY' converts it to 'YYYY-MM-LastDayOfMonth' that is last day of goven month 
     * @author 	Ramesh B
     * @since	3.1
     * @param $monthYear  - MM-YYYY
     * @return date 'YYYY-MM-LastDayOfMonth'
     * @created 19-09-2011
     */
    function MM_YYYY_To_YYYY_MM_MonthLastDay($monthYear) {
        if (strpos($monthYear, '-') !== false)
            $dateDetails = explode("-", $monthYear);
        if (strpos($monthYear, '/') !== false)
            $dateDetails = explode("/", $monthYear);
        $lastDay = $this->getLastDayOfMonth($dateDetails[0], $dateDetails[1]);
        $requiredDate = $dateDetails[1] . "-" . $dateDetails[0] . "-" . $lastDay;
        return $requiredDate;
    }

    /**
     * Given a date as 'YYYY_MM_DD' converts it to month year standars as 'MM-YYYY'
     * @author 	Ramesh B
     * @since	3.1
     * @param $dateString  - YYYY_MM_DD
     * @return string 'MM-YYYY'
     * @created 19-09-2011
     */
    function YYYY_MM_DD_To_MM_YYYY($dateString) {
        $dateDetails = explode("-", $dateString);
        $requiredDate = $dateDetails[1] . "-" . $dateDetails[0];
        return $requiredDate;
    }

    /**
     * Rreturns the last day of given month and year
     * @author 	Ramesh B
     * @since	3.1
     * @param $monthInteger -'MM'
     * @param $year -'YYYY'
     * @return string 'MM-YYYY'
     * @created 19-09-2011
     */
    function getLastDayOfMonth($monthInteger, $year) {
        if ($monthInteger == 1 || $monthInteger == 3 || $monthInteger = 5 || $monthInteger == 7 || $monthInteger = 8 || $monthInteger == 10 || $monthInteger == 12)
            return 31;
        else if ($monthInteger == 4 || $monthInteger == 6 || $monthInteger == 9 || $monthInteger == 11)
            return 30;
        else if ($monthInteger == 2) {
            if ($year % 4 == 0)
                return 29;
            else
                return 28;
        } else
            return 0;
    }

    /**
     * Validates the given postal code and prepares a valid postal code format of 5 digits(XXXXX) or 10 digits(XXXXX-XXXX) or blank
     * @author 	Ramesh B
     * @since	3.1
     * @param $postalCode
     * @return string 
     * @created 19-09-2011
     */
    function formatPostalCode($postalCode) {
        //First check is the postal code contails the charecter '-', if yest split it and validate each part separately, construct a proper format and save
        if (stripos($postalCode, '-')) {
            $postalCodeDetails = explode("-", $postalCode);
            //check is it contains only 2 parts ore more, if more then reject it and save blank
            if (sizeof($postalCodeDetails) == 2) {
                $firstPart = $postalCodeDetails[0];
                $secondPart = $postalCodeDetails[1];
                //Validate first part--------------------
                //validate for size 5
                if (strlen($firstPart) <= 5) {
                    //validate for integer
                    if (is_numeric($firstPart)) {
                        //if the lenght of the first part is less then 5, then prepend those many '0' to make it 5 digit
                        if (strlen($firstPart) < 5) {
                            $i = 5 - strlen($firstPart);
                            for ($j = 1; $j <= $i; $j++)
                                $firstPart = '0' . $firstPart;
                        }
                    } else {
                        //First part contains charecters, it shoud be numeric
                        return '';
                    }
                } else {
                    //First Part Contains more the 5 charecters
                    return '';
                }

                //Validate second part-------------------
                //validate for size 4
                if (strlen($secondPart) == 4) {
                    //validate for integer
                    if (is_numeric($secondPart)) {
                        return $firstPart . '-' . $secondPart;
                    } else {
                        //Second part contains charecters, it shoud be numeric
                        return '';
                    }
                } else {
                    //Second Part Contains more the 4 charecters
                    return '';
                }
            } else {
                //contains more than 2 parts
                return '';
            }
        }
        //If not, validate for charecters, and 5 digit, construct a proper format and save
        else {
            //Validate for numeric
            if (is_numeric($postalCode)) {
                //validate for size 5
                if (strlen($postalCode) <= 5) {
                    //if the lenght of the given input is less then 5, then prepend those many '0' to make it 5 digit
                    if (strlen($postalCode) < 5) {
                        $i = 5 - strlen($postalCode);
                        for ($j = 1; $j <= $i; $j++)
                            $postalCode = '0' . $postalCode;
                    }
                    return $postalCode;
                } else if (strlen($postalCode) == 9) {
                    //if the total number of digits is 9 then split them in the format XXXXX-XXX
                    return substr($postalCode, 0, 5) . '-' . substr($postalCode, 5, 8);
                } else {
                    //number of charecters is inconsistent
                    return '';
                }
            } else {
                //Contains charecters
                return '';
            }
        }
    }

    /**
     * Returns the name of the month in complete or 3-char format
     * @author 	Ramesh B
     * @since	3.1
     * @param $monthInteger -'MM' or 'M'
     * @param $threeCharFormat
     * @return string 'MM-YYYY'
     * @created 19-09-2011
     */
    function getMonthName($monthInteger, $threeCharFormat = null) {
        if ($monthInteger == 1 || $monthInteger == 1) {
            if ($threeCharFormat == null)
                return 'January';
            else
                return 'Jan';
        }
        if ($monthInteger == 2 || $monthInteger == 2) {
            if ($threeCharFormat == null)
                return 'February';
            else
                return 'Feb';
        }
        if ($monthInteger == 3 || $monthInteger == 3) {
            if ($threeCharFormat == null)
                return 'March';
            else
                return 'Mar';
        }
        if ($monthInteger == 4 || $monthInteger == 4) {
            if ($threeCharFormat == null)
                return 'April';
            else
                return 'Apr';
        }
        if ($monthInteger == 5 || $monthInteger == 5) {
            if ($threeCharFormat == null)
                return 'May';
            else
                return 'May';
        }
        if ($monthInteger == 6 || $monthInteger == 6) {
            if ($threeCharFormat == null)
                return 'June';
            else
                return 'Jun';
        }
        if ($monthInteger == 7 || $monthInteger == 7) {
            if ($threeCharFormat == null)
                return 'July';
            else
                return 'Jul';
        }
        if ($monthInteger == 8 || $monthInteger == 8) {
            if ($threeCharFormat == null)
                return 'August';
            else
                return 'Aug';
        }
        if ($monthInteger == 9 || $monthInteger == 9) {
            if ($threeCharFormat == null)
                return 'September';
            else
                return 'Sep';
        }
        if ($monthInteger == 10) {
            if ($threeCharFormat == null)
                return 'October';
            else
                return 'Oct';
        }
        if ($monthInteger == 11) {
            if ($threeCharFormat == null)
                return 'November';
            else
                return 'Nov';
        }
        if ($monthInteger == 12) {
            if ($threeCharFormat == null)
                return 'December';
            else
                return 'Dec';
        }
    }

    /**
     * Converts the given 12 hour format time to 24 hour format time
     * @author 	Ramesh B
     * @since	3.2
     * @param $timeString -HH:MM AP/PM
     * @return Time String 'HH:MM'
     * @created 04-10-2011
     */
    function convert12HourTo24HoureFormat($timeString) {
        if ($timeString != '') {
            $amOrPM = substr($timeString, 6, 2);
            if ($amOrPM == 'AM' || $amOrPM = 'PM') {
                if ($amOrPM == 'PM') {
                    $givenHour = (int) substr($timeString, 0, 2);
                    $givenMinutes = substr($timeString, 3, 2);
                    $formatedHour = $givenHour + 12;
                    return $formatedHour . ':' . $givenMinutes . ':00';
                } else {
                    return substr($timeString, 0, 5);
                }
            } else
                return '00:00:00';
        } else
            return '00:00:00';
    }

    /**
     * Converts the given 12 hour format time to 24 hour format time
     * @author 	Ramesh B
     * @since	3.2
     * @param $timeString 'HH:MM'
     * @return Time String -'HH:MM AP/PM'
     * @created 04-10-2011
     */
    function convert24HourTo12HoureFormat($timeString) {
        if ($timeString != '') {
            $givenHour = (int) substr($timeString, 0, 2);
            $givenMinutes = (int) substr($timeString, 3, 2);
            if ($givenHour > 12) {
                $formatedHour = $givenHour - 12;
                if ($formatedHour <= 9)
                    $formatedHour = "0" . $formatedHour;
                if ($givenMinutes <= 9)
                    $givenMinutes = "0" . $givenMinutes;
                return $formatedHour . ':' . $givenMinutes . ' PM';
            } else
                return substr($timeString, 0, 5) . ' AM';
        } else
            return '';
    }

    /**
     * Function to red the all the document comments and funvtion names from the given file
     * @author 	Ramesh B
     * @since	3.6
     * @param File name
     * @return Array
     * @created 21-12-2011
     */
    function getDefinedFunctionsAndCommentsInFile($fileName, $dirPath) {

        $filePath = $dirPath . '/' . $fileName;
        $source = file_get_contents($filePath);
        $tokens = token_get_all($source);

        $arrFileSecations = explode(".", $fileName);
        $className = $arrFileSecations[0];

        $arrFunAndComments = array();
        $nextStringIsFunc = false;
        $inClass = false;
        $bracesCount = 0;
        $currFun = array();
        $i = 0;
        foreach ($tokens as $token) {
            //Match for 'doc comment' token		
            if ($token[0] == T_DOC_COMMENT) {
                //$currFun['comments']=$tokens[$i][1];
                $currFun['comments'] = $this->parseDocComment($tokens[$i][1]);
            }
            //Match for 'function' token
            if ($token[0] == T_FUNCTION) {
                $k = $i;
                //After the function token there will be space and then the function name, so incrimenting by 2 to get the function name
                $k = $k + 2;
                $currFun['fun_name'] = trim($tokens[$k][1]);
                $currFun['cls_name'] = $className;
                $arrFunAndComments[] = $currFun;
                $currFun = array();
            }
            $i++;
        }
        //pr($arrFunAndComments);
        return $arrFunAndComments;
    }

    /**
     * Parse the given doc comment string and prepare a array of doc tags and value
     * @author 	Ramesh B
     * @since	3.6
     * @param String comment
     * @return Array
     * @created 21-12-2011
     */
    function parseDocComment($commentString) {
        $arrComments = array();
        /*
         * Single comment block
         */
        $single_comment = $commentString;

        /*
         * Get each comment section - Ex: @function -> startComment
         */
        $comment_sections = explode("@", $single_comment);

        foreach ($comment_sections as $key => $value) {
            if ($key != 0) {

                /*
                 * Remove start and end comment tags
                 */
                $filtered_comment = str_replace('/*', '', $value);
                $filtered_comment = str_replace('*/', '', $filtered_comment);

                /*
                 * Break each section into key and value - Ex:key=function,value=startComment
                 */
                $section_key_value = explode(' ', $filtered_comment);
                $comment['tag_name'] = $section_key_value[0];
                unset($section_key_value[0]);
                $cValue = '';
                foreach ($section_key_value as $cString)
                    $cValue.=' ' . $cString;
                $cValue = str_replace('*', '', $cValue);
                $comment['tag_value'] = trim($cValue);
                //$arrComments[]=$comment;
                $arrComments[$comment['tag_name']] = $comment['tag_value'];
            }
        }

        return $arrComments;
    }

    //This function creates array with name combinations for each name in the array.
    function getNameCombinationArray($arrKols) {
        $arrNameCombinationKols = array();
        foreach ($arrKols as $kol) {
            if ($kol['status'] == COMPLETED) {
                $id = $kol['id'];
                $firstName = trim($kol['first_name']);
                $middleName = trim($kol['middle_name']);
                $lastName = trim($kol['last_name']);
                if ($middleName != '') {
                    $lnFnMn = $lastName . '' . $firstName . '' . $middleName;
                    $lnFnMi = $lastName . '' . $firstName . '' . substr($middleName, 0, 1);
                    $lnFiMn = $lastName . '' . substr($firstName, 0, 1) . '' . $middleName;
                    $laFiMi = $lastName . '' . substr($firstName, 0, 1) . '' . substr($middleName, 0, 1);
                    $laFi = $lastName . '' . substr($firstName, 0, 1);

                    $arrNameCombinationKols['kolfnmn-' . $id] = $lnFnMn;
                    $arrNameCombinationKols['kolfnmi-' . $id] = $lnFnMi;
                    $arrNameCombinationKols['kolfimi-' . $id] = $lnFiMn;
                    $arrNameCombinationKols['kolfimi-' . $id] = $laFiMi;
                    $arrNameCombinationKols['kolfi-' . $id] = $laFi;
                } else {
                    $lnFnMi = $lastName . '' . $firstName;
                    $lnFiMn = $lastName . '' . substr($firstName, 0, 1);
                    $arrNameCombinationKols['kolfn-' . $id] = $lnFnMi;
                    $arrNameCombinationKols['kolfi-' . $id] = $lnFiMn;
                }
            }
        }
        return $arrNameCombinationKols;
    }

    //This method will return the matching kolID for the given name, by searching in the given array of KOLs, if the given array itself is a array of name combinations then pass the 3rd parameter as true
    function getMatchingKolId($name, $arrKols, $isNameCombinations = false) {
        $kolId = 0;
        if (!$isNameCombinations)
            $arrNameCombinationKols = $this->getNameCombinationArray($arrKols);
        else
            $arrNameCombinationKols = $arrKols;
        $nameWithNoSpace = str_replace(" ", "", $name);
        $kolIdString = array_search($nameWithNoSpace, $arrNameCombinationKols);
        if ($kolIdString !== false) {
            $kolIdStringElements = explode("-", $kolIdString);
            $kolId = (int) $kolIdStringElements[1];
        }
        return $kolId;
    }

    function helpToolTip($text, $position, $helpLinkURL, $options = array()) {
        if (TOOLTIP_CONF == 1) {
            $helpLink = "<a class='help-link' href='" . getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email')) . "&redirect_to=/$helpLinkURL' target='_new'>View Additional Help</a>";
            echo "<span id='" . $options['id'] . "' class='map-info tooltop-$position'><a href='#' class='tooltipLink' rel='tooltip' title=\"<span class='tttext'>$text.$helpLink</span>\">&nbsp;</a></span>";
        } else
            echo "";
    }

    function get_name_format($first_name, $middle_name, $last_name) {
        $nameOrder = $this->session->userdata('name_order');
       // $nameOrder = 2;
        switch ($nameOrder) {
            case 1: return $first_name . " " . $last_name;
                break;
            case 2:
                if ($last_name == '')
                    return $first_name;
                else if ($middle_name == '')
                    return $last_name . ", " . $first_name;
                else
                    return $last_name . ", " . $first_name . " " . $middle_name;
                break;
            case 3: 
                if ($last_name == '')
                    return $first_name;
                else if ($middle_name == '')
                    return $first_name . " " . $last_name;
                else
                    return $first_name . " " . $middle_name . " " . $last_name;
                break;
            default :return $first_name . " " . $last_name;
        }
    }
    // to get format order to use in like query
    function get_name_format_order($wordsCount) {
        $nameOrder = $this->session->userdata('name_order');
       // $nameOrder = 2;          
        switch ($nameOrder) {
            case 3: 
                if($wordsCount==3)
                    return "first_name,' ',middle_name,' ',last_name";
                if($wordsCount==2)
                    return "first_name,' ',middle_name";
                if($wordsCount==1)
                    return "first_name";
                break;
            case 1:                                 
                if($wordsCount==3)
                    return "first_name,' ',last_name";
                if($wordsCount==2)
                    return "first_name,' ',last_name";
                if($wordsCount==1)
                    return "first_name";   
                break;
            case 2: 
                if($wordsCount==3)
                    return "last_name,' ',first_name";
                if($wordsCount==2)
                    return "last_name,' ',first_name";
                if($wordsCount==1)
                    return "last_name";   
                break;
        }
    }
    // to get format order with out word count, to use in like query
    function get_name_format_order_simple($table='') {
        $nameOrder = $this->session->userdata('name_order');
       // $nameOrder = 2;       
        switch ($nameOrder) {
            case 3:    
            	if(is_null($table.middle_name)){
                	return "$table.first_name,' ',$table.middle_name,' ', $table.last_name";
            	}else{
            		return "$table.first_name,' ',$table.last_name";
            	}
                break;
            case 1:                                 
               return "$table.first_name,' ',$table.last_name";
               break;
            case 2:
            	if(is_null($table.middle_name)){
               return "$table.last_name,', ',$table.first_name,' ',$table.middle_name";
            	}else{
            		return "$table.last_name,', ',$table.first_name";
            	}
               break;
        }
    }    
    function getOnlyYearByDate($date) {
        if ($date == '0000-00-00')
            return '';
        if ($date != '') {
            $str = $date;
            $time = strtotime($str);
            if ($time == 0) {
                return '';
            } else {
                $yyyy = date("Y", $time);
            }
            return $yyyy;
        } else {
            return $date;
        }
    }

    function isActionAllowed($section = '', $action = '', $options = array(),$kolDetails=array()) {
        $userGroupName = getGroupDetails();
        $group_names = explode(',',  $userGroupName['group_names']);
        $userId = $this->session->userdata('user_id');
        $clientId = $this->session->userdata('client_id');
        $allowed = false;
        
        if($clientId == INTERNAL_CLIENT_ID){
           return true;
        }else if($this->session->userdata('user_role_id')==ROLE_READONLY_USER){
            return false;
        }
        $actionAdd  = 'add';
        $actionEdit  = 'edit';
        $actionDelete  = 'delete';
        
        $caseActionRole = $action.'_'.$this->session->userdata('user_role_id');
        if (!isset($options['user_role_id']))
            $options['user_role_id'] = $this->session->userdata('user_role_id');
        if (!isset($options['user_region']) && !($section == 'interaction' || $section == 'payment' || $section == 'monthly_report' || $section == 'assignedto')) {
            $user = $this->getUserDetailsById($userId);
            $options['user_region'] = $user['territory'];
        }
        
        if (isset($options['kol_id']) && !isset($options['kol_region'])) {
            $globalRegion = '';
            $this->db->select('countries.GlobalRegion,client_users.client_id');
            $this->db->where('kols.id', $options['kol_id']);
            $this->db->or_where('kols.unique_id', $options['kol_id']);
            $this->db->join('countries', 'kols.country_id = countries.CountryID', 'left');
            $this->db->join('client_users', 'kols.created_by = client_users.id', 'left');
            $res = $this->db->get('kols');
            if ($res->num_rows() > 0) {
                $res = $res->first_row();
                $globalRegion = $res->GlobalRegion;
                $options['kol_client_id'] = $res->client_id;
            }
            $options['kol_region'] = $globalRegion;
        }
        if (isset($options['org_id']) && !isset($options['org_region'])) {
            $globalRegion = '';
            $this->db->select('countries.GlobalRegion,client_users.client_id,organizations.country_id');
            $this->db->where('organizations.id', $options['org_id']);
            $this->db->join('countries', 'organizations.country_id = countries.CountryID', 'left');
            $this->db->join('client_users', 'organizations.created_by = client_users.id', 'left');
            $res = $this->db->get('organizations');
            if ($res->num_rows() > 0) {
                $res = $res->first_row();
                $globalRegion = $res->GlobalRegion;
                $options['org_client_id'] = $res->client_id;
                $options['org_country_id'] = $res->country_id;
            }
            $options['org_region'] = $globalRegion;
        }
        switch ($section) {
            case 'overview' :
            case 'personal' :
            case 'assesment' :
            case 'education' :
            case 'affiliation':
            case 'event' :
            case 'publication' :
            case 'trial' :
                switch($caseActionRole){
                    case $actionAdd.'_'.ROLE_USER:
                        case $actionAdd.'_'.ROLE_MANAGER:
                        case $actionAdd.'_'.ROLE_ADMIN:
                        case $actionEdit.'_'.ROLE_MANAGER:
                        case $actionEdit.'_'.ROLE_ADMIN:
                        case $actionDelete.'_'.ROLE_ADMIN:                            
                            return true;
                        break;
                        case $actionEdit.'_'.ROLE_USER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        case $actionDelete.'_'.ROLE_USER:
                        case $actionDelete.'_'.ROLE_MANAGER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        default:
                            return false;
                        break;
                }
            break;
            case 'mycontact' :
                //echo $options['user_role_id'];
                if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN) {
                    $allowed = true;
                    //echo "ss1";
                }
                if (isset($options['client_id']) && $options['client_id'] == INTERNAL_CLIENT_ID && $clientId != INTERNAL_CLIENT_ID)
                    $allowed = false;

                if (($action == 'edit' || $action == 'delete') && $clientId != INTERNAL_CLIENT_ID) {
                    if (isset($options['client_id'])) {
                        if ($options['client_id'] == INTERNAL_CLIENT_ID)
                            $allowed = false;
                    } else
                        $allowed = false;
                }
                if ($action == 'add') {
                    $allowed = true;
                }
                if ($action == 'edit' && $options['created_by'] == $userId) {
                    $allowed = true;
                    //echo "Ss3";
                }

                if ($action == 'delete' && $options['created_by'] == $userId) {

                    $allowed = true;
                }
                //echo $allowed;
                break;
            case 'overview_fields' : $allowed = true;
                if (($options['user_role_id'] == ROLE_REGIONAL_MANAGER || $options['user_role_id'] == ROLE_REGIONAL_USER) && $options['user_region'] != $options['kol_region'])
                    $allowed = false;
                break;
            case 'assignedto': $allowed = true;
                break;
            case 'objective':
            	if ($action == 'edit'){
            		if ($clientId == INTERNAL_CLIENT_ID){
            			return true;
            		}
            		if ($options['user_role_id'] == ROLE_ADMIN)
            			return true;
            		
            		if ($options['user_role_id'] == ROLE_MANAGER){
            		    if($this->checkKolRegionWithUserRegion(0,$options['country'],$userGroupName['group_names'])){
            				return true;
            			}
            		}
            		if($options['created_by'] == $userId)
            			return true;
            		
            	}
            	break;
            case 'contract':
            case 'payment':
            case 'planning':
            case 'monthly_report' :
                if($options['contract_type']!='org' || $options['contract_type']==''){
                    $options['contract_type'] = 'kol';
                }
//                 $group_names = explode(',', $this->session->userdata('group_names'));
                if ($action == 'edit' || $action == 'delete') {                   
                    if ($options['user_role_id'] == ROLE_ADMIN)
                        return true;
                    elseif ($options['user_role_id'] == ROLE_MANAGER){
                        if($options['contract_type']=='kol'){
                            $regionName = $options['kol_region'];
                        }else{
                            $regionName = $options['org_region'];
                        }
                        if(in_array($regionName, $group_names)){
                            return true;
                        }return false;
                    }
                    elseif ($options['created_by'] == $userId)
                        return  true;
                } 
                if ($action == 'add'){
                	if ($options['user_role_id'] == ROLE_ADMIN){
                		return  true;
                	}
	                if ($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
	                    if($options['contract_type']=='kol'){
	                        $regionName = $options['kol_region'];
	                    }else{
	                        $regionName = $options['org_region'];
	                    }
	                    if(isset($regionName)){
	                        if(in_array($regionName, $group_names)){                    
	                            return true;
	                        }
	                    }else{
	                        return true;
	                    }return false;
	                }
                }
                if ($action == 'download'){
                	if ($options['user_role_id'] == ROLE_ADMIN)
                		return true;
            		if($options['contract_type']=='kol'){
            		    $regionName = $options['kol_region'];
            		}else{
            		    $regionName = $options['org_region'];
            		}
            		if(isset($regionName)){
                        if(in_array($regionName, $group_names)){                    
                            return true;
                        }return false;
                    } return false;
                }
                break;
            case 'customkol' : if ($action == 'add') {
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
                        $allowed = true;
                }
                if ($action == 'edit') {
                    //if($clientId == $options['kol_client_id']){
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
                        $allowed = true;
                    if (($options['created_by'] == $userId))
                        $allowed = true;

                    //}
                    if ($clientId == INTERNAL_CLIENT_ID)
                        $allowed = false;
                }
                break;
            case 'publiclist' : if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
                    $allowed = true;
                break;
            case 'profile_request' :
//                 $group_names = explode(',', $this->session->userdata('group_names'));
                if (($options['profile_type'] == 'Basic' || $options['profile_type'] == 'Basic Plus' || $options['profile_type'] == USER_ADDED || $options['profile_type'] == LEGACY || $options['profile_type'] == DISCOVERY) && ($options['status'] != APPROVED && $options['status'] != NEW1 && $options['status'] != REQUESTED && $options['status'] != PROFILING )){
                         if ($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
                             if(in_array($options['kol_region'], $group_names)){
                                 return true;
                             }return false;
                           }else{                         
                            $allowed = true;
                           }
                    } 
                    if ($options['user_role_id'] == ROLE_READONLY_USER)
                        return false;
                    if ($action == 'approve' && $options['user_role_id'] == ROLE_MANAGER){
                        if(in_array($options['kol_region'], $group_names)){
                            return true;
                        }return false;                        
                    }
                    if ($action == 'add'){
                        if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_USER)
                            $allowed = true;
                    }
                break;
            case 'org_profile_request' :
//             	$group_names = explode(',', $this->session->userdata('group_names'));
                    if ($action == 'delete'){
                        if ($options['requested_by'] == $userId){
                            return true;
                        }
                    }

                    if ($options['profile_type'] != 2 && $options['status'] != APPROVED && $options['status'] != PROFILING){
                        if ($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
                             if(in_array($options['org_region'], $group_names)){
                                 return true;
                             }return false;
                           }else{                         
                            $allowed = true;
                           }
                    }
                    if ($action == 'approve' && $options['user_role_id'] == ROLE_MANAGER){
                        if(in_array($options['org_region'], $group_names) || $options['country_id']==null){
                            return true;
                        }return false;
                    }
                break;
            case 'user_notes' : 
	            	if ($options['created_by'] == $userId)
	                    $allowed = true;
	                if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
	                    $allowed = true;
                break;
            case 'org' : 
                	if ($action == 'delete')
                		if ($options['user_role_id'] == ROLE_ADMIN)
                			return true;
                		else
                			return false;
                	if ($action == 'add'){
                		if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_USER)
                			return true;
                		if ($options['user_role_id'] == ROLE_READONLY_USER)
                			return false;
                	}
                	if ($action == 'edit') {
                		if ($clientId == INTERNAL_CLIENT_ID)
                			return true;
//                 		if ($options['user_role_id'] == ROLE_ADMIN)
//                 			return true;
                		if ($options['user_role_id'] == ROLE_READONLY_USER){
                			return false;
                		}
                		//Allow if its aligned to user
                		if ($this->isOrgProfileAssignedToUser($options['org_id'], $userId))
                			
                			return true;
                		if (isset($options['created_by']) && is_numeric($options['created_by']))
                			$options['created_by_id'] = $options['created_by'];
                			$profileUserDetails = $this->getUserDetailsById($options['created_by_id']);
                		
                								
                	}
                break;
            case 'kol' : 
            	if ($action == 'delete')
            		if ($clientId == INTERNAL_CLIENT_ID)
                        return true;
            	if ($action == 'add'){
                      if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_USER)
                            return true;
                    if ($options['user_role_id'] == ROLE_READONLY_USER)
                              return false;
                }
                if ($action == 'edit') {
                    if($options['deleted_by']!=0){
                        return false;
                    }else{
                        //Allow if its aligned to user
                        if ($this->isProfileAssignedToUser($options['id'], $userId))
                            return true;
                        if (isset($options['created_by']) && is_numeric($options['created_by']))
                            $options['created_by_id'] = $options['created_by'];
                        $profileUserDetails = $this->getUserDetailsById($options['created_by_id']);
                        /* if (($options['user_role_id'] == ROLE_MANAGER || $options['created_by_id'] == $userId) && $profileUserDetails['client_id'] != INTERNAL_CLIENT_ID){
                            $group_names = explode(',', $this->session->userdata('group_names'));
                            if(in_array($options['kol_region'], $group_names)){
                                return true;
                            }return false;                       
                        }  */  
                        //if ($options['user_role_id'] == ROLE_ADMIN)
                            //return true;
                        if ($options['user_role_id'] == ROLE_READONLY_USER){
                             return false;
                           
                        }
                        if ($clientId == INTERNAL_CLIENT_ID)
                            return true;
                    }
                }
                break;
             case 'staff' :
                    switch($caseActionRole){
                        case $actionAdd.'_'.ROLE_USER:
                        case $actionAdd.'_'.ROLE_MANAGER:
                        case $actionAdd.'_'.ROLE_ADMIN:
                        case $actionEdit.'_'.ROLE_MANAGER:
                        case $actionEdit.'_'.ROLE_ADMIN:
                        case $actionDelete.'_'.ROLE_ADMIN:                            
                            return true;
                        break;
                        case $actionEdit.'_'.ROLE_USER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        case $actionDelete.'_'.ROLE_USER:
                        case $actionDelete.'_'.ROLE_MANAGER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        default:
                            return false;
                        break;
                    }
            break;
            case 'phone_number' :
                    switch($caseActionRole){
                        case $actionAdd.'_'.ROLE_USER:
                        case $actionAdd.'_'.ROLE_MANAGER:
                        case $actionAdd.'_'.ROLE_ADMIN:
                        case $actionEdit.'_'.ROLE_MANAGER:
                        case $actionEdit.'_'.ROLE_ADMIN:
                        case $actionDelete.'_'.ROLE_ADMIN:
                            return true;
                        break;
                        case $actionEdit.'_'.ROLE_USER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        case $actionDelete.'_'.ROLE_USER:
                        case $actionDelete.'_'.ROLE_MANAGER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        default:
                            return false;
                        break;
                    }
                  break;
            case 'email' :
                    switch($caseActionRole){
                        case $actionAdd.'_'.ROLE_USER:
                        case $actionAdd.'_'.ROLE_MANAGER:
                        case $actionAdd.'_'.ROLE_ADMIN:
                        case $actionEdit.'_'.ROLE_MANAGER:
                        case $actionEdit.'_'.ROLE_ADMIN:
                        case $actionDelete.'_'.ROLE_ADMIN:
                            return true;
                        break;
                        case $actionEdit.'_'.ROLE_USER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        case $actionDelete.'_'.ROLE_USER:
                        case $actionDelete.'_'.ROLE_MANAGER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        default:
                            return false;
                        break;
                    }
                  break;
            case 'statelicense':
                     switch($caseActionRole){
                        case $actionAdd.'_'.ROLE_USER:
                        case $actionAdd.'_'.ROLE_MANAGER:
                        case $actionAdd.'_'.ROLE_ADMIN:
                        case $actionEdit.'_'.ROLE_MANAGER:
                        case $actionEdit.'_'.ROLE_ADMIN:
                        case $actionDelete.'_'.ROLE_ADMIN:
                            return true;
                        break;
                        case $actionEdit.'_'.ROLE_USER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        case $actionDelete.'_'.ROLE_USER:
                        case $actionDelete.'_'.ROLE_MANAGER:
                            if($options['created_by']==$userId){
                                return true;
                            }
                        break;
                        default:
                            return false;
                        break;
                    }
                   break;
             case 'assign':
                   	switch($caseActionRole){
                   		case $actionAdd.'_'.ROLE_USER:
                   		case $actionAdd.'_'.ROLE_MANAGER:
                   		case $actionAdd.'_'.ROLE_ADMIN:
                   		case $actionEdit.'_'.ROLE_MANAGER:
                   		case $actionEdit.'_'.ROLE_ADMIN:
                   		case $actionDelete.'_'.ROLE_ADMIN:
                   			return true;
                   			break;
                   		case $actionEdit.'_'.ROLE_USER:
                   			if($options['created_by']==$userId){
                   				return true;
                   			}
                   			break;
                   		case $actionDelete.'_'.ROLE_USER:
                   		case $actionDelete.'_'.ROLE_MANAGER:
                   			if($options['created_by']==$userId){
                   				return true;
                   			}
                   			break;
                   		default:
                   			return false;
                   			break;
                   	}
            break;
            case 'ol key status':
            case 'best_kol_time':
                 if ($action == 'add'){
                                if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_USER)
                                        return true;
                                if ($options['user_role_id'] == ROLE_READONLY_USER)
                                          return false;
                            }
                            if ($action == 'delete'){
                                if ($options['user_role_id'] == ROLE_READONLY_USER)
                                            return false;
                                if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_USER)
                                        return true;
//                                
                            } 
            break;
            case 'location' :  
                switch($caseActionRole){
                    case $actionAdd.'_'.ROLE_USER:
                    case $actionAdd.'_'.ROLE_MANAGER:
                    case $actionAdd.'_'.ROLE_ADMIN:
                    case $actionEdit.'_'.ROLE_MANAGER:
                    case $actionEdit.'_'.ROLE_ADMIN:
                    case $actionDelete.'_'.ROLE_ADMIN:
                        return true;
                        break;
                    case $actionEdit.'_'.ROLE_USER:
                        if($options['created_by']==$userId){
                            return true;
                        }
                        break;
                    case $actionDelete.'_'.ROLE_USER:
                    case $actionDelete.'_'.ROLE_MANAGER:
                        if($options['created_by']==$userId){
                            return true;
                        }
                        break;
                    default:
                        return false;
                        break;
                }
                break;
            case 'medical insight' :if ($action == 'add')
                    return true;
                if ($action == 'edit') {
                    if ($options['ireport_id'] != null)
                        return false;
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN || $options['created_by'] == $userId) {
                        return true;
                    }
                }
                if ($action == 'delete')
                    return false;
                break;
            case 'compliance' : if ($action == 'edit') {
                    if ($options['ireport_id'] != null)
                        return false;
                }
                if ($action == 'delete')
                    return false;
                if ($action == 'add' || $action = 'edit' || $action = 'link') {
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
                        return true;
                }

                break;
            case 'coaching': if ($action == 'edit') {
                    if ($options['ireport_id'] != null)
                        return false;
                }
                if ($action == 'delete')
                    return false;
                if ($action == 'add' || $action = 'edit' || $action = 'link') {
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)
                        return true;
                }

                break;
            case 'interaction':
            	if ($action == 'add') {
                    if ($options['user_role_id'] == ROLE_READONLY_USER)
                         return false;
                    if ($options['user_role_id'] == ROLE_ADMIN)
                         return true;
                    if ($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
                        if($this->checkKolRegionWithUserRegion($kolDetails['id'],$kolDetails['country_id'],$userGroupName['group_names'])){
                            return true;
                        }else{
                          return false;
                        }
                    }
                }
                if ($action == 'edit' || $action == 'delete') {
                    //if intereaction is added by logged in user or logged in user is mamanger
                    if ($options['user_role_id'] == ROLE_MANAGER){
                        if($this->checkInteractionWithManagerRegion($options,$userGroupName['group_names'])){
                            return true;
                        } return false;
                    }
                    if ($options['user_role_id'] == ROLE_ADMIN || $options['created_by'] == $userId) {
                        return true;
                    }
                } 
                break;
            case 'org_interaction' :
//                 $group_names = explode(',', $this->session->userdata('group_names'));
                if ($action == 'edit' || $action == 'delete') {
                    if ($options['user_role_id'] == ROLE_ADMIN || $options['created_by'] == $userId){
                        return true;
                    }
                    elseif ($options['user_role_id'] == ROLE_MANAGER){
                        if(in_array($options['org_region'], $group_names)){
                            return true;
                        }
                    }
                } 
                if ($action == 'add') {
                	if ($options['user_role_id'] == ROLE_READONLY_USER)
                		return false;
                		if ($options['user_role_id'] == ROLE_ADMIN)
                			return true;
                
	                if ($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
	                    if(isset($options['org_region'])){
	                        if(in_array($options['org_region'], $group_names)){                    
	                            return true;
	                        }
	                    }else{
	                        return true;
	                    }
	                }
                }
            case 'mirf' : if ($action == 'add') {
                    if ($options['save_later'] == 0)
                        return false;
                    //if intereaction is added by logged in user or logged in user is mamanger
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN || $options['created_by'] == $userId)
                        return true;
                }
                if ($action == 'edit') {
                    if ($options['save_later'] == 0)
                        return false;
                    //if mirf or interaction is added by loggedin user or is mamanager
                    if ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN || $options['created_by'] == $userId) {
                        //return true;
                        return false;
                    }
                }
                if ($action == 'delete')
                    return false;
                break;

            case 'speaker evaluation':
                if ($action == 'add') {
                    return true;
                }
                if ($action == 'edit')
                    return false;
                if ($action == 'delete')
                    return false;
                break;
            case 'notification':
                if ($action == 'add') {
                    if ($options['user_role_id'] != ROLE_READONLY_USER)
                        return true;
                }
                if ($action == 'edit'|| $action == 'delete') {
                    if ($options['user_role_id'] == ROLE_ADMIN || $options['user_role_id'] == ROLE_MANAGER || $options['created_by'] == $userId)
                        return true;
                }
                if ($action == 'link') {
                    if ($options['user_role_id'] != ROLE_READONLY_USER)
                        return true;                     
                }
                break;
            case 'user group': if ($action == 'edit') {
                    if ($clientId == INTERNAL_CLIENT_ID)
                        return true;
                }
                if ($action == 'delete') {
                    if ($clientId == INTERNAL_CLIENT_ID)
                        return true;
                }
                break;
            case 'interaction_reports': return true;
                $teamName = $this->common_helpers->getUserTeamName($userId);
                if (strtolower($teamName) == strtolower("Home office") || $clientId == INTERNAL_CLIENT_ID) {
                    return true;
                } else {
                    return false;
                }
                break;
            case 'user_access_reports':
                $teamName = $this->common_helpers->getUserTeamName($userId);
                if ((strtolower($teamName) == strtolower("Home office") && ($options['user_role_id'] == ROLE_MANAGER || $options['user_role_id'] == ROLE_ADMIN)) || $clientId == INTERNAL_CLIENT_ID) {
                    return true;
                } else {
                    return false;
                }
                break;
            case 'kol_consent_visiblity':
                if ($action == 'add'){
                    $group_names = explode(',', KOL_CONSENT_REGION_VISBILITY);
                    if(in_array($options['kol_region'], $group_names)){
                        return true;
                    }else{
                        return false;
                    }
                }
                break;
                case 'kol_details':
                	if(empty($options['kol_id'])){
                		return true;
                	}
//                     $group_names = explode(',', $this->session->userdata('group_names'));                    
                    if ($action == 'edit' || $action == 'delete') {
                    	
                        if ($options['user_role_id'] == ROLE_ADMIN)
                            return true;
                        elseif ($options['user_role_id'] == ROLE_MANAGER){
                            if(in_array($options['kol_region'], $group_names)){                               
                                return true;
                            }else{
                            	return false;
                            }
                        }
                        elseif ($options['created_by'] == $userId)
                        	return true;
                    }
                    if ($action == 'add'){
                    	if ($options['user_role_id'] == ROLE_ADMIN){
                    		return true;
                    	}
                    
	                    if($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER){
	                    
	                        if(isset($options['kol_region'])){
	                            if(in_array($options['kol_region'], $group_names)){                                
	                                return true;
	                            }
	                        }else{
	                            return true;
	                        }
	                        
	                    }
                    }
                break;
                case 'interaction_doc_download':
                    if ($action == 'download'){
                        if ($options['user_role_id'] == ROLE_ADMIN)
                            return true;
                            if($this->checkKolRegionWithUserRegion(0,$options['country'],$userGroupName['group_names'])){
                            return true;
                        }
                        return false;
                    }
                break;
                    
                case 'org_details':
//                     $group_names = explode(',', $this->session->userdata('group_names'));
                    if ($action == 'edit' || $action == 'delete') {
                        if ($options['user_role_id'] == ROLE_ADMIN)
                            $allowed = true;
                        elseif ($options['user_role_id'] == ROLE_MANAGER){
	                            if(in_array($options['org_region'], $group_names)){
	                                    return true;
	                             }else{
		                            	return false;
		                         }
                        }
                        elseif ($options['created_by'] == $userId)
                            $allowed = true;
                    }
                    if ($action == 'add'){
                    	if ($options['user_role_id'] == ROLE_ADMIN){
                    		return true;
                    	}
	                    if (($options['user_role_id'] == ROLE_USER || $options['user_role_id'] == ROLE_MANAGER)){                        
	                        if(isset($options['org_region'])){
	                            if(in_array($options['org_region'], $group_names)){
	                                return true;
	                            }
	                        }else{
	                            return true;
	                        }
	                    }
                    }
                    break;
            case '' :
            default :break;
        }

        return $allowed;
    }

    function getUserName($id) {
        $name = '';
        if ($id != '' && $id != null) {
            $this->db->select('first_name,last_name,client_id');
            $this->db->where('id', $id);
            $results = $this->db->get('client_users');
            if ($results->num_rows() != 0) {
                $row = $results->first_row();
                if ($row->client_id == INTERNAL_CLIENT_ID)
                    $name = "Aissel Analyst";
                else
                    $name = $row->first_name . " " . $row->last_name;
            }
        }

        return $name;
    }

    function getUserProducts($userId = '',$latestDate) {
        $arrProducts = array();
        if ($userId == '')
            $userId = $this->session->userdata('user_id');

        //Get user groups
        $arrGroupIds = array();
        $this->db->select('group_id');
        $this->db->where('user_id', $userId);
        $res = $this->db->get('user_groups');
        if (is_object($res) && $res->num_rows() > 0) {
            foreach ($res->result_array() as $row)
                $arrGroupIds[] = $row['group_id'];
        }
        if (count($arrGroupIds) > 0) {
            $this->db->select('DISTINCT products.id,products.name,products.modified_on as date,products.sort_id', false);
            $this->db->where('products.status', 1);
            $this->db->where_in('group_products.group_id', $arrGroupIds);
            if($latestDate!='')
                 $this->db->where('products.modified_on >', $latestDate);
            $this->db->join('products', 'group_products.product_id = products.id', 'left');
            //$this->db->order_by('products.name', 'asc');
            $this->db->order_by('products.sort_id', 'asc');
            $res = $this->db->get('group_products');
            if (is_object($res) && $res->num_rows() > 0) {
                $noProdId = 0;
                $otherId = 0;
                $noProdRow = array();
                $otherRow = array();
                foreach ($res->result_array() as $row) {
                	$arrProducts[$row['sort_id']] = $row;
/*                	//$test = preg_match("/Other/i", $row['name']);
                	if (($row['name'] != "No Product") && (preg_match("/Other/i", $row['name']))) {
                    //if (($row['name'] != "No Product") && ($row['name'] != "Other")) {
                        $arrProducts[$row['id']] = $row;
                    } else if ($row['name'] == "No Product") {
                        $noProdId = $row['id'];
                        $noProdRow = $row;
                    } else {
                        $otherId = $row['id'];
                        $otherRow = $row;
                    }
*/
               }
 /*               if ($noProdId)
                    $arrProducts[$noProdId] = $noProdRow;
                if ($otherId)
                    $arrProducts[$otherId] = $otherRow;
*/
            }
        }

        return $arrProducts;
    }

    function getTeamOtherUserIDs($userId) {
        $arrUserIds = array();
        //Get user groups
        $arrGroupIds = array();
        $this->db->select('user_groups.group_id');
        $this->db->where('user_id', $userId);
        $this->db->where('groups.group_type', "Team");
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $res = $this->db->get('user_groups');
        if (is_object($res) && $res->num_rows() > 0) {
            foreach ($res->result_array() as $row)
                $arrGroupIds[] = $row['group_id'];
        }
        if (count($arrGroupIds) > 0) {
            $arrGroupIds = array_values($arrGroupIds);
            $this->db->select('DISTINCT user_id', false);
            $this->db->where_in('group_id', $arrGroupIds);
            $res = $this->db->get('user_groups');
            if (is_object($res) && $res->num_rows() > 0) {
                foreach ($res->result_array() as $row)
                    $arrUserIds[] = $row['user_id'];
            }

            $arrUserIds = array_values($arrUserIds);
        }
        $userId = $this->session->userdata('user_id');
        $arrUserIds[] = $userId;

        return $arrUserIds;
    }

    private function getUserDetailsById($userId) {
        $user = array();
        $this->db->where('id', $userId);
        $arrUserResult = $this->db->get('client_users');
        foreach ($arrUserResult->result_array() as $row) {
            $user = $row;
        }
        return $user;
    }

    function getTeamAllManagers($userId) {
        $arrUserIds = array();

        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->getTeamOtherUserIDs($userId);
        $teamName = $this->getUserTeamName($userId);
        //Get user groups
        $arrGroupIds = array();
        $this->db->select('user_groups.group_id');
        $this->db->where('user_groups.user_id', $userId);
        $this->db->where('groups.group_type', "Team");
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $res = $this->db->get('user_groups');
        if (is_object($res) && $res->num_rows() > 0) {
            foreach ($res->result_array() as $row)
                $arrGroupIds[] = $row['group_id'];
        }
        if (count($arrGroupIds) > 0) {
            $arrGroupIds = array_values($arrGroupIds);
            $this->db->select('client_users.id,client_users.first_name,client_users.last_name,client_users.email,client_users.user_name');
            $this->db->join('client_users', 'user_groups.user_id = client_users.id', 'left');
            $this->db->where_in('client_users.user_role_id', array(ROLE_MANAGER,ROLE_ADMIN));
            $this->db->where_in('user_groups.group_id', $arrGroupIds);
            $this->db->group_by('user_groups.user_id');
            $res = $this->db->get('user_groups');
            if (is_object($res) && $res->num_rows() > 0) {
                foreach ($res->result_array() as $row)
                    $arrUserIds[$row['id']] = $row;
            }

            $arrUserIds = array_values($arrUserIds);
        }
        return $arrUserIds;
    }

    function getGenericId($moduleName) {

        switch ($moduleName) {

            case "Compliance Form" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Customer Engagement Form" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Medical Insight" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Speaker Evaluation" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Interactions Name" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Location Form" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "Organization Locations" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;

            case "U O Q" :
                $result = $this->createUniqueId($moduleName);
                return $result;
                break;
        }
    }

    function createUniqueId($moduleName) {
        /*
         * Extract First letter from each word 'ex: Customer Engagement(CF)'
         * 
         */
        $expr = '/(?<=\s|^)[a-z]/i';
        preg_match_all($expr, $moduleName, $matches);

        $result = implode('', $matches[0]);

        $uniqueId = strtoupper($result);

        return $uniqueId . now();
    }

    function getUserTeamName($userID) {
        $name = "";
        $this->db->select("groups.group_name");
        $this->db->where("groups.group_type", "Team");
        $this->db->where("user_id", $userID);
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'left');
        $res = $this->db->get('user_groups');
        if ($res->num_rows() > 0) {
            $row = $res->row_array();
            $name = $row['group_name'];
        }
        return $name;
    }

    function getMonthAndYerBetweenTwoDates($fromDate = '', $toDate = '') {
//    	$fromDate = "2016-02-01";
//    	$toDate = "2016-02-01";
        if ($fromDate == '' || $toDate == '') {
            $arr = array();
        } else {
            $fromDate = strtotime(date("Y-m", strtotime($fromDate)));
            $toDate = strtotime(date("Y-m", strtotime($toDate)));
            //    	echo $toDate;
            //    	echo "</br>";
            //    	echo $fromDate;
            //    	echo "</br>";
            //    	echo strtotime(date("Y-m", strtotime("+1 month", $fromDate)));
            while ($fromDate <= $toDate) {
                $arr[date("Y", $fromDate)][] = (int) date("m", $fromDate);
                $fromDate = strtotime(date("Y-m", strtotime("+1 month", $fromDate)));
            }
        }
        return $arr;
//    	pr($arr);
//    	exit;
    }

    function getOrgName($id) {
        $this->db->select("name");
        $this->db->where("id", $id);

        $res = $this->db->get('organizations');
        $data = $res->row_array();
        return $data['name'];
    }

    function getManagerAlignedUsers($userId) {

        $user = array();
        $this->db->select("id");
        if(!is_array($userId)){
        	$userId	= array($userId);
        }
        $this->db->where_in('manager_id', $userId);
        $arrUserResult = $this->db->get('client_users');
        foreach ($arrUserResult->result_array() as $row) {
            $user[] = $row['id'];
        }
        $user = array_values($user);
//         $userId = $this->session->userdata('user_id');
//         $user[] = $userId;
        return $user;
    }

    function isProfileAssignedToUser($profileId, $userId) {
        $this->db->where('kol_id', $profileId);
        $this->db->where('user_id', $userId);
        $res = $this->db->get('user_kols');
        if ($res->num_rows() > 0) {
            return true;
        } else
            return false;
    }
    function isOrgProfileAssignedToUser($profileId, $userId) {
        $this->db->where('org_id', $profileId);
        $this->db->where('user_id', $userId);
        $res = $this->db->get('user_orgs');
        if ($res->num_rows() > 0) {
            return true;
        } else
            return false;
    }

    function getAllManagersForReports($userId) {
        $arrUserIds = array();

        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->getTeamOtherUserIDs($userId);
        $teamName = $this->getUserTeamName($userId);
        $this->db->select('client_users.id,client_users.first_name,client_users.last_name,client_users.email,client_users.user_name');
        $this->db->join('client_users', 'user_groups.user_id = client_users.id', 'left');
        $this->db->where_in('client_users.user_role_id', array(ROLE_MANAGER,ROLE_ADMIN,ROLE_READONLY_USER));
        if (($userRole == ROLE_MANAGER) && strtolower($teamName) != "home office") {
            //get all managers aligned to a team
            $this->db->where_in('client_users.id', $userIds);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN || $userRole == ROLE_READONLY_USER) && strtolower($teamName) != "home office") {
            $this->db->where('client_users.client_id', $this->session->userdata('client_id'));
        }

        $res = $this->db->get('user_groups');
        if (is_object($res) && $res->num_rows() > 0) {
            foreach ($res->result_array() as $row)
                $arrUserIds[$row['id']] = $row;
        }

        $arrUserIds = array_values($arrUserIds);

        return $arrUserIds;
    }
    function getKolidOrUniqueId($kolId){
    	if($kolId != ''){
    		if(!is_numeric($kolId)){
    			$kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
    		}else{
    			$kolId = $this->common_helpers->getUniqueIdByKolId($kolId);
    			$kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
    		}
    		return $kolId;
    	}else{
    		return 0;
    	}
    }
    /*
     * Gets kol id for given unique id.
     */
    function getKolIdByUniqueId($uniqueId){
        $this->db->select('id');
        $this->db->where('unique_id', $uniqueId);
        $query = $this->db->get('kols');
        $result = $query->result_array();
        $returnId = $result[0]['id'];
        return $returnId;
    }
    /*
     * Gets unique id for given kol id.
     */
    function getUniqueIdByKolId($id){
        $this->db->select('unique_id');
        $this->db->where('id', $id);
        $query = $this->db->get('kols');
        $result = $query->result_array();
        $returnId = $result[0]['unique_id'];
        return $returnId;
    }

    
    /*
     * Gets client logo and client favicon for given client id
     */
    function getClientLogo($clientId){
    	$this->db->select('client_logo,client_favicon');
    	$this->db->where('id',$clientId);
    	$arrClientResults = $this->db->get('clients');
		return $arrClientResults->result_array();
    }
    
    function getRegionNameByCountryName(){
    	
    }
    function checkKolRegionWithUserRegion($kolId,$country_id,$group_names){
        $group_names = explode(',', $group_names);
         $this->db->select('GlobalRegion');
         $this->db->where("CountryId",$country_id);
         $get = $this->db->get('countries')->row();
         if(in_array($get->GlobalRegion, $group_names)){
             return true;
         }
         return false;
             
    }
    function checkInteractionWithManagerRegion($interactionDetails,$group_names){
        $group_names = explode(',', $group_names);
        $this->db->select('GlobalRegion');
        $this->db->join('kols', 'kols.country_id = countries.CountryId', 'left');
        $this->db->where("kols.id",$interactionDetails['kol_id']);
        $get = $this->db->get('countries')->row();
        //echo $group_names."==".$get->GlobalRegion;exit;
        if(in_array($get->GlobalRegion, $group_names)){
             
            return true;
        }
        return false;
    }
	function checkApproverId(){
		$arrUserIds    = array();
        $group_name = 'ProfileRequestAccess';
        $this->db->select('user_groups.user_id');
        $this->db->join('groups', 'user_groups.group_id = groups.group_id', 'join');
        $this->db->where("groups.group_name",$group_name);
        $res = $this->db->get('user_groups');
        if (is_object($res) && $res->num_rows() > 0) {
            foreach ($res->result_array() as $key => $value){
                $arrUserIds[] = $value['user_id'];
            }
        }
        /*
        if(in_array($user_id, $arrUserIds)){
             return true;
        }
        return false;
       */
        return $arrUserIds;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : isDataNull()
	 * @Params : Variable
	 * @Return : TRUE if Variable is 'Null / Empty / Blankspace(s)' else FALSE
	 */
	function isDataNull($dataVar){
		$isNull = false;
		if(isset($dataVar) && !empty($dataVar) && !is_null($dataVar)){
			$isNull = ($dataVar == 'null' || $dataVar == 'undefined') ? true : $isNull;
		} else {
			$isNull = true;
		}
		return $isNull;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : search_nested_arrays()
	 * @Params : array, key
	 * @Action : Searches in nested array and returns result as a plain array
	 */
	function search_nested_arrays($array, $key) {
		if(is_object($array)){
			$array = (array) $array;
		}
		$result = array();
		foreach($array as $k => $value){
			if(is_array($value) || is_object($value)){
				$r = $this->search_nested_arrays($value, $key);
				if(!is_null($r)) {
					array_push($result, $r);
				}
			}
		}
		if(array_key_exists($key, $array)){
			array_push($result, $array [$key]);
		}
		if(count($result) > 0){
			$result_plain = array();
			foreach($result as $k => $value) {
				if(is_array($value)){
					$result_plain = array_merge($result_plain, $value);
				} else {
					array_push($result_plain, $value);
				}
			}
			return $result_plain;
		}
		return NULL;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getMailConfig()
	 * @Params : Username and Password
	 * @Action : Returns Configuration for Mail Service
	 */
	function getMailConfig($userName, $password, $configFor = 'DEFAULT') {
		// Default Settings
		$config ['DEFAULT'] ['PROTOCOL'] = PROTOCOL;
		$config ['DEFAULT'] ['HOST'] = HOST;
		$config ['DEFAULT'] ['PORT'] = PORT;
		// Opt-In / Out Settings
		$config ['OPTINOUT'] ['PROTOCOL'] = OPTINOUT_PROTOCOL;
		$config ['OPTINOUT'] ['HOST'] = OPTINOUT_HOST;
		$config ['OPTINOUT'] ['PORT'] = OPTINOUT_PORT;
		// Profile Request Settings
		$config ['PROFILE_REQUEST'] ['PROTOCOL'] = PROFILE_REQUEST_PROTOCOL;
		$config ['PROFILE_REQUEST'] ['HOST'] = PROFILE_REQUEST_HOST;
		$config ['PROFILE_REQUEST'] ['PORT'] = PROFILE_REQUEST_PORT;
		// Configuration Array
		$configFor = strtoupper ($this->isDataNull($config[$configFor]) ? 'DEFAULT' : $configFor );
		$arrConfig = array (
				'protocol' => $config [$configFor] ['PROTOCOL'],
				'smtp_host' => $config [$configFor] ['HOST'],
				'smtp_port' => $config [$configFor] ['PORT'],
				'smtp_user' => $userName,
				'smtp_pass' => $password,
				'mailtype' => 'html',
				'charset' => 'iso-8859-1',
				'wordwrap' => TRUE
		);
		return $arrConfig;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : sendMail()
	 * @Params : Configuration array, Information array
	 * @Action : Sends mail using the information array
	 * @Return : Response array with STATUS => True / False  
	 */
	function sendMailService($arrConfig,$arrInfo) {
		$arrResponse = array();
		$isControlAllowed = true;
		if($this->isDataNull($arrConfig) || $this->isDataNull($arrInfo)){
			$arrResponse['STATUS'] = false;
			$arrResponse['REASON'] = "Incomplete Configuration Information";
			$isControlAllowed = false;
		}
		if($isControlAllowed){
			$arrMissedConfigs = array();
			if($this->isDataNull($arrConfig['protocol'])){
				array_push($arrMissedConfigs, "Protocol");
			}
			if($this->isDataNull($arrConfig['smtp_host'])){
				array_push($arrMissedConfigs, "Host");
			}
			if($this->isDataNull($arrConfig['smtp_port'])){
				array_push($arrMissedConfigs, "Port");
			}
			if($this->isDataNull($arrConfig['smtp_user'])){
				array_push($arrMissedConfigs, "Username");
			}
			if($this->isDataNull($arrConfig['smtp_pass'])){
				array_push($arrMissedConfigs, "Password");
			}
			if($this->isDataNull($arrConfig['mailtype'])){
				array_push($arrMissedConfigs, "Mail Type");
			}
			if($this->isDataNull($arrConfig['charset'])){
				array_push($arrMissedConfigs, "Character Set");
			}
			if($this->isDataNull($arrConfig['wordwrap'])){
				$arrConfig['wordwrap'] = TRUE;
			}
			if(sizeof($arrMissedConfigs) >= 1){
				$arrResponse['STATUS'] = false;
				$arrResponse['REASON'] = "Incomplete Information [ Missed Details : ".implode(', ',$arrMissedConfigs)." ]";
				$isControlAllowed = false;
			}
		}
		if($isControlAllowed){
			$arrMissedInfos = array();
			if($this->isDataNull($arrInfo['FROM'])){
				array_push($arrMissedInfos, "From");
			}
			if($this->isDataNull($arrInfo['TO'])){
				array_push($arrMissedInfos, "To");
			}
			if($this->isDataNull($arrInfo['SUBJECT'])){
				array_push($arrMissedInfos, "Subject");
			}
			if($this->isDataNull($arrInfo['MAIL_BODY'])){
				array_push($arrMissedInfos, "Mail Body");
			}
			if($this->isDataNull($arrInfo['CC'])){
				$arrInfo['CC'] = '';
			}
			if($this->isDataNull($arrInfo['FROM_NAME'])){
				$arrInfo['FROM_NAME'] = '';
			}
			if(sizeof($arrMissedInfos) >= 1){
				$arrResponse['STATUS'] = false;
				$arrResponse['REASON'] = "Incomplete Information [ Missed Details : ".implode(', ', $arrMissedInfos)." ]";
				$isControlAllowed = false;
			}
		}
		if($isControlAllowed){
			$this->load->library('email',$arrConfig);
			$this->email->set_newline("\r\n");
			$this->email->from($arrInfo['FROM'], $arrInfo['FROM_NAME']);
			$this->email->to($arrInfo['TO']);
			$this->email->cc($arrInfo['CC']);
			$this->email->subject($arrInfo['SUBJECT']);
			$this->email->message($arrInfo['MAIL_BODY']);
			$arrResponse['STATUS'] = $this->email->send();
			$arrResponse['REASON'] = $arrResponse['STATUS'] ? "Mail(s) Sent Successfully" : "Server Error : Sending Failed";
			if($arrResponse['STATUS']){
    			//Record log Activity
    			$arrLogDetails = array(
    			    'type' => LOG_ACTIVITY_EMAIL,
    			    'description' => $arrInfo['MAIL_BODY'],
    			    'status' => STATUS_SUCCESS,
    			    'transaction_name' => $arrInfo['SUBJECT']." Email Triggerd"
    			);
    			$this->config->set_item('log_details', $arrLogDetails);
    			log_user_activity(null, true);
			}else{
			    //Record log Activity
			    $arrLogDetails = array(
			        'type' => LOG_ACTIVITY_EMAIL,
			        'description' => $arrInfo['MAIL_BODY'],
			        'status' => STATUS_FAIL,
			        'transaction_name' => $arrInfo['SUBJECT']." Email Triggerd"
			    );
			    $this->config->set_item('log_details', $arrLogDetails);
			    log_user_activity(null, true);
			}
		}
		return $arrResponse;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getEntityById()
	 * @Params : entity / table name, associative array to match, db object (Optional)
	 * @Action : Matches 'FROM $entityName WHERE $arrWhere( $colName => $colValue )
	 * @Return : Returns matching records of type $entityName
	 */
	function getEntityById($entityName, $arrWhere = array(), $dbObj = false) {
		$arrWhere = array_filter($arrWhere);
		$resultSet = null;
		if ($dbObj) {
			$dbObj->where ( $arrWhere );
			$resultSet = $dbObj->get ( $entityName );
		} else {
			$this->db->where ( $arrWhere );
			$resultSet = $this->db->get ( $entityName );
		}
		return $resultSet;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : updateEntity()
	 * @Params : entity / table name, data, colValue to match, Column Name (Default : ID - Can be overridden)
	 * @Action : Updates to $entityName WHERE $colName = $colValue'
	 * @Return : TRUE / FALSE
	 */
	function updateEntity($entityName, $arrData, $arrWhere = array()) {
		$arrWhere = array_filter($arrWhere);
		$this->db->where ( $arrWhere );
		return $this->db->update ( $entityName, $arrData );
	}
	
	
	/*
	 * @Author : Vinod Hangal (1083)
	 * @Method : array_multi_subsort()
	 * @Params : array / array value, subkey / key value to sort, Sort type/ sort order
	 * @Action : sort the array by key element
	 * @Return : Sort values
	 * Multiple array soting
	 */
	function array_multi_subsort($array, $subkey, $sortType = 'asort')
	{
	    $b = array(); $c = array();
	    
	    foreach ($array as $k => $v)
	    {
	        $b[$k] = strtolower($v[$subkey]);
	    }
	    
	    $sortType($b);
	    foreach ($b as $key => $val)
	    {
	        $c[] = $array[$key];
	    }
	    
	    return $c;
	}
}
