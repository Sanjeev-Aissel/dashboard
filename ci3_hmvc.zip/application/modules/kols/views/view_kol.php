<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>modules/kols/css/kols.css" />
<?php 
$queued_js_scripts = array('modules/kols/js/view_kol','js/chosen.jquery','jqgrid/i18n/grid.locale-en',
		'jqgrid/jquery.jqGrid.min_3.8','jquery_validator/dist/jquery.validate',
		'js/jquery.autocomplete'
);
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
		<div class="row">
			<div class="col-md-4">
			<div class="div_with_border">
				<?php //pr($arrKol);
					if(!empty($arrKol['primary_phone']) && sizeof($arrKol['primary_phone'])>10){
						$arrKol['primary_phone']	= (($arrKol['primary_phone'][0]=="+")?'':'+').$arrKol['primary_phone'];
					}
					if(!empty($arrKol['fax']) && sizeof($arrKol['fax'])>10){
						$arrKol['fax']				= (($arrKol['fax'][0]=="+")?'':'+').$arrKol['fax'];
					}
					if($arrKol['salutation'] != 0)
						$salutation	= $arrSalutations[$arrKol['salutation']];
					else
						$salutation = "";
					
					$firstName	= $arrKol[FIRST_ORDER];
					$middleName	= $arrKol[SECOND_ORDER];
					$lastName	= $arrKol[THIRD_ORDER];
					
					$fullName	= $firstName;
					if(!empty($middleName))
						$fullName	.= ' '. $middleName;
					if(!empty($lastName))
						$fullName	.= ' '. $lastName;									
				?>										
				<p class="kolName">
					<?php echo $salutation.' '.$this->common_helper->get_name_format($firstName,$middleName,$lastName);?>
					<br>
				</p>
		        <div class="speciality">(&nbsp;BDSc,  MA,  PhD,  MRACDS(DPH),  FICD	&nbsp;)</div>
		        <br>
                <?php if($arrKol['do_not_call_flag'] == "1") { ?>
                <div><p style="color: red;font-size: 11px;margin: -4px 0px 0px 0px;">Do Not Call</p></div>
                <?php } ?>
		        <table id="kolAdressInfo">
					<tbody>
					<!------------------specialty----------------------------------------->
						<?php if($arrKol['specialty'] != ''){?>
						<tr>
							<th style="width: 30px;">
								<div class="kolSpecialty sprite_iconSet">
								<a href="#" class="tooltipLink" rel='tooltip' title="Specialty" style="cursor: default;">&nbsp;</a>
								</div>
							</th>
							<th><?php echo $arrSpecialties[$arrKol['specialty']];?><br/><span style="font-weight: normal;"><?php echo implode(", ",$arrSubSpecialties); ?></span></th>
						</tr>
						<?php }?>
					<!---------------------kolDesignation-------------------------------->
						<?php if($arrKol['title'] != ''){?>
						<tr>
							<th>
								<div class="kolDesignation sprite_iconSet">
									<a href="#" class="tooltipLink" rel='tooltip' title="Position/Department" style="cursor: default;">&nbsp;</a>
								</div>
							</th>
							<th>
								<?php 
									//echo $arrKol['title'];
									if($arrKol['title'] == '1')
										echo "Advocacy";
									elseif($arrKol['title'] == '2')
										echo "C Suite CEO/CFO/COO";
									elseif($arrKol['title'] == '3')
										echo "Case Manager";
									elseif($arrKol['title'] == '4')
										echo "Chief Medical Officer/Clinical Affairs";
									elseif($arrKol['title'] == '5')
										echo "Consultant";
									elseif($arrKol['title'] == '6')
										echo "Dentist";
									else
										echo $arrKol['title'];
									if($arrKol['division'] != '' && $arrKol['division'] != '0'){
										echo '<br />'.$arrKol['division'];
									}
								?>
							</th>
						</tr>
						<?php }else if(!empty($arrKol['division']) && $arrKol['division'] != '0'){?>
						<tr>
							<th>
								<div class="kolDesignation sprite_iconSet">
									<a href="#" class="tooltipLink" rel='tooltip' title="Position/Department" style="cursor: default;">&nbsp;</a>
								</div>
							</th>
							<th>
								<?php echo $arrKol['division'];?>
							</th>
						</tr>
						<?php }?>
					<!--------------------------org_name--------------------------------->
					<?php if($arrKol['org_name'] != '' && $arrKol['org_id'] != ''){?>
						<tr>
							<th>
								<div class="kolOrg sprite_iconSet">
									<a href="#" class="tooltipLink" rel='tooltip' title="Institution Name" style="cursor: default;">&nbsp;</a>
								</div>
							</th>
							<th>
							<?php //if($this->organization->isOrgLinkAllowed($arrKol['org_id'])) {?>
							<?php if(true) {?>
								<a href="<?php echo base_url() ?>organizations/organizations/view/<?php echo $arrKol['org_id']?>"><?php echo $arrKol['org_name'];?></a>
							<?php } else {?>
								<?php echo $arrKol['org_name'];?>
							<?php } ?>
							</th>
						</tr>
					<?php } else {?>
                        <tr>
							<th>
								<div class="kolOrg sprite_iconSet">
									<a href="#" class="tooltipLink" rel='tooltip' title="Institution Name" style="cursor: default;">&nbsp;</a>
								</div>
							</th>
							<th>
								<?php echo $arrKol['private_practice'];?>
							</th>
						</tr>
					<?php }?>
					<!------------------------------edit button---------------------------->
						<tr>
							<td colspan="2">												
								<?php if($this->common_helper->isActionAllowed('kol','edit',$arrKol)){ ?>
									<div class="tooltip-demo tooltop-bottom" style="float: right;">
										<a type="button" id="editKTL" style="text-decoration: none;" rel="tooltip" href="<?php echo base_url();?>kols/kols/add_kol/<?php echo $arrKol['kols_client_visibility_unique_id'];?>" class="btn custom-btn" title="Edit Contact">Edit Contact</a>
									</div>
								<?php }?>
							</td>
						</tr>
						<!----------------------------CRM------------------------------>
						<?php if(CRM_LABEL){?>
							<?php if(!empty($arrKol['external_profile_id'])) {?>
							<tr>
								<td colspan="2" class="vAlignTop">
									<p class="addrHeading">CRM #</p>
									<p><?php echo $arrKol['external_profile_id'];?></p>
								</td>
							</tr>
							<?php } ?>
						<?php } ?>
						<!----------------------------Address------------------------------>
						<tr>
							<td colspan="2">
								<p class="addrHeading">Address</p>
									<?php
										if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
											echo "<p>".$arrKol['address1'].",</p>";
										if(!empty($arrKol['address2']) && isset($arrKol['address2']))
											echo "<p>".$arrKol['address2'].",</p>";
									 
									?>
									<p><?php
										if(isset($arrKol['city_name']))
											echo $arrKol['city_name'].', ';
										if($arrKol['country_name']=='Canada' || $arrKol['country_name']=='United States')
											echo $stateCode[0]['state_code']. " ". $arrKol['postal_code'];
										else if($arrKol['state_name']!='' && $arrKol['postal_code']!='')
											echo $arrKol['state_name']. " ". $arrKol['postal_code'];
										else
											echo $arrKol['state_name'];
									?></p>
									<?php 
									if(isset($arrKol['country_name']))
										echo "<p>".$arrKol['country_name']."</p>";
									?>
							</td>
						</tr>
						<!-------------------------Email---------------------------------->
						<?php if(!empty($arrKol['primary_email'])) {?>
						<tr>
							<td colspan="2">
								<p class="addrHeading">Email</p>
								<p><a id="emailIdLink" href="mailto:<?php echo $arrKol['primary_email'];?>"><?php echo $arrKol['primary_email'];?></a></p>
							</td>
						</tr>
						<?php }?>
						<!----------------------------Phone------------------------------>
						<?php if(!empty($arrKol['primary_phone'])) {?>
						<tr>
							<td colspan="2">
								<p class="addrHeading">Phone</p>
								<p><?php echo '<a class="linkClickToCall" href="callto:'.$arrKol['primary_phone'].'" >'.$arrKol['primary_phone'].'</a>';?></p>
							</td>
						</tr>
						<?php } ?>
						<!------------------------fax---------------------------------->
						<?php if(!empty($arrKol['fax'])) {?>
						<tr>
							<td colspan="2">
								<p class="addrHeading">Fax</p>
								<p><?php echo '<a class="linkClickToCall" href="callto:'.$arrKol['fax'].'" >'.$arrKol['fax'].'</a>';?></p>
							</td>
						</tr>
						<?php } ?>
						<!----------------------------------------------------------->
					</tbody>
				</table>
			</div>
			</div>
			<div class="col-md-8" style="padding:0px 5px">
				<div id="bio_research" class="div_with_border">
								<h1>Profile Summary</h1>
								<p><?php $this->load->view('kols/automated_biography',$data);?></p>
				</div>
			</div>
		</div>
		<div class="row row-padding">
			<div class="col-md-12">
				<p class="title">USER NOTES</p>
				<div id="notes-container">
							<table class="table">
								<?php foreach($arrNotes as $note){?>
								<tr id="<?php echo $note['id'];?>">
								<td width="60%">
								<input type="hidden" name="orginal_doc_name" id="orginal_file_<?php echo $note['id'];?>" value="<?php echo $note['orginal_doc_name'] ?>" data-docname="<?php echo $note['document_name']?>"/>
								<div id="container-<?php echo $note['id'];?>">
									<?php if(strlen($note['note']) >= 400){?>
											<span class="<?php echo $note['id'];?> halftext"><?php echo substr($note['note'],0,400)."...";?></span>
											<span class="<?php echo $note['id'];?> fulltext a"><?php echo $note['note'];?></span>
										<?php }else{?>
											<span class="<?php echo $note['id'];?>"><?php echo $note['note'];?></span>
										<?php }?>
										<?php if($note['orginal_doc_name']!=''){ ?>
										<div >Uploaded document: <gg id="uploadedFile_<?php echo $note['id']; ?>"><?php echo $note['document_name']?></gg></div>
									<?php } ?>
									<?php if($note['modified_by'] > 0 && $note['modified_by'] != ''){?>
										<div >Modified by: <?php if($note['modif_id']!=INTERNAL_CLIENT_ID) echo $note['modified_by_first_name']." ".$note['modified_by_last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['modified_on']));?></div>
									<?php }else{ 
									    if(KOL_CONSENT){?>	
										<div >Posted by: <?php if($note['is_from_opt_in'] == 0) { if($note['post_id']!=INTERNAL_CLIENT_ID) echo $note['first_name']." ".$note['last_name']; else echo 'Aissel Analyst';}else{ echo $arrKol['first_name']." ".$arrKol['last_name'];}?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on'])); if($note['is_from_opt_in'] == 0) echo '';else echo 'via Opt-in';?></div>
									<?php }else {?>
										<div >Posted by: <?php if($note['post_id']!=INTERNAL_CLIENT_ID) echo $note['first_name']." ".$note['last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on']));?></div>
									<?php } }?>
									<?php if($note['orginal_doc_name']!=''){ ?>
										<a href="<?php echo base_url(); ?>kols/kols/note_document_download/<?php echo $note['id'];?>" class="tooltipLink" rel="tooltip">
										<div class="actionIcon downloadIcon tooltip-demo tooltop-left">
										<div style="margin-top: 22%;">Download file</div>
										</div>
										</a>
									<?php } ?>
								</div>
								</td>
								<td width="40%" id="editDeleteDiv-<?php echo $note['id'];?>">
									<?php if($this->common_helper->isActionAllowed("user_notes","edit",array("created_by"=>$note['created_by']))){?>
										<div class="notes-actions">
											<div class="actionIcon deleteIcon tooltip-demo tooltop-left pull-right" onclick="deleteNote(<?php echo $note['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>
											<div class="actionIcon editIcon tooltip-demo tooltop-left pull-right" onclick="editNote(<?php echo $note['id'];?>); return false;"><a title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>
										</div>
									<?php }?>
								</td>
								</tr>
								<?php }?>
							</table>
						</div>
					<form class="form-inline" id="saveNote" method="post" action="#">
						<h6 style="margin-bottom: 0;font-weight:bold;">Add Note</h6>
						<div id="add-notes-area">
							<textarea onkeydown="limitText(this,'notesCountDown',200);" onkeyup="limitText(this,'notesCountDown',200);" rows="2" style="width:100%;" id="user-note" name="user_note" placeholder="Enter notes..."></textarea>
							<div>You have <span id="notesCountDown">200</span> characters left. <font size="1">(Maximum characters: 200)</font></div>
						</div>
						<div class="subnotes" style="display:none;">
            				<div class="form-group">
							    <label style="margin-left:0 !important">Attach File:</label>
							    <input class="form-control" type="text" name="fileName" id="file_name" value="" placeholder="Enter file name">
						  	</div>
							  <div class="form-group">
							    <input class="form-control" type="file" name="note_file" id="noteFile" value="">
							  </div>
            				<button type="submit" class="btn btn-default" id="saveBtn">Save</button>
            			</div>
					</form>
				</div>
		</div>
		<div class="gridWrapper" id="allInteractionGridContainer">
			<table id="JQBlistAllInteractionResultSet"></table>
			<div id="listAllInteractionPager"></div>
		</div>
		<div class="row row-padding">
			<a type="button" class="btn custom-btn" style="float:right;" onclick="addClientEducation();return false;">
				Add data
			</a>
		</div>	
		<div class="gridWrapper row-padding" id="gridEduContainer">
         	<div id="listEducationDetailsPage"></div>
            <table id="JQBlistEducationDetails"></table>
        </div>
        <div class="gridWrapper row-padding" id="gridHonorsAwardsContainer">
			<div id="listHonorsAwardsDetailsPage"></div>
			<table id="JQBlistHonorsAwardsDetails"></table>
		</div>
		<div class="gridWrapper row-padding" id="allAfiliationGridContainer">
			<table id="JQBlistAllResultSet"></table>
			<div id="listAllPager"></div>
		</div>	
		<div class="gridWrapper row-padding" id="confGridContainer">
			<table id="JQBlistConferenceResultSet"></table>
			<div id="listConferencePage"></div>
		</div>
		<div class="gridWrapper row-padding" id="gridContainer1">
			<div id="serchPublicationPage"></div>
			<table id="JQBlistSearchResultSet"></table>
		</div>
		<div class="gridWrapper clear" id="clinicalGridContainer">
			<table id="JQBlistClinicalTrialsResultSet"></table>
			<div id="listlistClinicalTrialsPage"></div>
		</div>
		<div id="clientEduDailog">	
			<div id="clientEduAddContainer" class="microProfileDialogBox">
				<div class="profileContent" id="clientEduAddProfileContent"></div>
			</div>
		</div>
<script type="text/javascript">
//var kolId="<?php //echo $arrKol['id'];?>";
var kolId="<?php echo $arrKol['kols_client_visibility_id'];?>";
var uniqueId="<?php echo $arrKol['kols_client_visibility_unique_id'];?>";
var is_events_module_enabled='<?php echo $this->common_helper->check_module("events");?>';
var is_publication_module_enabled='<?php echo $this->common_helper->check_module("pubmeds");?>';
var is_clinical_trail_module_enabled='<?php echo $this->common_helper->check_module("clinical_trials");?>';
var is_interaction_module_enabled='<?php echo $this->common_helper->check_module("interactions");?>';
$(document).ready(function (){
	listHonorsAwardsDetails();
	listEducationDetails();
	allAfiliationResult();
	if(is_events_module_enabled){
		getConferenceList();
	}
	if(is_publication_module_enabled){
		searchPublications();
	}
	if(is_clinical_trail_module_enabled){
		listClinicaltrials();
	}
	if(is_interaction_module_enabled){
		allInteractionResult();
	}
	$( "#user-note" ).focus(function() {
	  	  $('.subnotes').show('slow');
	  });
	  $( "#user-note" ).focusout(function() {
		    if($.trim($(this).val())==''){	
		  	  $('.subnotes').hide('slow');
		    }  
	  });
    $("form#saveNote").submit(function(){
    	var noteVal = $.trim($("#user-note").val());
    	if(noteVal.length > 200){
    		jAlert("Note is too long. Max 200 characters allowed");
    		return false;
    	}
    	if(noteVal == ''){
    		jAlert("Note should not be empty");
    		return false;
    	}	    	
        var formData = new FormData($(this)[0]);
        console.log(formData);
    	var data = {};
    	data['note'] = noteVal;
    	$('#saveBtn').attr('disabled','disabled');    	    	
    	$('#saveBtn').text('Processing...');
    	$.ajax({
    		url:base_url+'kols/kols/save_notes/'+kolId,
    		type:'post',
    		dataType:'json',
    		data: formData,
    		async: false,
    		cache: false,
	        contentType: false,
	        processData: false,
    		success:function(returnData){
    			$('#notesCountDown').html('200');
    			if(returnData.id>0){
    				var newNotesText = "<tr id='"+returnData.id+"'>";
    				newNotesText += '<td width="60%">';	
    				 newNotesText +='<input type="hidden" id="orginal_file_'+returnData.id+'" value="'+returnData.orginal_doc_name+'" data-docname="'+returnData.document_name+'" />';
    				newNotesText += '<div id="container-'+returnData.id+'">';
    				newNotesText += '<span class="'+returnData.id+'">'+$("#user-note").val()+'</span>';
    				if(returnData.document!=''){
    					newNotesText += '<div >Uploaded document: <gg id="uploadedFile_'+returnData.id+'">'+returnData.document_name+'</gg></div>';
    				}
    				newNotesText += '<div >Posted by: '+returnData.name+', '+returnData.created_on+'</div>';

    				if(returnData.document!=''){
    					newNotesText += '<a href="'+base_url+'kols/kols/note_document_download/'+returnData.id+'" class="tooltipLink" rel="tooltip" ><div class="actionIcon downloadIcon tooltip-demo tooltop-left"><div style="margin-top: 22%;">Download file</div></div></a>';
    				}
    				newNotesText += '</div>';
    				newNotesText += '</td><td width="40%">';
    				newNotesText += '<div class="notes-actions">';
    				newNotesText += '	<div class="actionIcon deleteIcon tooltip-demo tooltop-left pull-right" onclick="deleteNote('+returnData.id+'); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>';
    				newNotesText += '	<div class="actionIcon editIcon tooltip-demo tooltop-left pull-right" onclick="editNote('+returnData.id+'); return false;"><a title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;';
    				newNotesText += '</div>';
    				newNotesText += "</td></tr>";

    				$("#notes-container table").prepend(newNotesText);
    				$(".subnotes").hide('slow');
    				$("#user-note").val('');
    				$("#saveNote").trigger('reset');
    			}
    		},
    		complete: function() {
    			$('#saveBtn').removeAttr('disabled');
    	    	$('#saveBtn').text('Save');
    		}			
    	});
        return false;
    });
    // Settings for the Client Education Dialog Box
    var clientEducationAddOpts = {
        title: "EDUCATION",
        modal: true,
        autoOpen: false,
        width: 800,
        dialogClass: "microView",
        position: ['center', 155],
        open: function () {
            //display correct dialog content
        }
    };
    $("#clientEduAddContainer").dialog(clientEducationAddOpts);
});
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		$('#'+limitCount).html(limitNum - limitField.value.length);
	}
}
function editNote(id){
	$('#add-notes-area').hide('slow');
	var count	= 200-parseInt($.trim($("."+id).text()).length);
	var display='';
	var attfile='';
	var newNotesText = '<td colspan="2"><form id="updateform_'+id+'" class="form-inline"><div id="container-'+id+'">';
	newNotesText += '<textarea onKeyDown="limitText(this,\'notesCountDown'+id+'\',200);" onKeyUp="limitText(this,\'notesCountDown'+id+'\',200);" class="editTextarea" name="user_note" style="width:100%;" rows="3" placeholder="Enter notes...">'+$.trim($("."+id).text())+'</textarea>';
	newNotesText += '<div>You have <span id="notesCountDown'+id+'" class="notesCountDown">'+count+'</span> characters left. <font size="1">(Maximum characters: 200)</font></div><br>';
	if($("#orginal_file_"+id).val()!=''&& $("#orginal_file_"+id).val()!='undefined'){			
		display = "display:none";
		var org_file = $("#orginal_file_"+id).val();
		attfile = '<lable style="padding: 5px;background: #ccc;" id="att_'+id+'">'+org_file.replace(/%20/g, " ")+' <b style="font-size: 18px;margin-left: 15px;vertical-align: middle;cursor:pointer" onclick="deleteNoteAttachment('+id+')">&times;</b></lable>'
	}
	newNotesText +='<p><label style="margin-left: 0 !important">Attache File: </label><input class="form-control" type="text" name="fileName" id="file_name" value="'+$.trim($("#uploadedFile_"+id).text())+'" placeholder="Enter file name"/><lable style="'+display+'" id="attsec_'+id+'"><input type="file" class="form-control" name="note_file" id="noteFile" value="" size="40"></lable></span>'+attfile+'</p>'; 
	newNotesText += '<div class="notes-actions">';
	newNotesText += '<a type="button" class="btn custom-btn" rel="tooltip" title="Save" onclick="updateNote('+id+'); return false;">Save</a>';
	newNotesText += '<a type="button" class="btn custom-btn" rel="tooltip" title="Cancel" onclick="cancelNote('+id+'); return false;">Cancel</a>';
	newNotesText += '</div>';
	newNotesText += '</div></form></td>';
	$("#"+id).html(newNotesText);
	$("#editDeleteDiv-"+id).css('display','none');
}
function deleteNoteAttachment(id){
	jConfirm("Are you sure want to delete attachment?","Confirm message",function (r){
		if(r){
			$.ajax({
				url:base_url+'kols/kols/delete_notes_attachment/'+id,
				type:'post',
				dataType:'json',
				success:function(returnData){
					if(returnData.status){
						$('#file_name').val('');
						$("#att_"+id).hide();
						$("#attsec_"+id).show();
						$("#orginal_file_"+id).val('');
						$("#orginal_file_"+id).attr('data-docname','');
					}else{
						jAlert("Unable to delete");
					}
				}
			});
			return false;
		}
	});
}
function deleteNote(id){
	jConfirm("Are you sure want to delete note?","Confirm message",function (r){
		if(r){
			$.ajax({
				url:base_url+'kols/kols/delete_notes/'+id,
				type:'post',
				dataType:'json',
				success:function(returnData){
					if(returnData.status){
						$("#"+id).remove();
					}else{
						jAlert("Unable to delete");
					}
				}
			});
			return false;
		}
	});
}
function cancelNote(id){
	$.ajax({
		url:base_url+'kols/kols/get_notes_by_id/'+id,
		type:'post',
		dataType:'json',
		success:function(returnData){
			if(returnData.id){
				var newNotesText = "<tr id='"+returnData.id+"'>";
				newNotesText += '<td width="60%">';	
				newNotesText +='<input type="hidden"  name="orginal_doc_name" id="orginal_file_'+returnData.id+'" value="'+returnData.orginal_doc_name+'" data-docname="'+returnData.document_name+'" />';
				newNotesText += '<div id="container-'+returnData.id+'">';				
				newNotesText += '<span class="'+returnData.id+'">'+returnData.note+'</span>';

				if(typeof returnData.document!=='undefined' && returnData.document!==''){
					newNotesText += '<div>Uploaded document: <gg id="uploadedFile_'+returnData.id+'">'+returnData.document_name+'<gg></div>';
				}
				newNotesText += '<div class="notes-details">Posted by: '+returnData.name+', '+returnData.created_on+'</div>';
				if(typeof returnData.document!=='undefined' && returnData.document!==''){
					newNotesText +='<a href="'+base_url+'kols/kols/note_document_download/'+id+'" class="tooltipLink" rel="tooltip"><div class="actionIcon downloadIcon tooltip-demo tooltop-left"><div style="margin-top: 22%;">Download file</div></div></a>';
				}
				newNotesText += '</div>';
				newNotesText += '</td>';

				newNotesText += '<td width="40%" id="editDeleteDiv-'+returnData.id+'">';	
				newNotesText += '<div class="notes-actions">';
				newNotesText += '<div class="actionIcon deleteIcon tooltip-demo tooltop-left pull-right" onclick="deleteNote('+returnData.id+'); return false;"><a class="tooltipLink" rel="tooltip" title="Delete"></a></div>';
				newNotesText += '<div class="actionIcon editIcon tooltip-demo tooltop-left pull-right" onclick="editNote('+returnData.id+'); return false;"><a title="Edit" class="tooltipLink" rel="tooltip"></a></div>';
				newNotesText += '</div>';
				newNotesText += '</td>';
				newNotesText += "</tr>";
				$("#"+id).replaceWith(newNotesText);
			}
		}
	});
	var l = $("#notes-container tr form").length;
	if(l==1) $('#add-notes-area').show('slow');
}
function updateNote(id){
	var textAreaVal = $("#container-"+id).children("textarea").val();
	var noteVal = $.trim(textAreaVal)
	if(noteVal.length > 200){
		jAlert("Note is too long. Max 200 characters allowed");
		return false;
	}
	if(noteVal == ''){
		jAlert("Note should not be empty");
		return false;
	}
	var data = {};
	data['note'] = noteVal;
	var formData = new FormData($('#updateform_'+id)[0]);
	var orginal_doc_name = $("#orginal_file_"+id).val();
	if(orginal_doc_name==''){
		orginal_doc_name = 'undefined';
	}
	$.ajax({
		url:base_url+'kols/kols/update_notes/'+id+'/'+orginal_doc_name+'/'+kolId,
		type:'post',
		dataType:'json',
		data: formData,
		async: false,
		cache: false,
        contentType: false,
        processData: false,		
		success:function(returnData){
			$('#notesCountDown').html('200');
			if(returnData.id){
				var doc_name = returnData.document_name;
				$('#orginal_file_'+returnData.id).val(returnData.orginal_doc_name);
				if(typeof doc_name !== "undefined"){
					$('#orginal_file_'+returnData.id).attr('data-docname',doc_name);					
				}else{
					doc_name = $('#orginal_file_'+returnData.id).attr('data-docname');
				}
				
				var newNotesText = '<tr id="'+returnData.id+'">';
				newNotesText += '<td width="60%">';
				newNotesText += '<input type="hidden" name="orginal_doc_name" id="orginal_file_'+returnData.id+'" value="'+returnData.orginal_doc_name+'" data-docname="'+returnData.document_name+'">';
				newNotesText += '<div id="container-'+returnData.id+'">';
				newNotesText += '<span class="'+returnData.id+'">'+returnData.note+'</span>';
				
				if(((returnData.orginal_doc_name!='undefined') && returnData.orginal_doc_name!=='') || ((typeof returnData.document_name!=='undefined')&&returnData.document_name!='')){
					newNotesText += '<div>Uploaded document: <gg id="uploadedFile_'+returnData.id+'">'+doc_name+'</gg></div>';
				}
				newNotesText += '<div>Modified by: '+returnData.name+', '+returnData.created_on+'</div>';
				if(((returnData.orginal_doc_name!='undefined') && returnData.orginal_doc_name!=='') || ((typeof returnData.document_name!=='undefined') && returnData.document_name!='')){
					newNotesText += '<a  href="'+base_url+'kols/kols/note_document_download/'+returnData.id+'" class="tooltipLink" rel="tooltip"><div class="actionIcon downloadIcon tooltip-demo tooltop-left"><div style="margin-top: 22%;">Download file</div></div></a>';
					}
				newNotesText += '</div>';
				newNotesText += '</td>';
				newNotesText += '<td width="40%" id="editDeleteDiv-'+returnData.id+'">';
				newNotesText += '<div class="notes-actions">';
				newNotesText += '	<div class="actionIcon deleteIcon tooltip-demo tooltop-left pull-right" onclick="deleteNote('+returnData.id+'); return false;"><a class="tooltipLink" rel="tooltip" title="Delete"></a></div>';
				newNotesText += '	<div class="actionIcon editIcon tooltip-demo tooltop-left pull-right" onclick="editNote('+returnData.id+'); return false;"><a title="Edit" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;';
				newNotesText += '</div>';
				newNotesText += '</td>';
				newNotesText += '</tr>';
				$("#"+id).replaceWith(newNotesText);
				$('#add-notes-area').show('slow');
			}
		}			
	});
    return false;	
}
function saveTrainingDetail(){
	if(!$("#trainingForm").validate().form()){
		return false;
	}else{
		disableButton("saveTraining");
		// Check if the Institute Name is present in Master table or not
		instituteName	=	$("#trainInstituteName").val(); 
		// URL to get the Institute ID, if Name is present
		urlAction = base_url+'kols/kols/get_institute_id_else_save/'+instituteName;
		// Variable to hold the Institute Id
		instituteId	= '';
		$.post(urlAction,{name:instituteName},
				function(returnData){
					if(returnData){
						instituteId	= returnData;
						$("#trainInstituteNameNotFound").hide();
						saveTrainingDetails(instituteId);
					}else{
						enableButton("saveTraining");
						$("#trainInstituteNameNotFound").show();
						// Set the user entered name in the 'Add New Institute' form
						$("#instituteName").val(instituteName);
						return false;
					}
				}, 
				"json");
	}
}
function disableButton(buttonId){
	$("#"+buttonId).attr("disabled", "disabled");
}
function enableButton(buttonId){
	$("#"+buttonId).removeAttr("disabled");
}
function saveHonorNAwards(){
	if(!$("#awardForm").validate().form()){
		return false;
	}else{
		disableButton("saveAward");
		var name = $("#awardHonorName").val();
		var startDate =$("#awardStartDate").val();
		var endDate =$("#awardEndDate").val();
		if(startDate!='' && endDate!=''){
			if(startDate<=endDate){
				saveDetails('award','awardForm','JQBlistAwardResultSet','saveAward');
			}else{
				$("#awardDate").show();
				enableButton("saveAward");
			}
		}else{
			saveDetails('award','awardForm','JQBlistAwardResultSet','saveAward');
		}
	}
}	
function allowNumericOnly(src) {
	if(!src.value.match(/^\d{4}$/)) {
		src.value=src.value.replace(/[^0-9]/g,'');  
	}
}
function saveTrainingDetails(instituteId){
	$("#trainInstituteId").val(instituteId);
	var startDate =$("#trainStartDate").val();
	var endDate =$("#trainEndDate").val();
	if(startDate!='' && endDate!=''){
		if(startDate<=endDate){
			saveDetails('train','trainingForm','JQBlistTrainingResultSet','saveTraining',instituteId,'train');
		}else{
			$("#trainDate").show();
			enableButton("saveTraining");
		}
	}else{
		saveDetails('train','trainingForm','JQBlistTrainingResultSet','saveTraining',instituteId,'train');
	}
}
function saveDetails(idType,formId,gridId,btnId,instituteId,divId){
	$('div.eduMsgBox').removeClass('success');
	$('div.eduMsgBox').addClass('notice');
	$('div.eduMsgBox').show();
	$('div.eduMsgBox').html('Saving the data... <img src="<?php echo base_url()?>assets/images/ajax_loader_black.gif" />');
	if(idType!='award')
		$("#"+idType+"InstituteId").val(instituteId);				
	//If Institute Id is present then perform save or update
	id = $("#"+idType+"Id").val();
	if(id == ''){
		formAction = '<?php echo base_url();?>kols/kols/save_education_detail';
	}else{
		formAction = '<?php echo base_url();?>kols/kols/update_education_detail';
	}	
	 $.post(formAction, $("#"+formId).serialize(),
			 function(returnData){
	     		if(returnData.saved == true){
			     	enableButton(btnId);
					listHonorsAwardsDetails();
					listEducationDetails();
			     	setTimeout($("#clientEduAddContainer").dialog("close"), 1500);
		     	}else{
			     	enableButton(btnId);
			     }
			},"json");								
}	
</script>
