<?php
/*
 * To display Publications By Keywords in chart 
 *  
 * @Author		: Vishwanath
 * @since 		: Colpal v1.0
 * Created on	: 23-08-2016
 *  
 */

?>
	<style type="text/css">
		#asmtScoreReport .alignLeft{
			padding-right:5px;
			width:62px;
		}
		#asmtScoreReport .asmtScoreCategoryBar .progress{
			height: 15px;
		}
		#asmtScoreReport td.asmtScoreCategoryBar{
			width: 194px !important;
		}
		#asmtScoreReport .asmtScoreCategoryBar .filterBar .progress .bar{
			-moz-box-sizing: border-box;
			background-color: #F8F800;
			background-image: -moz-linear-gradient(center top, #F8F800, #F8F800);
			background-color: #89A54E;
    		background-image: -moz-linear-gradient(center top , #89A54E, #89A54E);
    		background-color: #618CBE;
    		background-image: -moz-linear-gradient(center top , #618CBE, #4572A7);
			background-repeat: repeat-x;
			color: #FFFFFF;
			font-size: 12px;
			height: 15px;
			text-align: center;
			text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
			width: 0;
		}
		.pieCharts div{
		  margin:0;
		}
	</style>
	<table id="asmtScoreReport">
	<?php 	
		if(sizeof($journalsCategories)>0){
			foreach($journalsCategories as $key=>$row){
			 $per = ($journalsData[$key]/$journalsData[0])*100;
			 $rowlink = str_replace("'","\'",$row);
	?>				
				<tr>					
					<td class="alignRight"><?php echo $row;?></td>
					<td class="asmtScoreCategoryBar">
						<div class="filterBar" onclick="showPublicationsForBarLink('type','<?php echo $rowlink ?>')">
							<div class="progress" title="<?php echo $row.':'.$journalsData[$key];?>">
								<div class="bar" style="width: <?php echo $per;?>%"></div>
							</div>
						</div>
					</td>
					<td class="alignLeft"><?php echo $journalsData[$key];?></td>
				</tr>
	<?php 
			}
		}
	?>
	</table>