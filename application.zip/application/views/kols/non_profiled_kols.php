<?php
$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<script type="text/javascript">
jqgridIds	= new Array('nottRequestedKolResultSet');
jqgridMinWidth	= 1010;
jqgridMaxWidth	= 1305;
	$(document).ready(function(){
		notRequesetdKOls();
		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#newKolProfile").dialog(addNewKol);

		var addNewMycustomer = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#myCustomer").dialog(addNewMycustomer);

		$("#newKolProfile").dialog(addNewKol);

		var editdMycustomer = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#editMyCustomer").dialog(editdMycustomer);
	
	});
	function checkDuplicates(KolId){
		$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		//$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		//$(".newProfileContent").find('.msgbox').append('<div id="similarNames"></div>');
		$(".newProfileContent").html('<div class="msgBox"></div><div id="similarNames"></div>');
		$('.msgBox').removeClass('success');
		$('.msgBox').addClass('notice');
		$('.msgBox').show();
		$('.msgBox').html("Please wait while we check if the name already exists in the database. <img src='<?php echo base_url()?>images/ajax_loader_black.gif' />");
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/check_similar_names/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.hasDuplicates){
					$('.msgBox').text("Similar Names found");
					$('.msgBox').fadeOut(1500);
					$("#similarNames").html(returnData.duplicates);
					var currentName = $("#first_name").val();
					if($("#middle_name").val() != '')
						currentName = currentName+" "+$("#middle_name").val();
					if($("#last_name").val() != '')
						currentName = currentName+" "+$("#last_name").val();
					$("#requestName label").html(currentName);
					$("#addNewKol").dialog('option','width',750);
					$("#addNewKol").dialog('option','position',['center', 80]);
					$("#requestKolForm").fadeOut(1500,function(){
						$("#addNewKol").dialog('option','position',['center', 80]);
					});
				}else{
					$('.msgBox').text("No duplicates found");
					requestProfile(KolId);
					$("#newKolProfile").dialog("close");
				}
			}
		});
	};
	function requestProfile(KolId){
		var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
					//jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
					window.location = '<?php echo base_url()?>requested_kols/show_client_requested_kols';
					//notRequesetdKOls();
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
	}
	function addNewKolProfile(KolId){
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		requestProfile(KolId);
		return false;	
	}

	function deleteNonRequestededKol(kolId){

		var formAction ='<?php echo base_url();?>requested_kols/delete_requested_kol/'+kolId;
		jQuery("#nottRequestedKolResultSet").jqGrid('delGridRow',kolId,{reloadAfterSubmit:false,url:formAction}); 
		//$("#delmodnottRequestedKolResultSet").addClass("gridConfirmFormCenterAlign");
		$("#delmodnottRequestedKolResultSet").center();
	}

	function notRequesetdKOls(){
		$("#notRequestedGridContainer").html("");

		// Append the required div and table
		$("#notRequestedGridContainer").html('<table id="nottRequestedKolResultSet"></table><div id="notRequestedRequestPager"></div>');

		var ele=document.getElementById('notRequestedGridContainer');
		var gridWidth=ele.clientWidth;
	
	jQuery("#nottRequestedKolResultSet").jqGrid({
	   	url:'<?php echo base_url()?>requested_kols/list_not_requested_kols_grid/',
		datatype: "json",
	 	colNames:['Id','','','Name','Organization','Specialty','Country', 'Phone', 'Email','Created By ','Status','Request Profile','Action'],
	   	colModel:[
					{name:'kol_id',index:'kol_id', hidden:true},
					{name:'created_by',index:'created_by', hidden:true},
					{name:'micro',index:'micro',width:40,search:false},
					{name:'kol_name',index:'kol_name',width:200 },
					{name:'name',index:'name',width:200},
			   		{name:'specialty',index:'specialty',width:150, resizable:false},
			   		{name:'country',index:'country',width:150, resizable:false},
			   		{name:'primary_phone',index:'primary_phone',width:100, resizable:false},
			   		{name:'primary_email',index:'primary_email',width:155, resizable:false},
			   		{name:'user_full_name',index:'user_full_name',width:175, resizable:false},
			   		{name:'status',index:'status',width:125, resizable:false},
			   		{name:'request_profile',index:'request_profile',width:180,search:false,resizable:false,align:'right',sortable:false},
			   		{name:'act',resizable:false,search:false,width:100,align:'left',sortable:false}	
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#notRequestedRequestPager',
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"Contacts",
	   	rowList:paginationValues,
	    gridComplete: function(){ 
	    	
			var userId = <?php echo $this->session->userdata('user_id')?>;
			var clientId = <?php echo $this->session->userdata('client_id')?>;
	   		var ids = jQuery("#nottRequestedKolResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    		
			    	var cl = ids[i];				    	
			    	var rowData = jQuery("#nottRequestedKolResultSet").jqGrid('getRowData', cl);
			    			var profileRequest	= '';
			    			var action	= '';
			    			if(rowData.request_profile==1){
			    				profileRequest	= '<button onclick="addNewKolProfile('+rowData.kol_id+')">Request</button>';
			    				jQuery("#nottRequestedKolResultSet").jqGrid('setRowData',ids[i],{request_profile:profileRequest});
			    			}
					    	//be = "<a href='#' onclick=\"deleteUniversity('"+cl+"');\" ><img title='Delete' src='"+base_url+"images/delete.png'></a>";
							if(userId==rowData.created_by){
								action = "<div style='margin-right: 10px;'><label><div class='actionIcon editIcon tooltip-demo tooltop-left' onclick=\"edit('"+cl+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\"></a></div></label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteNonRequestededKol('"+cl+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></label></div>";
						    	jQuery("#nottRequestedKolResultSet").jqGrid('setRowData',ids[i],{act:action});
					    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";
							}
				    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+cl+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
					    	jQuery("#nottRequestedKolResultSet").jqGrid('setRowData',cl,{micro:microviewLink}); 
	    	}
    	jQuery("#nottRequestedKolResultSet").jqGrid('navGrid','hideCol',"id"); 
    	//Initialize the tooltips
    	<?php $mobile = mobile_device_detect(); 
		if(!isset($mobile[1])){	?>			
			initializeCustomToolTips();
		<?php }?>
    	}
	});
	//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#nottRequestedKolResultSet").jqGrid('navGrid','#notRequestedRequestPager',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#nottRequestedKolResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	//Toolbar search bar above the Table Headers
	
	//Toggle Toolbar Search 
	
//jQuery("#nottRequestedKolResultSet").jqGrid('setGridWidth',gridWidth);
	}

	function showFormToAddKol(){
		$(".myCustomerContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#myCustomer").dialog("open");
		$(".myCustomerContent").load(base_url+'requested_kols/add_my_customer_kol/');
		return false;	

	}

	function edit(kolId){
		$(".myCustomerContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#myCustomer").dialog("open");
		$(".myCustomerContent").load(base_url+'requested_kols/edit_my_customer/'+kolId);
		return false;	
	}

	function viewKolMicroProfile(kolId){
			
		//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
		//	$("#interactionMicroProfile").dialog("open");
		//	$(".profileContent").load(base_url+'interactions/view_micro_interaction/'+interactionId);
		//	return false;
			var elmt=document.getElementById(kolId);	
			var pos = getElementAbsolutePos(elmt);
			var offset = $("#"+kolId).offset();
			var height = $("#"+kolId).height();
			var xPos=pos.x+65;
			var yPos=offset.top + height - 48;//pos.y-25;
			//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
			//$("#callOutTest").show();
			$("#arraouHolder").css({'position': 'absolute','top':yPos-31,'left':xPos-11});
			$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
			$("#arraouHolder").show();
			$("#contentHolder").show();

			$(".profileContent").html("");
			//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
			$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


			$(".profileContent").load(base_url+'kols/view_kol_micro/'+kolId+'/'+'myCustomer',{},
					function(){	$('#contentHolder .profileContent').unblock(); }
				);
			
			return false;
		}
	function closeKolProfile(){
		$("#arraouHolder").hide();
		$(".profileContent").html("");
		$("#contentHolder").hide();
	}
</script>
<div id="listKols">
		<div id="msg"></div>
	</div>
	<div id="newKolProfile" class="microProfileDialogBox">
		<div class="newProfileContent profileContent"></div>
	</div>
	<!-- Container to add my Customer -->
	<div id="myCustomer" class="microProfileDialogBox">
		<div class="myCustomerContent profileContent"></div>
	</div>
	
	<!-- Container to Edit my Customer -->
	<div id="editMyCustomer" class="microProfileDialogBox">
		<div class="editMyCustomerContent profileContent"></div>
	</div>
	
	<div>
		<div class="gridWrapper" id="notRequestedGridContainer">
			<table id="nottRequestedKolResultSet"></table>
			<div id="notRequestedRequestPager"></div>
		</div>		
	</div>
	
		<!-- Container for the 'Micro Profile'  box -->
		<div id="contentHolder" class="callOutTest microView" style="display: none;">
			<div>
				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
				<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
			--></div>
			<div class="profileContent"></div>
		</div>
		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>