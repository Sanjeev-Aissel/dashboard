<title><?php echo PRODUCT_VERSION;?></title>
<?php echo $this->load->view('elements/favicon');?>
<style>
#consent_form_holder{
	border: 1px solid #eceaea;
    width: 450px;
    padding: 15px;
    margin: 0 auto;
    margin-top: 40px;
    text-align: center;
}
</style>
<div id="consent_form_holder">
	<img src="<?php echo base_url();?>images/kolm_logo_beta.png"/>
	<?php if($status == 'success'){?>
		<p>Thank You!</p>
	<?php }else{?>
		<p>Sorry!</p>
	<?php } ?>
</div>