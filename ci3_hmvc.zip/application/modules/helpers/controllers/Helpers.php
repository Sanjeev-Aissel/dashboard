<?php
class Helpers extends MX_Controller{
	function Helpers(){
		parent::__construct();
		$this->load->Model('helper');
		$this->load->model('common_helper');
	}
	function index()
	{
		$data['showNavBar']=true;
		$data['tables']=$this->db->list_tables();
		$data['modules'] =  $this->common_helper->getEntityById('module_details',array ());
		$data['contentPage']='helpers/helper';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function get_table_fields()
	{
		$data1 = array();
		$arrData=$this->helper->getTableFields($_POST['table_name']);
		for($i=0;$i<sizeof($arrData);$i++){
			$data['id']=$i;
			$data['name']=$arrData[$i];
			$data1[]=$data;
		}
		echo json_encode($data1);
	}
	function modal_to_add_module(){
		$this->load->view('add_module');
	}
	function generate_module(){
		$data ['status']=false;
		$id =  $this->common_helper->insertEntity('module_details',
				array(
						'module_name'=>$_POST['module_name'],
						'created_by'=>$this->session->userdata('user_id'),
						'created_on'=>date('Y-m-d H:i:s')
				)
				);
		if($id>0){
			$data ['status']=true;
			$data ['module_name']=$_POST['module_name'];
		}
		echo json_encode($data);
	}
	function create_module()
	{   
		$responseData['status'] =true;
		$responseData['msg']='';
		$input_details=array();
		$input_details=$_POST;
		$filteredInputDetails=$this->getFilteredArray($input_details['columns'],$input_details['required'],$input_details['input_type']);
		$module_name			=strtolower($input_details['module_name']);
		$module_path			=APPPATH.'modules/'.$module_name;
		
		$controller_folder_path =$module_path.'/controllers';
		$model_folder_path		=$module_path.'/models';
		$view_folder_path		=$module_path.'/views';
		
		$controller_file_name	=ucfirst($input_details['controller_file_name']).'.php';
		$modal_file_name		=ucfirst($input_details['modal_file_name']).'.php';
		
		$controller_file_path		=$controller_folder_path.'/'.$controller_file_name;
		$model_file_path			=$model_folder_path.'/'.$modal_file_name;
		$listing_viewpage_file_path =$view_folder_path.'/'.$input_details['listing_file_name'].'.php';
		$add_viewpage_file_path		=$view_folder_path.'/'.$input_details['add_file_name'].'.php';
		$view_details_file_path		=$view_folder_path.'/'.$input_details['view_file_name'].'.php';
		if(file_exists($controller_file_path)){
			$responseData['status'] =false;
			$responseData['msg'].="Controller already exists with the given name<br>";
		}
		if(file_exists($model_file_path)){
			$responseData['status'] =false;
			$responseData['msg'].="Model already exists with the given name<br>";
		}
		if(($input_details['list_operation']==1) && ($input_details['listing_file_name'] ==' ' || file_exists($listing_viewpage_file_path))){
			$responseData['status'] =false;
			$responseData['msg'].="Listing file is either empty or already exists with the given name<br>";
		}
		if(($input_details['view_operation']==1) && ($input_details['view_file_name'] ==' ' || file_exists($add_viewpage_file_path))){
			$responseData['status'] =false;
			$responseData['msg'].="View file is either empty or  already exists with the given name<br>";
		}
		if(($input_details['add_edit_operation']==1) && ($input_details['add_file_name']==' ' || file_exists($view_details_file_path))){
			$responseData['status'] =false;
			$responseData['msg'].="Add data file is either empty or  already exists with the given name<br>";
		}
		if($responseData['status']){
			if(!file_exists($module_path)) {
				mkdir($module_path,0777,true);
				mkdir($controller_folder_path,0777,true);
				mkdir($model_folder_path,0777,true);
				mkdir($view_folder_path,0777,true);
			}
			$data['module_folder_name']		=$module_name;
			$data['controller_name']		=$input_details['controller_file_name'];
			$data['model_name']				=$input_details['modal_file_name'];
			$data['listing_file_name']		=$input_details['listing_file_name'];
			$data['add_record_file_name']	=$input_details['add_file_name'];
			$data['view_file_name']			=$input_details['view_file_name'];
			
			$data['table_name']				=$input_details['table_name'];
			$data['primary_key']			=$input_details['primary_key'];
			
			$data['required_fields']		=array_values(array_intersect($input_details['columns'],array_values($input_details['required'])));
			$data['allowed_fields']			=array_values($input_details['columns']);
			$data['form_elements']			=$filteredInputDetails;
			
			$data['add_edit_operation']		=$input_details['add_edit_operation'];
			$data['list_operation']			=$input_details['list_operation'];
			$data['view_operation']			=$input_details['view_operation'];
			$data['delete_operation']		=$input_details['delete_operation'];
			
			$data['file_path']=$controller_file_path;
			$response1=$this->generate_controller_file($data);
			
			$data['file_path']=$model_file_path;
			$response2=$this->generate_model_file($data);
			
			$data['file_path']=$listing_viewpage_file_path;
			$response3=$this->generate_listing_view_file($data);
			
			if($data['add_edit_operation']==1){
				$data['file_path']=$add_viewpage_file_path;
				$response4=$this->generate_add_view_file($data);
			}
			if($data['view_operation']==1){
				$data['file_path']=$view_details_file_path;
				$response5=$this->generate_details_view_file($data);
			}
		}
		chmod($module_path,0777);
		$responseData['msg'] =($responseData['status'])?"Module is successfully generated":$responseData['msg'];
		echo json_encode($responseData);
	}
	/// generating files reqd for module
//<------------------------------------------------------------------CONTROLLER FILE------------------------------------------------->//
	function generate_controller_file($details){
		$data['file_path']=$details['file_path'];
		$data['file_content']="<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ".$details['controller_name']." extends MX_Controller {
	function __construct()
	{
		parent::__construct();
		\$this->load->model('".$details['model_name']."');
		\$this->load->model('helpers/common_helper');
	}
	function index()
	{
		\$data['showNavBar']=true;
		\$data['contentPage']='".$details['listing_file_name']."';
		\$this->load->view(ANALYST_LAYOUT,\$data);
	}
	function list_records(){
		\$page = \$_REQUEST ['page'];
		\$limit =\$_REQUEST ['rows'];
		\$resultSet = \$this->".$details['model_name']."->getRecords();
		\$response = array();
		\$i = 1;
		foreach(\$resultSet->result_array() as \$row) {
			\$row['rowGridId'] = \$i;
			\$rows[] = \$row;
			\$i++;
		}
		\$count = sizeof(\$rows);
		if (\$count > 0) {
			\$total_pages = ceil ( \$count / \$limit );
		} else {
			\$total_pages = 0;
		}
		\$response['rows']= \$rows;
		\$response['records'] = \$count;
		\$response['total'] = \$total_pages;
		\$response['page'] =\$page;
		echo json_encode(\$response);
	}
";
if($details['add_edit_operation']==1){
	$data['file_content'].="
function update_record(\$id=0){
		\$data['title']='Add Record';
		if(\$id!=NULL){
			\$data['title']='Edit Record';
			\$details=\$this->common_helper->getEntityById('".$details['table_name']."',array('".$details['primary_key']."'=>\$id));
			\$details=\$details[0];
		}
		\$hidden_fields=array('".$details['primary_key']."'=>\$id);
";
		foreach($details['form_elements'] as $label=>$info){
			$required_class='';
			if(($info['required'])==1){
				$required_class='required';
			}
			switch ($info['type']){
				case 'text':	$data['file_content'].="\$form_inputs_details[]=array('type'=>'text','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'data'=>array('name'=>'".$label."','id'=>'".$label."','class'=>'".$required_class." form-control','value'=>\$details['".$label."']));";
								break;
				case 'textarea':$data['file_content'].="\$form_inputs_details[]=array('type'=>'textarea','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'data'=>array('name'=>'".$label."','id'=>'".$label."','value'=>\$details['".$label."'],'rows'=> '5','cols'=> '10','style'=> '','class'=>'".$required_class." form-control'));";
								break;
				case 'select':	$data['file_content'].="\$form_inputs_details[]=array('type'=>'select','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'name'=>'".$label."','data'=>array('id'=>'".$label."','class'=>'".$required_class." form-control'),'options'=>array('0'=>'select'),'selected'=>'');";
								break;
				case 'radio':	$data['file_content'].="\$form_inputs_details[]=array('type'=>'radio','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'name'=>'".$label."','value'=>'value1','options'=>array('name1'=>'value1'),'data'=>array('id'=>'".$label."','class'=>''));";
								break;
				case 'checkbox':$data['file_content'].="\$form_inputs_details[]=array('type'=>'checkbox','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'name'=>'".$label."[]','values'=>array('value1','value2'),'options'=>array('name1'=>'value1','name2'=>'value2','name3'=>'value3'),'data'=>array('id'=>'".$label."[]','class'=>'',));";
								break;
				case 'file':	$data['file_content'].="\$form_inputs_details[]=array('type'=>'file','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'data'=>array('name'=>'".$label."','id'=>'".$label."','class'=>'".$required_class." form-control'));";
								break;
				case 'date':	$data['file_content'].="\$form_inputs_details[]=array('type'=>'date','label'=>array('label_name'=>'".$label."','required'=>".$info['required']."),'data'=>array('name'=>'".$label."','id'=>'".$label."','class'=>'form-control','value'=>'','class'=>'".$required_class." form-control','style'=>'width: 34%;display: inline'));";
								break;
				default:$data['file_content'].="";
							break;
			}
			$data['file_content'].="";
		}
		
		$data['file_content'].="\$form_details=array('form_inputs_details'=>\$form_inputs_details,
				'hidden_ids'=>\$hidden_fields,
				'form_id'=>'update_record_form',
				'submit_function'=>'save_form();',
				'cancel_function'=>'cancel();'
		);
		\$data['html_form']=get_html_form(\$form_details);
		\$data['showNavBar']=true;
		\$data['contentPage']='".$details['add_record_file_name']."';
		\$this->load->view(ANALYST_LAYOUT,\$data);
	}
	function save_form_details(){
		if(\$this->".$details['model_name']."->saveDetails(\$_POST)>=0){
			\$data['status'] =true;
			\$data['msg']  = 'Saved Successfully';
		}else{
			\$data['status'] =false;
			\$data['msg']  = 'Error in updating data...!!';
		}
		echo json_encode(\$data);
	}
";
}
	
if($details['delete_operation']==1){
	$data['file_content'].="
	function delete_by_id(\$id=0){
		\$status = \$this->".$details['model_name']."->deleteById(\$id);
		if(\$status){
			\$data['status'] = 1;
		}else{
			\$data['status'] = 0;
		}
		echo json_encode(\$data);
	}
";
}
if($details['view_operation']==1){
	$data['file_content'].="
	function view_record(\$id=0){
		\$data['showNavBar']=true;
		\$details=\$this->common_helper->getEntityById('".$details['table_name']."',array('".$details['primary_key']."'=>\$id));
		\$data['details']= \$details[0];
		\$data['contentPage']='".$details['view_file_name']."';
		\$this->load->view(ANALYST_LAYOUT,\$data);
	}
";
}
$data['file_content'].="}
?>";
		$response=$this->create_file($data);
		return $response;
	}
	//<------------------------------------------------------------------MODEL FILE------------------------------------------------->//
	function generate_model_file($details){
		$data['file_path']=$details['file_path'];
		$data['file_content']="<?php
class ".$details['model_name']." extends CI_Model {
	function getRecords(){
		\$this->db->select('*');
		return \$this->db->get('".$details['table_name']."');
	}
";
if($details['add_edit_operation']==1){
	$data['file_content'].="function saveDetails(\$arrDetails){
		\$id = \$arrDetails['".$details['primary_key']."'];
		if(\$id>0)
		{
			\$this->db->where('".$details['primary_key']."',\$id);
			\$a=\$this->db->update('".$details['table_name']."',\$arrDetails);
			if(\$id)
				return \$id;
			else
				return false;
		}
		else
		{
			\$arrDetails['".$details['primary_key']."']=NULL;
			\$this->db->insert('".$details['table_name']."',\$arrDetails);
			\$id=\$this->db->insert_id();
			return \$id;
		}
	}
";
}
if($details['delete_operation']==1){
	$data['file_content'].="function deleteById(\$id){
	\$this->db->delete('".$details['table_name']."', array('".$details['primary_key']."' => \$id));
		return(\$this->db->affected_rows() > 0) ? TRUE : FALSE;
	}
";
}
$data['file_content'].="}
?>";
		$response=$this->create_file($data);
		return $response;
	}
	//<------------------------------------------------------------------LISTING FILE------------------------------------------------->//
	function generate_listing_view_file($details){
		$data['file_path']=$details['file_path'];
		$data['file_content']="<div style='margin:1% 1% 5% 0%;'>
	<div class='pull-right' style='display:inline;margin-left:2%;'>";
		if($details['add_edit_operation']==1){
			$data['file_content'].="<a class='btn btn-default' style='margin-bottom:4px;' href='<?php echo base_url();?>".$details['module_folder_name']."/".strtolower($details['controller_name'])."/update_record'>Add Record</a>";
		}
		$data['file_content'].="</div>
</div>
<div id='gridWrapper' class='gridWrapper'>
	<table id='gridListing'></table>
	<div id='gridPagintaion'></div>
</div>
<div id='userContainer'' class='microViewLoading'>
	<div class='modalcontent'></div>
</div>
<script>
var base_url = '<?php echo base_url(); ?>';
var columnNamesForGrid	= [];
var columnDataForGrid	= [];
var modalBoxLayout = {
		title:'',
		modal: true,
		width:400,
		position:['center',100],
		resizable: true
};
$(document).ready(function(){
	load_grid();
});
function toggle_search_toolbar(){
	if(jQuery('.ui-search-toolbar').css('display')=='none') {
		jQuery('.ui-search-toolbar').css('display','');
	} else {
		jQuery('.ui-search-toolbar').css('display','none');
	}
}
function load_grid(){	
	$('#gridWrapper').html('');
	$('#gridWrapper').html('<table id=\"gridListing\"></table><div id=\"gridPagintaion\"></div>');
	grid = $('#gridListing');
	columnNamesForGrid	= ['',";
		$allowed_fields=$details['allowed_fields'];
		for($i=0;$i<sizeof($allowed_fields);$i++){
			$data['file_content'].="'".$allowed_fields[$i]."',";
		}
		$data['file_content'].="'','Action'];
	columnDataForGrid	= [
";		
		$data['file_content'].="		{name:'".$details['primary_key']."',index:'".$details['primary_key']."',search:false,hidden:true},
";
		for($i=0;$i<sizeof($allowed_fields);$i++){
			$data['file_content'].="		{name:'".$allowed_fields[$i]."',index:'".$allowed_fields[$i]."',search:true},
";
		}
		$data['file_content'].="		{name:'rowGridId',index:'rowGridId',search:false,hidden:true},
{name:'act',width:110, hidden:false,align:'center',search:false,sortable:false}
	];
	grid.jqGrid({
		url: base_url+'".$details['module_folder_name']."/".strtolower($details['controller_name'])."/list_records',
 		datatype:'json',
		colNames:columnNamesForGrid,
		colModel:columnDataForGrid,
		rowNum:10,
		autowidth:true,
		pager: '#gridPagintaion',
		sortname:'".$details['primary_key']."',
		mtype:'POST',
		recordpos:'left',
		width:'100%',
		height:'auto',
		viewrecords: true,
		sortorder:'asc',
		ignoreCase:true,
		loadonce: true,
		caption:'',
	    jsonReader: {
	            root:'rows',
	            page:'page',
	            total:'total',
	            records:'records',
	            repeatitems: false,
	            Id:'0'
	    },
		gridComplete: function(){	
	    	var arrIds = jQuery('#gridListing').jqGrid('getDataIDs'); 
	    	for(var i=0;i<arrIds.length;i++){ 		    	
		    	var arrId =  jQuery('#gridListing').jqGrid ('getRowData',arrIds[i]);
		    	var id = arrId.".$details['primary_key'].";
		    	var ids = arrId.rowGridId;
		    	editDeleteLink ='<div>";
		if($details['view_operation']==1){
			$data['file_content'].="<a class=\"btn btn-success btn-sm\" title=\"View\"  href=\"'+base_url+'".$details['module_folder_name']."/".strtolower($details['controller_name'])."/view_record/'+id+'\"><span class=\"glyphicon glyphicon-eye-open\"></span></a>";
		}
		if($details['add_edit_operation']==1){
			$data['file_content'].="<a class=\"btn btn-info btn-sm\" title=\"Edit\"  href=\"'+base_url+'".$details['module_folder_name']."/".strtolower($details['controller_name'])."/update_record/'+id+'\"><span class=\"glyphicon glyphicon-edit\"></span></a>";
			}
			if($details['delete_operation']==1){
	$data['file_content'].="<a class=\"btn btn-danger btn-sm\" title=\"Delete\"  onclick=\"delete_record('+id+');return false;\"><span class=\"glyphicon glyphicon-remove-circle\"></span></a>";
}
$data['file_content'].="</div>';
";
$data['file_content'].="jQuery('#gridListing').jqGrid('setRowData',id,{act:editDeleteLink});
		    } 
	    }
	});
	grid.jqGrid('navGrid','#gridPagintaion',{add:false,del:false,edit:false,position:'right',search:false});
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:'cn'});
	grid.jqGrid('navButtonAdd','#gridPagintaion',{caption:'Search',buttonicon:'ui-icon-search',title:'Toggle Search', onClickButton:toggle_search_toolbar});
}
";
if($details['delete_operation']==1){
$data['file_content'].="function delete_record(id=NULL){
	jConfirm('Are you sure you want to delete the selected record?','Please Confirm',function(event){
		if(event){
			$.ajax({
				url: base_url+'".$details['module_folder_name']."/".strtolower($details['controller_name'])."/delete_by_id/'+id,
				type:'POST',
				dataType:'json',
				success:function(returnData){
						if(returnData.status==1){
							showMessageInSnackbar('Data is Successsfully Deleted');
							load_grid();
					}else{
						showMessageInSnackbar('Not deleted');
					}
				},
				error:function()
				{
					showMessageInSnackbar('Error in Deleting Data');
				}
			});
		}
	});	
}
";
}
$data['file_content'].="</script>";
		$response=$this->create_file($data);
		return $response;
	}
	//<------------------------------------------------------------------ADD RECORD FILE------------------------------------------------->//
	function generate_add_view_file($details){
		$data['file_path']=$details['file_path'];
		$data['file_content']="<style>
.col-form-label {
    text-align: right;
}
.reqd-field-indicator{
color:red;
}
</style>
<div class='container'>
 <div style='margin:1% 0%;'>
	<div style='display:inline;margin-left:2%;'>
		<a class='btn btn-default' style='margin-bottom:4px;' href='<?php echo base_url();?>".$details['module_folder_name']."/".strtolower($details['controller_name'])."'>Back</a>
		<h3 style='text-align: center'><?php echo \$title;?></h3>
	</div>
</div>
<?php echo \$html_form;?>
		<div class='form-group row'>
			<label class='col-sm-4'></label>
				<div class='col-sm-8'>
				<div class='responseMsgBox'></div>
   		  	</div>
		</div>
</div>
<script>
var base_url = '<?php echo base_url(); ?>';
var validationRules	=  {
";
		$required_fields=$details['required_fields'];
		for($i=0;$i<sizeof($required_fields)-1;$i++){
			$data['file_content'].="$required_fields[$i]: {
			required:true
		},";
		}
		$data['file_content'].="$required_fields[$i]: {
		required:true
	}
};
var validationMessages = {
";
for($i=0;$i<sizeof($required_fields)-1;$i++){
	$data['file_content'].="	$required_fields[$i]: {
			required:true
	},";
}
$data['file_content'].="$required_fields[$i]: {
	required:'This field is required.'
	}
};
$(function () {
	$('#update_record_form').validate({
        debug: false,
        onkeyup: false,
        rules: validationRules,
        messages: validationMessages
    });
});
function save_form(){
	var isValid = true;
	isValid=$('#update_record_form').validate().form();
	if(!isValid){
		return isValid;
	}
	if(isValid){
		data=$('#update_record_form').serialize();
		action = base_url+'".$details['module_folder_name']."/".strtolower($details['controller_name'])."/save_form_details';
		$.ajax({
			type:'POST',
			url:action,
			dataType:'json',
			data:data,
			success:function(respData){
				if(respData.status==true){
					$('.responseMsgBox').html('<p class=\"alert alert-success\">'+respData.msg+'</p>');
			}else{
				$('.responseMsgBox').html('<p class=\"alert alert-danger\">'+respData.msg+'</p>');
			}
 			},
			error:function()
			{
				showMessageInSnackbar('Error in Updating/Adding Data');
			}
		});
	}
}
function cancel(){
	window.location.href = '<?php echo base_url()?>".$details['module_folder_name']."/".$details['controller_name']."';
}
</script>";
		$response=$this->create_file($data);
		return $response;
	}
	//<------------------------------------------------------------------VIEW FILE------------------------------------------------->//
	function generate_details_view_file($details){
		$data['file_path']=$details['file_path'];
		$data['file_content']="<style>
.col-form-label {
    text-align: right;
}
</style>
<div class='container'>
 <div style='margin:1% 0%;>
	<div style='display:inline;margin-left:2%;'>
		<a class='btn btn-defaul' style='margin-bottom:4px;' href='<?php echo base_url();?>".$details['module_folder_name']."/".strtolower($details['controller_name'])."'>Back</a>
	<h3 style='text-align: center'>View Details</h3>
	</div>
</div>
<br>
<?php foreach (\$details as \$key=>\$value){?>
	<div class='form-group row'>
	<label class='col-sm-4 col-form-label'><?php echo \$key;?>:</label>
	<div class='col-sm-8'>
	<?php echo \$value;?>
	</div>
	</div>
<?php }?>
</div>";
		$response=$this->create_file($data);
		return $response;
	}
//<------------------------------------------------------------------FUNCTION TO WRITE TO A FILE------------------------------------------------->//
	function create_file($data){
		$response=0;
		$file_path=$data['file_path'];
		$content=$data['file_content'];
		chmod($file_path,0777);
		$response=write_file($file_path,$content);
		return $response;
	}
	function getFilteredArray($columns,$required,$input_types){
		$required_fields=array_intersect($columns,$required);
		$input_types    =array_intersect_key($input_types,$columns);
		$is_required=array();
		foreach($columns as $index=>$field){
			$is_required[$index]=0;
			if(in_array($field,$required_fields)){
				$is_required[$index]=1;
			}
		}
		$filteredArr=array();
		foreach ($columns as $index=>$field){
			$filteredArr[$field]['type']	=$input_types[$index];
			$filteredArr[$field]['required']=$is_required[$index];
		}
		return  $filteredArr;
	}
	/**
	 * Retruns the Organization Types matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return JSON
	 * @created 25-07-2011
	 */
	function get_org_types($orgType){
		$orgType		= urldecode($this->input->post($orgType));
		$arrOrgTypes = $this->helper->getMatchingOrgTypes($orgType);
		$arrSuggestTypes	= array();
		if(sizeof($arrOrgTypes)==0){
			$arrSuggestTypes[0]		= 'No results found for '.$orgType;
		}else{
			$flag	= 1;
			foreach($arrOrgTypes as $typeId=>$type){
				if($flag){
					$arrSuggestTypes[]='<div class="autocompleteHeading">Organization Types</div><div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type.'</label></div>';
					$flag	= 0;
				}else{
					$arrSuggestTypes[]='<div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type.'</label></div>';
				}
			}
		}
		$arrReturnData['query'] = $orgType;
		$arrReturnData['suggestions']	= $arrSuggestTypes;
		echo json_encode($arrReturnData);
	}
	function get_region($region){
		$regionKeyword		= urldecode($this->input->post($region));
		$arrRegions= $this->helper->getMatchingRegions($regionKeyword);
		$arrSuggestRegions	= array();
		if(sizeof($arrRegions)==0){
			$arrSuggestRegions[0]		= 'No results found for '.$regionKeyword;
		}else{
			$flag	= 1;
			foreach($arrRegions as $key=>$title){
				if($flag){
					$arrSuggestRegions[]='<div class="autocompleteHeading">Global Regions</div><div class="dataSet"><label name="'.$key.'" class="regionTypes" style="display:block">'.$title."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestRegions[]='<div class="dataSet"><label name="'.$key.'" class="regionTypes" style="display:block">'.$title."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $regionKeyword;
		$arrReturnData['suggestions']	= $arrSuggestRegions;
		echo json_encode($arrReturnData);
	}
	/**
	 * Searches for the "Country name" and Returns the list of Country names matched
	 *
	 *
	 * @param String 	$countryName
	 * @return unknown_type
	 */
	function get_country_names($countryName){
		$countryName	= urldecode($this->input->post($countryName));
		$arrCountryNames = $this->helper->getCountryNames($countryName);
		$arrSuggestCountryNames	= array();
		if(sizeof($arrCountryNames)==0){
			$arrSuggestCountryNames[0]			= 'No results found for '.$countryName;
		}else{
			$flag	= 1;
			foreach($arrCountryNames as $id=>$name){
				if($flag){
					$arrSuggestCountryNames[]='<div class="autocompleteHeading">Countries</div><div class="dataSet"><label name="'.$id.'" class="countries" style="display:block">'.$name."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestCountryNames[]='<div class="dataSet"><label name="'.$id.'" class="countries" style="display:block">'.$name."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $countryName;
		$arrReturnData['suggestions']	= $arrSuggestCountryNames;
		echo json_encode($arrReturnData);		
	}
	function get_kol_titles($title){		
		$titleKeyword		= urldecode($this->input->post($title));
		$arrKolTitles = $this->helper->getMatchingkolTitles($titleKeyword);
		$arrSuggestTitles	= array();
		if(sizeof($arrKolTitles)==0){
			$arrSuggestTitles[0]		= 'No results found for '.$titleKeyword;
		}else{
			$flag	= 1;
			foreach($arrKolTitles as $typeId=>$title){
				if($flag){
					$arrSuggestTitles[]='<div class="autocompleteHeading">Positions</div><div class="dataSet"><label name="'.$typeId.'" class="kolTypes" style="display:block">'.$title."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestTitles[]='<div class="dataSet"><label name="'.$typeId.'" class="kolTypes" style="display:block">'.$title."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $titleKeyword;
		$arrReturnData['suggestions']	= $arrSuggestTitles;
		echo json_encode($arrReturnData);
	}
	/**
	 *
	 * @param String	$membershipType
	 * @param String 	$committee
	 * @return unknown_type
	 */
	function get_specialty_names($spaciltyName) {
		$spaciltyName = urldecode($this->input->post($spaciltyName));
		$arrSpecialty = $this->helper->getSpecialties($spaciltyName);
		$arrSuggestSpecialties = array();
		if (sizeof($arrSpecialty) == 0) {
			$arrSuggestSpecialties[0] = 'No results found for ' . $spaciltyName;
		} else {
			$flag = 1;
			foreach ($arrSpecialty as $id => $name) {
				if ($flag) {
					$arrSuggestSpecialties[] = '<div class="autocompleteHeading">Specialties</div><div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestSpecialties[] = '<div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $spaciltyName;
		$arrReturnData['suggestions'] = $arrSuggestSpecialties;
		echo json_encode($arrReturnData);
	}
	/**
	 * Searches for the "State name" and Returns the list of Country names matched
	 *
	 *
	 * @param String 	$stateName
	 * @return unknown_type
	 */
	function get_state_names($isGeneric=1,$stateName){
		$stateName		= urldecode($this->input->post('keyword'));
		
		if($isGeneric==1){
			$isGeneric = true;
		}else{
			$isGeneric = false;
		}
		//$arrStateNames	= $this->Country_helper->getStateNames($stateName);
		$arrStateNames	= $this->helper->getStateNamesForAutoComplete($stateName,$isGeneric);
		if((sizeof($arrStateNames))<1){
			$arrStateNames1[]		= '<div style="padding-left:5px;">No results found for '.$stateName.'</div><div><label name="No results found for '.$stateName.'" class="stateName" style="display:block"></label><label></label><span style="display:none" class="autocompleteStateId"></span></div>';
		}else{
			foreach($arrStateNames as $key=>$row){
				$arrStateNames1[]	= '<div class="dataSet"><label name="'.$row[0].'" class="stateName" style="display:block">'.$row[0].'</label><label>'.$row[1].'</label><span style="display:none" class="autocompleteStateId">'.$key.'</span></div>';
			}
		}
		$arrReturnData['query'] 		= $stateName;
		$arrReturnData['suggestions']	= $arrStateNames1;
		echo json_encode($arrReturnData);		
	}
	/*
	 *  Retrives all the list names and also there respective category names
	 *  @author Ramesh B
	 *  @since 2.2
	 *  @created on 3-5-2011
	 */
	function get_list_names_with_category($listName){
		$listName	= urldecode($this->input->post($listName));
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$arrListDetails=$this->helper->getListNameAndCategoryName($listName,$user_id,$client_id);
		$arrSuggestLists	= array();
		if(sizeof($arrListDetails)==0){
			$arrSuggestLists[0]			= 'No results found for '.$listName;
		}else{
			$flag	= 1;
			foreach($arrListDetails as $id=>$row){
				if($flag){
					$arrSuggestLists[]='<div class="autocompleteHeading">Lists</div><div class="dataSet"><label name="'.$id.'" class="lists" style="display:block">'.$row['list_name']."</label><label>".$row['category']."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestLists[]='<div class="dataSet"><label name="'.$id.'" class="lists" style="display:block">'.$row['list_name']."</label><label>".$row['category']."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $listName;
		$arrReturnData['suggestions']	= $arrSuggestLists;
		echo json_encode($arrReturnData);
	}
	/**
	 * Returns the list of Names of Organizations
	 *
	 */
	function get_organization_names($organizationName,$restrictByRegion=0) {
		if($organizationName!="keyword"){
			$currentkolName  = $organizationName;
			$organizationName   = $restrictByRegion;
			$restrictByRegion  = $currentkolName;
		}
		$organizationName = urldecode($this->input->post($organizationName));
		$arrOrgNames = $this->helper->getOrganizationNamesWithStateCity($organizationName,$restrictByRegion);
		$arrOrgs = array();
		if (sizeof($arrOrgNames) == 0) {
			$arrSuggestOrgs[0] = 'No results found for ' . $organizationName;
		} else {
			$flag = 1;
			foreach ($arrOrgNames as $row) {
				$cityState=$row['city'];
				if(isset($row['city']) && isset($row['state']))
					$cityState.= ', ';
					$cityState.=$row['state'];
					if ($flag) {
						$arrSuggestOrgs[] = '<div class="autocompleteHeading">Organizations</div><div class="dataSet"><label name="' . $row['id'] . '" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label></div>";
						$flag = 0;
					} else {
						$arrSuggestOrgs[] = '<div class="dataSet"><label name="' . $row['id'] . '" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label></div>";
					}
			}
		}
		$arrReturnData['query'] = $organizationName;
		$arrReturnData['suggestions'] = $arrSuggestOrgs;
		echo json_encode($arrReturnData);
	}
	/**
	 * Searches for the InstituteName and Returns the list of Institution Names matched
	 *
	 * @param String 	$instituteName
	 * @return unknown_type
	 */
	function get_institute_names($instituteName) {
		$instituteName = urldecode($this->input->post($instituteName));
		$arrInstituteNames = $this->helper->getInstituteNames($instituteName);
		$arrSuggestInstitutes = array();
		if (sizeof($arrInstituteNames) == 0) {
			$arrSuggestInstitutes[0] = 'No results found for ' . $instituteName;
		} else {
			$flag = 1;
			foreach ($arrInstituteNames as $id => $name) {
				if ($flag) {
					$arrSuggestInstitutes[] = '<div class="autocompleteHeading">Institute Names</div><div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestInstitutes[] = '<div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $instituteName;
		$arrReturnData['suggestions'] = $arrSuggestInstitutes;
		echo json_encode($arrReturnData);
	}
	/**
	 * Searches for the EventName and Returns the list of Event Names matched
	 *
	 * @param String $category
	 * @param String $eventName
	 * @return unknown_type
	 */
	function get_search_eventLookup_names($eventName) {
		$eventName = urldecode($this->input->post($eventName));
		$arrEventLookupNames = $this->helper->getSearchEventLookupNames($eventName);
		$arrSuggestEvents = array();
		if (sizeof($arrEventLookupNames) == 0) {
			$arrSuggestEvents[0] = 'No results found for ' . $eventName;
		} else {
			$flag = 1;
			foreach ($arrEventLookupNames as $id => $name) {
				if ($flag) {
					$arrSuggestEvents[] = '<div class="autocompleteHeading">Events</div><div class="dataSet"><label name="' . $id . '" class="events" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestEvents[] = '<div class="dataSet"><label name="' . $id . '" class="events" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $eventName;
		$arrReturnData['suggestions'] = $arrSuggestEvents;
		echo json_encode($arrReturnData);
	}
	//Returns the list of KOL Names, based on search
	//$restrictOptInVisbility defalut 0 shows all kols irrespective of the Opt-in status, 1 only the KTLs that have Opted-in
	function get_kol_names_for_all_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0) {
		$kolName = urldecode($this->input->post('keyword'));
		$arrKolLookupNames = $this->helper->getAllKolNamesForAllAutocomplete($kolName);
		$arrSuggestKols = array();
		if (sizeof($arrKolLookupNames) == 0) {
			$arrSuggestKols[0] = 'No results found for ' . $kolName;
		} else {
			$flag = 1;
			foreach ($arrKolLookupNames as $id => $name) {
				if ($flag) {
					$arrSuggestKols[] = '<div class="autocompleteHeading">KOLs</div><div class="dataSet"><label name="' . $id . '" class="kolName" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestKols[] = '<div class="dataSet"><label name="' . $id . '" class="kolName" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $kolName;
		$arrReturnData['suggestions'] = $arrSuggestKols;
		echo json_encode($arrReturnData);
	}
}