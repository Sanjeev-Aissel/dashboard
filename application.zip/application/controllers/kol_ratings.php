<?php
/*
 * Controller for the new module 'KOL Rating' 
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v3.7 Abbott 1.0
 * Created on	: 17-03-2012
 *  
 */
class Kol_Ratings extends Controller{
	private $loggedUserId	= null;
	
	// constructor to initialize the data
	function Kol_Ratings(){
		parent::Controller();
		$this->load->model('Kol_rating');
		$this->load->Model('Country_helper');
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	function index(){
		//$this->add_assessment_rules();
		redirect('kols/list_kols_client_view');
	}
	
	/**
	 * to add new assessment rules
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @created 17-03-2012
	 */
	function add_assessment_rules(){
		$data['arrAsmtCategroies']	= $this->Kol_rating->getAllAsmtCategories();
		$data['arrAsmtCriteria']	= $this->Kol_rating->getAllAsmtCriteria();
		$data['arrAsmtRatings']		= $this->Kol_rating->getAllAsmtRatings();
		$data['arrCountries']		= $this->Country_helper->listCountries();
		//$this->load->view("kol_ratings/add_assessment_rules",$data);
		$data['contentPage'] 	=	'kol_ratings/add_assessment_rules';
		$this->load->view('layouts/analyst_view', $data);
	}
/*	
	function get_assessment_rules($countryId=254){
		$arrFormattedAsmtRules	= array();
		$arrAsmtRules			= array();
		$arrAsmtRules			= $this->Kol_rating->getAllAsmtRules($countryId);
		foreach($arrAsmtRules as $key=>$row){
			$arrFormattedAsmtRules[$row['cat_name']][$row['criteria']][]	= $row;
		}
		$data['arrAsmtRatings']	= $arrFormattedAsmtRules;
		return $this->load->view("kol_ratings/get_assessment_ratings",$data,TRUE);
	}
*/
	/**
	 * save new assessment rules sent by add assessment rules form
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @created 18-03-2012
	 */	
	function save_assessment_rules(){
		$arrAsmtRule	= array();
		$arrAsmtRules	= $_POST;
		$countryId		= $arrAsmtRules['country'];
		foreach($arrAsmtRules['asmt_rating'] as $key=>$value){
			$arrAsmtRow					= array();
			$arrAsmtRow['country_id']	= $countryId;
			$arrAsmtRow['category_id']	= $arrAsmtRules['asmt_category'][$key];
			$arrAsmtRow['criteria_id']	= $arrAsmtRules['asmt_criteria'][$key];
			$arrAsmtRow['rating_id']	= $value;
			$arrAsmtRow['order_no']		= $arrAsmtRules['order_no'][$key];
			$this->Kol_rating->saveAsmtRules($arrAsmtRow);
		}
		redirect('kol_ratings/add_assessment_rules');
	}
	
	/**
	 * save assessment rating for individual KOLs
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @created 18-03-2012
	 */	
	function save_assessment_ratings(){
		$kolId			= '';
		$asmtCatId		= '';
		$asmtCriteriaId	= '';
		foreach($_POST as $key=>$value){
			if($key=='kol_id'){
				$kolId	= $value;
			}else{
				$asmtCriteriaId	= explode('_',$key);
				$asmtCatId		= $asmtCriteriaId[0];
				$asmtCriteriaId	= $asmtCriteriaId[1];
				$this->Kol_rating->saveKolRatings($kolId,$asmtCatId,$asmtCriteriaId,$value);
			}
			
		}
		redirect('kols/view/'.$kolId.'/assessment');
	}
	
	/**
	 * add new assessment category
	 * @author 	Laxman K
	 * @since	KOLM v3.7 Abbott 1.0
	 * @created 18-03-2012
	 */	
	function add_asmt_category($catName){
		$arrNewRecord['name']	= $catName;
		$catId	= $this->Kol_rating->addAsmtCategory($arrNewRecord);
	}
	
	/**
	 * Assessment Score chart for dashboard
	 * @author 	Laxman K
	 * @since	Otsuka v1.0.5 KOLM v3.7 Abbott 1.0
	 * @created 10-11-2012
	 */	
	function show_asmt_score_chart($kolId){
		$arrData	= array();
		$arrAsmtCat	= array();
		$arrData['arrAsmtCat']	= $this->Kol_rating->getAsmtChartScore($kolId);
		$this->load->view('kol_ratings/asmt_score_chart',$arrData);
	}
}

?>