<?php
/**
 * Model for Survey Mapping
 * 
 * @package application.models
 * @author Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 14-03-2013
 */

class Survey extends model{
	// constructor to initialize the data
	function Survey(){
		parent::model();
			$this->load->model('Kol');
			$this->load->model("Client_User");
			$this->load->model("common_helpers");
			$this->load->model('country_helper');
	}

	/*
	 * get user who responded on behalf of respondent
	 * @param $userId
	 */
	function getRespondentUsers($userId){
		$arrUser	= array();
    	$this->db->select('client_users.id,client_users.first_name,client_users.last_name,client_users.country as country_id,countries.Country');
    	$this->db->join('countries', 'CountryId = client_users.country', 'left');
    	$this->db->where('client_users.id',$userId);
    	$this->db->order_by('first_name,last_name','asc');
    	$result = $this->db->get('client_users');
    	foreach($result->result_array() as $row){
    		$arrUser	= $row;
    	}
    	return $arrUser;
	}
	
	/*
	 * To get all the questions from active survey
	 * @param $id	- survey id
	 */
	function getActiveSurveyQuestions($id){
		$arrSurveys		= array();
		$arrQuestionIds	= array();
		$surveyId		= 0;
		$surveyName		= '';
		$this->db->select('id,question_ids,name');
		$this->db->where('id',$id);
		$arrResultData	= $this->db->get('surveys');
		if($arrResultData->num_rows()>0){
			$resultObj		= $arrResultData->first_row();
			$surveyId		= $resultObj->id;
			$surveyName		= $resultObj->name;
			$surveyName = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $surveyName);
	    	$surveyName = trim($surveyName," - ");
			$arrQuestionIds	= explode(',',$resultObj->question_ids);
		}
    	$this->db->select('survey_questions.id,survey_questions.question,survey_questions.category_id,survey_categories.name as survey_category,survey_roles.name as role,survey_questions.role_id,survey_questions.type_id');
    	$this->db->join('survey_categories', 'survey_categories.id =survey_questions.category_id', 'left');
    	$this->db->join('survey_roles', 'survey_roles.id =survey_questions.role_id', 'left');
    	$this->db->where_in('survey_questions.id',$arrQuestionIds);
    	$this->db->order_by('survey_categories.name','asc');
    	$result = $this->db->get('survey_questions');
    	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrSurveys[$row['survey_category']][]	= $row;
    	}
    	//pr($arrSurveys);
    	return array('surveyId'=>$surveyId,'surveyName'=>$surveyName,'arrQuestionData'=>$arrSurveys);
	}
	
	function getActiveSurveyQuestions_test($id){
		$arrSurveys		= array();
		$arrQuestionIds	= array();
		$surveyId		= 0;
		$surveyName		= '';
		$this->db->select('id,question_ids,name');
		$this->db->where('id',$id);
		$arrResultData	= $this->db->get('surveys');
		if($arrResultData->num_rows()>0){
			$resultObj		= $arrResultData->first_row();
			$surveyId		= $resultObj->id;
			$surveyName		= $resultObj->name;
			$arrQuestionIds	= explode(',',$resultObj->question_ids);
		}
    	$this->db->select('survey_questions.id,survey_questions.question,survey_questions.category_id,survey_categories.name as survey_category,survey_roles.name as role,survey_questions.type_id');
    	$this->db->join('survey_categories', 'survey_categories.id =survey_questions.category_id', 'left');
    	$this->db->join('survey_roles', 'survey_roles.id =survey_questions.role_id', 'left');
    	$this->db->where_in('survey_questions.id',$arrQuestionIds);
    	$this->db->order_by('survey_categories.name','asc');
    	$result = $this->db->get('survey_questions');
    	foreach($result->result_array() as $row){
    		$arrSurveys[$row['survey_category']][]	= $row;
    	}
    	//pr($arrSurveys);
    	return array('surveyId'=>$surveyId,'surveyName'=>$surveyName,'arrQuestionData'=>$arrSurveys);
	}
	/*
	 * To KOL information to populate in survey form
	 * @param $kolId
	 */
	function kolDetails($kolId,$kolName=false,$addressId){
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select('kol_names_for_survey.id,kol_names_for_survey.postal_code,kol_names_for_survey.country,kol_names_for_survey.state,kol_names_for_survey.city,kol_names_for_survey.organization as org');
		if($kolName){
			$clientId = $this->session->userdata('client_id');
			//$this->db->select("icontacts.first_name,icontacts.middle_name,icontacts.last_name,icontacts.salutation");
			/*if($clientId!=INTERNAL_CLIENT_ID){
				$this->db->where('kols.status',COMPLETED);
			}*/
		}
		//$this->db->join('organizations', 'organizations.id = additional_contacts.org_id', 'left');
		//$this->db->join('countries', 'CountryId = additional_contacts.country_id', 'left');
		//$this->db->join('regions','RegionId = additional_contacts.state_id','left');
		//$this->db->join('cities','cityId = additional_contacts.city_id','left');
		//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
		
		$this->db->where('kol_names_for_survey.id',$addressId);
//		$this->db->where('additional_contacts.present_address',1);
		$this->db->limit(1,0);
		$result	= $this->db->get('kol_names_for_survey');
		//pr($this->db->last_query());exit;
		foreach($result->result_array() as $row){
			$row['mdm_id'] = $row['master_customer_id']; 
			if($kolName){
				$row['salutation']	= $arrSalutations[$row['salutation']];
				$row['kolname']	= str_replace("  ", " ", $row['first_name'].' '.$row['middle_name'].' '.$row['last_name']);
			}
			$arrKolNames	= $row;
		}
		return $arrKolNames;
	}
	/*
	 * To get survey(s)
	 * @param $id	- survey id
	 */
	function getSurveys($id=''){
		$arrSurveys		= array();
		$arrSurveyIds	= array();		
		$roleId= $this->session->userdata('user_role_id');
		if($roleId != ROLE_MANAGER && $roleId != ROLE_ADMIN){
			$arrSurveyIds[]	= 0;
			$this->db->distinct();
			$this->db->select('survey_id');
			$this->db->where('created_by',$this->session->userdata('user_id'));
			$result = $this->db->get('survey_answers');
	    	foreach($result->result_array() as $row){
	    		$arrSurveyIds[]	= $row['survey_id'];
	    	}
    	}
    	$this->db->select('surveys.*,CONCAT(client_users.first_name," ",client_users.last_name) as username',false);
    	$this->db->join('client_users', 'client_users.id =surveys.created_by', 'inner');
    	if(!empty($id)){
    		$arrSurveyIds[]	= $id;
    		//$this->db->where('surveys.id',$id);
    		$this->db->limit(1,0);
    	}
    	if(sizeof($arrSurveyIds)>0){
    		//$this->db->where_in('surveys.id',$arrSurveyIds);
    	}
    	
    	$this->db->order_by('surveys.created_on','desc');
    	$client_id = $this->session->userdata('client_id');
    	$this->db->where("client_users.client_id",$client_id);
    	$result = $this->db->get('surveys');
    	    	
    	$userId			= $this->session->userdata('user_id');
    	$arrUserGroupIds	= array();
    	$this->db->select('group_id');
    	$this->db->where_in('user_id',$userId);
    	$resultGrp = $this->db->get('user_groups');
    	foreach($resultGrp->result_array() as $row){
    		$arrUserGroupIds[$row['group_id']]	= $row['group_id'];
    	}
    	
    	foreach($result->result_array() as $row){
    		/* $row['name'] = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $row['name']);
	    	$row['name'] = trim($row['name']," - ");
    		$arrSurveys[]	= $row; */
    		
    		$arrUserIds			= explode(',',$row['user_ids']);
    		$arrGroupIds		= explode(',',$row['group_ids']);
    		$existsInGroup	= array_intersect($arrUserGroupIds, $arrGroupIds);
    		if(in_array($userId,$arrUserIds) || (sizeof($existsInGroup)>0) || ($roleId==ROLE_MANAGER || $roleId==ROLE_ADMIN)){
    			//$row['start_date']	= sql_date_to_app_date($row['start_date']);
    			//$row['end_date']	= sql_date_to_app_date($row['end_date']);
    			$row['name'] = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $row['name']);
    			$row['name'] = trim($row['name']," - ");
    			$arrSurveys[]		= $row;
    		}
    	}
    	
    	return $arrSurveys;
	}
	/*
	 * To retrieve all the surveys currently active
	 */
	function getActiveSurveys($userId = '',$roleId=''){
		if($userId == '')
			$userId			= $this->session->userdata('user_id');
		if($roleId == '')
			$roleId		= $this->session->userdata('user_role_id');
		$arrSurveys		= array();
		$todays_date 	= date("Y-m-d");
		$arrUserGroupIds	= array();
		$this->db->select('group_id');
		$this->db->where_in('user_id',$userId);
		$resultGrp = $this->db->get('user_groups');
		foreach($resultGrp->result_array() as $row){
			$arrUserGroupIds[$row['group_id']]	= $row['group_id'];
		}
		$this->db->select("*,surveys.id as id, client_users.id as client_id");
    	$this->db->where('surveys.is_active','1');
    	$this->db->where("start_date <='".$todays_date."'");
    	$this->db->where("end_date >='".$todays_date."'");
    	$this->db->order_by('surveys.created_on','desc');
    	$this->db->join('client_users', 'client_users.id =surveys.created_by', 'inner');
    	$client_id = $this->session->userdata('client_id');
    	$this->db->where("client_users.client_id",$client_id);
    	$result = $this->db->get('surveys');
     	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrUserIds			= explode(',',$row['user_ids']);
    		$arrGroupIds		= explode(',',$row['group_ids']);
    		$existsInGroup	= array_intersect($arrUserGroupIds, $arrGroupIds);
    		if(in_array($userId,$arrUserIds) || (sizeof($existsInGroup)>0) || ($roleId==ROLE_MANAGER || $roleId==ROLE_ADMIN)){
				$row['start_date']	= sql_date_to_app_date($row['start_date']);
	    		$row['end_date']	= sql_date_to_app_date($row['end_date']);
	    		$row['name'] = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $row['name']);
	    		$row['name'] = trim($row['name']," - ");
	    		$arrSurveys[]		= $row;
    		}
    	}
    	//exit();
    	return $arrSurveys;
	}
	/*
	 * To get all categories 
	 */
	function getAllCategories(){
		$arrCategories	= array();
    	$this->db->select('survey_categories.id,survey_categories.name');
    	$this->db->order_by('survey_categories.name','asc');
    	$result = $this->db->get('survey_categories');
    	foreach($result->result_array() as $row){
    		$arrCategories[$row['name']]	= $row['id'];
    	}
    	return $arrCategories;
	}
	/*
	 * To save category
	 * @param $categoryName
	 */
	function saveCategory($categoryName){
		$arrData['id']		= 0;
		$arrData['status']	= 'failed';
		$this->db->select('id');
		$this->db->where('name',$categoryName);
		$arrResultData = $this->db->get('survey_categories');
		if($arrResultData->num_rows()>0){
			$resultObj		= $arrResultData->first_row();
			$arrData['id']	= $resultObj->id;
			$arrData['status']	= 'exist';
		}else{
			$arrCategory['name']		= $categoryName;
			$arrCategory['created_by']	= $this->session->userdata('user_id');
			$arrCategory['created_on']	= date("Y-m-d H:i:s");
			if($this->db->insert('survey_categories',$arrCategory)){
				$arrData['id']		= $this->db->insert_id();
				$arrData['status']	= 'saved';
			}
		}
		return $arrData;
	}
	/*
	 * To save question
	 * @param $arrSurveyData
	 */
	function saveQuestion($arrSurveyData){
		$arrData			= $arrSurveyData;
		$arrData['status']	= 'failed';
		$this->db->select('id');
		$this->db->where('category_id',$arrSurveyData['category_id']);
		$this->db->where('role_id',$arrSurveyData['role_id']);
		$this->db->where('question',$arrSurveyData['question']);
		$arrResultData = $this->db->get('survey_questions');
		if($arrResultData->num_rows()>0){
			$arrData['status']	= 'exist';
			$resultObj			= $arrResultData->first_row();
			$arrData['id']		= $resultObj->id;
		}else{
			$arrSurveyData['created_by']	= $this->session->userdata('user_id');
			$arrSurveyData['created_on']	= date("Y-m-d H:i:s");
			if($this->db->insert('survey_questions',$arrSurveyData)){
				$arrData['status']	= 'saved';
				$arrData['id']		= $this->db->insert_id();
			}
		}
		return $arrData;
	}
	/*
	 * To get a question data
	 * @param $id	- question id
	 */
	function getSurveyQuestion($id){
    	$this->db->select('survey_questions.id,survey_questions.question,survey_questions.category_id,survey_questions.type_id,survey_questions.is_enabled');
    	$this->db->join('survey_categories', 'survey_categories.id =survey_questions.category_id', 'left');
    	$this->db->where('survey_questions.id',$id);
    	$result = $this->db->get('survey_questions');
    	return $result->result_array();
	}
	/*
	 * To update a question
	 * @param $arrSurveyData
	 */
	function updateQuestion($arrSurveyData){
		$arrData			= $arrSurveyData;
		$arrData['status']	= 'failed';
		$this->db->select('id');
		$this->db->where('id',$arrSurveyData['id']);
		$arrResultData = $this->db->get('survey_questions');
		if($arrResultData->num_rows()>0){
			$arrData['status']	= 'saved';
			$arrSurveyData['modified_by']	= $this->session->userdata('user_id');
			$arrSurveyData['modified_on']	= date("Y-m-d H:i:s");
			$this->db->where('id',$arrSurveyData['id']);
			$this->db->update('survey_questions',$arrSurveyData);
			$arrData['id']	= $arrSurveyData['id'];
		}
		return $arrData;
	}
	/*
	 * To delete survey
	 * @param $id	- question id
	 */
	function deleteSurveyQuestion($id){
		$this->db->where('id',$id);
		$this->db->delete('survey_questions');
	}
	/*
	 * To get all questions or selected question
	 * @param $arrQuestionIds
	 */
	function getAllQuestions($arrQuestionIds=''){
		$arrSurveys	= array();
    	$this->db->select('survey_questions.id,survey_questions.question,survey_questions.category_id,survey_categories.name as survey_category,survey_questions.role_id,survey_questions.type_id');
    	$this->db->join('survey_categories', 'survey_categories.id =survey_questions.category_id', 'left');
    	if($arrQuestionIds!=''){
    		$this->db->where_in('survey_questions.id',$arrQuestionIds);
    	}
    	$this->db->order_by('survey_categories.name','asc');
    	$result = $this->db->get('survey_questions');
    	foreach($result->result_array() as $row){
    		$arrSurveys[$row['survey_category']]['category_id']	= $row['category_id'];
    		$arrSurveys[$row['survey_category']]['questions'][]	= $row;
    	}
    	return $arrSurveys;
	}
	/*
	 * To save survey
	 * @param $arrSurveyData
	 */
	function saveSurvey($arrSurveyData){
		$arrData['status']	= 'failed';
		$arrSurveyData['created_by']	= $this->session->userdata('user_id');
		$arrSurveyData['created_on']	= date("Y-m-d H:i:s");
		if($this->db->insert('surveys',$arrSurveyData)){
			$arrData['status']	= 'saved';
			$arrData['id']		= $this->db->insert_id();
		}
		return $arrData;
	}
	/*
	 * To update survey
	 * @param $arrSurveyData
	 */
	function updateSurvey($arrSurveyData){
		$arrData['status']	= 'failed';
		$this->db->select('id');
		$this->db->where('id',$arrSurveyData['id']);
		$arrResultData = $this->db->get('surveys');
		if($arrResultData->num_rows()>0){
			$arrData['status']	= 'saved';
			$arrData['id']		= $arrSurveyData['id'];
			$this->db->where('id',$arrSurveyData['id']);
			$this->db->update('surveys',$arrSurveyData);
		}
		return $arrData;
	}
	/*
	 * To delete survey
	 * @param $id	- survey id
	 */
	function deleteSurvey($id){
		$this->deleteSurveyRespondent($id);
		$this->db->where('id',$id);
		$this->db->delete('surveys');
		//Add Log activity
		$arrLogDetails = array(
				'type' => DELET_RECORD,
				'description' => 'Delete surveys',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => '',
				'transaction_id' =>  $id,
				'transaction_table_id' => SURVEYS,
				'transaction_name' => "Delete surveys",
				'parent_object_id' =>  ''
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	
	function delete1YearOldSurvey($surveyId=0,$respondentId=0,$createdBy=0){
		$this->db->select('max(survey_answers.created_on) as recentdate,ADDDATE(max(survey_answers.created_on), INTERVAL 1 YEAR) as max_date, DATEDIFF(NOW(),MAX(survey_answers.created_on)) as no_of_days',false);
		$this->db->where('survey_answers.survey_id',$surveyId);
		$this->db->where('survey_answers.respondent_id',$respondentId);
		//$this->db->where('survey_answers.created_by',$createdBy);
		$resultSet	= $this->db->get('survey_answers');
		if($resultSet->num_rows()>0){
			$arrRow	= $resultSet->result_array();
			$surveyRecentDate	= $arrRow[0]['recentdate'];
			$surveyDeleteDate	= $arrRow[0]['max_date'];
			$currentDate	= date("Y-m-d H:i:s");
			if($surveyDeleteDate<$currentDate){
				$this->deleteSurveyRespondent($surveyId,$respondentId,$createdBy);
				return true;
			}
		}
		return false;
	}
	/*
	 * To delete survey respondent
	 * @param $surveyId,$respondentId,$createdBy
	 */
	function deleteSurveyRespondent($surveyId=0,$respondentId=0,$createdBy=0){
		$this->db->where('survey_answers.survey_id',$surveyId);
		if($respondentId>0){
			$this->db->where('survey_answers.respondent_id',$respondentId);
		}
		if($createdBy>0){
			$this->db->where('survey_answers.created_by',$createdBy);
		}
		$this->db->delete('survey_answers');
		//Add Log activity
		$arrLogDetails = array(
				'type' => DELET_RECORD,
				'description' => 'Delete survey respondent',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => '',
				'transaction_id' =>  $respondentId,
				'transaction_table_id' => SURVEY_ANSWERS,
				'transaction_name' => "Delete survey respondent",
				'parent_object_id' =>  ''
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	/*
	 * To get all respondent of survey
	 * @param $surveyId, $createdBy and $id	- respondent
	 */
    function getRespondents($surveyId,$id='',$createdBy=''){		
		$arrKolNames	= array();
		$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
		$this->db->select(array('distinct(survey_answers.respondent_id) as id','concat('.$nameFormatOrder.') as respondent',
				'kol_names_for_survey.organization','kol_names_for_survey.source_table','kol_names_for_survey.source_table_id',
				'kol_names_for_survey.speciality','kol_names_for_survey.country as respondent_country','kol_names_for_survey.state as respondent_state',
				'kol_names_for_survey.city as respondent_city','kol_names_for_survey.postal_code as respondent_postal',
				'survey_answers.created_by','CONCAT(client_users.first_name, " ", client_users.last_name) as username',
				'surveys.end_date','survey_answers.resp_address_id','survey_answers.zeroInfluencers','survey_answers.respondent_id as kol_id',
				'survey_answers.created_on','kols.gender'
		));
		//$this->db->distinct('survey_kol_names.id');
		/* $this->db->select('survey_answers.respondent_id as id,concat(kol_names_for_survey.first_name, " ", kol_names_for_survey.middle_name, " ", kol_names_for_survey.last_name) as respondent,
							kol_names_for_survey.organization, kol_names_for_survey.source_table_id, kol_names_for_survey.speciality, countries.country as respondent_country,regions.region as respondent_state,cities.City as respondent_city,
							kol_names_for_survey.postal_code as respondent_postal,survey_answers.created_by,
							CONCAT(client_users.first_name," ",client_users.last_name) as username,
							surveys.end_date,survey_answers.resp_address_id,survey_answers.zeroInfluencers,survey_answers.resp_kol_id as kol_id,survey_answers.created_on',false); */
		
	//	$this->db->join('icontacts','icontacts.id = survey_answers.respondent_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.respondent_id','left');
		$this->db->join('kols','kols.id = kol_names_for_survey.source_table_id','left');
		#$this->db->join('countries','countries.Country = kol_names_for_survey.country','left');
		#$this->db->join('regions','regions.Region = kol_names_for_survey.state','left');
		#$this->db->join('cities','kol_names_for_survey.city = cities.City','left');
	
	//	$this->db->join('postal_codes','postal_codes.id = additional_contacts.postal_code_id','left');
		$this->db->join('surveys','surveys.id = survey_answers.survey_id','left');
		$this->db->join('client_users', 'client_users.id =survey_answers.created_by', 'left');
		$this->db->where('survey_answers.survey_id',$surveyId);
//		if($this->session->userdata('user_role_id') != ROLE_MANAGER){
//			$this->db->where('survey_answers.created_by',$this->session->userdata('user_id'));
//		}
		if(!empty($id)){
			$this->db->where('survey_answers.respondent_id',$id);
		}
		if(!empty($createdBy)){
			$this->db->where('survey_answers.created_by',$createdBy);
		}
//		$this->db->group_by('survey_answers.respondent_id');
		$this->db->order_by('survey_answers.created_on','asc');
		$this->db->where('( survey_answers.zeroInfluencers != 99 or survey_answers.zeroInfluencers is null )');
		$result	= $this->db->get('survey_answers');
		
		//pr($this->db->last_query());exit;
		//print($result);
		foreach($result->result_array() as $row){
			$row['survey_id']	= $surveyId;
			$arrKolNames[$row['id']]		= $row;
//			$arrKolNames[]		= $row;
		}
//		return $arrKolNames;
		return array_values($arrKolNames);
	}
	/*
	 * View get all questions and its answers from a respondent
	 * @param $surveyId, $respondentId and $createdBy
	 */
	function viewSurveyResult($surveyId,$respondentId,$createdBy=0){
		$arrSurveys			= array();
		$arrQuestionIds		= array();
		$arrSurveyAnswers	= array();
		$arrSurveyData		= array();
		$this->db->where('id',$surveyId);
		$arrResultData = $this->db->get('surveys');
		if($arrResultData->num_rows()>0){
			$resultObj				= $arrResultData->first_row();
			$arrSurveyData['id']	= $surveyId;
			$arrSurveyData['name']	= $resultObj->name;
			$arrQuestionIds			= explode(',',$resultObj->question_ids);
			$arrSurveyData['description']	= $resultObj->description;
			$arrSurveyData['created_by']	= $resultObj->created_by;
			$arrSurveyData['end_date']		= $resultObj->end_date;
		}
    	$this->db->select('survey_questions.id,survey_questions.question,survey_questions.category_id,survey_categories.name as survey_category,survey_roles.name as role,survey_questions.role_id,survey_questions.type_id');
    	$this->db->join('survey_categories', 'survey_categories.id =survey_questions.category_id', 'left');
    	$this->db->join('survey_roles', 'survey_roles.id =survey_questions.role_id', 'left');
    	$this->db->where_in('survey_questions.id',$arrQuestionIds);
    	$this->db->order_by('survey_categories.name','asc');
    	$result = $this->db->get('survey_questions');
    	foreach($result->result_array() as $row){
    		$arrSurveys[$row['survey_category']][]	= $row;
    	}
		$this->db->select('survey_answers.*, concat(kol_names_for_survey.first_name, " ", kol_names_for_survey.middle_name, " ", kol_names_for_survey.last_name ) AS name, kol_names_for_survey.country, kol_names_for_survey.city, kol_names_for_survey.state, kol_names_for_survey.postal_code as postal, CONCAT(client_users.first_name, " ", client_users.last_name) as created_user,kol_names_for_survey.source_table,kol_names_for_survey.source_table_id,kols.gender',false);
		//$this->db->join('icontacts','icontacts.id = survey_answers.nominee_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		$this->db->join('kols','kols.id = kol_names_for_survey.source_table_id','left');
		//$this->db->join('countries','countries.Country = kol_names_for_survey.country','left');
		//$this->db->join('regions','regions.Region = kol_names_for_survey.state','left');
		//$this->db->join('cities','kol_names_for_survey.city = cities.City','left');
		//$this->db->join('postal_codes','postal_codes.id = kol_names_for_survey.postal_code','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
    	$this->db->where('survey_answers.survey_id',$surveyId);
    	$this->db->where('survey_answers.respondent_id',$respondentId);
    	$this->db->where('survey_answers.is_deleted','0');
//    	if($createdBy>0){
//    		$this->db->where('survey_answers.created_by',$createdBy);
//    	}
    	$this->db->group_by('survey_answers.nominee_id,survey_answers.question_id');
    	$this->db->order_by('survey_answers.question_id','asc');
    	$this->db->order_by('survey_answers.created_on','asc');
    	$result = $this->db->get('survey_answers');
    	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrDateTime	= explode(' ',$row['created_on']);
    		$row['created_on']	= sql_date_to_app_date($arrDateTime[0]);
    		$arrSurveyAnswers[$row['question_id']][]	= $row;
    	}
    	
    	return array('arrQuestionData'=>$arrSurveys,'arrAnswerData'=>$arrSurveyAnswers,'arrSurveyData'=>$arrSurveyData);
	}
	/*
	 * To check and ensure uniqueness of respondent
	 * @param $arrData
	 */
	function isRespondentAlreadySurveyed($arrData){
		$this->db->select('survey_answers.respondent_id,survey_answers.resp_address_id,survey_answers.id,CONCAT(client_users.first_name," ",client_users.last_name) as created_user,survey_answers.created_on,survey_answers.created_by,CONCAT(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name) as respoName',false);
		$this->db->join('icontacts','icontacts.id = survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
    	//$this->db->where('survey_answers.created_by!=',$arrData['created_by'],false);
    	$this->db->where('survey_answers.respondent_id',$arrData['respondent_id']);
    	$this->db->where('survey_answers.survey_id',$arrData['survey_id']);
    	//$this->db->where('survey_answers.nominee_id>',0,false);
    	$this->db->where('survey_answers.is_deleted','0');
    	$this->db->order_by('survey_answers.created_on','desc');
    	$this->db->limit(1);
    	$result = $this->db->get('survey_answers');
    	echo $this->db->last_query();
    	exit;
//		echo $this->db->last_query();
    	if($result->num_rows()>0){
    		$arrRow	= array();
    		$arrRow	= $result->result_array();
//    		pr($arrRow);
//    		exit;
    		$arrMsg['respondent_id']	= $arrRow[0]['respondent_id'];
    		$arrMsg['resp_address_id']	= $arrRow[0]['resp_address_id'];
			$arrMsg['status']	= 'exists';
			$arrMsg['recent_user']	= $arrRow[0]['created_user'];
			$arrMsg['created_by']	= $arrRow[0]['created_by'];
			$date = strtotime($arrRow[0]['created_on']);
    		$dat = date('F d, Y', $date);
			$arrMsg['created_on']	= $dat;
			$arrMsg['respoName']	= $arrRow[0]['respoName'];
			
		}else{
			$arrMsg['status']	= 'new';
		}
//		pr($arrRow);
//    	exit;
		return $arrMsg;
	}
	
	function isRespondentAlreadySurveyedNew($arrData){
		$query	= 'SELECT survey_answers.respondent_id, 
survey_answers.resp_address_id, 
survey_answers.id,
CONCAT(client_users.first_name, " ", client_users.last_name) as created_user, 
survey_answers.created_on, 
survey_answers.created_by, 
CONCAT(kol_names_for_survey.first_name, " ", kol_names_for_survey.middle_name, " ", kol_names_for_survey.last_name) as respoName
FROM (survey_answers)
LEFT JOIN kol_names_for_survey ON kol_names_for_survey.id = survey_answers.respondent_id
LEFT JOIN client_users ON client_users.id=survey_answers.created_by
WHERE CONCAT(kol_names_for_survey.first_name, " ", kol_names_for_survey.middle_name, " ", kol_names_for_survey.last_name) = "'.$arrData['respondent_id'].'"
AND `survey_answers`.`survey_id` = '.$arrData["survey_id"].'
AND `survey_answers`.`is_deleted` = "0"
ORDER BY survey_answers.created_on desc
LIMIT 1';
		$result = $this->db->query($query);
				echo $this->db->last_query();
				exit;
		if($result->num_rows()>0){
			$arrRow	= array();
			$arrRow	= $result->result_array();
			//    		pr($arrRow);
			//    		exit;
			$arrMsg['respondent_id']	= $arrRow[0]['respondent_id'];
			$arrMsg['resp_address_id']	= $arrRow[0]['resp_address_id'];
			$arrMsg['status']	= 'exists';
			$arrMsg['recent_user']	= $arrRow[0]['created_user'];
			$arrMsg['created_by']	= $arrRow[0]['created_by'];
			$date = strtotime($arrRow[0]['created_on']);
			$dat = date('F d, Y', $date);
			$arrMsg['created_on']	= $dat;
			$arrMsg['respoName']	= $arrRow[0]['respoName'];
				
		}else{
			$arrMsg['status']	= 'new';
		}
		//		pr($arrRow);
		//    	exit;
		return $arrMsg;
	}
	
	function getRespondentDetails($surveyId,$respondentId,$respondentAddressId){
		$this->db->select('survey_answers.zeroInfluencers,CONCAT(icontacts.last_name,", ",icontacts.first_name," ",icontacts.middle_name) AS name,additional_contacts.country_name,additional_contacts.state_name,additional_contacts.city_name,additional_contacts.postal_code,icontacts.master_customer_id as mdm',false);
		$this->db->join('icontacts','icontacts.id = survey_answers.respondent_id','left');
		$this->db->join('additional_contacts','additional_contacts.id = survey_answers.resp_address_id','left');
		$this->db->where('survey_answers.respondent_id',$respondentId);
		$this->db->where('survey_answers.resp_address_id',$respondentAddressId);
		$this->db->where('survey_answers.survey_id',$surveyId);
		$this->db->where('survey_answers.is_deleted','0');
		$this->db->limit(1);
		$this->db->order_by('survey_answers.id','desc');
    	$result = $this->db->get('survey_answers');
    	if($result->num_rows()!=1){
    		$this->db->select('CONCAT(icontacts.last_name,", ",icontacts.first_name," ",icontacts.middle_name) AS name,additional_contacts.country_name,additional_contacts.state_name,additional_contacts.city_name,additional_contacts.postal_code,icontacts.master_customer_id as mdm',false);
			$this->db->join('additional_contacts','additional_contacts.kol_id = icontacts.id','left');
			$this->db->where('icontacts.id',$respondentId);
			$this->db->where('additional_contacts.id',$respondentAddressId);
			$this->db->limit(1);
	    	$result = $this->db->get('icontacts');
    	}
    	$arrRow	= $result->result_array();
    	return $arrRow[0];
	}
	/*
	 * To check survey name is unique
	 * @param $arrData
	 */
	function isValidateSurveyName($arrData){
		$this->db->select('id');
		if(isset($arrData['id'])){
			$this->db->where_not_in('id',$arrData['id']);
		}
    	$this->db->where('surveys.name',$arrData['survey_name']);
    	$this->db->where('surveys.start_date',$arrData['start_date']);
    	$this->db->where('surveys.end_date',$arrData['end_date']);
    	$result = $this->db->get('surveys');
		if($result->num_rows()>0){
			$arrMsg['status']	= 'exists';
		}else{
			$arrMsg['status']	= 'new';
		}
		return $arrMsg;
	}
	/*
	 * To get surveys which are expired/ended
	 */
	function getCompletedSurveys(){
		$arrData		= array();
		$userId			= $this->session->userdata('user_id');
		$todays_date 	= date("Y-m-d");
		$arrUserGroupIds	= array();
		$this->db->select('group_id');
		$this->db->where_in('user_id',$userId);
		$resultGrp = $this->db->get('user_groups');
		foreach($resultGrp->result_array() as $row){
			$arrUserGroupIds[$row['group_id']]	= $row['group_id'];
		}
		$this->db->distinct('id');
		$this->db->select('surveys.id,surveys.name,survey_answers.survey_id,surveys.user_ids,surveys.group_ids');
		$this->db->join('surveys','surveys.id=survey_answers.survey_id','inner');
		//$this->db->where("surveys.end_date <'".$todays_date."'");
		$this->db->where("surveys.start_date <='".$todays_date."'");
		$this->db->where("surveys.is_active",'1');
    	//$this->db->order_by('surveys.name','asc');
    	$this->db->order_by('surveys.created_on','desc');
    	$result = $this->db->get('survey_answers');
    	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrUserIds			= explode(',',$row['user_ids']);
    		$arrGroupIds		= explode(',',$row['group_ids']);
    		$existsInGroup	= array_intersect($arrUserGroupIds, $arrGroupIds);
    		if(in_array($userId,$arrUserIds) || (sizeof($existsInGroup)>0) || ($this->session->userdata('user_role_id')==ROLE_MANAGER)){
    		//if(in_array($userId,$arrUserIds) || ($this->session->userdata('user_role_id')==ROLE_MANAGER)){
    		$row['name'] = preg_replace('/<span\b[^>]*>(.*?)<\/span>/i', '', $row['name']);
	    	$row['name'] = trim($row['name']," - ");
				$arrData[]		= $row;
    		}
    	}
    	return $arrData;
	}
	/*
	 * To get top 10 influencers
	 * @param $surveyId, $arrFilters
	 */
	function topNominees($surveyId,$arrSelections=''){
		$arrData	= array();
		$this->db->select('kol_names_for_survey.id,kol_names_for_survey.search_name as name,kol_names_for_survey.country,kol_names_for_survey.state,kol_names_for_survey.city, kol_names_for_survey.postal_code, count(survey_answers.respondent_id) as count',false);
    	//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id=survey_answers.nominee_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
		//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
		//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		$this->db->where('survey_id',$surveyId);
    	foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->where_in('regions.region',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->where_in('cities.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}
		$this->db->where('survey_answers.nominee_id>',0,false);
    	$this->db->group_by('kol_names_for_survey.id,kol_names_for_survey.country,kol_names_for_survey.state,kol_names_for_survey.city,kol_names_for_survey.postal_code');
    	$this->db->order_by('count','desc');
    	$this->db->order_by('name','asc');
    	$this->db->limit(10,0);
    	$this->db->where('survey_answers.is_deleted','0');
    	$result = $this->db->get('survey_answers');
    	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrData[]		= $row;
    	}
    	return $arrData;
	}
	/*
	 * To get influencers with user
	 * @param $surveyId
	 */
	function userNominees($surveyId){
		$arrData	= array();
		$this->db->select('concat(client_users.first_name," ",client_users.last_name) as username, survey_answers.name, count(name) as count',false);
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
    	$this->db->where('survey_id',$surveyId);
    	$this->db->group_by('username,name');
    	$this->db->order_by('count','desc');
    	$result = $this->db->get('survey_answers');
    	foreach($result->result_array() as $row){
    		$arrData[]		= $row;
    	}
    	return $arrData;
	}
	/*
	 * To get respondents with user
	 * @param $surveyId
	 */
	function userRespondents($surveyId){
		$arrData	= array();
		$this->db->select('concat(client_users.first_name," ",client_users.last_name) as username, concat(kols.first_name," ",kols.middle_name," ",kols.last_name) as name, count(survey_answers.respondent_id) as count',false);
		$this->db->join('client_users','client_users.id=survey_answers.created_by','inner');
		$this->db->join('kols','kols.id=survey_answers.respondent_id','inner');
    	$this->db->where('survey_id',$surveyId);
    	$this->db->group_by('client_users.first_name,client_users.last_name,survey_answers.respondent_id');
    	$this->db->order_by('count','desc');
    	$result = $this->db->get('survey_answers');
    	foreach($result->result_array() as $row){
    		$arrData[]		= $row;
    	}
    	return $arrData;
	}
	/*
	 * To get no. users participated
	 * @param $surveyId
	 */
	function actualUsersRespondedCount($surveyId,$arrSelections=array()){
		$this->db->select('count(distinct(survey_answers.created_by)) as count');
		$this->db->where('survey_answers.survey_id',$surveyId);
		//$this->db->where('client_users.id is not null');
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.respondent_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
								$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->where_in('kol_names_for_survey.city',$arrSelectedData['city']);
								//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
								$this->db->where_in('kol_names_for_survey.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}

		$this->db->group_by('survey_answers.created_by');
		//$this->db->where('survey_answers.is_deleted','0');
		
		$result = $this->db->get('survey_answers');
		$result = $result->result_array();
		//pr($result);
		//pr($this->db->last_query());exit;
		return $result['0']['count'];
	}
	/*
	 * To get no. respondents participated
	 * @param $surveyId
	 */
	function actualRespondentsCount($surveyId,$arrSelections=array()){
		$this->db->select('count(survey_answers.respondent_id)');
		$this->db->where('survey_id',$surveyId);
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
								$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
								$this->db->where_in('kol_names_for_survey.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
								$this->db->where_in('kol_names_for_survey.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}
	
		$this->db->group_by('survey_answers.respondent_id');
		$this->db->where('survey_answers.is_deleted','0');
		$result = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		return $result->num_rows();
	}
	/*
	 * To get no. influencers participated
	 * @param $surveyId
	 */
	function actualNomineesCount($surveyId,$arrSelections=array()){
		//echo $surveyId;
		$this->db->select('count(*) as count');
		$this->db->where('survey_answers.survey_id',$surveyId);
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
		//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
		//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->where_in('kol_names_for_survey.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->where_in('kol_names_for_survey.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}
	
		$this->db->where('survey_answers.nominee_id>',0,false);
		//$this->db->group_by('survey_answers.name,survey_answers.country,survey_answers.state,survey_answers.city,survey_answers.postal');
		//$this->db->group_by('icontacts.id,additional_contacts.country_id,additional_contacts.state_id,additional_contacts.city_id,additional_contacts.postal_code_id');
		//$this->db->where('survey_answers.is_deleted','0');
		$result = $this->db->get('survey_answers');
		$result = $result->result_array();
		//pr($result);
		//pr($this->db->last_query());exit;
		return $result['0']['count'];
	}
	/*
	 * expected and actual participants in survey
	 * @param $surveyId
	 */
	function expectedAndActualRespondents($surveyId){
		$actualRespondentCount	= $this->actualRespondentsCount($surveyId);
		$actualUsersCount		= $this->actualUsersRespondedCount($surveyId);
		$this->db->select('count( distinct kols.id)');
		$this->db->where('kols.status',COMPLETED);
		$this->db->group_by('kols.id');
		$result = $this->db->get('kols');
		$kolsCount	= $result->num_rows();
		$this->db->select('count( distinct client_users.id)');
		$this->db->where('client_users.client_id',$this->session->userdata('client_id'));
		$this->db->group_by('client_users.id');
		$result = $this->db->get('client_users');
		$clientsCount	= $result->num_rows();
		$arrData[]	= array('name'=>'Respondents',	'data' => array($clientsCount,$actualRespondentCount));
		$arrData[]	= array('name'=>'Users'		,	'data' => array($clientsCount,$actualUsersCount));
		return $arrData;
	}
	/*
	 * To get data based on refined by filters
	 * @param $arrFilterFields, $filterSection
	 */
	function loadFilterData($arrFilterFields,$filterSection){
		$arrData	= array();
		$this->db->select('count( distinct survey_answers.respondent_id) as count');
		$this->db->join('kols','kols.id=survey_answers.respondent_id','inner');
		$this->db->join('countries','countries.CountryId=kols.country_id','inner');
		$this->db->join('regions','regions.RegionID=kols.state_id','inner');
		$this->db->join('specialties','specialties.id=kols.specialty','inner');
		$this->db->join('list_kols','list_kols.kol_id=kols.id','inner');
		$this->db->join('list_names','list_names.id=list_kols.list_name_id','inner');
		foreach($arrFilterFields as $key=>$arrSelections){
			if(!empty($arrSelections))
			switch($key){
				case 'country':
						$this->db->where_in('countries.Country',$arrSelections);
					break;
				case 'state':
						$this->db->where_in('kols.state_id',$arrSelections);
					break;
				case 'specialty':
						$this->db->where_in('specialties.specialty',$arrSelections);
					break;
				case 'list':
						$this->db->where_in('list_names.list_name',$arrSelections);
					break;
			}
		}
		switch($filterSection){
			case 'country':
					$this->db->select('countries.Country as country');
					$this->db->group_by('kols.country_id');
				break;
			case 'state':
					$this->db->select('regions.Region as state,kols.state_id');
					$this->db->group_by('kols.state_id');
				break;
			case 'specialty':
					$this->db->select('specialties.specialty as specs');
					$this->db->group_by('kols.specialty');
				break;
			case 'list':
					$this->db->select('list_names.list_name, list_kols.list_name_id');
					$this->db->group_by('list_kols.list_name_id');
				break;
		}
		$this->db->order_by('count','desc');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[]	= $row;
    	}
		return $arrData;
	}
	/*
	 * To get influencers with specialties
	 * @param $surveyId
	 */
	function nomineesBySpecialty($surveyId,$arrSelections=array()){
		$arrData	= array();
		$this->db->select('survey_categories.name as specialty,count(*) as count');
		$this->db->join('survey_questions','survey_questions.id=survey_answers.question_id','inner');
		$this->db->join('survey_categories','survey_categories.id=survey_questions.category_id','inner');
		$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('additional_contacts','additional_contacts.id = survey_answers.nom_address_id','left');
		$this->db->where('survey_id',$surveyId);
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
								$this->db->where_in('regions.region',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
								$this->db->where_in('cities.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
								$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
			}
		}

		$this->db->group_by('survey_categories.name');
		$this->db->order_by('count','desc');
		$this->db->order_by('specialty','asc');
		$result = $this->db->get('survey_answers');
		// $this->db->last_query();exit();
		foreach($result->result_array() as $row){
    		$arrData[]	= array($row['specialty'],(int)$row['count']);
    	}
		return $arrData;
	}
	/*
	 * To get influencers with states
	 * @param $surveyId
	 */
	function nomineesByState($surveyId,$arrSelections=array()){
		
		$arrData	= array();
		$this->db->select('kol_names_for_survey.state as state,count(distinct survey_answers.nominee_id) as count');
		$this->db->where('survey_id',$surveyId);
		//$this->db->where_not_in('additional_contacts.state_id','');
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
								$this->db->where_in('cities.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
								$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}

		$this->db->group_by('kol_names_for_survey.state');
		$this->db->order_by('count','desc');
		$this->db->order_by('kol_names_for_survey.state','asc');
		$this->db->where('survey_answers.is_deleted','0');
		$this->db->where('survey_answers.nominee_id>',0,false);
		$result = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		foreach($result->result_array() as $row){
    		$arrData[]	= array($row['state'],(int) $row['count']);
    	}
		return $arrData;
	}
	
	function respondentByState($surveyId,$arrSelections=array()){
		$arrData	= array();
		$this->db->select('kol_names_for_survey.state as state,count(distinct survey_answers.respondent_id) as count');
		$this->db->where('survey_id',$surveyId);
		//$this->db->where_not_in('additional_contacts.state_id','');
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.respondent_id','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('additional_contacts as nom_contacts','nom_contacts.id = survey_answers.nom_address_id','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								//$this->db->join('regions as nom_regions','nom_regions.regionId=nom_contacts.state_id','left');
								$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								
								//$this->db->join('cities as nom_cities','nom_cities.cityId=nom_contacts.city_id','left');
								$this->db->where_in('kol_names_for_survey.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								//$this->db->join('postal_codes as nom_postal','nom_postal.id=nom_contacts.postal_code_id','left');
								$this->db->where_in('kol_names_for_survey.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								//$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
					break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
					break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
					break;
			}
		}

		$this->db->group_by('kol_names_for_survey.state');
		$this->db->order_by('count','desc');
		$this->db->order_by('kol_names_for_survey.state','asc');
		$this->db->where('survey_answers.is_deleted','0');
		$result = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		foreach($result->result_array() as $row){
    		$arrData[]	= array($row['state'],(int) $row['count']);
    	}
		return $arrData;
	}
	/*
	 * To populate report builder
	 * @param $surveyId
	 */
	function loadCustomQueryData($surveyId){
		$arrData	= array();
		$arrData['nominees']	= $this->getUniqueNominees($surveyId);
		$arrData['specialties']	= $this->getSpecialties($surveyId);
		$arrData['countries']	= $this->getNomineesCountries($surveyId);
		$arrData['states']		= $this->getNomineesStates($surveyId);
		$arrData['cities']		= $this->getNomineesCities($surveyId);
		$arrData['postalcodes']	= $this->getNomineesPostalCode($surveyId);
		$arrRespondentsData		= $this->getUniqueRespondents($surveyId);
		$arrData['respondents']	= $arrRespondentsData['respondents'];
		$arrData['respondent_countries']= $arrRespondentsData['countries'];
		$arrData['respondent_states']	= $arrRespondentsData['states'];
		$arrData['respondent_cities']	= $arrRespondentsData['cities'];
		$arrData['respondent_postal']	= $arrRespondentsData['postal'];
		return $arrData;
	}
	/*
	 * To get all specialties of survey
	 * @param $surveyId
	 */
	function getSpecialties($surveyId){
		$arrData	= array();
		$this->db->select('survey_categories.name as specialty,survey_categories.id');
		$this->db->join('survey_questions','survey_questions.id=survey_answers.question_id','inner');
		$this->db->join('survey_categories','survey_categories.id=survey_questions.category_id','inner');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('survey_categories.name');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['id']]	= $row['specialty'];
    	}
		return $arrData;
	}
	/*
	 * To get all countries of influencers
	 * @param $surveyId
	 */
	function getNomineesCountries($surveyId){
		$arrData	= array();
		$this->db->select('country');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('country');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['country']]	= $row['country'];
    	}
		return $arrData;
	}
	/*
	 * To get all states of influencers
	 * @param $surveyId
	 */
	function getNomineesStates($surveyId){
		$arrData	= array();
		$this->db->select('regions.region as state');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('regions.region');
		$this->db->join('icontacts','survey_answers.respondent_id=icontacts.id','left');
		$this->db->join('additional_contacts','survey_answers.resp_address_id=additional_contacts.id','left');
		$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['state']]	= $row['state'];
    	}
		return $arrData;
	}
	/*
	 * To get all cities of influencers
	 * @param $surveyId
	 */
	function getNomineesCities($surveyId){
		$arrData	= array();
		$this->db->select('city');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('city');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['city']]	= $row['city'];
    	}
		return $arrData;
	}
	/*
	 * To get all postal code of influencers
	 * @param $surveyId
	 */
	function getNomineesPostalCode($surveyId){
		$arrData	= array();
		$this->db->select('postal');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('postal');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['postal']]	= $row['postal'];
    	}
		return $arrData;
	}
	/*
	 * To get all unqiue influencers
	 * @param $surveyId
	 */
	function getUniqueNominees($surveyId){
		$arrData	= array();
		$this->db->select('survey_kol_names.name');
		$this->db->join('survey_kol_names','survey_kol_names.id = survey_answers.nominee_id','left');
		$this->db->where('survey_answers.survey_id',$surveyId);
		$this->db->group_by('survey_kol_names.name');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData[$row['name']]	= trim($row['name']);
    	}
		return $arrData;
	}
	/*
	 * To get all unique respondents
	 * @param $surveyId
	 */
	function getUniqueRespondents($surveyId){
		$arrData	= array();
		$this->db->select('survey_answers.respondent_id, survey_kol_names.name as respondent,survey_answers.respondent_country as country,survey_answers.respondent_state as state,survey_answers.respondent_city as city,survey_answers.respondent_postal as postal',false);
		$this->db->join('survey_kol_names','survey_kol_names.id = survey_answers.respondent_id','left');
    	$this->db->where('survey_answers.survey_id',$surveyId);
    	$this->db->group_by('survey_answers.respondent_id');
    	$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
    		$arrData['respondents'][$row['respondent_id']]	= $row['respondent'];
    		$arrData['countries'][$row['country']]	= $row['country'];
    		$arrData['states'][$row['state']]	= $row['state'];
    		$arrData['cities'][$row['city']]	= $row['city'];
    		$arrData['postal'][$row['postal']]	= $row['postal'];
    	}
		return $arrData;
	}
	/*
	 * To get data based on report builder
	 * @param $arrData	- Data from report builder
	 */
	function load_query_result($arrSelections){
		$arrReturnData	= array();
		$this->db->select('icontacts.id,concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name) as name,countries.country,regions.region as state,cities.city, postal_codes.postal_code, count(survey_answers.respondent_id) as count,organizations.id as survey_org_id,organizations.name as org_name,organizations.id as org_id',false);
		$this->db->select('survey_answers.respondent_id,survey_answers.survey_id,survey_answers.created_by');
		$this->db->join('survey_questions','survey_questions.id=survey_answers.question_id','inner');
		$this->db->join('survey_categories','survey_categories.id=survey_questions.category_id','inner');
		$this->db->join('icontacts','icontacts.id = survey_answers.nominee_id','left');
		
		//$this->db->join('survey_org_names','survey_org_names.id = survey_answers.nominee_org_id','left');
		$this->db->join('organizations','organizations.id = icontacts.org_id','left');
		
		$this->db->join('regions','regions.regionId=icontacts.state_id','left');
		$this->db->join('countries','countries.countryId=icontacts.country_id','left');
		$this->db->join('cities','cities.cityId=icontacts.city_id','left');
		$this->db->join('postal_codes','postal_codes.id=icontacts.postal_code_id','left');
		
		$this->db->where('survey_answers.survey_id',$arrSelections['survey_id']);
		/* if(!empty($arrData['nominee']['name'])){
			$this->db->where_in('survey_answers.name',$arrData['nominee']['name']);
		}
		if(!empty($arrData['nominee']['city'])){
			$this->db->where_in('survey_answers.city',$arrData['nominee']['city']);
		}
		if(!empty($arrData['nominee']['country'])){
			$this->db->where_in('survey_answers.country',$arrData['nominee']['country']);
		}
		if(!empty($arrData['nominee']['postal'])){
			$this->db->where_in('survey_answers.postal',$arrData['nominee']['postal']);
		}
		if(!empty($arrData['nominee']['state']) && (sizeof($arrData['nominee']['state'])>0 && !empty($arrData['nominee']['state'][0]))){
			$this->db->where_in('survey_answers.state',$arrData['nominee']['state']);
		}
		if(!empty($arrData['nominee']['type'])){
			$this->db->where('survey_questions.type_id',$arrData['nominee']['type']);
		}
		if(!empty($arrData['nominee']['specialty'])){
			$this->db->where_in('survey_categories.id',$arrData['nominee']['specialty']);
		}
		if(!empty($arrData['respondent']['id'])){
			$this->db->where_in('survey_answers.respondent_id',$arrData['respondent']['id']);
		}
		if(!empty($arrData['respondent']['state'])){
			$this->db->where_in('survey_answers.respondent_state',$arrData['respondent']['state']);
		}
		if(!empty($arrData['respondent']['city'])){
			$this->db->where_in('survey_answers.respondent_city',$arrData['respondent']['city']);
		}
		if(!empty($arrData['respondent']['postal'])){
			$this->db->where_in('survey_answers.respondent_postal',$arrData['respondent']['postal']);
		} */
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
						if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
							//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
							$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
						}
						if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
							$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
						}
						if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
							$this->db->where_in('countries.country',$arrSelectedData['country']);
						}
						if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
							$this->db->where_in('regions.region',$arrSelectedData['state']);
						}
						if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
							$this->db->where_in('cities.city',$arrSelectedData['city']);
						}
						if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
							$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
						}
						break;
					case 'respondents':
						if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
							//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
							$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
						}
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
			}
		}
		$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->group_by('icontacts.id,icontacts.country_id,icontacts.state_id,icontacts.city_id,icontacts.postal_code_id');
		$this->db->order_by('count','desc');
		$this->db->order_by('name','asc');
		$result = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($result->result_array() as $row){
			$respondent			= '';
			$row['microview']	= '';
			$row['count']	= '<a href="#" onclick="showIndivisualSurveyConnections(this,true);return false;">'.$row['count'].'</a>';
		
			$respondent	= $row['name'];
			
			
			if($row['org_name']==null){
				$row['org_name']	= "Not Available";
				$row['org_microview']	= "";
			}
			/*$row['action']	= '';
			if($this->session->userdata('user_role_id')==ROLE_MANAGER && $this->session->userdata('client_id')==INTERNAL_CLIENT_ID){
				$row['action']	= "<div class='actionIcon editIcon' onclick='editSurveyData(".$row['respondent_id'].",".$row['survey_id'].",".$row['created_by']."); return false;'><a href='#' class='tooltipLink' rel='tooltip' data-original-title='Edit'></a></div>";
			}*/
    		$arrReturnData[]	= $row;
    	}
		return $arrReturnData;
	}
	/*
	 * To save role
	 * @param $roleName
	 */
	function saveRole($roleName){
		$arrData['id']		= 0;
		$arrData['status']	= 'failed';
		$this->db->select('id');
		$this->db->where('name',$roleName);
		$arrResultData = $this->db->get('survey_roles');
		if($arrResultData->num_rows()>0){
			$resultObj		= $arrResultData->first_row();
			$arrData['id']	= $resultObj->id;
			$arrData['status']	= 'exist';
		}else{
			$arrRole['name']		= $roleName;
			$arrRole['created_by']	= $this->session->userdata('user_id');
			$arrRole['created_on']	= date("Y-m-d H:i:s");
			if($this->db->insert('survey_roles',$arrRole)){
				$arrData['id']		= $this->db->insert_id();
				$arrData['status']	= 'saved';
			}
		}
		return $arrData;
	}
	/*
	 * To get all roles
	 */
	function getAllRoles(){
		$arrRoles	= array();
    	$this->db->select('survey_roles.id,survey_roles.name');
    	$this->db->order_by('survey_roles.name','asc');
    	$result = $this->db->get('survey_roles');
    	foreach($result->result_array() as $row){
    		$arrRoles[$row['name']]	= $row['id'];
    	}
    	return $arrRoles;
	}
	/*
	 * To get summary details of participants
	 * @param $arrData
	 */
	function loadSummeryDetails($arrData,$arrSelections=array(),$byId='',$respOrUser=''){
		$arrReturnData	= array();
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('icontacts','icontacts.id = survey_answers.nominee_id','left');
		$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
		$this->db->join('additional_contacts','additional_contacts.id = survey_answers.nom_address_id','left');
		$this->db->join('additional_contacts as resp_contacts','resp_contacts.id = survey_answers.resp_address_id','left');
		$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		$isJoined=false;
		switch($arrData['participant']){
			case 'respondents':
					if($byId != ''){
						$this->db->select('CASE
									WHEN survey_questions.type_id = 1 THEN "Local"
									WHEN survey_questions.type_id = 2 THEN "National"
									WHEN survey_questions.type_id = 3 THEN "Global"
									END AS type',false);
							$this->db->select('survey_answers.id AS n_id,additional_contacts.master_customer_id AS n_mdm,additional_contacts.full_name AS n_name,additional_contacts.state_name AS n_state,additional_contacts.city_name AS n_city,additional_contacts.postal_code AS n_postal_code,additional_contacts.master_customer_id AS n_mdm_id,survey_answers.resp_kol_id as kol_id');
							$this->db->group_by('survey_answers.nominee_id,survey_questions.type_id');
							$this->db->where('survey_answers.question_id >',0,false);
						$this->db->where('survey_answers.respondent_id',$byId);
					}else{
						if($respOrUser != ''){
							$this->db->select('CASE
									WHEN survey_questions.type_id = 1 THEN "Local"
									WHEN survey_questions.type_id = 2 THEN "National"
									WHEN survey_questions.type_id = 3 THEN "Global"
									END AS type',false);
							$this->db->select("survey_answers.id AS n_id,resp_contacts.full_name AS n_name, rcountries.country n_country, resp_regions.region AS n_state, resp_cities.city AS n_city, resp_postal_codes.postal_code AS n_postal_code, resp_contacts.master_customer_id AS n_mdm,count(DISTINCT CONCAT(survey_answers.nominee_id,'-',survey_questions.type_id)) as count,additional_contacts.master_customer_id AS n_mdm_id,survey_answers.resp_kol_id as kol_id",false);
//							'survey_repsondents.id AS n_id,resp_contacts.full_name AS n_name, rcountries.country n_country, resp_regions.region AS n_state, resp_cities.city AS n_city, resp_postal_codes.postal_code AS n_postal_code, resp_contacts.master_customer_id AS n_mdm, '
							$this->db->where('client_users.id',$respOrUser);
						}else{							
							$this->db->select("survey_repsondents.id,resp_contacts.full_name as name,rcountries.country,resp_regions.region as state,resp_cities.city,resp_postal_codes.postal_code,count(DISTINCT CONCAT(survey_answers.nominee_id,'-',survey_questions.type_id)) as count,additional_contacts.master_customer_id AS n_mdm_id,survey_answers.resp_kol_id as kol_id",false);
						}
						$this->db->group_by('survey_answers.respondent_id');
					}					
					$this->db->join('regions as resp_regions','resp_regions.regionId=resp_contacts.state_id','left');
					$this->db->join('countries as rcountries','rcountries.countryId=resp_contacts.country_id','left');
					$this->db->join('cities as resp_cities','resp_cities.cityId=resp_contacts.city_id','left');
					$this->db->join('postal_codes as resp_postal_codes','resp_postal_codes.id=resp_contacts.postal_code_id','left');				
				break;
			case 'influencers':
					$isJoined=true;
					$this->db->select("icontacts.id,additional_contacts.full_name as name,countries.country,regions.region as state,cities.city,postal_codes.postal_code,count(DISTINCT CONCAT(survey_answers.respondent_id,'-',survey_questions.type_id)) as count,survey_answers.nom_kol_id as kol_id",false);
					//$this->db->join('survey_kol_names','survey_kol_names.id = survey_answers.nominee_id','left');
				
					$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
					$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
					$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
					$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
					$this->db->where('survey_answers.nominee_id>',0,false);
					//$this->db->group_by('survey_answers.name, survey_answers.country, survey_answers.state, survey_answers.city, survey_answers.postal');
					$this->db->group_by('icontacts.id,additional_contacts.country_id,additional_contacts.state_id,additional_contacts.city_id,additional_contacts.postal_code_id');
				break;
			case 'users':
					$this->db->select('client_users.id,concat(client_users.first_name," ",client_users.last_name) as name,client_users.title,client_users.email,client_users.phone,concat(manager.first_name," ",manager.last_name) as manager,count(distinct survey_answers.respondent_id) as count',false);
					$this->db->group_by('client_users.first_name,client_users.last_name');
					//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
					$this->db->join('client_users as manager','manager.id=client_users.manager_id','left');
					$this->db->where('client_users.id is not null');
			    	
				break;
		}
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
						if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
							$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
						}
						if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
							$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
						}
						if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
							if($isJoined==false){
							$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
							}
							$this->db->where_in('countries.country',$arrSelectedData['country']);
						}
						if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
							if($isJoined==false){
								$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
							}
							$this->db->where_in('regions.region',$arrSelectedData['state']);
							
						}
						if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
							if($isJoined==false){
								$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
							}
							$this->db->where_in('cities.city',$arrSelectedData['city']);
						}
						if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
							if($isJoined==false){
								$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
							}
							$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
						}
						break;
					case 'respondents':
						/*if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
							$this->db->where_in('survey_repsondents.id',$arrSelectedData['respondent']);
						}*/
					    if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
					        $this->db->where_in('survey_repsondents.id',$arrSelectedData['respondent']);
					    }
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!=""){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
						break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!=""){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
						break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!=""){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
						break;
				}
		}
		//$this->db->join('survey_kol_names as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->where('survey_answers.survey_id',$arrData['survey_id']);
		$this->db->where('survey_answers.is_deleted','0');
		if($byId == ''){
			$this->db->order_by('count','desc');
			if($respOrUser != '')
				$this->db->order_by('n_name','asc');
			else
				$this->db->order_by('name','asc');
		}
		$this->db->select('additional_contacts.do_not_call_flag');
		$result = $this->db->get('survey_answers');
		foreach($result->result_array() as $row){
//			if($arrData['participant']!='users'){
				if($row['do_not_call_flag'] == 0)
					$row['do_not_call_flag'] = 'No';
				else
					$row['do_not_call_flag'] = 'Yes';
				$respondent	= '';
				$row['microview']	= '';
				$row['org_microview']	= '';
				$participant	= 'surveyRespondent';
//				if($arrData['participant']=='influencers'){
//					$participant	= 'surveyInfluencer';
//					//$row['count']	= '<a href="#" onclick="showIndivisualSurveyMap('.$row['id'].');return false;">'.$row['count'].'</a>';
//					$row['count']	= '<a id="popUpConfirmation" onclick="showIndivisualSurveyMap('.$row['id'].');return false;" href="#" data-rel="popup" data-position-to="window" data-transition="pop" class="">'.$row['count'].'</a>';
//				}
				switch($arrData['participant']){
					case 'respondents':
						if($row['count'] != 0)
//							$row['count']	= '<a id="popUpConfirmation" onclick="showIndivisualRespondents('.$row['id'].');return false;" href="#" data-rel="popup" data-position-to="window" data-transition="pop" class="">'.$row['count'].'</a>';
						break;
					case 'influencers':
						$participant	= 'surveyInfluencer';
//						$row['count']	= '<a id="popUpConfirmation" onclick="showIndivisualSurveyMap('.$row['id'].');return false;" href="#" data-rel="popup" data-position-to="window" data-transition="pop" class="">'.$row['count'].'</a>';
						break;
					case 'users':
//						$row['count']	= '<a id="popUpConfirmation" onclick="showIndivisualUsers('.$row['id'].');return false;" href="#" data-rel="popup" data-position-to="window" data-transition="pop" class="">'.$row['count'].'</a>';
						break;
				}
				$respondent	= $row['name'];
				
				$row['name']	= $respondent;
				
				if($row['org_name']==null){
					$row['org_name']	= "Not Available";
					$row['org_microview']	= "";
				}
//			}
    		$arrReturnData[]	= $row;
    	}
    	//pr($this->db->last_query());exit;
//    	pr($arrReturnData);
//    	exit;
		return $arrReturnData;
	}
	/*
	 * To get List of Kol Names By passing Kol Name for autocomltete 
	 * @author Laxman
	 * @since KOLM v5.5 Otsuka 1.0.10
	 * @created 12-04-2013
	 */
	function getAllKolNamesForAutocomplete($kolName){
		$arrKols			= array();
		$arrCompletedKols	= array();
		$arrMyCustomers		= array();
		$kolName = str_replace(","," ",$kolName);
		$kolName = preg_replace('!\s+!', ' ', $kolName);
		$kolName	= $this->db->escape_like_str($kolName);
		$this->db->select("icontacts.id,first_name,middle_name,last_name,organizations.name as name");
		$this->db->join('organizations','icontacts.org_id=organizations.id','left');
		if(count(explode(' ',$kolName))>2){
			$this->db->like("concat_ws(' ',last_name,first_name,middle_name)",$kolName);
		}else{
			$this->db->like("concat_ws(' ',last_name,first_name)",$kolName);
		}
		$arrKolsResult		= $this->db->get('icontacts');
		//echo $this->db->last_query();
		foreach($arrKolsResult->result_array() as $row){
			
//				$arrMyCustomers[$row['id']][]	= str_replace('  ',' ',$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER]);
				$arrCompletedKols[$row['id']][]	= $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
				$arrCompletedKols[$row['id']][]	= $row['name'];
			
		}
		$arrKols['kols']		= $arrCompletedKols;
		
		return $arrKols;
		
	}
	/*
	 * To get List of Key people Names By passing Name for autocomltete 
	 * @author Laxman
	 * @since KOLM v5.5 Otsuka 1.0.10
	 * @created 12-04-2013
	 */
	function getAllKeyPeopleNamesForAutocomplete($kolName){
		$arrKeyPeoples	= array();
		$this->db->select("key_peoples.id,first_name,middle_name,last_name,organizations.name as name");
		$this->db->join('organizations','key_peoples.org_id=organizations.id','left');
		$this->db->where('organizations.status',COMPLETED);
		if(count(explode(' ',$kolName))>2){
			$this->db->like("concat_ws(' ',first_name,middle_name,last_name)",$kolName);
		}else{
			$this->db->like("concat_ws(' ',first_name,last_name)",$kolName);
		}
		$arrKeyPeoplesResult=$this->db->get('key_peoples');
		foreach($arrKeyPeoplesResult->result_array() as $row){
			$arrKeyPeoples[$row['id']][]	= str_replace('  ',' ',$row['first_name'].' '.$row['middle_name'].' '.$row['last_name']);
			$arrKeyPeoples[$row['id']][]	= $row['name'];
		}
		return $arrKeyPeoples;
	}
	/*
	 * To get List of Names which are used in surveys for autocomltete 
	 * @author Laxman
	 * @since KOLM v5.5 Otsuka 1.0.10
	 * @created 18-04-2013
	 */
	function getAllSurveyNamesForAutocomplete($kolName){
		$arrNames	= array();
		$this->db->select('survey_kol_names.id,survey_kol_names.name,survey_org_names.name as org_name,survey_answers.country,survey_answers.state,survey_answers.city,survey_answers.postal');
		$this->db->join('survey_answers','survey_kol_names.id = survey_answers.nominee_id','left');
		$this->db->join('survey_org_names','survey_org_names.id = survey_answers.nominee_org_id','left');
		$this->db->like('survey_kol_names.name COLLATE UTF8_GENERAL_CI ',$kolName,false);
		$this->db->where('survey_kol_names.kol_id',0);
		$this->db->group_by('survey_kol_names.name,survey_org_names.name');
		$result = $this->db->get('survey_kol_names');
	//	echo $this->db->last_query();
		foreach($result->result_array() as $row){
			$arrNames[$row['id']][]	= $row['name'];
			$arrNames[$row['id']][]	= $row['org_name'];
			$arrNames[$row['id']][]	= $row['country'];
			$arrNames[$row['id']][]	= $row['state'];
			$arrNames[$row['id']][]	= $row['city'];
			$arrNames[$row['id']][]	= $row['postal'];
		}
		return $arrNames;
	}
	/*
	 * To get all organizations
	 */
	function getAllSurveyOrgNames(){
		$arrData	= array();
		$arrResult	= $this->db->get('survey_org_names');
		foreach($arrResult->result_array() as $row){
			$arrData[$row['name']]	= $row;
		}
		return $arrData;
	}
	/*
	 * To save organization name
	 * @param $respondentOrg	- organization name
	 */
	function saveSurveyOrgname($respondentOrg){
		$id	= 0;
		$this->db->select('id');
		$this->db->where('name',$respondentOrg);
		$arrResultData = $this->db->get('survey_org_names');
		if($arrResultData->num_rows()>0){
			$resultObj	= $arrResultData->first_row();
			$id			= $resultObj->id;
		}else{
			$arrSurveyOrgData['name']	= $respondentOrg;
			$this->db->select('id');
			$this->db->where('name',$respondentOrg);
			$arrResultData = $this->db->get('organizations');
			if($arrResultData->num_rows()>0){
				$resultObj	= $arrResultData->first_row();
				$arrSurveyOrgData['org_id']	= $resultObj->id;
			}
			if($this->db->insert('survey_org_names',$arrSurveyOrgData)){
				$id	= $this->db->insert_id();
			}
		}
		return $id;
	}
	/*
	 * To get all names
	 */
	function getAllSurveyKolNames(){
		$arrData	= array();
		$arrResult	= $this->db->get('survey_kol_names');
		foreach($arrResult->result_array() as $row){
			$arrData[$row['name']]	= $row;
		}
		return $arrData;
	}
	/*
	 * To save survey name
	 * @param $arrKolData	- array of influencer data
	 */
	function saveSurveyKolName($arrKolData){
		$id	= 0;
		if(!isset($arrKolData['kol_id'])){
			$arrKolData['kol_id']	= 0;
		}
		if(isset($arrKolData['kol_id']) && empty($arrKolData['kol_id'])){
			$arrKolData['kol_id']	= 0;
		}
		$this->db->select('id');
		$this->db->where('name',$arrKolData['name']);
		$this->db->where('kol_id',$arrKolData['kol_id']);
		$arrResultData = $this->db->get('survey_kol_names');
		if($arrResultData->num_rows()>0){
			$resultObj	= $arrResultData->first_row();
			$id			= $resultObj->id;
		}else{
			$arrSurveyKolData['name']	= $arrKolData['name'];
			$arrSurveyKolData['kol_id']	= $arrKolData['kol_id'];
			$this->db->select('id');
			$this->db->where('concat(first_name,"",middle_name,"",last_name) = ',str_replace(' ','',$arrKolData['name']));
			$arrResultData = $this->db->get('kols');
			if($arrResultData->num_rows()>0){
				$resultObj	= $arrResultData->first_row();
				$arrSurveyKolData['kol_id']	= $resultObj->id;
			}
			if($this->db->insert('survey_kol_names',$arrSurveyKolData)){
				$id	= $this->db->insert_id();
			}
		}
		return $id;
	}
	/*
	 * To get respondent id from name
	 * @param $name	- respondent name
	 */
	function getRespondentId($name){
		$arrData	= array();
		$id	= 0;
		$this->db->select('id');
    	$this->db->where('survey_kol_names.name',$name);
    	$arrResultData = $this->db->get('survey_kol_names');
		if($arrResultData->num_rows()>0){
			$resultObj	= $arrResultData->first_row();
			$id			= $resultObj->id;
		}
		$arrData['id']	= $id;
		return $arrData;
	}
	
	function getRespondentIdNew($name){
		$arrData	= array();
		$id	= 0;
		$query = 'SELECT id
FROM kol_names_for_survey WHERE CONCAT(kol_names_for_survey.first_name, " ", kol_names_for_survey.middle_name, " ", kol_names_for_survey.last_name) = "'.$name.'" LIMIT 1';
		$arrResultData = $this->db->query($query);
		
		if($arrResultData->num_rows()>0){
			$resultObj	= $arrResultData->first_row();
			$id			= $resultObj->id;
		}
		$arrData['id']	= $id;
		return $arrData;
	}
	/*
	 * To get details of nominated/respondent name
	 * @param $id
	 */
	function getNameDetails($id){
		$arrData	= array();
		$arrData['id']	= $id;
		$this->db->select('kol_names_for_survey.id as id,concat(last_name,", ",first_name," ",middle_name) as name,kol_names_for_survey.id as kol_id,kol_names_for_survey.country,kol_names_for_survey.state,kol_names_for_survey.city,kol_names_for_survey.postal_code as postal',false);
    	$this->db->where('kol_names_for_survey.id',$id);
	//	$this->db->join('organizations','organizations.id = additional_contacts.org_id','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
		//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
		//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
    	$arrResultData = $this->db->get('kol_names_for_survey');
    	//pr($this->db->last_query());exit;
		$arrData	= $arrResultData->result_array();
		return $arrData[0];
	}
	function getOrgName($orgId){
		$this->db->where('id',$orgId);
		$arrResultData = $this->db->get('survey_org_names');
		$arrData	= $arrResultData->result_array();
		return $arrData[0];
	}
	
	function getOrgDataByOrgId($orgId) {
			$orgData = array();
			$this->db->where('id',$orgId);
			$this->db->select('name,country_id,state_id,city_id');
			$result=$this->db->get('organizations');
			if($result->num_rows() > 0){
				foreach ($result->result_array() as $row){
					$orgData = $row;
				}
			}
	//		echo $this->db->last_query();
	//		pr($orgData);
			return $orgData;
		}
	/*
	 * To save survey answers
	 * @param $activeSurveyId,$respondentId,$userId,$preparedStatements
	 */
	function saveAnswers($activeSurveyId,$respondentId,$userId,$preparedStatements,$surveyRespondentId=''){
		if(!empty($surveyRespondentId)){
			$this->db->where('respondent_id',$surveyRespondentId);
		}else{
			$this->db->where('respondent_id',$respondentId);
		}
		$this->db->where('survey_id',$activeSurveyId);
		$this->db->where('created_by',$userId);
		$this->db->delete('survey_answers');
		if($this->db->query($preparedStatements))
			return true;
		else
			return false;
	}
	function saveExtendedDate($arrData){
			$this->db->where('id',$arrData['id']);
			$this->db->update('surveys',$arrData);
	}
	function saveQuery($arrData){
		$this->db->select('id');
    	$this->db->where('survey_queries.created_by',$arrData['created_by']);
    	$arrResultData = $this->db->get('survey_queries');
		if($arrResultData->num_rows()>0){
			$resultObj	= $arrResultData->first_row();
			$id			= $resultObj->id;
			$this->db->where('id',$id);
			$this->db->update('survey_queries',$arrData);
		}else{
			$this->db->insert('survey_queries',$arrData);
		}
	}
	function loadSavedQuery($userId){
		$arrRow	= array('query'=>'');
    	$this->db->where('survey_queries.created_by',$userId);
    	$arrResultData = $this->db->get('survey_queries');
		if($arrResultData->num_rows()>0){
			foreach($arrResultData->result_array() as $row){
				$row['query']	= json_decode($row['query']);
				$arrRow	= $row;
			}
		}
		return $arrRow;
	}
	function searchNames($arrData,$offset=0,$limit=10,$isForMobile=false){
		$count	= 0;
		$arrReturnData	= array();
		$this->db->limit($limit,$offset);
		if($isForMobile){
			$this->db->select('icontacts.id,concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name) as name,icontacts.first_name, icontacts.middle_name, icontacts.last_name',false);
		}else{
			$this->db->select('icontacts.id,concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name) as name, icontacts.first_name, icontacts.middle_name, icontacts.last_name, postal_codes.postal_code, organizations.name as org_name,countries.Country as country,regions.Region as state,cities.City as city',false);
		}
		if($arrData['name']!=''){
			if(is_array($arrData['name'])){
				foreach($arrData['name'] as $key=>$name){
					$this->db->like('concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name)',$name);
				}
			}else{
				$this->db->like('concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name)',$arrData['name']);
			}
		}
		if($arrData['orgname']!=''){
			$this->db->like('organizations.name',$arrData['orgname']);
		}
		if($arrData['country']!=''){
			$this->db->like('countries.Country',$arrData['country']);
		}
		if($arrData['state']!=''){
			$this->db->like('regions.Region',$arrData['state']);
		}
		if($arrData['city']!=''){
			$this->db->like('cities.City',$arrData['city']);
		}
		if($arrData['postal']!=''){
			$this->db->where('postal_codes.postal_code',$arrData['postal']);
		}
		$this->db->join('organizations','organizations.id=icontacts.org_id','left');
		$this->db->join('regions','regions.regionId=icontacts.state_id','left');
		$this->db->join('countries','countries.countryId=icontacts.country_id','left');
		$this->db->join('cities','cities.cityId=icontacts.city_id','left');
		$this->db->join('postal_codes','postal_codes.id=icontacts.postal_code_id','left');
		$this->db->group_by('icontacts.id');
		$this->db->order_by('icontacts.first_name, icontacts.middle_name, icontacts.last_name','asc');
		$arrResultData	= $this->db->get('icontacts');
		//echo $this->db->last_query();
		if($arrResultData->num_rows()>0){
			foreach($arrResultData->result_array() as $row){
//				$name	= trim($row['name']);
				$row['name']	= nf($row['first_name'],$row['middle_name'],$row['last_name']);
				$name	= trim($row['name']);
				if(!empty($name)){
					if($isForMobile){
						$arrReturnData[$row['id']]	= $name;
					}else{
						$count++;
						$row['unique_id']	= $row['id'];
						$row['type']		= 'kol';
						$row['id']			= $count;
						$arrReturnData[$row['id']]	= $row;
					}
				}
			}
		}
		
		//return array_slice($arrReturnData, ($arrData['offset']), $arrData['limit']);
		return $arrReturnData;
	}
	
	function getSurveyNomineesToRespondentConnnecions($surveyId, $filterData){
		$arrResults = array();
		$isQuestionsJoind = false;
		$isContryJoined=false;
		$isCityJoined=false;
		$isRegionJoined = false;
		$isPostalCode = false;
		$this->db->select('CASE
		WHEN survey_questions.type_id = 1 THEN "Local"
		WHEN survey_questions.type_id = 2 THEN "National"
		WHEN survey_questions.type_id = 3 THEN "Global"
		END AS type',false);
		$this->db->select("kol_names_for_survey.id as nom_kol_id, kol_names_for_survey.search_name as nom_name, resp_contacts.search_name as resp_name, survey_answers.id AS sur_ans_id, count(respondent_id) as num_noms, kol_names_for_survey.city, resp_contacts.city AS respondent_city, kol_names_for_survey.postal_code AS nom_postal, resp_contacts.postal_code AS resp_postal, kol_names_for_survey.state AS nstate_name, resp_contacts.state AS rstate_name, kol_names_for_survey.country AS ncountry_name, resp_contacts.country AS rcountry_name, survey_answers.nominee_id as nomkolid, survey_answers.respondent_id as respkolid",false);
		//$this->db->join('icontacts as nominees','survey_answers.nominee_id = nominees.id','left');
		//$this->db->join('icontacts as respondents','survey_answers.respondent_id = respondents.id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id=survey_answers.nominee_id','left');
		$this->db->join('kol_names_for_survey as resp_contacts','resp_contacts.id = survey_answers.respondent_id','left');
		$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		//$this->db->join('kols as nomkols','survey_answers.nom_kol_id = nomkols.id','left');
		//$this->db->join('kols as respkols','survey_answers.resp_kol_id = respkols.id','left');
		//$this->db->where('survey_id',$filterData['survey_id']);
		if(isset($filterData['nomineeId']) && $filterData['nomineeId'] != ''){
			$this->db->where("(nominee_id = ".$filterData['nomineeId']." OR respondent_id = ".$filterData['nomineeId'].")");
		}
		
		//Nominee filters
		if(isset($filterData['specialty']) && $filterData['specialty'] != ''){
//			$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
//			$isQuestionsJoind = true;
			$this->db->where_in('survey_questions.category_id',$filterData['specialty']);
		}
		if(isset($filterData['type']) && $filterData['type'] != '' && $filterData['type'] != 0){
//			if(!$isQuestionsJoind)
//				$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
			//$this->db->where_in('survey_questions.type_id',$filterData['type']);
//			$isQuestionsJoind = true;
		}
		if(isset($filterData['state']) && $filterData['state'][0] != '' && sizeof($filterData['state']) > 0){
			if($isRegionJoined==false){
				$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
				$isRegionJoined = true;
			}
			$this->db->where_in('regions.region',$filterData['state']);
		}
		if(isset($filterData['postal']) && $filterData['postal'] != '' && sizeof($filterData['postal']) > 0){
			if($isPostalJoined==false){
				$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
				$isPostalJoined = true;
			}
			$this->db->where_in('postal_codes.postal_code',$filterData['postal']);
		}
		if(isset($filterData['city']) && $filterData['city'] != '' && sizeof($filterData['city']) > 0){
			if($isCityJoined==false){
				
				$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
				$isCityJoined = true;
			}
			$this->db->where_in('cities.city',$filterData['city']);
		}
		if(isset($filterData['country']) && $filterData['country'] != '' && sizeof($filterData['country']) > 0){
			if($isContryJoined==false){
				$this->db->join('countries','countries.countryId=nominees.country_id','left');
				$isContryJoined=true;
			}
			$this->db->where_in('countries.country',$filterData['country']);
		}
		if(isset($filterData['name']) && $filterData['name'] != '' && sizeof($filterData['name']) > 0){
			$this->db->where_in('survey_answers.nominee_id',$filterData['name']);
		}
		
		//Responden filters
		if(isset($filterData['respondent_id']) && $filterData['respondent_id'] != '' && sizeof($filterData['respondent_id']) > 0){
			$this->db->where_in('survey_answers.respondent_id',$filterData['respondent_id']);
		}
		if(isset($filterData['respondent_state']) && $filterData['respondent_state'] != ''){
			$this->db->where_in('survey_answers.respondent_state',$filterData['respondent_state']);
		}
		if(isset($filterData['respondent_city']) && $filterData['respondent_city'] != ''){
			$this->db->where_in('survey_answers.respondent_city',$filterData['respondent_city']);
		}
		if(isset($filterData['respondent_postal']) && $filterData['respondent_postal'] != ''){
			$this->db->where_in('survey_answers.respondent_postal',$filterData['respondent_postal']);
		}
		if(isset($filterData['user_ids']) && $filterData['user_ids'] != '' && sizeof($filterData['user_ids']) > 0){
			$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
			$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$filterData['user_ids']);
		}
		if(isset($filterData['territory_ids']) && $filterData['territory_ids'] != '' && sizeof($filterData['territory_ids']) > 0){
			$this->db->where_in('sales_report_master_data.id',$filterData['territory_ids']);
		}
		if(isset($filterData['region_ids']) && $filterData['region_ids'] != '' && sizeof($filterData['region_ids']) > 0){
			$this->db->where_in('sales_report_master_data.region',$filterData['region_ids']);
		}
		if(isset($filterData['district_ids']) && $filterData['district_ids'] != '' && sizeof($filterData['district_ids']) > 0){
			$this->db->where_in('sales_report_master_data.district',$filterData['district_ids']);
		}
		if($filterData['inf_city'] != ''){
			if($isCityJoined==false){
				$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
				$isCityJoined = true;
			}
			$this->db->where('cities.city',trim($filterData['inf_city']));
		}
		if($filterData['inf_state'] != ''){
			if($isRegionJoined==false){
				$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
				$isRegionJoined = true;
			}
			$this->db->where('regions.region',trim($filterData['inf_state']));
		}
		if($filterData['inf_country'] != ''){
			if($isContryJoined==false){
				$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
				$isContryJoined=true;
			}
			$this->db->where('countries.country',trim($filterData['inf_country']));
		}
		if($filterData['inf_postal'] != ''){
			if($isPostalJoined==false){
				$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
				$isPostalJoined = true;
			}
			$this->db->where('postal_codes.postal_code',trim($filterData['inf_postal']));
		}
	//	if(isset($filterData['limit'])){
			$this->db->order_by('num_noms',"desc");
		//}
		$this->db->where('survey_answers.nominee_id>',0,false);
			
		$this->db->group_by('survey_answers.nominee_id,respondent_id');
		
		$this->db->where('survey_answers.is_deleted','0');
		if($filterData['survey_id'] > 0){
			$this->db->where('survey_answers.survey_id',$filterData['survey_id']);
		}
		$results = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
     			$arrResults[] = $row;
     		}
     	}
		return $arrResults;
	}
	
	function getSurveyNomineesToRespondentConnnecionsForGeo($surveyId, $filterData){
		$arrResults = array();
		$isQuestionsJoind = false;
		$this->db->select("survey_answers.id, kol_names_for_survey.search_name as nom_name, resp_contacts.search_name as resp_name, count(respondent_id) as num_noms, kol_names_for_survey.city as nom_city, resp_contacts.city as respondent_city, kol_names_for_survey.postal_code AS nom_postal, resp_contacts.postal_code AS resp_postal, kol_names_for_survey.state AS nstate_name, resp_contacts.state AS rstate_name, kol_names_for_survey.country AS ncountry_name, resp_contacts.country AS rcountry_name, survey_answers.nominee_id as nomkolid, survey_answers.respondent_id as respkolid,kol_names_for_survey.latitude as nomineLat, kol_names_for_survey.longitude as nominelang, resp_contacts.latitude as resp_lat, resp_contacts.longitude as resp_long",false);
		//$this->db->join('icontacts as nominees','survey_answers.nominee_id = nominees.id','left');
		//$this->db->join('icontacts as respondents','survey_answers.respondent_id = respondents.id','left');
		$this->db->join('kol_names_for_survey as resp_contacts','resp_contacts.id = survey_answers.respondent_id','left');
		$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		//$this->db->join('cities','cities.cityId=additional_contacts.city_id','inner');
		//$this->db->join('cities as city1','city1.cityId=resp_contacts.city_id','inner');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		//$this->db->join('kols as nomkols','survey_answers.nom_kol_id = nomkols.id','left');
		//$this->db->join('kols as respkols','survey_answers.resp_kol_id = respkols.id','left');
		$this->db->where('survey_id',$filterData['survey_id']);
		
		if(isset($filterData['nomineeId']) && $filterData['nomineeId'] != ''){
			$this->db->where("(nominee_id = ".$filterData['nomineeId']." OR respondent_id = ".$filterData['nomineeId'].")");
		}
		
		//Nominee filters
		if(isset($filterData['specialty']) && $filterData['specialty'] != ''){
			$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
			$isQuestionsJoind = true;
			$this->db->where_in('survey_questions.category_id',$filterData['specialty']);
		}
		if(isset($filterData['type']) && $filterData['type'] != '' && $filterData['type'] != 0){
			if(!$isQuestionsJoind)
				$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
			$this->db->where_in('survey_questions.type_id',$filterData['type']);
			$isQuestionsJoind = true;
		}
		if(isset($filterData['state']) && $filterData['state'][0] != '' && sizeof($filterData['state']) > 0){
			//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
			$this->db->where_in('kol_names_for_survey.state',$filterData['state']);
		}
		if(isset($filterData['postal']) && $filterData['postal'] != '' && sizeof($filterData['postal']) > 0){
			//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
			$this->db->where_in('kol_names_for_survey.postal_code',$filterData['postal']);
		}
		if(isset($filterData['city']) && $filterData['city'] != '' && sizeof($filterData['city']) > 0){
			$this->db->where_in('kol_names_for_survey.city',$filterData['city']);
		}
		if(isset($filterData['country']) && $filterData['country'] != '' && sizeof($filterData['country']) > 0){
			//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
			$this->db->where_in('kol_names_for_survey.country',$filterData['country']);
		}
		if(isset($filterData['name']) && $filterData['name'] != '' && sizeof($filterData['name']) > 0){
			$this->db->where_in('survey_answers.nominee_id',$filterData['name']);
		}
		
		//Responden filters
		if(isset($filterData['respondent_id']) && $filterData['respondent_id'] != '' && sizeof($filterData['respondent_id']) > 0){
			$this->db->where_in('survey_answers.respondent_id',$filterData['respondent_id']);
		}
		if(isset($filterData['respondent_state']) && $filterData['respondent_state'] != ''){
			$this->db->where_in('survey_answers.respondent_state',$filterData['respondent_state']);
		}
		if(isset($filterData['respondent_city']) && $filterData['respondent_city'] != ''){
			$this->db->where_in('survey_answers.respondent_city',$filterData['respondent_city']);
		}
		if(isset($filterData['respondent_postal']) && $filterData['respondent_postal'] != ''){
			$this->db->where_in('survey_answers.respondent_postal',$filterData['respondent_postal']);
		}
		if(isset($filterData['user_ids']) && $filterData['user_ids'] != '' && sizeof($filterData['user_ids']) > 0){
			$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
			//$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$filterData['user_ids']);
		}
		if(isset($filterData['territory_ids']) && $filterData['territory_ids'] != '' && sizeof($filterData['territory_ids']) > 0){
			$this->db->where_in('sales_report_master_data.id',$filterData['territory_ids']);
		}
		if(isset($filterData['region_ids']) && $filterData['region_ids'] != '' && sizeof($filterData['region_ids']) > 0){
			$this->db->where_in('sales_report_master_data.region',$filterData['region_ids']);
		}
		if(isset($filterData['district_ids']) && $filterData['district_ids'] != '' && sizeof($filterData['district_ids']) > 0){
			$this->db->where_in('sales_report_master_data.district',$filterData['district_ids']);
		}
		
		if($filterData['inf_city'] != '')
			$this->db->where('survey_answers.city',trim($filterData['inf_city']));
		if($filterData['inf_state'] != '')
			$this->db->where('survey_answers.state',trim($filterData['inf_state']));
		if($filterData['inf_country'] != '')
			$this->db->where('survey_answers.country',trim($filterData['inf_country']));
		if($filterData['inf_postal'] != '')
			$this->db->where('survey_answers.postal',trim($filterData['inf_postal']));
			
		$this->db->group_by('survey_answers.nominee_id,respondent_id');
		//$this->db->limit(10);
		$this->db->where('survey_answers.nominee_id>',0,false);
		
		$this->db->where('survey_answers.is_deleted','0');
		$results = $this->db->get('survey_answers');
		//pr($filterData);
		//pr($this->db->last_query());exit;
		if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
     			//if($row['nomineLat'] !='' && $row['resoLat']!=''){
     				$arrResults[] = $row;
     			//}
     		}
     		/*
     		foreach($results->result_array() as $row){
				 $prev_lat = end($lat);
		    	 $prev_lng = end($lng);
		    	 $latvalue = $row['nomineLat'];
		    	 $longvalue = $row['nominelang'];
		    	 if(($row['nomineLat'] == $prev_lat) && ($row['nomineLat'] == $prev_lng)) {
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$row['nomineLat']=$row['nomineLat']+ $random_num_lat;
					$row['nominelang']=$row['nominelang'] + $random_num_lng;
		    	 }else{
		    	 	$row['nomineLat']=$row['nomineLat'];
					$row['nominelang']=$row['nominelang'];
		    	 }
		    	 
		    			$row['connections'] = array('lat'=>51.838,'lang'=>-1.804);
						
		   		$lat[] = $latvalue;
		   		$lng[] = $longvalue; 
				$arrKols[]=$row;
			}*/
		//echo $this->db->last_que
     	}
//     	pr($arrResults);
//		exit;
		return $arrResults;
	}
	
	function getSurveyKolInfo($id,$type){
		$arrDetails = array();
		if($type=='nominee'){
			$this->db->select('nominees.id as kolId,survey_answers.id,nominees.id as nom_kol_id, concat(nominees.first_name," ",nominees.middle_name," ",nominees.last_name)  as nom_name, nominees.id as nominee_id,,
			 ,cities.city,regions.region as state,countries.country,postal_codes.postal_code as postal',false);
				$this->db->join('icontacts as nominees ',' survey_answers.nominee_id = nominees.id','left');
				$this->db->join('additional_contacts','additional_contacts.id = survey_answers.nom_address_id','left');
				$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
				$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
				$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
				$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
				
		
		}else{
			$this->db->select('respondents.id as kolId,survey_answers.id, nominee_id,
							respondents.id as resp_kol_id, concat(respondents.first_name," ",respondents.middle_name," ",respondents.last_name) as resp_name, respondents.id as respondent_id,
 							cities.city as respondent_city,countries.country as respondent_country,regions.region as respondent_state,postal_codes.postal_code as respondent_postal',false);
			$this->db->join('icontacts as respondents','survey_answers.respondent_id = respondents.id','left');
			$this->db->join('additional_contacts','additional_contacts.id = survey_answers.resp_address_id','left');
			$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
			$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
			$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
			$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
			
		}
		$this->db->where('survey_answers.id',$id);
		
		$arrSesultSet = $this->db->get('survey_answers');
	//	echo $this->db->last_query();
		foreach($arrSesultSet->result_array() as $row){
			if($type=='nominee' && $row['nominee_org']==null){
				$row['nominee_org']	= "Not Available";
			}else if($row['respo_org']==null){
				$row['respo_org']	= "Not Available";
			}
			$arrDetails =  $row;
		}
		return $arrDetails;
	}
	
	/*
	 * Function to get city id by city name
	 * 
	 */
	function getCityIdByName($cityName,$stateName='',$countryName=''){
		$cityId =	0;
		$this->db->select('cities.CityId');
		$this->db->where('cities.City',$cityName);
		
		if(!empty($countryName)){
			$this->db->join('countries','countries.CountryId=cities.CountryID','inner');
			$this->db->where('countries.Country',$countryName);
			if(!empty($stateName)){
				$this->db->join('regions','regions.CountryID=countries.CountryId','inner');
				$this->db->where('regions.Region',$stateName);
			}
		}else if(!empty($stateName)){
				$this->db->join('regions','regions.RegionID=cities.RegionID','inner');
				$this->db->where('regions.Region',$stateName);
		}
		$this->db->limit(1);
		$result = $this->db->get('cities');
		foreach($result->result_array() as $row){
			$cityId = $row['CityId'];
		}
		return $cityId;
	}
	/*
	 * fetch KOLs data used for survey seed data
	 * @author Laxman K
	 * @since Otsuka
	 * @created 18-06-2013
	 */
	function getKolsForSeedData($limit,$countryIds=0,$stateIds=0,$cityIds=0){
		$arrReturnData	= array();
		$this->db->select('kols.id,CONCAT(kols.first_name," ",kols.middle_name," ",kols.last_name) as name,kols.city_id,organizations.name as orgname,countries.country,regions.Region as state,cities.City as city,kols.postal_code as postal',false);
		$this->db->join('organizations','organizations.id=kols.org_id','left');
		$this->db->join('countries','countries.CountryId=kols.country_id','left');
		$this->db->join('regions','regions.RegionID=kols.state_id','left');
		$this->db->join('cities','cities.CityId=kols.city_id','left');
		$this->db->where('kols.org_id >','0');
		$this->db->where_not_in('organizations.name','null');
		if($countryIds!=0){
			$this->db->where_in('kols.country_id',$countryIds);
		}
		if($stateIds!=0){
			$this->db->where_in('kols.state_id',$stateIds);
		}
		if($cityIds!=0){
			$this->db->where_in('kols.city_id',$cityIds);
		}
		$this->db->order_by('kols.id','random');
		$this->db->limit($limit);
		$result = $this->db->get('kols');
		foreach($result->result_array() as $row){
			$arrReturnData[] = $row;
		}
		return $arrReturnData;
	}
	/*
	 * fetch Users data used for survey seed data
	 * @author Laxman K
	 * @since Otsuka
	 * @created 18-06-2013
	 */
	function getUsersForSeedData($limit){
		$arrReturnData	= array();
		$this->db->select('id,CONCAT(first_name," ",last_name) as username',false);
	//	$this->db->where('client_users.client_id',$this->session->userdata('client_id'));
		$this->db->order_by('id','random');
		$this->db->limit($limit);
		$result = $this->db->get('client_users');
		foreach($result->result_array() as $row){
			$arrReturnData[] = $row;
		}
		return $arrReturnData;
	}
	
	function getSurveyNomineesToRespondentConnnecionsMap($surveyId, $filterData){
		$arrResults = array();
		$isQuestionsJoind = false;
		$this->db->select("nominees.kol_id as nom_kol_id,nominees.name as nom_name,nominee_id,respondents.kol_id as resp_kol_id,respondents.name as resp_name,respondent_id,count(respondent_id) as num_noms,nom_kols.status as nom_status, resp_kols.status as resp_status");
		$this->db->join('survey_kol_names as nominees','survey_answers.nominee_id = nominees.id','left');
		$this->db->join('survey_kol_names as respondents','survey_answers.respondent_id = respondents.id','left');
		$this->db->join('kols as nom_kols','nominees.kol_id = nom_kols.id','left');
		$this->db->join('kols as resp_kols','respondents.kol_id = resp_kols.id','left');
		$this->db->where('nom_kols.status',COMPLETED);
		$this->db->where('resp_kols.status',COMPLETED);
		$this->db->where('survey_id',$filterData['survey_id']);
		if(isset($filterData['nomineeId']) && $filterData['nomineeId'] != ''){
			$this->db->where("(nominee_id = ".$filterData['nomineeId']." OR respondent_id = ".$filterData['nomineeId'].")");
		}
		
		//Nominee filters
		if(isset($filterData['specialty']) && $filterData['specialty'] != ''){
			$this->db->join('specialties as nom_kols_spec','nom_kols.specialty = nom_kols_spec.id','left');
			$this->db->where_in('nom_kols_spec.specialty',$filterData['specialty']);
			$this->db->join('specialties as resp_kols_spec','nom_kols.specialty =resp_kols_spec.id','left');
			$this->db->where_in('resp_kols_spec.specialty',$filterData['specialty']);
		}
		if(isset($filterData['state']) && $filterData['state'][0] != '' && sizeof($filterData) > 1){
			$this->db->where_in('nom_kols.state_id',$filterData['state']);
			$this->db->where_in('resp_kols.state_id',$filterData['state']);
		}
		
		if(isset($filterData['country']) && $filterData['country'] != ''){
			$this->db->where_in('survey_answers.country',$filterData['country']);
		}
		
		$this->db->group_by('survey_answers.nominee_id,respondent_id');
		$results = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
     			$data = array();
     			$data['kol_id'] = $row['resp_kol_id'];
     			$data['count'] = $row['num_noms'];
     			//if($data['kol_id'] == $filterData['nomineeId'])
     				//$data['kol_id'] = $row['nom_kol_id'];
     			if($row['nom_kol_id'] != 0)
     			$arrResults['kol_'.$data['kol_id']][]=$row['nom_kol_id'];
     		}
     	}
		return $arrResults;
	}
	
	function getSurveyNameById($id) {
		$surveyName = '';
		$this->db->select('name');
		$this->db->where('id',$id);
		$results = $this->db->get('surveys');
		foreach ($results->result_array() as $row){
			$surveyName = $row['name'];			
		}
		return $surveyName;
	}
	function listUserGroups($clientId){
		$arrUsers	= array();
    	$this->db->select('DISTINCT(client_users.id), client_users.first_name, client_users.last_name,GROUP_CONCAT(DISTINCT groups.group_id SEPARATOR ",") AS group_ids',false);
    	$this->db->join('user_groups','user_groups.user_id=client_users.id','left');
    	$this->db->join('groups','groups.group_id=user_groups.group_id','left');
    	$this->db->where('client_users.client_id',$clientId);
    	$this->db->group_by('client_users.id');
    	$result = $this->db->get('client_users');
    	foreach($result->result_array() as $row){
    		$arrUsers[]	= $row;
    	}
    	return $arrUsers;
	}
	function listGroups($clientId){
		$arrGroups	= array();
		$this->db->select('group_id,group_name');
		$this->db->where('client_users.client_id',$clientId);
		$this->db->join('client_users','client_users.id=groups.created_by','left');
		$this->db->order_by('group_name');
		$result = $this->db->get('groups');
		//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$arrGroups[]	= $row;
    	}
    	return $arrGroups;
	}
	function getSurveyFilterNotSelectedDetails($surveyId=0,$arrSelections=array()){
		$arrReturnData	= array();
		$clientId = $this->session->userdata('client_id');
		/*if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}*/
		if($surveyId!=0){
			$this->db->where('survey_answers.survey_id',$surveyId);
		}
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
						if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
							//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
							$this->db->where_not_in('survey_answers.nominee_id',$arrSelectedData['name']);
						}
						if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
							$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
							$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
						}
						if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
							$this->db->where_not_in('survey_answers.state',$arrSelectedData['country']);
						}else{
							$this->db->where_not_in('survey_answers.country',array(''));
						}
						if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
							$this->db->where_not_in('survey_answers.state',$arrSelectedData['state']);
						}else{
							$this->db->where_not_in('survey_answers.state',array(''));
						}
						if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
							$this->db->where_not_in('survey_answers.state',$arrSelectedData['city']);
						}else{
							$this->db->where_not_in('survey_answers.city',array(''));
						}
						if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
							$this->db->where_not_in('survey_answers.state',$arrSelectedData['postal']);
						}else{
							$this->db->where_not_in('survey_answers.postal',array(''));
						}
						break;
					case 'respondents':
						if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
							//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
							$this->db->where_not_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
						}
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_not_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
			}
		}
		$this->db->select('survey_answers.*,survey_kol_names.name as influencer_name,survey_repsondents.name as respondent_name');
		$this->db->select('CONCAT(client_users.first_name," ",client_users.last_name) as user',false);
		$this->db->join('survey_kol_names','survey_kol_names.id=survey_answers.nominee_id','left');
		$this->db->join('survey_kol_names as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$arrResultSet = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$row['country']	= ucwords(strtolower($row['country']));
			$row['state']	= ucwords(strtolower($row['state']));
			$row['city']	= ucwords(strtolower($row['city']));
			/*if(!isset($arrReturnData['influencers'][$row['influencer_name']])){
			 $arrReturnData['influencers'][$row['influencer_name']]	= 1;
			}else{
			$arrReturnData['influencers'][$row['influencer_name']]	+= 1;
			}*/
			if(!isset($arrReturnData['influencers'][$row['nominee_id']])){
				$arrReturnData['influencers'][$row['nominee_id']]['count']	= 1;
				$arrReturnData['influencers'][$row['nominee_id']]['name']	= $row['influencer_name'];
			}else{
				$arrReturnData['influencers'][$row['nominee_id']]['count']	+= 1;
			}
			if(!isset($arrReturnData['countries'][$row['country']])){
				$arrReturnData['countries'][$row['country']]	= 1;
			}else{
				$arrReturnData['countries'][$row['country']]	+= 1;
			}
			if(!isset($arrReturnData['states'][$row['state']])){
				$arrReturnData['states'][$row['state']]	= 1;
			}else{
				$arrReturnData['states'][$row['state']]	+= 1;
			}
			if(!isset($arrReturnData['cities'][$row['city']])){
				$arrReturnData['cities'][$row['city']]	= 1;
			}else{
				$arrReturnData['cities'][$row['city']]	+= 1;
			}
			if(!isset($arrReturnData['postalcodes'][$row['postal']])){
				$arrReturnData['postalcodes'][$row['postal']]	= 1;
			}else{
				$arrReturnData['postalcodes'][$row['postal']]	+= 1;
			}
			/*if(!isset($arrReturnData['respondents'][$row['respondent_name']])){
			 $arrReturnData['respondents'][$row['respondent_name']]	= 1;
			}else{
			$arrReturnData['respondents'][$row['respondent_name']]	+= 1;
			}*/
			if(!isset($arrReturnData['respondents'][$row['respondent_id']])){
				$arrReturnData['respondents'][$row['respondent_id']]['count']	= 1;
				$arrReturnData['respondents'][$row['respondent_id']]['name']	= $row['respondent_name'];
			}else{
				$arrReturnData['respondents'][$row['respondent_id']]['count']	+= 1;
			}
			if(!isset($arrReturnData['users'][$row['user']])){
				$arrReturnData['users'][$row['user']]	= 1;
			}else{
				$arrReturnData['users'][$row['user']]	+= 1;
			}
		}
		return $arrReturnData;
	}
	function getSurveyFilterDetails($surveyId=0,$arrSelections=array()){
		$arrReturnData	= array();
		$clientId = $this->session->userdata('client_id');
		/* if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where('client_users.client_id',$clientId);
		} */
		if($surveyId!=0){
			$this->db->where('survey_answers.survey_id',$surveyId);
		}
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->where_in('survey_answers.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->where_in('survey_answers.state',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->where_in('survey_answers.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->where_in('survey_answers.postal',$arrSelectedData['postal']);
							}
						break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
			}
		}
		$this->db->select('survey_answers.*,survey_kol_names.name as influencer_name,survey_repsondents.name as respondent_name');
		$this->db->select('CONCAT(client_users.first_name," ",client_users.last_name) as user',false);
		$this->db->join('survey_kol_names','survey_kol_names.id=survey_answers.nominee_id','left');
		$this->db->join('survey_kol_names as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$arrResultSet = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$row['country']	= ucwords(strtolower($row['country']));
			$row['state']	= ucwords(strtolower($row['state']));
			$row['city']	= ucwords(strtolower($row['city']));
			/*if(!isset($arrReturnData['influencers'][$row['influencer_name']])){
				$arrReturnData['influencers'][$row['influencer_name']]	= 1;
			}else{
				$arrReturnData['influencers'][$row['influencer_name']]	+= 1;
			}*/
			if(!isset($arrReturnData['influencers'][$row['nominee_id']])){
				$arrReturnData['influencers'][$row['nominee_id']]['count']	= 1;
				$arrReturnData['influencers'][$row['nominee_id']]['name']	= $row['influencer_name'];
			}else{
				$arrReturnData['influencers'][$row['nominee_id']]['count']	+= 1;
			}
			if(!isset($arrReturnData['countries'][$row['country']])){
				$arrReturnData['countries'][$row['country']]	= 1;
			}else{
				$arrReturnData['countries'][$row['country']]	+= 1;
			}
			if(!isset($arrReturnData['states'][$row['state']])){
				$arrReturnData['states'][$row['state']]	= 1;
			}else{
				$arrReturnData['states'][$row['state']]	+= 1;
			}
			if(!isset($arrReturnData['cities'][$row['city']])){
				$arrReturnData['cities'][$row['city']]	= 1;
			}else{
				$arrReturnData['cities'][$row['city']]	+= 1;
			}
			if(!isset($arrReturnData['postalcodes'][$row['postal']])){
				$arrReturnData['postalcodes'][$row['postal']]	= 1;
			}else{
				$arrReturnData['postalcodes'][$row['postal']]	+= 1;
			}
			/*if(!isset($arrReturnData['respondents'][$row['respondent_name']])){
				$arrReturnData['respondents'][$row['respondent_name']]	= 1;
			}else{
				$arrReturnData['respondents'][$row['respondent_name']]	+= 1;
			}*/
			if(!isset($arrReturnData['respondents'][$row['respondent_id']])){
				$arrReturnData['respondents'][$row['respondent_id']]['count']	= 1;
				$arrReturnData['respondents'][$row['respondent_id']]['name']	= $row['respondent_name'];
			}else{
				$arrReturnData['respondents'][$row['respondent_id']]['count']	+= 1;
			}
			if(!isset($arrReturnData['users'][$row['user']])){
				$arrReturnData['users'][$row['user']]	= 1;
			}else{
				$arrReturnData['users'][$row['user']]	+= 1;
			}
		}
		/* if(sizeof($arrSelections)>0){
//			echo $this->db->last_query();
			$arrFiltersNotSelectedData	= $this->getSurveyFilterNotSelectedDetails($surveyId,$arrSelections);
//			echo $this->db->last_query();
			foreach($arrFiltersNotSelectedData as $index=>$arrRow){
				foreach($arrRow as $key=>$value){
					if(!isset($arrReturnData[$index][$key])){
						$arrReturnData[$index][$key]	= $value;
					}else{
						//$arrReturnData[$index][$key]	+= $value;
					}
				}
			}
			//$this->getSurveyFilterNotSelectedDetails($surveyId,$arrSelections);
			//echo $this->db->last_query();
		} */
	/* 	$arrReturnData['countries']	= array_filter($arrReturnData['countries']);
		$arrReturnData['states']	= array_filter($arrReturnData['states']);
		$arrReturnData['cities']	= array_filter($arrReturnData['cities']);
		$arrReturnData['postalcodes']	= array_filter($arrReturnData['postalcodes']); */
		arsort($arrReturnData['influencers']);
		arsort($arrReturnData['countries']);
		arsort($arrReturnData['states']);
		arsort($arrReturnData['cities']);
		arsort($arrReturnData['postalcodes']);
		arsort($arrReturnData['respondents']);
		arsort($arrReturnData['users']);
		return $arrReturnData;
	}
	function getSurveySelectedFilterDetails($surveyId=0,$arrSelections=array(),$filterType=''){
		$arrReturnData	= array();
		$clientId = $this->session->userdata('client_id');
		/* if($clientId!=INTERNAL_CLIENT_ID){
		 $this->db->where('client_users.client_id',$clientId);
		} */
		if($surveyId!=0){
			$this->db->where('survey_answers.survey_id',$surveyId);
		}
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		
		//$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		if($filterType == 'respondent'){
			$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.respondent_id','left');
		}else{
			$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
		}
		//$this->db->join('additional_contacts as resp_add_contants','resp_add_contants.id = survey_answers.resp_address_id','left');
		//$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		//$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		//pr($arrSelections);
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
						if(isset($arrSelectedData['name']) && $arrSelectedData['name']!="" && !($filterType=="influencer")){
							//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
							//$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
						}
						if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
							$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
							$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
						}
						if(isset($arrSelectedData['country']) && $arrSelectedData['country']!="" && !($filterType=="country")){
							
							//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
							//$this->db->where_in('countries.country',$arrSelectedData['country']);
						}
						if(isset($arrSelectedData['state']) && $arrSelectedData['state']!="" && !($filterType=="state")){
							//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
							//$this->db->where_in('regions.region',$arrSelectedData['state']);
						}
						if(isset($arrSelectedData['city']) && $arrSelectedData['city']!="" && !($filterType=="city")){
							//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
							//$this->db->where_in('cities.city',$arrSelectedData['city']);
						}
						if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!="" && !($filterType=="postalcode")){
							//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
							//$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
						}
						break;
					case 'respondents':
						if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!="" && !($filterType=="respondent")){
							//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
							$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
						}
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!="" && !($filterType=="user")){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
					case 'territories':
						if(isset($arrSelectedData['territory']) && $arrSelectedData['territory']!="" && !($filterType=="territory")){
							$this->db->where_in('survey_answers.territory_id',$arrSelectedData['territory']);
						}
						break;
					case 'regions':
						if(isset($arrSelectedData['region']) && $arrSelectedData['region']!="" && !($filterType=="region")){
							$this->db->where_in('sales_report_master_data.region',$arrSelectedData['region']);
						}
						break;
					case 'districts':
						if(isset($arrSelectedData['district']) && $arrSelectedData['district']!="" && !($filterType=="district")){
							$this->db->where_in('sales_report_master_data.district',$arrSelectedData['district']);
						}
						break;
			}
		}
		
		$this->db->order_by('count','desc');
		$this->db->order_by('name','asc');
		switch($filterType){
			case 'influencer':
				$this->db->select("survey_answers.nominee_id as id,kol_names_for_survey.search_name as name,count(DISTINCT CONCAT(survey_answers.nominee_id,'-',survey_answers.question_id,'-',survey_answers.respondent_id)) as count",false);
				$this->db->group_by('survey_answers.nominee_id');
				break;
			case 'country':
				/* $this->db->select('countries.country as id,countries.country as name,count(countries.country) as count');
				$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
				$this->db->group_by('additional_contacts.country_id'); */
				$this->db->select('kol_names_for_survey.country as name, count(kol_names_for_survey.country) as count');
				//$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
				break;
			case 'state':
				/* $this->db->select('regions.region as id,regions.region as name,count(distinct survey_answers.nominee_id) as count');
				$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
				$this->db->group_by('additional_contacts.state_id'); */
				$this->db->select('survey_answers.nominee_id as id,kol_names_for_survey.state as name,count(kol_names_for_survey.state) as count');
				$this->db->group_by("kol_names_for_survey.state");
				break;
			case 'city':
				$this->db->select('survey_answers.nominee_id as id,kol_names_for_survey.city as name,count(kol_names_for_survey.city) as count');
				//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
				$this->db->group_by('kol_names_for_survey.city');
				break;
			case 'postalcode':
				$this->db->select('survey_answers.nominee_id as id,kol_names_for_survey.postal_code as name,count(kol_names_for_survey.postal_code) as count');
				//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
				$this->db->group_by('kol_names_for_survey.postal_code');
				break;
			case 'respondent':
				//$this->db->select('survey_answers.respondent_id as id,resp_add_contants.full_name as name,count(survey_answers.respondent_id) as count',false);
				//$this->db->select("survey_answers.respondent_id as id,resp_add_contants.full_name as name,count(DISTINCT CONCAT(survey_answers.nominee_id,'-',survey_answers.question_id,'-',survey_answers.respondent_id)) as count",false);
				$this->db->select("survey_answers.respondent_id as id, kol_names_for_survey.search_name as name, count(DISTINCT kol_names_for_survey.search_name) as count",false);
				$this->db->group_by('kol_names_for_survey.search_name');
				break;
			case 'user':
				$this->db->select('client_users.id as id,CONCAT(client_users.first_name," ",client_users.last_name) as name,count(distinct survey_answers.nominee_id) as count',false);
				$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
				$this->db->group_by('CONCAT(client_users.first_name," ",client_users.last_name)');
				break;
			case 'territory':
				$this->db->select('sales_report_master_data.id,sales_report_master_data.territory_name as name,count(distinct survey_answers.nominee_id) as count',false);
				$this->db->group_by('sales_report_master_data.id');
				break;
			case 'region':
				$this->db->select('sales_report_master_data.region as id,sales_report_master_data.region as name,count(distinct survey_answers.nominee_id) as count',false);
				$this->db->group_by('sales_report_master_data.region');
				break;
			case 'district':
				$this->db->select('sales_report_master_data.district as id,sales_report_master_data.district as name,count(distinct survey_answers.nominee_id) as count',false);
				$this->db->group_by('sales_report_master_data.district');
				break;
		}
		$this->db->where('survey_answers.nominee_id>',0,false);
		$this->db->where('survey_answers.is_deleted','0');
		$arrResultSet = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		foreach($arrResultSet->result_array() as $row){
			//$row['id']	= str_replace(' ','_',$row['id']);
			$arrReturnData[$row['id']]	= $row;
		}
		return $arrReturnData;
	}
	function getSuggestionsForAutocompleteRefineBy($type,$surveyId,$keyword){
		$fieldName	= '';
		//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		//$this->db->join('additional_contacts','additional_contacts.id=survey_answers.nom_address_id','left');
		switch($type){
			case 'influencer':
					$fieldName	= 'concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name)';
					$this->db->select('concat(icontacts.first_name," ",icontacts.middle_name," ",icontacts.last_name) as name,icontacts.id',false);
					//$this->db->join('survey_kol_names','survey_kol_names.id=survey_answers.nominee_id','left');
				break;
			case 'country';
				$fieldName	= 'countries.country';
				
				
				$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
				$this->db->select('countries.country as name,countries.country as id');
			break;
			case 'state';
				
				/* $fieldName	= 'regions.region';
				$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
				$this->db->select('regions.region as name,regions.region as id'); */
				
				$this->db->select('kol_names_for_survey.state as name');
				$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
				$fieldName = 'kol_names_for_survey.state';
				
			break;
			case 'city';
				/* $fieldName	= 'cities.city';
				$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
				$this->db->select('cities.city as name,cities.city as id'); */
				
				$this->db->select('kol_names_for_survey.city as name');
				$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
				$fieldName = 'kol_names_for_survey.city';
			
			break;
			case 'postalcode';
				/* $fieldName	= 'postal_codes.postal_code';
				$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
				$this->db->select('postal_codes.postal_code as name,postal_codes.postal_code as id'); */
			
				$this->db->select('kol_names_for_survey.postal_code as name');
				$this->db->join('kol_names_for_survey','kol_names_for_survey.id = survey_answers.nominee_id','left');
				$fieldName = 'kol_names_for_survey.postal_code';
			break;
			case 'respondent':
				$fieldName	= 'concat(resopndents.first_name," ",resopndents.middle_name," ",resopndents.last_name)';
				$this->db->select('concat(resopndents.first_name," ",resopndents.middle_name," ",resopndents.last_name) as name,resopndents.id',false);
				$this->db->join('icontacts as resopndents','resopndents.id=survey_answers.respondent_id','left');
				
				break;
			case 'user':
				$fieldName	= '';
				$this->db->where("(client_users.first_name like '%".$keyword."%' OR client_users.last_name like '%".$keyword."%')");
				$this->db->select('CONCAT(client_users.first_name," ",client_users.last_name) as name,client_users.id',false);
				$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
				break;
			case 'territory':
				$fieldName	= '';
				$this->db->where("(sales_report_master_data.territory_name like '%".$keyword."%' OR sales_report_master_data.territory_id like '%".$keyword."%')");
				$this->db->select('sales_report_master_data.id,sales_report_master_data.territory_id,sales_report_master_data.territory_name as name',false);
				$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
				break;
			case 'region':
				$fieldName	= '';
				$this->db->where("sales_report_master_data.region like '%".$keyword."%'");
				$this->db->select('sales_report_master_data.region as id,sales_report_master_data.region as name',false);
				$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
				break;
			case 'district':
				$fieldName	= '';
				$this->db->where("sales_report_master_data.district like '%".$keyword."%'");
				$this->db->select('sales_report_master_data.district as id,sales_report_master_data.district as name',false);
				$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
				break;
		}
	//	echo $fieldName."sss";
		if(!empty($fieldName)){
			$this->db->like($fieldName,$keyword);
		}
		if($surveyId!=''){
		$this->db->where('survey_answers.survey_id',$surveyId);
		}
		//$this->db->group_by('name');
		$arrResultSet = $this->db->get('survey_answers');
		pr($this->db->last_query());exit;
		$arrReturnData	= array();
		foreach($arrResultSet->result_array() as $row){
			$arrReturnData[$row['id']]	= $row; 
		}
		//return array_unique($arrReturnData);
		return $arrReturnData;
	}
	function getNamesById($id){
		$this->db->select('additional_contacts.full_name as name,additional_contacts.kol_id',false);
		if(is_array($id)){
			$this->db->where_in('kol_id',$id);
		}else{
			$this->db->where('kol_id',$id);
		}
		$this->db->where('present_address',1);
		$arrResultSet = $this->db->get('additional_contacts');
		$arrReturnData	= array();
		foreach($arrResultSet->result_array() as $row){
			$arrReturnData[$row['kol_id']]	= $row; 
		}
		return $arrReturnData;
	}
	
	function getStateNameByCode($code,$country,$city){
			$this->db->select('region');
			$this->db->join('countries','countries.CountryId=regions.CountryID','left');
			$this->db->join('cities','cities.RegionID=regions.RegionID','left');
			$this->db->where('regions.code',$code);
			$this->db->where('country',$country);
			$this->db->where('city',$city);
			$arrSate = $this->db->get('regions');
			//echo $this->db->last_query();
			//pr($arrSate->num_rows());
			//echo $arrSate->num_rows();
			if($arrSate->num_rows()!=0){
				$array=array();
				$state = $arrSate->result_array();
				return $state[0]['region'];
			}else{
				return false;
			}
	}
	
	function getCityIdByNameAndState($city,$state){
		$this->db->select('cityId');
		$this->db->join('regions','cities.regionId=regions.RegionID','left');
		$this->db->where('city',$city);
		$this->db->where('region',$state);
		$arrCity = $this->db->get('cities');
		//echo $this->db->last_query();
		$city = $arrCity->result_array();
		return $city[0]['cityId'];
	}
	
	function chk_name($contacts){
		$this->db->select('id');
		
		//$arrNames = explode(' ',$contacts);
		$this->db->where('full_name',$contacts['full_name']);
		$arrResultSet = $this->db->get('icontacts');
		
		if($arrResultSet->num_rows()==0){
			$this->db->insert('icontacts',$contacts);
			//echo $this->db->last_query();
			return $this->db->insert_id();
			
		}else{
			$id = $arrResultSet->result_array();
			return $id[0]['id'];
		}
		
	}
	
	function chk_org_name($name){
		$contacts = array();
		$contacts['name'] = $name;
		$this->db->select('id');
		$this->db->where('name',$name);
		$arrResultSet = $this->db->get('organizations');
	//	echo $this->db->last_query();
		if($arrResultSet->num_rows()==0){
			$this->db->insert('organizations',$contacts);
			
			return $this->db->insert_id();
			
		}else{
			$id = $arrResultSet->result_array();
			return $id[0]['id'];
		}
	}

	function getNomineesAndRespondentName($id,$type,$arrSelections,$arrData){
		
		$arrReturnData	= array();
		$this->db->select('survey_answers.*,kol_names_for_survey.search_name as name,kol_names_for_survey.city,kol_names_for_survey.state',false);
		if($type=='nominees'){
			//$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
			$this->db->join('kol_names_for_survey','kol_names_for_survey.id=survey_answers.nominee_id','left');
			$this->db->where('respondent_id',$id);
			$this->db->where('survey_answers.nominee_id>',0,false);
			$this->db->group_by('survey_answers.nominee_id');
		}else{
			//$this->db->join('icontacts','icontacts.id=survey_answers.respondent_id','left');
			$this->db->join('kol_names_for_survey','kol_names_for_survey.id=survey_answers.respondent_id','left');
			$this->db->where('nominee_id',$id);
			$this->db->group_by('survey_answers.respondent_id');
		}
		//$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
		//$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		//$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
		if($arrData['survey_id']!=0 && $arrData['survey_id']!='All'){
			$this->db->where('survey_answers.survey_id',$arrData['survey_id']);
		}
	//	$this->db->limit(1);
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
						if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
							$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
						}
						if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
						if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
							if($isJoined==false){
							$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
							}
							$this->db->where_in('kol_names_for_survey.country',$arrSelectedData['country']);
						}
						if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
							$this->db->where_in('kol_names_for_survey.state',$arrSelectedData['state']);
						}
						if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
							$this->db->where_in('kol_names_for_survey.city',$arrSelectedData['city']);
						}
						if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
							$this->db->where_in('kol_names_for_survey.postal_code',$arrSelectedData['postal']);
						}
						break;
					case 'respondents':
						if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
							$this->db->where_in('survey_repsondents.id',$arrSelectedData['respondent']);
						}
						break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
						break;
				}
		}
		$this->db->where('survey_answers.is_deleted','0');
		$arrResultSet = 	$this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		foreach($arrResultSet->result_array() as $row){
			if($row["do_not_call_flag"] == 0)
				$row["do_not_call_flag"] = "No";
			else
				$row["do_not_call_flag"] = "Yes";
			$arrReturnData[]	= $row; 
		}
		return $arrReturnData;
	}
	
	function getIcontactAutocomplete($kolName,$where,$offset=0,$limit = 50,$isForMobile=false){
		$anotherdb ='';
		$anotherdb = $this->load->database('secondarydb',TRUE);
		$arrCompletedKols = array();
		$arrQuery = array();
		$query = '';
		$arrQuery[] = "SELECT * FROM icontacts WHERE MATCH(first_name,middle_name,last_name) AGAINST ('".$kolName."' IN BOOLEAN MODE) ";
		if($where["country_name"] != '')
			$arrQuery[] = " country_name LIKE '%".$where['country_name']."%'";
		if($where["state_name"] != '')
			$arrQuery[] = " state_name LIKE '%".$where['state_name']."%'";
		if($where["city_name"] != '')
			$arrQuery[] = " city_name LIKE '%".$where['city_name']."%'";
		if($where["postal_code"] != '')
			$arrQuery[] = " postal_code LIKE '%".$where['postal_code']."%'";
		
		if(count($arrQuery) > 0){
			$query .= implode(' AND ',$arrQuery);
		}else{
			$query .= $arrQuery[0];
		}
		$query	.=	 " LIMIT $offset,$limit";
		//echo $query;
		//exit; 
		$arrKolsResult = $anotherdb->query($query);
		foreach($arrKolsResult->result_array() as $row){
			$arrCompletedKols[$row['id']][]	= $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
			$arrCompletedKols[$row['id']][]	= $row['org_name'];
			if( $row['city_name']!=''){
				$arrCompletedKols[$row['id']][]	= $row['city_name'].', '.$row['state_name'].', '.$row['postal_code'];
			}
		}
		$arrKols['kols']		= $arrCompletedKols;
		return $arrKols;
	}
	
	
	function searchIcontactNames($where,$count=false,$start=0,$limit=50,$sord=null,$sidx=null,$isForMobile=false,$isAutoComplete=false,$type=''){
		
		if(isset($where["state_name"]) && strlen($where["state_name"]) == 2){
			$where["state_name"] = $this->country_helper->getStateNameByStateCode($where["state_name"]);
		}
		if($count){
			$this->db->select("COUNT(*) as count");
		}else{
			$this->db->select("kol_names_for_survey.*");
		}
		$arrQuery = array();
		if(isset($where['name']) && $where['name'] != ''){
			if(preg_match_all('/[\'^Ã¯Â¿Â½$%&*()}{@#~?><>,|=_+Ã¯Â¿Â½-]/',$where['name'],$matches)){
				$name = $this->prepareFullTextSearchString($where['name']);
				$name = custom_escape_string($name);
				//$this->db->where("(MATCH(search_name) AGAINST ('".$where['name']."' IN BOOLEAN MODE) OR MATCH(last_name,first_name,middle_name) AGAINST ('".$name."' IN BOOLEAN MODE) )");
			}else{
				$name = $this->prepareFullTextSearchString($where['name']);
				$name = custom_escape_string($name);
				//$this->db->where("MATCH(search_name) AGAINST ('".$where['name']."' IN BOOLEAN MODE)");
			}
//			$this->db->where("(MATCH(search_name) AGAINST ('".$name."' IN BOOLEAN MODE) OR MATCH(last_name,first_name,middle_name) AGAINST ('".$name."' IN BOOLEAN MODE) )");
//			$this->db->or_where("MATCH(last_name,first_name,middle_name) AGAINST ('".$name."' IN BOOLEAN MODE)");
		}
		if(isset($where['org_name']) && $where['org_name'] != ''){
			$this->db->like("org_name",$where['org_name']);
		}
		if(isset($where['country_name']) && $where['country_name'] != ''){
			$this->db->like("country_name",$where['country_name']);
		}
		if(isset($where['state_name']) && $where['state_name'] != ''){
			$this->db->like("state_name",$where['state_name']);
		}
		if(isset($where['city_name']) && $where['city_name'] != ''){
			$this->db->like("city_name",$where['city_name']);
		}
		if(isset($where['postal_code']) && $where['postal_code'] != ''){
			$this->db->like("postal_code",$where['postal_code']);
		}
		if(isset($where['master_customer_id']) && $where['master_customer_id'] != ''){
			$this->db->like("master_customer_id",$where['master_customer_id']);
		}
		if(isset($where['kol_id']) && $where['kol_id'] != ''){
			$this->db->where("kol_id != ",$where['kol_id']);
		}
		if(isset($where['respondent_id']) && $where['respondent_id'] != ''){
			$this->db->where("kol_id",$where['respondent_id']);
		}
		if(isset($where['name']) && $where['name'] != ''){
			if(preg_match_all('/[\'^Ã¯Â¿Â½$%&*()}{@#~?><>,|=_+Ã¯Â¿Â½-]/',$where['name'],$matches)){
				//$where['name'] = mysqli_real_escape_string($where['name']);
				$this->db->where("(search_name LIKE '".$where['name']."%' OR CONCAT(last_name,' ',first_name,' ',middle_name) LIKE '".$where['name']."%')");
			}else{
				//$where['name'] = mysqli_real_escape_string($where['name']);
				$this->db->like("search_name",$where['name']);
				
			}
		}
		
		if($type=='nom' && $type!=''){
			$this->db->distinct('kol_names_for_survey.id');
			$this->db->join('survey_answers','survey_answers.nominee_id=kol_names_for_survey.id','inner');
		}else if($type=='resp' && $type!=''){
			$this->db->distinct('additional_contacts.kol_id');
			$this->db->join('survey_answers','survey_answers.resp_address_id=additional_contacts.id','inner');
		}
		
		//$this->db->where("present_address",1);
		if($isAutoComplete && $sord==null){
			$this->db->order_by("last_name,first_name,middle_name","ASC");
		}
		//$arrKolsResult = $this->db->get("kol_names_for_survey");
		//pr($this->db->last_query());exit;
		//$this->db->where("do_not_call_flag",0);
		//$this->db->select("do_not_call_flag");
		if($count){
			$arrKolsResult = $this->db->get("kol_names_for_survey");
			foreach ($arrKolsResult->result_array() as $row){
				$count = $row['count'];
			}
			return $count;
		}else{
			if(isset($sidx)){
				$this->db->order_by($sidx,$sord);
			}
			if($limit != 0)
				$this->db->limit($limit);
				$this->db->offset($start);
			$arrKolsResult = $this->db->get("kol_names_for_survey");
//			echo $this->db->last_query();
//			echo exit;
			$arrReturnData = array();
			if(!$isAutoComplete){
				foreach($arrKolsResult->result_array() as $row){
					$row['unique_id'] = $row['id'];
					$row['name']	= $row['last_name'].", ".$row['first_name']." ".$row['middle_name'];//trim(nf($row['first_name'],$row['middle_name'],$row['last_name']));
					$donotcall	= '';
					/* if($row['do_not_call_flag']==1){
						$donotcall	= 'Do Not Call';
					}
					$row['do_not_call']	= $donotcall; */
					$arrReturnData[]	= $row;
				}
				return $arrReturnData;
			}else{
				if($isForMobile){
					$arrReturnData = array();
					$donotcall	= '';
					foreach($arrKolsResult->result_array() as $row){
						$row['unique_id'] = $row['id'];
						if($row['last_name'] == '')
							$row['name']	= $row['first_name']." ".$row['middle_name'];//trim(nf($row['first_name'],$row['middle_name'],$row['last_name']));
						else
							$row['name']	= $row['last_name'].", ".$row['first_name']." ".$row['middle_name'];
						$address = array_filter(array($row['city_name'],$row['state_name'],$row['postal_code'],$row['country_name']));
						$donotcall	= '';
						if($row['do_not_call_flag']==1){
							$donotcall	= 'Do Not Call';
					}
						$row['do_not_call']	= $donotcall;
						$arrRowData	= array();
						$arrRowData['name']	= $row['name'];
						$arrRowData['master_customer_id']	= $row['master_customer_id'];
						$arrRowData['city']	= $row['city_name'];
						$arrRowData['state']	= $row['state_name'];
						$arrRowData['address']	= implode(', ',$address);
						$arrRowData['kol_id']	= $row['kol_id'];
						$arrRowData['address_id']	= $row['id'];
						$arrRowData['do_not_call']	= $donotcall;
						if($includeGeoData){
							$arrRowData['latitude']	= $row['latitude'];
							$arrRowData['longitude']	= $row['longitude'];
						}
						$arrReturnData[]	= $arrRowData;
					}
					return $arrReturnData;
				}else{
					$arrCompletedKols = array();
					foreach($arrKolsResult->result_array() as $row){
						/* $donotcall	= '';
						if($row['do_not_call_flag']==1){
							$donotcall	= 'Do Not Call';
						}
						$row['do_not_call']	= $donotcall; */
						$address = array_filter(array($row['city_name'],$row['state_name'],$row['postal_code'],$row['country_name']));
						foreach ($address as $key=>$val){
							if(trim($val) == '')
								unset($address[$key]);
						}
						$address = array_values($address);
						$arrCompletedKols[$row['id']]['kol_id']	= $row['kol_id'];
						$arrCompletedKols[$row['id']][]	= $row['last_name'].", ".$row['first_name']." ".$row['middle_name'];//$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
						$arrCompletedKols[$row['id']][]	= $row['master_customer_id'];
						if(count($address) > 1)
							$arrCompletedKols[$row['id']][]	= implode(', ',$address);
						else
							$arrCompletedKols[$row['id']][]	= $address[0];
						$arrCompletedKols[$row['id']][]	= $row['do_not_call'];
						if($includeGeoData){
							$arrCompletedKols[$row['id']][]	= $row['latitude'];
							$arrCompletedKols[$row['id']][]	= $row['longitude'];
					}
					}
					$arrKols['kols']		= $arrCompletedKols;
					return $arrKols;
				}	
			}
		}
	}
	function prepareFullTextSearchString($string){
		$arrString = explode(" ",$string);
		if(count($arrString)>1){
			$newStr = '';
			for ($i = 0; $i<count($arrString)-1; $i++){
				$newStr .= '+'.$arrString[$i].' ';
			}
			$newStr .= $arrString[sizeof($arrString) - 1].'*';
			$retString = $newStr;
		}else{
			$retString = $string.'*';
		}
		return $retString;
	}
	
	function chkCountOfNombers($surveyId,$userId,$stateId,$useChk){
		
		$this->db->join('additional_contacts','additional_contacts.id=survey_answers.nom_address_id');
		$this->db->join('regions','regions.Regionid=additional_contacts.state_id');
		$this->db->where('survey_id',$surveyId);
		if($useChk){
			$this->db->where('survey_answers.created_by',$userId);
		}
		if(!($useChk)){
			$this->db->where('state_id',$stateId);
		}
		
		$arr = $this->db->get('survey_answers');
		//pr($this->db->last_query());exit;
		return $arr->num_rows();
		
		
	}
	
	function getTopState($surveyId){
		$this->db->select('region,COUNT(DISTINCT survey_answers.nominee_id) AS COUNT');
		$this->db->join('additional_contacts','additional_contacts.id=survey_answers.nom_address_id');
		$this->db->join('regions','regions.Regionid=additional_contacts.state_id');
		$this->db->where('survey_id',$surveyId);
		$this->db->group_by('regions.RegionID');
		$this->db->order_by('count','desc');
		$this->db->limit(1);
		$arr = $this->db->get('survey_answers');
		$name = $arr->result_array();
		
		//echo $name[0]['region'];
		return $name[0]['region'];
	}
	
	function getMatchingCities($arrParams){
		$limit = 10;
		$offset = 0;
		$arrData = array();
		$this->db->select('cities.cityId as id,cities.city as name');
		$this->db->join('countries','cities.countryId=countries.countryId','left');
		if(isset($arrParams['string']))
			$this->db->like('city',$arrParams['string']);
		if(isset($arrParams['state'])){
			$this->db->join('regions','cities.regionId=regions.regionId','left');
			$this->db->like('regions.region',$arrParams['state']);
			//$this->db->or_like('regions.code',$arrParams['state']);
		}
		if(isset($arrParams['country'])){
			$this->db->like('countries.country',$arrParams['country']);
		}else{
			$this->db->where('countries.country',"United States");
		}	
		if(isset($arrParams['limit']) )
			$limit = $arrParams['limit'];
		if(isset($arrParams['offset']) )
			$offset = $arrParams['offset'];
		$this->db->group_by('name');
		$this->db->limit($limit,$offset);
		$this->db->order_by('name','asc');
		$results = $this->db->get('cities');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function getMatchingCitiesNew($arrParams){
		$anotherdb ='';
		$anotherdb = $this->load->database('secondarydb',TRUE);
		$query = '';
		$limit = 10;
		$offset = 0;
		$arrData = array();
		$arrQuery = array();
		$arrQuery[] = " SELECT DISTINCT city_name as name,city_id as id FROM additional_contacts WHERE country_id = 254 ";
		if(isset($arrParams['string']) && $arrParams['string'] != ''){
			$arrParams['string'] = $this->prepareFullTextSearchString($arrParams['string']);
			$arrQuery[] = " MATCH(city_name) AGAINST ('".$arrParams['string']."' IN BOOLEAN MODE) ";
		}
		if(isset($arrParams['state']) && $arrParams['state'] != ''){
			$arrParams['state'] = $this->prepareFullTextSearchString($arrParams['state']);
			$arrQuery[] = " MATCH(state_name) AGAINST ('".$arrParams['state']."' IN BOOLEAN MODE) ";
		}
		if(count($arrQuery)>1){
			$query .= implode(' AND ',$arrQuery);
		}else{
			$query .= $arrQuery[0];
		}
		$query .= " GROUP BY name ";
		$query .= " ORDER BY name ASC ";
		if(isset($arrParams['offset']) ){
			$offset = $arrParams['offset'];
			$query .= " LIMIT $offset ";
		}else{
			$query .= " LIMIT $offset ";
		}
		if(isset($arrParams['limit']) ){
			$limit = $arrParams['limit'];
			$query .= ",$limit ";
		}else{
			$query .= ",$limit ";
		}
		//echo $query;
		$results = $anotherdb->query($query); 
		foreach($results->result_array() as $row){
			if($row['name'] == null || $row['name'] == '')
				continue;
			$arrData[] = $row;
		}
//		pr($arrData);
		return $arrData;
	}
    
	function  saveUserLog($arrLogs){
		$this->db->insert('user_logs',$arrLogs);
	}
	
	function getAddressIdByKolId($kolId){
		$this->db->select('id');
		$this->db->where('kol_id',$kolId);
		$this->db->where('present_address',1);
		$results = $this->db->get('additional_contacts');
		foreach($results->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData[0]['id'];	
	}
	
	function saveStagingContact($arrParams,$returnDetails=true){
		$returnData	= array();
		$returnData['id']	= 0;
		$createdBy	= $this->session->userdata('user_id');
		$arrTerritoryData		= $this->getUserTerritory($createdBy);
		$arrParams['territory_id']	= $arrTerritoryData['id'];
		$arrParams['territory']	= $arrTerritoryData['territory'];
		if(!isset($arrParams['created_by']))
			$arrParams['created_by']	= $createdBy;
		$arrParams['created_on']	= date("Y-m-d H:i:s");
		$arrParams['is_iprofile'] = 1;
		if($this->db->insert('staging_icontacts',$arrParams)){
			$returnData['id']	= $this->db->insert_id();
			if($returnDetails){
				$returnData['name']	= trim(nf($arrParams['first_name'],$arrParams['middle_name'],$arrParams['last_name']));
				$returnData['address_id']	= 0;
				$returnData['mdm_id']	= $arrParams['mdm_id'];
				$address = array_filter(array($arrParams['city'],$arrParams['state'],$arrParams['postal_code'],$arrParams['country']));
				$returnData['address']	= implode(', ',$address);
			}
		}
		return $returnData;
	}
	function suggestSimilarNames($arrParams){
		if(strlen($arrParams['state'])==2){
			$arrParams['state'] = $this->country_helper->getStateNameByStateCode($arrParams['state']);
		}
		$arrData	= array();
		$this->db->select('additional_contacts.kol_id,additional_contacts.id as address_id,concat(additional_contacts.last_name,", ",additional_contacts.first_name," ",additional_contacts.middle_name )as name,additional_contacts.city_name as city,additional_contacts.state_name as state,additional_contacts.country_name as country,additional_contacts.master_customer_id,additional_contacts.postal_code',false);
		$this->db->like('additional_contacts.first_name',$arrParams['first_name']);
		$this->db->like('additional_contacts.last_name',$arrParams['last_name']);
//		$this->db->like('additional_contacts.city_name',$arrParams['city']);
		if($arrParams['country'] != '')
			$this->db->like('additional_contacts.country_name',$arrParams['country']);
		$this->db->where('additional_contacts.present_address',1);
		$this->db->like('additional_contacts.state_name',$arrParams['state']);
		$results = $this->db->get('additional_contacts');
		foreach($results->result_array() as $row){
			$address = array_filter(array($row['city'],$row['state'],$row['postal_code'],$row['country']));
			$row['address']	= implode(', ',$address);
			$arrData[] = $row;
		}
		return $arrData;
	}
	function getSurvey($id=0){
		$arrData		= array();
		if($id>0){
			$this->db->where('id',$id);
			$arrResultData	= $this->db->get('surveys');
			if($arrResultData->num_rows()>0){
				$arrRow	= $arrResultData->result_array();
				$arrData	= $arrRow[0];
			}
		}
		return $arrData;
	}
	
	function searchStagingIcontactNames($arrParams=array()){
		$arrData	= array();
		$this->db->where('id',$arrParams['id']);
		$this->db->limit(1);
		$arrResultData	= $this->db->get('staging_icontacts');
		if($arrResultData->num_rows()>0){
			foreach($arrResultData->result_array() as $row){
				$row['name']	= trim(nf($row['first_name'],$row['middle_name'],$row['last_name']));
				$arrData	= $row;
			}
		}
		return $arrData;
	}
	
	function deleteStagingIcontactsById($id=0){
		$return =	false;
		if($id>0){
			$created_by	= $this->session->userdata('user_id');
			$this->db->where('id',$id);
			$this->db->where('created_by',$created_by);
			if($this->db->delete('staging_icontacts'))
				$return	= true;
		}
		return $return;
	}
	
	function markInfluencerAsDelete($surveyId,$questionId,$respondentId,$respondentAddressId,$influenceId,$influenceAddressId,$createdBy=0){
		$return =	false;
		if($influenceId>0 && $surveyId>0 && $questionId>0){
			$userId	= $this->session->userdata('user_id');
			$arrUpdateData	= array();
			$arrUpdateData['is_deleted']	= 1;
			$arrUpdateData['deleted_by']	= $userId;
			$arrUpdateData['deleted_on']	= date("Y-m-d H:i:s");
			if($createdBy==0){
				$createdBy	= $userId;
			}
			$this->db->where('survey_id',$surveyId);
			$this->db->where('question_id',$questionId);
			$this->db->where('respondent_id',$respondentId);
			$this->db->where('resp_address_id',$respondentAddressId);
			$this->db->where('nominee_id',$influenceId);
			$this->db->where('nom_address_id',$influenceAddressId);
			$this->db->where('created_by',$createdBy);
			if($this->db->update('survey_answers',$arrUpdateData)){
				$return	= true;
				$arrTerritoryData		= $this->getUserTerritory($createdBy);
				$territoryId	= $arrTerritoryData['id'];
				$territory	= $arrTerritoryData['territory'];
				$arrInsertSurveyDetails	 = array();
				$arrInsertSurveyDetails['survey_id']	= $surveyId;
				$arrInsertSurveyDetails['created_by']	= $createdBy;
				$arrInsertSurveyDetails['territory_id']	= $territoryId;
				$arrInsertSurveyDetails['territory']	= $territory;
				$arrInsertSurveyDetails['created_on']	= date("Y-m-d H:i:s");
				$arrInsertSurveyDetails['is_submitted']	= 1;
				$arrInsertSurveyDetails['respondent_id']	= $respondentId;
				$arrInsertSurveyDetails['resp_address_id']	= $respondentAddressId;
				$this->creditUserForRespondent($surveyId,$respondentId,$respondentAddressId,$arrInsertSurveyDetails);
			}
		}
		return $return;
	}
	function markRespondentAsDelete($surveyId,$respondentId,$respondentAddressId,$isZeroInfluencer=false){
		$return =	false;
		if($surveyId>0 && $respondentId>0 && $respondentAddressId>0){
			$userId	= $this->session->userdata('user_id');
			$arrUpdateData	= array();
			$arrUpdateData['is_deleted']	= 1;
			$arrUpdateData['deleted_by']	= $userId;
			$arrUpdateData['deleted_on']	= date("Y-m-d H:i:s");
			$this->db->where('survey_id',$surveyId);
			$this->db->where('respondent_id',$respondentId);
			$this->db->where('resp_address_id',$respondentAddressId);
			$this->db->where('question_id is ','null',false);
			if($isZeroInfluencer){
				$this->db->where('zeroInfluencers>',0,false);	
			}
			if($this->db->update('survey_answers',$arrUpdateData))
				$return	= true;
		}
		return $return;
	}
	function creditUserForRespondent($surveyId,$respondentId,$respondentAddressId,$arrInsertSurveyDetails){
		$return =	false;
		$userId	= $this->session->userdata('user_id');
		if($surveyId>0 && $respondentId>0 && $respondentAddressId>0){
			$this->db->where('survey_id',$surveyId);
			$this->db->where('respondent_id',$respondentId);
			$this->db->where('resp_address_id',$respondentAddressId);
			$this->db->where('created_by',$userId);
			$resultSet	= $this->db->get('survey_answers');
			//echo $resultSet->num_rows();
			//pr($resultSet->result_array());
			if($resultSet->num_rows()==0){
				$arrInsertSurveyDetails['zeroInfluencers']	= 99;
				if($this->db->insert('survey_answers',$arrInsertSurveyDetails))
					$return	= true;
			}
		}
		return $return;
	}
	
	function addRespondentToSurvey($arrData,$isRespondent=false){
		$returnId	= 0;
		if(!$isRespondent){
			$this->deleteSurveyRespondentWithZeroInfluencer($arrData['survey_id'],$arrData['respondent_id'],$arrData['created_by']);
			if($this->db->insert('survey_answers',$arrData)){
				$returnId	= $this->db->insert_id();
			}
		}else{
			$arrUpdateData	= array();
			$arrUpdateData['zeroInfluencers']	= $arrData['zeroInfluencers'];
			$arrUpdateData['created_by']	= $this->session->userdata('user_id');
			$arrUpdateData['created_on']	= date("Y-m-d H:i:s");
			$this->db->where('id',$arrData['respondent_id']);
			$this->db->where('survey_id',$arrData['survey_id']);
			$this->db->where('created_by',$arrData['created_by']);
			if($this->db->update('staging_icontacts',$arrUpdateData)){
				$returnId	= $arrData['respondent_id'];
			}
		}
		return $returnId;
	}
	
	function saveSurveysAnswers($arrParams,$isStagingRespondent=false){
		$createdOn	= date("Y-m-d H:i:s");
		$createdBy	= $this->session->userdata('user_id');
		$arrTerritoryData		= $this->getUserTerritory($createdBy);
		$territoryId	= $arrTerritoryData['id'];
		$territory	= $arrTerritoryData['territory'];
		$surveyId	= $arrParams['survey_id'];
		$respondentId	= $arrParams['respondent_id'];
		$respondentAddressId	= $arrParams['respondent_address_id'];
		$respondantHaveNoNames	= $arrParams['no_influencers_reason'];
		$influencersData	= $arrParams['influencers_data']; // array of 'questionID_NomineeID_NomineeAddressID'
		if($surveyId>0 && $respondentId>0 && $createdBy>0){
			if($respondantHaveNoNames>0){
					$arrData	= array();
					$arrData['survey_id']	= $surveyId;
					$arrData['created_by']	= $createdBy;
					$arrData['territory_id']= $territoryId;
					$arrData['territory']	= $territory;
					$arrData['created_on']	= $createdOn;
					$arrData['respondent_id']	= $respondentId;
					$arrData['zeroInfluencers']	= $respondantHaveNoNames;
					if(!$isStagingRespondent){
						$arrData['resp_address_id']	= $respondentAddressId;
						$arrData['is_submitted']	= 1;
						$this->addRespondentToSurvey($arrData);
					}else{
						$this->addRespondentToSurvey($arrData,true);
					}
					foreach($influencersData as $key=>$row){
						$arrRow	= explode('_',$row);
						$questionId	= $arrRow[0];
						$nomineeId	= $arrRow[1];
						$nomineeAddressId	= $arrRow[2];
						if($nomineeId!='' && $nomineeAddressId==0){
							$this->deleteStagingIcontactsById($nomineeId);
						}
					}
			}else if($isStagingRespondent){
				/*$preparedStatements	= "insert into staging_icontacts(first_name,middle_name,last_name,specialty,city,state,country,postal_code,mdm_id,staging_respondent_id,survey_id,survey_question_id,survey_influencer_id,survey_influencer_address_id,created_by,created_on) values ";
				$separator	= '';
				foreach($influencersData as $key=>$row){
					$arrRow	= explode('_',$row);
					$questionId	= $arrRow[0];
					$nomineeId	= $arrRow[1];
					$nomineeAddressId	= $arrRow[2];
					if($nomineeId!='' && $nomineeAddressId>0){
						$arrInsertRecord	 = array();
						$influenerData	= $this->searchIcontactNames(array('respondent_id'=>$nomineeId),false);
						$influenerData	= $influenerData[0];
						//pr($returnData);
						$preparedStatements	.= $separator.'("'.$influenerData['first_name'].'","'.$influenerData['middle_name'].'","'.$influenerData['last_name'].'","'.$influenerData['specialty'].'","'.$influenerData['city_name'].'","'.$influenerData['state_name'].'","'.$influenerData['country_name'].'","'.$influenerData['postal_code'].'","'.$influenerData['master_customer_id'].'",'.$respondentId.','.$surveyId.','.$questionId.','.$nomineeId.','.$nomineeAddressId.','.$createdBy.',"'.$createdOn.'")';
						$separator		= ',';
					}
				}*/
				//echo $preparedStatements;
				$newInfluencersData	= array();
				$arrInsertSurveyDetails	 = array();
				$arrInsertSurveyDetails['survey_id']	= $surveyId;
				$arrInsertSurveyDetails['created_by']	= $createdBy;
				$arrInsertSurveyDetails['territory_id']= $territoryId;
				$arrInsertSurveyDetails['territory']	= $territory;
				$arrInsertSurveyDetails['created_on']	= $createdOn;
				$arrInsertSurveyDetails['staging_respondent_id']	= $respondentId;
				foreach($influencersData as $key=>$row){
					$arrInsertData	= array();
					$arrInfluencerRow	= explode('_',$row);
					$questionId	= $arrInfluencerRow[0];
					$nomineeId	= $arrInfluencerRow[1];
					$nomineeAddressId	= $arrInfluencerRow[2];
					if($nomineeId>0 && $nomineeAddressId>0){
						$influenerData	= $this->searchIcontactNames(array('respondent_id'=>$nomineeId),false);
						$influenerData	= $influenerData[0];
						$arrInsertData['first_name']	= $influenerData['first_name'];
						$arrInsertData['middle_name']	= $influenerData['middle_name'];
						$arrInsertData['last_name']	= $influenerData['last_name'];
						$arrInsertData['specialty']	= $influenerData['specialty'];
						$arrInsertData['city']		= $influenerData['city_name'];
						$arrInsertData['state']		= $influenerData['state_name'];
						$arrInsertData['country']	= $influenerData['country_name'];
						$arrInsertData['postal_code']	= $influenerData['postal_code'];
						$arrInsertData['mdm_id']	= $influenerData['master_customer_id'];
						$arrInsertData['survey_question_id']	= $questionId;
						$arrInsertData['survey_influencer_id']	= $nomineeId;
						$arrInsertData['survey_influencer_address_id']= $nomineeAddressId;
						$newInfluencersData	= array_merge($arrInsertSurveyDetails, $arrInsertData);
						$anotherdb = $this->load->database('default',TRUE);
						$newInfluencersData['is_iprofile'] = 1;
						$this->db->insert('staging_icontacts',$newInfluencersData);
					}
				}
				//$anotherdb = $this->load->database('default',TRUE);
				//$this->db->query($preparedStatements);
			}else{
				//$this->deleteSurveyRespondent($surveyId,$respondentId,$createdBy);
				/*$preparedStatements	= "insert into survey_answers(question_id,nominee_id,respondent_id,created_by,created_on,survey_id,is_submitted,nom_address_id,resp_address_id) values ";
				$separator	= '';
				foreach($surveyInfluencers as $key=>$row){
					$arrRow	= explode('_',$row);
					$questionId	= $arrRow[0];
					$nomineeId	= $arrRow[1];
					$nomineeAddressId	= $arrRow[2];
					if($nomineeId!='' && $nomineeAddressId>0){
						$preparedStatements	.= $separator.'("'.$questionId.'","'.$nomineeId.'","'.$respondentId.'","'.$createdBy.'","'.$createdOn.'","'.$surveyId.'","1","'.$nomineeAddressId.'","'.$respondentAddressId.'")';
						$separator		= ',';
					}
				}
				//echo $preparedStatements;
				//$this->db->query($preparedStatements);
				*/
				$this->deleteSurveyRespondentWithZeroInfluencer($surveyId,$respondentId,$createdBy);
				$newInfluencersData	= array();
				$arrInsertSurveyDetails	 = array();
				$arrInsertSurveyDetails['survey_id']	= $surveyId;
				$arrInsertSurveyDetails['created_by']	= $createdBy;
				$arrInsertSurveyDetails['territory_id']= $territoryId;
				$arrInsertSurveyDetails['territory']	= $territory;
				$arrInsertSurveyDetails['created_on']	= $createdOn;
				$arrInsertSurveyDetails['is_submitted']	= 1;
				$arrInsertSurveyDetails['respondent_id']	= $respondentId;
				$arrInsertSurveyDetails['resp_address_id']	= $respondentAddressId;
				$noOfNewRecordsInserted	= 0;
				$noOfRecords	= 0;
				foreach($influencersData as $key=>$row){
					$arrInsertData	= array();
					$arrInfluencerRow	= explode('_',$row);
					$questionId	= $arrInfluencerRow[0];
					$nomineeId	= $arrInfluencerRow[1];
					$nomineeAddressId	= $arrInfluencerRow[2];
					$skipRecord	= 0;
					if(isset($arrInfluencerRow[3]) && $arrInfluencerRow[3]>0){
						$skipRecord	= $arrInfluencerRow[3];
					}
					if($nomineeId>0 && $nomineeAddressId>0 && $skipRecord===0){
						$arrInsertData['question_id']	= $questionId;
						$arrInsertData['nominee_id']	= $nomineeId;
						$arrInsertData['nom_address_id']= $nomineeAddressId;
						$newInfluencersData	= array_merge($arrInsertSurveyDetails, $arrInsertData);
						$this->db->insert('survey_answers',$newInfluencersData);
						$noOfNewRecordsInserted++;
					}
					$noOfRecords++;
				}
				if($noOfNewRecordsInserted==0){
					/*$arrInsertSurveyDetails	 = array();
					$arrInsertSurveyDetails['survey_id']	= $surveyId;
					$arrInsertSurveyDetails['created_by']	= $createdBy;
					$arrInsertSurveyDetails['territory_id']	= $territoryId;
					$arrInsertSurveyDetails['territory']	= $territory;
					$arrInsertSurveyDetails['created_on']	= $createdOn;
					$arrInsertSurveyDetails['is_submitted']	= 1;
					$arrInsertSurveyDetails['respondent_id']	= $respondentId;
					$arrInsertSurveyDetails['resp_address_id']	= $respondentAddressId;*/
					$this->creditUserForRespondent($surveyId,$respondentId,$respondentAddressId,$arrInsertSurveyDetails);
					//echo $this->db->last_query();exit();
				}/*else if($noOfNewRecordsToInsert>0){
					//soft delete zero influcer respondents
					 $this->markRespondentAsDelete($surveyId,$respondentId,$respondentAddressId,true);
					 //echo $this->db->last_query();
				}*/
			}

		}

	}
	function deleteSurveyRespondentWithZeroInfluencer($surveyId,$respondentId,$createdBy){
		$this->db->where('survey_answers.survey_id',$surveyId);
		$this->db->where('survey_answers.respondent_id',$respondentId);
		$this->db->where('survey_answers.created_by',$createdBy);
		$this->db->where('survey_answers.zeroInfluencers>',0,false);
		$this->db->delete('survey_answers');
	}
	function isLoggedInUserExistsInGroup($groupName=''){
		$isAllowed	= false;
		if($groupName!=''){
			$userId	= $this->session->userdata('user_id');
			$this->db->select('user_groups.group_id');
			$this->db->join('groups','groups.group_id=user_groups.group_id','left');
			$this->db->where('user_id',$userId);
			$this->db->like('groups.group_name',$groupName);
			$resultSet = $this->db->get('user_groups');
			if($resultSet->num_rows()>0){
				$isAllowed	= true;
			}
		}
		return $isAllowed;
	}
	function salesReport($surveyId=0){
		$query	= "SELECT CONCAT(managers.first_name,' ',managers.last_name) AS manager_name,surveys.name AS survey_name,  CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name, client_users.territory,
					client_users.id as user_id,
					client_users.title,
					client_users.email,
					survey_answers.created_on,
					surveys.id AS survey_id,
					survey_questions.type_id AS type,
					abs(COUNT(survey_answers.nominee_id)) AS no_of_influencers,
					GROUP_CONCAT(survey_questions.type_id) AS qtype
					,abs(COUNT(DISTINCT survey_answers.respondent_id)) AS respondents_count
					,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district,sales_report_master_data.call_plan
					,COUNT(survey_answers.zeroInfluencers) AS respondent_only";
		$query	.= " FROM survey_answers
					LEFT JOIN surveys ON surveys.id=survey_answers.survey_id
					LEFT JOIN client_users ON client_users.id=survey_answers.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN survey_questions ON survey_questions.id=survey_answers.question_id 
					LEFT JOIN sales_report_master_data ON sales_report_master_data.territory_id=client_users.territory";
		$query	.= " where survey_answers.is_deleted=0";
		if($surveyId>0){
			$query	.= " and survey_answers.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_name,survey_answers.created_by
					ORDER BY user_name,manager_name,survey_name";
		$productionResultSet	= $this->db->query($query);
		
		$query	= "SELECT 
					staging_icontacts.id,
					surveys.name AS survey_name,
					surveys.id AS survey_id,
					survey_questions.type_id AS type,
					staging_icontacts.first_name,staging_icontacts.middle_name,staging_icontacts.last_name,staging_icontacts.organization,staging_icontacts.specialty,staging_icontacts.city,staging_icontacts.state,staging_icontacts.created_on
					, CONCAT(managers.first_name,' ',managers.last_name) AS manager_name, CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name, client_users.territory,client_users.title,
					client_users.email,
					client_users.id as user_id,
					abs(COUNT(staging_icontacts.id)-COUNT(staging_icontacts.zeroInfluencers)) AS no_of_influencers,
					GROUP_CONCAT(survey_questions.type_id) AS qtype
					,SUM(CASE WHEN staging_icontacts.survey_question_id IS NULL THEN 1 ELSE 0 END) AS respondents_count
					,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district,sales_report_master_data.call_plan
					,COUNT(staging_icontacts.zeroInfluencers) AS respondent_only";
		$query	.= " FROM staging_icontacts
					LEFT JOIN client_users ON client_users.id=staging_icontacts.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN surveys ON surveys.id=staging_icontacts.survey_id
					LEFT JOIN survey_questions ON survey_questions.id=staging_icontacts.survey_question_id 
					LEFT JOIN sales_report_master_data ON sales_report_master_data.territory_id=client_users.territory";
		//$query	.= " WHERE (staging_icontacts.survey_question_id>0 OR staging_icontacts.zeroInfluencers>0)";
		if($surveyId>0){
			$query	.= " WHERE staging_icontacts.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_name,staging_icontacts.created_by
					ORDER BY user_name,manager_name,survey_name";
		$stagingResultSet	= $this->db->query($query);
		//echo $this->db->last_query();
		$returnData	= array();
		$stagingData	= array();
		foreach($stagingResultSet->result_array() as $row){
			$uniqueId = $row['user_id'].'_'.$row['survey_id'];
			$stagingData[$uniqueId]	= $row;
		}
		foreach($productionResultSet->result_array() as $row){
			$respondentsCount	= 0;
			$stagingInfluencers	= 0;
			$totalInfluencers	= 0;
			$uniqueId = $row['user_id'].'_'.$row['survey_id'];
			$arrStagingCountByTypes = array(1=>0,2=>0);
			$percOfCallPlan	= 0;
			if(isset($stagingData[$uniqueId])){
				$stagingZeroInfluencersCount	= $stagingData[$uniqueId]['respondent_only'];
				$respondentsCount	= ($row['respondents_count']+$stagingData[$uniqueId]['respondents_count']);
				$explodeByType	= explode(',',$stagingData[$uniqueId]['qtype']);
				$arrStagingCountByTypes= array_count_values($explodeByType);
				$arrStagingCountByTypes[1]	= (isset($arrStagingCountByTypes[1])?$arrStagingCountByTypes[1]:0);
				$arrStagingCountByTypes[2]	= (isset($arrStagingCountByTypes[2])?$arrStagingCountByTypes[2]:0);
				$stagingInfluencers	= $stagingData[$uniqueId]['no_of_influencers'];
				$totalInfluencers	= ($row['no_of_influencers']+$stagingData[$uniqueId]['no_of_influencers']);
				unset($stagingData[$uniqueId]);
			}else{
				$respondentsCount	= $row['respondents_count'];
				$totalInfluencers	= $row['no_of_influencers'];
				$stagingZeroInfluencersCount	= 0;
			}
			$explodeByType	= explode(',',$row['qtype']);
			$arrCountByTypes= array_count_values($explodeByType);
			$rowData	= array();
			$rowData['survey_name']	= $row['survey_name'];
			$rowData['region']	= $row['region'];
			$rowData['district']	= $row['district'];
			$rowData['territory_name']	= $row['territory_name'];
			$rowData['territory']	= $row['territory'];
			$rowData['user_name']	= $row['user_name'];
			$rowData['respondents_count']	= $respondentsCount;
			$rowData['prod_local']	= (isset($arrCountByTypes[1])?$arrCountByTypes[1]:0);
			$rowData['prod_national']	= (isset($arrCountByTypes[2])?$arrCountByTypes[2]:0);
			$rowData['prod_zero_influencers']	= $row['respondent_only'];
			$rowData['prod_responses']	= $row['no_of_influencers'];
			$rowData['staging_local']	= $arrStagingCountByTypes[1];
			$rowData['staging_national']	= $arrStagingCountByTypes[2];
			$rowData['staging_zero_influencers']	= $stagingZeroInfluencersCount;
			$rowData['staging_responses']	= $stagingInfluencers;
			$rowData['total']	= $totalInfluencers;
			$rowData['call_plan']	=$row['call_plan'];
			$callPlanPercentage	= ($respondentsCount/$row['call_plan']*100);
			if($callPlanPercentage==''){
				$callPlanPercentage	= 0.0;
			}
			$rowData['call_plan_percentage']	= round($callPlanPercentage,2).'%';
			$rowData['title']	= $row['title'];
			$rowData['email']	= $row['email'];
			$rowData['manager_name']	= $row['manager_name'];
			$returnData[]	= $rowData;
		}
		foreach($stagingData as $key=> $row){
			$explodeByType	= explode(',',$row['qtype']);
			$arrCountByTypes= array_count_values($explodeByType);
			$rowData	= array();
			$rowData['survey_name']	= $row['survey_name'];
			$rowData['region']	= $row['region'];
			$rowData['district']	= $row['district'];
			$rowData['territory_name']	= $row['territory_name'];
			$rowData['territory']	= $row['territory'];
			$rowData['user_name']	= $row['user_name'];
			$rowData['respondents_count']	= $row['respondents_count'];
			$rowData['prod_local']	= 0;
			$rowData['prod_national']	= 0;
			$rowData['prod_zero_influencers']	= 0;
			$rowData['prod_responses']	= 0;
			$rowData['staging_local']	= (isset($arrCountByTypes[1])?$arrCountByTypes[1]:0);
			$rowData['staging_national']	= (isset($arrCountByTypes[2])?$arrCountByTypes[2]:0);
			$rowData['staging_zero_influencers']	= $row['respondent_only'];
			$rowData['staging_responses']	= $row['no_of_influencers'];
			$rowData['total']	= $row['no_of_influencers'];
			$rowData['call_plan']	=$row['call_plan'];
			$callPlanPercentage	= ($row['respondents_count']/$row['call_plan']*100);
			if($callPlanPercentage==''){
				$callPlanPercentage	= 0.0;
			}
			$rowData['call_plan_percentage']	= round($callPlanPercentage,2).'%';
			$rowData['title']	= $row['title'];
			$rowData['email']	= $row['email'];
			$rowData['manager_name']	= $row['manager_name'];
			$returnData[]	= $rowData;
		}
		return $returnData;
	}
	function salesReport_old($surveyId=0){
		$query	= "SELECT CONCAT(managers.first_name,' ',managers.last_name) AS manager_name,surveys.name AS survey_name,  CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name, client_users.territory,
					client_users.id as user_id,
					client_users.title,
					client_users.email,
					survey_answers.created_on,
					surveys.id AS survey_id,
					survey_questions.type_id AS type,
					abs(COUNT(survey_answers.nominee_id)) AS no_of_influencers,
					GROUP_CONCAT(survey_questions.type_id) AS qtype
					,(COUNT(DISTINCT survey_answers.respondent_id)) AS respondents_count
					,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district,sales_report_master_data.call_plan
					,COUNT(survey_answers.zeroInfluencers) AS respondent_only";
		$query	.= " FROM survey_answers
					LEFT JOIN surveys ON surveys.id=survey_answers.survey_id
					LEFT JOIN client_users ON client_users.id=survey_answers.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN survey_questions ON survey_questions.id=survey_answers.question_id 
					LEFT JOIN sales_report_master_data ON sales_report_master_data.territory_id=client_users.territory";
		$query	.= " where survey_answers.is_deleted=0";
		if($surveyId>0){
			$query	.= " and survey_answers.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_name,survey_answers.created_by
					ORDER BY user_name,manager_name,survey_name";
		$productionResultSet	= $this->db->query($query);
		
		$query	= "SELECT 
					staging_icontacts.id,
					surveys.name AS survey_name,
					surveys.id AS survey_id,
					survey_questions.type_id AS type,
					staging_icontacts.first_name,staging_icontacts.middle_name,staging_icontacts.last_name,staging_icontacts.organization,staging_icontacts.specialty,staging_icontacts.city,staging_icontacts.state,staging_icontacts.created_on
					, CONCAT(managers.first_name,' ',managers.last_name) AS manager_name, CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name, client_users.territory,client_users.title,
					client_users.email,
					client_users.id as user_id,
					abs(COUNT(staging_icontacts.id)-COUNT(staging_icontacts.zeroInfluencers)) AS no_of_influencers,
					GROUP_CONCAT(survey_questions.type_id) AS qtype
					,abs(COUNT( DISTINCT staging_icontacts.staging_respondent_id) + COUNT(DISTINCT staging_icontacts.survey_respondent_id)-COUNT(staging_icontacts.zeroInfluencers)) AS respondents_count
					,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district,sales_report_master_data.call_plan
					,COUNT(staging_icontacts.zeroInfluencers) AS respondent_only";
		$query	.= " FROM staging_icontacts
					LEFT JOIN client_users ON client_users.id=staging_icontacts.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN surveys ON surveys.id=staging_icontacts.survey_id
					LEFT JOIN survey_questions ON survey_questions.id=staging_icontacts.survey_question_id 
					LEFT JOIN sales_report_master_data ON sales_report_master_data.territory_id=client_users.territory";
		$query	.= " WHERE (staging_icontacts.survey_question_id>0 OR staging_icontacts.zeroInfluencers>0)";
		if($surveyId>0){
			$query	.= " and staging_icontacts.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_name,staging_icontacts.created_by
					ORDER BY user_name,manager_name,survey_name";
		$stagingResultSet	= $this->db->query($query);
		//echo $this->db->last_query();
		$returnData	= array();
		$stagingData	= array();
		foreach($stagingResultSet->result_array() as $row){
			$uniqueId = $row['user_id'].'_'.$row['survey_id'];
			$stagingData[$uniqueId]	= $row;
		}
		foreach($productionResultSet->result_array() as $row){
			$respondentsCount	= 0;
			$stagingInfluencers	= 0;
			$totalInfluencers	= 0;
			$uniqueId = $row['user_id'].'_'.$row['survey_id'];
			$arrStagingCountByTypes = array(1=>0,2=>0);
			$percOfCallPlan	= 0;
			if(isset($stagingData[$uniqueId])){
				$stagingZeroInfluencersCount	= $stagingData[$uniqueId]['respondent_only'];
				$respondentsCount	= ($row['respondents_count']+$stagingData[$uniqueId]['respondents_count']);
				$explodeByType	= explode(',',$stagingData[$uniqueId]['qtype']);
				$arrStagingCountByTypes= array_count_values($explodeByType);
				$arrStagingCountByTypes[1]	= (isset($arrStagingCountByTypes[1])?$arrStagingCountByTypes[1]:0);
				$arrStagingCountByTypes[2]	= (isset($arrStagingCountByTypes[2])?$arrStagingCountByTypes[2]:0);
				$stagingInfluencers	= $stagingData[$uniqueId]['no_of_influencers'];
				$totalInfluencers	= ($row['no_of_influencers']+$stagingData[$uniqueId]['no_of_influencers']);
				unset($stagingData[$uniqueId]);
			}else{
				$respondentsCount	= $row['respondents_count'];
				$totalInfluencers	= $row['no_of_influencers'];
				$stagingZeroInfluencersCount	= 0;
			}
			$explodeByType	= explode(',',$row['qtype']);
			$arrCountByTypes= array_count_values($explodeByType);
			$rowData	= array();
			$rowData['survey_name']	= $row['survey_name'];
			$rowData['region']	= $row['region'];
			$rowData['district']	= $row['district'];
			$rowData['territory_name']	= $row['territory_name'];
			$rowData['territory']	= $row['territory'];
			$rowData['user_name']	= $row['user_name'];
			$rowData['respondents_count']	= $respondentsCount;
			$rowData['prod_local']	= (isset($arrCountByTypes[1])?$arrCountByTypes[1]:0);
			$rowData['prod_national']	= (isset($arrCountByTypes[2])?$arrCountByTypes[2]:0);
			$rowData['prod_zero_influencers']	= $row['respondent_only'];
			$rowData['prod_responses']	= $row['no_of_influencers'];
			$rowData['staging_local']	= $arrStagingCountByTypes[1];
			$rowData['staging_national']	= $arrStagingCountByTypes[2];
			$rowData['staging_zero_influencers']	= $stagingZeroInfluencersCount;
			$rowData['staging_responses']	= $stagingInfluencers;
			$rowData['total']	= $totalInfluencers;
			$rowData['call_plan']	=$row['call_plan'];
			$callPlanPercentage	= ($respondentsCount/$row['call_plan']*100);
			if($callPlanPercentage==''){
				$callPlanPercentage	= 0.0;
			}
			$rowData['call_plan_percentage']	= round($callPlanPercentage,2).'%';
			$rowData['title']	= $row['title'];
			$rowData['email']	= $row['email'];
			$rowData['manager_name']	= $row['manager_name'];
			$returnData[]	= $rowData;
		}
		foreach($stagingData as $key=> $row){
			$explodeByType	= explode(',',$row['qtype']);
			$arrCountByTypes= array_count_values($explodeByType);
			$rowData	= array();
			$rowData['survey_name']	= $row['survey_name'];
			$rowData['region']	= $row['region'];
			$rowData['district']	= $row['district'];
			$rowData['territory_name']	= $row['territory_name'];
			$rowData['territory']	= $row['territory'];
			$rowData['user_name']	= $row['user_name'];
			$rowData['respondents_count']	= $row['respondents_count'];
			$rowData['prod_local']	= 0;
			$rowData['prod_national']	= 0;
			$rowData['prod_zero_influencers']	= 0;
			$rowData['prod_responses']	= 0;
			$rowData['staging_local']	= (isset($arrCountByTypes[1])?$arrCountByTypes[1]:0);
			$rowData['staging_national']	= (isset($arrCountByTypes[2])?$arrCountByTypes[2]:0);
			$rowData['staging_zero_influencers']	= $row['respondent_only'];
			$rowData['staging_responses']	= $row['no_of_influencers'];
			$rowData['total']	= $row['no_of_influencers'];
			$rowData['call_plan']	=$row['call_plan'];
			$callPlanPercentage	= ($row['respondents_count']/$row['call_plan']*100);
			if($callPlanPercentage==''){
				$callPlanPercentage	= 0.0;
			}
			$rowData['call_plan_percentage']	= round($callPlanPercentage,2).'%';
			$rowData['title']	= $row['title'];
			$rowData['email']	= $row['email'];
			$rowData['manager_name']	= $row['manager_name'];
			$returnData[]	= $rowData;
		}
		return $returnData;
	}
	
	function getInfluencerDetails($influencerIds){
		$arrDetails = array();
		$this->db->select('id,kol_id,CONCAT(last_name,", ",first_name," ",middle_name) AS name,city_name as city,state_name as state,postal_code',false);
		$this->db->where_in('kol_id',$influencerIds);
		$this->db->where('present_address',1);
		$resultSet = $this->db->get('additional_contacts');
		foreach($resultSet->result_array() as $row){
			$arrDetails[]=$row;
		}
		return $arrDetails;
	}
	
/*
	 * To get influencers with states
	 * @param $surveyId
	 */
	function nomineesByStateForGrid($surveyId,$arrSelections=array(),$stateName){
		
		$arrData	= array();
		$this->db->select('additional_contacts.full_name AS name,additional_contacts.state_name as state,additional_contacts.city_name as city,additional_contacts.postal_code',false);
		$this->db->where('survey_id',$surveyId);
		$this->db->where_not_in('additional_contacts.state_id','');
		$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('additional_contacts','additional_contacts.id = survey_answers.nom_address_id','left');
		$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								$this->db->where_in('regions.region',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								$this->db->join('cities','cities.cityId=additional_contacts.city_id','left');
								$this->db->where_in('cities.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->join('postal_codes','postal_codes.id=additional_contacts.postal_code_id','left');
								$this->db->where_in('postal_codes.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
			}
		}

		$this->db->group_by('survey_answers.nominee_id');
		$this->db->where('survey_answers.is_deleted','0');
		$this->db->where('regions.region',$stateName);
		//$this->db->order_by('count','desc');
		//$this->db->order_by('regions.region','asc');
		$result = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($result->result_array() as $row){
    		$arrData[]	= $row;
    	}
		return $arrData;
	}

	function respondentByStateForGrid($surveyId,$arrSelections=array(),$stateName){
		$arrData	= array();
		$this->db->select('additional_contacts.full_name AS name,additional_contacts.state_name as state,additional_contacts.city_name as city,additional_contacts.postal_code',false);
		$this->db->where('survey_id',$surveyId);
		$this->db->where_not_in('additional_contacts.state_id','');
		$this->db->join('icontacts','icontacts.id=survey_answers.nominee_id','left');
		$this->db->join('icontacts as survey_repsondents','survey_repsondents.id=survey_answers.respondent_id','left');
		$this->db->join('client_users','client_users.id=survey_answers.created_by','left');
		$this->db->join('additional_contacts','additional_contacts.id = survey_answers.resp_address_id','left');
		$this->db->join('regions','regions.regionId=additional_contacts.state_id','left');
		$this->db->join('additional_contacts as nom_contacts','nom_contacts.id = survey_answers.nom_address_id','left');
		foreach($arrSelections as $key=>$arrSelectedData){
			if(!empty($arrSelectedData))
				switch($key){
					case 'nominee':
							if(isset($arrSelectedData['name']) && $arrSelectedData['name']!=""){
								//$this->db->where_in('survey_kol_names.name',$arrSelectedData['name']);
								$this->db->where_in('survey_answers.nominee_id',$arrSelectedData['name']);
							}
							if(isset($arrSelectedData['type']) && $arrSelectedData['type']!=0){
								$this->db->join('survey_questions','survey_answers.question_id = survey_questions.id','left');
								$this->db->where_in('survey_questions.type_id',$arrSelectedData['type']);
							}
							if(isset($arrSelectedData['country']) && $arrSelectedData['country']!=""){
								$this->db->join('countries','countries.countryId=additional_contacts.country_id','left');
								$this->db->where_in('countries.country',$arrSelectedData['country']);
							}
							if(isset($arrSelectedData['state']) && $arrSelectedData['state']!=""){
								
									$this->db->join('regions as nom_regions','nom_regions.regionId=nom_contacts.state_id','left');
								$this->db->where_in('nom_regions.region',$arrSelectedData['state']);
							}
							if(isset($arrSelectedData['city']) && $arrSelectedData['city']!=""){
								
								$this->db->join('cities as nom_cities','nom_cities.cityId=nom_contacts.city_id','left');
								$this->db->where_in('nom_cities.city',$arrSelectedData['city']);
							}
							if(isset($arrSelectedData['postal']) && $arrSelectedData['postal']!=""){
								$this->db->join('postal_codes as nom_postal','nom_postal.id=nom_contacts.postal_code_id','left');
								$this->db->where_in('nom_postal.postal_code',$arrSelectedData['postal']);
							}
					break;
					case 'respondents':
							if(isset($arrSelectedData['respondent']) && $arrSelectedData['respondent']!=""){
								//$this->db->where_in('survey_repsondents.name',$arrSelectedData['respondent']);
								$this->db->where_in('survey_answers.respondent_id',$arrSelectedData['respondent']);
							}
					break;
					case 'users':
						if(isset($arrSelectedData['user']) && $arrSelectedData['user']!=""){
							$this->db->where_in('CONCAT(client_users.first_name," ",client_users.last_name)',$arrSelectedData['user']);
						}
					break;
			}
		}
		$this->db->where('regions.region',$stateName);
		$this->db->group_by('survey_answers.respondent_id');
		$this->db->where('survey_answers.is_deleted','0');
		$result = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($result->result_array() as $row){
    		$arrData[]	= $row;
    	}
		return $arrData;
	}
	
	function getTopNomineeByRespIds($arrRespIds){
		$this->db->select("survey_answers.id,survey_answers.nominee_id,survey_answers.respondent_id,COUNT(survey_answers.nominee_id) AS nom_count");
		$this->db->where_in("survey_answers.nominee_id",$arrRespIds);
		$this->db->group_by("survey_answers.nominee_id");
		$this->db->order_by("nom_count","desc");
		$arrResult = $this->db->get("survey_answers");
		//pr($this->db->last_query());exit;
		$arrData = array();
		foreach ($arrResult->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}

	function getUserTerritory($userId=0){
		$this->db->select('sales_report_master_data.id,sales_report_master_data.territory_id as territory,sales_report_master_data.territory_name');
		$this->db->join('sales_report_master_data','sales_report_master_data.territory_id=client_users.territory','left');
		$this->db->where('client_users.id',$userId);
		$this->db->limit(1);
		$result = $this->db->get('client_users');
		$row	= $result->result_array();
		return $row[0];
	}
	function hcpCompletionReport($surveyId=0){
		$returnData	= array();
		$arrZeroInfluencers	= array(''=>'',1=>'HCP did not provide influencers',2=>'HCP does not have influencers',99=>'');
		$query	= "SELECT CONCAT(managers.first_name,' ',managers.last_name) AS manager_name,surveys.name AS survey_name,CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name,
					survey_answers.created_on,CONCAT(resp_add_contatcts.first_name,' ',resp_add_contatcts.middle_name,' ',resp_add_contatcts.last_name)AS resp_name,resp_add_contatcts.org_name AS resp_org,
					resp_add_contatcts.specialty as resp_specialty ,resp_add_contatcts.state_name AS resp_state,resp_add_contatcts.city_name AS resp_city,resp_add_contatcts.master_customer_id as resp_mdm_id,
					CASE
					WHEN survey_questions.type_id = 1 THEN 'Local'
					WHEN survey_questions.type_id = 2 THEN 'National'
					WHEN survey_questions.type_id = 3 THEN 'Global'
					END AS influencer_type,
					CONCAT(nom_add_contatcts.first_name,' ',nom_add_contatcts.middle_name,' ',nom_add_contatcts.last_name) AS influencer_name,nom_add_contatcts.org_name AS influencer_org,
					nom_add_contatcts.master_customer_id as nom_mdm_id,
					nom_add_contatcts.specialty as influencer_specialty,nom_add_contatcts.state_name AS influencer_state,nom_add_contatcts.city_name AS influencer_city,survey_answers.zeroInfluencers
					,survey_answers.territory as territory_id,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district 
					,CASE 
					    WHEN (survey_answers.question_id>0)   THEN 'Influencer'
					    ELSE 'Respondent'
					END AS type";
		$query	.= " FROM survey_answers
					LEFT JOIN surveys ON surveys.id=survey_answers.survey_id
					LEFT JOIN client_users ON client_users.id = survey_answers.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN additional_contacts AS nom_add_contatcts ON nom_add_contatcts.id = survey_answers.nom_address_id
					LEFT JOIN additional_contacts AS resp_add_contatcts ON resp_add_contatcts.id = survey_answers.resp_address_id
					LEFT JOIN survey_questions ON survey_questions.id=survey_answers.question_id
					left join sales_report_master_data on sales_report_master_data.id= survey_answers.territory_id ";
		$query	.= " where survey_answers.is_deleted=0 and survey_answers.question_id>0";
		if($surveyId>0){
			$query	.= " and survey_answers.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_answers.created_by,survey_answers.respondent_id,survey_answers.nominee_id ORDER BY manager_name,user_name,survey_name";
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['source']	= 'Production';
			//$row['type']	= 'Influencer';
			$row['zero_influencers']	= $arrZeroInfluencers[$row['zeroInfluencers']];
			$returnData[]	= $row;
		}
	
		$query	= "SELECT CONCAT(managers.first_name,' ',managers.last_name) AS manager_name,surveys.name AS survey_name,CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name,
					survey_answers.created_on,CONCAT(resp_add_contatcts.first_name,' ',resp_add_contatcts.middle_name,' ',resp_add_contatcts.last_name)AS resp_name,resp_add_contatcts.org_name AS resp_org,
					resp_add_contatcts.specialty AS resp_specialty ,resp_add_contatcts.state_name AS resp_state,resp_add_contatcts.city_name AS resp_city,resp_add_contatcts.master_customer_id as resp_mdm_id,
					survey_answers.zeroInfluencers
					,survey_answers.territory as territory_id,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district 
					,CASE 
					    WHEN (survey_answers.question_id>0)   THEN 'Influencer'
					    ELSE 'Respondent'
					END AS type";
		$query	.= " FROM survey_answers
					LEFT JOIN surveys ON surveys.id=survey_answers.survey_id
					LEFT JOIN client_users ON client_users.id = survey_answers.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					LEFT JOIN additional_contacts AS resp_add_contatcts ON resp_add_contatcts.id = survey_answers.resp_address_id
					LEFT JOIN sales_report_master_data ON sales_report_master_data.id= survey_answers.territory_id ";
		$query	.= " where survey_answers.is_deleted=0";
		if($surveyId>0){
			$query	.= " and survey_answers.survey_id=".$surveyId;
		}
		$query	.= " GROUP BY survey_answers.created_by,survey_answers.respondent_id ORDER BY manager_name,user_name,survey_name";
		
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['source']	= 'Production';
			$row['type']	= 'Respondent';
			$row['zero_influencers']	= $arrZeroInfluencers[$row['zeroInfluencers']];
			$returnData[]	= $row;
		}
		
		$query	= "select surveys.name as survey_name, CONCAT(managers.first_name,' ',managers.last_name) AS manager_name, CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name,staging_icontacts.created_on
					,CASE 
					    WHEN (staging_icontacts.survey_question_id>0)   THEN 'Influencer'
					    ELSE 'Respondent'
					END AS type
					, CONCAT(COALESCE(staging_irespondents.first_name,''),' ',COALESCE(staging_irespondents.middle_name,''),' ',COALESCE(staging_irespondents.last_name,'')) AS resp_name,staging_irespondents.organization AS resp_org,staging_irespondents.specialty AS resp_specialty,staging_irespondents.city AS resp_city,staging_irespondents.state AS resp_state
					,staging_irespondents.specialty as resp_specialty, staging_irespondents.mdm_id as resp_mdm_id
					,staging_icontacts.mdm_id as nom_mdm_id
					,CASE
						WHEN survey_questions.type_id = 1 THEN 'Local'
						WHEN survey_questions.type_id = 2 THEN 'National'
						WHEN survey_questions.type_id = 3 THEN 'Global'
					END AS influencer_type
					, concat(COALESCE(staging_icontacts.first_name,''),' ',COALESCE(staging_icontacts.middle_name,''),' ',COALESCE(staging_icontacts.last_name,'')) as influencer_name,staging_icontacts.organization as influencer_organization,staging_icontacts.specialty as influencer_specialty,staging_icontacts.city as influencer_city,staging_icontacts.state as influencer_state
					,staging_icontacts.specialty as influencer_specialty
					,staging_icontacts.territory as territory_id,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district 
					,staging_icontacts.zeroInfluencers";
		$query	.= " FROM staging_icontacts
					left join surveys on surveys.id=staging_icontacts.survey_id
					LEFT JOIN survey_questions ON survey_questions.id=staging_icontacts.survey_question_id
					LEFT JOIN staging_icontacts as staging_irespondents ON staging_irespondents.id=staging_icontacts.staging_respondent_id
					LEFT JOIN client_users ON client_users.id=staging_icontacts.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					left join sales_report_master_data on sales_report_master_data.id=staging_icontacts.territory_id ";
		$query	.= " where staging_icontacts.survey_question_id>0
					and staging_icontacts.staging_respondent_id>0";
		if($surveyId>0){
			$query	.= " and staging_icontacts.survey_id=".$surveyId;
		}
		$query	.= " ORDER BY staging_icontacts.created_on DESC";
		
		$resultSet	= $this->db->query($query);
		//echo "----".$this->db->last_query();
		foreach($resultSet->result_array() as $row){
			$row['source']	= 'Staging';
			$row['zero_influencers']	= $arrZeroInfluencers[$row['zeroInfluencers']];
			$returnData[]	= $row;
		}
	
		$query	= "SELECT surveys.name as survey_name, CONCAT(managers.first_name,' ',managers.last_name) AS manager_name, CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name,staging_icontacts.created_on
					,CASE 
					    WHEN (staging_icontacts.survey_question_id>0)   THEN 'Influencer'
					    ELSE 'Respondent'
					END AS type
					, CONCAT(COALESCE(staging_irespondents.first_name,''),' ',COALESCE(staging_irespondents.middle_name,''),' ',COALESCE(staging_irespondents.last_name,'')) AS resp_name,cities.City AS resp_city,regions.Region AS resp_state
					,staging_irespondents.org_name AS resp_org,staging_irespondents.specialty AS resp_specialty, staging_irespondents.master_customer_id as resp_mdm_id
					,staging_icontacts.mdm_id as nom_mdm_id
					,CASE
						WHEN survey_questions.type_id = 1 THEN 'Local'
						WHEN survey_questions.type_id = 2 THEN 'National'
						WHEN survey_questions.type_id = 3 THEN 'Global'
					END AS influencer_type
					, CONCAT(COALESCE(staging_icontacts.first_name,''),' ',COALESCE(staging_icontacts.middle_name,''),' ',COALESCE(staging_icontacts.last_name,'')) AS influencer_name,staging_icontacts.organization AS influencer_organization,staging_icontacts.specialty AS influencer_specialty,staging_icontacts.city AS influencer_city,staging_icontacts.state AS influencer_state
					,staging_icontacts.territory as territory_id,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district 
					,staging_icontacts.zeroInfluencers";
		$query	.= " FROM staging_icontacts
					LEFT JOIN surveys ON surveys.id=staging_icontacts.survey_id
					LEFT JOIN survey_questions ON survey_questions.id=staging_icontacts.survey_question_id
					LEFT JOIN additional_contacts AS staging_irespondents ON staging_irespondents.id=staging_icontacts.survey_respondent_address_id
					LEFT JOIN additional_contacts ON additional_contacts.id=staging_icontacts.survey_respondent_address_id
					LEFT JOIN cities ON cities.CityId=additional_contacts.city_id
					LEFT JOIN regions ON regions.RegionID=additional_contacts.state_id
					LEFT JOIN client_users ON client_users.id=staging_icontacts.created_by
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id
					left join sales_report_master_data on sales_report_master_data.id=staging_icontacts.territory_id ";
		$query	.= " WHERE staging_icontacts.survey_question_id>0
					AND staging_icontacts.survey_respondent_address_id>0";
		if($surveyId>0){
			$query	.= " and staging_icontacts.survey_id=".$surveyId;
		}
		$query	.= " ORDER BY staging_icontacts.created_on DESC";
		//echo $query;
		$resultSet	= $this->db->query($query);
		foreach($resultSet->result_array() as $row){
			$row['source']	= 'Staging';
			$row['zero_influencers']	= $arrZeroInfluencers[$row['zeroInfluencers']];
			$returnData[]	= $row;
		}
		
		$query	= "SELECT staging_icontacts.* ,CONCAT(managers.first_name,' ',managers.last_name) AS manager_name
					,surveys.name AS survey_name,CONCAT(client_users.first_name,' ',client_users.last_name) AS user_name
					,CASE 
                            WHEN (staging_icontacts.survey_question_id>0)   THEN 'Influencer'
                            ELSE 'Respondent'
                        END AS type
                    ,CASE
						WHEN survey_questions.type_id = 1 THEN 'Local'
						WHEN survey_questions.type_id = 2 THEN 'National'
						WHEN survey_questions.type_id = 3 THEN 'Global'
					END AS influencer_type
					,staging_icontacts.territory as territory_id,sales_report_master_data.territory_name,sales_report_master_data.region,sales_report_master_data.district
					,CONCAT(COALESCE(staging_icontacts.first_name,''),' ',COALESCE(staging_icontacts.middle_name,''),' ',COALESCE(staging_icontacts.last_name,'')) AS resp_name,staging_icontacts.city AS resp_city,staging_icontacts.state AS resp_state,staging_icontacts.organization AS resp_org,staging_icontacts.specialty AS resp_specialty
					,staging_icontacts.mdm_id as resp_mdm_id
					,staging_icontacts.zeroInfluencers";
		$query	.= " FROM staging_icontacts
					LEFT JOIN surveys ON surveys.id=staging_icontacts.survey_id
					LEFT JOIN survey_questions ON survey_questions.id=staging_icontacts.survey_question_id
					LEFT JOIN client_users ON client_users.id=staging_icontacts.created_by
					left join sales_report_master_data on sales_report_master_data.id=staging_icontacts.territory_id
					LEFT JOIN client_users AS managers ON managers.id=client_users.manager_id ";
		$query	.= " WHERE  staging_icontacts.survey_question_id IS NULL";
		if($surveyId>0){
			$query	.= " and staging_icontacts.survey_id=".$surveyId;
		}
		$resultSet	= $this->db->query($query);
		//echo "<br />".$this->db->last_query();
		foreach($resultSet->result_array() as $row){
			$row['source']	= 'Staging';
			//$row['type']	= 'Respondent';
			$row['zero_influencers']	= $arrZeroInfluencers[$row['zeroInfluencers']];
			$returnData[]	= $row;
		}
		return $returnData;
	}
	function getAllTerritoryData(){
		$returnData	= array();
		$resultSet	= $this->db->get('sales_report_master_data');
		foreach($resultSet->result_array() as $row){
			$returnData[$row['id']]	= $row;
		}
		return $returnData;
	}
	
	function salesSummaryReport($surveyId){
		$returnData	= array();
		$uniqueData	= array();
		/*$arrTerritoryDetails	= $this->getAllTerritoryData();
		$this->db->select('sales_report_master_data.region,sales_report_master_data.district,sales_report_master_data.id,sales_report_master_data.territory_name as name');
		//$this->db->select('(SELECT SUM(territory_data.call_plan) FROM sales_report_master_data AS territory_data  WHERE territory_data.territory_id=sales_report_master_data.territory_id group by territory_data.territory_name) AS call_plan,((COUNT(DISTINCT survey_answers.respondent_id)/(SELECT SUM(territory_data.call_plan) FROM sales_report_master_data AS territory_data  WHERE territory_data.territory_id=sales_report_master_data.territory_id))*100) as completed');
		$this->db->select('GROUP_CONCAT(DISTINCT sales_report_master_data.id) as territory_ids');
		$this->db->select('COUNT(DISTINCT survey_answers.respondent_id) AS respondent_count');
		$this->db->join('sales_report_master_data','sales_report_master_data.id=survey_answers.territory_id','left');
		$this->db->where('survey_answers.survey_id',$surveyId);
		$this->db->where('survey_answers.is_deleted',0);
		$this->db->where('sales_report_master_data.id>',0,false);
		$this->db->group_by('sales_report_master_data.territory_name');
		//$this->db->order_by('completed','desc');
		$resultSet	= $this->db->get('survey_answers');
		//echo $this->db->last_query();
		$arrDistrict	= array();
		$arrRegion	= array();
		$arrTerritory	= array();
		foreach($resultSet->result_array() as $row){
			$arrTids	= explode(',',$row['territory_ids']);
			$noOfTerritories	= sizeof($arrTids);
			$callPlan	= 0;
			foreach($arrTids as $key=>$id){
				$callPlan	+= $arrTerritoryDetails[$id]['call_plan'];
			}
			$row['call_plan']	= $callPlan/$noOfTerritories;
			$row['completed']	= round(($row['respondent_count']/$row['call_plan']*100),2);
			$arrTerritory[$row['id']]['name']	= $row['name'];
			$arrTerritory[$row['id']]['respondent_count']	= $row['respondent_count'];
			$arrTerritory[$row['id']]['call_plan']	= $row['call_plan'];
			$arrTerritory[$row['id']]['completed']	= $row['completed'];
			if(!isset($arrRegion[$row['region']])){
				$arrRegion[$row['region']]['name']	= $row['region'];
				$arrRegion[$row['region']]['respondent_count']	= $row['respondent_count'];
				$arrRegion[$row['region']]['call_plan']	= $row['call_plan'];
				$arrRegion[$row['region']]['completed']	= $row['completed'];
				//$arrRegion[$row['region']]['no_of_territories']	= 1;
			}else{
				$arrRegion[$row['region']]['respondent_count']	+= $row['respondent_count'];
				$arrRegion[$row['region']]['call_plan']	+= $row['call_plan'];
				$arrRegion[$row['region']]['completed']	+= $row['completed'];
				//$arrRegion[$row['region']]['no_of_territories']	+= 1;
			}
			if(!isset($arrDistrict[$row['district']])){
				$arrDistrict[$row['district']]['name']	= $row['district'];
				$arrDistrict[$row['district']]['respondent_count']	= $row['respondent_count'];
				$arrDistrict[$row['district']]['call_plan']	= $row['call_plan'];
				$arrDistrict[$row['district']]['completed']	= $row['completed'];
				//$arrDistrict[$row['district']]['no_of_territories']	= 1;
			}else{
				$arrDistrict[$row['district']]['respondent_count']	+= $row['respondent_count'];
				$arrDistrict[$row['district']]['call_plan']	+= $row['call_plan'];
				$arrDistrict[$row['district']]['completed']	+= $row['completed'];
				//$arrDistrict[$row['district']]['no_of_territories']	+= 1;
			}
		}
		foreach($arrRegion as $key=>$row){
			$arrRegion[$key]['completed']	= round(($row['respondent_count']/$row['call_plan'])*100,2);
		}
		foreach($arrDistrict as $key=>$row){
			$arrDistrict[$key]['completed']	= round(($row['respondent_count']/$row['call_plan'])*100,2);
		}*/
		$uniqueData	= $this->salesReport($surveyId);
		$arrRegion	= array();
		$arrDistrict	= array();
		$arrTerritory	= array();
		foreach($uniqueData as $key=>$row){
			if(!empty($row['territory_name'])){
				$row['call_plan_percentage']	= str_replace('%','',$row['call_plan_percentage']);
				if(!isset($arrTerritory[$row['territory_name']])){
					$arrTerritory[$row['territory_name']]['district']	= $row['district'];
					$arrTerritory[$row['territory_name']]['region']	= $row['region'];
					$arrTerritory[$row['territory_name']]['name']	= $row['territory_name'];
					$arrTerritory[$row['territory_name']]['respondent_count']	= $row['respondents_count'];
					$arrTerritory[$row['territory_name']]['call_plan']	= $row['call_plan'];
					$arrTerritory[$row['territory_name']]['completed']	= $row['call_plan_percentage'];
					$arrTerritory[$row['territory_name']]['repeats']	= 1;
				}else{
					$arrTerritory[$row['territory_name']]['respondent_count']	+= $row['respondents_count'];
					$arrTerritory[$row['territory_name']]['call_plan']	+= $row['call_plan'];
					$arrTerritory[$row['territory_name']]['completed']	+= $row['call_plan_percentage'];
					$arrTerritory[$row['territory_name']]['repeats']	+= 1;
				}
				/*if(!isset($arrRegion[$row['region']])){
					$arrRegion[$row['region']]['name']	= $row['region'];
					$arrRegion[$row['region']]['respondent_count']	= $row['respondents_count'];
					$arrRegion[$row['region']]['call_plan']	= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	= $row['call_plan_percentage'];
					//$arrRegion[$row['region']]['no_of_territories']	= 1;
				}else{
					$arrRegion[$row['region']]['respondent_count']	+= $row['respondents_count'];
					$arrRegion[$row['region']]['call_plan']	+= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	+= $row['call_plan_percentage'];
					//$arrRegion[$row['region']]['no_of_territories']	+= 1;
				}
				if(!isset($arrDistrict[$row['district']])){
					$arrDistrict[$row['district']]['name']	= $row['district'];
					$arrDistrict[$row['district']]['respondent_count']	= $row['respondents_count'];
					$arrDistrict[$row['district']]['call_plan']	= $row['call_plan'];
					$arrDistrict[$row['district']]['completed']	= $row['call_plan_percentage'];
					//$arrDistrict[$row['district']]['no_of_territories']	= 1;
				}else{
					$arrDistrict[$row['district']]['respondent_count']	+= $row['respondents_count'];
					$arrDistrict[$row['district']]['call_plan']	+= $row['call_plan'];
					$arrDistrict[$row['district']]['completed']	+= $row['call_plan_percentage'];
					//$arrDistrict[$row['district']]['no_of_territories']	+= 1;
				}*/
			}
		}
		foreach($arrTerritory as $key=>$row){
			$arrTerritory[$key]['call_plan']	= round($row['call_plan']/$row['repeats']);
			if(!isset($arrDistrict[$row['district']])){
				$arrDistrict[$row['district']]['region']	= $row['region'];
				$arrDistrict[$row['district']]['name']	= $row['district'];
				$arrDistrict[$row['district']]['respondent_count']	= $row['respondent_count'];
				$arrDistrict[$row['district']]['call_plan']	= $arrTerritory[$key]['call_plan'];
				$arrDistrict[$row['district']]['completed']	= $row['call_plan_percentage'];
				//$arrDistrict[$row['district']]['no_of_territories']	= 1;
			}else{
				$arrDistrict[$row['district']]['respondent_count']	+= $row['respondent_count'];
				$arrDistrict[$row['district']]['call_plan']	+= $arrTerritory[$key]['call_plan'];
				$arrDistrict[$row['district']]['completed']	+= $row['call_plan_percentage'];
				//$arrDistrict[$row['district']]['no_of_territories']	+= 1;
			}
		}
		/*foreach($uniqueData as $key=>$row){
			if(!empty($row['territory_name'])){
				$row['call_plan_percentage']	= str_replace('%','',$row['call_plan_percentage']);
				$row['call_plan']	= $arrTerritory[$row['territory_name']]['call_plan'];
				if(!isset($arrRegion[$row['region']])){
					$arrRegion[$row['region']]['name']	= $row['region'];
					$arrRegion[$row['region']]['respondent_count']	= $row['respondents_count'];
					$arrRegion[$row['region']]['call_plan']	= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	= $row['call_plan_percentage'];
					//$arrRegion[$row['region']]['no_of_territories']	= 1;
				}else{
					$arrRegion[$row['region']]['respondent_count']	+= $row['respondents_count'];
					$arrRegion[$row['region']]['call_plan']	+= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	+= $row['call_plan_percentage'];
					//$arrRegion[$row['region']]['no_of_territories']	+= 1;
				}
				
			}
		}*/
		foreach($arrDistrict as $key=>$row){
			$arrDistrict[$key]['completed']	= round(($row['respondent_count']/$row['call_plan'])*100,2);
			if(!isset($arrRegion[$row['region']])){
					$arrRegion[$row['region']]['name']	= $row['region'];
					$arrRegion[$row['region']]['respondent_count']	= $row['respondent_count'];
					$arrRegion[$row['region']]['call_plan']	= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	= $arrDistrict[$key]['completed'];
					//$arrRegion[$row['region']]['no_of_territories']	= 1;
				}else{
					$arrRegion[$row['region']]['respondent_count']	+= $row['respondent_count'];
					$arrRegion[$row['region']]['call_plan']	+= $row['call_plan'];
					$arrRegion[$row['region']]['completed']	+= $arrDistrict[$key]['completed'];
					//$arrRegion[$row['region']]['no_of_territories']	+= 1;
				}
		}
		/*foreach($arrTerritory as $key=>$row){
			$arrTerritory[$key]['call_plan']	= round($row['call_plan']/$row['repeats']);
			if(!isset($arrRegion[$row['region']])){
				$arrRegion[$row['region']]['name']	= $row['region'];
				$arrRegion[$row['region']]['respondent_count']	= $row['respondent_count'];
				$arrRegion[$row['region']]['call_plan']	= $arrTerritory[$key]['call_plan'];
				$arrRegion[$row['region']]['completed']	= $row['call_plan_percentage'];
			}else{
				$arrRegion[$row['region']]['respondent_count']	+= $row['respondent_count'];
				$arrRegion[$row['region']]['call_plan']	+= $arrTerritory[$key]['call_plan'];
				$arrRegion[$row['region']]['completed']	+= $row['call_plan_percentage'];
			}
		}*/
		foreach($arrRegion as $key=>$row){
			$arrRegion[$key]['completed']	= round(($row['respondent_count']/$row['call_plan'])*100,2);
		}
		usort($arrTerritory,array($this,'usort_callback_salesreport'));
		usort($arrDistrict,array($this,'usort_callback_salesreport'));
		usort($arrRegion,array($this,'usort_callback_salesreport'));
		//usort($arrTerritory,function($a,$b){return $a['completed']-$b['completed'];});
		//usort($arrDistrict,function($a,$b){return $a['completed']-$b['completed'];});
		//usort($arrRegion,function($a,$b){return $a['completed']-$b['completed'];});
		//pr($arrTerritory);
		$returnData['territory']= array_values($arrTerritory);
		$returnData['district']	= array_values($arrDistrict);
		$returnData['region']	= array_values($arrRegion);
		return $returnData;
	}
	function usort_callback_salesreport($arrA,$arrB){
		return $arrA['completed']-$arrB['completed'];
	}
	
	function getSurveyAnserById($id){
		$this->db->where('id',$id);
		$result = $this->db->get('survey_answers');
		foreach ($result->result_array() as $row){
			$arrRow = $row;
		}
		return $arrRow;
	}
	
	function excelEsportQuery($arrIds,$type){
		$this->db->select('CASE
							WHEN survey_questions.type_id = 1 THEN "Local"
							WHEN survey_questions.type_id = 2 THEN "National"
							WHEN survey_questions.type_id = 3 THEN "Global"
							END AS type',false);
		$this->db->select("additional_contacts.full_name,additional_contacts.city_name,additional_contacts.state_name,additional_contacts.postal_code,additional_contacts.master_customer_id");
		$this->db->where_in('survey_answers.id',$arrIds);
		$this->db->join("survey_questions","survey_questions.id=survey_answers.question_id","left");
		if($type == 1){
			$this->db->join("additional_contacts","additional_contacts.id = survey_answers.nom_address_id","left");
		}else if($type == 2){
			$this->db->join("additional_contacts","additional_contacts.id = survey_answers.resp_address_id","left");
		}else if($type == 3){
			$this->db->join("additional_contacts","additional_contacts.id = survey_answers.resp_address_id","left");
		}
		$result = $this->db->get('survey_answers');
//		echo $this->db->last_query();
//		exit;
		$arrData = array();
		foreach ($result->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function insertFromStagingToProduction($arrRow){
		$return	= 'Error';
		$this->db->select('survey_id');
		if(isset($arrRow['influencer_id']) && $arrRow['influencer_id']>0){
			$this->db->where('survey_answers.nominee_id',$arrRow['influencer_id']);
			$this->db->where('survey_answers.nom_address_id',$arrRow['influencer_address_id']);
			$this->db->where('survey_answers.question_id',$arrRow['survey_question_id']);
		}
		$this->db->where('survey_answers.created_by',$arrRow['created_by']);
		$this->db->where('survey_answers.respondent_id',$arrRow['resp_id']);
		$this->db->where('survey_answers.resp_address_id',$arrRow['resp_address_id']);
		$this->db->where('survey_answers.survey_id',$arrRow['survey_id']);
		$this->db->where('survey_answers.is_deleted','0');
		$this->db->limit(1);
    	$result = $this->db->get('survey_answers');
    	//echo $this->db->last_query().'-'.$result->num_rows().'<br />';
    	if($result->num_rows()>0){
    		$return	= 'No';
    	}else{
    		$return	= 'Partial';
    		//Insert to production and Delete from Staging table
    		$newInfluencersData	 = array();
    		$newInfluencersData['survey_id']	= $arrRow['survey_id'];
    		$newInfluencersData['nominee_id']	= $arrRow['influencer_id'];
    		$newInfluencersData['nom_address_id']	= $arrRow['influencer_address_id'];
    		$newInfluencersData['question_id']	= $arrRow['survey_question_id'];
    		$newInfluencersData['respondent_id']	= $arrRow['resp_id'];
    		$newInfluencersData['resp_address_id']	= $arrRow['resp_address_id'];
    		$newInfluencersData['created_by']	= $arrRow['created_by'];
    		$newInfluencersData['created_on']	= $arrRow['created_on'];
    		$newInfluencersData['territory_id']	= $arrRow['territory_id'];
    		$newInfluencersData['territory']	= $arrRow['territory'];
    		$newInfluencersData['zeroInfluencers']	= $arrRow['zeroInfluencers'];
    		$newInfluencersData['is_submitted']	= 99; // to indicate pushed from staging table
    		if($this->db->insert('survey_answers',$newInfluencersData) && $arrRow['id']>0){
	    		$this->db->where('staging_icontacts.id',$arrRow['id']);
	    		$this->db->delete('staging_icontacts');
	    		$return	= 'Yes';
    		}
    	}
		return $return;
	}
	function moveStagingToProduction($createdBy=0){
		$arrData = array();
		$this->db->select('surveys.name as survey_name,CONCAT(client_users.first_name," ",client_users.last_name) AS user_name,staging_icontacts.id,staging_icontacts.survey_id,staging_icontacts.survey_question_id,staging_icontacts.created_by,staging_icontacts.created_on
						,staging_icontacts.survey_respondent_id AS resp_id,staging_icontacts.survey_respondent_address_id AS resp_address_id
						,respondents_contacts.master_customer_id AS resp_mdm
						,staging_icontacts.mdm_id AS influencer_mdm_id
						,influencers_contacts.master_customer_id AS influencer_mdm
						,influencers_contacts.kol_id AS influencer_id,influencers_contacts.id AS influencer_address_id
						,staging_icontacts.territory,staging_icontacts.territory_id',false);
		$this->db->select('CASE
							WHEN survey_questions.type_id = 1 THEN "Local"
							WHEN survey_questions.type_id = 2 THEN "National"
							WHEN survey_questions.type_id = 3 THEN "Global"
							END AS type',false);
		$this->db->select("CONCAT(COALESCE(influencers_contacts.first_name,''),' ',COALESCE(influencers_contacts.middle_name,''),' ',COALESCE(influencers_contacts.last_name,'')) AS influencer_name",false);
		$this->db->select("CONCAT(COALESCE(respondents_contacts.first_name,''),' ',COALESCE(respondents_contacts.middle_name,''),' ',COALESCE(respondents_contacts.last_name,'')) AS respondent_name",false);
		$this->db->join("surveys","surveys.id=staging_icontacts.survey_id","left");
		$this->db->join("client_users","client_users.id=staging_icontacts.created_by","left");
		$this->db->join("survey_questions","survey_questions.id=staging_icontacts.survey_question_id","left");
		$this->db->join("additional_contacts AS influencers_contacts","influencers_contacts.master_customer_id=staging_icontacts.mdm_id","left");
		$this->db->join("additional_contacts AS respondents_contacts","respondents_contacts.id=staging_icontacts.survey_respondent_address_id","left");
		$this->db->where('staging_icontacts.survey_respondent_id >',0,false);
		$this->db->where('staging_icontacts.mdm_id IS NOT ','NULL',false);
		$this->db->like('staging_icontacts.mdm_id','m');
		$this->db->where('influencers_contacts.present_address',1);
		$this->db->where('respondents_contacts.present_address',1);
		if($createdBy>0){
			$this->db->where('staging_icontacts.created_by',$createdBy);
		}
		$result = $this->db->get('staging_icontacts');
//echo $this->db->last_query();
		foreach ($result->result_array() as $row){
			$row['zeroInfluencers']	= '';
			$row['updated']	= $this->insertFromStagingToProduction($row);
			$arrData[] = $row;
		}
		
		$this->db->select('surveys.name as survey_name,CONCAT(client_users.first_name," ",client_users.last_name) AS user_name,staging_icontacts.id,staging_icontacts.survey_id,staging_icontacts.survey_question_id,staging_icontacts.created_by,staging_icontacts.created_on
						,respondents_contacts.kol_id AS resp_id,respondents_contacts.id AS resp_address_id
						,staging_respondents.mdm_id AS resp_mdm_id
						,respondents_contacts.master_customer_id AS resp_mdm
						,staging_icontacts.mdm_id AS influencer_mdm_id
						,influencers_contacts.master_customer_id AS influencer_mdm
						,influencers_contacts.kol_id AS influencer_id,influencers_contacts.id AS influencer_address_id
						,staging_icontacts.territory,staging_icontacts.territory_id',false);
		$this->db->select('CASE
							WHEN survey_questions.type_id = 1 THEN "Local"
							WHEN survey_questions.type_id = 2 THEN "National"
							WHEN survey_questions.type_id = 3 THEN "Global"
							END AS type',false);
		$this->db->select("CONCAT(COALESCE(respondents_contacts.first_name,''),' ',COALESCE(respondents_contacts.middle_name,''),' ',COALESCE(respondents_contacts.last_name,'')) AS respondent_name",false);
		$this->db->select("CONCAT(COALESCE(influencers_contacts.first_name,''),' ',COALESCE(influencers_contacts.middle_name,''),' ',COALESCE(influencers_contacts.last_name,'')) AS influencer_name",false);
		$this->db->join("surveys","surveys.id=staging_icontacts.survey_id","left");
		$this->db->join("client_users","client_users.id=staging_icontacts.created_by","left");
		$this->db->join("survey_questions","survey_questions.id=staging_icontacts.survey_question_id","left");
		$this->db->join("additional_contacts AS influencers_contacts","influencers_contacts.master_customer_id=staging_icontacts.mdm_id","left");
		$this->db->join("staging_icontacts AS staging_respondents","staging_respondents.id=staging_icontacts.staging_respondent_id","left");
		$this->db->join("additional_contacts AS respondents_contacts","respondents_contacts.master_customer_id=staging_respondents.mdm_id","left");
		$this->db->where('staging_icontacts.staging_respondent_id >',0,false);
		$this->db->where('staging_icontacts.mdm_id IS NOT ','NULL',false);
		$this->db->like('staging_icontacts.mdm_id','m');
		$this->db->where('influencers_contacts.present_address',1);
		$this->db->where('respondents_contacts.present_address',1);
		if($createdBy>0){
			$this->db->where('staging_icontacts.created_by',$createdBy);
		}
		$result = $this->db->get('staging_icontacts');
		//echo $this->db->last_query();
		foreach ($result->result_array() as $row){
			$row['zeroInfluencers']	= '';
			$row['updated']	= $this->insertFromStagingToProduction($row);
			$arrData[] = $row;
		}
		
		$this->db->select('surveys.name as survey_name,CONCAT(client_users.first_name," ",client_users.last_name) AS user_name,staging_icontacts.id,staging_icontacts.survey_id,staging_icontacts.survey_question_id,staging_icontacts.created_by,staging_icontacts.created_on
						,respondents_contacts.kol_id AS resp_id,respondents_contacts.id AS resp_address_id
						,staging_icontacts.mdm_id AS resp_mdm_id
						,respondents_contacts.master_customer_id AS resp_mdm
						,staging_icontacts.zeroInfluencers
						,staging_icontacts.mdm_id AS influencer_mdm_id
						,staging_icontacts.territory,staging_icontacts.territory_id',false);
		$this->db->select('CASE
							WHEN survey_questions.type_id = 1 THEN "Local"
							WHEN survey_questions.type_id = 2 THEN "National"
							WHEN survey_questions.type_id = 3 THEN "Global"
							END AS type',false);
		$this->db->select("CONCAT(COALESCE(respondents_contacts.first_name,''),' ',COALESCE(respondents_contacts.middle_name,''),' ',COALESCE(respondents_contacts.last_name,'')) AS respondent_name",false);
		$this->db->join("surveys","surveys.id=staging_icontacts.survey_id","left");
		$this->db->join("client_users","client_users.id=staging_icontacts.created_by","left");
		$this->db->join("survey_questions","survey_questions.id=staging_icontacts.survey_question_id","left");
		$this->db->join("additional_contacts AS respondents_contacts","respondents_contacts.master_customer_id=staging_icontacts.mdm_id","left");
		$this->db->where('staging_icontacts.zeroInfluencers >',0,false);
		$this->db->where('staging_icontacts.mdm_id IS NOT ','NULL',false);
		$this->db->like('staging_icontacts.mdm_id','m');
		$this->db->where('respondents_contacts.present_address',1);
		if($createdBy>0){
			$this->db->where('staging_icontacts.created_by',$createdBy);
		}
		$result = $this->db->get('staging_icontacts');
		//echo $this->db->last_query();
		foreach ($result->result_array() as $row){
			$row['updated']	= $this->insertFromStagingToProduction($row);
			if(!isset($row['influencer_id'])){
				$row['influencer_id']	= '';
			}
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function getNPIByAddressId($addressId){
		$npi='';
		$this->db->where('id',$addressId);
		$this->db->select('npi');
		$result=$this->db->get('additional_contacts');
		$data=$result->row();
		if($data!=null)
			$npi=$data->npi;
			
		//echo $this->db->last_query();
		return $npi;
	}
	
	function getIcontactByNpiNumOrByName($arrKol){
		if($arrKol["mdm_id"] != ''){
//			echo "1---";
			$this->db->where("master_customer_id",$arrKol["mdm_id"]);
			$this->db->where("present_address",1);
			$arrRes = $this->db->get("additional_contacts");
			if($arrRes->num_rows() == 1){
				$arrData = array();
				foreach ($arrRes->result_array() as $row){
					$arrData = $row;
				}
				return $arrData;
			}else{
				$this->searchByNpi($arrKol);
			}
		}else{
			$this->searchByNpi($arrKol);
		}
	}
	
	function searchByNpi($arrKol){
		if($arrKol["mdm_id"] != ''){
			$this->db->where("first_name",$arrKol["first_name"]);
			$this->db->where("last_name",$arrKol["last_name"]);
			$this->db->where("present_address",1);
			$arrRes = $this->db->get("additional_contacts");
			$arrData = array();
			if($arrRes->num_rows() == 1){
				foreach ($arrRes->result_array() as $row){
					$arrData = $row;
				}
				return $arrData;
			}else{
				$this->searchByName($arrKol);
			} 
		}else{
			$this->searchByName($arrKol);
		}
	}
	function searchByName($arrKol){
		$arrData = false;
		if($arrKol["first_name"] != '')
			$this->db->where("first_name",$arrKol["first_name"]);
		if($arrKol["last_name"] != '')
			$this->db->where("last_name",$arrKol["last_name"]);
		$this->db->where("present_address",1);
		$arrRes = $this->db->get("additional_contacts");
		if($arrRes->num_rows() == 1){
			foreach ($arrRes->result_array() as $row){
				$arrData = $row;
			}
		}
		return $arrData;
	}
	
	function getRespondentsById($id){
		$this->db->select("id AS resp_address_id,master_customer_id AS mdm,kol_id as id,full_name AS respondent, country_name AS respondent_country, state_name AS respondent_state,
		city_name AS respondent_city,postal_code AS respondent_postal,");
		$this->db->where("id",$id);
		$result = $this->db->get("additional_contacts");
		foreach ($result->result_array() as $row){
			$arrData = $row;
		}
		return $arrData;
	}
	
	function getOrgNameByOrgId($orgId){
		if($orgId > 0){
			$this->db->select('name');
			$this->db->where('id',$orgId);
			$result = $this->db->get('organizations');
			foreach ($result->result_array() as $row){
				$orgName = $row['name'];  
			}
			return $orgName;
		}else{
			return "";
		}
		
	}
	
//	specialty
	function getSpecialtyById($speId){
		if($speId > 0){
			$this->db->select('specialty');
			$this->db->where('id',$speId);
			$result = $this->db->get('specialties');
			foreach ($result->result_array() as $row){
				$specName = $row['specialty'];  
			}
			return $specName;
		}else{
			return '';
		}
	}
	
	function getCountryNameById($countryId){
		if($countryId > 0){
			$this->db->select('Country');
			$this->db->where('CountryID',$countryId);
			$result = $this->db->get('countries');
			foreach ($result->result_array() as $row){
				$countryName = $row['Country'];  
			}
			return $countryName;
		}else{
			return '';
		}
	}
	
	function getStateNameById($stateId){
		if($stateId > 0){
			$this->db->select('Region');
			$this->db->where('RegionId',$stateId);
			$result = $this->db->get('regions');
//			echo $this->db->last_query();
			foreach ($result->result_array() as $row){
				$stateName = $row['Region'];  
			}
			return $stateName;
		}else{
			return '';
		}
	}
	
	function getCityNameById($cityId){
		if($cityId > 0){
			$this->db->select('City');
			$this->db->where('CityId',$cityId);
			$result = $this->db->get('cities');
			foreach ($result->result_array() as $row){
				$cityName = $row['City'];  
			}
			return $cityName;
		}else{
			return '';
		}
	}
	
	function getIcontactDetailsById($id){
		$this->db->select("master_customer_id as mdm_id,first_name,middle_name,last_name,org_name as organization,specialty,country_name as country,state_name as state,city_name as city,postal_code");
		$this->db->where('id',$id);
		$result = $this->db->get('additional_contacts');
		$arrData = array();
		foreach ($result->result_array() as $row){
			$arrData = $row;
		}
		return $arrData;
	}
	
	function getMDMByAddressId($addressId){
		$mdm='';
		$this->db->where('id',$addressId);
		$this->db->select('master_customer_id');
		$result=$this->db->get('additional_contacts');
		$data=$result->row();
		if($data!=null)
			$mdm=$data->master_customer_id;
			
		//echo $this->db->last_query();
		return $mdm;
	}
	
	function getNomineeId($kolId){
			$this->db->select('id');
			$this->db->where('kol_id',$kolId);
			$arresultSet=$this->db->get('survey_kol_names');
			if($arresultSet->num_rows()==0){
				//$this->db->insert('survey_kol_names',$arryOfDetails);
				return false;
			}else{
				$detail = $arresultSet->result_array();
				return $detail[0]['id'];
			}
		}
	
	function getKolDetailsForSurvey($kolId){
		$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kols');
		//$this->db->select("kols.first_name,kols.middle_name,kols.last_name,kols.country_id,kols.state_id,kols.city_id,kols.postal_code,countries.country,regions.region as state,cities.city,specialties.specialty as specialty_name,organizations.name as org_name");
		$this->db->select(array('concat('.$nameFormatOrder.') as full_name', 'kols.id','kols.first_name','kols.middle_name','kols.last_name','kols.country_id','kols.state_id','kols.city_id','kols.postal_code','countries.country','regions.region as state','cities.city','specialties.specialty as specialty_name','organizations.name as org_name'));
		$this->db->join("countries","CountryId = country_id",left);
		$this->db->join("regions","regions.RegionId = kols.state_id",left);
		$this->db->join("cities","cities.cityId = kols.city_id",left);
		$this->db->join("specialties","specialties.id = kols.specialty",left);
		$this->db->join("kol_locations","kols.id = kol_locations.kol_id",left);
		$this->db->join("organizations","organizations.id = kol_locations.org_institution_id",left);
		if($kolId != ''){
			$this->db->where("kols.id",$kolId);
			$this->db->limit(1,0);
		}
		$this->db->where("kol_locations.is_primary","1");
		$result = $this->db->get("kols");
		//pr($this->db->last_query());exit;
		$result = $result->result_array();
		return $result;
	}
	
	function getKolDetailsFromMasterTable(){
		$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
		$this->db->select(array('concat('.$nameFormatOrder.') as full_name', 'kol_names_for_survey.first_name','kol_names_for_survey.middle_name','kol_names_for_survey.last_name','kol_names_for_survey.country','kol_names_for_survey.state','kol_names_for_survey.city','kol_names_for_survey.postal_code','kol_names_for_survey.speciality as specialty_name','kol_names_for_survey.organization as org_name'));
		$result = $this->db->get("kol_names_for_survey");
		$result = $result->result_array();
		return $result;
	}
	
	function saveMissingContact($respodentData){
		$this->db->select('id');
		$this->db->where('first_name',$respodentData['first_name']);
		$this->db->where('last_name',$respodentData['last_name']);
		$this->db->where('state',$respodentData['state']);
		$this->db->where('city',$respodentData['city']);
		$result = $this->db->get('kol_names_for_survey');
		$result = $result->result_array();
		$returnId = $result[0]['id'];
		
		if($returnId > 0){
			$this->db->where('id',$returnId);
			if($this->db->update('kol_names_for_survey',$respodentData)){
				$returnData['id']		= $returnId;
				$returnData['status']	= 'success';
			}else{
				$returnData['status']	= 'fail';
			}
		}else{
			if($this->db->insert('kol_names_for_survey',$respodentData)){
				 $returnData['id']		= $this->db->insert_id();
				 $returnData['status']	= 'success';
			 }else{
			 	$returnData['status']	= 'fail';
			 }
		}
		if($returnData['status'] == 'success'){
			$returnData['formattedName'] = $this->common_helpers->get_name_format($respodentData['first_name'],$respodentData['middle_name'],$respodentData['last_name']);
			$returnData['city'] = $respodentData['city'];
			$returnData['state'] = $respodentData['state'];
			$returnData['country'] = $respodentData['country'];
			$returnData['postal_code'] = $respodentData['postal_code'];
		}
		return $returnData;
	}
	
	function saveKolsToMasterTable($arrKolData){
		$this->db->select('id');
		$this->db->where('first_name',$arrKolData['first_name']);
		$this->db->where('middle_name',$arrKolData['middle_name']);
		$this->db->where('last_name',$arrKolData['last_name']);
		$this->db->where('country',$arrKolData['country']);
		$this->db->where('state',$arrKolData['state']);
		$this->db->where('city',$arrKolData['city']);
		$this->db->where('postal_code',$arrKolData['postal_code']);
		$this->db->where('speciality',$arrKolData['speciality']);
		$this->db->where('organization',$arrKolData['organization']);
		$result = $this->db->get('kol_names_for_survey');
		$result = $result->result_array();
		$returnId = $result[0]['id'];
		
		if($returnId > 0){
			$returnData['id']	= $returnId;
			$returnData['status']	= 'success';
		}else{
			if($this->db->insert('kol_names_for_survey',$arrKolData)){
				$returnData['id']		= $this->db->insert_id();
				//$this->db->select("CONCAT(COALESCE(influencers_contacts.first_name,''),' ',COALESCE(influencers_contacts.middle_name,''),' ',COALESCE(influencers_contacts.last_name,'')) AS influencer_name",false);
				$this->db->select("concat(COALESCE(last_name,''),' ', COALESCE(first_name,''),' ', COALESCE(middle_name,'')) as search_name",false);
				$this->db->where("id",$returnData['id']);
				$result = $this->db->get("kol_names_for_survey");
				$result = $result->result_array();
				
				$data = array(
						'search_name' => $result[0]['search_name']
				);
				
				$this->db->where('id', $returnData['id']);
				$this->db->update('kol_names_for_survey', $data);
				$this->storeLatitudeLongitudeForSurveyKols($returnData['id']);
				$returnData['status']	= 'success';
			}else{
				$returnData['status']	= 'fail';
			}
		}
		return $returnData;
	}
	
	function insertSurveyAnswers($preparedStatements){
		$query = $this->db->query($preparedStatements);
		if($query){
			return true;
		}else{
			return false;
		}
	}
	
	function deleteInfluencer($survey_answer_id, $created_by){
		$this->db->where('id', $survey_answer_id);
		$this->db->where('created_by', $created_by);
		$query = $this->db->delete('survey_answers');
		if($query){
			return 'success';
		}else{
			return 'failure'; 
		}
	}
	
	function loadSurveySummaryDetails($arrData,$arrSelections){
		
		if($arrData['participant'] == 'respondents'){
			$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
			$this->db->select(array('count(survey_answers.respondent_id) as count','concat('.$nameFormatOrder.') as name','kol_names_for_survey.city','kol_names_for_survey.state','kol_names_for_survey.postal_code','kol_names_for_survey.source_table','kol_names_for_survey.source_table_id as kolId','survey_answers.respondent_id as id'));
			$this->db->join("kol_names_for_survey","kol_names_for_survey.id = survey_answers.respondent_id",left);
			
			$arrData['respondent_id'] = array_diff($arrData['respondent_ids'], array('All Respondents'));
			foreach($arrData['respondent_id'] as $key=>$row){
				$this->db->or_where("kol_names_for_survey.id",$row);
			} 
			
			if($arrSelections['nominee']['type'] != ''){
				$this->db->join("survey_questions","survey_questions.id = survey_answers.question_id",left);
				$this->db->where("survey_questions.type_id",$arrSelections['nominee']['type']);
			}
			
			$this->db->where("survey_answers.survey_id",$arrData['survey_id']);
			$this->db->group_by("survey_answers.respondent_id");
			$this->db->order_by('count','desc');
			$result = $this->db->get("survey_answers");
			$result = $result->result_array();
			//pr($this->db->last_query());exit;
			return $result;
		}
		if($arrData['participant'] == 'influencers'){
			
			$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
			$this->db->select(array('count(survey_answers.nominee_id) as count','concat('.$nameFormatOrder.') as name','kol_names_for_survey.city','kol_names_for_survey.state','kol_names_for_survey.postal_code','kol_names_for_survey.source_table','kol_names_for_survey.source_table_id as kolId','survey_answers.respondent_id as id'));
			$this->db->join("kol_names_for_survey","kol_names_for_survey.id = survey_answers.nominee_id",left);
			
			$arrData['influencers'] = array_diff($arrData['influencer_ids'], array('All Influencers'));
			/* foreach($arrData['influencers'] as $key=>$row){
				$this->db->or_where("kol_names_for_survey.id",$row);
			} */
			if(!empty($arrData['influencers'])){
				$this->db->where_in("kol_names_for_survey.id",$arrData['influencers']);
			}
			
			$arrData['state_id'] = array_diff($arrData['state_ids'], array('All States'));
			/* foreach($arrData['state_id'] as $key=>$row){
				$this->db->or_like("kol_names_for_survey.state",$row);
			} */
			//pr($arrData['state_id']);
			if(!empty($arrData['state_id'])){
				$this->db->where_in("kol_names_for_survey.state",$arrData['state_id']);
			}
			
			$arrData['city_id'] = array_diff($arrData['city_ids'], array('All Cities'));
			/* foreach($arrData['city_id'] as $key=>$row){
				$this->db->or_like("kol_names_for_survey.city",$row);
			} */
			if(!empty($arrData['city_id'])){
				$this->db->where_in("kol_names_for_survey.city",$arrData['city_id']);
			}
			
			$arrData['postalcode_id'] = array_diff($arrData['postalcode_ids'], array('All Postalcodes'));
			/* foreach($arrData['postalcode_id'] as $key=>$row){
				$this->db->or_like("kol_names_for_survey.postal_code",$row);
			} */
			if(!empty($arrData['postalcode_id'])){
				$this->db->where_in("kol_names_for_survey.postal_code",$arrData['postalcode_id']);
			}
			
			if($arrSelections['nominee']['type'] != ''){
				$this->db->join("survey_questions","survey_questions.id = survey_answers.question_id",left);
				$this->db->where("survey_questions.type_id",$arrSelections['nominee']['type']);
			}
			
			$this->db->where("survey_answers.survey_id",$arrData['survey_id']);
			$this->db->group_by("survey_answers.nominee_id");
			$this->db->order_by('count','desc');
			$result = $this->db->get("survey_answers");
			$result = $result->result_array();
			//pr($this->db->last_query());exit;
			return $result;
		}
		if($arrData['participant'] == 'users'){
			$this->db->select(array('count(distinct(survey_answers.respondent_id)) as count','concat(client_users.first_name," ",client_users.last_name) as name','client_users.title', 'client_users.phone', 'client_users.email','client_users.manager_id','concat(CU.first_name," ",CU.last_name) as manager','client_users.id as id'));
			$this->db->join("client_users as CU","CU.id = client_users.manager_id",left);
			$this->db->join("survey_answers","survey_answers.created_by = client_users.id",left);
			
			if($arrSelections['nominee']['type'] != ''){
				$this->db->join("survey_questions","survey_questions.id = survey_answers.question_id",left);
				$this->db->where("survey_questions.type_id",$arrSelections['nominee']['type']);
			}
			
			$this->db->where("survey_answers.survey_id",$arrData['survey_id']);
			$this->db->order_by('count','desc');
			$result = $this->db->get("client_users");
			$result = $result->result_array();
			//pr($this->db->last_query());exit;
			return $result;
		}
	}
	
	function getNominationsByRespondentsId($arrData,$arrSelections,$respId){
		$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
		$this->db->select('CASE
								WHEN survey_questions.type_id = 1 THEN "Local"
								WHEN survey_questions.type_id = 2 THEN "National"
								WHEN survey_questions.type_id = 3 THEN "Global"
								END AS type',false);
		$this->db->select(array('concat('.$nameFormatOrder.') as name','kol_names_for_survey.city','kol_names_for_survey.state','kol_names_for_survey.postal_code','kol_names_for_survey.source_table','kol_names_for_survey.source_table_id as kolId','survey_answers.nominee_id as id'));
		$this->db->join("kol_names_for_survey","kol_names_for_survey.id = survey_answers.nominee_id",left);
		$this->db->join("survey_questions","survey_questions.id = survey_answers.question_id",left);	
		
		if($arrSelections['nominee']['type'] != ''){
			$this->db->where("survey_questions.type_id",$arrSelections['nominee']['type']);
		}
		
		$this->db->where("survey_answers.survey_id",$arrData['survey_id']);
		$this->db->where("survey_answers.respondent_id",$respId);
		$result = $this->db->get("survey_answers");
		$result = $result->result_array();
		//pr($this->db->last_query());exit;
		return $result;
	}
	
	function getRespondentsByUserId($arrData,$arrSelections,$userId){
		$nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kol_names_for_survey');
		$this->db->select(array('distinct(survey_answers.respondent_id)','concat('.$nameFormatOrder.') as name','kol_names_for_survey.city','kol_names_for_survey.state','kol_names_for_survey.postal_code'));
		$this->db->join("kol_names_for_survey","kol_names_for_survey.id = survey_answers.respondent_id",left);
		
		if($arrSelections['nominee']['type'] != ''){
			$this->db->join("survey_questions","survey_questions.id = survey_answers.question_id",left);
			$this->db->where("survey_questions.type_id",$arrSelections['nominee']['type']);
		}
		
		$this->db->where("survey_answers.survey_id",$arrData['survey_id']);
		$this->db->where("survey_answers.created_by",$userId);
		$result = $this->db->get("survey_answers");
		$result = $result->result_array();
		//pr($this->db->last_query());exit;
		return $result;
	}

	function storeLatitudeLongitudeForSurveyKols($kolId){
		$this->db->select("kol_names_for_survey.id,kol_names_for_survey.city,kol_names_for_survey.state,kol_names_for_survey.country");
		$this->db->order_by("kol_names_for_survey.id", 'asc');
		if($kolId > 0){
			$this->db->where("kol_names_for_survey.id",$kolId);
		}
		$result = $this->db->get("kol_names_for_survey");
		$result = $result->result_array();
		foreach($result as $row){
			$this->db->select("cities.Latitude as latitude, cities.Longitude as longitude");
			$this->db->join("regions","regions.RegionID = cities.RegionID",left);
			$this->db->join("countries","countries.CountryId = cities.CountryID",left);
			$this->db->where("cities.City",$row['city']);
			$this->db->where("regions.Region",$row['state']);
			$this->db->where("countries.Country",$row['country']);
			$result1 = $this->db->get("cities");
			$result1 = $result1->result_array();
			foreach($result1 as $row1){
				$rowData[$row['id']] =  $row1;
			}
		}
		$size = sizeof($rowData);
		$count = 0;
		foreach ($rowData as $key=>$data){
			$this->db->where('id',$key);
			if($this->db->update('kol_names_for_survey',$data)){
				$count++;
			}
		}
		if($kolId > 0){
			
		}else{
			$failed =  $size-$count;
			echo "Total KOLs = " .$size."<br/>";
			echo "Updated KOLs = " .$count."<br/>";
			echo "Failed Updates = " .$failed."<br/>";
		}
		
	}
	
	
}


?>