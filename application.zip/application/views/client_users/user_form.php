<?php
/**
 * this is html file to Add the User Deatils
 * @package application.views.client_users
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 * 
 */

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>User Registration</title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	
	<link type="text/css" href="<?php echo base_url()?>css/client_layout.css"  rel="stylesheet" />

	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	<script src="<?php echo base_url()?>js/jquery.popupWindow.js" type="text/javascript"></script>
	
<style type="text/css">

	#container{	
		margin:0 auto;
		position:relative;
		text-align:left;
		width:696px;
		background:#fff;		
		margin-bottom:2em;
		}	
	#header{
		height:144px;
		background:#5DC9E1;
		color:#fff;
		}				
	#content{
		position:relative;
		}			
	#footer{	
		background-color: #DEDFDE;
	}
	.userRegistrationForm{
	   background: none repeat scroll 0 0 #F1F1F1;
	    float: left;
	    padding: 11px;
	    width: 98%;
	}
	.userForm .labelForfields{
		color: black;
	    float: left;
	 /*   font-family: "myriad-pro-1","myriad-pro-2","Droid Sans","Segoe UI",Lucida Grande,arial,tahoma,"Trebuchet Ms";*/
	 	font-family:"Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
   	    font-size: 13px;
	    margin-right: 12px;
	    margin-top: 3px;
	    text-align: right;
	    width: 143px;
	    font-weight:bold;
	}
	.userForm tr td{
		padding:5px;
	}
	.userForm input[type="text"],input[type="password"],select{
		width:220px;
	}
	.userForm .error{
		color:red;
		margin-right:56px;
		padding:0;
		background-image: url("/images/error_medium.gif");
   		 background-position: 10px center;
   		 background-repeat: no-repeat;
	}
    #errorBox{
   	 padding-left:143px;
    }
	.userForm input[type="button"] {
       background: none repeat scroll 0 0 -moz-use-text-color;
	    float: left;
	    font: bold 10pt Arial,Helvetica,sans-serif;
	    letter-spacing: 1px;
	    margin-left: 200px;
	    padding: 5px 10px;
	    text-align: center;
	  
	}
	#about{
	    font-family: lucida Grande;
	    font-style: normal;
	    font-weight: bold;
	    margin-left: 693px;
		margin-top: -14px;
	}
	.heading{
		color: #3366CC;
	    font-family: arial,sans-serif;
	    font-weight: bold;
	    font-size:12pt;
	}
	.userForm{
	
		margin-left:10%;
	}
	
	.span{
		color:red;
	}
	#h4{
		/*font-family:"myriad-pro-1","myriad-pro-2","Droid Sans","Segoe UI",Lucida Grande,arial,tahoma,"Trebuchet Ms";*/
		font-family:"Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
	}
	.inputFields{
		width:100%;
		text-align:left;
	}
	
	#userRegistrationWrapper {
    background: url("../images/login-bg.png") no-repeat scroll 0 0 transparent;
    height: 275px;
	}
	
	 #userFormContainer{
		float: right;
		margin-top: -45px;
		width:538px;
	}
	#userRegistrationContainer{
		background-color: #EEEEEE;
		background-image: -moz-linear-gradient(center top , #DDDDDD, #FFFFFF);
		padding: 110px 40px;
    }
</style>	
<script type="text/javascript">
		
			var validationRules	=  {
					first_name: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					last_name: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					title: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					company_name: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					phone: {
						required:true,
						 maxlength: 16,
						 minlength:6,
						  phoneUS: true
					},
					email: {
						required:true,
						 maxlength: 50,
						 minlength:4
					},
					country: {
						required:true
					},
					password: {
						required:true,
						 maxlength: 32,
						 minlength:4
					},
					confirm_password: {
						required:true,
						 maxlength: 32,
						 minlength:4
					},
					user_name: {
						required:true,
						 maxlength: 32,
						 minlength:4,
						 lettersonly: true 
					}
				};
			
				var validationMessages = {
						first_name: {
							required: "Required field cannot be left blank"
						},
						last_name: {
							required: "Required field cannot be left blank"
						},
						user_name: {
							required: "Required field cannot be left blank"
						},
						
						title: {
							required: "Required field cannot be left blank"
						},
						country: {
							required: "Required field cannot be left blank"
						},
						password: {
							required: "Required field cannot be left blank"
						},
						confirm_password: {
							required: "Required field cannot be left blank"
						},
						title: {
							required: "Required field cannot be left blank"
						},
						company_name: {
							required: "Required field cannot be left blank"
						},
						phone: {
							required: "Required field cannot be left blank"
						},
						email: {
							required: "Required field cannot be left blank"
						}
				};
			
				$(document).ready(function(){
					$('#saveUser').click(function(){
				
						$('#errorBox').text(' ');
						if(!$("#saveUserForm").validate().form()){
							return false;
						}
						 // Regular ecpression for Vhecking white space
						 reWhiteSpace       = new RegExp(/^\s+$/);
						 var useName        = $('#userName').val();
			
					     // Check for white space
					     if (useName.indexOf(' ') > 0) {
					          jAlert("Please Check Your User Fields For Spaces");
					          return false;
					     }else{
			
							 var password        = $('#password').val();
							 var confirmPassword = $('#confirmPassword').val();
							 if(password == confirmPassword){
									$('#saveUserForm').submit();
									return true;
							 }else{
								 	$('#password').val('');
								 	$('#confirmPassword').val('');
									$('#errorBox').text('Passwords do not match.');
									$('#errorBox').css({'color':'red'});
							 }
					     }
					});
					//Validation to check first letter alphet only
					jQuery.validator.addMethod("lettersonly", function(value, element) {
							var value1=value[0];
						  return this.optional(element) || /^[a-z]+$/i.test(value1);
						}, "Please enter first letter Alphbet"); 


					jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
					    phone_number = phone_number.replace(/\s+/g, ""); 
						return this.optional(element) || phone_number.length > 9 &&
							phone_number.match(/\(?[0-9]{2,}\)?(-?)\(?[0-9]{3,}?\)?(-?)[0-9]{4,}/);
					}, "Please specify a valid phone number");
					
					$("#saveUserForm").validate({
						//debug:true,
						onkeyup:true,
						rules: validationRules,
						messages: validationMessages
					});
			
					$('.privacy').popupWindow({ 
						height:650, 
						width:850, 
						top:50, 
						left:50,
						resizable: false 
					}); 

				});

				function checkFirstLetterAlphabet(value1){
					var val1=value1[0];
				
					var regexLetter = /[a-zA-z]/;
					if(!regexLetter.test(val1)){
					jAlert('First letter will be alphbet only');
					return false;
					}
				}
		</script>
</head>

<body>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php if(isset($title) && $title!=null) { echo $title; } else { echo "KOLM"; }?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	
	<link type="text/css" href="<?php echo base_url()?>css/login.css"  rel="stylesheet" />
	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	

	<script type="text/javascript" src="<?php echo base_url(); ?>js/cufon-yui.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>js/cufon-replace.js"></script>  
	<script type="text/javascript" src="<?php echo base_url(); ?>js/Shanti_400.font.js"></script>

<?php flush();?>
</head>
<body>
	<div>
		<div class="headerBG"><h1 class="productName">Key Opinion Leader Management</h1></div>
		<div id="userRegistrationContainer">
			<div id="userRegistrationWrapper">
				<div  title="Login" id="userFormContainer">
					<div class="boldText"><center>Register a new User Account</center></div><hr />
					<div id="error" style="color:red; margin-left:155px; font-weight:bold">
						<?php if(isset($arrUserDetails['error'])){
						echo  $arrUserDetails['error'];
						}?>
					</div>
					<form action="<?php echo base_url();?>client_users/save_user_registration_details" id="saveUserForm" method="post" name="saveUserForm1" >
						<table border="0" class="userForm" style="">
							<tr>
								<td><div class="labelForfields">First Name:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="first_name" id="firstName" value="<?php if(isset($arrUserDetails['first_name'])) echo $arrUserDetails['first_name']; else echo '';?>" class="required" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Last Name:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="last_name" id="lastName" value="<?php if(isset($arrUserDetails['last_name'])) echo $arrUserDetails['last_name']; else echo '';?>" class="required" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Title:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="title" id="title" value="<?php if(isset($arrUserDetails['title'])) echo $arrUserDetails['title']; else echo '';?>" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Company Name:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="company_name" id="companyName" value="<?php if(isset($arrUserDetails['company_name'])) echo $arrUserDetails['company_name']; else echo '';?>"/>
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Country:<span class="span">*</span></div></td>
								<td class="inputFields">
									<select name="country" id="countryId1"  class="required">
										<option value="">-- Select --</option>
										<?php foreach( $arrCountry as $country ){
												if(isset($arrUserDetails['country'])){
													if($arrUserDetails['country']==$country['country_id']){
														echo "<option value=".$arrUserDetails['country']." selected='selected'>".$country['country_name']."</option>";
													}
												}
											?>
											<option value="<?php echo $country['country_id'];?>" >
												<?php echo $country['country_name'];?>
											</option>
										<?php }?>
									</select>
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Phone:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="phone" id="phone" value="<?php if(isset($arrUserDetails['phone'])) echo $arrUserDetails['phone']; else echo '';?>" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Email:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="email" id="email" value="<?php if(isset($arrUserDetails['email'])) echo $arrUserDetails['email']; else echo '';?>" class="email" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Username:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="text" name="user_name" id="userName" value="" class="required" />
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Password:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="password" name="password" id="password" value="" />
									<div id="errorBox"></div>
								</td>
							</tr>
							<tr>
								<td><div class="labelForfields">Confirm Password:<span class="span">*</span></div></td>
								<td class="inputFields">
									<input type="password" name="confirm_password" id="confirmPassword" value="" onkeyup="" />
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<input type="button" value="Register" id="saveUser" name="dss"></input>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
		<div id="loginFooter">
			&nbsp;&nbsp;<img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" style="float:right;" />&nbsp;&nbsp;
			<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | KOLM Copyright &copy; 2011 <a href="http://www.aissel.com" target="new">Aissel</a> Solutions | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
		</div>
	</div>
	<script language="javascript">
	$(document).ready(function() { 
		$('#userRegistrationContainer').height($(window).height()-360);	
	});
</script>
</body>
</html>

</body>
</html>
	