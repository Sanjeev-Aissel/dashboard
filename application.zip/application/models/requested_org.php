<?php 


class requested_org extends Model{

	//Constructore
	function requested_org(){
		parent::Model();
	}
	
	function save($rowData){
		if($this->db->insert('user_org_requests',$rowData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function update($rowData){
		$this->db->where('id',$rowData['id']);
		if($this->db->update('user_org_requests',$rowData))
			return true;
		else
			return false;
	}
	
	function listMyPendingApprovals($userId){
		$isApprover	= IS_APPROVER;
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		$this->db->select('user_org_requests.status,user_org_requests.comments,user_org_requests.is_re_request,organizations.name as org_name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_org_requests.id,organizations.id as org_id,client_users.user_name as user_full_name,cities.City as city,regions.Region as state,user_org_requests.rej_or_appr_on,user_org_requests.requested_on,user_org_requests.requested_by');
		$this->db->join('client_users','client_users.id = user_org_requests.requested_by','left');
		$this->db->join('organizations','organizations.id = user_org_requests.org_id','left');
		$this->db->join('cities','organizations.city_id = cities.CityId','left');
		$this->db->join('regions','organizations.state_id = regions.RegionID','left');
		$this->db->where('user_org_requests.status',New1);
		if($clientId != INTERNAL_CLIENT_ID){
			$this->db->where('client_users.client_id',$clientId);
			if(!$isApprover){
				if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
					$this->db->where('client_users.manager_id',$userId);
				else 
					$this->db->where('client_users.id',$userId);
			}
		}
		$this->db->order_by('user_org_requests.requested_on','desc');
		$results = $this->db->get('user_org_requests');
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
	}
	
	function listAll(){
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		$this->db->select('user_org_requests.status,user_org_requests.comments,user_org_requests.is_re_request,organizations.name as org_name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_org_requests.id,organizations.id as org_id,client_users.user_name as user_full_name,cities.City as city,regions.Region as state, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,user_org_requests.rej_or_appr_on,user_org_requests.requested_on');
		$this->db->join('client_users','client_users.id = user_org_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_org_requests.rej_or_appr_by','left');
		$this->db->join('organizations','organizations.id = user_org_requests.org_id','left');
		$this->db->join('cities','organizations.city_id = cities.CityId','left');
		$this->db->join('regions','organizations.state_id = regions.RegionID','left');
		if($clientId != INTERNAL_CLIENT_ID){
			$this->db->where('client_users.client_id',$clientId);
		}
		$this->db->order_by('user_org_requests.requested_on','desc');	
		$results = $this->db->get('user_org_requests');		
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
	}
	
	
	function delete($id){
		$this->db->where_in('id',$id);
		if($this->db->delete('user_org_requests')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete user organization request',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => '',
					'transaction_id' =>  $id,
					'transaction_table_id' => USER_ORG_REQUESTS,
					'transaction_name' => "Delete user organization request",
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete user organization request',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => '',
					'transaction_id' =>  $id,
					'transaction_table_id' => USER_ORG_REQUESTS,
					'transaction_name' => "Delete user organization request",
					'parent_object_id' => ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}
	
	function get($id){
		$rowData = array();
		$this->db->where('id',$id);
		$results = $this->db->get('user_org_requests');
		if(is_object($results) && $results->num_rows() > 0)
			$rowData = $results->row_array();
			
		return $rowData;
	}
	
	function getUserRequestDetails($arrIds){
		$arrResults = array();
		$this->db->select('user_org_requests.status,user_org_requests.comments,user_org_requests.is_re_request,organizations.name as org_name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_org_requests.id,organizations.id as org_id,client_users.user_name as user_full_name,cities.City as city,regions.Region as state, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,user_org_requests.rej_or_appr_on,user_org_requests.requested_on');
		$this->db->join('client_users','client_users.id = user_org_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_org_requests.rej_or_appr_by','left');
		$this->db->join('organizations','organizations.id = user_org_requests.org_id','left');
		$this->db->join('cities','organizations.city_id = cities.CityId','left');
		$this->db->join('regions','organizations.state_id = regions.RegionID','left');
		$this->db->where_in('user_org_requests.id',$arrIds);
		$results = $this->db->get('user_org_requests');
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
		
	}
}