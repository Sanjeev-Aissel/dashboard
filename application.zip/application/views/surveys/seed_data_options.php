<?php
/*
 * Options to generated seed data for particular survey
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 2.0.0
 * Created on	: 12-09-2013
 *  
 */
// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	
								'chosen.jquery'
							);
	// add the JS files into queue i.e Append to the existing queue
	$prevjs = $this->config->item('js_files_to_load');
	if($prevjs == null)
		$prevjs = array();
	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<style>
	.chzn-container{
		font-size: 12px;
		margin-bottom: 3px;
	}
	.countParticipants{
		width:50px;
	}
	select.chosenSelect{
		width:200px;
	}
</style>
<script type="text/javascript">
/**
* Returns the list of States of the Selected Country ID
*/
function getStatesByCountryId(){
	
	// Show the Loading Image
	$("#loadingStates").show();
	
	var countryId=$('#country_id').val();
	var params = "country_id="+countryId;	
	$("#state_id").html("<option value=''>Select State</option>");
	$("#city_id").html("<option value=''>Select City</option>");
	var states = document.getElementById('state_id');
	$.ajax({
		url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
		dataType: "json",
		data: params,
		type: "POST",
		success: function(responseText){					
			$.each(responseText, function(key, value) {					
				var newState = document.createElement('option');
				newState.text = value.state_name;
				newState.value = value.state_id;
				// var prev = states.options[states.selectedIndex];
				// states.add(newState, prev);				
				states.add(newState);
			});
			
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
		},
		complete: function(){
			$("#loadingStates").hide();
		}
	});		
}

/**
* Returns the list of Cities of the Selected State
*/
function getCitiesByStateId(){
	// Show the Loading Image
	$("#loadingCities").show();
	
	var stateId=$('#state_id').val();
	$("#city_id").html("<option value=''>Select City</option>");	
	var cities = document.getElementById('city_id');
	var params = "state_id="+stateId;	
	
	$.ajax({
		url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
		dataType: "json",
		data: params,
		type: "POST",
		success: function(responseText){					
			$.each(responseText, function(key, value) {	
						
			var newCity = document.createElement('option');
			newCity.text = value.city_name;
			newCity.value = value.city_id;
			// var prev = cities.options[cities.selectedIndex];
			 //cities.add(newCity, prev);				
			cities.add(newCity);
			});		
			$("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
		},
		complete: function(){
			$("#loadingCities").hide();
		}		
	});		
	
}
$(document).ready(function(){
	$('.chosenSelect').chosen({allow_single_deselect: true});
});	
</script>
<h4>Generate Seed Data</h4>
<form action="seed_data" method="post">
<table>
	<tr>
		<td>
				<select id="survey" name="survey_id" class="chosenSelect">
					<option value="0">Select Survey</option>
					<?php foreach($arrCompletedSurveys as $key=>$arrRow){
						echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
					}?>
				</select>
		</td>
		<td>No. Of Users: <input type="text" name="no_of_users" class="countParticipants" /></td>
		<td>No. Of Respondents: <input type="text" name="no_of_respondents" class="countParticipants" /></td>
		<td>No. Of Influencers: <input type="text" name="no_of_influencers" class="countParticipants" /></td>
	</tr>
	<tr>
		<td>
			<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required" style="width:200px;">
					<option value="">Select Country</option>
					<?php foreach( $arrCountry as $country ){ ?>
					<option value="<?php echo $country['country_id'];?>">
					<?php echo $country['country_name'];?>
					</option>
					<?php }?>
				</select>
			<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
		</td>
		<td>
			<select name="state_id[]" id="state_id" style="width:125px;" multiple="multiple">		
				<option>Select State</option>
			</select>
			<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
		</td>
		<td>
			<!--<select name="city_id" id="city_id" style="width:165px;" multiple="multiple">
				<option>Select City</option>		
			</select>
		--></td>
		<td></td>
	</tr>
	<tr>
		<td colspan="4"><center><input type="submit" value="Generate Seed Data" /></center></td>
	</tr>
</table>
</form>