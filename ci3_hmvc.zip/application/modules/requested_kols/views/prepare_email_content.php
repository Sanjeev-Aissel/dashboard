<?php
if($requestAction == 'USER_REQUEST_USER'){ ?>
	<p>Hello,</p><br>
	<p>Your profile request has been sent to your manager for approval and will be processed once approved.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Requested</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	
									  
<?php }else if($requestAction == 'USER_REQUEST_MANAGER'){ ?>
	<p>Hello,</p>
	<p>There are new profiles pending your approval. The profiling requests will be processed by Aissel Content Team once you approve the requests.<br> 
		To approve/reject the requests, please click on the link below and login to <?php echo PRODUCT_NAME ?>.</p>
	</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Requested</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	

<?php }else if($requestAction == 'MANAGER_APPROVE_USER'){ ?>
	<p>Hello,</p>
	<p>Your profile request has been approved by your manager. We will notify you once the request is processed and the profile is available.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Approved</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	

<?php }else if($requestAction == 'MANAGER_REJECT_USER'){ ?>
	<p>Hello,</p>
	<p>Your profile request has been rejected by your manager.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Rejected</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	

<?php }else if($requestAction == 'MANAGER_APPROVE_ANALYST' || $requestAction == 'MANAGER_REQUEST_ANALYST'){ ?>
	<p>Hello,</p>
	<p><b><?php echo $clientName;?></b> User has submitted new Profile content curation requests for further processing.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Requested</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	<p>
		<?php if($arrKol['specialty']!=''){?>
			<label>Specialty: <?php echo $arrKol['specialty'];?></label>
			<?php }?>
	
	</p>
	
	<p>
		<?php if($arrKol['npi_num']!='' && $arrKol['npi_num']!=0){?>
			<label>NPI Number: <?php echo $arrKol['npi_num'];?></label>
			<?php }?>
	
	
	<p>
		<?php if($arrKol['org_id']!=''){?>
			<label>Organization: <?php echo $arrKol['org_id'];?></label>
			<?php }?>
	
	</p>
	</p>
		<p>
		<?php if($arrKol['country_id']!=''){?>
			<label>Country: <?php echo $arrKol['country_name'];?></label>
			<?php }?>
	
	</p>
	<p>
		<?php if(isset($arrKol['state_id'])){?>
			<label>State: <?php echo $arrKol['state_name'];?></label>
			<?php }?>
	
	</p>
	<p>
		<?php if(isset($arrKol['city_id'])){?>
			<label>City: <?php echo $arrKol['city_name'];?></label>
			<?php }?>
	
	</p>

<?php }else if($requestAction == 'ANALYST_REJECT_USER'){ ?>
	<p>Hello,</p>
	<p>Your profile request has been rejected by Analyst manager.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Rejected</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>
	

<?php }else if($requestAction == 'ANALYST_APPROVE_USER'){ ?>
	<p>Hello,</p>
	<p>Your profile request has been approved by Analyst manager and will notify once completed.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>requested_kols/requested_kols/show_client_requested_kols' target='_NEW'>Profile Approved</a></p>
	<?php echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>


<?php }else if($requestAction == 'ANALYST_COMPLETE_USER'){ ?>
	<p>Hello,</p>
	<p>Your profile request has been processed. Please click on the link below and login to <?php echo PRODUCT_NAME ?> to access the profile.</p>
	<p><a title="Requested KOLs" href='<?php echo base_url();?>kols/kols/view/<?php echo $arrKol['id'];?>' target='_NEW'>View Profile</a></p>
	<?php //echo $arrKol['first_name']." ".$arrKol['middle_name']." ".$arrKol['last_name'];?>Aissel Content Services
	
<?php } ?>

<p>&nbsp;</p>
<p>Thanks,</p>
<p>Aissel Content Team</p>