<?php
/**
 * This is Model for 'Access Objects'
 * 
 * @author Ramesh B
 * @since  3.6
 * @package application.models	
 * @created 21-12-2011
 */

class Access_object extends Model{
 	
 	//Constructor
	function Access_object(){
		parent::Model();
	}
	
	/**
	 * Saves the given 'Access Object' details into tabl and returns the id of it, if the object already exist returns false
	 * @author 	Ramesh B
	 * @since	3.6
	 * @param String comment
	 * @return Array
	 * @created 21-12-2011
	 */	
	function saveAccessObject($accessObjectDetails){
		if($this->db->insert('access_objects',$accessObjectDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	
    /**
	 * Fetches the 'Access Object' Id for given pair of 'Controller' and 'Method' names, returns 0 if ther is no match
	 * @author Ramesh B
	 * @since 3.6
	 * @return Integer
	 * @created 22-12-2011
	 */
	function getAccessObjectIdByNames($controllerName,$methodName){
		$acoId=0;
		$this->db->select('id');
		$this->db->where('controller',$controllerName);
		$this->db->where('method',$methodName);
		$results=$this->db->get('access_objects');
		if($results->num_rows() > 0){
			$row=$results->first_row('array');
			$acoId=$row['id'];
		}
		return $acoId;
	}
	
	function getAccessObjects(){
		$arrAccessObjects =array();
		$this->db->order_by('category,alias');
		$arrResultSet = $this->db->get('access_objects');
		foreach($arrResultSet->result_array() as $row){
			$arrAccessObjects[]=$row;
		}
		return $arrAccessObjects;
	}
	
	function insertAccessPermissionsForRole($roleId){
		$arrAccessObjects=$this->getAccessObjects();
		
		$string="insert into access_permissions (access_object_id,role_id,is_allowed) values ";
		foreach($arrAccessObjects as $row){
			$string.="(".$row['id'].",".$roleId.",0),";
		}
		$string=trim($string,",");
		$this->db->query($string);
	}
	
}