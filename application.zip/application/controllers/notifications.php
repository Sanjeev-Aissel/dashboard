<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Notifications extends Controller {

    private $loggedUserId = null;

    //Constructor
    function Notifications() {
        parent::Controller();
        $this->load->model('kol');
        $this->load->model('notification');
        $this->load->model("Country_helper");
        $this->load->model("Event_helper");
        $this->load->model('pubmed');
        $this->load->model('clinical_trial');
        $this->load->model("Specialty");
        $this->load->library("Ajax_pagination");
        $this->load->model('common_helpers');
        $this->load->model('organization');
        $this->load->model('Client_User');
        $this->load->model('My_list_kol');
        $this->load->model("interaction");
        $this->load->model("payment");
        $this->load->model("kol_rating");
        $this->load->model('user_setting');
        $this->load->model('align_user');
        $this->loggedUserId = $this->session->userdata('user_id');
    }

    function notifications_home() {
    	//pr($this->session->userdata('user_full_name'));exit;
        $data['contentPage'] = 'notifications/notifications_home';
        //Add Log activity
        $arrLogDetails = array(
        		'type' => VIEW_RECORD,
        		'description' => "Visited notifications home Page",
        		'status' => STATUS_SUCCESS,
        		'transaction_name' => "View notifications home page"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $this->load->view('layouts/client_view', $data);
    }

    function add_notification($id = null) {
        if ($id == "" || $id == null) {
            $clientId = $this->session->userdata('client_id');
            $data['arrClientUsers'] = $this->Client_User->getClientUsers($clientId);
            $data['arrGroups'] = $this->user_setting->getUniqueGroupNames();
            //Add Log activity
            $arrLogDetails = array(
            		'type' => VIEW_RECORD,
            		'description' => "Visited add notification form",
            		'status' => STATUS_SUCCESS,
            		'transaction_name' => "View add notification form"
            );
            $this->config->set_item('log_details', $arrLogDetails);
            $this->load->view('notifications/add_notification_form', $data);
        } else {
            $clientId = $this->session->userdata('client_id');
            $data['arrNotification'] = $this->notification->getNotificationById($id);
            $data['arrNotification'] = $data['arrNotification'][0];
            $data['arrClientUsers'] = $this->Client_User->getClientUsers($clientId);
            $data['arrGroups'] = $this->user_setting->getUniqueGroupNames();
            //Add Log activity
            $arrLogDetails = array(
            		'type' => VIEW_RECORD,
            		'description' => "Visited add notification form",
            		'status' => STATUS_SUCCESS,
            		'transaction_name' => "View add notification form"
            );
            $this->config->set_item('log_details', $arrLogDetails);
            $this->load->view('notifications/add_notification_form', $data);
        }
    }

    function save_notification() {
    	//exit;
        $arrData['start_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $this->input->post('start_date'))));
        $arrData['end_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $this->input->post('end_date'))));
        $arrData['note'] = str_replace('<', '', $this->input->post('note'));
        $arrData['note'] = str_replace('>', '',  $arrData['note']);
        //$arrData['note'] = preg_replace("/[^a-zA-Z>.,)][(\s]/", "",$this->input->post('note'));
        if ($this->input->post('is_active') == "on")
            $arrData['is_active'] = 1;
        else
            $arrData['is_active'] = 0;
        $users = array();
        $temp = $this->input->post('users');
        if(!empty($temp))
        $users = $this->input->post('users');
        
        if (!empty($users))
            $arrData['users'] = implode(',', $this->input->post('users'));

        $groups = $this->input->post('groups');
        if (!empty($groups))
            $arrData['groups'] = implode(',', $this->input->post('groups'));
		
            $arrData['send_email'] = 0;
       	if(!empty($this->input->post('emailcheck')))
       		$arrData['send_email'] = 1;
       	
       		$arrData['all_users'] = 0;
		if($this->input->post('allusers'))
			$arrData['all_users'] = 1;
		
        $arrData['modified_by'] = $this->loggedUserId;
        $arrData['modified_on'] = date('Y-m-d H:i:s');

        $id = $this->input->post('notification_id');
		
        if ($id == "") {

            $arrData['created_by'] = $this->loggedUserId;
            $arrData['created_on'] = date('Y-m-d H:i:s');
            $notificationId = $this->notification->saveNotification($arrData);
            //$this->notification->updateEmailNotification($notificationId);
            $formData = json_encode ( $formData );
            $arrLogDetails = array (
            		'type' => ADD_RECORD,
            		'description' => 'Save Notifications',
            		'status' => STATUS_SUCCESS,
            		'transaction_id' => $notificationId,
            		'transaction_table_id' => NOTIFICATIONS,
            		'transaction_name' => "Notifications",
            		'parent_object_id' => $notificationId,
            		'user_id' => $arrData ['users'],
            		'form_data' => $formData
            );
            $this->config->set_item ( 'log_details', $arrLogDetails );
//        pr($this->db->last_query());

            if ($notificationId) {
                $data['id'] = $notificationId;
                $data['status'] = true;
            } else {
                $data['status'] = false;
            }
        } else {
        	$notificationId = $id;
            $this->notification->deleteAllNotificationUsers($id);
//            pr($this->db->last_query());//exit();
            
            if($this->notification->updateNotification($id, $arrData)){
            	$arrLogDetails = array(
            			'type' => EDIT_RECORD,
            			'description' => 'Update Notifications',
            			'status' => STATUS_SUCCESS,
            			'transaction_id' => $notificationId,
            			'transaction_table_id' => NOTIFICATIONS,
            			'transaction_name' => "Update Notifications",
            			'module'=>'Notification',
            			'parent_object_id'=>$notificationId,
            			'user_id'=> $arrData['users'],
            			'form_data' => $formData
            	);
            	$this->config->set_item('log_details', $arrLogDetails);
                $data['status'] = true;
            }
            else
                $data['status'] = false;
        }

        $groupUsers = array();
        $groupUsers = $this->user_setting->getUserIdsFromGroupIds($groups);

        $allUsers = array_merge((array)$users, (array)$groupUsers);
//pr($allUsers);
//exit();
        foreach ($allUsers as $user) {
            $notificationData['notification_id'] = $notificationId;
            $notificationData['user_id'] = $user;
            $notificationData['has_seen'] = 0;
            $lastId = $this->notification->saveUserNotification($notificationData);
        }
        if($arrData['all_users'] == 1){
            $arrAllUsersIds = $this->notification->getAllUsersIds($notificationId);
            foreach ($arrAllUsersIds as $user) {
                $notificationData['notification_id'] = $notificationId;
                $notificationData['user_id'] = $user;
                $notificationData['has_seen'] = 0;
                $lastId = $this->notification->saveUserNotification($notificationData);
            }
        }

        echo json_encode($data);
    }

    function list_user_notifications() {
        $data['notifications'] = $this->notification->getUserNotifications($this->loggedUserId);
        $this->load->view('notifications/list_notifications', $data);
    }

    function list_all_notifications() {
    	$userId = $this->session->userdata('user_id');
    	$getRegions = $this->notification->get_regions($userId);
    	foreach($getRegions as $refionUers){
    		$regionUsers = $refionUers['id'];
    		$divisionUsers = $this->notification->get_users_division($regionUsers);
    		if(!empty($divisionUsers)){
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrNotificationsResult = $this->notification->getAllNotifications();
        foreach($arrNotificationsResult as $key => $row){
        	$emailStatus = $row['email_status'];
        	if($emailStatus != 0){
            $arrNotificationsResult[$key]['eAllowed'] = $this->common_helpers->isActionAllowed('notification', 'edit', $row);
            $arrNotificationsResult[$key]['dAllowed'] = $this->common_helpers->isActionAllowed('notification', 'delete', $row);
        	$arrNotificationsResult[$key]['start_date'] = sql_date_to_app_date($row['start_date']);
        	$arrNotificationsResult[$key]['end_date'] = sql_date_to_app_date($row['end_date']);
        }else{
        	$arrNotificationsResult[$key]['eAllowed'] = $this->common_helpers->isActionAllowed('notification', 'edit', $row);
        	$arrNotificationsResult[$key]['dAllowed'] = $this->common_helpers->isActionAllowed('notification', 'delete', $row);
        	$arrNotificationsResult[$key]['start_date'] = sql_date_to_app_date($row['start_date']);
        	$arrNotificationsResult[$key]['end_date'] = sql_date_to_app_date($row['end_date']);
        	}
        
        }
    }
   }
        $count = sizeof($arrNotificationsResult);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrNotificationsResult;
        echo json_encode($data);
    }

    function mark_notification_seen($notificationId, $userId) {
        if ($this->notification->markNotificationSeen($notificationId, $userId)) {
            $data['status'] = true;
        } else {
            $data['status'] = false;
        }
        echo json_encode($data);
    }

    function delete_notification($id) {
        $this->notification->deleteNotification($id);
    }
    
    // Email Notification for Notifications to users and Managers
    function email_notification(){
    		$getNotificationForCurrentDay = $this->notification->get_notification_for_current_day();
    		$notifyId = '';
    		foreach($getNotificationForCurrentDay as $row){
    		    $notifyId .= $row['id'].',';
    			$startDate = $row['start_date'];
    			$endDate = $row['end_date'];
    			$note = $row['note'];
    			$users = $row['users'];
    			$groups = $row['groups'];
    			$createdBy = $row['created_by'];
    		}
    		$listGroupUsers = $this->notification->get_all_notifications_for_email();
    		$arrData = array();
    		foreach($listGroupUsers as $key=>$value){
    		    $arrData[] = explode('*email*', $key);
    		}
    		foreach($arrData as $rowData){
		    $email = $rowData['1'];
		    $sendMail =  $rowData['0'];
    		$fromEmail = NOTIFICATION_SENDER;
//     		$config['protocol'] = PROTOCOL;
//     		$config['smtp_host'] = HOST;
//     		$config['smtp_port'] = PORT;
//     		$config['smtp_user'] = USER;
//     		$config['smtp_pass'] = PASS;
//     		$config['mailtype'] = 'html';
    		$config = email_config_initializer('notification');
    		$this->load->library('email', $config);
    		$this->email->set_newline("\r\n");
    		$this->email->initialize($config);
    		$this->email->set_newline("\r\n");
    		$this->email->from($config['smtp_user'],$fromEmail);
    		$this->email->to($email);
    		$this->email->subject('New Notification in KTL application');
    		$this->email->message('Hi,<br /><br />
			You have an unread notification from &nbsp;'.$sendMail.'<br /><br /> Please <a href="'.base_url().'kols/client_index"> click here</a> to log in to the KTL application
			<br /><br /><br />
			Regards,<br />
			Aissel Support Team'
    		);
    		$this->email->set_crlf("\r\n");
    		if ($this->email->send()){
    		    //Record log Activity
    		    $arrLogDetails = array(
    		        'type' => CRON_JOBS,
    		        'description' => 'Notification Email Sent',
    		        'status' => STATUS_SUCCESS,
    		        'transaction_id' => $notifyId,
    		        'transaction_table_id' => NOTIFICATIONS,
    		        'transaction_name' => "Notification Email Sent",
    		        'parent_object_id' => $notifyId,
    		        'miscellaneous2' => " To- ".$email
    		    );
    		    $this->config->set_item('log_details', $arrLogDetails);
    		    log_user_activity(null, true);
    		    $this->notification->updateEmailNotification();
//     		    return true;
    		} else {
    		    //Record log Activity
    		    $arrLogDetails = array(
    		        'type' => CRON_JOBS,
    		        'description' => 'Notification Email Sent',
    		        'status' => STATUS_FAIL,
    		        'transaction_id' => $notifyId,
    		        'transaction_table_id' => NOTIFICATIONS,
    		        'transaction_name' => "Notification Email Sent",
    		        'parent_object_id' => $notifyId,
    		        'miscellaneous2' => " To- ".$email
    		    );
    		    $this->config->set_item('log_details', $arrLogDetails);
    		    log_user_activity(null, true);
//     		    return false;
    		}
    		$this->email->clear(TRUE);
    	}
    }
}

?>