<?php

require(APPPATH.'/libraries/mcrypt_modified.php');

class MyAPIConnect
{
	var $CI;
	var $user_table = 'client_users';

	function get_api_response($url,$type = 'get',$params = array()){
		$response = array();
		$this->CI =& get_instance();
		
		$userId = $this->CI->session->userdata('user_id');
		$this->CI->db->where('id', $userId); 
		$query = $this->CI->db->getwhere($this->user_table);
		//pr($this->CI->db->last_query());
		if ($query->num_rows() <= 0){
			$response['msg'] = 'Invalid User';
			return $response;
		}
		$user_data = $query->row_array(); 
		
		//$url = "http://203.129.219.198/poland/api/experts/process_find_exports_in";
		//$url = "http://localhost/ci_rest_server/index.php/api/example/users/format/json";
		$restApiKey = $user_data['api_key'];
		$restSecretKey = $user_data['secret_key'];
		
		$checksumtext = myencrypt($url,$restSecretKey);
		//echo $checksumtext."<br>";
		$c = curl_init($url);
		if($type == 'post'){
			curl_setopt($c, CURLOPT_POST, true);
			curl_setopt($c, CURLOPT_POSTFIELDS, $params);
		}
		
		$useragent = $_SERVER['HTTP_USER_AGENT'];
 		$strCookie = 'PHPSESSID=' . $_COOKIE['PHPSESSID'] . '; path=/';
 		curl_setopt($c,CURLOPT_USERAGENT, $useragent);
		curl_setopt( $c, CURLOPT_COOKIE, $strCookie );
 
		curl_setopt($c, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		//curl_setopt($c, CURLOPT_COOKIE, "X-API-KEY=1234;");
		//curl_setopt($c, CURLOPT_USERPWD, "admin:1234");
		$header = array("X-API-KEY: $restApiKey","CHECKSUM-TEXT:$checksumtext");
		curl_setopt($c, CURLOPT_HTTPHEADER, $header);
		// you can have cURL follow redirects using the option:
		curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($c, CURLOPT_COOKIESESSION, true);
		curl_setopt($c, CURLOPT_COOKIEJAR, '/cookie.txt');
    	curl_setopt($c, CURLOPT_COOKIEFILE, '/cookie.txt');
		curl_setopt($c, CURLOPT_VERBOSE, true);
		curl_setopt($c, CURLOPT_HEADER, false);
		curl_setopt($c, CURLOPT_AUTOREFERER, true);
		
		$response = curl_exec($c);
		//print_r($response);
		curl_close($c);
		//header("Location: http://203.129.219.197/poland_new/mesh_terms");
		//exit(); 
		//$responseData = json_decode($response, true);
		//print_r($responseData);
			
		return $response;
	}

}