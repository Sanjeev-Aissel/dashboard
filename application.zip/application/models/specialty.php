<?php
/**
 * Model file for the 'Specialty' 
 * 
 * @package application.models
 * @author Ramesh B
 * @since
 * @created on 06-01-11
*/

class Specialty extends Model{
	
	/**
	 * Returns all the specialties
	 * @return array	- ID, and Name
	 */
	function getAllSpecialties($contentPage=""){
	   $arrSpecialties	= array();
	    $clientId = $this->session->userdata('client_id');
	    /*$this->db->where('specialty !=', '');
	     $this->db->order_by("specialty", "asc");
	     if($clientId != INTERNAL_CLIENT_ID && $contentPage != 'all')
	         $this->db->where('client_id',$clientId);
	         //if($contentPage==""){
	         $this->db->or_where('all',1,false);
	         /*}
	         elseif($contentPage!=""){
	         $this->db->where($contentPage,1);
	         }
	         */
	     /*if($clientId != INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN){
	         if($clientId ==CUSTOMER_CLIENT_ID){
	             $this->db->where('client_id',$clientId);
	         }else{
	             $this->db->where('all',1);
	         }
	     }*/
	     $this->db->where('all',1);
	     $arrSpecialtiesResult = $this->db->get('specialties');
// 	     pr($this->db->last_query());exit;
	   //  $arrSpecialtiesResult = $this->db->query("SELECT * FROM (`specialties`) WHERE `specialty` != '' AND (`client_id` = $clientId OR `all` = 1) ORDER BY `specialty` asc");
	   
	     foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
	         $arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
	     }
	
	     $key = array_search('Non-medical / Others',$arrSpecialties);
	     unset($arrSpecialties[$key]);
	     if($clientId == INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN)
	         $arrSpecialties1[$key] = 'Non-medical / Others';
	         foreach($arrSpecialties as $key1=>$value1){
	             $arrSpecialties1[$key1] = $value1;
	         }
	         return $arrSpecialties1;
	}
	
	function getAllSpecialtiesAll($contentPage=""){
	    $arrSpecialties	= array();
	    $clientId = $this->session->userdata('client_id');
	    /*$this->db->where('specialty !=', '');
	     $this->db->order_by("specialty", "asc");
	     if($clientId != INTERNAL_CLIENT_ID && $contentPage != 'all')
	         $this->db->where('client_id',$clientId);
	         //if($contentPage==""){
	         $this->db->or_where('all',1,false);
	         /*}
	         elseif($contentPage!=""){
	         $this->db->where($contentPage,1);
	         }
	         */
	     //$arrSpecialtiesResult = $this->db->query("SELECT * FROM (`specialties`) WHERE `specialty` != '' AND (`client_id` = $clientId OR `all` = 1) ORDER BY `specialty` asc");
	     if($clientId != INTERNAL_CLIENT_ID){
	         $arrSpecialtiesResult = $this->db->query("SELECT * FROM (`specialties`) WHERE `specialty` != '' AND (`client_id` = $clientId ) ORDER BY `specialty` asc");
	     }else{
	         $arrSpecialtiesResult = $this->db->query("SELECT * FROM (`specialties`) WHERE `specialty` != '' AND (`client_id` = $clientId OR `all` = 1) ORDER BY `specialty` asc");
	     }
	    
	    
	     foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
	         $arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
	     }
	    
	     $key = array_search('Non-medical / Others',$arrSpecialties);
	     unset($arrSpecialties[$key]);
	     if($clientId == INTERNAL_CLIENT_ID)
	         $arrSpecialties1[$key] = 'Non-medical / Others';
	         foreach($arrSpecialties as $key1=>$value1){
	             $arrSpecialties1[$key1] = $value1;
	         }
	         return $arrSpecialties1;
	}  
	
	/**
	 * Returns the name of the specified specialty ID
	 */
	function getSpecialtyById($specialtyId){
		$this->db->where('id', $specialtyId);
		$this->db->select('specialty');
		
		$results	= $this->db->get('specialties');
		foreach($results->result_array() as $row){
			$specialty=$row['specialty'];				
		}
		return $specialty;
	}

	/**
	 * Returns all the specialties
	 * @return array	- ID, and Name
	 */
	function getSpecialties($specialty){
		$arrSpecialties	= array();
		$this->db->select('specialties.id,specialties.specialty');
		$this->db->like('specialties.specialty',$specialty);
		$this->db->join('kols','kols.specialty=specialties.id','inner');
		$this->db->group_by('kols.specialty');
		$this->db->where('status',COMPLETED);
		$arrSpecialtiesResult = $this->db->get('specialties');
		
		foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
			$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		}
		return $arrSpecialties;
	}
	
	/**
	 * Returns  Specialties those are aossociates with KOL's
	 * @return array	- ID, and Name
	 */
	function getKolsSpecialties(){
		$arrSpecialties	= array();
		$this->db->select('specialties.*');
		$this->db->order_by("specialties.specialty", "asc");
		$this->db->order_by("specialties.id", "asc");
		$this->db->join('kols','specialties.id=kols.specialty');
		$this->db->where('kols.status',COMPLETED);
		$this->db->group_by('specialties.specialty');
		$arrSpecialtiesResult = $this->db->get('specialties');
		foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
			$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		}
		return $arrSpecialties;
	}
	function getSpecialtiesById($arrId){
		$arrSpecialties	= array();
		$this->db->where_in('id', $arrId);
		$results	= $this->db->get('specialties');
		foreach($results->result_array() as $row){
			$arrSpecialties[$row['id']]=$row['specialty'];				
		}
		return $arrSpecialties;
	}
	function getExcludedKolsSpecialties($arrIds){
		$this->db->select(array('specialties.id', 'specialties.specialty', '0 as kol_specialty_count'), false);
		$this->db->order_by("specialty", "asc"); 
		$this->db->join('kols','specialties.id=kols.specialty');
                if(count($arrIds) !=0)
                    $this->db->where_not_in('specialties.id', $arrIds);
		$this->db->where('kols.status',COMPLETED);
		$this->db->group_by('specialties.id');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$query = $this->db->get('specialties');
		//print $this->db->last_query(); exit;
		return $query->result_array();
	}
	
	/*
	 * Insert kol sub specialty ids
	 * @param - $kolId, $arrSubSpecialty
	 */
	function insertKolSubSpecialty($kolId,$arrSubSpecialty){
		foreach ($arrSubSpecialty as $value) {
			$this->db->insert('kol_sub_specialty', array("kol_id" => $kolId, "kol_sub_specialty_id" => $value));
		}
	}
	/*
	 * Gets the sub specialty ids for given kol id
	 * @param - $kolId
	 * @return - Array - $arrSubSpecialties
	 */
	function getKolSubSpecialty($kolId){
		$this->db->select('kol_sub_specialty.kol_sub_specialty_id,kol_sub_specialty.id');
		$this->db->where('kol_sub_specialty.kol_id', $kolId);
		$arrkolSubSpecialtyResult = $this->db->get('kol_sub_specialty');
		 
		foreach($arrkolSubSpecialtyResult->result_array() as $arrSubSpecialty){
			$arrSubSpecialties[$arrSubSpecialty['kol_sub_specialty_id']]	= $arrSubSpecialty['kol_sub_specialty_id'];
		}
		return $arrSubSpecialties;
	}
	/*
	 * Gets the sub specialty names for given kol id
	 * @param - $kolId
	 * @return - Array - $arrSubSpecialties
	 */
	function getAllKolSubSpecialties($kolId){
		$this->db->select('kol_sub_specialty.kol_sub_specialty_id as id,specialties.specialty');
		$this->db->join('specialties','specialties.id = kol_sub_specialty.kol_sub_specialty_id','left');
		$this->db->where_in('kol_sub_specialty.kol_id', $kolId);
		//$this->db->where('priority',0);
		$arrPriorityCondition =array(
				'kol_sub_specialty.priority' => NULL,
				'kol_sub_specialty.priority' => '0'
		);
		$this->db->where_in($arrPriorityCondition);
		$arrkolSubSpecialtyResult = $this->db->get('kol_sub_specialty');
// 		echo $this->db->last_query();exit;
		$arrKolSubSpecialties	= array();
		foreach($arrkolSubSpecialtyResult->result_array() as $arrSubSpecialty){
			if($arrSubSpecialty['id']==0){
				$arrKolSubSpecialties[$arrSubSpecialty['id']]	= 'Non-medical / Others';
				continue;
			}
			$arrKolSubSpecialties[$arrSubSpecialty['id']]	= $arrSubSpecialty['specialty'];
		}
		return $arrKolSubSpecialties;
	}
	/*
	 * Gets the primary,additional specialty names for given kol id
	 * @param - $kolId
	 * @return - Array - $arrPrimaryAdditionalSpecialties
	 */
	function getAllKolPrimaryAdditionalSpecialties($kolId){
		$this->db->select('kol_sub_specialty.kol_sub_specialty_id as id,specialties.specialty');
		$this->db->join('specialties','specialties.id = kol_sub_specialty.kol_sub_specialty_id','left');
		$this->db->where_in('kol_sub_specialty.kol_id', $kolId);
		$this->db->where_in('priority',array(1,2));
		$arrkolPrimAddSpecialtyResult = $this->db->get('kol_sub_specialty');
		// 		echo $this->db->last_query();exit;
		$arrPrimaryAdditionalSpecialties	= array();
		foreach($arrkolPrimAddSpecialtyResult->result_array() as $arrPrimSpecialty){
			if($arrPrimSpecialty['id']==0){
				$arrPrimaryAdditionalSpecialties[$arrPrimSpecialty['id']]	= 'Non-medical / Others';
				continue;
			}
			$arrPrimaryAdditionalSpecialties[$arrPrimSpecialty['id']]	= $arrPrimSpecialty['specialty'];
		}
		return $arrPrimaryAdditionalSpecialties;
	}
	function getAllSpecialtyForAutocomplete($specialty){
		$arrSpecialties	= array();
		$this->db->select('specialties.id,specialties.specialty');
		$this->db->like('specialties.specialty',$specialty);
		//$this->db->join('kols','kols.specialty=specialties.id','inner');
		//$this->db->group_by('kols.specialty');
		//$this->db->where('status',COMPLETED);
		$arrSpecialtiesResult = $this->db->get('specialties');
		
		foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
			$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		}
		return $arrSpecialties;
	}
	
}