<?php 
  	if(!IS_IPAD_REQUEST) {
		echo '<h3>Similar names found</h3><hr>';
	}
?>
<table class="table">
  <tr>
    <th class="contentTitle"><?php echo lang("KOL"); ?> Name</th>
    <th class="contentTitle">Specialty</th>
    <th class="contentTitle">City</th>
    <th class="contentTitle">State</th>
    <th class="contentTitle">Postal Code</th>
  </tr>
  <?php 
  	$arrSalutations							= array(0 =>'', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
  foreach($arrDuplicates as $row){?>
  	  <tr>
	    <td>
	    	<?php 
  					if(IS_IPAD_REQUEST) {
						echo '<a href="'.base_url().IPAD_URL_SEGMENT.'/kols/view/'.$row['id'].'">'.$arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']).'</a>';//$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
					}else{
						echo '<a target="_NEW" href="'.base_url().'kols/view/'.$row['id'].'">'.$arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']).'</a>';//$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
					}
	    	?>
	    </td>
	    <td><?php echo $row['specialty'];?></td>
	    <td><?php echo $row['city'];?></td>
	    <td><?php echo $row['state'];?></td>
	    <td><?php echo $row['postal_code'];?></td>
	  </tr>
  <?php }?>
  <tr>
  	<td colspan="5" style="text-align: center;">
  		<!-- <a class="blueButton" href="<?php echo base_url();?>kols/list_kols_client_view">Cancel</a> -->
  		<?php if($step == '1'){?>
  		<a class="<?php if(IS_IPAD_REQUEST) echo 'btn btn-default'; else echo 'blueButton';?>" onclick="proceedToAdd1();">
  			Ignore, Proceed to <?php if($kolId != '') echo "Update"; else echo "Add New";?>
  		</a>
  		<?php }else{?>
  		<a class="<?php if(IS_IPAD_REQUEST) echo 'btn btn-default'; else echo 'blueButton';?>" onclick="proceedToAdd2();">
  			Ignore, Proceed to <?php if($kolId != '') echo "Update"; else echo "Add New";?>
  		</a>
  		<?php }?>
  	</td>
  </tr>
</table>

