
##----------------------------
##-- kol_educations, kol_additional_contacts, kol_memberships,  Table
## - Modified on Dec 23rd, 2010 - Added 3 more fields - url1, url2, notes
##----------------------------
ALTER TABLE `kol_educations` ADD COLUMN `url1` text   NULL  AFTER `year`, add column `url2` text   NULL  AFTER `url1`, add column `notes` text   NULL  AFTER `url2`;


ALTER TABLE `kol_additional_contacts` ADD COLUMN `url1` text   NULL  AFTER  `email`, add column `url2` text   NULL  AFTER `url1`, add column `notes` text   
NULL  AFTER`url2`;


ALTER TABLE `kol_memberships` ADD COLUMN `url1` text   NULL  AFTER  `amount`, ADD COLUMN `url2` text   NULL  AFTER `url1`, ADD COLUMN `notes` text   NULL  AFTER `url2`;

##----------------------------
##-- institutions Table
## - Modified on Dec 29th, 2010 - changed the name field as NOT NULL
##----------------------------
ALTER TABLE `institutions` CHANGE `name` `name` varchar (255)  NOT NULL;

##----------------------------
##-- events Table
## - Modified on Dec 29th, 2010 - Added 1 more field - category
##----------------------------
ALTER TABLE `events` ADD COLUMN `category` varchar (255)  NOT NULL  AFTER `id` , CHANGE `name` `name` varchar (255)  NOT NULL  COLLATE latin1_swedish_ci; 


##----------------------------
##-- kol_memberships Table
## - Modified on Dec 29th, 2010 - Added 1 more field - engagement_type
##----------------------------
ALTER TABLE `kol_memberships` ADD COLUMN `engagement_type` varchar (255)  NOT NULL  AFTER `notes` ;

##----------------------------
##-- kol_events Table
## - Modified on Dec 30th, 2010 - Changed the `topic` field as NOT null
##----------------------------
ALTER TABLE `kol_events` CHANGE `topic` `topic` int (50)  NOT NULL; 
  

##----------------------------
##-- kol_memberships Table
## - Modified on Dec 29th, 2010 - Changed   'name' field to 'institute_id'
##----------------------------
ALTER TABLE `kol_memberships` CHANGE `name` `institute_id` int (50)  NOT NULL ;



##----------------------------
##-- kol_memberships Table
## - Modified on Dec 29th, 2010 - Changed   'engagement_type' field to 	'engagement_id'
##----------------------------
ALTER TABLE `kol_memberships` CHANGE `engagement_type` `engagement_id` int (50)  NOT NULL ;


##----------------------------
##-- kol_educations Table
## - Modified on Dec 29th, 2010 - Changed   `institute_name` field to 	`institute_id`
##----------------------------
ALTER TABLE `kol_educations` CHANGE `institute_name` `institute_id` int (50)  NOT NULL;


##----------------------------
##-- kol_events Table
## - Modified on Dec 29th, 2010 - Changed   `event_name` field to `event_id`
##----------------------------
ALTER TABLE `kol_events` CHANGE `event_name` `event_id` int (50)  NOT NULL; 



##----------------------------
##-- kol_educations Table
## - Modified on Dec 29th, 2010 - Added 1 more field - honor_name, Changed   `year` field to integer(11) NULL
##----------------------------
ALTER TABLE `kol_educations` ADD COLUMN `honor_name` varchar (250)  NOT NULL  AFTER `specialty`,CHANGE `year` `year` int (11)  NULL; 

##----------------------------
##-- kols Table
## - Modified on Jan 5th, 2011 - Added 2 more field - is_pubmed_processed,`is_clinical_trial_processed`
##----------------------------
ALTER TABLE kols ADD COLUMN is_pubmed_processed TINYINT(1) NOT NULL;
ALTER TABLE `kols` ADD COLUMN `is_clinical_trial_processed` TINYINT (1)  NOT NULL;

##----------------------------
##-- organizations Table
##-- Modified on Jan 19th, 2011 
##--`organizations` Table has been changed as per the new CR
##----------------------------
ALTER TABLE `organizations` DROP COLUMN `comments`, DROP COLUMN `myspace`,CHANGE `type` `type_id` int (50)  NOT NULL,ADD COLUMN `founded` varchar (50)  NULL  AFTER `company_logo`;

##----------------------------
##-- kol_clinical_trials Table
## - Modified on Jan 19th, 2011 - Added  id as primari key and made 'id' as AUTO_INCREMENT
##----------------------------
ALTER TABLE kol_clinical_trials    CHANGE `id` `id` INT(50) NOT NULL AUTO_INCREMENT,    ADD PRIMARY KEY(`id`);

ALTER TABLE publications    ADD COLUMN `article_date` VARCHAR(50) NULL AFTER `language`;

ALTER TABLE clinical_trials  CHANGE `phase` `phase` VARCHAR(10) NULL ;


##----------------------------
##-- conf_event_types Table
## - Modified on Feb 5th, 2011 - Deleted 'Grand Rounds' from the list. its Autoincrement Id=3, 
## Right now not SETting any value to Autoincrement Id=3
##----------------------------
DELETE FROM `conf_event_types` WHERE `id`='3';

##----------------------------
##-- kol_publications Table
##-- Modified on Feb 22nd, 2011 
##--Modified in order to save the publication authorship position
##----------------------------
ALTER TABLE kol_publications ADD COLUMN auth_pos INT(10) NOT NULL;

##----------------------------
##-- interactions Table
##-- Modified on Mar 5th, 2011 
##--Modified the types
##----------------------------
ALTER TABLE `interactions`     CHANGE `role` `role` INT(50) NULL ,     CHANGE `category` `category` INT(50) NULL ,     CHANGE `therapeutic_area` `therapeutic_area` INT(50) NULL ;

##----------------------------
##-- cLIENT_USERS Table
##-- Modified on Mar 9th, 2011 
##--Added 3 columns 'is_analyst','user_role_id' and 'user_last_login
##----------------------------

ALTER TABLE `client_users` ADD COLUMN `is_analyst` tinyint(11) default '0' AFTER `contact`,ADD COLUMN  `user_role_id` int(11) default '1' AFTER `is_analyst`,ADD COLUMN `user_last_login` datetime default NULL AFTER `user_role_id` ;

##----------------------------
##-- interactions Table
##-- Modified on Mar 15th, 2011 
##--Added 4 columns 
##----------------------------

ALTER TABLE interactions ADD created_by INT(50) NOT NULL; 
ALTER TABLE interactions ADD created_on DATE NOT NULL; 
ALTER TABLE interactions ADD modified_by INT(50) NOT NULL; 
ALTER TABLE interactions ADD modified_on DATE NOT NULL; 

##----------------------------
##-- kol_publications TABLE
##-- Modified on Mar 21th, 2011 
##--Added 1 columns  "is_verified"
##----------------------------

ALTER TABLE `kol_publications` ADD COLUMN is_verified tinyint(1) NOT NULL default '0' AFTER `is_DELETEd`;

##----------------------------
##-- kol_memberships TABLE
##-- Modified on April 1st, 2011 
##-- Role is Refering in the form of all affiliations... so We need to get the role data from database
##----------------------------

UPDATE kol_memberships SET role=title WHERE role='' 

##----------------------------
##-- pubmed_authors TABLE
##-- Modified on Apr 7th, 2011 
##--Added  columns  "alias_id" "alias_last_name" "alias_initials" and "alias_fore_name"
##--in order to save the alias co author details, for name disambiguation
##----------------------------

ALTER TABLE `pubmed_authors`     ADD COLUMN `alias_id` INT(50) NULL AFTER `is_name_valid`,     ADD COLUMN `alias_last_name` VARCHAR(150) NULL AFTER `alias_id`,     ADD COLUMN `alias_initials` VARCHAR(50) NULL AFTER `alias_last_name`,     ADD COLUMN `alias_fore_name` VARCHAR(150) NULL AFTER `alias_initials`;

##----------------------------
##-- pubmed_authors TABLE
##-- Modified on Apr 7th, 2011 
##--Added  column  "alias_id" 
##--in order to save the alias co author details, for name disambiguation
##----------------------------
ALTER TABLE publications_authors ADD COLUMN alias_id INT(50) NULL; 
UPDATE publications_authors SET alias_id=author_id;

##----------------------------
##-- publications,clinical_trials TABLE
##-- Modified on Apr 7th, 2011 
##--Added  column  "is_manual" 
##--in order to SET the flag Manually added publications and clinical trials
##--Changed the Datatype of 'phase' int to varchar
##----------------------------

ALTER TABLE publications ADD COLUMN `is_manual` tinyint (1) DEFAULT '0' NOT NULL;

ALTER TABLE clinical_trials ADD COLUMN `is_manual` tinyint (1) DEFAULT '0' NOT NULL;

ALTER TABLE clinical_trials CHANGE `phase` `phase` varchar (10)  NULL; 

##---------------------------
##--kol_publications TABLE
##--Modified on Apr 27th 2011
##--Making all the unverified publications as verified
##---------------------------
UPDATE kol_publications SET is_verified=1 WHERE is_DELETEd=0;

##---------------------------
##--kol_publications,kol_clinical_trials,kol_educations TABLE
##--Modified on May 07th 2011 
##--Added the New column client_id to keep track of clients
##--@author Ambarish
##--@since 2.2
##---------------------------
ALTER TABLE kol_clinical_trials ADD COLUMN client_id int (11)  NULL;
ALTER TABLE kol_publications ADD COLUMN client_id int (11) NULL;
ALTER TABLE kol_educations ADD COLUMN client_id int (11) NULL;

/*Upadte Stetements to SET the client_id=1 for the existing data */
UPDATE kol_clinical_trials SET client_id=1;
UPDATE kol_publications SET client_id=1;
UPDATE kol_educations SET client_id=1;
UPDATE kol_events SET client_id=1;
UPDATE kol_memberships SET client_id=1;


##---------------------------
##--kol_memberships TABLE
##--Modified on may 5th 2011
##--Added new column 'client_id'
##--@author Vinayak
##--@since 2.2
##---------------------------
ALTER TABLE `kol_memberships` ADD COLUMN `client_id` int (11) NULL;

##---------------------------
##--kol_events TABLE
##--Modified on may 5th 2011
##--Added new column 'client_id'
##--@author Vinayak
##--@since 2.2
##---------------------------
ALTER TABLE `kol_events` ADD COLUMN `client_id` int (11) NULL;

##---------------------------
##--Added a column 'cin_num' for importing the data from 'csv' files
##--organizations TABLE
##--Modified on may 30th 2011
##--Added new column 'cin_num'
##--@author Ramesh B
##--@since 2.4
##---------------------------
ALTER TABLE organizations ADD COLUMN cin_num VARCHAR(50) NOT NULL DEFAULT 0;


##---------------------------
##--Added a column 'pin' for importing the data from 'xls' files
##--kols TABLE
##--Modified on July 4th 2011
##--Added new column 'pin'
##--@author Ambarish N
##--@since 2.5
##---------------------------
ALTER TABLE kols ADD COLUMN pin VARCHAR(50) NOT NULL DEFAULT 0;

##---------------------------
##--Added a column 'is_imported', to SET the flag for imported KOL's
##--kols TABLE
##--Modified on July 19th 2011
##--Added new column 'pin'
##--@author Ambarish N
##--@since 2.6
##---------------------------
ALTER TABLE `kols` ADD COLUMN `is_imported` TINYINT (1) DEFAULT '0' NOT NULL;


##---------------------------
##--Update a column 'is_imported'. Set flag for imported KOL's
##--Update a column 'pin'. Set Autoincrement ID as PIN for existing KOL's
##--kols TABLE
##--Modified on July 19th 2011
##--@author Ambarish N
##--@since 2.6
##---------------------------
UPDATE kols SET is_imported=1 WHERE pin <>'0';
UPDATE kols SET pin=id WHERE pin='0';

##---------------------------
##--Add unique constraint for (kol_id, pub_id)
##--
##--kol_publications TABLE
##--Modified on July 21th 2011
##--@author Ramesh B
##--@since 2.6
##---------------------------
ALTER TABLE kol_publications ADD UNIQUE INDEX(kol_id, pub_id);

##---------------------------
##--Add unique constraint on pmid
##--
##--publications TABLE
##--Modified on July 21th 2011
##--@author Ramesh B
##--@since 2.6
##---------------------------
ALTER TABLE publications ADD UNIQUE INDEX(pmid);

##---------------------------
##--Changed the CHARACTER SET from latin1(Default mysql value) to CHARACTER SET utf8 COLLATE utf8_general_ci.
##--kols,institutions,events,kol_educations,kol_memberships,kol_events TABLE
##--Modified on July 19th 2011
##--Added new column 'pin'
##--@author Ambarish N
##--@since 2.6
##---------------------------
ALTER DATABASE kolm_app DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE kols CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE institutions CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE events CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE kol_educations CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE kol_memberships CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE kol_events CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;


##---------------------------
##--Deleting the countries
##--
##--Countries,cities,regions TABLE
##-- Before deleting confirm whether they need to be DELETEd
##--@author Vinayak
##--@since 2.7
##---------------------------
DELETE FROM countries WHERE countryId  IN(4,5,6,7,8,11,12,13,16,17,19,22,25,26,27,31,32,34,35,36,
38,40,44,45,46,47,50,51,52,54,56,55,57,58,60,66,67,69,73,74,76,77,78,79,83,85,86,87,88,89,93,94,97,
98,99,101,102,103,104,106,107,108,110,121,123,124,125,127,130,131,135,136,139,140,
142,143,145,146,153,161,147,148,151,154,155,156,158,160,161,162,163,165,166,167,169,172,173,176,177,179,
180,182,183,184,188,189,191,192,196,201,204,205,206,207,208,209,212,214,216,217,218,222,
223,225,227,230,231,232,237,240,241,242,244,245,247,248,249,255,257,258,260,261,262,263,264,265,266,267,
268,269,270,272,275,55,56);

DELETE FROM regions WHERE countryId  IN(4,5,6,7,8,11,12,13,16,17,19,22,25,26,27,31,32,34,35,36,
38,40,44,45,46,47,50,51,52,54,56,55,57,58,60,66,67,69,73,74,76,77,78,79,83,85,86,87,88,89,93,94,97,
98,99,101,102,103,104,106,107,108,110,121,123,124,125,127,130,131,135,136,139,140,
142,143,145,146,153,161,147,148,151,154,155,156,158,160,161,162,163,165,166,167,169,172,173,176,177,179,
180,182,183,184,188,189,191,192,196,201,204,205,206,207,208,209,212,214,216,217,218,222,
223,225,227,230,231,232,237,240,241,242,244,245,247,248,249,255,257,258,260,261,262,263,264,265,266,267,
268,269,270,272,275,55,56);

DELETE FROM cities WHERE countryId  IN(4,5,6,7,8,11,12,13,16,17,19,22,25,26,27,31,32,34,35,36,
38,40,44,45,46,47,50,51,52,54,56,55,57,58,60,66,67,69,73,74,76,77,78,79,83,85,86,87,88,89,93,94,97,
98,99,101,102,103,104,106,107,108,110,121,123,124,125,127,130,131,135,136,139,140,
142,143,145,146,153,161,147,148,151,154,155,156,158,160,161,162,163,165,166,167,169,172,173,176,177,179,
180,182,183,184,188,189,191,192,196,201,204,205,206,207,208,209,212,214,216,217,218,222,
223,225,227,230,231,232,237,240,241,242,244,245,247,248,249,255,257,258,260,261,262,263,264,265,266,267,
268,269,270,272,275,55,56);

##---------------------------
##--Update a column 'country'. Set Country ='USA' for country 'Unitesd States' and 'UAE' for United Arab Emirates
##--Update a column 'pin'. Set Autoincrement ID as PIN for existing KOL's
##--Countries TABLE
##--
##--@author Vinayak
##--@since 2.7
##---------------------------
UPDATE countries SET country='UAE' WHERE countryId=252;
UPDATE countries SET country='USA' WHERE countryId=254;


##---------------------------
##--
##--Alter Commands for KOLM Database to include foreign key constraint with 'on DELETE cascade' for both kol_id 
##-- and org_id 
##--@date 16th Aug 2011
##--@author Laxman
##--@since 2.9
##-- Note :
##-- Remove rows in TABLEs WHERE kol_id in kols TABLE doesn't exist by following query
##-- SELECT * FROM TABLE_NAME WHERE kol_id NOT IN (SELECT id FROM kols);
##-- Remove rows in TABLEs WHERE org_id in organizations TABLE doesn't exist by following query
##-- SELECT * FROM TABLE_NAME WHERE org_id NOT IN (SELECT id FROM organizations);
##---------------------------

#Table 'clients_kols'
ALTER TABLE clients_kols modify kol_id int(11) not null, ADD CONSTRAINT fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'interactions'
ALTER TABLE interactions modify kol_id int(11) not null, ADD CONSTRAINT interaction_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_additional_contacts'
ALTER TABLE kol_additional_contacts modify kol_id int(11) not null, ADD CONSTRAINT keypeople_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_clinical_trials'
ALTER TABLE kol_clinical_trials modify kol_id int(11) not null, ADD CONSTRAINT clinicaltrial_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_educations'
ALTER TABLE kol_educations modify kol_id int(11) not null, ADD CONSTRAINT education_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_events'
ALTER TABLE kol_events modify kol_id int(11) not null, ADD CONSTRAINT events_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_memberships'
ALTER TABLE kol_memberships modify kol_id int(11) not null, ADD CONSTRAINT membership_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_publications'
ALTER TABLE kol_publications modify kol_id int(11) not null, ADD CONSTRAINT publication_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'list_kols'
ALTER TABLE list_kols modify kol_id int(11) not null, ADD CONSTRAINT list_kols_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'payment_threshholds'
ALTER TABLE payment_threshholds modify kol_id int(11) not null, ADD CONSTRAINT payment_threshholds_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'payments'
ALTER TABLE payments modify kol_id int(11) not null, ADD CONSTRAINT payments_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_personal_info'
ALTER TABLE kol_personal_info modify kol_id int(11) not null, ADD CONSTRAINT personlainfo_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'key_peoples'
ALTER TABLE key_peoples ADD CONSTRAINT keypeople_fk_org_id FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE;

#Table 'org_additional_contacts'
ALTER TABLE org_additional_contacts ADD CONSTRAINT additional_contacts_fk_org_id FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE;


##---------------------------
##--Update statements for a column 'role' 
##--Kol_events TABLE
##--
##--@author Vinayak
##--@since 3.0
##---------------------------

UPDATE kol_events SET role='Moderator' WHERE role='Moderador';

UPDATE kol_events SET role='Moderator' WHERE role='Moderate';

UPDATE kol_events SET role='Speaker' WHERE role='Speker';

UPDATE kol_events SET role='Speaker' WHERE role='Speakr';

UPDATE kol_events SET role='Program Committee Member' WHERE role='Program Committee';


##---------------------------
##--Update statements for a column  'Fax' data
##--Organizations TABLE
##--
##--@author Vinayak
##--@since 3.0
##---------------------------

UPDATE organizations SET fax='' WHERE fax='Beth Israel Deconess'; 

UPDATE organizations SET fax='' WHERE fax='GlaxoSmithKline'; 


##---------------------------
##--To SET each publication author alias to himself
##--publications_authors TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
UPDATE publications_authors SET alias_id=author_id WHERE alias_id IS NULL;

##---------------------------
##--Add a additional column 'calendar_event_id' to TABLE 'interactions' to hold id of the followup calendar event id
##--interactions TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
ALTER TABLE interactions ADD COLUMN calendar_event_id INT (10) DEFAULT 0;

##---------------------------
##--Alter commands to Add a column 'event_type' to identify the different kind of events
##--calendar_events TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
ALTER TABLE calendar_events ADD COLUMN event_type VARCHAR (50) DEFAULT 'EVENT_TYPE_GENERAL';

##---------------------------
##--Alter command to add a column 'birthday_event_id' and 'anniversary_event_id' to TABLE 'kol_personal_info' to hold id of the birthday and anniversary calendar event id
##--kol_personal_info TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
ALTER TABLE kol_personal_info ADD COLUMN birthday_event_id INT (10) DEFAULT 0;
ALTER TABLE kol_personal_info ADD COLUMN anniversary_event_id INT (10) DEFAULT 0;

##---------------------------
##--Alter command to add a column 'objective_id' in order to associate a interaction with plan
##--interactions TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
ALTER TABLE interactions ADD COLUMN objective_id INT(10);


##---------------------------
##--Alter command to add a column 'user_id' 
##--kol_publications and kol_clinical_trials  TABLE
##--
##--@author Vinayak B
##--@since 3.1
##---------------------------

ALTER TABLE kol_publications ADD COLUMN user_id INT(10);

ALTER TABLE kol_clinical_trials ADD COLUMN user_id INT(10);

##---------------------------
##--Update a column 'cin_num'
##--Update a column 'cin_num'. Set Autoincrement ID as cin_num for existing Organizations
##--Organizations TABLE
##--Modified on sept 19th 2011
##--@author Vinayak
##--@since 3.1
##---------------------------

UPDATE organizations SET cin_num=id WHERE cin_num=0

##---------------------------
##--Alter command to rename the mode name from 'In-person' to 'Face To Face'
##--interactions_modes TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
UPDATE interactions_modes SET NAME='Face To Face' WHERE NAME='In-person';

##---------------------------
##--Delete command to DELETE the entry 'Mode1' as it is not a mode
##--interactions_modes TABLE
##--
##--@author Ramesh B
##--@since 3.1
##---------------------------
DELETE FROM interactions_modes WHERE NAME='Mode1';

##--@author Laxman K
##--@since 3.1.2
##--For japanese demonstration, WHERE DmaId, county and code are temporary  
##
##-- for New state/provinence 'Island of Honshu' 
##-- New cities Shimonoseki, Kyoto and Fukushima


INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`) VALUES (5400,122,'Island of Honshu','IH','JA00');

INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) VALUES (42902,122,2370,'Shimonoseki',33.57,130.56,'+09:00',0,'shim',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`)	VALUES (42903,122,5400,'Kyoto',35.0042,135.46,'+09:00',0,'kyot',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) VALUES (42904,122,2333,'Fukushima',37.46,140.28,'+09:00',0,'fuku',NULL);

##---------------------------
##--Alter command to add a column 'First name','last name','phone','country','title' 
##--client_users TABLE
##--
##--@author Vinayak B
##--@since 3.2
##---------------------------
ALTER TABLE client_users ADD COLUMN first_name varchar(250) NOT NULL,ADD COLUMN last_name varchar(250) NOT NULL,ADD COLUMN title varchar(250) NOT NULL,ADD COLUMN company_name varchar(250) NOT NULL,ADD COLUMN phone varchar(250) NOT NULL,ADD COLUMN country int(11) NOT NULL;

##---------------------------
##--Update statements to SET user name to first name
##--client_users TABLE
##--
##--@author Vinayak B
##--@since 3.2

UPDATE client_users SET first_name=user_name;
UPDATE client_users SET user_name=email; 


##---------------------------
##--Update statements to SET year to start_yesr  name to first name
##--client_users TABLE
##--
##--@author Vinayak B
##--@since 3.2

UPDATE kol_educations SET start_date=year WHERE type="honors_awards"

UPDATE kol_educations SET start_date='' WHERE start_date = 0 

UPDATE kol_educations SET end_date='' WHERE end_date = 0 

##--@author Laxman K
##--@since 3.2
##
##-- New city 'wan chai'


INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) VALUES (42905,109,646,'Wan Chai ',22.279,114.17,'+08:00',0,'wanc',NULL);


##---------------------------
##--Update statements to SET Guests client id=2
##--client_users TABLE
##--
##--@author Vinayak B
##--@since 3.2

select id from clients order by id desc limit 0,1

UPDATE clients SET id=9 WHERE id=2

UPDATE client_users SET client_id=9 WHERE client_id=2

INSERT clients(`id`,`name`) VALUES('2','Guests')

##---------------------------
##--Update query to copy the authersgip positions from 'publications_authors' 
##--TABLE to 'kol_publications' for all the publications which are added extranaly
##--kol_publications TABLE
##--
##--@author Ramesh B
##--@since 3.2
##---------------------------
UPDATE pubmed_authors 
LEFT JOIN publications_authors ON  publications_authors.author_id=pubmed_authors.id
LEFT JOIN publications ON publications_authors.pub_id=publications.id
LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
SET kol_publications.auth_pos=publications_authors.position
WHERE publications.pmid < 0;

##---------------------------
##--Set 'fore_name' as blank if it is null, it helps in getting the matching co-authors
##--pubmed_authors TABLE
##--
##--@author Ramesh B
##--@since 3.2
##---------------------------
UPDATE pubmed_authors SET fore_name='' WHERE  fore_name IS NULL

##--@author Laxman K
##--@since 3.3
##
##-- New country Bahamas with its states and cities

INSERT  INTO `countries`
(`CountryId`,`Country`,`FIPS104`,`ISO2`,`ISO3`,`ISON`,`Internet`,`Capital`,`MapReference`,`NationalitySingular`,`NationalityPlural`,`Currency`,`CurrencyCode`,`Population`,`Title`,`Comment`) 
VALUES (276,'Bahamas ','BS','--','-- ','--','--','Nassau',' Central America and the Caribbean ','','','Bahamian Dollar','BSD',0,' Commonwealth of the Bahamas ','');



INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5401,276,'Eleuthera','ET','BF39');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5402,276,'Exuma','EX','BF10');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5403,276,'Grand Bahama','GB','BF41');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5404,276,'Inagua','IN','BF13');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5405,276,'New Providence','NP','BF23');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5406,276,'Rum Cay','RC','BF49');
INSERT  INTO `regions`(`RegionID`,`CountryID`,`Region`,`Code`,`ADM1Code`)
 VALUES (5407,276, 'San Salvador','SS','BF35');


INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42906,276, 5405,'Nassau',25.06,77.345,'-05:00',0,'nass',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42907,276, 5403,'High Rock',26.63,78.28,'-05:00',0,'hiro',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42908,276, 5403,'Freeport',26.54,78.64,'-05:00',0,'port',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42909,276, 5403,'West End',26.69,78.97,'-05:00',0,'wend',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42910,276, 5403,'Sweeting Cay',26.60,78.88,'-05:00',0,'scay',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42911,276, 5401,'Freetown',24.77,76.27,'-05:00',0,'fton',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42912,276, 5401,'Spanish Wells',25.54,76.75,'-05:00',0,'swel',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42913,276, 5401,'Dunmore Town',25.50,76.63,'-05:00',0,'dton',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42914,276, 5401,'Rock Sound',24.90,76.20,'-05:00',0,'rock',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42915,276, 5407,'Cockburn Town',24.03,74.52,'-05:00',0,'cbur',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42916,276, 5402,'George Town',23.52,75.78,'-05:00',0,'geot',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42917,276, 5404,'Matthew Town',20.96,73.68,'-05:00',0,'matt',NULL);
INSERT  INTO `cities`(`CityId`,`CountryID`,`RegionID`,`City`,`Latitude`,`Longitude`,`TimeZone`,`DmaId`,`County`,`Code`) 
VALUES (42918,276, 5406,'Port Nelson',23.66,74.83,'-05:00',0,'nelp',NULL);


##--@author Laxman K
##--@since 3.4
##
##-- Table to store monthly events report of respective clients 
CREATE TABLE `client_events` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `region_country` varchar(255) default NULL,
  `event_date` date default NULL,
  `presenter` varchar(255) default NULL,
  `meeting_type` varchar(255) default NULL,
  `no_of_attendees` int(11) default NULL,
  `topics` varchar(255) default NULL,
  `feedback` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_eventclient_id` (`client_id`),
  KEY `fk_eventuser_id` (`user_id`),
  CONSTRAINT `fk_eventclient_id` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eventuser_id` FOREIGN KEY (`user_id`) REFERENCES `client_users` (`id`) ON DELETE CASCADE
)



##---------------------------
##--
##--Alter Commands for KOLM Database to change the data type of varchar for kol_id/org_id INTO int 
##-- 
##--@date 3rd DEC 2011
##--@author Laxman K
##--@since 3.4.2
##-- 
##---------------------------

ALTER TABLE kol_educations CHANGE kol_id kol_id int(11);

ALTER TABLE kol_events CHANGE kol_id kol_id int(11);

ALTER TABLE kol_memberships CHANGE kol_id kol_id int(11);

ALTER TABLE kol_personal_info CHANGE kol_id kol_id int(11);

ALTER TABLE kol_publications CHANGE kol_id kol_id int(11);

ALTER TABLE list_kols CHANGE kol_id kol_id int(11);

ALTER TABLE plans CHANGE kol_id kol_id int(11);

ALTER TABLE interactions CHANGE kol_id kol_id int(11);

ALTER TABLE org_additional_contacts CHANGE org_id org_id int(11);

##---------------------------
##--
##--Alter Commands for KOLM Database to include foreign key constraint with 'on DELETE cascade' for both kol_id 
##-- and org_id 
##--@date 3rd DEC 2011
##--@author Laxman K
##--@since 3.4.2
##-- Note :
##-- Remove rows in TABLEs WHERE kol_id in kols TABLE doesn't exist by following query
##-- SELECT * FROM TABLE_NAME rt WHERE rt.kol_id NOT IN(SELECT id FROM kols)
##-- SELECT * FROM TABLE_NAME rt WHERE rt.org_id NOT IN(SELECT id FROM organizations)
##---------------------------

# To select the 'kol_id' from referenced TABLE WHERE kol_id/org_id not in kols/organization TABLE
SELECT * FROM TABLE_NAME rt WHERE rt.kol_id NOT IN(SELECT id FROM kols)
SELECT * FROM TABLE_NAME rt WHERE rt.org_id NOT IN(SELECT id FROM organizations)

# To DELETE the record from referenced TABLE WHERE kol_id/org_id not in kols/organization TABLE
DELETE FROM TABLE_NAME rt WHERE rt.kol_id NOT IN(SELECT id FROM kols)
DELETE from TABLE_NAME rt WHERE rt.org_id not in(select id from organizations)

#Table 'clients_kols'
ALTER TABLE clients_kols MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'interactions'
ALTER TABLE interactions MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT interaction_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_additional_contacts'
ALTER TABLE kol_additional_contacts MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT keypeople_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_clinical_trials'
ALTER TABLE kol_clinical_trials MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT clinicaltrial_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_educations'
ALTER TABLE kol_educations MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT education_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_events'
ALTER TABLE kol_events MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT events_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_memberships'
ALTER TABLE kol_memberships MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT membership_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_publications'
ALTER TABLE kol_publications MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT publication_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'list_kols'
ALTER TABLE list_kols MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT list_kols_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'payment_threshholds'
ALTER TABLE payment_threshholds MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT payment_threshholds_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'payments'
ALTER TABLE payments MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT payments_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'kol_personal_info'
ALTER TABLE kol_personal_info MODIFY kol_id int(11) NOT NULL, ADD CONSTRAINT personlainfo_fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

#Table 'key_peoples'
ALTER TABLE key_peoples ADD CONSTRAINT keypeople_fk_org_id FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE;

#Table 'org_additional_contacts'
ALTER TABLE org_additional_contacts ADD CONSTRAINT additional_contacts_fk_org_id FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE;

# To DELETE the record from referenced TABLE WHERE kol_idnot in kols TABLE
DELETE FROM list_kols WHERE kol_id NOT IN (SELECT id FROM kols)

##---------------------------
##--
##--Alter Commands change country name from 'The Bahamas' to only 'Bahamas'
##-- 
##--@date 3rd DEC 2011
##--@author Laxman K
##--@since 3.4.2
##-- 
##---------------------------
UPDATE countries SET Country='Bahamas' WHERE CountryId=276

##---------------------------
##--
##--Alter Commands for adding indexes for columns to increase the performance 
##-- 
##--@date 15th DEC 2011
##--@author Laxman K
##--@since 3.5.1
##-- 
##---------------------------

ALTER TABLE `kolm_app`.`kol_publications`ADD UNIQUE `kolpub_pub_kol_id` (`kol_id`, `pub_id`);

ALTER TABLE `kolm_app`.`regions` ADD INDEX `regions_country_id` (`CountryID`);
ALTER TABLE `kolm_app`.`cities` ADD INDEX `RegionID` (`RegionID`);
ALTER TABLE `kolm_app`.`kol_publications` ADD INDEX `kolpub_isdel_isver_kol_id` (`is_DELETEd`,`is_verified`, `kol_id`);
ALTER TABLE `kolm_app`.`kol_educations` ADD INDEX `koledu_type_kol_id` (`type`, `kol_id`);


##---------------------------
##--
##--Alter commands to add indexs for increasing the performacne of 'influence map' related queries
##-- 
##--@date 15th DEC 2011
##--@author Ramesh B
##--@since 3.6
##-- 
##---------------------------
/* Indexes for kol_publications TABLE*/
ALTER TABLE kol_publications ADD INDEX kol_id (kol_id);

/* Indexes for kol_events TABLE*/
ALTER TABLE kol_events ADD INDEX kol_id (kol_id);
ALTER TABLE kol_events ADD INDEX event_id (event_id);
ALTER TABLE kol_events ADD INDEX kol_id_event_id (kol_id, event_id);

/* Indexes for kol_membership TABLE*/
ALTER TABLE kol_memberships ADD INDEX kol_id (kol_id);
ALTER TABLE kol_memberships ADD INDEX institute_id (institute_id);
ALTER TABLE kol_memberships ADD INDEX TYPE (TYPE);

##---------------------------
##--
##--Alter commands to modify the the column 'time' to 'fromtime'
##--Add anothor column 'totime'
##-- 
##--@date 12th Apr 2011
##--@author Ramesh B
##--@since 3.6
##-- 
##---------------------------
ALTER TABLE interactions ADD COLUMN totime TIME;
ALTER TABLE interactions CHANGE TIME fromtime time;


 /**
 * @TABLE users_analytics
 * @description Added a another column 'is_login_failed' 
 * @author Ramesh B
 * @since 20th Apr 2012
 * @version 3.8
 * @modified  - Added a another column 'is_login_failed'
 */
ALTER TABLE users_analytics ADD COLUMN is_login_failed TINYINT(1) DEFAULT 0;

 /**
 * @TABLE client_users
 * @description Added a column mem_pic
 * @author Vinayak
 * @since 9 may,2012
 * @version 3.10
 * @modified  - Added a another column 'mem_pic'


ALTER TABLE client_users ADD COLUMN `mem_pic` VARCHAR(200) DEFAULT NULL;

 /**
 * @TABLE KOLS
 * @description Added a column status 
 * @author Vinayak
 * @since 1 jan,2012
 * @version 4.2
 * @modified  - Added a another column 'mem_pic'
ALTER TABLE kols ADD COLUMN status VARCHAR(255) null;



 /**
* Requirement - Cities "Calcutta" and "Kolkata" are present on dropdown.so we need to keep 'Kolkata' only because 
  Kolkata is new name of Calcutta
* Alter command to DELETE 'Calcutta' form cities TABLE and UPDATE city_id of city "Kolkata" in kols and kol_evnets  * TABLE WHERE city='Calcutta',
* Run one by one,dont excute all in once bacause first we need to get City_id of "Kolkata" and upadte this id WHERE  * ccity='Calcutta'. then DELETE  city='Kolkata' from Cities TABLE...for more reference check mantisbt- Bug id=271
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
select * from cities 
WHERE city='Calcutta' or city='Kolkata';

UPDATE kols SET city_id = 42561 WHERE city_id=6452 and state_id=2194; 
UPDATE kol_events SET city_id = 42561 WHERE city_id=6452 and state_id=2194; 
UPDATE organizations SET city_id = 42561 WHERE city_id=6452 and state_id=2194;

DELETE from cities WHERE cityId=6452 and RegionId=2194 and city="Calcutta";


/**
*Requirement - Cities "Dehra Dun" and "Dehradun" are present on dropdown.so we need to keep any one of out theses   cities because both are same .

* Alter command to DELETE city "Dehra Dun" form cities TABLE and UPDATE city_id of city "Dehradun" in kols and         kol_evnets  TABLE WHERE city='Dehra Dun',* 
* Run one by one,dont excute all in once bacause first we need to get City_id of "Dehradun" and upadte this id WHERE   ccity='Dehra Dun'. then DELETE  city='Dehra Dun' from Cities TABLE...for more reference check mantisbt- Bug *id=271
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
select * from cities WHERE city="Dehra Dun" or city="Dehradun";

UPDATE kols SET city_id = 42827 WHERE city_id=41683 and state_id=5259; 
UPDATE kol_events SET city_id = 42827 WHERE city_id=41683 and state_id=5259 ;
UPDATE organizations SET city_id = 42827 WHERE city_id=41683 and state_id=5259; 

DELETE from cities WHERE cityId=41683 and RegionId=5259 and city="Dehra Dun";


/**
 *Requirement - Cities "Naini tal" and "DNainital" are present on dropdown .so we need to keep any one of out theses   because both are same.
 
* Alter command to DELETE "Naini tal" form cities TABLE and UPDATE city_id of city "Nainital" in kols and              kol_evnets  TABLE WHERE city='Naini tal',* Run one by one,dont excute all in once bacause first we need to get      City_id of "Nainital" and upadte this id WHERE   ccity='Naini tal'. then DELETE  city='Dehra Dun' from Cities      TABLE...for more reference check mantisbt- Bug id=271
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
select * from cities WHERE city="Naini tal" or city="Nainital";

UPDATE kols SET city_id = 42615 WHERE city_id=42035 and state_id=5259; 
UPDATE kol_events SET city_id = 42615 WHERE city_id=42035 and state_id=5259; 
UPDATE organizations SET city_id = 42615 WHERE city_id=42035 and state_id=5259; 

DELETE from cities WHERE cityId=42035 and RegionId=5259 and city="Naini tal";


/**
 *Requirement - Cities "Banaras" and "Varanasi" are present on dropdown .so we need to keep 'Varanasi' only because 
  Varanasi is new name of Banaras
 
* Alter command to DELETE "Banaras" form cities TABLE and UPDATE city_id of city "Varanasi" in kols and              kol_evnets  TABLE WHERE city='Banaras',
* Run one by one,dont excute all in once bacause first we need to get       City_id of "Varanasi" and upadte this id WHERE   ccity='Banaras'. then DELETE  city='Banaras' from Cities       TABLE...for more reference check mantisbt- Bug id=271
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/


select * from cities WHERE city="Banaras" or city="Varanasi";

UPDATE kols SET city_id = 42778 WHERE city_id=42780 and state_id=2193; 
UPDATE kol_events SET city_id = 42778 WHERE city_id=42780 and state_id=2193;  
UPDATE organizations SET city_id = 42778 WHERE city_id=42780 and state_id=2193; 

DELETE from cities WHERE cityId=42780 and RegionId=2193 and city="Banaras";


/**
 *Requirement -Udaipur is a city in rajasthan and not in tripura.so DELETE city "udaypur" WHERE state="tripura" 
 
*
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
UPDATE kols SET city_id = 12554 , state_id=2190 WHERE city_id=42762; 
UPDATE kol_events SET city_id = 12554 , state_id=2190 WHERE city_id=42762;
UPDATE organizations SET city_id = 12554 , state_id=2190 WHERE city_id=42762;


DELETE from cities WHERE city="Udaipur" and regionId="2192";


/**
 *Requirement - Cities "Chennai, madras" are present on dropdown .so we need to keep 'Chennai' only because 
  Chennai is new name of madras
 
* Alter command to DELETE "madras" form cities TABLE and UPDATE city_id of city "Chennai" in kols and               kol_evnets  TABLE WHERE city='Banaras',
* Run one by one,dont excute all in once bacause first we need to get  City_id of "Chennai" and upadte this id WHERE   ccity='madras'. then DELETE  city='madras' from Cities       TABLE...for more reference check mantisbt- Bug id=271
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
select * from cities WHERE city="Chennai" or city="madras"

UPDATE kols SET city_id = 13147 WHERE city_id=42802 and state_id=2191; 
UPDATE kol_events SET city_id = 13147 WHERE city_id=42802 and state_id=2191;  
UPDATE organizations SET city_id = 13147 WHERE city_id=42802 and state_id=2191; 

DELETE from cities WHERE cityId=42802 and RegionId=2191 and city="madras";

/**
 *Requirement :Cites Bhubaneshwar, bhubaneswar are present in dropdown:use any one out of these and DELETE 1
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/

UPDATE kols SET city_id = 6451 WHERE city_id=42476 and state_id=2187; 
UPDATE kol_events SET city_id = 6451 WHERE city_id=42476 and state_id=2187; 
UPDATE organizations SET city_id = 6451 WHERE city_id=42476 and state_id=2187; 

DELETE from cities WHERE cityId=42476 and RegionId=2187 and city="Bhubaneswar";


/**
 *modify region "Pondicherry" to "Pudicherry"
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
UPDATE regions SET Region="Pudicherry" WHERE Region="Pondicherry";
UPDATE cities SET city="Pudicherry" WHERE city="Pondicherry";


/**
 *Requirement :Cites Raurkela,Rourkela are present in dropdown:use any one out of these and DELETE 1
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/

select * from cities WHERE city="Raurkela" or city="Rourkela";

UPDATE kols SET city_id = 41924 WHERE city_id=42687 and state_id=2187; 
UPDATE kol_events SET city_id = 41924 WHERE city_id=42687 and state_id=2187; 
UPDATE organizations SET city_id = 41924 WHERE city_id=42687 and state_id=2187; 

DELETE from cities WHERE cityId=42687 and RegionId=2187 and city="Rourkela";

/**
 *Requirement :Cites Bombay,mumbai are present in dropdown:use any one out of these and DELETE 1
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
select * from cities WHERE city="Bombay" or city="mumbai";

UPDATE kols SET city_id = 6457 WHERE city_id=42603 and state_id=2182; 
UPDATE kol_events SET city_id = 6457 WHERE city_id=42603 and state_id=2182;  
UPDATE organizations SET city_id = 6457 WHERE city_id=42603 and state_id=2182; 

DELETE from cities WHERE cityId=42603 and RegionId=2182 and city="Bombay";

/**
 *Modify city name "Calicut" to "Khozikhode" and
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
*/
UPDATE cities SET city="Khozikhode" WHERE city="Calicut";

select * from cities WHERE city="Cochin" or city="Kochi";
UPDATE kols SET city_id = 42559 WHERE city_id=18348 and state_id=2179; 
UPDATE kol_events SET city_id = 42559 WHERE city_id=18348 and state_id=2179; 
UPDATE organizations SET city_id = 42559 WHERE city_id=18348 and state_id=2179;

DELETE from cities WHERE cityId=18348 and RegionId=2179 and city="Cochin";

/**
 *Cites Shimla,simla are present in dropdown:use any one out of these and DELETE 1
* @author Vinayak
* @since 1 jan,2012
* @v
*/

select * from cities WHERE city="Shimla" or city="simla"
UPDATE kols SET city_id = 4064 WHERE city_id=42716 and state_id=2177; 
UPDATE kol_events SET city_id = 4064 WHERE city_id=42716 and state_id=2177; 
UPDATE organizations SET city_id = 4064 WHERE city_id=42716 and state_id=2177; 

DELETE from cities WHERE cityId=42716 and RegionId=2177 and city="Shimla";

/** 
 *Cites Delhi,dilli,new delhi are present in dropdown:use any one out of these and DELETE 2
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/
select * from cities WHERE city="Delhi" or city="dilli" or city="new delhi"

UPDATE kols SET city_id = 13690 WHERE city_id=14799 and state_id=2174; 
UPDATE kol_events SET city_id = 13690 WHERE city_id=14799 and state_id=2174; 
UPDATE organizations SET city_id = 13690 WHERE city_id=14799 and state_id=2174; 

UPDATE kols SET city_id = 13690 WHERE city_id=42629 and state_id=2174; 
UPDATE kol_events SET city_id = 13690 WHERE city_id=42629 and state_id=2174; 
UPDATE organizations SET city_id = 13690 WHERE city_id=42629 and state_id=2174; 


DELETE from cities WHERE cityId=14799 and RegionId=2174 and city="New Delhi";

DELETE from cities WHERE cityId=42629 and RegionId=2174 and city="Dilli";

/** 
 *Noida is in UP and not in Assam.move the city noida to Up nad  DELETE it form Assam
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/

select * from regions WHERE regionId in (2170,2193);

UPDATE kols SET city_id = 42631,state_id=2193 WHERE city_id=41696 and state_id=2170; 
UPDATE kol_events SET city_id = 42631,state_id=2193 WHERE city_id=41696 and state_id=2170; 
UPDATE organizations SET city_id = 42631,state_id=2193 WHERE city_id=41696 and state_id=2170; 

DELETE from cities WHERE cityId=41696 and RegionId=2170 and city="Noida";


/** 
 *Move City "gadag" to karnataka
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/
select * from regions WHERE region='Karnataka';


UPDATE cities SET regionId=2185 WHERE city="gadag";

UPDATE kols SET state_id=2185 WHERE city_id=42863;
UPDATE kol_events SET state_id=2185 WHERE city_id=42863;
UPDATE organizations SET state_id=2185 WHERE city_id=42863;


/** 
 * modify name of state Toshkent" to "Tashkent" and "Dubayy" to Dubai and kabol to kabul
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/
UPDATE regions SET region="Tashkent" WHERE region="Toshkent";

UPDATE regions SET region="Dubai" WHERE region="Dubayy";

UPDATE regions SET region="Kabul" WHERE region="kabol";

/** 
 * Bermu,Manmar  are present in Country dropdown:"Myanmar is the Original name"
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/
select * from countries WHERE countryId in (39,170);

UPDATE regions SET countryId=39 WHERE countryId=170;
UPDATE cities SET countryId=39 WHERE countryId=170;
UPDATE kols SET country_id=39 WHERE country_id=170;
UPDATE kol_events SET country_id=39 WHERE country_id=170;
UPDATE organizations SET country_id=39 WHERE country_id=170;
DELETE from countries WHERE countryId=170;
UPDATE countries SET country="Myanmar" WHERE country="Burma";

/** 
 * Adde the column approved_by and Status INTO KOLs TABLE
* @author Vinayak
* @since 1 jan,2012
* @version 4.2 
**/

Alter TABLE kols add column approved_by int(11) null;
Alter TABLE kols add column status varchar(255) null;
Alter TABLE organizations add column status varchar(260);

/** 
 * Update the column "engagement_type"
* @author Vinayak

* @version 4.4
**/

UPDATE engagement_types SET engagement_type="Clinical Practice" WHERE engagement_type="Practice";

UPDATE kol_events SET role='Member' WHERE role ='Abstract Grader';
UPDATE kol_events SET role='Member' WHERE role ='Abstract Reviewer';
UPDATE kol_events SET role='Member' WHERE role ='Activity Director';
UPDATE kol_events SET role='Member' WHERE role ='Advisor';
UPDATE kol_events SET role='Member' WHERE role ='Basic Research Committee, Member';
UPDATE kol_events SET role='Member' WHERE role ='DEWS Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Diagnosis Subcommittee Member';
UPDATE kol_events SET role='Member' WHERE role ='Familial Hypercholesterolemia Expert Panel, Member';
UPDATE kol_events SET role='Member' WHERE role ='International Advisory Board Member';
UPDATE kol_events SET role='Member' WHERE role ='Organizer';
UPDATE kol_events SET role='Member' WHERE role ='International Advisory Board, Member';
UPDATE kol_events SET role='Member' WHERE role ='International Advisory Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='International Program Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='International Scientific Committee, Member';
UPDATE kol_events SET role='Member' WHERE role ='Lab Staff';
UPDATE kol_events SET role='Member' WHERE role ='Local Organising Committee, Member';
UPDATE kol_events SET role='Member' WHERE role ='Member';
UPDATE kol_events SET role='Member' WHERE role ='National Institutes Of Health Liaison Committee, M';
UPDATE kol_events SET role='Member' WHERE role ='Nominating Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Organizing Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Representative';
UPDATE kol_events SET role='Member' WHERE role ='IMAST Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Planning Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Program Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Advisory Board Member';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Committee, Member';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Organization Member';
UPDATE kol_events SET role='Member' WHERE role ='Abstract Reviewer';
UPDATE kol_events SET role='Member' WHERE role ='Advisor';
UPDATE kol_events SET role='Member' WHERE role ='Chief Advisor';
UPDATE kol_events SET role='Member' WHERE role ='Chief Organizer';
UPDATE kol_events SET role='Member' WHERE role ='Chief Patron';
UPDATE kol_events SET role='Member' WHERE role ='Convenor';
UPDATE kol_events SET role='Member' WHERE role ='Co-Organizer';
UPDATE kol_events SET role='Member' WHERE role ='Co-Secretary';
UPDATE kol_events SET role='Member' WHERE role ='Executive Secretary';
UPDATE kol_events SET role='Member' WHERE role ='Finance Secretary';
UPDATE kol_events SET role='Member' WHERE role ='General Secretary';
UPDATE kol_events SET role='Member' WHERE role ='Joint Secretary';
UPDATE kol_events SET role='Member' WHERE role ='Member';
UPDATE kol_events SET role='Member' WHERE role ='Organiser';
UPDATE kol_events SET role='Member' WHERE role ='Organizer';
UPDATE kol_events SET role='Member' WHERE role ='Reviewer';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Consultant';
UPDATE kol_events SET role='Member' WHERE role ='Secretary';
UPDATE kol_events SET role='Member' WHERE role ='Secretary General';
UPDATE kol_events SET role='Member' WHERE role ='Supervisor';
UPDATE kol_events SET role='Member' WHERE role ='Treasurer';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Program Board, Member';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Program Organizer';
UPDATE kol_events SET role='Member' WHERE role ='Facilitator';
UPDATE kol_events SET role='Member' WHERE role ='Challenging Case Reviewer';
UPDATE kol_events SET role='Member' WHERE role ='Scientific Program Reviewer';
UPDATE kol_events SET role='Member' WHERE role ='Spine Instructional Course Subcommittee Member';
UPDATE kol_events SET role='Member' WHERE role ='Steering Committee Member';
UPDATE kol_events SET role='Member' WHERE role ='Travel Award Committee Member';
UPDATE kol_events SET role='Speaker' WHERE role ='Lecturer';
UPDATE kol_events SET role='Speaker' WHERE role ='Invited Lecture';
UPDATE kol_events SET role='Chair' WHERE role ='Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Chair Reviewer';
UPDATE kol_events SET role='Chair' WHERE role ='Chairman';
UPDATE kol_events SET role='Chair' WHERE role ='Chairperson';
UPDATE kol_events SET role='Chair' WHERE role ='Course Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Invited Session Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Organising Committee Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Planning Committee Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Program Chair';
UPDATE kol_events SET role='Chair' WHERE role ='Scientific Committee, Chairman';
UPDATE kol_events SET role='Chair' WHERE role ='Scientific Program Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Co Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Co-Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Co-Chairman';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Co-Chairperson';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Course Co-Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Workgroup Co-Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Vice Chair';
UPDATE kol_events SET role='Co-Chair' WHERE role ='Vice-Chair';
UPDATE kol_events SET role='Coordinator' WHERE role ='Coordinator';
UPDATE kol_events SET role='Coordinator' WHERE role ='Coordinator';
UPDATE kol_events SET role='Coordinator' WHERE role ='Co-Ordinator';
UPDATE kol_events SET role='Coordinator' WHERE role ='Course Coordinator';
UPDATE kol_events SET role='Coordinator' WHERE role ='Course Co-Ordinator';
UPDATE kol_events SET role='Coordinator' WHERE role ='Facilitator';
UPDATE kol_events SET role='Faculty' WHERE role ='Expert Faculty';
UPDATE kol_events SET role='Faculty' WHERE role ='Faculty';
UPDATE kol_events SET role='Faculty' WHERE role ='Faculty: Forum Planning Committee';
UPDATE kol_events SET role='Faculty' WHERE role ='Instructor';
UPDATE kol_events SET role='Faculty' WHERE role ='Chief Instructor';
UPDATE kol_events SET role='Faculty' WHERE role ='Senior Instructor';
UPDATE kol_events SET role='Faculty' WHERE role ='Leader';
UPDATE kol_events SET role='Faculty' WHERE role ='Operator';
UPDATE kol_events SET role='Faculty' WHERE role ='Stream Lead';
UPDATE kol_events SET role='Participant' WHERE role ='Author';
UPDATE kol_events SET role='Participant' WHERE role ='Particiapant';
UPDATE kol_events SET role='Participant' WHERE role ='Delegate';
UPDATE kol_events SET role='Participant' WHERE role ='Exhibitor';
UPDATE kol_events SET role='Participant' WHERE role ='Participant';
UPDATE kol_events SET role='Participant' WHERE role ='Particpant';
UPDATE kol_events SET role='Participant' WHERE role ='Paticipant';
UPDATE kol_events SET role='Participant' WHERE role ='Invited Participant';
UPDATE kol_events SET role='Participant' WHERE role ='Proposer';
UPDATE kol_events SET role='Director' WHERE role ='Course Director';
UPDATE kol_events SET role='Director' WHERE role ='Director';
UPDATE kol_events SET role='Director' WHERE role ='Executive Director';
UPDATE kol_events SET role='Director' WHERE role ='Program Director';
UPDATE kol_events SET role='Moderator' WHERE role ='Mederator';
UPDATE kol_events SET role='Moderator' WHERE role ='Co-Moderator';
UPDATE kol_events SET role='Moderator' WHERE role ='Moderator';
UPDATE kol_events SET role='Panelist' WHERE role ='Panel Member';
UPDATE kol_events SET role='Panelist' WHERE role ='Panelist';
UPDATE kol_events SET role='Panelist' WHERE role ='Chief Discussant';
UPDATE kol_events SET role='Panelist' WHERE role ='Discussant';
UPDATE kol_events SET role='Panelist' WHERE role ='Invited Panelist';
UPDATE kol_events SET role='Vice President' WHERE role ='Co-President';
UPDATE kol_events SET role='Vice President' WHERE role ='Vice President';
UPDATE kol_events SET role='Vice President' WHERE role ='Vice-President';


/** 
 * Update the column "role"
* @author Vinayak

* @version 4.5
**/

UPDATE kol_events SET role='Speaker' WHERE role ='Antipsychotic Therapy';
UPDATE kol_events SET role='Org. Member' WHERE role ='Auditor';
UPDATE kol_events SET role='Director' WHERE role ='Co-Director';
UPDATE kol_events SET role='Speaker' WHERE role ='Commentator';
UPDATE kol_events SET role='Speaker' WHERE role ='Convener';
UPDATE kol_events SET role='Speaker' WHERE role ='Councilor';
UPDATE kol_events SET role='Faculty' WHERE role ='Distinguished Faculty';
UPDATE kol_events SET role='Org. Member' WHERE role ='Ex Officio';
UPDATE kol_events SET role='Faculty' WHERE role ='Expert';
UPDATE kol_events SET role='Speaker' WHERE role ='Fergu Block Lecture';
UPDATE kol_events SET role='Faculty' WHERE role ='Guest';
UPDATE kol_events SET role='Faculty' WHERE role ='Guest Faculty';
UPDATE kol_events SET role='Speaker' WHERE role ='Guest Lecturer';
UPDATE kol_events SET role='Speaker' WHERE role ='Guest Speaker';
UPDATE kol_events SET role='Faculty' WHERE role ='International Faculty';
UPDATE kol_events SET role='Speaker' WHERE role ='Invired Speaker';
UPDATE kol_events SET role='Speaker' WHERE role ='Invited F. M. Hill Lecturer';
UPDATE kol_events SET role='Faculty' WHERE role ='Invited Faculty';
UPDATE kol_events SET role='Speaker' WHERE role ='Invited PHC Research Lecture';
UPDATE kol_events SET role='Speaker' WHERE role ='Invited Presenter';
UPDATE kol_events SET role='Speaker' WHERE role ='Invited Speaker';
UPDATE kol_events SET role='Keynote Speaker' WHERE role ='Keynote Speaker';
UPDATE kol_events SET role='Speaker' WHERE role ='Opponent';
UPDATE kol_events SET role='Speaker' WHERE role ='Other';
UPDATE kol_events SET role='Speaker' WHERE role ='Presenter';
UPDATE kol_events SET role='President' WHERE role ='President';
UPDATE kol_events SET role='Chair' WHERE role ='Program Co-Chair';
UPDATE kol_events SET role='Moderator' WHERE role ='Scientific Coordinator';
UPDATE kol_events SET role='Director' WHERE role ='Scientific Director';
UPDATE kol_events SET role='Org. Member' WHERE role ='Scientific Secretary';
UPDATE kol_events SET role='Speaker' WHERE role ='Teacher';


UPDATE kol_events SET role='Moderator' WHERE role ='Coordinator';
UPDATE kol_events SET role='Speaker' WHERE role ='Participant';
UPDATE kol_events SET role='Chair' WHERE role ='Co-Chair';
UPDATE kol_events SET role='Faculty' WHERE role ='Panelist';
UPDATE kol_events SET role='Org. Member' WHERE role ='Member';


INSERT INTO event_roles(`role`) VALUES('Org. Member'),('Speaker'),('Chair'),
('Moderator'),('Faculty'),('Director'),('Vice President'),('Keynote Speaker'),('President');


ALTER TABLE client_users ADD COLUMN department VARCHAR(250) NULL;

ALTER TABLE  client_users ADD COLUMN address text NULL;

ALTER TABLE  client_users ADD COLUMN about text NULL;

ALTER TABLE  client_users ADD COLUMN interest text NULL;

ALTER TABLE `kolm_app`.`wallposts` ENGINE = INNODB; 
ALTER TABLE `kolm_app`.`walllikes_track` ENGINE = INNODB; 
ALTER TABLE `kolm_app`.`wallcomments` ENGINE = INNODB; 

ALTER TABLE `kolm_app`.`wallcomments` ADD CONSTRAINT `FK_wallcomments` FOREIGN KEY (`post_id`) REFERENCES `wallposts` (`p_id`) ON DELETE CASCADE ; 


alter table `clinical_trials` add column `no_of_enrollees` int (11) DEFAULT '0' NULL , add column `no_of_trial_sites` int (11) DEFAULT '0' NULL, add column `collaborator` varchar (100);
alter table `clinical_trials` add column `kol_role` varchar (100)  NULL, add column `min_age` varchar (25)  NULL, add column `max_age` varchar (25)  NULL, add column `gender` varchar (10)  NULL; 

/** 
 * Added the new columns for clinical trials as per the new template
* @author Laxman K
* @since 13 july,2012
* @version 4.5 
**/
alter table `kolm_app`.`clinical_trials` add column `no_of_enrollees` int (11) DEFAULT '0' NULL , add column `no_of_trial_sites` int (11) DEFAULT '0' NULL, add column `collaborator` varchar (100);
alter table `kolm_app`.`clinical_trials` add column `kol_role` varchar (100)  NULL, add column `min_age` varchar (25)  NULL, add column `max_age` varchar (25)  NULL, add column `gender` varchar (10)  NULL;

/** 
 * Deletes the non cosiderable update entries
* @author Ramesh B
* @since 20 july,2012
* @version 4.6
**/
DELETE FROM updates WHERE update_type_id IS NULL OR update_type_id = '';
DELETE FROM updates WHERE update_type_id NOT IN (100,101,103,104,105,107,108,110,111,113,114,116,117,119,120,121,122,124,125,126,127,506,507,509,510);
/** 
 * Add column npi num
* @author Vinayak

* @version 4.6
**/

ALTER TABLE kols ADD COLUMN npi_num VARCHAR(255);

/** 
 * Add column following column to payment tables
* @author Vinayak

* @version 4.7
**/
ALTER TABLE payments ADD COLUMN paid_by int(11);
ALTER TABLE payments ADD COLUMN requested_by int(11);
ALTER TABLE payments ADD COLUMN amount decimal(10,2);


/** 
 * Alter commonds for Track modules
* @author Ramesh B
* @since 25 july,2012
* @version 4.7
**/ 
/* Delete the following columns from the 'payments' table */
ALTER TABLE payments DROP COLUMN rate;
ALTER TABLE payments DROP COLUMN duration;
ALTER TABLE payments DROP COLUMN interaction_id;

/* Add the following columns to the 'payments' table */
ALTER TABLE payments ADD COLUMN requested_by INT(12) NULL;
ALTER TABLE payments ADD COLUMN paid_by INT(12) NULL;

DROP TABLE IF EXISTS payment_threshholds;

/*Table structure for table `payment_threshholds` */
DROP TABLE IF EXISTS payment_split;

CREATE TABLE `payment_split` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(12) NOT NULL,
  `type` INT(12) NOT NULL,
  `amount` DECIMAL(10,0) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_payment_id` (`payment_id`),
  KEY `FK_payment_type` (`type`),
  CONSTRAINT `FK_payment_type` FOREIGN KEY (`type`) REFERENCES `payment_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8;

/*Insert another payment type 'event' */
INSERT INTO `payment_types`(`client_id`,`name`,`notes`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ('2','Event','Yes','2',NULL,NULL,NULL);

/* Delete the following columns from the 'client_events' table */
ALTER TABLE client_events DROP COLUMN presenter;
ALTER TABLE client_events DROP COLUMN events_month_year;
ALTER TABLE client_events ADD COLUMN amount DECIMAL(10,2) DEFAULT NULL;

/*Table structure for table `client_event_payments` */
DROP TABLE IF EXISTS client_event_payments;

CREATE TABLE `client_event_payments` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `client_event_id` INT(12) NOT NULL,
  `payment_id` INT(12) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_client_event_id` (`client_event_id`),
  KEY `FK_client_event_payment_id` (`payment_id`),
  CONSTRAINT `FK_client_event_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_client_event_id` FOREIGN KEY (`client_event_id`) REFERENCES `client_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8;

ALTER TABLE `payments` CHANGE `payment` `amount` DECIMAL(10,2) NULL ;

/** 
 * Alter commonds for Renaming Grand Rounds to Grand Round -  Bug Id - 418
 * @author Laxman
 * @since 08 Aug,2012
 * @version 4.9
**/ 
UPDATE conf_event_types set event_type='Grand Round' where event_type='Grand Rounds';


 /**
 * 
 * @description - to associate with products
 * @author - Laxman K
 * @since  - 09th Aug 2012
 * @version 4.9
 */
 ALTER TABLE `interactions_brands` ADD COLUMN `product_id` int (11)  NULL  after `Created_on`;
  

/**
 * 
 * @description - for the new interaction changes
 * @author - Laxman K
 * @since  - 09th Aug 2012
 * @version 4.9
 */

 ALTER TABLE `interactions` drop foreign key  `interaction_fk_kol_id`;
 ALTER TABLE `interactions` drop index `interaction_fk_kol_id`;
 ALTER TABLE `interactions` drop column `kol_id`, drop column `role`, drop column `brand`, drop column `topic`, drop column `category`, drop column `therapeutic_area`, drop column `objective_id`;



 /**
 * @table for interaction products
 * @description - products for interaction
 * @author - Laxman K
 * @since  - 09th Aug 2012
 * @version 4.9
 */
 
 
DROP TABLE IF EXISTS `interactions_products`;
CREATE TABLE `interactions_products` (
  `id` int (11) NOT NULL AUTO_INCREMENT , 
  `product_name` varchar (255) , 
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;
/*Table structure for table `interactions_about` */

DROP TABLE IF EXISTS `interactions_about`;

CREATE TABLE `interactions_about` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `objective_id` int(11) default NULL,
  `topic_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `brand_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `interactions_attendees` */

DROP TABLE IF EXISTS `interactions_attendees`;

CREATE TABLE `interactions_attendees` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `kol_id` int(11) default NULL,
  `specialty_id` int(11) default NULL,
  `category_id` int(11) default NULL,
  `role_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `interaction_internal_users`;
CREATE TABLE `interaction_internal_users` (  
  `id` int(11) NOT NULL auto_increment,      
  `interaction_id` int(11) default NULL,     
  `user_id` int(11) default NULL,            
  PRIMARY KEY  (`id`)                        
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

 /**
 * @table for interaction products
 * @description - products for interaction
 * @author - Laxman K
 * @since  - 09th Aug 2012
 * @version 4.9
 */
INSERT INTO interactions_categories(`name`,`cliemt_id`) VALUES('National',1);

DROP TABLE IF EXISTS `interactions`;
CREATE TABLE `interactions` (               
 `id` int(50) NOT NULL auto_increment,     
  `client_id` int(50) default NULL,         
  `date` date default NULL,                 
  `fromtime` time default NULL,             
  `mode` int(50) default NULL,              
  `location` varchar(250) default NULL,     
  `follow_up_on` date default NULL,         
   `reminder` tinyint(1) default NULL,       
  `notes` mediumtext,                       
  `created_by` int(50) NOT NULL,            
   `created_on` date NOT NULL,               
   `modified_by` int(50) NOT NULL,           
   `modified_on` date NOT NULL,              
   `calendar_event_id` int(10) default '0',  
   `totime` time default NULL,               
   `total_attendies` int(11) default NULL,   
   PRIMARY KEY  (`id`)                       
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;
              
DROP TABLE IF EXISTS `interactions_about`;
CREATE TABLE `interactions_about` (       
  `id` int(11) NOT NULL auto_increment,   
  `interaction_id` int(11) default NULL,  
  `objective_id` int(11) default NULL,    
  `topic_id` int(11) default NULL,        
  `product_id` int(11) default NULL,      
  `brand_id` int(11) default NULL,        
  PRIMARY KEY  (`id`)     
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
                 
DROP TABLE IF EXISTS `interactions_attendees`;   
CREATE TABLE `interactions_attendees` (   
  `id` int(11) NOT NULL auto_increment,   
  `interaction_id` int(11) default NULL,  
  `kol_id` int(11) default NULL,          
  `specialty_id` int(11) default NULL,    
  `category_id` int(11) default NULL,     
  `role_id` int(11) default NULL,         
  PRIMARY KEY  (`id`)                     
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
      
DROP TABLE IF EXISTS `interactions_products`;   
CREATE TABLE `interactions_products` (   
 `id` int(11) NOT NULL auto_increment,  
 `name` varchar(255) default NULL,      
  PRIMARY KEY  (`id`)                    
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
                       
DROP TABLE IF EXISTS `interactions_products`;   
CREATE TABLE `interaction_internal_users` (  
  `id` int(11) NOT NULL auto_increment,      
  `interaction_id` int(11) default NULL,     
  `user_id` int(11) default NULL,            
  PRIMARY KEY  (`id`)                        
) ENGINE=InnoDB DEFAULT CHARSET=utf8;   
                       

 /**
 * @description - for the `feedbacks`
 * @author - Laxman K
 * @since  - 23th Aug 2012
 * @version 5.0
 *
*/

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default NULL,
  `client_id` int(11) default NULL,
  `subject` varchar(255) default NULL,
  `description` text,
  `file_name` varchar(255) default NULL,
  `file_type` varchar(255) default NULL,
  `file_path` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `created_by` int(11) default NULL,
  `modified_on` datetime default NULL,
  `modified_by` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



 /**
 * @description - for the `feedback_types`
 * @author - Laxman K
 * @since  - 23th Aug 2012
 * @version 5.0
 */
CREATE TABLE `feedback_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  /**
 * 
 * @description - for the new interaction changes
 * @author - Vinayak
 * @since  - 23th Aug 2012
 * @version 5.0
 */
 ALTER TABLE contracts ADD COLUMN doc_name text;
 
 
 /*
 * @description - foreign key constraints
 * @author - Laxman K
 * @since  - 24th Aug 2012
 * @version 5.1
 */
 
ALTER TABLE `interactions_about` ADD CONSTRAINT `FK_interactions_about` FOREIGN KEY(`interaction_id`)REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `interactions_about` ADD CONSTRAINT `FK_interactions_about_objective` FOREIGN KEY(`objective_id`)REFERENCES `objectives` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_about` ADD CONSTRAINT `FK_interactions_about_topics` FOREIGN KEY(`topic_id`)REFERENCES `interactions_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_about` ADD CONSTRAINT `FK_interactions_about_products` FOREIGN KEY(`product_id`)REFERENCES `interactions_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_about` ADD CONSTRAINT `FK_interactions_about_brands` FOREIGN KEY(`brand_id`)REFERENCES `interactions_brands` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;

ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees` FOREIGN KEY(`interaction_id`)REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees_kols` FOREIGN KEY(`kol_id`)REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees_specialty` FOREIGN KEY(`specialty_id`)REFERENCES `specialties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees_categories` FOREIGN KEY(`category_id`)REFERENCES `interactions_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees_roles` FOREIGN KEY(`role_id`)REFERENCES `interactions_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;

ALTER TABLE `interaction_internal_users` ADD CONSTRAINT `FK_interaction_internal_users` FOREIGN KEY(`interaction_id`)REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;
ALTER TABLE `interaction_internal_users` ADD CONSTRAINT `FK_interaction_internal_users_clientuser` FOREIGN KEY(`user_id`)REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;

ALTER TABLE `interactions_brands` ADD CONSTRAINT `FK_interactions_brands_products` FOREIGN KEY(`product_id`)REFERENCES `interactions_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;

ALTER TABLE `feedbacks` ADD CONSTRAINT `FK_feedbacks_types` FOREIGN KEY(`type_id`)REFERENCES `feedback_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE ;

 /*
 * @description - Added Colmn profile_tye
 * @author - Vinayak
 * @since  - 29th Aug 2012
 * @version 5.1
 */

ALTER TABLE kols ADD COLUMN profile_type VARCHAR(255);
ALTER TABLE updates ADD COLUMN status_id INT(11);

/*Added column modified by and modified on for interactions_topics table
* date -  26 Sep 2012
* Version 5.3
* ONLY FOR BACSCH AND LOMB
*/
ALTER TABLE `interactions_topics`  ADD COLUMN `modified_by` INT(12) NULL;   
ALTER TABLE `interactions_topics`  ADD COLUMN `modified_on` DATE NULL;

/*Added Unique constraint for interactions_topics 'name' column
* date -  26 Sep 2012
* Version 5.3
* ONLY FOR BACSCH AND LOMB
*/
ALTER TABLE `interactions_topics` ADD UNIQUE `unique_client_topic` (`name`, `client_id`);

 /**
 * @table structure for `interaction grouping`
 * @description - specific changes for interaction
 * @author - Laxman K
 * @since  - 22 Sep 2012
 * @version Otsuka 1.0 
 */
 
ALTER TABLE `interactions` ADD COLUMN `grouping` int(11) NULL;
 
 /**
 * @table data for `coachings`
 * @description - data for coachings
 * @author - Shivu.dundur<shivu.dundur@bilva.co.in>
 * @since  - 30 Sep 2012
 * @version Otsuka 1.0
 */
ALTER TABLE `coachings`  ADD COLUMN `planscore` DECIMAL(11,2) NULL AFTER `wrap_topic4`,     ADD COLUMN `openscore` DECIMAL(11,2) NULL AFTER `planscore`,     ADD COLUMN `medscore` DECIMAL(11,2) NULL AFTER `openscore`,     ADD COLUMN `wrapscore` DECIMAL(11,2) NULL AFTER `medscore`,     ADD COLUMN `totalscore` DECIMAL(11,2) NULL AFTER `wrapscore`;

/*
*	remove the foreign key constraint
* 	@since  - 15 Oct 2012
*	@version Otsuka 1.0.2
*/
alter table `interaction_internal_users` drop foreign key  `FK_interaction_internal_users_clientuser`;

/*
*	for the release of otsuka v 1.0.2
* 	@since  - 15 Oct 2012
*	@version Otsuka 1.0.2
*/

/*Table structure for table `interaction_comm_objectives` */

/*Table structure for table `interaction_comm_objectives` */

DROP TABLE IF EXISTS `interaction_comm_objectives`;
DROP TABLE IF EXISTS `interaction_docs`;
DROP TABLE IF EXISTS `interaction_grouping`;
DROP TABLE IF EXISTS `interaction_internal_users`;
DROP TABLE IF EXISTS `interaction_topic_mapping`;
DROP TABLE IF EXISTS `interaction_types`;
DROP TABLE IF EXISTS `interactions_about`;
DROP TABLE IF EXISTS `interactions_attendees`;
DROP TABLE IF EXISTS `interactions_brands`;
DROP TABLE IF EXISTS `interactions_categories`;
DROP TABLE IF EXISTS `interactions_modes`;
DROP TABLE IF EXISTS `interactions_products`;
DROP TABLE IF EXISTS `interactions_roles`;
DROP TABLE IF EXISTS `interactions_topic_mapped_data`;
DROP TABLE IF EXISTS `interactions_topics`;
DROP TABLE IF EXISTS `interactions`;



CREATE TABLE `interaction_comm_objectives` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET= utf8;
CREATE TABLE `interaction_docs` (
  `id` int(50) NOT NULL auto_increment,
  `interaction_id` int(50) default NULL,
  `name` varchar(250) character set latin1 default NULL,
  `description` text character set latin1,
  `doc_path` text character set latin1,
  `created_by` int(50) default NULL,
  `created_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interaction_grouping` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `client_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions` (
  `id` int(50) NOT NULL auto_increment,
  `client_id` int(50) default NULL,
  `date` date default NULL,
  `fromtime` time default NULL,
  `mode` int(50) default NULL,
  `location` varchar(250) character set latin1 default NULL,
  `follow_up_on` date default NULL,
  `reminder` tinyint(1) default NULL,
  `notes` text character set latin1,
  `created_by` int(50) NOT NULL,
  `created_on` date NOT NULL,
  `modified_by` int(50) NOT NULL,
  `modified_on` date NOT NULL,
  `calendar_event_id` int(10) default '0',
  `totime` time default NULL,
  `total_attendies` int(11) default NULL,
  `grouping` int(11) default NULL,
  `address` varchar(255) default NULL,
  `city_id` int(11) default NULL,
  `state_id` int(11) default NULL,
  `postal_code` varchar(25) default NULL,
  `location_type` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_categories` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_modes` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_products` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_roles` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_topics` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  `modified_by` int(12) default NULL,
  `modified_on` date default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_client_topic` (`name`,`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interaction_topic_mapping` (
  `id` int(11) NOT NULL auto_increment,
  `grouping_id` int(11) default NULL,
  `interaction_type_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `topic_id` int(11) default NULL,
  `comm_objective_id` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interaction_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interaction_internal_users` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_interaction_internal_users` (`interaction_id`),
  KEY `FK_interaction_internal_users_clientuser` (`user_id`),
  CONSTRAINT `FK_interaction_internal_users` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_brands` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  `product_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_interactions_brands_products` (`product_id`),
  CONSTRAINT `FK_interactions_brands_products` FOREIGN KEY (`product_id`) REFERENCES `interactions_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interactions_about` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `objective_id` int(11) default NULL,
  `topic_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `brand_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_interactions_about` (`interaction_id`),
  KEY `FK_interactions_about_objective` (`objective_id`),
  KEY `FK_interactions_about_topics` (`topic_id`),
  KEY `FK_interactions_about_products` (`product_id`),
  KEY `FK_interactions_about_brands` (`brand_id`),
  CONSTRAINT `FK_interactions_about` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_about_brands` FOREIGN KEY (`brand_id`) REFERENCES `interactions_brands` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_about_objective` FOREIGN KEY (`objective_id`) REFERENCES `objectives` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_about_products` FOREIGN KEY (`product_id`) REFERENCES `interactions_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_about_topics` FOREIGN KEY (`topic_id`) REFERENCES `interactions_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `interactions_attendees` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `kol_id` int(11) default NULL,
  `specialty_id` int(11) default NULL,
  `category_id` int(11) default NULL,
  `role_id` int(11) default NULL,
  `note` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_interactions_attendees` (`interaction_id`),
  KEY `FK_interactions_attendees_kols` (`kol_id`),
  KEY `FK_interactions_attendees_specialty` (`specialty_id`),
  KEY `FK_interactions_attendees_categories` (`category_id`),
  KEY `FK_interactions_attendees_roles` (`role_id`),
  CONSTRAINT `FK_interactions_attendees` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_attendees_categories` FOREIGN KEY (`category_id`) REFERENCES `interactions_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_attendees_kols` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_attendees_roles` FOREIGN KEY (`role_id`) REFERENCES `interactions_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interactions_attendees_specialty` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interactions_topic_mapped_data` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `order` int(1) default '0',
  `comm_objective_id` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_interactions_topic_mapped_data` (`interaction_id`),
  CONSTRAINT `FK_interactions_topic_mapped_data` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




INSERT  INTO `interaction_grouping`(`id`,`name`,`client_id`) VALUES (1,'One-on-One',1),(2,'Group',1);
INSERT  INTO `interactions_products`(`id`,`name`) VALUES (1,'Abilify');
INSERT  INTO `interaction_types`(`id`,`name`) VALUES (1,'Proactive Promotional'),(2,'Proactive Non-Promotional'),(3,'Reactive');
INSERT  INTO `interactions_brands`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`product_id`) VALUES (1,'Brand A1',1,1,NULL,1),(2,'Brand A2',1,1,NULL,1),(3,'Brand A3',1,1,NULL,1),(4,'Brand A4',1,1,NULL,1),(5,'Brand A5',1,1,NULL,1);
INSERT  INTO `interactions_categories`(`id`,`name`,`client_id`,`created_by`,`Created_on`) VALUES (1,'Global',1,NULL,NULL),(2,'Regional',1,NULL,NULL),(3,'Local ',1,NULL,NULL),(4,'Not Specified',1,NULL,NULL);
INSERT  INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`) VALUES (1,'Face to Face',1,NULL,NULL),(2,'Phone',1,NULL,NULL),(3,'Web',1,NULL,NULL);
INSERT  INTO `interactions_roles`(`id`,`name`,`client_id`,`created_by`,`Created_on`) VALUES (1,'Speaker',1,NULL,NULL),(2,'Publisher',1,NULL,NULL),(3,'Advisor',1,NULL,NULL),(4,'Trainer',1,NULL,NULL),(5,'Researcher',1,NULL,NULL);
INSERT  INTO `interactions_topics`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`modified_by`,`modified_on`) VALUES (1,'HEOR (only for Managed Care/P&T/Formulary Committee member)',1,NULL,NULL,NULL,NULL),(2,'Label/Safety Warning Update',1,NULL,NULL,NULL,NULL),(3,'Quarterly Educational Initiative (Product)\r\n',1,NULL,NULL,NULL,NULL),(4,'Speaker Activities - Evaluation \r\n',1,NULL,NULL,NULL,NULL),(5,'Quarterly Educational Initiative (Product-Pediatrics)\r\n',1,NULL,NULL,NULL,NULL),(6,'Speaker Activities - Identification\r\n',1,NULL,NULL,NULL,NULL),(7,'Speaker Activities - Training\r\n',1,NULL,NULL,NULL,NULL),(8,'Product (On-Label)\r\n\r\n\r\n\r\n',1,NULL,NULL,NULL,NULL),(9,'Authorship/Scientific Collaboration\r\n',1,NULL,NULL,NULL,NULL),(10,'CST site identification\r\n',1,NULL,NULL,NULL,NULL),(11,'CST visit\r\n',1,NULL,NULL,NULL,NULL),(12,'Disease State\r\n',1,NULL,NULL,NULL,NULL),(13,'IST visit (with contracted investigator)\r\n',1,NULL,NULL,NULL,NULL),(14,'Quarterly Educational Initiative (Disease state)\r\n',1,NULL,NULL,NULL,NULL),(15,'Quarterly Educational Initiative (Disease State-CML Endpoints)\r\n',1,NULL,NULL,NULL,NULL),(16,'Quarterly Educational Initiative (Disease State-Updates in Schz)\r\n',1,NULL,NULL,NULL,NULL),(17,'REMs\r\n',1,NULL,NULL,NULL,NULL),(18,'HEOR (non-FDAMA 114) (only for Managed Care/P&T/Formulary Committee Member)\r\n',1,NULL,NULL,NULL,NULL),(20,'MIRF Interaction\r\n',1,NULL,NULL,NULL,NULL),(22,'Response to Unsolicited Question by HCP (CST)\r\n',1,NULL,NULL,NULL,NULL),(23,'Response to Unsolicited Question by HCP (Disease State)\r\n',1,NULL,NULL,NULL,NULL),(24,'Response to Unsolicited Question by HCP (HEOR)\r\n',1,NULL,NULL,NULL,NULL),(25,'Response to Unsolicited Question by HCP (IST)\r\n',1,NULL,NULL,NULL,NULL),(26,'Response to Unsolicited Question by HCP (Product Off-label) [No-Action MIRF needed]\r\n',1,NULL,NULL,NULL,NULL),(27,'Response to Unsolicited Question by HCP (Product On-label)\r\n',1,NULL,NULL,NULL,NULL),(28,'Safety & Pharmacovigilence follow up\r\n',1,NULL,NULL,NULL,NULL),(32,'Promotional Speaker Deck\r\n',1,NULL,NULL,NULL,NULL),(33,'Quarterly Educational Initiative (On-Label Product)\r\n',1,NULL,NULL,NULL,NULL),(36,'Quarterly Educational Initiative (Disease State- Adherence)\r\n',1,NULL,NULL,NULL,NULL);
INSERT  INTO `interaction_topic_mapping`(`id`,`grouping_id`,`interaction_type_id`,`product_id`,`topic_id`,`comm_objective_id`) VALUES (1,1,1,1,1,0),(2,1,1,1,2,0),(3,1,1,1,3,0),(4,1,1,1,4,0),(5,1,1,1,5,0),(6,1,1,1,6,0),(7,1,1,1,7,0),(8,1,1,1,8,0),(9,1,2,1,9,0),(10,1,2,1,10,0),(11,1,2,1,11,0),(12,1,2,1,12,0),(13,1,2,1,13,0),(14,1,2,1,14,0),(15,1,2,1,15,0),(16,1,2,1,16,0),(17,1,2,1,17,0),(18,1,2,1,36,0),(19,1,3,1,9,0),(20,1,3,1,10,0),(21,1,3,1,11,0),(22,1,3,1,18,0),(23,1,3,1,13,0),(24,1,3,1,2,0),(25,1,3,1,20,0),(26,1,3,1,14,0),(27,1,3,1,3,0),(28,1,3,1,17,0),(29,1,3,1,22,0),(30,1,3,1,23,0),(31,1,3,1,24,0),(32,1,3,1,25,0),(33,1,3,1,26,0),(34,1,3,1,27,0),(35,1,3,1,28,0),(36,1,3,1,4,0),(37,1,3,1,6,0),(38,1,3,1,7,0),(39,2,1,1,1,0),(40,2,1,1,32,0),(41,2,1,1,33,0),(42,2,1,1,5,0),(43,2,1,1,7,0),(44,2,2,1,36,0),(45,2,2,1,14,0),(46,2,2,1,15,0),(47,2,2,1,16,0),(48,2,3,1,1,0),(49,2,3,1,32,0),(50,2,3,1,14,0),(51,2,3,1,33,0),(52,2,3,1,7,0);

/*
* Add colmn profile Score
* v 5.3.2
* creates 16-10-2012
*
*/

ALTER Table kol_activities_count add column profileScore int(11);


 /**
 * @table structure for `json_store`
 * @description - specific changes for interaction
 * @author - Ramesh B
 * @since  - 31 Oct 2012
 * @version Otsuka 1.0 
 */
CREATE TABLE `json_store` (
  `id` int(12) NOT NULL auto_increment,
  `ref_id` int(5) NOT NULL,
  `json_data` blob,
  `filter` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**
 * 
 * @description - Update Statement for KOls table 
 * @author -Vinaak
 * @since  - 31 Oct 2012
 * @version Otsuka 1.0 
 */ 
update kols set profile_type='Full Profile'; 


/**
 * 
 * @description - Update Statement for KOls table 
 * @author -Vinaak
 * @since  - 8/11/2012
 * @version Otsuka 1.0.4 
 */ 
DELETE  FROM engagement_types WHERE engagement_type="Honararium";

/**
 *
 * @description - Feedback types
 * @author - Laxman K
 * @since  - 08 Nov 2012
 * @version Otsuka 1.0.4 
 */

insert into `feedback_types`(`id`,`name`) values (4,'Schedule Training');
insert into `feedback_types`(`id`,`name`) values (5,'Request Callback');


/*
* Table List_names
*/
SELECT * FROM list_names
 WHERE category_id NOT IN (SELECT id FROM list_categories);

DELETE FROM list_names 
WHERE category_id NOT IN (SELECT id FROM list_categories);

/*
* Table List_kols
*/
SELECT * FROM list_kols
 WHERE list_name_id NOT IN (SELECT id FROM list_names);


DELETE FROM list_kols 
WHERE list_name_id NOT IN (SELECT id FROM list_names);

/*
* Table List_kols
*/
SELECT * FROM list_kols
WHERE kol_id NOT IN (SELECT id FROM kols);


DELETE FROM list_kols 
WHERE kol_id NOT IN (SELECT id FROM kols);


ALTER TABLE list_names  ADD CONSTRAINT fk_category_id FOREIGN KEY (category_id) REFERENCES list_categories(id) ON DELETE CASCADE;
ALTER TABLE list_kols  ADD CONSTRAINT fk_list_name_id FOREIGN KEY (list_name_id) REFERENCES list_names(id) ON DELETE CASCADE;
ALTER TABLE list_kols  modify kol_id int(11) not null, ADD CONSTRAINT fk_kol_id FOREIGN KEY (kol_id) REFERENCES kols(id) ON DELETE CASCADE;

/**
 *
 * @description - for role based operations 
 * @author - Laxman K
 * @since  - 26 Nov 2012
 * @version Otsuka 1.0.6 
 */
 
ALTER TABLE `additionalcontacts`  ADD COLUMN `client_id` int(11) default '0', ADD COLUMN `created_by` int(11) default '0';

truncate table feedback_types;
insert  into `feedback_types`(`id`,`name`) values (1,'Question'),(2,'Software Issue'),(3,'Content Issue'),(4,'Training Request'),(5,'Callback Request'),(6,'Feature Request');

/**
 *
 * @description - Manager/User mapping
 * @author - Ramesh B
 * @since  - 20 Nov 2012
 * @version Otsuka 1.0.6 
 */
ALTER TABLE `client_users` ADD COLUMN `manager_id` INT(11) NULL;
ALTER TABLE `client_users` ADD COLUMN `territory` VARCHAR(255) NULL;
ALTER TABLE `client_users` ADD CONSTRAINT `FK_manager_id` FOREIGN KEY (`manager_id`) REFERENCES `client_users` (`id`);

 /**
 * @table structure for `kol_pmids`
 * @description - specific changes for publication crawling with given PMIDs
 * @author - Ramesh B
 * @since  - 06 Dec 2012
 * @version Otsuka 1.0.6 
 */
CREATE TABLE `kol_pmids` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `pmid` int(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `kol_pmid` (`kol_id`,`pmid`),
  CONSTRAINT `FK_kol` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 /**
 * @table structure for `kol_ctids`
 * @description - specific changes for clinical trials crawling with given CTIDs
 * @author - Ramesh B
 * @since  - 06 Dec 2012
 * @version Otsuka 1.0.6 
 */
CREATE TABLE `kol_ctids` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `ctid` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `kol_ctid` (`kol_id`,`ctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `updates` ADD COLUMN `published_time` TIMESTAMP NULL COMMENT 'when the update is published to client';   
ALTER TABLE `updates` ADD COLUMN `is_published` TINYINT(1) DEFAULT '0' NULL;

 /**
 * 
 * @description - 
 * @author - Vinayak
 * @since  - 20 Dec 2012
 *  @version Otsuka 1.0.7 
*/
ALTER TABLE client_users ADD COLUMN new_password_key varchar(255);
ALTER TABLE client_users ADD COLUMN new_password_creation datetime default '0000-00-00 00:00:00';

DELETE FROM regions where Region='AOL' AND CountryId=254;


ALTER TABLE kols modify column primary_phone varchar(25);
 /**
 * @table structure for `user_requests`
 * @description - specific changes for otsuka users profile requests
 * @author - Ramesh B
 * @since  - 20 Dec 2012
 * @version Otsuka 1.0.8 
 */
CREATE TABLE `user_requests` (
  `id` int(12) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `requested_by` int(12) default NULL,
  `requested_on` datetime default NULL,
  `status` varchar(255) default NULL,
  `request_for` varchar(255) default NULL,
  `profile_type` varchar(255) default NULL,
  `rej_or_appr_by` int(12) default NULL,
  `rej_or_appr_on` datetime default NULL,
  `comments` text,
  `assigned_to` int(12) default NULL,
  `assigned_on` datetime default NULL,
  `completed_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_requested_kol` (`kol_id`),
  KEY `FK_requested_user` (`requested_by`),
  CONSTRAINT `FK_requested_kol` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_requested_user` FOREIGN KEY (`requested_by`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 /**
 * @table structure for `user_requests`
 * @description - specific changes for otsuka users profile requests
 * @author - Ramesh B
 * @since  - 26 Dec 2012
 * @version Otsuka 1.0.8 
 */
ALTER TABLE user_requests ADD COLUMN `is_re_request` TINYINT(2) DEFAULT '0';

/**
 * @table `clinical_trials`
 * @description - changed the size from 10 to 100
 * @author - Laxman K
 * @since  - 31 Dec 2012
 * @version Otsuka 1.0.9 
 */
ALTER TABLE `clinical_trials` change `phase` `phase` varchar (100)  NULL;

ALTER TABLE user_org_requests ADD COLUMN `is_re_request` TINYINT(2) DEFAULT '0';

/**
 * @table structure for `user_org_requests`
 * @description - specific changes for otsuka users organization profile requests
 * @author - Ramesh B
 * @since  - 28 Dec 2012
 * @version Otsuka 1.0.9 
 */
CREATE TABLE `user_org_requests` (
  `id` int(12) NOT NULL auto_increment,
  `org_id` int(12) default NULL,
  `requested_by` int(12) default NULL,
  `requested_on` datetime default NULL,
  `status` varchar(255) default NULL,
  `rej_or_appr_by` int(12) default NULL,
  `rej_or_appr_on` datetime default NULL,
  `comments` text,
  `assigned_to` int(12) default NULL,
  `assigned_on` datetime default NULL,
  `completed_on` datetime default NULL,
  `is_re_request` tinyint(2) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_requested_kol` (`org_id`),
  KEY `FK_requested_user` (`requested_by`),
  CONSTRAINT `FK_org_requested_user` FOREIGN KEY (`requested_by`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_requested_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/**
 * @table `regions`
 * @description - To delete regionw hich has same country name
 * @author - Vinayak
 * @since  - 31 Dec 2012
 * @version Otsuka 1.0.9 
 */

delete from regions where RegionId in(select regionId from(select Regions.regionId
from Regions
left join countries on countries.countryId=Regions.CountryId
where region=country
)regions); 

DELETE FROM regions where Region='WebTV' AND CountryId=254;

/**
 * @table structure for `kol_name_combinations`
 * @description - table to hold the kol different name combinations, which are used for calculating the authorship position
 * @author - Ramesh B
 * @since  - 02 Jan 2013
 * @version Otsuka 1.0.9 
 */
CREATE TABLE `kol_name_combinations` (
  `id` int(15) NOT NULL auto_increment,
  `kol_id` int(15) default NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_kol_name_combinations` (`kol_id`),
  CONSTRAINT `FK_kol_name_combinations` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



alter table `clinical_trials` change `collaborator` `collaborator` text   NULL; 


/**
 * @table structure for `org_publications`
 * @description - table to hold the organization and publication association
 * @author - Ramesh B
 * @since  - 30 Mar 2013
 * @version Otsuka 1.0.11 
 */
CREATE TABLE `org_publications` (                                                                                                
    `id` int(50) NOT NULL AUTO_INCREMENT,                                                                                          
    `org_id` int(50) DEFAULT NULL,                                                                                                 
    `pub_id` int(50) DEFAULT NULL,                                                                                                 
    `is_deleted` tinyint(1) DEFAULT NULL,                                                                                          
    `is_verified` tinyint(1) NOT NULL DEFAULT '0',                                                                                 
    `client_id` int(11) DEFAULT NULL,                                                                                              
    `user_id` int(10) DEFAULT NULL,                                                                                                
    PRIMARY KEY (`id`),                                                                                                            
    UNIQUE KEY `kol_pub` (`org_id`,`pub_id`),                                                                                      
    KEY `FK_orgs_publications` (`pub_id`),                                                                                         
    CONSTRAINT `FK_publication_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,  
    CONSTRAINT `FK_orgs_publications` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE                    
  ) ENGINE=InnoDB AUTO_INCREMENT=268589 DEFAULT CHARSET=utf8;

/**
 * @table `organizations`
 * @description - added a new column 'is_pubmed_processed' to hold the pubmed status for organization
 * @author - Ramesh B
 * @since  - 30 Mar 2013
 * @version Otsuka 1.0.11 
 */
alter table `organizations` add column `is_pubmed_processed` tinyint (2) DEFAULT '0' NULL;

/**
 * @table structure for `org_pmids`
 * @description - table to hold the organization and pmid association
 * @author - Ramesh B
 * @since  - 30 Mar 2013
 * @version Otsuka 1.0.11 
 */
CREATE TABLE `org_pmids` (                                                                                               
     `id` int(50) NOT NULL AUTO_INCREMENT,                                                                                  
     `org_id` int(12) DEFAULT NULL,                                                                                         
     `pmid` int(50) DEFAULT NULL,                                                                                           
     PRIMARY KEY (`id`),                                                                                                    
     UNIQUE KEY `org_pmid` (`org_id`,`pmid`),                                                                               
     CONSTRAINT `FK_pmid_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE  
   ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/**
 * @table structure for `org_clinical_trials`
 * @description - table to hold the organization and clnical trials association
 * @author - Ramesh B
 * @since  - 03 Apr 2013
 * @version Otsuka 1.0.11 
 */  
CREATE TABLE `org_clinical_trials` (                                                                                
       `id` int(50) NOT NULL AUTO_INCREMENT,                                                                             
       `org_id` int(50) DEFAULT NULL,                                                                                    
       `cts_id` int(50) DEFAULT NULL,                                                                                    
       `client_id` int(11) DEFAULT NULL,                                                                                 
       `user_id` int(10) DEFAULT NULL,                                                                                   
       PRIMARY KEY (`id`),                                                                                               
       KEY `FK_org_clinical_trials` (`cts_id`),                                                                          
       CONSTRAINT `FK_org_clinical_trials` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE  
     ) ENGINE=InnoDB AUTO_INCREMENT=1783 DEFAULT CHARSET=utf8; 

/**
 * @table `organizations`
 * @description - added a new column 'is_clinical_trial_processed' to hold the trials status for organization
 * @author - Ramesh B
 * @since  - 03 Apr 2013
 * @version Otsuka 1.0.11 
 */
alter table `organizations` add column `is_clinical_trial_processed` tinyint (2) DEFAULT '0' NULL;

/**
 * @table `org_stats_facts`
 * @description - structure for org_stats_facts table
 * @since  - 04 April 2013
 * @version Otsuka 2.0
 */
CREATE TABLE `org_stats_facts` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                           
   `org_id` int(1) DEFAULT NULL,                                                                                   
   `no_of_beds` varchar(255) DEFAULT NULL,                                                                         
   `inpatient` varchar(255) DEFAULT NULL,                                                                          
   `births` varchar(255) DEFAULT NULL,                                                                             
   `outpatient` varchar(255) DEFAULT NULL,                                                                         
   `emergency_department` varchar(255) DEFAULT NULL,                                                               
   `link1` varchar(255) DEFAULT NULL,                                                                              
   `link2` varchar(255) DEFAULT NULL,                                                                              
   `no_of_surgeries` varchar(25) DEFAULT NULL,                                                                     
   PRIMARY KEY (`id`),                                                                                             
   UNIQUE KEY `uk_orgid` (`org_id`),                                                                               
   CONSTRAINT `org_stats_facts_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=782 DEFAULT CHARSET=utf8;   
 
 
 
/**
 * @table `affiliates_partnerships`
 * @description - structure for affiliates_partnerships table
 * @since  - 04 April 2013
 * @version Otsuka 2.0
 */
 
CREATE TABLE `affiliates_partnerships` (                                                                                       
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                        
   `org_id` int(11) DEFAULT NULL,                                                                                               
   `sub_org_id` int(11) NOT NULL,                                                                                               
   `address` varchar(255) DEFAULT NULL,                                                                                         
   `city_id` int(11) DEFAULT NULL,                                                                                              
   `state_id` int(11) DEFAULT NULL,                                                                                             
   `country_id` int(11) DEFAULT NULL,                                                                                           
   `postal_code` varchar(25) DEFAULT NULL,                                                                                      
   `phone` varchar(25) DEFAULT NULL,                                                                                            
    `url` varchar(255) DEFAULT NULL,                                                                                            
   `npi_num` varchar(255) DEFAULT NULL,                                                                                           
   PRIMARY KEY (`id`),                                                                                                          
   UNIQUE KEY `uK_orgid` (`org_id`,`sub_org_id`,`address`),                                                                     
   KEY `sub_org_id` (`sub_org_id`),                                                                                             
   CONSTRAINT `affiliates_partnerships_ibfk_2` FOREIGN KEY (`sub_org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,  
   CONSTRAINT `affiliates_partnerships_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE       
 ) ENGINE=InnoDB AUTO_INCREMENT=2204 DEFAULT CHARSET=utf8;
 
 /**
 * @table `medical_services`
 * @description - structure for medical_services table
 * @since  - 04 April 2013
 * @version Otsuka 2.0
 */
 
CREATE TABLE `medical_services` (                          
    `id` int(11) NOT NULL AUTO_INCREMENT,                    
    `name` varchar(255) DEFAULT NULL,                        
    PRIMARY KEY (`id`)                                       
  ) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8;  
 
  
 /**
 * @table `org_medical_services`
 * @description - structure for org_medical_services table
 * @since  - 04 April 2013
 * @version Otsuka 2.0
 */
 CREATE TABLE `org_medical_services` (                                                                                  
    `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                
    `medical_service_id` int(11) DEFAULT NULL,                                                                           
    `org_id` int(11) DEFAULT NULL,                                                                                       
    PRIMARY KEY (`id`),                                                                                                  
    KEY `org_id` (`org_id`),                                                                                             
    CONSTRAINT `org_medical_services_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
  ) ENGINE=InnoDB AUTO_INCREMENT=17450 DEFAULT CHARSET=utf8; 
 
 

ALTER TABLE organizations add column url varchar(255),add column addr_url varchar(255);

alter table organizations add column npi_num varchar(255);

CREATE TABLE `org_ctids` (                                                                                               
             `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                  
             `org_id` int(11) DEFAULT NULL,                                                                                         
             `ctid` varchar(255) DEFAULT NULL,                                                                                      
             PRIMARY KEY (`id`),                                                                                                    
             UNIQUE KEY `uk_org_id` (`org_id`,`ctid`),                                                                              
             CONSTRAINT `FK_ctid_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE  
           ) ENGINE=InnoDB AUTO_INCREMENT=2439 DEFAULT CHARSET=utf8; 
           
CREATE TABLE `org_name_combinations` (                                                                                                
     `id` int(15) NOT NULL AUTO_INCREMENT,                                                                                               
     `org_id` int(15) DEFAULT NULL,                                                                                                      
     `name` varchar(255) DEFAULT NULL,                                                                                                   
     PRIMARY KEY (`id`),                                                                                                                 
     KEY `FK_org_name_combinations` (`org_id`),                                                                                          
     CONSTRAINT `FK_org_name_combinations` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE  
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;  
           
ALTER TABLE `survey_answers` add column `nominee_city_id` int (11) DEFAULT '0' NULL  after `is_submitted`, add column `respondent_city_id` int (11) DEFAULT '0' NULL  after `nominee_city_id`;

/**
 * @table `kol_clinical_trials`
 * @description - added a new columns 'is_deleted' and 'is_verified' kol trials clensing
 * @author - Ramesh B
 * @since  - 13 jun 2013
 * @version Otsuka  
 */
alter table `kol_clinical_trials` add column `is_deleted` tinyint (1) DEFAULT '0' NOT NULL  after `user_id`, add column `is_verified` tinyint (1) DEFAULT '1' NOT NULL  after `is_deleted`
update kol_clinical_trials set is_verified = 1;

/**
 * @table `organizations`
 * @description - added a new columns 'is_deleted' and 'is_verified' organization trials clensing
 * @author - Ramesh B
 * @since  - 14 jun 2013
 * @version Otsuka  
 */
alter table `org_clinical_trials` add column `is_deleted` tinyint (1) DEFAULT '0' NOT NULL  after `user_id`, add column `is_verified` tinyint (1) DEFAULT '1' NOT NULL  after `is_deleted`


alter table key_peoples add column department varchar(255),add column url varchar(255);

alter table affiliates_partnerships add constraint org_id_unique unique(org_id,sub_org_id);
 
 CREATE TABLE `org_notes` (                                
     `id` int(11) NOT NULL AUTO_INCREMENT,                   
     `org_id` int(11) DEFAULT NULL,                          
     `note` text,                                            
     `created_by` int(11) DEFAULT NULL,                      
     `client_id` int(11) DEFAULT NULL,                       
     `created_on` datetime DEFAULT NULL,                     
     `modified_by` int(11) DEFAULT NULL,                     
     `modified_on` datetime DEFAULT NULL,                    
     PRIMARY KEY (`id`)                                      
   ) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
           

/** ----Start of Payor------
 * @table `organizations`
 * @description - added a new columns 'mergers' and 'clients',key_products organization trials clensing
 * @author - Vinayak
 * @since  - 27-7-2013
 * @version Otsuka  
 */           
alter table  organizations add column mergers varchar(255);   
alter table  organizations add column clients varchar(255);
alter table  organizations add column key_products varchar(255);

/**
 * @table `org_payer_facts`
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */           
CREATE TABLE `org_payer_facts` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                           
   `org_id` int(11) DEFAULT NULL,                                                                                  
   `no_of_hospitals` varchar(255) DEFAULT NULL,                                                                    
   `no_of_physicians` varchar(255) DEFAULT NULL,                                                                   
   `no_of_affiliated` varchar(255) DEFAULT NULL,                                                                   
   `benefit_management` varchar(255) DEFAULT NULL,                                                                 
   `specialty_pharmacy` varchar(255) DEFAULT NULL,                                                                 
   `ncqa_status` varchar(255) DEFAULT NULL,                                                                        
   `start_rating` varchar(255) DEFAULT NULL,                                                                       
   `physicians_employed` varchar(255) DEFAULT NULL,                                                                
   PRIMARY KEY (`id`),                                                                                             
   KEY `org_id` (`org_id`),                                                                                        
   CONSTRAINT `org_payer_facts_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;     

CREATE TABLE `org_claims_process` (                      
  `id` int(11) NOT NULL AUTO_INCREMENT,                  
  `claim` varchar(255) DEFAULT NULL,                     
  `type` int(11) DEFAULT NULL,                           
  PRIMARY KEY (`id`)                                     
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

CREATE TABLE `org_claims_process_mapped_data` (                                                                                     
  `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                             
  `fact_id` int(11) DEFAULT NULL,                                                                                                   
  `cliam_process_id` int(11) DEFAULT NULL,                                                                                          
  `type_id` int(11) DEFAULT NULL,                                                                                                   
  PRIMARY KEY (`id`),                                                                                                               
  KEY `fact_id` (`fact_id`),                                                                                                        
  CONSTRAINT `org_claims_process_mapped_data_ibfk_1` FOREIGN KEY (`fact_id`) REFERENCES `org_payer_facts` (`id`) ON DELETE CASCADE  
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8;
                                       
insert into org_claims_process(`claim`,`type`) values('Medical Claims',1),('Pharmacy Claims',1),('Laboratory Claims',1),('Integrated EMRs',1),('Manual',2),('Electronic',2),('Manual and Electronic',2);

/**
 * @table `org_enrollements`
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */ 
CREATE TABLE `org_enrollments` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                           
   `org_id` int(11) DEFAULT NULL,                                                                                  
   `type` varchar(255) DEFAULT NULL,                                                                               
   `2009` varchar(255) DEFAULT NULL,                                                                               
   `2010` varchar(255) DEFAULT NULL,                                                                               
   `2011` varchar(255) DEFAULT NULL,                                                                               
   `2012` varchar(255) DEFAULT NULL,                                                                               
   PRIMARY KEY (`id`),                                                                                             
   KEY `org_id` (`org_id`),                                                                                        
   CONSTRAINT `org_enrollments_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8;
 
 
 /**
 * @table `org_formularies`
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */
 
 CREATE TABLE `org_formularies` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                           
   `org_id` int(11) DEFAULT NULL,                                                                                  
   `drug_name` varchar(255) DEFAULT NULL,                                                                          
   PRIMARY KEY (`id`),                                                                                             
   KEY `org_id` (`org_id`),                                                                                        
   CONSTRAINT `org_formularies_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8;    

 /**
 * @table `org_formulary_dropdown_values` - Master table
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */
CREATE TABLE `org_formulary_dropdown_values` (            
     `id` int(11) NOT NULL AUTO_INCREMENT,                   
     `drug_pa` varchar(255) DEFAULT NULL,                    
     `type` int(11) DEFAULT NULL,                            
     PRIMARY KEY (`id`)                                      
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8; 
                               
CREATE TABLE `org_formluary_mapped_data` (                                                                                     
     `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                        
     `form_id` int(11) DEFAULT NULL,                                                                                              
     `drug_pa_id` int(11) DEFAULT NULL,                                                                                           
     `type` int(11) DEFAULT NULL,                                                                                                 
     PRIMARY KEY (`id`),                                                                                                          
     KEY `form_id` (`form_id`),                                                                                                   
     CONSTRAINT `org_formluary_mapped_data_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `org_formularies` (`id`) ON DELETE CASCADE  
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8; 

insert into org_formulary_dropdown_values(`drug_pa`,`type`) values('Tier 1',1),('Tier 2',1),
('Tier 3',1),('Tier 4',1),
('Tier 5',1),('Tier 2(Prior Authorization)',1),
('Tier 3 (Prior Authorization)',1),
('Tier 4 (Prior Authorization)',1),
('Tier 5 (Prior Authorization)',1),
('Tier 2 (Step Therapy)',1),
('Tier 3 (Step Therapy)',1),
('Tier 4 (Step Therapy)',1),
('Tier 5 (Step Therapy)',1),
('On-lable',2),
('Generic Failure',2),
('Other Preferred Brand Failure',2),
('Specify Medical Necessity',2);


 
 /**
 * @table `org_disease_managements`
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */
CREATE TABLE `org_disease_managements` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                   
   `org_id` int(11) DEFAULT NULL,                                                                                          
   `disease_name` varchar(255) DEFAULT NULL,                                                                               
   PRIMARY KEY (`id`),                                                                                                     
   KEY `org_id` (`org_id`),                                                                                                
   CONSTRAINT `org_disease_managements_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
 
 CREATE TABLE `org_disease_drop_down_values` (             
    `id` int(11) NOT NULL AUTO_INCREMENT,                   
    `value` varchar(255) DEFAULT NULL,                      
    `type` int(11) DEFAULT NULL,                            
    PRIMARY KEY (`id`)                                      
  ) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;   
 
  CREATE TABLE `org_disease_mapped_data` (                                                                                                
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                                 
   `disease_id` int(11) DEFAULT NULL,                                                                                                    
   `value_id` int(11) DEFAULT NULL,                                                                                                      
   `type` int(11) DEFAULT NULL,                                                                                                          
   PRIMARY KEY (`id`),                                                                                                                   
   KEY `disease_id` (`disease_id`),                                                                                                      
   CONSTRAINT `org_disease_mapped_data_ibfk_1` FOREIGN KEY (`disease_id`) REFERENCES `org_disease_managements` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8;

insert into org_disease_drop_down_values(`value`,`type`) values('Patient Rx Reminders',1),

('Outbound RN Calls',1),

('MD Contact for High Risk Patients',1),
('Rx Compliance Tracking',1),
('Behavioral Coaching',1),
('MD Alerts for Non-compliance',1),

('Screening',2),
('Claims Analysis/Chart Audit',2),
('Drug Utilization Review (DUR)',2),
('Other',2),

('Guideline Development',3),
('compliance Programs',3),
('Patient/Provider Education',3),
('Other',3),


('Patient Satisfaction',4),
('Drug Utilization Review (DUR)',4),
('Claims Analysis/Chart Audit',4),
('Other',4);

 
 /**
 * @table `org_payer_collabaration_categories`
 * @description - sql commands to create table
 * @since  - 27-7-2013
 * @version Otsuka  
 */
CREATE TABLE `org_payer_collabaration_categories` (      
  `id` int(11) NOT NULL AUTO_INCREMENT,                  
  `category` varchar(255) DEFAULT NULL,                  
  PRIMARY KEY (`id`)                                     
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;  


insert into org_payer_collabaration_categories(`category`) values('Cost versus Value Orientation'),('Evidence Receptivity'),
('Willingness to Partner' ),('Investment in Preventative Care and PHM'),('Sophistication in PHM Program/Tool Implementation');

CREATE TABLE `org_collabaration_categories_ratings` (     
    `id` int(11) NOT NULL AUTO_INCREMENT,                   
    `rating` varchar(255) DEFAULT NULL,                     
    `category` int(11) DEFAULT NULL,                        
    PRIMARY KEY (`id`)                                      
  ) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;  


CREATE TABLE `org_payer_collabaration_mapped_data` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                                               
   `org_id` int(11) DEFAULT NULL,                                                                                                      
   `category_id` int(11) DEFAULT NULL,                                                                                                 
   `rating_id` int(11) DEFAULT NULL,                                                                                                   
   PRIMARY KEY (`id`),                                                                                                                 
   KEY `org_id` (`org_id`),                                                                                                            
   CONSTRAINT `org_payer_collabaration_mapped_data_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;                                                                              


insert into org_collabaration_categories_ratings(`rating`,`category`) values
('1 - Drug cost is the only driver',1),
('2 - Cost is important but economic value is a factor',1),
('3 - Economic value is important but cost does factor in',1),
('4 - Economic Value Driven',1),


('1 - Will not consider pharma generated evidence',2),
('2 - Willing to consider pharma generated evidence',2),
('3 - Receptive to pharma generated evidence',2),
('4 - Relies on pharma generated evidence in formulary decision making',2),

('1 - Will not engage with pharma',3),
('2 - Reluctant to partner with pharma but willing consider',3),
('3 - Willing to partner with pharma',3),
('4 - Actively looking to partner with pharma',3),

('1 - Not willing to do anything beyond what they have to do',4),
('2 - Not willing to incur the additional costs, but will think about when patient is sick',4),
('3 - Some preventative care and disease management measures but not fully committed',4),
('4 - Willing to take all steps for prevention and disease management',4),

('1(Low)',5),
('2',5),
('3',5),
('4',5),
('5(High)',5);


ALTER TABLE `org_disease_managements` ADD COLUMN `created_by` int(11), ADD COLUMN `created_on` datetime, ADD COLUMN `modified_by` int(11),ADD COLUMN `modified_on` datetime,ADD COLUMN `client_id` int(11);

ALTER TABLE `org_enrollments` ADD COLUMN `created_by` int(11), ADD COLUMN `created_on` datetime, ADD COLUMN `modified_by` int(11),ADD COLUMN `modified_on` datetime,ADD COLUMN `client_id` int(11);

ALTER TABLE `org_formularies` ADD COLUMN `created_by` int(11), ADD COLUMN `created_on` datetime, ADD COLUMN `modified_by` int(11),ADD COLUMN `modified_on` datetime,ADD COLUMN `client_id` int(11);

ALTER TABLE `org_payer_collabaration_mapped_data` ADD COLUMN `created_by` int(11), ADD COLUMN `created_on` datetime, ADD COLUMN `modified_by` int(11),ADD COLUMN `modified_on` datetime,ADD COLUMN `client_id` int(11);

CREATE TABLE `org_enrollment_years` (                      
    `id` int(11) NOT NULL AUTO_INCREMENT,                    
    `enroll_id` int(11) DEFAULT NULL,                        
    `year` int(11) DEFAULT NULL,                             
    `value` varchar(255) DEFAULT NULL,                            
    PRIMARY KEY (`id`)                                       
  ) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8; 
  
DROP TABLE IF EXISTS `org_enrollments`;
CREATE TABLE `org_enrollments` (                                                                                  
   `id` int(11) NOT NULL AUTO_INCREMENT,                                                                           
   `org_id` int(11) DEFAULT NULL,                                                                                  
   `type` varchar(255) DEFAULT NULL,                                                                               
   `created_by` int(11) DEFAULT NULL,                                                                              
   `created_on` datetime DEFAULT NULL,                                                                             
   `modified_by` int(11) DEFAULT NULL,                                                                             
   `modified_on` datetime DEFAULT NULL,                                                                            
   `client_id` int(11) DEFAULT NULL,                                                                               
   PRIMARY KEY (`id`),                                                                                             
   KEY `org_id` (`org_id`),                                                                                        
   CONSTRAINT `org_enrollments_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE  
 ) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8;

 
insert into `key_people_roles`(`id`,`role`) values ( NULL,'Quality Director');
insert into `key_people_roles`(`id`,`role`) values ( NULL,'Pharmacy Director');
insert into `key_people_roles`(`id`,`role`) values ( NULL,'Case Manager');
insert into `key_people_roles`(`id`,`role`) values ( NULL,'P&T Committee');

insert into `org_formulary_dropdown_values`(`id`,`drug_pa`,`type`) values ( NULL,'Prior Authorization','1');
insert into `org_formulary_dropdown_values`(`id`,`drug_pa`,`type`) values ( NULL,'Step Therapy','1');
insert into `org_formulary_dropdown_values`(`id`,`drug_pa`,`type`) values ( NULL,'Not Covered','1');

alter table organizations ADD COLUMN profile_type int(11);

/**
 * @description - missed alter statements
 * @version Otsuka  
 */
update kol_clinical_trials set is_verified = 1;
ALTER TABLE user_org_requests ADD COLUMN `is_re_request` TINYINT(2) DEFAULT '0';
ALTER TABLE `users_analytics` ADD COLUMN `username` VARCHAR(255) NULL;

ALTER TABLE org_enrollment_years CHANGE COLUMN value value VARCHAR(255);

ALTER TABLE organizations ADD COLUMN key_reginal_offices VARCHAR(255);

ALTER TABLE `updates` CHANGE `module_id` `module_id` INT NULL;

ALTER TABLE org_medical_services ADD COLUMN url VARCHAR(255);

insert into organization_types(`type`) values('Payer');

ALTER TABLE `survey_answers` ADD CONSTRAINT `FK_survey_nominee` FOREIGN KEY (`nominee_id`) REFERENCES `survey_kol_names` (`id`);

ALTER TABLE `kol_publications` DROP FOREIGN KEY `FK_kols_publications`;
DELETE FROM kol_publications WHERE pub_id NOT IN (SELECT id FROM publications)
ALTER TABLE `kol_publications` ADD CONSTRAINT `FK_kols_publications` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON DELETE CASCADE  ON UPDATE CASCADE ;

ALTER TABLE `json_store` CHANGE `json_data` `json_data` LONGBLOB;

UPDATE org_disease_drop_down_values SET VALUE='Compliance Programs' WHERE id=30;


/**
*For Key Investigator clensing
*/
ALTER TABLE `cts_investigators` ADD COLUMN `alias_id` INT(50) NULL;
ALTER TABLE `cts_investigators` ADD COLUMN `alias_last_name` VARCHAR(255) NULL;
ALTER TABLE `ct_investigators`  ADD COLUMN `alias_id` INT(50) NULL;

ALTER TABLE `org_enrollment_years` ADD UNIQUE `IN_duplicate_year` (`enroll_id`, `year`);

ALTER TABLE organizations CHANGE COLUMN mergers mergers TEXT; 


CREATE TABLE `event_sponsor_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

CREATE TABLE `event_organizer_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



ALTER TABLE kol_events ADD COLUMN sponsor_type VARCHAR(255) AFTER organizer;

ALTER TABLE kol_events ADD COLUMN organizer_type INT(11) AFTER organizer;
ALTER TABLE kol_events ADD COLUMN session_sponsor VARCHAR(255) AFTER organizer;

INSERT INTO event_sponsor_types(`type`) VALUES('Association'),('Industry'),('University/Hospital'),('Other');
INSERT INTO event_organizer_types(`type`) VALUES('Association'),('Industry'),('Government'),('University/Hospital'),('Other');
/**
*Index for status column
*/
ALTER TABLE `kols` ADD INDEX `kol_status` (`status`);

ALTER TABLE `survey_kol_names` CHANGE `name` `name` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_org_names` CHANGE `name` `name` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `name` `name` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `country` `country` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `state` `state` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `city` `city` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `postal` `postal` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `respondent_country` `respondent_country` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `respondent_state` `respondent_state` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `respondent_city` `respondent_city` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;
ALTER TABLE `survey_answers` CHANGE `respondent_postal` `respondent_postal` VARCHAR(255) NULL , ROW_FORMAT=DEFAULT ;

/**
* API and Secret key columns for REST API
*/
ALTER TABLE client_users  ADD COLUMN `api_key` VARCHAR(255) NULL;
ALTER TABLE client_users  ADD COLUMN `secret_key` VARCHAR(255) NULL;

/**
* mdm id for kols table
*/
ALTER TABLE `kols` ADD COLUMN `mdm_id` VARCHAR(255) NULL AFTER `id`;

/**
* User analytics to differetiate user from iProfile and iMap
*/
ALTER TABLE `users_analytics` ADD COLUMN `user_from` VARCHAR(255) DEFAULT 'iMap' NULL AFTER `username`;






/********************************************** iProfile CRM Changes (iReport) ***************************************************************/
CREATE TABLE `products` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `group_products` (
  `group_id` int(12) DEFAULT NULL,
  `product_id` int(12) DEFAULT NULL,
  KEY `FK_group_products_ref_rgoup` (`group_id`),
  KEY `FK_group_products_ref_product` (`product_id`),
  CONSTRAINT `FK_group_products_ref_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_group_products_ref_rgoup` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `theraputic_areas` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `theraputic_area_products` (
  `theraputic_area_id` int(12) DEFAULT NULL,
  `product_id` int(12) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  KEY `FK_theraputic_area_products_ref_area` (`theraputic_area_id`),
  KEY `FK_theraputic_area_products_ref_product` (`product_id`),
  CONSTRAINT `FK_theraputic_area_products_ref_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_theraputic_area_products_ref_area` FOREIGN KEY (`theraputic_area_id`) REFERENCES `theraputic_areas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `key_insight_topics` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `key_insight_topics_association` (
  `product_id` int(12) DEFAULT NULL,
  `key_insight_topic_id` int(12) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  KEY `FK_key_insight_topics_association_ref_product` (`product_id`),
  KEY `FK_key_insight_topics_association_ref_key_ins` (`key_insight_topic_id`),
  CONSTRAINT `FK_key_insight_topics_association_ref_key_ins` FOREIGN KEY (`key_insight_topic_id`) REFERENCES `key_insight_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_key_insight_topics_association_ref_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interaction_types` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `interaction_topics` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interaction_topics_by_type` (
  `type_id` int(12) DEFAULT NULL,
  `topic_id` int(12) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  KEY `FK_interaction_topics_by_type_ref_type` (`type_id`),
  KEY `FK_interaction_topics_by_type_ref_topic` (`topic_id`),
  CONSTRAINT `FK_interaction_topics_by_type_ref_topic` FOREIGN KEY (`topic_id`) REFERENCES `interaction_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interaction_topics_by_type_ref_type` FOREIGN KEY (`type_id`) REFERENCES `interaction_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `interaction_sub_topics` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interaction_sub_topics_association` (
  `type_id` int(12) DEFAULT NULL,
  `topic_id` int(12) DEFAULT NULL,
  `product_id` int(12) DEFAULT NULL,
  `sub_topic_id` int(12) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` int(12) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(12) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  KEY `FK_interaction_sub_topics_association_ref_sub_topic` (`sub_topic_id`),
  KEY `FK_interaction_sub_topics_association_ref_ptoduct` (`product_id`),
  KEY `FK_interaction_sub_topics_association_ref_topic` (`topic_id`),
  KEY `FK_interaction_sub_topics_association_ref_type` (`type_id`),
  CONSTRAINT `FK_interaction_sub_topics_association_ref_type` FOREIGN KEY (`type_id`) REFERENCES `interaction_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interaction_sub_topics_association_ref_ptoduct` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interaction_sub_topics_association_ref_sub_topic` FOREIGN KEY (`sub_topic_id`) REFERENCES `interaction_sub_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_interaction_sub_topics_association_ref_topic` FOREIGN KEY (`topic_id`) REFERENCES `interaction_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/**
*Additional Fields like sphere_of_influence, relevance and action to medical_insight as per iReport
**/
ALTER TABLE medical_insight ADD (sphere_of_influence text,relevance text,actions_to_consider text,kol_id int(11),profile_type text);

/**
* Compliance monitoring(contact_type) to differentiate between KOL(s)/Organization(s) as attendees
* Compliance monitoring(compliance_violated_by_date) to record compliance violated date
*/
ALTER TABLE `compliance_monitoring` ADD COLUMN `contact_type` VARCHAR(30) AFTER `violation_description`;
ALTER TABLE `compliance_monitoring` ADD COLUMN `compliance_violated_by_date` date AFTER `compliance_violated_by_title`;

/**
* Create table compliance_monitoring_organizations to record all organizations attended in compliance
*/

CREATE TABLE IF NOT EXISTS `compliance_monitoring_organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compliance_monitoring_id` int(11) DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compliance_monitoring_id` (`compliance_monitoring_id`)
) ENGINE=InnoDB ;


CREATE TABLE `staffs` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(100) DEFAULT NULL,
  `name` VARCHAR(255) DEFAULT NULL,
  `phone_number` VARCHAR(255) DEFAULT NULL,
  `contact_type` VARCHAR(100) DEFAULT NULL,
  `contact` INT(12) DEFAULT NULL,
  `created_by` INT(12) DEFAULT NULL,
  `created_on` DATETIME DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

CREATE TABLE `phone_numbers` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(100) DEFAULT NULL,
  `number` VARCHAR(255) DEFAULT NULL,
  `contact_type` VARCHAR(100) DEFAULT NULL,
  `contact` INT(12) DEFAULT NULL,
  `created_by` INT(12) DEFAULT NULL,
  `created_on` DATETIME DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


CREATE TABLE `emails` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(100) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `is_primary` VARCHAR(10) DEFAULT NULL,
  `contact` INT(12) DEFAULT NULL,
  `created_by` INT(12) DEFAULT NULL,
  `created_on` DATETIME DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

CREATE TABLE `state_licenses` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `state_license` VARCHAR(255) DEFAULT NULL,
  `region` INT(12) DEFAULT NULL,
  `contact` INT(12) DEFAULT NULL,
  `created_by` INT(12) DEFAULT NULL,
  `created_on` DATETIME DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `ol_key_statuses` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `therapeutic_class` VARCHAR(100) DEFAULT NULL,
  `key_status` VARCHAR(100) DEFAULT NULL,
  `product` INT(12) DEFAULT NULL,
  `alignment` VARCHAR(255) DEFAULT NULL,
  `contact` INT(12) DEFAULT NULL,
  `created_by` INT(12) DEFAULT NULL,
  `created_on` DATETIME DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


/**
* Interaction changes alter commands
*/
ALTER TABLE `interactions`     ADD COLUMN `territory_id` INT(11) NULL AFTER `mirf_case_num`;
ALTER TABLE `interactions`     ADD COLUMN `employee_id` INT(11) NULL AFTER `territory_id`;
ALTER TABLE `interactions_attendees`     ADD COLUMN `status` VARCHAR(255) NULL AFTER `note`;
CREATE TABLE `interactions_other_attendees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interaction_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `specialty_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `interactions_discussion_topic_mapped_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interaction_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `interaction_type` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `sub_topic_id` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_interactions_discussion_topic_mapped_data` (`interaction_id`),
  CONSTRAINT `FK_interactions_discussion_topic_mapped_data` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8

# Alert commands for coaching tables
# Alert commands for `coaching` tables
ALTER TABLE coachings ADD plan_topic5 INT(11)
ALTER TABLE coachings ADD med_topic6 INT(11)
ALTER TABLE coachings ADD comment tinytext

# Digital signature

ALTER TABLE `interaction_mirf`     ADD COLUMN `hcp_signature` VARCHAR(255) NULL AFTER `mir_questions`;


/** Alert commands for medical_insight table**/
ALTER TABLE `medical_insight` CHANGE `agent` `agent` VARCHAR(255) NULL DEFAULT NULL;


/** Alert commands for organisation table with additional fields**/
ALTER TABLE `organizations` ADD `institution_type` VARCHAR(255) NOT NULL , ADD `specialty` INT(11) NOT NULL , ADD `num_of_physician` VARCHAR(255) NOT NULL , ADD `num_of_residents` VARCHAR(255) NOT NULL , ADD `research` VARCHAR(255) NOT NULL , ADD `foundation` VARCHAR(255) NOT NULL , ADD `admission_per_year` VARCHAR(255) NOT NULL , ADD `irb_present` VARCHAR(255) NOT NULL , ADD `licensing_opertunities` VARCHAR(255) NOT NULL , ADD `ists` VARCHAR(255) NOT NULL , ADD `csts` VARCHAR(255) NOT NULL , ADD `number_of_beds` VARCHAR(255) NOT NULL , ADD `ceo_name` VARCHAR(255) NOT NULL , ADD `email` VARCHAR(255) NOT NULL , ADD `rx_vol` VARCHAR(255) NOT NULL , ADD `size` VARCHAR(255) NOT NULL , ADD `patients_per_week` VARCHAR(255) NOT NULL , ADD `org_type` VARCHAR(255) NOT NULL, ADD `mco_type` VARCHAR(255) NOT NULL ;
ALTER TABLE compliance_monitoring_topics DROP COLUMN is_additional_topic;
ALTER TABLE `compliance_monitoring_topics`     ADD COLUMN `is_additional_topic` TINYINT(1) NULL AFTER `topic_id`;

ALTER TABLE coachings ADD med_topic7 INT(11);

/** KOL locations table 
CREATE TABLE IF NOT EXISTS `kol_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `org_institution_id` int(11) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) NOT NULL,
  `validation_status` varchar(50) NOT NULL,
  `address_type` varchar(50) NOT NULL,
  `country_id` smallint(6) DEFAULT NULL,
  `state_id` smallint(6) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `postal_code` varchar(50) NOT NULL,
  `postal_extension` varchar(50) NOT NULL,
  `postal_city` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT '0',
  `created_by` varchar(40) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kol_id` (`kol_id`),
  KEY `country_id` (`country_id`),
  KEY `state_id` (`state_id`),
  KEY `city_id` (`city_id`),
  KEY `org_institution_id` (`org_institution_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `kol_locations`
--
ALTER TABLE `kol_locations`
  ADD CONSTRAINT `kol_locations_ibfk_1` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `kol_locations_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `countries` (`CountryId`) ON DELETE CASCADE,
  ADD CONSTRAINT `kol_locations_ibfk_3` FOREIGN KEY (`state_id`) REFERENCES `regions` (`RegionID`) ON DELETE CASCADE,
  ADD CONSTRAINT `kol_locations_ibfk_4` FOREIGN KEY (`city_id`) REFERENCES `cities` (`CityId`) ON DELETE CASCADE,
  ADD CONSTRAINT `kol_locations_ibfk_5` FOREIGN KEY (`org_institution_id`) REFERENCES `organizations` (`id`);

--
-- Table structure for table `kol_emails`
--

CREATE TABLE IF NOT EXISTS `kol_emails` (
  `id` int(11) NOT NULL,
  `kol_id` int(11) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `kol_id` (`kol_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kol_emails`
--
ALTER TABLE `kol_emails`
  ADD CONSTRAINT `kol_emails_ibfk_1` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE;


--
-- Table structure for table `kol_phones`
--

CREATE TABLE IF NOT EXISTS `kol_phones` (
  `id` int(11) NOT NULL,
  `kol_id` int(11) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kol_id` (`kol_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kol_phones`
--
ALTER TABLE `kol_phones`
  ADD CONSTRAINT `kol_phones_ibfk_1` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE;
 
**/

# Organization location table
CREATE TABLE IF NOT EXISTS `org_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `main`  varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) NOT NULL,
  `validation_status` varchar(50) NOT NULL,
  `address_type` varchar(50) NOT NULL,
  `country_id` smallint(6) DEFAULT NULL,
  `state_id` smallint(6) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `postal_code` varchar(50) NOT NULL,
  `postal_extension` varchar(50) NOT NULL,
  `postal_city` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT '0',
  `created_by` varchar(40) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `country_id` (`country_id`),
  KEY `state_id` (`state_id`),
  KEY `city_id` (`city_id`),
  KEY `main` (`main`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;


ALTER TABLE `org_locations`
  ADD CONSTRAINT `org_locations_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `org_locations_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `countries` (`CountryId`) ON DELETE CASCADE,
  ADD CONSTRAINT `org_locations_ibfk_3` FOREIGN KEY (`state_id`) REFERENCES `regions` (`RegionID`) ON DELETE CASCADE,
  ADD CONSTRAINT `org_locations_ibfk_4` FOREIGN KEY (`city_id`) REFERENCES `cities` (`CityId`) ON DELETE CASCADE;
 
/** KOL profile changes **/
ALTER TABLE  `kols` ADD  `fma_speciality_id` INT( 11 ) NULL AFTER  `aissel_id` ;

ALTER TABLE  `kols` ADD  `product_id` INT( 11 ) NULL AFTER  `fma_speciality_id` ;

ALTER TABLE  `kols` ADD  `patients_range` VARCHAR( 250 ) NULL ;

ALTER TABLE  `kols` ADD  `additional_role_id` INT( 11 ) NULL AFTER  `product_id` ;

ALTER TABLE  `kols` ADD  `speaker_id` INT( 11 ) NULL AFTER  `additional_role_id` ;

ALTER TABLE  `kols` ADD  `compliance_flag` BOOLEAN NULL ;

ALTER TABLE  `kols` ADD  `degree_id` INT( 11 ) NULL AFTER  `speaker_id` ;

ALTER TABLE  `kols` ADD  `is_kol` BOOLEAN NOT NULL ;

 
ALTER TABLE `interactions`     ADD COLUMN `save_later` INT(1) NULL AFTER `employee_id`;

ALTER TABLE `interactions`     CHANGE `territory_id` `territory_id` VARCHAR(150) NULL ;

ALTER TABLE `countries`     ADD COLUMN `GlobalRegion` VARCHAR(100) NULL AFTER `MapReference`;

ALTER TABLE `key_peoples` ADD CONSTRAINT `FK_key_peoples_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE NO ACTION  ON UPDATE NO ACTION ;

CREATE TABLE `kol_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `note` text,
  `created_by` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_kol_notes` (`kol_id`),
  CONSTRAINT `FK_kol_notes` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/** Interactions for organiztions, org attendies *************/
ALTER TABLE `interactions_attendees`     ADD COLUMN `org_id` INT(11) NULL AFTER `kol_id`;
ALTER TABLE `interactions`     ADD COLUMN `is_org_interaction` TINYINT(1) DEFAULT 0 AFTER `save_later`;
ALTER TABLE `interactions_attendees` ADD CONSTRAINT `FK_interactions_attendees_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE NO ACTION  ON UPDATE NO ACTION ;


ALTER TABLE `compliance_monitoring`     ADD COLUMN `signature` VARBINARY(255) NULL AFTER `contact_type`;



CREATE TABLE `speaker_evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `evaluator` varchar(255) DEFAULT NULL,
  `evaluator_name` varchar(255) DEFAULT NULL,
  `program_date` date DEFAULT NULL,
  `no_of_attendees` int(11) DEFAULT NULL,
  `speaker_detail` varchar(255) DEFAULT NULL,
  `speaker_name` varchar(255) DEFAULT NULL,
  `speaker_background` varchar(255) DEFAULT NULL,
  `speaker_text` varchar(255) DEFAULT NULL,
  `moderated_program` varchar(255) DEFAULT NULL,
  `venu` varchar(255) DEFAULT NULL,
  `venu_city` varchar(255) DEFAULT NULL,
  `venu_presentation` varchar(255) DEFAULT NULL,
  `venu_presentation_comments` varchar(255) DEFAULT NULL,
  `audio_setup` varchar(255) DEFAULT NULL,
  `audio_setup_comments` varchar(255) DEFAULT NULL,
  `program_topic` varchar(255) DEFAULT NULL,
  `abilify_maintena` varchar(255) DEFAULT NULL,
  `rexulti` varchar(255) DEFAULT NULL,
  `nuedexta` varchar(255) DEFAULT NULL,
  `samsca` varchar(255) DEFAULT NULL,
  `disease_state` varchar(255) DEFAULT NULL,
  `psychu` varchar(255) DEFAULT NULL,
  `topic_presented` varchar(255) DEFAULT NULL,
  `action` tinytext,
  `speaker_stay` varchar(255) DEFAULT NULL,
  `saftey_info` varchar(255) DEFAULT NULL,
  `mirf_other` text,
  `mirf` varchar(255) DEFAULT NULL,
  `adverse_event` varchar(255) DEFAULT NULL,
  `adverse_event_report` varchar(255) DEFAULT NULL,
  `speaker_articulation` varchar(255) DEFAULT NULL,
  `speaker_articulation_comment` text,
  `mirf_doc` varchar(255) DEFAULT NULL,
  `mirf_comment` text,
  `guideline` varchar(255) DEFAULT NULL,
  `scale` varchar(255) DEFAULT NULL,
  `msl_follow_up` varchar(255) DEFAULT NULL,
  `msl_follow_up_comment` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `note` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `users` varchar(255) NOT NULL,
  `groups` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `created_on` date NOT NULL,
  `modified_by` varchar(255) NOT NULL,
  `modified_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;


--
-- Table structure for table `user_notifications`
--

CREATE TABLE IF NOT EXISTS `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `has_seen` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_notifications_ibfk_1` (`notification_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `user_notifications_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;


/***** Log table changes ****/
ALTER TABLE `log_activities`     ADD COLUMN `transaction_name` VARCHAR(255) NULL AFTER `transaction_table_id`;
ALTER TABLE `log_activities`     ADD COLUMN `form_data` BLOB NULL AFTER `transaction_name`;

/***** coaching table changes ****/

CREATE TABLE engagement_status
(id INT NOT NULL AUTO_INCREMENT,
status VARCHAR(255),
PRIMARY KEY (id));

INSERT INTO engagement_status (status) VALUES ('Established(>=4th visit)');
INSERT INTO engagement_status (status) VALUES ('Forming(2nd- 3rd visit)');
INSERT INTO engagement_status (status) VALUES ('Initial(Introductory visit)');
ALTER TABLE engagement_status ADD is_active INT(11) DEFAULT 0


--
-- Table structure for table `degrees`
--

CREATE TABLE IF NOT EXISTS `degrees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;


--
-- Table structure for table `titles`
--

CREATE TABLE IF NOT EXISTS `titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `abbr` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;


--
-- Table structure for table `additional_roles`
--

CREATE TABLE IF NOT EXISTS `additional_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Table structure for table `professional_suffix`
--

CREATE TABLE IF NOT EXISTS `professional_suffix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suffix` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Additional field for interactions as location_category
--
ALTER TABLE `interactions` ADD `location_category` VARCHAR(255) NOT NULL ;
--
-- Additional field for medical_insight as other
--
ALTER TABLE `medical_insight` ADD `other` TEXT NOT NULL AFTER `actions_to_consider`;
ALTER TABLE compliance_monitoring ADD state_id INT(11);
ALTER TABLE compliance_monitoring ADD city_id INT(11);

ALTER TABLE `interactions`     ADD COLUMN `quality_interaction` TINYINT(1) DEFAULT '0' NULL AFTER `location_category`;

CREATE TABLE `speaker_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_question_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`) VALUES ( NULL,'Email','1',NULL,NULL);



-- Titles table modification

ALTER TABLE  `titles` ADD  `client_id` INT( 11 ) NOT NULL DEFAULT  '12' AFTER  `abbr` ;

UPDATE titles SET client_id =12 ;

insert into titles values
    ('', 'Neurointensivist',12,1),
    ('', 'Ambulatory Care Pharmacist',12,1),
    ('', 'Clinical Pharmacist',12,1),
    ('', 'Clinical Pharmacy Manager',12,1),
    ('', 'Dietician',12,1),
    ('', 'Patient Safety & Quality',12,1),
    ('', 'Pharmacy Clinical Coordinator',12,1),
    ('', 'Registered Pharmacist Specialty Pharmacy',12,1),
    ('', 'Registered Pharmacist Hospital',12,1),
    ('', 'Research Coordinator',12,1),
    ('', 'Resident/Pharmacy',12,1),
    ('', 'Chief Resident',12,1);


INSERT INTO titles(title, abbr, client_id, is_active) 
SELECT distinct title, 'NULL', 8, 1 from kols where title not in (select title from titles) and 
title!='';

UPDATE kols
LEFT JOIN titles ON kols.title = titles.title
set kols.title=titles.id;

/* Medical insight */
ALTER TABLE `medical_insight` CHANGE `other` `other` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;


--db script to insert primary address of kol into 'kol_locations' table

SET FOREIGN_KEY_CHECKS =0;# MySQL returned an empty result set (i.e. zero rows).
INSERT INTO kol_locations(  `kol_id` ,  `org_institution_id` ,  `address1` ,  `address2` ,  `validation_status` ,  `country_id` ,  `state_id` ,  `city_id` ,  `postal_code` ,  `is_primary` ,  `created_by` ,  `created_on` ) 
SELECT id, org_id, address1, address2,  'Approved', country_id, state_id, city_id, postal_code, 1,  '11', NOW( ) 
FROM kols;


--additional degrees values

INSERT INTO degrees
VALUES (
'',  'BSN', 1
), (
'',  'MSN', 1
)


--for kol_locationss
ALTER TABLE  `kol_locations` ADD  `validated_address` BOOLEAN NOT NULL DEFAULT FALSE ;
ALTER TABLE compliance_monitoring ADD fma INT(12);

--for org_locations----
ALTER TABLE `org_locations` CHANGE `address3` `address3` VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `validation_status` `validation_status` VARCHAR(50) NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `address_type` `address_type` VARCHAR(50) NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `postal_code` `postal_code` VARCHAR(50) NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `postal_extension` `postal_extension` VARCHAR(50) NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `postal_city` `postal_city` VARCHAR(255) NULL DEFAULT NULL;

--db script to insert primary address of org into 'org_locations' table
SET FOREIGN_KEY_CHECKS =0;
INSERT INTO org_locations(`org_id`,`main`,`address1`,`validation_status`,`country_id`,`state_id`,`city_id`,`postal_code`,`is_primary`,`created_by`,`created_on`) 
SELECT id,name,address,'Approved',country_id,state_id,city_id,postal_code, 1, '11', NOW( ) FROM organizations;

/** alert command to key_insight_topics_association **/
ALTER TABLE `key_insight_topics_association` ADD `theraputic_area_id` INT(12) NULL DEFAULT NULL FIRST;

insert into key_insight_topics_association (theraputic_area_id,product_id,key_insight_topic_id,status)
select theraputic_areas.id as theraputic_area_id, products.id as product_id ,key_insight_topics.id as key_insight_topic_id,1  from producr_dummy
left join theraputic_areas on producr_dummy.TheraputicArea=theraputic_areas.name
left join products on producr_dummy.ProductCategory=products.name
left join key_insight_topics on producr_dummy.KeyInsightTopics=key_insight_topics.name;

UPDATE products SET name = 'Neudexta' WHERE id = 3;
UPDATE products SET name = 'Busulfex' WHERE id = 6;
UPDATE products SET name = 'Rexulti-SZ' WHERE id = 8;
INSERT INTO products (name, status, created_by, created_on, modified_by, modified_on) VALUES ('Rexulti-MDD', 1, 11, null, null, null);


--
-- Table structure for table `best_time`
--

CREATE TABLE IF NOT EXISTS `best_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

UPDATE kols SET created_by = 1000 WHERE id IN (SELECT id FROM otsuka_merge.kols WHERE STATUS = "Not Requested");
 
 ALTER TABLE `kol_activities_count` ADD CONSTRAINT `FK_kol_activities_count_kol_fk` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE NO ACTION  ON UPDATE NO ACTION ;
 
ALTER TABLE `groups`     ADD COLUMN `group_type` VARCHAR(50) DEFAULT 'Group' NULL AFTER `group_name`;
UPDATE `iprofile_crm`.`groups` SET `group_type`='Team' WHERE `group_id`='19';
UPDATE `iprofile_crm`.`groups` SET `group_type`='Team' WHERE `group_id`='23';
UPDATE `iprofile_crm`.`groups` SET `group_type`='Team' WHERE `group_id`='24';
UPDATE `iprofile_crm`.`groups` SET `group_type`='Team' WHERE `group_id`='25';
UPDATE `iprofile_crm`.`groups` SET `group_type`='Team' WHERE `group_id`='26';
 
ALTER TABLE `medical_insight` ADD `client_id` INT(11) NOT NULL ;
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 1, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 2, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 3, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 4, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 8, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 6, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 5, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 9, 1, null, null, null, null);
-- 
-- 
-- SELECT id,name FROM theraputic_area_products LEFT join products
--                     ON theraputic_area_products.product_id=products.id where theraputic_area_id=2
--                     
--                     
-- insert into theraputic_area_products (theraputic_area_id,product_id,status)
-- select theraputic_areas.id as theraputic_area_id, products.id as product_id ,1  from producr_dummy
-- left join theraputic_areas on producr_dummy.TheraputicArea=theraputic_areas.name
-- left join products on producr_dummy.ProductCategory=products.name
-- 
-- 
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 1, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 2, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 3, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 4, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 8, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 6, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 5, 1, null, null, null, null);
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 9, 1, null, null, null, null);
-- 
-- 
-- 
-- 
-- INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 7, 1, null, null, null, null);


ALTER TABLE `specialties`     ADD COLUMN `client_id` INT(11) NULL AFTER `specialty`;
UPDATE specialties SET client_id = 12 WHERE specialty IN ("Abdominal Surgery","Advance Heart Failure and Transplant Cardiology","Aerospace Medicine","Allergy","Allergy And Immunology","Allergy/Immunology, Diag Lab Immun","Anatomic Pathology","Anesthesiology","Biochemistry","Bone Marrow Transplantation","Breast Cancer","Cardiology","Cell Biology","Clinical Genetics","Clinical Molecular Genetics","Critical Care Medicine","Critical Care Surgery","Dermatology","Diabetes","Emergency Medicine","Endocrine tumors","Endocrinology","Epidemiology","Epilepsy","Family Medicine","Gastroenterology","Gastroenterology Oncology","General Medicine","General Practice","Genitourinary Oncology","Geriatrics","Gynecology","Gynecology Oncology","Head and Neck Oncology","Health Policy & Management","Hematology","Hematology/Oncology","Hepatology","Hospice Palliative Medicine","Hospitalist","Immunology","Infectious Diseases","Intensivists","Internal Medicine","Leukemia (AML,ALL, CML)","Lymphoma/Hodgkin’s Disease","Medical Genetics","Melanoma","Molecular Biology","Multiple Myeloma","Myelodysplastic Disease","Neoplastic Diseases","Nephrology","Neuro Oncology","Neurology","Nuclear Medicine","Nursing","Nutrition","Obstetrics","Obstetrics And Gynecology","Occupational Medicine","Oncology","Ophthalmology","Other Specialty","Pain Medicine","Palliative Medicine","Pathology","Pediatrics","Pharmacology, Clinical","Pharmacy","Physical Medicine and Rehabilitation","Physiology","Preventive Medicine, General","Proctology","Psychiatry","Psychiatry - Addiction","Psychiatry - Alzheimer's Disease","Psychiatry - Anxiety Disorders","Psychiatry - Bipolar","Psychiatry - Child/Adolescent","Psychiatry - Depression","Psychiatry - Forensic","Psychiatry - Geriatric","Psychiatry - Schizophrenia","Psychiatry/Neurology - Developmental Disorders/Autism","Psychiatry/Neurology - Tourettes/tics","Psychoanalysis","Psychology","Psychosomatic Medicine","Public Health","Pulmonary Diseases","Radiology","Rheumatology","Sarcoma","Skin cancer","Sleep Medicine","Social Work","Statistics","Surgery, General","Thoracic Oncology","Transplantation","Urology")
 
ALTER TABLE `medical_insight` DROP `client_id`;

ALTER TABLE iprofile_crm.coachings ADD generic_id VARCHAR(255);
ALTER TABLE iprofile_crm.compliance_monitoring ADD generic_id VARCHAR(255);


ALTER TABLE iprofile_crm.coachings MODIFY COLUMN planscore INT;
ALTER TABLE iprofile_crm.coachings MODIFY COLUMN wrapscore INT;
	ALTER TABLE iprofile_crm.coachings MODIFY COLUMN openscore INT;
	ALTER TABLE iprofile_crm.coachings MODIFY COLUMN medscore INT;

ALTER TABLE `kols`     ADD COLUMN `customer_status` VARCHAR(100) DEFAULT "ACTV";
ALTER TABLE `organizations`     ADD COLUMN `customer_status` VARCHAR(100) DEFAULT "ACTV";

ALTER TABLE `kols` ADD INDEX `customer_status` (`customer_status`);
ALTER TABLE `organizations` ADD INDEX `customer_status` (`customer_status`);


ALTER TABLE `kols` ADD COLUMN `do_not_call_flag` INT(11) DEFAULT '0' NULL AFTER `is_kol`;

ALTER TABLE `variable_radius_analytics`     
ADD COLUMN `trn_type` VARCHAR(255) DEFAULT 'VR' NULL AFTER `id`,     
ADD COLUMN `mdm_id` VARCHAR(255) NULL AFTER `created_on`,     
ADD COLUMN `dnc_flag` INT(11) NULL AFTER `mdm_id`,     
ADD COLUMN `modified_on` TIMESTAMP NULL AFTER `dnc_flag`;
ALTER TABLE `variable_radius_analytics`     CHANGE `created_on` `created_on` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL ;


/* Medical Insight*/
ALTER TABLE `medical_insight` CHANGE `created_on` `created_on` DATE NULL DEFAULT NULL;

/* add is_primary column for kol phone_numbers */
ALTER TABLE  `phone_numbers` ADD  `is_primary` BOOLEAN NOT NULL DEFAULT FALSE AFTER `contact`;

/* location id for staff and phone numbers table*/
ALTER TABLE phone_numbers ADD COLUMN location_id INT(11) NULL AFTER contact;
ALTER TABLE staffs ADD COLUMN location_id INT(11) NULL AFTER contact;

ALTER TABLE phone_numbers ADD COLUMN location_id INT(11) NULL AFTER contact;
ALTER TABLE staffs ADD COLUMN location_id INT(11) NULL AFTER contact;

ALTER TABLE `org_locations` CHANGE `postal_city` `phone_number_primary` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `postal_extension` `phone_type_primary` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;

ALTER TABLE  `kol_locations` ADD  `phone_type` VARCHAR( 100 ) NOT NULL AFTER  `postal_city` ,
ADD  `phone_number` VARCHAR( 255 ) NOT NULL AFTER  `phone_type` ;


-- TABLE kol_products

CREATE TABLE  `kol_products` (
 `id` INT( 11 ) NOT NULL AUTO_INCREMENT ,
 `kol_id` INT( 11 ) DEFAULT NULL ,
 `product_id` INT( 11 ) DEFAULT NULL ,
PRIMARY KEY (  `id` ) ,
KEY  `FK_kol_products` (  `kol_id` ) ,
CONSTRAINT  `FK_kol_products` FOREIGN KEY (  `kol_id` ) REFERENCES  `kols` (  `id` ) ON DELETE CASCADE ON UPDATE CASCADE ,
KEY  `FK_kol_products1` (  `product_id` ) ,
CONSTRAINT  `FK_kol_products1` FOREIGN KEY (  `product_id` ) REFERENCES  `products` (  `id` ) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = INNODB AUTO_INCREMENT =11 DEFAULT CHARSET = utf8

ALTER TABLE `iprofile_crm`.`medical_insight` 
ADD COLUMN `generic_id` VARCHAR(255) CHARACTER SET 'big5' NULL AFTER `client_id`;


ALTER TABLE `iprofile_crm`.`speaker_evaluations` 
CHANGE COLUMN `generic_id` `generic_id` VARCHAR(256) NULL DEFAULT NULL ;


ALTER TABLE `iprofile_crm`.`interactions` 
ADD COLUMN `generic_id` VARCHAR(45) NULL AFTER `quality_interaction`;

ALTER TABLE  `kol_locations` ADD  `validated_address` BOOLEAN NOT NULL DEFAULT FALSE ;
ALTER TABLE compliance_monitoring ADD fma INT(12);

ALTER TABLE `org_locations` CHANGE `postal_city` `phone_number_primary` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `org_locations` CHANGE `postal_extension` `phone_type_primary` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `iprofile_crm`.`kol_locations` 
ADD COLUMN `generic_id` VARCHAR(255) NULL AFTER `validated_address`;


ALTER TABLE `medical_insight` ADD CONSTRAINT `FK_medical_insight_user` FOREIGN KEY (`created_by`) REFERENCES `client_users` (`id`) ON DELETE NO ACTION  ON UPDATE NO ACTION ;
ALTER TABLE `client_users` ADD INDEX `NewIndex4` (`client_id`);
ALTER TABLE `interaction_topics_by_type`     ADD COLUMN `product_id` INT(12) NULL FIRST;
ALTER TABLE `interaction_topics_by_type` ADD CONSTRAINT `FK_interaction_topics_by_type` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE  ON UPDATE CASCADE ;
/**
Update empty generic ids
**/
UPDATE medical_insight
SET generic_id = CONCAT("MI",100000+id);


UPDATE compliance_monitoring
SET generic_id = CONCAT("CF",100000+id);

UPDATE coachings
SET generic_id = CONCAT("CEF",100000+id);

UPDATE interactions
SET generic_id = CONCAT("IF",100000+id);

UPDATE kol_locations
SET generic_id = CONCAT("LF",100000+id);

UPDATE speaker_evaluations
SET generic_id = CONCAT("SE",100000+id);



ALTER TABLE `iprofile_crm`.`coachings` 
ADD COLUMN `hcp_names` TEXT NULL AFTER `created_on`;


ALTER TABLE `speaker_evaluations`     ADD COLUMN `city` VARCHAR(255) NULL AFTER `generic_id`,     ADD COLUMN `city_id` INT(11) NULL AFTER `city`,     ADD COLUMN `state` VARCHAR(255) NULL AFTER `city_id`,     ADD COLUMN `state_id` INT(11) NULL AFTER `state`,     ADD COLUMN `country` VARCHAR(255) NULL AFTER `state_id`,     ADD COLUMN `country_id` INT(11) NULL AFTER `country`;

ALTER TABLE `iprofile_crm`.`org_locations` 
ADD COLUMN `generic_id` VARCHAR(255) NULL AFTER `modified_on`;


ALTER TABLE `iprofile_crm`.`interaction_mirf` 
ADD COLUMN `generic_id` VARCHAR(255) NULL AFTER `modified_on`;



ALTER TABLE iprofile_crm.medical_insight ADD ireport_id varchar(50);

ALTER TABLE `iprofile_crm`.`coachings` 
ADD COLUMN `ireport_id` INT(11) NULL AFTER `hcp_names`;

ALTER TABLE `iprofile_crm`.`interaction_mirf` 
ADD COLUMN `generic_id` VARCHAR(255) NULL AFTER `modified_on`;

ALTER TABLE `iprofile_crm`.`compliance_monitoring_kols` 
ADD COLUMN `hcpname` VARCHAR(255) ;


ALTER TABLE `kols`     ADD COLUMN `is_duplicate_case` TINYINT(1) DEFAULT '0' NULL;
UPDATE client_users SET is_activated = 1 WHERE id < 12303;


ALTER TABLE `iprofile_crm`.`log_activities` 
CHANGE COLUMN `miscellaneous1` `kol_id` INT NULL DEFAULT NULL ;

INSERT INTO log_activities(created_on, created_by,type,status,transaction_name)
SELECT login_time, user_id, "8",case is_login_failed
       when '1' then "fail"
       when '0' then "success"
   end ,"login" FROM users_analytics;

UPDATE iprofile_crm.investigational_agent SET Is_active = 0 WHERE id = 1;
INSERT INTO iprofile_crm.investigational_agent (id, name, Is_active, created_by, created_on, modified_by, modified_on) VALUES (5, 'AVP 786', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.investigational_agent (id, name, Is_active, created_by, created_on, modified_by, modified_on) VALUES (6, 'MIND1', 1, 11, null, 11, null);

UPDATE iprofile_crm.source_type SET name = 'Congress' WHERE id = 7 AND name = 'Congress symposia/poster session' AND is_active = 1 AND created_by = 11 AND created_on = '2015-11-03 14:42:06' AND modified_by = 11 AND modified_on = '2015-11-03 14:42:06';
UPDATE iprofile_crm.source_type SET name = 'Other' WHERE id = 9;

INSERT INTO iprofile_crm.sphere_of_influence (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (5, 'VA National', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.sphere_of_influence (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (6, 'VA Regional', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.sphere_of_influence (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (7, 'VA Local', 1, 11, null, 11, null);


INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('Outcomes', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('Competitor', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('Topic Suggestions', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('PBA: General', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('PBA:  Diagnosis', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('PBA: Burden of Illness', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('ADVOCACY', 1, null, null, null, null, '');
UPDATE iprofile_crm.key_insight_topics SET name = 'DSM 5  (ICD-10)' WHERE id = 18;



UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 4 AND key_insight_topic_id = 2 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 4 AND key_insight_topic_id = 17 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 4 AND key_insight_topic_id = 20 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 4 AND key_insight_topic_id = 53 AND status = 1;


UPDATE iprofile_crm.key_insight_topics_association SET theraputic_area_id = 1 WHERE theraputic_area_id = 3 AND product_id = 9 AND key_insight_topic_id = 19 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET theraputic_area_id = 1 WHERE theraputic_area_id = 3 AND product_id = 9 AND key_insight_topic_id = 46 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET theraputic_area_id = 1 WHERE theraputic_area_id = 3 AND product_id = 9 AND key_insight_topic_id = 50 AND status = 1;
UPDATE iprofile_crm.key_insight_topics_association SET theraputic_area_id = 1 WHERE theraputic_area_id = 3 AND product_id = 9 AND key_insight_topic_id = 52 AND status = 1;
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 1, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 1, 68, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 2, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 2, 68, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 3, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 3, 68, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 4, 69, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 4, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 8, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 8, 68, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 70, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 71, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 72, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 73, 1, null, null, null, null);



UPDATE iprofile_crm.products SET name = 'NUEDEXTA' WHERE id = 3;

CREATE TABLE `congress_sources` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO iprofile_crm.congress_sources (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (1, 'Poster', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.congress_sources (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (2, 'Symposium', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.congress_sources (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (3, '1:1 HCP', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.congress_sources (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (4, 'Industry professional', 1, 11, null, 11, null);


ALTER TABLE `iprofile_crm`.`medical_insight` 
ADD COLUMN `congress_sources` VARCHAR(255) NULL COMMENT '' AFTER `ireport_id`;

UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 4 AND key_insight_topic_id = 47 AND status = 1;

UPDATE iprofile_crm.key_insight_topics SET name = 'Use of Rexulti' WHERE id = 64;
UPDATE iprofile_crm.key_insight_topics SET status = 0 WHERE id = 65;
UPDATE iprofile_crm.key_insight_topics_association SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 8 AND key_insight_topic_id = 65 AND status = 1;

UPDATE iprofile_crm.products SET name = 'Rexulti' WHERE id = 8;
UPDATE iprofile_crm.products SET status = 0 WHERE id = 10;
UPDATE iprofile_crm.theraputic_area_products SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 10 AND status = 1;

TRUNCATE TABLE iprofile_crm.interaction_location_types;
INSERT INTO iprofile_crm.interaction_location_types (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (1, 'In Office', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.interaction_location_types (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (2, 'Out of Office', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.interaction_location_types (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (3, 'Congress', 1, 11, null, 11, null);
INSERT INTO iprofile_crm.interaction_location_types (id, name, is_active, created_by, created_on, modified_by, modified_on) VALUES (4, 'Internal Meetings', 1, 11, null, 11, null);
UPDATE iprofile_crm.theraputic_areas SET name = 'Hospital' WHERE id = 3;

SET FOREIGN_KEY_CHECKS=0;

DELETE FROM iprofile_crm.key_insight_topics WHERE id = 70;
DELETE FROM iprofile_crm.key_insight_topics WHERE id = 71;
DELETE FROM iprofile_crm.key_insight_topics WHERE id = 72;
UPDATE iprofile_crm.key_insight_topics SET id = 70 WHERE id = 73;
DELETE FROM iprofile_crm.key_insight_topics_association WHERE theraputic_area_id = 1 AND product_id = 9 AND key_insight_topic_id = 71 AND status = 1;
DELETE FROM iprofile_crm.key_insight_topics_association WHERE theraputic_area_id = 1 AND product_id = 9 AND key_insight_topic_id = 72 AND status = 1;
DELETE FROM iprofile_crm.key_insight_topics_association WHERE theraputic_area_id = 1 AND product_id = 9 AND key_insight_topic_id = 73 AND status = 1;
UPDATE iprofile_crm.products SET name = 'IV Busulfex' WHERE id = 6;
UPDATE iprofile_crm.key_insight_topics_association SET key_insight_topic_id = 67 WHERE theraputic_area_id = 2 AND product_id = 6 AND key_insight_topic_id = 40 AND status = 1;
UPDATE iprofile_crm.key_insight_topics SET name = 'Outcomes (readmission, quality, etc)' WHERE id = 40;
UPDATE iprofile_crm.key_insight_topics_association SET key_insight_topic_id = 40 WHERE theraputic_area_id = 1 AND product_id = 1 AND key_insight_topic_id = 67 AND status = 1;


ALTER TABLE `iprofile_crm`.`log_activities` 
CHANGE COLUMN `miscellaneous3` `user_id` VARCHAR(255) NULL DEFAULT NULL ,
CHANGE COLUMN `miscellaneous4` `manager_id` VARCHAR(255) NULL DEFAULT NULL ;

INSERT INTO `iprofile_crm`.`theraputic_areas` (`id`, `name`, `status`) VALUES ('4', 'Hospital', '0');
UPDATE `iprofile_crm`.`theraputic_areas` SET `status`='1' WHERE `id`='2';
UPDATE `iprofile_crm`.`theraputic_areas` SET `status`='1' WHERE `id`='3';
UPDATE `iprofile_crm`.`theraputic_areas` SET `name`='Hospital' WHERE `id`='3';
UPDATE `iprofile_crm`.`theraputic_areas` SET `name`='Cardio-Renal' WHERE `id`='4';

ALTER TABLE `iprofile_crm`.`medical_insight` 
ADD COLUMN `congress_name` VARCHAR(255) NULL COMMENT '' AFTER `generic_id`;

INSERT INTO `iprofile_crm`.`professional_suffix` (`suffix`, `is_active`) VALUES ('MBA', '1');
INSERT INTO `iprofile_crm`.`professional_suffix` (`suffix`, `is_active`) VALUES ('MBBS', '1');
INSERT INTO `iprofile_crm`.`professional_suffix` (`suffix`, `is_active`) VALUES ('RN', '1');
INSERT INTO `iprofile_crm`.`professional_suffix` (`suffix`, `is_active`) VALUES ('ScD', '1');

CREATE TABLE `ol_speaker_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;



ALTER TABLE `compliance_monitoring`     ADD COLUMN `ireport_id` VARCHAR(255) NULL AFTER `generic_id`;

## specialties removed for overall list
UPDATE specialties SET specialties.all = 0 WHERE id IN (63,65,68,67,55,73,72,2,57,38,12,117,118,121);

ALTER TABLE `iprofile_crm`.`products` 
ADD COLUMN `type` VARCHAR(100) NULL COMMENT '' AFTER `created_by`;

INSERT INTO `iprofile_crm`.`products` (`id`, `name`, `status`, `created_by`, `type`) VALUES ('23', 'Sativex', '1', '11', 'investigational_agent');
INSERT INTO `iprofile_crm`.`products` (`id`, `name`, `status`, `created_by`, `type`) VALUES ('24', 'LUU AE58054', '1', '11', 'investigational_agent');
INSERT INTO `iprofile_crm`.`products` (`id`, `name`, `status`, `created_by`, `type`) VALUES ('25', 'AVP 786', '1', '11', 'investigational_agent');
INSERT INTO `iprofile_crm`.`products` (`id`, `name`, `status`, `created_by`, `type`) VALUES ('26', 'MIND1', '1', '11', 'investigational_agent');
INSERT INTO `iprofile_crm`.`products` (`id`, `name`, `status`, `created_by`, `type`) VALUES ('27', 'Other', '1', '11', 'investigational_agent');

INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 23, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 24, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 25, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 26, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 27, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 23, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 24, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 25, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 26, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 27, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 23, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 24, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 25, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 26, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 27, 1, null, null, null, null);


INSERT INTO group_products (group_id,product_id) VALUES(24,19),(25,19),(19,20),(25,20);
INSERT INTO group_products (PRODUCT_ID,group_id) VALUES(22,19),(22,23),(22,24),(22,25),(22,26);
INSERT INTO group_products (group_id,product_id) VALUES(26,19),(26,20);

DELETE FROM iprofile_crm.org_mco_type WHERE id = 9 AND name = 'Medicaid';

ALTER TABLE `kols`     ADD COLUMN `aissel_alignment_id` VARCHAR(100) NULL AFTER `address_id`;

ALTER TABLE `kols` CHANGE `specialty` `specialty` INT(10) DEFAULT 0;

/* interaction changes */

ALTER TABLE iprofile_crm.interaction_grouping ADD org_active INT(10)
 
UPDATE iprofile_crm.interaction_grouping SET org_active = 1 WHERE id = 2;

 
ALTER TABLE iprofile_crm.interactions_modes ADD org_active INT(11)


UPDATE iprofile_crm.interactions_modes SET org_active = 1 WHERE id = 1;


UPDATE iprofile_crm.interactions_modes SET org_active = 1 WHERE id = 2;

UPDATE iprofile_crm.interactions_modes SET org_active = 1 WHERE id = 3;


UPDATE iprofile_crm.interactions_modes SET org_active =0  WHERE id = 4;


ALTER TABLE `iprofile_crm`.`log_activities` 
CHANGE COLUMN `transaction_id` `transaction_id` VARCHAR(255) NULL DEFAULT NULL ;

UPDATE `iprofile_crm`.`products` SET `name`='Nuedexta' WHERE `id`='3';
update medical_insight set product="Nuedexta" where product="NUEDEXTA";


UPDATE iprofile_crm.products SET name = 'Rexulti – Schizophrenia' WHERE id = 8;
UPDATE iprofile_crm.products SET status = 1 WHERE id = 10;
UPDATE iprofile_crm.theraputic_area_products SET status = 1 WHERE theraputic_area_id = 1 AND product_id = 10;

INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 2, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 17, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 20, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 37, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 47, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 53, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 59, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 64, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 10, 68, 1, null, null, null, null);


/** product changes **/
UPDATE iprofile_crm.products SET status = 1 WHERE id = 10;
INSERT INTO iprofile_crm.products (name, status, created_by, type, created_on, modified_by, modified_on, otsuka_id) VALUES ('Rexulti – Schizophrenia', 1, 11, '', null, null, null, '');

INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 1, null, null, null, null);

INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 2, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 17, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 20, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 37, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 47, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 53, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 59, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 64, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 67, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 28, 68, 1, null, null, null, null);



UPDATE iprofile_crm.interaction_type_by_product SET product_id = 10 WHERE id = 33;
UPDATE iprofile_crm.interaction_type_by_product SET product_id = 10 WHERE id = 34;
UPDATE iprofile_crm.interaction_type_by_product SET product_id = 10 WHERE id = 35;
UPDATE iprofile_crm.interaction_type_by_product SET product_id = 10 WHERE id = 36;
INSERT INTO iprofile_crm.interaction_type_by_product (product_id, type_id, status, created_by, created_on, modified_by, modified_on) VALUES (28, 1, 1, null, null, null, null);
INSERT INTO iprofile_crm.interaction_type_by_product (product_id, type_id, status, created_by, created_on, modified_by, modified_on) VALUES (28, 2, 1, null, null, null, null);
INSERT INTO iprofile_crm.interaction_type_by_product (product_id, type_id, status, created_by, created_on, modified_by, modified_on) VALUES (28, 3, 1, null, null, null, null);
INSERT INTO iprofile_crm.interaction_type_by_product (product_id, type_id, status, created_by, created_on, modified_by, modified_on) VALUES (28, 4, 1, null, null, null, null);


UPDATE iprofile_crm.theraputic_area_products SET status = 0 WHERE theraputic_area_id = 1 AND product_id = 8 AND status = 1;
UPDATE iprofile_crm.key_insight_topics SET name = 'Use of Nuedexta' WHERE id = 62;
update medical_insight set topics="Use of Nuedexta" where topics="Use of Neudexta";

## MSL activity table
CREATE TABLE `msl_activity_report_data` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `activity_name` VARCHAR(50) DEFAULT NULL,
  `activity_id` INT(12) DEFAULT NULL,
  `activity_date` DATETIME DEFAULT NULL,
  `activity_by` INT(11) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `NewIndex1` (`activity_name`),
  KEY `NewIndex2` (`activity_id`),
  KEY `NewIndex3` (`activity_date`),
  KEY `NewIndex4` (`activity_by`),
  KEY `NewIndex5` (`activity_by`,`activity_date`)
) ENGINE=INNODB AUTO_INCREMENT=139843 DEFAULT CHARSET=utf8;


ALTER TABLE `client_users`     ADD COLUMN `is_test_user` TINYINT(1) DEFAULT '0' NULL;



/* interaction new subtopics*/
	
INSERT INTO iprofile_crm.interaction_sub_topics (name, status, code, created_by, created_on, modified_by, modified_on) VALUES ('VF Satellite (Live)', 0, '', 0, null, null, null);
INSERT INTO iprofile_crm.interaction_sub_topics (name, status, code, created_by, created_on, modified_by, modified_on) VALUES ('VF Satellite (Rebroadcast)', 0, '', 0, null, null, null);

INSERT INTO iprofile_crm.interaction_sub_topics_association (type_id, topic_id, product_id, sub_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 1, 4, 124, 1, null, null, null, null);
INSERT INTO iprofile_crm.interaction_sub_topics_association (type_id, topic_id, product_id, sub_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 1, 4, 125, 1, null, null, null, null);


/** Medical Insight **/
UPDATE iprofile_crm.products SET name = 'Digital Health' WHERE id = 26;
INSERT INTO iprofile_crm.products (name, status, created_by, type, created_on, modified_by, modified_on, otsuka_id) VALUES ('ANTIPSYCHOTICS – GENERAL', 1, 11, 'investigational_agent', null, null, null, '');
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 29, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 29, 1, null, null, null, null);
INSERT INTO iprofile_crm.theraputic_area_products (theraputic_area_id, product_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 29, 1, null, null, null, null);
INSERT INTO iprofile_crm.key_insight_topics (name, status, created_by, created_on, modified_by, modified_on, otsuka_code) VALUES ('Schizophrenia: general', 1, null, null, null, null, '');
INSERT INTO iprofile_crm.key_insight_topics_association (theraputic_area_id, product_id, key_insight_topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (1, 9, 71, 1, null, null, null, null);

UPDATE iprofile_crm.products SET name = 'Rexulti-Schiz' WHERE id = 28;

/**Interaction Changes**/
ALTER TABLE `interactions` CHANGE `created_on` `created_on` DATETIME NOT NULL;
ALTER TABLE `interactions` CHANGE `date` `date` DATETIME NULL DEFAULT NULL;


/* new  interaction topic for rexulti */
INSERT INTO `interaction_topics`(`id`,`name`,`status`,`code`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 71,'Speaker Direct Program','1',NULL,NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00');

INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '10','2','71','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '28','2','71','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);



INSERT INTO `interaction_sub_topics_association` (`type_id`, `topic_id`, `product_id`, `sub_topic_id`, `status`, `created_by`, `created_on`, `modified_by`, `modified_on`) VALUES ('3', '1', '4', '13', '1', NULL, CURRENT_TIMESTAMP, NULL, '0000-00-00 00:00:00');
INSERT INTO `interaction_sub_topics_association` (`type_id`, `topic_id`, `product_id`, `sub_topic_id`, `status`, `created_by`, `created_on`, `modified_by`, `modified_on`) VALUES ('1', '1', '4', '13', '1', NULL, CURRENT_TIMESTAMP, NULL, '0000-00-00 00:00:00');

CREATE TABLE `interactions_deleted` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `client_id` int(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `fromtime` time DEFAULT NULL,
  `mode` int(50) DEFAULT NULL,
  `location` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `follow_up_on` date DEFAULT NULL,
  `reminder` tinyint(1) DEFAULT NULL,
  `notes` text CHARACTER SET latin1,
  `created_by` int(50) NOT NULL,
  `created_on` date NOT NULL,
  `modified_by` int(50) NOT NULL,
  `modified_on` date NOT NULL,
  `calendar_event_id` int(10) DEFAULT '0',
  `totime` time DEFAULT NULL,
  `total_attendies` int(11) DEFAULT NULL,
  `grouping` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `location_type` int(11) DEFAULT NULL,
  `mirf_case_num` varchar(255) DEFAULT NULL,
  `territory_id` varchar(150) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `save_later` int(1) DEFAULT NULL,
  `is_org_interaction` tinyint(1) DEFAULT '0',
  `location_category` varchar(255) NOT NULL,
  `quality_interaction` tinyint(1) DEFAULT '0',
  `generic_id` varchar(45) DEFAULT NULL,
  `otsuka_id` double DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `NewIndex1` (`employee_id`),
  KEY `NewIndex2` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**dropdown list for HCP Title**/
INSERT INTO  `titles` (`id` ,`title` ,`abbr` ,`client_id` ,`is_active`)VALUES ('35',  'MSW',  '',  '12',  '1');
INSERT INTO  `titles` (`id` ,`title` ,`abbr` ,`client_id` ,`is_active`)VALUES ('36',  'LPC (licensed professional counselor)',  '',  '12',  '1');
INSERT INTO  `titles` (`id` ,`title` ,`abbr` ,`client_id` ,`is_active`)VALUES ('37',  'Social Work',  '',  '12',  '1');
INSERT INTO  `titles` (`id` ,`title` ,`abbr` ,`client_id` ,`is_active`)VALUES ('38',  'LMSW',  '',  '12',  '1');

/**interaction alter commands**/
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 112;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 109;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 110;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 111;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 115;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 113;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 114;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 108;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 117;
UPDATE interaction_sub_topics_association SET product_id = 9 WHERE type_id = 1 AND topic_id = 1 AND product_id = 5 AND sub_topic_id = 116;

/**private practice**/
ALTER TABLE `kol_locations` ADD `private_practice` VARCHAR(255) NOT NULL ;

/**interaction alter commands**/
INSERT INTO interaction_topics( name, 
STATUS , code, created_by, created_on, modified_by, modified_on ) 
VALUES (
'Survey', 1,  '', NULL , NULL , NULL , NULL
);
INSERT INTO `interaction_topics_by_type` (`product_id`, `type_id`, `topic_id`, `status`, `created_by`, `created_on`, `modified_by`, `modified_on`, `id`) VALUES ('9', '1', '12', '1', NULL, CURRENT_TIMESTAMP, NULL, '0000-00-00 00:00:00', NULL);
INSERT INTO interaction_topics_by_type (product_id, type_id, topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (9, 3, 72, 1, null, null, null, null);
INSERT INTO interaction_topics_by_type (product_id, type_id, topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (2, 3, 72, 1, null, null, null, null);
INSERT INTO interaction_topics_by_type (product_id, type_id, topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (10, 3, 72, 1, null, null, null, null);
INSERT INTO interaction_topics_by_type (product_id, type_id, topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (28, 3, 72, 1, null, null, null, null);
INSERT INTO interaction_topics_by_type (product_id, type_id, topic_id, status, created_by, created_on, modified_by, modified_on) VALUES (3, 3, 72, 1, null, null, null, null);


ALTER TABLE `organizations` CHANGE `key_products` `key_products` TEXT NULL;
ALTER TABLE `org_payer_facts` CHANGE `specialty_pharmacy` `specialty_pharmacy` TEXT NULL ;

# to track disable and delete users
ALTER TABLE `client_users` ADD COLUMN `status` TINYINT(1) DEFAULT '0' NULL COMMENT '1 for diabled and 2 for deleted' AFTER `name_order`,     ADD COLUMN `deleted_by` INT(11) NULL AFTER `status`,     ADD COLUMN `deleted_on` DATETIME NULL AFTER `deleted_by`,     ADD COLUMN `status_modified_by` INT(11) NULL AFTER `deleted_on`,     ADD COLUMN `status_modified_on` DATETIME NULL AFTER `status_modified_by`;

ALTER TABLE `client_users` ADD COLUMN `failed_attempts` INT(11) DEFAULT '0' NULL;

CREATE TABLE IF NOT EXISTS `password_analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `last_created` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

update countries set GlobalRegion='Latin America' where CountryId='10';
update countries set GlobalRegion='South Pacific' where CountryId='14';
update countries set GlobalRegion='Europe' where CountryId='15';
update countries set GlobalRegion='AMED' where CountryId='18';
update countries set GlobalRegion='Greater Asia' where CountryId='23';
update countries set GlobalRegion='Europe' where CountryId='24';
update countries set GlobalRegion='Latin America' where CountryId='29';
update countries set GlobalRegion='Europe' where CountryId='30';
update countries set GlobalRegion='Latin America' where CountryId='33';
update countries set GlobalRegion='Europe' where CountryId='37';
update countries set GlobalRegion='North America' where CountryId='43';
update countries set GlobalRegion='Latin America' where CountryId='48';
update countries set GlobalRegion='Greater Asia' where CountryId='49';
update countries set GlobalRegion='Latin America' where CountryId='53';
update countries set GlobalRegion='Latin America' where CountryId='59';
update countries set GlobalRegion='Europe' where CountryId='61';
update countries set GlobalRegion='Europe' where CountryId='64';
update countries set GlobalRegion='Europe' where CountryId='65';
update countries set GlobalRegion='Latin America' where CountryId='68';
update countries set GlobalRegion='Latin America' where CountryId='70';
update countries set GlobalRegion='Latin America' where CountryId='72';
update countries set GlobalRegion='Europe' where CountryId='75';
update countries set GlobalRegion='Europe' where CountryId='81';
update countries set GlobalRegion='Europe' where CountryId='82';
update countries set GlobalRegion='Greater Asia' where CountryId='90';
update countries set GlobalRegion='Europe' where CountryId='91';
update countries set GlobalRegion='Europe' where CountryId='95';
update countries set GlobalRegion='Latin America' where CountryId='100';
update countries set GlobalRegion='Latin America' where CountryId='108';
update countries set GlobalRegion='Greater Asia' where CountryId='109';
update countries set GlobalRegion='Europe' where CountryId='111';
update countries set GlobalRegion='Europe' where CountryId='112';
update countries set GlobalRegion='Greater Asia' where CountryId='113';
update countries set GlobalRegion='Europe' where CountryId='117';
update countries set GlobalRegion='AMED' where CountryId='118';
update countries set GlobalRegion='Europe' where CountryId='119';
update countries set GlobalRegion='Greater Asia' where CountryId='122';
update countries set GlobalRegion='AMED' where CountryId='126';
update countries set GlobalRegion='Greater Asia' where CountryId='128';
update countries set GlobalRegion='AMED' where CountryId='134';
update countries set GlobalRegion='Europe' where CountryId='137';
update countries set GlobalRegion='AMED' where CountryId='138';
update countries set GlobalRegion='Europe' where CountryId='142';
update countries set GlobalRegion='Europe' where CountryId='143';
update countries set GlobalRegion='Europe' where CountryId='144';
update countries set GlobalRegion='Europe' where CountryId='146';
update countries set GlobalRegion='Greater Asia' where CountryId='149';
update countries set GlobalRegion='Latin America' where CountryId='159';
update countries set GlobalRegion='AMED' where CountryId='168';
update countries set GlobalRegion='Europe' where CountryId='175';
update countries set GlobalRegion='South Pacific' where CountryId='178';
update countries set GlobalRegion='Latin America' where CountryId='179';
update countries set GlobalRegion='Europe' where CountryId='185';
update countries set GlobalRegion='AMED' where CountryId='186';
update countries set GlobalRegion='Greater Asia' where CountryId='187';
update countries set GlobalRegion='Latin America' where CountryId='190';
update countries set GlobalRegion='Latin America' where CountryId='194';
update countries set GlobalRegion='Greater Asia' where CountryId='195';
update countries set GlobalRegion='Europe' where CountryId='197';
update countries set GlobalRegion='Europe' where CountryId='198';
update countries set GlobalRegion='AMED' where CountryId='200';
update countries set GlobalRegion='Europe' where CountryId='202';
update countries set GlobalRegion='Europe' where CountryId='203';
update countries set GlobalRegion='AMED' where CountryId='213';
update countries set GlobalRegion='Europe' where CountryId='215';
update countries set GlobalRegion='Greater Asia' where CountryId='219';
update countries set GlobalRegion='Europe' where CountryId='220';
update countries set GlobalRegion='Europe' where CountryId='221';
update countries set GlobalRegion='AMED' where CountryId='224';
update countries set GlobalRegion='Europe' where CountryId='226';
update countries set GlobalRegion='Europe' where CountryId='233';
update countries set GlobalRegion='Europe' where CountryId='234';
update countries set GlobalRegion='Greater Asia' where CountryId='236';
update countries set GlobalRegion='Greater Asia' where CountryId='239';
update countries set GlobalRegion='AMED' where CountryId='245';
update countries set GlobalRegion='Greater Asia' where CountryId='246';
update countries set GlobalRegion='Europe' where CountryId='251';
update countries set GlobalRegion='AMED' where CountryId='252';
update countries set GlobalRegion='Europe' where CountryId='253';
update countries set GlobalRegion='North America' where CountryId='254';
update countries set GlobalRegion='Latin America' where CountryId='256';
update countries set GlobalRegion='Greater Asia' where CountryId='257';
update countries set GlobalRegion='Latin America' where CountryId='259';
update countries set GlobalRegion='Greater Asia' where CountryId='260';

UPDATE `interactions_modes` SET `name`='Web Conference' WHERE `name`='Web';
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Lecture','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Letter, Direct Mail','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Lunch and Learn','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Mailing','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Other','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Presentation','1',NULL,NULL,NULL);
INSERT INTO `interactions_modes`(`id`,`name`,`client_id`,`created_by`,`Created_on`,`org_active`) VALUES ( NULL,'Seminar','1',NULL,NULL,NULL);


INSERT INTO `groups`(`group_id`,`group_name`,`group_type`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 1,'Colgate','Group','232',NULL,NULL,NULL);
INSERT INTO `groups`(`group_id`,`group_name`,`group_type`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 2,'Hills','Group','232',NULL,NULL,NULL);

INSERT INTO `products`(`id`,`name`,`status`,`created_by`,`type`,`created_on`,`modified_by`,`modified_on`,`otsuka_id`) VALUES ( 1,'COLGATE TOTAL','1','232',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00','');;
INSERT INTO `products`(`id`,`name`,`status`,`created_by`,`type`,`created_on`,`modified_by`,`modified_on`,`otsuka_id`) VALUES ( 2,'COLGATE OPTIC WHITE','1','232',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00','');
INSERT INTO `products`(`id`,`name`,`status`,`created_by`,`type`,`created_on`,`modified_by`,`modified_on`,`otsuka_id`) VALUES ( 3,'COLGATE ENAMEL HEALTH','1','232',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00','');
INSERT INTO `products`(`id`,`name`,`status`,`created_by`,`type`,`created_on`,`modified_by`,`modified_on`,`otsuka_id`) VALUES ( 4,'Hill\'s Prescription Diet','1','232',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00','');
INSERT INTO `products`(`id`,`name`,`status`,`created_by`,`type`,`created_on`,`modified_by`,`modified_on`,`otsuka_id`) VALUES ( 5,'Hill\'s Science Diet','1','232',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00','');

INSERT INTO `group_products`(`group_id`,`product_id`) VALUES ( '1','1');
INSERT INTO `group_products`(`group_id`,`product_id`) VALUES ( '1','2');
INSERT INTO `group_products`(`group_id`,`product_id`) VALUES ( '1','3');
INSERT INTO `group_products`(`group_id`,`product_id`) VALUES ( '2','4');
INSERT INTO `group_products`(`group_id`,`product_id`) VALUES ( '2','5');

INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_type_by_product`(`product_id`,`type_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_topics`(`id`,`name`,`status`,`code`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 1,'Authorship/Scientific Collaboration','1',NULL,NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00');
INSERT INTO `interaction_topics`(`id`,`name`,`status`,`code`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 2,'Product','1',NULL,NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00');
INSERT INTO `interaction_topics`(`id`,`name`,`status`,`code`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 3,'Clinical Trial Support','1',NULL,NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00');
INSERT INTO `interaction_topics`(`id`,`name`,`status`,`code`,`created_by`,`created_on`,`modified_by`,`modified_on`) VALUES ( 4,'Speaker Activities','1',NULL,NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00');


INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '1','4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '2','4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '3','4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '4','4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','1','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','2','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','3','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','4','1','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','1','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','2','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','3','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','4','2','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','1','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','2','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','3','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','4','3','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','1','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','2','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','3','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);
INSERT INTO `interaction_topics_by_type`(`product_id`,`type_id`,`topic_id`,`status`,`created_by`,`created_on`,`modified_by`,`modified_on`,`id`) VALUES ( '5','4','4','1',NULL,CURRENT_TIMESTAMP,NULL,'0000-00-00 00:00:00',NULL);

ALTER TABLE `interactions_other_attendees` ADD `comments` TEXT NOT NULL ;




/**log activity table alter commands for storing xhr status and xhr response for native app**/

ALTER TABLE `log_activities`  ADD `xhr_status` VARCHAR(15) NOT NULL;

ALTER TABLE `log_activities`  ADD `xhr_response` VARCHAR(255) NOT NULL;


CREATE TABLE `domain_validation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_name` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
)
#

INSERT INTO `colpal_poc`.`domain_validation`
(
`unique_name`,
`domain`
)
VALUES
('colpal','https://colpal.aisselkolm.com/poc/'
);




/* Alter command for products table to sort products with sort_id column*/
ALTER TABLE `products` ADD `sort_id` INT(11) NOT NULL DEFAULT  '0' AFTER `otsuka_id`;

-- ALTER TABLE `plans` 
-- ADD COLUMN `plan_start` TIMESTAMP NULL DEFAULT NOW() AFTER `modified_on`,
-- ADD COLUMN `plan_end` TIMESTAMP NULL AFTER `plan_start`;
-- ALTER TABLE `colpal_poc`.`plans` 
-- ADD COLUMN `plan_name` VARCHAR(255) NULL AFTER `plan_end`;

CREATE TABLE `plan_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(255) DEFAULT NULL,
  `plan_description` text,
  `plan_start` timestamp NULL DEFAULT NULL,
  `plan_end` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `client_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


CREATE TABLE `plan_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `kol_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

CREATE TABLE `plan_objectives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL,
  `objective_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


ALTER TABLE `contracts` ADD `created_by` INT(11) NOT NULL AFTER `doc_name`, ADD `created_on` TIMESTAMP NOT NULL AFTER `created_by`, ADD `modified_by` INT(11) NOT NULL AFTER `created_on`, ADD `modified_on` TIMESTAMP NOT NULL AFTER `modified_by`, ADD `client_id` INT(11) NOT NULL AFTER `modified_on`;
ALTER TABLE `contracts` ADD `kol_id` INT(11) NOT NULL AFTER `kol_name`;



	/*Store decimal values for payments with two digits after decimal*/
	ALTER TABLE `payment_split` CHANGE `amount` `amount` DECIMAL(10,2) NULL DEFAULT NULL;



#media
-- To be executed only for hills DB
-- To be executed only for hills DB
-- To be executed only for hills DB
-- To be executed only for hills DB
UPDATE  rss_link set `ignore`=1 where id <=187;
INSERT INTO `rss_link` (`id`, `link`, `attribute_name`, `attribute_value`, `tag_name`, `publisher`, `ignore`) VALUES
(188, 'http://feeds.feedburner.com/avma', 'id', 'content', 'div', 'AVMA', 0),
(189, 'http://feeds.feedburner.com/ExternsOnTheHill', 'id', 'content_box', 'div', 'Externs On The Hill', 0),
(190, 'http://www2.smartbrief.com/servlet/rss?b=AVMA', 'class', 'wyContent', 'div', 'Animal Health SmartBrief', 0),
(191, 'http://www.petmd.com/rss/dog.health', 'id', 'content-content', 'div', 'PETMD-Dog', 0),
(192, 'http://www.petmd.com/rss/dog.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Dog-Emergency', 0),
(193, 'http://www.petmd.com/rss/dog.wellness', 'id', 'content-content', 'div', 'PETMD-Dog-Wellness', 0),
(194, 'http://www.petmd.com/rss/cat.health', 'id', 'columnmiddle', 'div', 'PETMD-Cat-Health', 0),
(195, 'http://www.petmd.com/rss/cat.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Cat-Emergency', 0),
(196, 'http://www.petmd.com/rss/cat.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Cat-Wellness', 0),
(197, 'http://www.petmd.com/rss/bird.health', 'id', 'columnmiddle', 'div', 'PETMD-Bird-Health', 0),
(198, 'http://www.petmd.com/rss/bird.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Bird-Emergency', 0),
(199, 'http://www.petmd.com/rss/bird.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Bird-Wellness', 0),
(200, 'http://www.petmd.com/rss/horse.health', 'id', 'columnmiddle', 'div', 'PETMD-Horse-Health', 0),
(201, 'http://www.petmd.com/rss/horse.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Horse-Emergency', 0),
(202, 'http://www.petmd.com/rss/horse.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Horse-Wellness', 0),
(203, 'http://www.petmd.com/rss/horse.breeds', 'id', 'columnmiddle', 'div', 'PETMD-Horse-Breeds', 0),
(204, 'http://www.petmd.com/rss/fish.health', 'id', 'columnmiddle', 'div', 'PETMD-Fish-Health', 0),
(205, 'http://www.petmd.com/rss/fish.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Fish-Emergency', 0),
(206, 'http://www.petmd.com/rss/fish.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Fish-Wellness', 0),
(207, 'http://www.petmd.com/rss/exotic.health', 'id', 'columnmiddle', 'div', 'PETMD-Exotic-Health', 0),
(208, 'http://www.petmd.com/rss/rabbit.health', 'id', 'columnmiddle', 'div', 'PETMD-Rabbit-Health', 0),
(209, 'http://www.petmd.com/rss/rabbit.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Rabbit-Emergency', 0),
(210, 'http://www.petmd.com/rss/rabbit.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Rabbit-Wellness', 0),
(211, 'http://www.petmd.com/rss/ferret.health', 'id', 'columnmiddle', 'div', 'PETMD-Ferret-Health', 0),
(212, 'http://www.petmd.com/rss/ferret.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Ferret-Emergency', 0),
(213, 'http://www.petmd.com/rss/ferret.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Ferret-Wellness', 0),
(214, 'http://www.petmd.com/rss/reptile.health', 'id', 'columnmiddle', 'div', 'PETMD-Reptile-Health', 0),
(215, 'http://www.petmd.com/rss/reptile.emergency', 'id', 'columnmiddle', 'div', 'PETMD-Reptile-Emergency', 0),
(216, 'http://www.petmd.com/rss/reptile.wellness', 'id', 'columnmiddle', 'div', 'PETMD-Reptile-Wellness', 0);
-----end of hills modification---	

ALTER TABLE `interactions` 
ADD COLUMN `plan_name` VARCHAR(255) NULL AFTER `otsuka_id`;



/*Create table for kol sub specialty*/
CREATE TABLE `kol_sub_specialty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `kol_sub_specialty_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB

/*Add extra column in kols table to store unique id and consent status*/
ALTER TABLE `kols` ADD `unique_id` VARCHAR(255) NULL DEFAULT NULL AFTER `aissel_alignment_id`;
ALTER TABLE `kols` ADD `consent_status` INT(11) NULL DEFAULT NULL COMMENT '0-denied, 1-approved' AFTER `unique_id`;
ALTER TABLE `kols` ADD `consent_notes` VARCHAR(255) NULL DEFAULT NULL AFTER `unique_id`;
ALTER TABLE `kols` ADD `consent_doc_link` VARCHAR(255) NULL DEFAULT NULL AFTER `consent_notes`;

ALTER TABLE `kol_notes` ADD `document` VARCHAR(255) NOT NULL AFTER `note`;
ALTER TABLE `kol_notes` ADD `document_name` VARCHAR(255) NOT NULL AFTER `document`;


/*Add extra column to hold contact restrictions*/
ALTER TABLE `contact_restrictions` ADD `text` INT(10) NOT NULL AFTER `email`;
ALTER TABLE `contact_restrictions` ADD `video_call` INT(10) NOT NULL AFTER `text`;

/*Insert 'Private Practice' as a new organization type */
INSERT INTO `organization_types` VALUES('','Private Practice','')

ALTER TABLE `kol_notes` ADD `document_name` VARCHAR(255) NOT NULL AFTER `document`;

CREATE TABLE `colpal_latest`.`media_email_settings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NULL,
    `option` varchar(45) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NOW(),
  PRIMARY KEY (`id`));
  
ALTER TABLE `kol_notes` ADD `orginal_doc_name` VARCHAR(255) NOT NULL AFTER `document_name`;


ALTER TABLE `kol_memberships` ADD `added_from` INT(11) NOT NULL DEFAULT '0' AFTER `client_id`, ADD `source_row_id` INT(11) NOT NULL DEFAULT '0' AFTER `added_from`;
ALTER TABLE `kol_notes` ADD `orginal_doc_name` VARCHAR(255) NOT NULL AFTER `document_name`;



-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--
CREATE TABLE IF NOT EXISTS `campaigns` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `name` varchar(255) DEFAULT NULL,
 `description` varchar(255) DEFAULT NULL,
 `short_code` varchar(50) DEFAULT NULL,
 `identification_id` int(11) NOT NULL,
 `created_by` int(11) DEFAULT NULL,
 `created_on` datetime DEFAULT NULL,
 `modified_by` varchar(40) DEFAULT NULL,
 `modified_on` datetime DEFAULT NULL,
 `is_enable` tinyint(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB ;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_kols`
--

CREATE TABLE IF NOT EXISTS `campaign_kols` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `campaign_id` int(11) NOT NULL,
 `kol_id` int(11) NOT NULL,
 `created_by` int(11) NOT NULL,
 `created_on` datetime NOT NULL,
 `modified_by` varchar(40) DEFAULT NULL,
 `modified_on` datetime DEFAULT NULL,
 PRIMARY KEY (`id`),
 KEY `Foreignconstraint_on_campaign` (`campaign_id`)
) ENGINE=InnoDB



/**************************Additional column to hold address line 2 value in interactions table*******************************/
ALTER TABLE  `interactions` ADD  `address2` VARCHAR( 255 ) NULL DEFAULT NULL AFTER  `address` ;


/**************************Additional columns to hold latitude & longitude value in kol_locations table*******************************/
ALTER TABLE `kol_locations` ADD `latitude` DECIMAL(10,7) NULL DEFAULT NULL AFTER `private_practice`;
ALTER TABLE `kol_locations` ADD `longitude` DECIMAL(10,7) NULL DEFAULT NULL AFTER `latitude`;

/**************************Additional column in clinical_trials**
ALTER TABLE `clinical_trials` ADD `is_industry_trial` INT(4) NOT NULL DEFAULT '0' AFTER `gender`;


/**************************New table kols_client_visibility*******************************/
DROP TABLE IF EXISTS `kols_client_visibility`;
CREATE TABLE `kols_client_visibility` (       
  `id` int(11) NOT NULL auto_increment,   
  `kol_id` int(11) default NULL,  
  `client_id` int(11) default NULL,    
  `is_visible` int(11) default NULL,        
   PRIMARY KEY  (`id`)     
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `kols_client_visibility`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kol_client_visibility_unquie_constraint` (`kol_id`,`client_id`,`is_visible`);

/**************************Additional column to hold latitude and longitude values in kol_events table*******************************/
ALTER TABLE `kol_events` ADD `latitude` DECIMAL(10,7) NULL DEFAULT NULL AFTER `postal_code`, ADD `longitude` DECIMAL(10,7) NULL DEFAULT NULL AFTER `latitude`;



--
-- Table structure for table `demo_emails`
--

CREATE TABLE IF NOT EXISTS `demo_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demo_emails`
--

INSERT INTO `demo_emails` (`id`, `email`) VALUES
(1, 'preetan@aissel.com'),
(2, 'pritin@aissel.com'),
(3, 'karthikk@aissel.com');


CREATE TABLE `kols_project_visibility` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `kols_project_visibility`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kol_project_unique` (`client_id`,`project_id`);
ALTER TABLE `kols_project_visibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
  

/************************** Table structure for table `kol_names_for_survey` ******************************/
CREATE TABLE `kol_names_for_survey` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `middle_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(50) NOT NULL,
  `speciality` varchar(100) NOT NULL,
  `organization` varchar(250) NOT NULL,
  `source_table` varchar(50) NOT NULL,
  `source_table_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `kol_names_for_survey`
  ADD PRIMARY KEY (`id`);
  
ALTER TABLE `kol_names_for_survey` ADD `search_name` VARCHAR(250) NOT NULL AFTER `last_name`;

ALTER TABLE `kol_names_for_survey` ADD `latitude` FLOAT NOT NULL AFTER `postal_code`, ADD `longitude` FLOAT NOT NULL AFTER `latitude`;


/***************************Additional column to hold client logo and favicon in clients table******************************/
ALTER TABLE `clients` ADD `client_logo` VARCHAR(255) NULL DEFAULT NULL AFTER `support_email_id`;
ALTER TABLE `clients` ADD `client_favicon` VARCHAR(255) NULL DEFAULT NULL AFTER `client_logo`;



ALTER TABLE `kol_locations` ADD `processed_latlong` INT(2) NOT NULL DEFAULT '0' AFTER `longitude`;

/***************************Additional column to hold kol profile type in kols_client_visibility table******************************/
ALTER TABLE `kols_client_visibility` ADD `profile_type` VARCHAR(20) NULL DEFAULT NULL AFTER `kol_id`;


ALTER TABLE  `kol_locations` ADD  `processed_latlong` INT( 2 ) NOT NULL ;
ALTER TABLE `kols_client_visibility` ADD `profile_type` VARCHAR(20) NULL DEFAULT NULL AFTER `kol_id`;


ALTER TABLE `user_kols` ADD `type` VARCHAR(200) NOT NULL AFTER `kol_id`;

CREATE TABLE `kol_user_conatct_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `kol_user_conatct_type`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `kol_user_conatct_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


INSERT INTO `kol_user_conatct_type` (`id`, `name`) VALUES 
(1, 'Primary'),
(2, 'Secondary'),
(3, 'Professional'),
(4, 'Division/Global');

ALTER TABLE `kols` ADD `area_of_interest` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1:Primary;0:Not Primary' AFTER `consent_status`, ADD `bio_comments` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1:Primary;0:Not Primary' AFTER `area_of_interest`, ADD `languages_spoken` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1:Primary;0:Not Primary' AFTER `bio_comments`;

ALTER TABLE `kol_sub_specialty` ADD `priority` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '0:Sub-Specialty;1:Primary Specialty;2:Additional Specialty' AFTER `kol_sub_specialty_id`;

ALTER TABLE `kols` CHANGE `area_of_interest` `area_of_interest` TEXT NOT NULL;
ALTER TABLE `kols` CHANGE `bio_comments` `bio_comments` TEXT NOT NULL;
ALTER TABLE `kols` CHANGE `languages_spoken` `languages_spoken` TEXT NOT NULL;
ALTER TABLE `staffs` ADD `phone_type` INT NOT NULL AFTER `name`;
ALTER TABLE `staffs` ADD `email` VARCHAR(250) NOT NULL AFTER `phone_number`;
ALTER TABLE `kol_locations` ADD `title` INT NOT NULL AFTER `org_institution_id`, ADD `division` VARCHAR(250) NOT NULL AFTER `title`;
Update phone_numbers 
JOIN phone_type ON (phone_type.name = phone_numbers.type)
set phone_numbers.type = phone_type.id

Update staffs 
JOIN staff_title ON (staff_title.name = staffs.title)
set staffs.title = staff_title.id


ALTER TABLE `state_licenses` ADD `country_id` INT NOT NULL AFTER `state_license`;

DELETE FROM `state_licenses` WHERE `region` is null

UPDATE state_licenses
LEFT JOIN regions on regions.RegionID = state_licenses.region
SET state_licenses.country_id = regions.CountryID

UPDATE `app_setting_types` SET `lable_name` = 'Track module interactions default date range' WHERE `app_setting_types`.`id` = 1;
UPDATE `app_setting_types` SET `lable_name` = 'Media module default date range' WHERE `app_setting_types`.`id` = 2;

UPDATE `app_setting_type_values` SET `type_lable` = '1 Month to Date' WHERE `app_setting_type_values`.`id` = 1;
UPDATE `app_setting_type_values` SET `type_lable` = '2 Months to Date' WHERE `app_setting_type_values`.`id` = 2;
UPDATE `app_setting_type_values` SET `type_lable` = '3 Months to Date' WHERE `app_setting_type_values`.`id` = 3;
UPDATE `app_setting_type_values` SET `type_lable` = 'Last 30 Days' WHERE `app_setting_type_values`.`id` = 4;
UPDATE `app_setting_type_values` SET `type_lable` = 'Last 60 Days' WHERE `app_setting_type_values`.`id` = 5;
UPDATE `app_setting_type_values` SET `type_lable` = 'Last 90 Days' WHERE `app_setting_type_values`.`id` = 6;
UPDATE `app_setting_type_values` SET `type_value` = '30' WHERE `app_setting_type_values`.`id` = 4;
UPDATE `app_setting_type_values` SET `type_value` = '60' WHERE `app_setting_type_values`.`id` = 5;
UPDATE `app_setting_type_values` SET `type_value` = '90' WHERE `app_setting_type_values`.`id` = 6;


ALTER TABLE `kols` ADD `external_profile_id` VARCHAR(300) NOT NULL AFTER `languages_spoken`;

INSERT INTO `organization_types` (`id`, `type`, `code`) VALUES (NULL, 'Association', NULL);
Update `org_locations` set `phone_type_primary` = 0
ALTER TABLE `org_locations` CHANGE `phone_type_primary` `phone_type_primary` INT(0) NOT NULL DEFAULT '0';

/***************************Additional column to hold currency value in payment_split table ******************************/

ALTER TABLE  `payment_split` ADD  `currency` INT( 11 ) NOT NULL AFTER  `type` ;


-- Master table creation for currency value
-- Table structure for table `payments_currency`
--

CREATE TABLE `payments_currency` (
  `id` int(11) NOT NULL,
  `currency_name` varchar(255) NOT NULL,
  `currency_symbol` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments_currency`
--

INSERT INTO `payments_currency` (`id`, `currency_name`, `currency_symbol`) VALUES
(1, 'Dollar', '$'),
(2, 'Euro', '€'),
(3, 'Rupee', '₹'),
(4, 'pound', '£');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments_currency`
--
ALTER TABLE `payments_currency`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments_currency`
--
ALTER TABLE `payments_currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/***************************Interaction attenddee additional key people col date 10-06-2017******************************/
ALTER TABLE `interactions_attendees` ADD `key_id` INT NOT NULL AFTER `org_id`;

/***************************Update profile_type null to 1(Basic) date 11-06-2017******************************/
Update `organizations` set `profile_type` = 1 WHERE `profile_type` is null 
/***************************New coloumns to org_notes 12-06-2017******************************/
ALTER TABLE `org_notes` ADD `document` VARCHAR(255) NOT NULL AFTER `note`, ADD `document_name` VARCHAR(255) NOT NULL AFTER `document`, ADD
 `orginal_doc_name` VARCHAR(255) NOT NULL AFTER `document_name`;


/*********************************************Alter Table Notifications***************************************/
ALTER TABLE 'notifications' ADD 'send_email' BOOLEAN NOT NULL AFTER 'modified_on';

ALTER TABLE 'notifications' ADD 'all_users' BOOLEAN NOT NULL AFTER 'send_email';

ALTER TABLE 'notifications' ADD 'email_sent' BOOLEAN NOT NULL AFTER 'send_email';


ALTER TABLE `objectives` ADD `unique_id` VARCHAR(250) NOT NULL AFTER `modified_on`;

/*********************************************Alter Table Kols 27-06-2017***************************************/
ALTER TABLE `kols` ADD `opt_in_out_status` INT NOT NULL DEFAULT '0' COMMENT '0:New/Requested;1:Opt Out;2:Opt In' AFTER `external_profile_id`;

UPDATE `payments_currency` SET `currency_symbol` = '¥' WHERE `payments_currency`.`id` =3;
UPDATE `payments_currency` SET `currency_name` = 'Yuan' WHERE `payments_currency`.`id` =3;
UPDATE `payments_currency` SET `currency_name` = 'Pound' WHERE `payments_currency`.`id` =4;


ALTER TABLE `kols` CHANGE `opt_in_out_status` `opt_in_out_status` INT(11) NOT NULL DEFAULT '0' COMMENT '1:New;2:Requested;3:Opt Out;4:Opt In';
ALTER TABLE `opt_inout` CHANGE `status` `status` INT(10) NOT NULL DEFAULT '0' COMMENT '0:Requested;1:Opt Out;2:Opt In';
ALTER TABLE `opt_inout` ADD `expire_date` DATE NOT NULL AFTER `upload_file_content`;
/*********************************************Alter Table Kols 13-07-2017***************************************/
ALTER TABLE `opt_inout` ADD `salutation` INT NOT NULL AFTER `created_by`;

/* INdex for client visibility */
ALTER TABLE `kols_client_visibility` ADD INDEX `kols_client_visibility_kol_id` (`kol_id`);
ALTER TABLE `kols_client_visibility` ADD INDEX `kols_client_visibility_client_id` (`client_id`);
ALTER TABLE `countries` ADD INDEX `countries_globalregion` (`GlobalRegion`);

/**********************Alter Table kols 17-07-2017************/
ALTER TABLE `kols` CHANGE `opt_in_out_status` `opt_in_out_status` INT(11) NOT NULL DEFAULT '0' COMMENT '1:New;2:Requested;3:Opt Out;4:Opt In;5:Opt In Expires';
INSERT INTO `opt_inout_statuses` (`id`, `name`) VALUES (NULL, 'Opt-in Expired');

/*********************************************Alter for data type indicator 18-07-2017***************************************/
ALTER TABLE `kol_memberships` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `source_row_id`;
ALTER TABLE `kol_events` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `client_id`;
ALTER TABLE `kol_publications` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `user_id`;
ALTER TABLE `kol_clinical_trials` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `is_verified`;
ALTER TABLE `kol_educations` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `client_id`;
ALTER TABLE `contracts` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `client_id`;
ALTER TABLE `payments` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `requested_by`;
ALTER TABLE `kol_locations` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `processed_latlong`;
ALTER TABLE `emails` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `modified_on`;
ALTER TABLE `phone_numbers` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `location_id`;
ALTER TABLE `state_licenses` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `modified_on`; 
ALTER TABLE `staffs` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `location_id`; 
ALTER TABLE `interactions` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `plan_name`;
ALTER TABLE `plan_details` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `created_by`;
ALTER TABLE `objectives` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `modified_on`;
/* for orgnization */
ALTER TABLE `key_peoples` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `url`;
ALTER TABLE `affiliates_partnerships` ADD `data_type_indicator` VARCHAR(255) NOT NULL AFTER `npi_num`;
/*********************************************Alter Table Organizations 17-07-2017***************************************/
/* Storing Parent_id and Hierarchy Details of each Organization */
ALTER TABLE `organizations`  ADD `parent_id` INT NOT NULL DEFAULT '0' AFTER `profile_from`,  ADD `hierarchy` TEXT NULL DEFAULT NULL  AFTER `parent_id`;

/*********************************************Alter Table user_kols 26-07-2017***************************************/
ALTER TABLE `user_kols` ADD `created_by` INT NOT NULL AFTER `type`, ADD `created_on` DATETIME NOT NULL AFTER `created_by`;
ALTER TABLE `user_kols` ADD `modified_by` INT NOT NULL AFTER `created_on`, ADD `modified_on` DATETIME NOT NULL AFTER `modified_by`;
/*********************************************Alter Table jason_store 26-07-2017***************************************/
ALTER TABLE  `json_store` ADD  `client_id` INT NOT NULL ;
/*********************************************Alter Table kols 27-07-2017***************************************/
ALTER TABLE `kols` ADD `primary_language_id` INT NOT NULL AFTER `opt_in_out_status`;
/*********************************************Alter Table kols 28-07-2017***************************************/
ALTER TABLE acp_zipterr ENGINE = InnoDB;
ALTER TABLE additional_contacts ENGINE = InnoDB;
ALTER TABLE additional_contacts_ireports ENGINE = InnoDB;
ALTER TABLE additional_contacts_lat_long ENGINE = InnoDB;
ALTER TABLE additional_contacts_new ENGINE = InnoDB;
ALTER TABLE additional_contacts_others ENGINE = InnoDB;
ALTER TABLE disclaimer ENGINE = InnoDB;
ALTER TABLE duplicates ENGINE = InnoDB;
ALTER TABLE icontacts ENGINE = InnoDB;
ALTER TABLE icontacts_1 ENGINE = InnoDB;
ALTER TABLE ipro_mcad ENGINE = InnoDB;
ALTER TABLE roster ENGINE = InnoDB;
ALTER TABLE wallcomments ENGINE = InnoDB;
ALTER TABLE walllikes_track ENGINE = InnoDB;
ALTER TABLE wallposts ENGINE = InnoDB;
ALTER TABLE zipterr ENGINE = InnoDB;
ALTER TABLE pubmed_authors ENGINE = InnoDB;
ALTER TABLE publications_authors ENGINE = InnoDB;

ALTER TABLE pubmed_authors CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE publications_authors CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;

/*************************************** Add Composite Unique check on `title_id`, `client_id` in title_client_mappings ***********/
ALTER TABLE `title_client_mappings` ADD UNIQUE `TITLE_CLIENT_UNIQ` (`title_id`, `client_id`);

/*************************************** Add Foreign Key on `title_client_mappings->title_id` refer to `titles->id` *************/
ALTER TABLE `title_client_mappings` ADD FOREIGN KEY (`title_id`) REFERENCES `titles`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*************************************** Add Foreign Key on `speciality_client_mappings->specialty_id` refer to `specialties->id` *************/
ALTER TABLE `specialty_client_association` ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `clients_speciality_unique` (`specialty_id`,`client_id`);
ALTER TABLE `specialty_client_association` ADD CONSTRAINT `SPECIALITY_FK` FOREIGN KEY (`specialty_id`) REFERENCES `specialties`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*******Update commands for language table 03-08-2017**********/
UPDATE `languages` SET `lang_name` = 'Portugese (Brazil)' WHERE `languages`.`id` = 1;
UPDATE `languages` SET `lang_name` = 'Japanese' WHERE `languages`.`id` = 8;
UPDATE `languages` SET `lang_name` = 'Spanish (Latin America)' WHERE `languages`.`id` = 9;
UPDATE `languages` SET `lang_name` = 'Dutch' WHERE `languages`.`id` = 10;
UPDATE `languages` SET `lang_name` = 'Norwegian' WHERE `languages`.`id` = 11;
UPDATE `languages` SET `lang_name` = 'Russian' WHERE `languages`.`id` = 12;
UPDATE `languages` SET `lang_name` = 'Spanish (Europe)' WHERE `languages`.`id` = 13;
UPDATE `languages` SET `lang_name` = 'Swedish' WHERE `languages`.`id` = 14;
UPDATE `languages` SET `lang_name` = 'Chinese (Taiwan)' WHERE `languages`.`id` = 15;



ALTER TABLE `user_kols` ADD `data_type_indicator` INT NOT NULL AFTER `modified_on`;

/********************17-08-2017***************/
ALTER TABLE `countries` CHANGE `Country` `Country` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE `regions` CHANGE `Region` `Region` VARCHAR(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE `cities` CHANGE `City` `City` VARCHAR(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE organizations CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE opt_inout CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci;

/********************01-08-2017***************/
ALTER TABLE `organizations` CHANGE `parent_id` `parent_id` INT(11) NULL;