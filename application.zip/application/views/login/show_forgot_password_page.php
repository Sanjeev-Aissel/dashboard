<?php
/**
 * View -password page
 * @author Vinayaj
 * @since 0tsuka_1.0.7
 * @package application.view.login	
 * @created on 20-12-2012
 */
?>
<style type="text/css">
.password_reset_block {
	background: white; 
	border:2px solid #FFFFFF; 
	width: 550px; 
	height: 150px; 
	border-radius: 10px; 
	margin: 5% auto; 
	margin-left: auto; 
	margin-right: auto; 
	min-height: 200px;
}

.reset_message {
	color: #717072; 
	padding: 5px;
	margin: 0;
	font-family: arial;
    font-size: 11px;
}

.resetpwd_header{
    border-bottom: 1px solid #D7D9DA;
    color: #0070BD;
	font-family: trebuchet ms;
    font-size: 28px;
    margin-bottom: auto;
    margin-left: 4%;
    margin-right: 4%;
    margin-top: 1px;
    padding-bottom: 5px;
    padding-left: 0;
    padding-right: 5px;
    padding-top: 18px;
    width: 515px;
}

.content-inner{
	min-height: 435px;
}

#loginWrapper {
    background: none;
    height: 275px;
}

#container{background: none repeat scroll 0 0 white;
    border: 2px solid #FFFFFF;
    border-radius: 10px 10px 10px 10px;
    min-height: 150px;
    height:auto;
    margin: 5% auto;
    min-height: 200px;
    width: 550px;
}
    
#forgotPasswordForm table{
	margin-left: 18px; 
	margin-top: 20px;
}
	    
.forgot_pwd_msg{
	margin-left: 22px;
	margin-top: 5px;
	font-size: 13px;
}
   
#resetBotton{
   height: 35px;
   width: 80px;
}
   
label.error{
	color: red;
	display: block;
	font-size: 11px;
	font-weight: normal;
}
    
.notice {
    background-color: yellow;
	border: 1px solid #BDBDBD;
	margin: 5px 5% auto 4%;
	padding-bottom: 5px;
	padding-left: 5px;
	padding-top: 1px;
}
#loginContainer{
	width: 100%;
}
</style>
	<div>
			<div id="loginContainer">
				<div id="loginWrapper">
					<div id="container">
						<div class="resetpwd_header">Reset your password</div>
						<div class="forgot_pwd_msg">
			                  Please enter your official Email address to receive an email
			                  with the link to reset your password.
						</div>
						<br />
						<div class='masBox'></div>
						<form action="" method="post" name="forgot_password_form" id="forgotPasswordForm" >
							<table style="margin: auto">
								<tr>
									<td>
										<input type="text" name="email" value="" class="email required" style="width:300px;height: 26px;"></input>
										<br />
									</td>
								</tr>
								<tr>
									<td>
										<center>
    										<button type="button" onclick="window.location='<?php echo base_url()?>/login'"  id="resetBotton" >Cancel</button>&nbsp;&nbsp;
    										<input type="button" value="Submit" onclick="resetPass();" id="resetBotton"></input>
										</center>
									</td>
								</tr>
							</table>
						</form>
					</div>
				</div>
			</div>
	</div>




<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
<script src="<?php echo base_url();?>js/jquery/jquery.validate1.9.min.js"></script>

<script>


	var html = '<div class="password_reset_block">';
	html+= '<div class="resetpwd_header">Check your email...</div>';
	html+= '<div style="margin: 5px 3% auto;">';
		html+= '<p class="reset_message">An email with instructions for creating a new password has been sent to you.</p>';
		html+='<p class="reset_message">';
		html+='<br>In case you do not receive the email, please check your junk mail folder as well.';
		html+='</p>'
	html+='</div>';

	function resetPass(){
		if(!$("#forgotPasswordForm").validate().form()){
		
			return false;
		}
		$('div.masBox').removeClass('success');
		$('div.masBox').addClass('notice');
		$('div.masBox').show();
		$('div.masBox').html('Sending the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		
		$('#resetBotton').hide();
		//return false;
		$.ajax({
				url:'<?php echo base_url();?>login/forgot_password',
				type:'post',
				dataType:'json',
				data:$("#forgotPasswordForm").serialize(),
				success:function(returnData){
		
					if(!(returnData.status)){
						$('#resetBotton').show();	
						$('.masBox').text("We don't have the email address you entered in our records. Please enter your official email address and make sure it is spelled right.");
						//$('.masBox').fadeOut(5000);
					}else{
						
						$('#container').html(html);
						
					}
				}

			});
	}

	$(document).ready(function(){
		$('#forgotPasswordForm').keydown(function(event) {
			if (event.keyCode == 13 && !event.shiftKey) {
				event.preventDefault();
				
				resetPass();
			   }
		});

	});

</script>

