<?php

/* 

*@author Yuvaraj M
*@since
*@created on 3-10-2016
 */
//pr($profile_summary);
?>
<style>
   #top > li:before, #profile_summary  > li:before {
    content: " - ";
  }
    #top,  #profile_summary  {
    padding-left:0 !important;
        font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
    font-size: 105% !important;
    font-size: 12px;
    color: #626262;
    
  } 
  #content-data > p{
   margin: 0 !important; 
font-size: 110% !important;   
  }

</style>
<div id="content-data">
<p >
<ul id="profile_summary" style="list-style: none">
<li>
  <?php echo $profile_summary['exp'][0]  ?> years of experience
</li>
<li>
   Studied in <?php echo implode(",",$profile_summary['university'])  ?> 
</li>
<li>
    <?php
    
    $data=array();
    $i=0;
    $count=0;
    $text='';
    foreach($profile_summary['affiliation'] as $value){
        
        if($i<=1){
            $data[]=$value;
        }
        else{
           $count++;
        }
        
        $i++;
        
    }
    if($count>0)
    $text=" and ".$count." "." other Affiliation";
    echo implode(",",$data).$text;
?> 
</li>
<li>
   Speaker in <?php  echo $profile_summary['speaker'][0]  ?>  Sessions in Conferences
</li> 
<li>
    <?php  echo $profile_summary['total_publications']  ?> Publication(s) with <?php  echo (int)$profile_summary['last_author_count']+(int)$profile_summary['first_author_count'];  ?>  as Lead Author 
</li>
<li>
   <?php
   
   if($profile_summary['interactionsCount']>0){?>
   <?php  echo $profile_summary['interactionsByUsersCount']  ?> interactions entered by <?php  echo $profile_summary['interactionsCount']  ?> employees in last 6 months 

<?php }?>
</li>


</ul>
    
    
    
</p>
<p>
      Top Event Topics:
    <ul id="top" style="list-style: none">
    <?php if(count($profile_summary['events'])>0) { ?>
     <?php   foreach($profile_summary['events'] as $value){ ?>

      <li><?php echo $value ?></li>
    

      
      
      
     
     <?php }} ?></ul> 
       <?php if(count($profile_summary['top_mesh_terms']['categoryData'])>0) { ?>
      <?php
      $i=0;
        $data=array();
      foreach($profile_summary['top_mesh_terms']['categoryData'] as $row){
          if($i<=2){
             $data[]=$row['name'];
                     
          }
          else{
              break;
          }
          $i++; 
      } ?>
      
<p> Top Publication Mesh Terms:</p>
    <ul id="top" style="list-style: none">
   
     <?php   foreach($data as $value){ ?>

      <li><?php echo $value ?></li>
    

      
      
      
     
     <?php } ?></ul>
     
    <?php   }  ?>
    
</p>
    
    
</div>




