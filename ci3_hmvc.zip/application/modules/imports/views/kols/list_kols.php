<style>
.box-container {
    margin-top: 20px;
}
.inline{
	display: inline;
}
p.inline.title {
    font-weight: bold;
}
</style>
<script>
$(document).ready(function(){
	getAllKolsAvailable();
});

function select_analyst_client(){
	var clientId = $('#client_id').val();
	getKolsNotAssociatedWithClient(clientId);
}

function getKolsNotAssociatedWithClient(clientId){
	$("#gridNotClientKolsContainer").html("");
	$("#gridNotClientKolsContainer").html('<table id="JQBlistNotClientKolsDetails"></table><div id="listNotClientKolsDetailsPage"></div>');
	var ele=document.getElementById('gridNotClientKolsContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridNotClientKolsContainer').width();
	jQuery("#JQBlistNotClientKolsDetails").jqGrid({
		url: base_url + 'imports/get_kols_not_associated_with_client/'+clientId,
		datatype: "json",
		mtype: 'POST',
		colNames:['Id','Name','Speciality','Gender','Organization','Pubmed ?','Trials ?','Created By','Pin','Status', 'Action'],
		colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'kol_link',index:'kol_link', search:true},
					{name:'kol_speciality',index:'kol_speciality', width:100, search:true},
					{name:'kol_gender',index:'kol_gender', width:50, search:true, resizable:false},
			   		{name:'kol_org',index:'kol_org', search:true},
			   		{name:'is_pubmed_processed',index:'is_pubmed_processed', width:50, resizable:false},
			   		{name:'is_clinical_trial_processed',index:'is_clinical_trial_processed', width:50, resizable:false},
			   		{name:'kol_created_by',index:'kol_created_by', width:80, search:true},
			   		{name:'kol_pin',index:'kol_pin', width:100, search:true},
			   		{name:'kol_status',index:'kol_status', width:60, search:true},
			   		{name:'action',index:'action',width:30, align:'center',search:false, resizable:false}
			   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listNotClientKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"KOLs Not Associated With Client",
   		rowList:paginationValues,
		gridComplete: function(){ 
						$(".btn").show();
						$(".setting-dorpdowns").show();
						$(".horizontal-line").show();
						
						var pubmedValue = '';
						var trialValue = '';
						var ids = jQuery("#JQBlistNotClientKolsDetails").jqGrid('getDataIDs');
	         			for (var i = 0; i < ids.length; i++) {
	        				var rowId = ids[i];
	        				var isPubmedProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_pubmed_processed');
							if(isPubmedProcessed == '1'){
								pubmedValue = 'Yes';
							}else{
								pubmedValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_pubmed_processed: pubmedValue});

	        				var isTrialProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_clinical_trial_processed');
							if(isTrialProcessed == '1'){
								trialValue = 'Yes';
							}else{
								trialValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_clinical_trial_processed: trialValue});

	        				var kolId = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'id');
	        				var act = '';
	        				
							act += '<div class="actionIcon editIcon"><a href="'+base_url+'kols/edit_kol/'+kolId+'" title="Edit">&nbsp;</a></div>';
							act += '<div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols('+kolId+',2);" href="#" title="Delete">&nbsp;</a></div>';

							jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {action: act});
	         			}
	    }
	});

	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navGrid','#listNotClientKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navButtonAdd',"#listNotClientKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('setGridWidth',gridWidth); 
}
function getAllKolsAvailable(){
	$("#gridNotClientKolsContainer").html("");
	$("#gridNotClientKolsContainer").html('<table id="JQBlistNotClientKolsDetails"></table><div id="listNotClientKolsDetailsPage"></div>');
	var ele=document.getElementById('gridNotClientKolsContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridNotClientKolsContainer').width();
	jQuery("#JQBlistNotClientKolsDetails").jqGrid({
		url: base_url + 'imports/get_all_kols_available',
		datatype: "json",
		mtype: 'POST',
		colNames:['Id','Name','Speciality','Gender','Organization','Pubmed ?','Trials ?','Created By','Pin','Status', 'Action'],
		colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'kol_link',index:'kol_link', search:true},
					{name:'kol_speciality',index:'kol_speciality', width:100, search:true},
					{name:'kol_gender',index:'kol_gender', width:50, search:true, resizable:false},
			   		{name:'kol_org',index:'kol_org', search:true},
			   		{name:'is_pubmed_processed',index:'is_pubmed_processed', width:50, resizable:false},
			   		{name:'is_clinical_trial_processed',index:'is_clinical_trial_processed', width:50, resizable:false},
			   		{name:'kol_created_by',index:'kol_created_by', width:80, search:true},
			   		{name:'kol_pin',index:'kol_pin', width:100, search:true},
			   		{name:'kol_status',index:'kol_status', width:60, search:true},
			   		{name:'action',index:'action',width:30, align:'center',search:false, resizable:false}
			   	],
	   	rowNum:20,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listNotClientKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"KOLs Not Associated With Client",
   		rowList:paginationValues,
		gridComplete: function(){ 
						$(".btn").show();
						$(".setting-dorpdowns").show();
						$(".horizontal-line").show();
						
						var pubmedValue = '';
						var trialValue = '';
						var ids = jQuery("#JQBlistNotClientKolsDetails").jqGrid('getDataIDs');
	         			for (var i = 0; i < ids.length; i++) {
	        				var rowId = ids[i];
	        				var isPubmedProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_pubmed_processed');
							if(isPubmedProcessed == '1'){
								pubmedValue = 'Yes';
							}else{
								pubmedValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_pubmed_processed: pubmedValue});

	        				var isTrialProcessed = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'is_clinical_trial_processed');
							if(isTrialProcessed == '1'){
								trialValue = 'Yes';
							}else{
								trialValue = 'No';
							}
	        				jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {is_clinical_trial_processed: trialValue});

	        				var kolId = jQuery('#JQBlistNotClientKolsDetails').jqGrid ('getCell',rowId,'id');
	        				var act = '';
	        				
							act += '<div class="actionIcon editIcon"><a href="'+base_url+'kols/edit_kol/'+kolId+'" title="Edit">&nbsp;</a></div>';
							act += '<div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols('+kolId+',2);" href="#" title="Delete">&nbsp;</a></div>';

							jQuery("#JQBlistNotClientKolsDetails").jqGrid('setRowData', ids[i], {action: act});
	         			}
	    }
	});

	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navGrid','#listNotClientKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('navButtonAdd',"#listNotClientKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistNotClientKolsDetails").jqGrid('setGridWidth',gridWidth); 
}

function updateStatus(gridName,id){
	grid = $(gridName);
	var kolId	= grid.getGridParam('selarrrow');
	var updateStatus = $("#"+id).val();
	var clientId = $("#client").val();
	if(updateStatus==''){
		jAlert("Please select status");
		return false;
	}
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}else{
		var kol_id = kolId.join();
		var dataString = 'where='+ id +'&kol_id='+kol_id +'&update_status='+updateStatus;
		// AJAX Code To Submit Form.
		$.ajax({
			type: "POST",
			url: "<?php echo base_url()?>/kols/update_kols_status_within_client_visibility",
			data: dataString,
			cache: false,
			success: function(result){
				var result = JSON.parse(result);
				if(gridName == "#JQBlistClientKolsDetails"){
					if(result.status == 'success'){
						$("#disassociateMsg").show();
						getKolsAssociatedWithClient(clientId);
						$("#"+id).val('');
					}else{
						$("#disassociateMsg span").css('color','red');
						$("#disassociateMsg span").text('Unable to process request');
						$("#disassociateMsg").show();
						setTimeout(function(){ $("#disassociateMsg").hide(); }, 3000);
					}
				}else{
					if(result.status == 'success'){
						$("#associateMsg").show();
						getKolsNotAssociatedWithClient(clientId);
						$("#"+id).val('');
					}else{
						$("#associateMsg span").css('color','red');
						$("#associateMsg span").text('Unable to process request');
						$("#associateMsg").show();
						setTimeout(function(){ $("#associateMsg").hide(); }, 3000);
					}
				}
			}
		});
	}
	return false;	
}

</script>
<div class="container-fluid box-container">
	<div class="row">
		<div class="col-md-8">
			<div class="inline">
					<p class="inline title">Set Status:</p>
						<select name="update_kol_status1" id="updateKolStatus1" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="<?php echo New1?>">New</option>
							<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo APPROVED?>">Approved</option>
							<?php }?>
							<option value="<?php echo PROFILING?>">Profiling</option>
							<option value="<?php echo REVIEW?>">Review</option>
								<?php if($userRoleId==ROLE_MANAGER || userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo COMPLETED?>">Completed</option>
							<?php }?>
						</select>
					<button onclick="updateStatus('#JQBlistClientKolsDetails','updateKolStatus1')" class="btn btn-default" style="margin-bottom: 4px;">Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Pubmed Status:</p>
						<select name="update_pubmed_status1" id="updatePubmedStatus1" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
							<option value="2">Recrawl</option>
						</select>
					<button onclick="updateStatus('#JQBlistClientKolsDetails','updatePubmedStatus1')" class="btn btn-default" style="margin-bottom: 4px;">Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Trial Status:</p>
						<select name="update_trial_status1" id="updateTrialStatus1" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
						</select>
					<button onclick="updateStatus('#JQBlistClientKolsDetails','updateTrialStatus1')" class="btn btn-default" style="margin-bottom: 4px;">Save</button>
				</div>
		</div>
		
		<div class="col-md-4" style="text-align: right;">
			<p class="inline title">Client <span class="required">*</span>:</p>
						<select name="client" id="client_id" class="form-control inline" onchange="select_analyst_client();" style="width:150px;">
							<option value="">--Select Client--</option>
								<?php foreach($arrClientList as $client){	?>
								<option value="<?php echo $client['id'];?>">
										<?php echo $client['name'];?>
									</option>
								<?php }?>
							</select>
			<button class="btn" onclick="associateKols('#JQBlistNotClientKolsDetails');" style="margin-bottom: 4px;">Associate</button>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div id="associateMsg" class="msg">&nbsp;<span></span></div>
			<div class="gridWrapper" id="gridNotClientKolsContainer">
				<table id="JQBlistNotClientKolsDetails"></table>
				<div id="listNotClientKolsDetailsPage"></div>
			</div>
		</div>	
	</div>
</div>