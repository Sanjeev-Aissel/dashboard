<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<?php echo $html_form;?>
<div id="msgBox">
</div>
<script>
$(document).ready(function() {
		$("#saveKolAssignClientForm").validate({
			rules: {
				client: "required",
				client_type: "required"
			},
			messages: {
				client: {
					required: "This field is required.",
				},
				client_type: {
					required: "This field is required.",
				}
			}
		});		
});
</script>