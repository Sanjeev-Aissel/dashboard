<?php
/**
* Description: Lists the Users
* Created by:Laxman K
* Created on:05-06-2014
* @since KOLM CORE v6.0.9
*/
?>
<!-- 2nd Plugin for Validation -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
<style>
	div.extraOptions div.rightSideOptions {
	    text-align: right;
	}
	.iconForOn{
		background: none #0C0 !important;
		border-radius: 11px;
		-webkit-border-radius: 11px;
   		-moz-border-radius: 11px;
	    height: 15px !important;
	    margin-top: 3px;
	    width: 15px !important;
	    margin-left: 5px;
	}
	.iconForOff{
		background: none #C00 !important;
		border-radius: 11px;
		-webkit-border-radius: 11px;
   		-moz-border-radius: 11px;
	    height: 15px !important;
	    margin-top: 3px;
	    width: 15px !important;
	    margin-left: 5px;
	}
	#gridUsersListingPagintaion_right{
		width: 220px;
	}
</style>
<script type="text/javascript">
	function addUser(){
		$(".addUserContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog("open");
		$(".addUserContent").load('<?php echo base_url()?>client_users/add_user');
		return false;	
	}
	function cancelUser(){
		$("#userContainer").dialog("close");
	}
	function list_users_grid(){
		var lastsel2;
		$('#gridUsersListing').html('');
	    $('#gridUsersListing').html('<div class="gridWrapper"><div id="gridUsersListingPagintaion"></div><table id="gridUsersListingResultSet"></table><div>');
	    grid = $("#gridUsersListingResultSet"),
        getUniqueNames = function(columnName) {
            var texts = grid.jqGrid('getCol',columnName), uniqueTexts = [],
                textsLength = texts.length, text, textsMap = {}, i;
         //   jAlert(texts.toSource());
            for (i=0;i<textsLength;i++) {
                text = texts[i];
                if (text !== undefined && textsMap[text] === undefined) {
                    // to test whether the texts is unique we place it in the map.
                    textsMap[text] = true;
                    uniqueTexts.push(text);
                }
            }
            return uniqueTexts;
        },
        buildSearchSelect = function(uniqueNames) {
            var values=":All";
            $.each (uniqueNames, function() {
                values += ";" + this + ":" + this;
            });
            return values;
        },
        grid.jqGrid({
			url:'<?php echo base_url();?>client_users/list_users_grid',
			datatype: "json",
			colNames:['Id','User Full Name','Email ID','Company Name','Contact', 'Client','Status','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true, search:false, resizable:false},
				{name:'user_full_name',index:'user_full_name', search:true},
				{name:'email',index:'email', search:true},
		   		{name:'company_name',index:'company_name',search:true},
		   		{name:'contact',index:'contact',search:true},
		   		{name:'client',index:'client',search:true},
		   		{name:'status',index:'status',width:80,search:true,resizable:false},
		   		{name:'action',index:'action',width:92, align:'center',search:false, resizable:false}
		   	],
		   	rowNum:10,
		   	multiselect: true,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#gridUsersListingPagintaion',
		   	mtype: "POST",
		   	sortname: 'user_name',
		    viewrecords: true,
		    sortorder: "asc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"Client Users",
		    gridComplete: function(){
		    },
			rowList:paginationValues
		});
        grid.jqGrid('navGrid','#gridUsersListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
		//Toolbar search bar below the Table Headers
		//setSearchSelect('pubmed_processed');
		grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Activate",buttonicon : "ui-icon-circle-check", title:"Activate Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					updateStatus(selectedUsers,0);
				}else{
					jAlert('Please select at least one User');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Deactivate",buttonicon : "ui-icon-circle-close", title:"Deactivate Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					updateStatus(selectedUsers,1,2);
				}else{
					jAlert('Please select at least one User');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Delete",buttonicon : "ui-icon-trash", title:"Delete Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					updateStatus(selectedUsers,2,2);
				}else{
					jAlert('Please select at least one User');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Block",buttonicon : "ui-icon-circle-close", title:"Block Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					blockUser(selectedUsers);
				}else{
					jAlert('Please select at least one User');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Unblock",buttonicon : "ui-icon-circle-check", title:"Unblock Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					unblockUser(selectedUsers);
				}else{
					jAlert('Please select at least one User');
				}
			}
		});
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Export",buttonicon:"ui-icon-document", title:"Export Selected User(s)",
			onClickButton:function (){
				var selectedUsers	= $(this).getGridParam('selarrrow');
				if(selectedUsers.length>0){
					exportUsers(selectedUsers);
				}else{
					jAlert('Please select at least one User');
				}
			}
		}); 
		//Toggle Toolbar Search 
		grid.jqGrid('navButtonAdd',"#gridUsersListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
			onClickButton:toggleSearchToolbar
		});
	}
	function toggleSearchToolbar(){			
		if(jQuery(".ui-search-toolbar").css("display")=="none") {
			jQuery(".ui-search-toolbar").css("display","");
		} else {
			jQuery(".ui-search-toolbar").css("display","none");
		}
	};
	function exportUsers(selectedUsers){
		 window.location.assign('<?php echo base_url();?>client_users/export_users/'+selectedUsers);
	}
	function loadManagers(status,selectedUsers){
		$(".addUserContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog("open");
		$(".addUserContent").load('<?php echo base_url().'client_users/list_managers/'?>'+status+'/'+selectedUsers);
		return false;
	}
	function updateStatus(id,status,role){
		var arrData	= {};
		arrData['user_id']	= id;
		arrData['status']	= status;
		if(status==2){
			jConfirm("Are you sure you want to delete selected User Permanently?","Please confirm",function(r){
				if(r){
					//if(role==1){
						$.ajax({
							type:'post',
							url:'<?php echo base_url();?>client_users/update_user_status',
							data:arrData,
							dataType:'json',
							success:function(returnData){
								reloadUsersGrid();	
							}
						 });
					//}else{
					//	loadManagers(status,id);
					//}
				}else{
					return false;
				}
			});
		}else if(status==1){
			jConfirm("Are you sure you want to deactivate selected User?","Please confirm",function(r){
				if(r){
					if(role==1||role==2){
						$.ajax({
							type:'post',
							url:'<?php echo base_url();?>client_users/update_user_status',
							data:arrData,
							dataType:'json',
							success:function(returnData){
								reloadUsersGrid();	
							}
						 });
					}else{
						loadManagers(status,id);
					}
				}else{
					return false;
				}
			});
		}else{
			$.ajax({
				type:'post',
				url:'<?php echo base_url();?>client_users/update_user_status',
				data:arrData,
				dataType:'json',
				success:function(returnData){
					reloadUsersGrid();	
				}
			 });
		}
	}
	function editClientUser(clientUserId){
		$("tr.recentlyAddedRow").removeClass('recentlyAddedRow');
		$("#userId_"+clientUserId).addClass('recentlyAddedRow');
		$(".addUserContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog("open");
		$(".addUserContent").load('<?php echo base_url().'client_users/edit_user/'?>'+clientUserId);
		return false;
	}

	function saveUserDetail(){

		var userName = $('#userName').val();

		var spaceIndex = userName.indexOf(' ', 0);
		if(spaceIndex > -1){
		
			jAlert('space not allowed for the Username');
			return false;
			
		}
		if(!$("#saveUser").validate().form()){
			return false;
		}
		$('div.clientUserMsgBox').removeClass('success');
		$('div.clientUserMsgBox').addClass('notice');
		$('div.clientUserMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

		id=$("#userId").val();
		if(id==''){
			action = '<?php echo base_url();?>client_users/save_user';
		}else{
			action = '<?php echo base_url();?>client_users/update_user';
		}
			$.ajax({
				type:'post',
				url:action,
				data:$("#saveUser").serialize(),
				dataType:'json',
				success:function(returnData){
							$('.clientUserMsgBox').text(returnData.msg);
							if(returnData.saved==true){
								if(id==''){	
									$("tr.recentlyAddedRow").removeClass('recentlyAddedRow');
									$newRecord="<tr class='recentlyAddedRow' id='userId_"+returnData.lastInsertId+"'>";
									$newRecord+="<td>"+returnData.arrUser.user_name+"</td>";
									$newRecord+="<td>"+returnData.arrUser.email+"</td>";
									$newRecord+="<td>"+returnData.arrUser.company_name+"</td>";
									$newRecord+="<td>"+returnData.arrUser.contact+"</td>";
									$newRecord+="<td>"+returnData.arrUser.client_id+"</td>";
									$newRecord+="<td><a onclick='editClientUser("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a></td>";
									$newRecord+="<td><a onclick='deleteUser("+returnData.lastInsertId+")'><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a></td>";
									$newRecord+="</tr>";
									$('.listUserResultSet').prepend($newRecord);
									$('.clientUserMsgBox').fadeOut(2000);
									setTimeout(closeAddUserDialog,3000);
									
								}else{
									var newRecord='';
									newRecord+="<td>"+returnData.arrUser.user_name+"</td>";
									newRecord+="<td>"+returnData.arrUser.email+"</td>";
									newRecord+="<td>"+returnData.arrUser.company_name+"</td>";
									newRecord+="<td>"+returnData.arrUser.contact+"</td>";
									newRecord+="<td>"+returnData.arrUser.client_id+"</td>";
									newRecord+="<td><a onclick='editClientUser("+returnData.lastInsertId+")'><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a></td>";
									newRecord+="<td><a onclick='deleteUser("+returnData.lastInsertId+")'><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a></td>";
									$('#userId_'+id).html(newRecord);
									$('.clientUserMsgBox').fadeOut(2000);
									setTimeout(closeEditUserDialog,3000);
								}
								reloadUsersGrid();	
						}else{		

						}
				}
				
			 });


	}

	function closeAddUserDialog(){
		$("#userContainer").dialog("close");	
	}

	function closeEditUserDialog(){
		$("#userContainer").dialog("close");	
	}
	$(document).ready(function(){
		var userProfileDialogOpts = {
				title: "Add/Edit Client User",
				modal: true,
				autoOpen: false,
				height: 400,
				width: 600,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				},
				close:function(){
				}
		};
		$("#userContainer").dialog(userProfileDialogOpts);
		list_users_grid();
	});
	function reloadUsersGrid(){
		$('#gridUsersListingResultSet').trigger('reloadGrid');
	}
	function blockUser(userIds){
		//console.log(userIds);
		var arrData	= {};
		arrData['user_id']	= userIds;
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>client_users/block_user',
			data:arrData,
			dataType:'json',
			success:function(returnData){
				alert("blocked");
				reloadUsersGrid();	
			}
		 });
	}
	function unblockUser(userIds){
		//console.log(userIds);
		var arrData	= {};
		arrData['user_id']	= userIds;
		$.ajax({
			type:'post',
			url:'<?php echo base_url();?>client_users/un_block_user',
			data:arrData,
			dataType:'json',
			success:function(returnData){
				alert("unblocked");
				reloadUsersGrid();	
			}
		 });
	}
</script>
<div>
	<div class="msgBoxContainer"><div class="msgBox"></div></div>
	<div class="extraOptions">
		<div class="rightSideOptions">
			<a href="#" onclick="addUser();"><img style="height: 30px;vertical-align: middle;" src="<?php echo base_url();?>images/bullet_add.png" border="0" />Add New user</a>
		</div>
	</div>
	<div id="gridUsersListing">
		<div class="gridWrapper">
			<div id="gridUsersListingPagintaion"></div>
			<table id="gridUsersListingResultSet"></table>
		</div>
	</div>
</div>
<!-- Modal content -->
<div id="userContainer" class="microViewLoading">
	<div class="addUserContent"></div>
</div>
<?php if($this->session->userdata('user_name') == 'test@test.com'){?>
<div style=" margin-top: 20px;">
	<a href="<?php echo base_url()?>client_users/generateApiKeyForUsers">Generate api keys for all users</a></br>
	<a href="<?php echo base_url()?>client_users/generateSecretKeyForUsers">Generate secret keys for all users</a></br>
	<a href="<?php echo base_url()?>client_users/sync_all_users_to_poland">Sync all users to poland</a>
</div>
<?php }?>
<!-- End of Modal content -->