<?php

/**
 * this is html file to show Contents for 'Privacy and Terms & service'
 * @package application.views.client_users
 *
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 *
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<?php //echo link_tag('images/favicon.ico', 'shortcut icon', 'image/ico'); ?>
	<?php echo $this->load->view('elements/favicon');?>
	<script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
<style type="text/css">
#logo {
    background: rgba(0, 0, 0, 0) url(../images/logo.png) no-repeat scroll 20px 0 / 130px auto;
    float: left;
    height: 57px;
    text-align: left;
    width: 550px;
    background-repeat: no-repeat;
}
.navBar{
    border:1px solid #eee;
}
.logDiv{
    padding:10px;
}
</style>
</head>
<body>
	<div class="container">
		<div class="row navBar">
    		<div class="col-md-2 logDiv">
    			<?php 
					$clientId = $this->session->userdata('client_id');
					if($clientId !== INTERNAL_CLIENT_ID){
						$arrClientResults = $this->common_helpers->getClientLogo($clientId);
						$clientLogoName = $arrClientResults[0]['client_logo'];
						if($clientLogoName != ''){
							echo '<img class="img-responsive" src="'.base_url().'images/client_logos/logos/'.$clientLogoName.'"/>';
						}else{
						    echo '<img class="img-responsive" src="'.base_url().'images/logo.png"/>';
						}
						
					}else{
					    echo '<img class="img-responsive" src="'.base_url().'images/logo.png"/>';
					}
					?>
    		</div>
    		<div class="col-md-2" style="float: right">
    			<select class="form-control language">
                    		<?php foreach($languages as $row){?>
                    			<option value="<?php echo $row['lang_value']?>"><?php echo $row['lang_name']?></option>
                    		<?php }?>
            	</select>
    		</div>
		</div>
	</div>
</body>
</html>