<script src="<?php echo base_url().MODULES_ASSETS;?>clients/js/client.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>clients/css/client.css" rel="stylesheet">
<div style="margin:10px 0px;">
	<p style="display: inline">Select Client:</p>
	<select name="client_id" id="client_id" class="form-control required" onchange="select_analyst_client();" style="width:12%;display: inline">
			<?php foreach($arrClients as $client){	?>
			<option value="<?php echo $client['id'];?>">
					<?php echo $client['name'];?>
				</option>
			<?php }?>
	</select>
</div>