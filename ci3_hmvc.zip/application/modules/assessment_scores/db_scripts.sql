SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS `asmt_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `asmt_categories_client_association` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asmt_category_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `asmt_criteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `criteria` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `asmt_criteria_client_association` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asmt_criteria_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `asmt_kols_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kol_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `criteria_id` int(11) DEFAULT NULL,
  `rating_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `asmt_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` varchar(256) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `asmt_ratings_client_association` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asmt_rating_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `rating_score` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `asmt_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'assessment rule id',
  `client_id` int(11) DEFAULT NULL COMMENT 'client id',
  `category_id` int(11) DEFAULT NULL COMMENT 'assessment category id',
  `criteria_id` int(11) DEFAULT NULL COMMENT 'assessment criteria id',
  `rating_id` int(11) DEFAULT NULL COMMENT 'assessment rating id',
  `order_no` int(11) DEFAULT NULL COMMENT 'order to display',
  `country_id` int(11) DEFAULT NULL COMMENT 'country id',
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `asmt_categories_client_association`
  ADD CONSTRAINT `asmt_categories_client_association_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
