<?php
class report extends CI_Model {
}
?>