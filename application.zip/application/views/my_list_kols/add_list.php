<?php
/**
 * File to open  modal box to add category and list names
 *
 * @package application.views.my_list_kols
 * @author: Vinayak
 * @since :2.0
 * @reated  11-4-11
 * 
 */

?>

<style type="text/css">
	.clientTbl label{
	 	display:inline;
		float:left;
		font-size:125%;
		margin-right:10px;
		text-align:right;
		width:33%;
	 }
	 .clientTbl select{
	 	width:52%;
	 	
	 }
	
	 
	 .clientTbl input[type="button"]{
	 	width:15%;
	 }
	.microView .ui-dialog-content {
	    background-color: none !important;
	}
	
	label.error{
	margin-left: 104px;
    width: 57%;
	}
	
	#listNameCss,#catCss,#css1,#css2{
	color:red;
	}
	
	#input input[type="text"],#listInputBoxContaioner input[type="text"]{
		width:187px;
	}
	
	input[type="text"], input[type="password"], input.text, input.title, textarea, select {
    margin: 0;
	}
	.error{
		padding:0;
	}
</style>




<script type="text/javascript">
var dvjQuery = null;
var private1 = null;
	var validationRules	=  {
			category_id: {
				required:true
			},
			list_name_id:{
				required:true
				},
			category:{
				required: true,
				alphaNumeric:true
			},
			list_name:{
				required: true,
				alphaNumeric:true
			}
	};

		var validationMessages = {
				category_id: {
				required: "Required",
				remote: ""
			},
			list_name_id:{
				required: "Required"
			},
			category:{
				required: "Required"
				},
			list_name:{
					required: "Required"
				}
			
		};
	$(document).ready(function(){
		//Code Starts
		
		dvjQuery = $('.catType1').detach();
		$("#dvParent").html(dvjQuery);
		//Code Ends
		
		//$('.catType1').hide();
		$("#saveListKolsForm").validate({
			debug:true,
			//onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});
		
		$.validator.addMethod("alphaNumeric", function(value, element) {
	        return this.optional(element) || /^[a-z0-9\- ]+$/i.test(value);
	    }, "Letters, numbers and dashes are allowed.");
	});

	function validateListForm(){
		if(!$("#saveListKolsForm").validate().form()){
			//enableButton("saveEducation");
			return false;
		}else
			return true;
	}
	
	/*
	* Ajax saving of selected Kols
	* @author Vinayak
	* @since 2.0
	* created on 8/4/2011 
	*/	
	$("#saveKolList").click(function(){
		if(!$("#saveListKolsForm").validate().form()){
			return false;
		}
		var kols=$("#kolId").val();
		if(kols!=0){
			$(' div.categoryMsgBox').removeClass('success');
			$(' div.categoryMsgBox').addClass('notice');
			$(' div.categoryMsgBox').show();
			$('div.categoryMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			$('div.categoryMsgBox').css({color:"black"});
	
			
			$.ajax({
				url:'<?php echo base_url()?>my_list_kols/save_list_kols',
				data:$('#saveListKolsForm').serialize(),
				type:'post',
				dataType:'json',
				success:function(returnData){
						if(returnData.cat_saved==true){
								if(returnData.list_saved==false)
									$('div.categoryMsgBox').text(returnData.msg1);
								else
								$('div.categoryMsgBox').text(returnData.msg);
						}else if(returnData.cat_saved==false){
							$('div.categoryMsgBox').text(returnData.msg);
						}else{
							$('div.categoryMsgBox').text(returnData.msg1);
						}
						if((returnData.cat_saved==true) && (returnData.list_saved==true )){
							//$('#errorBox').removeClass('error');
							//$('.categoryMsgBox').hide();	
							//$('#errorBox').html('Saved Successfully');
	
							$('div.categoryMsgBox').removeClass('error');
							$('div.categoryMsgBox').addClass('success');
							
							setTimeout(closeDialog, 2000);
						}else{
							$('div.categoryMsgBox').addClass('error');
							$('div.categoryMsgBox').removeClass('success');
							$('div.categoryMsgBox').fadeOut(10000);
						}
						var category	= sessionStorage['categoryName'];
						if(category=="kol_create_list"){
							moveFromCurrentStep(5);
						}
					}
			});	
		}
		else{
			$('div.categoryMsgBox').text("No <?php echo lang("KOL");?>s selected. Please select the KOLs and click on create list.");
			$('div.categoryMsgBox').css({color:'red'});
			setTimeout(closeDialog, 4000);
		}
	});

	function closeDialog(){
		$("#categoryModalBox").dialog("close");
		$("#categoryModalBoxWithinProile").dialog("close");
	}

	/*
	* To get list names of particular 'category'
    * @author Vinayak
	* @since 2.0
	* created on 8/4/2011 
	*/
	function displayField(){

		if($('#categoryId').val()==0){
			$("#list_id").html("<option value=''>Select</option><option id='css1' style='color:red' value='0' name='list_name'>Add New List Name</option>");
		
		}
		if(($('#categoryId').val()!=0) && ($('#categoryId').val()!='Select')){
			var id=$('#categoryId').val();
			//$("#list_id").html("<option value='0' id='css2' name='list_name'>Add New List</option>");
			$("#list_id").html("");
			var list = document.getElementById('list_id');
			//jAlert(list.toSource());
			$('#loadingTopic').show();
			$.ajax({
				url:'<?php echo base_url()?>my_list_kols/get_list_names/'+id,
				type:'post',
				dataType:'json',
				success: function(responseText){					
					$('#list_id').prepend("<option value='' selected='selected'>Select</option>");
						$.each(responseText, function(key, value) {				
							
							//var listName = document.createElement('option');
								//listName.text = value.list_name;

				  				
								
								//jAlert(newState.text);
								//	listName.value = value.id;
								//var prev = list.options[list.selectedIndex];
								//jAlert(prev.toSource());
							
								if(value.list_name!='undefined'){
									 $('#list_id').append($("<option></option>")
							                    .attr("value",value.id)
							                    .text(value.list_name));		
								}

								if(value.is_public==1){
									$("#isPrivate").removeAttr("checked");
									$("#isPublic").attr({'checked':'checked'});
								}else{
									$("#isPrivate").attr({'checked':'checked'});
								}
							});
						
						$('#list_id').append("<option value='0' id='css2' name='list_name'>Add New List</option>")
				                   

						
					},
					complete:function(){
						$('#loadingTopic').hide();
					}	
			});
		}

		if($('#categoryId').val()==0 && $('#categoryId').val() !=''){
			$('#input').html('<label>Add Category :</label><input  type="text" name="category" class="required"></input>');
		}else{
			$('#input').html('');
		}
	
	}

	/*
	* To diplay hidden field 
 	* @author Vinayak
	* @since 2.0
	* created on 8/4/2011 
	*/
	function displayNameField(){
		
		var value =$('#list_id').val(); 
		if(value == 0 && value !=''){
			$('#listInputBoxContaioner').html('<label>Add List Name :</label><input type="text" name="list_name" class="required"></input>');
		}else{
			$('#listInputBoxContaioner').html('');
		}

	}

	function toggleCategory(thisObj){
		
		var is_public	= thisObj.value;
		if(is_public==1){
			private1 = $('.catType0').detach();
			$('#categoryId').append(dvjQuery);
			//$('.catType0').hide();
			//$('.catType1').show();
		}else{
			$(".catType1").detach();
			$('#categoryId').append(private1);
			//$('.catType1').hide();
			//$('.catType0').show();
		}
	}
</script>

		<div class="categoryMsgBox"></div><div class="errorBox"></div>
		<form action="<?php echo base_url();?>my_list_kols/save_list_kols" method="post" id="saveListKolsForm" name="saveKolsForm" class="validateForm" onsubmit="return validateListForm();">
		<input  type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKols?>"></input>
		
		<?php if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){?>
			<label>Private</label><input type="radio" name="is_public" id="isPrivate" value="0" checked="checked" onclick="toggleCategory(this);">
			<label>Public</label><input type="radio" name="is_public" id="isPublic" value="1"  class="required" onclick="toggleCategory(this);">
		<?php }?>	
		<table class="anaylystForm clientTbl addList">
			
			<tr>
				<td>
					<p>	
						<label for="clientName">Categories :<span class="required">*</span></label>
						<select name="category_id" id="categoryId" onchange="displayField();" class="required">
							<option value="">Select </option>
							<option value="0" id="catCss">Add New Category </option>
							<?php foreach($arrCetgory as $row){?>
							
							<option class="catType<?php echo $row['is_public'];?>" value="<?php echo $row['id']?>"><?php echo $row['category']?></option>
							<?php }?>
							
						</select>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p id="input">
						
					
					</p>
				
				</td>
			
			</tr>
			<tr>
				<td>
					<p>
						<label for="clientNotes">List Names :<span class="required">*</span></label>
						<select name="list_name_id"  id="list_id" onchange="displayNameField()" class="required">
						<option value="">Select</option>
						<option value="0" id="listNameCss">Add New List Name</option>
						</select>	
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						
					</p>
				</td>
			</tr>
			 <tr>
	         	<td>
	         		<p id="listInputBoxContaioner">
	         		
	         		</p>
	         	
	         	</td>
	         
	         </tr>
			<tr>
				<td>
					<div class="formButtons"">
						<input type="button" value="Save"  id="saveKolList" name="saveKolList">
			         </div>
		         </td>
	         </tr>
	        
         </table>
	</form>