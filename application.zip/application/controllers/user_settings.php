<?php
/**
 * This is Controller file for 'User settings'
 * 
 * @author Vivekanand N
 * @since
 * @package application.controllers	 
 * @created on 03-12-2013
 */

class User_settings extends Controller{
	
	private $loggedUserId	= null;
	//Constructor
	function User_settings(){
		parent::Controller();
		$this->load->model("user_setting");
		$this->load->library('ColinUpload');
		$this->load->library('SimpleLoginSecure');
                $this->load->model('common_helpers');
                $this->load->model('Client_User');
                 $this->load->model('media_parser');
		$this->loggedUserId	= $this->session->userdata('user_id');
	}
	
	function index($type=null){
		$data['type'] = $type;
//		pr($this->session->userdata);
		require_once($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/libraries/mobile_device_detect.php");
		$mobile = mobile_device_detect();
// 		pr($mobile);
		if(isset($mobile[1])){		
		    if(preg_match('/iPad/',$mobile[1])){		       
		        redirect(IPAD_URL_SEGMENT.'/user_settings/index/password');
		    }
		    else{		        
		        redirect(MOBILE_URL_SEGMENT.'/user_settings/index/password');
		    }
		}
		$data['arrUsersToOptInOptOut'] = $this->user_setting->getUsersToOptInOptOut();
		$data['contentPage'] 	= 'user_settings/view_settings';
		$this->load->view('layouts/client_view',$data);
	}
	
	function edit_user_profile() {
		$data['arrUserDetails'] = $this->user_setting->getUserdetail($this->loggedUserId);
		$this->load->view('user_settings/edit_user_profile',$data);
	}
	
	/**
	 * General Settings
	 */
	function general() {
		$userId = $this->loggedUserId;
		$savedData = $this->user_setting->getAppSettingsSavedData($userId);
		if($savedData){
			$getAppDetails = $this->user_setting->getApplicationSettings($userId);
		}else{
			$getAppDetails = $this->user_setting->getApplicationSettings();
		}
		$arrOptions = array();
		foreach($getAppDetails as $row){
			$arrOptions[$row['id']]['name'] = $row['name'];
			$arrOptions[$row['id']]['lable_name'] = $row['lable_name'];
			$arrOptions[$row['id']]['saved_value'] = $row['user_app_value'];
			$arrOptions[$row['id']]['values'][$row['app_setting_value_id']] = array(
											'type_value'=>$row['type_value'],
											'type_lable'=>$row['type_lable']
										);
		}
		$data['arrOptions']	= $arrOptions;
		$this->load->view('user_settings/application_settings',$data);
	}
	function optin_optout() {	    
	    $arrUserData = array();	    
	    $arrData = $this->user_setting->getRegionsFromGroups($this->loggedUserId,'team');
	    foreach ($arrData as $rowData){
	        $arrUserData[$rowData['group_id']]['group_name'] = $rowData['group_name'];
	        $arrUserData[$rowData['group_id']]['created_by'] = $rowData['created_by'];
	        $arrUserData[$rowData['group_id']]['group_id'] = $rowData['group_id'];
	        $arrUserData[$rowData['group_id']]['name'][] = $rowData['first_name']." ".$rowData['last_name'];
	    }
	   $data['region'] = $arrUserData;
	   $data['optInOutData'] = $arrOptInOutData;
	   $this->load->view('user_settings/oioo_settings',$data);
	}
	
	function id_profile_settings() {
	    $arrUserData = array();
	    $arrData = $this->user_setting->getRegionsFromGroups($this->loggedUserId,'team');
	    foreach ($arrData as $rowData){
	        $arrUserData[$rowData['group_id']]['group_name'] = $rowData['group_name'];
	        $arrUserData[$rowData['group_id']]['created_by'] = $rowData['created_by'];
	        $arrUserData[$rowData['group_id']]['group_id'] = $rowData['group_id'];
	        $arrUserData[$rowData['group_id']]['name'][] = $rowData['first_name']." ".$rowData['last_name'];
	    }
	    $data['region'] = $arrUserData;
	    $data['optInOutData'] = $arrOptInOutData;
	    $this->load->view('user_settings/id_profile_setting',$data);
	}
	function save_update_oioo_settings(){
	    $arr['client_id'] = $this->session->userdata('client_id');
	    $arr['region'] = $this->input->post('region');
	    $arr['isEnabled'] = $this->input->post('process');
	    $arr['duration'] = $this->input->post('duration');
	    $arrOptin = $this->user_setting->saveUpdateOptInOut($arr);
	    $returnData['status'] = $arrOptin;
	    echo json_encode($returnData);
	}
	
	function save_update_id_profile_settings(){
	    $arr['client_id'] = $this->session->userdata('client_id');
	    $arr['region'] = $this->input->post('region');
	    $arr['isEnabled'] = $this->input->post('process');
	    $arrOptin = $this->user_setting->saveUpdateIdProfile($arr);
	    $returnData['status'] = $arrOptin;
	    echo json_encode($returnData);
	}
	
	function add_application_settings(){
		$userId = $this->loggedUserId;
		$arrDetails = $this->input->post("user_settings");
		foreach($arrDetails as $key=>$value){
			$arrData = array();
			$arrData['user_id'] = $userId;
			$arrData['app_setting_type_id'] = $key;
			$arrData['app_setting_value_id'] = $value;
			$lastIns = $this->user_setting->add_application_settings($arrData);
		}
		$data['status'] = true;
		echo json_encode($data);
// 		redirect("user_settings");
	}
	
	function update_user_data() {
		$arrData = array();
		$arrData["id"] 				= $this->loggedUserId;
		$arrData["first_name"] 		= $this->input->post("data_1");
		$arrData["last_name"] 		= $this->input->post("data_2");
		$arrData["title"] 			= $this->input->post("data_3");
		$arrData["phone"] 			= $this->input->post("data_4");
		$arrData["department"] 		= $this->input->post("data_5");
		$arrData["address"] 		= $this->input->post("data_6");
		$arrData["about"] 			= $this->input->post("data_7");
		$this->load->library('form_validation');
		//set validations
		$this->form_validation->set_rules("data_1", "First Name", "trim|required");
		$this->form_validation->set_rules("data_2", "Last Name", "trim|required");
		$this->form_validation->set_rules("data_4", "Phone No.", "trim|required|numeric");
		if($this->form_validation->run() == FALSE){
			$this->session->set_flashdata('status', 'Invalid input data.');
			//redirect("user_settings");
			$data['type'] = null;
			$data['contentPage'] 	= 'user_settings/view_settings';
			$this->load->view('layouts/client_view',$data);
		}else{
//		unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/user_profile_images/".$this->input->post('prevImage'));
		$imageHandler = new ColinUpload($_FILES["imageUpload"]);
			if ($imageHandler->uploaded) {
//				if($this->input->post('prevImage') != '')
				unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/user_profile_images/".$this->input->post('prevImage'));
				$filePath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/user_profile_images/";
				$pathInfo = pathinfo($_FILES["imageUpload"]['name']);
				$newFileName	= random_string('unique', 20);
			       $imageHandler->file_new_name_body   = $newFileName;
			       $imageHandler->image_resize         = true;
			       $imageHandler->image_x              = 90;
			       $imageHandler->image_y              = 90;
//			       $imageHandler->image_ratio_y        = true;
			       $imageHandler->process($filePath);
			       if ($imageHandler->processed) {
			       		$arrData["mem_pic"] 		= $newFileName.".".$pathInfo['extension'];;
			            $imageHandler->clean();
			       } 
		   }
//		$filePath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/user_profile_images";
//		if($_FILES["imageUpload"]['name'] != ''){
//			$pathInfo = pathinfo($_FILES["imageUpload"]['name']);
//			$newFileName	= random_string('unique', 20).".".$pathInfo['extension'];
//			$overview_file_target_path = $filePath ."/". $newFileName;
//			if(move_uploaded_file($_FILES["imageUpload"]["tmp_name"],$overview_file_target_path)){
//				$arrData["mem_pic"] 		= $newFileName;
//			}
//		}
		$this->user_setting->updateUserData($arrData);
		$this->session->set_userdata('mem_pic',$arrData["mem_pic"]);
		redirect("user_settings");
		}
	}
	
	function edit_user_password() {
		$data['arrUserDetails'] = $this->user_setting->getUserdetail($this->loggedUserId);
		$this->load->view('user_settings/edit_user_password',$data);
	}
	
	function add_user_groups($type='group') {
		$clientId = $this->session->userdata('client_id');
		$data['arrUsers'] = $this->user_setting->getAllUsers($clientId);
		$data['groupsOrTeams'] = $type;
		$this->load->view('user_settings/edit_user_groups',$data);
	}
	
	function save_user_group(){
		$arrData = array();
		$arrData["created_by"]		= $this->loggedUserId;
		$arrData["group_name"] 		= $this->input->post("group_name");
		$arrData["group_type"] 		= ucfirst($this->input->post("group_type"));
		$arrData["created_on"] 		= date("Y-m-d H:i:s");
		$usersId 					= $this->input->post("users_id");
		if($this->user_setting->checkDuplicatGroupName($arrData["group_name"])){
			$id = $this->user_setting->addGroup($arrData);
			foreach($usersId as $userId){
				$arr[] = array("user_id"=>$userId,"group_id"=>$id);
			}
			if($this->user_setting->saveUserGroup($arr)){
				$data['status'] = true;
			}else{
				$data['status'] = false;
			}
			echo json_encode($data);
		}else{
			$data['status'] = false;
			echo json_encode($data);
		} 
				
	}
	
	function get_all_users_groups($type='group'){
            
		$arrUserData = array();
		$arrData = $this->user_setting->getAllUsersGroups($this->loggedUserId,$type);
		foreach ($arrData as $rowData){
			$arrUserData[$rowData['group_id']]['group_name'] = $rowData['group_name'];
			$arrUserData[$rowData['group_id']]['created_by'] = $rowData['created_by'];
			$arrUserData[$rowData['group_id']]['group_id'] = $rowData['group_id'];
			$arrUserData[$rowData['group_id']]['name'][] = $rowData['first_name']." ".$rowData['last_name'];
		}               
//		pr($arrUserData);		
		$data['groupsOrTeams'] = $type;
		$data['arrUserData'] = $arrUserData; 
		$this->load->view('user_settings/edit_user_groups',$data);
	}
	
	function edit_language(){
		$this->load->view('user_settings/edit_language');
	}
	
	function change_language(){
		$language = $this->input->post('language');
		$this->session->set_userdata('lang',$language);
		redirect($_SERVER['HTTP_REFERER']);
	}
	
	function edit_users_groups_by_id($groupId,$type) {
		$clientId = $this->session->userdata('client_id');
		$data['arrUsers'] = $this->user_setting->getAllUsers($clientId);
		$data['arrExistUser'] = $this->user_setting->getUserGroupById($this->loggedUserId,$groupId,$type);
		//pr($arrExistUser);
		foreach ($data['arrExistUser'] as $rowData){
			$arrUserData['group_name'] = $rowData['group_name'];
			$arrUserData['created_by'] = $rowData['created_by'];
			$arrUserData['group_id'] = $rowData['group_id'];
			$arrUserData['name'][$rowData['user_id']] = $rowData['user_id'];
		}
// 		pr($arrUserData);
		$data['arrExistUserData'] = $arrUserData; 
		$data['groupsOrTeams'] = $type;
		$this->load->view('user_settings/edit_user_groups',$data);
	}
	
	function update_user_group(){
		$arrData = array();
		$arrData["modified_by"]		= $this->loggedUserId;
		$arrData["group_name"] 		= $this->input->post("group_name");
		$arrData["modified_on"] 	= date("Y-m-d H:i:s");
		$arrData["group_id"] 		= $this->input->post("group_id");
		$usersId 					= $this->input->post("users_id"); 
		if($this->user_setting->checkDuplicatGroupNameByGroupId($arrData["group_id"],$arrData["group_name"])){
			if($this->user_setting->updateGroup($arrData)){
				foreach($usersId as $userId){
					$arr[] = array("user_id"=>$userId,"group_id"=>$arrData["group_id"]);
				}
				if($this->user_setting->updateUserGroup($arrData["group_id"],$arr)){
					$data['status'] = true;
				}else{
					$data['status'] = false;
				}
			}
			echo json_encode($data);
		}else{
			$data['status'] = false;
			echo json_encode($data);
		}
	}
	
	function delete_user_group($groupId){
		if($this->user_setting->deleteUserGroupById($groupId)){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function updatePassword() {
		$password = 0;
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$arrData = array();
		$userName	= $this->session->userdata('user_name');
		$arrData['id'] = $this->loggedUserId;
		$newPassword	= $this->input->post('new_pasword');
		$arrData['password']   = $hasher->HashPassword($newPassword);
		$arrPassword = $this->Client_User->getUserRecentPassword($arrData['id']);
		if(strlen($newPassword)<8){
			$data['status'] = false;
			$data['text'] ="Password should of minimum of 8 characters" ;
			echo json_encode($data);
			return false;
		}
		if(preg_match("/".$userName."/i",$newPassword)){
			$data['status'] = false;
			$data['text'] ="Username should not be used in password." ;
			echo json_encode($data);
			return false;
		}
		 $userCurrentPassword	= $this->Client_User->getUserCurrentPassword($arrData['id']);
			if($hasher->CheckPassword($this->input->post('current_pasword'), $userCurrentPassword[0]['password'])){
				foreach($arrPassword as $row){
					if($hasher->CheckPassword($newPassword, $row['password'])){
						$password=1;
					}
				}
				if($password==0){
					if($this->user_setting->updatePassword($arrData)){
						$passwordDetals['user_id'] = $this->loggedUserId;
							$passwordDetals['created_by'] = $this->session->userdata('user_id');
							$passwordDetals['last_created'] = date('Y-m-d H:i:s');
							$passwordDetals['last_created'] = date('Y-m-d H:i:s');
								$passwordDetals['password'] = $arrData['password'];
							$this->Client_User->savePassword($passwordDetals);
						$data['status'] = true;
					}else{
						$data['status'] = false;
					}
				}else{
					$data['status'] = 'invalid_no_of_pwd';
					$data['text'] ="Password should not be same as your previous ".RESTRICT_NO_OF_PASSWORDS_TO_REUSE." passwords" ;
				}
			}else{
				$data['status'] = 'invalid_current_pwd';
				$data['text'] ="Current Password is invalid" ;
			}
		echo json_encode($data);
	}
	
	function support_email_configure(){
		$data['arrSupporEmailId'] = $this->user_setting->getAllClientsAndSupportEmailIds();
		$this->load->view('user_settings/edit_support_email',$data);
	}
	
	function update_support_email_address(){
		$arrData = array();
		$arrData['id']						=	$this->input->post("id");
		$arrData['support_email_id']		=	$this->input->post("emailAddress");
		$arrData['modified_by']				=	$this->loggedUserId;
		$arrData['modified_on']				=	date("Y-m-d H:i:s");
		if($this->user_setting->updateSupportEmailAddress($arrData)){
			$data['status'] = true; 
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function name_format(){
//		pr($this->session->userdata);
		$clientId = $this->session->userdata("user_id");
		$data['formatId'] = $this->user_setting->getNameFormat($clientId);
		$this->load->view('user_settings/name_format',$data);
	}
	
	function save_name_format_old(){
		
		$nameFormatVal['id'] = $this->session->userdata('client_id');
		$nameFormatVal['name_format'] = $this->input->post('val');
		
		if($this->user_setting->saveNameFormat($nameFormatVal)){
			
			$filePath = $_SERVER['DOCUMENT_ROOT']."".$this->config->item('app_folder_path')."application/config/constants.php";
			$handle = fopen($filePath, "r+");
			$arrLine = array();
			while(!feof($handle)){
				$arrLine[] = fgets($handle);
		    }
			$arrNewLines = array();
			if($nameFormatVal['name_format'] == 2){
			    foreach ($arrLine as $key => $line){
			    	if(trim($arrLine[$key]) == "define('FIRST_ORDER','first_name');"){
			    		$arrNewLines[$key] = "define('FIRST_ORDER','last_name');\n";
			    	}else if(trim($arrLine[$key]) == "define('THIRD_ORDER','last_name');"){
			    		$arrNewLines[$key] = "define('THIRD_ORDER','first_name');\n";
			    	}else{
			    		$arrNewLines[$key] = $line;
			    	}
			    }
			}else if($nameFormatVal['name_format'] == 1){
			 	foreach ($arrLine as $key => $line){
			    	if(trim($arrLine[$key]) == "define('FIRST_ORDER','last_name');"){
			    		$arrNewLines[$key] = "define('FIRST_ORDER','first_name');\n";
			    	}else if(trim($arrLine[$key]) == "define('THIRD_ORDER','first_name');"){
			    		$arrNewLines[$key] = "define('THIRD_ORDER','last_name');\n";
			    	}else{
			    		$arrNewLines[$key] = $line;
			    	}
			    }
		    }
		    file_put_contents($filePath, $arrNewLines);
//		    if(file_put_contents($filePath, $arrNewLines)){
//		    	echo "true";
//		    }
			fclose($handle);
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function save_name_format(){
		$nameFormatVal['client_id'] = $this->session->userdata('client_id');
		$nameFormatVal['name_order'] = $this->input->post('val');
		//if($this->session->userdata('user_role_id') == ROLE_MANAGER){
			$this->session->set_userdata('name_order',$nameFormatVal['name_order']);
			$this->user_setting->saveNameFormat($nameFormatVal);
		//}
		$this->load->view('user_settings/name_format');
	}
	function update_walkthrough(){
		$status	= $this->input->post('walkthrough');
		$this->user_setting->updateWalkthrough($status);
		$sess_data['userSettings']['walkthrough']	= $status;
		$this->session->set_userdata($sess_data);
	}
	function users(){
		$this->load->view('user_settings/get_users');
	}
        
	function list_users(){
            
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
       // $this->common_helpers->checkUsers();
        $client_id = $this->session->userdata('client_id');
        $arrUsers = $this->Client_User->getUsers($client_id);
        foreach ($arrUsers as $row) {
            $arrResult[] = $row;
        }
        $count = sizeof($arrResult);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrResult;
      
        echo json_encode($data); 
              
        }
        function medintel($isfromMedia) {
		$result=$this->media_parser->getEmailSettings();
                if($isfromMedia)
                    $data['media']=1;
		$data['option']=$result['option'];
		$this->load->view('user_settings/medintel',$data);
	}
        
        function save_medintel_settings($option,$userId){
            
            $this->media_parser->saveSettings($option,$userId);
        }
        
        function getAllProducts() {
        	$this->db->select("id,name");
        	$arrData = $this->db->get('products');
        	foreach ($arrData->result_array() as $row) {
        		$arrRetData[$row['id']] = $row['name'];
        	}
        	return $arrRetData;
        }
        function getAllTopics() {
        	$this->db->select("interaction_topics.id,interaction_topics.name");
        	$arrData = $this->db->get('interaction_topics');
        	foreach ($arrData->result_array() as $row) {
        		$arrRetData[$row['id']] = $row['name'];
        	}
        	return $arrRetData;
        }
        function associate_interaction_product_type_topic(){
        	$arrData = array();
        	$this->load->model('interaction');
        	$arrData['arrProducts'] = $this->getAllProducts();
        	$arrData['arrTypes'] = $this->interaction->getAllTypesOfClient();
        	$arrData['arrTopics'] = $this->getAllTopics();
        	//$arrData['arrTopics'] = $this->interaction->getTopicByType($row['interaction_type'], $row['product_id']);
        	//$arrData['arrSubTopics'] = $this->interaction->getSubTopics($row['product_id'], $row['interaction_type'], $row['topic_id']);
        	$arrData['contentPage']= 'user_settings/associate_interaction_product_type_topic';
        	$this->load->view('layouts/client_view',$arrData);
        }
        function save_associate_interaction_product_type_topic(){
        	$arrProductIds    = $this->input->post('product_ids');
        	$arrTypeIds    = $this->input->post('type_ids');
        	$arrTopicIds    = $this->input->post('topic_ids');
        	foreach($arrProductIds as $productIdsKey=>$productId){
        		foreach($arrTypeIds as $typeIdsKey=>$typeId){
        			$arrAssociation    = array();
        			$arrAssociation['status']    = 1;
        			$arrAssociation['product_id']    = $productId;
        			$arrAssociation['type_id']    = $typeId;
        			$this->db->insert('interaction_type_by_product',$arrAssociation);
        			foreach($arrTopicIds as $topicIdsKey=>$topicId){
        				$arrAssociation['topic_id']    = $topicId;
        				$this->db->insert('interaction_topics_by_type',$arrAssociation);
        			}
        		}
        	}
        }
        
        
        function associate_team_to_product(){
            $arrData = array();
            $arrData['arrProducts'] = $this->getAllProducts();
            $arrData['arrTeam'] = $this->user_setting->getTeams();
            $arrData['contentPage']= 'user_settings/associate_teams_to_products';
            $this->load->view('layouts/client_view',$arrData);
        }
        function save_associate_teams_to_products(){
            $arrProductIds    = $this->input->post('product_ids');
            $arrTeamIds    = $this->input->post('team_ids');            
            foreach($arrTeamIds as $teamIdsKey=>$teamId){
                foreach($arrProductIds as $productIdsKey=>$productId){
                    $arrAssociation    = array();
                    $arrAssociation['product_id']    = $productId;
                    $arrAssociation['group_id']    = $teamId;
                    $this->db->insert('group_products',$arrAssociation);
                }
            }
            echo "Sucessfully Assoiciated";
        }
        
}