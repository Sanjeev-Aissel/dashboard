<?php
/**
 * @Author : Sanjeev K
 * @Desc : Controller for Organizations data manipulation
 * @Since : KOLM_hmvc 1.0
 * @Package : application.controllers
 * @Created : 25-06-2018
 * @Refactored : 26-06-2018
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class organizations extends MX_Controller {
	
	private $loggedUserId = null;
	
	//Constructor
	public function __construct()
	{
		parent::__construct();
		//load models
		$this->load->model('analysts/organization');
		$this->load->model('analysts/kol');
		$this->load->model('analysts/speciality');
		$this->load->model('analysts/json_store');
		$this->load->model('analysts/pubmed');
		$this->load->model('helpers/country_helper');
		$this->load->model('helpers/common_helper');
		
		//variables
		$this->loggedUserId = $this->session->userdata('user_id');
		$this->clientId		=$this->session->userdata('client_id');
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : list_organizations()
	 * @Param  : none
	 * @return : loads list organizations view
	 */
	function list_organizations(){
		$this->common_helper->checkUsers();
		$analyst_client = $this->session->userdata('analyst_client');
		if(!isset($analyst_client)){
			redirect('clients/analysis_client');
		}
		
		$data['contentPage'] = 'organizations/list_organizations';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_organizations_grid()
	 * @Param  : none
	 * @return : returns organizations list to jqgrid
	 */
	function list_organizations_grid($overRideAction = false){
		$page = $_REQUEST['page']; 
		$limit = $_REQUEST['rows']; 
		$sidx = $_REQUEST['sidx']; 
		$sord = $_REQUEST['sord'];
		if(!$sidx) $sidx =1;
		$filterData=$_REQUEST['filters'];
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helper->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helper->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helper->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];
		}
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
		$count	=	$this->organization->listOrganizationGridDetails($limit,$start,true,$sidx,$sord,$whereResultArray);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
			
		$arrOrgDetailResult = array();
		$data 				= array();
		$arrOrgDetail		= array();
		if($arrOrgDetailResult = $this->organization->listOrganizationGridDetails($limit,$start,false,$sidx,$sord,$whereResultArray)){
			
			foreach($arrOrgDetailResult->result_array() as $row){
				$row['id']			= $row['id'];
				$row['name']		= $row['name'];
				$row['type']		= $row['type'];
				$row['founded']		= $row['founded'];
				if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
					if($row['is_pubmed_processed'] == 0)
						$pubStatusHtml= "No";
		
					if($row['is_pubmed_processed'] == 1)
						$pubStatusHtml = "Yes";
		
					if($row['is_pubmed_processed'] == 2)
						$pubStatusHtml = "Recrawl";
		
					$row['is_pubmed_processed']	= $pubStatusHtml;
				}else{
					$pubStatus = 'No';
					if($row['is_pubmed_processed'] == 1)
						$pubStatus = 'Yes';
					if($row['is_pubmed_processed'] == 2)
						$pubStatus = 'Recrawl';
					$row['is_pubmed_processed']	= $pubStatus;
				}
				if($row['is_clinical_trial_processed'] == 0){
					$trialStatusHtml= "No";
				}else{
					$trialStatusHtml = "Yes";
				}
				$row['is_clinical_trial_processed']	= $trialStatusHtml;
		
				if($row['profile_type'] == 1){
					$profileTypeHtml= "Basic";
				}else{
					$profileTypeHtml = "Full";
				}
				$parentOrg = $this->organization->getOrgs('id', $row['parent_id'], 'WHERE');
				foreach ($parentOrg as $org){
					$row['parent_name'] = $org['name'];
				}
				$row['profile_type']= $profileTypeHtml;
				$row['created_by']	= $row['user_full_name'];
				$row['status']	= $row['status'];
				$actions = '<a href="'.base_url().'analysts/organizations/edit_organization/'.$row['ovid'].'/about" title="Edit"><span class="icon edit glyphicon glyphicon-edit"></span></a> <a onclick="deleteSelectedOrg('.$row['ovid'].')" href="javascript:void(0)" title="delete"><span class="icon delete glyphicon glyphicon-trash"></span></a>';
				if($overRideAction){
					$actions = '<a href="javascript:assocOrgDialog('.$row['id'].',\''.$row['name'].'\','.$row['parent_id'].',\''.$row['parent_name'].'\');" title="Associate"><span class="icon glyphicon glyphicon-random"></span></a>';
				}
				$row['action']	= $actions;
				$arrOrgDetail[]	= $row;
			}
		
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrOrgDetail;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : add_organization()
	 * @Param  : none
	 * @return : loads add Organization's view
	 */
	function add_organization(){
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		 
		$reportSection=$this->uri->segment(3);
		// Remove any OrganizationId from Session, if set
		$this->session->unset_userdata("organizationId");
			
		$organizationDetails = array(	
				'id' 				=>  '',
				'name' 				=>  '',
				'type_id'			=>  '',
				'company_logo'		=> 	'',
				'website'			=>  '',
				'founded'			=> 	'',
				'background'		=>	'',
				'products_services'	=> 	'',
				'mission_vision' 	=> 	'',
				'headquarters'	 	=>  '',
				'address'	 		=> 	'',
				'phone'	 			=> 	'',
				'fax'	 			=> 	'',
				'country_id'	 	=> 	'',
				'state_id' 			=> 	'',
				'city_id'	 		=> 	'',
				'postal_code'	 	=> 	'',
				'blog'	 			=> 	'',
				'facebook'	 		=> 	'',
				'twitter'	 		=> 	'',
				'youtube'	 		=> 	'',
				'linkedin'	 		=> 	'',
				'created_by'		=>	'',
				'created_on'		=>	''
		);
			
		$data['arrOrganization']	= $organizationDetails;
	
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
	
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
	
		$data['arrCountry']=$this->country_helper->listCountries();
	
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$data['reportSection']=$reportSection;
		$data['contentPage'] 	=	'organizations/add_organization';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : save_kol()
	 * @Param  : salutation, gender, first_name, middle_name, last_name, suffix, specialty, org_id, is_pubmed_processed, status, npi_num, profile_type, unique_id
	 * @return : insert / modify kol details
	 */
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_kol()
	 * @Param  : none
	 * @return : deletes deleted kol with selected parameters
	 */
	
	/**
	 * top bar functionalities starts
	 * @Author : Sanjeev K
	 * @Method : update_status()
	 * @Param  : status, kol id(array)
	 * @return : update status of kol
	 */
	
	/**
	*  Grid bar functionalities
	* @Author : Sanjeev K
	* @Method : calculate_dashboard_data()
	* @Param  : none
	* @return : none
	*/
	
	/**
	 *  bottom bar functionalities
	 * @Author : Sanjeev K
	 * @Method : calculate_dashboard_data()
	 * @Param  : none
	 * @return : none
	 */
	
	/**
	 * Edit option functionalities starts
	 * About Tab
	 * @Author : Sanjeev K
	 * @Method : edit_organization()
	 * @Param  : $organizationId 
	 * @return : loads add organization's edit view
	 */
	function edit_organization($organizationId = null, $type){
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
	
		$reportSection=$this->uri->segment(5);
		
		if(!$organizationId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('analysts/organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('analysts/organizations/list_organizations');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $organizationId);
	
		$data['arrCountry']		=	$this->country_helper->listCountries();
	
		$arrStates 	= array();
		$arrCities	= array();
	
		if($arrOrganizationDetail['country_id'] != 0){
			$arrStates = $this->country_helper->getStatesByCountryId($arrOrganizationDetail['country_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
			$arrCities = $this->country_helper->getCitiesByStateId($arrOrganizationDetail['state_id']);
		}
		$data['arrStates']	= $arrStates;
		$data['arrCities']	= $arrCities;
	
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
	
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
	
		$data['arrCountry']=$this->country_helper->listCountries();
	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
		$data['arrContactDetails']	= array();
		$arrContactDetails = array();
		if($arrContactDetails = $this->organization->listContacts($organizationId)){
			foreach ($arrContactDetails->result_array() as $row){
				$data['arrContactDetails'][] = $row;
			}
		}
	
	
		$data['arrOrganization']	= $arrOrganizationDetail;
		//pr($arrOrganizationDetail);
		//$data['orgContentPage'] 	=	'organizations/add_organization';
		//$this->load->view('organizations/organization_profile',$data);
		if($reportSection == 'publications')
			$data['contentPage'] 	=	'pubmeds/list_org_publications';
		else if ($reportSection == 'trials')
			$data['contentPage'] 	=	'clinical_trials/list_org_clinical_trials';
		else
			$data['contentPage'] 	=	'organizations/edit_organization';
					
		$data['reportSection']=$type;
		//$data['orgId']=$organizationId;
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : upload_organization_logo()
	 * @Param  : none
	 * @return : loads add organization's edit view
	 */
	function upload_organization_logo(){
		$this->load->library('colinUpload');
		$orgLogo = new ColinUpload($_FILES['organization_logo']);
		if ($orgLogo->uploaded) {
			// Save uploaded image with a random name
				
			// Generate the Random String
			$this->load->helper('string');
			$newFileName	= random_string('unique', 20);

			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->process('images/organization_images/original');
			if ($orgLogo->processed) {
	
			} else {
				log_message('error', 'Error while uploading the image'. $orgLogo->error);
			}
	
			// Resize the image to Medium Size and save
			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->image_resize = true;
			$orgLogo->image_x = 400;
			$orgLogo->image_ratio_y = true;
			$orgLogo->Process('images/organization_images/medium');
			if ($orgLogo->processed) {
	
			} else {
				log_message('error', 'Error while Resizing the Image to Medium Size'. $orgLogo->error);
			}
				
				
			// Resize the image to Small Size and save
			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->image_resize = true;
			$orgLogo->image_x = 144;
			$orgLogo->image_ratio_y = true;
			$orgLogo->Process('images/organization_images/resized');
			if ($orgLogo->processed) {
				//echo 'Image Resized';
				$orgLogo->Clean();
	
				// Save the Image Path into the database
				$this->organization->db->where('id', $this->session->userdata('organizationId'));
	
				$data['company_logo']	= $newFileName . '.' . $orgLogo->file_src_name_ext;
				$this->organization->db->update('organizations', $data);
	
				// Redirect to the organization Profile
				redirect(base_url().'analysts/organizations/edit_organization/'.$this->session->userdata('organizationId').'/about');
				exit;
	
				// Output the HTML text
				echo '<div id="output">success</div>';
	
				//then output your message (optional)
				$imageSrc	= base_url().'images/organization_images/medium/'.$data['company_logo'];
				echo '<div id="message"><img src="'.$imageSrc.'" alt="Uploaded Image"> </div>';
	
				echo '<div id="imageSrc">'.$imageSrc.'</div>';
	
			} else {
				log_message('error', 'Error while uploading the image'. $orgLogo->error);
			}
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : crop_image()
	 * @Param  : none
	 * @return : store image name in database
	 */
	function crop_image(){
		$x1	= $this->input->post('x1');
		$y1	= $this->input->post('y1');
		$x2	= $this->input->post('x2');
		$y2	= $this->input->post('y2');
		$w	= $this->input->post('w');
		$h	= $this->input->post('h');
		$thumbImagePath	= $this->input->post('thumbImagePath');
	
		// Get the FileName info
		$arrFileInfo	= pathinfo($thumbImagePath);
	
		// Filename without Extension
		$fileName	= $arrFileInfo['filename'];
		$fileExtn	= $arrFileInfo['extension'];
	
		/** As of now we don't need this code **/
		$maxSmallImageWidth	= 100;
	
		// Calculate the SCaling Factor
		$scale	= $maxSmallImageWidth/$w;
	
		// Get the existing Image Dimension of the Medium Sized image
		list($imageWidth, $imageHeight, $imageType) = getimagesize($thumbImagePath);
	
		$newImageWidth	= ceil($w * $scale);
		$newImageHeight	= ceil($h * $scale);
		/** End of Unwanted Code **/
	
		$this->load->library('ColinUpload');
	
		// Create the absolute path of the local file system
		$docRoot	= $_SERVER['DOCUMENT_ROOT'];
		$absFilePath	= $docRoot.'/'.$this->config->item('app_folder_path').'images/organization_images/medium/'.$fileName.'.'.$fileExtn;
		$orgLogo = new ColinUpload($absFilePath);
		$newFileName	= $orgLogo->file_src_name_body;
	
		$orgLogo->file_new_name_body = $newFileName;
	
		// Resize the image to Medium Size and save
		$orgLogo->file_new_name_body = $newFileName;
		$orgLogo->image_resize = true;
		// For Colin Upload
		// My Observation - Top, Right , Bottom , Left (As seen with Crop dimension from Office Pict)
		$right 	= $imageWidth - $x1 - $w;
		$left 	= $x1;
		$top	= $y1;
		$bottom	= $imageHeight - $y1 - $h;
		//- End of Observation
	
		$orgLogo->image_precrop		= array($top, $right, $bottom, $left);
		$orgLogo->image_x = 100;
		$orgLogo->image_ratio_y = true;
	
		$orgLogo->Process('images/organization_images/resized');
		if ($orgLogo->processed) {
			//echo 'Image Resized';
			//$orgLogo->Clean();
				
			// Save the Image Path into the database
			$this->organization->db->where('id', $this->session->userdata('organizationId'));
				
			$data['company_logo']	= $orgLogo->file_dst_name_body . '.' . $orgLogo->file_src_name_ext;
			$this->organization->db->update('organizations', $data);
				
		} else {
			log_message('error', 'Error while uploading the image'. $orgLogo->error);
		}
	
		// Redirect to the organization Profile
		redirect(base_url().'organizations/add_organization/'.$this->session->userdata('organizationId'));
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_organization()
	 * @Param  : $_POST
	 * @return : json data : $arrResult
	 */
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update_organization()
	 * @Param  : $_POST
	 * @return : json data : $arrResult
	 */
	function update_organization(){
		if(isset($_POST) && count($_POST)>0){
			// Getting the POST details of Organization
			$form_type = $this->input->post('form_type');
			switch ($form_type){
				case 'form_org_info':
					$organizationDetails = array(
							'id' 				=> 	$this->input->post('org_id'),
							'name' 				=> 	ucwords(trim($this->input->post('name'))),
							'type_id'			=> 	$this->input->post('type_id'),
							'website'			=> 	$this->input->post('website'),
							'founded'			=> 	trim($this->input->post('founded')),
							'background'		=>	$this->input->post('background'),
							'products_services'	=> 	$this->input->post('products_services'),
							'mission_vision' 	=> 	$this->input->post('mission_vision'),
							'headquarters'	 	=> 	ucwords(trim($this->input->post('headquarters'))),
							'modified_by'		=>	$this->loggedUserId,
							'modified_on'		=>	date('Y-m-d H:i:s'),
							'profile_type'		=>	$this->input->post('profile_type')
					);
					break;
				case 'form_org_address':
					$organizationDetails = array(
							'id' 				=> 	$this->input->post('org_id'),
							'address'	 		=> 	$this->input->post('address'),
							'phone'	 			=> 	$this->input->post('orgphone'),
							'fax'	 			=> 	$this->input->post('fax'),
							'country_id'	 	=> 	$this->input->post('country_id'),
							'state_id' 			=> 	$this->input->post('state_id'),
							'city_id'	 		=> 	$this->input->post('city_id'),
							'postal_code'	 	=> 	$this->input->post('postal_code'),
							'modified_by'		=>	$this->loggedUserId,
							'modified_on'		=>	date('Y-m-d H:i:s')
					);
					break;
				case 'form_org_social':
					$organizationDetails = array(
							'id' 				=> 	$this->input->post('org_id'),
							'blog'	 			=> 	$this->input->post('blog'),
							'facebook'	 		=> 	$this->input->post('facebook'),
							'twitter'	 		=> 	$this->input->post('twitter'),
							'youtube'	 		=> 	$this->input->post('youtube'),
							'linkedin'	 		=> 	$this->input->post('linkedin'),
							'modified_by'		=>	$this->loggedUserId,
							'modified_on'		=>	date('Y-m-d H:i:s')
					);
					break;
				default:	
					$organizationDetails = array();
					break;
			}				
			$returnValue = $this->organization->updateOrganization($organizationDetails);
			if($this->organization->updateOrganization($organizationDetails)){
				$arrResult['saved']			= true;
				$arrResult['lastInsertId']	= $organizationDetails['id'];
				$arrResult['data']			= $organizationDetails;
				//	$this->session->set_userdata('organizationId', $lastInsertId);
			}else{
				$arrResult['saved']			= false;
			}
				
			echo json_encode($arrResult);
	
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : list_key_peoples_analyst()
	 * @Param  : $orgId
	 * @return : json data to grid
	 */
	function list_key_peoples_analyst($orgId=null){
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$arrKeyPeople			=	array();
		$data['arrKeyPeople']	=	$arrKeyPeople;
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
	
		$arrAssociltedPeople = array();
		$arrDetails = array();
		if($arrKeyPeople =  $this->organization->listKeyPeoples($this->session->userdata('organizationId'))){
			$count	=	sizeof($arrKeyPeople);
			if( $count >0 ) {
				$total_pages = ceil($count/$limit);
			} else {
				$total_pages = 0;
			}
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$arrKeyPeople;
		}
		echo json_encode($data);
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : save_key_people()
	 * @Param  : $_POST
	 * @return : json data : $arrResult
	 */
	function save_key_people(){
		if(isset($_POST) && count($_POST)>0){
			$dataType = 'User Added';
			$client_id =$this->session->userdata('client_id');
			if($client_id == INTERNAL_CLIENT_ID){
				$dataType = 'Aissel Analyst';
			}
			// Getting the POST details of Organization
			$keyPeopleDetails = array(		
					'id'				=> 	$this->input->post('id'),
					'org_id' 			=> 	$this->input->post('org_id'),
					'role_id' 			=> 	$this->input->post('role_id'),
					'salutation'		=> 	$this->input->post('salutation'),
					'first_name'		=> 	ucwords(trim($this->input->post('first_name'))),
					'middle_name'		=> 	ucwords(trim($this->input->post('middle_name'))),
					'last_name'			=>	ucwords(trim($this->input->post('last_name'))),
					'title' 			=> 	ucwords(trim($this->input->post('title'))),
					'email'	 			=> 	trim($this->input->post('email')),
					'department'	 	=> 	trim($this->input->post('department')),
					'created_by'		=>	$this->loggedUserId,
					'created_on'		=>	date('Y-m-d H:i:s'),
					'data_type_indicator' => $dataType
			);
	
	
			// Create an array to return the result
				
			$arrResult = array();
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
				
			if($lastInsertId = $this->organization->saveKeyPeople($keyPeopleDetails)){
				$arrResult['saved']				= true;
				$arrResult['lastInsertId']		= $lastInsertId;
				if($keyPeopleDetails['salutation'] !=''){
					$keyPeopleDetails['salutation']	= $arrSalutations[$keyPeopleDetails['salutation']];
				}
				$keyPeopleDetails['role_id']	= $this->organization->getKeyPeopleRoleNameById($keyPeopleDetails['role_id']);
				$keyPeopleDetails['kol_name']   = $keyPeopleDetails['first_name']." ".$keyPeopleDetails['middle_name']." ".$keyPeopleDetails['last_name'];
				$arrResult['data']				= $keyPeopleDetails;
	
			}else{
				$arrResult['saved']				= false;
			}
			echo json_encode($arrResult);
		}
	}
	
}
