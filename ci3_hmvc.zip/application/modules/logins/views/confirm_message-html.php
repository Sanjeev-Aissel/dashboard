<html>
<head>
<style>
table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
td { background: #FAFAFA; text-align: left; border: 0px;}
</style>
</head>
	<body>
		<div>
			Hi <?php echo $fullName;?>,<br><br>
			<table>
				<tr><td>The password on your <?php echo PRODUCT_VERSION;?> Application account has been successfully changed.</td></tr>
				<tr><td><br>If you feel this is an error, please contact us at support@aissel.com.</td></tr>
			</table>
			<br>Regards,<br><?php echo PRODUCT_VERSION;?> Support<br>
		</div>
	</body>
</html>