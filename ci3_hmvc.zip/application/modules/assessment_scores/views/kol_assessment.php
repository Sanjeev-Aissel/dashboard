<style>
#assessmentRating .evenRow {
    background-color: #F5F5F5;
}
.oddRow {
    background-color: #eee;
}
</style>

<div class="table-responsive" id="assessmentRating">          
  <table class="table no_border">
    <thead>
      <tr>
        <th>Category</th>
        <th>Criteria</th>
        <th>Rating</th>
      </tr>
    </thead>
    <tbody>
    <form id="kol_assessment_form">
    <input type="hidden" name="kol_id" value="<?php echo $kol_id;?>">
	<?php $altBgColorFlag	= 0;
		foreach($arrAsmtRatings as $categoryName=>$arrCriteria){
			$displayCatName	= 1;
			
			foreach($arrCriteria as $criteriaName=>$arrRatings){
				if($displayCatName){
					if($altBgColorFlag){
						$alternateBgColor	= 'evenRow';
						$altBgColorFlag		= 0;
					}else{
						$alternateBgColor	= 'oddRow';
						$altBgColorFlag		= 1;
					}
				}?>
					<tr class="<?php echo $alternateBgColor;?>">
						<td>
							<?php if($displayCatName){
										echo "<strong>".$categoryName."</strong>";
										$displayCatName	= 0;
									}
							?>
						</td>
						<td style="border-bottom:1px solid #fff;">
							<?php echo $criteriaName;?>
						</td>
						<td style="border-bottom:1px solid #fff;">
							<select name="<?php echo $arrRatings[0]['category_id'].'_'.$arrRatings[0]['criteria_id'];?>">
								<option value="">Select Rating</option>							
							<?php foreach($arrRatings as $key=>$row){
									$selectedValue	= '';
									if(isset($arrCriteriaRating[$row['criteria_id']]) && $arrCriteriaRating[$row['criteria_id']]==$row['rating_id']){
										$selectedValue	= ' selected="selected"';
									}
									echo '<option value="'.$row['rating_id'].'"'.$selectedValue.'>'.$row['rating'].'</option>';
								}
							?>
							</select>
						</td>
					</tr>
	<?php }
		}?>
		</form>
    </tbody>
  </table>
  </div>
  <div class="row align_center">
    <a type="button" class="btn custom-btn requestProfileIcon" onclick="validateAsmtRating();return false;" title="Save Ratings">
	Save
	</a>
  </div>
	
	
<script type="text/javascript">
function validateAsmtRating() {
    var doSubmitForm = true;
    $('#assessmentRating select').each(function (index) {
        var value = $(this).attr('value');
        if (value == "") {
            $(this).parent().parent().css('color', 'red');
            $(this).css('border-color', 'red');
            doSubmitForm = false;
        }else{
            $(this).parent().parent().css('color','');
            $(this).css('border-color','');
        }
    });
    if (doSubmitForm){
	  	$.ajax({
			type:'POST',
			url:base_url+'assessment_scores/assessment_scores/save_kol_ratings',
			dataType:'json',
			data:$("#kol_assessment_form").serialize(),
					success:function(respData){
			},
			error:function()
			{
			}
		});
    }
}
</script>
	
	
	
	
	