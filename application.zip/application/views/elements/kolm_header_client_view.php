<?php
/**
 * Common headers for Kol Analyst application. 
 *
 * @author: Ambarish N
 * @created on: 01-02-11
 */

//With Trailing slashes
$userName	= $this->session->userdata('user_full_name');
$userMailId = $this->session->userdata('email');
$userPhoto	= $this->session->userdata('mem_pic');
// $companyName= $this->session->userdata('company_name');
$userTitle	= $this->session->userdata('title');
$mirfWithin=0;
$link = $_SERVER['HTTP_REFERER'];
    $link_array = explode('/',$link);
     $page = end($link_array);
     if($page=="interaction_report")
         $mirfWithin=1;
//     echo $mirfWithin;
    
//- End of FreshDesk SSO Section
//$host = substr($this->config->item("host"), 0, -1);
//$currenrURL	= $host.$_SERVER['REQUEST_URI'];
//$currenrURL	= $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$currenrURL	= base_url().$this->uri->segment(1).'/'.$this->uri->segment(2);
//echo $currenrURL.'<br />';
//echo $host.'/'.$this->uri->segment(1).'/'.$this->uri->segment(2);
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('elements/kolm_header_client_view');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style type="text/css">
.secondaryNavWrapper li a.geographicalLink{
	width:110px;
}
.ui-widget-header {
	background:none;
}
#settingstab ul:hover{
/*	background:#E1E1E1; */
}
ul:hover.Settingsoptions {
	background:#EEEEEE !important;
}
#settingstab ul{
/*	background: none repeat scroll 0 0 #EEEEEE;*/
    list-style: none outside none;
    margin-bottom: 2px;
    margin-right: 0;
    padding-bottom: 4px;
    padding-left: 0;
    padding-top: 3px;
    text-align: center;
    width: 120px;
    width:150px;
}
#settingstab ul li ul{
	margin:0px;
	padding: 0 0 0 0;
}
#settingstab ul li a{
	text-decoration: none !important;
	color:gray;
}
#settingstab ul li a:hover{
	text-decoration: none !important;
	color:#3F7DB2;
}
#Settingsoptions{
	position: absolute;
	border-top: 1px solid;
	text-align: left !important;
}
#searchBoxWrapper input[type="text"], .advSearchWrapper{
	background: none;
}
#settingstab .navPrimSeparator{
	height: 12px;
    margin-top: 3px;
}

#header .nav-box ul li a {
    border-left: 1px solid #FFFFFF;
    border-right: 1px solid #999999;
    height: 32px;
    line-height: 28px;
    padding: 0 10px 0 5px;
    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms";
    font-family: "Droid Sans",tahoma,arial,"Trebuchet Ms";
    font-weight: bold;
   /* font-size:14px;*/
}
#header .nav-box ul li a:hover{
	/*color:#2f86be;*/
	color: #2b9af3;
}
#loginBox{
	position: absolute;
	display: none;
	right:0px;
	top: 28px;
	background: -moz-linear-gradient(center top , rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.05) 20%, rgba(0, 0, 0, 0.05) 100%) repeat scroll 0 0 transparent;
	border-top: 1px solid #CCCCCC;
	width:200px;
	width:300px;
	background-color:#fff;
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
	z-index:1003;
	border: 1px solid #AAAAAA;
	border-radius:2px;
	-webkit-border-radius: 2px;
	-moz-border-radius: 2px;
}
#loginBox #loginForm {
	margin: 0; 
	padding: 0; 
	width:auto; 
	border:0px;
}
.headerTopSectionWrapper #userSettingWrapper ul {
    float: right;
    list-style-type: none;
    margin: 0 0 10px;
    padding:10px 0;
    padding:0;
    width:100%;
}
.headerTopSectionWrapper #userSettingWrapper ul li{
	/*padding-left:10px;
	padding-top:2px;
	padding-bottom:2px;*/
	border-bottom: 1px inset #AAAAAA;
    padding: 6px 6px 6px 15px;
}
.headerTopSectionWrapper #userSettingWrapper ul li.noBorder{
	border-bottom: 1px inset #fff;
}
.headerTopSectionWrapper #userSettingWrapper ul li:hover{
	/*background-color:#E1E8F3;*/
	background: #f1f1f1 none repeat scroll 0 0;
    /*border: 0 none;*/
    /*box-shadow: 0 1px 2px 1px #cccccc inset;*/
}
.headerTopSectionWrapper #userSettingWrapper ul li a{
    text-decoration: none;
    display:block;
    padding-left:40px;
    color: #333333;
}
.headerTopSectionWrapper #userSettingWrapper ul li div.actionIcon{
	margin-right:5px;
	float:left;
}
#headerTopSection .arrowUp {
    height: 15px;
    margin-top: -15px;
    position: absolute;
    right: -4px;
    top: 0;
    width: 35px;
}
.userSettings {
    /*background: url("<?php echo base_url();?>images/gearicon.png") repeat scroll 0 -2px transparent;*/
    background: url("<?php echo base_url();?>images/settings_inactve.svg") no-repeat scroll 0 0 / 20px auto;
    
}
.userSettings:hover{
    /*background: url("<?php echo base_url();?>images/gearicon0.png") repeat scroll 0 -2px transparent;*/
    background: url("<?php echo base_url();?>images/settings_actve.svg") no-repeat scroll 0 0 / 20px auto;
}
.userSettings.active {
    /*background: url("<?php echo base_url();?>images/gearicon.png") repeat scroll 0 -2px transparent;*/
    background: url("<?php echo base_url();?>images/settings_actve.svg") no-repeat scroll 0 0 / 20px auto;
    
}
.medIntel{
	background: url("<?php echo base_url();?>images/media_menu.svg") no-repeat scroll 2px 0px transparent;
	margin-top: 7px;
}
.dropdown{
    /*background: url("<?php echo base_url();?>images/chosen-sprite.png") repeat scroll 0 2px transparent;*/
    background: url("<?php echo base_url();?>images/more_inactive.svg") no-repeat scroll 0 0px transparent !important;
    /*cursor: pointer;
    float: right;
    height: 20px;
    margin-left: 5px;
    margin-right: 0px;
    width: 20px;*/
    margin-left: 0px !important;
}
.activeIcon.dropdown{
    /*background: url("<?php echo base_url();?>images/chosen-sprite.png") repeat scroll 0 2px transparent;*/
    background: url("<?php echo base_url();?>images/more_active.svg") no-repeat scroll 0 0px transparent !important;
    /*cursor: pointer;
    float: right;
    height: 20px;
    margin-left: 5px;
    margin-right: 0px;
    width: 20px;*/
    margin-left: 0px !important;
}
.dropdown.up{
  /* background: url("<?php echo base_url();?>images/chosen-sprite.png") repeat scroll -17px 4px transparent;*/
}
#moreLinks{
	padding-left:10px !important;
}
#moreLinksContainer{
    margin-top: 34px;
    position: absolute;
    z-index: 1002;
    background-color: #fff;
    border: 0px solid #999;
    border-top: 0px;
    width: 178px; 
    left: -98px;
}
#moreLinksContainer ul li{
	/*
	clear: both;
	width: 100%;
	margin-right:8px;
	background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
	background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
	background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
	background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
	background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
	background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
	*/
	background: #f1f1f1 none repeat scroll 0 0;
    /*box-shadow: 0 1px 2px 1px #cccccc inset;*/
    clear: both;
    margin-right: 8px;
    width: 100%;
    border-left: 1px solid #cccccc !important;
    border-bottom: 1px solid #cccccc;
    border-right: 1px solid #cccccc;
}
#moreLinksContainer ul li .kolRequestIcon{
	margin-top: 3px;
}
#moreLinksContainer ul li .orgRequestIcon{
	margin-top: 3px;
}
#moreLinksContainer ul li a{
/*	width:139px;*/
	border: 0px !important;
    font-family: "Droid Sans",tahoma,arial,"Trebuchet Ms";
    font-weight: bold;
    height: 30px;
    line-height: 28px;
    padding: 0px !important;
    width: 100%;
    /*border-top: 1px solid #FFFFFF !important;*/
    /*border-bottom: 1px solid #999999 !important;*/
}
#moreLinksContainer ul li a:hover{
   /*padding: 0px !important;
   margin-top:0px !important;*/
   /*border-top: 1px solid #FFFFFF !important;*/
   /*border-bottom: 1px solid #999999 !important;*/
}
#moreLinksContainer ul{
	position: absolute;
    right: 1px;
    /*background: -moz-linear-gradient(center top , #FFFFFF 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;*/
    /*border-bottom: 0px solid #BCBCBC;
    border-right: 1px solid #CCCCCC;
    border-left: 1px solid #CCCCCC;
    border-top: 0px solid #CCCCCC;
    box-shadow: 0 2px 1px 1px #FFFFFF inset;*/
    
}
.question{
	background-position: 57% 35%;
	float: left;
    margin-left: -1px;
    margin-right: 0;
    margin-top: -1px;
    width: 22px;
}
.passwordChange{
	background: url("<?php echo base_url();?>images/change_password.png") no-repeat scroll 2px 0px transparent;
	float: left;
    margin-left: 0px;
    margin-right: 0;
    margin-top: 0px;
    width: 22px;
}
#moreLinksContainer{
	display: none;
}
#moreLinksContainer.displayMenus{
	display: block !important;
}
#moreButton{
	position: relative;
}
.recentActivity{
	/*background: url("<?php echo base_url();?>images/recent_activity.png") no-repeat scroll 2px 0px transparent;
	margin-top: 7px;*/
	background: url("<?php echo base_url();?>images/recent_activity_inactive.svg") no-repeat scroll -1px 0px transparent;
}
.activeIcon.recentActivity{
	/*background: url("<?php echo base_url();?>images/recent_activity.png") no-repeat scroll 2px 0px transparent;
	margin-top: 7px;*/
	background: url("<?php echo base_url();?>images/recent_activity_active.svg") no-repeat scroll -1px 0px transparent;
}

.notifications{
	background: url("<?php echo base_url();?>images/notification_inactive.svg") no-repeat scroll -1px 0px transparent;
}
.activeIcon.notifications{
	background: url("<?php echo base_url();?>images/notification_blue.svg") no-repeat scroll -1px 0px transparent;
}

#moreButton ul li:FIRST-CHILD {
	/*border-top: 1px solid #999999;*/
}
.userProfilePhoto{
	border-radius:25px;
	-webkit-border-radius: 25px;
	-moz-border-radius: 25px;
	float: left;
	margin-right: 10px;
	width: 45px;
}
#userProfileInfoWrapper{
	height: 45px;
	margin-top: 2px;
    padding: 5px;
}

#notiticationsSection{
	background: url("<?php echo base_url();?>images/notification.png") no-repeat;
	bottom: -28px;
    left: -33px;
    position: absolute;
	/*border-image: none;
    border-style: none solid solid;
    border-width: 0 1px 1px;
    color: white;
    cursor: pointer;
    font-weight: bold;
    left: -161px;
    margin-top: -2px;
    padding: 4px 10px 2px;
    position: absolute;
    border: 0 1px 1px #bbbbbb;
    background: #4D7BD6;
	background: -moz-linear-gradient(top,#5689DB 0%,#4D7BD6 100%);
	background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#5689DB),color-stop(100%,#4D7BD6));
	background: -webkit-linear-gradient(top,#5689DB 0%,#4D7BD6 100%);
	background: -o-linear-gradient(top,#5689DB 0%,#4D7BD6 100%);
	background: -ms-linear-gradient(top,#5689DB 0%,#4D7BD6 100%);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#5689db,endColorstr=#4d7bd6,GradientType=0);
	background: linear-gradient(top,#5689DB 0%,#4D7BD6 100%);*/
}
#add-notification{
	background: transparent url("<?php echo base_url();?>images/all_icons.png") repeat scroll 24% 36%;
    display: inline-block;
    height: 20px;
    vertical-align: middle;
    width: 20px;
    cursor: pointer;
}
#icon-notification{
	/*background-image: url("<?php echo base_url();?>images/notification_warning.png");*/
    background-repeat: no-repeat;
    background-size: 84% auto;
    color: #ffffff !important;
    cursor: pointer;
    display: inline-block;
    height: 40px;
    margin-top: -8px;
    vertical-align: middle;
    width: 34px;
}
#notificationCount{
	background: #ff0000 none repeat scroll 0 0;
    border: 3px solid #ffffff;
    border-radius: 12px;
    color: #ffffff;
    left: 13px;
    min-height: 14px;
    min-width: 14px;
    padding: 0 2px 1px;
    position: absolute;
    text-align: center;
    top: -11px;
    vertical-align: middle;
    cursor: pointer;
}
</style>
<script type="text/javascript">
	//Global declaration specifically for survey autocomplete search .
	var country_name;
	var state_name;
	var city_name;
	var postal_code;
	
	/*
	* To open the modal box to add feedback
	* @author Vinayak
	* @since 2.0
	* @created on 22-Aug-2012
	*/
	//This function acts on displaying setting options.
	$(function() {
	    var button = $('#settingOptions');
	    var box = $('#loginBox');
	    var form = $('#loginForm');
	    button.removeAttr('href');
	    button.mouseup(function(login) {
	        box.toggle();
	        button.toggleClass('active');
	    });
	    form.mouseup(function() { 
	        return false;
	    });
	    $(this).mouseup(function(login) {
	        if(!($(login.target).parent('#settingOptions').length > 0)) {
	            button.removeClass('active');
	            box.hide();
	        }
	    });
	});

	/*
	* To open the modal box to add new category 
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function addFeedback(){	
                $("#feedbackDialogContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#feedbackDialogContainer").dialog("open");
		$("#feedbackDialogContent").load(base_url+'feedbacks/add_feedback');
		return false;	
	}
	var tabname="";
	function showMessaage(tab){
		
		tabname =tab;
		
		$("#messageDialogContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#messageDialogContainer").dialog("open");
		$("#messageDialogContent").load(base_url+'client_users/show_message_view');
		return false;	

	}

	function showAlertMessage(){
		$("#messageDialogContainer").dialog("close");
		//alert(tabname);
	//return false;
		var data ={};
		data['tabname'] = tabname;
		data['demo'] ='Yes';
		$.ajax({
				url:base_url+'client_users/send_demo_mail',
				type:'post',
				dataType:'json',
				data:data,
				success:function(){
				}

			});
		//alert("Thank you for your interest. We will get in touch with you shortly to set up a demo.");
			$("#messageDialogContent").html("<div class='microViewLoading'>Loading...</div>");
		$(".ui-dialog").animate({width:"490px",duration: 0});

		$("#messageDialogContainer").dialog("open");
		$('.microView .ui-dialog-content').css('min-height','70px !important');
		$("#messageDialogContent").html('<div class="alertContent"><p><b>Thank you for your interest. We will get in touch with you shortly to set up a demo.<b><p></div><div class="buttonContent"><button onclick="closeDialogeBox()"> Ok</button></div>');
		
	}

	function closeDialogeBox(){
		$("#messageDialogContainer").dialog("close");
		var data ={};
		data['tabname'] = tabname;
		data['demo'] ='No';
		$.ajax({
				url:base_url+'client_users/send_demo_mail',
				type:'post',
				dataType:'json',
				data:data,
				success:function(){
				}

			});
	}
	
    function addNotification() {
		$("#notificationDialogContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#notificationDialogContainer").dialog("open");
		$("#notificationDialogContent").load(base_url+'notifications/add_notification');
		return false;
    }
                
        function listNotifications() {
		$("#notificationDialogContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#notificationDialogContainer").dialog("open");
		$("#notificationDialogContent").load(base_url+'notifications/list_user_notifications');
		return false;
        }
        
        function closeNotification() {
            $("#notificationDialogContainer").dialog("close");
        }

	function changePassword(){
		$("#changePasswordContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#changePasswordContainer").dialog("open");
		$("#passwordContent").load('<?php echo base_url().'client_users/change_password/'?>');
		//	$("#advSearchAddProfileContent").load(formAction);
		return false;	
	}
	function showmorelinks(){
	//	$('#moreLinksContainer').toggle();
		$('#moreLinksContainer').toggleClass('displayMenus');
		$('#moreLinks').toggleClass('current');
		$('#moreLinks div.dropdown').toggleClass('up');
	}
	
	$(document).ready(function(){
		// Settings for the password  Dialog Box
//		$("#moreButton ul li").eq(0).css('border-top','1px solid #999999');
		var curContr = "<?php echo $this->uri->segment(1);?>";
		var curContrMethod = "<?php echo $this->uri->segment(2);?>";
		//var curController = $(location).attr('href');
		var curController = "<?php echo $currenrURL;?>";
                
                
		var curUrl;
               
		var swapCurrContent = $("#swap_menu").html();
		$.each($("#moreButton ul li"),function(key,value){
			curUrl = $(this).children('a').attr("href");
			if(curController == curUrl || ((curContr == 'requested_kols') && curContrMethod!='show_non_profiled_kols')){
				$.each($(".nav-box ul li"),function(){
					var a = $(this).find('a').removeClass('current');
					});
				$(this).find('a').addClass('current');
				$(this).replaceWith(swapCurrContent);
				$("#swap_menu li a").replaceWith($(this).html());
				return false;						
			}
		});
		
		$("#moreButton").mouseover(function(){
			$('#moreLinksContainer').toggleClass('displayMenus');
			$('#moreLinks').toggleClass('current');
			$('#moreLinks div.dropdown').toggleClass('up');
		});
		$("#moreButton").mouseout(function(){
			$('#moreLinksContainer').toggleClass('displayMenus');
			$('#moreLinks').toggleClass('current');
			$('#moreLinks div.dropdown').toggleClass('up');
		});
		var passwordOpts = {
				title: "PASSWORD",
				modal: true,
				autoOpen: false,
				width: 500,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		var feedbackAddOpts = {
				title: "Add Feedback",
				modal: true,
				autoOpen: false,
				width: 570,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
                var notificationAddOpts = {
				title: "Add Notification",
				modal: true,
				autoOpen: false,
				width: 570,
                                height: 450,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
                };
                var notificationListOpts = {
				title: "List Notifications",
				modal: true,
				autoOpen: false,
				width: 570,
                height: 'auto',
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
                };
                var message = {
        				title: "",
        				modal: true,
        				autoOpen: false,
        				width: 440,
        				dialogClass: "microView",
        				position: ['center', modalBoxTopPosition],
        				open: function() {
        					//display correct dialog content
        				}
        		};        
		$("#notificationDialogContainer").dialog(notificationAddOpts);
		$("#notificationListDialogContainer").dialog(notificationListOpts);
		$("#feedbackDialogContainer").dialog(feedbackAddOpts);
		$("#changePasswordContainer").dialog(passwordOpts);
		$("#messageDialogContainer").dialog(message);

		$("#header .nav-box ul a.current").find('.sprite_iconSet').addClass('activeIcon');
		$("#header .nav-box ul a.first-current").find('.sprite_iconSet').addClass('activeIcon');
		
		$("#header .nav-box ul a").mouseover(function(){
				$(this).find('.sprite_iconSet').addClass('activeIcon');
		});
		$("#header .nav-box ul a").mouseout(function(){
			if(!$(this).hasClass('current') || $(this).hasClass('last')){
				$(this).find('.sprite_iconSet').removeClass('activeIcon');
			}
		});

		$("#moreLinksContainer ul li").mouseover(function(){
			$(".dropdown").addClass("activeIcon");
		});
		$("#moreLinksContainer ul li").mouseout(function(){
			$(".dropdown").removeClass("activeIcon");
		});
		
		$(document).on('mouseover', 'a.NewBlueButton', function(e) {
			$(this).addClass('activeIcon');
		});
		$(document).on('mouseout', 'a.NewBlueButton', function(e) {
			$(this).removeClass('activeIcon');
		});
		
		$(document).on('mouseover', '.exportOptionsContainer div.sprite_iconSet', function(e) {
			$(this).addClass('activeIcon');
		});
		$(document).on('mouseout', '.exportOptionsContainer div.sprite_iconSet', function(e) {
			if(!$(this).hasClass('current') || $(this).hasClass('last'))
				$(this).removeClass('activeIcon');
		});
		
	});
</script>

	<!-- Start of Header Div -->
	<div id="header" class="span-24">
		<div class="headerTopSectionWrapper last">
		<div id="headerTopSection" class="ui-tabs tooltip-demo tooltop-bottom">
			<div id="settingstab">
				<?php   
					$ciInst =& get_instance();
					$ciInst->load->model('notification');
					$notifications = $ciInst->notification->getUserNotifications($ciInst->session->userdata('user_id'),"notSeen");?>
				<!--<div class="logout sprite_iconSet"><a rel='tooltip' title="Logout" href="<?php echo base_url()?>login/logout">&nbsp;</a></div>
				<div class="navPrimSeparator"></div>
					-->
                                        <div id="notiticationsSection" style="<?php if(count($notifications) == 0) echo "display:none;";?>" onclick="listNotifications();">
                                        	<span id="icon-notification" class="actionIcon addIcon"><span></span></span>
<!--                                            <a style="color: white;text-decoration: none;" id="list-notification">Notifications</a>-->
                                            <span id='notificationCount'><?php echo count($notifications);?></span>
                                        </div>
                                        <div id="settingOptions" class="userSettings sprite_iconSet tooltip-demo tooltop-left">
						<a rel='tooltip' title="Options" href="" onclick="return false;">&nbsp;</a>
					</div>
<!--				<div class="navPrimSeparator"></div>-->
				<div style="float: right; margin-right: 8px; font-weight: bold; color: #333333;"><?php echo $userName;?>
					<div class="userIcon sprite_iconSet"></div> 
<!--					| <span onclick="hintcategories()" style="color:#00f;cursor: pointer;">Show me how</span>-->
				</div>
			</div>
			<!-- Setting Options drop down Starts Here -->
			<div id="loginBox">                
            	<div class="arrowMarkIcon arrowUp"></div>
            	<div id="loginForm">
                    <div id="userSettingWrapper">
						<ul class="userSettingOptionsContainer">
							<li>
		                    	<div id="userProfileInfoWrapper"><?php 
									if(!empty($userPhoto)){
										echo '<img class="userProfilePhoto" alt="Profile Photo" src="'.base_url().'images/user_profile_images/'.$userPhoto.'" />';
									}else{
										echo '<img class="userProfilePhoto" alt="Profile Photo" src="'.base_url().'images/ipad/user.svg" />';
									}
									echo '<a href="'.base_url().'user_settings"><div><span style="font-weight: bold;">'.$userName.'</span><br />'.$userTitle.'</div></a>';
								?></div>
							</li>
				  			<li class=""><div class="SettingsActionIcon"><img width="18px" height="18px" alt="Feedback" src="<?php echo base_url();?>images/submit_ticket_active.svg" /></div><a href="" onclick="addFeedback();return false;">&nbsp;Submit a ticket</a></li>
							<!--<li><div class="actionIcon"><img width="21px" alt="Help" src="<?php echo base_url();?>images/question_mark.png" /></div><a href="http://aisselkolm.helpdocsonline.com" target="_new">&nbsp;Help</a></li>-->
							<li><div class="question sprite_iconSet"></div><a href="<?php echo getSSOUrl($userName, $userMailId);?>" target="_blank" >&nbsp;Help Documentation</a></li>
							<!--<li><div class="typeDropDownActive sprite_iconSet" style="float: left; width: 21px; margin-right: 1px; margin-left: 0px; margin-top: 2px;"></div><a href="javascript:void(0)" class="activechat">&nbsp;Live Support</a></li>-->
							<li><div class="settings sprite_iconSet" style="float: left; width: 21px; margin-right: 1px; margin-left: 0px; margin-top: 2px;"></div><a href="<?php echo base_url();?>user_settings">&nbsp;Settings</a></li>
							<li><div class="logout sprite_iconSet" style="float: left; margin-top: 0px; width: 21px; margin-left: 0px; margin-right: 1px;"></div><a href="<?php echo base_url();?>login/logout">&nbsp;Logout</a></li>
						</ul>
					</div>
				</div>
			</div>
            <!-- Setting Options drop down Ends Here -->
		</div>
		</div>
		<?php 
			$clientId = $this->session->userdata('client_id');
			if($clientId !== INTERNAL_CLIENT_ID){
				$arrClientResults = $this->common_helpers->getClientLogo($clientId);
				$clientLogoName = $arrClientResults[0]['client_logo'];
				if($clientLogoName != ''){
					echo '<div id="client_logo_holder" class="span-3">';
					echo '<img src="'.base_url().'images/client_logos/logos/'.$clientLogoName.'"/>';
					echo '</div>';
				}else{
					echo '<div id="logo" class="span-3"></div>';
				}
				
			}else{
				echo '<div id="logo" class="span-3"></div>';
			}
		?>
			<div id="searchBoxWrapper" class="prepend-10 last"><?php $this->load->view('search/search_box',array('searchDockType'=>'headerDock'));?></div>		

		<?php 
			// Get the URI segment. Helps in setting the link as 'ACTIVE'
			$currentController	= $this->uri->segment(1);
			$currentMethod		= $this->uri->segment(2);
			$param				= $this->uri->segment(3);
			$param1				= $this->uri->segment(4);
			
			//Conditions data for Role based user
			$userRoleId 		=	$this->session->userdata('user_role_id');
			$clientId = $this->session->userdata('client_id');
			$campaneid = GUEST_CLIENT_ID;
		?>
		
		<!-- Start of Primary Navigation -->
 		<div class="nav-box clear">
					<ul>
					
					<?php if($clientId==$campaneid){?>
						<li>
							<a href="<?php echo base_url();?>kols/list_kols_client_view" 
							<?php if(($currentController == 'kols' && $currentMethod=='adv_search') || (($currentController == 'kols') && ($currentMethod != 'client_index'))
                                                                        || ($currentController == 'interactions' && ($currentMethod != 'list_interactions' && $currentMethod != 'view_numeric_report' && $currentMethod != 'add_mirf' && $currentMethod != 'view_mirf' && $currentMethod !='view_drilldown_list'))
                                                                        ||
									$currentController == 'clinical_trials' || $currentController == 'pubmeds' || ($currentController=='requested_kols') && $currentMethod == 'show_non_profiled_kols' || ($mirfWithin==1 && $currentMethod == 'add_mirf')  || ($mirfWithin==1 && $currentMethod == 'view_mirf') || ($currentController=='payments'))  echo 'class="current"';?>> 
									<div class="navLinkMyKols sprite_iconSet"></div><?php echo lang('MyKols')?>
							</a>
						</li>
						<?php $mobile = mobile_device_detect(); 
							if(!isset($mobile[1])) {?>
								<li>
									<a href="<?php echo base_url();?>maps/view_influence_map" 
										<?php if($currentController == 'maps') echo 'class="current"';?> id="topMenuMap"> 
										<div class="navLinkMaps sprite_iconSet"></div><?php echo lang('NetworkMaps')?>
									</a>
								</li>
						<?php } else {?>
								<li>
									<a href="<?php echo base_url();?>maps/view_influence_map" 
										<?php if($currentController == 'maps') echo 'class="current"';?> id="topMenuMap"> 
										<div class="navLinkMaps sprite_iconSet"></div><?php echo lang('NetworkMaps')?>
									</a>
								</li>
						<?php }?>
						<li>
                          <a  href="#" onclick="showMessaage('Identifications')"
								<?php if(($currentController == 'identifications')) echo 'class="current"';?>>
								<div class="navLinkIdentify sprite_iconSet"></div><?php echo lang('IdReport')?>
							</a>
						</li>
						<?php if(!HIDE_ORGANIZATION){?>
						<li>
							<a  href="#" onclick="showMessaage('Organizations')"
								<?php if($currentController == 'organizations' || $currentController == 'requested_orgs') echo 'class="current"';?> id="topMenuOrg"> 
								<div class="navLinkOrgs sprite_iconSet"></div><?php echo lang('Organizations')?>
							</a>
						</li>
						<?php } ?>
						<li>
							<a  href="#" onclick="showMessaage('Track')"
								<?php if(($currentController == 'payments') OR ($currentController == 'plannings') || ($currentController == 'interactions' && ($currentMethod == 'list_interactions' || $currentMethod == 'view_numeric_report' || ($currentMethod == 'add_mirf' && $mirfWithin==0) || $currentMethod == 'view_mirf' && $mirfWithin==0)) OR ($currentController == 'monthly_reports') OR ($currentController == 'contracts') OR ($currentController == 'coachings' OR $currentController == 'customer_engagements') or ($currentController == "speaker_evaluations") OR ($currentController == 'interactions')) echo 'class="current"';?>>
								<div class="navLinkTrack sprite_iconSet"></div><?php echo lang('Track')?>
							</a>
						</li>
						<li>
							<a href="#" onclick="showMessaage('Surveys')"
								<?php if($currentController == 'surveys') echo 'class="current"';?>> 
								<div class="navLinkSurvey sprite_iconSet"></div><?php echo lang('Surveys')?>
							</a>
						</li>
						<li>
							<a onclick="showMessaage('MyLists')"
								<?php if(($currentController == 'my_list_kols')) echo 'class="current"';?>>
								<div class="navLinkMyLists sprite_iconSet"></div><?php echo lang('MyLists')?>
							</a>
						</li>
						<div id="swap_menu">
							<?php if(!$this->common_helpers->isActionAllowed('interaction_reports')){?>
							<li>
								<a  href="#" onclick="showMessaage('Reports')" 
									<?php if($currentController == 'reports') echo 'class="current"';?>> 
									<div class="navLinkReports sprite_iconSet"></div><?php echo lang('Reports')?>
								</a>
							</li>
							<?php }else{?>
							<li>
								<a  href="#" onclick="showMessaage('Reports')" 
									<?php if($currentController == 'reports') echo 'class="current"';?>> 
									<div class="navLinkReports sprite_iconSet"></div><?php echo lang('Reports')?>
								</a>
							</li>
							<?php }?>
						</div>
						<li id="moreButton">
							<a href="#" class="last" id="moreLinks" >
								<?php echo lang('More')?><div class="dropdown sprite_iconSet"></div>
							</a>
							<div id="moreLinksContainer" style="display: none;">
								<ul>
                                   <?php if($this->common_helpers->isActionAllowed('profile_request','add',$kolDetails)){ ?>
									<li>
										<a onclick="showMessaage('ProfileRequest')">
											<div class="kolRequestIcon sprite_iconSet"></div><?php echo lang('ProfileRequest')?>
										</a>
									</li>
                                                                    <?php }?>
									<li>
										<a  href="#" onclick="showMessaage('OrgProfileRequest')">
											<div class="orgRequestIcon sprite_iconSet"></div><?php echo lang('OrgProfileRequest')?>
										</a>
									</li>
									<!--li>
										<a  href="#"  onclick="showMessaage('Calendar')" class="last <?php if($currentController == 'calendars') echo 'current';?>">
											<div class="navLinkCalendar sprite_iconSet"></div><?php echo lang('Calendar')?>
										</a>
									</li-->
									<li>
										<a href="#" onclick="showMessaage('RecentActivity')" class="last <?php if($currentController == 'updates') echo 'current';?>">
											<div class="recentActivity sprite_iconSet"></div><?php echo lang('RecentActivity')?>
										</a>
									</li>                             
                                    <li>
										<a onclick="showMessaage('Media')" class="last <?php if($currentController == 'medintel') echo 'current';?>">
											<div class="medIntel sprite_iconSet"></div><?php echo "Media"?>
										</a>
									</li>
									<?php if($this->common_helpers->isActionAllowed('notification','link',array())) { ?>
									<li>
										<a onclick="showMessaage('Notifications')" class="last <?php if($currentController == 'notifications') echo 'current';?>">
											<div class="notifications sprite_iconSet"></div><?php echo lang('Notifications')?>
										</a>
									</li>
                                     <?php } ?>
								</ul>
							</div>
						</li>
						<?php } else {?>
						<li>
							 <a href="<?php echo base_url().'kols/client_index'?>" 
								<?php if(($currentController == 'kols') && ($currentMethod == 'client_index')) {echo "class='first-current'";} else {echo "class='first'";}?>>
								<div class="navLinkHome sprite_iconSet"></div><?php echo lang('Home')?>
							</a>
						</li>
					
						<li>
							<a href="<?php echo base_url();?>kols/list_kols_client_view" 
							<?php if(($currentController == 'kols' && $currentMethod=='adv_search') || ((($currentController == 'kols') && ($currentMethod != 'client_index'))
                                                                        || ($currentController == 'interactions' && ($currentMethod != 'list_interactions' && $currentMethod != 'view_numeric_report' && $currentMethod != 'add_mirf' && $currentMethod != 'view_mirf' && $currentMethod !='view_drilldown_list' && $currentMethod !='view_micro_interaction'))
                                                                        ||
									$currentController == 'clinical_trials' || $currentController == 'pubmeds' || ($currentController=='requested_kols') && $currentMethod == 'show_non_profiled_kols' || ($mirfWithin==1 && $currentMethod == 'add_mirf')  || ($mirfWithin==1 && $currentMethod == 'view_mirf')) && ((isset($arrKol) && $arrKol['imported_as']!=1)|| $currentMethod =='list_kols_client_view'))  echo 'class="current"';?>> 
									<div class="navLinkMyKols sprite_iconSet"></div><?php echo lang('MyKols')?>
							</a>
						</li>
						<?php if(HIDE_ORGANIZATION){ ?>
						<li>
							<a href="<?php echo base_url();?>organizations/list_organizations_client_view" 
								<?php if($currentController == 'organizations' || $currentController == 'requested_orgs') echo 'class="current"';?> id="topMenuOrg"> 
								<div class="navLinkOrgs sprite_iconSet"></div><?php echo lang('Organizations')?>
							</a>
						</li>
						<?php } ?>
						<li>
							<a href="<?php echo base_url();?>interactions/view_numeric_report" 
								<?php if(($currentController == 'payments') OR ($currentController == 'plannings') || ($currentController == 'interactions' && ($currentMethod == 'list_interactions' || $currentMethod == 'view_numeric_report' || ($currentMethod == 'add_mirf' && $mirfWithin==0) || $currentMethod == 'view_mirf' && $mirfWithin==0)) OR ($currentController == 'monthly_reports') OR ($currentController == 'contracts') OR ($currentController == 'coachings' OR $currentController == 'customer_engagements') or ($currentController == "speaker_evaluations") OR ($currentController == 'interactions')) echo 'class="current"';?>>
								<div class="navLinkTrack sprite_iconSet"></div><?php echo lang('Track')?>
							</a>
						</li>
						<?php 
						if(IDENTIFY_ENABLE){
					    $userGroupName = getGroupDetails();
					    $group_names = explode(',',  $userGroupName['group_names']);
// 						$group_names = explode(',', $this->session->userdata('group_names'));
						$userIdCheck = $this->session->userdata('user_id');
						$idInst =& get_instance();
						$idInst->load->model('user_setting');
						$regionNames = $idInst->user_setting->getEnableRegionForIdTab();
                		$result=array_intersect($group_names,$regionNames);
                		if(sizeof($result) > 0){
                		?>
                         <li>                         
                            <a href="<?php echo base_url();?>identifications/home"
								<?php if(($currentController == 'identifications' || (isset($arrKol) && $arrKol['imported_as']==1))) echo 'class="current"';?>>
								<div class="navLinkIdentify sprite_iconSet"></div><?php echo lang('IdReport')?>
							</a>
						</li> 
						<?php } }?>
						<li>
							<a href="<?php echo base_url();?>my_list_kols/show_list"
								<?php if(($currentController == 'my_list_kols')) echo 'class="current"';?>>
								<div class="navLinkMyLists sprite_iconSet"></div><?php echo lang('MyLists')?>
							</a>
						</li>
						<?php $mobile = mobile_device_detect(); 
							if(!isset($mobile[1])) {?>
								<li>
									<a href="<?php echo base_url();?>maps/view_influence_map" 
										<?php if($currentController == 'maps') echo 'class="current"';?> id="topMenuMap"> 
										<div class="navLinkMaps sprite_iconSet"></div><?php echo lang('NetworkMaps')?>
									</a>
								</li>
						<?php } else {?>
								<li>
									<a href="<?php echo base_url();?>maps/view_influence_map" 
										<?php if($currentController == 'maps') echo 'class="current"';?> id="topMenuMap"> 
										<div class="navLinkMaps sprite_iconSet"></div><?php echo lang('NetworkMaps')?>
									</a>
								</li>
						<?php }?>
<!-- 					<li>
							<a href="<?php echo base_url();?>surveys/list_active_surveys" 
								<?php if($currentController == 'surveys') echo 'class="current"';?>> 
								<div class="navLinkSurvey sprite_iconSet"></div><?php echo lang('Surveys')?>
							</a>
						</li>  -->	
						<div id="swap_menu">
							<?php if(!$this->common_helpers->isActionAllowed('interaction_reports')){?>
							<li>
								<a href="<?php echo base_url();?>reports/view_reports/activity" 
									<?php if($currentController == 'reports') echo 'class="current"';?>> 
									<div class="navLinkReports sprite_iconSet"></div><?php echo lang('Reports')?>
								</a>
							</li>
							<?php }else{?>
							<li>
								<a href="<?php echo base_url();?>reports/view_interaction_reports" 
									<?php if($currentController == 'reports') echo 'class="current"';?>> 
									<div class="navLinkReports sprite_iconSet"></div><?php echo lang('Reports')?>
								</a>
							</li>
							<?php }?>
						</div>
						<li id="moreButton">
							<a href="#" class="last" id="moreLinks" >
								<?php echo lang('More')?><div class="dropdown sprite_iconSet"></div>
							</a>
							<div id="moreLinksContainer" style="display: none;">
								<ul>
                                                                    <?php //if($this->common_helpers->isActionAllowed('profile_request','add',$kolDetails)){ ?>
									<li>
										<a href="<?php echo base_url();?>requested_kols/show_client_requested_kols">
											<div class="kolRequestIcon sprite_iconSet"></div><?php echo lang('ProfileRequest')?>
										</a>
									</li>
                                                                    <?php //}?>
									<li>
										<a href="<?php echo base_url();?>requested_orgs/show_client_requested_orgs">
											<div class="orgRequestIcon sprite_iconSet"></div><?php echo lang('OrgProfileRequest')?>
										</a>
									</li>
									<!--li>
										<a href="<?php echo base_url();?>calendars/view_calendar" class="last <?php if($currentController == 'calendars') echo 'current';?>">
											<div class="navLinkCalendar sprite_iconSet"></div><?php echo lang('Calendar')?>
										</a>
									</li-->
									<li>
										<a href="<?php echo base_url();?>updates/show_updates" class="last <?php if($currentController == 'updates') echo 'current';?>">
											<div class="recentActivity sprite_iconSet"></div><?php echo lang('RecentActivity')?>
										</a>
									</li>
                                                                        
                                                                        <li>
										<a href="<?php echo base_url();?>medintel/" class="last <?php if($currentController == 'medintel') echo 'current';?>">
											<div class="medIntel sprite_iconSet"></div><?php echo "Media"?>
										</a>
									</li>
									<?php //if($this->common_helpers->isActionAllowed('notification','link',array())) { ?>
									<li>
										<a href="<?php echo base_url();?>notifications/notifications_home" class="last <?php if($currentController == 'notifications') echo 'current';?>">
											<div class="notifications sprite_iconSet"></div><?php echo lang('Notifications')?>
										</a>
									</li>
                                     <?php //} ?>
								</ul>
							</div>
						</li>
						<?php }?>
					</ul>
					
		</div>
		<!-- End of Primary Navigation -->
		<?php
			$arrData['currentController']	= $currentController;
			$arrData['currentMethod']		= $currentMethod;
			$arrData['param']				= $param;
			$arrData['subContentPage']		= (isset($subContentPage)?$subContentPage:'');
			$arrData['arrOrganization']		= (isset($arrOrganization)?$arrOrganization:'');
			$arrData['arrKol']				= (isset($arrKol)?$arrKol:'');
			echo $this->load->view('elements/export_options',$arrData);
		?>
	</div>
	<!-- End of Header Div -->
	
	<!-- Container for the 'Advance Search' modal box -->
	<div id="advanceDailog">	
		<div id="advSearchAddContainer" class="microProfileDialogBox">
			<div class="profileContent" id="advSearchAddProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Advance Search' modal box -->
	
	<!-- Container for the 'Organization Import' modal box -->
	<div id="importOrgDialog">	
		<div id="importOrgContainer" class="microProfileDialogBox">
			<div class="profileContent" id="importOrgProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Organization Import' modal box -->
	
	<!-- Container for the 'KOL Import' modal box -->
	<div id="importKolDialog">	
		<div id="importKolContainer" class="microProfileDialogBox">
			<div class="profileContent" id="importKolProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'KOL Import' modal box -->
	
	<!-- Container for the 'Kol's Export' modal box -->
	<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Kol's Export' modal box -->
	

	<!-- Container for Email modal box -->
	<div id="addEmail" class="microProfileDialogBox">
 		<div id="emailContainer"  class="profileContent"></div>
 	</div>

 		
	<div id="categoryModalBoxWithinProile" class="microProfileDialogBox">
		<div class="addListContentForWithinProfile profileContent"></div>
	</div>
	
	<div id="feedbackDialog">	
		<div id="feedbackDialogContainer" class="microProfileDialogBox">
			<div class="profileContent" id="feedbackDialogContent"></div>
		</div>
	</div>
	<div id="messageDialog">	
		<div id="messageDialogContainer" class="microProfileDialogBox">
			<div class="profileContent" id="messageDialogContent"></div>
		</div>
	</div>
        
   	<div id="notificationDialog">	
		<div id="notificationDialogContainer" class="microProfileDialogBox">
			<div class="profileContent" id="notificationDialogContent"></div>
		</div>
	</div>
        
        <div id="notificationListDialog">	
		<div id="notificationListDialogContainer" class="microProfileDialogBox">
			<div class="profileContent" id="notificationListDialogContent"></div>
		</div>
	</div>
	
	<!-- Container for the 'Change Password' modal box -->
	<div id="changePasswordDailog">	
		<div id="changePasswordContainer" class="microProfileDialogBox">
			<div class="profileContent" id="passwordContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Change Password' modal box -->
	
	<div id="alignUsersModalWithinKolView" class="microProfileDialogBox">
		<div class="alignUsersContentWithinView profileContent"></div>
	</div>
	<div id="alignOrgUsersModalBoxWitinView" class="microProfileDialogBox">
		<div class="alignOrgUsersContentWitinView profileContent"></div>
	</div>
