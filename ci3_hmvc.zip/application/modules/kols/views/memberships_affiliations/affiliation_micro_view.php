<?php
/**
*Microview page for Affiliation
*Created By: Ramesh B
*Created 12 June 2012
*
*/

?>
<style type="text/css">
	#aff_microview table caption h3{
		margin: 5px 0px;
		text-align: center;
	}
	#aff_microview table tr th{
		text-align: right;
	}
</style>
<div id="aff_microview">
<table>
	<caption><h3><?php echo $arrAffDetails['name']?></h3></caption>
	<tr>
		<th>
			<label>	Department:</label>
		</th>
		<td>
			<?php echo $arrAffDetails['department'];?>
		</td>
	</tr>
	<tr>
		<th>
			<label>	Title:</label>
		</th>
		<td>
		<?php echo $arrAffDetails['role'];?>
		</td>
	</tr>
	<tr>
		<th>
			<label>	Type:</label>
		</th>
		<td>
		<?php echo $arrAffDetails['type'];?>
		</td>
	</tr>
	<tr>
		<th>
			<label>	Start Date:</label>
		</th>
		<td>
		<?php echo $arrAffDetails['start_date'];?>
		</td>
	</tr>
	<tr>
		<th>
			<label>	End Date:</label>
		</th>
		<td>
		<?php echo $arrAffDetails['end_date'];?>
		</td>
	</tr>
</table>
</div>
