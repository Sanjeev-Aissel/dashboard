<style>
.col-form-label{
text-align:right;
}
.reqd-field-indicator {
    color: #f00;
}
</style>
<script>
	var validationRules = {
		client_id: {
            required: true
        },
        user_id: {
            required: true
        },
        comment: {
            required: true
        },
        ticket_no: {
            required: true
        }
    };
    var validationMessages = {
		client_id: {
            required: "Required"
        },
        user_id: {
            required: "Required"
        },
        comment: {
            required: "Required"
        },
        ticket_no: {
        	required: "Required"
        }
    };
	/**
	 * Ajax function  to send request to "Delete KTL" function  
	 * @author Vinod H
	 * @since Jan 30,2018
	 * @param 
	 * @return json
	 * 
	 */
	$('#sendDelete').click(function(){
		if (!$("#deleteForm").validate().form()) {
            return false;
        }
		$('.errorMessage').html("");
		$('div.uniMsgBox').removeClass('success');
		$('div.uniMsgBox').addClass('notice');
		$('div.uniMsgBox').show();
		$('div.uniMsgBox').html('Saving Delete Comment... <img src="'+base_url+'assets/images/ajax_loader_black.gif" />');
		$.ajax({
			url:"<?php echo base_url();?>kols/kols/delete_created_opt_ol",
			data:$('#deleteForm').serialize(),
			dataType:'json',
			type:'post',
			success:function(returnData){
								},
			complete:function(returnData){
					if (returnData.status == 200) {
                        $('div.uniMsgBox').html("Profile Deleted Successfully");
                    } else {
                        $('div.uniMsgBox').html("Profile Deleted Failed");
                    }
                    $('div.uniMsgBox').fadeOut(1500);
                    setTimeout(closeDeletedlDialog, 2000);
				}
		});	
	});

	/**
     * Returns the list of Client User Names of the Selected Client Id
     */
    function getUserNameById() {
        $("#loadingCities").show();        
        $("#user_id").html("<option value=''>-- Select User--</option>");
        var clientId = $("#client_id").val();    
        var params = "client_id=" + clientId;
        $.ajax({
            url: "<?php echo base_url();?>kols/kols/get_user_name_by_clientId/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                console.log(responseText);
            	if(responseText==''){
                    alert('No Users for Seleted Client');
                }else{
                	setTimeout(function(){ 	
                		var selectedIndex	= '';
	                $.each(responseText, function (key, value) {
     					 $('#user_id').append('<option value="'+value.user_id+'">'+value.user_name+'</option>');
	                });
                	}, 30);
                }
            },
            complete: function () {
                $("#loadingCities").hide();
            }
        });
    }

	/**
	 * To close dialog box
	 * @author Vinayak
	 * @version 3.8
	 * @since april 7,2012
	 * @param 
	 * 
	 */
	function closeDeletedlDialog(){
		$('#userContainer').dialog("close");
		location.reload();
	}
</script>

<div class="uniMsgBox"></div>
<form action="" method="post" name="deleteForm" id="deleteForm">
	<input type="hidden" name="kolId" value="<?php echo $kolId?>"/>
	<strong>Are you sure want to Delete <?php echo $kolName?> Profile?</strong>
	<div class="form-group row">
		<label class="col-sm-4 align_right">Client: <span class="reqd-field-indicator">*</span></label>
		<div class="col-sm-8">
			<select name="client_id" id="client_id" onchange="getUserNameById();" class="form-control required">
				<option value=''>-- Select Client--</option>
					<?php foreach($arrClients as $row){?>
						<option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
					<?php }?>
			</select>
			<img id="loadingCities" src="<?php echo base_url() ?>assets/images/ajax_loader_black.gif" style="display:none"/>
    	</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-4 align_right">Requested User: <span class="reqd-field-indicator">*</span></label>
		<div class="col-sm-8">
			<select name="user_id" id="user_id" class="form-control required">
				<option value=''>-- Select User--</option>
			</select>
    	</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-4 align_right">Ticket No: <span class="reqd-field-indicator">*</span></label>
		<div class="col-sm-8">
			  <input type="text" name="ticket_no" id="ticket_no" class="form-control required"/>
    	</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-4 align_right">Comment:<span class="reqd-field-indicator">*</span></label>
		<div class="col-sm-8">
			<textarea id="comment" name="comment" class="form-control required" rows="5"></textarea>
			<div class="fromErrorMessage"></div>
    	</div>
	</div>
	<div class="form-group row align_center">
		<input type="button" id="sendDelete" value="Ok"/>
		<input type="button" onclick="closeDeleteDialog(); return false;" value="Cancel"/>
	</div>
</form>