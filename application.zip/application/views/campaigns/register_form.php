<?php
/**
 * this is html file to Add the User Deatils
 * @package application.views.client_users
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 * 
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php if(isset($title) && $title!=null) { echo $title; } else { echo  PRODUCT_NAME; }?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	<script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	<script src="<?php echo base_url()?>js/jquery.popupWindow.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/imageslider/demo.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/imageslider/style.css" />
		<script type="text/javascript" src="<?php echo base_url()?>js/imageslider/modernizr.custom.28468.js"></script>
		<noscript>
			<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/imageslider/nojs.css" />
		</noscript>
	<style>
		body{
			margin-top: 0px;
		}
		#comp-logo {
		    background: rgba(0, 0, 0, 0) url("<?php echo base_url()?>/images/logo.png") no-repeat scroll 20px 0 / 130px auto;
		    height: 50px;
		    width: 550px;
		}
		td{
			 font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
			 color:#626262;
			 padding: 5px;
			 vertical-align: text-top;
		}
		.productNameContainer {
		    border-bottom: 1px solid #BCBCBC;
		    color: #4A85BE;
		}
		#loginFormContainer {
		    background-color: #FFFFFF;
		    border: 1px solid #BCBCBC;
		    border-radius: 5px 5px 5px 5px;
		    box-shadow: 1px 1px 10px #999999;
		    font-size: 15px;
		    height: 100%;
		    padding: 10px;
		/*	width: 700px;*/
			margin: auto;
		}
		.labelForfields{
		    width: 130px;
			text-align:right;
		}
		label.error {
		    padding: 2px;
		    color: red;
		}
		.boldText{
			font-weight:bold;
			display: block;
			border-bottom: 1px solid #BCBCBC;
		    margin-bottom: 10px;
		    padding-bottom: 10px;
		}
		#saveUser{
			height:50px;
			color: #444444;
   			font-size: 15px;
		}
		input[type="text"], input[type="password"], select{
			height:30px;
			width: 300px;
			width:100%;
		}
		.container{
			background-image: none;
			background-color: none;
		}
		span.span{
			color: red;
		}
		.copyRightText {
		    float: right;
		    padding-right: 5px;
		}
		.footerContainer {
		    border-top: 1px solid #BCBCBC;
		}
		.sliderWrapper{
			width: 400px;
			width: 95%;
			/*margin: auto;*/
		}
		.da-slider{
			margin: 0px;
			background: url("<?php echo base_url()?>images/waves_gray.gif");
			background:none;
		}
		.da-dots span,.da-arrows span{
			background: #444;
		}
		p.codrops-demos{
			padding: 0px;
		}
		.da-slide h2{
			color: #444444;
		}
		.da-slide .da-link{
			color: #444444;
			border-color: #444444;
			display: none;
		}
		.da-slider{
			/*overflow: visible;
			min-width: 500px !important;*/
		}
		.da-slide h2 {
			top:0px;
			width: 100%;
			font-size: 40px;
			white-space: inherit;
			z-index:11;
		}
		.da-slide p{
			height:200px;
			overflow: visible !important;
			z-index:11;
			width:30%;
			top:105px;
		}
		.da-slide .da-img{
			z-index:10;
		}
		.error{
			color:red;
		}
	</style>
	<script type="text/javascript">
		
			var validationRules	=  {
					first_name: {
						required:true,
						 maxlength: 64,//32,
						 minlength:2,
						 lettersonly: true 
					},
					/*	last_name: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					title: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},*/
					company_name: {
						required:true,
						 maxlength: 32,
						 minlength:2,
						 lettersonly: true 
					},
					/*phone: {
						required:true,
						 maxlength: 16,
						 minlength:6,
						  phoneUS: true
					},*/
					email: {
						required:true,
						 maxlength: 50,
						 minlength:4,
						 officialemail:true
					},
				/*	country: {
						required:true
					},*/
					password: {
						required:true,
						 maxlength: 32,
						 minlength:4
					},
					confirm_password: {
						required:true,
						 maxlength: 32,
						 minlength:4
					}/*,
					user_name: {
						required:true,
						 maxlength: 32,
						 minlength:4,
						 lettersonly: true 
					}*/
				};
			
				var validationMessages = {
						first_name: {
							required: "Required field cannot be left blank"
						},
						/*last_name: {
							required: "Required field cannot be left blank"
						},
						user_name: {
							required: "Required field cannot be left blank"
						},
						
						title: {
							required: "Required field cannot be left blank"
						},
						country: {
							required: "Required field cannot be left blank"
						},*/
						password: {
							required: "Required field cannot be left blank"
						},
						confirm_password: {
							required: "Required field cannot be left blank"
						},
						/*title: {
							required: "Required field cannot be left blank"
						},*/
						company_name: {
							required: "Required field cannot be left blank"
						},
						/*phone: {
							required: "Required field cannot be left blank"
						},*/
						email: {
							required: "Required field cannot be left blank"
						}
				};

				var emailblockReg =	/\b[\w\.-]+@((?!gmail|yahoo|).)[\w\.-]+\.\w{2,4}\b/i;
				function isBlockedEmail(str) {
					  var blocked = ["@gmail.com", "@hotmail.com", "@yahoo.com","@aol.com"];
					  for(var i = 0; i< blocked.length; i++) {
					    if(str.indexOf(blocked[i]) != -1) {
					       return false;
					    }
					  }
					  return true;
					 // return emailblockReg.test(str);
					}
				$(document).ready(function(){
					$('#saveUser').click(function(){
				
						$('#errorBox').text(' ');
						if(!$("#saveUserForm").validate().form()){
							return false;
						}
						 // Regular ecpression for Vhecking white space
						 reWhiteSpace       = new RegExp(/^\s+$/);
						 var useName        = $('#email').val();
			
					     // Check for white space
					     if (useName.indexOf(' ') > 0) {
					          jAlert("Please Check Your User Fields For Spaces");
					          return false;
					     }else{
			
							 var password        = $('#password').val();
							 var confirmPassword = $('#confirmPassword').val();
							 if(password == confirmPassword){
									$('#saveUserForm').submit();
									return true;
							 }else{
								 	$('#password').val('');
								 	$('#confirmPassword').val('');
									$('#errorBox').text('Passwords do not match.');
									$('#errorBox').css({'color':'red'});
							 }
					     }
					});
					//Validation to check first letter alphet only
					jQuery.validator.addMethod("officialemail", function(value, element) {
						  return this.optional(element) || isBlockedEmail(value);
						}, "For security reasons, we request you to please use your company email address");
					 
					jQuery.validator.addMethod("lettersonly", function(value, element) {
							var value1=value[0];
						  return this.optional(element) || /^[a-z]+$/i.test(value1);
						}, "Please enter first letter Alphbet"); 


					jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
					    phone_number = phone_number.replace(/\s+/g, ""); 
						return this.optional(element) || phone_number.length > 9 &&
							phone_number.match(/\(?[0-9]{2,}\)?(-?)\(?[0-9]{3,}?\)?(-?)[0-9]{4,}/);
					}, "Please specify a valid phone number");
					
					$("#saveUserForm").validate({
						//debug:true,
						onkeyup:true,
						rules: validationRules,
						messages: validationMessages
					});
			
					$('.privacy').popupWindow({ 
						height:650, 
						width:850, 
						top:50, 
						left:50,
						resizable: false 
					}); 

				});

				function checkFirstLetterAlphabet(value1){
					var val1=value1[0];
					var regexLetter = /[a-zA-z]/;
					if(!regexLetter.test(val1)){
					jAlert('First letter will be alphbet only');
					return false;
					}
				}
		sessionStorage.clear();
	</script>
</head>
<body>
	<div>
		<table style="width:98%;border-collapse: collapse;margin: auto;">
			<tr>
				<td colspan="2" class="productNameContainer"><div id="comp-logo"></div></td>
			</tr>
			<!-- tr>
				<td colspan="2"><div style="font-size: 20px;font-weight: bold;text-align: center;">Create your new account</div></td>
			</tr-->
			<tr class="container">
				<td style="vertical-align: inherit;width:50%;">
					<div class="sliderWrapper">
			<header>
				<p class="codrops-demos">&nbsp;</p>
			</header>
			<div id="da-slider" class="da-slider">
				<div class="da-slide">
					<h2>Expert Profiling</h2>
					<p>Understand the key strengths of experts with accurate and comprehensive profiles built across multiple data points.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="<?php echo base_url();?>images/imageslider/2.gif" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>Network Maps</h2>
					<p>Network Maps with visual representation of Physician networks and work-groups.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="<?php echo base_url();?>images/imageslider/4.gif" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>Geo Map</h2>
					<p> Visualize the social network connections on stunning world maps and identify the global connections and key influencers.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="<?php echo base_url();?>images/imageslider/5.gif" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>Cross Platform Compatibility</h2>
					<p>Accessible on desktop, iPad and smartphones.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="<?php echo base_url();?>images/imageslider/1.gif" alt="image01" /></div>
				</div>
				
				<nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>
				</nav>
			</div>
					</div>
				</td>
				<td style="padding:5% 5px 5% 0;width:50%;" valign="top">
					<div id="loginFormContainer">
					<div id="userRegistrationContainer">
						<div id="userRegistrationWrapper">
							<div title="Login" id="userFormContainer">
								<div class="boldText">Create your new account</div>
								<div id="error" style="color:red; margin-left:155px; font-weight:bold">
									<?php if(isset($arrUserDetails['error'])){
									echo  $arrUserDetails['error'];
									}?>
								</div>
								<form action="<?php echo base_url();?>register/save_user_registration_details" id="saveUserForm" method="post" name="saveUserForm1" >
									<table border="0" class="userForm" style="margin: auto;">
										<tr>
											<td><div class="labelForfields">Full Name:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="first_name" id="firstName" value="<?php if(isset($arrUserDetails['first_name'])) echo $arrUserDetails['first_name']; else echo '';?>" class="required" />
											</td>
										</tr>
										<!--<tr>
											<td><div class="labelForfields">Last Name:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="last_name" id="lastName" value="<?php if(isset($arrUserDetails['last_name'])) echo $arrUserDetails['last_name']; else echo '';?>" class="required" />
											</td>
										</tr>
										<tr>
											<td><div class="labelForfields">Title:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="title" id="title" value="<?php if(isset($arrUserDetails['title'])) echo $arrUserDetails['title']; else echo '';?>" />
											</td>
										</tr>
										--><tr>
											<td><div class="labelForfields">Company Name:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="company_name" id="companyName" value="<?php if(isset($arrUserDetails['company_name'])) echo $arrUserDetails['company_name']; else echo '';?>"/>
											</td>
										</tr>
										<!--<tr>
											<td><div class="labelForfields">Country:<span class="span">*</span></div></td>
											<td class="inputFields">
												<select name="country" id="countryId1"  class="required">
													<option value="">-- Select --</option>
													<?php foreach( $arrCountry as $country ){
															if(isset($arrUserDetails['country'])){
																if($arrUserDetails['country']==$country['country_id']){
																	echo "<option value=".$arrUserDetails['country']." selected='selected'>".$country['country_name']."</option>";
																}
															}
														?>
														<option value="<?php echo $country['country_id'];?>" >
															<?php echo $country['country_name'];?>
														</option>
													<?php }?>
												</select>
											</td>
										</tr>
										<tr>
											<td><div class="labelForfields">Phone:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="phone" id="phone" value="<?php if(isset($arrUserDetails['phone'])) echo $arrUserDetails['phone']; else echo '';?>" />
											</td>
										</tr>-->
										<tr>
											<td><div class="labelForfields">Email:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="email" id="email" value="<?php if(isset($arrUserDetails['email'])) echo $arrUserDetails['email']; else echo '';?>" class="email" />
												<?php if($this->session->flashdata('emailError'))?><br/><span class="error"><?php echo $this->session->flashdata('emailError')?></span>
												<br /><span>Email address will be your username</span>
											</td>
										</tr>
										
										<!--<tr>
											<td><div class="labelForfields">Username:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="text" name="user_name" id="userName" value="" class="required" />
											</td>
										</tr>
										--><tr>
											<td><div class="labelForfields">Password:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="password" name="password" id="password" value="" />
												<div id="errorBox"></div>
											</td>
										</tr>
										<tr>
											<td><div class="labelForfields">Confirm Password:<span class="span">*</span></div></td>
											<td class="inputFields">
												<input type="password" name="confirm_password" id="confirmPassword" value="" onkeyup="" />
											</td>
										</tr>
										<input type="hidden" name="campaign_id" id="campaign_id" value="<?php if(isset($campaign_id))echo $campaign_id;?>"/>
										<input type="hidden" name="campaign_name" id="campaign_name" value="<?php if(isset($campaign_name)) echo $campaign_name;?>"/>
										<input type="hidden" name="campaign_short_code" id="campaign_short_code" value="<?php if(isset($campaign_short_code)) echo $campaign_short_code;?>"/>
										<input type="hidden" name="campaign_project_id" id="campaign_project_id" value="<?php if(isset($campaign_project_id)) echo $campaign_project_id;?>"/>
										<tr>
											<td colspan="2" style="text-align: center;">
												<input type="button" value="Create my account" id="saveUser" name="dss"></input>
											</td>
										</tr>
									</table>
								</form>
							</div>
						</div>
					</div>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="2" class="footerContainer">
					<div id="loginFooter">
						<div class="copyRightText"><a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> | <?php echo PRODUCT_NAME;?> <?php echo PRODUCT_VERSION;?> Copyright &copy; <?php echo COPYRIGHT;?> <a href="http://www.aissel.com" target="new">Aissel</a> Solutions | Powered by <a href="http://www.aissel.com" target="new">Aissel</a></div>
					</div>
				</td>
			</tr>
		</table>
	</div>
	<script type="text/javascript" src="<?php echo base_url()?>js/imageslider/jquery.cslider.js"></script>
		<script type="text/javascript">
			$(function() {
				$('#da-slider').cslider({
					autoplay	: true,
					bgincrement	: 450
				});
			});
		</script>	
</body>
</html>