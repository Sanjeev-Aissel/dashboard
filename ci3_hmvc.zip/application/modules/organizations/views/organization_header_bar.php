<style>
#toggleView {
    width: 37px;
    margin-right: 5px;
    margin-left: 8px;
}
#toggleViewIcon {
    /* background: url(../images/toggle_view.png) no-repeat scroll 0 3px transparent; */
    background: url(../../assets/modules/organizations/images/toggle_list.svg) no-repeat scroll;
    width: 42px;
    margin-top: 4px;
}
#toggleViewIcon.listView {
    /* background: url(../images/toggle_view.png) no-repeat -41px 3px transparent; */
    background: url(../../assets/modules/organizations/images/toggle_detailed_view.svg) no-repeat scroll;
}


#toggleViewIcon a {
    text-decoration: none;
    display: block;
}
.alignToUsersIcon {
    /* background-position: -267px -388px; */
    background-image: url(../../assets/modules/organizations/images/assign_profile_inactive.svg);
    background-position: 0 5px !important;
    background-repeat: no-repeat;
    background-size: 20px auto;
}
.exportOptionsContainer {
    overflow: visible;
}
.exportOptionsContainer ul:first-child, .exportOptionsContainer ul.pageRightOptions {
    margin: 0px;
    padding: 0px;
    float: left;
}
.exportOptionsContainer ul:first-child li, .exportOptionsContainer ul.pageRightOptions li {
    list-style: none;
    padding: 2px 3px;
    float: left;
    height: 25px;
    line-height: 25px;
}
.sprite_iconSet {
   /*  background: url(../assets/modules/organizations/images/all_icons.png); */
    float: left;
    height: 25px;
    width: 20px;
    margin-left: 5px;
    margin-right: 5px;
    cursor: pointer;
    margin-top: -3px;
}
div.editIcon {
    background-image: url(<?php echo base_url().MODULES_ASSETS; ?>organizations/images/assign_to_edit_inactive.svg) !important;
    background-position: 0 0px !important;
    background-repeat: no-repeat !important;
    background-size: 20px auto !important;
}
div.actionIcon {
    background: url(../../assets/images/kolm-sprite-image.png) repeat scroll -160px -2px transparent;
    float: left;
    height: 25px;
    width: 20px;
}
.custom-btn{
    padding: 3px 10px !important;
    font-size: 12px !important;
    border-radius: 2px !important;
    background: #2b9af3 none repeat scroll 0 0;
    border: 1px solid #2b9af3;
    color:white;
    margin-left: 5px;
}
.custom-btn:hover{
    background: #ffffff none repeat scroll 0 0;
    border: 1px solid #2b9af3;
    color:#2b9af3;
}
</style>
<script>

var orgId = "<?php echo $arrOrganization['id'];?>";
function editOrgUsers(orgId, type){
	$(".modal-body").load('http://localhost/hmvc/align_users/edit_org_align_users/'+orgId+'/Edit');
}

</script>
	<div class="col-sm-6 exportOptionsContainer">
			<ul>
				<li>        
				<div class="assignedOrgUsers">
                            <label style="float: left;">Assigned to:</label>
                            <div style="float: right;">
                                <p style="float:left;margin:0px;">&nbsp;</p>                                                                
                               <a class="tooltipLink" onclick="editOrgUsers(60333, 'Edit');" href="#" rel="tooltip" data-original-title="Edit" data-toggle="modal" data-target="#myModal"> 
                                <div class="actionIcon editIcon tooltip-demo tooltop-bottom" style="float: right; margin-left: 4px; margin-top: 2px;">
                                    &nbsp;</div>
                               </a>
                             </div>
                        </div>
				</li>
			</ul>
			</div>
	<div class="col-md-6">
		<button class="btn custom-btn btn-default pull-right">Add Interactions</button>
	</div>
	
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body"></div>
    </div>

  </div>
</div>