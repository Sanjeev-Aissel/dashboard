<?php
/*
 * To enter KOL survey response
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v6.0.9 Otsuka 2.1
 * Created on	: 26-05-2014
 *  
 */

	$autoSearchOptionsForKolName = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
	
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery/jquery.validate1.9.min',
							'chosen.jquery',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	#surveyContainer input[type="text"],#surveyContainer select, #surveyContainer label{
		color:#333;
	}
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	#addSurvey{
	/*	width: 805px;
		margin-top: -75px;*/
		margin-top: 0px;
	/*	float: right;*/
	}
	legend {
	    color: #626262;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		background-color:#C4D8EF;
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -274px transparent;
		color: #4D7BD6;
		background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
		background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
		background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		border: 1px solid #DADAEE;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	select.chosenSelect{
		width:200px;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.alignLeft{
		text-align: left;
	}
	.alignTop{
		vertical-align: top;
	}
	h5{
		background:url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
		padding:2px;
	}
	label.lblName{
		display: inline-block;
	    text-align: center;
	    width: 200px;
	}
	label.lblCountry,label.lblState,label.lblCity{
		display: inline-block;
	    text-align: center;
	}
	.organizationNameAutoComplete, .country, .state, .city, .zipcode,label.lblCountry,label.lblState,label.lblCity{
	<?php 
			if(IS_IPAD_REQUEST == 1){
				echo 'width:100px;';
			}else{
				echo 'width:150px;';
			}
		?>
	}
	label.lblZip{
		display: inline-block;
	    text-align: center;
	    width: 130px;
	}
	.chzn-container {
		vertical-align: sub;
		font-size: 13px;
	}
	input[type="text"]{
		height: 21px;
		height: auto;
		font-size: 12px;
	}
	th, td, caption {
	    padding: 4px 5px;
	    padding-right: 0px;
	}
	td p{
		margin: 0px;
	}
	td div.microViewIcon{
		margin: 0px;
	}
	div#contentHolder{
		width: auto !important;
		min-width: 260px;
		max-width: 600px;
	}
	th.borderBottom{
		border-bottom: 1px solid #aaa;
	}
	fieldset{
		background-color: #eee;
		border-color:#4D7BD6;
	}
	legend{
		background-color: #EEEEEE;
	    border-left: 2px solid;
	    border-right: 2px solid;
	    color: #4D7BD6;
	    padding-bottom: 5px;
	    padding-top: 5px;
	}
	label{
		font-weight:normal;
	}
	span.required{
		color:red;
	}
	span.tags{
		font-weight: normal;
		color: #090;
	}
	#surveyContainer .advSearchIcon {
		background: url("<?php echo base_url();?>images/all_icons.png") repeat scroll -105px -291px transparent !important;
		height: 20px !important;
		width: 22px !important;
	}
	.saveIcon{
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -219px -32px transparent !important;
	}
	.existingData input[type="text"]{
		border: 0px;
		background: none;
	}
	.microView{
		<?php 
			if(IS_IPAD_REQUEST == 1){
				echo 'left: 17% !important;';
			}else{
				//echo 'left: 28.7% !important;';
			}
		?>
	}
	/*#surveyContainer input.autocompleteInputBox {
		height: 15px !important;
		vertical-align: bottom !important;
	}*/
	#surveyContainer{
		position: relative;
	}
	#tooltip-resp-details{
		left: 120px;
    	position: absolute;
    	top: 32px;
	}
	#tooltip-survey-fill{
		float: right;
	    left: 3px;
	    position: relative
	}
	input[type="text"], input[type="password"], select{
		padding: 0;
	}
	
	#tooltip-survey-select {
	    display: inline-block;
	    position: relative;
	    vertical-align: middle;
	}
	.alignInline{
	 	float: left;
	 	padding-right: 30px;
	 }
	 .surveyname input[type="text"]{
	 	width:373px;
	 }
	 .influencerOrgName input[type="text"]{
	 	width:405px;
	 }
	.surveyname label{
    	display: inline-block;
	    text-align: right;
	    width: 46px;
	}
	#surveyContainer input[type="text"]{
	 	height: 20px !important;
	}
	.otherInfo{
	 	clear: left;
	 	display: none;
	}
	.influencerCity label{
	 	display: inline-block;
	    text-align: right;
	    width: 75px;
	}
	.influencerActions .labelDelete{
		display: inline-block;
		width:20px;
	}
	.influencerActions .exapndCollapseSlider{
	 	background-image: url("<?php echo base_url();?>images/double-arrowmarks-up_down.png");
	 	background-position: 2px -25px;
	 	border:0px;
	 	display: inline-block;
	    height: 17px;
	    margin-top: 0;
	    width: 20px;
	}
	.influencerActions .collapseSlider{
	 	background-position:2px -4px;
	}
	.influencerActions div.saveIcon{
		background-position:-223px -30px !important;
		margin-left: 2px;
   		margin-right: 5px;
	}
	.influencerActions div.editIcon{
	    margin-left: 5px;
   		margin-right: 5px;
	}
	.otherInfo{
		display: none;
	}
	.showOtherInfo{
		display: block !important;
	}
	<?php if(IS_IPAD_REQUEST == 1){?>
		#surveyDetails .influencerName{
			width: 300px;
			padding-right: 0px;
		}
		.alignInline{
		 	padding-right: 12px;
		 }
		.surveyname label {
			width: 41px;
		}
		.surveyname input[type="text"]{
			width: 230px !important;
		}
		.influencerOrgName input[type="text"]{
			width: 260px !important;
		}
	<?php }?>
</style>
<script type="text/javascript">
	var searchedNameRow	= 0;
	var globalId	= '';
	var globalOrgId	= '';
	var arrCount	= new Array();
	var isValidatingRespondent	= false;
	var currentSurveyId	= <?php echo $surveyId;?>;
	var surveyKolAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_kol_names_for_autocomplete',
		<?php echo $autoSearchOptionsForKolName;?>,
		onSelect : function(event, ui) {
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			var classname	= ($(event).children('.kolName').attr('class'));
			selText=selText.replace(/\&amp;/g,'&');
			$('#'+globalId).val(selText);
			$('#'+globalId).prev('input').prev('input').val(selText);
			$('#'+globalId).prev('input').val(kolId);
			if(globalId=='respondentName'){
				isRespondentAlreadySurveyed();
				getKolDetails($('#'+globalId),true);
			}else{
				if(classname=='surveynames kolName'){
					var selText = $(event).children('.orgName').html();
					selText=selText.replace(/\&amp;/g,'&');
					var inputObj	= $('#'+globalId).parent().parent().next();
					$(inputObj).find('input:eq(0)').val(selText);
					//$(inputObj).find('.influencerOrgName input[type="text"]').val(selText);
					selText = $(event).children('.country').html();
					selText=selText.replace(/\&amp;/g,'&');
					inputObj	= $(inputObj).parent().find('.otherInfo');
					$(inputObj).find('input:eq(0)').val(selText);
					//$(inputObj).find('.influencerCountry input[type="text"]').val(selText);
					selText = $(event).children('.state').html();
					selText=selText.replace(/\&amp;/g,'&');
					//$(inputObj).find('.influencerState input[type="text"]').val(selText);
					$(inputObj).find('input:eq(1)').val(selText);
					selText = $(event).children('.city').html();
					selText=selText.replace(/\&amp;/g,'&');
					//$(inputObj).find('.influencerCity input[type="text"]').val(selText);
					$(inputObj).find('input:eq(2)').val(selText);
					selText = $(event).children('.postal').html();
					selText=selText.replace(/\&amp;/g,'&');
					//$(inputObj).find('.influencerZipcode input[type="text"]').val(selText);
					$(inputObj).find('input:eq(3)').val(selText);
				}else{
					getKolDetails($('#'+globalId),false);
				}
			}
			$('#'+globalId).trigger('blur');
		}
	};
	$('#respondentName').live('keypress',function (){
		moveFromCurrentStep(5);
	});
	$('.kolNameAutoComplete').live('keypress',function (){
		moveFromCurrentStep(6);
	});
	// Autocomplet Options for the 'org name' field
	var orgNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
		<?php echo $autoSearchOptionsForKolName;?>,
		onSelect : function(event, ui) {
			var selText = $(event).children('.organizations').html();
			var selId = $(event).children('.organizations').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			if(event.length>20){
				if(event.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#'+globalOrgId).val(selText);
					return true;
				}
			}else{
				$('#'+globalOrgId).val(selText);
				return true;
			}
		}
	};
	function saveEditedAnswer(thisObj){
		var EnableDelete	= '<div onclick="editAnswer(this);return false;" class="actionIcon editIcon"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit">&nbsp;</a></div><label class="tooltip-demo tooltop-left labelDelete"><a rel="tooltip" class="tooltipLink" href="#" onclick="return false;" data-original-title="Delete"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></a></label><div class="tooltip-demo tooltop-left exapndCollapseSlider"><a class="tooltipLink" rel="tooltip" href="#" onclick="return false;" title="Expand/Collapse Influencer information"> </a></div>';
		//$(thisObj).parent().parent().find('td:eq(2) input[type="text"]').css('width','150px');
		$(thisObj).parent().parent().find('input[type="text"]:eq(0)').attr('data-original-title',$(thisObj).parent().parent().find('input[type="text"]:eq(0)').val());
		$(thisObj).parent().parent().find('input[type="text"]:eq(1)').attr('data-original-title',$(thisObj).parent().parent().find('input[type="text"]:eq(1)').val());
		$(thisObj).parent().parent().find('input[type="text"]').css('border','0px');
		$(thisObj).parent().parent().find('input[type="text"]').css('background','none');
		$(thisObj).parent().parent().find('input[type="text"]').attr('readonly','readonly');
		$(thisObj).parent().parent().find('.influencerActions').html(EnableDelete);
		$('.tooltip.in').hide();
	}
	function editAnswer(thisObj){
		var EnableDelete	= '<div onclick="saveEditedAnswer(this);return false;" class="actionIcon saveIcon"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Save Changes">&nbsp;</a></div><label class="tooltip-demo tooltop-left labelDelete"><a rel="tooltip" class="tooltipLink" href="#" onclick="return false;" data-original-title="Delete"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></a></label><div class="tooltip-demo tooltop-left exapndCollapseSlider"><a class="tooltipLink" rel="tooltip" href="#" onclick="return false;" title="Expand/Collapse Influencer information"> </a></div>';
		//$(thisObj).parent().parent().find('td:eq(2) input[type="text"]').css('width','100px');
		$(thisObj).parent().parent().find('input[type="text"]').css('border','1px solid #bbb');
		$(thisObj).parent().parent().find('input[type="text"]').css('background','#fff');
		$(thisObj).parent().parent().find('input[type="text"]').removeAttr('readonly');
		$(thisObj).parent().parent().find('.influencerActions').html(EnableDelete);
		$('.tooltip.in').hide();
	}
	function addMore(appendTo){
		$('.tooltip.in').hide();
		var limit	= 10;
		var newRow			= '<tr class="'+appendTo+'">'+$('tr.'+appendTo+':last').html()+'</tr>';
		var newCount		= $('#count_'+appendTo).val();
		var uniqueNewCount	= $('#uniqueCount_'+appendTo).val();
		if(limit>newCount){
			uniqueNewCount++;
			newCount++;
			isUnique			= true;
			$('#count_'+appendTo).val(newCount);
			$('#uniqueCount_'+appendTo).val(uniqueNewCount);
			$(newRow).insertAfter('tr.'+appendTo+':last');
			$('tr.'+appendTo+':last').find('td:eq(0)').html('');
			$('tr.'+appendTo+':last').prev().find('.otherInfo').hide();
			var EnableDelete	= '<div onclick="editAnswer(this);return false;" class="actionIcon editIcon tooltip-demo tooltop-left"><a rel="tooltip" class="tooltipLink" href="#" title="Edit">&nbsp;</a></div><label class="tooltip-demo tooltop-left labelDelete"><a rel="tooltip" class="tooltipLink" href="#" onclick="return false;" data-original-title="Delete"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></a></label><div class="tooltip-demo tooltop-left exapndCollapseSlider"><a class="tooltipLink" rel="tooltip" href="#" onclick="return false;" title="Expand/Collapse Influencer information"> </a></div>';
			$('tr.'+appendTo+':last').prev().find('.influencerActions').html(EnableDelete);
			$('tr.'+appendTo+':last').prev().find('input[type="text"]').css('border','0px');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]').css('background','none');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]').attr('readonly','readonly');
			
			/*$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(0)').parent().parent().attr('class','tooltip-demo tooltop-top');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(1)').parent().attr('class','tooltip-demo tooltop-top');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(0)').attr('rel','tooltip');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(1)').attr('rel','tooltip');
			$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(0)').attr('title',$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(0)').val());
			$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(1)').attr('title',$('tr.'+appendTo+':last').prev().find('input[type="text"]:eq(1)').val());
			//$('tr.'+appendTo+':last').prev().find('td:last').attr('class','tooltip-demo tooltop-left');
			//$('tr.'+appendTo+':last').prev().find('td:last').html(EnableDelete);
			*/
			var uniqueIdPrefix	= appendTo+'_'+uniqueNewCount;
			$('tr.'+appendTo+':last').find('input[type="text"]:eq(0)').attr('title','');
			$('tr.'+appendTo+':last').find('input[type="text"]:eq(1)').attr('title','');
			$('tr.'+appendTo+':last').find('td:eq(1) p input:eq(1)').attr('id','kolNameAuto_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('td:eq(1) p input:eq(2)').attr('id','kolIdAuto_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('td:eq(1) p input:eq(3)').attr('id','kolName_'+uniqueIdPrefix).addClass('autocompleteInputBox');
			$('#kolName_'+uniqueIdPrefix).autocomplete(surveyKolAutoCompleteOptions);
	
			$('tr.'+appendTo+':last').find('.influencerOrgName input[type="text"]').attr('id','org_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('.influencerCountry input[type="text"]').attr('id','country_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('.influencerState input[type="text"]').attr('id','state_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('.influencerCity input[type="text"]').attr('id','city_'+uniqueIdPrefix);
			$('tr.'+appendTo+':last').find('.influencerZipcode input[type="text"]').attr('id','postal_'+uniqueIdPrefix);
			$('#org_'+uniqueIdPrefix).autocomplete(orgNameAutoCompleteOptions);
			$('tr.'+appendTo+':last').find('td input').val('');
			initializeInputTooltip();
		}else{
			jAlert('Maximum of 10 answers are allowed for each question');
		}
	}
	function deleteRow(currentObj){
		$('.tooltip.in').hide();
		var appendTo	= $(currentObj).parent().parent().parent().parent().attr('class');
		var newCount	= $('#count_'+appendTo).attr('value');
		newCount--;
		$('#count_'+appendTo).val(newCount);
		$(currentObj).parent().parent().parent().parent().parent().remove();
	}
	function getKolDetails(thisObj,isRespondent){
		if(isRespondent){
			var kolId		= $('#respondentId').val();
		}else{
			var kolId		= $(thisObj).prev('input').val();
			var inputObj	= $(thisObj).parent().parent().next();
		}
		$.ajax({
			type: "post",
			dataType:"json",
			data:{
		        'kol_id':kolId
		    },
			url: '<?php echo base_url();?>surveys/getKolData',
			success: function(returnData){
				if(isRespondent){
					$('#respondent_country').val(returnData.Country);
					$('#respondent_state').val(returnData.State);
					$('#respondent_city').val(returnData.City);
					$('#respondent_postal').val(returnData.postal_code);
					$('#respondent_npi').val(returnData.npi_num);
					$('#respondent_org').val(returnData.org);
				}else{
					$(inputObj).find('input:eq(0)').val(returnData.org);
					inputObj	= $(inputObj).parent().find('.otherInfo');
					$(inputObj).find('input:eq(0)').val(returnData.Country);
					$(inputObj).find('input:eq(1)').val(returnData.State);
					$(inputObj).find('input:eq(2)').val(returnData.City);
					$(inputObj).find('input:eq(3)').val(returnData.postal_code);
				}
				var enableMIcroview	= '<div class="tooltip-demo tooltop-right microViewIcon kolMicroViewIcon" onclick="showMicroProfile('+kolId+',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Profile Snapshot">&nbsp;</a></div>';
				$(thisObj).parent().parent().parent().prev().html(enableMIcroview);
			}
		});
	}
	function showMicroProfile(kolId,thisEle){
		var pos = getElementAbsolutePos(thisEle);
		var offset = $(thisEle).offset();
		var height = $(thisEle).height();
		var xPos=pos.x-220;
		var yPos=offset.top + height - 215;//pos.y-190;
		$("#arraouHolder").css({'position': 'absolute','top':yPos,'left':xPos-11});
		$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
		$("#arraouHolder").show();
		$("#contentHolder").show();
		$(".profileContent").html("");
		$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		
		$(".profileContent").load(base_url+'kols/view_kol_micro/'+kolId,{},
				function(){	$('#contentHolder .profileContent').unblock(); }
			);
		return false;
	}
	function closeKolProfile(){
		$("#arraouHolder").hide();
		$(".profileContent").html("");
		$("#contentHolder").hide();
	}
	function saveAnswers(){
		var respondent		= $.trim($('#respondentName').val());
		var respondentOrg	= $.trim($('#respondent_org').val());
		if(respondent=='' || respondentOrg==''){
			jAlert('Fields marked with * are mandatory in respondent details and should not be empty');
			return false;
		}else{
			var formDate	= $('#surveyForm').serialize();
			$.ajax({
				type: "post",
				dataType:"json",
				data:formDate,
				url: '<?php echo base_url();?>surveys/save_answers1/0',
				success: function(returnData){
				}
			});
		}
	}
	function searchNames(thisObj){
		searchedNameRow	= $(thisObj).parent().parent().parent().attr('class');
		var data	= '';
		var arrRow	= new Array('name','orgname','country','state','city','postal');
		$.each($(thisObj).parent().parent().parent().find('input[type="text"]'),function(index, elementObj){
			//jAlert(arrRow[index]+'='+index+'-'+$(elementObj).val());
			if(index>0){
				data += '&'+arrRow[index]+'='+$(elementObj).val();
			}else{
				data = arrRow[index]+'='+$(elementObj).val();
			}
		});
		$(".searchedNamesContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#searchedNames").dialog("open");
		$.ajax({
			type: "post",
			dataType:"text",
			data:data,
			url: '<?php echo base_url();?>surveys/search_names',
			success: function(returnData){
				$('#searchedNames .profileContent').unblock();
				$(".searchedNamesContent").html(returnData);
			}
		});
	}
	function isRespondentAlreadySurveyed(){
		var thisObj	= $('#respondentName');
		var respondent	= $('#respondentName').val();
		$.ajax({
			type: "post",
			dataType:"json",
			data:{
		        'respondent':respondent
		    },
			url: '<?php echo base_url();?>surveys/isRespondentAlreadySurveyed/'+currentSurveyId,
			success: function(returnData){
				if(returnData.status=='exists'){
					/*$('#respondentName').val('');
					$('#respondent_org').val('');
					$('#respondent_country').val('');
					$('#respondent_state').val('');
					$('#respondent_city').val('');
					$('#respondent_postal').val('');
					$('#respondent_npi').val('');*/
					jConfirm("Survey for respondent already exists.. Do you want to view the existing survey?","Please confirm",function(r){
							if(r){
								var userId	= <?php echo $this->session->userdata('user_id');?>;
								respondentId	= 0;
								$.ajax({
									type: "post",
									dataType:"json",
									data:{
								        'respondent':respondent
								    },
									url: '<?php echo base_url();?>surveys/getRespondentId',
									success: function(returnData){
										respondentId	= returnData.id;
										window.location	= base_url+"surveys/view/<?php echo $surveyId;?>/"+respondentId+"/"+userId;
									}
								});
								}else{
									//javascript:history.go(-1);
									jAlert("Please choose different survey to add influencers");
									return false;
								}
						});
				}else{
					//getKolDetails(thisObj,true);
				}
			}
		});
	}
	$("#respondentName").live("focus",function(){
		 globalId = $(this).attr('id');
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
	});
	$("#respondentName").live("blur",function(){
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
	});
	$(".kolNameAutoComplete").live("focus",function(){
		 globalId = $(this).attr('id');
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
	});
	$(".kolNameAutoComplete").live("blur",function(){
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
		var respondent	= $.trim($('#respondentName').val());
		if(respondent==kolName && respondent!=''){
			jAlert('Respondent cannot nominate himself.');
			$(this).val('');
			var inputObj	= $(this).parent().parent().next();
			$(inputObj).find('input:eq(0)').val('');
			$(inputObj).find('input:eq(1)').val('');
			$(inputObj).find('input:eq(2)').val('');
			$(inputObj).find('input:eq(3)').val('');
			$(this).parent().parent().prev().html('');
		}
	});
	$(".organizationNameAutoComplete").live("focus",function(){
		 globalOrgId = $(this).attr('id');
	});
	$(".exapndCollapseSlider").live("click",function(){
		$(this).toggleClass('collapseSlider');
		$(this).parent().next("div").toggleClass("showOtherInfo");
	});
	function initializeInputTooltip(){
		$('td.tooltip-demo').tooltip({
	      selector: "input[rel=tooltip]",
	      placement:'top'
	    });
	}

	$(document).ready(function(){
		initializeInputTooltip();
		$('.chosenSelect').chosen({allow_single_deselect: false});
		$('#respondentName').autocomplete(surveyKolAutoCompleteOptions);
		$('#respondent_org').autocomplete(orgNameAutoCompleteOptions);
		$('.kolNameAutoComplete').each(function (i){
			$('#'+$(this).attr('id')).autocomplete(surveyKolAutoCompleteOptions);
		}); 
		$('.organizationNameAutoComplete').each(function (i){
			$('#'+$(this).attr('id')).autocomplete(orgNameAutoCompleteOptions);
		});
		$("#survey").chosen().change(function() {
			var surveyId	= $('#survey').val();
			var surveyName	= $('#survey_chzn li.result-selected').text();
			$("#surveyNameLabel").html(surveyName);
			currentSurveyId	= surveyId;
			changeSurvey(surveyId);
		});
		isRespondentAlreadySurveyed();
		function changeSurvey(surveyId){
			isRespondentAlreadySurveyed();
			$('#surveyDetails').html();
			$("#surveyDetails").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$("#surveyDetails").load(base_url+'surveys/survey_form/'+surveyId+'/1',{},
					function(){
						$('.kolNameAutoComplete').each(function (i){
							$('#'+$(this).attr('id')).autocomplete(surveyKolAutoCompleteOptions);
						}); 
						$('.organizationNameAutoComplete').each(function (i){
							$('#'+$(this).attr('id')).autocomplete(orgNameAutoCompleteOptions);
						});	
					});
		}
		function countWords(string){
			s = string;
			s = s.replace(/(^\s*)|(\s*$)/gi,"");
			s = s.replace(/[ ]{2,}/gi," ");
			s = s.replace(/\n /,"\n");
			return (s.split(' ').length);
		}
		$('#surveyForm').submit(function (){
			isRespondentAlreadySurveyed();
			var respondent		= $.trim($('#respondentName').val());
			var respondentOrg	= $.trim($('#respondent_org').val());
			
			var isEmpty			= false;
			var isZipNotValid	= false;
			var isNotAlpha		= false;
			var isSingleWord	= false;
			var isExceeds4Words		= false;
			var isNameLimitReached	= false;
			var nameLengthLimit	= 64;
			var isAlphaNumeric	= false;
			$("#surveyDetails").find("input[type='text'][readonly='readonly']").each(function (index){
				var zip		= /\d{5}$|^\d{5}-\d{4}/g;
				var alpha	= /^([a-zA-Z ]+)$/g;
				var alphaNumeric	= /^([a-zA-z]{1}[a-zA-Z0-9 ]+)$/g;
				
				//if($(this).hasClass('kolNameAutoComplete') || $(this).hasClass('organizationNameAutoComplete')){
				if($(this).hasClass('kolNameAutoComplete') || $(this).hasClass('state') || $(this).hasClass('city')){
					if($(this).val()==''){
						$(this).css('border','1px solid red');
						isEmpty	= true;
					}else{
						if($(this).hasClass('kolNameAutoComplete')){
							var name	= $(this).val();
							var noOfWords	= countWords(name);
							if(noOfWords<2){
								$(this).css('border','1px solid red');
								isSingleWord	= true;
							}
							if(noOfWords>4){
								$(this).css('border','1px solid red');
								isExceeds4Words	= true;
							}
							if(name.length>nameLengthLimit){
								$(this).css('border','1px solid red');
								isNameLimitReached	= true;
							}
						//	if(!alphaNumeric.test($(this).val())){
						//		$(this).css('border','1px solid red');
						//		isAlphaNumeric	= true;
						//	}
						}
					}
				}else if($(this).val()!=''){
					$(this).css('border-color','#bbb');
					var classname	= $(this).attr('class');
					switch(classname){
					/*	case "zipcode": 
									if(!zip.test($(this).val())){
										$(this).css('color','red');
										isZipNotValid	= true;
									}else{
										$(this).css('color','#333');
									}
								break;*/
						case "country":
						case "state":
						case "city":
									if(!alpha.test($(this).val())){
										$(this).css('color','red');
										isNotAlpha	= true;
									}else{
										$(this).css('color','#333');
									}
								break;
					}
				}
			});

			//if(respondent=='' || respondentOrg==''){
			if(respondent==''){
				//if(respondent==''){
					$('#respondentName').css('border','1px solid red');
				//}
				//if(respondentOrg==''){
				//	$('#respondent_org').css('border','1px solid red');
				//}
				jAlert('Fields marked with * are mandatory and should not be empty');
				return false;
			}
			if(respondent==''){
				jAlert('Respondent cannot be empty, please enter respondent name');
			}else if(isEmpty){
				jAlert('Fields marked with * are mandatory and should not be empty');
				return false;
			}else if(isSingleWord){
				jAlert('Single word name is not allowed. Please enter full name');
				return false;
			}else if(isExceeds4Words){
				jAlert('Maximum of 4 words are allowed.');
				return false;
			}else if(isNameLimitReached){
				jAlert('Maximum of 64 characters are allowed for name');
				return false;
			}else if(isAlphaNumeric){
				jAlert('Enter a valid name');
				return false;
			}
			
			var rowClassName	= '';
			var uniqueRowClassName	= '';
			var uniqueName		= '';
			var arrUniqueName	= [];
			var arrUniqueAnswers	= [];
			var duplicatesFound	= false;
			var isRespondentNominatedHimself	= false;
			var isFirstAnswerEmpty	= false;
			var isFirstAnswerMandatory	= false;
			$("#surveyDetails").find('tr').each(function (i){
				rowClassName	= $(this).attr('class');
				if(rowClassName==undefined){
					rowClassName	= 'undefined';
				}
				switch(rowClassName){
					case 'tableHeader':
					case 'undefined':
						//jAlert('skip');
					break;
					case 'tableSubHeader':
						var firstRow	= $(this).next();//.next();
						var nominee		= $.trim($(firstRow).find('input[type="text"]:eq(0)').val());
						var nomineeOrg	= $.trim($(firstRow).find('input[type="text"]:eq(1)').val());
						var nomineeState	= $.trim($(firstRow).find('input[type="text"]:eq(3)').val());
						var nomineeCity		= $.trim($(firstRow).find('input[type="text"]:eq(4)').val());
						totalAnsweres	= arrUniqueAnswers.length;
						if(totalAnsweres<1){
							//if(nominee=='' && nomineeOrg==''){
							if(nominee=='' && nomineeState=='' && nomineeCity==''){
								isFirstAnswerEmpty	= true;
							}
							//if(nominee=='' || nomineeOrg==''){
							if(nominee=='' || nomineeState=='' || nomineeCity==''){
								isFirstAnswerMandatory	 = true;
							}
						}
						break;
					
					default:
						var resCountry	= $.trim($('#respondent_country').val());
						var resState	= $.trim($('#respondent_state').val());
						var resCity		= $.trim($('#respondent_city').val());
						var resPostal	= $.trim($('#respondent_postal').val());
						var nominee		= $.trim($(this).find('input[type="text"]:eq(0)').val());
						var nomineeOrg	= $.trim($(this).find('input[type="text"]:eq(1)').val());
						var nomineeCountry	= $.trim($(this).find('input[type="text"]:eq(2)').val());
						var nomineeState	= $.trim($(this).find('input[type="text"]:eq(3)').val());
						var nomineeCity		= $.trim($(this).find('input[type="text"]:eq(4)').val());
						var nomineePostal	= $.trim($(this).find('input[type="text"]:eq(5)').val());
						//alert(respondent+"="+nominee);
						if(respondent==nominee && respondentOrg==nomineeOrg && resCountry==nomineeCountry && resState==nomineeState && resCity==nomineeCity && resPostal==nomineePostal){
						//	alert("true");
							isRespondentNominatedHimself	= true;
						}
						uniqueName		= ''; 
						$(this).css('background-color','#eee');
						$(this).find('input[type="text"]').each(function(index){
							uniqueName	+= $(this).val();
						});
						if(arrUniqueAnswers.length<1){
							//jAlert('update classname'+arrUniqueAnswers.length);
							uniqueRowClassName	= rowClassName;
						}
						//jAlert(arrUniqueAnswers+'-'+uniqueName+'-'+arrUniqueAnswers.length);
						if(uniqueRowClassName != rowClassName){
							//jAlert('new row'+uniqueRowClassName+'-'+rowClassName+'-'+arrUniqueAnswers.length);
							uniqueRowClassName	= rowClassName;
							arrUniqueAnswers	= new Array();
						}
						for(var count=0;count<(arrUniqueAnswers.length);count++){
							if(arrUniqueAnswers[count]==uniqueName){
								$(this).css('background-color','#ff9999');
								duplicatesFound	= true;
							}
						}
						arrUniqueAnswers.push(uniqueName);
					break;
				}
			});
			if(isFirstAnswerEmpty && arrUniqueAnswers[0]==''){
				jAlert('Survey should be filled with at least one answer');
				return false;
			}
			if(isFirstAnswerMandatory){
				jAlert('Fields marked with * are mandatory and should not be empty');
				return false;
			}
			if(isRespondentNominatedHimself){
				jAlert('Respondent cannot nominate himself');
				return false;
			}
			if(duplicatesFound){
				jAlert('Duplicate answer(s) not allowed.');
				return false;
			}
			if(isZipNotValid){
				jAlert('Enter proper postal code.');
				return false;
			}
			if(isNotAlpha){
				jAlert('Country, State and City should be alphabets.');
				return false;
			}
			
			return true;
		});

		var searchedNames = {
				title: "Search Result",
				modal: true,
				autoOpen: false,
				width: 798,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#searchedNames").dialog(searchedNames);
	});
</script>
<div id="surveyContainer" class="tooltip-demo tooltop-left">
<div id="addSurvey">
<form action="<?php echo base_url();?>surveys/save_answers/1/<?php echo $arrRespondent['id'];?>" method="post" name="survey_form" id="surveyForm">
<input type="hidden" name="active_survey_id" value="<?php echo $surveyId;?>" />
<?php
	//pr($arrRespondent);
	//pr($arrSurveys); ?>
	<div class="contentHeader"><span>Survey Response of <?php echo $arrRespondent['salutation'].' '.$arrRespondent['kolname'];?></span></div>
	<table style="margin-top:5px;">
		<caption style="font-weight: bold;">Respondent Details</caption>
		<tr>
			<th class="alignRight">Name:</th>
			<td>
				<input type="hidden" name="respondent_id" value="<?php if(isset($arrRespondent['id'])) echo $arrRespondent['id'];?>" id="respondentId"  />
				<input readonly="readonly" type="text" name="respondent_name" value="<?php if(isset($arrRespondent['kolname'])) echo $arrRespondent['kolname'];?>" id="respondentName" class="autocompleteInputBox" />
			</td>
			<th class="alignRight">Organization Name:</th>
			<td>
				<input readonly="readonly" type="text" name="respondent_org" id="respondent_org" class="autocompleteInputBox" value="<?php if(isset($arrRespondent['org'])) echo $arrRespondent['org'];?>" />
				<input type="hidden" name="respondent_npi" id="respondent_npi" readonly="readonly" value="<?php if(isset($arrRespondent['npi_num'])) echo $arrRespondent['npi_num'];?>" />
			</td>
			<td style="width:25%"></td>
		</tr>
		<tr>
			<th class="alignRight">Country:</th>
			<td><input readonly="readonly" type="text" name="respondent_country" id="respondent_country" value="<?php if(isset($arrRespondent['Country'])) echo $arrRespondent['Country'];?>" /></td>
			<th class="alignRight">State:</th>
			<td><input readonly="readonly" type="text" name="respondent_state" id="respondent_state" value="<?php if(isset($arrRespondent['State'])) echo $arrRespondent['State'];?>" /></td>
		</tr>
		<tr>
			<th class="alignRight">City:</th>
			<td><input readonly="readonly" type="text" name="respondent_city" id="respondent_city" value="<?php if(isset($arrRespondent['City'])) echo $arrRespondent['City'];?>" /></td>
			<th class="alignRight">Postal Code:</th>
			<td><input readonly="readonly" type="text" name="respondent_postal" id="respondent_postal" value="<?php if(isset($arrRespondent['postal_code'])) echo $arrRespondent['postal_code'];?>" /></td>
		</tr>
		<tr>
			<th class="alignRight">Select Survey:</th>
			<td colspan="3">
				<select id="survey" name="active_survey_id" class="chosenSelect">
					<?php foreach($arrActiveSurveys as $key=>$arrRow){
						echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
					}?>
				</select>
				<span id="tooltip-survey-select" class="map-info tooltop-bottom">
					<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Select the Survey name from the drop down to respond.</span>">&nbsp;</a>
				</span>
			</td>
		</tr>
	</table>
	<fieldset>
		<legend>
			<label id="surveyNameLabel">Survey <?php if(!empty($arrSurveyData['name'])) echo "on ".$arrSurveyData['name'];?></label>
			<span id="tooltip-survey-fill" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Type in a few letters and select the name from the drop down. If you want to add another name, click on the plus icon.<br><br>If you do not find any matches, you can enter all the details manually and the names will be saved as new entries.<?php echo $helpLink;?></span>">&nbsp;</a></span>
		</legend>
		<table id="surveyDetails">
			<?php
				$surveyIds	= '';
				$separator	= '';
				$count	= 1;
				$i		= 0;
				foreach($arrSurveys as $categoryName => $arrSurveys){
			?>
				<tr class="tableHeader">
					<th class="alignLeft" colspan="4"><?php echo $categoryName;?></th>
				</tr>
				<?php foreach($arrSurveys as $key => $arrRow){
						$totalAnswersCount	= sizeof($arrSurveyAnswers[$arrRow['id']]);
						$surveyIds .= $separator.$arrRow['id'];
						$separator	= ',';
						$i++;
						if($totalAnswersCount<1){
							$totalAnswersCount	= 1;
						}
					?>
					<tr class="tableSubHeader">
						<th class="alignTop borderBottom"><?php echo $i;?>)</th>
						<th class="borderBottom" colspan="3">
							<?php echo $arrRow['question'];?> &nbsp;
							<span class="tags">( Tags: <?php echo $arrTypes[$arrRow['type_id']].', '.$categoryName.', '.$arrRow['role'];?> )</span>
							<input type="hidden" id="count_<?php echo $arrRow['id'];?>" name="count_<?php echo $arrRow['id'];?>" value="<?php echo $totalAnswersCount;?>" />
							<input type="hidden" id="uniqueCount_<?php echo $arrRow['id'];?>" name="unique_count_<?php echo $arrRow['id'];?>" value="<?php echo $totalAnswersCount;?>" />
						</th>
					</tr>
					<tr class="<?php echo $arrRow['id'];?>">
						<td style="vertical-align: top;"></td>
						<td class="tooltip-demo tooltop-top">
							<div class="influencerName alignInline">
								<p class="surveyname tooltip-demo tooltop-top">
									<label>Name:<span class="required">*</span></label>
									<input type="hidden" name="kol_id" value="<?php echo $arrAnswers['kol_id'];?>" id="kolId" class="test" />
									<input type="hidden" name="kol_name_auto[]" value="<?php echo $arrAnswers['name'];?>" id="kolNameAuto_<?php echo $arrRow['id'].'_'.$answersCount;?>" class="checkAboveInputValue" />
									<input type="hidden" name="kol_id_<?php echo $arrRow['id'];?>[]" value="<?php echo $arrAnswers['kol_id'];?>" id="kolIdAuto_<?php echo $arrRow['id'].'_'.$answersCount;?>"  />
									<input rel="tooltip" title="<?php echo $arrAnswers['name'];?>" type="text" name="kol_name_<?php echo $arrRow['id'];?>[]" value="<?php echo $arrAnswers['name'];?>" id="kolName_<?php echo $arrRow['id'].'_'.$answersCount;?>" class="autocompleteInputBox kolNameAutoComplete" />
								</p>
							</div>
							<div class="influencerOrgName alignInline">
								<label>Organization:</label>
								<input rel="tooltip" title="<?php echo $arrAnswers['org_name'];?>" type="text" class="autocompleteInputBox organizationNameAutoComplete" value="<?php echo $arrAnswers['org_name'];?>" id="org_<?php echo $arrRow['id'].'_'.$answersCount;?>" name="org_<?php echo $arrRow['id'];?>[]" />
							</div>
							<div class="influencerActions">
								<div class="tooltip-demo tooltop-left exapndCollapseSlider">
									<a class="tooltipLink" rel="tooltip" href="#" onclick="return false;" title="Expand/Collapse Influencer information"> </a>
								</div>
								<!-- div class="advSearchIcon sprite_iconSet tooltip-demo tooltop-left">
									<a href="#" onclick="searchNames(this);return false;" rel="tooltip" class="tooltipLink" title="Search Names">&nbsp;</a>
								</div-->
								<label onclick="addMore(<?php echo $arrRow['id'];?>);"><div class="addNewAnswer actionIcon addIcon tooltip-demo tooltop-left"><a href="#" onclick="return false;" rel="tooltip" class="tooltipLink" title="Add another name">&nbsp;</a></div></label>
							</div>
							<div class="otherInfo">
								<div class="influencerCountry alignInline">
									<label>Country: </label><input type="text" class="country" id="country_<?php echo $arrRow['id'].'_'.$count;?>" name="country_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerState alignInline">
									<label>State:<span class="required">*</span> </label><input type="text" class="state" id="state_<?php echo $arrRow['id'].'_'.$count;?>" name="state_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerCity alignInline">
									<label>City:<span class="required">*</span> </label><input type="text" class="city" id="city_<?php echo $arrRow['id'].'_'.$count;?>" name="city_<?php echo $arrRow['id'];?>[]" />
								</div>
								<div class="influencerZipcode alignInline">
									<label>Postal Code: </label><input type="text" class="zipcode" id="postal_<?php echo $arrRow['id'].'_'.$count;?>" name="postal_<?php echo $arrRow['id'];?>[]" />
								</div>
							</div>
						</td>
					</tr>
				<?php 
				}
			}?>
			<input type="hidden" name="surveyIds" value="<?php echo $surveyIds;?>" />
		</table>
	</fieldset>
	<center>
		<!--<input type="button" value="Save" onclick="saveAnswers(); return false;" /> &nbsp; -->
		<input type="button" value="Cancel" onclick="javascript:history.go(-1); return false;" />
		<input type="submit" value="Submit" />
	</center>
</form>
	<!-- Container for the 'Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		</div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
</div>
<div id="searchedNames" class="microProfileDialogBox">
	<div class="searchedNamesContent profileContent"></div>
</div>