<?php
/**
 * Page to display the given rss feeds
 * 
 * @author Ramesh B
 * @since	
 * @created: 16-06-2011
 */
?>

<ul>
	<?php foreach($arrRssDetails as $rssDetails){?>
		<li>
			<a href="<?php echo $rssDetails['link'];?>" target="_new"><?php echo $rssDetails['title']; ?></a><br>
			<?php echo $rssDetails['desc'];?><br>
			<?php echo $rssDetails['date'];?>
		</li>
	<?php }?>
</ul>