<style>
td{
	vertical-align: top;
}
.exportOptionsContainer, #rightSideBarWrapper{
	display: none;
}
</style>
<form method="post" name="asscoiate_topics" action="<?php echo base_url();?>user_settings/save_associate_interaction_product_type_topic">
	<table>
		<tr>
			<td colspan="3"><center><input type="submit" value="Associate Topics" /></center></td>
		</tr>
		<tr>
			<td><?php 
				foreach($arrProducts as $key=>$value){
					echo '<input type="checkbox" name="product_ids[]" value="'.$key.'" />'.$value.'<br />';
				}
			?></td>
			<td valign="top"><?php 
				foreach($arrTypes as $key=>$arrRow){
					echo '<input type="checkbox" name="type_ids[]" value="'.$arrRow['id'].'" />'.$arrRow['name'].'<br />';
				}
			?></td>
			<td valign="top"><?php 
				foreach($arrTopics as $key=>$value){
					echo '<input type="checkbox" name="topic_ids[]" value="'.$key.'" />'.$value.'<br />';
				}
			?></td>
		</tr>
		<tr>
			<td colspan="3"><center><input type="submit" value="Associate Topics" /></center></td>
		</tr>
	</table>
</form>