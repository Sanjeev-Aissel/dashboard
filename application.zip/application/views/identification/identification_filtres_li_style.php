<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
?>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999; */
	/*	margin-top:0.7em;*/
		overflow:visible;
		/*padding-top:0.8em;*/
		padding-top:0px;
		position:relative;
	/*	margin-right: 10px;*/
		clear: both;
	}
	
	#searchLeftBar li#categotyKols{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
		padding-top:0.7em;
	}
/*	
	#searchLeftBar label.facet-toggle {
		background:transparent url(../images/sprite_facetsearch_v7.png) no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:11px;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
*/	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.kolSpecialty{
		margin-top: 4px;
	}
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px !important
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		margin-top: 0px;
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
	.hidden-filter{
		display: none;
	}
	span.showMore{
		display: inline-table;
		color: blue;
		cursor: pointer;
		display: block;
    	text-align: right;
	}
</style>
<div id="searchLeftBar">
<h3>
	<div class="funnelIcon sprite_iconSet"></div><?php echo lang('Refinedby.Refinedby')?>
	<div id="resetBttnContainer"><label onclick="resetFilters();" id="resetBttn" class="tooltip-demo tooltop-left"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Reset Filters">&nbsp;</a></label><?php echo lang('Refinedby.Reset')?></div>
</h3>
<div id="searchFiltersElements">
	<form id="rightSidebarForm" name="rightSidebarForm" action="">
		<ul id="categoriesContainer">
			<!-- <li class="category">
					<label for="ignoreMykols"  class="categoryName" style="float:left;border-bottom:0px; margin-right: 30px;">Exclude Contacts</label>
					<input id="ignoreMykols" type="checkbox" name="ignore_mykols" <?php if(isset($filters['ignore_mykols'])) echo "checked = 'checked'";?>>
			</li> -->
			<li class="category">
			<?php $endYear=date("Y");
			      $startYear = $endYear - 5;   
			?>
				<div>
					<div></div><label class="categoryName" style="float:left;border-bottom:0px; margin-right: 36px;"><?php echo lang('Refinedby.Project')?></label>
					<div >
						<select id="projectSelection" name="project" class="chosenSelect" style="width:180px;">
							<option yearRange="<?php echo $startYear.'-'.$endYear?>" value="">All Projects</option>
							<?php foreach($arrProjects as $project){
							    $year = $project['year_range'];
							     if($project['year_range']=='' || $project['year_range']==null){
					               $year = $startYear.'-'.$endYear;		         
							     }
							    ?>							
								<option yearRange="<?php echo $year ?>"  value="<?php echo $project['id'];?>"  <?php if($project['id'] == $filters['project']) echo "selected='selected'";?> ><?php echo $project['name'];?></option>
							<?php }?>
						</select>
					</div>
				</div>
			</li>
				
			<li id="customFilters" class="category">
				<div>
					<div></div><label class="categoryName" style="float:left;border-bottom:0px; margin-right: 5px;"><?php echo lang('Refinedby.SavedFilters')?></label>
					<div >
						<select id="savedFilterValue" name="saved_filter" data-placeholder="Choose saved filters..." style="width:180px;" class="chosen-select">
							<option></option>
							<?php foreach($customFilters as $customFilter){ ?>
				 				<option value='<?php echo $customFilter['id'];?>' <?php if($filters['saved_filter'] == $customFilter['id']){ echo 'selected="selected"';}?> ><?php echo $customFilter['name'];?></option>
							<?php }?>
						</select>
						 <div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
							<a title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
						</div> 
					</div>
				</div>
			</li>
			
			<!--  <li id="customFilters" class="category">
				<div></div><label for="includeSurvey"  class="categoryName" style="float:left;border-bottom:0px; margin-right: 30px;">Include Peer Nominations </label>
				<div style="border-bottom:1px solid #2283AE;">
					<input id="includeSurvey" type="checkbox" name="include_survey" <?php if(isset($filters['include_survey'])) echo "checked = 'checked'";?>>
				</div>
			</li>-->
						
			<li id="categotySpecialty" class="category">
				<div class="kolSpecialty sprite_iconSet"></div><label class="categoryName"><?php echo lang('Refinedby.Specialty')?></label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allSpecialties">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_specialties" id="allSpecialties" value="All Specialties" <?php if(isset($selectedSpecialties) && $selectedSpecialties!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Specialties</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allSpecialtyCount."(".round(($allSpecialtyCount/$allSpecialtyCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($allSpecialtyCount/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allSpecialtyCount)) echo $allSpecialtyCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedSpecialties);pr($arrKolsBySpecialtyCount);
					 	foreach($arrKolsBySpecialtyCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="specialty<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="specialty[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedSpecialties[$row['id']])){
											unset($selectedSpecialties[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allSpecialtyCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($row['count']/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsBySpecialtyCount[$row['id']]); $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedSpecialties) && $selectedSpecialties!=null){foreach($selectedSpecialties as $id=>$name){?>
						<tr class="specialty<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="specialty[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allSpecialtyCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsBySpecialtyCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php $i=0;//pr($selectedSpecialties);pr($arrKolsBySpecialtyCount);
					 	foreach($arrKolsBySpecialtyCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="specialty<?php echo $row['id'];?>  hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="specialty[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedSpecialties[$row['id']])){
											unset($selectedSpecialties[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allSpecialtyCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($row['count']/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					</table>
					<?php if(count($arrKolsBySpecialtyCount) > 0) {?>
						<span class="showMore"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div>
					<input type="text" name="specialty_name" class="autocompleteInputBox" id="specialtyName" value="Enter Specialty" title=""/><input type="hidden" name="specialty_id" id="specialtyId" value="" />
				</div>
			</li>
			
			<li id="categotyRegion" class="category">
				<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName"><?php echo lang('Refinedby.Region')?></label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allRegions">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_regions" id="allRegions" value="All Regions" <?php if(isset($selectedRegions) && $selectedRegions!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Regions</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allRegionCount."(".round(($allRegionCount/$allRegionCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($allRegionCount/$allRegionCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedRegions);pr($arrKolsByRegionCount);
					 	foreach($arrKolsByRegionCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="region<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="region[]" class="regionElement hideCheckbox" id="region<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedRegions[$row['id']])){
											unset($selectedRegions[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allRegionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($row['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsByRegionCount[$row['id']]); $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedRegions) && $selectedRegions!=null){foreach($selectedRegions as $id=>$name){?>
						<tr class="region<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="region[]" class="regionElement hideCheckbox" id="region<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByRegionCount[$id]['count']."(".round(($arrKolsByRegionCount[$id]['count']/$allRegionCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($arrKolsByRegionCount[$id]['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsByRegionCount)) echo $arrKolsByRegionCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsByRegionCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php 
					 	foreach($arrKolsByRegionCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="region<?php echo $row['id'];?>  hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="region[]" class="regionElement hideCheckbox" id="region<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedRegions[$row['id']])){
											unset($selectedRegions[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allRegionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($row['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					</table>
					<?php if(count($arrKolsByRegionCount) > 0) {?>
						<span class="showMore"><?php echo lang('ShowMore');?></span >
					<?php }?>
<!-- 					<div class="filterSearchIcon"></div> -->
<!-- 					<input type="text" name="region_name" class="autocompleteInputBox" id="regionName" value="Enter Region" title=""/><input type="hidden" name="region_id" id="regionId" value="" /> -->
					<div class="filterSearchIcon"></div>
					<input type="text" name="region_type" class="autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" />
				</div>
			</li>
			
			<li id="categotyCountry" class="category">
				<div class="countryIcon sprite_iconSet"></div><label class="categoryName"><?php echo lang('Refinedby.Country')?></label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allCountries">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries" value="All Countries" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Countries</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allCountryCount."(".round(($allCountryCount/$allCountryCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($allCountryCount/$allCountryCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedCountries);pr($arrKolsByCountryCount);
					 	foreach($arrKolsByCountryCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="country<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="country[]" class="countryElement hideCheckbox" id="country<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedCountries[$row['id']])){
											unset($selectedCountries[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allCountryCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($row['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsByCountryCount[$row['id']]); $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedCountries) && $selectedCountries!=null){foreach($selectedCountries as $id=>$name){?>
						<tr class="country<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="country[]" class="countryElement hideCheckbox" id="country<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByCountryCount[$id]['count']."(".round(($arrKolsByCountryCount[$id]['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrKolsByCountryCount[$id]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsByCountryCount)) echo $arrKolsByCountryCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsByCountryCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php
					 	foreach($arrKolsByCountryCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="country<?php echo $row['id'];?> hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="country[]" class="countryElement hideCheckbox" id="country<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedCountries[$row['id']])){
											unset($selectedCountries[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allCountryCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($row['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					
					</table>
					<?php if(count($arrKolsByCountryCount) > 0) {?>
						<span class="showMore"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div>
					<input type="text" name="country_name" class="autocompleteInputBox" id="countryName" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
				</div>
			</li>
			<li id="categoryState" class="category">
				<div class="refineByStateImage sprite_iconSet"></div><label class="categoryName">State</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allStates">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_states" id="allStates" value="All States" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All States</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allStateCount."(".round(($allStateCount/$allStateCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($allStateCount/$allStateCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($arrKolsByStateCount);//pr($arrKolsByCountryCount);
					 	foreach($arrKolsByStateCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="country<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="state[]" class="stateElement hideCheckbox" id="state<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedStates[$row['id']])){
											unset($selectedStates[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/><?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allStateCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($row['count']/$allStateCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsByStateCount[$row['id']]); 
                                        $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedStates) && $selectedStates!=null){ foreach($selectedStates as $id=>$name){?>
						<tr class="country<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="state[]" class="stateElement hideCheckbox" id="state<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/><?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByStateCount[$id]['count']."(".round(($arrKolsByStateCount[$id]['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($arrKolsByStateCount[$id]['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsByStateCount)) echo $arrKolsByStateCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsByStateCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php
					 	foreach($arrKolsByStateCount as $row){ ?>
					 	<?php if($row['name']!=''){ //pr($row); ?>

					 		<tr class="country<?php echo $row['id'];?> hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="state[]" class="stateElement hideCheckbox" id="state<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedStates[$row['id']])){
											unset($selectedStates[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/><?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allStateCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($row['count']/$allStateCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					
					</table>
					<?php if(count($arrKolsByStateCount) > 1) {?>
						<span class="showMore" id="country"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div>
					<div class="filterSearchIcon"></div><input type="text" name="state_name" class="autocompleteInputBox" id="stateName" value="Enter State" title=""/><input type="hidden" name="state_id" id="stateId" value="">
				</div>
			</li>	
			<li id="categotyCity" class="category">
				<div class="refineByCityImage sprite_iconSet"></div><label class="categoryName"><?php echo lang('Refinedby.City')?></label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allCities">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCities" value="All Cities" <?php if(isset($selectedCities) && $selectedCities!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Cities</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allCityCount."(".round(($allCityCount/$allCityCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($allCityCount/$allCityCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCityCount)) echo $allCityCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedCities);pr($arrKolsByCityCount);
					 	foreach($arrKolsByCityCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="city<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="city[]" class="cityElement hideCheckbox" id="city<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedCities[$row['id']])){
											unset($selectedCities[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allCityCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($row['count']/$allCityCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsByCityCount[$row['id']]); $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedCities) && $selectedCities!=null){foreach($selectedCities as $id=>$name){?>
						<tr class="city<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="city[]" class="cityElement hideCheckbox" id="city<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByCityCount[$id]['count']."(".round(($arrKolsByCityCount[$id]['count']/$allCityCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($arrKolsByCityCount[$id]['count']/$allCityCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsByCityCount)) echo $arrKolsByCityCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsByCityCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php
					 	foreach($arrKolsByCityCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="city<?php echo $row['id'];?> hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="city[]" class="cityElement hideCheckbox" id="city<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedCities[$row['id']])){
											unset($selectedCities[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allCityCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($row['count']/$allCityCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					
					</table>
					<?php if(count($arrKolsByCityCount) > 0) {?>
						<span class="showMore"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div>
					<input type="text" name="city_name" class="autocompleteInputBox" id="cityName" value="Enter City" title=""/><input type="hidden" name="city_id" id="cityId" value="" />
				</div>
			</li>
			
			<li id="categotyIndustry" class="category">
				<div class="refineByIndustryImage sprite_iconSet"></div><label class="categoryName"><?php echo lang('Refinedby.Industry')?></label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allIndustries">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allIndustries" value="All Industries" <?php if(isset($selectedIndustries) && $selectedIndustries!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Industries</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allIndustryCount."(".round(($allIndustryCount/$allIndustryCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allIndustryCount)) echo round(($allIndustryCount/$allIndustryCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allIndustryCount)) echo $allIndustryCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedIndustries);pr($arrKolsByIndustryCount);
					 	foreach($arrKolsByIndustryCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="industry<?php echo $row['id'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="industry[]" class="industryElement hideCheckbox" id="industry<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedIndustries[$row['id']])){
											unset($selectedIndustries[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allIndustryCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allIndustryCount)) echo round(($row['count']/$allIndustryCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php unset($arrKolsByIndustryCount[$row['id']]); $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedIndustries) && $selectedIndustries!=null){foreach($selectedIndustries as $id=>$name){?>
						<tr class="industry<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="industry[]" class="industryElement hideCheckbox" id="industry<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $name;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByIndustryCount[$id]['count']."(".round(($arrKolsByIndustryCount[$id]['count']/$allIndustryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allIndustryCount)) echo round(($arrKolsByIndustryCount[$id]['count']/$allIndustryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsByIndustryCount)) echo $arrKolsByIndustryCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php unset($arrKolsByIndustryCount[$id]); }}?>
					
					<!-- Display remaing elements as hidden for show more option -->
					<?php
					 	foreach($arrKolsByIndustryCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="industry<?php echo $row['id'];?> hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="industry[]" class="industryElement hideCheckbox" id="industry<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedIndustries[$row['id']])){
											unset($selectedIndustries[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/>&nbsp;<?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allIndustryCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allIndustryCount)) echo round(($row['count']/$allIndustryCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }}?>
					
					
					</table>
					<?php if(count($arrKolsByIndustryCount) > 0) {?>
						<span class="showMore"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div>
					<input type="text" name="industry_name" class="autocompleteInputBox" id="industryName" value="Enter Industry" title=""/><input type="hidden" name="industry_id" id="industryId" value="" />
				</div>
			</li>
                        <li id="categotyOrganization" class="category">
				<div class="navLinkOrganizations sprite_iconSet"></div><label class="categoryName">Organization</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div style="display:block;">
				<table class="clear" id="orgID">
					<tr class="allOrgs">
				 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_orgs" id="allOrgs" value="All Organizations" <?php if(isset($selectedOrgs) && $selectedOrgs!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Organizations</td>
				 		<td class="histoGram">
				 			<div class="filterBar">
								<div class="progress" title="<?php echo $allOrgCount."(".round(($allOrgCount/$allOrgCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($allOrgCount/$allOrgCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
				 		</td>
				 		<td><?php if(isset($allOrgCount)) echo $allOrgCount; else echo 0;?></td>
				 	</tr>
					<?php $i=0; //pr($arrKolsByOrgCount); exit;
					 	foreach($arrKolsByOrgCount as $orgCountDetails){ ?>
					 	<?php
					 		if($orgCountDetails['name']!=''){?>
					 	<tr class="org<?php echo $orgCountDetails['id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgCountDetails['id'];?>" value="<?php echo $orgCountDetails['id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedOrgs) && sizeof($selectedOrgs)>0 && $selectedOrgs!=null){
										if(in_array($orgCountDetails['name'], $selectedOrgs)) {?>
											checked="checked"
									<?php 
										$key = array_search($orgCountDetails['name'], $selectedOrgs);
										if(array_key_exists($key, $selectedOrgs))
											unset($selectedOrgs[$key]);
										//$selectedOrgs=array_values($selectedOrgs);
							 			}
							 		}?>
								/><?php echo $orgCountDetails['name'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $orgCountDetails['count']."(".round(($orgCountDetails['count']/$allOrgCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($orgCountDetails['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php echo $orgCountDetails['count'];?></td>
					 	</tr>
					<?php unset($arrKolsByOrgCount[$orgCountDetails['id']]);  $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgs) && $selectedOrgs!=null){foreach($selectedOrgs as $orgId => $orgName){?>
						<tr class="org<?php echo $orgId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgId;?>" value="<?php echo $orgId;?>" onclick="doSearchFilter1(-1,this)" checked="checked" /> <?php echo $orgName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByOrgCount[$orgId]['count']."(".round(($arrKolsByOrgCount[$orgId]['count']/$allOrgCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($arrKolsByOrgCount[$orgId]['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($orgId, $arrKolsByOrgCount)) echo $arrKolsByOrgCount[$orgId]['count']; else echo 0;?></td>
						</tr>
                                                <?php unset($arrKolsByOrgCount[$orgId]); }}?>
					<!-- Display remaing elements as hidden for show more option -->
					<?php
					 	foreach($arrKolsByOrgCount as $row){ ?>
					 	<?php if($row['name']!=''){?>

					 		<tr class="org<?php echo $row['id'];?> hidden-filter">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $row['id'];?>" value="<?php echo $row['id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedOrgs[$row['id']])){
											unset($selectedOrgs[$row['id']]);
											echo 'checked="checked"';
										}
									?> 
									/><?php echo $row['name'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $row['count']."(".round(($row['count']/$allOrgCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($row['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $row['count'];?></td>
					 		</tr>

					<?php }} 
					
					?>
					    
					
					</table>
                                        <?php if(count($arrKolsByOrgCount) > 0) {?>
						<span class="showMore" id="org"><?php echo lang('ShowMore');?></span >
					<?php }?>
					<div class="filterSearchIcon"></div><input type="text" name="organization" class="autocompleteInputBox" id="organization" value="Enter Organization" title=""/><input type="hidden" name="organization_id" id="organizationId" value="" />
					</div>
			</li>
				
		</ul>
	</form>
</div>
</div>
<script type="text/javascript">
//Hide or Show the Category checkbox's 
function toggleCategory(toggleFlag,thisEle){
	var parentId=$(thisEle).parent().attr("id");
	if($(thisEle).hasClass('expanded')){
		$(thisEle).removeClass('expanded');
		$(thisEle).addClass('collapsed');
// 		$('#searchLeftBar #'+parentId+' > div').hide();
		$(thisEle).next().hide();
	}
	else {
		$(thisEle).removeClass('collapsed');
		$(thisEle).addClass('expanded');
// 		$('#searchLeftBar #'+parentId+' > div').show();
		$(thisEle).next().show();
	}
}

//Autocomplet Options for the 'role' field 
var SpecialtyNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var selText = $(event).children('.specialties').html();
		var selId = $(event).children('.specialties').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#specialtyName').val(selText);
		$('#specialtyId').val(selId);
		if(event.length>20){
			if(event.substring(0,21)=="No results found for "){
				return false;
			}else{
				$('#specialtyName').val(selText);
				var filterElem = '<tr class="specialty'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="specialty'+selId+'" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotySpecialty tbody").append(filterElem);
				reloadSection();
			}
		}else{
			$('#specialtyName').val(selText);
			var filterElem = '<tr class="specialty'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="specialty'+selId+'" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
			$("#categotySpecialty tbody").append(filterElem);
			reloadSection();
		}
	}
};	

// Autocomplet Options for the 'country' field
var countryNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var selText = $(event).children('.countries').html();
		var selId = $(event).children('.countries').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#countryName').val(selText);
		$('#countryId').val(selId);
		if(event.length>20){
			if(event.substring(0,21)=="No results found for "){
				return false;
			}else{
				$('#countryName').val(selText);
				var filterElem = '<tr class="country'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="country'+selId+'" class="countryElement hideCheckbox" name="country[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotyCountry tbody").append(filterElem);
				reloadSection();
			}
		}else{
			$('#countryName').val(selText);
			var filterElem = '<tr class="country'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="country'+selId+'" class="countryElement hideCheckbox" name="country[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
			$("#categotyCountry tbody").append(filterElem);
			reloadSection();
		}
	}
};	

// Autocomplet Options for the 'state' field
var regionNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>kols/get_region',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var selText = $(event).children('.regionTypes').html();
		var selId = $(event).children('.regionTypes').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#regionType').val(selText);
		if(selText.length>20){
			if(selText.substring(0,21)=="No results found for "){
				return false;
			}else{
				$('#regionType').val(selText);
				var filterElem = '<tr class="region'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="region'+selId+'" class="regionElement hideCheckbox" name="region[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotyRegion tbody").append(filterElem);
				reloadSection();
			}
		}else{
			$('#regionType').val(selText);
			var filterElem = '<tr class="region'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="region'+selId+'" class="regionElement hideCheckbox" name="region[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
			$("#categotyRegion tbody").append(filterElem);
			reloadSection();
		}
	}
};

	//Autocomplet Options for the 'state' field
	var cityNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var selId = $(event).children('.autocompleteCityId').html();
			var selText = $(event).children('.cityName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#cityName').val(selText);
			$('#cityId').val(selId);
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#cityName').val(selText);
					var filterElem = '<tr class="city'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="city'+selId+'" class="cityElement hideCheckbox" name="city[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
					$("#categotyCity tbody").append(filterElem);
					reloadSection();
				}
			}else{
				$('#cityName').val(selText);
				var filterElem = '<tr class="city'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="city'+selId+'" class="cityElement hideCheckbox" name="city[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotyCity tbody").append(filterElem);
				reloadSection();
			}
		}
	};
	
	//Autocomplet Options for the 'state' field
	var stateNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var selId = $(event).children('.autocompleteStateId').html();
			var selText = $(event).children('.stateName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#stateName').val(selText);
			$('#stateId').val(selId);
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#stateName').val(selText);
					var filterElem = '<tr class="state'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="state'+selId+'" class="stateElement hideCheckbox" name="state[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
					$("#categotyRegion tbody").append(filterElem);
					reloadSection();
				}
			}else{
				$('#stateName').val(selText);
				var filterElem = '<tr class="state'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="state'+selId+'" class="stateElement hideCheckbox" name="state[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotyRegion tbody").append(filterElem);
				reloadSection();
			}
		}
	};

//Autocomplet Options for the 'industry' field
var industryNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>identifications/get_industry_names',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var selText = $(event).children('.industries').html();
		var selId = $(event).children('.industries').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#industryName').val(selText);
		$('#industryId').val(selId);
		if(event.length>20){
			if(event.substring(0,21)=="No results found for "){
				return false;
			}else{
				$('#industryName').val(selText);
				var filterElem = '<tr class="industry'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="industry'+selId+'" class="industryElement hideCheckbox" name="industry[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
				$("#categotyIndustry tbody").append(filterElem);
				reloadSection();
			}
		}else{
			$('#industryName').val(selText);
			var filterElem = '<tr class="industry'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="industry'+selId+'" class="industryElement hideCheckbox" name="industry[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
			$("#categotyIndustry tbody").append(filterElem);
			reloadSection();
		}
	}
};

//Autocomplet Options for the 'Organizer' field 
var organizationNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var selText = $(event).children('.organizations').html();
			var selId = $(event).children('.organizations').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#organization').val(selText);
			$('#organizationId').val(selId);
			if(event.length>20){
				if(event.substring(0,21)=="No results found for "){
					return false;
				}else{
					$('#organization').val(selText);
                                            var filterElem = '<tr class="org'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="org'+selId+'" class="orgElement hideCheckbox" name="org_ids[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                                            $("#categotyOrganization tbody").append(filterElem);
                                            reloadSection();
				}
			}else{
				$('#organization').val(selText);
                                    var filterElem = '<tr class="org'+selId+'"><td class="textAlignRight"><input type="checkbox" checked="checked" value="'+selId+'" id="org'+selId+'" class="orgElement hideCheckbox" name="org_ids[]">&nbsp;'+selText+'</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                                    $("#categotyOrganization tbody").append(filterElem);
                                    reloadSection();
			}
		}
	};	

function resetFilters(){
	$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
		$(this).removeAttr('checked');
	});
	$.each($("#categoriesContainer input[type='text']"), function() {
		$(this).val('');
	});
	$('#projectSelection').val('');
   $('#projectSelection').trigger("chosen:updated");
    $('#savedFilterValue').val('');
//    $('#savedFilterValue').trigger("chosen:updated");
	reloadSection();
}

$(document).ready(function(){
	//$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
	$('#categoriesContainer input:checked').each(function (index){
		$(this).parent().parent().css('background-color','#D3DFED');
	});

	$('#searchFiltersElements ul li table tr').click(function (){
		isProjectChanged = 1;
		var className = $(this).attr('class');
		if(className == 'allSpecialties' || className == 'allRegions' || className == 'allCountries' || className == 'allStates' || className == 'allCities' || className == 'allIndustries' || className == 'allOrgs'){
			$(this).parent().children('tr').each(function(){
				var input = $(this).children('td:first').children('input');
				$(this).css('background-color','#ffffff');
				$(input).removeAttr('checked');
			});
		}
		var input = $(this).children('td:first').children('input');
		if($(input).attr('checked')=="checked"){
			$(this).css('background-color','#ffffff');
			$(input).removeAttr('checked');
			reloadSection();
		}else{
			$(this).css('background-color','#D3DFED');
			$(input).attr('checked','checked');
			reloadSection();
		}
	});

	// Trigger the Autocompleter for 'education' field of  Event'
	a = $('#specialtyName').autocomplete(SpecialtyNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'country' field of  Event'
	a = $('#countryName').autocomplete(countryNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'state' field of  Event'
	a = $('#regionType').autocomplete(regionNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'city' field of  Event'
	a = $('#cityName').autocomplete(cityNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'state' field of  Event'
	a = $('#stateName').autocomplete(stateNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'industry' field of  Event'
	a = $('#industryName').autocomplete(industryNameAutoCompleteOptions);
        
        // Trigger the Autocompleter for 'organizer' field of  Event'
	a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);


	$('#countryName').focus(function(){
		$('#countryName').val(' ');
		
	});
	       
	$('#countryName').blur(function(){
		$('#countryName').val('Enter Country ');
		
	});

	$('#cityName').focus(function(){
		$('#cityName').val(' ');
		
	});
	       
	$('#cityName').blur(function(){
		$('#cityName').val('Enter City ');
		
	});

	$('#stateName').focus(function(){
		$('#stateName').val(' ');
		
	});
	       
	$('#stateName').blur(function(){
		$('#stateName').val('Enter State ');
		
	});

	$('#regionType').focus(function(){
		$('#regionType').val(' ');
		
	});
	       
	$('#regionType').blur(function(){
		$('#regionType').val('Enter Region');
		
	});

	$('#specialtyName').focus(function(){
		$('#specialtyName').val(' ');
		
	});
	       
	$('#specialtyName').blur(function(){
		$('#specialtyName').val('Enter Specialty');
		
	});

	$('#industryName').focus(function(){
		$('#industryName').val(' ');
		
	});
	       
	$('#industryName').blur(function(){
		$('#industryName').val('Enter Industry');
		
	});
        
	$('#organization').focus(function(){
		$('#organization').val(' ');
		
	});
	       
	$('#organization').blur(function(){
		$('#organization').val('Enter Organization');
		
	});

   if($('#countryName').val()=='Enter Country' || $('#regionType').val()=='Enter Region' || $('#specialtyName').val()=='Enter Specialty' || $('#cityName').val()=='Enter City' || $('#stateName').val()=='Enter State' || $('#industryName').val()=='Enter Industry' || $('#organization').val()=='Enter Organization'){
		$('.autocompleteInputBox').css({color:'grey'});
   }
       

	$(".showMore").on('click',function(){
		var numc = 0;
		var obj = this;
		var chk = '';
		var table = $(this).prev();
		$(this).prev().find("tr").each(function(){
			if($(this).hasClass('hidden-filter')){
				if(numc < 5){
					$(this).removeClass('hidden-filter');
					numc++;
				}
				chk="yes";
			}
		});

		if(chk==''){
			$(obj).hide();
		}

		$(table +'tr.private').ht
	});

	$("#savedFilterValue").change(function(){
		activeCustmFilters(this);
	});

	$("#projectSelection").change(function(){
		$("#globalYear").val($("option:selected", this).attr("yearrange"));
		var yearRange = $("#globalYear").val();
		var splitYear = yearRange.split('-');
		defaultStartYear = splitYear[0];  
	    defaultEndYear = splitYear[1];
	    isProjectChanged = 1;
		reloadSection();
	});

	$("input[name='include_survey']").on('change',function(){
		if($(this).attr('checked') == 'checked'){
			$("input[name='include_survey2']").attr('checked','checked');
		}else{
			if($("input[name='wyn']").val() == 'yes' && $("input[name='surveys_all']").val() > 0){
				$("input[name='include_survey']").attr('checked','checked');
				showCustomWeightage();
				/*setTimeout(delay, 30);
				$("#customWeightage input[name='surveys_all']").val(0);
				$("#customWeightage input[name='surveys_all']").parent().slider( "value",0);
				$("#customWeightage input[name='surveys_all']").parent().children('.selectedHighlight').width(0+'%');
				$("#customWeightage input[name='surveys_all']").parent().children('.max').html(0).position({
			        my: 'center top',
			        at: 'center top',
			        of: $("#customWeightage input[name='surveys_all']").next(),
			        offset: "0, 10"
			    });*/
				return false;
			}
			$("input[name='include_survey2']").removeAttr('checked');
		}
		reloadSection();
	});
	$("input[name='ignore_mykols']").on('change',function(){
		reloadSection();
	});
});
</script>