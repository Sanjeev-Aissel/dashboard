<script src="<?php echo base_url().MODULES_ASSETS;?>configurations/js/configuration.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<script type="text/javascript">
var role_id='<?php echo $product_id =$this->uri->segment(3);?>';
$(document).ready(function(){	
		//Uncheck select-all checkbox if one of checkbox is checked
		$("#module1 input[type='checkbox']").live("change",function(){
		    if(!($(this).is(":checked"))){
		        $("#select-all-connections").removeAttr("checked");
		    }
		});
		$("#set_permission").validate({
			rules: {
				role_name: "required",
				role_desc: "required",
			},
			messages: {
				role_name: {
					required: "Please Enter Role Name",
				},
				role_desc: {
					required: "Please Enter short description of Role",
				}
			}
		});	
});
</script>
<section class="features_table">
	<div class="container ">
	<h3 class="page_title"><?php if($role_details==null) echo "Add Role"; else echo "Update Role";?></h3>
		<div style="margin: 10px 0px 10px 293px;display:flow-root;">
		<?php if($role_details['id']>0){?>
		<select name="clone_role_id" id="clone_role_id" class="form-control required"  style="width:18%;display: inline">
				<option value="">--Select Role--</option>
				<?php foreach($roles as $role){	?>
				<option value="<?php echo $role['id'];?>">
						<?php echo $role['name'];?>
					</option>
				<?php }?>
			</select>
			<a class="btn btn-default" onclick="clone_role()" style="margin-bottom: 4px;">Clone</a>
		<?php }?>	
			<div class="pull-right">
			<a class="btn btn-default" onclick="add_module_action()"><i class="glyphicon glyphicon-plus"></i>Action</a>
			</div>
		</div>
		<form id="set_permission" method="post">
		<input type="hidden" id="role_id" name="role_id" value="<?php echo $role_details['id'];?>">
		<div class="form-group row" id="">
				<label class="col-sm-2 col-form-label">Role-name:</label>
				<div class="col-sm-10">
					<input type="text" name="role_name" value="<?php echo $role_details['name'];?>" id="role_name" class="form-control">
		    			<div id="role_duplicate" style="margin-top: 14px;">

		    			</div>
		    	</div>
		</div>
		<div class="form-group row" id="">
				<label class="col-sm-2 col-form-label">Description:</label>
				<div class="col-sm-10">
					<textarea name="role_desc" class="form-control" id="role_desc" rows="5"><?php echo trim($role_details['description']);?></textarea>
			    </div>
		</div>
		<div class="form-group row" id="">
				<label class="col-sm-2 col-form-label">Permissions:</label>
				<div class="col-sm-10">
				<table class="table table-curved">
				<thead>
					<tr class="features-table">
						<th >Modules</th>
						<?php foreach ($role_actions as $action){?>
						<th> 
							<span><strong><?php echo $action;?></strong></span>
						</th>
						<?php }?>
						<th>
							<i class="glyphicon glyphicon-check"></i>
							<span><strong>All</strong></span>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$actions=array_map('strtolower',$role_actions);
					array_push($actions,"all");
					foreach($modules as $module){	?>
					<tr id="<?php echo $module['id'];?>">
						<td><?php echo $module['module_name'];?></td>
						<?php foreach($actions as $key=>$value){ ?>							
						<td>    
							<label class="custom-control custom-checkbox">	
							<input type="checkbox" id="<?php echo $module['id'];?>_<?php echo $value;?>" class="actions custom-control-input"
							<?php if($value != "all") {
							?>
							name="modules[]" value="<?php echo $module['id'];?>_<?php echo $value;?>" 
							<?php }
							else{
							?>
							 onclick="toggle_module_actions('<?php echo $module['id'];?>') ;
									<?php }?>
									<?php if(($rolesPermDetails[$module['id']][$value])==1) 
										echo "checked";?>					
									">
							<span class="custom-control-indicator"></span>
							</label>
						</td>
						<?php }?>
					</tr>	
					<?php }?>
				</tbody>
				</table>
		     </div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 col-form-label"></label>
	   		<div class="col-sm-10">
	     		<button type="submit" class="btn btn-primary" onclick="save_permission();return false;">Save permissions</button>
	         	<a type="button" class="btn btn-primary" href="<?php echo base_url();?>configurations/configurations/client_roles">Cancel</a>
	    	</div>
		</div>
		</form>
	</div>
	<div id="userContainer" class="microViewLoading">
		<div class="modalcontent"></div>
	</div>
</section>
<script src="<?php echo base_url().MODULES_ASSETS;?>configurations/js/configuration.js"></script>