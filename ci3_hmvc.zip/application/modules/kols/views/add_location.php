<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<link  href="<?php echo base_url().MODULES_ASSETS;?>kols/css/kols.css" rel="stylesheet">
<?php echo $html_form;?>
<div id="msgBox">
</div>
<script>
$(document).ready(function() {
		$("#saveKolAssignClientForm").validate({
			rules: {
		        address1: {
		            required: true
		        },
		        country_id: {
		            required: true
		        },
		        address_type: {
		            required: true
		        },
		        organization: {
		            required: true
		        }
			},
			messages: {
		        address1: {
		            required: "Required"
		        },
		        country_id: {
		            required: "Required"
		        },
		        address_type: {
		            required: "Required"
		        },
		        organization: {
		            required: "Required"
		        }
			}
		});		
});
var organizationNameAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/kols/get_organization_names/1',
					<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {                    	
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    console.log(selId);
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#saveKolLocationForm #organizationLocation').val(selText);
                    $('input[name="org_institution_id"]').val(selId);
//                     $('#saveKolLocationForm #org_institution_id').val(selId);
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#saveKolLocationForm #organizationLocation').val(trim(split(' ', selText)[4]));
                            return false;
                        }
                    }                       
                }
    };
a = $('#saveKolLocationForm #organizationLocation').autocomplete(organizationNameAutoCompleteOptions);
function getStatesByCountryIdLocation() {
    var countryId = $('#saveKolLocationForm #country_id').val();
    var params = "country_id=" + countryId;
    $("#saveKolLocationForm #state_id").html("<option value=''>-- Select State --</option>");
    $("#saveKolLocationForm #city_id").html("<option value=''>-- Select City --</option>");
    var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
    $.ajax({
        url: "<?php echo base_url() ?>helpers/country_helpers/get_states_by_countryid/",
        dataType: "json",
        data: params,
        type: "POST",
        success: function (responseText) {
        	var selectedIndex	= '';
            $.each(responseText, function (key, value) {
				 $('#saveKolLocationForm #state_id').append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
            });
        },
        complete: function () {
            $("#saveKolLocationForm #loadingStates").hide();
        }
    });
}
function getCitiesByStateIdLocation() {
    $("#saveKolLocationForm #city_id").html("<option value=''>-- Select City</option>");
    var cities = document.getElementById("saveKolLocationForm").elements.namedItem("city_id");
    stateId = $("#saveKolLocationForm #state_id").val();  
    var params = "state_id=" + stateId;
    $.ajax({
        url: "<?php echo base_url()?>helpers/country_helpers/get_cities_by_stateid/",
        dataType: "json",
        data: params,
        type: "POST",
        success: function (responseText) {
        	var cityParentObject	= $('#saveKolLocationForm #city_id').parent();
        	if(responseText==''){
                $(cityParentObject).html('');
                $(cityParentObject).html('<input type="text" name="city_id" id="city_id" class="required" placeholder="Enter City" />');
            }else{
            	$(cityParentObject).html('');
            	$(cityParentObject).html('<select name="city_id" id="city_id" class="required form-control" ><option value="">Select City</option></select>');
            	setTimeout(function(){
                $.each(responseText, function (key, value) {
 					 $('#saveKolLocationForm #city_id').append('<option value="'+value.city_id+'">'+value.city_name+'</option>');
                });
            	}, 30);
            }
        },
        complete: function () {
        }
    });
}
function changeAutoComplete(){
	var orgType = $('#org_typeLocation').find(":selected").text();
	if(orgType == 'Private Practice'){
    	$('#private_practice').val('1');
    }else{
    	$('#private_practice').val('0');
    }
}
</script>