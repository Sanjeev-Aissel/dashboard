<?php
/**
 * Controller for showing presentation and other pages
 * 
 * @author Ramesh B
 * @since  3.2
 * @package application.controllers	
 * @created on 11-10-2011
 */

class Pages extends Controller {
	
	var $pageName='';
	function Pages(){
		parent::Controller();
		$this->pageName=$this->uri->segment(2);
	}
	
	/**
	 * The second segment of the URI typically determines which function in the controller 
	 * gets called. CodeIgniter permits you to override this behavior through the use of 
	 * the _remap() function:
	 * 
	 * 
	 */
	public function _remap(){
	   $this->showPage($this->pageName);
	}
	
	
	function showPage($pageName){
		$this->load->view('presentation_pages/'.$pageName);
	}
}