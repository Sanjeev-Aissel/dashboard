<script type="text/javascript">
	var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
	var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
	var data={};
	var kolId ="<?php echo (isset($arrKol))?$arrKol['kols_client_visibility_id']:null;?>";
	var org_contract = '<?php echo ORGS_CONTRACT;?>';
	var contractType = "kol";
	var subContentPage	= '<?php echo $subContentPage;?>';
	var arrExcludeColumnsInExcelExport = new Array('act'); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by');
	$(document).ready(function(){
		listContracts();
	});
</script>
<style>
.contract_expired_indicator td{
color: #ff0000 !important;
}
.excelExportIcon{
float: right;
margin-right: 50px;
margin-right: 20px !important;
}
</style>
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"  rel="stylesheet"/>
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'js/custom_js/jqgridExportToExcel',
			'modules/contracts/js/contracts',
			'alerts/jquery.alerts',
		'js/jquery.autocomplete',
		'jquery_validator/dist/jquery.validate'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<div id="contractsList">
	<div class="row">
		<div class="pull-right row_padding">
			<?php if($role_permissions[$module_id]["add"]==1){?>
					<button onclick="addContract();return false;" type="button" class="btn custom-btn" title="Add Contract">Add Contract</button>
			<?php }?>
			<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#listContractResultSet','contracts');">
				<a href="#" rel="tooltip" data-original-title="Export Contract Details into Excel format">&nbsp;</a>
			</div>
		</div>
	</div>
	<div class="gridWrapper" id="allContractsContainer">
		<div id="listContractPage"></div>
		<table id="listContractResultSet"></table>
	</div>	
	<div id="modalContainer" class="microViewLoading">
		<div class="modalContent"></div>
	</div>
</div>
