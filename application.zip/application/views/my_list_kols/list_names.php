<?php
/**
 * File to 'List' list names of particular category
 *
 * @package application.views.my_list_kols
 * @author: Vinayak
 * @since :2.0
 * @created : 11-4-11
 *  
 */

?>

<style type="text/css">
	.listNameResultSet thead th{
		-moz-background-clip:border;
		-moz-background-inline-policy:continuous;
		-moz-background-origin:padding;
		/*background:#EBEBEB none repeat scroll 0 0; */
		 background: url("../images/nav-box-bg.gif") repeat-x scroll left top transparent;
		 color:#2E6E9E;
	}

	#instantdesc {
		padding:0px;
		-moz-border-radius-bottomleft:5px;
		-moz-border-radius-bottomright:5px;
		-moz-border-radius-topleft:5px;
		-moz-border-radius-topright:5px;
		border:0px solid #BBBBBB;
		clear: both;
	}
	
	#rowmarker tr td{
		padding:0px;
	}
	.tdspacer{
		 padding-left:5px;
	}
	


</style>

<script type="text/javascript">

	function validateListName(){
		if(!$("#saveListNameForm").validate().form()){
			//enableButton("saveEducation");
			return false;
		}else
			return true;
	}
	/*
	* Ajax savaing of List names
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function saveListName(){

		if(!$("#saveListNameForm").validate().form()){
			//enableButton("saveEducation");
			return false;
		}
		
			$('.listNameMsgBox').removeClass('success');
			$('.listNameMsgBox').addClass('notice');
			$('.listNameMsgBox').show();
			$('.listNameMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
					
			var id=$('#listNameId').val();
			var category_id='<?php echo $category_id?>';
			if(id==''){
				formAction='<?php echo base_url()?>my_list_kols/save_list_name/'+category_id;
					
			}else{
				formAction='<?php echo base_url()?>my_list_kols/update_list_name/'+category_id;
			}
			  $.ajax({
					url:formAction,
					type:'post',
					data:$('#saveListNameForm').serialize(),
					dataType:'json',
					success:function(returnData){
					  $('.listNameMsgBox').text(returnData.msg);
						if(returnData.saved==true){
							$("tr.recentlyAddedRow").removeClass('recentlyAddedRow');
							if(id==''){
								// Append the data to the Listing Table
								var newRecord="";
								newRecord = "<tr class='recentlyAddedRow' id='L_"+returnData.lastinsertId+"'>";
								newRecord += "<td>&nbsp;&nbsp;" + returnData.data.list_name + "</td>";
								newRecord += "<td class='actionContainer'><div class='actionIcon editIcon tooltip-demo tooltop-left'><a class='editLink tooltipLink' rel='tooltip' title='Edit' href='#' onClick='javascript:editListName("+ returnData.lastinsertId +")'></a></div>"  + "</td>";
								newRecord += "<td class='actionContainer'><div class='actionIcon deleteIcon tooltip-demo tooltop-left'><a class='editLink tooltipLink' rel='tooltip' title='Delete' href='#' onClick='javascript:deleteListName("+ returnData.lastinsertId +")'></a></div>"  + "</td>";
								newRecord += "</tr>";
								//$("L_"+returnData.lastinsertId).html(newRecord);
								$('.listNameMsgBox').removeClass('error');
								$('.listNameMsgBox').addClass('success');
								
								$(".listNameResultSet").prepend(newRecord);
							//	$('#listNames').load('<?php echo base_url()?>my_list_kols/get_list_names_by_category/'+category_id);
								
							
								setTimeout(closeDialog1,1000);
							} else {
								var newRecord='';

								newRecord += "<td>&nbsp;&nbsp;" + returnData.data.list_name + "</td>";
								newRecord += "<td class='actionContainer'><div class='actionIcon editIcon tooltip-demo tooltop-left'><a class='editLink tooltipLink' rel='tooltip' title='Edit' href='#' onClick='javascript:editListName("+ returnData.lastinsertId +")'></a></div>" + "</td>";
								newRecord += "<td class='actionContainer'><div class='actionIcon deleteIcon tooltip-demo tooltop-left'><a class='editLink tooltipLink' rel='tooltip' title='Delete' href='#' onClick='javascript:deleteListName("+ returnData.lastinsertId +")'></a></div>" + "</td>";
								$("#L_"+returnData.lastinsertId).html(newRecord);
								setTimeout(closeDialog2,1000);
							}
							
							
						}else{
							$('.listNameMsgBox').addClass('success');
							$('.listNameMsgBox').removeClass('error');
							$('.uniMsgBox').fadeOut(10000);
						}
					},
					cpmplete:function(){

						}
			
			  });
		
	}

	/*
	* To close the modal box after saving of list_names 
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function closeDialog1(){
		$("#listNameAddContainer").dialog("close");
	}
	function closeDialog2(){
		$("#listNameAddContainer").dialog("close");
	}
	
	/*
	* To open the modal box to add  list_name
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function addListName(id){
		$("#listNameAddProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#listNameAddContainer").dialog("open");
		$("#listNameAddProfileContent").load('<?php echo base_url()?>my_list_kols/add_list_name/'+id);
		return false;	
	}

	/*
	* To open the modal box to edit list_name
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function editListName(listNameId){
		$("#L_"+listNameId).each(function(){
			//$("#L_"+listNameId).remove();
		});
		$("#listNameAddProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#listNameAddContainer").dialog("open");
		$("#listNameAddProfileContent").load('<?php echo base_url().'my_list_kols/edit_list_name/'?>'+listNameId);
		return false;	
	}
	
	/*
	* To open the modal box to edit list_name
	* @author vianyak
	* @since 2.0
	* @created on 12-4-2011
	*/
	function deleteListName(listNameId){
		jConfirm("Are you sure you want to delete the list?",'Please Confirm',function(event){
			if(event){
				$("#L_"+listNameId).each(function(){
					$("#L_"+listNameId).remove();
		
				});
				
				$.ajax({
					url:'<?php echo base_url()?>my_list_kols/delete_list_name/'+listNameId,
					type:'post'
				});
		
			}
		});
	}

	$(document).ready(function(){
		// Settings for the Add category Dialog Box
		var listNameAddOpts = {
				title: "Add Payment",
				modal: true,
				autoOpen: false,
				width: 400,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		$("#listNameAddContainer").dialog(listNameAddOpts);
	});

	function loadrowmarker(){
		var dom=document.getElementById("rowmarker");
		dom.innerHTML="<";
	}
	$(document).ready(function(){
		$('#instantdesc table tbody tr').each(function (index){
			$(this).bind('click',function(){
				$('#instantdesc table tbody tr.selectedRow').removeClass('selectedRow');
				$(this).addClass('selectedRow');
			});
			$(this).bind('mouseover',function(){
				$(this).css('background',"#D0E5F5");
			});
			$(this).bind('mouseout',function(){
				$(this).css('background','#ffffff');
			});
		});
	});

	function closeListBox(){
		$('#contentHolder').css("display","none");
		$('#arrowImg').css("display","none");
		
	}
	
</script>
<div style="padding:0px;margin:0px;">
	<a class="ui-dialog-titlebar-close ui-corner-all" href="#" role="button">
			<span class="ui-icon ui-icon-closethick" onclick="closeListBox()">close</span>
		</a>
	<div id="listAddLink" style="float:none;">
			<div class="addLink">
<!--				<label class="link" onclick="addListName();" id="addButton"><div class="actionIcon addIcon"></div>Add List Name</label>-->
				<span style="float: left; font-weight: bold;">Category Name: <?php echo $arrListNames[0]['category']?></span>
				<a href="#" class="NewBlueButton NewAddIcon" onclick="addListName(<?php echo $category_id; ?>);" id="addButton">Add List</a>
			</div>
	</div>
	<div id="instantdesc">	
		<table class="ListResultset listNameResultSet" style="border-collapse: collapse;">
					<thead>
						<tr>
							<th>&nbsp;&nbsp;List Name</th>
							<th colspan="2" style="text-align:center;">Actions</th>
					   </tr>
				   </thead>
				   <?php 
				   		$slNo=1;
				   
				   		foreach($arrListNames as $row){
				   			
				   			$rowId	= "L_" . $row['id'];
				   			
				   	?>
					     <tr id="<?php echo $rowId;?>">
							<td>&nbsp;&nbsp;<?php echo $row['list_name'] ?></td>
							<?php if($row['user_id']==$this->session->userdata('user_id')){
								echo '<td class="actionContainer"><div class="actionIcon editIcon tooltip-demo tooltop-left"><a class="tooltipLink" rel="tooltip" title="Edit" href="#" onclick="editListName('.$row['id'].');"></a></div></td>';
								echo '<td class="actionContainer"><div class="actionIcon deleteIcon tooltip-demo tooltop-left"><a class="tooltipLink" rel="tooltip" title="Delete" href="#" onclick="deleteListName('.$row['id'].');"></a></div></td>';
					   		}?>
							<?php  $slNo++;?>
						</tr>
					
				<?php }?>
			</table>
	</div>				
</div>				
			