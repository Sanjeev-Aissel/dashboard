<style type="text/css">
.title{
	font-size: 14px;
    font-weight: 700;
    text-align: center;
}
.wrapper{
	text-align: center;
	margin-top: 20px;
}
.labelForfields {
    font-weight: bold;
}
</style>

<script type="text/javascript">
//function to submit data
	function recalculate(){
				var clientId = $('#clientId').val();
				if(clientId==''){
					jAlert("Please select Client");
					return false;
				}
				var data ={};
				data['clientId'] = clientId;
				$('#activityChartContainer .msgBox').removeClass('success');
				$('#activityChartContainer .msgBox').addClass('notice');
				$('#activityChartContainer .msgBox').show();
				$('#activityChartContainer .msgBox').html('Calculating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
				$.ajax({
					url:'<?php echo base_url()?>reports/calculate_reports_chart_data',
					data:data,
					type:'post',
					dataType:'json',
					success:function(){
						$('#activityChartContainer .msgBox').text("Activity Charts Data Recalculated Successfully!");
						$('#activityChartContainer .msgBox').fadeOut(1500);
					}
				}); 
			}
</script>

<div id="activityChartContainer">
	<div class="title">
	Client for Recalculate Activity Charts Data
	</div>
	<div class="msgBox"></div>
	<div class="wrapper">
		<div class="clientListing">
						<span class="labelForfields">Clients: </span><select name="client_id" class="required ipadCSS clientId" id="clientId">
							<option value="">--- Select ---</option>
							<?php foreach ($arrClients as $clients){
								echo '<option value="'.$clients["id"].'">'.$clients["name"].'</option>';
							}?>
					</select>
		</div>
		<div class="button">
			<button class="btn_recalculate" id="recalculate" onclick="recalculate()">Recalculate</button>
		</div>
	</div>

</div>