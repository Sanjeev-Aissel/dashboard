<?php


/**
 * description of the function
 * 
 * @package		application.models
 * @author		Shivu M.D. <shivu.dundur@bilva.co.in>
 * @copyright	Copyright (c) 2012, Bilva Solutions <www.bilva.co.in>
 * @link		http://www.bilva.co.in
 * @version		Version 1.0
 * @since		Oct 4, 2012
 */
?>
<?php

/*
 * Controller for the new module 'KOL Rating' 
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v3.7 Abbott 1.0
 * Created on	: 17-03-2012
 *  
 */

	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.datepicket',
							'chosen.jquery'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

	$optionValues	= array (
							1=>'Not Met',
							2=>'Partially Met',
							3=>'Fully Met',
							4=>'Exceeds'
						);
        $scoreArray = array('N/A' => 0, 'Not Met'=>1,
							'Partially Met'=>2,
							'Fully Met'=>3,
							'Exceeds'=>4);
						
?>
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
/*	#addCoaching{
		width: 805px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
	}*/
	legend {
	    color: #ececec;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		
		background: #ececec;
		color: #4D7BD6;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	select.chosenMultipleSelect, select.chosenSelect{
		width:200px;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.scoreContainer{
		color:#000;
	}
</style>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
	var totalScore	= 0;
	var arrPlanScore = new Array();
	var totalPlanScore	= 0;
	var arrOpenScore = new Array();
	var totalOpenScore	= 0;
	var arrMedScore = new Array();
	var totalMedScore	= 0;
	var arrWrapScore = new Array();
	var totalWrapScore	= 0;
	function validateSelect(){
		var doSubmitForm    = true;
		$('#coachingForm select').each(function (index){
			var value    = $(this).attr('value');
			switch(value){
				case 'Select Username':
			    case 'Select Specialty':
			    case 'Select Scale':
			    case '': 
			    $(this).parent().parent().css('color','red');
			    $(this).css('border-color','red');
			    doSubmitForm    = false;
			    break;
			    default:
					$(this).parent().parent().css('color','#333');
		            $(this).css('border-color','#333');
				    break;
		        }
		 });
		 if(doSubmitForm){
		 	$('#coachingForm').submit();
		 }
	}
	function calTopicScore(thisEle,index,topic){
		var currValue	= 0;
		var length		= 0;
		var total		= 0;
		switch(topic){
			case 'plan':
				if(arrPlanScore[index]>0){
					totalPlanScore -= parseInt(arrPlanScore[index]);
					arrPlanScore[index]	= 0;;
				}
				currValue	= parseInt($(thisEle).attr('value'));
				if(currValue>0){
					arrPlanScore[index]	= currValue;
					totalPlanScore += parseInt(arrPlanScore[index]);
				}
				length	= 0;
				$.each(arrPlanScore,function(i,value){
					if(value>0){
						length++;	
					}
				});
				total	= parseFloat(totalPlanScore/length);
				if(!(total>=0)){
					total	= 0;
				}
				$('#planScore').html(total);
				$('#scoreforplan').val(total);
			break;
			case 'open':
				if(arrOpenScore[index]>0){
					totalOpenScore -= parseInt(arrOpenScore[index]);
					arrOpenScore[index]	= 0;
				}
				currValue	= parseInt($(thisEle).attr('value'));
				if(currValue>0){
					arrOpenScore[index]	= currValue;
					totalOpenScore += parseInt(arrOpenScore[index]);
				}
				length	= 0;
				$.each(arrOpenScore,function(i,value){
					if(value>0){
						length++;	
					}
				});
				total	= parseFloat(totalOpenScore/length);
				if(!(total>=0)){
					total	= 0;
				}
				$('#openScore').html(total);
				$('#scoreforopen').val(total);
			break;
			case 'med':
				if(arrMedScore[index]>0){
					totalMedScore -= parseInt(arrMedScore[index]);
					arrMedScore[index]	= 0;
				}
				currValue	= parseInt($(thisEle).attr('value'));
				if(currValue>0){
					arrMedScore[index]	= currValue;
					totalMedScore += parseInt(arrMedScore[index]);
				}
				length	= 0;
				$.each(arrMedScore,function(i,value){
					if(value>0){
						length++;	
					}
				});
				total	= parseFloat(totalMedScore/length);
				if(!(total>=0)){
					total	= 0;
				}
				$('#medScore').html(total);
				$('#scoreformed').val(total);
			break;
			case 'wrap':
				if(arrWrapScore[index]>0){
					totalWrapScore -= parseInt(arrWrapScore[index]);
					arrWrapScore[index]	= 0;
				}
				currValue	= parseInt($(thisEle).attr('value'));
				if(currValue>0){
					arrWrapScore[index]	= currValue;
					totalWrapScore += parseInt(arrWrapScore[index]);
				}
				length	= 0;
				$.each(arrWrapScore,function(i,value){
					if(value>0){
						length++;	
					}
				});
				total	= parseFloat(totalWrapScore/length);
				if(!(total>=0)){
					total	= 0;
				}
				$('#wrapScore').html(total);
				$('#scoreforwrap').val(total);
			break;
		}
		totalScore	= (parseFloat($('#planScore').html())+parseFloat($('#openScore').html())+parseFloat($('#medScore').html())+parseFloat($('#wrapScore').html()));
		$('#totalScore').html(totalScore);
		$('#scorefortotal').val(totalScore);
	}
	function cancelCoachingForm(){
		 window.location=base_url+'coachings/list_coachings';
	}
	$(document).ready(function(){
		$('#date').datepicker({
			dateFormat: 'mm/dd/yy'
		});
		
		
		$('.chosenSelect').chosen({allow_single_deselect: true});
		$('.chosenMultipleSelect').chosen({
			no_results_text: "KTL not found with the name ",
			placeholder_text : "Click to Select KTL Name(s)",
			allow_single_deselect: true
		});
	});

</script>

<button value="Back To List Customer Engagements" onclick="window.history.back();">Back to List Field Coachings</button>
<div class="pdfExportIcon sprite_iconSet tooltip-demo tooltop-left"  style="float: right; margin-right: 30px;">
    
	<a class="tooltipLink tooltip-left" rel="tooltip" href="<?php echo base_url();?>coachings/export_pdf/<?php echo $coachingDetails[0]['id']; ?>" data-original-title="Export to PDF">&nbsp;</a>
</div>


<div id="addCoaching">
<form action="<?php echo base_url();?>coachings/update_coaching" method="post" name="msl_coaching_form" id="coachingForm">
<input type="hidden" name="id" id="id" value="<?php echo $coachingDetails['id']?>" />
	<div id="addFormWrapper">	
    	<h5 class="heading">Field Coaching</h5>
    </div>
	<table style="margin-top:5px;">
		<caption style="font-weight: bold;">General Information <?php   $coachingDetails	= $coachingDetails[0]; ?></span></caption>
		<tr>
			<th class="alignRight">Engagement ID :</th>
			<td><?php   echo $coachingDetails['generic_id'] ?></td>
			
		</tr>
                <tr>
			<th class="alignRight">MSL Name:</th>
			<td><?php  echo  $coachingDetails["username"] ?></td>
			<td>&nbsp;</td>
			<th class="alignRight">Date:</th>
			<td><?php echo  $coachingDetails["date"] ?></td>
		</tr>
		<tr>
			<th class="alignRight">Therapeutic Area:</th>
			<td><?php echo  $coachingDetails["specialty"] ?></td>
			<td>&nbsp;</td>
			<th class="alignRight"><?php echo lang("HCP");?> Name(s):</th>
                        <td ><?php echo  $coachingDetails["kol_id"] ?></td>
		</tr>
		<tr>
			<th class="alignRight">Engagement Status:</th>
			<td><?php echo  $coachingDetails["status"] ?></td>
			<td>&nbsp;</td>

		</tr>
	</table>

	<fieldset style=" border: 1px solid #d3d3d3  ;">
		<legend style="color:#000;">Evaluation Details</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter">Weight</th><th class="alignCenter">Topic</th><th class="alignCenter" style="width: 160px;">Evaluation (use scale below)</th>
			</tr>
			<tr class="tableSubHeader">
				<th>25%</th>
				<th>Planning and Preparation</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Has a firm understanding of KDMs, their role within health system and their sphere of influence</td>
				<td>
					
						<?php 
						if(isset($optionValues[$coachingDetails['plan_topic1']])){
							echo $optionValues[$coachingDetails['plan_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Has a detailed understanding of KDM needs and drivers of decision making</td>
				<td>
					
						
                                    
						<?php 
						if(isset($optionValues[$coachingDetails['plan_topic2']])){
							echo $optionValues[$coachingDetails['plan_topic2']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Clearly identifies objective(s) prior to meeting</td>
				<td>
					
					<?php 
						if(isset($optionValues[$coachingDetails['plan_topic3']])){
							echo $optionValues[$coachingDetails['plan_topic3']];
						}else{
							echo 'N/A';
						}
					?>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified available tools, resources and support needed for use with KDM</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails['plan_topic4']])){
							echo $optionValues[$coachingDetails['plan_topic4']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified and prepared for potential KDM questions that may arise during interaction</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['plan_topic5']])){
							echo $optionValues[$coachingDetails['plan_topic5']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
                 <th ></th><th>Over All Score</th>
				<td>
                                    
                                    <?php 
                                    $key = array_search( $coachingDetails['planscore'], $scoreArray);
                                    echo $key;
                                            
                                            ?></td>
			</tr>
			<tr class="tableSubHeader">
				<th>10%</th>
				<th>Rapport Building Dialogue</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively connected/reconnected with KDM to establish constructive environment for engagement</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails['open_topic1']])){
							echo $optionValues[$coachingDetails['open_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Effectively set the tone and communicated objective(s) of interaction</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails['open_topic2']])){
							echo $optionValues[$coachingDetails['open_topic2']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
                <th ></th><th>Over All Score</th>
				<td><?php  $key = array_search( $coachingDetails['openscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			<tr class="tableSubHeader">
				<th>50%</th>
				<th>Medical Dialogue</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Effectively listened to KDM and understood their issues, concerns, and medical needs within health system</td>
				<td>
					
						
                                        <?php 
						if(isset($optionValues[$coachingDetails['med_topic1']])){
							echo $optionValues[$coachingDetails['med_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified the barriers for care delivery through effective engagement and dialogue with KDM</td>
				<td>
					
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic2']])){
							echo $optionValues[$coachingDetails['med_topic2']];
						}else{
							echo 'N/A';
						}
					?>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Asked questions to gain better understanding of health care system and landscape including patient flow and other KDM influencers</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic3']])){
							echo $optionValues[$coachingDetails['med_topic3']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Discussed and shared ideas with KDM that appropriately addressed barriers to care delivery within health system through evidence application</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic4']])){
							echo $optionValues[$coachingDetails['med_topic4']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Competently shared product and disease state information including appropriate use of FMA resources and tools
	</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic5']])){
							echo $optionValues[$coachingDetails['med_topic5']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                        <tr>
				<td></td>
				<td>Responded appropriately to unsolicited KDM requests for information including use of FMA resources and tools</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic6']])){
							echo $optionValues[$coachingDetails['med_topic6']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
                          <tr>
				<td></td>
				<td>Respectfully challenged KDM when faced with positions that go against evidence based data and its appropriate application</td>
				<td>
					
						
                                     <?php 
						if(isset($optionValues[$coachingDetails['med_topic7']])){
							echo $optionValues[$coachingDetails['med_topic7']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
			
                  <th ></th><th>Over All Score</th>
				
                                <td><?php  $key = array_search( $coachingDetails['medscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			<tr class="tableSubHeader">
				<th>15%</th>
				<th>Next Steps</th>
				<th></th>
			</tr>
			<tr>
				<td></td>
				<td>Reviewed action items including questions that need follow-up at conclusion of interaction</td>
				<td>
					
							
                                       <?php 
						if(isset($optionValues[$coachingDetails['wrap_topic1']])){
							echo $optionValues[$coachingDetails['wrap_topic1']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Identified and reported medical insights gleaned from interaction within 5 business days</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails['wrap_topic2']])){
							echo $optionValues[$coachingDetails['wrap_topic2']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Took appropriate steps to secure a follow up appointment to address action items including scheduling of educational presentations and/or collaborative opportunities</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails['wrap_topic3']])){
							echo $optionValues[$coachingDetails['wrap_topic3']];
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td>Completed MIRF including documenting unsolicited customer requests for off-label information consistent with company policies</td>
				<td>
					
						
                                       <?php 
						if(isset($optionValues[$coachingDetails['wrap_topic4']])){
                                                    if($coachingDetails['wrap_topic4']==2)
							echo "Yes";
                                                     if($coachingDetails['wrap_topic4']==1)
							echo "No";
						}else{
							echo 'N/A';
						}
					?>
					
				</td>
			</tr>
			<tr class="scoreContainer">
				
                <th ></th><th>Over All Score</th>
				
                                 <td><?php  $key = array_search( $coachingDetails['wrapscore'], $scoreArray);
                                    echo $key; ?></td>
			</tr>
			<tr hidden class="tableSubHeader scoreContainer">
				<td><input type="hidden" name="scorefortotal" id="scorefortotal"></input></td>
				<th class="alignRight">Total Score</th>
				<th><div id="totalScore">0</div></th>
        
			</tr>
                        <tr>
                        <th style="width:80px !important;" >Evaluated By:</th>
			<td><?php echo $coachingDetails['evaluated_by']?></td>
                        
                        </tr>
                         <tr>
                        <th style="width:80px !important;" ><?php echo CREATED_ON ?>:</th>
			<td><?php echo $coachingDetails['created_on']?></td>
                        
                        </tr>
                        <tr>
                        <th style="width:80px !important;" >Comment:</th>
                        <td><?php echo $coachingDetails['comment']?></td>
                        </tr>
		</table>
	</fieldset>
	
        
        <fieldset style=" border: 1px solid #d3d3d3  ;">
		<legend style="color:#000;">Anchor</legend>
		<table id="evaluationDetails">
			<tr class="tableHeader">
				<th class="alignCenter">Rank</th><th style='width:150px;'>Values</th><th >Description</th>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Planning and Description</th>
			</tr>
			<tr>
				<td>1.</td>
				<td >Not Met</td>
				<td>
				Demonstrated little to no planning.	
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated planning was done to some degree but did not fully meet criteria and insufficient to have effective engagement with the KDM.	
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Fully met the criteria of successfully planning for a KDM meeting including appropriate research and preparation to facilitate an effective interaction.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully prepared for interaction with KDM, but also conducted additional research and preparation on the KDM’s broader interests and areas of specialty. This may extend to include other experts and key issues and findings in the field beyond the KDM.	
				</td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Rapport Building Dialogue</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not demonstrate an effective medical dialogue nor appropriately captured insights. Failed to listen and was focused on own agenda without regard to what was being said or shared. Additionally, did not ask appropriate questions to gain better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not appropriately challenge KDM where appropriate nor use available resources.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
				Demonstrated some effort but insufficient to engage <?php echo lang("HCP");?> in an effective medical dialogue. Acknowledged views of KDM but was more focused on own agenda with only some or little regard to what was being said or shared. Made some attempt to ask questions but insufficient to gain a better understanding of healthcare system nor identified barriers and challenges to care delivery. Did not adequately challenge KDM or fully communicate relevant disease and product information using available resources.
				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
				Completely met the criteria for successful medical dialogue including highlighted evidenced based data and appropriate use of MSL resources to share disease and product information. Demonstrated active listening skills, asked appropriate probing questions to better understand patient flow and healthcare system to help identify issues and challenges that stand in the way of optimized care delivery. Insights gained from dialogue were sufficiently refined as applicable to <?php echo PRODUCT_NAME;?>. Appropriately and respectfully challenged KDM if their comment(s) or position(s) was/were not supported by available evidence.	
				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
				Not only fully meets the criteria for successful medical dialogue but also demonstrated superior listening and probing skills to develop a thorough understanding of the KDMs issues, concerns and needs. Additionally, consistently sought opportunities to collaborate with KDM to develop health management, quality improvement, care coordination tools as well as other collaborative projects related to optimized care delivery.
				</td>
			</tr>
			<tr class="tableSubHeader">
				<th></th>
				<th></th>
				<th>Next Steps</th>
			</tr>
			<tr>
				<td>1.</td>
				<td>Not Met</td>
				<td>
				Did not complete/adjourn the meeting by providing follow-up or action items.
				</td>
			</tr>
                        <tr>
				<td>2.</td>
				<td>Partially Met</td>
				<td>
Did not appropriately complete/adjourn the meeting by providing follow-up or action items in sufficient detail. Did not secure follow-up appointment nor submit medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>3.</td>
				<td>Fully Met	</td>
				<td>
Completely met the criteria for successful completion/adjournment of meeting including review of follow-up and actions items, identified the plan for determining a future interaction and submitted key medical insights in a timely manner.				</td>
			</tr>
			<tr>
				<td>4.</td>
				<td>Exceeds</td>
				<td>
Not only fully meets the criteria for successful completion/adjournment of meeting, but conducted a detailed review of all follow-up and actions items, identified the plan for determining a future interaction and submitted critical medical insights shortly after meeting.				</td>
			</tr>
			
		</table>
	</fieldset>
</form>
</div>
