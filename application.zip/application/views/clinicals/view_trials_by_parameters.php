<?php
/*
 * To display Details of Publications 
 * @author Vinayak
 * @since 1.5
 * @package application.views.publications
 * 
 */

//To show row list in jqgrid
	function listRecordsPerPage($maxRecords=1000,$increament=100){
		$rowList="";
		for($i=100;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
	<meta charset="UTF-8" />
	<title>Key Opinion Leader Management</title>
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	<!-- jQuery Core File -->
	<link href="<?php echo base_url();?>css/tooltip/bootstrap.css" rel="stylesheet">
	<!--<link href="<?php echo base_url();?>css/tooltip/style.less" rel="stylesheet/less" type="text/css">
	--><script src="<?php echo base_url();?>js/tooltip/jquery.js"></script>
	<!--<script src="<?php echo base_url();?>js/tooltip/less-1.2.1.min.js" type="text/javascript"></script>	
	--><script src="<?php echo base_url();?>js/tooltip/bootstrap-tooltip.js"></script>
	<!-- jQuery UI File -->
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>	
	
	<!-- JQGrid Plugins -->
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min.js" type="text/javascript"></script>
	
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/client_layout.css" />
	<?php 
		if(IS_IPAD_REQUEST == 1){
		//	echo 'iPad';
			?>
			<script type="text/javascript">
				isiPad	= true;
			</script>
			<meta content='initial-scale=1.05;' name='viewport' />
			<!--<meta name="viewport" content="width=device-width" />
			--><link type="text/css" rel="stylesheet" media="only screen and (min-device-width: 481px) and (max-device-width: 1024px)" href="<?php echo base_url()?>css/ipad_only.css">
			<?php 
		}
	?>
	<style type="text/css">
		#publicationsListingContainer{
			margin:10px;
		}
		
		#publicationsListingContainer h2, #publicationsListingContainer h3{
			text-align:left;
			font-weight:normal;
		}
		
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			padding: 0px;
			padding-left:4px;
		}
		.ui-widget-header {
		    background-image: none;
		}
		.ui-jqgrid .ui-jqgrid-title {
		    font-size: 13px;
		    padding-left: 1px;
		}
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td {
			border-bottom:1px solid #EEEEEE;
		}
		h2 {
		    color: #626262;
		    font-family: lucida grande,tahoma,verdana,helvetica,arial !important;
		    font-size: 12px;
		    font-weight: bold !important;
		}
		.gridWrapper .ui-jqgrid tr.ui-search-toolbar th div {
		    text-align: left;
		}
	</style>
	

	
<script type="text/javascript">

	var paginationValues		= new Array();
	<?php 
		$paginationValues	= explode(',',PAGINATION_VALUES);
		foreach($paginationValues as $key=>$value){
	?>
		paginationValues.push('<?php echo $value;?>');
	<?php
		}
	?>

	$(document).ready(function(){
		// Settings for the Dialog Box
		var trialMicroProfileDialogOpts = {
				title: "Clinical Trial Snapshot",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#trialMicroProfile").dialog(trialMicroProfileDialogOpts);	
		/*
		*jqgrid for Clinical Trials table
		*/
		var ele=document.getElementById('clinicalGridContainer');
		var gridWidth=ele.clientWidth;
		gridWidth-=-5;
		var base_url = '<?php echo base_url()?>';
		var id = '<?php echo $id?>';
		var orgId = '<?php echo $orgId?>';
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid({
		
		   	url:base_url+'clinical_trials_org/list_trials_details/'+id+'/'+orgId,
			datatype: "json",
			colNames:['Id','User Id','CT ID','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				//{name:'is_manual',index:'is_manual', hidden:true},
				{name:'user_id',index:'user_id', hidden:true},
				{name:'client_id',index:'client_id', hidden:true},
				{name:'micro',index:'micro',width:35, search:false, hidden:true},
				{name:'ct_id',index:'ct_id',width:105},
		   		{name:'trial_name',index:'trial_name',width:290,editable:true},
		   		{name:'status',index:'status',width:80,editable:true},
		   		{name:'sponsors',index:'sponsors',width:160,editable:true},
		   		{name:'condition',index:'condition',width:130,editable:true},
		   		{name:'interventions',index:'interventions',width:120,editable:true},
		   		{name:'phase',index:'phase',width:60,editable:true}
		   		
		   	],
		   	rowNum:10,
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:true,
		   	multiselect: false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listlistClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
		
			    var ids = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getDataIDs'); 
		    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	
						
					    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewClinicalTrialMicroProfile('"+cl+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Clinical Trial Snapshot\">&nbsp;</a></div></label>";
					    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
					    	
					 /*   	else if(ret.client_id==clientId && userRoleId==ROLE_MANAGER  ){
							
					    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='"+base_url+"images/delete.png'></label>";	
					    		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be});
					    	}else if(ret.client_id==clientId && userRoleId==ROLE_USER && userId==ret.user_id){
								
					    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='"+base_url+"images/delete.png'></label>";	
					    		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
					    	}
				    	*/
				    	} 
			    
			    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id");
				    
			    	//Initialize the tooltips
			    	initializeCustomToolTips();
		    	}, 
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:"TRIALS",
			rowList:[10,20,30,40,50,60,70,80,90,100]
			
		});
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','#listlistClinicalTrialsPage',{edit:false,add:false,del:false,search:false,refresh:false});
	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setGridWidth',gridWidth);

		var ALL = '<?php echo $count?>' ;
		$.each($('.ui-pg-selbox'),function(){
		$(this).children('option:last').val(ALL).text('All');
		});
			// Set the JSON data
			//var data = <?php echo json_encode($data);?>;
			//jAlert(data.toSource());
			//jQuery("#JQBlistPublicationResultSet").jqGrid('addRowData',2,data);

		//Place holder to Jqgrid Search Column
		$(".ui-search-toolbar input[type='text']").each(function(){
			$(this).attr("placeholder","Search");
	    });

    	<?php 
    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			if(preg_match('/MSIE/i',$u_agent)){
    	?>
    	$('.ui-search-toolbar input[placeholder]').each(function(){
    		$(this).after("<span class='jq-placeholder'>"+$(this).attr('placeholder')+"</span>"); 
            var input = $(this);       
            $(input).focus(function(){
                $(this).next().hide();
            });
            $(input).blur(function(){
                 if (input.val() == '') {
                	 $(this).next().show();
                 }
            });
        });

        $(".jq-placeholder").live("click",function(){
        	$(this).hide();
        	$(this).prev().focus();
	    });
        <?php }?>
		
	});
	//- End of DOCUMENT.READY function
	
	/**
	* Opens the Modal Box with the Micro Profile content of KOL
	* @param: kolId
	*/
	function viewPubMicroProfile(pubId){
		$("#pubMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#pubMicroProfile").dialog("open");
		$("#pubMicroProfile .profileContent").load('<?php echo base_url().'pubmeds/view_micro_pub/'?>'+pubId);
		return false;
	}
	function initializeCustomToolTips(){
		
		$('.tooltip-demo.tooltop-top').tooltip({
	      selector: "a[rel=tooltip]", placement:'top'
	    });
	    $('.tooltip-demo.tooltop-bottom').tooltip({
	      selector: "a[rel=tooltip]", placement:'bottom'
	    });
	    $('.tooltip-demo.tooltop-right').tooltip({
	      selector: "a[rel=tooltip]", placement:'right'
	    });
	    $('.tooltip-demo.tooltop-left').tooltip({
	      selector: "a[rel=tooltip]", placement:'left'
	    });

	}
	

</script>

</head>
<body>

<div id="publicationsListingContainer">
		
		<div id="trials">
					<!--  
					<div class="addLink">
						<label class="link" onclick="addClinicalTrail();"><div class="actionIcon addIcon"></div>Add New Clinical Trial</label>
					</div>-->
					<div class="gridWrapper clear" id="clinicalGridContainer">
							<table id="JQBlistClinicalTrialsResultSet"></table>
							<div id="listlistClinicalTrialsPage"></div>
					</div>
				</div>
		<!-- Container for the 'Publication Micro Profile' modal box -->
		<!-- Container for the 'Add Clinical Trail' modal box -->
		<div id="clinicalTrailDailog">	
			<div id="clinicalTrailAddContainer" class="microProfileDialogBox">
				<div class="profileContent" id="clinicalTrailAddProfileContent"></div>
			</div>
		</div>
		<!--End of  Container for the 'Publication Micro Profile' modal box -->
	
	
</div>
</body>
</html>