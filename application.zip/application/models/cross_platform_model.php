<?php

class cross_platform_model extends Model {

    var $ipdb = '';

    //Constructor
    function cross_platform_model() {
        parent::Model();
    }

    function getKolsDetailsCount($arrKolIds) {
        $this->db->select('*', false);
        $this->db->where_in('kol_id', $arrKolIds);
        $query = $this->db->get('kol_activities_count');
        $result = $query->result_array();
        return $result;
    }

    function getKolsEducations($arrKolIds) {
        $data = array();
        $edu=array();
        foreach ($arrKolIds as $id) {
            $arrEducationResults = $this->kol->listEducationDetailsRecent5('all', $id,array('honors_awards'));
            $data[] = $arrEducationResults;
        }
        foreach ($data as $values) {
            foreach ($values as $innerArr) {
                $edu[] = $innerArr;
            }
        }
        return $edu;
    }

    function getKols($userId = '', $kolIds) {
        $this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name,titles.title,kols.suffix,kols.primary_phone,kols.primary_email,kols.address1,kols.postal_code,kols.fax,kols.license,kols.profile_type,kols.modified_on,
		organizations.name as org_name,kols.profile_image,kols.biography,kols.division,kols.research_interests,specialties.specialty,cities.City,regions.Region,kols.npi_num as npi,Country,organization_types.type,   case kols.salutation
                when "1"  then "Dr."
               when "2"  then "Prof."
               when "3" then "Mr."
               when  "4"  then "Ms."  end as salutation', false);
        if ($userId != '')
            $this->db->join('kols', 'user_kols.kol_id = kols.id', 'left');
        $this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
         $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join('cities', 'kols.city_id = cities.cityid', 'left');
        $this->db->join('regions', 'kols.state_id = regions.regionid', 'left');
        $this->db->join('countries', 'kols.country_id = countries.countryid', 'left');
        $this->db->join('organizations', 'kols.org_id = organizations.id', 'left');
        $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
        $this->db->limit(500);
        //$this->db->where('kols.status',COMPLETED);
        if (count($kolIds) > 0)
            $this->db->where_in('kols.id', $kolIds);
        if ($userId != '') {
            $this->db->where('user_id', $userId);
            $result = $this->db->get('user_kols');
        } else
            $result = $this->db->get('kols');
//                echo $this->db->last_query();
        return $result->result_array();
    }

   function getPublications($arrKolIds) {

        $data = array();
        $pubs = array();

        foreach ($arrKolIds as $id) {
            $this->db->select('kol_publications.kol_id,publications.*,publications.id,publications.iso_abbreviation,publications.article_title,publications.abstract_text,publications.affiliation,publications.article_date,pubmed_journals.name as journal_name', false);
            $this->db->join('publications', 'publications.id=kol_publications.pub_id', 'left');
            $this->db->join('pubmed_journals', 'publications.journal_id=pubmed_journals.id', 'left');
            $this->db->where_in('kol_publications.kol_id', $id);
            $this->db->where_in('kol_publications.is_verified', 1);
            $this->db->where_in('kol_publications.is_deleted', 0);
            $this->db->limit(5);
            $this->db->order_by('publications.created_date','desc');
          
            
            
            
            $query = $this->db->get('kol_publications');
//        echo $this->db->last_query();
            $result = $query->result_array();
       
             foreach ($result as $row) {
                   
            $row["arrAuthorDetails"] = $this->pubmed->getPublictionsAuthorsbyPubid($row["id"]);
            $row['created_date']=date("d-M-Y", strtotime( $row['created_date']));
            $auth=array();
            foreach($row["arrAuthorDetails"] as $details){
                $auth[]=$details['last_name']." ".$details['initials'];
            }
            $row["arrAuthorDetails"]=implode(',',$auth);
            $arrAllPubDetails[] = $row;
        }
        
         
           
        }
        $data[]=$arrAllPubDetails;
        foreach ($data as $values) {
            foreach ($values as $innerArr) {
                $pubs[] = $innerArr;
            }
        }

        return $pubs;
    }

    function getEvents($arrKolIds) {
        $data = array();
        $events = array();
        foreach ($arrKolIds as $id) {
             $arrEventsResultsResult = $this->kol->listEventsRecent5("conference", $id, $startDate, $endDate);

            $data[] = $arrEventsResultsResult;
        }
        foreach ($data as $values) {
            foreach ($values as $innerArr) {
                $events[] = $innerArr;
            }
        }

        return $events;
    }

    function getTrials($arrKolIds) {
        $data = array();
        $trials = array();
        foreach ($arrKolIds as $id) {
           $arrClinicalTrialsResults=$this->clinical_trial->listClinicalTrialsDetailsByTypeRecent5($id);
            $data[] = $arrClinicalTrialsResults;
        }
        foreach ($data as $values) {
            foreach ($values as $innerArr) {
                $trials[] = $innerArr;
            }
        }
        return $trials;
    }

    function getAff($arrKolIds) {
        $data = array();
        $aff = array();
        foreach ($arrKolIds as $id) {
          $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');

            $this->db->where_in('kol_memberships.kol_id', $id);
            $this->db->limit(5);
             $this->db->order_by('kol_memberships.end_date', 'desc');
            $query = $this->db->get('kol_memberships');
            $result = $query->result_array();
            $data[] = $result;
        }
        foreach ($data as $values) {
            foreach ($values as $innerArr) {
                $aff[] = $innerArr;
            }
        }
        return $aff;
    }

    function getProducts($ids) {
        $data = array();
        $this->db->select('name,id');
        $this->db->where_not_in('id',$ids);
        $query = $this->db->get('products');
        $result = $query->result_array();
        if(count($result)>0)
        return  "true";
        else
            return "false";
    }

    function getTypes($productIds) {
        $ids=array();
        foreach($productIds as $values){
            $ids[]=$values['id'];
        }
        $this->db->select("distinct interaction_types.id,interaction_types.name",false);
        $this->db->join('interaction_types', 'interaction_types.id=interaction_topics_by_type.type_id', 'left');
        $this->db->where_in('interaction_topics_by_type.product_id', $ids);
        $this->db->where('interaction_topics_by_type.status', 1);
        $this->db->order_by('name', 'ASC');
        $arrResults = $this->db->get('interaction_topics_by_type');
        return $arrResults->result_array();;
    }

    function getTopics($productIds) {
        $ids=array();
        foreach($productIds as $values){
            $ids[]=$values['id'];
        }
        $this->db->select("distinct interaction_topics.id,interaction_topics.name",false);
        $this->db->join('interaction_topics', 'interaction_topics.id=interaction_topics_by_type.topic_id', 'left');
        $this->db->where_in('interaction_topics_by_type.product_id ', $ids);
        $this->db->where('interaction_topics.status ', 1);
        $this->db->order_by("interaction_topics.name");
        $arrResults = $this->db->get('interaction_topics_by_type');
        return $arrResults->result_array();
    }

    function getSpecs() {
        $data = array();
        $this->db->select('specialty,id');

        $query = $this->db->get('specialties');
        $result = $query->result_array();

        return $result;
    }

    function getChannel() {
        $data = array();
        $this->db->select('name,id');

        $query = $this->db->get('interactions_modes');
        $result = $query->result_array();

        return $result;
    }

    function getProfessionalSuffix() {
        $data = array();
        $this->db->select('suffix,id');
        $this->db->where('is_active', 1);
        $query = $this->db->get('professional_suffix');
        $result = $query->result_array();

        return $result;
    }
    
    function saveAlignMent($userId,$kolIds,$type){
    	switch($type){
    		case "assign": foreach($kolIds as $value){
    			$this->db->select('user_id,kol_id');
    			$this->db->where('user_id', $userId);
    			$this->db->where('kol_id', $value);
    			$query = $this->db->get('user_kols');
    			$result = $query->num_rows();
    			if($result==0){
    				$data=array("user_id"=>$userId,"kol_id"=>$value);
    				$this->db->insert('user_kols',$data);
    			}
    		}
    		break;
    		case "unassign":
    
    			$this->db->where_in('kol_id', $kolIds);
    			$query = $this->db->delete('user_kols');
    			break;
    	}
    	 
    }
    
    function checkStateIfExistElseAdd($state,$country){
    	$this->db->select('RegionID');
    	$this->db->where('Region',$state);
    	$this->db->limit(1);
    	$query = $this->db->get('regions');
    	$result = $query->result_array();
    	
    	if($result['0']['RegionID'] == ""){
    		$data = array(
    				'CountryID' => $country,
    				'Region' => $state
    		);
    		$this->db->insert('regions', $data);
    		return $this->db->insert_id();
    	}else{
    		return $result['0']['RegionID'];
    	}
    	
    }
    
    function checkCityIfExistElseAdd($city,$stateId,$country){
    	$this->db->select('CityId');
    	$this->db->where('city',$city);
    	$this->db->limit(1);
    	$query = $this->db->get('cities');
    	$result = $query->result_array();
    	
    	if($result['0']['CityId'] == ""){
    		$data = array(
    				'CountryID' => $country,
    				'RegionID' => $stateId,
    				'City'	=>	$city
    		);
    		$this->db->insert('cities', $data);
    		return $this->db->insert_id();
    	}else{
    		return $result['0']['CityId'];
    	}
    }
    
    function checkOrgIfExistElseAdd($institution,$address,$country,$stateId,$cityId,$postal_code,$phone_number){
    	$this->db->select('id');
    	$this->db->where('name',$institution);
    	$this->db->limit(1);
    	$query = $this->db->get('organizations');
    	$result = $query->result_array();
    	
    	if($result['0']['id'] == ""){
    		$dataOrg = array(
    				'name' => $institution,
    				'address' => $address,
    				'phone'	=>	$phone_number,
    				'city_id'	=>	$cityId,
    				'state_id'	=>	$stateId,
    				'country_id'	=>	$country,
    				'postal_code'	=>	$postal_code,
    				'type_id'		=> '9'
    				
    		);
    		$this->db->insert('organizations', $dataOrg);
    		$returnId = $this->db->insert_id();
    		$dataOrgLoc = array(
    				'org_id' => $returnId,
    				'main' => $institution,
    				'address1'	=>	$address,
    				'country_id'	=>	$country,
    				'state_id'	=>	$stateId,
    				'city_id'	=>	$cityId,
    				'postal_code'	=>	$postal_code,
    				'phone_type_primary'	=>	$postal_code,
    				'phone_number_primary'	=>	$phone_number
    		);
    		$this->db->insert('org_locations', $dataOrgLoc);
    		return $returnId;
    	}else{
    		return $result['0']['id'];
    	}
    }
    
    function getInteractionAttenDees($userId,$clientId,$date){
         $data = array();
        $this->db->select('distinct kol_id',false);
        $this->db->join('interactions', 'interactions_attendees.interaction_id=interactions.id', 'left');
        $this->db->where('interactions.created_by',$userId);
         $this->db->where('interactions.client_id',$clientId);
         if($date!=''){
              $this->db->where('interactions.created_on >=',$date);
         }
        $this->db->where('interactions_attendees.kol_id !=','');
        
        $query = $this->db->get('interactions_attendees');
//        echo $this->db->last_query();
        $result = $query->result_array();
        return $result;
    }
	
    
    function getPublicationDetails($publicationId){
    	
    	$this->db->select("group_concat(pubmed_authors.last_name,' ',pubmed_authors.initials) as authors,publications.created_date,publications.article_title,publications.abstract_text,pubmed_journals.name,publications.pmid,publications.link", FALSE);
    	$this->db->join('publications_authors', 'publications.id = publications_authors.pub_id');
    	$this->db->join('pubmed_authors', 'pubmed_authors.id = publications_authors.author_id');
    	$this->db->join('pubmed_journals', 'publications.journal_id = pubmed_journals.id');
    	$this->db->where('publications.id',$publicationId);
    	$query = $this->db->get('publications');
    	$result = $query->result_array();
    	return $result;
    }
    
    function getTrialDetails($trialId){

    	$this->db->select('clinical_trials.trial_name,cts_statuses.status,clinical_trials.study_type,cts_sponsers.agency,clinical_trials.collaborator,clinical_trials.ct_id,clinical_trials.purpose,clinical_trials.link');
    	$this->db->join('cts_statuses','clinical_trials.status_id = cts_statuses.id');
    	$this->db->join('ct_sponsers','clinical_trials.id = ct_sponsers.cts_id');
    	$this->db->join('cts_sponsers','ct_sponsers.sponser_id = cts_sponsers.id');
    	$this->db->where('clinical_trials.id',$trialId);
    	$query = $this->db->get('clinical_trials');
    	$result = $query->result_array();
    	return $result;
    }
    
    function getEventDetails($eventId){
    	$this->db->select('events.name as event_name, kol_events.type as event_type,conf_session_types.session_type as session_type,kol_events.session_name,event_topics.name as event_topic, kol_events.role,kol_events.start,kol_events.end,kol_events.location,countries.country,kol_events.organizer');
    	$this->db->join('events','events.id = kol_events.event_id','left');
    	$this->db->join('countries','countries.countryId = kol_events.country_id','left');
    	$this->db->join('conf_event_types','conf_event_types.id = kol_events.event_type','left');
    	$this->db->join('conf_session_types','conf_session_types.id = kol_events.session_type','left');
    	$this->db->join('event_topics','event_topics.id = kol_events.topic','left');
    	$this->db->join('event_sponsor_types','event_sponsor_types.id = kol_events.sponsor_type','left');
    	$this->db->where('kol_events.id',$eventId);
    	$query = $this->db->get('kol_events');
    	$result = $query->result_array();
    	return $result;
    }
    
    function newKOLS($date){
        $this->db->select("kols.id");
    	$this->db->where('modified_on >',$date);
    	$query = $this->db->get('kols');
    	$result = $query->result_array();
        foreach($result as $values){
            $kolIds[]=$values['id'];
        }
        return $kolIds;
    }
    
    function isUserActive($id,$clientId){
        $this->db->select("status");
    	$this->db->where('id',$id);
        $this->db->where('client_id',$clientId);
    	$query = $this->db->get('client_users');
    	$result = $query->row_array();
        if($result['status']!=0)
            return false;
        else
            return true;
       
    }
    
    
    function alignmentChanges($userId,$kolIds,$type){
        $this->db->select("kol_id");
        if($type=="assign")
            $this->db->where_not_in('kol_id',explode(",",$kolIds));
        if($type=="unassign")
             $this->db->where_in('kol_id',explode(",",$kolIds));
        $this->db->where('user_id',$userId);
    	$query = $this->db->get('user_kols');
    	$result = $query->result_array();
        return $result;
    }
    
    
    function validateUID($id){
        $this->db->select("unique_name,domain");
    	$this->db->where('unique_name',$id);
    	$query = $this->db->get('domain_validation');
    	$result = $query->row_array();
        if($query->num_rows()>0)
            return $result;
        else
            return "false";
    }
    
    
    function getUserGroups($userId){
        $arrGroupIds = array();
        $this->db->select('group_id');
        $this->db->where('user_id', $userId);
        $res = $this->db->get('user_groups');
        foreach($res->result_array() as $values){
            $ids[]=$values['group_id'];
        }
        return implode(',',$ids);
    }
    
}
