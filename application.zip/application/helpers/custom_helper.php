<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Extending the HTML Helpers
 *
 *
 * @package		application.helpers
 * @author		Vinod S.T.
 * @since		Version 1.0
 */

// ------------------------------------------------------------------------


/**
 * Pr
 *
 * Prints the ARRAY in the Human Readable format by printing withint the PRE tags
 *
 * @access	public
 * @param	array
 * @return	none
 */
if ( ! function_exists('custom_escape_string'))
{
	function custom_escape_string($string)
	{
// 	    $string = mysqli_real_escape_string($string);
	    $string    = trim($string);
	    $string    = addslashes($string);
		return $string;
	}
}

if ( ! function_exists('sortbykey'))
{
    function sortbykey($a, $b) {
        //return $b['score'] - $a['score'];
        return $b['score'] > $a['score'] ? 1 : -1;
    }
}

if ( ! function_exists('getGroupDetails'))
{
    function getGroupDetails() {
        $CI = & get_instance();
        $userGroups = array();
        $userId = $CI->session->userdata('user_id');
        $CI->db->select('GROUP_CONCAT(user_groups.group_id) AS group_ids,GROUP_CONCAT(groups.group_name) AS group_names');
        $CI->db->join('groups','groups.group_id=user_groups.group_id');
        $CI->db->where('user_id', $userId);
        $CI->db->group_by('user_id');
        $query = $CI->db->getwhere('user_groups');
        if ($query->num_rows() > 0)
        {
            $userGroups = $query->row_array();
        }
        return $userGroups;
    }
}

