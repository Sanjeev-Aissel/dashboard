<?php
/**
 * Kols Import Status page
 * 
 * @author Ambarish N
 * @since	2.5
 * @created: 04-06-2011
 */


function listRecordsPerPage($maxRecords=1000,$increament=100){
		$rowList="";
		for($i=100;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 
	
		$page						= 1; // get the requested page 
		$limit						= 100;
		$count					= sizeof($arrCounts);				
		if( $count >0 ){ 
			$total_pages 		= ceil($count/$limit); 
		}else{ 
			$total_pages 		= 0; 
		} 
		$data1['records'] 		= $count;
		$data1['total']   		= $total_pages;
		$data1['page']    		= $page;				
		$data1['rows']   	= $arrCounts;  
?>

<style>
	#kolImportStatusContiner label.errorStatus {
		font-weight: normal;
		color: red;
	}
	#kolImportStatusContiner label.successStatus {
		font-weight: normal;
		color: green;
	}
	#kolImportStatusContiner label.statusCategory {
		font-size: 14px;
	}
	.content-box{
		margin-top:20px;
		padding:0px 15px;
	}
	.well{
		padding: 15px 19px !important;
	}
	.unorder-list{
		margin-left:20px;
	}
	.title-header{
	    margin: 5px 0;
    	font-size: 13px;
    	font-weight: bold;
	}
	hr{
		clear:both;
	}
</style>
<div id="kolImportStatusContiner" class="content-box">
	<?php foreach($arrImportStatusMsg  as $key=>$arrMes){
			 foreach($arrMes as $key1=>$arrMessage){ ?>
				<div class="col-md-12" style="text-align: center;">
					Status Of <?php echo $key1?>
				</div>
				<!-- Start of proffessional Status -->
				<div class="col-md-12">
					<label class="statusCategory">Professional Info Import Status</label> :
					<?php if(isset($arrMessage['professional']['success'])) {?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['professional']['no_pin_num']) && sizeof($arrMessage['professional']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['professional']['no_pin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['professional']['existingKols']) && sizeof($arrMessage['professional']['existingKols'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing KOLs : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['professional']['existingKols'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['incorrect_format'])) {?>
						<label class="errorStatus"><?php echo $value1['professional']['incorrect_format'];?></label>
					<?php }?>	
				</div>
				<!-- End of proffessional Status -->
				<hr size="10px;">
				<!-- Start of contact Status -->
				<?php if(isset($arrMessage['contact'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Contact info Import Status</label> :
					<?php if(isset($arrMessage['contact']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['contact']['no_pin_num']) && sizeof($arrMessage['contact']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['contact']['no_pin_num'] as $key => $value){ 
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['contact']['no_matching_pin_num']) && sizeof($arrMessage['contact']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['contact']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['contact']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>	
					</div>
				<?php }?>
				<!-- End of contact Status -->
				<!-- Start of biography Status -->
				<?php if(isset($arrMessage['biography'])) {?>
					<div class="col-md-12">
					<label class="statusCategory">Biography info Import Status</label> :
					<?php if(isset($arrMessage['biography']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['biography']['no_pin_num']) && sizeof($arrMessage['biography']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['biography']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['biography']['no_matching_pin_num']) && sizeof($arrMessage['biography']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['biography']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['biography']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>		
					</div>
				<?php }?>
				<!-- End of biography Status -->
				
				<!-- Start of education Status -->
				<?php if(isset($arrMessage['education'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Education info Import Status</label> :
					<?php if(isset($arrMessage['education']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['education']['no_pin_num']) && sizeof($arrMessage['education']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['education']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['education']['no_matching_pin_num']) && sizeof($arrMessage['education']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['education']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['education']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>		
					</div>
				<?php }?>
				<!-- End of education Status -->
				<!-- Start of affiliation Status -->
				<?php if(isset($arrMessage['affiliation'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Affiliation info Import Status</label> :
					<?php if(isset($arrMessage['affiliation']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['affiliation']['no_pin_num']) && sizeof($arrMessage['affiliation']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['affiliation']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['affiliation']['no_matching_pin_num']) && sizeof($arrMessage['affiliation']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['affiliation']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['affiliation']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>			
					</div>
				<?php }?>
				<!-- End of affiliation Status -->
				<!-- Start of event Status -->
				<?php if(isset($arrMessage['event'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Event info Import Status</label> :
					<?php if(isset($arrMessage['event']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['event']['no_pin_num']) && sizeof($arrMessage['event']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['event']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['event']['no_matching_pin_num']) && sizeof($arrMessage['event']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['event']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['event']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>			
					</div>
				<?php }?>
				<!-- End of event Status -->
				<!-- Start of publication Status -->
				<?php if(isset($arrMessage['publication'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Publication info Import Status</label> :
					<?php if(isset($arrMessage['publication']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['publication']['no_pin_num']) && sizeof($arrMessage['publication']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['publication']['no_matching_pin_num']) && sizeof($arrMessage['publication']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>		
					<?php if(isset($arrMessage['publication']['pmid_exist']) && sizeof($arrImportStatusMsg['publication']['pmid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing publications : </p>
					content-box				<ul class="unorder-list">	
									<?php foreach($arrMessage['publication']['pmid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['publication']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>			
					</div>
				<?php }?>
				<!-- End of publication Status -->
				<!-- Start of trial Status -->
				<?php  if(isset($arrMessage['trial'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Trial info Import Status</label> :
					<?php  if(isset($arrMessage['trial']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['trial']['no_pin_num']) && sizeof($arrMessage['trial']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['trial']['no_matching_pin_num']) && sizeof($arrMessage['trial']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	?>		
					<?php if(isset($arrMessage['trial']['ctid_exist']) && sizeof($arrMessage['trial']['ctid_exist'])>0){ ?>
								<div class="well"> 
									<p class="title-header">Already Existing trials : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['trial']['ctid_exist'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }		
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['trial']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>			
					</div>
				<?php }?>
				<!-- End of trial Status -->
				<!-- Start of media Status -->
				<?php  if(isset($arrMessage['media'])) { ?>
					<div class="col-md-12">
					<label class="statusCategory">Media info Import Status</label> :
					<?php  if(isset($arrMessage['media']['success'])) { ?>
					<label class="successStatus">Import Success</label>
					<?php if(isset($arrMessage['media']['no_pin_num']) && sizeof($arrMessage['media']['no_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No PIN Number : : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['media']['no_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }?>
					<?php if(isset($arrMessage['media']['no_matching_pin_num']) && sizeof($arrMessage['media']['no_matching_pin_num'])>0){ ?>
								<div class="well"> 
									<p class="title-header">No Matching PIN in database : </p>
									<ul class="unorder-list">	
									<?php foreach($arrMessage['media']['no_matching_pin_num'] as $key => $value){
										echo '<li>'.$value.'</li>';
										} ?>
									 </ul>
								</div>
							<?php }	
						 } ?>
					<?php if(isset($arrMessage['professional']['upload_error'])) {?>
						<label class="errorStatus">File Upload Error</label>
					<?php }?>
					<?php if(isset($arrMessage['professional']['file_type_missmatch'])) {?>
						<label class="errorStatus">File Type mismatch</label>
					<?php }?>
					<?php if(isset($arrMessage['media']['incorrect_format'])) {?>
						<label class="errorStatus">Incorrect File Format</label>
					<?php }?>				
					</div>
				<?php }?>
				<!-- End of media Status -->
				
		<?php }
		} ?>
</div>
<div class="clearfix"></div>
<script>
	$(document).ready(function(){
		var data = <?php echo json_encode($data1);?>;
  jQuery("#JQBlistAffResultSet").jqGrid({
		  		  
					datatype: "jsonstring",
			        datastr: data,
					colNames:['Id','Kol Name','Educations','Affiliations','Events','Publications','Events'],
				   	colModel:[
								{name:'id',index:'id', hidden:true},
						   		{name:'name',index:'name',width:500, resizable:false},
						   		{name:'eduCountAfterImport',index:'medicalCountAfterImport',width:500, resizable:false},
						   		{name:'affCountAfterImport',index:'affCountAfterImport',width:500, resizable:false},
						   		{name:'eventCountAfterImport',index:'eventCountAfterImport',width:500, resizable:false},
						   		{name:'pubCountAfterImport',index:'pubCountAfterImport',width:500, resizable:false},
						   		{name:'trailCountAfterImport',index:'trailCountAfterImport',width:500, resizable:false}
						   		
				   	],
				   	rowNum:100,
				   	rownumbers: true,
				   	autowidth: true, 
					
					gridComplete: function(){ 
			    		jQuery("#JQBlistAffResultSet").jqGrid('navGrid','hideCol',"id"); 
			    		var ALL = '<?php echo $count?>' ;
			    		$.each($('.ui-pg-selbox'),function(){
			    			$(this).children('option:last').val(ALL).text('All');
			    		});
			    	}, 
				   	loadonce:true,
				   	multiselect: false,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",
				   	width: 800,  
				   	pager: '#listlistAffPage',
				   	toppager:false,
				   	mtype: "POST",
				   	sortname: 'name',
				    viewrecords: true,
				    sortorder: "desc",
					rowList:paginationValues,
				    jsonReader: { repeatitems : false, id: "0" },
				    //toolbar: "top",
				    caption:"Imported Counts",
				    rowList:[<?php echo listRecordsPerPage()?>]
			   	
				});
	
				jQuery("#JQBlistAffResultSet").jqGrid('navGrid','#listlistAffPage',{edit:false,add:false,del:false,search:false,refresh:false});
				
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistAffResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistAffResultSet").jqGrid('navButtonAdd',"#listlistAffPage",{
					caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}							
					} 
				}); 
	});
</script>

<div id="affsListingContainer" class="content-box">
	<div id="searchResultsContainer" class="col-md-12">
		<div class="gridWrapper" id="gridContainer">
			<div id="listlistAffPage"></div>
			<table id="JQBlistAffResultSet"></table>
		</div>	
	</div>
</div>