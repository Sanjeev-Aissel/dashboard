<?php if (!IS_IPAD_REQUEST) { ?>
<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
<!-- jQuery Block UI Plugin -->
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.blockUI.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>
	
<!--<script type="text/javascript" src="<?php echo base_url()?>js/tooltip/jquery.js"></script>-->
<?php } else { ?>
<!--  <script type="text/javascript" src="<?php echo base_url() ?>js/jquery-v1.11.3.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-ui-1.11.3/jquery-ui.min.js" ></script>
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>js/jquery-ui-1.11.3/jquery-ui.min.css" />
   <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">

        <link rel="stylesheet" href="<?php echo base_url(); ?>css/ipad/client_layout.css">
             <script type="text/javascript" src="<?php echo base_url() ?>js/jquery.blockUI_v2.7.js"></script>-->
<?php } ?>
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('i18n/grid.locale-en',
    'jquery.jqGrid.min',
    'chosen.jquery'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
$client_id = (int) $this->session->userdata('client_id');


?>
           
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />
<link href="<?php echo base_url();?>css/tooltip/bootstrap.css" rel="stylesheet">

	
	 <!--jQuery UI File--> 
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.alerts.js" ></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/jquery.alerts.css" />
         <!--2nd Plugin for Validation--> 
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
	 <!--JQGrid Plugins--> 
        
        
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min_3.8.js" type="text/javascript"></script>
	
	
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    #load_listUsersResultSet
    {
        display:none !important;
    }
   
    .gridWrapper {
        width: 100%;
    }
    th.ui-th-column div {
        height: auto !important;
        overflow: hidden !important;
        padding: 2px;
        white-space: normal !important;
    }
    .ui-th-ltr, .ui-jqgrid .ui-jqgrid-htable th.ui-th-ltr{
        vertical-align: top;
    }
    #userContainer{
         height: 520px !important;
    }
    .ui-helper-clearfix::after {
    clear:none !important;
    content: ".";
    display: block;
    visibility: hidden;
    height:20px !important;
}
</style>
<script type="text/javascript">
    
    $(document).ready(function () {
       
        list_users_grid();
        var userProfileDialogOpts = {
				title: "Add/Edit Client User",
				modal: true,
				autoOpen: false,
				height: 400,
				width: 450,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				},
				close:function(){
				
				}
		};
		$("#userContainer").dialog(userProfileDialogOpts);
    });
   
    
 
    function listRecordsPerPage(maxRecords, increament) {
        var rowList = new Array();
        for (i = increament; i <= maxRecords; i += increament) {
            rowList.push(i);
        }
        return rowList;
    }

    /** 
     * Show/Hide the Search Tool Bar in the JQGrid
     */
    function toggleSearchToolbar() {
        if (jQuery(".ui-search-toolbar").css("display") == "none") {
            jQuery(".ui-search-toolbar").css("display", "");
        } else {
            jQuery(".ui-search-toolbar").css("display", "none");
        }
    }
    
     
    function list_users_grid() {  
        var ele = document.getElementById('usersList');
        var gridWidth = ele.clientWidth;
        $('#usersList').html('');
        $('#usersList').html('<div class="gridWrapper"><div id="listCoachingsPage"></div><table id="listUsersResultSet"></table><div>');
        jQuery("#listUsersResultSet").jqGrid({
            url: '<?php echo base_url(); ?>user_settings/list_users/',
            datatype: "json",
            colNames: ['', 'Username', 'Email', 'Company Name', 'Contact','Role', 'Clients', 'Actions'],
            colModel: [
                {name: 'id', index: 'id', width: 0, hidden: true, search: false, resizable: false},
                {name: 'user_name', index: 'user_name', width: 100, search: true},
                {name: 'email', index: 'email', width: 100, search: true},
                {name: 'company_name', index: 'company_name', width: 80, search: true},
                {name: 'contact', index: 'contact', width: 100, search: true},
                {name: 'user_role_name', index: 'user_role_name', width: 100, search: true},
                {name: 'name', index: 'name', width: 80, search: true, resizable: false,hidden: true,},
                {name: 'act', width: 50, hidden: false, align: 'center', search: false}
            ],
                
            rowNum: 10,
            multiselect: false,
            rownumbers: true,
            autowidth: false,
            width: gridWidth,
            loadonce: true,
            ignoreCase: true,
            hiddengrid: false,
            height: "auto",
            pager: '#listCoachingsPage',
            mtype: "POST",
            sortname: 'name',
            viewrecords: true,
            sortorder: "desc",
            shrinkToFit: true,
            jsonReader: {repeatitems: false, id: "0"},
            caption: 'Users',
          
            gridComplete: function () {
               
                var arrIds = jQuery("#listUsersResultSet").jqGrid('getDataIDs');
                // Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
                var roleId = '<?php echo $this->session->userdata('user_role_id') ?>';
                var role = '<?php echo ROLE_MANAGER ?>';
                for (var i = 0; i < arrIds.length; i++) {
                    var id = arrIds[i];
                    var rowData = jQuery('#listUsersResultSet').jqGrid('getRowData', id);
//                                        alert((rowData.id));
                    //Edit and Delete labels 
                    var actionLink = '';
                    actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editClientUser('" + rowData.id + "'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";



                    jQuery("#listUsersResultSet").jqGrid('setRowData', arrIds[i], {act: actionLink});
                   

                  
                }
                jQuery("#listUsersResultSet").jqGrid('navGrid', 'hideCol', "id");
                //Initialize the tooltips
//                initializeCustomToolTips();
               
              
                
            },
            rowList: paginationValues
        });
        jQuery("#listUsersResultSet").jqGrid('navGrid', '#listCoachingsPage', {edit: false, add: false, del: false, search: false, refresh: false});
        //Toolbar search bar below the Table Headers
        jQuery("#listUsersResultSet").jqGrid('filterToolbar', {stringResult: true, searchOnEnter: false, defaultSearch: "cn"});
        //Toggle Toolbar Search 
        jQuery("#listUsersResultSet").jqGrid('navButtonAdd', "#listCoachingsPage", {caption: "Search", buttonicon: "ui-icon-search", title: "Toggle Search",
            onClickButton: toggleSearchToolbar
        });
      
   
        jQuery("#listUsersResultSet").jqGrid('setGridWidth', gridWidth);
        
    }
    function editClientUser(clientUserId){
   
                $('#usersList').hide();
              
		$(".addUserContent").show();
		$(".addUserContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$(".addUserContent").load(base_url+'client_users/edit_user/'+clientUserId);  
	}
  
    function closeEditUserDialog(){
		$("#userContainer").dialog("close");	
	}
   function saveUserDetail(){

		var userName = $('#userName').val();

		var spaceIndex = userName.indexOf(' ', 0);
		if(spaceIndex > -1){
		
			jAlert('space not allowed for the Username');
			return false;
			
		}
		if(!$("#saveUser").validate().form()){
			return false;
		}
		$('div.clientUserMsgBox').removeClass('success');
		$('div.clientUserMsgBox').addClass('notice');
		$('div.clientUserMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

		id=$("#userId").val();
		if(id==''){
			action = '<?php echo base_url();?>client_users/save_user';
		}else{
			action = '<?php echo base_url();?>client_users/update_user';
		}
			$.ajax({
				type:'post',
				url:action,
				data:$("#saveUser").serialize(),
				dataType:'json',
				success:function(returnData){
							$('.clientUserMsgBox').text(returnData.msg);
                                                        $('.clientUserMsgBox').fadeOut(2000);
                                                        setTimeout(closeEditUserDialog,3000);
                                                         $('.addUserContent').hide();
              
                                                            $("#usersList").show();
							    list_users_grid();
				}
				
			 });


	}
        function cancelUserDetail(){
                $('.addUserContent').hide();
              
		$("#usersList").show();
		  
                list_users_grid();
        }
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Users</h3></div>
	</div>
</div>
<div style="width: 100%; margin: auto;" class="">

    <div id="usersList"  ></div>
  <div class="addUserContent"></div>
</div>

