<?php
/**
 * This is Controller is for Call Plans Uploading
 *
 * @author Vinod R H
 * @since
 * @package application.controllers
 * @created on 20-07-2017
 */


class Optinout_addhcp_import extends Controller{
    
    function Optinout_addhcp_import(){
        parent::Controller();
        $this->load->model("kol");
        $this->load->model("kol_consent");
        $this->load->library('form_validation');
        $this->load->model("country_helper");
        $this->loggedUserId = $this->session->userdata('user_id');
    }
    
    function add($type=''){
        //form exection and upload script
        //error_reporting(E_ALL);
        if(isset($_POST['ktl_upload'])){
            $error = array();
            
            //print_r($_FILES);exit;
            $this->form_validation->set_rules('afile', 'Document', 'callback_file_selected');
            
            if ($this->form_validation->run() == FALSE) {
                $data['contentPage'] 	= 'kols/optinout_import';
                $this->load->view('layouts/analyst_view',$data);
//                 $this->load->view('kols/optinout_import');
            }else{
                $file_type = explode('.', $_FILES["afile"]['name']);
                if($file_type[1]=='xls'){
                    $folder_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/optinout_ktl/";
                    $file_info = $_FILES["afile"]['name'];
                    $file_target_path = $folder_path.$file_info;
                    //echo $file_target_path;exit;
                    if(move_uploaded_file($_FILES['afile']['tmp_name'],$file_target_path)){
                        $data['result'] = $this->_upload($file_info,$type);
                        //echo 'Info'.$result;
                        //exit;
                        $data['contentPage'] 	= 'kols/optinout_import';
                        $this->load->view('layouts/analyst_view',$data);
//                         $this->load->view('kols/optinout_import', $data);
                    }else{
                        $data['error'] = 'Failed to upload file!';
                        $data['contentPage'] 	= 'kols/optinout_import';
                        $this->load->view('layouts/analyst_view',$data);
//                         $this->load->view('kols/optinout_import', $data);
                    }
                }else{
                    $data['error'] = 'File formate should be .xls extension!';
                    $data['contentPage'] 	= 'kols/optinout_import';
                    $this->load->view('layouts/analyst_view',$data);
//                     $this->load->view('kols/optinout_import', $data);
                    
                }
            }
            
            
        }else{
            $data['contentPage'] 	= 'kols/optinout_import';
            $this->load->view('layouts/analyst_view',$data);
//             $this->load->view('kols/optinout_import');
        }
    }
    
    function file_selected(){
        $this->form_validation->set_message('file_selected', 'Please select file.');
        if (empty($_FILES['afile']['name'])) {
            return false;
        }else{
            return true;
        }
    }
    
    function _upload($file_info,$type=''){
        ini_set("max_execution_time",7200);
        ini_set('memory_limit', '-1');
        $this->load->plugin("excelreader/reader2");
        //Uploaded file path
        $folder_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/optinout_ktl/";
        $file_path = $file_info;
        $file = $folder_path.$file_path;
        $clientId = 17;
        $reader	=	new Spreadsheet_Excel_Reader($file, true, 'utf-8');
        $info = 'KTL import processing started<br />';
        $emailExist = "Email Id already exist for following Records <br />";
        $emailExistContent = "";
        $dataExist = "First Name, Last Name, Country already exist for following Records <br />";
        $dataExistContent = "";
        $userExist = "User Email Address not exist for following Records <br />";
        $userExistContent = "";
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        foreach ($reader->boundsheets as $k=>$sheet){
            $info .= 'sheet name '.$sheet['name'].' processing started<br />';
            if (strcasecmp(trim($sheet['name']),'KTL Details')==0) {
                $row = 1;
                if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"Salutation")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"First Name")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Last Name")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"KTL Email Address")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Country")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"User name")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"User Email Address")!=0 ||
                    strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Language")!=0){
                        $info .= 'KTL header formate is incorrect <br />';
                }else{
                    for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
                        //Check Duplicate KTL If exist by email id skip the process if exist else continue
                        $email = $this->kol_consent->checkKtlByEmailId(trim($reader->sheets[$k]["cells"][$row][4]));
                        if($email){
                            
                            $emailExistContent .= 'Salutation | First Name | Last Name | KTL Email Address | Country | User name | User Email Address <br/>';
                            $emailExistContent .= trim($reader->sheets[$k]["cells"][$row][1]).' | '.trim($reader->sheets[$k]["cells"][$row][2]).' | '.trim($reader->sheets[$k]["cells"][$row][3]).' | '.trim($reader->sheets[$k]["cells"][$row][4]).' | '.trim($reader->sheets[$k]["cells"][$row][5]).' | '.trim($reader->sheets[$k]["cells"][$row][6]).' | '.trim($reader->sheets[$k]["cells"][$row][7]).'<br/>';
                            continue;
                        }
                        //Check Duplicate KTL If exist by first_name,last_name,country_id skip the process if exist else continue
                        $arrCheckDupicate =array();
                        $arrCheckDupicate['first_name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                        $arrCheckDupicate['last_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                        $country_name = trim($reader->sheets[$k]["cells"][$row][5]);
                        $arrCheckDupicate['country_id'] = $this->country_helper->checkCountryIfExistElseAdd($country_name);
                        $dataExist = $this->kol_consent->checkKtlByFNLNCI($arrCheckDupicate);
                        if($dataExist){
                            $dataExistContent .= 'Salutation | First Name | Last Name | KTL Email Address | Country | User name | User Email Address <br/>';
                            $dataExistContent .= trim($reader->sheets[$k]["cells"][$row][1]).' | '.trim($reader->sheets[$k]["cells"][$row][2]).' | '.trim($reader->sheets[$k]["cells"][$row][3]).' | '.trim($reader->sheets[$k]["cells"][$row][4]).' | '.trim($reader->sheets[$k]["cells"][$row][5]).' | '.trim($reader->sheets[$k]["cells"][$row][6]).' | '.trim($reader->sheets[$k]["cells"][$row][7]).'<br/>';
                            continue;
                        }
                        
                        //Check the User exist in db
                        $userEmail = trim($reader->sheets[$k]["cells"][$row][7]);
                        $userId = $this->kol_consent->getUserIdByEmail($userEmail); //Check user if exist get user id else skip
                        if(!$userId){
                            $userExistContent .= 'Salutation | First Name | Last Name | KTL Email Address | Country | User name | User Email Address <br/>';
                            $userExistContent .= trim($reader->sheets[$k]["cells"][$row][1]).' | '.trim($reader->sheets[$k]["cells"][$row][2]).' | '.trim($reader->sheets[$k]["cells"][$row][3]).' | '.trim($reader->sheets[$k]["cells"][$row][4]).' | '.trim($reader->sheets[$k]["cells"][$row][5]).' | '.trim($reader->sheets[$k]["cells"][$row][6]).' | '.trim($reader->sheets[$k]["cells"][$row][7]).'<br/>';
                            continue;
                        }
                        
                        $arrKolData = array();
                        $arrKolData['first_name'] = trim($reader->sheets[$k]["cells"][$row][2]);
                        $arrKolData['last_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
                        $arrKolData['primary_email'] = trim($reader->sheets[$k]["cells"][$row][4]);
                        //                         $country_name = trim($reader->sheets[$k]["cells"][$row][5]);
                        $arrKolData['country_id'] = $this->country_helper->checkCountryIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][5]));
                        $arrKolData['salutation'] = array_search(trim($reader->sheets[$k]["cells"][$row][1]), $arrSalutations);
                        if (!$arrKolData['salutation']) {
                            $arrKolData['salutation'] = '';
                        }
                        $arrKolData['created_by'] = $userId;
                        $arrKolData['created_on'] = date('Y-m-d H:i:s');
                        $arrKolData['modified_by'] = $userId;
                        $arrKolData['modified_on'] = date('Y-m-d H:i:s');
                        $arrKolData['opt_in_out_date'] = date('Y-m-d H:i:s');
                        $arrKolData['profile_type'] = USER_ADDED;
                        $langName = trim($reader->sheets[$k]["cells"][$row][8]);
                        $arrKolData['primary_language_id'] = $this->kol_consent->getLangIdByName($langName);
                        //Save KTL
                        $kolId = $this->kol->saveKolInfo($arrKolData);
                                                
                        if($kolId){
                            //Log activity
                            $arrLogDetails = array(
                                'module'=>"opt_in_out",
                                'description'=>'New Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$userId,
                                'type' => 'New Url',
                                'status' => STATUS_SUCCESS,
                                'user_id' => $userId,
                                'transaction_table_id'=>'',
                                'transaction_name'=>'New',
                                'miscellaneous1'=>$kolId
                            );
                            $this->config->set_item('log_details', $arrLogDetails);
                            log_user_activity(null, true);
                            
                            $dataType = 'User Added';
                            $client_id =$this->session->userdata('client_id');
                            if($client_id == INTERNAL_CLIENT_ID){
                                $dataType = 'Aissel Analyst';
                            }
                            //Assign User
                            $arrAssData = array();
                            $arrAssData['created_by'] = $userId;
                            $arrAssData['created_on'] = date('Y-m-d H:i:s');
                            $arrAssData['user_id'] = $userId;
                            $arrAssData['kol_id'] = $kolId;
                            $arrAssData['data_type_indicator'] = $dataType;
                            $arrAssData['type'] = 1;
                            $saveAssignId = $this->kol->saveAssignClient($arrAssData);
                            
                            //Associate kols client visibility
                            $userClientId = $this->kol_consent->getUserClientIdByEmail($userEmail);
                            $this->save_kol_client_association($kolId,'fromKol',$userClientId);
                            //Get lang name by lang id
                            $langName = $this->kol_consent->getLanguageNameByLangId($kolId);
                            $landingContent ='';
                            $landingMissionCaption ='';
                            $landingMissionContent ='';
                            //echo $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/system/language/".$langName."/kolm_lang.php";
                            if($langName!='english'){
                                require_once($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/system/language/".$langName."/kolm_lang.php");
                            }
                            //Opt-in/Opt-out Processing
                            $date = date('Y-m-d H:i:s');
                            $arrLinkData = array();
                            $arrLinkData['kol_id'] = $kolId;
                            $arrLinkData['unique_id'] = md5($kolId.$date);
                            $arrLinkData['status'] = 0;
                            $arrLinkData['created_by'] = $userId;
                            $arrLinkData['created_on'] = date('Y-m-d H:i:s');
                            $arrLinkData['note'] = '';
                            $arrLinkData['upload_file_content'] = '';
                            $query = $this->kol_consent->generateUrlLink($arrLinkData);
                            $kolName = $this->kol_consent->getKolNameByKolId($kolId);
                            if($langName!='english'){
                                $landingContent = $lang['OptInOutEmail.LandingContent'];
                                $landingMissionCaption = $lang['OptInOutEmail.LandingMissionCaption'];
                                $landingMissionContent = $lang['OptInOutEmail.LandingMissionContent'];
                            }else{
                                $landingContent = lang('OptInOutEmail.LandingContent');
                                $landingMissionCaption = lang('OptInOutEmail.LandingMissionCaption');
                                $landingMissionContent = lang('OptInOutEmail.LandingMissionContent');
                            }
                            if($query > 0 || $query == 'updated'){
                                //Log activity
                                $arrLogDetails = array(
                                    'module'=>"opt_in_out",
                                    'description'=>'Requested Opt-In / Opt-Out Invite for KTL '.$kolId.' by '.$userId,
                                    'type' => 'Requested Url',
                                    'status' => STATUS_SUCCESS,
                                    'user_id' => $userId,
                                    'transaction_table_id'=>'',
                                    'transaction_name'=>'Opt-in Requested',
                                    'miscellaneous1'=>$kolId
                                );
                                $this->config->set_item('log_details', $arrLogDetails);
                                log_user_activity(null, true);
                                //$data['status'] = true;
                                //Email Notification
                                $ktlEmailId = $arrKolData['primary_email'];
                                $urlLink = base_url().'kol_consents/change_language/'.$arrLinkData['unique_id'].'/'.$langName.'/page';
                                $url	= '<a href="'.$urlLink.'" style="font-style: italic;font-weight:bold">'.$urlLink.'</a>';
                                $subject = "Opt-In / Opt-Out Invite for KTL $kolName";
                                $popUpContent = "Below is the opt in opt out form link generated for the KTL $kolName,
    								$url
    							    You can now forward this email to “".$kolName."” and get the consent to feature in the Hills KTL Application.";
								$img = '<img src="'.base_url().'images/optinlandingimg.png" style="display:block;text-align:center" width="850" height="656">';
								$content = "<table width='900' border='0' cellspacing='0' cellpadding='0' style='border-spacing: 0;border-collapse: collapse;margin:0 auto'>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>KTL Email Id: $ktlEmailId </p></td></tr>";
								$content .="<tr><td align='center'> <h2 style='margin:0.83em 0;text-align:center;'>$landingContent</h2></td></tr>";
								$content .="<tr><td align='center'><p style='margin:1em 0;'>$url</p></td></tr>";
								$content .="<tr><td align='center'>$img</td></tr>";
								$content .="<tr><td align='center' style='color:#000'><h2 style='margin:1em 0;'>$landingMissionCaption</h2><p style='margin:1em 0;font-size: 18px;'>$landingMissionContent</p></td></tr>";
								$content .="</table>";
                                $emailStatus = $this->send_email_notification($subject,$content,$kolId);
                            }
                        }
                        ob_clean();
                    }
                }
            }else{
                $info .= 'sheet name '.$sheet['name'].' mismatched<br />';
            }
            $info .= 'sheet name '.$sheet['name'].' processing completed<br />';
        } //loop
        $info .= 'KTL processing completed<br />';
        if($emailExistContent!=''){
            $emailExist .= $emailExistContent;
        }else{
            $emailExist ='';
        }
        if($dataExistContent!=''){
            $dataExist .= $dataExistContent;
        }else{
            $dataExist = '';
        }
        if($userExistContent!=''){
            $userExist .= $userExistContent;
        }else{
            $userExist ='';
        }
        return $info.'<br/>'.$emailExist.'<br/>'.$dataExist.'<br/>'.$userExist;
    }
    
    //Function to save association or disassociation KOLs to particular client
    function save_kol_client_association($kolId=null,$fromKol='',$clientId){
        $arrAssociationData['kol_id'] = $kolId;
        $arrAssociationData['client_id'] = $clientId;
        $arrAssociationData['associationFlag'] = 'associate';
        $returnData = $this->kol->saveKolClientAssociation($arrAssociationData);
        if($returnData){
            $status = true;
        }else{
            $status = false;
        }
        if($fromKol==''){
            echo json_encode($status);
        }else{
            return $status;
        }
    }
    
    /**
     * Sends a mail of success and faliure of the Opt In - Opt Out
     * @param string $subject
     * @param string $content
     * @param string $emailId
     */
    function send_email_notification($subject,$content,$kolId){
        $emailIds = '';
        $seperator = '';
        $user_email = $this->kol_consent->getAssignedUserEmails($kolId);
        foreach($user_email as $row){
            $emailIds .= $seperator."'".$row."'";
            $seperator = ',';
        }
        //     	$emailId = 'vhanagal@gmail.com';
        $fromEmail	= OPTINOUT_SENDER;
        $note = nl2br($content);
        /* $config['protocol']  = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] 		= 'html'; */
        $config = email_config_initializer('optinout');
        $this->load->library('email', $config);
        $this->email->initialize($config);
        $this->email->from($config['smtp_user'],$fromEmail);
        $this->email->to($user_email);
        $this->email->message($note);
        $this->email->subject($subject);
        if($this->email->send()){
            //Log Activity
            $arrLogDetails = array(
                'description'=>$note.'-----'.$kolId,
                'type' => 'Email Notification',
                'status' => STATUS_SUCCESS,
                'transaction_table_id'=>'',
                'transaction_name'=>"Email sent to ".$emailIds
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status	=  true;
        }else{
            //Log Activity
            $arrLogDetails = array(
                'description'=>$note.'-----'.$kolId,
                'type' => 'Email Notification',
                'status' => STATUS_FAIL,
                'transaction_table_id'=>'',
                'transaction_name'=>"Email Not sent to ".$emailIds
            );
            $this->config->set_item('log_details', $arrLogDetails);
            // 			log_user_activity(null, true);
            $status 	=  false;
        }
        $this->email->clear(TRUE);
        return $status;
    }
    
}
