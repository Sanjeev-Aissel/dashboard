<script type="text/javascript">
$('#user_settings').click(function () {
        $id = '<?php if($displayContent) echo $getSavedDetails['id'];?>';
        $.ajax({
            url: '<?php echo base_url() ?>user_settings/add_application_settings',
            type: 'post',
            dataType: 'json',
            data: $('#user_form_settings').serialize(),
            beforeSend: function(){
    			$("#user_settings").attr("disabled", true);
            },
            success: function (returnData) {
                if (returnData.status == true) {
                	jAlert('User Settings saved successfully', 'highlight', function(result) {
                		window.location	= "<?php echo base_url().'user_settings';?>";
                    });
                } else {
                	jAlert('Error saving User Settings', 'highlight', function(result) {
                		window.location	= "<?php echo base_url().'user_settings';?>";
                    });
                }
            }
        });
        return false;
    });
function myFunction() {
	$("select option").removeAttr("selected", false);
	//$("#user_settings").click();
}
</script>
<div class="msgBox"></div>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>User Settings</h3></div>
	</div>
</div>
<div>
	<form action="" method="post" id="user_form_settings">
		<table class="userDetails" style="width:50% !important;">
		<?php //if(isset($getSavedDetails)) { foreach ($getSavedDetails as $value=>$key) {?>
			<?php foreach($arrOptions as $settingTypeId=>$arrOptionsRow){?>
				<tr>
					<th><?php echo $arrOptionsRow['lable_name'];?> :</th>
					<td>
						<div id="languageBar">
						
							<select name="user_settings[<?php echo $settingTypeId;?>]" id="<?php echo $arrOptionsRow['name'];?>" style="min-width: 130px;">
							
					            <?php foreach ($arrOptionsRow['values'] as $valueId=>$arrValueRow){?>
					            
					            	<option value="<?php echo $valueId;?>" <?php if($arrOptionsRow['saved_value'] == $valueId) echo 'selected';?>><?php echo $arrValueRow['type_lable'];?></option>
					            	 
					            <?php }?>
					        
							</select>
							 
						</div>
					</td>
				</tr>
				
			<?php }?>
			<?php //if(isset($getSavedDetails)) { } }}?>  
			<tr>
				<td colspan="2" style="text-align:center;">
					<div id="submitBtn">
						<input type="submit" value="Save Changes" id="user_settings" name="submit" class="btn btn-info">
						<input type="button" onclick="myFunction()" value="Reset">
					</div>
				</td>
			</tr>
		</table>
	</form>
</div>
