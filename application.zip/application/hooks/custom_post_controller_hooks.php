<?php
/**
 * All Post Controller Hook methods
 * @author Ramesh B
 * @since 3.4
 * @package application.controllers	
 * @created 21-11-2011
 */



if (!defined('BASEPATH')) exit('No direct script access allowed');



class Custom_post_controller_hooks

{

	var $CI;
    var $lang;
    
    // No Comments 
    function __construct(){
    	$this->CI =& get_instance();
    	$this->CI->load->helper('url');
    	$this->CI->load->model('common_helpers');
    	require_once($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."application/libraries/mobile_device_detect.php");
    	//As of now we are not using the functionalities provided by this, remove the comments if u want to use
    	//require_once($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."application/libraries/Browscap.php");
    }
    

	/**
	 * Enables the Profile if the Project Environment is 'development'
	 * @author Ramesh B
	 * @since 3.4
	 * @created 21-11-2011
	 */
    function enable_profiler(){
    	if (ENVIRONMENT == 'development'){
			if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			 	//don't eanble profiler
			 	//$this->CI->load->library('Console');
				//$this->CI->output->enable_profiler(true);
			}else{
				//$this->CI->load->library('Console');
				//$this->CI->output->enable_profiler(true);
			}
		}else{
			if($this->CI->session->userdata('user_id')==11){
				if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
				 	//don't eanble profiler
				 	//$this->CI->load->library('Console');
					//$this->CI->output->enable_profiler(true);
				}else{
					//$this->CI->load->library('Console');
					//$this->CI->output->enable_profiler(true);
				}
			}
		}
    }
    
	/**
	 * Checks the user login status from session, redirects to login page in user not logged in
	 * and alos check for UNDER_MAINTENANCE
	 * @author Ramesh B
	 * @since 3.4
	 * @created 28-11-2011
	 */
    function userLoginCheck(){
   
if($this->CI->session->userdata('logged_in')){
		$currentController=$this->CI->uri->segment(1);
		$currentMethod=$this->CI->uri->segment(2);
		$ipadUserSettings = 'i/user_settings';
		$mobileUserSettings = 'm/user_settings';		        
	//	echo $currentController;
		//echo $currentMethod;
	//print_r($this->CI->session->userdata);
	if($this->CI->session->userdata['passwordStatus'] && ($currentController!='user_settings' && $currentController.'/'.$currentMethod != $ipadUserSettings && $currentController.'/'.$currentMethod != $mobileUserSettings && $currentMethod!='logout' && $currentMethod !='logins')){    
		redirect('/user_settings/index/password');
		
	}
	/* $arrApproverIds	= explode(',',APPROVER_IDS);
	if(in_array($this->CI->session->userdata('user_id'),$arrApproverIds)){
		define('IS_APPROVER',true);
	}else{
		define('IS_APPROVER',false);
	} */
	//define('IS_APPROVER',$checkApproverId); 
	$user_id = $this->CI->session->userdata('user_id');
	$arrApproverIds = $this->CI->common_helpers->checkApproverId();
	define('APPROVER_IDS',implode(",",$arrApproverIds));
	if(in_array($user_id,$arrApproverIds)){
		define('IS_APPROVER',true);
	}else{
		define('IS_APPROVER',false);
	}
}
    	if( !$this->checkForAllowedUrlsWithoutLogin()){
	    		if(UNDER_MAINTENANCE == 1){
	    			redirect(base_url()."login");
	    		}
	    		else if(!$this->CI->session->userdata('logged_in')) {
	    			if(IS_AJAX) {
	    				//echo 'Session has been expired.<br />Redirecting to Login page..<br /> please wait..';
	    				//echo 'Session has been expired.<br />Refresh your page';
	    				//echo '<script type="text/javascript">	window.location.reload();</script>';
	    				//echo "<div style='padding-left:5px;'>Session is expired, please <a href='".base_url()."'>click here</a> to login</div><div><label name='No results found for " . $kolName . "' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
	    				//exit();
	    			}else{
	    				$currentURI = $this->CI->uri->uri_string();
	    				$this->CI->session->set_userdata("back_url",$currentURI);
                                        if($this->CI->uri->segment(1) == 'm'){
                                            redirect(base_url()."".MOBILE_URL_SEGMENT."/logins");
                                        }else{
                                            redirect(base_url()."login");
                                        }
	    				//echo "Page request";
	    				
	    			}
				}
				//if he logged in and his last login is more than one day then add user analytics and update the session last logged in time
				$currentTimeStamp = time();
				//$this->CI->session->set_userdata("user_last_login",date('Y-m-d H:i:s', time() - 86400*2));
				$lastLoginTimeStamp = strtotime($this->CI->session->userdata("user_last_login"));
				$numDays = abs($lastLoginTimeStamp - $currentTimeStamp)/60/60/24;
				if($numDays > 1){
					//add the user analytics
					$arrUserAnalytics['user_id']	=$this->CI->session->userdata('user_id');
					$arrUserAnalytics['is_login_failed']=0;
					$arrUserAnalytics['username'] =$this->CI->session->userdata('user_name');
					$arrUserAnalytics['login_time']	=date("Y-m-d H:i:s");
					$arrUserAnalytics['user_from']	='iProfile';
					
					if($this->CI->db->insert('users_analytics',$arrUserAnalytics)){
						$this->CI->session->set_userdata('user_analytics_id',$this->CI->db->insert_id());
						$this->CI->session->set_userdata("user_last_login",date("Y-m-d H:i:s"));
					}
					
					$arrLogDetails = array(
		                'type' => LOG_USER,
		                'description' => 'logged in',
		                'status' => 'success',
		                'transaction_table_id' => CLIENT_USERS,
		                'transaction_name' => "login"
		            );
		            $this->CI->config->set_item('log_details', $arrLogDetails);
		
		            log_user_activity($arrLogDetails, true);
            
				}
    		//if(!$this->CI->session->userdata('name_order')){
			//	$this->CI->session->set_userdata("name_order",3);
			//}	
			// set the name format
			$this->CI->db->where('id',$this->CI->session->userdata('user_id'));
			$nameFormat = $this->CI->db->get('client_users')->result_array();
			foreach ($nameFormat as $row){
				$format = $row['name_order'];
			}
			$this->CI->session->set_userdata("name_order",$format);	
		
    	}else{
    		// Checking the UNDER_MAINTENANCE value.if it 0 redirect it to login page
    		if(UNDER_MAINTENANCE == 1){
    			$this->CI->load->view('layouts/show_under_maintenance_page');
    		}
    	}
    }
   
    /**
	 * Hook to detect the the user agent and the browser of the request and redirect the request 
     * to  appropriate controller
	 * @author Ramesh B
	 * @since 3.4
	 * @created 30-11-2011
	 */
    function mobile_app_redirect(){
    	//Get the Mobile Platform details from the library 'mobile_device_detect'
		$mobile = mobile_device_detect();
             //pr($mobile);
              
		//pr($mobile);	
		
		//Get the Browser Details from the php native funtion 'get_browser'  using 'browsecap.ini'
		//$browser=get_browser(null, true);

		//Get the Browser Details from 'Browscap.php' file
		//As of now we are not using the functionalities provided by this, remove the comments if u want to use
		// Creates a new Browscap object (loads or creates the cache)
		//$bc = new Browscap($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."system/cache");				
		// Gets information about the current browser's user agent
		//$browser = $bc->getBrowser();
		
		
		$currentController=$this->CI->uri->segment(1);
		$currentMethod=$this->CI->uri->segment(2);
		if( ($currentController== 'login' || $currentController == '') && $currentMethod=='' ){
			//echo 'Platform : '.$mobile[1].',   Browser : '.$browser['browser'];
               
			if(isset($mobile[1])){
                    
				if(preg_match('/iPad/',$mobile[1])){
                                   
						redirect(base_url().IPAD_URL_SEGMENT."/login");
                                }
                                else{
                                     
					redirect(base_url().MOBILE_URL_SEGMENT."/logins");
                                    //exit;
                                    
                                }
			}
				
		}
    }
    
    /**
	 * checks for the allowed urls without login and returns true if it is allowed
	 * @author Ramesh B
	 * @since 3.4.2
	 * @return boolean
	 * @created 05-12-2011
	 */
    function checkForAllowedUrlsWithoutLogin(){
    	//Array of all the urls which are allowed without login
    	$arrAllowedUrls=array();
    	$arrAllowedUrls[]=array('login','');
    	$arrAllowedUrls[]=array('login','do_login');
        $arrAllowedUrls[]=array('m','cross_platform');
    	$arrAllowedUrls[]=array('login','login_failed');
    	$arrAllowedUrls[]=array('m','cross_platform');
        //$arrAllowedUrls[]=array('m','nearme');
    	$arrAllowedUrls[]=array('login','show_forgot_password_page');
    	$arrAllowedUrls[]=array('login','forgot_password');
    	$arrAllowedUrls[]=array('login','reset_password');
    	$arrAllowedUrls[]=array('login','update_password');
    	$arrAllowedUrls[]=array('login','process_sso_login');
    	$arrAllowedUrls[]=array('mobile','login');
    	$arrAllowedUrls[]=array('m','login');
        $arrAllowedUrls[]=array('m','logins');
        
         $arrAllowedUrls[]=array('m','login_from_app');
            	$arrAllowedUrls[]=array('i','login');
        $arrAllowedUrls[]=array('i','logins');
        $arrAllowedUrls[]=array('logins','do_login');        
    	$arrAllowedUrls[]=array('logins','login_failed');
        $arrAllowedUrls[]=array('logins','show_forgot_password_page');
    	$arrAllowedUrls[]=array('logins','forgot_password');
    	$arrAllowedUrls[]=array('logins','reset_password');
    	$arrAllowedUrls[]=array('logins','update_password');
    	$arrAllowedUrls[]=array('client_users','show_terms_page');
    	$arrAllowedUrls[]=array('pages','');
    	$arrAllowedUrls[]=array('client_users','user_form');
    	$arrAllowedUrls[]=array('client_users','save_user_registration_details');
         $arrAllowedUrls[]=array('m','media_intel_extractions');
        $arrAllowedUrls[]=array('media_intel_extractions','get_data');
        $arrAllowedUrls[]=array('media_intel_extractions','deleteNull');
         $arrAllowedUrls[]=array('media_intel_extractions','downloadServerFile');
        $arrAllowedUrls[]=array('media_intel_extractions','send_mail');
        $arrAllowedUrls[]=array('media_intel_extractions','prepareInsertStatmentsForSync');
    	//$arrAllowedUrls[]=array('client_users','show_terms_page');
    	$arrAllowedUrls[]=array('new_user_registration','');
		$arrAllowedUrls[]=array('signin','');
		$arrAllowedUrls[]=array('pubmeds','process_pubmeds');
		$arrAllowedUrls[]=array('pubmeds_org','process_pubmeds');
		$arrAllowedUrls[]=array('api');
		$arrAllowedUrls[]=array('register');
		$arrAllowedUrls[]=array('m','register');
		$arrAllowedUrls[]=array('contracts','email_contracts');
		$arrAllowedUrls[]=array('notifications','email_notification');
		$arrAllowedUrls[]=array('kol_consents');
    	$isAllowed=false;
    	foreach($arrAllowedUrls as $row){
    		$segment1=$this->CI->uri->segment(1);
    		$segment2=$this->CI->uri->segment(2);
    		if(isset($row[1]) && $row[1] == ''){
    			if($segment1==$row[0] && ($segment2 == null || $segment2 == ""))    			
    				$isAllowed=true;
    		}else{
    			if($segment1==$row[0] && $segment2==$row[1])
    				$isAllowed=true;
    		}
    		
    		if(count($row) == 1){
    			if($segment1==$row[0])
    				$isAllowed=true;
    		}
    		
    	}
    	return $isAllowed;
    }

    function permission(){
    	
    	$arrAccessObjects=array();
    	$roleId = $this->CI->session->userdata('user_role_id');
		$accessObject=array(); 
	
    	if(!(empty($roleId))){
    			$arrAccessObjects=$this->CI->session->userdata['access_objects'];

    //echo "<pre>";print_r($arrAccessObjects);
			$method= $this->CI->uri->segment(2);
			if(isset($arrAccessObjects[$method])){
				
				if($arrAccessObjects[$method]['is_allowed']==1){
					
				}else{
					$controller= $this->CI->uri->segment(1);
						if($controller=='kols'){
							if($method=='view'){
								
							}
						
					}else{
						if(isset($_SERVER['HTTP_REFERER'])){
							
							redirect($_SERVER['HTTP_REFERER']);
						}else{
							redirect(base_url(),'kols/client_index');
						}
					}
				}
			}
    	}
    	
    }
}

?>