<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<?php echo $html_form;?>
<div id="msgBox">
</div>
<script>
$(document).ready(function() {
		$("#saveKolPhoneNumberForm").validate({
			rules: {
		    	phone_type: {
		            required: true
		         },
		         phone_number: {
		         	required: true,
		         },
		         phone_location: {
		             required: true
		         }
			},
			messages: {
		    	phone_location: {
		            required: "Required"
		        },
		        phone_type: {
		            required: "Required"
		        },
		        phone_number: {
		        	required: "Required"
		        }
			}
		});		
});
</script>