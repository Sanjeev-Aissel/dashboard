<?php
/**
* File to 'List' Contacts details
*
* Created By: Ambarish
* Created On:13-12-2010
* 
*/
?>

<!--List Contacts details-->
<h1>List of Contacts details </h1>	
	<table border="2">
		<tr>
			<th>Related To</th>
			<th>Phone No</th>
			<th>Email</th>
			<th colspan="2">Action</th>
		</tr>

		<?php 
		foreach($arrContactsDetails as $contactInfo){ 
		?>
		<tr>
			<td>&nbsp;<?php echo $contactInfo['related_to'];?> </td>
			<td>&nbsp;<?php echo $contactInfo['phone'];?> </td>
			<td>&nbsp;<?php echo $contactInfo['email'];?> </td>
			
			<?php echo '<td><a href="edit_contact/'.$contactInfo['id'].'">Edit</a></td>' ?>
			<?php echo '<td><a href="delete_contact/'.$contactInfo['id'].'">Delete</a></td>' ?>
		</tr>

	
		<?php }?>
	</table>
<!--End of List Contacts details -->	