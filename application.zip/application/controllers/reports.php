<?php

/**
 * This is Controller file for 'Reports'
 *
 * @author Ambarish
 * @since
 * @package application.controllers
 * @created on 15-01-11
 */
class Reports extends Controller {
    
    private $loggedUserId = null;
    
    //Constructor
    function Reports() {
        parent::Controller();
        $this->load->model('kol');
        $this->load->model('pubmed');
        $this->load->model('country_helper');
        $this->load->model('clinical_trial');
        $this->load->model('my_list_kol');
        $this->load->model('report');
        $this->load->model('coaching');
        $this->load->model('client_User');
        $this->load->model('speaker_evaluation');
        $this->load->model('customer_engagement');
        $this->load->model('login_model');
        $this->load->model('common_helpers');
        $this->loggedUserId	= $this->session->userdata('user_id');
    }
    
    /**
     * Checks if the user has logged in or not
     * @access private
     */
    private function _is_logged_in() {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url() . "/login");
        } else {
            $this->loggedUserId = $this->session->userdata('user_id');
        }
    }
    
    function view_reports() {
        //		if($this->session->userdata('filterContent'))
            //			$this->session->unset_userdata('filterContent');
        // Variable to hold the Section, which needs to be shown
        $reportSection = '';
        if ($this->uri->segment(3)) {
            $reportSection = $this->uri->segment(3);
        }
        if ($this->uri->segment(4)) {
            $data['kolIdForProfileScore'] = $this->uri->segment(4);
            $data['specialty'] = $this->uri->segment(5);
        }
        if ($reportSection != 'rating') {
            if ($reportSection == 'segmentation') {
                $scatData['arrEngagementTypes'] = $this->kol->getEngagementTypesFromLookUp();
                $scatData['arrOrganizationTypes'] = $this->kol->getOrganizationTypesFromLookUp();
                $scatData['arrSessionTypes'] = $this->kol->getSessionTypesFromLookUp();
                $scatData['arrRoles'] = $this->kol->getRoles();
                $data['scatData'] = $scatData;
            }
        }
        if ($reportSection == 'user_analytics' || $reportSection == 'ktl_analytics') {
            $data['arrManager'] =  $this->report->getListOfAllManagerAnalytics();
            $data['arrDivision'] = $this->report->getListOfAllDivisionAnalytics();
            $data['arrRequestedByUsers'] = $this->report->getListOfAllRequestedUsers();
            $data['arrApprovedByUsers'] = $this->report->getListOfAllApprovedUsers();
        }
        if ($reportSection == 'summary') {
            $arrUserCountGlobalRegion = $this->report->getAllUserCountGlobalRegion();
            $arrPowerUsersCountGlobalRegion = $this->report->getPowerUsersCountGlobalRegion();
           /*Non Assigned user*/
            $others = $arrPowerUsersCountGlobalRegion[0]['Others'];
            $total_assigned_user = 0;
        
            foreach($arrUserCountGlobalRegion as $row){
            	$total_assigned_user = $total_assigned_user + $row['totalUser'];
            }
            $arrPowerUsersCountGlobalRegion[0]['Others'] = ($others - $total_assigned_user);
            $data['arrUserCountGlobalRegion'] = $arrUserCountGlobalRegion;
            $data['arrPowerUsersCountGlobalRegion'] = $arrPowerUsersCountGlobalRegion;
            $data ['arrDivision'] = $this->report->getListOfAllDivisionAnalytics();
        }
        //$data['arrKolDetails']	= $this->kol->getKolNames();
        $data['contentPage'] = 'reports/view_reports';
        
        $data['reportSection'] = $reportSection;
        if ($reportSection != 'rating') {
            //not needed as we are sending another ajax request from client side on page load to get refine by section
            /* $data['totalKolsCount']	= $this->kol->getAllKolsCount();
             $data['totalListCount']	= $this->kol->getAllListKolsCount();
             $data['arrListName']	= $this->my_list_kol->getAllListNamesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNameIds=0,$reportSection,$chartType=0);
             $data['arrSpacialties'] = $this->kol->getAllSpecialties($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNameIds=0,$reportSection,$chartType=0,$arrStateIds=0);
             $data['arrCountries']	= $this->country_helper->listCountriesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType=0);
             $data['arrStates']		= $this->country_helper->listStatesAndCount($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrStatesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType=0);
             $data['arrKolDetails']	= $this->kol->getAllkols($fromYear=0,$toYear=0,$arrSpecialityIds=0,$arrCountriesIds=0,$arrKolIds=0,$arrListNamesIds=0,$reportSection,$chartType=0); */
        }
        $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
        if (sizeof($viewMyKols) > 0) {
            $viewTypeMyKols = MY_RECORDS;
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $data['viewType'] = $viewTypeMyKols;
        // Get the list of Specialties
        $this->load->model('Specialty');
        //$data['arrFilterById'] = $this->kol->getFilterByRecentApplied();
        $data['arrFilterById'] = false;
        //		pr($data['arrFilterById']);
        $data['specialties'] = $this->Specialty->getAllSpecialties();
        $data['kolSpecialties'] = $this->Specialty->getKolsSpecialties();
        $data['enableReportForUsers'] = $this->report->getUsersToAccessReports();
        $data['filterPage'] = 'reports/report_filter_li_style';
        //$data['data']['filterPage']		= 'reports/report_filter_li_style';
       $this->load->view('layouts/client_view', $data);
    }
    
    /**
     * Counts the number kols based on country
     *
     * @return unknown_type
     */
    function get_kols_count_by_country() {
        //		$arrFilterById = $this->kol->getFilterByRecentApplied();
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        //		$arrFilterFields									= $arrFilterById['arrFilterFields'];
        
        $fromYear = ($this->input->post('from_year') == (NULL || '')) ? 0 : $this->input->post('from_year');
        $toYear = ($this->input->post('to_year') == (NULL || '')) ? 0 : $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        //		$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $profileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        
        //		echo $fromYear."-d-".$toYear."-d-".$arrKolNames."-d-".$arrSelectedKol."-d-".$arrSpecialities."-d-".pr($arrCountries)."-d-".$arrStatesIds."-d-".$arrListNames."-d-".$arrProfileType;
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else
                    $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        //$arrKolsCount = $this->kol->getKolsCountByCountry();
        $arrKolsCount = $this->kol->getKolsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'country', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        $countryAndKolsCount = array();
        foreach ($arrKolsCount as $kolsCount) {
            $tmp = array();
            $tmp[] = $kolsCount['name'];
            $tmp[] = (int) $kolsCount['count'];
            $countryAndKolsCount[] = $tmp;
        }
        echo json_encode($countryAndKolsCount);
    }
    
    /**
     * Counts the number kols based on specialty
     *
     * @return unknown_type
     */
    function get_kol_count_by_specialty() {
        $arrKolIds = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
        $arrSpecialities = ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
        //		$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else
                    $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        //$arrKolCount=$this->kol->getKolCountBySpecialty();
        $arrKolCount = $this->kol->getKolsByParam($fromYear = 0, $toYear = 0, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'specialty', $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        $arrKolCounts = array();
        foreach ($arrKolCount as $row) {
            $arr = array();
            $arr[] = $row['name'];
            $arr[] = (int) $row['count'];
            $arrKolCounts[] = $arr;
        }
        echo json_encode($arrKolCounts);
    }
    
    /**
     * Counts the number co-authors of kol
     *
     * @return unknown_type
     */
    function get_kol_co_auth_freqency($id, $fromYear, $toYear) {
        $arrKolName = $this->kol->getKolName($id);
        
        $firstName = trim($arrKolName['first_name'], ".");
        $middleName = trim($arrKolName['middle_name'], ".");
        $lastName = trim($arrKolName['last_name'], ".");
        
        $fullName = $firstName;
        if (!empty($middleName))
            $fullName .= ' ' . $middleName;
            if (!empty($lastName))
                $fullName .= ' ' . $lastName;
                
                
                $keyWord = $this->input->post('keyWord');
                
                $this->session->set_userdata('kolKeyWords', $keyWord);
                $keyWord = $this->session->userdata('kolKeyWords');
                
                $arrAuth = $this->kol->getKolCoAuthFreqency($id, $fromYear, $toYear, $arrKolName, null, $keyWord);
                $name = array();
                $count = array();
                $arrIds = array();
                foreach ($arrAuth as $row) {
                    $authorName = '';
                    //based on the name avilability, construct a proper name
                    if ($row['last_name'] != '' && $row['fore_name'] != '')
                        $authorName = $row['last_name'] . " " . $row['fore_name'];
                        else if ($row['fore_name'] == '')
                            $authorName = $row['last_name'] . " " . $row['initials'];
                            else if ($row['last_name'] == '')
                                $authorName = $row['fore_name'] . " " . $row['initials'];
                                
                                if ($authorName != $fullName) {
                                    $name[] = $authorName;
                                    $count[] = (int) $row['count'];
                                    $arrIds[] = $row['id'];
                                }
                }
                $data[] = $name;
                $data[] = $count;
                $data[] = $arrIds;
                echo json_encode($data);
    }
    
    /**
     * prepares the json data for kol activity chart,
     * @author 	Ramesh B
     * @Created on: 16-02-11
     * @since
     * @return JSON
     */
    function get_kols_activity_chart() {
        //		$arrFilterById = $this->kol->getFilterByRecentApplied();
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        //		$arrFilterFields									= $arrFilterById['arrFilterFields'];
        //		pr($arrFilterFields);
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
        $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        
        //		echo $fromYear."-d-".$toYear."-d-".$arrKolNames."-d-".$arrSelectedKol."-d-".pr($arrSpecialities)."-d-".pr($arrCountries)."-d-".pr($arrStatesIds)."-d-".pr($arrListNames)."-d-".$arrProfileType;
        $arrFilters['event_weight'] = $this->input->post('event_weight');
        $arrFilters['aff_weight'] = $this->input->post('aff_weight');
        $arrFilters['pub_weight'] = $this->input->post('pub_weight');
        $arrFilters['trial_weight'] = $this->input->post('trial_weight');
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        if ($arrKolNames == '0' && $arrGlobalRegions == '0' && $arrSpecialities == '0' &&
            $arrCountries == '0' && $arrStatesIds == '0' &&
            $arrListNames == '0' && $arrProfileType == '' &&
            $arrFilters['event_weight'] == 1 && $arrFilters['aff_weight'] == 1 &&
            $arrFilters['pub_weight'] == 1 && $arrFilters['trial_weight'] == 1 &&
            $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0') {
                $this->load->model('json_store');
                $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_ACTIVITY);
                $data = $arrStoredJson['json_data'];
                echo $data;
            } else {
                
                if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                    if (!is_array($arrGlobalRegions))
                        $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                        else
                            $arrGlobalRegionIds = $arrGlobalRegions;
                }
                
                if ($arrSpecialities != '0' && $arrSpecialities != '') {
                    if (!is_array($arrSpecialities))
                        $arrSpecialityIds = explode(",", $arrSpecialities);
                        else
                            $arrSpecialityIds = $arrSpecialities;
                }
                //			pr($arrSpecialityIds);
                if ($arrCountries != '0' && $arrCountries != '') {
                    if (!is_array($arrCountries))
                        $arrCountriesIds = explode(",", $arrCountries);
                        else
                            $arrCountriesIds = $arrCountries;
                }
                //			pr($arrCountriesIds);
                if ($arrStatesIds != '0' && $arrStatesIds != '') {
                    if (!is_array($arrStatesIds))
                        $arrStatesIds = explode(",", $arrStatesIds);
                        else
                            $arrStatesIds = $arrStatesIds;
                }
                //			pr($arrStatesIds);
                if ($arrKolNames != '0' && $arrKolNames != '') {
                    if (!is_array($arrKolNames))
                        $kolIds = $arrSelectedKol;
                        else
                            $kolIds = $arrKolNames;
                }else {
                    $kolIds = $arrSelectedKol;
                }
                //			pr($arrSelectedKol);
                if ($arrListNames != '0' && $arrListNames != '') {
                    if (!is_array($arrListNames))
                        $arrListNamesIds = explode(",", $arrListNames);
                        else
                            $arrListNamesIds = $arrListNames;
                            //				$arrListNamesIds=$arrListNames;
                }
                //			pr($arrListNamesIds);
                $arrWeights['event_weight'] = 1;
                $arrWeights['aff_weight'] = 1;
                $arrWeights['pub_weight'] = 1;
                $arrWeights['trial_weight'] = 1;
                
                if (isset($_POST) && count($_POST) > 0) {
                    $arrWeights['event_weight'] = $this->input->post('event_weight');
                    $arrWeights['aff_weight'] = $this->input->post('aff_weight');
                    $arrWeights['pub_weight'] = $this->input->post('pub_weight');
                    $arrWeights['trial_weight'] = $this->input->post('trial_weight');
                }
                
                if ($arrWeights['event_weight'] == 0 && $arrWeights['aff_weight'] == 0 && $arrWeights['pub_weight'] == 0 && $arrWeights['trial_weight'] == 0) {
                    $data = array();
                    echo json_encode($data);
                    return;
                }
                
                $arrEventsData = array();
                $arrAffsData = array();
                $arrPublicationsData = array();
                $arrTrialsData = array();
                $arrEventsCount = array();
                $arrAffsCount = array();
                $arrPublicationsCount = array();
                $arrTrialsCount = array();
                $arrKolIds = array();
                $arrEventsCountResults = $this->kol->getEventsByParam($fromYear, $toYear, $kolIds, $arrSessionTypes = 0, $arrRoles = 0, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                //			echo $this->db->last_query();
                foreach ($arrEventsCountResults as $event)
                    $arrEventsCount[$event['kol_id']] = $event['count'];
                    
                    $arrAffsCountResults = $this->kol->getAffiliationsByParam($fromYear, $toYear, $kolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                    foreach ($arrAffsCountResults as $aff)
                        $arrAffsCount[$aff['kol_id']] = $aff['count'];
                        
                        $arrPublicationsCountResults = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limit = 0, $arrProfileType, $viewType, $arrGlobalRegionIds);
                        foreach ($arrPublicationsCountResults as $publication)
                            $arrPublicationsCount[$publication['kol_id']] = $publication['count'];
                            
                            $arrTrialsCountResults = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                            //			echo $this->db->last_query();
                            foreach ($arrTrialsCountResults as $trial)
                                $arrTrialsCount[$trial['kol_id']] = $trial['count'];
                                
                                $mergedArray = array_merge($arrEventsCountResults, $arrAffsCountResults, $arrPublicationsCountResults, $arrTrialsCountResults);
                                foreach ($mergedArray as $details) {
                                    $arrKolIds[] = $details['kol_id'];
                                }
                                $uniqeKolIds = array_unique($arrKolIds);
                                
                                $arrTopKols = $this->calcTopKolsAcivities($arrEventsCount, $arrAffsCount, $arrPublicationsCount, $arrTrialsCount, $arrWeights, $uniqeKolIds);
                                
                                $topLimit = 15;
                                $i = 1;
                                
                                foreach ($arrTopKols as $kolId) {
                                    if (array_key_exists($kolId, $arrEventsCount)) {
                                        $arrEventsData[] = ((int) $arrEventsCount[$kolId] * $arrWeights['event_weight']);
                                    } else
                                        $arrEventsData[] = 0;
                                        
                                        if (array_key_exists($kolId, $arrAffsCount)) {
                                            $arrAffsData[] = ((int) $arrAffsCount[$kolId] * $arrWeights['aff_weight']);
                                        } else
                                            $arrAffsData[] = 0;
                                            
                                            if (array_key_exists($kolId, $arrPublicationsCount)) {
                                                $arrPublicationsData[] = ((int) $arrPublicationsCount[$kolId] * $arrWeights['pub_weight']);
                                            } else
                                                $arrPublicationsData[] = 0;
                                                
                                                if (array_key_exists($kolId, $arrTrialsCount)) {
                                                    $arrTrialsData[] = ((int) $arrTrialsCount[$kolId] * $arrWeights['trial_weight']);
                                                } else
                                                    $arrTrialsData[] = 0;
                                                    
                                                    if ($i >= $topLimit)
                                                        break;
                                                        else
                                                            $i++;
                                }
                                $arrKolDetails = $this->kol->getKolNames();
                                $topKolNames = $this->report->prepareKolIdNameCombinations($arrTopKols, $arrKolDetails);
                                $data[] = array_values($topKolNames);
                                $data[] = $arrEventsData;
                                $data[] = $arrAffsData;
                                $data[] = $arrPublicationsData;
                                $data[] = $arrTrialsData;
                                echo json_encode($data);
            }
    }
    
    /**
     * Takes the Events,Affiliations,Publications and Trials counts of all kols and Based on the weightage given by customers
     * it calculates the top ranking for kols in ascending order
     * @author 	Ramesh B
     * @Created on: 16-02-11
     * @since
     * @return Array
     */
    function calcTopKolsAcivities($arrEventsCount, $arrAffsCount, $arrPublicationsCount, $arrTrialsCount, $arrWeights, $uniqeKolIds) {
        $i = 1;
        $arrKolTotalCount = array();
        foreach ($uniqeKolIds as $kolId) {
            $totalCount = 0;
            if (array_key_exists($kolId, $arrEventsCount)) {
                $totalCount+=((int) $arrEventsCount[$kolId] * $arrWeights['event_weight']);
            }
            
            if (array_key_exists($kolId, $arrAffsCount)) {
                $totalCount+=((int) $arrAffsCount[$kolId] * $arrWeights['aff_weight']);
            }
            
            if (array_key_exists($kolId, $arrPublicationsCount)) {
                $totalCount+=((int) $arrPublicationsCount[$kolId] * $arrWeights['pub_weight']);
            }
            
            if (array_key_exists($kolId, $arrTrialsCount)) {
                $totalCount+=((int) $arrTrialsCount[$kolId] * $arrWeights['trial_weight']);
            }
            //if you don't want to show the kols with total 0 count
            if ($totalCount > 0){
                if($kolId != ''){
                    $arrKolTotalCount[$kolId] = $totalCount;
                }
            }
        }
        arsort($arrKolTotalCount);
        return array_keys($arrKolTotalCount);
    }
    
    /**
     * prepares the json data for overall Events Type timeline chart chart,
     * @author 	Ramesh B
     * @Created on: 17-02-11
     * @since
     * @return JSON
     */
    function get_event_types_timeline_chart() {
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
        $arrSpecialities = ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
        //		$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        //		echo $arrKolNames;
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else
                    $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        
        $congressData = array();
        $conferenceData = array();
        $grData = array();
        $amData = array();
        $cmeData = array();
        $webcastData = array();
        $webinarData = array();
        $podcastData = array();
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        //		echo "ids".$kolIds;
        $arrEventTypeDetails = $this->kol->getEventTypesCountByTimeLine($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        //get unique years
        $arrUniqueYears = $this->get_unique_years($arrEventTypeDetails);
        $arrEventTypeCount = array();
        $arrEventTypes = array();
        $arrEventTypesData = array();
        $arrUniqueYear = array();
        foreach ($arrEventTypeDetails as $eventTypeDetail) {
            $arrEventTypeCount[$eventTypeDetail['year']][$eventTypeDetail['event_type']] += (int) $eventTypeDetail['count'];
            //$arrEventTypeCount[$eventTypeDetail['event_type']][$eventTypeDetail['year']] += (int)$eventTypeDetail['count'];
            $arrEventTypes[$eventTypeDetail['event_type']] = 1;
        }
        ksort($arrEventTypeCount);
        foreach ($arrEventTypeCount as $year => $arrRow) {
            $arrUniqueYear[substr($year, 2)] = $year; //"'".substr($year,2);
            $arrYears[substr($year, 2)] = $year;
            foreach ($arrEventTypes as $eventType => $value) {
                if (isset($arrRow[$eventType])) {
                    $arrEventTypesData[$eventType][] = $arrRow[$eventType];
                } else {
                    $arrEventTypesData[$eventType][] = 0;
                }
            }
        }
        //pr($arrEventTypesData);
        $arrTypesData = array();
        $arrData[] = array_values($arrUniqueYear);
        foreach ($arrEventTypes as $eventType => $value) {
            $arrTypesData[] = array('name' => $eventType, 'data' => $arrEventTypesData[$eventType]);
        }
        $arrData[] = $arrTypesData;
        $arrData[] = $arrYears;
        //		pr($arrData);
        echo json_encode($arrData);
        /*
         //pr($arrData);
         //$arrEventTypesData[]	= array('name'=>'Congress','data'=>$congressData);
         //pr($arrEventTypeCount);
         foreach($arrUniqueYears as $year){
         //collect the Congress type counts for this year
         $congressDataCount=0;
         foreach($arrEventTypeDetails as $eventTypeDetail){
         if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Congress'){
         $congressDataCount+=(int)$eventTypeDetail['count'];
         $checkCongress = true;
         }
         }
         $congressData[]=(int)$congressDataCount;
         
         //collect the Conference type counts for this year
         $conferenceDataCount=0;
         foreach($arrEventTypeDetails as $eventTypeDetail){
         if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Conference'){
         $conferenceDataCount+=(int)$eventTypeDetail['count'];
         $checkConference = true;
         }
         }
         $conferenceData[]=(int)$conferenceDataCount;
         
         //collect the Grand Rounds type counts for this year
         $grDataCount=0;
         foreach($arrEventTypeDetails as $eventTypeDetail){
         if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Grand Round'){
         $grDataCount+=(int)$eventTypeDetail['count'];
         $checkGrand = true;
         }
         }
         $grData[]=(int)$grDataCount;
         
         //collect the Annual Meeting type counts for this year
         $amDataCount=0;
         foreach($arrEventTypeDetails as $eventTypeDetail){
         if($eventTypeDetail['year']==$year && $eventTypeDetail['event_type']=='Annual Meeting'){
         $amDataCount+=(int)$eventTypeDetail['count'];
         $checkAnual = true;
         }
         }
         $amData[]=(int)$amDataCount;
         
         
         }
         $data[]=array_values($arrUniqueYears);
         $arrEventTypes	= array();
         if($checkCongress){
         //$arrData[]=$congressData;
         $congData = array('name'=>'Congress','data'=>$congressData);
         $arrEventTypes[]=$congData;
         }
         
         if($checkConference){
         //$arrData[]=$congressData;
         $confData = array('name'=>'Conference','data'=>$conferenceData);
         $arrEventTypes[]=$confData;
         }
         //$arrData[]=$conferenceData;
         if($checkGrand){
         //$arrData[]=$congressData;
         $grandData = array('name'=>'Grand Round','data'=>$grData);
         $arrEventTypes[]=$grandData;
         }
         
         if($checkAnual){
         //$arrData[]=$congressData;
         $annulData = array('name'=>'Annual Meeting','data'=>$amData);
         $arrEventTypes[]=$annulData;
         }
         
         $data[]=$arrEventTypes;
         //	$data[]=array_values($arrUniqueYears);
         //	$data[]=$congressData;
         //	$data[]=$conferenceData;
         //	$data[]=$grData;
         //	$data[]=$amData;
         //	$data[]=$cmeData;
         // 	$data[]=$webcastData;
         //	$data[]=$webinarData;
         //	$data[]=$podcastData;
         
         echo json_encode($data);
         */
    }
    
    /**
     * Fetches the array of unique years form the array of events details count and sorts them in revers order
     * @author 	Ramesh B
     * @Created on: 16-02-11
     * @since
     * @return Array
     */
    function get_unique_years($arrEventTypeDetails) {
        $arrYears = array();
        foreach ($arrEventTypeDetails as $eventTypeDetail) {
            $arrYears[] = $eventTypeDetail['year'];
        }
        $arrUniqueYears = array_unique($arrYears);
        sort($arrUniqueYears);
        return $arrUniqueYears;
    }
    
    /*
     *  Getting ALL Affiliation details
     */
    
    function get_all_affiliations() {
        //$arrAffiliations=$this->kol->getAllAffiliations();
        $arrAffiliations = $this->kol->getAffiliationsByParam($fromYear = 1900, $toYear = 2011, $arrKolIds = 0, $arrEngTypes = '', $arrOrgType = '', $arrCountries = 0, $arrSpecialities = 0, 'kol_memberships.type');
        $arrAff = array();
        foreach ($arrAffiliations as $row) {
            $aff = array();
            $aff[] = ucwords($row['type']);
            $aff[] = (int) $row['count'];
            $arrAff[] = $aff;
        }
        echo json_encode($arrAff);
    }
    
    /*
     *  Counting the kols Publications details
     */
    
    function count_publications_of_kols() {
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
        $arrSpecialities = ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
        //		$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else
                    $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $result = array();
        //$arrPubCounts	=	$this->pubmed->countPublicationsOfKols();
        $arrPubCounts = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limit = 0, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        $i = 15;
        $kolName = array();
        $pubCount = array();
        $kolId = array();
        foreach ($arrPubCounts as $row) {
            if ($i <= 0)
                break;
                //			$kolName[]	= $row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
                $kolName[] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']);
                $pubCount[] = (int) $row['count'];
                $kolId[] = (int) $row['kol_id'];
                $i--;
        }
        $data[] = $kolName;
        $data[] = $pubCount;
        $data[] = $kolId;
        
        echo json_encode($data);
    }
    
    /*
     *  Grt the kol counts Based on Event Type
     */
    
    function get_all_events_chart() {
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
        $arrSpecialities = ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
        //		$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else
                    $kolIds = $arrKolNames;
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewType = array(0);
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $arrEventsCount = $this->kol->getEventTypesAndCount($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds);
        //		echo $this->db->last_query();
        $eventTypeAndKolsCount = array();
        $arrTypes = array();
        $arrIds = array();
        $data = array();
        foreach ($arrEventsCount as $eventsCount) {
            $tmp = array();
            $tmp[] = $eventsCount['event_type'];
            $tmp[] = (int) $eventsCount['count'];
            $arrIds[] = $eventsCount['id'];
            $arrTypes[] = $eventsCount['event_type'];
            $eventTypeAndKolsCount[] = $tmp;
        }
        $data[] = $eventTypeAndKolsCount;
        $data[] = $arrTypes;
        $data[] = $arrIds;
        echo json_encode($data);
    }
    
    /**
     * Prepares the JSON data for top 20 MeshTerms count chart
     * @author 	Ramesh B
     * @Created on: 14-03-11
     * @since	1.5.1
     * @return Array
     */
    function view_pub_major_meshterm_chart() {
        ini_set("max_execution_time", 36000);
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_ids') == (null || '')) ? 0 : $this->input->post('kol_ids'));
        $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrKolNames == '0' && $arrSpecialities == '0' &&
            $arrCountries == '0' && $arrGlobalRegions == '0' && $arrStatesIds == '0' &&
            $arrListNames == '0' && $arrProfileType == '' &&
            $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0' && $fromYear=='0' && $toYear=='0') {
                $this->load->model('json_store');
                $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_PUBLICATIONS_BY_KEYWORDS);
                $data = $arrStoredJson['json_data'];
                echo $data;
            } else {
                
                if ($viewTypeMyKols == MY_RECORDS) {
                    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                    if (sizeof($viewMyKols) > 0) {
                        $viewType = $viewMyKols;
                        $viewTypeMyKols = MY_RECORDS;
                    } else {
                        $viewType = array(0);
                        $viewTypeMyKols = MY_RECORDS;
                    }
                } else {
                    $viewTypeMyKols = ALL_RECORDS;
                }
                if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                    if (!is_array($arrGlobalRegions))
                        $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                        else
                            $arrGlobalRegionIds = $arrGlobalRegions;
                }
                if ($arrSpecialities != '0' && $arrSpecialities != '') {
                    if (!is_array($arrSpecialities))
                        $arrSpecialityIds = explode(",", $arrSpecialities);
                        else
                            $arrSpecialityIds = $arrSpecialities;
                }
                if ($arrCountries != '0' && $arrCountries != '') {
                    if (!is_array($arrCountries))
                        $arrCountriesIds = explode(",", $arrCountries);
                        else
                            $arrCountriesIds = $arrCountries;
                }
                if ($arrStatesIds != '0' && $arrStatesIds != '') {
                    if (!is_array($arrStatesIds))
                        $arrStatesIds = explode(",", $arrStatesIds);
                        else
                            $arrStatesIds = $arrStatesIds;
                }
                if ($arrKolNames != '0' && $arrKolNames != '') {
                    if (!is_array($arrKolNames))
                        $kolIds = $arrSelectedKol;
                        else
                            $kolIds = $arrKolNames;
                }else {
                    $kolIds = $arrSelectedKol;
                }
                if ($arrListNames != '0' && $arrListNames != '') {
                    if (!is_array($arrListNames))
                        $arrListNamesIds = explode(",", $arrListNames);
                        else
                            $arrListNamesIds = $arrListNames;
                }
                
                $arrMajorMeshterm = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'keyword', $arrListNamesIds, $arrStatesIds, $limit = 0, $profileType, $viewType, $arrGlobalRegionIds);
                
                //$arrMajorMeshterm = $this->pubmed->getPublicationsByParam($fromYear, $toYear,$arrKolIds,$arrCountries,$arrSpecialties,$groupBy='keyword');
                
                $meshTerms = array();
                $count = array();
                $arrIds = array();
                $arrParentIds = array();
                $i = 20;
                foreach ($arrMajorMeshterm as $meshterm) {
                    if ($i <= 0)
                        break;
                        $termName = '';
                        $parentId = $meshterm['parent_id'];
                        if ($parentId != 0 && $parentId != null) {
                            $parentName = $this->pubmed->getMeshTermName($parentId);
                            $termName = $parentName . "/" . $meshterm['mesh_term'];
                        } else {
                            $termName = $meshterm['mesh_term'];
                        }
                        $meshTerms[] = ucwords($termName);
                        $count[] = (int) $meshterm['count'];
                        $arrIds[] = $meshterm['id'];
                        $arrParentIds[] = $meshterm['parent_id'];
                        $i--;
                }
                $data[] = $meshTerms;
                $data[] = $count;
                $data[] = $arrIds;
                $data[] = $arrParentIds;
                
                echo json_encode($data);
            }
            //echo json_encode($arrMajorMeshterm);
    }
    
    /**
     * Prepares the JSON data for top 15 Years with Publications count chart
     * @author 	Ramesh B
     * @Created on: 14-03-11
     * @since	1.5.1
     * @return Array
     */
    function view_publication_chart() {
        
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
        $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrKolNames == '0' && $arrGlobalRegions == '0' && $arrSpecialities == '0' &&
            $arrCountries == '0' && $arrStatesIds == '0' &&
            $arrListNames == '0' && $arrProfileType == '' &&
            $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0' && $fromYear=='0' && $toYear=='0') {
                $this->load->model('json_store');
                $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_PUBLICATIONS_BY_YEAR);
                $data = $arrStoredJson['json_data'];
                echo $data;
            } else {
                
                if ($viewTypeMyKols == MY_RECORDS) {
                    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                    if (sizeof($viewMyKols) > 0) {
                        $viewType = $viewMyKols;
                        $viewTypeMyKols = MY_RECORDS;
                    } else {
                        $viewType = array(0);
                        $viewTypeMyKols = MY_RECORDS;
                    }
                } else {
                    $viewTypeMyKols = ALL_RECORDS;
                }
                
                if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                    if (!is_array($arrGlobalRegions))
                        $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                        else
                            $arrGlobalRegionIds = $arrGlobalRegions;
                }
                if ($arrSpecialities != '0' && $arrSpecialities != '') {
                    if (!is_array($arrSpecialities))
                        $arrSpecialityIds = explode(",", $arrSpecialities);
                        else
                            $arrSpecialityIds = $arrSpecialities;
                }
                if ($arrCountries != '0' && $arrCountries != '') {
                    if (!is_array($arrCountries))
                        $arrCountriesIds = explode(",", $arrCountries);
                        else
                            $arrCountriesIds = $arrCountries;
                }
                if ($arrStatesIds != '0' && $arrStatesIds != '') {
                    if (!is_array($arrStatesIds))
                        $arrStatesIds = explode(",", $arrStatesIds);
                        else
                            $arrStatesIds = $arrStatesIds;
                }
                if ($arrKolNames != '0' && $arrKolNames != '') {
                    if (!is_array($arrKolNames))
                        $kolIds = $arrSelectedKol;
                        else
                            $kolIds = $arrKolNames;
                }else {
                    $kolIds = $arrSelectedKol;
                }
                if ($arrListNames != '0' && $arrListNames != '') {
                    if (!is_array($arrListNames))
                        $arrListNamesIds = explode(",", $arrListNames);
                        else
                            $arrListNamesIds = $arrListNames;
                }
                $arrPublications = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'year', $arrListNamesIds, $arrStatesIds, $limit = 0, $arrProfileType, $viewType, $arrGlobalRegionIds);
                //			echo $this->db->last_query();
                $years = array();
                $count = array();
                $yearMapping = array();
                //$i=15;
                foreach ($arrPublications as $publication) {
                    //if($i<=0)break;
                    if ($publication['year'] != 0)
                        $years[] = $publication['year'];
                        //                 else
                            //                     $years[] = $publication['year'];
                        $count[] = (int) $publication['count'];
                        $yearMapping[substr($publication['year'], 2)] = $publication['year'];
                        //$i--;
                }
                $data[] = array_reverse($years);
                $data[] = array_reverse($count);
                $data[] = $yearMapping;
                echo json_encode($data);
            }
            
            
            /* $arrFilterById = $this->kol->getFilterByRecentApplied();
             $viewTypeMyKols = $this->input->post("viewTypeMyKols");
             $arrFilterFields	= array();
             $arrFilterFields	= $arrFilterById['arrFilterFields'];
             $fromYear 			= $this->input->post('from_year');
             $toYear				= $this->input->post('to_year');
             $arrKolNames		= ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id']:(($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id'));
             $arrSelectedKol		= ($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
             $arrSpecialities	= ($arrFilterFields['specialty']) ? $arrFilterFields['specialty']:(($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty'));
             $arrCountries		= ($arrFilterFields['country']) ? $arrFilterFields['country']:(($this->input->post('country')==(null || '')) ? 0:$this->input->post('country'));
             //	$arrStates			= ($this->input->post('state')==(null || '')) ? 0:$this->input->post('state');
             $arrStatesIds		= ($arrFilterFields['state']) ? $arrFilterFields['state']:(($this->input->post('state')==(null || '')) ? 0:$this->input->post('state'));
             $arrListNames		= ($arrFilterFields['list_id']) ? $arrFilterFields['list_id']:(($this->input->post('listName')==(null || '')) ? 0:$this->input->post('listName'));
             $arrProfileType		= ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type'):'');
             //		echo  "d-".$fromYear."d-".$toYear;
             if($arrKolNames == '0' && $arrSpecialities == '0' && $arrCountries == '0' && $arrStatesIds == '0' && $arrListNames == '0' && $arrProfileType == '' && $viewTypeMyKols==ALL_RECORDS){
             $this->load->model('json_store');
             $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_PUBLICATIONS_BY_YEAR);
             $data = $arrStoredJson['json_data'];
             echo $data;
             }else{
             if($arrSpecialities!='0' && $arrSpecialities!=''){
             $arrSpecialityIds=$arrSpecialities;
             }
             
             if($arrCountries!='0' && $arrCountries!=''){
             $arrCountriesIds=$arrCountries;
             }
             
             if($arrKolNames!='0' && $arrKolNames!=''){
             $arrKolIds[]=$arrSelectedKol;
             }else{
             $arrKolIds=$arrKolNames;
             }
             
             if($arrListNames!='0' && $arrListNames!=''){
             $arrListNamesIds=$arrListNames;
             }
             if($viewTypeMyKols == MY_RECORDS){
             $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
             if(sizeof($viewMyKols) > 0){
             $viewType = $viewMyKols;
             $viewTypeMyKols = MY_RECORDS;
             }else{
             $viewTypeMyKols = ALL_RECORDS;
             }
             }else{
             $viewTypeMyKols = ALL_RECORDS;
             }
             $arrPublications = $this->pubmed->getPublicationsByParam($fromYear, $toYear,$arrKolIds,$arrCountriesIds,$arrSpecialityIds,$groupBy='year',$arrListNamesIds,$arrStatesIds,$limit = 0,$arrProfileType,$viewType);
             //		echo $this->db->last_query();
             $years =array();
             $count=array();
             //$i=15;
             foreach($arrPublications as $publication){
             //if($i<=0)break;
             if($publication['year']!=0)
             $years[]="'".substr($publication['year'],2);
             else
             $years[]=$publication['year'];
             $count[]=(int)$publication['count'];
             //$i--;
             }
             $data[]=array_reverse($years);
             $data[]=array_reverse($count);
             echo json_encode($data);
             } */
    }
    
    /**
     * Prepares the JSON data for top 20 Substances count chart
     * @author 	Ramesh B
     * @Created on: 14-03-11
     * @since	1.5.1
     * @return Array
     */
    function view_pub_substances_chart() {
        ini_set("max_execution_time", 36000);
        
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
        $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        if ($arrKolNames == '0' && $arrGlobalRegions == '0' && $arrSpecialities == '0' &&
            $arrCountries == '0' && $arrStatesIds == '0' &&
            $arrListNames == '0' && $arrProfileType == '' &&
            $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0' && $fromYear=='0' && $toYear=='0') {
                $this->load->model('json_store');
                $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_PUBLICATIONS_BY_SUBSTANCES);
                $data = $arrStoredJson['json_data'];
                echo $data;
            } else {
                
                if ($viewTypeMyKols == MY_RECORDS) {
                    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                    if (sizeof($viewMyKols) > 0) {
                        $viewType = $viewMyKols;
                        $viewTypeMyKols = MY_RECORDS;
                    } else {
                        $viewType = array(0);
                        $viewTypeMyKols = MY_RECORDS;
                    }
                } else {
                    $viewTypeMyKols = ALL_RECORDS;
                }
                
                if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                    if (!is_array($arrGlobalRegions))
                        $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                        else
                            $arrGlobalRegionIds = $arrGlobalRegions;
                }
                if ($arrSpecialities != '0' && $arrSpecialities != '') {
                    if (!is_array($arrSpecialities))
                        $arrSpecialityIds = explode(",", $arrSpecialities);
                        else
                            $arrSpecialityIds = $arrSpecialities;
                }
                if ($arrCountries != '0' && $arrCountries != '') {
                    if (!is_array($arrCountries))
                        $arrCountriesIds = explode(",", $arrCountries);
                        else
                            $arrCountriesIds = $arrCountries;
                }
                if ($arrStatesIds != '0' && $arrStatesIds != '') {
                    if (!is_array($arrStatesIds))
                        $arrStatesIds = explode(",", $arrStatesIds);
                        else
                            $arrStatesIds = $arrStatesIds;
                }
                if ($arrKolNames != '0' && $arrKolNames != '') {
                    if (!is_array($arrKolNames))
                        $kolIds = $arrSelectedKol;
                        else
                            $kolIds = $arrKolNames;
                }else {
                    $kolIds = $arrSelectedKol;
                }
                if ($arrListNames != '0' && $arrListNames != '') {
                    if (!is_array($arrListNames))
                        $arrListNamesIds = explode(",", $arrListNames);
                        else
                            $arrListNamesIds = $arrListNames;
                }
                
                $arrSubstances = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'substance', $arrListNamesIds, $arrStatesIds, 20, $profileType, $viewType, $arrGlobalRegionIds);
                //		echo $this->db->last_query();
                $substances = array();
                $count = array();
                $arrIds = array();
                $i = 20;
                foreach ($arrSubstances as $substance) {
                    if ($i <= 0)
                        break;
                        $substances[] = ucwords($substance['name']);
                        $count[] = (int) $substance['count'];
                        $arrIds[] = $substance['id'];
                        $i--;
                }
                $data[] = $substances;
                $data[] = $count;
                $data[] = $arrIds;
                echo json_encode($data);
            }
            //echo json_encode($arrSubstances);
    }
    
    /**
     * Prepares the JSON data for top 20 Journals count chart
     * @author 	Ramesh B
     * @Created on: 14-03-11
     * @since	1.5.1
     * @return Array
     */
    function view_pub_journals_chart() {
        ini_set("max_execution_time", 36000);
        
        
        $arrFilterFields = array();
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
        $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
        $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
        $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
        $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
        $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
        $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
        $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
        $arrGlobalRegions = urldecode($arrGlobalRegions);
        
        if ($arrKolNames == '0' && $arrGlobalRegions == '0' && $arrSpecialities == '0' &&
            $arrCountries == '0' && $arrStatesIds == '0' &&
            $arrListNames == '0' && $arrProfileType == '' &&
            $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0' && $fromYear=='0' && $toYear=='0') {
                $this->load->model('json_store');
                $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_PUBLICATIONS_BY_JOURNALS);
                $data = $arrStoredJson['json_data'];
                echo $data;
            } else {
                
                if ($viewTypeMyKols == MY_RECORDS) {
                    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                    if (sizeof($viewMyKols) > 0) {
                        $viewType = $viewMyKols;
                        $viewTypeMyKols = MY_RECORDS;
                    } else {
                        $viewType = array(0);
                        $viewTypeMyKols = MY_RECORDS;
                    }
                } else {
                    $viewTypeMyKols = ALL_RECORDS;
                }
                if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                    if (!is_array($arrGlobalRegions))
                        $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                        else
                            $arrGlobalRegionIds = $arrGlobalRegions;
                }
                if ($arrSpecialities != '0' && $arrSpecialities != '') {
                    if (!is_array($arrSpecialities))
                        $arrSpecialityIds = explode(",", $arrSpecialities);
                        else
                            $arrSpecialityIds = $arrSpecialities;
                }
                if ($arrCountries != '0' && $arrCountries != '') {
                    if (!is_array($arrCountries))
                        $arrCountriesIds = explode(",", $arrCountries);
                        else
                            $arrCountriesIds = $arrCountries;
                }
                if ($arrStatesIds != '0' && $arrStatesIds != '') {
                    if (!is_array($arrStatesIds))
                        $arrStatesIds = explode(",", $arrStatesIds);
                        else
                            $arrStatesIds = $arrStatesIds;
                }
                if ($arrKolNames != '0' && $arrKolNames != '') {
                    if (!is_array($arrKolNames))
                        $kolIds = $arrSelectedKol;
                        else
                            $kolIds = $arrKolNames;
                }else {
                    $kolIds = $arrSelectedKol;
                }
                if ($arrListNames != '0' && $arrListNames != '') {
                    if (!is_array($arrListNames))
                        $arrListNamesIds = explode(",", $arrListNames);
                        else
                            $arrListNamesIds = $arrListNames;
                }
                $arrJournals = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'journal', $arrListNamesIds, $arrStatesIds, 20, $profileType, $viewType, $arrGlobalRegionIds);
                //		echo $this->db->last_query();
                $name = array();
                $count = array();
                $arrIds = array();
                $i = 20;
                foreach ($arrJournals as $row) {
                    if ($i <= 0)
                        break;
                        $name[] = $row['name'];
                        $count[] = (int) $row['count'];
                        $arrIds[] = $row['id'];
                        $i--;
                }
                $data[] = $name;
                $data[] = $count;
                $data[] = $arrIds;
                echo json_encode($data);
            }
    }
    
    function scattered_graph() {
        $data['arrEngagementTypes'] = $this->kol->getEngagementTypesFromLookUp();
        $data['arrOrganizationTypes'] = $this->kol->getOrganizationTypesFromLookUp();
        $data['arrSessionTypes'] = $this->kol->getSessionTypesFromLookUp();
        $data['arrRoles'] = $this->kol->getRoles();
        $this->load->view('reports/scatr_graph', $data);
        //$this->load->view('reports/scatr_graph_tree_based',$data);
    }
    
    function get_scat_graph_data() {
        
        $viewTypeMyKols = $this->input->post("viewTypeMyKols");
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $arrKolNames = ($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id');
        $key = array_search('Enter KTL Name', $arrKolNames);
        unset($arrKolNames[$key]);
        if(sizeof($arrKolNames)<1){
            $arrKolNames = 0;
        }
        $arrSelectedKol = ($this->input->post('selected_kol_id') == null) ? 0 : $this->input->post('selected_kol_id');
        $arrGlobalRegions = ($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region');
        $arrSpecialities = ($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty');
        $arrCountries = ($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country');
        $arrStatesIds = ($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state');
        $arrListNames = ($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName');
        $profileType = ($this->input->post('profile_type')) ? $this->input->post('profile_type') : '';
        if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
            if (!is_array($arrGlobalRegions))
                $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                else
                    $arrGlobalRegionIds = $arrGlobalRegions;
        }
        if ($arrSpecialities != 0 && $arrSpecialities != '') {
            if (!is_array($arrSpecialities))
                $arrSpecialityIds = explode(",", $arrSpecialities);
                else
                    $arrSpecialityIds = $arrSpecialities;
        }
        if ($arrCountries != 0 && $arrCountries != '') {
            if (!is_array($arrCountries))
                $arrCountriesIds = explode(",", $arrCountries);
                else
                    $arrCountriesIds = $arrCountries;
        }
        if ($arrStatesIds != 0 && $arrStatesIds != '') {
            if (!is_array($arrStatesIds))
                $arrStatesIds = explode(",", $arrStatesIds);
                else
                    $arrStatesIds = $arrStatesIds;
        }
        if ($arrKolNames != '0' && $arrKolNames != '') {
            if (!is_array($arrKolNames))
                $kolIds = $arrSelectedKol;
                else{
                    $kolIds = $arrKolNames;
                }
        }else {
            $kolIds = $arrSelectedKol;
        }
        if ($arrListNames != '0' && $arrListNames != '') {
            if (!is_array($arrListNames))
                $arrListNamesIds = explode(",", $arrListNames);
                else
                    $arrListNamesIds = $arrListNames;
        }
        /*
         if ($viewTypeMyKols == MY_RECORDS) {
         $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
         if (sizeof($viewMyKols) > 0) {
         $viewType = $viewMyKols;
         $viewTypeMyKols = MY_RECORDS;
         } else {
         $viewTypeMyKols = ALL_RECORDS;
         }
         } else {
         $viewTypeMyKols = ALL_RECORDS;
         }
         */
        $viewType = array();
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                //$viewType = array(0);
                $viewType = 0;
                $viewTypeMyKols = MY_RECORDS;
            }
        } else {
            //$viewType = 0;
            $viewTypeMyKols = ALL_RECORDS;
        }
        
        //		$fromYear 			= $this->input->post('from_year');
        //		$toYear				= $this->input->post('to_year');
        //		$arrKolNames		= ($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id');
        //		$arrSpecialities	= ($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty');
        //		$arrCountries		= ($this->input->post('country')==(null || '')) ? 0:$this->input->post('country');
        //		$arrListNames		= ($this->input->post('listName')==(null || '')) ? 0:$this->input->post('listName');
        //		$profileType 		= ($this->input->post('profile_type')) ? $this->input->post('profile_type'): '';
        
        $affParamsX = $this->input->post('aff_par_x');
        $affWeightX = $this->input->post('aff_wt_x');
        $eventParamsX = $this->input->post('event_par_x');
        $eventWeightX = $this->input->post('event_wt_x');
        $pubParamsX = $this->input->post('pub_par_x');
        $pubWeightX = $this->input->post('pub_wt_x');
        $trialX = $this->input->post('trial_wt_x');
        
        $affParamsY = $this->input->post('aff_par_y');
        $affWeightY = $this->input->post('aff_wt_y');
        $eventParamsY = $this->input->post('event_par_y');
        $eventWeightY = $this->input->post('event_wt_y');
        $pubParamsY = $this->input->post('pub_par_y');
        $pubWeightY = $this->input->post('pub_wt_y');
        $trialY = $this->input->post('trial_wt_y');
        
        //Get array of kols for X- Axis with count and array of kols for Y - Axis with count
        $arrKolsCountX = $this->report->getSegmentationDataForChart($fromYear, $toYear, $kolIds, $arrSpecialityIds, $arrCountriesIds, $arrListNamesIds, $affParamsX, $affWeightX, $eventParamsX, $eventWeightX, $pubParamsX, $pubWeightX, $trialX, $arrStatesIds, $profileType, $viewType,$arrGlobalRegionIds);
        $arrKolsCountY = $this->report->getSegmentationDataForChart($fromYear, $toYear, $kolIds, $arrSpecialityIds, $arrCountriesIds, $arrListNamesIds, $affParamsY, $affWeightY, $eventParamsY, $eventWeightY, $pubParamsY, $pubWeightY, $trialY, $arrStatesIds, $profileType, $viewType,$arrGlobalRegionIds);
        //Set the data in a session in order to reuse for xls or html table generation
        //Not working
        //$this->session->set_userdata('arrKolsCountX',$arrKolsCountX);
        //$this->session->set_userdata('arrKolsCountY',$affParamsY);
        //Alternative session storage
        $this->session->set_userdata('fromYear', $fromYear);
        $this->session->set_userdata('toYear', $toYear);
        $this->session->set_userdata('arrKolNames', $kolIds);
        $this->session->set_userdata('arrGlobalRegions', $arrGlobalRegionIds);
        $this->session->set_userdata('arrSpecialities', $arrSpecialityIds);
        $this->session->set_userdata('arrCountries', $arrCountriesIds);
        $this->session->set_userdata('arrStates', $arrStatesIds);
        $this->session->set_userdata('arrListNames', $arrListNamesIds);
        $this->session->set_userdata('profileType', $profileType);
        $this->session->set_userdata('viewType', $viewTypeMyKols);
        $this->session->set_userdata('affParamsX', $affParamsX);
        $this->session->set_userdata('affWeightX', $affWeightX);
        $this->session->set_userdata('eventParamsX', $eventParamsX);
        $this->session->set_userdata('eventWeightX', $eventWeightX);
        $this->session->set_userdata('pubParamsX', $pubParamsX);
        $this->session->set_userdata('pubWeightX', $pubWeightX);
        $this->session->set_userdata('trialX', $trialX);
        $this->session->set_userdata('affParamsY', $affParamsY);
        $this->session->set_userdata('affWeightY', $affWeightY);
        $this->session->set_userdata('eventParamsY', $eventParamsY);
        $this->session->set_userdata('eventWeightY', $eventWeightY);
        $this->session->set_userdata('pubParamsY', $pubParamsY);
        $this->session->set_userdata('pubWeightY', $pubWeightY);
        $this->session->set_userdata('trialY', $trialY);
        
        
        
        $arrKolIdX = array_keys($arrKolsCountX);
        $arrKolIdY = array_keys($arrKolsCountY);
        $arrKolIds = array_merge($arrKolIdX, $arrKolIdY);
        
        $arrUniqueKolIds = array_unique($arrKolIds);
        $arrUniqueKolIds = $this->report->sortKolIdsOnCount($arrUniqueKolIds, $arrKolsCountX);
        
        $arrKolDetails = $this->kol->getKolNames();
        $arrKolNames = $this->report->prepareKolIdNameCombinations($arrUniqueKolIds, $arrKolDetails);
        
        //$this->generate_segmentation_xls($arrKolsCountX,$arrKolsCountY,$arrUniqueKolIds,$arrKolNames);
        
        $arrData = array();
        foreach ($arrUniqueKolIds as $kolId) {
            if ($kolId != '') {
                $kolDetails = array();
                if (isset($arrKolNames[$kolId])) {
                    $kolDetails['name'] = $arrKolNames[$kolId];
                    $xCount = 0;
                    $yCount = 0;
                    if (array_key_exists($kolId, $arrKolsCountX))
                        $xCount = round($arrKolsCountX[$kolId]);
                        if (array_key_exists($kolId, $arrKolsCountY))
                            $yCount = round($arrKolsCountY[$kolId]);
                            
                            $kolDetails['y'] = (int) $yCount;
                            $kolDetails['x'] = (int) $xCount;
                            $kolDetails['kolId'] = $kolId;
                            $arrData[] = $kolDetails;
                }
            }
        }
        
        echo json_encode($arrData);
    }
    
    function generate_segmentation_xls() {
        //Get all the post parameters from the session
        $fromYear = $this->session->userdata('fromYear');
        $toYear = $this->session->userdata('toYear');
        $arrKolNames = $this->session->userdata('arrKolNames');
        $arrSpecialities = $this->session->userdata('arrSpecialities');
        $arrCountries = $this->session->userdata('arrCountries');
        $arrListNames = $this->session->userdata('arrListNames');
        $affParamsX = $this->session->userdata('affParamsX');
        $affWeightX = $this->session->userdata('affWeightX');
        $eventParamsX = $this->session->userdata('eventParamsX');
        $eventWeightX = $this->session->userdata('eventWeightX');
        $pubParamsX = $this->session->userdata('pubParamsX');
        $pubWeightX = $this->session->userdata('pubWeightX');
        $trialX = $this->session->userdata('trialX');
        $affParamsY = $this->session->userdata('affParamsY');
        $affWeightY = $this->session->userdata('affWeightY');
        $eventParamsY = $this->session->userdata('eventParamsY');
        $eventWeightY = $this->session->userdata('eventWeightY');
        $pubParamsY = $this->session->userdata('pubParamsY');
        $pubWeightY = $this->session->userdata('pubWeightY');
        $trialY = $this->session->userdata('trialY');
        $arrStatesIds = $this->session->userdata('arrStates');
        $profileType = $this->session->userdata('profileType');
        $viewTypeMyKols = $this->session->userdata('viewType');
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        //Get array of kols for X- Axis with count and array of kols for Y - Axis with count
        $arrKolsCountX = $this->report->getSegmentationData($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsX, $affWeightX, $eventParamsX, $eventWeightX, $pubParamsX, $pubWeightX, $trialX, $arrStatesIds, $profileType, $viewMyKols);
        $arrKolsCountY = $this->report->getSegmentationData($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsY, $affWeightY, $eventParamsY, $eventWeightY, $pubParamsY, $pubWeightY, $trialY, $arrStatesIds, $profileType, $viewMyKols);
        
        $this->load->plugin('phpxls/writer');
        
        $sheet1 = $this->report->prepare_segmentation_table_data($arrKolsCountX, $arrKolsCountY);
        $yearRangeData = array('', '', 'Year Range: ' . $fromYear . ' - ' . $toYear, '', '','','');
        $sheet1[0] = $yearRangeData;
        //pr($sheet1);
        $filename = "segmentationFile.xls";
        
        
        $workbook = new Spreadsheet_Excel_Writer();
        
        // To allow more than 255 charecters.
        $workbook->setVersion(8);
        
        $format_und = & $workbook->addFormat();
        $format_und->setBottom(2); //thick
        $format_und->setRight(1);
        $format_und->setBold();
        $format_und->setHAlign('centre');
        $format_und->setVAlign('vcentre');
        $format_und->setColor('black');
        $format_und->setFontFamily('Arial');
        $format_und->setSize(11);
        
        $format_reg = & $workbook->addFormat();
        $format_reg->setBorder(1);
        $format_reg->setHAlign('left');
        $format_reg->setVAlign('vcentre');
        $format_reg->setColor('black');
        $format_reg->setFontFamily('Arial');
        $format_reg->setSize(10);
        
        $format_newKol = & $workbook->addFormat();
        $format_newKol->setBold();
        $format_newKol->setBorder(1);
        $format_newKol->setHAlign('left');
        $format_newKol->setVAlign('vcentre');
        $format_newKol->setColor('black');
        $format_newKol->setFontFamily('Arial');
        $format_newKol->setSize(10);
        
        $format_secondSub = & $workbook->addFormat();
        $format_secondSub->setItalic();
        $format_secondSub->setBorder(1);
        $format_secondSub->setHAlign('left');
        $format_secondSub->setVAlign('vcentre');
        $format_secondSub->setColor('black');
        $format_secondSub->setFontFamily('Arial');
        $format_secondSub->setSize(10);
        
        $arr = array(
            'SegmentationData' => $sheet1
        );
        
        foreach ($arr as $wbname => $rows) {
            $rowcount = count($rows);
            $colcount = count($rows[0]);
            
            $worksheet = & $workbook->addWorksheet($wbname);
            
            if ($wbname == 'SegmentationData') {
                $worksheet->setColumn(0, 0, 15); //setColumn(startcol,endcol,float)
                $worksheet->setColumn(1, 1, 40);
                $worksheet->setColumn(2, 2, 50);
                $worksheet->setColumn(3, 6, 15);
                //$worksheet->setColumn(2,6, 50.00);
            }
            //$worksheet->setMerge(0, 0, 0, 5);
            for ($j = 0; $j < $rowcount; $j++) {
                for ($i = 0; $i < $colcount; $i++) {
                    $fmt = & $format_reg;
                    if ($j == 0)
                        $fmt = & $format_und;
                        
                        if (isset($rows[$j][$i])) {
                            //It's start of new KOL, make that row as bold
                            if ($rows[$j][0] != '') {
                                $fmt = & $format_newKol;
                            } else {
                                //If the row is a 'second level split up row' then print them in 'Italic' format
                                if ($rows[$j][2] != 'Affiliations' && $rows[$j][2] != 'Events' && $rows[$j][2] != 'Publications' && $rows[$j][2] != 'Trials')
                                    $fmt = & $format_secondSub;
                            }
                            $data = $rows[$j][$i];
                            $worksheet->write($j, $i, $data, $fmt);
                        }
                }
            }
        }
        //for downloading the file
        $workbook->send('ktls_segmentation.xls');
        $workbook->close();
    }
    
    /*
     * @author Laxman K
     * @since 3.1.2
     * @created on 22-10-11
     *
     *  Function to fetch the records of scattered diagram and display it in html page
     *
     */
    
    function scatr_graph_html_data() {
        
        // Retrieve the data from scattered diagram which has been stored in session
        $fromYear = $this->session->userdata('fromYear');
        $toYear = $this->session->userdata('toYear');
        $arrKolNames = $this->session->userdata('arrKolNames');
        $arrSpecialities = $this->session->userdata('arrSpecialities');
        $arrCountries = $this->session->userdata('arrCountries');
        $arrListNames = $this->session->userdata('arrListNames');
        $affParamsX = $this->session->userdata('affParamsX');
        $affWeightX = $this->session->userdata('affWeightX');
        $eventParamsX = $this->session->userdata('eventParamsX');
        $eventWeightX = $this->session->userdata('eventWeightX');
        $pubParamsX = $this->session->userdata('pubParamsX');
        $pubWeightX = $this->session->userdata('pubWeightX');
        $trialX = $this->session->userdata('trialX');
        $affParamsY = $this->session->userdata('affParamsY');
        $affWeightY = $this->session->userdata('affWeightY');
        $eventParamsY = $this->session->userdata('eventParamsY');
        $eventWeightY = $this->session->userdata('eventWeightY');
        $pubParamsY = $this->session->userdata('pubParamsY');
        $pubWeightY = $this->session->userdata('pubWeightY');
        $trialY = $this->session->userdata('trialY');
        $arrStatesIds = $this->session->userdata('arrStates');
        $profileType = $this->session->userdata('profileType');
        $viewTypeMyKols = $this->session->userdata('viewType');
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        // To retrieve X and Y counts with each KOLs
        $arrKolsCountX = $this->report->getSegmentationData($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsX, $affWeightX, $eventParamsX, $eventWeightX, $pubParamsX, $pubWeightX, $trialX, $arrStatesIds, $profileType, $viewMyKols);
        $arrKolsCountY = $this->report->getSegmentationData($fromYear, $toYear, $arrKolNames, $arrSpecialities, $arrCountries, $arrListNames, $affParamsY, $affWeightY, $eventParamsY, $eventWeightY, $pubParamsY, $pubWeightY, $trialY, $arrStatesIds, $profileType, $viewMyKols);
        
        // Prepare an array of each KOL and respective count values
        $data['data'] = $this->report->prepare_segmentation_table_data($arrKolsCountX, $arrKolsCountY);
        $this->load->view('reports/scatr_graph_html_data', $data);
    }
    
    /**
     * prepares the json data for kol activity report,
     * @author 	Ramesh B
     * @Created on: 20-07-12
     * @since 4.6
     * @return JSON
     */
    function get_kols_activity_report() {
        $page = $_REQUEST['page']; // get the requested page
        $limit = $_REQUEST['rows']; // get how many rows we want
        $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
        $sord = $_REQUEST['sord']; // get the direction
        if (!$sidx)
            $sidx = 1;
            //With respect to issue '0001206' as it was considering the date range and missing the years grater than current year
            //		$arrFilterById = $this->kol->getFilterByRecentApplied();
            $arrFilterFields = array();
            $viewTypeMyKols = $this->input->post("viewTypeMyKols");
            //		$arrFilterFields									= $arrFilterById['arrFilterFields'];
            //		pr($arrFilterFields);
            $fromYear = $this->input->post('from_year');
            $toYear = $this->input->post('to_year');
            $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
            $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
            $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
            $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
            $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
            $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
            $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
            $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
            $arrGlobalRegions = urldecode($arrGlobalRegions);
            //		echo $fromYear."-d-".$toYear."-d-".$arrKolNames."-d-".$arrSelectedKol."-d-".pr($arrSpecialities)."-d-".pr($arrCountries)."-d-".pr($arrStatesIds)."-d-".pr($arrListNames)."-d-".$arrProfileType;
            $arrFilters['event_weight'] = $this->input->post('event_weight');
            $arrFilters['aff_weight'] = $this->input->post('aff_weight');
            $arrFilters['pub_weight'] = $this->input->post('pub_weight');
            $arrFilters['trial_weight'] = $this->input->post('trial_weight');
            if ($viewTypeMyKols == MY_RECORDS) {
                $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                if (sizeof($viewMyKols) > 0) {
                    $viewType = $viewMyKols;
                    $viewTypeMyKols = MY_RECORDS;
                } else {
                    $viewType = array(0);
                    $viewTypeMyKols = MY_RECORDS;
                }
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
            if ($arrKolNames == '0' && $arrGlobalRegions == '0' && $arrSpecialities == '0' &&
                $arrCountries == '0' && $arrStatesIds == '0' &&
                $arrListNames == '0' && $arrProfileType == '' &&
                $arrFilters['event_weight'] == 1 && $arrFilters['aff_weight'] == 1 &&
                $arrFilters['pub_weight'] == 1 && $arrFilters['trial_weight'] == 1 &&
                $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS && $arrSelectedKol == '0') {
                    $this->load->model('json_store');
                    $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_ACTIVITY_REPORT);
                    $data = $arrStoredJson['json_data'];
                    ob_start('ob_gzhandler');
                    echo $data;
                } else {
                    if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
                        if (!is_array($arrGlobalRegions))
                            $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
                            else
                                $arrGlobalRegionIds = $arrGlobalRegions;
                    }
                    
                    if ($arrSpecialities != '0' && $arrSpecialities != '') {
                        if (!is_array($arrSpecialities))
                            $arrSpecialityIds = explode(",", $arrSpecialities);
                            else
                                $arrSpecialityIds = $arrSpecialities;
                    }
                    //			pr($arrSpecialityIds);
                    if ($arrCountries != '0' && $arrCountries != '') {
                        if (!is_array($arrCountries))
                            $arrCountriesIds = explode(",", $arrCountries);
                            else
                                $arrCountriesIds = $arrCountries;
                    }
                    //			pr($arrCountriesIds);
                    if ($arrStatesIds != '0' && $arrStatesIds != '') {
                        if (!is_array($arrStatesIds))
                            $arrStatesIds = explode(",", $arrStatesIds);
                            else
                                $arrStatesIds = $arrStatesIds;
                    }
                    //			pr($arrStatesIds);
                    if ($arrKolNames != '0' && $arrKolNames != '') {
                        if (!is_array($arrKolNames))
                            $kolIds = $arrSelectedKol;
                            else
                                $kolIds = $arrKolNames;
                    }else {
                        $kolIds = $arrSelectedKol;
                    }
                    //			pr($arrSelectedKol);
                    if ($arrListNames != '0' && $arrListNames != '') {
                        if (!is_array($arrCountries))
                            $arrListNamesIds = explode(",", $arrListNames);
                            else
                                $arrListNamesIds = $arrListNames;
                    }
                    
                    
                    /* $arrFilterById = $this->kol->getFilterByRecentApplied();
                     $viewTypeMyKols	= $this->input->post("viewTypeMyKols");
                     $arrFilterFields	= array();
                     $arrFilterFields	= $arrFilterById['arrFilterFields'];
                     
                     $fromYear 			= 0;
                     $toYear				= 0;
                     $arrKolNames		= ($arrFilterFields['kol_id'])? $arrFilterFields['kol_id'] : (($this->input->post('kol_id')==(null || '')) ? 0:$this->input->post('kol_id'));
                     $arrSelectedKol		= ($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
                     $arrSpecialities	= ($arrFilterFields['specialty'])? $arrFilterFields['specialty'] : (($this->input->post('specialty')==(null || '')) ? 0:$this->input->post('specialty'));
                     $arrCountries		= ($arrFilterFields['country'])? $arrFilterFields['country'] : (($this->input->post('country')==(null || '')) ? 0:$this->input->post('country'));
                     $arrStatesIds		= ($arrFilterFields['state'])? $arrFilterFields['state'] : (($this->input->post('state')==(null || '')) ? 0:$this->input->post('state'));
                     $arrListNames		= ($arrFilterFields['list_id'])? $arrFilterFields['list_id'] : (($this->input->post('listName')==(null || '')) ? 0:$this->input->post('listName'));
                     $arrProfileType		= ($arrFilterFields['profile_type'])? $arrFilterFields['profile_type'] : (($this->input->post('profile_type'))? $this->input->post('profile_type'):'');
                     
                     //		pr($arrSpecialities);
                     $arrFilters['event_weight']=$this->input->post('event_weight');
                     $arrFilters['aff_weight']=$this->input->post('aff_weight');
                     $arrFilters['pub_weight']=$this->input->post('pub_weight');
                     $arrFilters['trial_weight']=$this->input->post('trial_weight');
                     if($viewTypeMyKols == MY_RECORDS){
                     $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                     if(sizeof($viewMyKols) > 0){
                     $viewType = $viewMyKols;
                     $viewTypeMyKols = MY_RECORDS;
                     }else{
                     $viewType = array(0);
                     $viewTypeMyKols = ALL_RECORDS;
                     }
                     }else{
                     $viewTypeMyKols = ALL_RECORDS;
                     }
                     if($arrKolNames == '0' && $arrSpecialities == '0' &&
                     $arrCountries == '0' && $arrStatesIds == '0' &&
                     $arrListNames == '0' && $arrProfileType == '' &&
                     $arrFilters['event_weight'] == 1 && $arrFilters['aff_weight'] == 1 &&
                     $arrFilters['pub_weight'] == 1 && $arrFilters['trial_weight'] == 1 &&
                     $arrProfileType == '' && $viewTypeMyKols == ALL_RECORDS)
                     {
                     $this->load->model('json_store');
                     $arrStoredJson = $this->json_store->getJsonByParamFromStore(JSON_STORE_ACTIVITY_REPORT);
                     $data = $arrStoredJson['json_data'];
                     ob_start('ob_gzhandler');
                     echo $data;
                     }else{
                     if($arrSpecialities!='0' && $arrSpecialities!=''){
                     if(!is_array($arrSpecialities))
                     $arrSpecialityIds=explode(",",$arrSpecialities);
                     else
                     $arrSpecialityIds=$arrSpecialities;
                     //				$arrSpecialityIds=$arrSpecialities;
                     }
                     if($arrCountries!='0' && $arrCountries!=''){
                     if(!is_array($arrCountries))
                     $arrCountriesIds=explode(",",$arrCountries);
                     else
                     $arrCountriesIds=$arrCountries;
                     }
                     if($arrStatesIds!='0' && $arrStatesIds!=''){
                     if(!is_array($arrStatesIds))
                     $arrStatesIds=explode(",",$arrStatesIds);
                     else
                     $arrStatesIds=$arrStatesIds;
                     }
                     if($arrKolNames!='0' && $arrKolNames!=''){
                     $kolIds[]=$arrSelectedKol;
                     }else{
                     $kolIds=$arrKolNames;
                     }
                     if($arrListNames!='0' && $arrListNames!=''){
                     $arrListNamesIds=$arrListNames;
                     } */
                     $arrWeights['event_weight'] = 1;
                     $arrWeights['aff_weight'] = 1;
                     $arrWeights['pub_weight'] = 1;
                     $arrWeights['trial_weight'] = 1;
                     /* 		 */
                     if (isset($_POST) && count($_POST) > 0) {
                         $arrWeights['event_weight'] = $this->input->post('event_weight');
                         $arrWeights['aff_weight'] = $this->input->post('aff_weight');
                         $arrWeights['pub_weight'] = $this->input->post('pub_weight');
                         $arrWeights['trial_weight'] = $this->input->post('trial_weight');
                     }
                     
                     if ($arrWeights['event_weight'] == 0 && $arrWeights['aff_weight'] == 0 && $arrWeights['pub_weight'] == 0 && $arrWeights['trial_weight'] == 0) {
                         $data = array();
                         echo json_encode($data);
                         return;
                     }
                     
                     $arrEventsData = array();
                     $arrAffsData = array();
                     $arrPublicationsData = array();
                     $arrTrialsData = array();
                     $arrEventsCount = array();
                     $arrAffsCount = array();
                     $arrPublicationsCount = array();
                     $arrTrialsCount = array();
                     $arrKolIds = array();
                     
                     $arrEventsCountResults = $this->kol->getEventsByParam($fromYear, $toYear, $kolIds, $arrSessionTypes = 0, $arrRoles = 0, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                     foreach ($arrEventsCountResults as $event)
                         $arrEventsCount[$event['kol_id']] = $event['count'];
                         
                         $arrAffsCountResults = $this->kol->getAffiliationsByParam($fromYear, $toYear, $kolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                         foreach ($arrAffsCountResults as $aff)
                             $arrAffsCount[$aff['kol_id']] = $aff['count'];
                             
                             $arrPublicationsCountResults = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limit, $arrProfileType, $viewType, $arrGlobalRegionIds);
                             foreach ($arrPublicationsCountResults as $publication)
                                 $arrPublicationsCount[$publication['kol_id']] = $publication['count'];
                                 
                                 $arrTrialsCountResults = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType, $arrGlobalRegionIds);
                                 foreach ($arrTrialsCountResults as $trial)
                                     $arrTrialsCount[$trial['kol_id']] = $trial['count'];
                                     
                                     $mergedArray = array_merge($arrEventsCountResults, $arrAffsCountResults, $arrPublicationsCountResults, $arrTrialsCountResults);
                                     foreach ($mergedArray as $details) {
                                         $arrKolIds[] = $details['kol_id'];
                                     }
                                     $uniqeKolIds = array_unique($arrKolIds);
                                     
                                     $arrTopKols = $this->calcTopKolsAcivities($arrEventsCount, $arrAffsCount, $arrPublicationsCount, $arrTrialsCount, $arrWeights, $uniqeKolIds);
                                     
                                     $arrKolDetails = $this->kol->getKolNames();
                                     //pr($arrKolDetails);exit;
                                     $topKolNames = $this->report->prepareKolIdNameCombinations($arrTopKols, $arrKolDetails);
                                     // pr($arrTopKols);exit;
                                     $arrKolsActivityCounts = array();
                                     foreach ($arrTopKols as $kolId) {
                                         $arrKolData = array();
                                         if (array_key_exists($kolId, $arrEventsCount)) {
                                             $arrKolData['events'] = ((int) $arrEventsCount[$kolId] * $arrWeights['event_weight']);
                                         } else
                                             $arrKolData['events'] = 0;
                                             
                                             if (array_key_exists($kolId, $arrAffsCount)) {
                                                 $arrKolData['affs'] = ((int) $arrAffsCount[$kolId] * $arrWeights['aff_weight']);
                                             } else
                                                 $arrKolData['affs'] = 0;
                                                 
                                                 if (array_key_exists($kolId, $arrPublicationsCount)) {
                                                     $arrKolData['pubs'] = ((int) $arrPublicationsCount[$kolId] * $arrWeights['pub_weight']);
                                                 } else
                                                     $arrKolData['pubs'] = 0;
                                                     
                                                     if (array_key_exists($kolId, $arrTrialsCount)) {
                                                         $arrKolData['trials'] = ((int) $arrTrialsCount[$kolId] * $arrWeights['trial_weight']);
                                                     } else
                                                         $arrKolData['trials'] = 0;
                                                         
                                                         $arrKolData['id'] = $kolId;
                                                         $arrKolData['name'] = $topKolNames[$kolId];
                                                         $arrKolData['unique_id'] = $this->common_helpers->getUniqueIdByKolId($kolId);
                                                         $arrKolData['total'] = (int) $arrKolData['events'] + (int) $arrKolData['affs'] + (int) $arrKolData['pubs'] + (int) $arrKolData['trials'];
                                                         $arrKolsActivityCounts[] = $arrKolData;
                                     }
                                     $limit = $_REQUEST['rows'];
                                     $count = sizeof($arrKolsActivityCounts);
                                     if ($count > 0) {
                                         $total_pages = ceil($count / $limit);
                                     } else {
                                         $total_pages = 0;
                                     }
                                     //             pr($arrKolsActivityCounts);exit;
                                     $data['records'] = $count;
                                     $data['total'] = $total_pages;
                                     $data['page'] = $page;
                                     $data['rows'] = $arrKolsActivityCounts;
                                     ob_start('ob_gzhandler');
                                     echo json_encode($data);
                }
                
    }
    
    function events_by_type_tabular_report($typeId, $kol_id, $fromYear, $toYear, $reportFilters = '', $viewTypeMyKols) {
        
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        
        //		pr($viewType);
        $filters = array();
        $filters = $this->filters_to_array($reportFilters);
        //		pr($filters);
        //		if($filters['kol_id'][0]!=''){
        //			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
        //		}
        //	pr($filters);
        $arrEvents = $this->kol->eventsByTypeTabularReport($typeId, $kol_id, $fromYear, $toYear, $filters, $viewType);
        //		echo $this->db->last_query();
        $data['arrEvents'] = $arrEvents;
        $data['viewType'] = $viewType;
        $this->load->view('reports/events_by_type_tabular_report', $data);
    }
    
    function activty_tabular_report($value, $reportFilters = '', $viewTypeMyKols,$profileType) {
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
    
        //		pr($viewType);
        $filters = array();
        $filters = $this->filters_to_array($reportFilters);
        if($profileType!='publication'){
            $value = str_replace("_","/",$value);
            $arrKols = $this->kol->activtyTabularReport($value,$filters, $viewType,$profileType);
            //		echo $this->db->last_query();
            $data['arrKols'] = $arrKols;
            $data['profileType'] = 'country';
            $this->load->view('reports/activity_tabular_report', $data);
        }else{           
            $data['profileType'] = 'publication';
            $data['kolId'] = $value;
            if($value != 0){
                $koldetails = $this->kol->getKolName($value);
                $data['first_name']		= $koldetails['first_name'];
                $data['middle_name']	= $koldetails['middle_name'];
                $data['last_name']		= $koldetails['last_name'];
            }
            $this->load->view('reports/activity_tabular_report',$data);
        }
    }
    
    
    function get_kols_by_event_id($id,$view_type=''){
        $data['arrKols'] = $this->kol->getKolsByEventId($id,$view_type);
        $this->load->view('reports/events_attended_kols', $data);
    }
    function get_kols_by_inst_id($id,$viewTypeMyKols){
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $data['arrKols'] = $this->kol->getKolsByInstId($id,$viewType);
        $this->load->view('reports/affilation_attended_kols', $data);
    }
    
    function aff_by_type_tabular_report($type, $kol_id, $fromYear, $toYear, $reportFilters = '', $viewTypeMyKols) {
        if ($viewTypeMyKols == MY_RECORDS) {
            $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
            if (sizeof($viewMyKols) > 0) {
                $viewType = $viewMyKols;
                $viewTypeMyKols = MY_RECORDS;
            } else {
                $viewTypeMyKols = ALL_RECORDS;
            }
        } else {
            $viewTypeMyKols = ALL_RECORDS;
        }
        $filters = array();
        $filters = $this->filters_to_array($reportFilters);
        //		pr($filters);
        //		if($filters['kol_id'][0]!=''){
        //			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
        //		}
            $arrAffs = $this->kol->affsByTypeTabularReport($type, $kol_id, $fromYear, $toYear, $filters, $viewType);
            $data['arrAffs'] = $arrAffs;
            $this->load->view('reports/aff_by_type_tabular_report', $data);
    }
    
    function filters_to_array($reportFilters) {
        $filters = array();
        if ($reportFilters != '') {
            $reportFiltersElements = explode(':', $reportFilters);
            foreach ($reportFiltersElements as $filterElement) {
                $filterElements = explode('=', $filterElement);
                $filterName = $filterElements[0];
                $filterValues = array();
                if ($filterElements[1] != '') {
                    $arrFilterValues = explode(',', $filterElements[1]);
                    $filterValues = $arrFilterValues;
                }
                if (sizeof($filterValues) > 0)
                    $filters[$filterName] = $filterValues;
            }
        }
        return $filters;
    }
    
    function getKolIds($kolNames) {
        
        $kolIds = array();
        
        foreach ($kolNames as $key => $kolname) {
            $kolIds[] = $this->kol->getKolId($kolname);
        }
        return $kolIds;
    }
    
    function calculate_reports_chart_data() {
    	$analystSelectedClientId = $this->input->post('clientId');
        $this->load->model('json_store');
        ini_set("max_execution_time", 36000);
        
        //------------------------- Acitvity Reports -------------------------------
        $fromYear = 0;
        $toYear = 0;
        $kolIds = 0;
        $arrSpecialityIds = 0;
        $arrCountriesIds = 0;
        $arrStatesIds = 0;
        $arrListNamesIds = 0;
        $arrProfileType = 0;
        //$viewType = 0;
        $arrGlobalRegionIds = 0;
        $limit = 0;
        
        $arrWeights['event_weight'] = 1;
        $arrWeights['aff_weight'] = 1;
        $arrWeights['pub_weight'] = 1;
        $arrWeights['trial_weight'] = 1;
        
        $arrEventsData = array();
        $arrAffsData = array();
        $arrPublicationsData = array();
        $arrTrialsData = array();
        $arrEventsCount = array();
        $arrAffsCount = array();
        $arrPublicationsCount = array();
        $arrTrialsCount = array();
        $arrKolIds = array();
        
        $arrEventsCountResults = $this->kol->getEventsByParam($fromYear, $toYear, $kolIds, $arrSessionTypes = 0, $arrRoles = 0, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType = NULL, $arrGlobalRegionIds, $analystSelectedClientId);
        foreach ($arrEventsCountResults as $event)
            $arrEventsCount[$event['kol_id']] = $event['count'];
            
        //$arrAffsCountResults 			= $this->kol->getAffsCountOfAllKols();
        $arrAffsCountResults = $this->kol->getAffiliationsByParam($fromYear, $toYear, $kolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType = NULL, $arrGlobalRegionIds, $analystSelectedClientId);
        foreach ($arrAffsCountResults as $aff)
            $arrAffsCount[$aff['kol_id']] = $aff['count'];
                
        $arrPublicationsCountResults = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limit,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
        foreach ($arrPublicationsCountResults as $publication)
             $arrPublicationsCount[$publication['kol_id']] = $publication['count'];
                    
        $arrTrialsCountResults = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
        foreach ($arrTrialsCountResults as $trial)
             $arrTrialsCount[$trial['kol_id']] = $trial['count'];
                        
        $mergedArray = array_merge($arrEventsCountResults, $arrAffsCountResults, $arrPublicationsCountResults, $arrTrialsCountResults);
        //$mergedArray=array_merge(array_reverse($arrEventsCount), array_reverse($arrEventsCount),array_reverse($arrPublicationsCount),array_reverse($arrTrialsCount));
        foreach ($mergedArray as $details) {
             $arrKolIds[] = $details['kol_id'];
        }
        $uniqeKolIds = array_unique($arrKolIds);
                        
        $arrTopKols = $this->calcTopKolsAcivities($arrEventsCount, $arrAffsCount, $arrPublicationsCount, $arrTrialsCount, $arrWeights, $uniqeKolIds);
                        
        $arrKolDetails = $this->kol->getKolNames();
        $topKolNames = $this->report->prepareKolIdNameCombinations($arrTopKols, $arrKolDetails);
        $arrKolsActivityCounts = array();
        foreach ($arrTopKols as $kolId) {
          $arrKolData = array();
          if (array_key_exists($kolId, $arrEventsCount)) {
                 $arrKolData['events'] = ((int) $arrEventsCount[$kolId] * $arrWeights['event_weight']);
              } else
                 $arrKolData['events'] = 0;
                                
          if (array_key_exists($kolId, $arrAffsCount)) {
                  $arrKolData['affs'] = ((int) $arrAffsCount[$kolId] * $arrWeights['aff_weight']);
              } else
                  $arrKolData['affs'] = 0;
                                    
          if (array_key_exists($kolId, $arrPublicationsCount)) {
                   $arrKolData['pubs'] = ((int) $arrPublicationsCount[$kolId] * $arrWeights['pub_weight']);
              } else
                   $arrKolData['pubs'] = 0;
                                        
          if (array_key_exists($kolId, $arrTrialsCount)) {
                   $arrKolData['trials'] = ((int) $arrTrialsCount[$kolId] * $arrWeights['trial_weight']);
              } else
                   $arrKolData['trials'] = 0;
                                            
          $arrKolData['id'] = $kolId;
          $arrKolData['unique_id'] = $this->common_helpers->getUniqueIdByKolId($kolId);
          $arrKolData['name'] = $topKolNames[$kolId];
          //	$arrKolData['name'] = '<a target="_NEW" href="'.base_url().'kols/view/'.$kolId.'">'.$arrKolData['name'].'</a>';
          $arrKolData['total'] = (int) $arrKolData['events'] + (int) $arrKolData['affs'] + (int) $arrKolData['pubs'] + (int) $arrKolData['trials'];
          $arrKolsActivityCounts[] = $arrKolData;
        }
                        
        $count = sizeof($arrKolsActivityCounts);
        $limit = 10;
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data0['records'] = $count;
        $data0['total'] = $total_pages;
        $data0['page'] = $page;
        $data0['rows'] = $arrKolsActivityCounts;
        
        $arrData[JSON_STORE_ACTIVITY_REPORT] = json_encode($data0);
        
        //------------------------- Acitvity Chart -------------------------------
        
        $fromYear = $this->input->post('from_year');
        $toYear = $this->input->post('to_year');
        $kolIds = 0;
        $arrSpecialityIds = 0;
        $arrCountriesIds = 0;
        $arrStatesIds = 0;
        $arrListNamesIds = 0;
        $arrProfileType = 0;
        //$viewType = 0;
        $arrGlobalRegionIds = 0;
        $limit = 0;
        
        $arrWeights['event_weight'] = 1;
        $arrWeights['aff_weight'] = 1;
        $arrWeights['pub_weight'] = 1;
        $arrWeights['trial_weight'] = 1;
        
        $arrEventsData = array();
        $arrAffsData = array();
        $arrPublicationsData = array();
        $arrTrialsData = array();
        $arrEventsCount = array();
        $arrAffsCount = array();
        $arrPublicationsCount = array();
        $arrTrialsCount = array();
        $arrKolIds = array();
        
        $arrEventsCountResults = $this->kol->getEventsByParam($fromYear, $toYear, $kolIds, $arrSessionTypes = 0, $arrRoles = 0, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType = NULL, $arrGlobalRegionIds, $analystSelectedClientId);
        foreach ($arrEventsCountResults as $event)
            $arrEventsCount[$event['kol_id']] = $event['count'];
            
        //$arrAffsCountResults 			= $this->kol->getAffsCountOfAllKols();
        $arrAffsCountResults = $this->kol->getAffiliationsByParam($fromYear, $toYear, $kolIds, $arrEngTypes = '', $arrOrgType = '', $arrCountriesIds, $arrSpecialityIds, 'kol_memberships.kol_id', $arrListNamesIds, $arrStatesIds, $arrProfileType, $viewType = NULL, $arrGlobalRegionIds, $analystSelectedClientId);
        foreach ($arrAffsCountResults as $aff)
            $arrAffsCount[$aff['kol_id']] = $aff['count'];
                
        $arrPublicationsCountResults = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'kolId', $arrListNamesIds, $arrStatesIds, $limit,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
        foreach ($arrPublicationsCountResults as $publication)
            $arrPublicationsCount[$publication['kol_id']] = $publication['count'];
                    
        $arrTrialsCountResults = $this->clinical_trial->getTrialsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, 'kolId', $arrListNamesIds, $arrStatesIds,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
        foreach ($arrTrialsCountResults as $trial)
            $arrTrialsCount[$trial['kol_id']] = $trial['count'];
                        
        $mergedArray = array_merge($arrEventsCountResults, $arrAffsCountResults, $arrPublicationsCountResults, $arrTrialsCountResults);
        //$mergedArray=array_merge(array_reverse($arrEventsCount), array_reverse($arrEventsCount),array_reverse($arrPublicationsCount),array_reverse($arrTrialsCount));
        foreach ($mergedArray as $details) {
                  $arrKolIds[] = $details['kol_id'];
        }
        $uniqeKolIds = array_unique($arrKolIds);
                        
        $arrTopKols = $this->calcTopKolsAcivities($arrEventsCount, $arrAffsCount, $arrPublicationsCount, $arrTrialsCount, $arrWeights, $uniqeKolIds);
                        
        $topLimit = 15;
        $i = 1;
                        
        foreach ($arrTopKols as $kolId) {
             if (array_key_exists($kolId, $arrEventsCount)) {
               		$arrEventsData[] = ((int) $arrEventsCount[$kolId] * $arrWeights['event_weight']);
                } else
                    $arrEventsData[] = 0;
                                
             if (array_key_exists($kolId, $arrAffsCount)) {
                    $arrAffsData[] = ((int) $arrAffsCount[$kolId] * $arrWeights['aff_weight']);
                } else
                    $arrAffsData[] = 0;
                                    
             if (array_key_exists($kolId, $arrPublicationsCount)) {
                    $arrPublicationsData[] = ((int) $arrPublicationsCount[$kolId] * $arrWeights['pub_weight']);
                } else
                    $arrPublicationsData[] = 0;
                                        
             if (array_key_exists($kolId, $arrTrialsCount)) {
                    $arrTrialsData[] = ((int) $arrTrialsCount[$kolId] * $arrWeights['trial_weight']);
                } else
                    $arrTrialsData[] = 0;
                                            
             if ($i >= $topLimit)
                	break;
                else
                    $i++;
         }
         $arrKolDetails = $this->kol->getKolNames();
         $topKolNames = $this->report->prepareKolIdNameCombinations($arrTopKols, $arrKolDetails);
         $data[] = array_values($topKolNames);
         $data[] = $arrEventsData;
         $data[] = $arrAffsData;
         $data[] = $arrPublicationsData;
         $data[] = $arrTrialsData;
         $arrData[JSON_STORE_ACTIVITY] = json_encode($data);
                        
                        
         //------------------------- Acitvity Chart -------------------------------
         //------------------------- Publications By Year Chart -------------------------------
         //				$data = array();
         $limit = 0;
         $arrPublications = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'year', $arrListNamesIds, $arrStatesIds, $limit,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
         $years = array();
         $count = array();
         //$i=15;
                        
         foreach ($arrPublications as $publication) {
         //if($i<=0)break;
             if ($publication['year'] != 0){
             //$years[] = substr($publication['year'], 2);
                 $years[] = $publication['year'];
                }
             // else
             //     $years[] = $publication['year'];
             $count[] = (int) $publication['count'];
             $yearMapping[substr($publication['year'], 2)] = $publication['year'];
             //$i--;
         }
         $data1[] = array_reverse($years);
         $data1[] = array_reverse($count);
         $data1[] = $yearMapping;
                        
         //				foreach($arrPublications as $publication){
         //					//if($i<=0)break;
         //					$years[]=$publication['year'];
         //					$count[]=(int)$publication['count'];
         //					//$i--;
         //				}
         //				$data1[]=array_reverse($years);
         //				$data1[]=array_reverse($count);
                        
         $arrData[JSON_STORE_PUBLICATIONS_BY_YEAR] = json_encode($data1);
                        
         //------------------------- Publications By Substances Chart -------------------------------
                        
         $arrSubstances = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'substance', $arrListNamesIds, $arrStatesIds, 20, $arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
         $substances = array();
         $count = array();
         $arrIds = array();
         $i = 20;
         foreach ($arrSubstances as $substance) {
                 if ($i <= 0)
                 break;
                 $substances[] = ucwords($substance['name']);
                 $count[] = (int) $substance['count'];
                 $arrIds[] = $substance['id'];
                 $i--;
         }
         $data2[] = $substances;
         $data2[] = $count;
         $data2[] = $arrIds;
                        
         $arrData[JSON_STORE_PUBLICATIONS_BY_SUBSTANCES] = json_encode($data2);
                        
         //------------------------- Publications By Keywords Chart -------------------------------
         $limit = 0;               
         $arrMajorMeshterm = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'keyword', $arrListNamesIds, $arrStatesIds,$limit,$arrProfileType,$viewType = NULL, $arrGlobalRegionIds,$analystSelectedClientId);
                        
         $meshTerms = array();
         $count = array();
         $arrIds = array();
         $arrParentIds = array();
         $i = 20;
         foreach ($arrMajorMeshterm as $meshterm) {
                 if ($i <= 0)
                 break;
                 $termName = '';
                 $parentId = $meshterm['parent_id'];
                 if ($parentId != 0 && $parentId != null) {
                     	$parentName = $this->pubmed->getMeshTermName($parentId);
                     	$termName = $parentName . "/" . $meshterm['mesh_term'];
                     } else {
                     	$termName = $meshterm['mesh_term'];
                     }
                 $meshTerms[] = ucwords($termName);
                 $count[] = (int) $meshterm['count'];
                 $arrIds[] = $meshterm['id'];
                 $arrParentIds[] = $meshterm['parent_id'];
                 $i--;
         }
         $data3[] = $meshTerms;
         $data3[] = $count;
         $data3[] = $arrIds;
         $data3[] = $arrParentIds;
                        
         $arrData[JSON_STORE_PUBLICATIONS_BY_KEYWORDS] = json_encode($data3);
                        
         //------------------------- Publications By Journals Chart -------------------------------
                        
         $arrJournals = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'journal', $arrListNamesIds, $arrStatesIds, 20);
         $name = array();
         $count = array();
         $arrIds = array();
         $i = 20;
         foreach ($arrJournals as $row) {
                 if ($i <= 0)
                 break;
                 $name[] = $row['name'];
                 $count[] = (int) $row['count'];
                 $arrIds[] = $row['id'];
                 $i--;
         }
         $data4[] = $name;
         $data4[] = $count;
         $data4[] = $arrIds;
                        
         $arrData[JSON_STORE_PUBLICATIONS_BY_JOURNALS] = json_encode($data4);
                        
         //------------------------- Inserting all the data to json_store table -------------------------------
         foreach ($arrData as $k => $arrJsonData) {
                 $rowData['json_data'] = $arrJsonData;
                 $rowData['ref_id'] = $k;
                 $rowData['client_id'] = $analystSelectedClientId;
                 $this->json_store->deleteFromStoreByClientId($k, $analystSelectedClientId);
                 $this->json_store->insertJsonToStore($rowData);
          }
         $filePath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "system/logs/jobs/cron_job_status.txt";
         $content = "reports_data_cron.php :: " . date("Y-m-d H:i:s") . "::success :: no comments \r\n";
         file_put_contents($filePath, $content, FILE_APPEND | LOCK_EX);
}

/**
 * Prepares the JSON data for top 20 Journals count chart
 * @author 	Ramesh B
 * @Created on: 14-03-11
 * @since	1.5.1
 * @return Array
 */
function view_pub_type_chart() {
    ini_set("max_execution_time", 36000);
    
    $arrFilterFields = array();
    $viewTypeMyKols = $this->input->post("viewTypeMyKols");
    $fromYear = $this->input->post('from_year');
    $toYear = $this->input->post('to_year');
    $arrKolNames = ($arrFilterFields['kol_id']) ? $arrFilterFields['kol_id'] : (($this->input->post('kol_id') == (null || '')) ? 0 : $this->input->post('kol_id'));
    $arrSelectedKol = ($this->input->post('selected_kol_id')) ? $this->input->post('selected_kol_id') : 0; //($this->input->post('selected_kol_id')==null) ? 0:$this->input->post('selected_kol_id');
    $arrGlobalRegions = ($arrFilterFields['global_region']) ? $arrFilterFields['global_region'] : (($this->input->post('global_region') == (null || '')) ? 0 : $this->input->post('global_region'));
    $arrSpecialities = ($arrFilterFields['specialty']) ? $arrFilterFields['specialty'] : (($this->input->post('specialty') == (null || '')) ? 0 : $this->input->post('specialty'));
    $arrCountries = ($arrFilterFields['country']) ? $arrFilterFields['country'] : (($this->input->post('country') == (null || '')) ? 0 : $this->input->post('country'));
    $arrStatesIds = ($arrFilterFields['state']) ? $arrFilterFields['state'] : (($this->input->post('state') == (null || '')) ? 0 : $this->input->post('state'));
    $arrListNames = ($arrFilterFields['list_id']) ? $arrFilterFields['list_id'] : (($this->input->post('listName') == (null || '')) ? 0 : $this->input->post('listName'));
    $arrProfileType = ($arrFilterFields['profile_type']) ? $arrFilterFields['profile_type'] : (($this->input->post('profile_type')) ? $this->input->post('profile_type') : '');
    $arrGlobalRegions = urldecode($arrGlobalRegions);
    //		echo $arrKolNames." - ".$arrSelectedKol;
    if ($viewTypeMyKols == MY_RECORDS) {
        $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
        if (sizeof($viewMyKols) > 0) {
            $viewType = $viewMyKols;
            $viewTypeMyKols = MY_RECORDS;
        } else {
            $viewType = array(0);
            $viewTypeMyKols = MY_RECORDS;
        }
    } else {
        $viewTypeMyKols = ALL_RECORDS;
    }
    
    if ($arrGlobalRegions != '0' && $arrGlobalRegions != '') {
        if (!is_array($arrGlobalRegions))
            $arrGlobalRegionIds = explode(",", $arrGlobalRegions);
            else
                $arrGlobalRegionIds = $arrGlobalRegions;
    }
    if ($arrSpecialities != '0' && $arrSpecialities != '') {
        if (!is_array($arrSpecialities))
            $arrSpecialityIds = explode(",", $arrSpecialities);
            else
                $arrSpecialityIds = $arrSpecialities;
    }
    if ($arrCountries != '0' && $arrCountries != '') {
        if (!is_array($arrCountries))
            $arrCountriesIds = explode(",", $arrCountries);
            else
                $arrCountriesIds = $arrCountries;
    }
    if ($arrStatesIds != '0' && $arrStatesIds != '') {
        if (!is_array($arrStatesIds))
            $arrStatesIds = explode(",", $arrStatesIds);
            else
                $arrStatesIds = $arrStatesIds;
    }
    if ($arrKolNames != '0' && $arrKolNames != '') {
        if (!is_array($arrKolNames))
            $kolIds = $arrSelectedKol;
            else
                $kolIds = $arrKolNames;
    }else {
        $kolIds = $arrSelectedKol;
    }
    //		pr($kolIds);
    if ($arrListNames != '0' && $arrListNames != '') {
        if (!is_array($arrListNames))
            $arrListNamesIds = explode(",", $arrListNames);
            else
                $arrListNamesIds = $arrListNames;
    }
    
    $arrJournals = $this->pubmed->getPublicationsByParam($fromYear, $toYear, $kolIds, $arrCountriesIds, $arrSpecialityIds, $groupBy = 'type', $arrListNamesIds, $arrStatesIds, 20, $profileType, $viewType,$arrGlobalRegionIds);
    //		echo $this->db->last_query();
    $name = array();
    $count = array();
    $arrIds = array();
    $i = 20;
    foreach ($arrJournals as $row) {
        if ($i <= 0)
            break;
            $name[] = $row['name'];
            $count[] = (int) $row['count'];
            $arrIds[] = $row['id'];
            $i--;
    }
    $data[] = $name;
    $data[] = $count;
    $data[] = $arrIds;
    echo json_encode($data);
}

function msl_activity_report() {
    $clientId = $this->session->userdata('client_id');
    $data['arrClientUsers'] = $this->Client_User->getClientUsersMSL($clientId);
    $managerId = $this->session->userdata('user_id');
    $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
    $data['arrTeam'] = $this->interaction->getTeamForMirf();
    $data['contentPage'] = 'reports/msl_activity_report';
    if(IS_IPAD_REQUEST){
        $data['enableRefineBySection'] = true;
        $data['data']['filterPage'] = '/reports/crm_report_filters';
        $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
    }else{
        $this->load->view('layouts/client_view', $data);
    }
}

function msl_activity_grid_data() {
    $data['start_date'] = $_REQUEST['start_date'];
    $data['end_date'] = $_REQUEST['end_date'];
    $data['msl'] = $_REQUEST['msl'];
    $data['team'] = $_REQUEST['team'];
    $data['manager_id'] = $_REQUEST['manager_id'];
    $arrData = array();
    $arrData = $this->report->getMSLActivityReportData($limit, $start, false, $sidx, $sord, $whereResultArray, $data);
    
    foreach ($arrData as $key => $row) {
        $arrData[$key]['name'] = $row['first_name'] . " " . $row['last_name'];
    }
    
    $data['records'] = count($arrData);
    ;
    $data['total'] = $total_pages;
    $data['page'] = $page;
    $data['rows'] = $arrData;
    echo json_encode($data);
}

function user_access_report() {
    $managerId = $this->session->userdata('user_id');
    $data['arrClientUsers'] = $this->login_model->getTopMslForUserDetails();
    $data['arrTeam'] = $this->interaction->getTeamForMirf();
    $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);//new
    $data['contentPage'] = 'reports/user_access_report';
    if(IS_IPAD_REQUEST){
        $data['enableRefineBySection'] = true;
        $data['data']['filterPage'] = '/reports/crm_report_filters';
        $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
    }else{
        $this->load->view('layouts/client_view', $data);
    }
}

function view_coaching_reports() {
    
    
    //        $data['filterPage'] = 'reports/coaching_filter_li_style';
    $managerId = $this->session->userdata('user_id');
    $data['arrTeam'] = $this->interaction->getTeamForMirf();
    $data['arrClientUsers'] = $this->coaching->getClientUser();
    ;
    //                 pr($data['arrClientUsers']);
    
    $data['arrSpecialties'] = $this->coaching->getAllAreas();
    $data['arrEngagement'] = $this->coaching->getAllEngagement();
    $data['arrEngagementManager'] = $this->common_helpers->getAllManagersForReports($managerId);//new
    
    $data['contentPage'] = 'reports/view_coaching_reports';
    if(IS_IPAD_REQUEST){
        $data['enableRefineBySection'] = true;
        //            $data['filterPage'] = 'reports/medical_insight_filter_li';
        $data['data']['filterPage'] = 'reports/coaching_filter_li_style';
        $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
    }else{
        $data['filterPage'] = 'reports/coaching_filter_li_style';
        $this->load->view('layouts/client_view', $data);
    }
    
}

function coaching_report_filter() {
    $data = $_POST;
    pr($data);
}

function list_coaching_grid() {
    //         $this->output->enable_profiler(TRUE);
    $filters = $_POST;
    //        pr($filters);
    $page = $_REQUEST['page'];
    $limit = $_REQUEST['rows'];
    $arrCoachingResult = $this->coaching->listCoachingReport($filters);
    $count = sizeof($arrCoachingResult);
    if ($count > 0) {
        $total_pages = ceil($count / $limit);
    } else {
        $total_pages = 0;
    }
    $data['records'] = $count;
    $data['total'] = $total_pages;
    $data['page'] = $page;
    $data['rows'] = $arrCoachingResult;
    echo json_encode($data);
}

function category_filter($cat) {
    $filters = $_POST;
    $this->coaching->categoryFilter($cat, $filters);
}

function category_filter_engagement($cat) {
    $filters = $_POST;
    $this->customer_engagement->categoryFilterEngagement($cat, $filters);
}

function list_uoq() {
    $managerId = $this->session->userdata('user_id');
    $data['arrClientUsers'] = $this->interaction->getTopMslForMirf();
    $data['arrTeam'] = $this->interaction->getTeamForMirf();
    $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
    $data['contentPage'] = 'interactions/list_mirf';
    if(IS_IPAD_REQUEST){
        $data['enableRefineBySection'] = true;
        $data['data']['filterPage'] = '/reports/crm_report_filters';
        $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
    }else{
        $this->load->view('layouts/client_view', $data);
    }
}

function list_speaker_evaluations() {
    $managerId = $this->session->userdata('user_id');
    $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
    $data['arrClientUsers'] = $this->speaker_evaluation->getMslForSpeaker();
    $data['arrTeam'] = $this->interaction->getTeamForMirf();
    $data['isReportPage'] = true;
    $data['contentPage'] = 'speakers/list_speaker_evaluation';
    if(IS_IPAD_REQUEST){
        $data['enableRefineBySection'] = true;
        $data['data']['filterPage'] = '/reports/crm_report_filters';
        $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
    }else{
        $this->load->view('layouts/client_view', $data);
    }
}

/**
 *
 *
 * Coaching reports
 */
function getBarChartDataCoaching() {
    $filterData = $_POST;
    $arrReportData = $this->coaching->getTherapeuticAreaNamesForBarChartCoaching($filterData);
    
    foreach ($arrReportData as $row) {
        //                     pr($val);
        $arrReportData['chartdata']['nominees'][] = $row['name'];
        $arrReportData['chartdata']['count'][] = (int) $row['CountOf'];
        //                    pr($row['specialty']);
    }
    if (count($arrReportData) == 0)
        echo '{"chartdata":{"nominees":["CNS","Oncology","Cardio-Renal"],"count":[0,0,0]}}';
        else
            echo json_encode($arrReportData);
}

function export_coaching_report() {
    
    //		error_reporting(E_ALL);
    $startTime = microtime(true);
    ini_set('memory_limit', "-1");
    ini_set("max_execution_time", 0);
    $this->load->plugin('php_excel/Classes/PHPExcel.php');
    //		$exportOpts		= $this->input->post('export_opts');
    $coachingIds = $this->input->post('coaching');
    $filters = $this->input->post('filter');
    $arrFilters = str_replace(";", "", $filters);
    parse_str($arrFilters, $params);
    
    $arrCoachingIds = explode(',', $coachingIds);
    // Get PIN
    //		$kolArray	=	$this->kol->getKolsIdAndPin();
    // Get the list of Specialties
    //		$this->load->model('Specialty');
    //		$arrSpecialties	=	$this->Specialty->getAllSpecialties();
    //		$exportOpts = array();
    //		$exportOpts[] = "professional";
    //		$exportOpts[] = "contact";
    //		$exportOpts[] = "biography";
    //		$exportOpts[] = "education";
    //		$exportOpts[] = "affiliation";
    //		$exportOpts[] = "event";
    //		$exportOpts[] = "publication";
    //		$exportOpts[] = "trial";
    //		$exportOpts[] = "media";
    //		pr($exportOpts);
    //		exit;
    //		$clientId = $this->session->userdata('client_id');
    
    $objPHPExcel = new PHPExcel();
    //		$objPHPExcel->setActiveSheetIndex(0);
    //		$arrKolIds = array(2016,1619,1976,264,2018);
    $arrExcelData = array();
    
    $arrCoachingDetails = $this->coaching->exportCoachingReport($arrCoachingIds, $params);
    
    
    
    
    //		foreach ($arrKolIds as $kolsId){
    //			$arrKolDetails	=	$this->kol->getKolDetailsById($kolId);
    //			if(in_array('professional', $exportOpts)){
    //New Worksheet
    $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
    //				$objWorksheet = $objPHPExcel->getActiveSheet();
    $objWorksheet->setTitle('Coaching Report');
    //Add header
    $objWorksheet->setCellValue('A1', 'Is Active')
    ->setCellValue('B1', 'MSL NAME')
    ->setCellValue('C1', 'Team Name')
    ->setCellValue('D1', 'Count')
    ->setCellValue('E1', 'Evaluated By');
    //								->setCellValue('E1', 'Topics')
    //								->setCellValue('F1', 'Sphere of Influence')
    //								->setCellValue('G1', 'Summarize Medical Insight')
    //								->setCellValue('H1', 'Describe Relevance to OPDCI')
    //								->setCellValue('I1', 'Actions to consider')
    //								->setCellValue('J1', 'Recorded By');
    //
    //				if($clientId==INTERNAL_CLIENT_ID){
    //					$objWorksheet->setCellValue('P1', 'Url');
    //				}
        $i = 2;
        
        //					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
        foreach ($arrCoachingDetails as $row) {
            
            $objWorksheet->setCellValue('A' . $i, $row['active'])
            ->setCellValue('B' . $i, $row['username'])
            ->setCellValue('C' . $i, $row['group_name'])
            ->setCellValue('D' . $i, $row['entry_count'])
            ->setCellValue('E' . $i, $row['evaluated_by']);
            //									->setCellValue('E'.$i, $row['topics'])
            //									->setCellValue('F'.$i, $row['sphere_of_influence'])
            //									->setCellValue('G'.$i, $row['summary'])
            //									->setCellValue('H'.$i, $row['relevance'])
            //									->setCellValue('I'.$i, $row['actions_to_consider'])
            //									->setCellValue('J'.$i, $row['created_user']);
            //						if($clientId==INTERNAL_CLIENT_ID){
            //							$objWorksheet->setCellValue('P'.$i, $row['url']);
            //						}
            $i++;
        }
        
        $objPHPExcel->addSheet($objWorksheet);
        //			}
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'D') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Coaching Report.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit;
    }
    
    function medical_insight_reports() {
        
        $managerId = $this->session->userdata('user_id');
        
        $data['arrClientUsers'] = $this->coaching->getTopMsl();
        $data['arrSpecialties'] = $this->coaching->getAllAreasCount();
        $arrInvestigational = array();
        $investigationalAgent = $this->coaching->getInvestigationalAgentNamesCount();
        
        $sourceType = $this->coaching->getTopSourceType();
        $sphereOfInfluence = $this->coaching->getSphereOfInfluenceNamesCount();
        
        
        $Product = $this->coaching->getTopProductNames();
        
        $keyInsightTopic = $this->coaching->getTopKeyInsightTopicNames();
        $data['arrTeam'] = $this->interaction->getTeamForMirf();
        $data['keyInsightTopic'] = $keyInsightTopic;
        $data['sphereOfInfluence'] = $sphereOfInfluence;
        $data['sourceType'] = $sourceType;
        
        $data['investigationalAgent'] = $investigationalAgent;
        $data['product'] = $Product;
        $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
        $data['contentPage'] = 'reports/view_medical_insight_reports';
        if(IS_IPAD_REQUEST){
            $data['enableRefineBySection'] = true;
            //        	$data['filterPage'] = 'reports/medical_insight_filter_li';
            $data['data']['filterPage'] = '/reports/medical_insight_filter_li';
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
        }else{
            $data['filterPage'] = 'reports/medical_insight_filter_li';
            $this->load->view('layouts/client_view', $data);
        }
        
    }
    
    function getReportsData() {
        //            $filters=$_POST;
        $filterData = array();
        $filterData['from'] = ($this->input->post('from')) ? $this->input->post('from') : '';
        $filterData['to'] = ($this->input->post('to')) ? $this->input->post('to') : '';
        $filterData['msl'] = ($this->input->post('msl')) ? $this->input->post('msl') : '';
        $filterData['thrp_name'] = ($this->input->post('thrp_name')) ? $this->input->post('thrp_name') : '';
        $filterData['agent'] = ($this->input->post('agent')) ? $this->input->post('agent') : '';
        $filterData['sphere_influencers'] = ($this->input->post('sphere_influencers')) ? $this->input->post('sphere_influencers') : '';
        $filterData['source_type'] = ($this->input->post('source_type')) ? $this->input->post('source_type') : '';
        $filterData['topics'] = ($this->input->post('topics')) ? $this->input->post('topics') : '';
        $filterData['product'] = ($this->input->post('product')) ? $this->input->post('product') : '';
        $filterData['team_name'] = ($this->input->post('team_name')) ? $this->input->post('team_name') : '';
        $arrReportData['therapeuticArea'] = $this->coaching->getChartMedicalInsightCountBasedOnMSl($filterData);
        if (count($arrReportData['therapeuticArea']) == 0)
            echo '[["No results",""]]';
            else
                echo json_encode($arrReportData['therapeuticArea']);
    }
    
    function getReportsDataCoaching() {
        $filters = $_POST;
        $arrReportData['therapeuticArea'] = $this->coaching->getUserCount($filters);
        if (count($arrReportData['therapeuticArea']) == 0)
            echo '[["No results",""]]';
            else
                echo json_encode($arrReportData['therapeuticArea']);
    }
    
    function getBarChartData() {
        //                $filters=$_POST;
        $filterData = array();
        $filterData['from'] = ($this->input->post('from')) ? $this->input->post('from') : '';
        $filterData['to'] = ($this->input->post('to')) ? $this->input->post('to') : '';
        $filterData['msl'] = ($this->input->post('msl')) ? $this->input->post('msl') : '';
        $filterData['thrp_name'] = ($this->input->post('thrp_name')) ? $this->input->post('thrp_name') : '';
        $filterData['agent'] = ($this->input->post('agent')) ? $this->input->post('agent') : '';
        $filterData['sphere_influencers'] = ($this->input->post('sphere_influencers')) ? $this->input->post('sphere_influencers') : '';
        $filterData['source_type'] = ($this->input->post('source_type')) ? $this->input->post('source_type') : '';
        $filterData['topics'] = ($this->input->post('topics')) ? $this->input->post('topics') : '';
        $filterData['product'] = ($this->input->post('product')) ? $this->input->post('product') : '';
        $filterData['team_name'] = ($this->input->post('team_name')) ? $this->input->post('team_name') : '';
        $arrReportData = $this->coaching->getTherapeuticAreaNamesForBarChart($filterData);
        // pr($arrReportData);
        foreach ($arrReportData as $row) {
            //                     pr($val);
            $arrReportData['chartdata']['nominees'][] = $row['specialty'];
            $arrReportData['chartdata']['count'][] = (int) $row['CountOf'];
            //                    pr($row['specialty']);
        }
        if (count($arrReportData) == 0)
            echo '{"chartdata":{"nominees":["CNS","Oncology","Cardio-Renal"],"count":[0,0,0]}}';
            else
                echo json_encode($arrReportData);
    }
    
    function medical_report_filter($fields) {
        
        $data = $_POST;
        $arrMedicalResult = $this->coaching->getMedicalInsightFilteredData($fields, $data);
    }
    
    function getMedicalInsightCount() {
        $filterData = array();
        $filterData['from'] = ($this->input->post('from')) ? $this->input->post('from') : '';
        $filterData['to'] = ($this->input->post('to')) ? $this->input->post('to') : '';
        $filterData['msl'] = ($this->input->post('msl')) ? $this->input->post('msl') : '';
        $filterData['thrp_name'] = ($this->input->post('thrp_name')) ? $this->input->post('thrp_name') : '';
        $filterData['agent'] = ($this->input->post('agent')) ? $this->input->post('agent') : '';
        $filterData['sphere_influencers'] = ($this->input->post('sphere_influencers')) ? $this->input->post('sphere_influencers') : '';
        $filterData['source_type'] = ($this->input->post('source_type')) ? $this->input->post('source_type') : '';
        $filterData['topics'] = ($this->input->post('topics')) ? $this->input->post('topics') : '';
        $filterData['product'] = ($this->input->post('product')) ? $this->input->post('product') : '';
        $filterData['team_name'] = ($this->input->post('team_name')) ? $this->input->post('team_name') : '';
        $filterData['manager_id'] = ($this->input->post('manager_id')) ? $this->input->post('manager_id') : '';
        //        $page = $_REQUEST['page'];
        //        $limit = $_REQUEST['rows'];
        //        $sidx = $_POST['sidx']; // get index row - i.e. user click to sort
        //        $sord = $_POST['sord']; // get the direction
        //        $start = $limit * ($page - 1); // do not put $limit*($page - 1)
        //        $filterDatas = $_REQUEST['filters'];
        //        $Details = array();
        //        $Details['page'] = $page;
        //        $Details['limit'] = $limit;
        //        $Details['sidx'] = $sidx;
        //        $Details['sord'] = $sord;
        //        $Details['start'] = $start;
        //        $arrFilter = array();
        //        $arrFilter = json_decode(stripslashes($filterDatas));
        //        $field = 'field';
        //        $op = 'op';
        //        $data = 'data';
        //        $groupOp = 'groupOp';
        //        $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
        //        $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
        //        $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
        //        $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
        //
        //        foreach ($searchField as $key => $val) {
        //            $Details[$val] = $searchString[$key];
        //        }
        //         $arrCoachingResult = $this->coaching->getMedicalInsightCountBasedOnMSl($limit, $start, false, $sidx, $sord, $Details, $filterData);
        $arrCoachingResult = $this->coaching->getMedicalInsightCountBasedOnMSl($filterData);
        foreach ($arrCoachingResult as $row) {
            $arrCoaching[] = $row;
        }
        //         $count = $this->coaching->getMedicalInsightCountBasedOnMSl($limit, $start, true, $sidx, $sord, $Details, $filterData);
        
        $count = sizeof($arrCoaching);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data = array();
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCoaching;
        echo json_encode($data);
    }
    
    function get_suggestions_for_msl_autocomplete_refineby($mslName) {
        $mslName = utf8_urldecode($this->input->post($mslName));
        $arrMSL = $this->report->getMsl($mslName);
        $arrSuggestMSL = array();
        if (sizeof($arrMSL) == 0) {
            $arrSuggestMSL[0] = 'No results found for ' . $mslName;
        } else {
            $flag = 1;
            foreach ($arrMSL as $id => $name) {
                if ($flag) {
                    $arrSuggestMSL[] = '<div class="autocompleteHeading">MSL</div><div class="dataSet"><label name="' . $id . '" class="msl" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestMSL[] = '<div class="dataSet"><label name="' . $id . '" class="msl" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $mslName;
        $arrReturnData['suggestions'] = $arrSuggestMSL;
        echo json_encode($arrReturnData);
    }
    
    function get_suggestions_for_product_autocomplete_refineby($productName) {
        $productName = utf8_urldecode($this->input->post($productName));
        $arrProduct = $this->report->getProduct($productName);
        $arrSuggestProduct = array();
        if (sizeof($arrProduct) == 0) {
            $arrSuggestProduct[0] = 'No results found for ' . $productName;
        } else {
            $flag = 1;
            foreach ($arrProduct as $id => $name) {
                if ($flag) {
                    $arrSuggestProduct[] = '<div class="autocompleteHeading">Product</div><div class="dataSet"><label name="' . $id . '" class="products" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestProduct[] = '<div class="dataSet"><label name="' . $id . '" class="products" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $productName;
        $arrReturnData['suggestions'] = $arrSuggestProduct;
        echo json_encode($arrReturnData);
    }
    
    function get_suggestions_for_topic_autocomplete_refineby($topicName) {
        $topicName = utf8_urldecode($this->input->post($topicName));
        $arrTopic = $this->report->getTopic($topicName);
        $arrSuggestTopic = array();
        if (sizeof($arrTopic) == 0) {
            $arrSuggestTopic[0] = 'No results found for ' . $topicName;
        } else {
            $flag = 1;
            foreach ($arrTopic as $id => $name) {
                if ($flag) {
                    $arrSuggestTopic[] = '<div class="autocompleteHeading">Topics</div><div class="dataSet"><label name="' . $name . '" class="topics" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestTopic[] = '<div class="dataSet"><label name="' . $id . '" class="topics" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $topicName;
        $arrReturnData['suggestions'] = $arrSuggestTopic;
        echo json_encode($arrReturnData);
    }
    
    function get_suggestions_for_source_autocomplete_refineby($sourceName) {
        $sourceName = utf8_urldecode($this->input->post($sourceName));
        $arrSource = $this->report->getSource($sourceName);
        $arrSuggestSource = array();
        if (sizeof($arrSource) == 0) {
            $arrSuggestSource[0] = 'No results found for ' . $sourceName;
        } else {
            $flag = 1;
            foreach ($arrSource as $id => $name) {
                if ($flag) {
                    $arrSuggestSource[] = '<div class="autocompleteHeading">Source Type</div><div class="dataSet"><label name="' . $name . '" class="source" style="display:block">' . $name . "</label></div>";
                    $flag = 0;
                } else {
                    $arrSuggestSource[] = '<div class="dataSet"><label name="' . $id . '" class="source" style="display:block">' . $name . "</label></div>";
                }
            }
        }
        $arrReturnData['query'] = $sourceName;
        $arrReturnData['suggestions'] = $arrSuggestSource;
        echo json_encode($arrReturnData);
    }
    
    function export_kol_new() {
        
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('medical');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arr1 = (array) json_decode($arrFilters);
        $objPHPExcel = new PHPExcel();
        
        $arrExcelData = array();
        $arrKolDetails[] = $this->coaching->exportMedicalIdGridReport($id, $arr1);
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Medical Insight Reports');
        $fileName = 'Medical Insight Report';
        //Add header
        $objWorksheet->setCellValue('A1', 'Active?')
        ->setCellValue('B1', 'MSL Name')
        ->setCellValue('C1', 'Team Name')
        ->setCellValue('D1', 'Count')
        ;
        $i = 2;
        
        foreach ($arrKolDetails[0] as $rows) {
            
            $objWorksheet->setCellValue('A' . $i, $rows['is_activated'])
            ->setCellValue('B' . $i, $rows['username'])
            ->setCellValue('C' . $i, $rows['group_name'])
            ->setCellValue('D' . $i, $rows['entry_count'])
            ;
            $i++;
        }
        
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        
        
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'D') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="medical_insight_report.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function view_interaction_reports() {
        
        ini_set("max_execution_time", 7200);
        ini_set('memory_limit', '-1');
        
        $arrInteractionsFilterResults = $this->interaction->getInteractionFilters($arrFilters);
        //		echo $this->db->last_query();
        $filterData = array();
        //		pr($arrInteractionsFilterResults);
        foreach ($arrInteractionsFilterResults as $row) {
            if ($row['client_user_id'] != '')
                $filterData['arrInteractionsUsers'][$row['client_user_id']] = $row['user_name'];
                if ($row['interaction_channel_id'] != '')
                    $filterData['arrInteractionsChannel'][$row['interaction_channel_id']] = $row['interaction_channel'];
                    if ($row['interaction_category_id'] != '')
                        $filterData['arrInteractionsCategory'][$row['interaction_category_id']] = $row['interaction_category'];
                        if ($row['interaction_product_id'] != '')
                            $filterData['arrInteractionsProduct'][$row['interaction_product_id']] = $row['interaction_product'];
                            if ($row['interaction_type_id'] != '')
                                $filterData['arrInteractionsType'][$row['interaction_type_id']] = $row['interaction_type'];
                                if ($row['interaction_topic_id'] != '')
                                    $filterData['arrInteractionsTopic'][$row['interaction_topic_id']] = $row['interaction_topic'];
                                    if ($row['interaction_sub_topic_id'] != '')
                                        $filterData['arrInteractionsSubTopic'][$row['interaction_sub_topic_id']] = $row['interaction_sub_topic'];
                                        if ($row['interaction_group_id'] != '')
                                            $filterData['arrInteractionsTeams'][$row['interaction_group_id']] = $row['interaction_group_name'];
        }
        $managerId = $this->session->userdata("user_id");
        $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
        foreach ($data['arrManager'] as $row){
            $filterData['arrManager'][$row['id']] = $row['first_name']." ".$row['last_name'];
        }
        
        $arr = array();
        function cmp($a, $b) {
            if ($a == $b) {
                return 0;
            }
            return ($a < $b) ? -1 : 1;
        }
        
        foreach ($filterData as $key => $row) {
            $arrTemp = array();
            foreach ($row as $k => $v) {
                $arrTemp[$k] = $v;
            }
            uasort($arrTemp, 'cmp');
            $arr[$key] = $arrTemp;
        }
        $this->load->model('user_setting');
        $userId = $this->loggedUserId;
        $filterData = $this->user_setting->getDataFromAppSettings($userId,'interaction_filter_date');
        if($filterData > 0){
            $arr['fromFilterData'] = $filterData-1;
        }else{
            $arr['fromFilterData'] = 0;
        }
        $arr['contentPage'] = 'reports/view_interaction_reports';
        //		$filterData['filterPage']		= 'reports/interaction_filter_li_style';
        if(IS_IPAD_REQUEST){
            $arr['enableRefineBySection'] = true;
            $arr['data']['layout_type'] = true;
            $arr['data']['filterPage'] = '/reports/interaction_filters';
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $arr);
        }else{
        	$arr['enableReportForUsers'] = $this->report->getUsersToAccessReports();
            $arr['filterPage'] = 'reports/interaction_filters';
            $this->load->view('layouts/client_view', $arr);
        }
    }
    
    function reload_interaction_filters() {
        ini_set("max_execution_time", 7200);
        $arrInteractionFromDate = $this->input->post('fromDate');
        $arrInteractionToDate = $this->input->post('toDate');
        $interactionChannel = trim($this->input->post('interaction_id'));
        $interactionCategory = trim($this->input->post('category_id'));
        
        $arrInteractionChannels = $this->input->post('channel');
        $arrInteractionCategories = $this->input->post('category');
        $arrInteractionProcuts = $this->input->post('product');
        $arrInteractionTypes = $this->input->post('type');
        $arrInteractionTopics = $this->input->post('topic');
        $arrInteractionSubTopics = $this->input->post('sub_topic');
        
        //Prepare array of filter fields, ehich will be used for querying
        $arrFilters = array();
        $arrFilters['fromDate'] = $arrInteractionFromDate;
        $arrFilters['toDate'] = $arrInteractionToDate;
        $arrFilters['channel'] = $arrInteractionChannels;
        $arrFilters['category'] = $arrInteractionCategories;
        $arrFilters['product'] = $arrInteractionProcuts;
        $arrFilters['type'] = $arrInteractionTypes;
        $arrFilters['topic'] = $arrInteractionTopics;
        $arrFilters['sub_topic'] = $arrInteractionSubTopics;
        
        //		pr($arrFilters);
        $arrInteractionsChannelResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_channel');
        $arrInteractionsCategoryResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_category');
        $arrInteractionsProductResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_product');
        $arrInteractionsTypeResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_type');
        $arrInteractionsTopicResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_topic');
        $arrInteractionsSubTopicResults = $this->interaction->getInteractionFilters($arrFilters, 'interaction_sub_topic');
        
        //Preparing the kols by category results as required by the filter page and aso getting the total count for category
        $allInteractionsChannelCount = 0;
        $assoArrInteractionsByChannelCount = array();
        foreach ($arrInteractionsChannelResults as $row) {
            $assoArrInteractionsByChannelCount[$row['interaction_channel_id']] = $row;
            $allInteractionsChannelCount += $row['count'];
        }
        foreach ($assoArrInteractionsByChannelCount as $row) {
            foreach ($arrInteractionChannels as $key => $row1) {
                if ($row1 == $row['interaction_channel_id'])
                    $arrSelectedChannels[$row['interaction_channel_id']] = $row1;
            }
        }
        
        $allInteractionsCategoryCount = 0;
        $assoArrInteractionsByCategoryCount = array();
        foreach ($arrInteractionsCategoryResults as $row) {
            $assoArrInteractionsByCategoryCount[$row['interaction_category_id']] = $row;
            $allInteractionsCategoryCount += $row['count'];
        }
        foreach ($assoArrInteractionsByCategoryCount as $row) {
            foreach ($arrInteractionCategories as $key => $row1) {
                if ($row1 == $row['interaction_category_id'])
                    $arrSelectedCategories[$row['interaction_category_id']] = $row1;
            }
        }
        
        $allInteractionsProductCount = 0;
        $assoArrInteractionsByProductCount = array();
        foreach ($arrInteractionsProductResults as $row) {
            $assoArrInteractionsByProductCount[$row['interaction_product_id']] = $row;
            $allInteractionsProductCount += $row['count'];
        }
        foreach ($assoArrInteractionsByProductCount as $row) {
            foreach ($arrInteractionProcuts as $key => $row1) {
                if ($row1 == $row['interaction_product_id'])
                    $arrSelectedProducts[$row['interaction_product_id']] = $row1;
            }
        }
        
        $allInteractionsTypeCount = 0;
        $assoArrInteractionsByTypeCount = array();
        foreach ($arrInteractionsTypeResults as $row) {
            $assoArrInteractionsByTypeCount[$row['interaction_type_id']] = $row;
            $allInteractionsTypeCount += $row['count'];
        }
        foreach ($assoArrInteractionsByTypeCount as $row) {
            foreach ($arrInteractionTypes as $key => $row1) {
                if ($row1 == $row['interaction_type_id'])
                    $arrSelectedTypes[$row['interaction_type_id']] = $row1;
            }
        }
        
        $allInteractionsTopicCount = 0;
        $assoArrInteractionsByTopicCount = array();
        foreach ($arrInteractionsTopicResults as $row) {
            $assoArrInteractionsByTopicCount[$row['interaction_topic_id']] = $row;
            $allInteractionsTopicCount += $row['count'];
        }
        foreach ($assoArrInteractionsByTopicCount as $row) {
            foreach ($arrInteractionTopics as $key => $row1) {
                if ($row1 == $row['interaction_topic_id'])
                    $arrSelectedTopics[$row['interaction_topic_id']] = $row1;
            }
        }
        
        $allInteractionsSubTopicCount = 0;
        $assoArrInteractionsBySubTopicCount = array();
        foreach ($arrInteractionsSubTopicResults as $row) {
            $assoArrInteractionsBySubTopicCount[$row['interaction_sub_topic_id']] = $row;
            $allInteractionsSubTopicCount += $row['count'];
        }
        foreach ($assoArrInteractionsBySubTopicCount as $row) {
            foreach ($arrInteractionTopics as $key => $row1) {
                if ($row1 == $row['interaction_sub_topic_id'])
                    $arrSelectedSubTopics[$row['interaction_sub_topic_id']] = $row1;
            }
        }
        $filterData = array();
        $filterData['fromDate'] = $arrInteractionFromDate;
        $filterData['toDate'] = $arrInteractionToDate;
        $filterData['allChannelCount'] = $allInteractionsChannelCount;
        $filterData['arrInteractionsByChannelCount'] = $assoArrInteractionsByChannelCount;
        $filterData['selectedChannels'] = $arrSelectedChannels;
        $filterData['allCategoryCount'] = $allInteractionsCategoryCount;
        $filterData['arrInteractionsByCategoryCount'] = $assoArrInteractionsByCategoryCount;
        $filterData['selectedCategories'] = $arrSelectedCategories;
        $filterData['allProductCount'] = $allInteractionsProductCount;
        $filterData['arrInteractionsByProductCount'] = $assoArrInteractionsByProductCount;
        $filterData['selectedProducts'] = $arrSelectedProducts;
        $filterData['allTypeCount'] = $allInteractionsTypeCount;
        $filterData['arrInteractionsByTypeCount'] = $assoArrInteractionsByTypeCount;
        $filterData['selectedTypes'] = $arrSelectedTypes;
        $filterData['allTopicCount'] = $allInteractionsTopicCount;
        $filterData['arrInteractionsByTopicCount'] = $assoArrInteractionsByTopicCount;
        $filterData['selectedTopics'] = $arrSelectedTopics;
        $filterData['allSubTopicCount'] = $allInteractionsSubTopicCount;
        $filterData['arrInteractionsBySubTopicCount'] = $assoArrInteractionsBySubTopicCount;
        $filterData['selectedSubTopics'] = $arrSelectedSubTopics;
        
        //		pr($filterData);
        //		pr($filterData['selectedSpecialties']);
        $this->load->view('reports/interaction_filter_li_style', $filterData);
    }
    
    function list_interactions($isExport = false, $interIds = array()) {
        ini_set("max_execution_time", 7200);
        ini_set('memory_limit', '-1');
        $page = 1;
        $limit = 10;
        
        $arrInteractions = array();
        $arrInteractionFromDate = ($this->input->post('fromDate')) ? $this->input->post('fromDate') : '';
        $arrInteractionToDate = ($this->input->post('toDate')) ? $this->input->post('toDate') : '';
        $arrInteractionMSLUser = ($this->input->post('msl_user')) ? $this->input->post('msl_user') : '';
        $arrInteractionChannels = ($this->input->post('channel')) ? $this->input->post('channel') : '';
        $arrInteractionCategories = ($this->input->post('category')) ? $this->input->post('category') : '';
        $arrInteractionProcuts = ($this->input->post('product')) ? $this->input->post('product') : '';
        $arrInteractionTypes = ($this->input->post('type')) ? $this->input->post('type') : '';
        $arrInteractionTopic = ($this->input->post('topic')) ? $this->input->post('topic') : '';
        $arrInteractionSubTopic = ($this->input->post('sub_topic')) ? $this->input->post('sub_topic') : '';
        $arrInteractionTeam = ($this->input->post('team')) ? $this->input->post('team') : '';
        $arrInteractionIds = ($this->input->post('interaction_ids')) ? $this->input->post('interaction_ids') : '';
        $arrInteractionManagerIds = ($this->input->post('manager_ids')) ? $this->input->post('manager_ids') : '';
        if ($arrInteractionIds != '') {
            $arrInteractionIds = explode(',', $arrInteractionIds);
        }
        
        //Prepare array of filter fields, ehich will be used for querying
        $arrFilters = array();
        $arrFilters['fromDate'] = $arrInteractionFromDate;
        $arrFilters['toDate'] = $arrInteractionToDate;
        $arrFilters['msl_user'] = $arrInteractionMSLUser;
        $arrFilters['channel'] = $arrInteractionChannels;
        $arrFilters['category'] = $arrInteractionCategories;
        $arrFilters['product'] = $arrInteractionProcuts;
        $arrFilters['type'] = $arrInteractionTypes;
        $arrFilters['topic'] = $arrInteractionTopic;
        $arrFilters['sub_topic'] = $arrInteractionSubTopic;
        $arrFilters['team'] = $arrInteractionTeam;
        $arrFilters['interaction_ids'] = $arrInteractionIds;
        $arrFilters['manager_ids'] = $arrInteractionManagerIds;
        if ($isExport) {
            $otherFilters = $this->input->post('filters');
            $otherFilters = rtrim($otherFilters, ',');
            if($otherFilters != ''){
                $filtersArr = array();
                $otherFilters = explode(",",$otherFilters);
                foreach ($otherFilters as $key => $row){
                    $arr = explode(":",$row);
                    $filtersArr[trim($arr[0])] = trim($arr[1]);
                }
            }
            $arrFilters['otherFilters'] = $filtersArr;
            if(empty($interIds)){
                $interIds = $this->input->post('exportIds');
            }
            $arrInteractionIds = ($interIds) ? explode(',', $interIds) : '';
            $arrFilters['interaction_ids'] = $arrInteractionIds;
        }
        //        pr($_POST);
        //        pr($arrFilters);
        //		pr($filtersArr);
        //        exit;
        $reportType = $this->input->post("reportType");
        $arrFilters['report_type'] = $reportType;
        switch ($reportType) {
            case '':
                $arrInteractionsResults = $this->interaction->listInteractions($arrFilters);
                if ($isExport) {
                    $path = $this->excel_export_interactions($arrInteractionsResults);
                    return $path;
                }
                break;
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
                $arrInteractionsResults = $this->interaction->getInteractionsMonthlyByChannel($arrFilters);
                $isExport = $this->input->post("isExport") ? $this->input->post("isExport") : false;
                if ($isExport) {
                    $path = $this->excel_export_by_different_categories($arrInteractionsResults, $arrFilters);
                    return $path;
                }
                
                break;
            case 'chart':
                $arrInteractionsResults = $this->interaction->listInteractions($arrFilters, 'channel');
                break;
        }
        
        if ($isExport) {
            return $arrInteractionsResults;
        }
        if ($reportType == 'chart') {
            $arrInteractionsResultsCount = array();
            foreach ($arrInteractionsResults as $interactionCount) {
                $tmp = array();
                $tmp[] = $interactionCount['interaction_channel'];
                $tmp[] = (int) $interactionCount['interactions_count'];
                $arrInteractionsResultsCount[] = $tmp;
            }
            ob_start('ob_gzhandler');
            echo json_encode($arrInteractionsResultsCount);
            //			echo json_encode($arrInteractionsResults);
            //			exit;
        } else {
            $data = array();
            if (count($arrInteractionsResults) > 0) {
                if (isset($arrInteractionsResults['userdata'])) {
                    $data['userdata'] = $arrInteractionsResults['userdata'];
                    unset($arrInteractionsResults['userdata']);
                }
                $count = sizeof($arrInteractionsResults);
                if ($count > 0) {
                    $total_pages = ceil($count / $limit);
                } else {
                    $total_pages = 0;
                }
                $data['records'] = $count;
                $data['total'] = $total_pages;
                $data['page'] = $page;
                $data['rows'] = $arrInteractionsResults;
            }
            ob_start('ob_gzhandler');
            echo json_encode($data);
        }
    }
    
    /**
     * coaching quarterly reports
     */
    function view_coaching_quarterly_reports() {
        $data['contentPage'] = 'reports/view_coaching_quarterly_reports';
        $data['filterPage'] = 'reports/coaching_quarterly_filter_li_style';
        $managerId = $this->session->userdata('user_id');
        $data['arrClientUsers'] = $this->coaching->getClientUser();
        ;
        //                 pr($data['arrClientUsers']);
        //
        //                   $data['arrSpecialties'] = $this->coaching->getAllAreas();
        //                   $data['arrEngagement'] = $this->coaching->getAllEngagement();
        $this->load->view('layouts/client_view', $data);
    }
    
    function get_quarterly_data() {
        $filters = $_POST;
        
        $this->coaching->filterQuater($filters);
    }
    
    function get_quarterly_data22() {
        $filters = $_POST;
        $filters['msl_name'][0] = 138;
        $rankingResult = $this->coaching->getMSLCoachingRankingData($filters);
        $quarterlyData = array();
        foreach ($rankingResult as $key => $row) {
            $quarter = "";
            switch ($row['month']) {
                case 1:
                case 2:
                case 3: $quarter = "Q1";
                break;
                case 4:
                case 5:
                case 6: $quarter = "Q2";
                break;
                case 7:
                case 8:
                case 9: $quarter = "Q3";
                break;
                case 10:
                case 11:
                case 12: $quarter = "Q4";
                break;
            }
            $quarter = $quarter . "-" . $row['year'][2] . $row['year'][3];
            $quarterlyData[$quarter][] = (int) $row['score'];
            $rankingResult[$key]['q'] = $quarter;
        }
        $arrQuarterLabels = array_keys($rankingResult);
        $arrQuarterData = array();
        foreach ($rankingResult as $key => $row) {
            $arrQuarterData;
        }
        
        echo json_encode($data);
    }
    
    function view_mirf_base($id) {
        $aarData = $this->interaction->listMirf($id);
        $productDetails = $this->interaction->getProductDetails($id);
        $productName = $this->interaction->getProductNames();
        $arrTemp = array();
        foreach ($productName as $key => $value) {
            $arrTemp[$value['id']] = strtoupper($value['name']);
        }
        $selectedProductIds = array();
        foreach ($productDetails as $key => $value) {
            $selectedProductIds[] = $value['product_id'];
            foreach ($value as $key1 => $value1) {
                if ($key1 == 'other_product_name')
                    $otherProductValue = $value1;
            }
        }
        $data['userTerritory'] = $this->Client_User->getUserTerritoryById($aarData[0]['created_by']);
        $data['productArray'] = $arrTemp;
        $data['selectedProductIds'] = $selectedProductIds;
        $data['otherProductValue'] = $otherProductValue;
        $data['productDetails'] = $productDetails;
        $data['arrData'] = $aarData[0];
        $savedMirfID = $id;
        //Add Log activity
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_VIEW,
            'description' => 'View Mirf',
            'status' => 'success',
            'transaction_id' => $savedMirfID,
            'transaction_table_id' => INTERACTION_MIRF,
            'transaction_name' => "ViewMirf",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);
        log_user_activity(null, true);
        $this->load->view('interactions/view_mirf', $data);
    }
    
    function customer_seen_report() {
        $clientId = $this->session->userdata('client_id');
        $data['arrClientUsers'] = $this->Client_User->getClientUsersMSL($clientId);
        $managerId = $this->session->userdata('user_id');
        $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
        $data['arrTeam'] = $this->interaction->getTeamForMirf();
        $data['isReportPage'] = true;
        $data['contentPage'] = 'reports/customer_seen_report';
        if(IS_IPAD_REQUEST){
            $data['enableRefineBySection'] = true;
            $data['data']['filterPage'] = '/reports/crm_report_filters';
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
        }else{
            $this->load->view('layouts/client_view', $data);
        }
    }
    
    function list_customer_grid() {
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
        $arrCustomerDetails = $this->report->listCustomerSeenReport($arrParams);
        foreach ($arrCustomerDetails as $row) {
            $arrCustomerResult[] = $row;
        }
        $count = sizeof($arrCustomerDetails);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCustomerResult;
        echo json_encode($data);
    }
    
    function institution_seen_report() {
        $clientId = $this->session->userdata('client_id');
        $data['arrClientUsers'] = $this->Client_User->getClientUsersMSL($clientId);
        $managerId = $this->session->userdata('user_id');
        $data['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
        $data['arrTeam'] = $this->interaction->getTeamForMirf();
        $data['isReportPage'] = true;
        $data['contentPage'] = 'reports/institution_seen_report';
        if(IS_IPAD_REQUEST){
            $data['enableRefineBySection'] = true;
            $data['data']['filterPage'] = '/reports/crm_report_filters';
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
        }else{
            $this->load->view('layouts/client_view', $data);
        }
    }
    
    function list_institution_grid() {
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
        $arrInstitutionDetails = $this->report->listInstitutionSeenReport($arrParams);
        foreach ($arrInstitutionDetails as $row) {
            $arrInstitutionResult[] = $row;
        }
        $count = sizeof($arrInstitutionDetails);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrInstitutionResult;
        echo json_encode($data);
    }
    
    function excel_export_interactions($arrData) {
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        //        $interactionIds = $this->input->post("exportIds");
        //        $arrData = $this->list_interactions(true, $_POST);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        
        //		pr($_POST);
        //		exit;
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        $objWorksheet->setTitle('Interactions');
        //Add header
        
        // 		$objWorksheet->setCellValue('A1', 'Active?')
        $objWorksheet->setCellValue('A1', 'User Name')
        ->setCellValue('B1', 'Division')
        ->setCellValue('C1', 'Interaction ID')
        ->setCellValue('D1', 'Interaction Category')
        ->setCellValue('E1', 'Interaction Type')
        // 						->setCellValue('F1', 'Speaker')
        // 						->setCellValue('G1', 'KTL Degree')
        ->setCellValue('F1', 'KTL / Org Name')
        ->setCellValue('G1', 'Discussion Type')
        ->setCellValue('H1', 'Interaction Topic')
        ->setCellValue('I1', lang("Overview.Product"))
        ->setCellValue('J1', '# Attendees')
        ->setCellValue('K1', 'Interaction Date');
        
        $i = 2;
        foreach ($arrData as $row) {
            // 				$objWorksheet->setCellValue('A'.$i, $row['is_activated'])
            $objWorksheet->setCellValue('A'.$i, $row['msl_name'])
            ->setCellValue('B'.$i, $row['interaction_group_name'])
            ->setCellValue('C'.$i, $row['exp_interaction_generic_id'])
            ->setCellValue('D'.$i, $row['interaction_category'])
            ->setCellValue('E'.$i, $row['interaction_channel'])
            // 							->setCellValue('G'.$i, $row['interaction_speaker'])
            // 							->setCellValue('H'.$i, $row['interaction_kol_degree'])
            ->setCellValue('F'.$i, $row['profile_name'])
            ->setCellValue('G'.$i, $row['interaction_type'])
            ->setCellValue('H'.$i, $row['interaction_topic'])
            ->setCellValue('I'.$i, $row['interaction_product'])
            ->setCellValue('J'.$i, $row['attendees'])
            ->setCellValue('K'.$i, date("m/d/Y",strtotime($row['interaction_date'])));
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'K') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:K1')->applyFromArray($arrStyles);
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $fileName = "interactions_".date("m-d-Y");
        if(IS_IPAD_REQUEST){
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xlsx";
            $objWriter->save($path);
            return $path;
        }else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function excel_export_by_different_categories($arrInteractionsResults, $arrFilters) {
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $userdata = $arrInteractionsResults['userdata'];
        unset($arrInteractionsResults['userdata']);
        $arrInteractionsData = $arrInteractionsResults;
        $arrMonths = array("", "JAN", "FEB", "MAR", "APR", "MAY", "JUNE", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC");
        //    	pr($arrInteractionsData);
        //    	pr($userdata);
        //    	exit;
        $fileName = '';
        $reportType = $arrFilters['report_type'];
        switch ($reportType) {
            case '1':
                //New Worksheet
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "D";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $key => $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'D';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category')
                ->setCellValue($alphabet++ . '2', 'Interaction Type');
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_channel']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Interaction_Type";
                break;
            case '2':
                //New Worksheet
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "D";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'D';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category')
                ->setCellValue($alphabet++ . '2', lang("Overview.Product"));
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_product']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Product";
                break;
            case '3':
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "C";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'C';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category');
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Category";
                break;
            case '4':
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "D";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'D';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category')
                ->setCellValue($alphabet++ . '2', 'Discussion Type');
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_type']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Discussion_Type";
                break;
            case '5':
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "D";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'D';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category')
                ->setCellValue($alphabet++ . '2', 'Discussion Topic');
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_topic']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Topic";
                break;
            case '6':
                $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
                $objWorksheet->setTitle('Interactions');
                //Add header
                $alphabet = "F";
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                        $objWorksheet->setCellValue($alphabet++ . '1', $arrMonths[$month] . "-" . $year);
                    }
                }
                $mergeCellStartsWith = 'F';
                $alphabet = "A";
                $objWorksheet->setCellValue($alphabet++ . '2', 'Division')
                ->setCellValue($alphabet++ . '2', 'Interaction Category')
                ->setCellValue($alphabet++ . '2', 'Discussion Type')
                ->setCellValue($alphabet++ . '2', 'Discussion Topic')
                ->setCellValue($alphabet++ . '2', 'Interaction Sub Topic');
                foreach ($userdata as $year => $months) {
                    foreach ($months as $month) {
                        $objWorksheet->setCellValue($alphabet++ . '2', '# Interactions');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count');
                        $objWorksheet->setCellValue($alphabet++ . '2', 'Attendee Count Provided by User');
                    }
                }
                $i = 3;
                foreach ($arrInteractionsData as $row) {
                    $alphabet = "A";
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['team_name']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_category']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_type']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_topic']);
                    $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['interaction_sub_topic']);
                    foreach ($userdata as $year => $months) {
                        foreach ($months as $month) {
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ic' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_iac' . $year]);
                            $objWorksheet->setCellValue($alphabet++ . "" . $i, $row['m' . $month . '_ac' . $year]);
                        }
                    }
                    $i++;
                }
                $fileName = "Interactions_Monthly_By_Sub_Topic";
                break;
        }
        
        $objPHPExcel->addSheet($objWorksheet);
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            //				foreach(range('A',$alphabet) as $columnID) {
            //				    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            //				}
            $a = 'A';
            while ($a != $alphabet) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($a)->setWidth(30);
                $lastCol = $a;
                $a++;
            }
            $objPHPExcel->getActiveSheet()->getStyle("A1:" . $alphabet . "1")->applyFromArray(array('font' => array('bold' => true, 'italic' => false)));
            $objPHPExcel->getActiveSheet()->getStyle("A2:" . $lastCol . "2")->applyFromArray($arrStyles);
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $alphabet = $mergeCellStartsWith;
        $style = array(
            'alignment' => array(
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            )
        );
        foreach ($userdata as $year => $months) {
            foreach ($months as $key => $month) {
                $first = $alphabet++;
                $alphabet++;
                $last = $alphabet++;
                $objPHPExcel->setActiveSheetIndex(0)->mergeCells($first . '1:' . $last . '1');
                $objPHPExcel->getActiveSheet()->getStyle($first . '1:' . $last . '1')->applyFromArray($style);
            }
        }
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        
        $fileName = $fileName."_".date("m-d-Y_His");
        if(IS_IPAD_REQUEST){
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xlsx";
            $objWriter->save($path);
            return $path;
        }else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function get_target_kols() {
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
        $arrCustomerDetails = $this->report->getkolDetails($arrParams);
        foreach ($arrCustomerDetails as $row) {
            $arrCustomerResult[] = $row;
        }
        $count = sizeof($arrCustomerDetails);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCustomerResult;
        echo json_encode($data);
    }
    
    
    function get_target_org() {
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrParams = $_POST;
        $arrInstitutionDetails = $this->report->getOrgDetails($arrParams);
        foreach ($arrInstitutionDetails as $row) {
            $arrInstitutionResult[] = $row;
        }
        $count = sizeof($arrInstitutionResult);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrInstitutionResult;
        echo json_encode($data);
    }
    
    
    function export_uoq() {
        
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('list_mirf');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arr1 = (array) json_decode($arrFilters);
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        //        $arrFilters = str_replace(";", "", $arrFilters);
        //        parse_str($arrFilters, $params);
        
        $objPHPExcel = new PHPExcel();
        $fileName="UOQ Report";
        $arrExcelData = array();
        $arrKolDetails[] = $this->interaction->listMirf($arr1, $Details);
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('UOQ Report');
        //Add header
        $objWorksheet->setCellValue('A1', 'Date of Request')
        ->setCellValue('B1', 'Product Name')
        ->setCellValue('C1', 'KTL Name')
        ->setCellValue('D1', 'Institution')
        ->setCellValue('E1', 'City')
        ->setCellValue('F1', 'State')
        ->setCellValue('G1', 'Zip Code')
        ->setCellValue('H1', 'Interaction Id')
        ->setCellValue('I1', 'UOQ Id')
        ->setCellValue('J1', 'MSL Name');
        $i = 2;
        
        foreach ($arrKolDetails[0] as $rows) {
            // pr($rows['first'][0]['is_single_use_vial']);
            $firstproductnames='';
            $productnames='';
            if($rows['first'][0]['is_single_use_vial']==1)
                $firstproductnames .=' Abilify Maintena: Single-Use Vial ';
                if($rows['first'][0]['is_dual_chamber_syringe']==1)
                    $firstproductnames .='Abilify Maintena: Dual Chamber Syringe ';
                    if($rows['first'][0]['is_non_kit_specific_enquiry']==1)
                        $firstproductnames .='Abilify Maintena: Non-kit Specific Inquiry ';
                        
                        
                        foreach ($rows['prod'] as $key1 => $value1) {
                            if (in_array("PsychU", $value1) || in_array("Abilify Maintena", $value1)) {
                                //                $productnames .=$value1['other_product_name'];
                            } else {
                                if($value1['name']!="")
                                    
                                    $productnames .=$value1['name'] . ", ";
                                    $productnames .=$value1['other_product_name'];
                            }
                        }
                        
                        $productnames.=$firstproductnames;
                        $objWorksheet->setCellValue('A' . $i, $rows['date_of_request'])
                        ->setCellValue('B' . $i, $productnames)
                        ->setCellValue('C' . $i, $rows['kol_id'])
                        ->setCellValue('D' . $i, $rows['institution'])
                        ->setCellValue('E' . $i, $rows['city'])
                        ->setCellValue('F' . $i, $rows['state'])
                        ->setCellValue('G' . $i, $rows['zip_code'])
                        ->setCellValue('H' . $i, $rows['interactionGeneric'])
                        ->setCellValue('I' . $i, $rows['generic_id'])
                        ->setCellValue('J' . $i, $rows['client_id']);
                        $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'J') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="uoq_report.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function customer_seen_kol_export(){
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('customer_seen_kol');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        $Details['isexcel']=1;
        $arrFilters = str_replace(";", "", $arrFilters);
        parse_str($arrFilters, $params);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $arrKolDetails[] = $this->report->getkolDetails($arrFilters,$Details);
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Customer Seen');
        //Add header
        $fileName="Customer Seen kol";
        $objWorksheet->setCellValue('A1', 'KTL Name')
        ->setCellValue('B1', 'Specialty')
        ->setCellValue('C1', 'State')
        ->setCellValue('D1', 'City')
        ->setCellValue('E1', 'Phone');
        $i = 2;
        foreach ($arrKolDetails[0] as $rows) {
            
            $objWorksheet->setCellValue('A' . $i, $rows['kolname'])
            ->setCellValue('B' . $i, $rows['specialty_name'])
            ->setCellValue('C' . $i, $rows['Region'])
            ->setCellValue('D' . $i, $rows['City'])
            ->setCellValue('E' . $i, $rows['primary_phone']);
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'E') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="customer seen ktl.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function customer_seen_export(){
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('customer_seen');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        $Details['isexcel']=1;
        $arrFilters = str_replace(";", "", $arrFilters);
        parse_str($arrFilters, $params);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $arrKolDetails[] = $this->report->listCustomerSeenReport($arrFilters,$Details);
        //New Worksheet
        $fileName = 'Customer Seen';
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Customer Seen');
        //Add header
        $objWorksheet->setCellValue('A1', 'MSL Name')
        ->setCellValue('B1', 'Team Name')
        ->setCellValue('C1', 'OverAll Seen')
        ->setCellValue('D1', 'Target')
        ->setCellValue('E1', 'Seen')
        ->setCellValue('F1', 'Not Seen')
        ->setCellValue('G1', 'One-Off');
        $i = 2;
        foreach ($arrKolDetails[0] as $rows) {
            if($rows['overAllSeenTarget'] == '0')
                $rows['overAllSeenTarget'] = "";
                if($rows['target'] == '0')
                    $rows['target'] = "";
                    if($rows['targetseen'] == '0')
                        $rows['targetseen'] = "";
                        if($rows['notseen'] == '0')
                            $rows['notseen'] = "";
                            if($rows['OneOff'] == '0')
                                $rows['OneOff'] = "";
                                $objWorksheet->setCellValue('A' . $i, $rows['first_name']." ".$rows['last_name'])
                                ->setCellValue('B' . $i, $rows['group_name'])
                                ->setCellValue('C' . $i, $rows['overAllSeenTarget'])
                                ->setCellValue('D' . $i, $rows['target'])
                                ->setCellValue('E' . $i, $rows['targetseen'])
                                ->setCellValue('F' . $i, $rows['notseen'])
                                ->setCellValue('G' . $i, $rows['OneOff']);
                                $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'G') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="customer seen.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function institution_seen_export(){
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('institution_seen');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        $Details['isexcel']=1;
        $arrFilters = str_replace(";", "", $arrFilters);
        parse_str($arrFilters, $params);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $arrKolDetails[] = $this->report->listInstitutionSeenReport($arrFilters,$Details);
        //New Worksheet
        $fileName = 'Institution Seen';
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Institution Seen');
        //Add header
        $objWorksheet->setCellValue('A1', 'MSL Name')
        ->setCellValue('B1', 'Team Name')
        ->setCellValue('C1', 'OverAll Seen')
        ->setCellValue('D1', 'Target')
        ->setCellValue('E1', 'Seen')
        ->setCellValue('F1', 'Not Seen')
        ->setCellValue('G1', 'One-Off');
        $i = 2;
        foreach ($arrKolDetails[0] as $rows) {
            if($rows['overAllSeenTarget'] == '0')
                $rows['overAllSeenTarget'] = "";
                if($rows['target'] == '0')
                    $rows['target'] = "";
                    if($rows['targetseen'] == '0')
                        $rows['targetseen'] = "";
                        if($rows['notseen'] == '0')
                            $rows['notseen'] = "";
                            if($rows['OneOff'] == '0')
                                $rows['OneOff'] = "";
                                $objWorksheet->setCellValue('A' . $i, $rows['first_name']." ".$rows['last_name'])
                                ->setCellValue('B' . $i, $rows['group_name'])
                                ->setCellValue('C' . $i, $rows['overAllSeenTarget'])
                                ->setCellValue('D' . $i, $rows['target'])
                                ->setCellValue('E' . $i, $rows['targetseen'])
                                ->setCellValue('F' . $i, $rows['notseen'])
                                ->setCellValue('G' . $i, $rows['OneOff']);
                                $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'F') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="institution seen.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function institution_seen_export_org(){
        
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('institution_seen_org');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        $Details['isexcel']=1;
        $arrFilters = str_replace(";", "", $arrFilters);
        parse_str($arrFilters, $params);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $arrKolDetails[] = $this->report->getOrgDetails($arrFilters,$Details);
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Insitution Seen');
        //Add header
        $fileName="Insitution Seen Organization";
        $objWorksheet->setCellValue('A1', 'Institution Name')
        ->setCellValue('B1', 'Specialty')
        ->setCellValue('C1', 'State')
        ->setCellValue('D1', 'City')
        ->setCellValue('E1', 'Phone');
        $i = 2;
        foreach ($arrKolDetails[0] as $rows) {
            
            $objWorksheet->setCellValue('A' . $i, $rows['name'])
            ->setCellValue('B' . $i, $rows['specialty_name'])
            ->setCellValue('C' . $i, $rows['Region'])
            ->setCellValue('D' . $i, $rows['City'])
            ->setCellValue('E' . $i, $rows['phone']);
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'E') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="institution seen organization.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    function msl_export(){
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        
        $id = $this->input->post('msl_activity');
        $id = explode(',', $id);
        $arrFilters = $this->input->post('filter');
        $arrFilters = stripslashes($arrFilters);
        $arrFilters = str_replace('"{', '{', $arrFilters);
        $arrFilters = str_replace('}"', '}', $arrFilters);
        $arrFilters = trim($arrFilters, '"');
        $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
        $field = 'field';
        $op = 'op';
        $data = 'data';
        $groupOp = 'groupOp';
        $arrFilter = $arrFilters['filters'];
        if (isset($arrFilters['filters'])) {
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $Details = array();
            foreach ($searchField as $key => $val) {
                $Details[$val] = $searchString[$key];
            }
        }
        $arrFilters = str_replace(";", "", $arrFilters);
        parse_str($arrFilters, $params);
        $objPHPExcel = new PHPExcel();
        $arrExcelData = array();
        $arrKolDetails[] = $this->report->getMSLActivityReportData($limit, $start, false, $sidx, $sord,$Details,$arrFilters);
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('MSL Activity');
        $fileName = 'MSL Activity';
        //Add header
        $objWorksheet->setCellValue('A1', 'MSL Name')
        ->setCellValue('B1', 'Interactions')
        ->setCellValue('C1', 'UOQ')
        ->setCellValue('D1', 'Medical Insight')
        ->setCellValue('E1', 'Speaker Evaluation')
        ->setCellValue('F1', 'Sphere of Influence');
        $i = 2;
        foreach ($arrKolDetails[0] as $rows) {
            
            $objWorksheet->setCellValue('A' . $i, $rows['first_name']." ".$rows['last_name'])
            ->setCellValue('B' . $i, $rows['intc'])
            ->setCellValue('C' . $i, $rows['mic'])
            ->setCellValue('D' . $i, $rows['uoq'])
            ->setCellValue('E' . $i, $rows['speaker_eval'])
            ->setCellValue('F' . $i, $rows['survey']);
            $i++;
        }
        $objPHPExcel->addSheet($objWorksheet);
        
        
        
        
        // remove first sheet
        
        $styleArray = array(
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array('argb' => '0000000'),
                ),
            ),
        );
        
        $arrStyles = array(
            'font' => array(
                'bold' => true,
                'italic' => false
            ),
            'borders' => array(
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THICK,
                    'color' => array(
                        'rgb' => '000000'
                    )
                ),
                'quotePrefix' => true
            )
        );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
        foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
            $exportOpts = array(strtolower($sheet->getTitle()));
            //if(in_array('professional',$exportOpts)){
            $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
            foreach (range('A', 'F') as $columnID) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
            //  }
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if(IS_IPAD_REQUEST){
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
            $objWriter->save($path);
            return $path;
        }
        else{
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="msl activity.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
        }
    }
    
    function send_excel_as_email(){
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        // $this->email->to("shrutip@aissel.com");
        $loggedInUserName = $this->session->userdata('user_full_name');
        
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody = 'Hi  ' . $loggedInUserName . ', <br/><br/> Attached is the export of Interactions report data from '.PRODUCT_NAME;
        
        $loggedInUserEmail = $this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.":Interactions");
        
        $export_method = $this->input->post("export_method");
        if($export_method == 'interactions')
            $path = $this->list_interactions(1);
            else if($export_method == 'interactions_by_category')
                $path = $this->list_interactions();
                
                
                $this->email->attach($path);
                $this->email->set_crlf("\r\n");
                if ($this->email->send()) {
                    $emailData['status'] = 'Excel has been mailed successfully';
                    unlink($path);
                } else {
                    $emailData['status'] = 'Mail not sent';
                }
                echo $emailData['status'];
    }
    
    function send_email_for_export_medical_report() {
        $currentMethod = $this->uri->segment(3);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        //        $this->email->to("shrutip@aissel.com");
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody='Hi  ' .$loggedInUserName . ', <br/><br/> Attached is the export of Medical Insight report data from '.PRODUCT_NAME;
        $loggedInUserEmail=$this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.":Medical Insight Report");
        $path = $this->export_kol_new();
        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
            link($path);
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email Sent',
                'status' => 'success',
                'transaction_id' =>'' ,
                'transaction_table_id' => '',
                'transaction_name' => "Email",
                'module'=>'send_email_for_export_medical_report',
                'parent_object_id'=>'',
                'user_id'=>$loggedInUserName,
                
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            
            log_user_activity($arrLogDetails, true);
            
        } else {
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email failed',
                'status' => 'failed',
                'transaction_id' =>'' ,
                'transaction_table_id' => '',
                'transaction_name' => "Email",
                'module'=>'send_email_for_export_medical_report',
                'parent_object_id'=>'',
                'user_id'=>$loggedInUserName,
                
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            
            log_user_activity($arrLogDetails, true);
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
    }
    
    function send_email_for_export_reports($content) {
        $currentMethod = $this->uri->segment(3);
        $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
        //        $this->email->to("shrutip@aissel.com");
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody='Hi  ' .$loggedInUserName . ', <br/><br/> Attached is the export of '.$content.' report data from '.PRODUCT_NAME;
        $loggedInUserEmail=$this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.":".$content." Report");
        if($content=="Customer_Seen"){
            $path = $this->customer_seen_export();
        }
        if($content=="Customer_Seen_kol"){
            $path = $this->customer_seen_kol_export();
        }
        if($content=="Institution_Seen"){
            $path = $this->institution_seen_export();
        }
        if($content=="Institution_Seen_Org"){
            $path = $this->institution_seen_export_org();
        }
        if($content=="MSL_Activity"){
            $path = $this->msl_export();
        }
        if($content=="User_Access"){
            $path = $this->login->export_analytic_detail("client");
        }
        if($content=="UOQ"){
            $path = $this->export_uoq();
        }
        $this->email->attach($path);
        $this->email->set_crlf("\r\n");
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
            unlink($path);
            link($path);
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email Sent',
                'status' => 'success',
                'transaction_id' =>'' ,
                'transaction_table_id' => '',
                'transaction_name' => "Email",
                'module'=>'send_email_for_export_reports',
                'parent_object_id'=>'',
                'user_id'=>$loggedInUserName,
                
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            
            log_user_activity($arrLogDetails, true);
            
        } else {
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                'type' => LOG_UPDATE,
                'description' => 'Email failed',
                'status' => 'failed',
                'transaction_id' =>'' ,
                'transaction_table_id' => '',
                'transaction_name' => "Email",
                'module'=>'send_email_for_export_reports',
                'parent_object_id'=>'',
                'user_id'=>$loggedInUserName,
                
                'form_data' => $formData
            );
            $this->config->set_item('log_details', $arrLogDetails);
            
            log_user_activity($arrLogDetails, true);
            $emailData['status'] = 'Mail not sent';
        }
        echo $emailData['status'];
    }
    
    public function view_engagement_reports(){
        $data['filterPage'] = 'reports/engagement_filter_li_style';
        $managerId = $this->session->userdata('user_id');
        $data['arrTeam'] = $this->interaction->getTeamForMirf();
        $data['arrClientUsers'] = $this->coaching->getClientUser();
        ;
        //                 pr($data['arrClientUsers']);
        $data['arrEngagementManager'] = $this->common_helpers->getAllManagersForReports($managerId);//new
        $data['arrSpecialties'] = $this->coaching->getAllAreas();
        $data['arrEngagement'] = $this->coaching->getAllEngagement();
        $data['contentPage'] = 'reports/view_engagement_report';
        if(IS_IPAD_REQUEST){
            $data['enableRefineBySection'] = true;
            //            $data['filterPage'] = 'reports/medical_insight_filter_li';
            $data['data']['filterPage'] = 'reports/engagement_filter_li_style';
            $this->load->view(IPAD_APP_FOLDER . '/layouts/bootstrap_layout', $data);
        }else{
            $data['filterPage'] = 'reports/engagement_filter_li_style';
            $this->load->view('layouts/client_view', $data);
        }
    }
    
    
    function list_engagement_report_grid() {
        //         $this->output->enable_profiler(TRUE);
        $filters = $_POST;
        //        pr($filters);
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrCoachingResult = $this->customer_engagement->listEngagementReport($filters);
        $count = sizeof($arrCoachingResult);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCoachingResult;
        echo json_encode($data);
    }
    
    function export_customer_report() {
        
        //		error_reporting(E_ALL);
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        //		$exportOpts		= $this->input->post('export_opts');
        $coachingIds = $this->input->post('coaching');
        $filters = $this->input->post('filter');
        $arrFilters = str_replace(";", "", $filters);
        parse_str($arrFilters, $params);
        
        $arrCoachingIds = explode(',', $coachingIds);
        // Get PIN
        //		$kolArray	=	$this->kol->getKolsIdAndPin();
        // Get the list of Specialties
        //		$this->load->model('Specialty');
        //		$arrSpecialties	=	$this->Specialty->getAllSpecialties();
        //		$exportOpts = array();
        //		$exportOpts[] = "professional";
        //		$exportOpts[] = "contact";
        //		$exportOpts[] = "biography";
        //		$exportOpts[] = "education";
        //		$exportOpts[] = "affiliation";
        //		$exportOpts[] = "event";
        //		$exportOpts[] = "publication";
        //		$exportOpts[] = "trial";
        //		$exportOpts[] = "media";
        //		pr($exportOpts);
        //		exit;
        //		$clientId = $this->session->userdata('client_id');
        
        $objPHPExcel = new PHPExcel();
        //		$objPHPExcel->setActiveSheetIndex(0);
        //		$arrKolIds = array(2016,1619,1976,264,2018);
        $arrExcelData = array();
        
        $arrCoachingDetails = $this->customer_engagement->exportCustomerReport($arrCoachingIds, $params);
        
        
        
        
        //		foreach ($arrKolIds as $kolsId){
        //			$arrKolDetails	=	$this->kol->getKolDetailsById($kolId);
        //			if(in_array('professional', $exportOpts)){
        //New Worksheet
        $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
        //				$objWorksheet = $objPHPExcel->getActiveSheet();
        $objWorksheet->setTitle('Coaching Report');
        //Add header
        $objWorksheet->setCellValue('A1', 'MSL NAME')
        ->setCellValue('B1', 'Count')
        ->setCellValue('C1', 'Evaluated By')
        ->setCellValue('D1', 'Engagement Type');
        
        //								->setCellValue('E1', 'Topics')
        //								->setCellValue('F1', 'Sphere of Influence')
        //								->setCellValue('G1', 'Summarize Medical Insight')
        //								->setCellValue('H1', 'Describe Relevance to OPDCI')
        //								->setCellValue('I1', 'Actions to consider')
        //								->setCellValue('J1', 'Recorded By');
        //
        //				if($clientId==INTERNAL_CLIENT_ID){
        //					$objWorksheet->setCellValue('P1', 'Url');
        //				}
            $i = 2;
            
            //					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
            foreach ($arrCoachingDetails as $row) {
                
                $objWorksheet->setCellValue('A' . $i, $row['username'])
                ->setCellValue('B' . $i, preg_replace('/<\/?a[^>]*>/', '', $row['entry_count']))
                ->setCellValue('C' . $i, $row['evaluated_by'])
                ->setCellValue('D' . $i, $row['interaction_type'])
                ;
                //									->setCellValue('E'.$i, $row['topics'])
                //									->setCellValue('F'.$i, $row['sphere_of_influence'])
                //									->setCellValue('G'.$i, $row['summary'])
                //									->setCellValue('H'.$i, $row['relevance'])
                //									->setCellValue('I'.$i, $row['actions_to_consider'])
                //									->setCellValue('J'.$i, $row['created_user']);
                //						if($clientId==INTERNAL_CLIENT_ID){
                //							$objWorksheet->setCellValue('P'.$i, $row['url']);
                //						}
                $i++;
            }
            
            $objPHPExcel->addSheet($objWorksheet);
            //			}
            // remove first sheet
            
            $styleArray = array(
                'borders' => array(
                    'bottom' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THICK,
                        'color' => array('argb' => '0000000'),
                    ),
                ),
            );
            
            $arrStyles = array(
                'font' => array(
                    'bold' => true,
                    'italic' => false
                ),
                'borders' => array(
                    'bottom' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THICK,
                        'color' => array(
                            'rgb' => '000000'
                        )
                    ),
                    'quotePrefix' => true
                )
            );
            // remove first sheet
            $objPHPExcel->removeSheetByIndex(0);
            // iterate each sheet and add the style for each sheet
            foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
                $exportOpts = array(strtolower($sheet->getTitle()));
                //if(in_array('professional',$exportOpts)){
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range('A', 'D') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                    //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($arrStyles);
                //  }
            }
            $objPHPExcel->setActiveSheetIndex(0);
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="Coaching Report.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
    }
    
    
    function grid_filter(){
        $userId=$this->input->post('user_id');
        $interactionType=$this->input->post('interaction_type');
        $from=$this->input->post('from');
        $to=$this->input->post('to');
        
        $filters = $_POST;
        //        pr($filters);
        $page = $_REQUEST['page'];
        $limit = $_REQUEST['rows'];
        $arrCoachingResult =  $this->customer_engagement->listEngagementFilterdGrid($userId,$interactionType,$from,$to);
        $count = sizeof($arrCoachingResult);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrCoachingResult;
        echo json_encode($data);
    }
    
    function pmmc_score_chart(){
        $data['meshTermCategories'] = $_POST['a'];
        $data['meshTermData'] = $_POST['b'];
        $this->load->view('reports/pmmc_score_chart',$data);
    }
    function psc_score_chart(){
        $data['substancesCategories'] = $_POST['a'];
        $data['substancesData'] = $_POST['b'];
        $this->load->view('reports/psc_score_chart',$data);
    }
    function pjc_score_chart(){
        $data['journalsCategories'] = $_POST['a'];
        $data['journalsData'] = $_POST['b'];
        $this->load->view('reports/pjc_score_chart',$data);
    }
    function pt_score_chart(){
        $data['journalsCategories'] = $_POST['a'];
        $data['journalsData'] = $_POST['b'];
        $this->load->view('reports/pt_score_chart',$data);
    }
    function pka_score_chart(){
        $data['journalsCategories'] = $_POST['a'];
        $data['journalsData'] = $_POST['b'];
        $this->load->view('reports/pka_score_chart',$data);
    }
    function cafco_score_chart(){
        $data['categories'] = $_POST['a'];
        $data['data'] = $_POST['b'];
        $this->load->view('reports/cafco_score_chart',$data);
    }
    
    
    // Kol co-authors network map
    function get_kol_co_auth($id, $fromYear, $toYear){
        
        $kolName = $this->kol->getKolName($id);
        $arrKolName = $this->kol->getKolName($id);
        
        $firstName	= trim($arrKolName['first_name'],".");
        $middleName	= trim($arrKolName['middle_name'],".");
        $lastName	= trim($arrKolName['last_name'],".");
        
        $fullName	= $firstName;
        if(!empty($middleName))
            $fullName	.= ' '. $middleName;
            if(!empty($lastName))
                $fullName	.= ' '. $lastName;
                
                
                $keyWord = $this->input->post('keyWord');
                
                $this->session->set_userdata('kolKeyWords',$keyWord);
                $keyWord = $this->session->userdata('kolKeyWords');
                
                $arrAuth=$this->kol->getKolCoAuthFreqency($id, $fromYear, $toYear,$arrKolName,null,$keyWord);
                //		echo $this->db->last_query();
                $nodeData=array();
                $nodeData['$lineWidth']= 5;
                $nodeData['$color']="#ddeeff";
                $nodeData['$dim']= 0;
                $influenceData=array();
                $centerNode = array();
                $influenceData['id']='kol-'.$id;
                $influenceData['name']=$fullName;
                $influenceData['data']=$nodeData;
                $influenceData['children'] = array();
                $x=1;
                foreach($arrAuth as $key => $row){
                    $authorName = '';
                    //based on the name avilability, construct a proper name
                    if($row['last_name']!='' && $row['fore_name']!='')
                        $authorName =$row['last_name']." ".$row['fore_name'];
                        else if($row['fore_name']=='')
                            $authorName =$row['last_name']." ".$row['initials'];
                            else if($row['last_name']=='')
                                $authorName =$row['fore_name']." ".$row['initials'];
                                
                                $names = array();
                                $count = array();
                                $arrIds = array();
                                if($authorName != $fullName){
                                    $name = $authorName;
                                    $count1 = (int)$row['count'];
                                    $arrId = $row['id'];
                                    $nodeData =array();
                                    $nodeData['$color']="#555555";
                                    $nodeData['connections']=$count1;
                                    $nodeDetails=array();
                                    $nodeDetails['id']= $x."_".$arrId;
                                    //				$nodeDetails['pmid']=$arrId;
                                    $nodeDetails['name']=$name."(".$count1.")";
                                    $nodeDetails['data']=$nodeData;
                                    $arrAdjecencies=array();
                                    $nodeDetails['children']=$arrAdjecencies;
                                    $influenceData['children'][]=$nodeDetails;
                                }
                                if($authorName != $fullName){
                                    $names[] = $authorName;
                                    $count[]=(int)$row['count'];
                                    $arrIds[]=$row['id'];
                                }
                                $x++;
                }
                $retunData['connectionData'] = $influenceData;
                //		$retunData['coAuthorsKOLIds'] = array();
                $data[]=$names;
                $data[]=$count;
                $data[]=$arrIds;
                $data['influenceData'] = $retunData;
                echo json_encode($data);
                //		pr($data);
    }
    
    function get_user_analytics($from_export=false, $exportFilters=NULL){
        $client_id	= $this->session->userdata('client_id');
        
        if($from_export==true){
            $page = $exportFilters['page']; // get the requested page
            $limit = $exportFilters['rows']; // get how many rows we want
            $sidx = $exportFilters['sidx']; // get index row - i.e. user click to sort
            $sord = $exportFilters['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrFilter = array();
                $arrFilters['end_date'] = $exportFilters['ed'];
                $arrFilters['start_date'] = $exportFilters['sd'];
                $arrDivision = $exportFilters['division_id'];
                $arrManager = $exportFilters['manager_id'];
                
                if($exportFilters['filters']){
                	$arrFilter = array();
                	$arrFilter = $exportFilters['filters'];
                	$field = 'field';
                	$op = 'op';
                	$data = 'data';
                	$groupOp = 'groupOp';
                	$searchGroupOperator = $this->common_helpers->search_nested_arrays ($arrFilter, $groupOp);
                	$searchString = $this->common_helpers->search_nested_arrays ($arrFilter, $data);
                	$searchOper = $this->common_helpers->search_nested_arrays ($arrFilter, $op);
                	$searchField = $this->common_helpers->search_nested_arrays ($arrFilter, $field);
                	$whereResultArray = array();
                	foreach ($searchField as $key => $val) {
                		$whereResultArray[$val] = $searchString[$key];
                	}
                } 
        }else{
            $page = $_REQUEST['page']; // get the requested page
            $limit = $_REQUEST['rows']; // get how many rows we want
            $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
            $sord = $_REQUEST['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrFilter = array();
                $arrFilters['end_date'] = $this->input->post('ed');
                $arrFilters['start_date'] = $this->input->post('sd');
                $arrDivision = $this->input->post('division_id');
                $arrManager = $this->input->post('manager_id');
        }
        
        if($arrFilters['end_date'] != '')
            $arrFilters['end_date'] = date("Y-m-d",strtotime("+1 day", strtotime($arrFilters['end_date'])));
            
        if($arrFilters['start_date'] != '')
            $arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
                
        if($arrDivision != 'null' && !empty($arrDivision)){
            if(!is_array($arrDivision)){
                 $arrDivision = explode(",", $arrDivision);
               }
          }
                
        if($arrManager != 'null' && !empty($arrManager)){
            if(!is_array($arrManager)){
                 $arrManager = explode(",", $arrManager);
               }
         }
                
        $arrFilters['division_id'] = $arrDivision;
        $arrFilters['manager_id'] = $arrManager;
                
                $arrUserDetails = $this->report->getAllUsersOfClient($client_id, $arrFilters, $limit = '', $start, $sidx, $sord, $whereResultArray);
                foreach($arrUserDetails as $row){
                    $arrUserData['id'] = $row['id'];
                    $arrUserData['user_name'] = $row['primary_user_name'];
                    $arrUserData['manager'] = $row['secondary_level_user'];
                    $arrUserData['division'] = $row['GlobalRegion'];
                    $created_on = $row['created_on'];
                    $arrUserData['registered'] = ($created_on=='0000-00-00 00:00:00')?NULL:$this->common_helpers->convertDateToMM_DD_YYYY($created_on);
                    $status = $row['status'];
                    if($status > 0){
                    	$arrUserData['user_status'] = 'No';
                    }else{
                    	$arrUserData['user_status'] = 'Yes';
                    }
                    $login_count = $this->report->userTotalLoginCount($row['id'], $arrFilters);
                    if($login_count == 0){
                    	$last_access = NULL;
                    }else{
                    	$last_access = (empty($row['user_last_login']))?NULL:$this->common_helpers->convertDateToMM_DD_YYYY($row['user_last_login']);
                    }
                    $arrUserData['last_access'] = $last_access;
                    $arrUserData['login_count'] = $login_count;
                    $arrUserData['kol_access'] = $this->report->userTotalKolAccess($row['id'], $arrFilters, true);
                    $arrUserData['num_payments'] = $this->report->userTotalPaymentCreated($row['id'], $arrFilters);
                    $arrUserData['num_interactions'] = $this->report->userTotalInteractionCreated($row['id'], $arrFilters);
                    $arrUserData['num_contracts'] = $this->report->userTotalContractsCreated($row['id'], $arrFilters);
                    $arrUserData['num_plans'] = $this->report->userTotalPlansCreated($row['id'], $arrFilters);
                    $arrUserAnalyticsCounts[] = $arrUserData;
                }
                if($from_export==true){
                    return $arrUserAnalyticsCounts;
                }else{
                    $count = sizeof($arrUserAnalyticsCounts);
                    $limit = $_REQUEST['rows'];
                    if ($count > 0) {
                        $total_pages = ceil($count / $limit);
                    } else {
                        $total_pages = 0;
                    }
                    //             pr($arrKolsActivityCounts);exit;
                    $data['records'] = $count;
                    $data['total'] = $total_pages;
                    $data['page'] = $page;
                    $data['rows'] = $arrUserAnalyticsCounts;
                    ob_start('ob_gzhandler');
                    echo json_encode($data);
                }
    }
    function get_ktl_accessed_user_analytics(){
    	$page = $_REQUEST['page']; // get the requested page
    	$limit = $_REQUEST['rows']; // get how many rows we want
    	$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
    	$sord = $_REQUEST['sord']; // get the direction
    	if (!$sidx)
    		$sidx = 1;
    	

    	$user_id = $this->input->post('user_id');
    	$arrFilter = array();
    	$arrFilters['end_date'] = $this->input->post('ed');
    	$arrFilters['start_date'] = $this->input->post('sd');
    	$arrDivision = $this->input->post('division_id');
    	$arrManager = $this->input->post('manager_id');
    	
    	if($arrFilters['end_date'] != '')
    		$arrFilters['end_date'] = date("Y-m-d",strtotime("+1 day", strtotime($arrFilters['end_date'])));
    	
    	if($arrFilters['start_date'] != '')
    		$arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
    	
    	if($arrDivision != 'null' && !empty($arrDivision)){
    		if(!is_array($arrDivision)){
    			$arrDivision = explode(",", $arrDivision);
    		}
    	}
    	
    	if($arrManager != 'null' && !empty($arrManager)){
    		if(!is_array($arrManager)){
    			$arrManager = explode(",", $arrManager);
    		}
    	}
    	
    	$arrFilters['division_id'] = $arrDivision;
    	$arrFilters['manager_id'] = $arrManager;
    			
    	$arrKtlAccessUserDetails = $this->report->userTotalKolAccess($user_id, $arrFilters, false);
    	foreach($arrKtlAccessUserDetails as $row){
    		$arrKtlAccessUserData['id'] = $row->kolId;
    		$arrKtlAccessUserData['kol_name'] = $row->kol_name;
    		$arrKtlAccessUserData['specialty'] = $row->specialty;
    		$arrKtlAccessUserData['country'] = $row->Country;
    		$arrKtlAccessUserAnalyticsCounts[] = $arrKtlAccessUserData;
    	}
    	$count = sizeof($arrKtlAccessUserAnalyticsCounts);
    	//$limit = $_REQUEST['rows'];
    	if ($count > 0) {
    		$total_pages = ceil($count / $limit);
    	} else {
    		$total_pages = 0;
    	}
    	//             pr($arrKolsActivityCounts);exit;
    	$data['records'] = $count;
    	$data['total'] = $total_pages;
    	$data['page'] = $page;
    	$data['rows'] = $arrKtlAccessUserAnalyticsCounts;
    	ob_start('ob_gzhandler');
    	echo json_encode($data);
    }
    function get_ktls_analytics($from_export=false, $exportFilters=NULL){	
        $client_id	= $this->session->userdata('client_id');
        
        if($from_export==true){
            $page = $exportFilters['page']; // get the requested page
            $limit = $exportFilters['rows']; // get how many rows we want
            $sidx = $exportFilters['sidx']; // get index row - i.e. user click to sort
            $sord = $exportFilters['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrFilter = array();
                $arrFilters['end_date'] = $exportFilters['ed'];
                $arrFilters['start_date'] = $exportFilters['sd'];
                $kolId = $exportFilters['kol_id'];
                $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
                $arrReqestedFor = $exportFilters['request_ktl'];
                $arrDivision = $exportFilters['division_id'];
                $arrProfileType = $exportFilters['profile_type'];
                $arrReqestedBy = $exportFilters['request_by'];
                $arrApprovedBy = $exportFilters['approved_by'];
                if($exportFilters['filters']){
                	$arrFilter = array();
                	$arrFilter = $exportFilters['filters'];
                	$field = 'field';
                	$op = 'op';
                	$data = 'data';
                	$groupOp = 'groupOp';
                	$searchGroupOperator = $this->common_helpers->search_nested_arrays ($arrFilter, $groupOp);
                	$searchString = $this->common_helpers->search_nested_arrays ($arrFilter, $data);
                	$searchOper = $this->common_helpers->search_nested_arrays ($arrFilter, $op);
                	$searchField = $this->common_helpers->search_nested_arrays ($arrFilter, $field);
                	$whereResultArray = array();
                	foreach ($searchField as $key => $val) {
                		$whereResultArray[$val] = $searchString[$key];
                	}
                }
        }else{
            $page = $_REQUEST['page']; // get the requested page
            $limit = $_REQUEST['rows']; // get how many rows we want
            $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
            $sord = $_REQUEST['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrFilter = array();
                $arrFilters['end_date'] = $this->input->post('ed');
                $arrFilters['start_date'] = $this->input->post('sd');
                $kolId = $this->input->post('kol_id');
                $kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
                $arrReqestedFor = $this->input->post('request_ktl');
                $arrDivision = $this->input->post('division_id');
                $arrProfileType = $this->input->post('profile_type');
                $arrReqestedBy = $this->input->post('request_by');
                $arrApprovedBy = $this->input->post('approved_by');
                
                if($_REQUEST['filters']){
                	$filterData = $_REQUEST['filters'];
                	$arrFilter = array();
                	$arrFilter = json_decode(stripslashes($filterData));
                	$field = 'field';
                	$op = 'op';
                	$data = 'data';
                	$groupOp = 'groupOp';
                	$searchGroupOperator = $this->common_helpers->search_nested_arrays ($arrFilter, $groupOp);
                	$searchString = $this->common_helpers->search_nested_arrays ($arrFilter, $data);
                	$searchOper = $this->common_helpers->search_nested_arrays ($arrFilter, $op);
                	$searchField = $this->common_helpers->search_nested_arrays ($arrFilter, $field);
                	$whereResultArray = array();
                	foreach ($searchField as $key => $val) {
                		$whereResultArray[$val] = $searchString[$key];
                	}
                	/*
                	 * $searchGroupOperator = $searchGroupOperator[0];
                	 * $searchResults = array();
                	 */
                }
        }
        
        if($arrFilters['end_date'] != '')
            $arrFilters['end_date'] = date("Y-m-d",strtotime("+1 day", strtotime($arrFilters['end_date'])));
            //$arrFilters['end_date'] = date("Y-m-d",strtotime($arrFilters['end_date']));
            
            if($arrFilters['start_date'] != '')
                $arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
                
                $arrFilters['kol_id'] = $kolId;
                $arrFilters['request_for'] = $arrReqestedFor;
                $arrFilters['division_id'] = $arrDivision;
                $arrFilters['profile_type'] = $arrProfileType;
                $arrFilters['reuqest_user_id'] = $arrReqestedBy;
                $arrFilters['approved_user_id'] = $arrApprovedBy;
                $count = $this->report->getAllKolsAnalyticsReport ($client_id, $arrFilters, $limit, $start, true, $sidx, $sord, $whereResultArray);
                // pr($this->db->last_query());
                // $count = sizeof($arrKtlAnalyticsCounts);
                // $limit = $_REQUEST['rows'];
                if ($count > 0){
                	$total_pages = ceil($count / $limit);
                }else{
                	$total_pages = 0;
                }
                if ($page > $total_pages)
                	$page = $total_pages;
                
                	$start = $limit * $page - $limit;
                
                	$arrKtlsDetails = $this->report->getAllKolsAnalyticsReport($client_id, $arrFilters, $limit, $start, false, $sidx, $sord, $whereResultArray);
                	
				     /* pr($this->db->last_query());
                	 exit; */
                foreach($arrKtlsDetails as $row){
                    $arrKtlData['id'] = $row['id'];
                    $arrKtlData['ktl_name'] = $row['ktl_name'];
                    $arrKtlData['ktl_region'] = $row['ktl_region'];
                    $arrKtlData['ktl_profile_type'] = $row['ktl_profile_type'];
                    if ($row['user_client_id'] === INTERNAL_CLIENT_ID) {
                        $arrKtlData['created_by'] = 'Aissel Analyst';
                    }else{
                        $arrKtlData['created_by'] = $row['created_by'];
                    }
                    $arrKtlData['created_on'] = $this->common_helpers->convertDateToMM_DD_YYYY($row['created_on']);
                    //$arrKtlData['last_updated'] = $this->common_helpers->convertDateToMM_DD_YYYY($row['created_on']);
                    $last_updated = $this->report->getLastUpdated($row['id']);
                    if($last_updated){
                    	$arrKtlData['last_updated'] = $this->common_helpers->convertDateToMM_DD_YYYY($last_updated);
                    }else{
                    	$arrKtlData['last_updated'] = $this->common_helpers->convertDateToMM_DD_YYYY($row['created_on']);
                    }
                    $arrKtlData['request_by'] = $row['request_by'];
                    $last_requested = $row['last_requested'];
                    $arrKtlData['last_requested'] = (empty($last_requested))?NULL:$this->common_helpers->convertDateToMM_DD_YYYY($last_requested);
                    $arrKtlData['status'] = $row['status'];
                    $arrKtlData['approve_by'] = $row['approve_by'];
                    $approve_on = $row['approve_on'];
                    $arrKtlData['approve_on'] = (empty($approve_on))?NULL:$this->common_helpers->convertDateToMM_DD_YYYY($approve_on);
                    $last_access = $this->report->userTotalAccessKtl($row['id'], $row['unique_id'], $arrFilters, true);
                    $arrKtlData['user_access'] = $last_access;
                    $arrKtlData['num_payments'] = $this->report->ktlTotalPaymentCreated($row['id'], $arrFilters);
                    $arrKtlData['num_interactions'] = $this->report->ktlTotalInteractionCreated($row['id'], $arrFilters);
                    $arrKtlData['num_contracts'] = $this->report->ktlTotalContractsCreated($row['id'], $arrFilters);
                    $arrKtlData['num_plans'] = $this->report->ktlTotalPlansCreated($row['id'], $arrFilters);
                    $arrKtlAnalyticsCounts[] = $arrKtlData;
                }
                if($from_export==true){
                    return $arrKtlAnalyticsCounts;
                }else{
                	// pr($arrKolsActivityCounts);exit;
                    $dataResult['records'] = $count;
                    $dataResult['total'] = $total_pages;
                    $dataResult['page'] = $page;
                    $dataResult['rows'] = $arrKtlAnalyticsCounts;
                    ob_start('ob_gzhandler');
                    echo json_encode($dataResult);
                }
    }
    function get_user_accessed_ktl_analytics(){
    	$page = $_REQUEST['page']; // get the requested page
    	$limit = $_REQUEST['rows']; // get how many rows we want
    	$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
    	$sord = $_REQUEST['sord']; // get the direction
    	if (!$sidx)
    		$sidx = 1;
    	
    	$arrFilter = array();
    	$kol_id = $this->input->post('kol_id');
    	$arrFilters['end_date'] = $this->input->post('ed');
    	$arrFilters['start_date'] = $this->input->post('sd');
    	$kolId = $this->input->post('kol_id');
    	$arrReqestedFor = $this->input->post('request_ktl');
    	$arrDivision = $this->input->post('division_id');
    	$arrProfileType = $this->input->post('profile_type');
    	$arrReqestedBy = $this->input->post('request_by');
    	$arrApprovedBy = $this->input->post('approved_by');
    	
    	if($arrFilters['end_date'] != '')
    		$arrFilters['end_date'] = date("Y-m-d",strtotime("+1 day", strtotime($arrFilters['end_date'])));
    		//$arrFilters['end_date'] = date("Y-m-d",strtotime($arrFilters['end_date']));
    	
    	if($arrFilters['start_date'] != '')
    		$arrFilters['start_date'] = date("Y-m-d",strtotime($arrFilters['start_date']));
    	
    	$arrFilters['kol_id'] = $kolId;
    	$arrFilters['request_for'] = $arrReqestedFor;
    	$arrFilters['division_id'] = $arrDivision;
    	$arrFilters['profile_type'] = $arrProfileType;
    	$arrFilters['reuqest_user_id'] = $arrReqestedBy;
    	$arrFilters['approved_user_id'] = $arrApprovedBy;
    			
    	$unique_id = $this->common_helpers->getUniqueIdByKolId($kol_id);
    	$arrUserAccessKtlDetails = $this->report->userTotalAccessKtl($kol_id, $unique_id, $arrFilters, false);
    	foreach($arrUserAccessKtlDetails as $row){
    		$arrUserAccessKtlData['id'] = $row->user_id;
    		$arrUserAccessKtlData['user_name'] = $row->user_name;
    		$arrUserAccessKtlData['manager_name'] = $row->manager_name;
    		$arrUserAccessKtlData['division'] = $row->division;
    		$arrUserAccessKtlAnalyticsCounts[] = $arrUserAccessKtlData;
    	}
    	$count = sizeof($arrUserAccessKtlAnalyticsCounts);
    	//$limit = $_REQUEST['rows'];
    	if ($count > 0) {
    		$total_pages = ceil($count / $limit);
    	} else {
    		$total_pages = 0;
    	}
    	//             pr($arrKolsActivityCounts);exit;
    	$data['records'] = $count;
    	$data['total'] = $total_pages;
    	$data['page'] = $page;
    	$data['rows'] = $arrUserAccessKtlAnalyticsCounts;
    	ob_start('ob_gzhandler');
    	echo json_encode($data);
    	
    }
    function summary_report($from_export=false, $exportFilters=NULL){
        if($from_export==true){
            $page = $exportFilters['page']; // get the requested page
            $limit = $exportFilters['rows']; // get how many rows we want
            $sidx = $exportFilters['sidx']; // get index row - i.e. user click to sort
            $sord = $exportFilters['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrDivision = $exportFilters['division_id'];
                $arrMonth = $exportFilters['month'];
                $year = $exportFilters['year'];
        }else{
            $page = $_REQUEST['page']; // get the requested page
            $limit = $_REQUEST['rows']; // get how many rows we want
            $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
            $sord = $_REQUEST['sord']; // get the direction
            if (!$sidx)
                $sidx = 1;
                
                $arrDivision = $this->input->post('division_id');
                $arrMonth = $this->input->post('month');
                $year = $this->input->post('year');
        }
        
        $arrFilters = array ();
        $arrFilters['region'] = $arrDivision;
        $arrFilters['month'] = $arrMonth;
        $arrFilters['year'] = $year;
        
        $getMonthsList = $this->report->transtionMonths($arrFilters);
        arsort($getMonthsList);
        
        foreach($getMonthsList as $key => $value) {
            $date['year'] = substr ( $value, 0, 4 );
            $date['month'] = substr ( $value, 4 );
            /*
             * To get user information for the month
             */
            $arrSummaryReportResult = $this->report->getSummaryReport($date, $arrFilters, $limit = '', $start, $sidx, $sord);
            $month = ltrim (substr($value, 4), '0');
            $arrSummaryData['month'] = $this->common_helpers->getMonthName($month, true).'-'.$date['year'];
            //$arrSummaryData['total_users'] = $arrSummaryReportResult['resultClientUsers'][0]->userTotal;
            $arrSummaryData['active_users'] = $arrSummaryReportResult['resultClientUsers'][0]->activeTotal;
            $arrSummaryData['inactive_users'] = $arrSummaryReportResult['resultClientUsers'][0]->inactiveTotal;
            $arrSummaryData['registration'] = $arrSummaryReportResult['resultClientUsers'][0]->createUsers;
            $arrSummaryData['accessed_system'] = $arrSummaryReportResult['resultUserAccess'][0]->userAccess;
            $arrSummaryData['accessed_ktls'] = $arrSummaryReportResult['resultUserUniqueCount'][0]->uniqueCount;
            $arrSummaryData['crawled'] = $arrSummaryReportResult['resultRequestKtls'][0]->crowled;
            $arrSummaryData['requested'] = $arrSummaryReportResult['resultRequestKtls'][0]->requested;
            $arrSummaryData['updated'] = $arrSummaryReportResult['resultRequestKtls'][0]->updatedKols;
            //$arrSummaryData['updated'] = '-';
            $arrSummaryData['ktl_accessed'] = $arrSummaryReportResult['resultKtlsAccess'][0]->ktlAccess;
            $arrSummaryDataCounts[] = $arrSummaryData;
        }
        if($from_export==true){
            return $arrSummaryDataCounts;
        }else{
            $count = sizeof($arrSummaryDataCounts);
            $limit = $_REQUEST['rows'];
            if ($count>0) {
                $total_pages = ceil($count/$limit);
            } else {
                $total_pages = 0;
            }
            // pr($arrKolsActivityCounts);exit;
            $data['records'] = $count;
            $data['total'] = $total_pages;
            $data['page'] = $page;
            $data['rows'] = $arrSummaryDataCounts;
            ob_start('ob_gzhandler');
            echo json_encode($data);
        }
    }
    /**
     * Gets the newly added report(Analytics and summary) details and exporting d$arrQueryOptionsata to excel format
     *
     * @Created on: 04-07-2017
     * @since	5.3
     * @return
     */
    function export_reports_details(){
        $startTime = microtime(true);
        ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
        $this->load->plugin('php_excel/Classes/PHPExcel.php');
        
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');
            
            $generate_report_for = $this->input->post('report_type');
            $arrFilters = $this->input->post('filters');
            $arrFilters = stripslashes($arrFilters);
            $arrFilters = str_replace('"{', '{', $arrFilters);
            $arrFilters = str_replace('}"', '}', $arrFilters);
            $arrFilters = trim($arrFilters, '"');
            $arrFilters = json_decode($arrFilters, JSON_UNESCAPED_SLASHES);
            
            /* $field = 'field';
             $op = 'op';
             $data = 'data';
             $groupOp = 'groupOp'; */
            $arrFilter = $arrFilters['filters'];
            $whereResultArray = array();
            $whereResultArray = $arrFilters;
            /* if (isset($arrFilters['filters'])) {
             $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
             $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
             $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
             $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
             
             foreach ($searchField as $key => $val) {
             $whereResultArray[$val] = $searchString[$key];
             }
             } */
            $sidx = $arrFilters['sidx'];
            $sord = $arrFilters['sord'];
            $whereResultArray['sidx'] = $sidx;
            $whereResultArray['sord'] = $sord;
            //$arrInteractions[0] = array('Id', 'User', 'Manager', 'Division', 'Registered Date', 'Last Access', 'KTLs Acess', 'payment', 'Interaction', 'Contracts', 'Plans');
            /*
             * get details from repective function
             */
            $objPHPExcel = new PHPExcel();
            $objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
            switch($generate_report_for){
                case 'user_analytics':
                    $arrResultUserAnalytics = $this->get_user_analytics(true, $whereResultArray);
                    
                    //New Worksheet
                    
                    $objWorksheet->setTitle('User Analytics');
                    $fileName = 'User_Analytics';
                    
                    $objWorksheet->setCellValue('A1', 'User')
                    ->setCellValue('B1', 'Manager')
                    ->setCellValue('C1', 'Division')
                    ->setCellValue('D1', 'Registered Date')
                    ->setCellValue('E1', 'Active ?')
                    ->setCellValue('F1', 'Last Access')
                    ->setCellValue('G1', 'Number of Logins')
                    ->setCellValue('H1', lang("KOL").'s Accessed')
                    ->setCellValue('I1', 'Payments')
                    ->setCellValue('J1', 'Interactions')
                    ->setCellValue('K1', 'Contracts')
                    ->setCellValue('L1', 'Plans')
                    ;
                    
                    $i = 2;
                    foreach ($arrResultUserAnalytics as $rows) {
                        $objWorksheet->setCellValue('A'.$i, $rows['user_name'])
                        ->setCellValue('B'.$i, $rows['manager'])
                        ->setCellValue('C'.$i, $rows['division'])
                        ->setCellValue('D'.$i, $rows['registered'])
                        ->setCellValue('E'.$i, $rows['user_status'])
                        ->setCellValue('F'.$i, $rows['last_access'])
                        ->setCellValue('G'.$i, $rows['login_count'])
                        ->setCellValue('H'.$i, $rows['kol_access'])
                        ->setCellValue('I'.$i, $rows['num_payments'])
                        ->setCellValue('J'.$i, $rows['num_interactions'])
                        ->setCellValue('K'.$i, $rows['num_contracts'])
                        ->setCellValue('L'.$i, $rows['num_plans'])
                        ;
                        $i++;
                    }
                    $columnStart = 'A';
                    $columnEnd = 'L';
                    break;
                    
                case 'ktl_analytics':
                    $arrResultKtlAnalytics = $this->get_ktls_analytics(true, $whereResultArray);
                    //New Worksheet
                    
                    $objWorksheet->setTitle('KTL Analytics');
                    $fileName = 'KTL_Analytics';
                    
                    $objWorksheet->setCellValue('A1', lang("KOL").' Name')
                    ->setCellValue('B1', lang("KOL").' Division')
                    ->setCellValue('C1', 'Profile Type')
                    ->setCellValue('D1', 'Created By')
                    ->setCellValue('E1', 'Created On')
                    ->setCellValue('F1', 'Last Updated')
                    ->setCellValue('G1', 'Requested By')
                    ->setCellValue('H1', 'Requested On')
                    ->setCellValue('I1', 'Request Status')
                    ->setCellValue('J1', 'Approved/Rejected By')
                    ->setCellValue('K1', 'Approved/Rejected On')
                    ->setCellValue('L1', 'Users Accessed')
                    ->setCellValue('M1', 'Payments')
                    ->setCellValue('N1', 'Interactions')
                    ->setCellValue('O1', 'Contracts')
                    ->setCellValue('P1', 'Plans')
                    ;
                    
                    $i = 2;
                    foreach ($arrResultKtlAnalytics as $rows) {
                        $objWorksheet->setCellValue('A'.$i, $rows['ktl_name'])
                        ->setCellValue('B'.$i, $rows['ktl_region'])
                        ->setCellValue('C'.$i, $rows['ktl_profile_type'])
                        ->setCellValue('D'.$i, $rows['created_by'])
                        ->setCellValue('E'.$i, $rows['created_on'])
                        ->setCellValue('F'.$i, $rows['last_updated'])
                        ->setCellValue('G'.$i, $rows['request_by'])
                        ->setCellValue('H'.$i, $rows['last_requested'])
                        ->setCellValue('I'.$i, $rows['status'])
                        ->setCellValue('J'.$i, $rows['approve_by'])
                        ->setCellValue('K'.$i, $rows['approve_on'])
                        ->setCellValue('L'.$i, $rows['user_access'])
                        ->setCellValue('M'.$i, $rows['num_payments'])
                        ->setCellValue('N'.$i, $rows['num_interactions'])
                        ->setCellValue('O'.$i, $rows['num_contracts'])
                        ->setCellValue('P'.$i, $rows['num_plans'])
                        ;
                        $i++;
                    }
                    $columnStart = 'A';
                    $columnEnd = 'P';
                    break;
                    
                case 'summary':
                    $arrResultSummary= $this->summary_report(true, $whereResultArray);
                    //New Worksheet
                    
                    $objWorksheet->setTitle('Audit Summary');
                    $fileName = 'Audit_Summary';
                    
                    $objWorksheet->setCellValue('A1', 'Month')
                    ->setCellValue('B1', 'Active Users')
                    ->setCellValue('C1', 'Inactive Users')
                    ->setCellValue('D1', 'New Users')
                    ->setCellValue('E1', 'Logged In')
                    ->setCellValue('F1', 'Viewed '.lang("KOL").'s')
                    ->setCellValue('G1', 'Crawled')
                    ->setCellValue('H1', 'Requested')
                    ->setCellValue('I1', 'Updated')
                    ->setCellValue('J1', 'Profiles Accessed by Users')
                    ;
                    
                    $i = 2;
                    foreach ($arrResultSummary as $rows) {
                        $objWorksheet->setCellValue('A'.$i, $rows['month'])
                        ->setCellValue('B'.$i, $rows['active_users'])
                        ->setCellValue('C'.$i, $rows['inactive_users'])
                        ->setCellValue('D'.$i, $rows['registration'])
                        ->setCellValue('E'.$i, $rows['accessed_system'])
                        ->setCellValue('F'.$i, $rows['accessed_ktls'])
                        ->setCellValue('G'.$i, $rows['crawled'])
                        ->setCellValue('H'.$i, $rows['requested'])
                        ->setCellValue('I'.$i, $rows['updated'])
                        ->setCellValue('J'.$i, $rows['ktl_accessed'])
                        ;
                        $i++;
                    }
                    $columnStart = 'A';
                    $columnEnd = 'J';
                    break;
            }
            $objPHPExcel->addSheet($objWorksheet);
            $styleArray = array(
                'borders' => array(
                    'bottom' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THICK,
                        'color' => array('argb' => '0000000'),
                    ),
                ),
            );
            $arrStyles = array(
                'font' => array(
                    'bold' => true,
                    'italic' => false
                ),
                'borders' => array(
                    'bottom' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THICK,
                        'color' => array(
                            'rgb' => '000000'
                        )
                    ),
                    'quotePrefix' => true
                )
            );
            $objPHPExcel->removeSheetByIndex(0);
            // iterate each sheet and add the style for each sheet
            foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
                $exportOpts = array(strtolower($sheet->getTitle()));
                //if(in_array('professional',$exportOpts)){
                $objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
                foreach (range($columnStart, $columnEnd) as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                    //				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
                }
                $cell = $columnStart."1:".$columnEnd."1";
                $objPHPExcel->getActiveSheet()->getStyle($cell)->applyFromArray($arrStyles);
                //  }
            }
            $objPHPExcel->setActiveSheetIndex(0);
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            // Redirect output to a client’s web browser (Excel2007)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="'.$fileName.'_'.date('m-d-Y').'.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
            exit;
    }
}
