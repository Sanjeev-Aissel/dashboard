<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>

<script type="text/javascript">
    var filters; ;
            var mainFilter = 0;
            var mainFilterId = '';
            var mainCateogry = '';
            if (!js_files_loaded){
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
    }
</script>
<style type="text/css">
    .hasDatepicker{
        /*width: 141px !important;
        margin-left: 36px !important;*/
    }
    .selectBoxMsl
    {
        width: 165px;
    }
    #timeLineSliderContainer {
        padding-left: 10px;
        padding-right: 8px;
    }
    #timeLineSlider{
        margin-right:10px;
    }
    #searchLeftBar li.category{
        border-top: 0px;
    }
    #searchLeftBar{
        /*	margin-top:-40px; */
    }
    <?php
    if (IS_IPAD_REQUEST == 1) {
        echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
    }
    ?>
    .chzn-container-multi .chzn-choices{
        padding-left: 0px !important;
    }
    .chzn-container{
        font-size: 12px;
    }
    .chzn-container-single .chzn-single{
        border-radius: 2px;
        height: 18px;
        padding: 0 0 0 5px;		
    }
    .chzn-container-single .chzn-single span{
        margin-top: -3px;
    }
    .chzn-container .chzn-results{
        padding-left: 0px !important;
        margin: 0px;
    }
    #profileType_chzn .chzn-single span{
        /*margin-top: 0px;*/
    }
    #savedFilterValue_chzn .chzn-drop .chzn-search input{
        border-radius: 2px;
    }
    .highlighted{
       // background: #5A86B8 !important;
        color: white;
    }
    .chzn-container-single .chzn-search input{
        padding: 2px 20px 2px 4px;
    }
    .chzn-search li input[type="text"]{
        border-radius: 2px !important;
    }
    div.actionIcon{
        float: right;
    }
    .chzn-container-single .chzn-single div{
        top: -3px !important;
    }
    /*	.chzn-container .chzn-results li{
                    padding: 3px 4px !important;
                    line-height: 12px !important;
            }
    */
    .chzn-drop{
        min-width: 106px !important;
    }
    .ui-widget-content, #timeLineSliderContainer p, #yearRange {
        background: inherit;
    }
    
        select.chosenMultipleSelectMsl,select.chosenMultipleSelectTherp,select.chosenMultipleSelectStatus{
        width:250px;
    }
    .microView .ui-dialog-content {
   background-color: white;
   }
    .users{
       list-style-type: none;
       margin:0;
       padding:0
       
   }
   .users li{
       float:left;
   }
   .editIcon{
    margin-left: 3px;
   }
   #rightSideBarContainer {
	    width: 311px;
	}
	#rightSideBar::before {
	    border-top: 1px solid #bbbbbb !important;
	    height: 0 !important;
	    margin-left: 0 !important;
	}
	#rightSideBarWrapper {
	    border-left: 1px solid #bbbbbb;
	    /*overflow: hidden;*/
	}
	#categoriesContainer .category{
	    padding: 5px 5px 5px 15px;
	}
	#categoriesContainer table{
		margin-bottom: 0 !important;
	}
	.chzn-container-multi .chzn-choices .search-field input{
		color: #444444 !important;
	}
	#contentWrapper.span-23{
		width: 1342px !important;
	}
	#categoriesContainer .category{
		padding-bottom: 0;
	}
</style>
<?php
$arrfilterdata = $this->session->userdata('filterContent');
$selectedKolId = $arrfilterdata['selected_kol_id'];
if (!empty($selectedKolId) && $selectedKolId != 0) {
    foreach ($arrKolDetails as $key => $rowData) {
        if ($key == $selectedKolId) {
            $selectedKol[$key] = $rowData['name'];
        }
    }
} else {
    $selectedKol = $arrfilterdata['arrKolNames']; //$this->kol->getKolNameById($arrfilterdata['arrKolNames']);
}
if ($arrfilterdata['profileType'] != '') {
    $profileType = $arrfilterdata['profileType'];
}
if ($arrfilterdata['savedFilterId'] != '') {
    $savedFilterId = $arrfilterdata['savedFilterId'];
}
if (!empty($arrfilterdata['arrSpecialities'])) {
    if (!is_array($arrfilterdata['arrSpecialities'])) {
        $arrfilterdata['arrSpecialities'] = explode(',', $arrfilterdata['arrSpecialities']);
    }
    $selectedSpecialty = $this->Specialty->getSpecialtiesById($arrfilterdata['arrSpecialities']);
} else {
    $selectedSpecialty = array();
}
if (sizeof($arrfilterdata['arrCountries']) > 0) {
    if (!is_array($arrfilterdata['arrCountries'])) {
        $arrfilterdata['arrCountries'] = explode(',', $arrfilterdata['arrCountries']);
    }
    $selectedCountry = $this->Country_helper->getCountryNameById($arrfilterdata['arrCountries']);
} else {
    $selectedCountry = array();
}
//$selectedState		= $arrfilterdata['arrStates'];
if (!empty($arrfilterdata['arrStates'])) {
    if (!is_array($arrfilterdata['arrStates'])) {
        $arrfilterdata['arrStates'] = explode(',', $arrfilterdata['arrStates']);
    }
    $selectedState = $this->Country_helper->getStateNameById($arrfilterdata['arrStates']);
} else {
    $selectedState = array();
}
if (sizeof($arrfilterdata['arrListNames']) > 0) {
    if (!is_array($arrfilterdata['arrListNames'])) {
        $arrfilterdata['arrListNames'] = explode(',', $arrfilterdata['arrListNames']);
    }
    $CI = & get_instance();
    $CI->load->model("My_list_kol");
    //$selectedListName	= $arrfilterdata['arrListNames'];
    $selectedListName = $CI->My_list_kol->getListsById($arrfilterdata['arrListNames']);
} else {
    $selectedListName = array();
}
?>
<script type="text/javascript">

    $(document).ready(function (){
      
        
        // resetFilters();
    $('#from').datepicker({
  dateFormat: 'mm/dd/yy',
            onSelect: function(date, instance) {
            filters += "&from=" + date;
                    
            }
    });
            $('#to').datepicker({
   dateFormat: 'mm/dd/yy',
            onSelect: function(date, instance) {
            filters += "&to=" + date;
                   
            }
    });
            //$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
    
            initializeCustomToolTips();
    });
            var options, a;
            // Autocomplet Options for the 'role' field 
            var SpecialtyNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_specialty_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.specialties').html();
                            var selId = $(event).children('.specialties').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#specialty').val(selText);
                            $('#specialtyId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var countryNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>country_helpers/get_country_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.countries').html();
                            var selId = $(event).children('.countries').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#country').val(selText);
                            $('#countryId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var stateNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>country_helpers/get_state_names',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var stateId = $(event).children('.autocompleteStateId').html();
                            var selText = $(event).children('.stateName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#state').val(selText);
                            $('#stateIdForAutocomplete').val(stateId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }
            };
            var kolNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete_refineby',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var kolId = $(event).children('.id1').html();
                            //var selText = $(event).children('.kolName').html();
                            var selText = $(event).children('.kolName').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#kolName').val(selText);
                            $('#kolIdForReport').val(kolId);
                            if (selText.length > 20){
                    if (selText.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    displaySelectedChart(true);
                    }
                    } else{
                    displaySelectedChart(true);
                    }
                    }

            };
            // Autocomplet Options for the 'country' field
            var listNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>my_list_kols/get_list_names_with_category',
<?php echo $autoSearchOptions; ?>,
                    onSelect : function(event, ui) {
                    var selText = $(event).children('.lists').html();
                            var selId = $(event).children('.lists').attr('name');
                            selText = selText.replace(/\&amp;/g, '&');
                            $('#listName').val(selText);
                            $('#listNameId').val(selId);
                            if (event.length > 20){
                    if (event.substring(0, 21) == "No results found for "){
                    return false;
                    } else{
                    //  displaySelectedChart(true);
                    }
                    } else{
                    // displaySelectedChart(true);
                    }
                    }

            };
            /*		
             $(document).ready(function(){
             
             // Trigger the Autocompleter for 'education' field of  Event'
             a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'country' field of  Event'
             a = $('#country').autocomplete(countryNameAutoCompleteOptions);
             
             a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
             
             // Trigger the Autocompleter for 'list' field of  Event'
             a = $('#listName').autocomplete(listNameAutoCompleteOptions);
             
             // Binding the function for slidechange event 
             $( "#timeLineSlider" ).bind( "slidechange", filterChart);
             
             });
             */
            //Initiallize the Timeline slider
<?php $date = date('Y'); ?>
    //	var minYear=<?php echo ($date - 35); ?>;
    var minYear =<?php echo ($date - 60); ?>;
            var maxYear =<?php echo $date; ?>;
            var startDate = '<?php
if (isset($startDate))
    echo $startDate;
else
    echo 0;
?>';
            var endDate = '<?php
if (isset($endDate))
    echo $endDate;
else
    echo 0;
?>';
            var rangeValue1 = minYear;
            var rangeValue2 = maxYear;
            if (startDate != null && startDate != 0)
            rangeValue1 = startDate;
            if (endDate != null && endDate != 0)
            rangeValue2 = endDate;
            /*			
             $(function() {
             $( "#timeLineSlider" ).slider({
             range: true,
             min: minYear,
             max: maxYear,
             values: [ rangeValue1, rangeValue2 ],
             step:1,
             slide: function( event, ui ) {
             $( "#yearRange" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
             }
             });
             
             $( "#yearRange" ).val( "" + $( "#timeLineSlider" ).slider( "values", 0 ) +" - " + $( "#timeLineSlider" ).slider( "values", 1 ) );
             });
             
             
             
             
             
             // Hide or Show the Category checkbox's 
             
             
             $(document).ready(function(){
             $('#kolName').css({color:"gray"});
             $('#specialty').css({color:"gray"});
             $('#country').css({color:"gray"});
             $('#listName').css({color:"gray"});
             
             
             $('#kolName').focus(function(){
             
             var name=$('#kolName').val();
             if(name=='Enter KOL Name'){
             $('#kolName').val(" ");
             }
             });
             
             $('#kolName').blur(function() {
             var name=$('#kolName').val();
             if(name==' '){
             $('#kolName').val('Enter KOL Name');
             }
             });
             
             $('#specialty').focus(function(){
             
             var name=$('#specialty').val();
             if(name=='Enter Specialty'){
             $('#specialty').val(" ");
             }
             });
             
             $('#specialty').blur(function() {
             var name=$('#specialty').val();
             if(name==' '){
             $('#specialty').val('Enter Specialty');
             }
             });
             
             $('#country').focus(function(){
             
             var name=$('#country').val();
             if(name=='Enter Country'){
             $('#country').val(" ");
             }
             });
             
             $('#country').blur(function() {
             var name=$('#country').val();
             if(name==' '){
             $('#kolName').val('Enter Country');
             }
             });
             
             $('#listName').focus(function(){
             
             var name=$('#listName').val();
             if(name=='Enter List Name'){
             $('#listName').val(" ");
             }
             });
             
             $('#listName').blur(function() {
             var name=$('#listName').val();
             if(name==' '){
             $('#listName').val('Enter List Name');
             }
             });
             });
             */
            if (js_files_loaded){

    // Hide or Show the Category checkbox's 
    function toggleCategory(toggleFlag, thisEle){
    //	jAlert("Ds");
    /*	if($(thisEle).parent().attr('id')=='categotySpecialty'){
     $('#specialtyCheckBox').slideToggle();	
     
     }else if($(thisEle).parent().attr('id')=='categotyCountry'){
     $('#countryCheckBox').slideToggle();	
     }else if($(thisEle).parent().attr('id')=='categotyLists'){
     $('#listCheckBox').slideToggle();
     }else{
     $('#kolsCheckBox').slideToggle();
     }
     */
    $(thisEle).next().slideToggle('slow');
            $(thisEle).toggleClass('expanded');
            $(thisEle).toggleClass('collapsed');
    }

    $(function() {
    $("#timeLineSlider").slider({
    range: true,
            min: minYear,
            max: maxYear,
            values: [ rangeValue1, rangeValue2 ],
            step:1,
            slide: function(event, ui) {
            $("#yearRange").val("" + ui.values[ 0 ] + " - " + ui.values[ 1 ]);
            }
    });
            $("#yearRange").val("" + $("#timeLineSlider").slider("values", 0) + " - " + $("#timeLineSlider").slider("values", 1));
    });
            $(document).ready(function(){

    // Trigger the Autocompleter for 'education' field of  Event'
    a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'country' field of  Event'
            a = $('#country').autocomplete(countryNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'country' field of  Event'
            a = $('#state').autocomplete(stateNameAutoCompleteOptions);
            a = $('#kolName').autocomplete(kolNameAutoCompleteOptions);
            // Trigger the Autocompleter for 'list' field of  Event'
            a = $('#listName').autocomplete(listNameAutoCompleteOptions);
            // Binding the function for slidechange event 
            $("#timeLineSlider").bind("slidechange", filterChart);
    });
            $(document).ready(function(){
    $('#kolName').css({color:"gray"});
            $('#specialty').css({color:"gray"});
            $('#country').css({color:"gray"});
            $('#state').css({color:"gray"});
            $('#listName').css({color:"gray"});
            $('#kolName').focus(function(){

    //	var name=$('#kolName').val();
    //	if(name=='Enter KOL Name'){
    $('#kolName').val(" ");
            //	}
    });
            $('#kolName').blur(function() {
    //	var name=$('#kolName').val();
    //	if(name==' '){
    $('#kolName').val('Enter KOL Name');
            //	}
    });
            $('#specialty').focus(function(){

    //	var name=$('#specialty').val();
    //	if(name=='Enter Specialty'){
    $('#specialty').val(" ");
            //	}
    });
            $('#specialty').blur(function() {
    //	var name=$('#specialty').val();
    //	if(name==' '){
    $('#specialty').val('Enter Specialty');
            //	}
    });
            $('#country').focus(function(){

    //	var name=$('#country').val();
    //	if(name=='Enter Country'){
    $('#country').val(" ");
            //	}
    });
            $('#country').blur(function() {
    //	var name=$('#country').val();
    //	if(name==' '){
    $('#country').val('Enter Country');
            //	}
    });
            $('#state').focus(function(){

    //	var name=$('#state').val();
    //	if(name=='Enter State'){
    $('#state').val(" ");
            //	}
    });
            $('#state').blur(function() {
    //	var name=$('#state').val();
    //	if(name==' '){
    $('#state').val('Enter State');
            //	}
    });
            $('#listName').focus(function(){

    //	var name=$('#listName').val();
    //	if(name=='Enter List Name'){
    $('#listName').val(" ");
            //	}
    });
            $('#listName').blur(function() {
    //	var name=$('#listName').val();
    //	if(name==' '){
    $('#listName').val('Enter List Name');
            //	}
    });
    });
            /*
             $('#rightSideBarSliderShow').click(function() {
             $('#searchLeftBar').show(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');					
             });
             $("#rightSideBarSliderHide").show();
             $("#rightSideBarSliderShow").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             
             $('#rightSideBarSliderHide').click(function() {
             $('#searchLeftBar').hide(1000, function() 
             {
             $('#rightSideBarSliderShow').toggleClass('expandRightSideBar');
             $("#rightSideBarSliderShow").show(500);
             });
             $("#rightSideBarSliderHide").hide();
             
             //	$('#searchLeftBar').slideToggle('slow', function() {
             //		$('#rightSideBarSlider').toggleClass('expandRightSideBar');
             //	});
             });
             */
    }
    $(document).ready(function(){
       $('.chosenMultipleSelectMsl').chosen({
        allow_single_deselect: false
    });
     $('.chosenMultipleSelectTherp').chosen({
        allow_single_deselect: true
    });
     $('.chosenMultipleSelectStatus').chosen({
        allow_single_deselect: true
    });
        var a,options;
      



            
            // Autocomplet Options for the 'role' field 
              var MslNameAutoCompleteOptions = {
                    serviceUrl: '<?php echo base_url();?>reports/get_suggestions_for_msl_autocomplete_refineby',
                    <?php echo $autoSearchOptions;?>,
                    onSelect : function(event, ui) {
                        var selText = $(event).children('.msl').html();
                        var selId = $(event).children('.msl').attr('name');
                       
                        selText=selText.replace(/\&amp;/g,'&');
                        $('#mslAuto').val(selId);
                        //$('#mslId').val(selId);
                        filter(null,"msl")
                         $('#mslAuto').val('');
                        if(event.length>20){
                            if(event.substring(0,21)=="No results found for "){
                                return false;
                            }else{
                               // displaySelectedChart(true);
                            }
                        }else{
                          //  displaySelectedChart(true);
                        }
                    }
                    
                };
                  a = $('#mslAuto').autocomplete(MslNameAutoCompleteOptions);
//	$("#savedFilterValue").chosen().change(function(){
//		activeCustmFilters(this);
//	});
//	$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
//		displaySelectedChart(this);
//	});
//	$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
//		if($("#savedFilterValue").val()){
//			activeCustmFilters($("#savedFilterValue").val());
//			return true;
//			}
////		doSearchFilter1(-1,this);
//		displaySelectedChart(this);
//	});
    });
            function toggleCategory(toggleFlag, thisEle){
            //	jAlert("Ds");

            if ($(thisEle).parent().attr('id') == 'MSL'){

            $('#MslCheck').slideToggle();
            } else if ($(thisEle).parent().attr('id') == 'TherpyArea'){
            $('#ThrpCheck').slideToggle();
            } else if ($(thisEle).parent().attr('id') == 'EngStatus'){

            $('#EngCheck').slideToggle();
            }

            }
    function filter(thisEle, category){

$("#filerMessage").empty();

    filters = {};
            if (category == 0)
            category = "msl";
            if (category == 1)
            category = "therp";
            if (category == 2)
            category = "status";
            mainCategory = category;
            if (mainFilter == 0){
    mainFilterId = $(thisEle).children().val();
            mainFilter = 1;
    }

    if ($(thisEle).children().attr('checked') == "checked"){

    

    //$(thisEle).css('background-color', '#fff')
            $(thisEle).children().removeAttr("checked");
         
    }
    else{
   // $(thisEle).css('background-color', '#D3DFED')
            $(thisEle).children().attr("checked", "checked");
    }
//    if (mainCategory != '')
//            mainCategory = '';

    var data = $("#searchFilterForm ").serialize();
            filters += data;
          getChartData();
    }
    
    
    function resetFilters(){
$("select").find('option').removeAttr("selected");
$("input").val('');
$("input").text('');
$('.search-choice').remove();
      filter(null,"msl");
    }
</script>

<style>
    .gridHeight{
        width:837px !important;
    }
    #from, #to{
		width: 80px;
	}
        
        #table :hover{
            background-color: #000 !important;
        }
</style>
<!--		<h3>
                        <div class="funnelIcon sprite_iconSet"></div>Refine By
                        <div id="resetBttnContainer"><label id="resetBttn" onclick="resetFilters();">&nbsp;</label>Reset</div>
                </h3>-->

<div id="searchFiltersContainer">
    <div id="searchFiltersElements">
<!--        <div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
            <p><label>Year Range:</label>
                <input type="text" readonly="readonly" id="yearRange" style="border:0; color:#f6931f; font-weight:bold;" />
            </p>
            <div id="timeLineSlider" class="timeLineSlider" title="Slide to Adjust Timeline">

            </div>
        </div>-->

        <form action="<?php echo base_url() ?>kols/" name="searchFilterForm" method="post" id="searchFilterForm">
            <ul id="categoriesContainer">
                <!--							<li class="">
                                                                                <div>
                                                                                        <div class="assigned sprite_iconSet" id="assignedIcon"></div>
                                                                                        <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
                                                                                        <div style="">
                                                                                                <select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
                                                                                                        <option value="1" <?php if ($viewType == MY_RECORDS) echo 'selected="selected"'; ?>>My Contacts</option>
                                                                                                        <option value="2" <?php if ($viewType == ALL_RECORDS) echo 'selected="selected"'; ?>>All Contacts</option>
                                                                                                </select>
                                                                                        </div>
                                                                                </div>
                                                                        </li>
                                                                        <li id="customFilters" class="">
                                                                                <div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
                                                                                <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 5px;">Saved Filters </label>
                                                                                <div style="">
                                                                                        <select id="savedFilterValue" data-placeholder="Choose saved queries..." style="width:150px;" class="chosen-select">
                                                                                                <option></option>
                <?php foreach ($customFilters as $customFilter) { ?>
                                                                                                                    <option value='<?php echo $customFilter['id']; ?>' <?php
                    if ($savedFilterId == $customFilter['id']) {
                        echo 'selected="selected"';
                    }
                    ?> ><?php echo $customFilter['name']; ?></option>
<?php } ?>
                                                                                        </select>
                                                                                        <div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
                                                                                                <a data-original-title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
                                                                                        </div>
                                                                                </div>
                                                                        </li>
                                                                        <li class="">
                                                                                <div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
                                                                                <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">Profile Type </label>
                                                                                <div style="">
                                                                                        <select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
                                                                                                <option value="">All Profiles</option>
                                                                                                <option value="Full Profile" <?php if ($profileType == "Full Profile") echo "selected='selected'"; ?>>Full Profiles</option>
                                                                                                <option value="Basic Plus" <?php if ($profileType == "Basic Plus") echo "selected='selected'"; ?>>Basic+ Profiles</option>
                                                                                                <option value="Basic" <?php if ($profileType == "Basic") echo "selected='selected'"; ?>>Basic Profiles</option>
                                                                                        </select>
                                                                                </div>
                                                                        </li>-->
                <li id="categotyKols" class="category">
                    <!--								<div class="kolName sprite_iconSet"></div><label class="categoryName">KOL Name</label>-->
                    <!--								<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>-->
                    <div>
                        <table>
                            <?php
                            if (isset($selectedKol) && $selectedKol != null && $selectedKol != 0) {
                                foreach ($selectedKol as $k => $kol) {
                                    ?>
                                    <tr class="kol<?php echo str_replace(' ', '', $kol); ?>">
                                        <td class="textAlignRight">
                                            <input type="checkbox" name="kol_ids[]" class="kolElement hideCheckbox" id="kol<?php echo str_replace(' ', '', $kol); ?>" checked="checked" value="<?php echo $k; ?>" onclick="displaySelectedChart(this)" />&nbsp;<?php echo $kol; ?>
                                        </td>
                                        <td class="histoGram"><div class="filterBar">
                                                <div class="progress" title="1(<?php echo round((1 / 1) * 100); ?>%)">
                                                    <div class="bar" style="width: <?php
                                                    if (isset($kol))
                                                        echo round((1 / 1) * 100);
                                                    else
                                                        echo 0;
                                                    ?>%;"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
                                            //	if($reportSection=='activity'){
                                            if (array_key_exists($kol, $arrKolDetails)) {
                                                if (isset($arrKolDetails[$kol]['count']))
                                                    echo '(' . $arrKolDetails[$kol]['count'] . ')';
                                            }
                                            else {
                                                if (isset($arrKolDetails[$kol]['count']))
                                                    echo '(' . '0' . ')';
                                            }
                                            //	}
                                            ?>
                                        </td>
                                    </tr>
    <?php
    }
}
?>
                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="kol_ids1" class="autocompleteInputBox" id="kolName" value="Enter KOL Name" title=""/>
                        <input type="hidden" id="kolIdForReport" value="<?php echo $selectedKolId; ?>" name="kol_id1"></input>
                    </div>
                </li>


<!--                <li id="coaching" class="">-->
                    <form name="coaching" id="coachingForm" >
                        <!--<div class="refineBySecialtyImage sprite_iconSet"></div><label class="categoryName">MSL Name</label>-->
                        <!--<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>-->



                       
                          
<!--                            <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">From: </label>
                            <div style="">
                                <input type="text" name="from" id="from" value="<?php
                                       if (isset($mirfDetails[0]['date_of_request']))
                                           echo $mirfDetails[0]['date_of_request'];
                                       else
                                           echo '';
                                       ?>">
                            </div>-->
                           
                       

<!--                            <div class="assigned sprite_iconSet" id="assignedIcon"></div>
                            <label class="categoryName" style="float:left;border-bottom:0px; margin-right: 45px;">To: </label>
                            <div style="">
                                <input type="text" name="to" id="to" value="<?php
                                       if (isset($mirfDetails[0]['date_of_request']))
                                           echo $mirfDetails[0]['date_of_request'];
                                       else
                                           echo '';
                                       ?>">
                            </div>-->

                    </form>



<!--								<table>
        <tr class="allSpecialties">
                <td class="textAlignRight">
                        <input class="hideCheckbox" type="checkbox" name="all_specialties" id="allSpecialties"  value="specialties" <?php
                                       if (isset($selectedSpecialty) && $selectedSpecialty != null && $selectedSpecialty != 0)
                                           echo '';
                                       else
                                           echo "checked='checked'"
                                           ?> onclick="displaySelectedChart(this)"/>All Specialties
                </td>
                <td class="histoGram"><div class="filterBar">
                                <div class="progress" title="<?php
                    if (isset($totalKolsCount))
                        echo $totalKolsCount . "(" . round(($totalKolsCount / $totalKolsCount) * 100);
                    else
                        echo "0(0";
                    ?>%)">
                                        <div class="bar" style="width: <?php
                    if (isset($totalKolsCount))
                        echo round(($totalKolsCount / $totalKolsCount) * 100);
                    else
                        echo 0;
                    ?>%;"></div>
                                </div>
                        </div>
                </td>
                <td>
                    <?php
//	if($reportSection=='activity'){
                    if (isset($totalKolsCount))
                        echo $totalKolsCount;
                    else
                        echo 0;
//	}
                    ?>
                </td>
        </tr>
                
</div>
</li>

                    <!---->							
                
                 <table style='  margin-left: 7px;' id="dateFilter">
                     <tr>
                                        <td colspan="2" style="text-align: center;">
                                                                                   <button type="button" name="applyFilter"  id="applyFilter" onclick="filter();">Apply Filters</button>                                
                                            <!--<input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" onclick="filter('this','0');">-->                                                
                                        </td>
                                    </tr>
								<tr>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;"  >From </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="from" value="" id="from">
										</div>
									</td>
									<td>
										<label style="color:#33335F;float:left;border-bottom:0px; margin-right: 9px;" >To </label>
										<div style="">
											<input style="float: left;margin-left: -2px !important;  border-color: #AAAAAA;" type="text" name="to" value="" id="to">
										</div>
									</td>
								</tr>
							</table>
				<li class="category"></li>
                <li id="MSL" class="category">

                    <!--<div class="refineByCountryImage sprite_iconSet"></div>-->
                    <label class="categoryName">MSL Name</label>
                    <div id="MslCheck">
                        <table id="mslData">
<select name="msls[]" id="users" class="chosenMultipleSelectMsl" data-placeholder="Select Users" >
            <option value=""></option>
            <?php 
                
                foreach($arrClientUsers as $key=>$arrRow){
                    $selected    = '';?>
                    <option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name'].' '.$arrRow['last_name']?></option>;
                <?php }
                
            ?>
            
        </select>
                      





                        </table>
                        <!--<div class="filterSearchIcon"></div><input type="text" name="msl_auto" class="autocompleteInputBox" id="mslAuto" value="" title=""/><input type="hidden" name="msl_id" id="mslId" value="" />


                        <!--<div class="filterSearchIcon"></div><input type="text" name="country_ids" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />-->
                    </div>
                    
                    
                </li>

<!--                <li id="TherpyArea" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div>
                    <label class="categoryName">Therapeutic Area:</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div id="ThrpCheck">
                        
                        <table id="therpData">	
                            <select name="thrp_name[]" id="therp" multiple="multiple" class=" chosenMultipleSelectTherp" data-placeholder="Select Area" onchange="filter('this','1')">
            <option value=""></option>
            <?php 
                
                foreach($arrSpecialties as $key=>$arrRow){
                    $selected    = '';?>
                    <option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['name']?></option>;
                <?php }
                
            ?>
            
        </select>
                            <?php
//                            foreach ($arrSpecialties as $key => $row) {
//                                echo '<tr class="allTherpys">';
//
//                                //     echo '<option  value="'.$row['id'].'">'.$row['first_name'].' '.$row['last_name'].'</option>';
//                                echo '<td  onclick="filter(this,1)" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="thrp_name[]" id="mslName"  value=' . $row['id'] . ' "/>' . $row['name'] . '</td>';
//                                echo '<td class="histoGram">
//                                                         <div class="filterBar">
//                                                            <div class="progress" title="100%">
//                                                                <div class="bar" style="width: 100%;"></div>
//                                                            </div>
//                                                        </div>
//                                                    </td>';
//                                echo '</tr>';
//                            }
//                            ?> 





                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="country_ids" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
                    </div>
                </li>

                <li id="EngStatus" class="category">

                    <div class="refineByCountryImage sprite_iconSet"></div>
                    <label class="categoryName">Engagement Status:</label>
                    <label class="facet-toggle expanded" onclick="toggleCategory(true, this);"></label>
                    <div id="EngCheck">
                        <table id="engData">
                            
                                          <select name="eng_name[]" id="status" multiple="multiple" class="chosenMultipleSelectStatus" data-placeholder="Select Engagement Status" onchange="filter('this','2')">
            <option value=""></option>
            <?php 
                
                foreach($arrEngagement as $key=>$arrRow){
                   
                    $selected    = '';?>
                    <option value="<?php echo $arrRow['status']?>"><?php echo $arrRow['status']?></option>;
                <?php }
                
            ?>
            
        </select>
                            <?php
//                            foreach ($arrEngagement as $key => $row) {
//                                echo '<tr class="allTherpys">';
//
//                                //     echo '<option  value="'.$row['id'].'">'.$row['first_name'].' '.$row['last_name'].'</option>';
//                                echo '<td onclick="filter(this,2)" class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="eng_name[]" id="mslName"  value="' . $row['status'] . '"  "/>' . $row['status'] . '</td>';
//                                echo '<td class="histoGram">
//                                                         <div class="filterBar">
//                                                            <div class="progress" title="100%">
//                                                                <div class="bar" style="width: 100%;"></div>
//                                                            </div>
//                                                        </div>
//                                                    </td>';
//                                echo '</tr>';
//                            }
//                            ?> 





                        </table>
                        <div class="filterSearchIcon"></div><input type="text" name="country_ids" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
                    </div>
                </li>-->


            </ul>
        </form>

    </div>
</div>
