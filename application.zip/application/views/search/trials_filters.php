<?php
/**
*File To show clinical trials filter search page.
*
*@author: Ambarish N
*@created on: 07-02-11
*/
 //$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
 $autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999; */
	/*	margin-top:0.7em;*/
		overflow:visible;
		padding-top:0.8em;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url(../../images/sprite_facetsearch_v7.png) no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:11px;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttn{
		width: 11px;
		height: 11px;
		float: right;
		background-color:buttonshadow;
		-moz-border-radius-bottomleft:2px;
		-moz-border-radius-bottomright:2px;
		-moz-border-radius-topleft:2px;
		-moz-border-radius-topright:2px;
		vertical-align: middle;
		margin-left:4px;
		margin-top:4px;
		cursor: pointer;
		margin-right: 10px;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
</style>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<script type="text/javascript">

	var options, a;

	//--------------Start of Clinical trails Filters Autocomplet------------------------
		// Autocomplet Options for the 'Intervention' field 
		var interventionAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>clinical_trials/get_interventions_name',<?php echo $autoSearchOptions;?>
		};	

		var conditionAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>clinical_trials/get_condition_name',<?php echo $autoSearchOptions;?>
			};	

		var investigatorsAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>clinical_trials/get_investigators_name',<?php echo $autoSearchOptions;?>
			};	

		var meshTermsAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>clinical_trials/get_mesh_term_name',<?php echo $autoSearchOptions;?>
			};	

		var sponsorsAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>clinical_trials/get_sponsors_name',<?php echo $autoSearchOptions;?>
			};	

		$(document).ready(function(){

			$('#categoriesContainer input:checked').each(function (index){
				$(this).parent().parent().css('background-color','#D3DFED');
			});

			$('#searchFiltersElements ul li table tr').click(function (){
				if($('#'+$(this).attr('class')).attr('checked')=="checked"){
					$(this).css('background-color','#ffffff');
					$('#'+$(this).attr('class')).removeAttr('checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}else{
					$(this).css('background-color','#D3DFED');
					$('#'+$(this).attr('class')).attr('checked','checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}
			});

			
			// Trigger the Autocompleter for 'Intervention' field 
	    	a = $('#intervention').autocomplete(interventionAutoCompleteOptions);

			// Trigger the Autocompleter for 'condition' field 
	    	a = $('#condition').autocomplete(conditionAutoCompleteOptions);

			// Trigger the Autocompleter for 'Investigators' field 
	    	a = $('#investigator').autocomplete(investigatorsAutoCompleteOptions);

			// Trigger the Autocompleter for 'MeshTerms' field 
	    	a = $('#meshterm').autocomplete(meshTermsAutoCompleteOptions);

			// Trigger the Autocompleter for 'Sponsors' field 
	    	a = $('#sponsor').autocomplete(sponsorsAutoCompleteOptions);
		});

		// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
			var parentId=$(thisEle).parent().attr("id");
			if($(thisEle).hasClass('expanded')){
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				//$('#searchLeftBar #'+parentId+' ul').hide();
				$(thisEle).next().hide();
			}
			else {
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
				//$('#searchLeftBar #'+parentId+' ul').show();
				$(thisEle).next().show();
			}
		}
</script>

<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>clinical_trials/filter_search_trials" name="searchForm" method="post" id="searchFilterForm">
		<input type="hidden" name="keyword" id="keyword" value="<?php echo $keyword;?>"/>
		<input type="hidden" name="search_type" id="searchType" value="<?php echo $searchType;?>"/>
		<input type="hidden" name="filterCategory" id="filterCategory" value="trials"/>
		
		<?php if($arrAdvSearchFields != null){ ?>
			<input type="hidden" name="trialInterventions" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['interventions']; ?>"/>
			<input type="hidden" name="trialCondition" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['condition']; ?>"/>
			<input type="hidden" name="trialInvestigators" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['investigators']; ?>"/>
			<input type="hidden" name="trialMesh_term" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['mesh_term']; ?>"/>
			<input type="hidden" name="trialSponsors" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['sponsors']; ?>"/>
		<?php }?>	
		
		<ul id="categoriesContainer">
			<li id="categoryMeshTerm" class="category">
				<label class="categoryName">MeshTerm</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allMeshterms">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_meshterms" id="allMeshterms"  value="meshterm" <?php if(isset($selectedMeshterms) && $selectedMeshterms!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All MeshTerms</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allMeshtermCount."(".round(($allMeshtermCount/$allMeshtermCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($allMeshtermCount/$allMeshtermCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allMeshtermCount)) echo $allMeshtermCount; else echo 0;?></td>
					</tr>

					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrTrialsByMeshtermCount as $meshtermCountDetails){ ?>
					 	<?php if($meshtermCountDetails['meshterm']!=''){?>
						 	<tr class="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermCountDetails['meshterm']));?>">
								<td class="textAlignRight">
									<input type="checkbox" name="meshterm_ids[]" class="meshtermElement hideCheckbox" id="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermCountDetails['meshterm']));?>" value="<?php echo $meshtermCountDetails['meshterm'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedMeshterms) && sizeof($selectedMeshterms)>0 && $selectedMeshterms!=null){if(in_array($meshtermCountDetails['meshterm'], $selectedMeshterms)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($meshtermCountDetails['meshterm'], $selectedMeshterms);if(array_key_exists($key, $selectedMeshterms))unset($selectedMeshterms[$key]);$selectedMeshterms=array_values($selectedMeshterms);}}?>
									/>&nbsp;<?php echo $meshtermCountDetails['meshterm'];?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="<?php echo $meshtermCountDetails['count']."(".round(($meshtermCountDetails['count']/$allMeshtermCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($meshtermCountDetails['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $meshtermCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedMeshterms) && $selectedMeshterms!=null){foreach($selectedMeshterms as $meshtermName){?>
						<tr class="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermName));?>">
							<td class="textAlignRight"><input type="checkbox" name="meshterm_ids[]" class="meshtermElement hideCheckbox" id="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermName));?>" value="<?php echo $meshtermName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $meshtermName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrTrialsByMeshtermCount[$meshtermName]['count']."(".round(($arrTrialsByMeshtermCount[$meshtermName]['count']/$allMeshtermCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($arrTrialsByMeshtermCount[$meshtermName]['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($meshtermName, $arrTrialsByMeshtermCount)) echo $arrTrialsByMeshtermCount[$meshtermName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="meshterm" class="autocompleteInputBox" id="meshterm" value="" title=""/>
				</div>
			</li>
			
			<li id="categoryCondition" class="category">
				<label class="categoryName">Condition</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allConditions">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_conditions" id="allConditions"  value="condition" <?php if(isset($selectedConditions) && $selectedConditions!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All Conditions</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allConditionCount."(".round(($allConditionCount/$allConditionCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allConditionCount)) echo round(($allConditionCount/$allConditionCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allConditionCount)) echo $allConditionCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrTrialsByConditionCount as $conditionCountDetails){ ?>
					 	<?php if($conditionCountDetails['condition']!=''){?>
						 	<tr class="condition<?php echo str_replace(' ','',str_replace('&','and',$conditionCountDetails['condition']));?>">
								<td class="textAlignRight"><input type="checkbox" name="condition_ids[]" class="conditionElement hideCheckbox" id="condition<?php echo str_replace(' ','',str_replace('&','and',$conditionCountDetails['condition']));?>" value="<?php echo $conditionCountDetails['condition'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedConditions) && sizeof($selectedConditions)>0 && $selectedConditions!=null){if(in_array($conditionCountDetails['condition'], $selectedConditions)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($conditionCountDetails['condition'], $selectedConditions);if(array_key_exists($key, $selectedConditions))unset($selectedConditions[$key]);$selectedConditions=array_values($selectedConditions);}}?>
									/>&nbsp;<?php echo $conditionCountDetails['condition'];?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="<?php echo $conditionCountDetails['count']."(".round(($conditionCountDetails['count']/$allConditionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allConditionCount)) echo round(($conditionCountDetails['count']/$allConditionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $conditionCountDetails['count'];?></td>
							</tr>
						</li>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedConditions) && $selectedConditions!=null){foreach($selectedConditions as $conditionName){?>
						<tr class="condition<?php echo str_replace(' ','',str_replace('&','and',$conditionName));?>">
							<td class="textAlignRight"><input type="checkbox" name="condition_ids[]" class="conditionElement hideCheckbox" id="condition<?php echo str_replace(' ','',str_replace('&','and',$conditionName));?>" value="<?php echo $conditionName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $conditionName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrTrialsByConditionCount[$conditionName]['count']."(".round(($arrTrialsByConditionCount[$conditionName]['count']/$allConditionCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allConditionCount)) echo round(($arrTrialsByConditionCount[$conditionName]['count']/$allConditionCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($conditionName, $arrTrialsByConditionCount)) echo $arrTrialsByConditionCount[$conditionName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="condition" class="autocompleteInputBox" id="condition" value="" title=""/>
				</div>
			</li>
			
			<li id="categorySponsor" class="category">
				<label class="categoryName">Sponsor</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allSponsors">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_sponsors" id="allSponsors"  value="sponsor" <?php if(isset($selectedSponsors) && $selectedSponsors!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All Sponsor</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allSponsorCount."(".round(($allSponsorCount/$allSponsorCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allSponsorCount)) echo round(($allSponsorCount/$allSponsorCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allSponsorCount)) echo $allSponsorCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrTrialsBySponsorCount as $sponsorCountDetails){ ?>
					 	<?php if($sponsorCountDetails['sponsor']!=''){?>
						 	<tr class="sponsor<?php echo str_replace(' ','',str_replace('&','and',$sponsorCountDetails['sponsor']));?>">
								<td class="textAlignRight">
									<input type="checkbox" name="sponsor_ids[]" class="sponsorElement hideCheckbox" id="sponsor<?php echo str_replace(' ','',str_replace('&','and',$sponsorCountDetails['sponsor']));?>" value="<?php echo $sponsorCountDetails['sponsor'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedSponsors) && sizeof($selectedSponsors)>0 && $selectedSponsors!=null){if(in_array($sponsorCountDetails['sponsor'], $selectedSponsors)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($sponsorCountDetails['sponsor'], $selectedSponsors);if(array_key_exists($key, $selectedSponsors))unset($selectedSponsors[$key]);$selectedSponsors=array_values($selectedSponsors);}}?>
									/>&nbsp;<?php echo $sponsorCountDetails['sponsor'];?>
								</td>
								<td class="histoGram">
									<div class="filterBar">
										<div class="progress" title="<?php echo $sponsorCountDetails['count']."(".round(($sponsorCountDetails['count']/$allSponsorCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allSponsorCount)) echo round(($sponsorCountDetails['count']/$allSponsorCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $sponsorCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedSponsors) && $selectedSponsors!=null){foreach($selectedSponsors as $sponsorName){?>
						<tr class="sponsor<?php echo str_replace(' ','',str_replace('&','and',$sponsorName));?>">
							<td class="textAlignRight"><input type="checkbox" name="sponsor_ids[]" class="sponsorElement hideCheckbox" id="sponsor<?php echo str_replace(' ','',str_replace('&','and',$sponsorName));?>" value="<?php echo $sponsorName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $sponsorName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrTrialsBySponsorCount[$sponsorName]['count']."(".round(($arrTrialsBySponsorCount[$sponsorName]['count']/$allSponsorCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allSponsorCount)) echo round(($arrTrialsBySponsorCount[$sponsorName]['count']/$allSponsorCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($sponsorName, $arrTrialsBySponsorCount)) echo $arrTrialsBySponsorCount[$sponsorName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="sponsor" class="autocompleteInputBox" id="sponsor" value="" title=""/>
				</div>
			</li>
			
			<li id="categoryIntervention" class="category">
				<label class="categoryName">Intervention</label>
				<label class="facet-toggle collapsed"  onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allInterventions">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_interventions" id="allInterventions"  value="intervention" <?php if(isset($selectedInterventions) && $selectedInterventions!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All Interventions</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allInterventionCount."(".round(($allInterventionCount/$allInterventionCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allInterventionCount)) echo round(($allInterventionCount/$allInterventionCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allInterventionCount)) echo $allInterventionCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrTrialsByInterventionCount as $interventionCountDetails){ ?>
					 	<?php if($interventionCountDetails['intervention']!=''){?>
						 	<tr class="intervention<?php echo str_replace(' ','',str_replace('&','and',$interventionCountDetails['intervention']));?>">
								<td class="textAlignRight">
									<input type="checkbox" name="intervention_ids[]" class="interventionElement hideCheckbox" id="intervention<?php echo str_replace(' ','',str_replace('&','and',$interventionCountDetails['intervention']));?>" value="<?php echo $interventionCountDetails['intervention'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedInterventions) && sizeof($selectedInterventions)>0 && $selectedInterventions!=null){if(in_array($interventionCountDetails['intervention'], $selectedInterventions)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($interventionCountDetails['intervention'], $selectedInterventions);if(array_key_exists($key, $selectedInterventions))unset($selectedInterventions[$key]);$selectedInterventions=array_values($selectedInterventions);}}?>
									/>&nbsp;<?php echo $interventionCountDetails['intervention'];?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="<?php echo $interventionCountDetails['count']."(".round(($interventionCountDetails['count']/$allInterventionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allInterventionCount)) echo round(($interventionCountDetails['count']/$allInterventionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $interventionCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedInterventions) && $selectedInterventions!=null){foreach($selectedInterventions as $interventionName){?>
						<tr class="intervention<?php echo str_replace(' ','',str_replace('&','and',$interventionName));?>">
							<td class="textAlignRight"><input type="checkbox" name="intervention_ids[]" class="interventionElement hideCheckbox" id="intervention<?php echo str_replace(' ','',str_replace('&','and',$interventionName));?>" value="<?php echo $interventionName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $interventionName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrTrialsByInterventionCount[$interventionName]['count']."(".round(($arrTrialsByInterventionCount[$interventionName]['count']/$allInterventionCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allInterventionCount)) echo round(($arrTrialsByInterventionCount[$interventionName]['count']/$allInterventionCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($interventionName, $arrTrialsByInterventionCount)) echo $arrTrialsByInterventionCount[$interventionName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="intervention" class="autocompleteInputBox" id="intervention" value="" title=""/>
				</div>
			</li>
			
			<li id="categoryInvestigator" class="category">
				<label class="categoryName">Investigator</label>
				<label class="facet-toggle collapsed"  onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allInvestigators">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_investigators" id="allInvestigators"  value="investigator" <?php if(isset($selectedInvestigators) && $selectedInvestigators!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All Investigators</td>
						<td class="histoGram">
							<div class="filterBar">
								<div class="progress" title="<?php echo $allInvestigatorCount."(".round(($allInvestigatorCount/$allInvestigatorCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allInvestigatorCount)) echo round(($allInvestigatorCount/$allInvestigatorCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allInvestigatorCount)) echo $allInvestigatorCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrTrialsByInvestigatorCount as $investigatorCountDetails){ ?>
					 	<?php if($investigatorCountDetails['investigator']!=''){?>
						 	<tr class="investigator<?php echo str_replace(' ','',str_replace('&','and',$investigatorCountDetails['investigator']));?>">
								<td class="textAlignRight"><input type="checkbox" name="investigator_ids[]" class="investigatorElement hideCheckbox" id="investigator<?php echo str_replace(' ','',str_replace('&','and',$investigatorCountDetails['investigator']));?>" value="<?php echo $investigatorCountDetails['investigator'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedInvestigators) && sizeof($selectedInvestigators)>0 && $selectedInvestigators!=null){if(in_array($investigatorCountDetails['investigator'], $selectedInvestigators)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($investigatorCountDetails['investigator'], $selectedInvestigators);if(array_key_exists($key, $selectedInvestigators))unset($selectedInvestigators[$key]);$selectedInvestigators=array_values($selectedInvestigators);}}?>
									/>&nbsp;<?php echo $investigatorCountDetails['investigator'];?>
								</td>
								<td class="histoGram">
									<div class="filterBar">
										<div class="progress" title="<?php echo $investigatorCountDetails['count']."(".round(($investigatorCountDetails['count']/$allInvestigatorCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allInvestigatorCount)) echo round(($investigatorCountDetails['count']/$allInvestigatorCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $investigatorCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedInvestigators) && $selectedInvestigators!=null){foreach($selectedInvestigators as $investigatorName){?>
						<tr class="investigator<?php echo str_replace(' ','',str_replace('&','and',$investigatorName));?>">
							<td class="textAlignRight"><input type="checkbox" name="investigator_ids[]" class="investigatorElement hideCheckbox" id="investigator<?php echo str_replace(' ','',str_replace('&','and',$investigatorName));?>" value="<?php echo $investigatorName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $investigatorName;?></td>
							<td class="histoGram">
								<div class="filterBar">
									<div class="progress" title="<?php echo $arrTrialsByInvestigatorCount[$investigatorName]['count']."(".round(($arrTrialsByInvestigatorCount[$investigatorName]['count']/$allInvestigatorCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allInvestigatorCount)) echo round(($arrTrialsByInvestigatorCount[$investigatorName]['count']/$allInvestigatorCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($investigatorName, $arrTrialsByInvestigatorCount)) echo $arrTrialsByInvestigatorCount[$investigatorName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="investigator" class="autocompleteInputBox" id="investigator" value="" title=""/>
				</div>
			</li>
		</ul>
	</form>
</div>