<?php  
/*
 * @author: Vinayak
 * @siice 3.9
 * @created  April 5,2012	
 *
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author: Ben Kitzelman - Nov 2010 - http://thecodeabode.blogspot.com/
 *
 * LICENSE: All free - do what you like with it.
 *
 * INSTRUCTIONS:		
 * Extends the Native CI_Email Class to provide support for embedding images.
 * A custom macro in the message body is used to embed an image.... 
 *
 * MACRO FORMAT: 
 * {embedded_image file=C:\\my_windows_folder\\my_pic.png class_id=myPic}{/embedded_image}
 * {embedded_image file=/my_linux_folder/my_pic.png class_id=myPic}{/embedded_image}
 * 
 * --NOTE: With windows - remember to addslashes($img_path) to delimit the path to image for parsing
 * 
 * EXAMPLE: the following is the string to be sent as the body of the email:
 * 
 * <html>
 * <body>
 * <p>This is my email message</p>
 * <img src='cid:myPic' />
 * </body>
 * </html>
 * {embedded_image file=C:\\my_windows_folder\\my_pic.png class_id=myPic}{/embedded_image}
 */
class MY_email extends CI_Email 
{
	/**
	 * change_string_to_regex: Changes the given string into a regular expression fragment
	 *
	 * @param - the string to be changed
	 * @return - a regular expression fragment
	 */
	protected function change_string_to_regex($str)
	{
		$regex = str_ireplace("\\", "\\\\", $str);
		$regex = str_ireplace("{", "\\{", $regex);
		$regex = str_ireplace("}", "\\}", $regex);
		$regex = str_ireplace("/", "\\/", $regex);
		
		return $regex;	
	} 
	
	/**
	 * embed_images: Parses the message body for embedded_images macros, and processes them.
	 * 
	 * @return
	 * TRUE - the message had embedded images and they have been processed
	 * FALSE - the message did not have any embedded images
	 */
	protected function embed_images()
	{
		//
		// Find all embedded image macros in the message body
		//
		$match_found = preg_match_all('/(\{embedded_image ([^\}]*)\}[^\}]*?\{\/embedded_image\})/ms', $this->_body, $matches);
		if($match_found == false || $match_found == 0) return false;
				
		//
		// For each Macro
		//
		for($i=0; $i < sizeof($matches[2]); $i++)
		{
			$full_macro = $matches[1][$i]; //get the macro tag
			$macro_args = $matches[2][$i]; //get the macro arguments
			//echo $full_macro;
			//echo $macro_args;
			//
			// parse attributes into an assoc array 
			//
			$atts = explode(" ", $macro_args);
			$attributes = array();
			foreach($atts as $att)
			{			
				$kv = explode("=",$att);
				$attributes[strtolower($kv[0])] = $kv[1];
			}
			
			//
			// embed the image
			//
			$this->embed_image($attributes, $full_macro);
		}
		
		return true;
	}
	
	/**
	 * embed_image: Encodes the image for embedding, and adds it to a relevant content region 
	 * in the message body.
	 * 
	 * @param $attributes - assoc array - containing the image's 'file' path and 'class_id' (used as img src)
	 * @param $macro - string - the full macro tag used to embed this image
	 * 
	 * @return
	 * TRUE - the image was embedded
	 * FALSE - the specified image could not be found
	 */
	protected function embed_image($attributes, $macro)
	{	
		//
		// Check the image file exists
		//
		$fn = $attributes["file"];
		if(file_exists($fn) == false)
		{
			log_error("ERROR: Could not find the attachment '$fn' on disk");
			return false;	
		}
		
		//
		// Get the image class id and mime type
		//
		$cid = $attributes["class_id"];
		$ext = strtolower(end(explode('.', $fn)));
		$mime = $this->_mime_types($ext);
		
		/*
		 * Embed the image into the email body by generating content in the following format 
		    --wrap
			Content-Type: image/png;
			 name="organisation_logo.png"
			Content-Transfer-Encoding: base64
			Content-ID: <$cid>
			Content-Disposition: inline;
			 filename="myfile.png"
			 
			 /9/9=sd33gsd54cf4fgdsd...  (binary image data base64 encoded)
			  
		 */
		$embed_str  = $this->newline."--wrap".$this->newline;
		$embed_str .= "Content-Type: $mime".$this->newline;
		$embed_str .= " name='".basename($fn)."'".$this->newline;
		$embed_str .= "Content-Transfer-Encoding: base64".$this->newline;
		$embed_str .= "Content-ID: <$cid>".$this->newline;
		$embed_str .= "Content-Disposition: inline;".$this->newline;
		$embed_str .= " filename='".basename($fn)."'".$this->newline.$this->newline;
		$embed_str .= chunk_split(base64_encode(file_get_contents($fn))).$this->newline;		
				
		//
		// Insert the embedded image data into the body with an id stamped embed_image tag - to show it has been processed
		//
		$macro_regex = $this->change_string_to_regex($macro);
		$id = sha1(date('r', time()));
		$this->_body = preg_replace("/(.*)$macro_regex(.*)/ms", "$1{embedded_image $id}$embed_str{/embedded_image}$2", $this->_body);
		
		return true;
	}
	
	/**
	 * OVERRIDDEN: Build Final Body and attachments
	 *
	 * @access	private
	 * @return	void
	 */
	function _build_message()
	{
		$has_embeded_image = $this->embed_images();		
		//if($has_embeded_image == true) log_info("EMAIL HAS EMBEDDED IMAGES");
			
		if ($this->wordwrap === TRUE  AND  $this->mailtype != 'html')
		{
			$this->_body = $this->word_wrap($this->_body);
		}

		$this->_set_boundaries();
		$this->_write_headers();

		$hdr = ($this->_get_protocol() == 'mail') ? $this->newline : '';

		switch ($this->_get_content_type())
		{
			case 'plain' :

				$hdr .= "Content-Type: text/plain; charset=" . $this->charset . $this->newline;
				$hdr .= "Content-Transfer-Encoding: " . $this->_get_encoding();

				if ($this->_get_protocol() == 'mail')
				{
					$this->_header_str .= $hdr;
					$this->_finalbody = $this->_body;

					return;
				}

				$hdr .= $this->newline . $this->newline . $this->_body;

				$this->_finalbody = $hdr;
				return;

			break;
			case 'html' :

				if ($this->send_multipart === FALSE)
				{
					$hdr .= "Content-Type: text/html; charset=" . $this->charset . $this->newline;
					$hdr .= "Content-Transfer-Encoding: quoted-printable";
				}
				else
				{
					$hdr .= "Content-Type: multipart/alternative; boundary=\"" . $this->_alt_boundary . "\"" . $this->newline . $this->newline;
					$hdr .= $this->_get_mime_message() . $this->newline . $this->newline;
					$hdr .= "--" . $this->_alt_boundary . $this->newline;
					
					$hdr .= "Content-Type: text/plain; charset=" . $this->charset . $this->newline;
					$hdr .= "Content-Transfer-Encoding: " . $this->_get_encoding() . $this->newline . $this->newline;
					$hdr .= $this->_get_alt_message() . $this->newline . $this->newline . "--" . $this->_alt_boundary . $this->newline;

					if($has_embeded_image == true)
					{						
						$hdr .= "Content-Type: multipart/related;" . $this->newline . " ";
 						$hdr .= "boundary=\"wrap\"". $this->newline . $this->newline;	
 						$hdr .= "--wrap" . $this->newline;					
					}
					
					$hdr .= "Content-Type: text/html; charset=" . $this->charset . $this->newline;
					$hdr .= "Content-Transfer-Encoding: quoted-printable";
				}

				$this->_body = $this->_prep_quoted_printable($this->_body);

				if ($this->_get_protocol() == 'mail')
				{
					$this->_header_str .= $hdr;
					$this->_finalbody = $this->_body . $this->newline . $this->newline;

					if ($this->send_multipart !== FALSE)
					{
						if($has_embeded_image == true) $this->_finalbody .= "--wrap--". $this->newline . $this->newline;
						$this->_finalbody .= "--" . $this->_alt_boundary . "--";
					}

					return;
				}

				$hdr .= $this->newline . $this->newline;
				$hdr .= $this->_body . $this->newline . $this->newline;

				if ($this->send_multipart !== FALSE)
				{
					if($has_embeded_image == true) $hdr .= "--wrap--". $this->newline . $this->newline;
					$hdr .= "--" . $this->_alt_boundary . "--";
				}

				$this->_finalbody = $hdr;
				return;

			break;
			case 'plain-attach' :

				$hdr .= "Content-Type: multipart/".$this->multipart."; boundary=\"" . $this->_atc_boundary."\"" . $this->newline . $this->newline;
				$hdr .= $this->_get_mime_message() . $this->newline . $this->newline;
				$hdr .= "--" . $this->_atc_boundary . $this->newline;

				$hdr .= "Content-Type: text/plain; charset=" . $this->charset . $this->newline;
				$hdr .= "Content-Transfer-Encoding: " . $this->_get_encoding();

				if ($this->_get_protocol() == 'mail')
				{
					$this->_header_str .= $hdr;

					$body  = $this->_body . $this->newline . $this->newline;
				}

				$hdr .= $this->newline . $this->newline;
				$hdr .= $this->_body . $this->newline . $this->newline;

			break;
			case 'html-attach' :

				$hdr .= "Content-Type: multipart/".$this->multipart."; boundary=\"" . $this->_atc_boundary."\"" . $this->newline . $this->newline;
				$hdr .= $this->_get_mime_message() . $this->newline . $this->newline;
				$hdr .= "--" . $this->_atc_boundary . $this->newline;

				$hdr .= "Content-Type: multipart/alternative; boundary=\"" . $this->_alt_boundary . "\"" . $this->newline .$this->newline;
				$hdr .= "--" . $this->_alt_boundary . $this->newline;

				$hdr .= "Content-Type: text/plain; charset=" . $this->charset . $this->newline;
				$hdr .= "Content-Transfer-Encoding: " . $this->_get_encoding() . $this->newline . $this->newline;
				$hdr .= $this->_get_alt_message() . $this->newline . $this->newline . "--" . $this->_alt_boundary . $this->newline;

				if($has_embeded_image == true)
				{						
					$hdr .= "Content-Type: multipart/related;" . $this->newline . " ";
 					$hdr .= "boundary=\"wrap\"". $this->newline . $this->newline;	
 					$hdr .= "--wrap" . $this->newline;					
				}
					
				$hdr .= "Content-Type: text/html; charset=" . $this->charset . $this->newline;
				$hdr .= "Content-Transfer-Encoding: quoted-printable";

				$this->_body = $this->_prep_quoted_printable($this->_body);

				if ($this->_get_protocol() == 'mail')
				{
					$this->_header_str .= $hdr;

					$body  = $this->_body . $this->newline . $this->newline;
					if($has_embeded_image == true) $body .= "--wrap--". $this->newline . $this->newline;
					$body .= "--" . $this->_alt_boundary . "--" . $this->newline . $this->newline;
				}

				$hdr .= $this->newline . $this->newline;
				$hdr .= $this->_body . $this->newline . $this->newline;
				if($has_embeded_image == true) $hdr .= "--wrap--". $this->newline . $this->newline;
				$hdr .= "--" . $this->_alt_boundary . "--" . $this->newline . $this->newline;

			break;
		}

		$attachment = array();

		$z = 0;

		for ($i=0; $i < count($this->_attach_name); $i++)
		{
			$filename = $this->_attach_name[$i];
			$basename = basename($filename);
			$ctype = $this->_attach_type[$i];

			if ( ! file_exists($filename))
			{
				$this->_set_error_message('email_attachment_missing', $filename);
				return FALSE;
			}

			$h  = "--".$this->_atc_boundary.$this->newline;
			$h .= "Content-type: ".$ctype."; ";
			$h .= "name=\"".$basename."\"".$this->newline;
			$h .= "Content-Disposition: ".$this->_attach_disp[$i].";".$this->newline;
			$h .= "Content-Transfer-Encoding: base64".$this->newline;

			$attachment[$z++] = $h;
			$file = filesize($filename) +1;

			if ( ! $fp = fopen($filename, FOPEN_READ))
			{
				$this->_set_error_message('email_attachment_unreadable', $filename);
				return FALSE;
			}

			$attachment[$z++] = chunk_split(base64_encode(fread($fp, $file)));
			fclose($fp);
		}

		if ($this->_get_protocol() == 'mail')
		{
			$this->_finalbody = $body . implode($this->newline, $attachment).$this->newline."--".$this->_atc_boundary."--";

			return;
		}

		$this->_finalbody = $hdr.implode($this->newline, $attachment).$this->newline."--".$this->_atc_boundary."--";

		return;
	}
  
	// --------------------------------------------------------------------

	/**
	 * OVERRIDDEN: Prep Quoted Printable
	 *
	 * Prepares string for Quoted-Printable Content-Transfer-Encoding
	 * Refer to RFC 2045 http://www.ietf.org/rfc/rfc2045.txt
	 *
	 * @access	private
	 * @param	string
	 * @param	integer
	 * @return	string
	 */
	function _prep_quoted_printable($str, $charlim = '')
	{		
		$matches_found = preg_match_all('/(\{embedded_image [^\}]*\})([^\}]*?)\{\/embedded_image\}/ms', $str, $matches);
		$has_embedded_image = ($matches_found !== false && $matches_found > 0);
				
		//
		// If there are any images embedded in the email's body, they cannot be prepped / escaped / changed in any way as they represent
		// encoded binary data. To prevent them from being escaped, they should be stripped out before parsing, and reinserted after. 
		//
		$embedded_images = array();		
		if($has_embedded_image == true)
		{	
			//
			// for each macro
			//	
			for($i = 0; $i < sizeof($matches[1]); $i++)
			{		
				//
				// Get the macro start tag (which at this stage should have been processed 
				// and stamped with an id) and the image data and store the image data in memory
				//
				$macro_start_tag = $matches[1][$i];
				$embedded_image_data = $matches[2][$i];
				$embedded_images["img$i"] = $embedded_image_data;				

				//log_info("Preseving for delimiting embedded_image: img$i ($macro_start_tag)");
				
				//
				// convert the found macro start tag to a regex expression
				//
				$macro_start_tag_regex = $this->change_string_to_regex($macro_start_tag);
				
				//
				// strip out the macro (and associated embedded data) and replace it with a placeholder '____undelimited_img[n]____'
				//				
				$str = preg_replace("/(.*)$macro_start_tag_regex.[^\}]*?{\/embedded_image\}(.*)/ms", "$1____undelimited_img".$i."____$2", $str);
			}
		}
		
		// Set the character limit
		// Don't allow over 76, as that will make servers and MUAs barf
		// all over quoted-printable data
		if ($charlim == '' OR $charlim > '76')
		{
			$charlim = '76';
		}

		// Reduce multiple spaces
		$str = preg_replace("| +|", " ", $str);

		// kill nulls
		$str = preg_replace('/\x00+/', '', $str);

		// Standardize newlines
		if (strpos($str, "\r") !== FALSE)
		{
			$str = str_replace(array("\r\n", "\r"), "\n", $str);
		}

		// We are intentionally wrapping so mail servers will encode characters
		// properly and MUAs will behave, so {unwrap} must go!
		$str = str_replace(array('{unwrap}', '{/unwrap}'), '', $str);

		// Break into an array of lines
		$lines = explode("\n", $str);

		$escape = '=';
		$output = '';

		foreach ($lines as $line)
		{
			$length = strlen($line);
			$temp = '';

			// Loop through each character in the line to add soft-wrap
			// characters at the end of a line " =\r\n" and add the newly
			// processed line(s) to the output (see comment on $crlf class property)
			for ($i = 0; $i < $length; $i++)
			{
				// Grab the next character
				$char = substr($line, $i, 1);
				$ascii = ord($char);

				// Convert spaces and tabs but only if it's the end of the line
				if ($i == ($length - 1))
				{
					$char = ($ascii == '32' OR $ascii == '9') ? $escape.sprintf('%02s', dechex($ascii)) : $char;
				}

				// encode = signs
				if ($ascii == '61')
				{
					$char = $escape.strtoupper(sprintf('%02s', dechex($ascii)));  // =3D
				}

				// If we're at the character limit, add the line to the output,
				// reset our temp variable, and keep on chuggin'
				if ((strlen($temp) + strlen($char)) >= $charlim)
				{
					$output .= $temp.$escape.$this->crlf;
					$temp = '';
				}

				// Add the character to our temporary line
				$temp .= $char;
			}

			// Add our completed line to the output
			$output .= $temp.$this->crlf;
		}

		// get rid of extra CRLF tacked onto the end
		$output = substr($output, 0, strlen($this->crlf) * -1);
		
		//
		// Now that the body has been parsed and delimited, re insert the embedded data
		//
		if($has_embedded_image == true)
		{
			foreach($embedded_images as $key=>$data)
			{
				//log_info("Reinstating embedded_image: $key");				
				$output = preg_replace("/(.*)____undelimited_".$key."____(.*)/ms", "$1$data$2", $output);	
			}				
		}
			
		return $output;
	}
	
}
