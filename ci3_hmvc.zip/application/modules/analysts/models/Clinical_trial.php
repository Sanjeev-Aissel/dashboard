<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for Clinical Trials from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 13-06-2018
 * @Refactored : 13-06-2018
 */
class clinical_trial extends CI_Model {
	
	function getClinicalTrialsUnprocessedKols(){
		$arrKolDetails=array();
		$this->db->where('(is_clinical_trial_processed = 0 or is_clinical_trial_processed is null)','',false);
		$this->db->where('kols.status',PROFILING);
		$this->db->order_by("created_on", "asc");
		$arrKolDetailResult=$this->db->get('kols');
		foreach($arrKolDetailResult->result_array() as $arrKol){
			$arrKolDetails[]= $arrKol;
		}
		return $arrKolDetails;
	}
	
	function getCTIDs($kolId){
		$arrCTIDs = array();
		$this->db->select('ctid');
		$this->db->where('kol_id',$kolId);
		$arrResults = $this->db->get('kol_ctids');
		foreach($arrResults->result_array() as $row){
			$arrCTIDs[] = $row['ctid'];
		}
	
		return $arrCTIDs;
	}
	
	function checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId){
		$arrCount=sizeof($arrUniqueCTIDs);
		for($i=0;$i<$arrCount; $i++){
			$nctId=$arrUniqueCTIDs[$i];
			$ctId=$this->checkClinicalTrialExist($nctId);
			if($ctId!=''){
				$kolClinicalTrial=array();
				$kolClinicalTrial['kol_id']=$kolId;
				$kolClinicalTrial['cts_id']=$ctId;
				//	$kolClinicalTrial['is_deleted']=0;
				//Save the association only if it is not exist
				if(!$this->checkKolCTAssociationExist($kolClinicalTrial)){
					$isSaved=$this->saveKolClinicalTrials($kolClinicalTrial);
				}
				unset($arrUniqueCTIDs[$i]);
			}
		}
		$arrUniqueCTIDs=array_values($arrUniqueCTIDs);
		//pr($arrUniqueCTIDs);
		return $arrUniqueCTIDs;
	}
	
	/**
	 * Saves the array of Sponsers one by one
	 * @param Array $arrSponsers
	 * @param Integer $ctId
	 * @return boolean
	 */
	function saveSponsers($arrSponsers, $ctId){
		$isSaved=false;
		foreach($arrSponsers as $sponser){
			if(!isset($sponser['type']) || empty($sponser['type'])){
				$sponser['type']	= 'lead sponsor';
			}
			$sponserId=$this->saveSponser($sponser);
				
			$ctSponcer=array();
			$ctSponcer['cts_id']=$ctId;
			$ctSponcer['sponser_id']=$sponserId;
				
			$isSaved=$this->saveCtSponser($ctSponcer);
		}
		return $isSaved;
	}
	
	function saveInvestigators($arrInvestigators, $ctId){
		$isSaved=false;
		foreach($arrInvestigators as $investigator){
			$investigatorId=$this->saveInvestigator($investigator);
				
			$ctInvestigator=array();
			$ctInvestigator['cts_id']=$ctId;
			$ctInvestigator['investigator_id']=$investigatorId;
				
			$isSaved=$this->saveCtInvestigator($ctInvestigator);
		}
		return $isSaved;
	}
	
	function updateClinicalTrialProcessedKol($arrKolDetail){
		$kolDetail['is_clinical_trial_processed']=	$arrKolDetail['is_clinical_trial_processed'];
		$this->db->where('id', $arrKolDetail['id']);
		$this->db->update('kols', $kolDetail);
	}
	
	function saveKeyword($keyword){
		$keywordId='';
		$this->db->select('id');
		$this->db->where('name',$keyword['name']);
		$resultSet	= $this->db->get('cts_keywords');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$keywordId	= $ctObj->id;
		}else if($this->db->insert('cts_keywords',$keyword)){
			$keywordId=$this->db->insert_id();
		}else{
	
		}
		return $keywordId;
	}
	
	/**
	 * Saves the record to associate the Keyword to Clinical Trial
	 * @param Array $ctKeyword, Array containing the Clinical Trial to Keyword association
	 * @return boolean
	 */
	function saveCtKeyword($ctKeyword){
		$this->db->select('id');
		$this->db->where('cts_id',$ctKeyword['cts_id']);
		$this->db->where('keyword_id',$ctKeyword['keyword_id']);
		$resultSet	= $this->db->get('ct_keywords');
	
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('ct_keywords',$ctKeyword)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Keyword to Clinical Trial',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_KEYWORDS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Keyword to Clinical Trial',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_KEYWORDS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return false;
		}
	}
	
	/**
	 * Saves the Meshterms record and returns the id of last inserted record
	 * @param  Array $meshterms, which contains the Meshterms details
	 * @return Integer $meshtermId
	 */
	function saveMeshterms($meshterms){
		$meshtermId	= '';
		$this->db->select('id');
		$this->db->where('term_name',$meshterms['term_name']);
		$this->db->where('type',$meshterms['type']);
		$resultSet	= $this->db->get('cts_mesh_terms');
		if($resultSet->num_rows()>0){
			$ctObj=$resultSet->first_row();
			$meshtermId	= $ctObj->id;
		}else {
			if($this->db->insert('cts_mesh_terms',$meshterms)){
				$meshtermId	= $this->db->insert_id();
			}
		}
		return $meshtermId;
	}
	
	/**
	 * Saves the record to associate the Meshterms to Clinical Trial
	 * @param Array $ctMeshterms, Array containing the Clinical Trial to $ctMeshterms association
	 * @return boolean
	 */
	function saveCtMeshterms($ctMeshterms){
		$this->db->select('id');
		$this->db->where('cts_id',$ctMeshterms['cts_id']);
		$this->db->where('term_id',$ctMeshterms['term_id']);
		$resultSet	= $this->db->get('ct_mesh_terms');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('ct_mesh_terms',$ctMeshterms)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Meshterms to Clinical Trial',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_MESH_TERMS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add the record to associate the Meshterms to Clinical Trial',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'transaction_table_id' => CT_MESH_TERMS,
					'transaction_name' => ADD_RECORD,
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true );
			return false;
		}
	}
	
	function listClinicalTrialsDetailsByType($kolId,$type = null,$ctsId = null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id','client_users.first_name','client_users.last_name','kol_clinical_trials.data_type_indicator'));
		$this->db->from('clinical_trials');
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->join('client_users', 'client_users.id = kol_clinical_trials.user_id','left');
		$this->db->where('kol_id', $kolId);
		if($ctsId != 0){
			$this->db->where('clinical_trials.id', $ctsId);
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
		$arrClinicalTrialsResult = $this->db->get();
		// 		echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
			$arrClinicalTrials[]=$row;
		}
		return 	$arrClinicalTrials;
	}
}
?>