<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jquery_validator/css/screen.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>datepicker/css/ui.daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jquery_validator/dist/jquery.validate.js"></script>
<?php
$queued_js_scripts = array('js/jquery.autocomplete',		
							'datepicker/js/daterangepicker.jQuery',
							'datepicker/js/date',		
							'alerts/jquery.alerts',
							'modules/interactions/js/add_interactions'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style>
.input_with_microview{
    display: inline-grid;
    width: 93%;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
     border-top:0px solid #ddd; 
}
</style>
<?php
$interactionKolAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$interaction_id=$this->uri->segment(6);
$interaction_for=$this->uri->segment(4);
?>
<div class="panel panel-info">
	<div class="panel-heading align_center">
		<?php if($interactionDetails!= null){echo 'Edit Interaction Details';}else{echo 'Record New Interaction';}?>
	</div>
	<div class="panel-body">
	<div class="row alert alert-success" id="responseMessageOfSaveInteraction" role="alert" style="display:none"></div>
		<form action="" id="interactionForm" name="interactionForm" method="post" enctype="multipart/form-data">	
			<input type="hidden" name="interaction_id" value="<?php echo $interaction_id;?>">
			<input type="hidden" name="interaction_for" value="<?php echo $interaction_for;?>">
			<!-- -------------------------------------Interaction Details starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Interaction Details:</div>
			  <div class="panel-body">
					<div class="row_padding">
					<div class="form-group row">
						<label class="col-sm-2 col-form-label">Interaction Date:<span class="required">*</span></label>
						<div class="col-sm-2">
				    		<input type="text" class="form-control" name="interaction_date"	value="<?php $this->load->model('common_helper');
									if ($interactionDetails != null && $interactionDetails ['date'] != '0000-00-00')
										echo $this->common_helper->convertDateToMM_DD_YYYY ( $interactionDetails ['date'] );
									?>"
									id="date" class="required maxPastDateValidate"/>
				    	</div>
				    	<label class="col-sm-2 col-form-label">Interaction Location:</label>
						<div class="col-sm-2">
							<select class="form-control" name="location_category" id="location_category" data-toggle="tooltip" title="In Office">
			                    <?php	foreach ( $locationType as $key => $value ){
										$selected = '';
										if ($key == $interactionDetails ['location_category']) {
											echo '<option value="' . $key . '" selected="selected">' . $value . '</option>';
										} else {
											echo '<option value="' . $key . '">' . $value . '</option>';
										}
								}?> 
							</select>
				    	</div>
				    	<label class="col-sm-2 col-form-label">Plan Name:</label>
						<div class="col-sm-2">
							<select name="plan_id" class="form-control">
								<option value=''>Select Plan</option>
			                    <?php foreach ($plans as $key => $value ) {
									$selected = '';
									if ($key == $interactionDetails ['plan_name']) {
										echo '<option value="' . $key . '" selected="">' . $value . '</option>';
									} else {
										echo '<option value="' . $key . '">' . $value . '</option>';
									}
								}
								?> 
							</select>
				    	</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 col-form-label">Interaction Type:<span class="required">*</span></label>
						<div class="col-sm-2">
				    		<select name="mode" id="mode" class="required form-control"	data-toggle="tooltip"	title="Face to Face">
									<?php foreach($arrModes as $mode){ //if($mode['id'] == 2){ continue;}?>
										<option value="<?php echo $mode['id'];?>"
												<?php if($interactionDetails!=null) if($mode['id']==$interactionDetails['mode']) echo 'SELECTED';?>>
											<?php echo $mode['name'];?>
										</option>
									<?php }?>
							</select>
				    	</div>
				    	<label class="col-sm-2 col-form-label">Interaction Category:<span class="required">*</span></label>
						<div class="col-sm-2">
							<select name="grouping" id="grouping" class="required form-control"	onchange="restrictAttendees(this);" data-toggle="tooltip"	title="One-on-One">
									<?php foreach($arrGroupings as $row){?>
										<option value="<?php echo $row['id'];?>"
												<?php if($interactionDetails!=null) if($row['id']==$interactionDetails['grouping']) echo 'SELECTED';?>>
											<?php echo $row['name'];?>
										</option>
									<?php }?>
								</select>
				    	</div>
				    	<label class="col-sm-2 col-form-label">Number of Attendees:<span class="required">*</span></label>
						<div class="col-sm-2">
							<input type="text" name="total_attendies" value="<?php if($interactionDetails!=null){echo $interactionDetails['total_attendies'];}else{echo '1';}?>" id="anttendies" class="required number form-control"/>
				    	</div>
					</div>	
				</div>
			  </div>
			</div>
			<!-- -------------------------------------Interaction Details ends------------------------------------------------------ -->
			<!-- -------------------------------------Discussion Topics ends------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Discussion Topic:</div>
			  <div class="panel-body">
				  	<div class="form-group row">
					<div class="col-sm-12">
					<table class="table" id="objectiveTable">
						<tr>
							<td width="5%">
							</td>
							<td width="30%" align="center">
								<label>Indication:<span class="required">*</span></label>
							</td>
							<td width="30%" align="center">
								<label>Discussion Type:<span class="required">*</span></label>
							</td>
							<td width="30%" align="center">
								<label>Topic:<span class="required">*</span></label>
							</td>
							<td width="5%" class="TextAlignCenter">
								<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add" title="Add" onclick="addMoreObjectives();return false;">
							</td>
						</tr>
						<input type="hidden" id="noOfObjectives" value="0" name="noOfObjectives"/>
						<?php if($interactionDetails==''){?>
						<tr class="trobjective" id="tr_objective">
							<td>
								<span class="is_primary">&nbsp;</span>	
							</td>
							<td>
								<div class="col-sm-10">
									<select name="product[]" id="product" class="form-control required" onchange="resetDropDowns(this);" data-toggle="tooltip" title="Select">
										<option value="">Select</option>
										<?php foreach($arrProduct as $row){?>
											<option value="<?php echo $row['id'];?>"
												<?php if($interactionDetails!=null) if($row['id']==$interactionDetails['type_id']) echo 'SELECTED';?>>
												<?php echo $row['name'];?>
											</option>
										<?php }?>
									</select>
								</div>
								<div class="col-sm-2">
								</div>
							</td>
							<td>
								<div class="col-sm-10">
									<select name="objective[]" id="objective" onchange="getTopic(this)" class="form-control required typeSelectBox" data-toggle="tooltip" title="Select">
										<option value="">Select</option>
									</select>
								</div>
								<div class="col-sm-2">
									<img id="loaderType" src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display:none"/>
								</div>
							</td>
							<td>
								<div class="col-sm-10">
									<select name="topic[]" id="new_topic" class="form-control required" data-toggle="tooltip" title="Select">
											<option value="">Select</option>
									</select>
								</div>
								<div class="col-sm-2">
									<img id="loadingTopic"	src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display:none"/>
								</div>
							</td>
							<td style="vertical-align: middle;">
								<!--<img src="<?php echo base_url().ASSETS;?>/images/delete_active.png" alt="Delete" title="Delete" onclick="deleteRow(this)">-->
							</td>
						</tr>
					<?php }else{?>
					<?php 
					$objectiveNo = 0;//pr($arrDiscussion);
					foreach ($arrDiscussion as $topicKey => $arrDiscussionData ){?>
						<tr class="trobjective" id="tr_objective_<?php echo $arrDiscussionData['row']['id']?>">
							<td class="align_center">
								<?php if($objectiveNo == 0){?>
									<span class="is_primary">&nbsp;</span>
								<?php }?>
							</td>
							<td>
							<div class="col-sm-10">
								<select name="product[]"
										id="product<?php echo $objectiveNo;?>"
										onchange="resetDropDowns(this)" class="form-control required"
										data-toggle="tooltip" title="Select">
										<option value="">Select</option>	
									<?php foreach($arrDiscussionData['arrProducts'] as $product){?>
										<option value="<?php echo $product['id'];?>"
											<?php  if($product['id']==$arrDiscussionData['row']['product_id']) echo 'SELECTED';?>>
											<?php echo $product['name'];?>
										</option>
									<?php }?>
								</select> 
								</div>
								<div class="col-sm-2">
								</div>
							</td>
							<td>
								<div class="col-sm-10">
									<select name="objective[]"
										id="objective<?php echo $objectiveNo;?>"
										onchange="getTopic(this)" class="form-control required typeSelectBox"
										data-toggle="tooltip" title="Select">
										<option value="">Select</option>	
									<?php  foreach($arrDiscussionData['arrTypes'] as $key=>$objective){?>
										<option value="<?php echo $objective['id'];?>"
											<?php if($objective['id']==$arrDiscussionData['row']['interaction_type']) echo 'SELECTED';?>>
											<?php echo $objective['name']?>
										</option>
									<?php }?>
									</select>
								</div>
								<div class="col-sm-2">
									<img id="loaderType" src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display:none"/>
								</div>
							</td>
							<td>
								<div class="col-sm-10">
								<select name="topic[]"
										id="new_topic<?php echo $objectiveNo?>"
										class="form-control required"
										data-toggle="tooltip" title="Select">
										<option value="">Select</option>	
									<?php foreach($arrDiscussionData['arrTopics'] as $key=>$value){?>
										<option value="<?php echo $value['id'];?>"
											<?php  if($value['id']==$arrDiscussionData['row']['topic_id']) echo 'SELECTED';?>>
											<?php echo $value['name'];?>
										</option>
									<?php }?>
								</select> 
								</div>
								<div class="col-sm-2">
									<img id="loadingTopic"	src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display:none"/>
								</div>
							</td>
							<td style="vertical-align: middle;">
								<?php if($objectiveNo >0){?>
									<img src="<?php echo base_url().ASSETS;?>/images/delete_active.png" alt="Delete" title="Delete" onclick="deleteRow(this)">
								<?php }?>
							</td>
						</tr>
			        <?php $objectiveNo++;
					}
					}?>
						</table>
			    	</div>
				</div>
			  </div>
			</div>
			<!-- -------------------------------------Discussion Topics ends------------------------------------------------------ -->
			<!-- -------------------------------------Attendees starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Attendees:</div>
			  <div class="panel-body">
			    <table id="kolsTable" class="table">
					<tr>
						<th class="align_center">
							<label>
								<?php if($interactionFor == 'org'){?>
									KOL / Key People Name
								<?php }else{?>
								KOL Name
								<?php }?>
								<span class="required">*</span>
							</label>
						</th>
						<th class="align_center" style="display: none;">Status</th>
						<?php if($interactionFor == 'org'){?>
						<th class="align_center">Title</th>
						<?php }else{?>
						<th class="align_center">Specialty</th>
						<th class="align_center">Title</th>
						<?php }?>
						<th>&nbsp;</th>
					</tr>
					<!-- 	//////////////////////////////////while adding new interaction//////////////////////////////-->
						<?php if($interactionDetails==''){ ?>
							<input type="hidden" id="noOfKols" value="1" name="noOfKols" />
							<?php if($interactionFor == 'org'){?>
								<input type="hidden" id="orgWithinID" value="<?php echo $kolId;?>" name="org_within_id"/> 
							<?php }?>
							<tr class="kols" id="tr_kols_0">
								<td class="align_center">
									<div id="pkolName">
										<input type="hidden" name="kol_id" value="<?php echo $kolId;?>"	id="kolId" class="test">
										<?php if($interactionFor == 'org'){?>
											<input type="hidden" name="kol_id" value="" id="kolId" class="test"/>
											<input type="hidden" name="attendee_type[]" value="" id="attendeeType1"/>
											<input type="hidden" name="attendee_types[]" value="" id="attendeeTypes1"/>
											<input type="hidden" name="kol_name_auto[]" value="" id="kolNameAuto1" class="checkAboveInputValue"/>
											<input type="hidden" name="kol_id_auto[]" value="" id="kolIdAuto1"/>
											<input type="text" name="kol_name[]" value="" id="kolName" class="form-control autocompleteInputBox required test1"/>
										<?php }else{?>
											<input type="hidden" name="kol_name_auto[]"	value="<?php echo $arrKolDetails['first_name']." ".$arrKolDetails['middle_name']." ".$arrKolDetails['last_name'];?>" id="kolNameAuto" class="checkAboveInputValue"/>
											<input type="hidden" name="kol_id_auto[]" value="<?php echo $kolId;?>" id="kolIdAuto" class="selectedKolId"/> 
											<input type="text" name="kol_name[]" value="<?php echo $this->common_helper->get_name_format($arrKolDetails['first_name'],$arrKolDetails['middle_name'],$arrKolDetails['last_name']);?>" id="kolName" readonly="readonly" class="form-control required input_with_microview test1"/>
											<img class="image" src="<?php echo base_url().ASSETS;?>/images/microview_inactive.png" title="KOL Profile Snapshot" alt="profile"	onclick="viewKolMicroProfile(this,'<?php echo $kolId;?>')"/>									
										<?php }?>
									</div>
								</td>
								<?php if($interactionFor == 'org'){?>
									<td class="align_center">
										<input type="text" class="form-control" readonly="readonly" name="last_interaction" id="last_interaction" value="<?php echo $kolTitle;?>" />
									</td>
								<?php }else{?>
									<td class="align_center">
										<input class="form-control" type="text" readonly="readonly" name="therapeutic_area" value="<?php echo $kolSpecialty1;?>" />
									</td>
									<td class="align_center">
										<input type="text" class="form-control" readonly="readonly" name="last_interaction" id="last_interaction" value="<?php echo $kolTitle;?>" />
									</td>
								<?php }?>
								<td>
									<label>
										<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add" title="Add"  onclick="addMoreKolsDiv();return false;"/>
									</label>
								</td>
							</tr>
							<!--  //////////////////////////////////edit interaction form//////////////////////////////-->
						<?php }else{?>
									<!-- ///set hidden fields-->
									<?php if($interactionFor != 'org'){?>
										<input type="hidden" id="noOfKols"	value="<?php echo sizeof($interactionDetails['attendees']['kol_names']);?>" name="noOfKols"/>
									<?php }else{ ?>
										<input type="hidden" id="noOfKols"	value="<?php echo sizeOf( $interactionDetails ['attendies']);?>" name="noOfKols"/>
										<input type="hidden" id="orgWithinID" value="<?php echo $kolId1;?>" name="org_within_id"/>
									<?php } ?>	
									
					    			<?php
					    			
									$no = '';
									$noOrg = 1;
									$arr = array ();
									if($interactionFor != 'org'){
										if (sizeOf ( $interactionDetails ['attendies'] ) > 1) {
											foreach ( $interactionDetails ['attendies'] as $id => $value ) {
												if ($value ['kol_id'] == $kolId) {
													$arr = $interactionDetails ['attendies'] [$id];
													unset ( $interactionDetails ['attendies'] [$id] );
													break;
												}
											}
											$interactionDetails ['attendies'] [] = $arr;
											$interactionDetails ['attendies'] = array_reverse ( $interactionDetails ['attendies']);
										}
									}									
								foreach ( $interactionDetails['attendies'] as $key1 => $kols ){?>
								<tr class="kols" id="tr_kols_<?php echo $kols['id'];?>">
									<input type="hidden" name="kol_id" value="<?php echo $kolId1;?>" id="kolId" />
									<td class="align_center">
										<div id="kolName" style="display:-webkit-inline-box;">
										
										<?php if($kols['org_id'] != null && $kols['org_id'] != ''){?>
												<?php if ($kols['kol_id']!=''){?>
													<input type="hidden" name="kol_name_auto[]" value="<?php echo $kols['first_name'].' '.$kols['middle_name'].' '.$kols['last_name'];?>" id="kolNameAuto<?php echo $noOrg?>" class="checkAboveInputValue"/>
													<input type="hidden" name="attendee_type[]" value="<?php echo $kols['attType'];?>" id="attendeeType<?php echo $noOrg?>"/>
													<input type="hidden" name="attendee_types[]" value="<?php echo $kols['attType'];?>" id="attendeeTypes<?php echo $noOrg?>"/>
													<input type="hidden" name="kol_id_auto[]" value="<?php echo $kols['kol_id'];?>" id="kolIdAuto<?php echo $noOrg?>" class="selectedKolId"/>
													<input type="text" name="kol_name[]" value="<?php echo $this->common_helper->get_name_format($kols['first_name'],$kols['middle_name'],$kols['last_name']);?>" id="kolName<?php echo $noOrg?>" readonly="readonly" class="form-control required test1"/> 
												<?php }else{?>
													<input type="hidden" name="kol_name_auto[]" value="<?php echo $kols['key_fn'].' '.$kols['key_mn'].' '.$kols['key_ln'];?>" id="kolNameAuto<?php echo $noOrg?>" class="checkAboveInputValue"/> 
													<input type="hidden" name="attendee_type[]" value="<?php echo $kols['attType'];?>" id="attendeeType<?php echo $noOrg?>"/>
													<input type="hidden" name="attendee_types[]" value="<?php echo $kols['attType'];?>" id="attendeeTypes<?php echo $noOrg?>"/>
													<input type="hidden" name="kol_id_auto[]" value="<?php echo $kols['key_id'];?>" id="kolIdAuto<?php echo $noOrg?>" class="selectedKolId"/>
													<input type="text" name="kol_name[]" value="<?php echo $this->common_helper->get_name_format($kols['key_fn'],$kols['key_mn'],$kols['key_ln']);?>" id="kolName<?php echo $noOrg?>" readonly="readonly" class="form-control required test1"/> 
												<?php }?>
										<?php }else{ ?>
											<?php foreach($arrKolDetails as $kolDetails){?> 
												<?php if ($kolDetails['id']==$kols['kol_id']){?>
													<input type="hidden" name="kol_name_auto[]" value="<?php echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>" id="kolNameAuto<?php echo $no?>" class="checkAboveInputValue"/>
													<input type="hidden" name="kol_id_auto[]"	value="<?php echo $kolDetails['id'];?>" id="kolIdAuto<?php echo $no?>" class="selectedKolId"/>
													<input type="text" class="form-control required test1" name="kol_name[]" id="kolName<?php echo $no;?>" value="<?php echo $this->common_helper->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);?>" <?php if($key1==0) echo "readonly=''readonly";?>/> 
													<img class="image"	src="<?php echo base_url().ASSETS;?>/images/microview_inactive.png"	title="KOL Profile Snapshot" alt="profile"	onclick="viewKolMicroProfile(this,'<?php echo $kolDetails['id'];?>')"/>
												<?php }?>
											<?php }?>
										<?php }?>
										</div>
									</td>
									<?php if($kols['org_id'] != null && $kols['org_id'] != ''){?>
											<?php if ($kols['kol_id']!=''){?>
												<td class="align_center">
													<input type="text" class="form-control" readonly="readonly" name="last_interaction"	id="last_interaction" value="<?php echo $kols['title'];?>" />
												</td>
											<?php }else{?>
												<td class="align_center">
													<input type="text" class="form-control" readonly="readonly" name="last_interaction" id="last_interaction" value="<?php echo $kols['key_title'];?>" />
												</td>
											<?php }?>
									<?php }else {?>
										<td class="align_center">
											<input class="form-control" type="text" readonly="readonly" name="therapeutic_area"	value="<?php echo $kols['specialty'];?>" />
										</td>
										<td class="align_center">
											<input type="text" class="form-control" readonly="readonly" name="last_interaction" id="last_interaction" value="<?php echo $kols['title'];?>" />
										</td>
									<?php }?>
									
									<td class="TextAlignLeft">
										<?php if($key1==0){?>
												<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add" title="Add"  onclick="addMoreKolsDiv();return false;"/>
										<?php }else{?>
												<img src="<?php echo base_url().ASSETS;?>/images/delete_active.png" alt="Delete" title="Delete" onclick="deleteRow(this)">
										<?php }?>
									</td>
								</tr>
						<?php	$no ++;
								$noOrg ++;
							}
						 }?>
						 <!-- //////////////////////////////////edit interaction form ends//////////////////////////////-->
					</tr>
				</table>
			  </div>
			</div>
			<!-- -------------------------------------Attendees ends------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Location:</div>
			  <div class="panel-body">
			    <table class="table">
					<tr>
						<td width="5%"></td>
						<td>
							<table class="table">
								<tr>
									<th></th>
									<th>Location</th>
									<th>Address</th>
									<th>Country</th>
									<th>State</th>
									<th>City</th>
								</tr>
								<?php
									$isChecked = 0;
									if (isset($kolLocations )) {
										foreach ( $kolLocations as $key => $row ) {
												$selectedLocation = '';
												if ($interactionDetails ['location_type'] == $row ['id'] && $row ["location"] == 'Primary') {
													$selectedLocation = ' checked="checked"';
													$isChecked = 1;
												}
												if (! isset ( $interactionDetails ['location_type'] ) && $row ["location"] == 'Primary') {
													$selectedLocation = ' checked="checked"';
													$isChecked = 1;
												}
												?>
										<tr>
											<td>
												<input type="radio" name="selectedLocation" value="<?php echo $row['id'];?>"
												<?php echo $selectedLocation;?> />
											</td>
											<?php
											echo '<td>' . $row ['location'] . '</td>';
											echo '<td>' . $row ['address'] . '</td>';
											echo '<td>' . $row ['country'] . '</td>';
											echo '<td>' . $row ['state'] . '</td>';
											echo '<td>' . $row ['city'] . '</td>';?>
										</tr>
				                    <?php }
									}
								?>
							</table>
						</td>
					</tr>
					<tr>
						<td></td>
						<td><div class="caption">other:</div></td>
					</tr>
					<tr>
						<td></td>
						<td>
							<table class="table">
								<tr>
									<td rowspan="3">
										<input type="radio" name="selectedLocation" value="0" 
										<?php if (isset($interactionDetails['location_type']) && ($interactionDetails['location_type']) == 0) {
												echo ' checked="checked"';
											}?>/>
									</td>
									<th class="align_right">
										<label>Address1:</label>
									</th>
									<td>
										<input name="address1" type="text" class="form-control"
										value="<?php echo (isset($interactionDetails['address'])?$interactionDetails['address']:'');?>"/>
									</td>
									<th class="align_right">
										<label>Country:</label>
									</th>
									<td>
										<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="form-control" data-toggle="tooltip" title="Select">
											<option value="">-- Select Country --</option>
			                                <?php if ($interactionDetails['country_id'] == "") {
									         foreach ( $arrCountry as $country ) {?>
			                                <option value="<?php echo  $country['country_id']; ?>">
			                                	<?php echo  $country['country_name']; ?>
			                                </option>
		                                    <?php }
											} else {
												 foreach ( $arrCountry as $country ) {
													   $selected = '';
													   if ($country['country_id'] == $interactionDetails['country_id']) {?>
													   	<option value="<?php echo $country ['country_id'];?>" <?php if($interactionDetails['location_type'] == 0){echo 'selected="selected"';} ?>>
													   		<?php echo $country ['country_name'];?>
													   	</option>
				        							<?php } else {
				        									echo '<option value="' . $country ['country_id'] . '">' . $country ['country_name'] . '</option>';
				        								}
												     }?>                 
		                                	<?php } ?>     				
										</select>
									</td>
										</tr>
										<tr>
											<th class="align_right">
												<label>Address2:</label>
											</th>
											<td>
												<input name="address2" type="text" class="form-control"
												value="<?php if($interactionDetails['location_type']==0 && isset($interactionDetails['address2'])){echo $interactionDetails['address2']; }//echo (isset($interactionDetails['address2'])?$interactionDetails['address2']:'');?>" /></td>
											<th class="align_right">
												<label>State:</label>
											</th>
											<td>
												<select name="state" id="state_id" class="form-control"
												onchange="getCitiesByStateId();" data-toggle="tooltip" title="Select">
													<option value="">-- Select State --</option>
													<?php
													foreach ( $arrStates as $key => $row ) {
														$selected = '';
														if ($interactionDetails ['state_id'] == $row ['state_id']) {
															$selected = ' selected="selected"';
														}
														echo '<option value="' . $row ['state_id'] . '"' . $selected . '>' . $row ['state_name'] . '</option>';
													}
													?>
												</select> 
												<img id="loadingStates" src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display:none" />
											</td>
										</tr>
										<tr>
											<th class="align_right">
												<label>Postal Code:</label>
											</th>
											<td>
												<input name="postal_code" type="text" id="postal_code" class="form-control"
												value="<?php echo (isset($interactionDetails['postal_code'])?$interactionDetails['postal_code']:'');?>"/>
											</td>
											<th class="align_right">
												<label>City:</label>
											</th>
											<td>
												<select name="city" id="city_id" data-toggle="tooltip" class="form-control"
												title="Select">
													<option value="">-- Select City --</option>
													<?php
													if (isset ( $arrCities )) {
														foreach ( $arrCities as $key => $row ) {
															$selected = '';
															if ($interactionDetails ['city_id'] == $row ['city_id']) {
																$selected = ' selected="selected"';
															}
															echo '<option value="' . $row ['city_id'] . '"' . $selected . '>' . $row ['city_name'] . '</option>';
														}
													}
													?>
												</select>
												<img id="loadingCities" src="<?php echo base_url().ASSETS;?>/images/ajax_loader_black.gif" style="display: none" />
											</td>
											<td></td>
										</tr>
									</table>
						</td>
					</tr>
					</table>
			  </div>
			</div>
			<!-- -------------------------------------Non-Profiled Attendees starts------------------------------------------------------ -->
			<div id="nonProfiledkolsTable">
				<div class="panel panel-default">
				  <div class="panel-heading">Non-Profiled Attendees:</div>
				  <div class="panel-body">
				   <table class="table">
					<tr>
						<th class="align_center"><label for=therapeuticArea>Attendee Name</label></th>
						<th class="align_center"><label for=therapeuticArea>Specialty</label></th>
						<th class="align_center"><label for=therapeuticArea>Comments</label></th>
						<th>&nbsp;</th>
					</tr>
					<?php if(count($interactionDetails['otherAttendisData']) > 0){ ?>
						<input type="hidden" id="noOfNonProfiledKols" value="<?php echo count($interactionDetails['otherAttendisData']); ?>" name="noOfNonProfiledKols"/>
					<?php $otherAttendisObj = '';
						foreach ( $interactionDetails ['otherAttendisData'] as $key1 => $otherAttendis ) {?>
						<tr class="nonProfiledKols"  id="tr_nonProfiledKols_<?php echo $otherAttendis['id'];?>">
								<td class="align_center">
									<input type="text" class="form-control"
										name="non_profiled_kol[]"
										id="non_profiled_kol<?php echo $otherAttendisObj?>"
										value="<?php echo $otherAttendis['name'];?>">
								</td>
								<td class="align_center">
									<select class="form-control"
										name="non_profifled_specialty[]"
										id="non_profifled_specialty<?php echo $otherAttendisObj?>"
										data-toggle="tooltip" title="Select">
											<option>Select Specialty</option>
										<?php foreach ($arrSpecialties as $key => $specialty){ ?>
			                                <option	value="<?php echo $key; ?>"
												<?php if ($otherAttendis ['specialty_id'] == $key) {
													echo "selected='selected'";
												}
												?>>
											<?php echo $specialty; ?>
										</option>
										<?php }?>
									</select>
								</td>
								<td class="align_center">
									<textarea cols="" rows="2" class="form-control"
											name="non_profiled_comment[]"
											id="non_profiled_comment<?php echo $otherAttendisObj?>"><?php echo $otherAttendis['comments'];?></textarea>
								</td>
								<td class="TextAlignCenter">
								<?php if($key1==0){?>
									<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add"
										title="Add" onclick="addMoreNonAttendeeKols();return false;"/>
								<?php }else{?>
									<img src="<?php echo base_url().ASSETS;?>/images/delete_active.png"
										alt="Delete" title="Delete" onclick="deleteRow(this)">
								<?php }?>
							</td>
							</tr>
							<?php $otherAttendisObj ++;
								}
							} else {
								?>
						<input type="hidden" id="noOfNonProfiledKols" value="0"	name="noOfNonProfiledKols"/>
							<tr class="nonProfiledKols"  id='tr_nonProfiledKols_0'>
								<td class="align_center">
									<input class="form-control" type="text" name="non_profiled_kol[]" id="non_profiled_kol">
								</td>
								<td class="align_center">
									<select name="non_profifled_specialty[]" class="form-control"
										id="non_profifled_specialty" data-toggle="tooltip" title="Select">
											<option>Select Specialty</option>
										<?php foreach ($arrSpecialties as $key => $specialty){ ?>
										<option value="<?php echo $key;?>"><?php echo $specialty;?></option>
										<?php }?>
									</select>
								</td>
								<td class="align_center">
									<textarea class="form-control" cols="" rows="2" name="non_profiled_comment[]" id="non_profiled_comment"></textarea>
								</td>
								<td class="TextAlignCenter">
								<?php if($key1==0){?>
									<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add"
										title="Add" onclick="addMoreNonAttendeeKols();return false;"/>
								<?php }else{?>
									<img src="<?php echo base_url().ASSETS;?>/images/delete_active.png"
										alt="Delete" title="Delete" onclick="deleteRow(this)">
								<?php }?>
							</td>
							</tr>
					<?php }?>
						</table>
				  </div>
				</div>
			</div>	
			<!-- -------------------------------------Non-Profiled Attendees ends------------------------------------------------------ -->
			<!-- -------------------------------------Attach documents starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Attach Document(s):</div>
			  <div class="panel-body">
			    <table id="fileUploadContainer"	class="highlightHeadings table">
					<input type="hidden" name="no_of_files" id="noOfFiles" value="1" />
					<tr>
						<th class="align_center"><label>Document Name</label></th>
						<th class="align_center"><label>Description</label></th>
						<th class="align_center"><label>File</label></th>
						<th>&nbsp;</th>
					</tr>
					<?php if(isset($arrDocs) && sizeof($arrDocs)>=1){?>
						<div id="docsList">
							<?php foreach($arrDocs as $doc){?>
							 	<tr id="doc<?php echo $doc['id'];?>">
									<td>
										<span>
											<a href="<?php echo base_url(); ?>interactions/interactions/download_doc/<?php echo $doc['id']; ?>">
											<?php if($doc ['name'] != '')
												echo $doc ['name'];
											else
												echo 'File' . $doc ['name'];
											?>
											</a>
										</span>
									</td>
									<td>
										<span><?php echo $doc['description'];?></span>
									</td>
									<td>
										<a onclick="deleteDocument(<?php echo $doc['id'];?>);">
										remove</a>
									</td>
									<td></td>
								</tr>
							<?php }?>
						</div>
					<?php }?>
					<tr id="docContainer1">
						<td><input type="text" name="doc_name[]" id="docName1" class="form-control"/></td>
						<td><input type="text" name="doc_description[]" id="description1" class="form-control"/></td>
						<td><input type="file" name="int_ref_file[]" id="intRefFile1" class="form-control"/></td>
						<td>
							<label id="addMoreFile" onclick="addMoreFile();return false;">
								<img src="<?php echo base_url().ASSETS;?>/images/add_active.png" alt="Add" title="Add" />
							</label>
						</td>
					</tr>
				</table>
			  </div>
			</div>
			<!-- -------------------------------------Attach documents Ends------------------------------------------------------ -->
			<!-- -------------------------------------Notes section starts------------------------------------------------------ -->
			<div class="panel panel-default">
			  <div class="panel-heading">Notes:</div>
			  <div class="panel-body">
			   	<div class="form-group row row-padding">
					<div class="col-sm-12">
					<?php $notes = '';
						$ncount = 200;
						if ($interactionDetails != null) {
							$notes = $interactionDetails ['notes'];
							$ncount = 200 - strlen ( $notes );
						}
						?>
						<textarea onKeyDown="limitText(this,'notesCountDown',200);"
									onKeyUp="limitText(this,'notesCountDown',200);" class="form-control" name="notes" id="notes"><?php  echo $notes;?></textarea>
						<div>
							You have <span id="notesCountDown"><?php echo $ncount;?></span>
							characters left. <font size="1">(Maximum characters: 200)</font>
						</div>
			    	</div>
				</div>
			  </div>
			</div>
			<!-- -------------------------------------Notes section ends------------------------------------------------------ -->
			<div style="text-align: center;">
				<a type="button" class="btn custom-btn" onclick="return validateAndSubmitInteractionForm();" id="saveInteraction" title="Save Interaction">
					Save
				</a>
				<a type="button" class="btn custom-btn" onclick="goBack();return false;">
					Cancel
				</a>
			</div>
		</form>
	</div>
</div>

<script>
var interaction_id='<?php echo $interactionDetails['id']?>';
var globalId='';
var kolAutoCompleteId ='';
var orgId = '<?php echo  $this->uri->segment(5);?>';

<?php if($interactionFor == 'org') { ?>
		var interactionKolAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>interactions/interactions/get_all_kol_org_names_for_autocomplete/1/1/'+orgId,
					<?php echo $interactionKolAutoCompleteOptions;?>,
					onSelect : function(event, ui) {
						var selText = $(event).children('.organizations').html();
						var selId = $(event).children('.organizations').attr('name');
						specType = $(event).children('.organizations').attr('type');
						selText=selText.replace(/\&amp;/g,'&');
						console.log(globalId);
						console.log(kolId);
						console.log(specType);
						$('#'+globalId).val(selText);
						$('#'+globalId).prev('input').prev('input').val(selText);
						$('#'+globalId).prev('input').val(selId);
						$('#'+globalId).next('img').show().attr('onclick','showMicroProfileOrg("'+selId+'")');
						getKolOtherDetails();
					 }
		};
	<?php }else{ ?>
		var interactionKolAutoCompleteOptions = {
				<?php 
		        if(KOL_CONSENT){ ?>
				serviceUrl: '<?php echo base_url();?>kols/kols/get_kol_names_for_all_autocomplete/1/1',
				<?php } else {?>
				serviceUrl: '<?php echo base_url();?>kols/kols/get_kol_names_for_all_autocomplete/1',
				<?php }?>
				<?php echo $interactionKolAutoCompleteOptions;?>,
				onSelect : function(event, ui) {
					var kolId = $(event).children('.id1').html();
					var selText = $(event).children('.kolName').html();
					selText=selText.replace(/\&amp;/g,'&');
					$('#'+globalId).val(selText);
					$('#'+globalId).prev('input').prev('input').val(selText);
					$('#'+globalId).prev('input').val(kolId);
					$('#'+globalId).next('img').show().attr('onclick','viewKolMicroProfile(this,"'+kolId+'")');
					getKolOtherDetails();
				 }
			};
	<?php } ?>
var interactionKolAutoComplete	= $('#kolName').autocomplete(interactionKolAutoCompleteOptions);
<?php if($interactionDetails!=''){?>
	var noOfKols = $('#noOfKols').val();
	for(var i=1;i<=noOfKols;i++){
		var interactionKolAutoComplete	= $('#kolName'+i).autocomplete(interactionKolAutoCompleteOptions);
	}
<?php }?>

var maxPastDate = new Date();
maxPastDate.setMonth(maxPastDate.getMonth()-1);
var maxPastDate = new Date();
maxPastDate.setMonth(maxPastDate.getMonth()-1);

 jQuery.validator.addMethod("maxPastDateValidate",
         function (value, element, params) {
             var curDate = maxPastDate;
             curDate.setHours(00);
             curDate.setMinutes(00);
             curDate.setSeconds(00);
             //alert('hi');
             var inputDate = new Date(value);
             if(inputDate.toString() == curDate.toString())
                 return true;
             if (inputDate >= curDate)
                 return true;
             return false;
         }, 'Past Dates not allowed');


$('#date').datepicker({
	changeMonth: true,
    changeYear: true,
	dateFormat: 'mm/dd/yy',
	maxDate:new Date(),
	minDate: maxPastDate
});


$(document).ready(function (){
	$("#interactionForm").validate();
	if(interaction_id>0){
		$("#date").datepicker();
	}else{
		$("#date").datepicker().datepicker("setDate",new Date());
	}
	
	$(".test1").live("focus",function(){
		 kolAutoCompleteId = $(this).attr('id');
		 globalId = $(this).attr('id');
		 $(this).parent().children("label.error").remove();
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
	});
});
function addMoreFile(){
	var noOfFiles=0;
	noOfFiles=$("#noOfFiles").val();
	noOfFiles++;
	var newUpload	= "<tr id=docContainer"+noOfFiles+"><td><input class='form-control' type='text' name='doc_name[]' id=docName"+noOfFiles+" /></td><td><input class='form-control' type='text' name='doc_description[]' id=description"+noOfFiles+" /></td><td><input class='form-control' type='file' name='int_ref_file[]' id=intRefFile"+noOfFiles+" /></td><td class=TextAlignCenter><label onclick='cancelFileUpload("+noOfFiles+");'><img src='<?php echo base_url().ASSETS;?>/images/delete_active.png' alt='Delete' title='Delete'/></label></td></tr>";
	$("#fileUploadContainer").append(newUpload);
	$("#noOfFiles").val(noOfFiles);
}
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		$('#'+limitCount).html(limitNum - limitField.value.length);
	}
}
function restrictAttendees(thisObj){
	if($(thisObj).val()!=1){
		$('#addMoreKols').show();
		$("#nonProfiledkolsTable").show(); 
	}else{
		$('#addMoreKols').hide();
		$("#nonProfiledkolsTable").hide(); 
	}
}
function resetDropDowns(proObject){
	getTypeByProduct(proObject);
	var typeId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
	var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
	$('#'+topicId+" option").remove();
	$('#interactionForm select#' + typeId + ' option').remove();
	$('select#' + typeId).append('<option value="">Select</option>');
	$('#'+topicId).append('<option value="">Select</option>');
	var typeObject = $(proObject).parent().parent().parent().find('td').eq(2).find('select');
}
function getTypeByProduct(proObject) {
	productid = $(proObject).val();
    var typeId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
    $('#' + typeId).parent().parent().find("#loaderType").show();
	$.ajax({
            url: '<?php echo base_url() ?>interactions/interactions/get_type_by_product/' + productid,
           	type: 'POST',
           	dataType: 'JSON',
           	success: function (returnData){
	                    $('select #' + typeId + ' option').remove();
	                    $('select #' + typeId).append('<option value="">Select</option>');
	                    for (var result in returnData) {
	                    $('#objectiveTable select#' + typeId).append($("<option></option>")
	                            .attr("value", returnData[result].id)
	                            .text(returnData[result].name));
	      		}
	        	$('#' + typeId).parent().parent().find("#loaderType").hide();
           }
	});
	return true;
}
function getTopic(proObject){
	var groupId =  $('#grouping').val();
	var productId =  $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
 	var typeId = $(proObject).val();
	var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
	if(typeId == "" || productId == ""){
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
	}else{
		$('#'+topicId).parent().parent().find("#loadingTopic").show();
		$.ajax({
				url:'<?php echo base_url()?>interactions/interactions/get_topic_by_type/'+typeId+'/'+productId,
			dataType:'json',
			success:function(returndata){
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				// .each loops through the array
	              for (var result in returndata.arrTopics) {
	                   $('#'+topicId).append("<option  id='" + returndata.arrTopics[result].id + "' value='" + returndata.arrTopics[result].id + "'>" + returndata.arrTopics[result].name + "</option>");
	              }
			},
			complete:function(){
				$('#'+topicId).parent().parent().find("#loadingTopic").hide();
				}
		});
	}
}
function addMoreObjectives(){
	var kolSHtml = 	$('.trobjective').html();
	var noOfFields = parseInt($('#noOfObjectives').val())+1;
	$('#noOfObjectives').val(noOfFields);
	
	$('#objectiveTable').append("<tr class='trobjective' id='tr_objective_0'>"+kolSHtml+"</tr>");
	$('#objectiveTable tr:last td:eq(0)').html('');
	var order = 'product'+noOfFields;
// 	$('#objectiveTable tr:last td:eq(1) select').attr('name',order);
	$('#objectiveTable tr:last td:eq(1) select').attr('id',order);
	var selProduct = $('#'+order+' option:selected').val();
	$("#"+order+" option[value='"+selProduct+"']").removeAttr('selected', false);
	$('#objectiveTable tr:last td:eq(1) select option:first').attr('selected','selected').val('').text('Select');
	$('#objectiveTable tr:last td:eq(1) .is_primary').remove();
	
	var objectFieldName = 'objective'+noOfFields;
	$('#objectiveTable tr:last td:eq(2) select').attr('id',objectFieldName);
	var selObject = $('#'+objectFieldName+' option:selected').val();
	$("#"+objectFieldName+" option[value='"+selObject+"']").removeAttr('selected', false);
	$('#objectiveTable tr:last td:eq(2) select option:first').attr('selected','selected').val('').text('Select');
	$('#objectiveTable tr:last td:eq(2) select').find("option:gt(0)").remove();
	
	var topic = 'topic'+noOfFields;
	$('#objectiveTable tr:last td:eq(3) select').attr('id',topic);
	$('#objectiveTable tr:last td:eq(3) select option:first').attr('selected','selected').val('').text('Select');
	$('#objectiveTable tr:last td:eq(3) select').find("option:gt(0)").remove();

	$('#objectiveTable tr td:last').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>assets/images/delete_active.png' onclick='deleteRow(this)'>");
	
}
function deleteRow(thisObj){
	var rowId = $(thisObj).parent().parent().attr('id');
	console.log(thisObj);
	console.log(rowId);
	var rowIdElements = rowId.split("_");
	console.log(rowIdElements[2]);
	if(rowIdElements[2]>0){
		jConfirm("Are you sure you want to delete the selected row?",'Please Confirm',function(r){
        	if (r == true) {                      
        		$.ajax({
        			url:'<?php echo base_url();?>interactions/interactions/delete_interaction_row/'+rowIdElements[1]+'/'+rowIdElements[2],
        			dataType:'json',
        			success:function(returnData){
        				if(returnData.status==true){
        					$(thisObj).parent().parent().remove();
        					return false;
        				}
        			}
        		});
             }
		});
	}else{
		$(thisObj).parent().parent().remove();
		return false;
	}
}
//deletes the document with given document id
function deleteDocument(documentId){
	$.ajax({
		url:'<?php echo base_url();?>interactions/interactions/delete_document/'+documentId,
		dataType:'json',
		success:function(returnData){
			if(returnData==true)
				$("#doc"+documentId).remove();
		}
	});
}
function cancelFileUpload(fileNumber){
	$('#docContainer'+fileNumber).remove();
}
function addMoreNonAttendeeKols(){
	var kolSHtml = 	$('.nonProfiledKols').html();
	$('#nonProfiledkolsTable .table').append("<tr class='nonProfiledKols' id='tr_nonProfiledKols_0'>"+kolSHtml+"</tr>");
	var noofKols = $('#noOfNonProfiledKols').val();
	var noOfFields = parseInt(noofKols)+1;
	$('#noOfNonProfiledKols').val(noOfFields);
	
	var non_profiled_kol = 'non_profiled_kol'+noOfFields;
// 	$('#nonProfiledkolsTable tr:last td:eq(0) input').attr('name',non_profiled_kol);
	$('#nonProfiledkolsTable tr:last td:eq(0) input').attr('id',non_profiled_kol).val('');

	var non_profifled_specialty = 'non_profifled_specialty'+noOfFields;
// 	$('#nonProfiledkolsTable tr:last td:eq(1) select').attr('name',non_profifled_specialty);
	$('#nonProfiledkolsTable tr:last td:eq(1) select').attr('id',non_profifled_specialty);
	$("#nonProfiledkolsTable tr:last td:eq(1) select option").prop("selected", false);
	$("#nonProfiledkolsTable tr:last td:eq(1) select").val(0).click();
	
	var non_profiled_comment = 'non_profiled_comment'+noOfFields;
// 	$('#nonProfiledkolsTable tr:last td:eq(2) textarea').attr('name',non_profiled_comment);
	$('#nonProfiledkolsTable tr:last td:eq(2) textarea').attr('id',non_profiled_comment).val('');

	$('#nonProfiledkolsTable tr:last td:eq(3)').html("<img title='Delete' alt='Delete' src='<?php echo base_url().ASSETS;?>/images/delete_active.png' onclick='deleteRow(this)'>");

}
function addMoreKolsDiv(){
	var kolSHtml = 	$('.kols').html();
	var noofKols = $('#noOfKols').val();
	var numRows = $('#noOfKols').parent().children().length;
	var grouppping = $("#interactionForm #grouping").val();
	if(grouppping == 1 && numRows > 2){
		jAlert("You can only enter 1 for a One-to-One interaction");
		return false;
	}
	$('#kolsTable').append("<tr class='kols' id='tr_kols_0'>"+kolSHtml+"</tr>");
	var noOfFields = parseInt(noofKols)+1;
	$('#noOfKols').val(noOfFields);
	var kolFieldName = 'kol_name[]';
	var kolFieldId = 'kolName'+noOfFields;
	$('#kolsTable tr:last td:eq(0) input:last').removeAttr('readonly');
	$('#kolsTable tr:last td:eq(0) input:last').val('');
	$('#kolsTable tr:last td:eq(0) input:last').attr('name',kolFieldName);
	$('#kolsTable tr:last td:eq(0) input:last').attr('id',kolFieldId);
	$('#kolsTable tr:last td:eq(0) input:last').addClass('autocompleteInputBox');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').prev('input').attr('id','attendeeType'+noOfFields).val('');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').prev('input').attr('name','attendee_type[]');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').attr('id','attendeeTypes'+noOfFields).val('');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').prev('input').attr('name','attendee_types[]');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('id','kolNameAuto'+noOfFields).val('');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('name','kol_name_auto[]');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('name','kol_id_auto[]');
	$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('id','kolIdAuto'+noOfFields).val('');
	//Hide the image
	$('#kolsTable tr:last td:eq(0) input:last').next('img').hide();
	$('#kolsTable tr:last td:eq(0) input:last').next('img').removeAttr('onClick');
	
	<?php if($interactionFor =='org'){?>
		var last_interaction = 'last_interaction'+noOfFields;
		$('#kolsTable tr:last td:eq(1) input').attr('name',last_interaction);
		$('#kolsTable tr:last td:eq(1) input').attr('id',last_interaction).val('');
	<?php }else{ ?>
		var therapeutic_area = 'therapeutic_area'+noOfFields;
		$('#kolsTable tr:last td:eq(1) input').attr('name',therapeutic_area);
		$('#kolsTable tr:last td:eq(1) input').attr('id',therapeutic_area).val('');
		
		var last_interaction = 'last_interaction'+noOfFields;
		$('#kolsTable tr:last td:eq(2) input').attr('name',last_interaction);
		$('#kolsTable tr:last td:eq(2) input').attr('id',last_interaction).val('');
		<?php } ?>
	var interactionKolAutoComplete	= $('#'+kolFieldId).autocomplete(interactionKolAutoCompleteOptions);
	<?php if($interactionFor =='org'){?>
		$('#kolsTable tr:last td:eq(2)').html("<img title='Delete' alt='Delete' src='<?php echo base_url().ASSETS;?>/images/delete_active.png' onclick='deleteRow(this)'>");
	<?php }else{?>
		$('#kolsTable tr:last td:eq(3)').html("<img title='Delete' alt='Delete' src='<?php echo base_url().ASSETS;?>/images/delete_active.png' onclick='deleteRow(this)'>");
	<?php } ?>	
}
function getKolOtherDetails(){
	var kolId	= $("#"+kolAutoCompleteId).prev().val();
	var kolName=$("#"+kolAutoCompleteId).val();
	var data = {};
	data['kol_name'] = kolName;
	if(!kolId){
		kolId = '<?php echo $kolId;?>';
	}
	var otherDetailsUrl = '<?php echo base_url()?>kols/kols/get_kol_other_details/'+kolId;
	<?php if($interactionFor =='org'){?>
	if(specType=='key'){
		otherDetailsUrl = '<?php echo base_url()?>interactions/interactions/get_key_people_details/'+kolId;
	}else{
		otherDetailsUrl = '<?php echo base_url()?>kols/kols/get_kol_other_details/'+kolId;
	}
	<?php }?>
	
	if(kolName!=''){
		$.ajax({
			url:otherDetailsUrl,
			type:'post',
			data:data,
			dataType:"json",
			success:function(returndData){
				var speccialtyId=returndData.specialtyId;
				var specialtyName=returndData.specialtyName;
				var last_interaction=returndData.title;
				<?php if($interactionFor =='org'){?>
				if(specType=='key'){
					$('#'+globalId).prev('input').prev('input').prev('input').val('key_type');
					$('#'+globalId).prev('input').prev('input').prev('input').prev('input').val('key_type');
				}else{
					$('#'+globalId).prev('input').prev('input').prev('input').val('kol_type');
					$('#'+globalId).prev('input').prev('input').prev('input').prev('input').val('kol_type');
				}
					$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(1).find('input').val(last_interaction);
				<?php }else{ ?>
				console.log(kolAutoCompleteId);
					$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(1).find('input').val(specialtyName);
					$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(2).find('input').val(last_interaction);
				<?php } ?>
				
			}
		});
	}else{
		$("#therapeuticArea").val("");
	}
}
function getStatesByCountryId(){
	// Show the Loading Image
	$("#loadingStates").show();
	$("#postal_code").parent().find("label.error").remove();
	var countryId=$('#country_id').val();
	var params = "country_id="+countryId;	
	$("#state_id").html("<option value=''>-- Select State --</option>");
	$("#city_id").html("<option value=''>-- Select City --</option>");
	var states = document.getElementById('state_id');
	$.ajax({
		url: "<?php echo base_url()?>helpers/country_helpers/get_states_by_countryid/",
		dataType: "json",
		data: params,
		type: "POST",
		success: function(responseText){					
			$.each(responseText, function(key, value) {					
				var newState = document.createElement('option');
				newState.text = value.state_name;
				newState.value = value.state_id;
				 var prev = states.options[states.selectedIndex];
				 states.add(newState, prev);				
				});
			var lastOPtion = $('#state_id option:last').val();
			if(lastOPtion==''){
				$('#state_id option:last').remove();
				$('#state_id').prepend("<option value='' selected='selected'>-- Select State --</option>");
			}
		},
		complete: function(){
			$("#loadingStates").hide();
		}
	});	
}
function getCitiesByStateId(){
	// Show the Loading Image
	$("#loadingCities").show();
	$("#postal_code").parent().find("label.error").remove();
	var stateId=$('#state_id').val();
	$("#city_id").html("<option value=''>Select City</option>");	
	var cities = document.getElementById('city_id');
	var params = "state_id="+stateId;	
	if(stateId == ''){
		$("#loadingCities").hide();
		return false;
	}
	$.ajax({
		url: "<?php echo base_url()?>helpers/country_helpers/get_cities_by_stateid/",
		dataType: "json",
		data: params,
		type: "POST",
		success: function(responseText){					
			$.each(responseText, function(key, value) {	
						
			var newCity = document.createElement('option');
			newCity.text = value.city_name;
			newCity.value = value.city_id;
			 var prev = cities.options[cities.selectedIndex];
			 cities.add(newCity, prev);				
			});
                            $("#city_id option[value='']").remove();
                $("#city_id").prepend("<option value=''>-- Select City --</option>");
                $("#city_id").val("");
			
		},
		complete: function(){
			$("#loadingCities").hide();
		}		
	});		
}
//Validates the interaction form using jquery plugin
function validateAndSubmitInteractionForm(){
	//$("#saveInteraction").hide();
	$("#interactionForm label.error").remove();
// 	$.each($('.checkAboveInputValue'),function(){
// 		var kolName =$(this).val();
// 		var  mainkol=$(this).next('input').next('input').val();
// 		if(kolName != mainkol){
// 			$(this).next('input').val('');
// 		}
// 	});
	if(!$("#interactionForm").validate({
		  rules: {
		    field: {
		      required: true,
		      maxlength: 4
		    },
		    date:{
				date:true,
				reqired:true,
		    }
		  }
		}).form()){
		$('html, body').animate({
            scrollTop: $("#interactionForm .error").first().offset().top-30
        });
		 $("#interactionForm .error").first().focus();
		$("#saveInteraction").show();
		return false;
	}else{
		var value = $("#date").val();
		$("#date").next().remove();
		 var curDate = maxPastDate;
             curDate.setHours(00);
             curDate.setMinutes(00);
             curDate.setSeconds(00);
             var inputDate = new Date(value);
             if(inputDate.toString() == curDate.toString()){
	             	return true;
             }                     
             if(inputDate <= curDate){
                 $("#date").parent().append('<label for="date" generated="true" class="error">Past date not allowed, Max 30 days.</label>');
                 $("#saveInteraction").show();
                 return false;
             }
             curDate = new Date();
             curDate.setHours(00);
             curDate.setMinutes(00);
             curDate.setSeconds(00);
             var inputDate = new Date(value);
             if(inputDate > curDate){
                 $("#date").parent().append('<label for="date" generated="true" class="error">Future date not allowed.</label>');
                 $("#saveInteraction").show();
                 return false;
             }
			
			var form = $('#interactionForm')[0];
			var data = new FormData(form);
		      $.ajax({
		   	  url:'<?php echo base_url();?>interactions/interactions/save_interaction',
		        type: "POST",
		        data:  new FormData(form),
		        dataType:'json',
		        enctype: 'multipart/form-data',
		        processData: false,  // Important!
		        contentType: false,
		        cache: false,
		        success:function(returnData){ 
		        		$('#responseMessageOfSaveInteraction').show();
		            	if(returnData.status==true){
		            		$('#responseMessageOfSaveInteraction').addClass("alert-success");
		            	}else{
		            		$('#responseMessageOfSaveInteraction').addClass("alert-danger");
		            	}
		        		$('html, body').animate({
		                    scrollTop: $("#responseMessageOfSaveInteraction").first().offset().top-20
		                });
		            	$('#responseMessageOfSaveInteraction').html(returnData.message);
				 	},
		        error: function (jqXHR, textStatus, errorThrown)
		        {
		            alert('Error in adding / update data');
		        }
		    });
		}
}
</script>