<?php
/**
*Description:
*
*Created by:Developer
*
*Created on:Dec 13, 2010
*/?>
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
<script>
var validationRules	=  {
		name: {
			required:true
		}
	};

var validationMessages = {
	name: {
			required: "Required"
	}
};

$(document).ready(function(){
	$("#saveAbout").click(function(){
		saveOrganization();
	});
});

/* 
 function saveOrganization(){
	if(!$("#organizationForm").validate().form()){
		return false;
	}
	var formAction = '<?php echo base_url();?>analysts/organizations/save_organization';
	
	$.ajax({
		type: "post",
		dataType: "json",
		data: $("#organizationForm").serialize(),
		url: formAction,
		success: function(returnData){
			if(returnData.saved == true){
				
			}else{
			
			}
		},
		complete: function(){
			
		}
	});
};
*/
</script>
<div class="container" style="margin-top:20px;">
	<div class="col-md-8 col-md-offset-2">
		<div class="panel panel-default"> 
			 <div class="panel-heading"> <h3 class="panel-title">Add New Organization Profile</h3> </div> 
			 <div id="editKolForm" class="panel-body">
			     <form action="save_organization" method="post" id="organizationForm" name="organizationForm" class="validateForm form-horizontal">      
			            <div class="form-group">
							<div class="col-md-4">
								<label class="control-label">Profile Type <span class="required">*</span> :</label>
								<select name="profile_type" id="profile_type" class="form-control required">
									<option value="Basic">Basic</option>
									<option value="Full Profile">Full Profile</option>
				    			</select>
							</div>
						</div>
		                <div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Name <span class="required">*</span> :</label>
								<input type="text" name="name" value="<?php echo $arrOrganization['name'];?>" id="orgName" maxlength="100" class="form-control required"/>
								<input type="hidden" name="org_id" id="orgId" value="<?php echo $arrOrganization['id'];?>"></input>
							</div>
							<div class="col-md-6">
								<label class="control-label">Type :</label>
								<select name="type_id" id="orgType" class="form-control required">
								<option value="0">--- Select ---</option>
								<?php 
								foreach($arrOrganizationTypes as $key => $value){
								if($key == $arrOrganization['type_id'])
									echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
								else
									echo '<option value="'.$key.'">'.$value.'</option>';
								}
								?>
						    	</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Founded :</label>
								<input type="text" name="founded" id="orgFounded" class="form-control required gray">
								</div>
							<div class="col-md-6">
								<label class="control-label">Website :</label>
								<input type="text"  name="website" id="orgWebsite" class="url form-control gray">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label class="control-label">Company Headquarters :</label>
								<input type="text" name="headquarters" id="orgHeadquarters" class="form-control required gray">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<label class="control-label">Products & Services :</label>
								<textarea class="form-control" rows="2" cols="3"></textarea>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<label class="control-label">Company Background :</label>
								<textarea class="form-control" rows="2" cols="3"></textarea>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<label class="control-label">Mission, Vision & Values :</label>
								<textarea class="form-control" rows="2" cols="3"></textarea>
							</div>
						</div>
						<div style="text-align: center;">
							<button type="button" name="submit" id="saveAbout" class="btn btn-primary pull-center"><span class="glyphicon glyphicon-save"></span> Save</button>
						</div>
			        </form>
			  </div> 
		</div>
	</div>
</div>
					<!-- End of Personal and Professional Information -->