<?php
/**
*File To Know Basics.
*Created By:
*Created On:10:06:33 AM
*/
	$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	$autoApproveRequest	= IS_APPROVER;
 ?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	.gridWrapper {
		width: 98%;
	}
	
	#myPendingApprovalsResultSet_cb{
		vertical-align: top;
	}
	#rejectBox span{
		color: black;
	    font-size: 12px;
	}
	#rejectBox label{
		font-size: 13px !important;
	}
	#rejectBox textarea{
		width: 90%;
	}
	#rejectBox input{
		float: right;
   		margin-right: 35px;
	}
	.approve-reject{
		float: left;
   		margin-left: 5px;
	}
	.approve{
		background-attachment: scroll;
	    background-clip: border-box;
	    background-color: transparent;
	    background-image: url("<?php echo base_url()?>images/right_blue.svg");
	    background-origin: padding-box;
	    background-position: 0 6px;
	    background-repeat: no-repeat;
	    height: 29px;
	    width: 22px;
	    margin-top: -3px;
	}
	.reject{
		background-attachment: scroll;
	    background-clip: border-box;
	    background-color: transparent;
	    background-image: url("<?php echo base_url()?>images/deny_red.svg");
	    background-origin: padding-box;
	    background-position: 0 6px;
	    background-repeat: no-repeat;
	    height: 29px;
	    width: 22px;
	    margin-top: -3px;
	}
	.title-bar-actions .approve-button, .title-bar-actions .reject-button{
		padding-bottom: 2px;
	}
	#allOrgRequestsGridContainer{
		margin-top:20px;
	}
	.gridWrapper .ui-jqgrid tr.jqgrow td{
		padding: 2px 2px 2px 4px !important;
	}
	.title-bar-actions{
		float:right;
		margin-right: 19px;
	}
	.title-bar-actions .sprite_iconSet{
		float:right;
		margin-left: 0;
	}
	.title-bar-actions .blueButton{
		/*background: none no-repeat scroll left center #BBBBBB;
	    border-color: #8A8A8A !important;*/
	    margin-left: 5px;
	}
	.reasonContent{
		height: 79px !important;
		width:350px;
	}
	.title-bar-actions .approve-button{
		background-image: url("<?php echo base_url()?>images/right_white.svg");
		background-position: 3px 3px;
	    background-repeat: no-repeat;
	    background-size: 17px auto;
	    padding-left: 23px;
	}
	.title-bar-actions .approve-button:HOVER{
		background-image: url("<?php echo base_url()?>images/right_blue.svg");
		background-position: 3px 3px;
	    background-repeat: no-repeat;
	    background-size: 17px auto;
	    padding-left: 23px;
	}
	.title-bar-actions .reject-button{
		background-image: url("<?php echo base_url()?>images/deny_red.svg");
		background-position: 3px 3px;
	    background-repeat: no-repeat;
	    background-size: 17px auto;
	    padding-left: 23px;
	}
	.title-bar-actions .reject-button:HOVER{
		background-image: url("<?php echo base_url()?>images/deny_red.svg");
		background-position: 3px 3px;
	    background-repeat: no-repeat;
	    background-size: 17px auto;
	    padding-left: 23px;
	}
	#cb_myPendingApprovalsResultSet{
		margin-left: 6px;
	}
</style>
<!--[if IE]>
<style type="text/css">
	#cb_myPendingApprovalsResultSet{
		margin-left: 3px;
	}
	#jqgh_myPendingApprovalsResultSet_rn{
		margin-right: -2px !important;
	}
</style>
<![endif]-->

<script type="text/javascript">
var urlFilters = null;
<?php if(isset($urlString)){?>
urlFilters = <?php echo $urlString ?>;
<?php }?>
var autoApproveRequest= '<?php echo $autoApproveRequest;?>';
var myPendingApprovalsTitle = "<?php echo lang("ProfileRequest.PendingApprovals");?>";
var statusHeader = "<?php echo lang("Overview.Status");?>";
var nameHeader = "<?php echo lang("Organizations.Name");?>";
var cityHeader = "<?php echo lang("Surveys.City");?>";
var stateHeader = "<?php echo lang("Surveys.State");?>";
var createdByHeader = "<?php echo lang("Surveys.CreatedBy");?>";
var actionHeader = "<?php echo lang("Overview.Action");?>";
var approverHeader = "<?php echo lang("ProfileRequest.Approver");?>";
var allOrgRequestTitle = "<?php echo lang("OrgProfileRequest.OrganizationRequests");?>";
jqgridIds	= new Array('myPendingApprovalsResultSet','allOrgRequestsResultSet');
jqgridMinWidth	= 1010;
jqgridMaxWidth	= 1305;
function myPendingApprovals(){
	$("#myPendingApprovals").html("");
	// Append the required div and table
	$("#myPendingApprovals").html('<table id="myPendingApprovalsResultSet"></table><div id="myPendingApprovalsPager"></div>');

	jQuery("#myPendingApprovalsResultSet").jqGrid({
	   	url:'<?php echo base_url()?>requested_orgs/list_my_pending_approvals/',
		datatype: "json",
		colNames:['Id','','','',statusHeader,nameHeader,cityHeader,stateHeader,createdByHeader,"Requested On","Approved / Rejected on",actionHeader,'',"approve_allow"],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'created_by',index:'created_by', hidden:true},
					{name:'org_id',index:'org_id', hidden:true},
					{name:'micro',index:'micro',width:30, search:false },
					<?php if($autoApproveRequest){?>
					{name:'status',index:'status',width:80, resizable:false},
					<?php }else{ ?>
					{name:'status',index:'status',width:100, resizable:false},
					<?php } ?>
					{name:'org_name',index:'org_name',width:190 },
					{name:'city',index:'city',width:100 },
					{name:'state',index:'state',width:220},
			   		{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
			   		{name:'requested_on',index:'requested_on',width:100 },
					{name:'rej_or_appr_on',index:'rej_or_appr_on',width:100 },
			   		{name:'act',resizable:true,search:false,width:100,align:'center',title:false},
					{name:'dAllowed',index:'dAllowed', hidden:true},
					{name:'approve_allow',index:'approve_allow', hidden:true}
	   	],
	   	rowNum:10,
	   	rownumbers: true,
		//rownumWidth: 60,
	   	<?php if($autoApproveRequest){?>
		multiselect: true,
		<?php } ?>
	   	autowidth: true, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#myPendingApprovalsPager',
	   	mtype: "POST",
	   	sortname: 'requested_on',
	    viewrecords: true,
	    sortorder: "desc",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:myPendingApprovalsTitle,
	   	rowList:paginationValues,
	    gridComplete: function(){
	    	/*$("#jqgh_rn").html("Select All");
		    $("#jqgh_cb").prepend("Select All");
		    $("#myPendingApprovalsResultSet").css("width","80px");
		   	$("#myPendingApprovalsResultSet tbody tr").children().first("td").css("width","80px");
		   	*/
			var userId = <?php echo $this->session->userdata('user_id')?>;
	   		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
		    	var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', ids[i]);
		    	var cl = rowData.id;
		    	if(autoApproveRequest){
					be = "<div class='tooltip-demo tooltop-left approve-reject'><a onclick='approveRequestedOrgs("+rowData.id+")' href='#' class='tooltipLink approve' rel='tooltip' title=\"Approve profile request\">&nbsp;</a></div> <div class='tooltip-demo tooltop-left approve-reject'><a onclick='showRejectBox("+rowData.id+")' href='#' class='tooltipLink reject' rel='tooltip' title=\"Reject profile request\">&nbsp;</a></div>";
		    		jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{act:be});
		    	}else{  
			    	if(rowData.dAllowed){
    		    		be = "<div style='margin-right: 10px;'><label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteRequsetedOrg('"+rowData.id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\">&nbsp;</a></div></label></div>";
    			    	//jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{act:be});
			    	}
			    }

				microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewOrgMicroProfile('"+rowData.org_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
	    	} 
    	jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','hideCol',"id"); 
    	//Initialize the tooltips
    	<?php $mobile = mobile_device_detect(); 
		if(!isset($mobile[1])){	?>			
			initializeCustomToolTips();
		<?php }?>
    	},
    	onSelectAll: function(aRowids,status) {
    		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    		
			    	var cl = ids[i];				    	
			    	var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', cl);
			    
			    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
						
			    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#myPendingApprovalsResultSet")[0]);
			                cbs.removeAttr("checked");

			                //modify the selarrrow parameter
			                jQuery("#myPendingApprovalsResultSet")[0].p.selarrrow = jQuery("#myPendingApprovalsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
			                    .map(function() { return this.id; }) // convert to set of ids
			                    .get(); // convert to instance of Array
					}
				
	    	} 

	          
        }
	});
	//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','#myPendingApprovalsPager',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#myPendingApprovalsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
		/*$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == 'Search')
				$(this).val("");
	    });*/
	},afterSearch:function(){
		/*$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == '')
				$(this).val("Search");
	    });*/
	}}); 

	if(autoApproveRequest){
   		$('#jqgh_myPendingApprovalsResultSet_rn').html('All');
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-right","-2px");
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-top","4px");
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("text-align","right");
   	}
   	
	//Add action button in the title bar
	if(autoApproveRequest){
		var buttonsText = "<div class='title-bar-actions'>";
			buttonsText += "<a class='blueButton approve-button' href='#' onclick='approveRequestedOrgs()' class='tooltipLink' rel='tooltip' title='Approve organization request(s)'>Approve</a>";
			buttonsText += "<a class='blueButton reject-button' href='#' onclick='showRejectBox()' class='tooltipLink' rel='tooltip' title='Reject organization request(s)'>Reject</a>";
			buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
			buttonsText += "</div>";
		$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText);
	}else{
		//Add action button in the title bar
		var buttonsText = "<div class='title-bar-actions'>";
			buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
			buttonsText += "</div>";
		$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText); 
	}
			
}

function allProfileRequests(){
	$("#allOrgRequests").html("");
	// Append the required div and table
	$("#allOrgRequests").html('<table id="allOrgRequestsResultSet"></table><div id="allOrgRequestsPager"></div>');

	jQuery("#allOrgRequestsResultSet").jqGrid({
	   	url:'<?php echo base_url()?>requested_orgs/list_all_profile_requests/',
		datatype: "json",
	 	colNames:['Id','','','',statusHeader,nameHeader,approverHeader,cityHeader,stateHeader,createdByHeader,'',"Requested On","Approved / Rejected On"],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'created_by',index:'created_by', hidden:true},
					{name:'org_id',index:'org_id', hidden:true},
					{name:'micro',index:'micro',width:30, search:false },
					{name:'status',index:'status',width:100, resizable:false,title: false},
					{name:'org_name',index:'org_name',width:190 },
					{name:'approved_by',index:'approved_by',width:100, resizable:false},
					{name:'city',index:'city',width:220},
					{name:'state',index:'state',width:100 },
					{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
					{name:'comments',index:'comments',width:100,hidden:true },
					{name:'requested_on',index:'requested_on',width:100 },
					{name:'rej_or_appr_on',index:'rej_or_appr_on',width:200 }
	   	],
	   	rowNum:10,
	   	rownumbers: true,
		//rownumWidth: 60,
		multiselect: false,
	   	autowidth: true, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#allOrgRequestsPager',
	   	mtype: "POST",
	   	sortname: 'requested_on',
	    viewrecords: true,
	    sortorder: "desc",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:allOrgRequestTitle,
	   	rowList:paginationValues,
	   	afterInsertRow: function(rowid, aData) {
		   	if(aData.status == 'Rejected'){
		   		jQuery("#allOrgRequestsResultSet").setCell(rowid, 'status', '', '',{ title: "Click to View Reason" });
		   		jQuery("#allOrgRequestsResultSet").setCell(rowid, 'status', '', '',{ onclick: "showRejectREason(this,'"+aData.comments+"');" });
		   	}
		   	else
	    		jQuery("#allOrgRequestsResultSet").setCell(rowid, 'status', '', '',{ title: aData.status });
	    },
	    gridComplete: function(){
	    	var ids = jQuery("#allOrgRequestsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
		    	var cl = ids[i];				    	
		    	var rowData = jQuery("#allOrgRequestsResultSet").jqGrid('getRowData', cl);
				    	
		    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewOrgMicroProfile('"+rowData.org_id+"',this,true); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#allOrgRequestsResultSet").jqGrid('setRowData',cl,{micro:microviewLink});
    		} 

	    	jQuery("#allOrgRequestsResultSet").jqGrid('navGrid','hideCol',"id"); 
	    	//Initialize the tooltips
	    	<?php $mobile = mobile_device_detect(); 
			if(!isset($mobile[1])){	?>			
				initializeCustomToolTips();
			<?php }?>
    	},
    	onSelectAll: function(aRowids,status) {
    		var ids = jQuery("#allOrgRequestsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    		
			    	var cl = ids[i];				    	
			    	var rowData = jQuery("#allOrgRequestsResultSet").jqGrid('getRowData', cl);
			    
			    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
						
			    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#allOrgRequestsResultSet")[0]);
			                cbs.removeAttr("checked");

			                //modify the selarrrow parameter
			                jQuery("#allOrgRequestsResultSet")[0].p.selarrrow = jQuery("#allOrgRequestsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
			                    .map(function() { return this.id; }) // convert to set of ids
			                    .get(); // convert to instance of Array
					}
				
	    	} 

	          
        }
	});
	//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#allOrgRequestsResultSet").jqGrid('navGrid','#allOrgRequestsPager',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#allOrgRequestsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
		$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == 'Search')
				$(this).val("");
	    });
	},afterSearch:function(){
		/*$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == '')
				$(this).val("Search");
	    });*/
	}});

	//Add action button in the title bar
	var buttonsText = "<div class='title-bar-actions'>";
		buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel(2)' >	<a rel='tooltip' href='#' title='Export'>&nbsp;</a>	</div>";
		buttonsText += "</div>";
	$("#allOrgRequestsGridContainer .ui-jqgrid-titlebar").append(buttonsText); 		
}

$(document).ready(function(){
	myPendingApprovals();
	allProfileRequests();
	var addNewOrg = {
			title: "Add KOL",
			modal: true,
			autoOpen: false,
			width: 450,
			draggable:false,
			position: ['center', modalBoxTopPosition],
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};

	$("#addNewOrg").dialog(addNewOrg);

	$(".ui-icon-closethick").click(function(){
		$("#addNewOrg").dialog('option','width',450);
	});

	if(urlFilters != null && urlFilters.ONAME != null){
		//alert(urlFilters);
		addNewOrgProfile();
		$("#addNewKol").css({"height":"auto"});
	}
	
});

function showRejectREason(thisEle,comments){
	var pos = getElementAbsolutePos(thisEle);

	var xPos=pos.x+23;
	var yPos=pos.y+170;
	var position = findPos(thisEle);
	$("#arraouHolder").css({'position': 'absolute','top':position[0]-57,'left':position[1]+13});
	$("#contentHolder").css({'position': 'absolute','top':position[0]-24,'left':position[1]+24});
	$("#arraouHolder").show();
	$("#contentHolder").show();
	$(".profileContent").html(comments);
	$("#contentHolder").addClass("reasonContent");
}

function addNewOrgProfile(){
	$(".addNewOrgContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#addNewOrg").dialog("open");
	$(".addNewOrgContent").load(base_url+'requested_orgs/add_client_org',{},function(){
		if(urlFilters != null){
			$(".msgBox").html("Organization you are looking for is not pressent in iProfile. Would you like to request for profile?");
			$("#name").val(urlFilters.ONAME);

			//$("input[value='Full Profile']").attr("checked","checked");
			urlFilters = null;
			
		}
	});
	return false;	
}

function approveRequestedOrgs(id){
	var arrIds = new Array();
	var arrOrgids = new Array();
	if(id == null){
		arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');
		$.each(arrIds, function( index, value ) {
			var arrRowData = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', value);
			arrOrgids.push(arrRowData.id);
		});
	}else{
		arrIds.push(id);
		arrOrgids.push(id);
	}

	if(arrIds == ''){
		jAlert("Please select at least one Organization")
		return false;
	}
	var data = {};
	data['arrIds'] = arrOrgids;

	jConfirm("The Organization Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed.",'Please Confirm',function(event){
		if(event){
			$('#listOrgsTbl').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$('#msg').removeClass('success');
			$('#msg').addClass('notice');
			$('#msg').show();

			$('#msg').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');
		
			$.ajax({
					url:'<?php echo base_url()?>requested_orgs/approve',
					type:'post',
					data:data,
					dataType:'json',
					success:function(returnData){
						$('#listOrgsTbl').unblock();
						$('#msg').fadeOut(1500);
						//myPendingApprovals();
						//allProfileRequests();
						var numberSelected = arrIds.length;
						for(i=0;i<numberSelected;i++){
							var id = arrIds[i];
							var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', id);
							rowData.status = 'Approved';
							rowData.approved_by = returnData.approved_by;

							var selectedOPtion = $(".ui-pg-selbox").val();
							$(".ui-pg-selbox option:last").attr('selected','selected');
					    	$('.ui-pg-selbox').trigger('change');

					    	var su=jQuery("#allOrgRequestsResultSet").jqGrid('setRowData',id,rowData);
							$('#myPendingApprovalsResultSet').jqGrid('delRowData',id); 
					    	
					    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
					    	$('.ui-pg-selbox').trigger('change');
					    	 
						}
					}

				});
	}else{
		return false;
		}
	});
		
}

function selectAll(thise){
	if($(thise).attr("checked")=='checked'){

		$.each($("input[name='org_id[]']"),function(){
			if($(this).attr('disabled')!='disabled')
			$(this).attr('checked','checked');
		});

	}else{
		$.each($("input[name='org_id[]']"),function(){
			$(this).removeAttr('checked','checked');
		});
	}
	//if($(this).attr("checked","chcked"))

}

function deleteRequsetedOrg(id){
	var formAction ='<?php echo base_url();?>requested_orgs/delete/'+id;
	jQuery("#myPendingApprovalsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction}); 
	$('#allOrgRequestsResultSet').jqGrid('delRowData',id); 
	//$("#delmodmyPendingApprovalsResultSet").addClass("gridConfirmFormCenterAlign");
	$("#delmodmyPendingApprovalsResultSet").center();
}

function rejectRequestedOrg(id){
	$("#addNewOrg").dialog("close");
	var arrIds = new Array();
	var arrOrgids = new Array();
	if(id == null){
		arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');
		$.each(arrIds, function( index, value ) {
			var arrRowData = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', value);
			arrOrgids.push(arrRowData.id);
		});
	}else{
		arrIds.push(id);
		arrOrgids.push(id);
	}

	var data = {};
	data['comments'] = $("#comments").val();
	data['arrIds'] = arrOrgids;
	$('#listOrgsTbl').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$('#msg').removeClass('success');
	$('#msg').addClass('notice');
	$('#msg').show();

	$('#msg').html('Rejecting the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

	$.ajax({
			url:'<?php echo base_url()?>requested_orgs/reject',
			data:data,
			type:'post',
			dataType:'json',
			success:function(returnData){
				$('#msg').html('Rejected successfully');
				$('#msg').fadeOut(1500);
				$('#listOrgsTbl').unblock();
				//myPendingApprovals();
				//allProfileRequests();
				var numberSelected = arrIds.length;
				for(i=0;i<numberSelected;i++){
					var id = arrIds[i];
					var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', id);
					rowData.status = 'Rejected';
					rowData.approved_by = returnData.approved_by;
					rowData.comments = data['comments'];

					var selectedOPtion = $(".ui-pg-selbox").val();
					$(".ui-pg-selbox option:last").attr('selected','selected');
			    	$('.ui-pg-selbox').trigger('change');

			    	var su=jQuery("#allOrgRequestsResultSet").jqGrid('setRowData',id,rowData);
					$('#myPendingApprovalsResultSet').jqGrid('delRowData',id);
					$("#allOrgRequestsResultSet tr#"+rowData.id+" td:eq(5)"). attr("title",rowData.comments);
					$("#allOrgRequestsResultSet tr#"+rowData.id+" td:eq(5)"). attr("onclick","showRejectREason(this,'"+rowData.comments+"');");
			    	
			    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
			    	$('.ui-pg-selbox').trigger('change');
				}
			}
		});

}

function showRejectBox(id){
	var arrIds = new Array();
	if(id == null)
		arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');
	else
		arrIds.push(id);

	if(arrIds == ''){
		jAlert("Please select at least one Organization")
		return false;
	}
	
	$(".addNewOrgContent").html("<div id='rejectBox'><label>Reason for rejecting Profile(s) </label><textarea id='comments'></textarea><input type='button' value='Reject' onclick='rejectRequestedOrg("+id+");' /></div>");
	$("#addNewOrg").dialog("open");
	return false;	
}


function viewOrgMicroProfile(orgId,thisEle,allPage){
		$("#contentHolder").removeClass("reasonContent");
		//var elmt=document.getElementById(orgId);	
		var pos = getElementAbsolutePos(thisEle);

		var xPos=pos.x+23;
		if(allPage == null){
			var yPos=pos.y+170;
		}else{
			var yPos=pos.y+480;
		}
		$("#arraouHolder").css({'position': 'absolute','top':yPos-31,'left':xPos-11});
		$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});

		var position = findPos(thisEle);
		$("#arraouHolder").css({'position': 'absolute','top':position[0]-57,'left':position[1]+13});
		$("#contentHolder").css({'position': 'absolute','top':position[0]-24,'left':position[1]+24});
		
		$("#arraouHolder").show();
		$("#contentHolder").show();

		$(".profileContent").html("");
		//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
		$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


		$("#contentHolder .profileContent").load(base_url+'organizations/view_micro_profile_for_org_request/'+orgId+'/'+orgId,{},
				function(){	$('#contentHolder .profileContent').unblock(); }
			);
		
		return false;
	}

function findPos(obj) {
	 var obj2 = obj;
	 var curtop = 0;
	 var curleft = 0;
	 if (document.getElementById || document.all) {
	  do  {
	   curleft += obj.offsetLeft-obj.scrollLeft;
	   curtop += obj.offsetTop-obj.scrollTop;
	   obj = obj.offsetParent;
	   obj2 = obj2.parentNode;
	   while (obj2!=obj) {
	    curleft -= obj2.scrollLeft;
	    curtop -= obj2.scrollTop;
	    obj2 = obj2.parentNode;
	   }
	  } while (obj.offsetParent)
	 } else if (document.layers) {
	  curtop += obj.y;
	  curleft += obj.x;
	 }
	 return [curtop, curleft];
	}   // en
	
function closeOrgProfile(){
	$("#arraouHolder").hide();
	$(".profileContent").html("");
	$("#contentHolder").hide();
}


function sendReRequest(thisEle){
	if(autoApproveRequest)
		jAlert("The Organization Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
	else
		jAlert("Your Organization Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
	
	$('.msgBox').addClass('notice');
	$('.msgBox').show();
	$('.msgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

	var data = {};
	data['org_id'] = $(thisEle).parent().parent().find('#org_id').val();
	data['current_profile_type'] = $(thisEle).parent().parent().find('#current_profile_type').val();
	
	
	$.ajax({
			url:'<?php echo base_url()?>requested_orgs/re_request',
			data:data,
			type:'post',
			dataType:'json',
			success:function(returnData){
				$('.msgBox').html('Saved successfully');
				$('.msgBox').fadeOut(1500);
				//myPendingApprovals();
				//allProfileRequests();
				if(returnData.arrOrg.org_name == '0')
					returnData.arrOrg.org_name = "";
				
				var datarow = {
					id:returnData.arrOrg.id,
					created_by		:	returnData.arrOrg.created_by,
					org_id:returnData.arrOrg.org_id,
					micro:"<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewOrgMicroProfile('"+returnData.org_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>",
					status:returnData.arrOrg.status,
					org_name:returnData.arrOrg.org_name,
					city:returnData.arrOrg.city,
					state:returnData.arrOrg.state,
					user_full_name:	returnData.arrOrg.user_full_name
				};
				if(!returnData.is_manager)
					var su=jQuery("#myPendingApprovalsResultSet").jqGrid('addRowData',returnData.arrOrg.id,datarow);

				datarow.approved_by =  datarow.user_full_name;
				var dt=jQuery("#allOrgRequestsResultSet").jqGrid('addRowData',returnData.arrOrg.id,datarow); 
			
				$("#addNewOrg").dialog("close");
			}
		});
}

function export_excel(type){
	$('#type').val(type);
	var excelFilters = '';
	if(type==1){
	$("#myPendingApprovals .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
		if($(this).val() != ''){
			var filterName = $(this).attr('name');
			var filterValue = $(this).val();
			excelFilters += filterName+" : "+filterValue+",";
		}
	});
	$("#filters").val(excelFilters);
	var selectedOPtion = $(".ui-pg-selbox").val();
	$(".ui-pg-selbox option:last").attr('selected','selected');
    $('.ui-pg-selbox').trigger('change');
    var arrIds = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs');    
    id = new Array();
	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
	for(var i=0;i < arrIds.length;i++){ 
		var arrId =  jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData',  arrIds[i]);
    	id.push(arrId.id);	
	}
	$('#exportIds').val(id);
//	return false;
    $('#exportClientRequestDetail').submit();
    $(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
    $('.ui-pg-selbox').trigger('change');

	}else{

		$("#allOrgRequestsGridContainer .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
			if($(this).val() != ''){
				var filterName = $(this).attr('name');
				var filterValue = $(this).val();
				excelFilters += filterName+" : "+filterValue+",";
			}
		});
		$("#filters").val(excelFilters);
		var selectedOPtion = $(".ui-pg-selbox").val();
		$(".ui-pg-selbox option:last").attr('selected','selected');
    	$('.ui-pg-selbox').trigger('change');
    	var arrIds = jQuery("#allOrgRequestsResultSet").jqGrid('getDataIDs'); 
    	id = new Array();
    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
    	for(var i=0;i < arrIds.length;i++){ 
    		var arrId =  jQuery('#allOrgRequestsResultSet').jqGrid ('getRowData',  arrIds[i]);
        	id.push(arrId.id);	
    	}
    	$('#exportIds').val(id);
	//	return false;
    	$('#exportClientRequestDetail').submit();
    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
    	$('.ui-pg-selbox').trigger('change');
	}
}

</script>
<form action="<?php echo base_url()?>requested_orgs/export_org_detail" method="post" id="exportClientRequestDetail">
	<input type="hidden" value="" name="exportIds" id="exportIds"></input>
	<input type="hidden" value="" name="filters" id="filters"></input>
	<input type="hidden" value="" name="type" id="type">
</form>
<div id="listOrgs">
	<div id="msg"></div>
	<div id="listOrgsTbl">
		
	</div>
</div>
<div id="addNewOrg" class="microProfileDialogBox">
	<div class="addNewOrgContent profileContent"></div>
</div>
	
<div>
	<div class="gridWrapper" id="myPendingApprovals" style="clear: both;">
		<table id="myPendingApprovalstResultSet"></table>
		<div id="myPendingApprovalstPager"></div>
	</div>
	
	<div class="gridWrapper" id="allOrgRequestsGridContainer">
		<table id="allOrgRequestsResultSet"></table>
		<div id="allOrgRequestsPager"></div>
	</div>		
</div>
	
<!-- Container for the 'Micro Profile'  box -->
<div id="contentHolder" class="callOutTest microView" style="display: none;">
	<div>
		<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeOrgProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeOrgProfile();" />
	--></div>
	<div class="profileContent"></div>
</div>
<div id="arraouHolder" class="callOutTest" style="display: none;">
	<div class="arrowMarkIcon"></div>
</div>