<?php
/**
 * this is html file to hold the Report filter fields like linked-in style
 * 
 * @author Vinayak
 * @since	2.4
 * @created: 4-6-11
 * @package application.views.reports
 */

$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";
?>
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
			// prepare array of JS files to insert into queue
//			$queued_js_scripts = array('reports/interaction_filter_li_style');
			$queued_js_scripts = array(
//			'reports/interaction_filters'
			);
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
	}
</script>
<style type="text/css">
	#timeLineSliderContainer {
	    padding-left: 10px;
    	padding-right: 8px;
	}
	#timeLineSlider{
		margin-right:10px;
	}
	#searchLeftBar li.category{
		border-top: 0px;
	}
	#searchLeftBar{
	/*	margin-top:-40px; */
	}
	<?php if(IS_IPAD_REQUEST == 1){
			echo '#searchLeftBar label.facet-toggle{
				top:-7px !important;
			}';
		}
	?>
	<?php if(IS_IPAD_REQUEST == 1){ ?>
		#rightSideBarContainer {
		    width: 250px;
		}
		form label {
	        font-weight: normal !important;
	        text-align: right;
		}
		.chzn-container-multi .chzn-choices .search-field .default {
		    height: 25px;
		    border-radius: 2px !important;
		}
		.chzn-container-multi .chzn-choices {
		    border-radius: 4px;
		}
	    .postalerror{
	    	display: block !important;
	    	text-align: left !important;
	    	color: green !important;
	    }
	    .alignRight{
	    	vertical-align: top !important;
	    }
	    .chosenMultipleSelect {
	    	width: 230px;
	    }
	    .chosenSingleSelectManager {
	    	width: 230px;
	    }
	    label.categoryName{
	    	border-bottom: 0 !important;
	    	font-size: 11px;
			color: #444444;
	    }
	    #categoriesContainer .category{
	    	margin-top: 15px;
	    }
	    #fromDate, #toDate{
			width: 80px;
			border: 1px solid #aaaaaa !important;
			margin-right: 10px;
			font-size: 12px;
			height: 20px;
		}
		.filtersButton{
			margin-left: 16px;
		}
		.filtersButton label{
			font-size: 12px !important;
		}
		.applyFilter{
			font-size: 12px !important;
		}
		.ui-widget-content{
			background: white;
		}
		.dateText{
			font-size: 11px;
			color: #444444;
		}
		#searchFiltersElements ul{
			padding-left: 1px;
			margin-right: 0px;
			padding-left: 5px;
		}
		#searchFiltersElements ul li{
			font-size: 11px;
			list-style: none;
			color:#000000;
			font-style: normal;
			font-family: inherit;
		}
		
	<?php }else{ ?>
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px;
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		/*margin-top: 0px;*/
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
	.chzn-container-single .chzn-single div{
		top: -3px !important;
	}
/*	.chzn-container .chzn-results li{
		padding: 3px 4px !important;
		line-height: 12px !important;
	}
*/
	.chzn-drop{
		min-width: 106px !important;	
	}
	.ui-widget-content, #timeLineSliderContainer p, #yearRange {
		background: inherit;
	}
	#fromDate, #toDate{
		width: 80px;
		border: 1px solid #aaaaaa !important;
	}
	.selectChosenBox{
		width: 280px;
	}
	.chzn-container-multi ul li{
		/*padding: 2px !important;*/		
	}
	#rightSideBarContainer {
	    width: 311px;
	}
	#rightSideBar::before {
	    border-top: 1px solid #bbbbbb !important;
	    height: 0 !important;
	    margin-left: 0 !important;
	}
	#rightSideBarWrapper {
	    border-left: 1px solid #bbbbbb;
	    /*overflow: hidden;*/
	}
	#categoriesContainer .category{
	    padding: 5px 5px 5px 15px;
	}
	#categoriesContainer .category{
		padding-bottom: 0;
	}
	label.categoryName{
		color: #000000;
	    font-family: inherit;
	    font-size: 12px;
	    font-style: normal;
	    list-style: outside none none;
	}
	<?php }?>
	#hideSideBarButton{
		margin: 5px 20px 5px 10px;
		font-size: 11px;
	}
</style>
<?php 
	$fromDate	= date('m/01/Y');
	if($fromFilterData > 0){
		$fromDate	= date('m/01/Y', strtotime("last day of -$fromFilterData month"));
	}
	$toDate	= date('m/d/Y');
?>

	<script type="text/javascript">
		var todayDate = "<?php echo $toDate;?>";
		var monthFirstDate = "<?php echo $fromDate;?>";
		$(document).ready(function (){
			$("#resetBttnContainer").remove();
			$('#fromDate').datepicker({
				dateFormat: 'mm/dd/yy'
			});
			$('#fromDate').val(monthFirstDate);
		});
		$(document).ready(function (){
			$('#toDate').datepicker({
				dateFormat: 'mm/dd/yy'
			});
			$('#toDate').val(todayDate);
			doSearchFilter1(-1);
		});
	</script>
		<script type="text/javascript">

	
$(document).ready(function(){
	/*
	$('#msl_user').chosen({
        placeholder_text: "Click to Select MSLs",
        allow_single_deselect: true
    });
	$('#team').chosen({
        placeholder_text: "Click to Select Teams",
        allow_single_deselect: true
    });
	$('#channel').chosen({
        placeholder_text: "Click to Select Channels",
        allow_single_deselect: true
    });
	$('#category').chosen({
        placeholder_text: "Click to Select Categories",
        allow_single_deselect: true
    });
	$('#product').chosen({
        placeholder_text: "Click to Select Products",
        allow_single_deselect: true
    });
	$('#type').chosen({
        placeholder_text: "Click to Select Types",
        allow_single_deselect: true
    });
	$('#topic').chosen({
        placeholder_text: "Click to Select Topics",
        allow_single_deselect: true
    });
	$('#subTopic').chosen({
        placeholder_text: "Click to Select Sub Topics",
        allow_single_deselect: true
    });
    */
    
    $(".chosenSingleSelectManager").chosen({
    	allow_single_deselect: true
    });
    $(".chosenMultipleSelect").chosen({
        placeholder_text: "Click to Select",
        allow_single_deselect: true
    });
    
    $("#resetInterctionsFilters").click(function (){
    	$(".chosenMultipleSelect").val('').trigger('liszt:updated');
    	setTimeout(function() {
    		doSearchFilter1(-1);
    	   }, 100);
    });
});
	</script>
		<div id="searchFiltersContainer">
			<div id="searchFiltersElements">
					<form action="<?php echo base_url()?>reports/reload_interaction_filters" name="searchFilterForm" method="post" id="searchFilterForm">
						<ul id="categoriesContainer">
							<?php if(IS_IPAD_REQUEST == 1){?>
									<div class="row">
										<div class="col-md-12 text-right">
											<input type="button" id="hideSideBarButton" class="toggle-button" onclick="toggleIreportSidebar(this);" value="Hide Sidebar">
										</div>
                						<div class="col-md-12 text-center">
                							<input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" class="toggle-button applyFilter" onclick="doSearchFilter1(-1);">
                							<input type="reset" name="applyFilter" value="Reset" id="resetInterctionsFilters" class="toggle-button applyFilter">
                						</div>
                					</div>
                					<br>
                					<div class="row">
                						<div class="col-md-12 text-center">
											<label class="dateText">From </label>
											<input type="text" name="fromDate" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="fromDate">
											<label class="dateText">To </label>
											<input type="text" name="toDate" value="<?php if($toDate != ''){echo $toDate;}?>" id="toDate">
										</div>
									</div>
									
							<?php }else{?>
								<li id="categotyChannels" class="category"> </li>
								<table class="filtersButton">
									<tr>
										<td colspan="2" style="text-align: center;">
											<input type="button" name="applyFilter" value="Apply Filters" id="applyFilter" onclick="doSearchFilter1(-1);">
											<input type="reset" name="applyFilter" value="Reset" id="resetInterctionsFilters">
										</td>
									</tr>
									<tr>
										<td>
											<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">From </label>
											<div style="">
												<input type="text" name="fromDate" value="<?php if($fromDate != ''){echo $fromDate;}?>" id="fromDate">
											</div>
										</td>
										<td>
											<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">To </label>
											<div style="">
												<input type="text" name="toDate" value="<?php if($toDate != ''){echo $toDate;}?>" id="toDate">
											</div>
										</td>
									</tr>
								</table>
							<?php }?>	
							<li id="categotyChannels" class="category"> </li>
							<li id="categotyChannels" class="category">
								<label class="categoryName">User</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="msl_user_ids[]" id="msl_user">
                               		<?php foreach($arrInteractionsUsers as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyChannels" class="category">
								<label class="categoryName">Division</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="team_ids[]" id="team">
                               		<?php foreach($arrInteractionsTeams as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
								<li id="categotyChannels" class="category">
									<label class="categoryName">Manager Name</label>
									<select class="chosenSingleSelectManager selectChosenBox" name="manager_ids[]" id="manager">
										<option value=""></option>
	                               		<?php foreach($arrManager as $key=>$val){ ?>
	                               			<option value="<?php echo $key?>"><?php echo $val?></option>
	                               		<?php }?>
	                            	</select>
								</li>
							<?php }?>
							<li id="categotyChannels" class="category">
								<label class="categoryName">Interaction Type</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="channel_ids[]" id="channel">
                               		<?php foreach($arrInteractionsChannel as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyCategory" class="category">
								<label class="categoryName">Interaction Categories</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="category_ids[]" id="category">
                               		<?php foreach($arrInteractionsCategory as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyCategory" class="category">
								<label class="categoryName"><?php echo lang("Overview.Product");?></label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="product_ids[]" id="product">
                               		<?php foreach($arrInteractionsProduct as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyCategory" class="category">
								<label class="categoryName">Discussion Type</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="type_ids[]" id="typeIds">
                               		<?php foreach($arrInteractionsType as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyCategory" class="category">
								<label class="categoryName">Interaction Topics</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="topic_ids[]" id="topic">
                               		<?php foreach($arrInteractionsTopic as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
							<li id="categotyCategory" class="category" style="display:none;">
								<label class="categoryName">Interaction Sub Topics</label>
								<select class="chosenMultipleSelect selectChosenBox" multiple="multiple"  name="sub_topic_ids[]" id="subTopic">
                               		<?php foreach($arrInteractionsSubTopic as $key=>$val){ ?>
                               			<option value="<?php echo $key?>"><?php echo $val?></option>
                               		<?php }?>
                            	</select>
							</li>
						</ul>
					</form>
			
			</div>
		</div>