<script src="<?php echo base_url().MODULES_ASSETS;?>configurations/js/configuration.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function(){
	list_roles_jqgrid();
	jQuery("#associate_role_btn").click( function() {
		var s;
		s = jQuery("#gridUserListingResultSet").jqGrid('getGridParam','selarrrow');
		if(s.length>=1){
			associate_roles(s,1);
		}
        else
        	alert("please select one or more modules");
	});	
	jQuery("#dissociate_role_btn").click( function() {
		var s;
		s = jQuery("#gridUserListingResultSet").jqGrid('getGridParam','selarrrow');
		if(s.length>=1){
			associate_roles(s,0);
		}
        else
        	alert("please select one or more modules");
	});		
});
</script>
<div style="margin:10px 0px;">
	<p style="display: inline">Select Client:</p>
	<select name="client_id" id="client_id" class="form-control required" onchange="list_roles_jqgrid();" style="width:12%;display: inline">
			<?php foreach($arrClients as $client){	?>
			<option value="<?php echo $client['id'];?>">
					<?php echo $client['name'];?>
				</option>
			<?php }?>
	</select>
	<div class="pull-right">
		<a class="btn btn-default " id="associate_role_btn" >Associate Role</a>
		<a class="btn btn-default " id="dissociate_role_btn" >Dissociate Role</a>
		<a class="btn btn-default" href="<?php echo base_url().'configurations/configurations/getpermission';?>">Add Role</a>
	</div>
</div>
<div class="gridWrapper">
	<div id="gridUserListing">
			<div id="gridUserListingPagintaion"></div>
			<table id="gridUserListingResultSet"></table>
	</div>
</div>
<div id="moduleContainer" class="microViewLoading">
	<div class="addModuleclientContent"></div>
</div>