<?php
class Kol_rating extends CI_Model {
	function getKolTotalActivityCount1($kolId){
		$arrKolTotalActivitiesCount = '';
		$this->db->select('kol_activities_count.totalAllscore');
		$this->db->where('kol_activities_count.kol_id',$kolId);
		$arrTotalActivityResultset = $this->db->get('kol_activities_count');
		foreach($arrTotalActivityResultset->result_array() as $arrTotalActivitiesCount){
			$arrKolTotalActivitiesCount = $arrTotalActivitiesCount['totalAllscore'];
		}
		return $arrKolTotalActivitiesCount;
	}
	function gerSpecilatyIdByKol($kolId){
		$client_id = $this->session->userdata('client_id');
		$specialltyId = '';
		$this->db->select('specialty');
		$this->db->where('kols.id',$kolId);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$specialtyReusltSet = $this->db->get('kols');
		foreach($specialtyReusltSet->result() as $row){
			$panelistCount=$row->specialty;
		}
		return $panelistCount;
	}
	function getMaxTotalCountOfKolBySpecialty($specialtyId){
		$client_id = $this->session->userdata('client_id');
		$maxTolalScore=array();
		$this->db->select("max(totalAllScore) as maxTolalScore");
		$this->db->join('kols','kols.id=kol_activities_count.kol_id');
		$this->db->where('kols.specialty',$specialtyId);
		//$this->db->where('status',COMPLETED);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrResultSet = $this->db->get('kol_activities_count');
		foreach($arrResultSet->result() as $row){
			$maxTolalScore=$row->maxTolalScore;
		}
		//	pr($maxTolalScore);
		return $maxTolalScore;
	}
	function getProfileScore($kolId){
		$profileScore = '';
		$this->db->select('profileScore');
		$this->db->where('kol_id',$kolId);
		$profoleScoreResultSet = $this->db->get('kol_activities_count');
		foreach($profoleScoreResultSet->result_array() as $row){
			$profileScore =$row['profileScore'];
		}
		return $profileScore;
	}
	function getCountOfAllParameter($id){
		$client_id = $this->session->userdata('client_id');
		$arrCounts = array();
		$this->db->select('kol_activities_count.*,kols.salutation,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kol_activities_count.kol_id',$id);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrReultSet =$this->db->get('kol_activities_count');
		foreach($arrReultSet->result_array() as $row){
			$arrCounts[]=$row;
		}
		return $arrCounts;
	}
	function getmaxCategoriesCounts($specialtyId){
		$client_id = $this->session->userdata('client_id');
		$this->db->select('max(totalProfessionalCount) as maxProfessionalCount,
							max(totalEvents) as maxEventsPresenceCount,
							max(totalResearch) as maxResearchCount');
		$this->db->join('kols','kols.id=kol_activities_count.kol_id','left');
		$this->db->where('kols.specialty',$specialtyId);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrResulSet = $this->db->get('kol_activities_count');
		foreach($arrResulSet->result_array() as $row){
			$arrCounts[]= $row;
		}
		return $arrCounts;
	}
	function getMaxCountBySpecialty($specialtyId){
		$client_id = $this->session->userdata('client_id');
		$maxActvityCount=array();
		$this->db->select("max(teachingCount),max(practiseCount),
							max(trialCount),max(socialComitteCount),
						max(socialBoardCount),max(guidelineCount),
						max(governmentCount),max(executiveCount),
						max(speakingCount),max(facultyCount),
						max(panelistCount),max(authPosCount)");
		$this->db->join('kols','kols.id=kol_activities_count.kol_id');
		$this->db->where('kols.specialty',$specialtyId);
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		//$this->db->where('status',COMPLETED);
		$arrResultSet = $this->db->get('kol_activities_count');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$maxActvityCount[]=$row;
		}
		return $maxActvityCount;
	}
}