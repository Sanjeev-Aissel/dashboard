<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Assessment_scores extends MX_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('assessment_score');
		$this->load->model('helpers/common_helper');
	}
	function kol_assessment($kolId){
		$arrAsmtRules = array();
		$arrAsmtRules = $this->assessment_score->getAllAsmtRules(254);
		foreach ($arrAsmtRules as $key => $row) {
			$arrFormattedAsmtRules[$row['cat_name']][$row['criteria']][] = $row;
		}
		$kolId							= $this->common_helper->getKolClientVisiblityId($kolId);
		
		$data['kol_id'] 				= $kolId;
		$data['arrAsmtRatings'] 		= $arrFormattedAsmtRules;
		$data['contentPage'] 			='kol_assessment';
		$data['contentData']			=$data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function save_kol_ratings(){
		$this->assessment_score->saveKolRatings($_POST);
	}
	function script_for_client_specific_asmt(){
		$resultSet	= $this->db->get('asmt_ratings');
		foreach($resultSet->result_array() as $row){
			pr($row);
			$this->db->insert('asmt_ratings_client_association',array('asmt_rating_id'=>$row['id'],
				'client_id'=>1,
					'rating_score'=>$row['rating_score']
			));
			pr('--------------------------------------------');
		}
	}
	function kol_assessment_score($kolId){
		$arrCriteriaRating = $this->assessment_score->getKolRatings($kolId);
		if (sizeof($arrCriteriaRating) > 0) {
			$arrAsmtCat = $this->assessment_score->getAsmtChartScore($kolId);
			$i = 0;
			$asmtPercentageScore = 0;
			foreach ($arrAsmtCat as $key => $arrAsmtCatData) {
				$i++;
				$asmtPercentageScore += $arrAsmtCatData['percentage'];
			}
			if ($i == 0) {
				$i = 1;
			}
			$asmtPercentageScore = ($asmtPercentageScore / $i);
			return  $asmtPercentageScore;
		}
	}
}
?>