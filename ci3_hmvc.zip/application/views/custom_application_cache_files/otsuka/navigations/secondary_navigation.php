<?php
							$menuGenerator	= "";
							switch ($current_tab) {
										 }
			if(!empty($menuGenerator)){
				echo '<th class="col-sm-2"><div id="secondaryMenuWrapper">'.$menuGenerator.'</div></th>';
			}
		