<?php
/*
 * To display assessment score in chart 
 *  
 * @Author		: Laxman K
 * @since 		: Otsuka v1.0.5 KOLM v3.7 Abbott 1.0
 * Created on	: 10-11-2012
 *  
 */

?>
	<style type="text/css">
		#asmtScoreReport .alignLeft{
			padding-right:5px;
			width:62px;
		}
		#asmtScoreReport .asmtScoreCategoryBar .progress{
			height: 15px;
			width: 194px !important;
		}
		#asmtScoreReport td.asmtScoreCategoryBar{
			width: 194px !important;
		}
		#asmtScoreReport .asmtScoreCategoryBar .filterBar .progress .bar{
			-moz-box-sizing: border-box;
			background-color: #F8F800;
			background-image: -moz-linear-gradient(center top, #F8F800, #F8F800);
			background-color: #89A54E;
    		background-image: -moz-linear-gradient(center top , #89A54E, #89A54E);
    		background-color: #618CBE;
    		background-image: -moz-linear-gradient(center top , #618CBE, #4572A7);
			background-repeat: repeat-x;
			color: #FFFFFF;
			font-size: 12px;
			height: 15px;
			text-align: center;
			text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
			width: 0;
		}
	</style>
	<table id="asmtScoreReport">
	<?php 	
		if(sizeof($arrAsmtCat)>0){
			foreach($arrAsmtCat as $ct_id=>$row){
	?>
				<tr>
					<td class="alignRight"><?php echo $row['category_name'];?></td>
					<td class="asmtScoreCategoryBar">
						<div class="filterBar">
							<div class="progress" title="<?php echo $row['percentage'];?>%">
								<div class="bar" style="width: <?php echo $row['percentage'];?>%"></div>
							</div>
						</div>
					</td>
					<td class="alignLeft"><?php echo $row['percentage'];?>% (<?php echo $row['total_cat_score'];?>)</td>
				</tr>
	<?php 
			}
		}
	?>
	</table>