<!-- 
 * View File to timeout the Idle session
 * @Author	: Kishan Ravindra (00001111)
 -->
<!DOCTYPE html>
<html>
<head>
	<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>
	<?php echo $this->load->view('elements/favicon');?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php //echo $this->load->view('imports/common_imports','',true);?>
	<script src="<?php echo base_url();?>js/jquery-3.2.1.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>js/jquery-ui-1.11.3/jquery-ui.min.css" />
	<script src="<?php echo base_url();?>js/jquery-ui-1.11.3/jquery-ui.min.js"></script>
</head>

<script>
$(document).ready(function(){
	var message = '<center><a href="<?php echo base_url()?>login">Click Here</a> to Login again</center>';
	$("#sessionKillContent").html(message);
	$('#sessionKillContainer').dialog(getModalLayout('Session Expired'));
});
	/*
 * Description	: Builds a Modal Box Layout.
 * Params		: Title for the Modal Box, Width [Optional, Defalut : 360].
 * Author		: Kishan Ravindra
 */
function getModalLayout(headerTitle, modWidth = 360){
	var modalBoxLayout = {
		title: headerTitle,
		modal: true,
		width: modWidth,
		resizable: false,
	}
	return modalBoxLayout;
};
</script>
<div id="sessionKillContainer"><span id="sessionKillContent"></span></div>
</html>