<?php
?>
<script>
	function save(){

	$.ajax({
		url:'<?php echo base_url()?>speaker_evaluations/save_evaluation',
		data:$('#speakerForm').serialize(),
		type:'post',
		success:function(){

		}

		})
	}


	function hideQuestion(){

	}
</script>
<div>
	<form id="speakerForm">
	<div class="reomoveLater" style="display:none">
		<label>1. Evaluator</label>
		<div><input type='radio' name="evaluator" value="MSL"></input><label>MSL</label></div>
		<div><input type='radio' name="evaluator" value="MSL Director"></input><label>MSL Director </label></div>
		<div><input type='radio' name="evaluator" value="MML"></input><label>MML </label></div>
		<div><input type='radio' name="evaluator" value="MML Director"></input><label>MML Director </label></div>
		<div>
			<label style="display:block">Name:</label>
			<input type="text" name="evaluator_name" value=""></input>
		</div>
	
	
		<label>2.Program Date</label>
		<div>
			<label>Date of Program</label>
			<input type="text" name="program_date"></input>
		
		</div>
		
		<label>3. No. of Attendees:</label>
		<div>
		
			<input type="text" name="no_of_attendees" value=""></input>
		
		</div>
		
		<label>4. Speaker Details</label>
		<div><input type='radio' name="speaker_detail" value="MSL Speaker"></input><label>MSL Speaker </label></div>
		<div><input type='radio' name="speaker_detail" value="External Speaker"></input><label>External Speaker </label></div>
		<div>
			<label style="display:block">Speaker Name: (This field is required)</label>
			<input type="text" name="speaker_name" value=""></input>
		</div>
		
		
		<label> 5. Speaker background: </label>
		<div><input type='checkbox' name="speaker_background[]" value="Academic"></input><label>Academic </label></div>
		<div><input type='checkbox' name="speaker_background[]" value="Private Practice/Office"></input><label>Private Practice/Office </label></div>
		<div><input type='checkbox' name="speaker_background[]" value="Hospital/Inpatient"></input><label>Hospital/Inpatient </label></div>
		<div><input type='checkbox' name="speaker_background[]" value="Community Clinic/Outpatient"></input><label>Community Clinic/Outpatient </label></div>
		<div>
			<label style="display:block">Other (please specify): </label>
			<input type="text" name="speaker_text" value=""></input>
		</div>
		
		<label>6. Was this a co-moderated program?</label>
		<div><input type='radio' name="moderated_program" value="yes"></input><label>Yes </label></div>
		<div><input type='radio' name="moderated_program" value="no"></input><label>No </label></div>
		
		<label>7. Venue</label>
		<div><input type='radio' name="venu" value="In Office"></input><label>In Office </label></div>
		<div><input type='radio' name="venu" value="Out of Office"></input><label>Out of Office  </label></div>
		<div>
			<label style="display:block">City, State: </label>
			<input type="text" name="venu_city" value=""></input>
		</div>
		
		<label>8. Was venue appropriate for a promotional educational presentation (low noise level, private room/area, minimal distractions and modest venue)?</label>
		<div><input type='radio' name="venu_presentation"></input><label>In Office </label></div>
		<div><input type='radio' name="venu_presentation"></input><label>Out of Office  </label></div>
		<div>
			<label style="display:block">Comments: </label>
			<input type="text" name="venu_comments" value=""></input>
		</div>
		
		<label>9. Did audio/visual setup work properly?</label>
		<div><input type='radio' name="audio_setup" value="yes"></input><label>Yes </label></div>
		<div><input type='radio' name="audio_setup" value="no"></input><label>No  </label></div>
		<div>
			<label style="display:block">Comments: </label>
			<input type="text" name="audio_setup_comments" value=""></input>
		</div>
			</div>
		<label>10. Program Topic</label>
		<div><input type='radio' name="program_topic" value="Abilify Maintena" onclick="hideQuestion('abilify')"></input><label>Abilify Maintena</label></div>
		<div><input type='radio' name="program_topic" value="Rexulti" onclick="hideQuestion('rexulti')"></input><label>Rexulti</label></div>
		<div><input type='radio' name="program_topic" value="Nuedexta" onclick="hideQuestion('nuedexta')"></input><label>Nuedexta</label></div>
		<div><input type='radio' name="program_topic" value="Samsca" onclick="hideQuestion('samsca')"></input><label>Samsca</label></div>
		<div><input type='radio' name="program_topic" value="Disease State" onclick="hideQuestion('disease')"></input><label>Disease State </label></div>
		<div><input type='radio' name="program_topic" value="PsychU" onclick="hideQuestion('psychU')"></input><label>PsychU</label></div>
		
	
		<div class="abilify question">
			<label>11. Abilify Maintena:</label>
			<div><input type='radio' name="abilify_maintena" value="Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia"></input><label>Beyond Maintenance Therapy: Abilify Maintena as a treatment option for acutely relapsed patients with Schizophrenia</label></div>
			<div><input type='radio' name="abilify_maintena" value="Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia"></input><label>Abilify Maintena Provides Efficacy Early and Throughout the Course of Schizophrenia</label></div>
			<div><input type='radio' name="abilify_maintena" value="Targeted Topics Around Use of Abilify Maintena for Treatment of Acutely Relapse and Maintenance Phase patients with Schizophrenia"></input><label>Targeted Topics Around Use of Abilify Maintena for Treatment of Acutely Relapse and Maintenance Phase patients with Schizophrenia</label></div>
			<div><input type='radio' name="abilify_maintena" value="Abilify Maintena for Early and Ongoing Treatment of Schizophrenia"></input><label>Abilify Maintena for Early and Ongoing Treatment of Schizophrenia</label></div>
			<div><input type='radio' name="abilify_maintena" value="Abilify Maintena: A Treatment Option for Patients with Acutely Relapsed Schizophrenia"></input><label>Abilify Maintena: A Treatment Option for Patients with Acutely Relapsed Schizophrenia </label></div>
			<div><input type='radio' name="abilify_maintena" value="In the Treatment of Acutely Relapsed Patients with Schizophrenia: Workbook"></input><label>In the Treatment of Acutely Relapsed Patients with Schizophrenia: Workbook</label></div>
			<div><input type='radio' name="abilify_maintena" value="Working Together to Incorporate Abilify Maintena Into Your Practice"></input><label>Working Together to Incorporate Abilify Maintena Into Your Practice</label></div>
			<div><input type='radio' name="abilify_maintena" value="Coordinating Care for Patients with Schizophrenia Roundtable Program"></input><label>Coordinating Care for Patients with Schizophrenia Roundtable Program</label></div>
		</div>
		
		<div class="rexulti question">
		<label>12. Rexulti:</label>
		<div><input type='radio' name="rexulti" value="Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder"></input><label>Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder</label></div>
		<div><input type='radio' name="rexulti" value="Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder (Primary Care)"></input><label>Introducing Rexulti: A New Adjunctive Therapy for Major Depressive Disorder (Primary Care)</label></div>
		<div><input type='radio' name="rexulti" value="Introducing Rexulti: A New Therapy for Schizophrenia"></input><label>Introducing Rexulti: A New Therapy for Schizophrenia</label></div>
		</div>
		
		<div class="nuedexta question">
		<label>13. Nuedexta:</label>
		<div><input type='radio' name="nuedexta" value="Understanding PBA"></input><label>Understanding PBA</label></div>
		<div><input type='radio' name="nuedexta" value="The Diagnosing and Treatment of PBA"></input><label>The Diagnosing and Treatment of PBA</label></div>
		</div>
		
		<div class="samsca question">
		<label>14. Samsca:</label>
		<div><input type='radio' name="samsca" value="Understanding Hyponatremia: Treating Beyond the primary Diagnosis"></input><label>Understanding Hyponatremia: Treating Beyond the primary Diagnosis</label></div>
		<div><input type='radio' name="samsca" value="Hyponatremia in Heart Failure: Treating Beyond the Initial Diagnosis"></input><label>Hyponatremia in Heart Failure: Treating Beyond the Initial Diagnosis</label></div>
		<div><input type='radio' name="samsca" value="Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment"></input><label>Hyponatremia and SIADH: A Targeted Mechanism of Action Approach to Treatment</label></div>
			<div><input type='radio' name="samsca" value="Evaluation and Management of Hyponatremia in the Hospital Setting"></input><label>Evaluation and Management of Hyponatremia in the Hospital Setting</label></div>	
		</div>
		
		<div class="disease question">
			<label>15. Disease State (Enter Program Topic Below)</label>
			<div><textarea name="disease_state"></textarea>
		</div>
		</div>
		<div class="psychU question">
			<label>16. PsychU (Enter Program Topic Below)</label>
			<div><textarea name="psychU"></textarea>
		</div>
		</div>
		<label>17. Were the attendees the appropriate audience for the topic(s) presented?</label>
		<div><input type='radio' name="topic_presented" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="topic_presented" value="No"></input><label>No</label></div>
		
		
		
		<label>18. What actions were taken to assure only appropriate individuals were in the
audience?</label>
		<div><textarea name="action"></textarea>
		
		<label>20. Did the speaker stay within label during the presentation?</label>
		<div><input type='radio' name="speaker_stay" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="speaker_stay" value="No"></input><label>No</label></div>
		
		<label>21. Did the speaker minimize or dismiss product safety information?</label>
		<div><input type='radio' name="speaker_stay" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="safety_info" value="No"></input><label>No</label></div>
		
		<label>22. Was all off label discussion appropriately handled per Otsuka policy including
documentation using a MIRF?</label>
		<div><input type='radio' name="mirf" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="mirf" value="No"></input><label>No</label></div>
		<div>
			<label style="display:block">Comments: </label>
			<textarea name="mirf_other"></textarea>
		</div>
		
		<label>23. Were any adverse events reported by any attendee during the event?</label>
		<div><input type='radio' name="adverse_event" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="adverse_event" value="No"></input><label>No</label></div>
		
			
		<label>24. Was the adverse event reported as per Otsuka Policy?</label>
		<div><input type='radio' name="adverse_event_report" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="adverse_event_report" value="No"></input><label>No</label></div>
		
			<label>25. Was the speaker's articulation of their experience with the product on label?</label>
		<div><input type='radio' name="speaker_articulation" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="speaker_articulation" value="No"></input><label>No</label></div>
		<div>
			<label style="display:block">Comments: </label>
			<textarea name="speaker_articulation_comment"></textarea>
		</div>
		
		<label>26. Was all off label discussion appropriately handled per Otsuka policy including
documentation using a MIRF?</label>
		<div><input type='radio' name="mirf_doc" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="mirf_doc" value="No"></input><label>No</label></div>
		<div>
			<label style="display:block">Comments: </label>
			<textarea name="mirf_comment"></textarea>
		</div>
		
		
		<label>guideline</label>
		<div><input type='radio' name="guideline" value="Yes"></input><label>Yes</label></div>
		<div><input type='radio' name="guideline" value="No"></input><label>No</label></div>
		
		<input type="button" onclick="save()" value="save"></input>
	</form>


</div>