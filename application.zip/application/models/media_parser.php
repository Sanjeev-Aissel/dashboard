<?php

/**

 * Created By: Yuvaraj M
 * Created On:10-04-2015 11:00 AM
 * Updated on:21-04-2015
 */
class Media_parser extends Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }
    function mediaLog($logArr)
    {
      //  pr($logArr);
        $logArr['created_by'] = $this->session->userdata('user_id');
        $logArr['created_on'] = date("Y-m-d H:i:s");
        $this->db->insert('log_activities', $logArr); 
      // echo $this->db->last_query();
    }
    function getPreloadedData()
    {
         $this->db->select("json_data");
        $this->db->where("ref_id",200);
         $query = $this->db->get("json_store");
        $result = $query->row_array();
//        echo $this->db->last_query();
        echo $result["json_data"];
    }
    function storePreloadedData($result)
    {
        $this->db->where("ref_id",200);
        $this->db->delete("json_store");
        $this->db->set("ref_id",200);
          $this->db->set("json_data",json_encode($result));
          $this->db->insert('json_store'); 
    }
    function restore() {
        $this->load->library('AlchemyAPI');
        $alchemyapi = new AlchemyAPI();
        $this->db->select("*");
        $this->db->where("img_url","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbMpL-ka6O0_jq0YUoPqTkfePaPxtXQ0eARuLNFSaFzrSlyksy2MjCrg");
        $query = $this->db->get("rss_feed");
        $result = $query->result_array();
        foreach ($result as $values) {
         $response = $alchemyapi->imageExtraction('url',$values["rss_feed_url"], null);
         pr($response);
                 $img_url=$response["image"];
                    if (empty($img_url)) 
                    $img_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbMpL-ka6O0_jq0YUoPqTkfePaPxtXQ0eARuLNFSaFzrSlyksy2MjCrg";
            $data = array("img_url" => $img_url);
            $this->db->where('id', $values["id"]);
            $this->db->update('rss_feed', $data);
        }
    }
    function exportLog()
    {
    
        
        $this->db->select(" count(distinct month(created_on)) as month_count ");
        
        $query = $this->db->get("log_activities");
        $result=$query->row_array();
      
        if($result["month_count"]>1)
        {
            $fileName = date('Y-m-d');
        $filePath = "logbckup/" . $fileName . ".csv";
        chmod($filePath, 0777);
        $myfile = fopen($filePath, "w");
             $this->db->select(" * ");
              $this->db->where('created_on>=(NOW( ) - INTERVAL 1 MONTH)');
        
        $queryEx = $this->db->get("log_activities");
        $resultEx=$queryEx->result_array();
        foreach ($resultEx as $values) {
            

            fputcsv($myfile, $values);
        }
        fclose($myfile);
        $this->db->query("delete from log_activities where created_on>=(NOW( ) - INTERVAL 1 MONTH)");
        }
}
function clearAmbugates()
{
    $this->db->query("delete from media_entity_merge");
}
function getDetails()
{
   $query= $this->db->query("ALTER TABLE media_entity_merge 
ADD COLUMN cat_name VARCHAR(255) NULL AFTER not_merged_entity_id
 ");
      
       
        //  echo $this->db->last_query();
        $result = $query->result_array();
        pr($result);
}
    function prepareInsertStatmentsForSyncs() {
        $days=0;
        $fileName = date('Y-m-d');
        $filePath = "dbsync/" . $fileName . ".sql";
        chmod($filePath, 0777);

        $this->db->select("*");
        $this->db->where("modified_date>=DATE_SUB(CURDATE(), INTERVAL ".$days." DAY)");
        $query = $this->db->get("rss_feed");
        
        //  echo $this->db->last_query();
        $result = $query->result();
        $myfile = fopen($filePath, "w");
        if($myfile==false)
        {
             $logArrFileCreationFail=array("id"=>NULL,"module"=>"prepareInsertStatmentsForSyncs","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>"","description"=>"File coudnt be created.Please check for file permission problems",
                        "type"=>"file_creation","status"=>"fail","file_name"=>$filePath,"client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");
             $this->mediaLog($logArrFileCreationFail);
             exit;
        }
        else
        {
             $logArrFileCreationSucc=array("id"=>NULL,"module"=>"prepareInsertStatmentsForSyncs","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>"","description"=>"",
                        "type"=>"file_creation","status"=>"success","file_name"=>$filePath,"client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");
             $this->mediaLog($logArrFileCreationSucc);
        }
        fwrite($myfile, "/*------------------------Rss Feed Table----------------------------*/\n\n");
         fwrite($myfile, "SET FOREIGN_KEY_CHECKS = 0;\n\n");
        foreach ($result as $values) {
            $fileContent = '';
            $feedUrl = addslashes($values->rss_feed_url);
            // $city = $this->db->real_escape_string($city);
            $feedContent = $values->feed_content;
           
                $fileContent = "insert into rss_feed values('" . $values->id . "','" . $values->rss_link_id . "','" . $feedUrl . "'," . $this->db->escape($feedContent) . "," . $this->db->escape($values->title) . "," . $this->db->escape($values->description) . ",'" . $values->date . "'," . $this->db->escape($values->img_url) . ",'" . $values->modified_date . "');" . "\n\n";

            fwrite($myfile, $fileContent);
        }

        $this->db->select("*");
        $this->db->where("modified_date>=DATE_SUB(CURDATE(), INTERVAL ".$days." DAY)");
        $queryRssEntity = $this->db->get("rss_entity");
        //  echo $this->db->last_query();
        $resultRssEntity = $queryRssEntity->result();
        $myfile = fopen($filePath, "a");
        fwrite($myfile, "/*------------------------Entities Table----------------------------*/\n\n");
        $this->db->select("*");
        $this->db->where("modified_date>=DATE_SUB(CURDATE(), INTERVAL ".$days." DAY)");
        $queryEn = $this->db->get("entities");
        //  echo $this->db->last_query();
        $resultEn = $queryEn->result();
        foreach ($resultEn as $valuesEn) {
            $fileContent = '';



            $fileContent = "insert into entities values('" . $valuesEn->id . "','" . $valuesEn->entity_name . "','" . $valuesEn->modified_date . "');" . "\n\n";

            fwrite($myfile, $fileContent);
        }
        $myfile = fopen($filePath, "a");
        chmod($filePath, 0777);
        fwrite($myfile, "/*------------------------Rss Entity Table----------------------------*/\n\n");
        foreach ($resultRssEntity as $valuesRe) {
            $fileContent = '';
            $feedUrl = addslashes($values->rss_feed_url);


            $fileContent = "insert into rss_entity values('" . $valuesRe->id . "','" . $valuesRe->rss_feed_url_id . "','" . $valuesRe->entity_name_id . "','" . $valuesRe->category_id . "','" . $valuesRe->modified_date . "');" . "\n\n";

            fwrite($myfile, $fileContent);
        }


        $zip = new ZipArchive;
        $res = $zip->open("dbsync/" . $fileName . ".zip", ZipArchive::CREATE);

        if ($res === TRUE) {
            if (file_exists("dbsync/" . $fileName . ".sql")) {
                $zip->addFile("dbsync/" . $fileName . ".sql", $fileName . ".sql");
            }

            $zip->close();
            $content = "Zip created on server For client sync";
        } else {
            $content = "Zip coudnt be created for Client sync";
        }
        return $content;
    }

    function getMailId() {
        $this->db->select("email,id,user_name,first_name");
        $query = $this->db->get("client_users");
        // echo $this->db->last_query();
        return $query->result_array();
    }

    function getSources() {
        $this->db->select("*");
        $query = $this->db->get("rss_link");
        return $query->result_array();
    }

    function getSourceDetail($id) {
        $this->db->select("*");
        $this->db->where("id", $id);
        $query = $this->db->get("rss_link");
        // echo $this->db->last_query();
        return $query->row_array();
    }

    function getSourceBookmark($userId) {
        
    }

    function getLogs()
    { ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
         $this->db->select("*",false);
        
        $query = $this->db->get("log_activities");
         return $query->result_array();
    }
    function getMergedEntities() {
        $this->db->select("distinct merged_entity_name,not_merged_entity_name,cat_name,id",false);
        $this->db->group_by('merged_entity_name');
        $query = $this->db->get("media_entity_merge");
        //echo $this->db->last_query();
        return $query->result_array();
    }

    function restoreMergedEntities($aliasEntityName) {
        $this->db->select('rss_entity_id,merged_entity_id,not_merged_entity_name');
        $this->db->where('not_merged_entity_name', $aliasEntityName);
        $query = $this->db->get("media_entity_merge");
        $result = $query->result_array();
        foreach ($result as $values) {
            $data = array("entity_name_id" => $values["merged_entity_id"]);
            $this->db->where('id', $values["rss_entity_id"]);
            $this->db->update('rss_entity', $data);
        }

        $this->db->where('merged_entity_name', $aliasEntityName);
        $this->db->delete('media_entity_merge');
        //echo $this->db->last_query();
    }

    function mergeEntities($arrEntities) {
//        $entity=array();
        $entity = $arrEntities["leftForm"][0];
        $catName=$arrEntities["cat"];
        $this->db->select("entity_name");
        $this->db->where("id", $entity);
        $queryNotMergedName = $this->db->get("entities");
        $resultNotMergedName = $queryNotMergedName->row_array();
        $notMergedEntityName = $resultNotMergedName["entity_name"];
        $data = array("entity_name_id" => $entity);
        $dataBookMarks = array("entity_id" => $entity);
        $entityToMerge = $arrEntities["rightForm"];
        foreach ($entityToMerge as $values) {
            $this->db->select("entity_name");
            $this->db->where("id", $values);
            $query = $this->db->get("entities");
            $result = $query->row_array();
            $entityName = $result["entity_name"];
            $this->db->select("id");
            $this->db->where("entity_name_id", $values);
            $queryRssEntityId = $this->db->get("rss_entity");
            $resultId = $queryRssEntityId->result_array();

            foreach ($resultId as $ids) {

                //perfrom insert operations to merge_table for restore operations
//                $this->db>query("insert into media_entity_merge values(NULL,'".$ids."','".$entityName."','".$notMergedEntityName."','".$values."','".$entity."')");

                $this->db->set('rss_entity_id', $ids["id"]);
                $this->db->set('merged_entity_name', $entityName);
                $this->db->set('not_merged_entity_name', $notMergedEntityName);
                $this->db->set('merged_entity_id', $values);
                $this->db->set('not_merged_entity_id', $entity);
                  $this->db->set('cat_name', $catName);
                $this->db->insert('media_entity_merge');
//                echo $this->db->last_query();
            }
        }
        //  echo $this->db->last_query();
//        pr($ids);
//         pr($entityName);
//          pr($notMergedEntityName);
//           pr($values);
//            pr($entity);
        $this->db->where_in('entity_name_id', $entityToMerge);
        $this->db->update('rss_entity', $data);

        $this->db->where_in('entity_id', $entityToMerge);
        $this->db->update('user_bookmarks', $dataBookMarks);

//        echo $this->db->last_query();
    }

    function updateSource($id, $link, $attribute_name, $attribute_value, $tag_name, $publisher) {

        $this->db->set('link', $link);
        $this->db->set('attribute_name', $attribute_name);
        $this->db->set('attribute_value', $attribute_value);
        $this->db->set('tag_name', $tag_name);
        $this->db->set('publisher', $publisher);
        $this->db->where("id", $id);
        $query = $this->db->update('rss_link');
        return $query;
    }

    function saveSourceData($id, $link, $attribute_name, $attribute_value, $tag_name, $publisher) {
        $this->db->set('link', $link);
        $this->db->set('attribute_name', $attribute_name);
        $this->db->set('attribute_value', $attribute_value);
        $this->db->set('tag_name', $tag_name);
        $this->db->set('publisher', $publisher);
        $query = $this->db->insert('rss_link');
        return $query;
    }

    function ignoreSource($id) {
        $this->db->set('ignore', 1);
        $this->db->where("id", $id);
        $query = $this->db->update('rss_link');
        return $query;
    }

    function restoreSource($id) {
        $this->db->set('ignore', 0);
        $this->db->where("id", $id);
        $query = $this->db->update('rss_link');
        return $query;
    }

    function getBookMarkedArticles($userId,$onPageLoad='') {
        $this->db->select('distinct rss_link.publisher,rss_feed.id,rss_feed.img_url,rss_feed.title,rss_feed.description,rss_feed.rss_feed_url,rss_feed.date,rss_feed.modified_date', false);
        $this->db->join('rss_entity', 'rss_entity.entity_name_id=user_bookmarks.entity_id', 'left');
        $this->db->join('rss_feed', 'rss_entity.rss_feed_url_id=rss_feed.id', 'left');
        $this->db->join('rss_link', 'rss_feed.rss_link_id=rss_link.id ', 'left');
        $this->db->where('user_bookmarks.user_id', $userId);
        if($onPageLoad==''){
            $this->db->where('rss_feed.date >=',date('Y-m-d'));
            $this->db->where('user_bookmarks.user_id NOT IN (SELECT user_id from media_email_settings where `option`="no") ');

            
        }
        else {
			 $old_startdate_timestamp = strtotime(date('Y-m-d', strtotime("-3 days")));
                $startDate = date('Y-m-d', $old_startdate_timestamp);
                $arrParams['start_date'] = $startDate;
                $old_enddate_timestamp = strtotime(date('Y-m-d', strtotime("-3 days")));
                $endDate = date('Y-m-d', $old_enddate_timestamp);
           // $this->db->where('rss_feed.date >=',);
            $this->db->where('rss_feed.date>=', "'" . $startDate . " 00:00:00'", false);
                $this->db->where('rss_feed.date<=', "'" . $endDate . " 23:23:59'", false);
       }
        $this->db->limit(10);
        $this->db->order_by('rss_feed.modified_date','DESC');
        $query = $this->db->get('user_bookmarks');
        //echo $this->db->last_query()."<br/>";
        return $query->result_array();
    }

    function getEntityCategoryCount($category_name, $isAnalystSet) {
        $user_id = $this->session->userdata("user_id");
        $this->db->select('rss_entity.id,rss_entity.rss_feed_url_id,entities.id ,entities.entity_name,categories.category_name,COUNT(distinct rss_feed_url_id) AS numc');
        $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
        $this->db->join('categories', 'rss_entity.category_id = categories.id', 'left');
        $this->db->join('rss_feed', 'rss_entity.rss_feed_url_id = rss_feed.id  ', 'left');
        $this->db->join('rss_link', 'rss_feed.rss_link_id = rss_link.id  ', 'left');
        $names = array('SocialTag', 'PublishedMedium', 'City', 'Facility', 'Position');
        $this->db->where_not_in('categories.category_name', $names);
        $this->db->where('categories.category_name', $category_name);

        $clientId = $this->session->userdata("client_id");
        if ($clientId == INTERNAL_CLIENT_ID)
            $this->db->where('rss_entity.entity_name_id NOT IN(Select entity_id from user_blacklists where user_id is NULL)');
        else
            $this->db->where('rss_entity.entity_name_id NOT IN(SELECT entity_id from user_blacklists where user_id="' . $userId . '" or user_id is NULL)');
        $this->db->where("rss_link.ignore !=", '1');
        $this->db->group_by("entity_name_id");
        if (!$isAnalystSet)
            $this->db->order_by("numc", "desc");
        $this->db->order_by("entity_name", "asc");
        $query = $this->db->get('rss_entity');
        // echo $this->db->last_query()."<br/><br/>";
        return $query->result_array();
    }

    function getEntitesForMerge($category_name,$list=false) {
        $user_id = $this->session->userdata("user_id");
        $this->db->select('rss_entity.id,rss_entity.rss_feed_url_id,entities.id ,entities.entity_name,categories.category_name,COUNT(distinct rss_feed_url_id) AS numc');
        $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
        // $this->db->join('user_bookmarks', 'user_bookmarks.entity_id = entities.id', 'left');
         //  $this->db->join('user_blacklists', 'user_blacklists.entity_id = entities.id', 'left');
        $this->db->join('categories', 'rss_entity.category_id = categories.id', 'left');

        $names = array('SocialTag', 'PublishedMedium', 'City', 'Facility', 'Position','PhoneNumber');
        $this->db->where_not_in('categories.category_name', $names);
        if($category_name!='')
        $this->db->where('categories.category_name', $category_name);
        if(!$list)
        $this->db->where('rss_entity.entity_name_id NOT IN(Select merged_entity_id from media_entity_merge )');
        else{
//              $this->db->where('rss_entity.entity_name_id NOT IN (Select entity_id from user_bookmarks )');
//                $this->db->where('rss_entity.entity_name_id NOT IN (Select entity_id from user_blacklists )');
              
        }
        

        $this->db->group_by("entity_name");

        $query = $this->db->get('rss_entity');
//         echo $this->db->last_query()."<br/><br/>";
        return $query->result_array();
    }

    function getEachTotalCatCount() {
        $query = $this->db->query("SELECT categories.id, categories.category_name,COUNT(DISTINCT rss_entity.rss_feed_url_id) as num
       FROM rss_entity
       LEFT JOIN categories ON rss_entity.category_id = categories.id
       and categories.category_name  in('Person', 'MedicalCondition', 'Technology','Company','Organization')
       and rss_entity.entity_name_id NOT IN(Select entity_id from user_blacklists)
       GROUP BY rss_entity.category_id
        ");

        return $query->result_array();
    }

    function saveComment($user_id, $comment, $feed_id) {
        $this->db->set('user_id', $user_id);
        $this->db->set('feed_id', $feed_id);
        $this->db->set('date', date("Y-m-d H:i:s"));
        $this->db->set('comment', $comment);
        $this->db->insert('user_comments');
        $this->db->select('first_name,last_name');
        $this->db->join('client_users', 'client_users.id = user_comments.user_id', left);
        $this->db->where('client_users.id', $user_id);
        $query = $this->db->get('user_comments');
        return $query->row_array();
    }

    function getComment($feed_id) {
        $this->db->select('comment,user_name,date,first_name,last_name');
        $this->db->join('client_users', 'client_users.id = user_comments.user_id', left);
        $this->db->where('feed_id', $feed_id);
        $this->db->order_by('date', 'asc');
        $query = $this->db->get('user_comments');
        return $query->result_array();
    }

    function saveTag($userId, $entityId, $tagName) {
        $this->db->select("tag_name,id");
        $this->db->where("tag_name", $tagName);
        $query = $this->db->get("media_tags");
        if ($query->num_rows > 0) {
            $result = $query->row_array();
            $tagId = $result["id"];

            $this->db->select("entity_id");
            $this->db->where("entity_id", $entityId);
            $this->db->where("tag_id", $tagId);
            $queryResult = $this->db->get("entity_tags");
            if ($queryResult->num_rows == 0) {
                $this->db->set('tag_id', $tagId);
                $this->db->set('user_id', $userId);
                $this->db->set('entity_id', $entityId);
                $this->db->insert("entity_tags");
                return true;
            } else {
                return false;
            }
        } else {

            $this->db->set('tag_name', $tagName);
            $this->db->set('user_id', $userId);
            $this->db->insert("media_tags");
            $id = $this->db->insert_id();
            $this->db->set('tag_id', $id);
            $this->db->set('user_id', $userId);
            $this->db->set('entity_id', $entityId);
            $this->db->insert("entity_tags");
            return true;
        }
    }

    function getTagName($userId, $tagName) {
        $this->db->select("distinct media_tags.tag_name,media_tags.id", false);
        $this->db->join('media_tags', 'media_tags.id=entity_tags.tag_id', 'left');
        $this->db->where("entity_tags.user_id", $userId);
        $this->db->like("media_tags.tag_name", $tagName);
        $query = $this->db->get("entity_tags");
        $arrRet = array();
        foreach ($query->result_array() as $row) {
            $arrRet[] = $row;
        }

        return $arrRet;
    }

    function getTagEntities($tagName) {
        $this->db->select("id");
        $this->db->where("tag_name", $tagName);
        $query = $this->db->get("media_tags");
        $result = $query->row_array();
        $this->db->select(" categories.category_name, media_tags.tag_name,entity_tags.tag_id,entity_tags.entity_id,entities.entity_name,entities.id");
        $this->db->join('rss_entity', ' entity_tags.entity_id = rss_entity.entity_name_id', 'left');
        $this->db->join('categories', ' rss_entity.category_id = categories.id', 'left');
        $this->db->join('entities', ' rss_entity.entity_name_id = entities.id', 'left');
        $this->db->join('media_tags', ' entity_tags.tag_id = media_tags.id', 'left');
        $this->db->where("entity_tags.tag_id", $result["id"]);
        $this->db->where("categories.category_name !=", 'SocialTag');
        $this->db->group_by("entity_tags.entity_id");
        $queryTag = $this->db->get("entity_tags");
        $resultTag = $queryTag->result_array();
        return $resultTag;
    }

    function userSpecificTags($userId, $entName) {
        $this->db->select('id');
        $this->db->where('entity_name', $entName);
        $queryId = $this->db->get("entities");
        $resultId = $queryId->row_array();
        $this->db->select("media_tags.tag_name,media_tags.id");
        $this->db->join('media_tags', 'media_tags.id=entity_tags.tag_id', 'left');
        $this->db->where('entity_id', $resultId["id"]);
        $queryTags = $this->db->get("entity_tags");
        return $queryTags->result_array();
    }

    function getIgnoredEntities($userId) {
        $this->db->select("distinct categories.category_name,entities.id,entities.entity_name", false);
        $this->db->join('rss_entity', 'rss_entity.entity_name_id = user_blacklists.entity_id ', 'left');
        $this->db->join('entities', 'entities.id = rss_entity.entity_name_id', 'left');
        $this->db->join('categories', 'categories.id = rss_entity.category_id ', 'left');
        $names = array('SocialTag', 'PublishedMedium', 'City', 'Facility');
        $this->db->where_not_in('categories.category_name', $names);
        $clientId = $this->session->userdata("client_id");
//        if ($clientId == INTERNAL_CLIENT_ID)
//            $this->db->where('user_blacklists.user_id is NULL ');
//        else {
            $id = $userId;
            $this->db->where('user_blacklists.user_id ', $id);
      //  }

        $this->db->where('categories.category_name !=', "SocialTag");
        $query = $this->db->get("user_blacklists");
        return $query->result_array();
    }

    function removeBlacklists($userId, $entityId) {
        $this->db->where('entity_id', $entityId);
//        $clientId = $this->session->userdata("client_id");
//        if ($clientId == INTERNAL_CLIENT_ID)
//            $this->db->where('user_id is NULL');
//        else
        if($userId=='null'){
            
         $this->db->where('user_id is NULL');
        }
        else{
            $this->db->where('user_id', $userId);
        }
            $this->db->delete('user_blacklists');
//            echo $this->db->last_query();
			//Add Log activity
            $arrLogDetails = array(
            		'type' => REMOVE_IGNORE,
            		'description' => 'Removes the ignore of particular entity',
            		'status' => STATUS_SUCCESS,
            		'transaction_id' =>  $entityId,
            		'transaction_table_id' => USER_BLACKLISTS,
            		'transaction_name' => "Remove Ignore"
            );
            $this->config->set_item('log_details', $arrLogDetails);
        return true;
    }

    function checkEntityName($completeName, $doCount = false) {
        if ($doCount)
            $this->db->select('count(*) as numc');
        else
            $this->db->select('entity_name');
        $this->db->or_where_in('entity_name', $completeName);
        $query = $this->db->get('entities');
        if ($query->num_rows > 0) {
            if ($doCount) {
                $row = $query->row_array();
                return $row['numc'];
            } else
                return $query->row_array();
        }
        else {
            if ($doCount)
                return 0;
            else
                return fail;
        }
    }

    function getCommentCount($feed_id, $OnurlHit) {
        $this->db->select('feed_id,count(feed_id) as comment_count');
        if ($feed_id != null)
            $this->db->where('feed_id', $feed_id);
        $this->db->group_by('feed_id');
        $query = $this->db->get('user_comments');
        if ($OnurlHit != 1)
            return $query->row_array();
        else
            return $query->result_array();
    }

    function blacklist_entity($entity_id, $user_id) {
//        $this->db->select('entity_id');
//        $this->db->where('entity_id',$entity_id);
//        if($user_id!=null)
//            $this->db->where('user_id',$user_id);
//        else
//             $this->db->where('user_id is NULL');
//        $query=$this->db->get('user_blacklists');
//        echo $this->db->last_query();
//
//        if($query->num_rows>0)
//        {
//            $this->db->where('entity_id',$entity_id);
//            $this->db->delete('user_blacklists'); 
//            $this->db->set('user_id',$user_id);
//            $this->db->set('entity_id',$entity_id);
//            $this->db->insert('user_blacklists');
//            return true;
//        }
//        else
//        {
//           $this->db->set('user_id',$user_id);
//           $this->db->set('entity_id',$entity_id);
//           $this->db->insert('user_blacklists');
//            return true;
//        }
        $this->db->select('*');
        $this->db->where('user_id', $user_id);
        $this->db->where('entity_id', $entity_id);
        $query = $this->db->get('user_blacklists');
//        echo $this->db->last_query();
        if ($query->num_rows <= 0) {
           
        $this->db->set('user_id', $user_id);
        $this->db->set('entity_id', $entity_id);
        $this->db->insert('user_blacklists');
        }
        //Add Log activity
        $arrLogDetails = array(
        		'type' => MARK_AS_IGNORED,
        		'description' => 'Do Not Show Entity',
        		'status' => STATUS_SUCCESS,
        		'transaction_id' =>  $entity_id,
        		'transaction_table_id' => USER_BLACKLISTS,
        		'transaction_name' => "Mark As Ignored"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        return true;
    }

    function getMessage($id)
    {
        $this->db->query("insert into ajax values(3,'4')");
    }
   function getFeedsToDisplay($arrParams,$isCountSet) {
        $arrFeedUrlIds = $this->getAllFeedUrlIds($arrParams);

        $this->db->select(' rss_feed.rss_feed_url,rss_feed.id as rss_feed_url_id,rss_feed.img_url,rss_feed.title,rss_feed.description,rss_link.publisher,rss_feed.date');

        $this->db->order_by("date", "desc");
        if (isset($arrParams['offset']) && $isCountSet!=true) {
            $this->db->LIMIT(10, $arrParams['offset']);
        } else {
            if($isCountSet!=true)
                $this->db->LIMIT(10, 0);
        }
        if (isset($arrParams['start_date']) && $arrParams['start_date'] != '') {
            // pr($arrParams);
            $this->db->where('date>=', "'" . $arrParams['start_date'] . " 00:00:00'", false);
            $this->db->where('date<=', "'" . $arrParams['end_date'] . " 23:23:59'", false);
        }
        $isRssEntiryJoined = false;
        if (isset($arrParams['user_id'])) {
            $isRssEntiryJoined = true;
            $this->db->join('rss_entity', 'rss_entity.rss_feed_url_id = rss_feed.id', 'left');
            $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
            $this->db->join('user_bookmarks', 'user_bookmarks.entity_id = rss_entity.entity_name_id', 'left');
            $this->db->where('date>=', "'" . $arrParams['start_date'] . "'", false);
            $this->db->where('user_id', $arrParams['user_id']);
        }

        if (isset($arrParams['stat_filters']) && count($arrParams['stat_filters']) > 0) {
            if (!$isRssEntiryJoined) {
                $this->db->join('rss_entity', 'rss_entity.rss_feed_url_id = rss_feed.id', 'left');
                $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
            }


            $this->db->where_in('rss_feed.id', $arrFeedUrlIds);
        }


        $this->db->join('rss_link', 'rss_feed.rss_link_id = rss_link.id', 'left');
        if (count($arrFeedUrlIds) == 0)
            $this->db->where('rss_link.ignore !=', '1');

        $this->db->group_by('rss_feed.id');
        $query = $this->db->get('rss_feed');
//        echo $this->db->last_query();
        return $query->result_array();
    }

    function ajax_entity_filter($entity_name) {
        $query = $this->db->query("SELECT distinct rss_entity.rss_feed_url_id,rss_feed.rss_feed_url,rss_feed.img_url,rss_feed.date,rss_feed.title,rss_feed.description,entities.entity_name
        from rss_feed,rss_entity,entities
        where entities.id=rss_entity.entity_name_id
        and rss_feed.id=rss_entity.rss_feed_url_id
        and entities.entity_name='" . $entity_name . "' ");
        return $query->result();
    }

    function searchEntityName($category, $keyword) {
        if ($category == 'people')
            $id = 96;
        if ($category == 'disease')
            $id = 100;
        if ($category == 'technology')
            $id = 98;
        if ($category == 'organization')
            $id = 95;
        if ($category == 'company')
            $id = 105;
        if ($category == 'product')
            $id = 110;
        $query = $this->db->query("SELECT DISTINCT `maintable`.`entity_name_id` as id, `maintable`.`rss_feed_url_id`, `entities`.`entity_name`, `categories`.`category_name`, COUNT(distinct maintable.rss_feed_url_id) AS numc
FROM (`rss_entity` as maintable)
LEFT JOIN `entities` ON `maintable`.`entity_name_id` = `entities`.`id`
LEFT JOIN `categories` ON `maintable`.`category_id` = `categories`.`id`
WHERE `maintable`.`category_id` = $id
AND `maintable`.`entity_name_id` NOT IN(SELECT entity_id from user_blacklists where user_id is NULL)
and entities.entity_name like '$keyword%'
GROUP BY `entities`.`id`
ORDER BY `numc` desc, `entity_name` asc;");
        // echo $this->db->last_query();

        return $query->result_array();
    }

    function category_filter($category_id, $arrFilters, $isCount = false, $entiCount = false, $keyword, $searchParam) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        if ($arrFilters['sel_option'] == 1) {
            global $linkJoined;
            $linkJoined = 0;
            if ($isCount) {

                $this->db->select("COUNT(DISTINCT other_ent.rss_feed_url_id)  AS numc");
                $this->db->join('rss_entity ', " user_bookmarks.entity_id = rss_entity.entity_name_id  ", 'left');

                $this->db->join('rss_entity AS other_ent ', "rss_entity.rss_feed_url_id = other_ent.rss_feed_url_id  ", 'left');
            } elseif ($category_id == 'link') {
                $this->db->distinct();

                $this->db->select('rss_link.id  AS id,  rss_link.publisher,  COUNT(DISTINCT other_ent.rss_feed_url_id) AS numc');
                $this->db->join('rss_entity ', " user_bookmarks.entity_id = rss_entity.entity_name_id  ", 'left');

                $this->db->join('rss_entity AS other_ent ', "rss_entity.rss_feed_url_id = other_ent.rss_feed_url_id  ", 'left');
                $this->db->join('rss_feed', "other_ent.rss_feed_url_id = rss_feed.id", 'left');
                $this->db->join('rss_link', "rss_feed.rss_link_id = rss_link.id", 'left');

                $this->db->where("rss_link.ignore !=", '1');
            } else {
                $this->db->distinct();
                $this->db->select('other_ent.entity_name_id as id ,other_ent.rss_feed_url_id,entities.entity_name,categories.category_name,COUNT(distinct other_ent.rss_feed_url_id) AS numc');
                $this->db->join('rss_entity ', " user_bookmarks.entity_id = rss_entity.entity_name_id  ", 'left');

                $this->db->join('rss_entity AS other_ent ', "rss_entity.rss_feed_url_id = other_ent.rss_feed_url_id  ", 'left');
            }

            $userId = $arrFilters['user_id'];
            $clientId = $this->session->userdata("client_id");
            $this->db->join('entities', 'other_ent.entity_name_id = entities.id', 'left');
            $this->db->join('categories', 'other_ent.category_id = categories.id', 'left');
            if ($category_id != 'link') {

                $this->db->where('other_ent.category_id', $category_id);
            }
            if($category_id!="link")
            {
//            if ($clientId == INTERNAL_CLIENT_ID)
//                $this->db->where('other_ent.entity_name_id NOT IN(SELECT entity_id from user_blacklists where user_id is NULL)');
//            else
                $this->db->where('other_ent.entity_name_id NOT IN(SELECT entity_id from user_blacklists where user_id="' . $userId . '" or user_id is NULL)');
            }
            if (isset($arrFilters['people']) && count($arrFilters['people']) > 0 && $category_id != 96) {
                $this->db->join('rss_entity as ppl', "other_ent.rss_feed_url_id = ppl.rss_feed_url_id AND ppl.category_id = 96", 'left');
                $this->db->where_in("ppl.entity_name_id", $arrFilters['people']);
            }
            if (isset($arrFilters['disease']) && count($arrFilters['disease']) > 0 && $category_id != 100) {
                $this->db->join('rss_entity as dis', "other_ent.rss_feed_url_id = dis.rss_feed_url_id AND dis.category_id = 100", 'left');
                $this->db->where_in("dis.entity_name_id", $arrFilters['disease']);
            }
            if (isset($arrFilters['organization']) && count($arrFilters['organization']) > 0 && $category_id != 95) {
                $this->db->join('rss_entity as org', "other_ent.rss_feed_url_id = org.rss_feed_url_id AND org.category_id = 95", 'left');
                $this->db->where_in("org.entity_name_id", $arrFilters['organization']);
            }
            if (isset($arrFilters['technology']) && count($arrFilters['technology']) > 0 && $category_id != 98) {
                $this->db->join('rss_entity as tech', "other_ent.rss_feed_url_id = tech.rss_feed_url_id AND tech.category_id = 98", 'left');
                $this->db->where_in("tech.entity_name_id", $arrFilters['technology']);
            }
            if (isset($arrFilters['company']) && count($arrFilters['company']) > 0 && $category_id != 105) {
                $this->db->join('rss_entity as cmp', "other_ent.rss_feed_url_id = cmp.rss_feed_url_id AND cmp.category_id = 105", 'left');
                $this->db->where_in("cmp.entity_name_id", $arrFilters['company']);
            }
            if (isset($arrFilters['product']) && count($arrFilters['product']) > 0 && $category_id != 110) {
                $this->db->join('rss_entity as prod', "other_ent.rss_feed_url_id = prod.rss_feed_url_id AND prod.category_id = 110", 'left');
                $this->db->where_in("prod.entity_name_id", $arrFilters['product']);
            }
            if ($searchParam != '')
                $this->db->like('entities.entity_name', $keyword, 'after');
            if (isset($arrFilters['link']) && count($arrFilters['link']) > 0 && $category_id != 'link') {
                if ($category_id != "link")
                    $this->db->join('rss_feed', "other_ent.rss_feed_url_id = rss_feed.id", 'left');
                $this->db->where_in("rss_feed.rss_link_id", $arrFilters['link']);
            }


            if (isset($arrFilters['start_date']) && $arrFilters['end_date'] != '') {
                //echo $linkJoined;
                //pr($category_id);
                $old_startdate_timestamp = strtotime($arrFilters['start_date']);
                $startDate = date('Y-m-d', $old_startdate_timestamp);
                $arrParams['start_date'] = $startDate;
                $old_enddate_timestamp = strtotime($arrFilters['end_date']);
                $endDate = date('Y-m-d', $old_enddate_timestamp);
                $arrParams['end_date'] = $endDate;
                $this->db->where('date>=', "'" . $startDate . " 00:00:00'", false);
                $this->db->where('date<=', "'" . $endDate . " 23:23:59'", false);
                if (count($arrFilters['link']) == 0 && $category_id != "link") {
                    $this->db->join('rss_feed', 'rss_feed.id = other_ent.rss_feed_url_id', 'left');
                    $this->db->join('rss_link', "rss_feed.rss_link_id = rss_link.id", 'left');
                    $this->db->where("rss_link.ignore !=", '1');
                }
//     if( $category_id!="link" )
//                $this->db->join('rss_feed', 'rss_feed.id = maintable.rss_feed_url_id','left');
            }




            $this->db->where('user_id', $arrFilters['user_id']);


            if (!$isCount) {
                if ($category_id == 'link')
                    $this->db->group_by("rss_feed.rss_link_id");
                else
                    $this->db->group_by("entities.id");
                $this->db->order_by("numc", "desc");
                $this->db->order_by("entity_name", "asc");
            }
            $query = $this->db->get('user_bookmarks');
        }
        else {
            global $linkJoined;
            $linkJoined = 0;
            if ($isCount) {

                $this->db->select("COUNT(DISTINCT maintable.rss_feed_url_id)  AS numc");
            } elseif ($category_id == 'link') {
                $this->db->distinct();

                $this->db->select('maintable.id  AS id,  maintable.publisher,  COUNT(DISTINCT rss_feed.id) AS numc');
                $this->db->join('rss_feed', "rss_feed.rss_link_id = maintable.id", 'left');
                $this->db->join('rss_entity', "rss_entity.rss_feed_url_id = rss_feed.id", 'left');
                $this->db->where("maintable.ignore !=", '1');
            } else {
                $this->db->distinct();
                $this->db->select('maintable.entity_name_id as id ,maintable.rss_feed_url_id,entities.entity_name,categories.category_name,COUNT(distinct maintable.rss_feed_url_id) AS numc');
            }

            $userId = $arrFilters['user_id'];
            $clientId = $this->session->userdata("client_id");
            if($category_id!=link)
            {
            $this->db->join('entities', 'maintable.entity_name_id = entities.id', 'left');
            $this->db->join('categories', 'maintable.category_id = categories.id', 'left');
            }
            else
            {
                $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
                $this->db->join('categories', 'rss_entity.category_id = categories.id', 'left');
            }
            if ($category_id != 'link') {

                $this->db->where('maintable.category_id', $category_id);
            }
            if($category_id!="link")
            {
//            if ($clientId == INTERNAL_CLIENT_ID)
//                $this->db->where('maintable.entity_name_id NOT IN(SELECT entity_id from user_blacklists where user_id is NULL)');
//            else
                $this->db->where('maintable.entity_name_id NOT IN(SELECT entity_id from user_blacklists where user_id="' . $userId . '" or user_id is NULL)');
            }
            if (isset($arrFilters['people']) && count($arrFilters['people']) > 0 && $category_id != 96) {
                if($category_id!="link")
                    $this->db->join('rss_entity as ppl', "maintable.rss_feed_url_id = ppl.rss_feed_url_id AND ppl.category_id = 96", 'left');
                else
                     $this->db->join('rss_entity as ppl', "rss_entity.rss_feed_url_id = ppl.rss_feed_url_id AND ppl.category_id = 96", 'left');
                $this->db->where_in("ppl.entity_name_id", $arrFilters['people']);
            }
            if (isset($arrFilters['disease']) && count($arrFilters['disease']) > 0 && $category_id != 100) {
                if($category_id!="link")
                    $this->db->join('rss_entity as dis', "maintable.rss_feed_url_id = dis.rss_feed_url_id AND dis.category_id = 100", 'left');
                else {
                    $this->db->join('rss_entity as dis', "rss_entity.rss_feed_url_id = dis.rss_feed_url_id AND dis.category_id = 100", 'left');
                }
                $this->db->where_in("dis.entity_name_id", $arrFilters['disease']);
            }
            if (isset($arrFilters['organization']) && count($arrFilters['organization']) > 0 && $category_id != 95) {
                 if($category_id!="link")
                    $this->db->join('rss_entity as org', "maintable.rss_feed_url_id = org.rss_feed_url_id AND org.category_id = 95", 'left');
                else
                    $this->db->join('rss_entity as org', "rss_entity.rss_feed_url_id = org.rss_feed_url_id AND org.category_id = 95", 'left');
                 $this->db->where_in("org.entity_name_id", $arrFilters['organization']);
            }
            if (isset($arrFilters['technology']) && count($arrFilters['technology']) > 0 && $category_id != 98) {
                if($category_id!="link")
                    $this->db->join('rss_entity as tech', "maintable.rss_feed_url_id = tech.rss_feed_url_id AND tech.category_id = 98", 'left');
                else
                     $this->db->join('rss_entity as tech', "rss_entity.rss_feed_url_id = tech.rss_feed_url_id AND tech.category_id = 98", 'left');
                $this->db->where_in("tech.entity_name_id", $arrFilters['technology']);
            }
            if (isset($arrFilters['company']) && count($arrFilters['company']) > 0 && $category_id != 105) {
                if($category_id!="link")
                    $this->db->join('rss_entity as cmp', "maintable.rss_feed_url_id = cmp.rss_feed_url_id AND cmp.category_id = 105", 'left');
                else {
                     $this->db->join('rss_entity as cmp', "rss_entity.rss_feed_url_id = cmp.rss_feed_url_id AND cmp.category_id = 105", 'left');
                }
                $this->db->where_in("cmp.entity_name_id", $arrFilters['company']);
            }
            if (isset($arrFilters['product']) && count($arrFilters['product']) > 0 && $category_id != 110) {
                if($category_id!="link")
                    $this->db->join('rss_entity as prod', "maintable.rss_feed_url_id = prod.rss_feed_url_id AND prod.category_id = 110", 'left');
                else {
                     $this->db->join('rss_entity as prod', "rss_entity.rss_feed_url_id = prod.rss_feed_url_id AND prod.category_id = 110", 'left');
                }
                $this->db->where_in("prod.entity_name_id", $arrFilters['product']);
            }
            if ($searchParam != '')
                $this->db->like('entities.entity_name', $keyword, 'after');
            if (isset($arrFilters['link']) && count($arrFilters['link']) > 0 && $category_id != 'link') {
                if ($category_id != "link")
                    $this->db->join('rss_feed', "maintable.rss_feed_url_id = rss_feed.id", 'left');
                $this->db->where_in("rss_feed.rss_link_id", $arrFilters['link']);
            }


            if (isset($arrFilters['start_date']) && $arrFilters['end_date'] != '') {
                //echo $linkJoined;
                //pr($category_id);
                $old_startdate_timestamp = strtotime($arrFilters['start_date']);
                $startDate = date('Y-m-d', $old_startdate_timestamp);
                $arrParams['start_date'] = $startDate;
                $old_enddate_timestamp = strtotime($arrFilters['end_date']);
                $endDate = date('Y-m-d', $old_enddate_timestamp);
                $arrParams['end_date'] = $endDate;
                $this->db->where('date>=', "'" . $startDate . " 00:00:00'", false);
                $this->db->where('date<=', "'" . $endDate . " 23:23:59'", false);
                if (count($arrFilters['link']) == 0 && $category_id != "link") {
                    $this->db->join('rss_feed', 'rss_feed.id = maintable.rss_feed_url_id', 'left');
                    $this->db->join('rss_link', "rss_feed.rss_link_id = rss_link.id", 'left');
                    $this->db->where("rss_link.ignore !=", '1');
                }
//     if( $category_id!="link" )
//                $this->db->join('rss_feed', 'rss_feed.id = maintable.rss_feed_url_id','left');
            }




            if (!$isCount) {
                if ($category_id == 'link')
                    $this->db->group_by("rss_feed.rss_link_id");
                else
                    $this->db->group_by("entities.id");
                $this->db->order_by("numc", "desc");
                $this->db->order_by("entity_name", "asc");
            }
            if($category_id!="link")
                $query = $this->db->get('rss_entity as maintable');
            else
                 $query = $this->db->get('rss_link as maintable');
        }
//        echo $this->db->last_query()."<br/><br/>";
//         pr($query->result_array());
        if ($isCount) {
            $row = $query->row_array();

            return $row["numc"];
        } else {
            return $query->result_array();
        }
    }

    function getUsersBookmark($user_id) {
        $this->db->select('*');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('user_bookmarks');
        // echo $this->db->last_query()."<br/>";
        return $query->result_array();
    }

    function getUserBlacklists($user_id) {
        $this->db->select('*');
        $clientId = $this->session->userdata("client_id");
        $name = array($user_id, "");
//        if ($clientId == INTERNAL_CLIENT_ID)
//            $this->db->where('user_id', "");
//        else
//            $this->db->or_where_in('user_id', $name);
         $this->db->where('user_id',$user_id);
        $query = $this->db->get('user_blacklists');
//         echo $this->db->last_query();
        return $query->result_array();
    }

    function getUserBookmark($user_id, $rss_id) {

        $query = $this->db->query("SELECT distinct categories.category_name, entities.id,entities.entity_name,rss_entity.rss_feed_url_id
    FROM user_bookmarks
    LEFT JOIN rss_entity ON user_bookmarks.entity_id = rss_entity.entity_name_id
    LEFT JOIN entities ON rss_entity.entity_name_id = entities.id
    LEFT JOIN categories ON categories.id = rss_entity.category_id

  

    where user_bookmarks.user_id=" . $user_id . "
    and rss_entity.rss_feed_url_id=" . $rss_id . "
         AND categories.category_name NOT in ('SocialTag','MedicalTreatMent')
        group by id

    ");
        // echo "hi";
        $arrBookId = array();
        foreach ($query->result() as $values) {
            if ($values->category_name != '') {
                $entNameId = $values->id . "_" . $values->entity_name;
                $arraBookmark['entName'][] = array("$entNameId" => "$values->category_name");
            }
            //$arraBookmark['entName']= array_unique( $arraBookmark['entName']);
            $arrBookId[] = $values->id;
        }
        //var_dump($arrBookId);

        foreach ($arrBookId as $entId) {
            $this->db->select('tag_name');
            $this->db->join('media_tags', 'entity_tags.tag_id = media_tags.id', 'left');
            $this->db->where('entity_tags.entity_id', $entId);
            $queryRes = $this->db->get('entity_tags');
            // echo $this->db->last_query();
            foreach ($queryRes->result_array() as $tags) {
                $arraBookmark["tags"][] = $tags["tag_name"];
                //$arraBookmark["tags"]= array_unique( $arraBookmark["tags"]);
            }
        }
        return $arraBookmark;
    }

    function getUserAjaxUserBookmarks($user_id, $rss_id) {

        $query = $this->db->query("SELECT distinct categories.category_name, entities.id,entities.entity_name,rss_entity.rss_feed_url_id
    FROM user_bookmarks
    LEFT JOIN rss_entity ON user_bookmarks.entity_id = rss_entity.entity_name_id
    LEFT JOIN entities ON rss_entity.entity_name_id = entities.id
    LEFT JOIN categories ON categories.id = rss_entity.category_id

  

    where user_bookmarks.user_id=" . $user_id . "
    and rss_entity.rss_feed_url_id=" . $rss_id . "
         AND categories.category_name NOT in ('SocialTag','MedicalTreatMent')
        group by id

    ");
        $arrBookId = array();
        foreach ($query->result() as $values) {
            $entNameId = $values->id . "_" . $values->entity_name;
            if ($values->category_name != '')
                $arraBookmark['entName'][] = array("$entNameId" => "$values->category_name");
            //$arraBookmark['entName']= array_unique( $arraBookmark['entName']);

            $arrBookId[] = $values->id;
        }

        foreach ($arrBookId as $entId) {
            $this->db->select('tag_name');
            $this->db->join('media_tags', 'entity_tags.tag_id = media_tags.id', 'left');
            $this->db->where('entity_tags.entity_id', $entId);
            $queryRes = $this->db->get('entity_tags');
            foreach ($queryRes->result_array() as $tags) {
                $arraBookmark["tags"][] = $tags["tag_name"];
                $arraBookmark["tags"] = array_unique($arraBookmark["tags"]);
            }
        }
        return $arraBookmark;
    }

    function remove_book_mark($user_id, $entity_id) {
        $this->db->delete('user_bookmarks', array('user_id' => $user_id, 'entity_id' => $entity_id));
        //Add Log activity
        $arrLogDetails = array(
        		'type' => REMOVE_FAVOURITE,
        		'description' => 'Removes the Favourite of particular entity',
        		'status' => STATUS_SUCCESS,
        		'transaction_id' =>  $entity_id,
        		'transaction_table_id' => USER_BOOKMARKS,
        		'transaction_name' => "Remove Favourite"
        );
        $this->config->set_item('log_details', $arrLogDetails);
        $this->db->delete('entity_tags', array('user_id' => $user_id, 'entity_id' => $entity_id));
    }

    function getRssLinkId() {
        $this->db->select('id,link');
        $this->db->order_by('id','desc');
        $query = $this->db->get('rss_link');
        return $query->result();
    }

    function user_bookmark($entity_id, $user_id) {
        $client_id=$this->session->userdata("client_id");
        $this->db->select('*');
        $this->db->where('user_id', $user_id);
        $this->db->where('entity_id', $entity_id);
        $query = $this->db->get('user_bookmarks');
        if ($query->num_rows > 0) {        	
            return "bookmarked";
        } else {
            $this->db->set('user_id', $user_id);
            $this->db->set('entity_id', $entity_id);
            $this->db->insert('user_bookmarks');
            //Add Log activity
            $arrLogDetails = array(
            		'type' => MARK_AS_FAVOURITE,
            		'description' => 'Marked as Favourite',
            		'status' => STATUS_SUCCESS,
            		'transaction_id' =>  $entity_id,
            		'transaction_table_id' => USER_BOOKMARKS,
            		'transaction_name' => "Mark As Favourite"
            );
            $this->config->set_item('log_details', $arrLogDetails);
            return "notbookmarked";
        }        
        
    }

    function user_bookmark_all_users($entity_id, $user_id,$arrUserResults,$isRemoveSet){
                foreach($arrUserResults as $row){
                    if($isRemoveSet=='false'){
                        if($user_id!=$row['id']){
                        $this->db->set('user_id', $row['id']);
                        $this->db->set('entity_id', $entity_id);
                        $this->db->insert('user_bookmarks');
                        }
                    }
                    else{
                        $this->db->where('user_id', $row['id']);
                        $this->db->where('entity_id', $entity_id);
                        $this->db->delete('user_bookmarks');
                    }
                }
    }
    
    function getRssLinkData($rssUrl) {
        $this->db->select('*');
        $this->db->where('id', $rssUrl);
        $query = $this->db->get('rss_link');
        return $query->row_array();
    }

    function insertFeedUrl($value, $rssLinkId, $contents, $img_url) {
        $this->db->select('rss_feed_url');
        $this->db->where('rss_feed_url', $value['link']);
        $query_duplicate = $this->db->get('rss_feed');
        /**
         * Condition to check if the feed ur already exists in rss_feed table
         */
        if ($query_duplicate->num_rows == 0) {
            $id = $rssLinkId;

            $mystring = $value['date'];
            $date_time = substr($mystring, 0, 26);
            $date = strtotime($date_time);
            $formatted_date = date('d-m-Y H:i:s', $date);
            $conv_date = $this->db->query("Select STR_TO_DATE('" . $formatted_date . "', '%d-%m-%Y %H:%i:%s') as dates");
            $result_date = $conv_date->result();
            $nowDate = date('d-m-Y H:i:s');
//            if(($result_date[0]->dates)<=$nowDate)
//            {   
            $this->db->set('feed_content', $contents);

            $this->db->set('title', $value['title']);
            $this->db->set('date', $result_date[0]->dates);
            $this->db->set('description', $value['desc']);
            $this->db->set('rss_feed_url', $value['link']);
            $this->db->set('rss_link_id', $id);
            $this->db->set('img_url', $img_url);
            $res = $this->db->insert('rss_feed');
            if ($res)
                return true;
            else
                return false;
//            }
//           else
//               return false;
        }
        else {
            return false;
        }
    }

    function getFeedId($rssUrl) {
        $this->db->select('id');
        $this->db->where('rss_feed_url', strip_quotes($rssUrl));
        $query = $this->db->get('rss_feed');
        return $query->row_array();
    }

    function getSourceLinks() {
        $this->db->select('id,publisher');
        $query = $this->db->get('rss_link');
        return $query->result_array();
    }

    function getFeedUrl() {
        $this->db->select('id');
        $this->db->where("rss_feed.id NOT IN (SELECT DISTINCT rss_feed_url_id FROM rss_entity)");
        //$this->db->limit(4);
        $query = $this->db->get('rss_feed');
        return $query->result_array();
    }

    function insertParsedEntity($type, $entity, $feed_url, $rssId) {
        $this->db->select('entity_name,id');
        $this->db->where('entity_name', strip_quotes($entity));
        $query = $this->db->get('entities');
        /**
         * Check if the entity name exists in entites table
         */
        if ($query->num_rows() > 0) {
            /**
             * Get the id of entity if present 
             */
            $ent_id_result = $query->row_array();
            $eid = $ent_id_result['id'];

            /**

              /**
             * Get the category id to whcih the entity belongs
             * 
             * 
             */
            $this->db->select('id');
            $this->db->where('category_name', trim(strip_quotes($type)));
            $query_cat_id = $this->db->get('categories');
            if ($query_cat_id->num_rows() > 0) {
                $result_cat_id = $query_cat_id->row_array();
                $cat_id = $result_cat_id['id'];
                /**
                 * insert fetched id's into rss_entity table
                 */
                $this->db->set('category_id', $cat_id);
                $this->db->set('rss_feed_url_id', $rssId);
                $this->db->set('entity_name_id', $eid);
                $this->db->insert('rss_entity');
            }
        } else { /**
         * If entity name doesnt exist in entites table insert it
         * 
         */
            $this->db->select('id');
            $this->db->where('category_name', trim(strip_quotes($type)));
            /**
             * Chekk if the category exists
             */
            $querys = $this->db->get('categories');
            if ($querys->num_rows() > 0) {

                $this->db->set('entity_name', trim(strip_quotes($entity)));
                $this->db->insert('entities');

                /**

                  /**
                 * Get entity_id to insert into rss_entity table
                 */
                $this->db->select('id');
                $this->db->where('entity_name', trim(strip_quotes($entity)));
                $query_entity_id = $this->db->get('entities');
                if ($query_entity_id->num_rows > 0) {
                    $result_entity_id = $query_entity_id->row_array();

                    $entity_id = $result_entity_id['id'];
                    /**
                     * Get the category id to whcih the entity belongs
                     * 
                     * 
                     */
                    $this->db->select('id');
                    $this->db->where('category_name', trim(strip_quotes($type)));
                    $query_cat_id = $this->db->get('categories');
                    $result_cat_id = $query_cat_id->row_array();
                    $cat_id = $result_cat_id['id'];
                    /**
                     * insert fetched id's into rss_entity table
                     */
                    $this->db->set('category_id', $cat_id);
                    $this->db->set('rss_feed_url_id', $rssId);
                    $this->db->set('entity_name_id', $entity_id);
                    $this->db->insert('rss_entity');
                }
            } else {
                /**
                 * Insert the category 
                 */
                if($type=='')
                    return;
                $this->db->set('category_name', $type);
                $this->db->insert('categories');
                $cat_id = $this->db->insert_id();
                /*
                 * Insert non-exisisting entity in to entites table 
                 */
                $this->db->set('entity_name', trim(strip_quotes($entity)));
                $this->db->insert('entities');

                /**

                  /**
                 * Get entity_id to insert into rss_entity table
                 */
                $this->db->select('id');
                $this->db->where('entity_name', trim(strip_quotes($entity)));
                $query_entity_id = $this->db->get('entities');
                if ($query_entity_id->num_rows > 0) {
                    $result_entity_id = $query_entity_id->row_array();

                    $entity_id = $result_entity_id['id'];
                    /**
                     * insert fetched id's into rss_entity table
                     */
                    $this->db->set('category_id', $cat_id);
                    $this->db->set('rss_feed_url_id', $rssId);
                    $this->db->set('entity_name_id', $entity_id);
                    $this->db->insert('rss_entity');
                }
            }
        }
    }

    function getAllFeedUrlIds($arrParams) {
        $arrFeedUrlIds = array();

        $arrCat = array();

        if (isset($arrParams['people']) && count($arrParams['people']) > 0) {
            $arrCat[] = "Person";
            if (isset($arrParams['source_id']))
                $arrFeedUrlIds = $this->getDistinctFeedUrlIds($arrParams['people'], $arrCat, $arrParams['source_id']);
            else
                $arrFeedUrlIds = $this->getDistinctFeedUrlIds($arrParams['people'], $arrCat);
            unset($arrCat);
        }
        if (isset($arrParams['disease']) && count($arrParams['disease']) > 0) {
            $arrCat[] = "MedicalCondition";
            if (isset($arrParams['source_id']))
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['disease'], $arrCat, $arrParams['source_id']);
            else
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['disease'], $arrCat);
            unset($arrCat);
            if (count($arrFeedUrlIds) == 0)
                $arrFeedUrlIds = $urlIds;
            else {
                if (isset($arrParams['tag_name']))
                    $arrFeedUrlIds = array_merge($arrFeedUrlIds, $urlIds);
                else
                    $arrFeedUrlIds = array_intersect($arrFeedUrlIds, $urlIds);
            }
        }
        if (isset($arrParams['organization']) && count($arrParams['organization']) > 0) {
            $arrCat[] = "Organization";
            if (isset($arrParams['source_id']))
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['organization'], $arrCat, $arrParams['source_id']);
            else
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['organization'], $arrCat);
            unset($arrCat);
            if (count($arrFeedUrlIds) == 0)
                $arrFeedUrlIds = $urlIds;
            else {
                if (isset($arrParams['tag_name']))
                    $arrFeedUrlIds = array_merge($arrFeedUrlIds, $urlIds);
                else
                    $arrFeedUrlIds = array_intersect($arrFeedUrlIds, $urlIds);
            }
        }
        if (isset($arrParams['technology']) && count($arrParams['technology']) > 0) {
            $arrCat = "Technology";
            if (isset($arrParams['source_id']))
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['technology'], $arrCat, $arrParams['source_id']);
            else
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['technology'], $arrCat);
            unset($arrCat);
            if (count($arrFeedUrlIds) == 0)
                $arrFeedUrlIds = $urlIds;
            else {
                if (isset($arrParams['tag_name']))
                    $arrFeedUrlIds = array_merge($arrFeedUrlIds, $urlIds);
                else
                    $arrFeedUrlIds = array_intersect($arrFeedUrlIds, $urlIds);
            }
        }
        if (isset($arrParams['company']) && count($arrParams['company']) > 0) {
            $arrCat[] = "Company";
            if (isset($arrParams['source_id']))
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['company'], $arrCat, $arrParams['source_id']);
            else
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['company'], $arrCat);
            unset($arrCat);
            if (count($arrFeedUrlIds) == 0)
                $arrFeedUrlIds = $urlIds;
            else {
                if (isset($arrParams['tag_name']))
                    $arrFeedUrlIds = array_merge($arrFeedUrlIds, $urlIds);
                else
                    $arrFeedUrlIds = array_intersect($arrFeedUrlIds, $urlIds);
            }
        }
        if (isset($arrParams['product']) && count($arrParams['product']) > 0) {
            $arrCat[] = "Product";
            if (isset($arrParams['source_id']))
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['product'], $arrCat, $arrParams['source_id']);
            else
                $urlIds = $this->getDistinctFeedUrlIds($arrParams['product'], $arrCat);
            unset($arrCat);
            if (count($arrFeedUrlIds) == 0)
                $arrFeedUrlIds = $urlIds;
            else {
                if (isset($arrParams['tag_name']))
                    $arrFeedUrlIds = array_merge($arrFeedUrlIds, $urlIds);
                else
                    $arrFeedUrlIds = array_intersect($arrFeedUrlIds, $urlIds);
            }
        }
        if (isset($arrParams['source_id']) && count($arrParams['source_id']) > 0 && (!isset($arrParams['people'])) && (!isset($arrParams['disease'])) && (!isset($arrParams['organization'])) && (!isset($arrParams['technology'])) && (!isset($arrParams['company'])) && (!isset($arrParams['product']))) {

            $arrFeedUrlIds = $this->getDistinctFeedUrlIds(null, $arrCat, $arrParams['source_id']);
            // pr($arrFeedUrlIds);
        }
        // pr($arrFeedUrlIds);
        return $arrFeedUrlIds;
    }

    function insertFeed() {
        $this->db->select('*');
        $query = $this->db->get('rss_feed_dummy');

        $res = $query->result_array();

        foreach ($res as $values) {
            $this->db->select('rss_feed_url');
            $this->db->where('rss_feed_url', $values["rss_feed_url"]);
            $query1 = $this->db->get('rss_feed');
            if ($query1->num_rows == 0) {
                unset($values["id"]);
                if ($values["rss_link_id"] != 13) {
                    $this->db->insert("rss_feed", $values);
                }
            }
        }
    }

    function getDistinctFeedUrlIds($arrEntities, $arrCat, $arrLink) {
        $arrFeedIds = array();
        $this->db->select('distinct rss_feed.id', false);
          $this->db->join('rss_link', 'rss_feed.rss_link_id = rss_link.id  ', 'left');
            if (!(count($arrLink) > 0) || count($arrEntities) > 0)
            {
          $this->db->join('rss_entity', 'rss_entity.rss_feed_url_id = rss_feed.id  ', 'left');
        $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
        $this->db->join('categories', 'categories.id = rss_entity.category_id ', 'left');
      
      

        $names = array('SocialTag', 'PublishedMedium', 'City', 'Facility', 'Position');
        $this->db->where_not_in('categories.category_name', $names);
        foreach ($arrCat as $values)
            $this->db->where('categories.category_name', $values);
        if (count($arrEntities) > 0)
            $this->db->where_in('entities.id', $arrEntities);
            }
        if (count($arrLink) > 0)
            $this->db->where_in('rss_feed.rss_link_id', $arrLink);
        $this->db->where("rss_link.ignore !=", '1');
        $res = $this->db->get('rss_feed');
//       echo $this->db->last_query()."<br/>";
        //echo $this->db->last_query();
        if ($res->num_rows > 0) {
            foreach ($res->result_array() as $row)
                $arrFeedIds[] = $row['id'];
        }
//        echo $this->db->last_query();
        //pr($arrFeedIds);
        return $arrFeedIds;
    }

    function getKolMediaCounts($arrKolDetail) {
        $firstName = $arrKolDetail["first_name"];
        $spaceSplitter = " ";
        $lastName = $arrKolDetail['last_name'];
        $completeName = array();

        $completeName[] = $firstName . $spaceSplitter . $lastName;
        $completeName[] = $lastName . $spaceSplitter . $firstName;
        $mediaCount = $this->checkEntityName($completeName, true);
        return $mediaCount;
    }

    function getFeedDetailsById($feedId) {
        $rowData = array();
        $this->db->where('id', $feedId);
        $res = $this->db->get('rss_feed');
        if ($res->num_rows > 0) {
            $rowData = $res->row_array();
        }
        return $rowData;
    }

    function getKolFeeds($arrNames) {

        $this->db->select('distinct rss_feed.rss_feed_url,rss_feed.id as rss_feed_url_id,rss_feed.img_url,rss_feed.title,rss_feed.description,rss_link.publisher,rss_feed.date', false);
        $this->db->join('rss_entity', 'rss_entity.rss_feed_url_id = rss_feed.id', 'left');
        $this->db->join('entities', 'rss_entity.entity_name_id = entities.id', 'left');
        $this->db->join('rss_link', 'rss_feed.rss_link_id = rss_link.id', 'left');
        $this->db->where_in('entities.entity_name', $arrNames);
        $this->db->order_by("date", "desc");
        $query = $this->db->get('rss_feed');
        //echo $this->db->last_query();
        return $query->result_array();
    }

    /**
     * Log Maintainence Functions
     * 
     */
    function logSourceIdAndFeedCount($feedCount, $linkId, $oldRssCount) {
        pr($feedCount) . "<br/>";
        pr($linkId) . "<br/>";
        $this->db->select("count(rss_link_id) as count");
        $this->db->where("rss_link_id", $linkId);
        $querys = $this->db->get("rss_feed");

        $result = $querys->row_array();
        $this->db->_reset_write();
//        $arrVal=array("rss_link_id"=>$linkId,"rss_feed_count"=>$feedCount,"old_rss_feed_count"=>$result["count"],"last_modified"=>date('Y-m-d H:i:s'));
////        $this->db->set("rss_link_id",$linkId);
////        $this->db->set("rss_feed_count",$feedCount);
////        $this->db->set("old_rss_feed_count",$result["count"]);
////        $this->db->set("last_modified",date('Y-m-d H:i:s'));
//        $this->db->insert("media_source_log",$arrVal);

        $this->db->query("insert into media_source_log values(NULL,'" . $linkId . "','" . $feedCount . "','" . $oldRssCount . "','" . date('Y-m-d H:i:s') . "','" . $result["count"] . "')");

        //echo $this->db->last_query()."<br/>";
    }

    function logEntitiesCatAndInnerContent($rssId, $catCount, $entCount, $articleLength) {
        $this->db->set("rss_feed_id", $rssId);
        $this->db->set("cat_count", $catCount);
        $this->db->set("ent_count", $entCount);
        $this->db->set("inner_article_length", $articleLength);
        $this->db->set("last_modfied", date('Y-m-d H:i:s'));
        $this->db->insert("media_entity_log");
    }

    function oldRssCount($linkId) {
        $this->db->select("count(rss_link_id) as count");
        $this->db->where("rss_link_id", $linkId);
        $querys = $this->db->get("rss_feed");
        return $querys->row_array();
    }

    function apiResponse($response) {
         
                    $logArr=array("id"=>NULL,"module"=>"media_feature","controller"=>"media_intel_extractions","param"=>"","created_by"=>"","url"=>"","description"=>$response,
                        "type"=>"OpenCalaiasApiCall","status"=>"","file_name"=>"","client_id"=>"","browser"=>"","os"=>"","ip_address"=>"");  
       $this->db->insert('log_activities', $logArr); 
    }
    function analystAction($ent_ids,$user_ids,$type,$client_id,$arrUserResults){
        if($type=="bookmark"){
            if($user_ids!=''){
                foreach($ent_ids as $value){
                    foreach($user_ids as $id){
                        $this->media_parser->user_bookmark($value, $id);
                    }
                }
            }
            else{
                foreach($ent_ids as $value){
                    // foreach($arrUserResults as $row){
                    $this->media_parser->user_bookmark($value, $row['id']);
                    // }
                }
            }
        }
        if($type=="ignore"){
            if($user_ids!=''){
                foreach($ent_ids as $value){
                    foreach($user_ids as $id){
                        $this->media_parser->blacklist_entity($value, $id);
                    }
                }
            }
            else{
                foreach($ent_ids as $value){
                    //foreach($arrUserResults as $row){
                    $this->media_parser->blacklist_entity($value, null);
                    // }
                }
            }
            
        }
        
        if($type=="remove_bookmark"){
            if($user_ids!=''){
                foreach($ent_ids as $value){
                    foreach($user_ids as $id){
                        $this->media_parser->remove_book_mark($id,$value);
                    }
                }
            }
            else{
                foreach($ent_ids as $value){
                    // foreach($arrUserResults as $row){
                    $this->media_parser->remove_book_mark( $row['id'],$value);
                    // }
                }
            }
            
        }
        if($type=="remove_ignore"){
            
            if($user_ids!=''){
                foreach($ent_ids as $value){
                    foreach($user_ids as $id){
                        $this->media_parser->removeBlacklists($id,$value);
                    }
                }
            }
            else{
                foreach($ent_ids as $value){
                    
                    $this->media_parser->removeBlacklists( 'null',$value);
                    
                }
            }
            
        }
    }
    
    function getAnalystBookmarks(){
        $this->db->select("group_concat(concat(client_users.first_name,' ',client_users.last_name)) as users ,entity_name,entities.id",false);
        
        $this->db->join('entities', 'user_bookmarks.entity_id = entities.id', 'left');
        $this->db->join('client_users', 'client_users.id = user_bookmarks.user_id', left);
         $this->db->group_by('user_bookmarks.entity_id', left);
        $query = $this->db->get('user_bookmarks');
        $result=$query->result_array();
        return $result;
        
    }
    
    function getAnalystIgnores(){
        $this->db->select("group_concat(concat(client_users.first_name,' ',client_users.last_name)) as users ,entity_name,entities.id",false);
        
        $this->db->join('entities', 'user_blacklists.entity_id = entities.id', 'left');
        $this->db->join('client_users', 'client_users.id = user_blacklists.user_id', left);
         $this->db->group_by('user_blacklists.entity_id', left);
        $query = $this->db->get('user_blacklists');
        $result=$query->result_array();
        return $result;
        
    }
    function getEntityUsers($id,$type){
        $this->db->select("concat(client_users.first_name,' ',client_users.last_name) as users ,client_users.id",false);
        if($type!="ignore"){
            $this->db->join('entities', 'user_bookmarks.entity_id = entities.id', 'left');
            $this->db->join('client_users', 'client_users.id = user_bookmarks.user_id', left);
            $this->db->where('user_bookmarks.entity_id', $id);
            $query = $this->db->get('user_bookmarks');
        }
        else{
            $this->db->join('entities', 'user_blacklists.entity_id = entities.id', 'left');
            $this->db->join('client_users', 'client_users.id = user_blacklists.user_id', left);
             $this->db->where('user_blacklists.entity_id', $id);
            $query = $this->db->get('user_blacklists'); 
        }
        $result=$query->result_array();
        return $result;
        
    }
    
    function saveSettings($option,$lastId){
        $user_id=$this->session->userdata('user_id');
        $this->db->select('user_id');
        if($lastId!='')
            $this->db->where('user_id', $lastId);
        else
            $this->db->where('user_id', $user_id);
        $query = $this->db->delete('media_email_settings');
//        echo $this->db->last_query();
        
           if($lastId!='')
            $this->db->set('user_id', $lastId);
           else
               $this->db->set('user_id', $user_id);
        $this->db->set('option', $option);
        $this->db->insert('media_email_settings');
        //Add Log activity
        $arrLogDetails = array(
        		'type' => ADD_RECORD,
        		'description' => 'Add New media email settings',
        		'status' => STATUS_SUCCESS,
        		'kols_or_org_type' => 'Kol',
        		'kols_or_org_id' => '',
        		'transaction_id' =>  $user_id,
        		'transaction_table_id' => MEDIA_EMAIL_SETTINGS,
        		'transaction_name' => 'Add New media email settings',
        		'parent_object_id' =>  ''
        );
        $this->config->set_item('log_details', $arrLogDetails);
    }
    
    function getEmailSettings(){
        $this->db->select("option");
        $this->db->where("user_id", $this->session->userdata('user_id'));
        $querys = $this->db->get("media_email_settings");
        return $querys->row_array();
        
    }
    
    function disablePopUp(){
         $this->db->select("user_id");
        $this->db->where("user_id", $this->session->userdata('user_id'));
        $querys = $this->db->get("media_email_popup");
        $result=$querys->row_array();
        
        if(count($result)>0){
             $this->db->where('user_id', $this->session->userdata('user_id'));
            $query = $this->db->delete('media_email_popup');
            
        }
        else{
        $this->db->set('user_id', $this->session->userdata('user_id'));
       $this->db->insert('media_email_popup');
        }
    }
    
    function getPopUpSettings(){
         $this->db->select("user_id");
        $this->db->where("user_id", $this->session->userdata('user_id'));
        $querys = $this->db->get("media_email_popup");
        $result=$querys->row_array();
        
        if(count($result)>0){
             return "true";
            
        }
        else{
            return "false";
        }
    }

}

?>