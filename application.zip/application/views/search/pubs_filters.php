<?php
/**
*File To show Pubmed filter search page.
*
*@author: Ambarish N
*@created on: 09-02-11
*/
 //$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
 $autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>

<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999; */
	/*	margin-top:0.7em;*/
		overflow:visible;
		padding-top:0.8em;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url(../../images/sprite_facetsearch_v7.png) no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:11px;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttn{
		width: 11px;
		height: 11px;
		float: right;
		background-color:buttonshadow;
		-moz-border-radius-bottomleft:2px;
		-moz-border-radius-bottomright:2px;
		-moz-border-radius-topleft:2px;
		-moz-border-radius-topright:2px;
		vertical-align: middle;
		margin-left:4px;
		margin-top:4px;
		cursor: pointer;
		margin-right: 10px;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
</style>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<script type="text/javascript">

	var options, a;

	//--------------Start of Clinical trails Filters Autocomplet------------------------
		// Autocomplet Options for the 'Journals' field 
		var journalsAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>pubmeds/get_journals_name',<?php echo $autoSearchOptions;?>
		};	

		var affiliationsAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>pubmeds/get_affiliations_name',<?php echo $autoSearchOptions;?>
			};	

		var meshTermsAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>pubmeds/get_mesh_terms_name',<?php echo $autoSearchOptions;?>
			};	

		var substancesAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>pubmeds/get_substances_name',<?php echo $autoSearchOptions;?>
			};	

		$(document).ready(function(){

			$('#categoriesContainer input:checked').each(function (index){
				$(this).parent().parent().css('background-color','#D3DFED');
			});

			$('#searchFiltersElements ul li table tr').click(function (){
				if($('#'+$(this).attr('class')).attr('checked')=="checked"){
					$(this).css('background-color','#ffffff');
					$('#'+$(this).attr('class')).removeAttr('checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}else{
					$(this).css('background-color','#D3DFED');
					$('#'+$(this).attr('class')).attr('checked','checked');
					doSearchFilter1(-1,$('#'+$(this).attr('class')));
				}
			});
			
			// Trigger the Autocompleter for 'Journals' field 
	    	a = $('#journal').autocomplete(journalsAutoCompleteOptions);

			// Trigger the Autocompleter for 'Affiliations' field 
	    	a = $('#affiliation').autocomplete(affiliationsAutoCompleteOptions);

			// Trigger the Autocompleter for 'MeshTerms' field 
	    	a = $('#meshterm').autocomplete(meshTermsAutoCompleteOptions);

			// Trigger the Autocompleter for 'Substances' field 
	    	a = $('#substance').autocomplete(substancesAutoCompleteOptions);
		});

		// Hide or Show the Category checkbox's 
		function toggleCategory(toggleFlag,thisEle){
			var parentId=$(thisEle).parent().attr("id");
			if($(thisEle).hasClass('expanded')){
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				//$('#searchLeftBar #'+parentId+' ul').hide();
				$(thisEle).next().hide();
			}
			else {
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
				//$('#searchLeftBar #'+parentId+' ul').show();
				$(thisEle).next().show();
			}
		}
</script>

<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>pubmeds/<?php if($searchType=='simple') echo 'filter_search_publications'; else echo 'filter_adv_search_publications';?>" name="searchForm" method="post" id="searchFilterForm">
		<input type="hidden" name="keyword"  class="hiddenSearchField" id="keyword" value="<?php echo $keyword;?>"/>
		<input type="hidden" name="search_type"  class="hiddenSearchField" id="searchType" value="<?php echo $searchType;?>"/>
		<input type="hidden" name="filterCategory"  class="hiddenSearchField" id="filterCategory" value="publication"/>	
		<?php if($arrAdvSearchFields != null){ ?>
			<input type="hidden" name="pubKeywords" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['pubKeywords']; ?>"/>
			<input type="hidden" name="pubAuthors" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['authors']; ?>"/>
			<input type="hidden" name="pubMesh_term" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['mesh_term']; ?>"/>
			<input type="hidden" name="pubSubstances" class="hiddenSearchField" value="<?php echo $arrAdvSearchFields['substances']; ?>"/>
		<?php }?>
			
		<ul id="categoriesContainer">
			<li id="categoryMeshTerm" class="category">
				<label class="categoryName">MeshTerm</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allMeshterms">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_meshterms" id="allMeshterms"  value="meshterm" <?php if(isset($selectedMeshterms) && $selectedMeshterms!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All MeshTerms</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allMeshtermCount."(".round(($allMeshtermCount/$allMeshtermCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($allMeshtermCount/$allMeshtermCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allMeshtermCount)) echo $allMeshtermCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrPublicationsByMeshtermCount as $meshtermCountDetails){ ?>
					 	<?php if($meshtermCountDetails['meshterm']!=''){?>
							 	<tr class="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermCountDetails['meshterm']));?>">
									<td class="textAlignRight"><input type="checkbox" name="meshterm_ids[]" class="meshtermElement hideCheckbox" id="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermCountDetails['meshterm']));?>" value="<?php echo $meshtermCountDetails['meshterm'];?>" onclick="doSearchFilter1(-1,this)" 
										<?php if(isset($selectedMeshterms) && sizeof($selectedMeshterms)>0 && $selectedMeshterms!=null){if(in_array($meshtermCountDetails['meshterm'], $selectedMeshterms)) {?>
											checked="checked"
										<?php //remove the checked vlues from selected array
										$key = array_search($meshtermCountDetails['meshterm'], $selectedMeshterms);if(array_key_exists($key, $selectedMeshterms))unset($selectedMeshterms[$key]);$selectedMeshterms=array_values($selectedMeshterms);}}?>
										/>&nbsp;<?php echo $meshtermCountDetails['meshterm'];?>
									</td>
									<td class="histoGram">
										<div class="filterBar">
											<div class="progress" title="<?php echo $meshtermCountDetails['count']."(".round(($meshtermCountDetails['count']/$allMeshtermCount)*100)."%)";?>">
												<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($meshtermCountDetails['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
											</div>
										</div>
									</td>
									<td><?php if(isset($meshtermCountDetails['count'])) echo $meshtermCountDetails['count']; else echo 0;?></td>
								</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedMeshterms) && $selectedMeshterms!=null){foreach($selectedMeshterms as $meshtermName){?>
						<tr class="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermName));?>">
							<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="meshterm_ids[]" class="meshtermElement" id="meshterm<?php echo str_replace(' ','',str_replace('&','and',$meshtermName));?>" value="<?php echo $meshtermName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $meshtermName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrPublicationsByMeshtermCount[$meshtermName]['count']."(".round(($arrPublicationsByMeshtermCount[$meshtermName]['count']/$allMeshtermCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allMeshtermCount)) echo round(($arrPublicationsByMeshtermCount[$meshtermName]['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($meshtermName, $arrPublicationsByMeshtermCount)) echo $arrPublicationsByMeshtermCount[$meshtermName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					<div class="filterSearchIcon"></div>
					<input type="text" name="meshterm" class="autocompleteInputBox" id="meshterm" value="" title=""/>
				</div>
			</li>
			
			<li id="categorySubstance" class="category">
				<label class="categoryName">Substance</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allSubstances">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_substances" id="allSubstances"  value="substance" <?php if(isset($selectedSubstances) && $selectedSubstances!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Substances</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allSubstanceCount."(".round(($allSubstanceCount/$allMeshtermCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allSubstanceCount)) echo round(($allSubstanceCount/$allMeshtermCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allSubstanceCount)) echo $allSubstanceCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrPublicationsBySubstanceCount as $substanceCountDetails){ ?>
					 	<?php if($substanceCountDetails['substance']!=''){?>
						 	<tr class="substance<?php echo str_replace(' ','',str_replace('&','and',$substanceCountDetails['substance']));?>">
								<td class="textAlignRight"><input type="checkbox" name="substance_ids[]" class="substanceElement hideCheckbox" id="substance<?php echo str_replace(' ','',str_replace('&','and',$substanceCountDetails['substance']));?>" value="<?php echo $substanceCountDetails['substance'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedSubstances) && sizeof($selectedSubstances)>0 && $selectedSubstances!=null){if(in_array($substanceCountDetails['substance'], $selectedSubstances)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($substanceCountDetails['substance'], $selectedSubstances);if(array_key_exists($key, $selectedSubstances))unset($selectedSubstances[$key]);$selectedSubstances=array_values($selectedSubstances);}}?>
									/>&nbsp;<?php echo $substanceCountDetails['substance'];?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="<?php echo $substanceCountDetails['count']."(".round(($substanceCountDetails['count']/$allMeshtermCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allSubstanceCount)) echo round(($substanceCountDetails['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $substanceCountDetails['count'];?></td>
							</tr>
						</li>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedSubstances) && $selectedSubstances!=null){foreach($selectedSubstances as $substanceName){?>
						<tr class="substance<?php echo str_replace(' ','',str_replace('&','and',$substanceName));?>">
							<td class="textAlignRight"><input type="checkbox" name="substance_ids[]" class="substanceElement hideCheckbox" id="substance<?php echo str_replace(' ','',str_replace('&','and',$substanceName));?>" value="<?php echo $substanceName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $substanceName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrPublicationsBySubstanceCount[$substanceName]['count']."(".round(($arrPublicationsBySubstanceCount[$substanceName]['count']/$allMeshtermCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allSubstanceCount)) echo round(($arrPublicationsBySubstanceCount[$substanceName]['count']/$allMeshtermCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($substanceName, $arrPublicationsBySubstanceCount)) echo $arrPublicationsBySubstanceCount[$substanceName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="substance" class="autocompleteInputBox" id="substance" value="" title=""/>
				</div>
			</li>
			
			<li id="categoryJournal" class="category">
				<label class="categoryName">Journal</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allJournals">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_journals" id="allJournals"  value="journal" <?php if(isset($selectedJournals) && $selectedJournals!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)" />All Journals</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allJournalCount."(".round(($allJournalCount/$allJournalCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allJournalCount)) echo round(($allJournalCount/$allJournalCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allJournalCount)) echo $allJournalCount; else echo 0;?></td>
					</tr>
				
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrPublicationsByJournalCount as $journalCountDetails){ ?>
					 	<?php if($journalCountDetails['journal']!=''){?>
						 	<tr class="journal<?php echo str_replace(' ','',str_replace('&','and',$journalCountDetails['journal']));?>">
								<td class="textAlignRight"><input type="checkbox" name="journal_ids[]" class="journalElement hideCheckbox" id="journal<?php echo str_replace(' ','',str_replace('&','and',$journalCountDetails['journal']));?>" value="<?php echo $journalCountDetails['journal'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php if(isset($selectedJournals) && sizeof($selectedJournals)>0 && $selectedJournals!=null){if(in_array($journalCountDetails['journal'], $selectedJournals)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($journalCountDetails['journal'], $selectedJournals);if(array_key_exists($key, $selectedJournals))unset($selectedJournals[$key]);$selectedJournals=array_values($selectedJournals);}}?>
									/>&nbsp;<?php echo $journalCountDetails['journal'];?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="<?php echo $journalCountDetails['count']."(".round(($journalCountDetails['count']/$allJournalCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allJournalCount)) echo round(($journalCountDetails['count']/$allJournalCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $journalCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedJournals) && $selectedJournals!=null){foreach($selectedJournals as $journalName){?>
						<tr class="journal<?php echo str_replace(' ','',str_replace('&','and',$journalName));?>">
							<td class="textAlignRight"><input type="checkbox" name="journal_ids[]" class="journalElement hideCheckbox" id="journal<?php echo str_replace(' ','',str_replace('&','and',$journalName));?>" value="<?php echo $journalName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $journalName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrPublicationsByJournalCount[$journalName]['count']."(".round(($arrPublicationsByJournalCount[$journalName]['count']/$allJournalCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allJournalCount)) echo round(($arrPublicationsByJournalCount[$journalName]['count']/$allJournalCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($journalName, $arrPublicationsByJournalCount)) echo $arrPublicationsByJournalCount[$journalName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="journal" class="autocompleteInputBox" id="journal" value="" title=""/>
				</div>
			</li>
			
			<li id="categoryAffiliation" class="category">
				<label class="categoryName">Affiliation</label>
				<label class="facet-toggle collapsed"  onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				<table>
					<!-- CheckBox representing All for this Category -->
					<tr class="allAffiliations">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_affiliations" id="allAffiliations"  value="affiliation" <?php if(isset($selectedAffiliations) && $selectedAffiliations!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Affiliations</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allAffiliationCount."(".round(($allAffiliationCount/$allAffiliationCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allAffiliationCount)) echo round(($allAffiliationCount/$allAffiliationCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allAffiliationCount)) echo $allAffiliationCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrPublicationsByAffiliationCount as $affiliationCountDetails){ ?>
					 	<?php if($affiliationCountDetails['affiliation']!=''){?>
						 	<tr class="affiliation<?php echo str_replace(' ','',str_replace('&','and',$affiliationCountDetails['affiliation']));?>">
								<td class="textAlignRight">
									<input type="checkbox" name="affiliation_ids[]" class="affiliationElement hideCheckbox" id="affiliation<?php echo str_replace(' ','',str_replace('&','and',$affiliationCountDetails['affiliation']));?>" value="<?php echo $affiliationCountDetails['affiliation'];?>" onclick="doSearchFilter1(-1,this)"
									<?php if(isset($selectedAffiliations) && sizeof($selectedAffiliations)>0 && $selectedAffiliations!=null){if(in_array($affiliationCountDetails['affiliation'], $selectedAffiliations)) {?>
										checked="checked"
									<?php //remove the checked vlues from selected array
									$key = array_search($affiliationCountDetails['affiliation'], $selectedAffiliations);if(array_key_exists($key, $selectedAffiliations))unset($selectedAffiliations[$key]);$selectedAffiliations=array_values($selectedAffiliations);}}?>
									/>&nbsp;<?php echo $affiliationCountDetails['affiliation'];?>
								</td>
								<td class="histoGram">
									<div class="filterBar">
										<div class="progress" title="<?php echo $affiliationCountDetails['count']."(".round(($affiliationCountDetails['count']/$allAffiliationCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allAffiliationCount)) echo round(($affiliationCountDetails['count']/$allAffiliationCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php echo $affiliationCountDetails['count'];?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedAffiliations) && $selectedAffiliations!=null){foreach($selectedAffiliations as $affiliationName){?>
						<tr class="affiliation<?php echo $affiliationName;?>">
							<td class="textAlignRight"><input type="checkbox" name="affiliation_ids[]" class="affiliationElement hideCheckbox" id="affiliation<?php echo str_replace(' ','',str_replace('&','and',$affiliationName));?>" value="<?php echo $affiliationName;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp;<?php echo $affiliationName;?></td>
							<td class="histoGram"><div class="filterBar">
									<div class="progress" title="<?php echo $arrPublicationsByAffiliationCount[$affiliationName]['count']."(".round(($arrPublicationsByAffiliationCount[$affiliationName]['count']/$allAffiliationCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allAffiliationCount)) echo round(($arrPublicationsByAffiliationCount[$affiliationName]['count']/$allAffiliationCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($affiliationName, $arrPublicationsByAffiliationCount)) echo $arrPublicationsByAffiliationCount[$affiliationName]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="affiliation" class="autocompleteInputBox" id="affiliation" value="" title=""/>
				</div>
			</li>

		</ul>
	</form>
</div>