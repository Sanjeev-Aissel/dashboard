<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class events extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('event');
		$this->load->model('helpers/common_helper');
	}
	function get_eventLookup_names($category, $eventName) {
		$eventName = urldecode($this->input->post('keyword'));
		$arrEventLookupNames = $this->event->getEventLookupNames($category, $eventName);
		$arrSuggestEvents = array();
		if (sizeof($arrEventLookupNames) == 0) {
			$arrSuggestEvents[0] = 'No results found for ' . $instituteName;
		} else {
			$flag = 1;
			foreach ($arrEventLookupNames as $id => $name) {
				if ($flag) {
					$arrSuggestEvents[] = '<div class="autocompleteHeading">Events Names</div><div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestEvents[] = '<div class="dataSet"><label name="' . $id . '" class="educations" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $eventName;
		$arrReturnData['suggestions'] = $arrSuggestEvents;
		echo json_encode($arrReturnData);
	}
	function view_events($kolId, $subContentPage = '') {
		// Getting the KOL details
		$this->load->model('kols/kol');
// 		$kolId 							= $this->common_helper->getFieldValueByEntityDetails('kols','unique_id',$kolId,'id');
		$kolId							= $this->common_helper->getKolClientVisiblityId($kolId);
		$arrKolDetail 					= $this->kol->editKol($kolId);
		// If there is no record in the database
		if (!$arrKolDetail) {
			return false;
		}
		
		$module_name					='events';
		$data['module_id']				=$this->common_helper->getModuleIdByModuleName($module_name);
		
		$data['arrKol'] 				= $arrKolDetail;
		$arrYearRange 					= $this->event->getEventsYearsRange($kolId);
		if ($arrYearRange['max_year'] == '')
			$arrYearRange['max_year'] = date("Y");
		if ($arrYearRange['min_year'] == '')
			$arrYearRange['min_year'] = (int) $arrYearRange['max_year'] - 35;
		
		$data['arrYearRange'] 			=$arrYearRange;
		$data['contentPage'] 			='view_events';
		$data['subContentPage']			=$subContentPage;
		$data['contentData']			=$data;
		
		$arr_option_data['kol_id']			=$arrKolDetail['kols_client_visibility_id'];
		$arr_option_data['kol_unique_id']	=$arrKolDetail['kols_client_visibility_unique_id'];
		if($this->common_helper->check_module("align_users")){
			$this->load->model('align_users/align_user');
			$arr_option_data['assignedUsers'] 	= $this->align_user->getAssignedUsers($kolId);
		}
		
		$data['options_page']				='kols/export_options_within_kol';
		$data['options_data']				=$arr_option_data;
		
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function list_events($type, $startYear = '', $endYear = '', $kolId,$sortByYear=false) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		$arrEventsResults = array();
		$data = array();
		if ($arrEventsResultsResult = $this->event->listEvents($type, $kolId, $startYear, $endYear,null,null,$sortByYear)) {
			foreach ($arrEventsResultsResult as $row) {
				$row['topic'] = $this->event->getTopicName($row['topic']);
				$arrEventsResults[] = $row;
			}
			$count = sizeof($arrEventsResults);
			if ($count > 0) {
				$total_pages = ceil($count / $limit);
			} else {
				$total_pages = 0;
			}
			$data['records'] = $count;
			$data['total'] = $total_pages;
			$data['page'] = $page;
			$data['rows'] = $arrEventsResults;
		}
		echo json_encode($data);
	}
	function add_client_event($kolId,$eventId=null) {
		$kolId							= $this->common_helper->getKolClientVisiblityId($kolId);
		$data['kolId'] 					= $kolId;
		// Get the list of Conference Event Types
		$this->load->model('kols/kol');
		$this->load->model('helpers/country_helper');
		$data['arrConfEventTypes'] 			= $this->event->getAllConferenceEventTypes();
		// Get the list of Conference Session Types
		$arrConfSessionTypes 				= $this->event->getAllConferenceSessionTypes();
		$key = array_search('Other', $arrConfSessionTypes);
		unset($arrConfSessionTypes[$key]);
		$arrConfSessionTypes[$key] 			= 'Other';
		$data['arrConfSessionTypes'] 		= $arrConfSessionTypes;
		$data['arrEventSponsorTypes'] 		= $this->event->getSponsorTypes();
		$data['arrEventOrganizerTypes'] 	= $this->event->getOrganizerTypes();
		$arrKolDetail 						= $this->kol->editKol($kolId);
		$arrTopics							= $this->event->getTopicsBySpecialty($arrKolDetail['specialty']);
		if ($eventId!=null){
			$data['arrEventData'] 			=$this->event->getEventById($eventId);
			// Get the list of Topic belongs to kol specialty
			if($data['arrEventData']['topic'] > 0){
				$arrTopics 					= $this->event->getTopicsBySpecialty($data['arrEventData']['et_specialty_id']);
			}
		}
		// Get the list of Topic belongs to kol specialty
		$data['arrTopics'] 					= $arrTopics;
		$data['arrCountry'] 				= $this->country_helper->listCountries();
		$data['arrRoles'] 					= $this->event->getEventRoles();
		$data['contentPage'] 				= 'events/add_client_event';
		$data['contentData']				= $data;
		$this->load->view(CLIENT_LAYOUT,$data);
	}
	function view_micro_event($eventId) {
		$data = array();
		// Getting the Payment details
		$arrEvents[] = $this->event->getEventById($eventId);
		foreach ($arrEvents as $row) {
			$row['start'] = sql_date_to_app_date($row['start']);
			$row['end'] = sql_date_to_app_date($row['end']);
			$arrEventsResult[] = $row;
		}
		$data['arrEvents'] = $arrEventsResult;
		$this->load->view('view_events_micro_profile', $data);
	}
	function get_lat_long_dynamically(){
		$address = $this->input->post("address");
		$country = $this->input->post("country");
		$state = $this->input->post("state");
		$city = $this->input->post("city");
		$postalCode = $this->input->post("postalCode");
		if(!empty($address) && !empty($city)){
			$jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($address.' '.$city.' '.$state.' '.$country).'&sensor=false');
			// 			pr('https://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($address.' '.$city.' '.$state.' '.$country).'&sensor=false');
		}else{
			$jsondata = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($postalCode).'&sensor=false');
			// 			pr('https://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($postalCode).'&sensor=false');
		}
		// 		pr($jsondata);exit;
		$jsondata = json_decode($jsondata, true);
		if ($jsondata['status'] = 'OK') {
			$lat = trim($jsondata['results'][0]['geometry']['location']['lat']);
			$lon = trim($jsondata['results'][0]['geometry']['location']['lng']);
			if($lat != '' || $long != ''){
				$data['lat'] = $lat;
				$data['lon'] = $lon;
				echo json_encode($data);
			}
		}
	}
	function get_event_id_else_save($name) {
		$name = str_replace("%20"," ",$name);
		$eventDetails = array('name' => $name,
				'category' => 'conference',
				'notes' => $this->input->post('notes'),
				'created_by' => $this->loggedUserId,
				'created_on' => date('Y-m-d H:i:s'));
		$eventId = $this->event->getEventIdElseSave($eventDetails);
		echo json_encode($eventId);
	}
	function view_events_by_session_type($kolId = 0, $startYear, $endYear, $role = '', $arrCountryId = 0, $arrSpecialities = 0) {
		$kolId = (int) $kolId;
		$startYear = (int) $startYear;
		$endYear = (int) $endYear;
		$arrCountryId = (int) $arrCountryId;
		$arrSpecialities = (int) $arrSpecialities;
		$role = $this->db->escape_like_str($role);
		$data = array();
		$arrEventsresult = $this->event->getEventsBySessionType($kolId, $startYear, $endYear, $role, $arrCountryId, $arrSpecialities = 0);
		foreach ($arrEventsresult as $row) {
			$arrEvents = array();
			$arrEvents[] = ucwords($row['session_type']);
			$arrEvents[] = (int) $row['count'];
			$data[] = $arrEvents;
		}
		echo json_encode($data);
	}
	function view_events_chart_by_topic($kolId, $startYear, $endYear) {
		$arrEventTopics = array();
		$arrEventsTopic = $this->event->getDataForEventsTopicChart($kolId, $startYear, $endYear);
		foreach ($arrEventsTopic as $row) {
			$arrTopic = array();
			$arrTopic[] = $row['name'];
			$arrTopic[] = (int) $row['count'];
			$arrEventTopics[] = $arrTopic;
		}
		echo json_encode($arrEventTopics);
	}
	function delete_event($id) {
		if ($this->event->deleteEventById($id)) {
			$arrResult['status'] = 'success';
		} else {
			$arrResult['status'] = 'fail';
		}
		echo json_encode($arrResult);
	}
	function view_events_by_role($kolId = 0, $startYear, $endYear, $sessionType = '', $counTryId = 0) {
		$kolId = (int) $kolId;
		$startYear = (int) $startYear;
		$endYear = (int) $endYear;
		$counTryId = (int) $counTryId;
		$sessionType = $this->db->escape_like_str($sessionType);
		$arrEventsresult = $this->event->getEventsByRole($kolId, $startYear, $endYear, $sessionType, $counTryId = 0);
		$data = array();
		foreach ($arrEventsresult as $row) {
			$arrEvents = array();
			$arrEvents[] = ucwords($row['role']);
			$arrEvents[] = (int) $row['count'];
			$data[] = $arrEvents;
		}
		echo json_encode($data);
	}
	function view_events_by_sponsor_type($kolId = 0, $startYear, $endYear, $role = '', $arrCountryId = 0, $arrSpecialities = 0) {
		$data = array();
		$arrEventsresult = $this->event->getEventsBySponsorType($kolId, $startYear, $endYear, $role, $arrCountryId, $arrSpecialities = 0);
		foreach ($arrEventsresult as $row) {
			$arrEvents = array();
			$arrEvents[] = ucwords($row['type']);
			$arrEvents[] = (int) $row['count'];
			$data[] = $arrEvents;
		}
		echo json_encode($data);
	}
	function getLoacionOfEvents($kolId) {
		$data['locations'] = $this->event->getEventLoaction($kolId);
		echo json_encode($data);
	}
	function save_event1(){
		$event_id=null;
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		// Getting the POST details of Events
		$eventDetails = array(
				'id' => $this->input->post('id'),
				'kol_id' => $this->input->post('kol_id'),
				'type' => $this->input->post('type'),
				'event_type' => $this->input->post('event_type'),
				'event_id' => $this->input->post('event_id'),
				'session_type' => $this->input->post('session_type'),
				'session_name' => ucwords(trim($this->input->post('session_name'))),
				'role' => ucwords(trim($this->input->post('role'))),
				'topic' => $this->input->post('topic'),
				'start' => app_date_to_sql_date($this->input->post('start')),
				'end' => app_date_to_sql_date($this->input->post('end')),
				'organizer' => ucwords(trim($this->input->post('organizer'))),
				'sponsor_type' => ucwords(trim($this->input->post('sponsor_type'))),
				'session_sponsor' => ucwords(trim($this->input->post('session_sponsor'))),
				'organizer_type' => $this->input->post('organizer_type'),
				'location' => ucwords(trim($this->input->post('location'))),
				'address' => $this->input->post('address'),
				'city_id' => $this->input->post('city_id'),
				'state_id' => $this->input->post('state_id'),
				'country_id' => $this->input->post('country_id'),
				'postal_code' => $this->input->post('postal_code'),
				'url1' => $this->input->post('url1'),
				'client_id' => $this->session->userdata('client_id'),
				'data_type_indicator' => $dataType
		);
		if($eventDetails['id']>0){
			$eventDetails['modified_by']=$this->session->userdata('user_id');
			$eventDetails['modified_on']=date("Y-m-d H:i:s");
			$event_id=$this->common_helper->updateEntity('kol_events',$eventDetails,array('id'=>$eventDetails['id']));
		}else{
			$eventDetails['created_by']=$this->session->userdata('user_id');
			$eventDetails['created_on']=date("Y-m-d H:i:s");
			$event_id=$this->common_helper->insertEntity('kol_events',$eventDetails);
		}
		if($event_id>0){
			$returnData['saved']	=true;
			$returnData['msg']		="Events Details are successfully updated";
		}else{
			$returnData['saved']	=false;
			$returnData['msg']		="Error in updating the event details,Please try again.";
		}
		echo json_encode($returnData);
	}
	function view_all_topics($kolId) {
		$this->load->model('kols/kol');
		$this->load->model('Specialities/Speciality');
		$arrKolDetail = $this->kol->editKol($kolId);
		$data['arrSpecialties'] = $this->Speciality->getAllSpecialties();
		$data['kolSpecialty'] = $arrKolDetail['specialty'];
		$this->load->view('view_all_topics', $data);
	}
	function get_topics_by_specialty($specialtyId) {
		// Get the list of Topic belongs to kol specialty
		$arrTopics = $this->event->getTopicsBySpecialty($specialtyId);
		$arrPreparedTopics = array();
		foreach ($arrTopics as $key => $value) {
			$arrPreparedTopics[$key] = $value['name'];
		}
		echo json_encode($arrPreparedTopics);
	}
}
?>