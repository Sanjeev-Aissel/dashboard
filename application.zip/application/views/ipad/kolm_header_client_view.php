<?php
/**
 * Common headers for Ipad 
 *
 * @author: Laxman K
 * @created on: 07-12-2012
 */
//With Trailing slashes
$userName	= $this->session->userdata('user_full_name');
$userMailId = $this->session->userdata('email');
$userPhoto	= $this->session->userdata('mem_pic');
// $companyName= $this->session->userdata('company_name');
$userTitle	= $this->session->userdata('title');
//- End of FreshDesk SSO Section
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('elements/kolm_header_client_view');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style type="text/css">
.secondaryNavWrapper li a.geographicalLink{
	width:110px;
}
.ui-widget-header {
	background:none;
}
#settingstab ul:hover{
/*	background:#E1E1E1; */
}
ul:hover.Settingsoptions {
	background:#EEEEEE !important;
}
#settingstab ul{
/*	background: none repeat scroll 0 0 #EEEEEE;*/
    list-style: none outside none;
    margin-bottom: 2px;
    margin-right: 0;
    padding-bottom: 4px;
    padding-left: 0;
    padding-top: 3px;
    text-align: center;
    width: 120px;
    width:150px;
}
#settingstab ul li ul{
	margin:0px;
	padding: 0 0 0 0;
}
#settingstab ul li a{
	text-decoration: none !important;
	color:gray;
}
#settingstab ul li a:hover{
	text-decoration: none !important;
	color:#3F7DB2;
}
#Settingsoptions{
	position: absolute;
	border-top: 1px solid;
	text-align: left !important;
}
#searchBoxWrapper input[type="text"], .advSearchWrapper{
	background: none;
}
#settingstab .navPrimSeparator{
	height: 12px;
    margin-top: 3px;
}

#loginBox{
	position: absolute; 
	display: none; 
	right:0;
	top: 37px;
	background: -moz-linear-gradient(center top , rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.05) 20%, rgba(0, 0, 0, 0.05) 100%) repeat scroll 0 0 transparent;
	border-top: 1px solid #CCCCCC;
	width:200px;
	width:300px;
	background-color:#fff;
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
	z-index:1002;
}

#loginBox #loginForm {
	margin: 0; 
	padding: 0; 
	width:auto; 
	border:0px;
}

.headerTopSectionWrapper #userSettingWrapper ul {
    float: right;
    list-style-type: none;
    margin:0;
    padding:10px 0;
    width:100%;
}
.headerTopSectionWrapper #userSettingWrapper ul li{
	padding-left:10px;
	border-bottom:1px inset #aaa;
	padding-top:2px;
	padding-bottom:2px;
}

.headerTopSectionWrapper #userSettingWrapper ul li:hover a{
/*	background-color:#E1E8F3;*/
	color:#000 !important;
}

.headerTopSectionWrapper #userSettingWrapper ul li a{
    text-decoration: none;
    display:block;
    width:154px;
    border-right: 0px;
}
.headerTopSectionWrapper #userSettingWrapper ul li div.actionIcon{
	margin-right:5px;
	float:left;
}
#headerTopSection .arrowUp {
    height: 15px;
    margin-top: -15px;
    position: absolute;
    right: 27px;
    top: 0;
    width: 35px;
}
#searchBoxWrapper{
	margin-top:-2px;
}
.loggedInUser{
	float: right;
	margin-right: 20px;
	font-size: 15px;
	line-height: 40px;
}
.optionValue{
	clear:both;
	background-color: #fff;
	padding-left:5px;
}
.optionValue:hover{
	background-color: #3e3e3e;
}
.optionValue a{
	line-height: 40px;
	height: 40px;
	width: 150px;
	text-decoration: none;
}
#loginForm{
	background-color: #fff;
}
.userProfilePhoto{
	border-radius:2px;
	-webkit-border-radius: 2px;
	-moz-border-radius: 2px;
	float: left;
	margin-right: 10px;
	width: 65px;
}
#userProfileInfoWrapper{
	height: 65px;
	margin-top: 2px;
    padding: 5px;
}
</style>
<script type="text/javascript">
/*
* To open the modal box to add feedback
* @author Vinayak
* @since 2.0
* @created on 22-Aug-2012
*/
//This function acts on displaying setting options.
$(function() {
    var button = $('#settingOptions');
    var box = $('#loginBox');
    var form = $('#loginForm');
    button.removeAttr('href');
    button.mouseup(function(login) {
        box.toggle();
        $('#maskbody').toggle();
        button.toggleClass('active');
    });
    form.mouseup(function() { 
        return false;
    });
    $('#maskbody').mouseup(function(login) {
        if(!($(login.target).parent('#settingOptions').length > 0)) {
            button.removeClass('active');
            box.hide();
            $('#maskbody').hide();
        }
    });
});

/*
* To open the modal box to add new category 
* @author vianyak
* @since 2.0
* @created on 12-4-2011
*/
function addFeedback(){
	$("#feedbackDialogContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#feedbackDialogContainer").dialog("open");
	$("#feedbackDialogContent").load(base_url+'feedbacks/add_feedback');
	return false;	
}

	function changePassword(){
		$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#changePasswordContainer").dialog("open");
		$("#passwordContent").load('<?php echo base_url().'client_users/change_password/'?>');
		//	$("#advSearchAddProfileContent").load(formAction);
		return false;	
	}
	function togglePrimaryMenus(){
		$('#ipadIconShortcuts').dialog("open");
		/*var categoryName	= sessionStorage['categoryName'];
	  	var hintStep	= sessionStorage['hintStep'];
	    if(categoryName=='overall_introduction'){
	    	moveFromCurrentStep(3);
	    }*/
	}
	$(document).ready(function(){
		// Settings for the password  Dialog Box
		var passwordOpts = {
				title: "PASSWORD",
				modal: true,
				autoOpen: false,
				width: 500,
				dialogClass: "microView",
				position: ['center', 80],
				open: function() {
					//display correct dialog content
				}
		};
		var feedbackAddOpts = {
				title: "Add Feedback",
				modal: true,
				autoOpen: false,
				width: 570,
				dialogClass: "microView",
				position: ['center', 80],
				open: function() {
					//display correct dialog content
				}
		};
		var menuShortcuts = {
				title: "Menu",
				modal: true,
				autoOpen: false,
				width: 800,
				height: 720,
				dialogClass: "microView",
				position: ['center', 20],
				open: function() {
					//jAlert('Height - '+window.screen.height+' Width - '+window.screen.width);
					//display correct dialog content
				}
		};
		$("#ipadIconShortcuts").dialog(menuShortcuts);
		$("#feedbackDialogContainer").dialog(feedbackAddOpts);
		$("#changePasswordContainer").dialog(passwordOpts);
	});
</script>
	<!-- Start of Header Div -->
	<div id="header" class="span-24">
		<?php 
			// Get the URI segment. Helps in setting the link as 'ACTIVE'
			$currentController	= $this->uri->segment(1);
			$currentMethod		= $this->uri->segment(2);
			$param				= $this->uri->segment(3);
			//Conditions data for Role based user
			$userRoleId 		=	$this->session->userdata('user_role_id');
		?>
		<!-- Start of Primary Navigation -->
 		<div class="nav-box clear">
 			<table>
 				<tr>
 					<td style="padding: 0px;text-align: center !important;width:50px;">
 						<div id="menuIcon" onclick="togglePrimaryMenus();">&nbsp;</div>
 					</td>
 					<td>
						<ul>
							<li>
	 						<?php 
								switch($currentController){
									case 'kols':
									//case 'interactions':
									case 'clinical_trials':
									case 'pubmeds':
									case 'requested_kols':
														if($currentController=='kols' && $currentMethod == 'client_index'){
															echo '<a class="current" href="'.base_url().'kols/client_index"><div class="navLinkHome sprite_iconSet"></div>Home</a>';
														}else{
															echo '<a class="current" href="'.base_url().'kols/list_kols_client_view"><div class="navLinkMyKols sprite_iconSet"></div>My KOLs</a>';
														}
														break;
									case 'organizations': 
									case 'requested_orgs':
														echo '<a class="current" href="'.base_url().'organizations/list_organizations_client_view"><div class="navLinkOrgs sprite_iconSet"></div>Organizations</a>';
														break;
									case 'plannings':
									case 'interactions':
									case 'payments':
									case 'monthly_reports':
									case 'contracts':
									case 'coachings':
														echo '<a class="current" href="'.base_url().'interactions/view_numeric_report"><div class="navLinkTrack sprite_iconSet"></div>Track</a>';
														break;
									case 'my_list_kols':
														echo '<a class="current" href="'.base_url().'my_list_kols/show_list"><div class="navLinkMyLists sprite_iconSet"></div>My Lists</a>';
														break;
									case 'maps': 
														echo '<a class="current" href="'.base_url().'maps/view_influence_map_ipad"><div class="navLinkMaps sprite_iconSet"></div>Network Maps</a>';
														break;
									case 'reports': 
														echo '<a class="current" href="'.base_url().'reports/view_reports/activity"><div class="navLinkReports sprite_iconSet"></div>Reports</a>';
														break;
									case 'surveys': 
														echo '<a class="current" href="'.base_url().'surveys/list_active_surveys"><div class="navLinkSurveys sprite_iconSet"></div>Surveys</a>';
														break;
								}
	 						?>
	 						</li>
 						</ul>
 						<span class="hintForShowMeHow" onclick="hintcategories();" style="color:#00f;cursor: pointer;line-height: 40px;padding-left: 5px;">Show me how</span>
 					</td>
 					<td style="padding-top:0px;padding-right:0px;">
 						<div class="headerTopSectionWrapper">
						<div id="headerTopSection" class="ui-tabs tooltip-demo tooltop-bottom">
							<div id="settingstab">
								<div id="settingOptions" class="userSettings sprite_iconSet">
									<a rel='tooltip' title="Options" href="#" onclick="return false;">&nbsp;</a>
								</div>
							</div>
							<!-- Setting Options drop down Starts Here -->
							<div id="loginBox">                
				            	<div class="arrowMarkIcon arrowUp"></div>
				            	<div id="loginForm">
				                    <div id="userSettingWrapper">
				                    	<div class="userSettingOptionsContainer">
				                    		<!--<div class="optionValue"><div class="userIcon sprite_iconSet" style="float: left;">&nbsp;</div><a style="float:right;padding:0px !important;" href="#" onclick="return false;"><?php echo $this->session->userdata('user_full_name');?></a></div>
				                    		-->
				                    		<div class="optionValue">
				                    			<div id="userProfileInfoWrapper"><?php 
													if(!empty($userPhoto)){
														echo '<img class="userProfilePhoto" alt="Profile Photo" src="'.base_url().'images/user_profile_images/'.$userPhoto.'" />';
													}else{
														echo '<img class="userProfilePhoto" alt="Profile Photo" src="'.base_url().'images/user3.png" />';
													}
													echo '<a href="'.base_url().'user_settings"><div><label style="display:block;line-height:15px;">'.$userName.'</label><span style="margin-top:-5px">'.$userTitle.'</span></div></a>';
												?></div>
				                    		</div>
				                    		<div class="optionValue" style="border-top:1px solid #333; "><div class="ticket sprite_iconSet" style="float: left;margin-right:15px;">&nbsp;</div><a style="padding:0px !important;" href="" onclick="addFeedback();return false;">&nbsp;Submit a ticket</a></div>
				                    		<div class="optionValue"><div class="help sprite_iconSet" style="float: left;margin-right:15px;">&nbsp;</div><a style="padding:0px !important;" href="<?php echo getSSOUrl($userName, $userMailId);?>" target="_blank" >&nbsp;Help</a></div>
				                    		<div class="optionValue" style="border-top:1px solid #333; "><div class="userSettings sprite_iconSet" style="background-position: -555px -145px;margin-left: 0px;float: left;margin-right:15px;">&nbsp;</div><a style="padding:0px !important;" href="<?php echo base_url();?>user_settings">&nbsp;Settings</a></div>
				                    		<div class="optionValue" style="border-top:1px solid #333; "><div class="logout sprite_iconSet" style="float: left;margin-right:15px;">&nbsp;</div><a style="padding:0px !important;" href="<?php echo base_url()?>login/logout">&nbsp;Logout</a></div>
				                    	</div>
										<!--<ul class="userSettingOptionsContainer">
											<li><div class="changepwd sprite_iconSet" style="float: left;">&nbsp;</div><a style="float:right;padding:0px !important;" href="" onclick="changePassword();return false;">&nbsp;Change Password</a></li>
								  			<li><div class="ticket sprite_iconSet" style="float: left;">&nbsp;</div><a style="float:right;padding:0px !important;" href="" onclick="addFeedback();return false;">&nbsp;Submit a ticket</a></li>
								  			<li><div class="help sprite_iconSet" style="float: left;">&nbsp;</div><a style="float:right;padding:0px !important;" href="http://aisselkolm.helpdocsonline.com" target="_new">&nbsp;Help</a></li>
								  			<li><div class="logout sprite_iconSet" style="float: left;">&nbsp;</div><a style="float:right;padding:0px !important;" href="<?php echo base_url()?>login/logout">&nbsp;Logout</a></li>
										</ul>
									--></div>
								</div>
							</div>
				            <!-- Setting Options drop down Ends Here -->
						</div>
						</div>
						<div id="searchBoxWrapper"><?php $this->load->view('search/search_box',array('searchDockType'=>'headerDock'));?></div>
						<!--<div class="loggedInUser"><div class="userIcon sprite_iconSet"></div><?php echo $this->session->userdata('user_full_name');?></div>
 					--></td>
 				</tr>
 			</table>
		</div>
		<!-- End of Primary Navigation -->
		
		<?php /*
			if(($currentController == 'kols') && 
				($currentMethod != 'search_kols') && 
				($currentMethod != 'view_kol_adv_search') &&
				($currentMethod != 'adv_search_kols') &&
				($currentMethod != 'search_events') &&
				($currentMethod != 'view_event_adv_search') && 
				($currentMethod != 'adv_search_events')&&
				($currentMethod != 'client_index') &&
				($currentMethod != 'list_kols_client_view') &&
				($currentMethod != 'import_kol_profiles')): ?>
			<div class="exportOptions exportOptionsContainer tooltip-demo tooltop-bottom" style="padding:0px;">
				<div style="float: left;color:#5396D1;padding-top:2px;">
					<?php if($currentMethod=="view" && ($subContentPage=="bio" || $subContentPage=="")){ ?>
						<?php if($arrKol['status'] == PRENEW){?>
							<button style="float: right;" id='kolRequestButton' onclick="addNewKolProfile(<?php echo $arrKol['id'];?>)">Request Profile</button>
						<?php }?>
						<!--<div style="float: right;padding-left: 10px; padding-right: 5px;"><label style="cursor: pointer;" onclick="jumpToAddInteraction('<?php echo $arrKol['id']?>');"><div class="actionIcon addIcon"></div>Add Interaction</label></div>
					--><?php } ?>
				</div>
				<div style="float: right;">
				<div class="createListIcon sprite_iconSet tooltip-demo tooltop-left" onclick="showListModalBox();"><a  rel='tooltip' title="Create List" href="#">&nbsp;</a></div>
					<?php if($this->session->userdata('client_id')!= INTERNAL_CLIENT_ID){?>
						<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="disableExports();"><a  rel='tooltip' title="Export profiles into Excel format" href="#">&nbsp;</a></div>
						<div class="pdfExportIcon sprite_iconSet" onclick="disableExports();"><a  rel='tooltip' title="Export profile into PDF format" href="#">&nbsp;</a></div>
						<div id="emailIcon" class="emailId sprite_iconSet" onclick="disableExports();">
							<a  rel="tooltip" title="Send profile to email" href="#">&nbsp;</a>
						</div>
					<?php } else{ ?>
						<div class="pdfExportIcon sprite_iconSet">
							<a rel="tooltip" title="Export profiles into PDF format" href="<?php echo base_url().'kols/export_pdf/'.(isset($arrKol['id'])?$arrKol['id']:0);?>" target="_new">&nbsp;</a>
						</div>
						<div class="excelExportIcon sprite_iconSet" onClick="showSingleKolExportBox(<?php echo (isset($arrKol['id'])?$arrKol['id']:0);?>)">
							<a  href="#"  rel="tooltip" title="Export profiles into Excel format">&nbsp;</a>
						</div>
						<div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBox(<?php echo (isset($arrKol['id'])?$arrKol['id']:0);?>)">
							<a  rel="tooltip" title="Send profile to email" href="#">&nbsp;</a>
						</div>
				<?php }?>
				</div>
			</div>
			<?php 
			endif;
			*/
			$arrData['currentController']	= $currentController;
			$arrData['currentMethod']		= $currentMethod;
			$arrData['param']				= $param;
			$arrData['subContentPage']		= $subContentPage;
			$arrData['arrOrganization']		= $arrOrganization;
			$arrData['arrKol']				= $arrKol;
			echo $this->load->view('elements/export_options',$arrData);
		?>
	</div>
	<!-- End of Header Div -->
	
	<!-- Container for the 'Advance Search' modal box -->
	<div id="advanceDailog">	
		<div id="advSearchAddContainer" class="microProfileDialogBox">
			<div class="profileContent" id="advSearchAddProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Advance Search' modal box -->
	
	<!-- Container for the 'Organization Import' modal box -->
	<div id="importOrgDialog">	
		<div id="importOrgContainer" class="microProfileDialogBox">
			<div class="profileContent" id="importOrgProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Organization Import' modal box -->
	
	<!-- Container for the 'KOL Import' modal box -->
	<div id="importKolDialog">	
		<div id="importKolContainer" class="microProfileDialogBox">
			<div class="profileContent" id="importKolProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'KOL Import' modal box -->
	
	<!-- Container for the 'Kol's Export' modal box -->
	<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Kol's Export' modal box -->
	

	<!-- Container for Email modal box -->
	<div id="addEmail" class="microProfileDialogBox">
 		<div id="emailContainer"  class="profileContent"></div>
 	</div>

 		
	<div id="categoryModalBoxWithinProile" class="microProfileDialogBox">
		<div class="addListContentForWithinProfile profileContent"></div>
	</div>
	
	<div id="feedbackDialog">	
		<div id="feedbackDialogContainer" class="microProfileDialogBox">
			<div class="profileContent" id="feedbackDialogContent"></div>
		</div>
	</div>
	
	<!-- Container for the 'Change Password' modal box -->
	<div id="changePasswordDailog">	
		<div id="changePasswordContainer" class="microProfileDialogBox">
			<div class="profileContent" id="passwordContent"></div>
		</div>
	</div>
	<div id="alignUsersModalWithinKolView" class="microProfileDialogBox">
		<div class="alignUsersContentWithinView profileContent"></div>
	</div>
	<div id="alignOrgUsersModalBoxWitinView" class="microProfileDialogBox">
		<div class="alignOrgUsersContentWitinView profileContent"></div>
	</div>
	<!--End of  Container for the 'Change Password' modal box -->
	<div id="ipadIconShortcuts">
		<table>
			<tr>
				<td><a href="<?php echo base_url()?>kols/client_index"><div class="navLinkHome sprite_iconSet"></div>Home</a></td>
				<td><a href="<?php echo base_url()?>kols/list_kols_client_view"><div class="navLinkMyKols sprite_iconSet"></div>My KOLs</a></td>
				<td><a href="<?php echo base_url()?>organizations/list_organizations_client_view"><div class="navLinkOrgs sprite_iconSet"></div>Organizations</a></td>
			</tr>
			<tr>
				<td><a href="<?php echo base_url()?>interactions/view_numeric_report"><div class="navLinkTrack sprite_iconSet"></div>Track</a></td>
				<td><a href="<?php echo base_url()?>my_list_kols/show_list"><div class="navLinkMyLists sprite_iconSet"></div>My Lists</a></td>
				<td><?php
						echo '<a href="'.base_url().'maps/view_influence_map_ipad"><div class="navLinkMaps sprite_iconSet"></div>Network Maps</a>';
				?></td>
			</tr>
			<tr>
				<td><a href="<?php echo base_url()?>surveys/list_active_surveys"><div class="navLinkSurveys sprite_iconSet"></div>Surveys</a></td>
				<td><a href="<?php echo base_url()?>reports/view_reports/activity"><div class="navLinkReports sprite_iconSet"></div>Reports</a></td>
				<td></td>
			</tr>
		</table>
	</div>