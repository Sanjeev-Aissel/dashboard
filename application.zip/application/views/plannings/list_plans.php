<?php

/**
 * This is HTML page which lists all the Plans of the perticular client
 * 
 * @package application.views.interactions
 * @author Vinayak
 * @since  1.5
 * @created on: 12-9-2011
 */

?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('plannings/list_plans',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min',
							'CalendarControl',
							//'jquery.validate',
							'jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.slider',
							'jqgridExportToExcel'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<?php 
	//Initiallize the Timeline slider
	$date	= date('Y');
	if($this->session->userdata('kolId')== '-1'){
		$userRoleId = $this->session->userdata('user_role_id');
	}
?>
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
<!-- Month Year Selection Calendar plugin -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />


	
<style type="text/css">
		#viewPlan{
			width:70%;
		}
		#viewPlanContainer{
		    background-color: #FFFFFF;
		    border-radius: 15px 15px 15px 15px;
		    display: block;
		    margin-left: 135px;
		    margin-top: 2px;
		    padding-left: 5px;
		    padding-right: 17px;
		 /*   padding-top: 24px; */
		    position: absolute;
		    width: 573px;
		}
		
		.listResultSet a{
			text-decoration:none;
			text-align:left;
			float:left;
		}
		
		tr.selectedRow {
	    	background-color: #D8DFEA !important;
		}
		
		.addLink {
			width:auto;
			float: right;
			margin-top: -25px;
		}
		
		.toggleBtnWrapper{
			width: auto;
		}
		
		#plansList{
		/*	width: 810px;*/
			float: right;
		}
			
		#addDeleteLinks img {
			margin-top: 18px;   
    		vertical-align: bottom;
		}
		
		
		#planCreate .error,#editPlanForm .error {
			background-color: #FFFFFF;
			border: 1px solid #BBBBBB;
			background-image: none;;
			padding: 0px;
			color: gray;
			border: 1px solid red;
		}
		#planCreate label.error ,#editPlanForm label.error { 
			float: none; 
			color: red; 
			padding-left: .5em; 
			vertical-align: top; 
			border: 0px;
			padding: 0px;
			font-weight: normal;
		}
		
		#addPlansForm input[type='button']{
			margin-left: 350px;
		}
		
		#addPlansForm  .duplicatePlan{
			border-bottom: 1px solid red;
			border-top: 1px solid red;
			background-color: lightPink;
		}
		div.actionIconsContainer{
			margin-left: 20px;
		}
		#viewPlanContainer {
			margin-left: 20px !important;
		}
		.dataTypeIndicator{
		  margin-right: 10px;
		}
		.iconCreatedByUser{
		   margin-right: 10px;
		}
	</style>

<script type="text/javascript">

	var minYear			= '<?php echo ($date-25);?>';
	var maxYear			= '<?php echo substr($maxYear, 0, 4); ?>';
	var subContentPage	= '<?php echo $subContentPage;?>';
	var userRoleId 		= <?php echo $userRoleId;?>;
	var role			= '<?php echo ROLE_MANAGER;?>';

	var plansTitle = "<?php echo lang("Track.Plans");?>";
	var kolName = "<?php echo lang("track.KOLName");?>";
	var assignedTo = "<?php echo lang("track.AssignedTo");?>";
	var target = "<?php echo lang("track.Target");?>";
	var date = "<?php echo lang("Overview.Date");?>";
	var achieved = "<?php echo lang("track.Achieved");?>";
	var action = "<?php echo lang("Overview.Action");?>";
	var name = "<?php echo lang("Organizations.Name");?>";
	var topicsTitle = "<?php echo lang("Track.Topics");?>";
	var objectivesTitle = "<?php echo lang("Track.Objectives");?>";
	var description = "<?php echo lang("track.Description");?>";
	var arrExcludeColumnsInExcelExport = new Array('micro','action','act',' '); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','objective_id','micro');
	jqgridIds	= new Array('listPlansResultSet','listtopicResultSet','listObjectiveResultSet');
        
        function viewPlans(interactionId){

		  var url="<?php echo base_url()?>"+'plannings/view_plan/'+interactionId;
                window.location.href=url;
	}
        
        function editPlan(id){
                var url="<?php echo base_url()?>"+'plannings/add_plans/'+id;
                 window.location.href=url; 
        }
</script>




<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.ui-tabs-vertical .ui-tabs-nav {
		margin-left: 0px;
		margin-right: 0px;
		padding-right:11px;
	}
	.listResultSet a{
		text-decoration:none;
		text-align:left;
		float:left;
	}
	
	tr.selectedRow {
    	background-color: #D8DFEA !important;
	}
	
	.addLink {
		width:auto;
		float: right;
/*		margin-top: -25px; */
		margin-top: 0px
	}
	
	.toggleBtnWrapper{
		width: auto;
		text-align: right;
		margin-bottom: 2px;
	}
	
	#plansList{
	/*	width: 800px;*/
		float: right;
	}
	
	#planReportsContainer{
		margin-top: 4px;
	}
	
	#objectiveList{
		margin-top: 10px;
	}	
/*	
	#timeLineSliderContainer{
		width: 810px;
	}
*/
	#timeLineSliderContainer p {
		margin-top: 36px;
		margin-top: 0px;
	}
		
	#addDeleteLinks img {
		margin-top: 18px;   
    	vertical-align: bottom;
	}
	
	#planCreate {
		margin-top: 17px;
	}
	
	#planCreate .error,#editPlanForm .error {
		background-color: #FFFFFF;
		border: 1px solid #BBBBBB;
		background-image: none;;
		padding: 0px;
		color: gray;
		border: 1px solid red;
		margin-bottom: 0px;
	}
	#planCreate label.error ,#editPlanForm label.error { 
		float: none; 
		color: red; 
		padding-left: .5em; 
		vertical-align: middle; 
		border: 0px;
		padding: 0px;
		font-weight: normal;
		margin-bottom: 0px;
		margin-left: 5px;
	}
	
	#addPlansForm input[type='button']{
		margin-left: 350px;
	}
	
	#addPlansForm  .duplicatePlan{
		border-bottom: 1px solid red;
		border-top: 1px solid red;
		background-color: lightPink;
	}
	
	#addPlansForm td{
		vertical-align: top;
	}
	
	td#addDeleteLinks{
		vertical-align: middle;
	}
	
	#plansReports{
		float: left;
		clear: left;
		width: 100%;
	}
	
	#plansReports td.nodeLevelTwo {
		padding-left: 50px;
		background: url("<?php echo base_url();?>images/tabletree-dots.gif") no-repeat scroll 36px 54% transparent;
	}
	
	#plansReports td.endNode {
		background: url("<?php echo base_url();?>images/tabletree-dots2.gif") no-repeat scroll 36px 50% transparent;
	}
	#plansReports tr.collapsed td .expander {
	    background-image: url("<?php echo base_url();?>images/toggle-expand-dark.png");
	    padding-left: 19px;
	    cursor: pointer;
	    background-repeat: no-repeat;
	}
	#plansReports tr.expanded td .expander {
	    background-image: url("<?php echo base_url();?>images/toggle-collapse-dark.png");
	    padding-left: 19px;
	    cursor: pointer;
	    background-repeat: no-repeat;
	}
	#plansReports .parentNode{
		color: green;
		font-weight: bold;
	}
	
	#monthSelectionBar {
		height: auto;
	}
	#monthSelectionBar p{
		float: left;
		margin-right: 10px;
	}
	#monthSelectionBar p input[type="text"]{
		width:100px;
		margin-top:0px;
	}
	label#reloadReportLink{
		cursor: pointer;
	}
	
	#plansReports tr.parentNode {
		background: whiteSmoke;
	}
	
	#plansReports tr.subNode {
		background: wheat;
	}
	
	#planReportsContainer #leftReports{
		width: 100%;
		min-height: 565px;
		float: left;
	}
	#planReportsContainer #rightReports{
		width: 38%;
		min-height: 565px;
		float: left;
		border: 1px solid silver;
		margin-left: 10px;
		text-align: center;
	}
	
	#planReportsContainer .parentNode td {
		border-bottom: 1px solid black;
	}
	#plansList {
	    margin-top: -28px;
	    margin-top: 0px;
	}
	#objectiveList,#planReportsContainer,#planCreate{
		padding-left:5px;
	}
</style>

		<div id="plansTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<li><a href="#plansList">Plans</a></li>				
				<?php if($userRoleId == ROLE_MANAGER || $userRoleId == ROLE_ADMIN){?>
					<li><a href="#objectiveList">Objectives</a></li>
					<li><a href="#planCreate">Create Plan</a></li>
				<?php }?>
				<li><a href="#planReportsContainer">Reports</a></li>
			</ul>
			-->
			<?php 
				switch($subContentPage){
                                                case 'objectives':	if($userRoleId != ROLE_READONLY_USER){
			?>
								<div class="exportOptionsContainer">
									<ul class="pageRightOptions">
										<li><label class="link" onclick="addObjective();" id="addButton"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add Objective</label></li>
										<li>
									       	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#listObjectiveResultSet','objectives');">
												<a href="#" rel="tooltip" data-original-title="Export Objectives Details into Excel format">&nbsp;</a>
											</div>
										</li>
									</ul>
								</div>
                                                <?php }  ?>
								<div id="objectiveList" class="clear">
									<!-- Container for Objective grid -->
									<div class="gridWrapper clear" id="objectiveContainer">
											<table id="listObjectiveResultSet"></table>
											<div id="listObjectivePage"></div>
									</div>
									<!-- Enf of Container for Objective grid -->
									
									<!-- Container for Add objective modal box -->
									<div id="objectiveAddContainer">
										<div id="objectiveAddProfileContent" class ="profileContent">
										
										</div>
									</div>
									<!-- End of Container for Add objective modal box -->
									<!-- Container for Edit objective modal box -->
									<div id="objectiveEditContainer">
										<div id="objectiveEditProfileContent" class="profileContent">
															
										</div>
									</div>
								</div>
									<!-- End of Container for Edit objective modal box -->
			<?php			
							break;
						case 'create_plan': if($userRoleId != ROLE_READONLY_USER){
			?>
											<!-- Start of 'Create Plan' Form -->
											<div id="planCreate">
												<div id="planCreateContainer">
												
												</div>
												<!-- Start of  'Plan Edit' Model Box-->
												<div id="planEditContainer">
													<div id="planEditContent" class="profileContent">
																		
													</div>			
												</div>
												<!-- End of  'Plan Edit' Model Box-->
											</div>
											<!-- End of 'Create Plan' Form -->
			<?php 						}
							break;
						case 'reports':
			?>
							<!-- Start of 'Plans Reports' Form -->
							<div id="planReportsContainer">
								<div id="leftReports">
									<div id="monthSelectionBar" style="display: none;">
										<p>
											<label>Month From</label>:
											<input type="text" name="report_start_date" id="reportStartDate" onclick="showCalendarControl(this.id);" value="<?php echo date('m/Y');?>" style="vertical-align: middle;" />
										</p>
										<p>
											<label>To</label>:
											<input type="text" name="report_end_date" id="reportEndDate" onclick="showCalendarControl(this.id);" value="<?php echo date('m/Y');?>" style="vertical-align: middle;" />
										</p>
										<input type="button" id="reloadReportLink" value="Filter" />
									</div>
									<div id="plansReports">
										
									</div>
								</div>
								<!--<div id="rightReports">
									Charts
								</div>				
							--></div>
							<!-- End of 'Plans Reports' Form -->
			<?php 
							break;
						case 'topics':
			?>
							<div class="exportOptionsContainer">
								<ul class="pageRightOptions">
									<li><label class="link" onclick="addtopic();" id="addButton"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add topic</label></li>
								</ul>
							</div>
							<div id="topicList" class="clear">
								<!-- Container for topic grid -->
								<div class="gridWrapper clear" id="topicContainer">
										<table id="listtopicResultSet"></table>
										<div id="listtopicPage"></div>
								</div>
								<!-- Enf of Container for topic grid -->
								
								<!-- Container for Add topic modal box -->
								<div id="topicAddContainer">
									<div id="topicAddProfileContent" class ="profileContent">
									
									</div>
								</div>
								<!-- End of Container for Add topic modal box -->
								<!-- Container for Edit topic modal box -->
								<div id="topicEditContainer">
									<div id="topicEditProfileContent" class="profileContent">
														
									</div>
								</div>
							</div>
								<!-- End of Container for Edit objective modal box -->
			<?php 
							break;		
			
						default:
			?>
                          <div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
								<div class="exportOptionsContainer">
									<ul class="pageRightOptions">
										<li>
											<label>Year Range:</label>
											<input type="text" readonly="readonly" id="yearRange" style="border:0; color:#f6931f; font-weight:bold;vertical-align: middle;background-color:#fff;width: 80px;" />
										</li>
										<li>
											<div style="min-width:100px;" id="timeLineSlider" class="timeLineSlider" title="Slide to Adjust Timeline"></div>
										</li>
<!--										<li><input type="button" onClick="kolGrouping('toggleKolGrouping','objectiveGrouping','userGrouping','Group By KOL','Group By Product','Group By User','kol_name','objective_name','user_name');" value="Group By KOL" name="toggleKolGrouping" id="toggleKolGrouping" /></li>
										<li><input type="button" onClick="userGrouping('userGrouping','objectiveGrouping','toggleKolGrouping','Group By User','Group By Product','Group By KOL','user_name','objective_name','kol_name');" value="Group By User" name="userGrouping" id="userGrouping" /></li>-->
										<?php 
                                            $arrKol = array();
                                            if($kolId!=''){
                                                $arrKol["kol_id"]=$kolId;            
                                            }?>
           							<?php if($this->common_helpers->isActionAllowed('planning','add',$arrKol)){ ?>
										<li style="margin-left: 50px;"> <a style="float:right" href="<?php echo base_url() ?>/plannings/show_plans/create_plan" class="NewBlueButton NewAddIcon" >Create Plans</a><br/><br/></li>
									<?php }?>								
										<li>
									       	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#listPlansResultSet','plans');">
												<a href="#" rel="tooltip" data-original-title="Export Plans Details into Excel format">&nbsp;</a>
											</div>
										</li>
									</ul>
								</div>
							</div>
							<div id="plansList" class="clear">
								<div class="gridWrapper" id="plansGridContainer">
										<table id="listPlansResultSet"></table>
										<div id="listPlansPage"></div>
								</div>
							</div>
							<div id="viewPlan">
								<div id="viewPlanContainer" class="profileContent">
								
								</div>
							</div>
							<!-- Start of  'Plan Edit' Model Box-->
							<div id="planEditContainer">
								<div id="planEditContent" class="profileContent">
													
								</div>			
							</div>
							<!-- End of  'Plan Edit' Model Box-->
			<?php 
							break;
				}
			?>
		
	</div>
	
