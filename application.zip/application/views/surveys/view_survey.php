<?php
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 29-03-2013
 *  
 */
// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style type="text/css">
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	#viewSurvey{
/*		width: 805px;
		margin-top: -75px;*/
		margin-top: 0px;
		/*float: right;*/
	}
	legend {
	    color: #626262;
	    font-size: 12px;
	    padding: 0 5px;
	}
	tr.tableHeader th{
		background-color:#C4D8EF;
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll 2px -274px transparent;
		color: #4D7BD6;
	}
	tr.tableSubHeader th{
		background-color:#eee;
	}
	.alignRight{
		padding-right:0px;
	}
	.alignCenter{
		text-align: center;
	}
	.alignLeft{
		text-align: left;
	}
	.alignTop{
		vertical-align: top;
	}
	th, td, caption {
	    padding: 4px 5px;
	}
	th.borderBottom{
		border-bottom: 0px solid #aaa;
	}
	.addLink{
		text-align: right;
	}
	#viewSurvey .kolRequestIcon{
		margin-left: 0px;
	}
</style>
<script type="text/javascript">
	function showMicroProfile(kolId,thisEle){
		var pos = $(thisEle).parent().parent().offset();
		var xPos=pos.left-18;
		var yPos=pos.top-53;
		$("#arraouHolder").css({'position': 'absolute','top':yPos,'left':xPos+45});
		$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+56});
		$("#arraouHolder").show();
		$("#contentHolder").show();
		$(".profileContent").html("");
		$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		
		$("#dailog2 .profileContent").load(base_url+'/kols/view_kol_micro/'+kolId,{},
				function(){	$('#contentHolder .profileContent').unblock(); }
			);
		return false;
	}
	function closeKolProfile(){
		$("#arraouHolder").hide();
		$(".profileContent").html("");
		$("#contentHolder").hide();
	}
	function addNewKolProfile(id){
		/*$(".addNewKolContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addNewKol").dialog("open");
		$(".addNewKolContent").load(base_url+'surveys/add_client_pre_kol/'+id);*/
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:base_url+'surveys/add_client_pre_kol_request/'+id,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
					//jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
					//window.location = base_url+'requested_kols/show_client_requested_kols';
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
		return false;	
	}
	$(document).ready(function(){
		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#newKolProfile").dialog(addNewKol);
	});
</script>
<div id="viewSurvey">
	<!--<button>MSL/KDM Survey</button>
	-->
	<div class="buttonsWarpper">
		<div class="addLink">
			<?php
				$surveyId		= $this->uri->segment(3);
				if(isset($editAllowed) && ($editAllowed)){
					foreach($arrSurveyData['arrAnswerData'] as $key=>$arrData){
						if($arrData[0]['created_by']==$this->session->userdata('user_id')){
							$respondentId	= $this->uri->segment(4);
							$userId			= $this->uri->segment(5);
							echo '<a class="blueButton" href="'.base_url().'surveys/edit_survey_data/'.$surveyId.'/'.$respondentId.'/'.$userId.'">Edit</a>';
						}
						break;
					}
				}
			?>
			<a class="blueButton" href="<?php echo base_url();?>surveys/list_surveys/<?php echo $surveyId;?>">Back to question</a>
		</div>
	</div>

	<div class="contentHeader"><span>Response - <?php echo $arrSurveyData['arrSurveyData']['name'];?></span></div>
	<table style="margin-top:5px;">
		<caption style="font-weight: bold;">Respondent Details</caption>
		<tr>
			<th class="alignRight">Name:</th>
			<td><?php echo $arrRespondent[0]['respondent'];?></td>
			<th class="alignRight">State:</th>
			<td><?php echo $arrRespondent[0]['respondent_state'];?></td>
		</tr>
<!--		<tr>-->
<!--			<th class="alignRight">Country:</th>-->
<!--			<td><?php //echo $arrRespondent[0]['respondent_country'];?></td>-->
<!--		</tr>-->
		<tr>
			<th class="alignRight">City:</th>
			<td><?php echo $arrRespondent[0]['respondent_city'];?></td>
			<th class="alignRight">Postal Code:</th>
			<td><?php echo $arrRespondent[0]['respondent_postal'];?></td>
		</tr>
		<!-- <tr>
			<th class="alignRight">MDM ID:</th>
			<td><?php echo $arrRespondent[0]['mdm'];?></td>
			<th class="alignRight"></th>
			<td></td>
		</tr> -->
	</table>
	<?php $arrRespondent2[] = end($arrRespondent); if($arrRespondent2[0]['zeroInfluencers'] == ''){?>
	<fieldset style="border-color:#4D7BD6;">
		<legend style="color:#4D7BD6;"><?php echo $arrSurveyData['arrSurveyData']['name'];?></legend>
		<table id="evaluationDetails">
			<?php $i	= 0;
				foreach($arrSurveyData['arrQuestionData'] as $categoryName => $arrSurveys){?>
				<tr class="tableHeader">
					<th class="alignLeft" colspan="7"><?php echo $categoryName;?></th>
				</tr>
				<?php foreach($arrSurveys as $key => $arrRow){
						$i++;
					?>
					<tr class="tableSubHeader">
						<th class="alignTop" colspan="7"><?php echo $i.') '.$arrRow['question'];?></th>
					</tr>
					<tr>
						<th colspan="2" class="borderBottom">Name</th>
<!--						<th class="borderBottom">Country</th>-->
						<th class="borderBottom">State</th>
						<th class="borderBottom">City</th>
						<th class="borderBottom">Postal Code</th>
						<!-- <th class="borderBottom">MDM ID</th> -->
					</tr>
					<?php foreach($arrSurveyData['arrAnswerData'][$arrRow['id']] as $index=>$arrAnswers){
						//pr($arrAnswers);
							$microview	= '';
							$name		= '';
							if($arrAnswers['source_table']=="kols"){
								$kolGender	= 'Male';
								if(isset($arrAnswers['gender'])){
									$kolGender	= $arrAnswers['gender'];
								}
								$microview	= '<div style="float:left;margin-right:5px;margin-top:-4px;" class="tooltip-demo tooltop-right '.$kolGender.' microViewIcon" onclick="showMicroProfile('.$arrAnswers['source_table_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Profile Snapshot">&nbsp;</a></div>';
								$name		= '<a href="'.base_url().'kols/view/'.$arrAnswers['source_table_id'].'">'.$arrAnswers['name'].'</a>';
							}else{
								$microview	= '<div style="float:left;" class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$arrAnswers['source_table_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request profile">&nbsp;</a></div>';
								$name		= $arrAnswers['name'];
							}
							if(empty($arrAnswers['org_name'])){
								$arrAnswers['org_name']	= 'Not Available';
							}
						?>
						<tr>
							<td colspan="2"><?php echo $microview.$name;?></td>
							
<!--							<td><?php //echo $arrAnswers['country'];?></td>-->
							<td><?php echo $arrAnswers['state'];?></td>
							<td><?php echo $arrAnswers['city'];?></td>
							<td><?php echo $arrAnswers['postal'];?></td>
							<!-- <td><?php echo $arrAnswers['mdm'];?></td> -->
						</tr>
				<?php }
				}
			}?>
		</table>
	</fieldset>
	<?php }?>
	<?php $arrRespondent1[] = end($arrRespondent);if($arrRespondent1[0]['zeroInfluencers'] != ''){?>
		<div style="margin-bottom: 25px;">
			<?php if($arrRespondent1[0]['zeroInfluencers'] == 1){?>
			 	<label style="font-weight: bold;">HCP did not provide influencers</label>				
			 <?php }else{?>
			 	<label style="font-weight: bold;">HCP does not have influencers</label>
			 <?php }?>	
		</div>
	<?php }?>
</div>
<div id="dailog2">
	<!-- Container for the 'Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		</div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
<div id="newKolProfile" class="microProfileDialogBox">
	<div class="newProfileContent profileContent"></div>
</div>