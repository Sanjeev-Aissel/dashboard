<?php
/**
 * File to show the Excel report
 *
 * @author: Ambarish
 * @created on: 02-02-11
 */


?>
<STYLE type="text/css">
	.tableTd {
	   	border-width: 0.5pt; 
		border: solid; 
	}
	td{
		border-width: 0.5pt; 
		border: solid;
	}
	thead#titles th{
		font-weight: bolder;
		border-width: 0.5pt; 
		border: solid; 
	}
   </STYLE>
   
	<div id="kolOverview">
		<table class="records">
			<caption>List of KOL Overview Records</caption>
			<thead id="titles">
				<tr>
					<th>PIN</th>
					<th>Picture</th> 
					<th>Salutation</th>
					<th>First</th>
					<th>Middle</th>
					<th>Last</th>
					<th>Suffix</th>
					<th>Gender</th>
					<!-- <th>Licence#</th> -->
					<th>Specialty</th>
					<th>Sub-Specialty</th>
					<th>Organization Name</th>
					<th>Department</th>
					<th>Title</th>
					<th>Address 1</th>
					<th>Address 2</th>
					<th>City</th>
					<th>State / Province</th>
					<th>Postal Code</th>
					<th>Country</th>
					<th>Phone</th>
					<th>Fax</th>
					<th>Email</th>
					<th>Additional Phone - Additional Email</th>
					<th>Bio</th>
					<th>Clinical Research Interests</th>
					
				</tr>
			</thead>
				<?php 
					foreach ($dataSet as $data){
						foreach($data['arrKol'] as $kol){
							echo '<tr>';
								echo '<td class="tableTdContent" style="position:relative; overflow:hidden; width:100px; height:100px;">' .$kol['id']. '</td>';
							
								if($kol['profile_image'] != ''){
									echo '<td>'.'<img alt="Image"  src="'. base_url(). 'images/kol_images/resized/'. $kol['profile_image'].'"/>'.'</td>';
								}else{
									echo '<td>'.'<img alt="Image" width="150" height="150" src="<?php echo base_url()?>images/user_doctor.jpg" />'. '</td>';
								}
					
								echo '<td>' .$kol['salutation']. '</td>';
								echo '<td>' .$kol['first_name']. '</td>';
								echo '<td>' .$kol['middle_name']. '</td>';
								echo '<td>' .$kol['last_name']. '</td>';
								echo '<td>' .$kol['suffix']. '</td>';
								echo '<td>' .$kol['gender']. '</td>';
								//echo '<td>' .$kol['license']. '</td>';
								
								echo '<td>' .$arrSpecialties[$kol['specialty']]. '</td>';
								echo '<td>' .$kol['sub_specialty']. '</td>';
								echo '<td>' .$kol['org_id']. '</td>';
								
								echo '<td>' .$kol['division']. '</td>';
								
								echo '<td>' .$kol['title']. '</td>';
								echo '<td>' .$kol['address1']. '</td>';
								echo '<td>' .$kol['address2']. '</td>';
								echo '<td>' .$kol['City']. '</td>';
								echo '<td>' .$kol['Region']. '</td>';
								echo '<td>' .$kol['postal_code']. '</td>';
								echo '<td>' .$kol['Country']. '</td>';
								echo '<td>' .$kol['primary_phone']. '</td>';
								echo '<td>' .$kol['fax']. '</td>';
								echo '<td>' .$kol['primary_email']. '</td>';
								echo '<td>';
								$j=1;
								foreach ($data['arrAdditionalContact'] as $i => $additionalContact){
									echo $j.". ".$additionalContact. '<br />'; 
									$j++;
								}
								echo '</td>';
								echo '<td>' .$kol['biography']. '</td>';
								echo '<td>' .$kol['research_interests']. '</td>';
		
							echo '</tr>';
					}
				}
			?>
		</table>
	</div>


	<div id="kolEducation">
		<table class="records" border="1">
			<caption>List of KOL Education Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>Name</th>
					<th>Education Type</th>
					<th>Degree</th>
					<th>Specialty</th>
					<th>Year</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrEducation'] as $education){
						if($education['type'] == 'education'){
							echo '<tr>';
								
								echo '<td>' .$education['kol_id']. '</td>';
								echo '<td>' .$education['name']. '</td>';
								echo '<td>' ."Education". '</td>';
								echo '<td>' .$education['degree']. '</td>';
								echo '<td>' .$education['specialty']. '</td>';
								echo '<td>&nbsp</td>';
							echo '</tr>';
						}	
					}
	
					
					foreach($data['arrEducation'] as $education){
						if($education['type'] == 'training'){
							echo '<tr>';
								
								echo '<td>' .$education['kol_id']. '</td>';
								echo '<td>' .$education['name']. '</td>';
								echo '<td>' ."Training". '</td>';
								echo '<td>' .$education['degree']. '</td>';
								echo '<td>' .$education['specialty']. '</td>';
								echo '<td>&nbsp</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrEducation'] as $education){
						if($education['type'] == 'board_certification'){
							echo '<tr>';
								
								echo '<td>' .$education['kol_id']. '</td>';
								echo '<td>' .$education['name']. '</td>';
								echo '<td>' ."Board Certification". '</td>';
								echo '<td>' .$education['degree']. '</td>';
								echo '<td>' .$education['specialty']. '</td>';
								echo '<td>&nbsp</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrEducation'] as $education){
						if($education['type'] == 'honors_awards'){
							echo '<tr>';
								
								echo '<td>'	.$education['kol_id']. '</td>';
								echo '<td>' .$education['honor_name']. '</td>';
								echo '<td>' ."Award/Honor". '</td>';
								echo '<td>&nbsp</td>';
								echo '<td>&nbsp</td>';
								if($education['year'] != '0'){
									echo '<td>' .$education['year']. '</td>';
								}
							echo '</tr>';	
						}	
					}
				}
			?>
		</table>
	</div>
	
	<div id="kolAffiliation">
		<table class="records" border="1">
			<caption>List of KOL Affiliation Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>Affiliation Type</th>
					<th>Engagement Type</th>
					<th>Name</th>
					<th>Department</th>
					<th>Title/Purpose</th>
					<th>Start</th>
					<th>End</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrMembership'] as $membership){
						if($membership['type'] == 'university'){
							echo '<tr>';
								
								echo '<td>' .$membership['kol_id']. '</td>';
								echo '<td>' ."University/Hospital". '</td>';
								echo '<td>' .$membership['engagement_type']. '</td>';
								echo '<td>' .$membership['name']. '</td>';
								echo '<td>' .$membership['department']. '</td>';
								echo '<td>' .$membership['role']. '</td>';
								echo '<td>' .$membership['start_date']. '</td>';
								echo '<td>' .$membership['end_date']. '</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrMembership'] as $membership){
						if($membership['type'] == 'association'){
							echo '<tr>';
								
								echo '<td>' .$membership['kol_id']. '</td>';
								echo '<td>' ."Association". '</td>';
								echo '<td>' .$membership['engagement_type']. '</td>';
								echo '<td>' .$membership['name']. '</td>';
								echo '<td>' .$membership['department']. '</td>';
								echo '<td>' .$membership['role']. '</td>';
								echo '<td>' .$membership['start_date']. '</td>';
								echo '<td>' .$membership['end_date']. '</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrMembership'] as $membership){
						if($membership['type'] == 'industry'){
							echo '<tr>';
								
								echo '<td>' .$membership['kol_id']. '</td>';
								echo '<td>' ."Industry". '</td>';
								echo '<td>' .$membership['engagement_type']. '</td>';
								echo '<td>' .$membership['name']. '</td>';
								echo '<td>' .$membership['department']. '</td>';
								echo '<td>' .$membership['role']. '</td>';
								echo '<td>' .$membership['start_date']. '</td>';
								echo '<td>' .$membership['end_date']. '</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrMembership'] as $membership){
						if($membership['type'] == 'government'){
							echo '<tr>';
								
								echo '<td>' .$membership['kol_id']. '</td>';
								echo '<td>' ."Government Agency". '</td>';
								echo '<td>' .$membership['engagement_type']. '</td>';
								echo '<td>' .$membership['name']. '</td>';
								echo '<td>' .$membership['department']. '</td>';
								echo '<td>' .$membership['role']. '</td>';
								echo '<td>' .$membership['start_date']. '</td>';
								echo '<td>' .$membership['end_date']. '</td>';
							echo '</tr>';	
						}	
					}
					
					foreach($data['arrMembership'] as $membership){
						if($membership['type'] == 'others'){
							echo '<tr>';
								
								echo '<td>' .$membership['kol_id']. '</td>';
								echo '<td>' ."Other". '</td>';
								echo '<td>' .$membership['engagement_type']. '</td>';
								echo '<td>' .$membership['name']. '</td>';
								echo '<td>' .$membership['department']. '</td>';
								echo '<td>' .$membership['role']. '</td>';
								echo '<td>' .$membership['start_date']. '</td>';
								echo '<td>' .$membership['end_date']. '</td>';
							echo '</tr>';	
						}	
					}
				}
			?>
		</table>
	</div>
	
	<div id="kolEvents">
		<table class="records" border="1">
			<caption>List of KOL Events Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>Event Category</th>
					<th>Event Name</th>
					<th>Event Type</th>
					<th>Session Type</th>
					<th>Role</th>
					<th>Session Name</th>
					<th>Topic</th>
					<th>Start</th>
					<th>End</th>
					<th>Organizer</th>
					<th>Location</th>
					<th>Address</th>
					<th>Country</th>
					<th>State</th>
					<th>City</th>
					<th>Postal Code</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrEvent'] as $event){
						if($event['type'] == 'conference'){
							echo '<tr>';
								
								echo '<td>' .$event['kol_id']. '</td>';
								echo '<td>' ."Conference". '</td>';
								echo '<td>' .$event['name']. '</td>';
								echo '<td>' .$event['event_type']. '</td>';
								echo '<td>' .$event['session_type']. '</td>';
								echo '<td>' .$event['role']. '</td>';
								echo '<td>' .$event['session_name']. '</td>';
								echo '<td>&nbsp</td>';//echo '<td>' .$event['topic']. '</td>';
								echo '<td>' .$event['start']. '</td>';
								echo '<td>' .$event['end']. '</td>';
								echo '<td>' .$event['organizer']. '</td>';
								echo '<td>' .$event['location']. '</td>';
								echo '<td>' .$event['address']. '</td>';
								echo '<td>' .$event['Country']. '</td>';
								echo '<td>' .$event['Region']. '</td>';
								echo '<td>' .$event['City']. '</td>';
								echo '<td>' .$event['postal_code']. '</td>';
							echo '</tr>';	
						}	
					}
					foreach($data['arrEvent'] as $event){
						if($event['type'] == 'online'){
							echo '<tr>';
								
								echo '<td>' .$event['kol_id']. '</td>';
								echo '<td>' ."Online". '</td>';
								echo '<td>' .$event['name']. '</td>';
								echo '<td>' .$event['event_type']. '</td>';
								echo '<td>' .$event['session_type']. '</td>';
								echo '<td>' .$event['role']. '</td>';
								echo '<td>' .$event['session_name']. '</td>';
								echo '<td>&nbsp</td>';//echo '<td>' .$event['topic']. '</td>';
								echo '<td>' .$event['start']. '</td>';
								echo '<td>' .$event['end']. '</td>';
								echo '<td>' .$event['organizer']. '</td>';
								echo '<td>' .$event['location']. '</td>';
								echo '<td>&nbsp</td>';
								echo '<td>' .$event['Country']. '</td>';
								echo '<td>' .$event['Region']. '</td>';
								echo '<td>' .$event['City']. '</td>';
								echo '<td>&nbsp</td>';
							echo '</tr>';	
						}	
					}
				}
			?>
		</table>
	</div>
	
	<div id="kolMedia">
		<table class="records" border="1">
			<caption>List of KOL Social Media Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>Blog</th>
					<th>LinkedIn</th>
					<th>Facebook</th>
					<th>Twitter</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrKol'] as $kol){
						echo '<tr>';
							echo '<td>' .$kol['id']. '</td>';
							echo '<td>' .$kol['blog']. '</td>';
							echo '<td>' .$kol['linked_in']. '</td>';
							echo '<td>' .$kol['facebook']. '</td>';
							echo '<td>' .$kol['twitter']. '</td>';
						echo '</tr>';
					}
				}
			?>
		</table>
	</div>		
	
	<div id="kolPublications">
		<table class="records" border="1">
			<caption>List of KOL Publications Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>PMID</th>
					<th>Journal Name</th>
					<th>Article Name</th>
					<th>Affiliation</th>
					<th>Date</th>
					<th>Authors</th>
					<th>Authorship Position</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrPublication'] as $publication){
						echo '<tr>';
							echo '<td>' .$publication['kol_id']. '</td>';
							echo '<td>' .$publication['pmid']. '</td>';
							echo '<td>' .$publication['journal_name']. '</td>';
							echo '<td>' .$publication['article_title']. '</td>';
							echo '<td>' .$publication['affiliation']. '</td>';
							echo '<td>' .$publication['date']. '</td>';
							echo '<td>' .$publication['authors']. '</td>';
							echo '<td>' .$publication['auth_pos']. '</td>';
						echo '</tr>';
					}
				}
			?>
		</table>
	</div>	
	
	<div id="kolClinicalTrials">
		<table class="records" border="1">
			<caption>List of KOL ClinicalTrials Records</caption>
			<thead>
				<tr>
					<th>PIN</th>
					<th>CTID</th>
					<th>Study Type</th>
					<th>Trial Name</th>
					<th>Condition</th>
					<th>Intervention</th>
					<th>Phase</th>
					<th>Role</th>
					<th>Number of enrollees</th>
					<th>Number of trial sites</th>
					<th>Sponsors</th>
					<th>Status</th>
					<th>Start Date</th>
					<th>End Date</th>
					<th>Minimum Age</th>
					<th>Maximum Age</th>
					<th>Gender</th>
					<th>Investigators</th>
					<th>Collaborator</th>
					<th>Purpose</th>
					<th>Official Title</th>
					<th>Keywords</th>
					<th>MeSH Terms</th>
					<th>Url</th>
				</tr>
			</thead>
			<?php 
				foreach ($dataSet as $data){
					foreach($data['arrClinicalTrial'] as $clinicalTrial){
						echo '<tr>';
							echo '<td>' .$clinicalTrial['kol_id']. '</td>';
							echo '<td>' .$clinicalTrial['ct_id']. '</td>';
							echo '<td>' .$clinicalTrial['study_type']. '</td>';
							echo '<td>' .$clinicalTrial['trial_name']. '</td>';
							echo '<td>' .$clinicalTrial['condition']. '</td>';
							echo '<td>' .$clinicalTrial['interventions']. '</td>';
							echo '<td>' .$clinicalTrial['phase']. '</td>';
							echo '<td>' .$clinicalTrial['kol_role']. '</td>';
							echo '<td>' .$clinicalTrial['no_of_enrollees']. '</td>';
							echo '<td>' .$clinicalTrial['no_of_trial_sites']. '</td>';
							echo '<td>' .$clinicalTrial['sponsors']. '</td>';
							echo '<td>' .$clinicalTrial['status']. '</td>';
							echo '<td>' .$clinicalTrial['start_date']. '</td>';
							echo '<td>' .$clinicalTrial['end_date']. '</td>';
							echo '<td>' .$clinicalTrial['min_age']. '</td>';
							echo '<td>' .$clinicalTrial['max_age']. '</td>';
							echo '<td>' .$clinicalTrial['gender']. '</td>';														
							echo '<td>' .$clinicalTrial['investigators']. '</td>';
							echo '<td>' .$clinicalTrial['collaborator']. '</td>';
							echo '<td>' .$clinicalTrial['purpose']. '</td>';
							echo '<td>' .$clinicalTrial['official_title']. '</td>';
							echo '<td>' .$clinicalTrial['keywords']. '</td>';
							echo '<td>' .$clinicalTrial['mesh_terms']. '</td>';
							echo '<td>' .$clinicalTrial['url']. '</td>';
						echo '</tr>';
					}
				}
			?>
		</table>
	</div>			