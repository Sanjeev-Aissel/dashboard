<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code{
    	width: 192px;
    }
    #org_typeLocation{
    	width: 207px;
    }
</style>
<script type="text/javascript">
var secStateId = '';
var secCityId = '';
var kolId = <?php if (isset($locationData)) echo $locationData['kol_id']; else echo $kolId; ?>;

    var staff_count = <?php
if (isset($locationData)) {
    echo count($staffData);
} else {
    echo 0;
}
?>;
    var phone_count = <?php
if (isset($locationData)) {
    echo count($phoneData);
} else {
    echo 0;
}
?>;
 $(document).ready(function () {
     var privatePractice="<?php echo $locationData['private_practice']; ?>";
        if (privatePractice!="") {
            // $("#organizationLocation").removeClass("autocompleteInputBox"); //checked
        }
        else {
          $("#organizationLocation").addClass("autocompleteInputBox"); //not checked
        }
    });
      
    var validationRules = {
        address1: {
            required: true
        },
        country_id: {
            required: true
        },
        /*city_id: {
            required: true
        },*/
        address_type: {
            required: true
        },
        organization: {
            required: true
        }
    };
    var validationMessages = {
        address1: {
            required: "Required"
        },
        country_id: {
            required: "Required"
        },
        /*city_id: {
            required: "Required"
        },*/
        address_type: {
            required: "Required"
        },
        organization: {
            required: "Required"
        }
    };
    $('#saveKolLocation').click(function () {
        if (!$("#saveKolLocationForm").validate().form()) {
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_location',
            type: 'post',
            dataType: 'json',
            data: $('#saveKolLocationForm').serialize(),
            beforeSend: function(){
    			$("#saveKolLocation").attr("disabled", "disabled");
            },
            success: function (returnData) {
                if (returnData.status == true) {
                	if(returnData.duplicate_location == true){
                    	$('.msgBox').html('Location is already present');
                        $('#saveKolLocationForm').find("input,textarea,select,input[type=checkbox]").val('');
                        $('#saveKolLocationForm').find("input[type=checkbox]").prop("checked", "");
                        $('#saveKolLocationForm #org_typeLocation').prop('disabled', '');
                        $("#addLocationForKolsContent #org_typeLocation").css('background-color','#fff');
                        $("#kol_id").val(kolId);
                        $('.msgBox').fadeOut(2000);
                        $('#saveKolLocation').val('Save');
                    }else{
	                    $('.msgBox').html('<?php echo lang("KOL"); ?> location saved successfully');
	                    $('.msgBox').fadeOut(1500);
	                    if(returnData.details !=''){
	                       
	                    	$('#organization').attr('value', returnData.details.org_name);
	                    	$('#org_institution_id').attr('value', returnData.details.org_id);
	                    	$('#address1').attr('value', returnData.details.address1);
	                    	$('#address2').attr('value', returnData.details.address2);
	                    	$('#department_loc').attr('value', returnData.details.division);
	                    	$('#address_label').text(returnData.details.address_type);
	                    	$('#address_type').attr('value', returnData.details.address_type);
	                    	$('#postal_code').attr('value', returnData.details.postal_code);
	                    	
							$('.primaryOrgType').attr('selected', '-1');
	                    	$('.primaryOrgType option[value="'+returnData.details.org_type+'"]').attr("selected","selected");
	                    	$('.primaryCountry').html($('.additionalCountry').html());
	                    	$('#title').attr('selected', '-1');
	                    	$('#title option[value="'+returnData.details.title+'"]').attr("selected","selected");


							$('.primaryCountry').val(returnData.details.country_id);
	                    	//State Select
	                    	$(".primaryState").html("<option value=''>-- Select State --</option>");
	                    	var params = "country_id=" + returnData.details.country_id;
	                        var selectedStateId = returnData.details.state_id;
	                        $.ajax({
	                            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
	                            dataType: "json",
	                            data: params,
	                            type: "POST",
	                            success: function (responseText) {
	                            	var selectedIndex	= '';
	                                $.each(responseText, function (key, value) {
	                                	selectedIndex	= '';
	                					if(selectedStateId>0 && selectedStateId===value.state_id){
	                						selectedIndex	= ' selected="selected"';
	                					} 
	                					 $('.primaryState').append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
	                                });
	                            },
	                            complete: function () {
	                                $("#loadingCities").hide();
	                            }
	                        });
	                        //City Select
                                var cities = document.getElementById('city_id');
                                var params = "state_id=" + returnData.details.state_id;
								 $.ajax({
		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
		                            dataType: "json",
		                            data: params,
		                            type: "POST",
		                            success: function (responseText) {
		                                $.each(responseText, function (key, value) {

		                                    var newCity = document.createElement('option');
		                                    newCity.text = value.city_name;
		                                    newCity.value = value.city_id;
		                                    var prev = cities.options[cities.selectedIndex];
		                                    cities.add(newCity, prev);
		                                });

		                                $("#city_id").val(returnData.details.city_id);
		                            },
		                            complete: function () {
		                                $("#loadingCities").hide();
		                            }
		                        });
	                    }
	                    closeDialog();
                    }  
                } else {
                    $('.msgBox').html('Error saving <?php echo lang("KOL"); ?> location');
                    $('.msgBox').fadeOut(1500);
                }
            },
    		complete:function(){
    			$('#saveKolLocation').removeAttr("disabled");
    		}
        });
    });
    function closeDialog() {
        $("#addLocationForKols").dialog("close");
        getLocationDataOnPageLoad();
       // window.location = "<?php echo base_url() ?>kols/view/" + $("#kol_id").val() + "/details";
    }

    /**
     * Returns the list of States of the Selected Country ID
     */
    function getStatesByCountryIdLocation() {
    	$("#saveKolLocationForm #postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#saveKolLocationForm #loadingStates").show();
        var countryId = $('#saveKolLocationForm #country_id').val();
        var params = "country_id=" + countryId;
        var selectedStateId = secStateId;
        $("#saveKolLocationForm #state_id").html("<option value=''>-- Select State --</option>");
        $("#saveKolLocationForm #city_id").html("<option value=''>-- Select City --</option>");
        var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
            	var selectedIndex	= '';
                $.each(responseText, function (key, value) {
                    /* var newState = document.createElement('option');
                    newState.text = value.state_name;
                    newState.value = value.state_id;
                    var prev = states.options[states.selectedIndex];
                    states.add(newState, prev); */
                	selectedIndex	= '';
					if(selectedStateId>0 && selectedStateId===value.state_id){
						selectedIndex	= ' selected="selected"';
					} 
					 $('#saveKolLocationForm #state_id').append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
                });
                
                /* $("#saveKolLocationForm #state_id option[value='']").remove();
                $("#saveKolLocationForm #state_id").prepend("<option value=''>-- Select State --</option>");
                $("#saveKolLocationForm #state_id").val(""); */
                if(secCityId > 0){
                	getCitiesByStateIdLocation();
                }
            },
            complete: function () {
                $("#saveKolLocationForm #loadingStates").hide();
            }
        });
    }

    /**
     * Returns the list of Cities of the Selected State
     */
    function getCitiesByStateIdLocation() {

    	$("#addLocationForKolsContent #postal_code").parent().find("label.error").remove();
        // Show the Loading Image
        $("#addLocationForKolsContent #loadingCities").show();        
        $("#addLocationForKolsContent #city_id").html("<option value=''>-- Select City</option>");
        var cities = document.getElementById("saveKolLocationForm").elements.namedItem("city_id");
        stateId = $("#addLocationForKolsContent #state_id").val();        
        var params = "state_id=" + stateId;

        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
//                 alert(responseText)
            	if(responseText==''){
                    $('#saveKolLocationForm #cityDiv').html('');
                    $('#saveKolLocationForm #cityDiv').html('<input type="text" name="city_id" id="city_id" class="required" placeholder="Enter City" />');
                }else{
                    $('#saveKolLocationForm #cityDiv').html('');
                	$('#saveKolLocationForm #cityDiv').html('<select name="city_id" id="city_id" class="required additionalCity" ><option value="">-- Select City --</option></select>');
                	setTimeout(function(){ 	
                		var selectedIndex	= '';
	                $.each(responseText, function (key, value) {
	
// 	                    var newCity = document.createElement('option');
// 	                    newCity.text = value.city_name;
// 	                    newCity.value = value.city_id;
// 	                    var prev = cities.options[cities.selectedIndex];
// 	                    cities.add(newCity, prev);
	                    selectedIndex	= '';
     					if(secCityId>0 && secCityId===value.city_id){
     						selectedIndex	= ' selected="selected"';
     					} 
     					 $('#saveKolLocationForm #city_id').append('<option value="'+value.city_id+'"'+selectedIndex+'>'+value.city_name+'</option>');
	                });
// 	                $("#saveKolLocationForm #city_id option[value='']").remove();
// 	                    $("#saveKolLocationForm #city_id").prepend("<option value=''>-- Select City --</option>");
// 	                    $("#saveKolLocationForm #city_id").val("");
                	}, 30);
                }
            },
            complete: function () {
                $("#addLocationForKolsContent #loadingCities").hide();
            }
        });
    }

    function addLocStaff() {
        $("#addLocationForKolsContent #delete_staff_" + staff_count).show();
        $("#addLocationForKolsContent #add_staff").remove();

        staff_count++;

        var html = "<tr id='staff_" + staff_count + "'>";
        html += $("#addLocationForKolsContent #new_staff tr").html();
        html += '<td><img id="add_staff" title="Add Staff" alt="Add Staff" src="<?php echo base_url(); ?>/images/add_active.png" onclick="addLocStaff();">';
        html += '<img class="cancelIcon" id="delete_staff_' + staff_count + '" title="Delete Staff" alt="Delete Staff" src="<?php echo base_url(); ?>/images/delete_active.png" onclick="deleteLocStaff(' + staff_count + ');" style="display:none"></td>';
        html += "</tr>";

        $("#addLocationForKolsContent #staff_table").append(html);
    }

    function deleteLocStaff(id) {
        $("#addLocationForKolsContent #staff_" + id).remove();
    }


    function addLocPhone() {
        $("#addLocationForKolsContent #delete_phone_" + phone_count).show();
        $("#addLocationForKolsContent #add_phone").remove();

        phone_count++;

        var html = "<tr id='phone_" + phone_count + "'>";
        html += $("#addLocationForKolsContent #new_phone tr").html();
        html += '<td><img id="add_phone" title="Add Phone" alt="Add Phone" src="<?php echo base_url(); ?>/images/add_active.png" onclick="addLocPhone();">';
        html += '<img class="cancelIcon" id="delete_phone_' + phone_count + '" title="Delete Phone" alt="Delete Phone" src="<?php echo base_url(); ?>/images/delete_active.png" onclick="deleteLocPhone(' + phone_count + ');" style="display:none"></td>';
        html += "</tr>";

        $("#addLocationForKolsContent #phone_table").append(html);
    }

    function deleteLocPhone(id) {
        $("#addLocationForKolsContent #phone_" + id).remove();
    }


    $(function () {
        $("#addLocationForKolsContent #saveKolLocationForm").validate({
            debug: true,
            onkeyup: false,
            rules: validationRules,
            messages: validationMessages,
        });
    });

    $(document).ready(function () {
        // Autocomplet Options for the 'Organizer' field 
        var organizationNameAutoCompleteOptions = {
            serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names/1',
    <?php echo $autoSearchOptions; ?>,
                    onSelect: function (event, ui) {                    	
                        var selText = $(event).children('.organizations').html();
                        var selId = $(event).children('.organizations').attr('name');
                        selText = selText.replace(/\&amp;/g, '&');
                        $('#addLocationForKolsContent #organizationLocation').val(selText);
//                        $('#addLocationForKolsContent #org_institution_id').val(selId);
                        $('#addLocationForKolsContent #org_institution_id').val(selId).trigger('change');

                        if (event.length > 20) {
                            if (event.substring(0, 21) == "No results found for ") {
                                $('#addLocationForKolsContent #organizationLocation').val(trim(split(' ', selText)[4]));
                                return false;
                            } else {
                                //doSearchFilter1( - 1);
                            }
                        } else {
                            //doSearchFilter1( - 1);
                        }                       
                    },
                    onValueChange: function (event, ui) {
                        alert();     
                    }
        };
         $('#private_practice').change(function() {
	        if ($(this).prop('checked')) {
	             $("#organizationLocation").removeClass("autocompleteInputBox"); //checked
	        }
	        else {
	          $("#organizationLocation").addClass("autocompleteInputBox"); //not checked
	        }
	    });
         var changeAutoComplete = 0;
         var attr = $("#addLocationForKolsContent #org_typeLocation").attr('disabled');
       	if (typeof attr !== typeof undefined && attr !== false) {
       		changeAutoComplete = 1;
       	}
        $('#addLocationForKolsContent #org_institution_id').change(function () {
            OrgId = $(this).val();
            $.ajax({
                url: '<?php echo base_url() ?>organizations/getOrgDetails/' + OrgId,
                type: 'POST',
                dataType: 'JSON',
                success: function (returnData) {
                    for (var result in returnData) {
                        $("#addLocationForKolsContent #country_id").val(returnData[result].country_id);
                       secStateId = returnData[result].state_id;
                       secCityId = returnData[result].city_id;
                       $("#addLocationForKolsContent #state_id").val(returnData[result].state_id);
                       getStatesByCountryIdLocation();
                        $("#addLocationForKolsContent #address1").val(returnData[result].address);
                        $("#addLocationForKolsContent #address2").val('');
                        $("#addLocationForKolsContent #postal_code").val(returnData[result].postal_code);
                        if(returnData[result].type_id > 0){
                      	$("#addLocationForKolsContent #org_typeLocation option:selected").removeAttr("selected");
                      	$("#addLocationForKolsContent #org_typeLocation").prop('selectedIndex',returnData[result].type_id);	
      					$("#addLocationForKolsContent #org_typeLocation").prop('disabled', 'disabled');
      					$("#addLocationForKolsContent #org_typeLocation").css('background-color','#ccc');
      					$('#addLocationForKolsContent #org_typeLocation [value="'+returnData[result].type_id+'"]').attr("selected","selected");
      					changeAutoComplete = 1;
                        }else{
                      	$("#addLocationForKolsContent #org_typeLocation option:selected").removeAttr("selected");
                      	$('#addLocationForKolsContent #org_typeLocation [value=""]').attr("selected","selected");
    						$("#addLocationForKolsContent #org_typeLocation").prop('disabled', '');
    						$("#addLocationForKolsContent #org_typeLocation").css('background-color','#fff');
                        }
                    }
                }
            });
            //fire your ajax call  
        })   // Trigger the Autocompleter for 'organizer' field of  Event'

        $("#organizationLocation").keypress(function(){
		    if(changeAutoComplete == 1){
		    	$("#org_typeLocation").prop('disabled', '');
				$("#org_typeLocation").css('background-color','#fff');
				$("#org_institution_id").val('');
			}
		});
		
        a = $('#addLocationForKolsContent #organizationLocation').autocomplete(organizationNameAutoCompleteOptions);

      //------------------- Start of Postal code focusout ----------
        $("#addLocationForKolsContent #postal_code").on("focusout",function(){
        	$("#addLocationForKolsContent #postal_code").parent().find("label.error").remove();
            var postalEle = $(this);
			var postalCode = $(this).val();
			if(postalCode != ''){
				$("#addLocationForKolsContent #loadingStates").show();
				$.ajax({
		            url: '<?php echo base_url() ?>country_helpers/get_zip_code_details/'+postalCode,
		            type: 'post',
		            dataType: 'json',
		            success: function (returnData) {
		            	$(postalEle).parent().find("label.error").remove();
		              if(returnData.status == 1){
						$("#addLocationForKolsContent #country_id").val(returnData.details.country_id);

						$("#addLocationForKolsContent #loadingStates").show();
				        var countryId = $('#addLocationForKolsContent #country_id').val();
				        var params = "country_id=" + countryId;
				        $("#addLocationForKolsContent #state_id").html("<option value=''>-- Select State --</option>");
				        $("#addLocationForKolsContent #city_id").html("<option value=''>-- Select City --</option>");
				        var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
				        $.ajax({
				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
				            dataType: "json",
				            data: params,
				            type: "POST",
				            success: function (responseText) {
				                $.each(responseText, function (key, value) {
				                    var newState = document.createElement('option');
				                    newState.text = value.state_name;
				                    newState.value = value.state_id;
				                    var prev = states.options[states.selectedIndex];
				                    states.add(newState, prev);
				                });
				                $("#addLocationForKolsContent #state_id option[value='']").remove();
				                $("#addLocationForKolsContent #state_id").prepend("<option value=''>-- Select State --</option>");
				                $("#addLocationForKolsContent #state_id").val("");
				            },
				            complete: function () {
				                $("#addLocationForKolsContent #loadingStates").hide();
				                $("#addLocationForKolsContent #state_id").val(returnData.details.region_id);
								//$("#city_id").val(returnData.details.city_id);
								var stateId = $('#addLocationForKolsContent #state_id').val();
		                        $("#addLocationForKolsContent #city_id").html("<option value=''>-- Select City</option>");
		                        var cities = document.getElementById("saveKolLocationForm").elements.namedItem("city_id");
		                        var params = "state_id=" + stateId;
		                        $("#addLocationForKolsContent #loadingCities").show();
								 $.ajax({
		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
		                            dataType: "json",
		                            data: params,
		                            type: "POST",
		                            success: function (responseText) {
		                                $.each(responseText, function (key, value) {

		                                    var newCity = document.createElement('option');
		                                    newCity.text = value.city_name;
		                                    newCity.value = value.city_id;
		                                    var prev = cities.options[cities.selectedIndex];
		                                    cities.add(newCity, prev);
		                                });

		                                $("#addLocationForKolsContent #city_id").val(returnData.details.city_id);
		                            },
		                            complete: function () {
		                                $("#addLocationForKolsContent #loadingCities").hide();
		                            }
		                        });				                
				            }
				        });
						
	                        if(returnData.details.city_id == '')
						 		$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror" style="color:green !important">Unable to populate City, State for given Postal Code.</label>');
			          }else{
							$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror" style="color:green !important">Unable to populate City, State for given Postal Code.</label>');
				      }
		            },
		            complete: function () {
                        $("#addLocationForKolsContent #loadingStates").hide();
                    }
		        });
			}
        });
		// ------------------- End of Postal code focusout ----------
		
    });

    function changeAutoComplete(){
    	var orgType = $('#org_typeLocation').find(":selected").text();
    	if(orgType == 'Private Practice'){
        	$('#private_practice').val('1');
			//$('#organization').removeClass('autocompleteInputBox');
        }else{
        	$('#private_practice').val('0');
        	//$('#organization').addClass('autocompleteInputBox');
        }
    }
</script>


<div class="msgBox"></div>

<div id="similarNames">

</div>

<h4 style="border-bottom: 1px solid #bbbbbb;">Location </h4>

<form action="save_kol_location" method="post" id="saveKolLocationForm" name="saveKolLocationForm">
    <?php //pr($locationData); ?>
    <?php
    if (isset($locationData)) {
        ?>
        <input type="hidden" name="id" value="<?php echo $locationData['id']; ?>"/>
        <input type="hidden" name="kol_id" id="kol_id" value="<?php echo $locationData['kol_id']; ?>"/>
        <input type="hidden" name="org_inst_selected" id="org_inst_selected" value="<?php echo $locationData['org_institution_id'];?>"/>
        <?php
    } else {
        ?>
        <input type="hidden" name="kol_id"  id="kol_id" value="<?php echo $kolId; ?>"/>
        <?php
    }
    ?>
    <table class="requestedKols">
        <tbody>
            <tr>
                <td style="width: 50%;">
                    <table style="te">
                        <tr>
                            <td class="alignRight">
                                <label for="isPrimary">Primary Address:</label>
                            </td>
                            <td>
                                <input type="checkbox" name="is_primary" value="1" 
                                <?php
                                if (isset($locationData)) {
                                    if ($locationData['is_primary'] == "1")
                                        echo "checked class='ui-disabled'";
                                }
                                ?>
                                       />
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight"><label for="org_institution_id">Institution<span class="required">*</span>:</label></td>
                            <td>
                                <input type="text" name="organization" class="autocompleteInputBox" id="organizationLocation" placeholder="Enter Organization" title="" 
                                <?php
                                if (isset($locationData) && $locationData['org_institution_name'] != "0") {
                                    echo 'value="' . $locationData['org_institution_name'] . '"';
                                }
                                else{
                                      echo 'value="' . $locationData['private_practice'] . '"';
                                }
                                ?>/>
                                <input type="hidden" name="org_institution_id" id="org_institution_id" 
                                <?php
                                if (isset($locationData)) {
                                    echo 'value="' . $locationData['org_institution_id'] . '"';
                                } else {
                                    echo 'value=""';
                                }
                                ?>/>
                            </td>
                        </tr>
                         <tr>
                              	<td class="alignRight"><label for = "title">Institution Type :</label></td>
		                        <td>
		                        	<input type="hidden" name="private_practice" id="private_practice" value="1"/>                      	
		                            <select name = "org_type" id = 'org_typeLocation' class="additionalOrgType" onchange="changeAutoComplete();"
			                            <?php 
				                           if (!empty($orgTypeId)){
				                            		echo "disabled";
				                            		echo " style='background-color: #ccc;'";
				                            }		                            
			                            ?>
		                            >
		                                <option value = ""> --Select--</option>
		                                <?php
		                                	foreach ($arrOrganizationTypes as $key => $value) {
		                                ?>
		                                <option value="<?php echo $key; ?>"
		                                <?php 
		                                	if (!empty($orgTypeId) && $orgTypeId == $key){
			                                		echo "selected = 'selected'";
			                                }
		                                ?>
		                                ><?php echo $value; ?></option>
		                                <?php
		                                    }
		                                ?>
		                            </select>
		                        </td>
                        </tr>
                        
                        <tr>
                            <td class="alignRight"><label for="address1">Address Line 1<span class="required">*</span>:</label></td>
                            <td>
                                <input type="text" name="address1" id="address1" 
                                <?php
                                if (isset($locationData)) {
                                    echo "value='" . $locationData['address1'] . "'";
                                } else {
                                    echo "value=''";
                                }
                                ?>
                                       maxlength="50" class="required"></input>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="address2">Address Line 2 :</label>
                            </td>
                            <td>
                                <input type="text" name="address2" id="address2" 
                                <?php
                                if (isset($locationData)) {
                                    echo "value='" . $locationData['address2'] . "'";
                                } else {
                                    echo "value=''";
                                }
                                ?>
                                       maxlength="50"></input>
                            </td>
                        </tr>
                        <tr>
                       	 	<td class="alignRight">
                        		<label for="department">Department :</label>
                        	</td>
	                        <td>
		                        <input type="text" name="department_loc" id="department_loc" 
		                        <?php
		                        if (isset($locationData)) {
		                        	echo 'value="'.$locationData['division'].'"';
		                        }
		                        ?>></input>
	                        </td>
                        </tr>
                        <tr>
			                <td class="alignRight">
			               	 	<label for = "title">Position :</label>
			                </td>
			                <td>                        	
				                <select name = "title_loc" id = 'title_loc' class="additionalTitleLoc">
					                <option value = ""> --Select--</option>
					                <?php foreach ($arrTitles as $title) {?>
				                    	<option value="<?php echo $title['id']; ?>" 
				                    <?php
				                    if (isset($locationData)) {
				                    	if ($locationData['title'] == $title['id'])
				                    	echo 'selected';
				                    }?>><?php echo $title['title']; ?></option>
				                    <?php } ?>
			                    </select>
		                    </td>
	                    </tr>
                    </table>
                </td>

                <td>
                    <table>
                        <!-- <tr>
                            <td class="alignRight">
                                <label for="address_type">Address Type<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <select name="address_type" class="required">
                                    <option value="">--Select--</option>
                                    <option value="Billing" 
                                    <?php
                                    if ($locationData['address_type'] == "Billing")
                                        echo "selected";
                                    ?>
                                            >Billing</option>
                                    <option value="Headquarters" 
                                    <?php
                                    if ($locationData['address_type'] == "Headquarters")
                                        echo "selected";
                                    ?>
                                            >Headquarters</option>
                                    <option value="Mailing" 
                                    <?php
                                    if ($locationData['address_type'] == "Mailing")
                                        echo "selected";
                                    ?>
                                            >Mailing</option>
                                    <option value="Pharmacy Operations" 
                                    <?php
                                    if ($locationData['address_type'] == "Pharmacy Operations")
                                        echo "selected";
                                    ?>
                                            >Pharmacy Operations</option>
                                    <option value="Physical" 
                                    <?php
                                    if ($locationData['address_type'] == "Physical")
                                        echo "selected";
                                    ?>
                                            >Physical</option>
                                    <option value="Shipping" 
                                    <?php
                                    if ($locationData['address_type'] == "Shipping")
                                        echo "selected";
                                    ?>
                                            >Shipping</option>
                                </select>
                            </td>
                        </tr> -->
                        <tr>
                            <td class="alignRight">
                                <label for="postal_code">Postal Code :</label>
                            </td>
                            <td>
                                <input type="text" name="postal_code" id="postal_code" 
                                <?php
                                if (isset($locationData)) {
                                    if ($locationData['postal_code'] != "") {
                                        echo 'value="' . $locationData['postal_code'] . '"';
                                    }
                                }
                                ?>
                                       />
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="country_id">Country<span class="required">*</span> :</label>
                            </td>
                            <td>
                            	<select name="country_id" id="country_id" onchange="getStatesByCountryIdLocation();" class="additionalCountry required">
                                        <option value="">-- Select Country --</option>
                                        <?php 
                                        //$selectedCountryId	= $arrFirstCountry;
                                        if(isset($locationData) && $locationData['country_id']>0){
                                        	$selectedCountryId	= $locationData['country_id'];
                                        }
                                        foreach ($arrCountries as $country) { ?>
                                            <option value="<?php echo $country['country_id']; ?>"
                                            <?php
                                            if ($selectedCountryId == $country['country_id'])
                                                echo "selected";
                                            ?>
                                            >
                                            <?php echo $country['country_name']; ?>
                                            </option>
                                        <?php } ?>
                                </select>
                                <img id="loadingStates" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">									
                                <label for="stateId1">State / Province :</label>
                            </td>
                            <td>
                                <select name="state_id" id="state_id" onchange="getCitiesByStateIdLocation();" class="additionalState">		
                                    <option value="">-- Select State --</option>
                                    <?php foreach ($arrStates as $state) { ?>
                                        <option value="<?php echo $state['state_id']; ?>" 
                                        <?php
                                        if (isset($locationData)) {
                                            if ($state['state_id'] == $locationData['state_id']) {
                                                echo 'selected';
                                            }
                                        }
                                        ?>>
                                        <?php echo $state['state_name']; ?>
                                        </option>
<?php } ?>
                                </select>
                                <img id="loadingCities" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="city_id">City :</label>
                            </td>
                            <td id="cityDiv">
                                <select name="city_id" id="city_id" class="additionalCity" >
                                    <!--<option value="">Select city</option>-->

                                    <?php
                                    if (isset($locationData)) {
                                        foreach ($arrCities as $city) {
                                            echo '<option value="' . $city['city_id'] . '" ';
                                            if ($city['city_id'] == $locationData['city_id']) {
                                                echo 'selected';
                                            } else {
                                                if ($city['$city'] == 254) {
                                                    echo 'selected';
                                                }
                                            }
                                            echo '>' . $city['city_name'] . '</option>';
                                        }
                                    } else {
                                        ?>
                                        <?php foreach ($arrCities as $city) { ?>
                                            <option value="<?php echo $city['city_id']; ?>"
                                            <?php
                                            if (isset($locationData)) {
                                                if ($state['city_id'] == $locationData['city_id']) {
                                                    echo 'selected';
                                                }
                                            }
                                            ?>><?php echo $city['city_name']; ?>
                                            </option>
                                        <?php
                                        }
                                    }
                                    ?>   
                                </select>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- End of Personal and Professional Information -->


        </tbody>
    </table>
    <tr>
        <td colspan="2">
            <div class="formButtons">	
                <?php if (!isset($locationData)) { ?>
                    <input type="button" value="Save" name="submit" id="saveKolLocation"></input>
                    <?php
                }
                if (isset($locationData)) {
                    ?>
                    <input type="button" value="Save" name="submit" id="saveKolLocation"></input>
<?php } ?>
            </div>
        </td>
    </tr>
</tbody>
</table>

</form>

