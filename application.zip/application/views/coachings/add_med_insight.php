<?php
/**
 * Element page to display the add Medical Insight details
 * 
 * @package application.views.coaching	
 * @author Shruti Purushan
 * @created: 18-09-15
 */
$queued_js_scripts = array('jquery/jquery.validate1.9.min', 'chosen.jquery'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
$client_id = $this->session->userdata('client_id');
$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
if ($currentController == 'kols') {
    $kolID = $this->uri->segment(3);
}
if (!empty($kolID)) {
    $kolId = $kolID;
} else {
    $kolId = 0;
}
$subContentPageMethodName = $this->uri->segment(4);
//$KeyInsightTopics = array(
//    1 => 'Abilify-FAQs',
//    2 => "Asenapine",
//    3 => "Cariprazine",
//    4 => "COMED",
//    5 => "DSM-V",
//    6 => "Lurasidone",
//    7 => "MDD-General",
//    8 => "Other",
//    9 => "Payer-Landscape",
//    10 => "Pediatrics-General",
//);
//$str = $medicalInsightDetails[0]['topics'];
//
//
//
//$val = trim($str, " ");
//$val = str_replace(' ', '', $str);
//
//$agentValueSeperated = (explode(",", $val));
//
////                                             pr($agentValueSeperated);
//foreach ($KeyInsightTopics as $key => $values) {
//
//    if (in_array(($values), $agentValueSeperated)) {
////                                                    echo $values."<br>";
//        $insightTopic[] = $values;
//    }
//}
//exit();
?>
<style type="text/css">
    label.error {
        background: none repeat scroll 0 0 transparent;
        border: 0 none;
        color: red;
        font-weight: normal;
        box-shadow: 0 0 0px #d1d1d1 inset;
    }
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    #medContainer{
        padding-left: 15px;
        padding-right: 15px;
        padding-bottom: 15px;
    }
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
    }
    /*table {
    border: 1px solid #DDDDDD;
}*/
    .validation
    {
        color: red;
        margin-left: 74px;
        margin-top: -10px;

    }
    .chzn-container-single .chzn-default {
        color: #555 !important;
    }

    th.alignRight{
        width: 165px;
    }
    .error {
        /* background-image: url(../images/error_medium.gif); */
        background-position: 10px center;
        background-repeat: no-repeat;
        padding: initial !important;
        border:0em !important;
    }
    .error, .notice, .success {
        padding: .8em;
        background:transparent !important;
        margin-bottom: 0em !important;
        /*background :#ececec ;*/ 
        box-shadow: 0 0 4px #d1d1d1  inset;
        border: 1px solid #F2F2F2 ;
    }
    .err{
        box-shadow: transparent !important;;
        border:transparent !important; ;
    }
    .selectBoxInputWidth{
        width: 200px;
        padding: 2px;
        background: white !important;
        border: 1px solid #999999 !important;
        box-shadow: none;
    }
    table caption{
        background :#ececec ; 
        box-shadow: 0 0 4px #d1d1d1  inset;
        border: 0px solid #ececec ;
    }

    input[type="text"], input[type="password"], select {
        border: 1px solid #d3d3d3 ;
    }
    #medicalInsight{
        border: 1px solid #ddd !important;
        padding-bottom: 15px;
    }
    #headerContentCss{
        background :#fff !important ; 
        box-shadow: 0 0 4px #d1d1d1  inset;
        border: 1px solid #ececec ;
    }
    span.err{
        color:red;
        width:6px !important;
        height:6px !important;
    }
    .spherereqired{
        display:block;
    }
    #medicalInsight textarea{
        background: white !important;
        border: 1px solid #999999 !important;
        box-shadow: none;
    }
    #medicalContainer{
        margin-bottom: 0em !important;
    }
    td  {
        padding: 4px 10px 4px 5px !important;
    }
    .inputBoxInputWidth{
        width:190px;
    }
</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
    var specialtyid;
    var flag = 0;
    var keyflag = 0;
<?php if (isset($speciltyName)) { ?>
        specialtyids = <?php echo $speciltyName; ?>;
<?php } //else {   ?>
    //    specialtyids=specialtyid;

<?php //}   ?>
    $(document).ready(function () {
<?php if (($currentMethod == 'medical_insight') || ($subContentPageMethodName == 'medical_insight')) { ?>
            $("#congress_sources_data").css("display", "none");
<?php } else { ?>
     var summary_length = $('#summary').val().length;
     var text_remaining = 500 - summary_length;
     $('.editSummary').append(text_remaining);
     var other_length = $('#otherTextArea').val().length;
     var text_remaining_other = 500 - other_length;
     $('.editOtherText').append(text_remaining_other);
     
<?php } ?>
        $("#investigationalAgent").live("change", function () {
//          alert("the value has changed")
        });
        $('.chosenSelect').chosen({allow_single_deselect: true});
        $('.chosenMultipleSelect').chosen({
            no_results_text: "Topic not found",
            placeholder_text: "Click to Select Topic(s)",
            allow_single_deselect: true
        });
    });

    function goBack() {
        window.history.back();
    }

    function getProducts(specialty) {
        $("#loaderProducts").show();
<?php unset($speciltyName); ?>;
        var spl =<?php echo $speciltyName; ?>
        // alert("hi");
        //  alert(spl);
        specialtyid = $('option:selected', specialty).attr('id');
        // alert(specialtyid);
        specialtyids = specialtyid;
//        var id = $(specialty).attr('id');
//        var specialtyid=$( "#"+id+" option:selected" ).attr('id');
        $.ajax({
            url: '<?php echo base_url() ?>coachings/get_productname_basedon_theraputicArea/' + specialtyid,
            type: 'POST',
            dataType: 'JSON',
            success: function (returnData) {
                $('#product option').remove();
                $('#keyInsightName option').remove();
                $('#keyInsightName').append('<option value="">Select Key Insight Name</option>');
                $('#product').append('<option value="">Select Product</option>');
                for (var result in returnData) {
                    $('#product').append("<option  id='" + returnData[result].id + "' value='" + returnData[result].name + "' type='" + returnData[result].type + "'>" + returnData[result].name + "</option>");
                    $("#product").trigger("liszt:updated");
                }
                $("#loaderProducts").hide();
            }
        });


        return true;


    }

    function getOther(specialty) {
        var id = $(specialty).attr('id');
        var specialtyid = $("#" + id + " option:selected").attr('id');
        $('#other').empty();
        if (specialtyid == 2) {
            $('#other').append("<th class='alignRight'>Other:<span class='err'>*</span></th><td style='text-align: center;'><textarea rows='5' name='other' style='width:95%;'></textarea></td>");
        }
        return true;
    }

<?php if (($medicalInsightDetails[0]['product'] == "Sativex") || ($medicalInsightDetails[0]['product'] == "LUU AE58054") || ($medicalInsightDetails[0]['product'] == "AVP 786") || ($medicalInsightDetails[0]['product'] == "MIND1") || ($medicalInsightDetails[0]['product'] == "Other")) { ?>
        $(function () {
            if (keyflag != 1) {
              $('#key').html('');  
            $('#keyInsightName').removeClass('required');
            }
            keyflag = 1; 
        });
<?php } ?>
    function getKeyInsightTopics(productId) {
    
         var productType = $('option:selected', productId).attr('type'); 
         if(productType!="investigational_agent"){
             $('#other').empty();
        $("#loader").show();
        var productid = $('option:selected', productId).attr('id');
        if (keyflag == 1) {
           $('#key').append('*');
            $('#keyInsightName').addClass('required'); } keyflag = 0; 
//    var id = $(productId).attr('id');
//    var productid=$( "#"+id+" option:selected" ).attr('id');
        $.ajax({
            url: '<?php echo base_url() ?>coachings/get_keyinsightname_basedon_productname/' + productid + '/' + specialtyids,
            type: 'POST',
            dataType: 'JSON',
            success: function (returnData) {
                $('#keyInsightName option').remove();
                $('#keyInsightName').append('<option value="">Select key Insight Name</option>');
                for (var result in returnData) {
                    $('#keyInsightName').append("<option  id='" + returnData[result].id + "' value='" + returnData[result].name + "'>" + returnData[result].name + "</option>");
                    $("#keyInsightName").trigger("liszt:updated");
                }
                $("#loader").hide();
            }
        });


        return true;
        }
        else{
        var productid = $('option:selected', productId).attr('id');
         $('#other').empty();
        if (productid == 27) {
          var html= '<th class="alignRight">Other:<span class="err">*</span></th><td style="text-align: center;"><textarea onKeyDown="limitText(this,\'otherText\',500);" onKeyUp="limitText(this,\'otherText\',500);" rows="5" class="required" name="other"  style="width:95%;"></textarea>';
            html+=' <div style="float:left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have <span id="otherText">500</span> characters left. <font size="1">(Maximum characters: 500)</font></div><br></td>';
         $('#other').append(html);
        }
        keyflag = 1; 
            $('#keyInsightName option').remove();
            $('#key').html(''); 
            $('#keyInsightName').removeClass('required');
            return true;
        }

    }
<?php if (($medicalInsightDetails[0]['source_type'] == "KTL direct knowledge") || ($medicalInsightDetails[0]['source_type'] == "HCP secondary knowledge") || ($medicalInsightDetails[0]['source_type'] == "Payer direct knowledge") || ($medicalInsightDetails[0]['source_type'] == "Payer secondary knowledge")) { ?>
        $(function () {
            if (flag != 1) {
                $('#spere').append('*');
                $('#sphere_of_influence').addClass('required');
            }
            flag = 1;
        });
<?php } ?>


    function getSourceType(sphere_of_influence) {
        var sphere_of_influence = $('option:selected', sphere_of_influence).attr('id');

        if ((sphere_of_influence == 1) || (sphere_of_influence == 2) || (sphere_of_influence == 5) || (sphere_of_influence == 6))

        {
            if (flag != 1) {
                $('#spere').append('*');
                $('#sphere_of_influence').addClass('required');
            }
            flag = 1;

        }
        else {
            flag = 0;
            $('.spere').html('');
            $('#sphere_of_influence').removeClass('required');
        }
        if (sphere_of_influence == 7) {

            $("#congress_sources_data").css("display", "block");
            var html;
            $.ajax({
                url: '<?php echo base_url() ?>coachings/get_congress_sources/',
                type: 'POST',
                dataType: 'JSON',
                success: function (returnData) {
                    $("#congress_sources_data").empty();
                    html += "  <th class='alignRight'>Congress Source:</th>";
                    html += '<td style="width: 364px;"><select id="congress_sources" name="congress_sources" class="selectBoxInputWidth">';
                    html += '<option value="">Select Congress Source</option>';
                    for (var result in returnData) {
                        html += "<option  id='" + returnData[result].id + "' value='" + returnData[result].name + "'>" + returnData[result].name + "</option>";
                      
                    }
                    html += "<td>&nbsp;</td>";
                    html += "<th class='alignRight'>Congress Name:</th><td style='text-align: center;'><input type='text' name='congress_name' id='congress_name' class='inputBoxInputWidth'> </td>";
                    $('#congress_sources_data').append(html);
                }
            });

        }
        else {
            $("#congress_sources_data").css("display", "none");
            $("#congress_sources").find('option').removeAttr("selected");
            $("#congress_name").val('');
        }
    }
    function investigationalType() {
//        alert("investigationalType");
        $("#investigationalAgent_chzn").removeClass("search-choice-close");

    }
    
    
    
    function validate() {
        jQuery.extend(jQuery.validator.messages, {
            required: "Required."
        });
//            $.validator.setDefaults({ ignore: ":hidden:not(select)" });
        if ($("#medicalInsight").validate().form()) {
            return true;
        }
        else {
            return false;
        }
    }
//        $("#medicalInsight").validate({

    // Specify the validation rules
//            rules: {
//                product: "required",
//                relevance: "required",
//                source_type: "required",
//                specialty: "required",
//                topics: "required",
//                summary: "required",
//                other: "required",
//                actions_to_consider: "required"
//
//            },
//            // Specify the validation error messages
//            messages: {
//                product: "Required",
//                relevance: "Required",
//                source_type: "Required",
//                specialty: "Required",
//                topics: "Required",
//                summary: "Required",
//                other: "Required",
//                actions_to_consider: "Required"
//            },
//            submitHandler: function (form) {
//                form.submit();
//            }
//        });

//            $('#medicalInsight').submit();
//    var focusSet = false;
//        if (!$('#investigationalAgent').val()) {
//            if ($("#investigationalAgent").parent().next(".validation").length == 0) // only add if not added
//            {
//                $("#agent").parent().after("<tr><td id='validationClass' class='validation alignRight'>Required</td></tr>");
//            }
//            e.preventDefault(); // prevent form from POST to server
//            $('#investigationalAgent').focus();
//            
//            focusSet = true;
//        } else {
//            $("#validationClass").removeClass("validation");
//            $('#medicalInsight').submit();
//        }
//    }
</script>
<?php if (($currentMethod == 'medical_insight') || ($subContentPageMethodName == 'medical_insight')) { ?>
    <div id="medContainer">
        <div id="addFormWrapper">
            <h5 class="heading">New Medical Insight</h5>
        </div>
        <form id="medicalInsight" name ="medicalInsightForm" action="<?php echo base_url(); ?>coachings/save_medical_insight" method="post" >
            <table style="margin-top:0px;" id="medicalContainer">
                <caption style="font-weight: bold;">Medical Insight</caption>
                <tr>
                    <th class="alignRight">Therapeutic Area:<span class="err">*</span></th>
                    <td><select name="specialty" class="selectBoxInputWidth required" onchange="getProducts(this)">
                            <option value="">Select Therapeutic Area</option>
                            <?php foreach ($therapeuticArea as $key => $val) { ?>
                                <option id="<?php echo $key; ?>" value="<?php echo $val; ?>">
                                    <?php echo $val; ?>
                                </option><?php } ?>
                        </select>
                    </td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <th class="alignRight">Product and Investigational Agent Category:<span class="err">*</span></th>
                    <td><select name="product" class="selectBoxInputWidth required" id="product" onchange="getKeyInsightTopics(this)">
                            <option value="">Select</option>
                        </select>
                        <img id="loaderProducts" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                    </td>
                    <td>&nbsp;</td>
                    <th class="alignRight">Source Type:<span class="err">*</span></th>
                    <td><select name="source_type" class="selectBoxInputWidth required" onchange="getSourceType(this)">
                            <option value="">Select Source Type</option>
                            <?php foreach ($sourceType as $key => $val) { ?>
                                <option id="<?php echo $key; ?>" value="<?php echo $val; ?>">
                                    <?php echo $val; ?>
                                </option><?php } ?>
                        </select></td>
                </tr>
            </table>

            <table style="margin-top:0px;" id="congressTable">
                <tr id="congress_sources_data">
    <!--                    <th class="alignRight">Congress Source:</th>
                    <td style="width: 364px;"><select id="congress_sources" name="congress_sources" class="selectBoxInputWidth">
                            <option value="">Select Congress Source</option>
                    <?php foreach ($congressSources as $key => $val) { ?>
                                    <option id="<?php echo $key; ?>" value="<?php echo $val; ?>">
                        <?php echo $val; ?>
                                    </option><?php } ?>
                        </select></td>
                                <td>&nbsp;</td>
                        <th class="alignRight">Congress Name:</th>
                    <td style="text-align: center;">
                        <input type="text" name="congress_name" id="congress_name" class="selectBoxInputWidth">    
                    </td>-->
                </tr>
            </table>
            <?php if ($currentController == 'kols') { ?>
                <table style="margin-top:0px;">


                    <tr>
                        <th class="alignRight"><?php echo lang("HCP");?> Name:</th>
                        <td>
                            <?php
                            if (($arrKolDetail['salutation'] != '') || ($arrKolDetail["first_name"] != '') || ($arrKolDetail["middle_name"] != "") || ($arrKolDetail["last_name"] != ''))
                            //echo $arrKolDetail["salutation"] . " " . $arrKolDetail["first_name"] . " " . $arrKolDetail["middle_name"] . " " . $arrKolDetail["last_name"];
                                echo $this->common_helpers->get_name_format($arrKolDetail['first_name'], $arrKolDetail['middle_name'], $arrKolDetail['last_name']);
                            ?>
                        </td>

                    </tr>
                </table>
            <?php } ?>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;">Key Insight Topics</caption>
                <tr><th class="alignRight">Key Insight Topics:<span id="key" class="err">*</span></th>
                    <td><select name="topics" class="selectBoxInputWidth required" id="keyInsightName" >
                            <option value="">Select Key Insight Name</option>
                            <!--<option>Select Product</option>-->

                        </select>
                        <img id="loader" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/></td>
                </tr>
            </table>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;">Medical Insight Details</caption>
                <tr>    
                    <th class="alignRight">Medical Insight Summary:<span class="err">*</span></th>
                    <td style="text-align: center;">
                        <!--<textarea rows="5" name="summary" class="required" style="width:95%;"></textarea>-->
                         <textarea  onKeyDown="limitText(this,'notesCountDown',500);" onKeyUp="limitText(this,'notesCountDown',500);" rows="5" class="required" name="summary" style="width:95%;"></textarea>
                        <!--<textarea rows="2" cols="700" id="user-note" name="user_note"></textarea>-->
                        <div style="float:left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have <span id="notesCountDown">500</span> characters left. <font size="1">(Maximum characters: 500)</font></div>
                        <br>
                    </td>

                </tr>
                <tr id="other">
                </tr>
                <input type="hidden" name="kol_id" value='<?php echo $kolId; ?>'>
                <input type="hidden" name="profile_type" value='<?php echo $currentController; ?>'>
            </table>
             <table style="margin-top:5px;" class="textLabel">
            <hr/><center> <label  style="font-weight: bold; text-align: center;" >Adverse events MUST NOT be reported on this form. </label><br/></center> 
            <center> <label style="font-weight: bold; text-align: center;"> Adverse Events/Product Complaints MUST be reported to 1-800-438-9927.</label></center> 

        </table>
            <center>
                <input type="submit" value="<?php echo SUBMIT_BUTTON_LABEL ?>" onclick="validate();" />
                <input type="button" value="Cancel" onclick="goBack();" />
            </center>
        </form>
    </div>
<?php } ?>
<?php if (($currentMethod == 'edit_medical_insight') || ($subContentPageMethodName == 'edit_medical_insight')) { ?>

    <div id="medContainer">
        <div id="addFormWrapper">
            <h5 class="heading">Edit Medical Insight</h5>
        </div>
        <form id="medicalInsight" action="<?php echo base_url(); ?>coachings/update_medical_insight/<?php echo $medicalInsightDetails[0]['id'] ?>" method="post">
            <input type="hidden" name="id" id="id" value="<?php echo $medicalInsightDetails[0]['id'] ?>" />
            <table style="margin-top:0px;" id="medicalContainer">
                <caption style="font-weight: bold;">Medical Insight</caption>
                <tr>
                    <th class="alignRight">Therapeutic Area:<span class="err">*</span></th>
                    <td><select name="specialty" class="selectBoxInputWidth required" onchange="getProducts(this)">
                            <option value="">Select Therapeutic Area</option>
                            <?php
                            foreach ($therapeuticArea as $key => $value) {
                                $selected = '';
                                if ($value == $medicalInsightDetails[0]['specialty']) {
                                    echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                                } else {
                                    echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                                }
                            }
                            ?>

                        </select>

                    </td>
                    <td>&nbsp;</td>
                     <td>&nbsp;</td>
<!--                    <th class="alignRight" style="display:none;">Investigational Agent:</th>
                    <td style="display:none;"><select name="agent" class="selectBoxInputWidth" id="investigationalAgent" onchange="getOther(this)">
                            <option value="">Select Investigational Agent</option>-->
                            <?php
//                            foreach ($investigationalAgent as $key => $value) {
//                                $selected = '';
//                                if ($value == $medicalInsightDetails[0]['agent']) {
//                                    echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
//                                } else {
//                                    echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
//                                }
                         //   }
                            ?>
                        <!--</select></td>-->

                </tr>
                <tr>
                    <th class="alignRight">Product and Investigational Agent Category:<span class="err">*</span></th>
                    <td><select name="product" class="selectBoxInputWidth required" id="product" onchange="getKeyInsightTopics(this)" >
                            <!--<option><?php echo $medicalInsightDetails[0]['product'] ?></option>-->
                            <option value="">Select</option>
                            <?php 
                            foreach ($productName as $key => $value) {
                                $selected = '';
                                if ($value['name'] == $medicalInsightDetails[0]['product']) {
                                    echo '<option type="' . $value['type'] . '" id="' . $value['id'] . '" value="' . $value['name'] . '" selected="selected">' . $value['name'] . '</option>';
                                } else {
                                    echo '<option type="' . $value['type'] . '" id="' . $value['id'] . '" value="' . $value['name'] . '">' . $value['name'] . '</option>';
                                }
                            }
                            ?>

                        </select>
                        <img id="loaderProducts" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                    </td>
                    <td>&nbsp;</td>
                    <th class="alignRight">Source Type:<span class="err">*</span></th>
                    <td><select name="source_type" class="selectBoxInputWidth required" onchange="getSourceType(this)">
                            <option value="">Select Source Type</option>
                            <?php
                            foreach ($sourceType as $key => $value) {
                                $selected = '';
                                if ($value == $medicalInsightDetails[0]['source_type']) {
                                    echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                                } else {
                                    echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                                }
                            }
                            ?>  </select></td>
                </tr>
            </table>

            <table style="margin-top:0px;">
                <tr id="congress_sources_data">
                    <?php
                    // if(strcmp($medicalInsightDetails[0]['congress_sources'], "0")) {
                    if ((!empty($medicalInsightDetails[0]['congress_sources'])) || (!empty($medicalInsightDetails[0]['congress_name']))) {
                        ?>
                        <th class="alignRight">Congress Source:</th>
                        <td style="width: 350px !important;"><select id="congress_sources" name="congress_sources" class="selectBoxInputWidth">
                                <option value="">Select Congress Source</option>
                                <?php
                                foreach ($congressSources as $key => $value) {
                                    $selected = '';
                                    if ($value == $medicalInsightDetails[0]['congress_sources']) {
                                        echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                                    } else {
                                        echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                                    }
                                }
                                ?> 
                            </select></td>
                        <td>&nbsp;</td>
                        <th class="alignRight">Congress Name:</th>
                        <td >
                            <input type="text" name="congress_name" id="congress_name" class="inputBoxInputWidth" value="<?php echo $medicalInsightDetails[0]['congress_name']; ?> ">    
                        </td>
                    <?php } ?>
                </tr>

            </table>

            <table style="margin-top:0px;">
                <?php if ($currentController == 'kols') { ?>

                    <th class="alignRight"><?php echo lang("HCP");?> Name:</th>
                    <td><?php
                        if (($arrKolDetail['salutation'] != '') || ($arrKolDetail["first_name"] != '') || ($arrKolDetail["middle_name"] != "") || ($arrKolDetail["last_name"] != ''))
                            echo $this->common_helpers->get_name_format($arrKolDetail['first_name'], $arrKolDetail['middle_name'], $arrKolDetail['last_name']);
//                                echo $arrKolDetail["salutation"] . " " . $arrKolDetail["first_name"] . " " . $arrKolDetail["middle_name"] . " " . $arrKolDetail["last_name"];
                        ?>
                    </td>
                <?php } else if ($currentController == 'coachings') { ?>

                    <?php if (($arrKolDetail['salutation'] != '') || ($kolname["first_name"] != '') || ($kolname["middle_name"] != "") || ($kolname["last_name"] != '')) { ?>
                        <th class="alignRight"><?php echo lang("HCP");?> Name:</th>
                        <td><?php
                            echo $this->common_helpers->get_name_format($kolname['first_name'], $kolname['middle_name'], $kolname['last_name']);
//            echo $arrKolDetail["salutation"] . " " . $kolname["first_name"] . " " . $kolname["middle_name"] . " " . $kolname["last_name"];
                        }
                        ?>
                    </td>
                <?php } ?>
                </tr>
            </table>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;">Key Insight Topics</caption>
                <tr><th class="alignRight">Key Insight Topics:<span id="key" class="err">*</span></th>
                    <td><select name="topics" class="selectBoxInputWidth required" id="keyInsightName" >
                             <!--<option><?php echo $medicalInsightDetails[0]['topics'] ?></option>-->
                            <option value="">Select key Insight Name</option>
                            <?php
                            foreach ($KeyInsightName as $key => $value) {
                                $selected = '';
                                if ($value == $medicalInsightDetails[0]['topics']) {
                                    echo '<option  id="' . $key . '" value="' . $value . '" selected="selected">' . $value . '</option>';
                                } else {
                                    echo '<option id="' . $key . '" value="' . $value . '">' . $value . '</option>';
                                }
                            }
                            ?>

                        </select>
                        <img id="loader" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                    </td>
                </tr>
            </table>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;">Medical Insight Details</caption>
                <tr>    
                    <th class="alignRight">Medical Insight Summary:<span class="err">*</span></th>
                    <td style="text-align: center;">
                      
                        <textarea  onKeyDown="limitText(this,'notesCountDown',500);" onKeyUp="limitText(this,'notesCountDown',500);" rows="5" class="required" name="summary" id="summary" style="width:95%;"><?php echo $medicalInsightDetails[0]['summary'] ?></textarea>
                        <!--<textarea rows="2" cols="700" id="user-note" name="user_note"></textarea>-->
                        <div style="float:left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have <span id="notesCountDown" class="editSummary"></span> characters left. <font size="1">(Maximum characters: 500)</font></div>
                        <br>
                    </td>
                </tr>

                <tr id="other">
                    <?php
                    //if(strcmp($medicalInsightDetails[0]['other'], "0")) {
                    if (!empty($medicalInsightDetails[0]['other'])) {
                        ?>
                        <th class="alignRight">Other:<span class="err">*</span></th>
                        <td style="text-align: center;">
                            <textarea rows="5" onKeyDown="limitText(this,'otherText',500);" onKeyUp="limitText(this,'otherText',500);"  class="required other" name="other" id="otherTextArea" style="width:95%;"><?php echo $medicalInsightDetails[0]['other'] ?></textarea>
                            <div style="float:left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have <span id="otherText" class="editOtherText"></span> characters left. <font size="1">(Maximum characters: 500)</font></div>
                        <br>
                        </td>
                    <?php } ?>
                </tr>

                <input type="hidden" name="kol_id" value='<?php echo $medicalInsightDetails[0]['kol_id']; ?>'>
                <input type="hidden" name="profile_type" value='<?php echo $medicalInsightDetails[0]['profile_type']; ?>'>
                <input type="hidden" name="current_controller" value='<?php echo $currentController; ?>'>
            </table>
             <table style="margin-top:5px;" class="textLabel">
            <hr/><center> <label  style="font-weight: bold; text-align: center;" >Adverse events MUST NOT be reported on this form. </label><br/></center> 
            <center> <label style="font-weight: bold; text-align: center;"> Adverse Events/Product Complaints MUST be reported to 1-800-438-9927.</label></center> 

        </table>
            <center>
                <input type="submit" value="<?php echo SUBMIT_BUTTON_LABEL ?>" onclick="validate();" />
                <input type="button" value="Cancel" onclick="goBack();" />
            </center>
        </form>
    </div>
<?php } ?>
