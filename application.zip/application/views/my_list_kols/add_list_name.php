<?php
/**
 * File to open  modal box to add/edit new list name
 * @author: Vinayak
 * @since :2.0
 * @Created on: 11-4-11
 */

?>
		<?php 
			/** @Author Vinayak
			 ** @since  22 Aug 2012
			 **The following code is used to disable caching in IE
			 **/
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
<style type="text/css">

	.clientTbl label {
		color:DimGray;
		display:block;
		font-size:125%;
		padding-right:8px;
		text-align:left;
	}
		
	label {
		font-weight:bold;
	}
	
	.clientTbl input[type="text"], .clientTbl select {
			width:200px;
	}
 
</style>



<script type="text/javascript">
/**
* Validate the text for 'Alpha Numeric Only'
*/
function alphanumeric(catName)
{
	var numaric = catName;
	for(var j=0; j<numaric.length; j++)
	{
		var alphaa = numaric.charAt(j);
		 
		var hh = alphaa.charCodeAt(0);
		
		if((hh > 47 && hh<58) || (hh > 64 && hh<91) || (hh > 96 && hh<123))
		{
			
		}
		else{
			jAlert("Enter Only Alpha numeric value");
			return false;
		}
	}
	return true;

}
	var validationRules	=  {
			list_name: {
				required:true,
				alphaNumeric:true
			}
		};
	
		var validationMessages = {
				list_name: {
				required: "Required",
				remote: ""
			}
		};
	$(document).ready(function(){
		$("#saveListNameForm").validate({
			debug:true,
			//onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});
	
		$.validator.addMethod("alphaNumeric", function(value, element) {
	        return this.optional(element) || /^[a-z0-9\- ]+$/i.test(value);
	    }, "Letters, numbers and dashes are allowed..");
	});



</script>

<div class="listNameMsgBox"></div>
<form action="<?php echo base_url()."my_list_kols/";if($arrListName==null) echo "save_list_name"; else echo "update_list_name";?>" method="post" id="saveListNameForm" name="saveListNameForm" class="validateForm" onsubmit="return validateListName();">
	
		<input type="hidden" name="id" id="listNameId" value="<?php if($arrListName!=null) echo $arrListName['id'];?>"></input> 
		<table class="anaylystForm clientTbl manageList">
		
			<?php if($arrListName['id']!=''){?>
			<tr>
				<td>
					<p><label>Category:</label>
						<?php if($arrCategoryName[0]['category']==''){?>
						<select name="category_id" id="categoryId">
							<option value="<?php echo $arrListName['category_id']?>"><?php echo $arrListName['category']?></option>
							<?php foreach($arrCategories as $row){?>
								<option value="<?php echo $row['id']?>"><?php echo $row['category']?></option>
							<?php }?>
						</select>
						<?php }?>
				</p>
				</td>
			</tr>
			<?php }else{echo "<p style='padding-left: 4px;'><label>Category:</label> ".$arrCategoryName[0]['category'];}?>
			<tr>
				<td>
					<p>	
						<label for="categoryName">List Name:</label>
						<input type="text" name="list_name" id="listName" value="<?php if($arrListName!=null) echo $arrListName['list_name'];?>"  class="required"></input><br /><br />
					</p>
					<div id='msgBox'></div>
				</td>
			</tr>
			
			<tr>
				<td>
					<div class="formButtons"">
						<input type="submit" value="Save" onclick="saveListName()" name="saveList">
			         </div>
		         </td>
	         </tr>
         </table>
	</form>