<?php 

/**
 * this is html file to Show Message 'site in in under Mainenance' 
 * @package application.views.layouts
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 5-11-11
 * 
 */


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php if(isset($title) && $title!=null) { echo $title; } else { echo PRODUCT_VERSION; }?></title>
	
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<link type="image/x-icon" href="<?php echo base_url()?>images/favicon.gif" rel="shortcut icon"/>
	
	<link type="text/css" href="<?php echo base_url()?>css/client_layout.css"  rel="stylesheet" />


	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	
	
<style type="text/css">

	img{
		border:none;
	}
	pre{
		display:block;
		font:12px "Courier New", Courier, monospace;
		padding:10px;
		border:1px solid #bae2f0;
		background:#e3f4f9;	
		margin:.5em 0;
		width:674px;
		}	
			
    /* image replacement */
        .graphic, #prevBtn, #nextBtn{
            margin:0;
            padding:0;
            display:block;
            overflow:hidden;
            text-indent:-8000px;
            }
    /* // image replacement */
			

	#container{	
		margin:0 auto;
		position:relative;
		text-align:left;
		width:696px;
		background:#fff;		
		margin-bottom:2em;
		}	
	#header{
		height:144px;
		background:#5DC9E1;
		color:#fff;
		}				
	#content{
		position:relative;
		}			


</style>	

</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="loginTable" align="center">
  <tr>
    <td class="topHeaderRow">&nbsp;<h1><?php echo PRODUCT_VERSION;?></h1></td>
  </tr>
  <tr>
    <td class="loginRow">
		<div style="text-align:center;">
		
			<h1>Our site is Currently</h1>
			<h1 style="color:#ffffff;">Under Maintenance!</h1>
			<p>
			We will be back soon...<br />
			Thank you for your patience
			</p>
		</div>
		<div  title="Login"></div>	
	</td>
  </tr>
  <tr>
    <td id="footer" align="right" height="50px;"><img src="<?php echo base_url(); ?>images/footer-logo_ie6.jpg" class="logo_a" /> &nbsp;&nbsp;Copyright � 2012  Powered by Aissel Solutions &nbsp;&nbsp;</td>
  </tr>
</table>


</body>
</html>
