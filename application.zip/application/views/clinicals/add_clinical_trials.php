<?php
/**
 * File to 'add' Clinical Trials details manually
 *
 * @author: Ambarish
 * @created on: 07-04-11
 */

	$currentMethod		= $this->uri->segment(2);
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />
	<style type="text/css">
		
		#ctManualTbl{
		/*	width: 600px; */
		}
		.validateForm label.error {
			-moz-background-clip:border;
			-moz-background-inline-policy:continuous;
			-moz-background-origin:padding;
			background:transparent none repeat scroll 0 0;
			border:0 none;
			color:red;
			font-weight:normal;
			margin:0;
			padding:0;
		}
		input.error {
			-moz-background-clip:border;
			-moz-background-inline-policy:continuous;
			-moz-background-origin:padding;
			background:#FBE3E4 none repeat scroll 0 0;
			border:1px solid red;
		}
		.error {
			background-image:url(../images/error_medium.gif);
			background-position:10px center;
			background-repeat:no-repeat;
			padding:2px 30px;
		}
		label.labelHeading{
			width:100% !important;
		}
		legend{
			color:gray;
			padding:0 5px;
		}
		.analystForm label{
			width: 85%;
		}
		.analystForm td{
			padding: 0 5px 7px;
		}
		.analystForm fieldset table tr td input[type="text"], .analystForm fieldset table tr td select{
			width: 95% !important;
		}
		.analystForm input[type="text"], .analystForm select {
		    width: 148px;
		}
		input[type="text"].fullWidth, textarea.fullWidth{
			width: 95% !important;
		}
		#ctCollaborator{
			width: 87% !important;
		}
		.floatLeft{
			float: left;
		}
		.actionIcon a{
			display: block;
			text-decoration: none;
		}
		.vAlignTop{
			vertical-align: top !important;
		}
		.analystForm td {
		    padding: 0 5px 7px !important;
		}
		.analystForm td.extraPadding{
			padding-top:5px !important;
		}
		#CalendarControl{
		   z-index: 10000;
		}
		div.addIcon {
		    background-position: -262px -62px;
		    background: url("<?php echo base_url()?>images/plus_blue.svg") no-repeat scroll 24% 36% transparent !important;
		    margin-left: 4px;
		}
	 
	</style>
	
	<script type="text/javascript" language="javascript">
		/**
		* Save the new Event Lookup Name
		*/
		function saveClinicalTtialManual(){
			if(!$("#ctManualForm").validate().form()){
				return false;
			}
			id = $("#ctManualId").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>clinical_trials/save_clinical_trial_manual';
			}else{
				formAction = '<?php echo base_url();?>clinical_trials/update_clinical_trial_manual';
			}
			
			formData	= $("#ctManualForm").serialize();
			$.ajax({
				type:"post",
				dataType:"json",
				data: formData,
				url:formAction,
				beforeSend: function(){
					$("#saveCtManual").removeAttr("onclick", null);
		        },
				success:function(returnMsg){
					$('div.ctManualMsgBox').fadeIn("fast");
					$('div.ctManualMsgBox').text(returnMsg.msg);
					if(returnMsg.saved){
						$('div.ctManualMsgBox').removeClass('error');
						$('div.ctManualMsgBox').addClass('success');
	
						// Call the 'CloseDialog' method with delay
						setTimeout(closeDialog, 1500);
					}else{
						$('div.ctManualMsgBox').removeClass('success');
						$('div.ctManualMsgBox').addClass('error');
					}
	
					$('div.ctManualMsgBox').fadeOut(10000);
				},
				complete:function(){
					$('#saveCtManual').attr('onclick','savePayement()');
				}
			});
		}

		//Validates the 'ctManualForm'
		function saveClinicalTtialManualValidate(){
			if(!$("#ctManualForm").validate().form()){
				return false;
			}else
				return true;
				
		}
		/**
		* Closes the Dialog Box with some time delay
		*/
		function closeDialog(){			
			$("#clinicalTrailAddContainer").dialog("close");
		}
		
		//Validation
		var validationRules	=  {
				required:true
			};
		
		var validationMessages = {
			required: "Required"
		};

		//Additional fields to Delete
		function deleteSponsor(id){
			$('#ctSponsorDelete'+id).remove();		
		}
		function deleteIntervention(id){
			$('#ctInterventionDelete'+id).remove();
		}
		function deleteInvestigator(id){
			$('#ctInvestigatorsDelete'+id).remove();
			/*var noOfInvestigators = 0;
			noOfInvestigators=$("#noOfInvestigators").val();
			noOfInvestigators--;
			$("#noOfInvestigators").val(noOfInvestigators);*/
		}
		function deleteIntervention(id){
			$('#ctInterventionDelete'+id).remove();
			var noOfInterventions=0;
			noOfInterventions=$("#noOfInterventions").val();
			//noOfInterventions--;
			$("#noOfInterventions").val(noOfInterventions);
		}
		function deleteMeshterm(id){
			$('#ctMeshtermsDelete'+id).remove();
		}
		function deleteKeyword(id){
			$('#ctKeywordsDelete'+id).remove();
		}

		//Document block
		$(document).ready(function(){
			//Adds the another Author input field below the current input field
			$("#addMoreSponsors").click(function(){
				var noOfSponsors=0;
				noOfSponsors=$("#noOfSponsors").val();
				noOfSponsors++;
				var newSponsor="<div id=\"ctSponsorDelete"+noOfSponsors+"\"><input type=\"text\" name=\"sponsor"+noOfSponsors+"\" id=\"ctSponsor"+noOfSponsors+"\" /><a href=\"#\" onclick=\"deleteSponsor("+noOfSponsors+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\"  width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
				$("#addSponsorContainer").append(newSponsor);
				$("#noOfSponsors").val(noOfSponsors);
			});
			
			//Adds the another Intervention input field below the current input field
			$("#addMoreInterventions").click(function(){
				//jAlert('hi');
				var noOfInterventions=0;
				noOfInterventions=$("#noOfInterventions").val();
				noOfInterventions++;
				var newIntervention="<div id=\"ctInterventionDelete"+noOfInterventions+"\"><input type=\"text\" name=\"intervention"+noOfInterventions+"\" id=\"ctIntervention"+noOfInterventions+"\" /><a href=\"#\" onclick=\"deleteIntervention("+noOfInterventions+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\" width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
				$("#addInterventionContainer").append(newIntervention);
				$("#noOfInterventions").val(noOfInterventions);
			});

			//Adds the another Investigator input field below the current input field
			$("#addMoreInvestigators").click(function(){
				//jAlert('hi');
				var noOfInvestigators=0;
				noOfInvestigators=$("#noOfInvestigators").val();
				noOfInvestigators++;
				var newIntervention="<div id=\"ctInvestigatorsDelete"+noOfInvestigators+"\"><input type=\"text\" name=\"investigators"+noOfInvestigators+"\" id=\"ctInvestigators"+noOfInvestigators+"\" /><a href=\"#\" onclick=\"deleteInvestigator("+noOfInvestigators+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\" width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
				$("#addInvestigatorContainer").append(newIntervention);
				$("#noOfInvestigators").val(noOfInvestigators);
			});
			//Adds the another Investigator input field below the current input field
			$("#addMoreMeshterms").click(function(){
				//jAlert('hi');
				var noOfMeshterms=0;
				noOfMeshterms=$("#noOfMeshterms").val();
				noOfMeshterms++;
				var newMeshterm="<div id=\"ctMeshtermsDelete"+noOfMeshterms+"\"><input type=\"text\" name=\"meshterms"+noOfMeshterms+"\" id=\"ctMeshterms"+noOfMeshterms+"\" /><a href=\"#\" onclick=\"deleteMeshterm("+noOfMeshterms+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\" width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
				$("#addMeshtermContainer").append(newMeshterm);
				$("#noOfMeshterms").val(noOfMeshterms);
			});
			//Adds the another Investigator input field below the current input field
			$("#addMoreKeywords").click(function(){
				//jAlert('hi');
				var noOfKeywords=0;
				noOfKeywords=$("#noOfKeywords").val();
				noOfKeywords++;
				var newKeyword="<div id=\"ctKeywordsDelete"+noOfKeywords+"\"><input type=\"text\" name=\"keywords"+noOfKeywords+"\" id=\"ctKeywords"+noOfKeywords+"\" /><a href=\"#\" onclick=\"deleteKeyword("+noOfKeywords+");return false;\"><img src=\"<?php echo base_url();?>images/delete_active.png\" width=\"20\"  height=\"20\" alt=\"Delete\" title=\"Delete\"/></a></div>";
				$("#addKeywordContainer").append(newKeyword);
				$("#noOfKeywords").val(noOfKeywords);
			});
			$('.ui-dialog-titlebar-close').click(function(){
				hideCalendarControl();
			});
//			$("#ctManualForm").validate({
//				debug:true,
//				onkeyup:true,
//				rules: validationRules,
//				messages: validationMessages
//			});
//
//			$("#saveCtManual").click(function(){
//				if(!$("#ctManualForm").validate().form()){
//					return false;
//				}else
//					$('#ctManualForm').submit();
//			});
			$('#clinical_start_id').datepicker({
				dateFormat: 'mm/dd/yy'
			});

			$('#clinical_end_id').datepicker({
				dateFormat: 'mm/dd/yy'
			});
			
		});

		function compareStratEndDate(){			
			var startDate = Date.parse($('#clinical_start_id').val());
			var endDate = Date.parse($('#clinical_end_id').val());
			if(endDate!='' && startDate!=''){
    			if(endDate < startDate){
    				jAlert("End date should be greater or Equal than Start date");
					$('#clinical_end_id').val('');
					return false;
    			}
			}
		}
	</script>
	<?php 
		if($currentMethod == 'add_client_clinical_trial' || $currentMethod == 'edit_clinical_trial_manual'){?>
			<div class="formHeader"><h5>Clinical Trials</h5></div>
	<?php }?>
	
	<div id="addCTManual" onmousemove="compareStratEndDate();">
	<?php //$arrClinicalTrial = $arrClinicalTrial[0];?>
	<?php 
	$formAction = base_url().'clinical_trials/save_clinical_trial_manual';	
	if($arrClinicalTrial['id']!=''){
	   $formAction = base_url().'clinical_trials/update_clinical_trial_manual';
	}?>
		<form action="<?php echo $formAction;?>"  enctype="multipart/form-data" method="post" id="ctManualForm" name="ctManualForm" class="validateForm" onsubmit="return saveClinicalTtialManualValidate();">
			<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId;?>"></input>
			<input type="hidden" name="id"  value="<?php echo $arrClinicalTrial['id'];?>" id="ctManualId"></input>
			<div class="msgBoxContainer"><div class="ctManualMsgBox"></div></div>
			<?php
				 $currentMethod		= $this->uri->segment(2);
				 if($currentMethod == 'add_client_clinical_trial'){?>
					<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="ctMethodName"></input>
			<?php }else{?>
					<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="ctMethodName"></input>
			<?php }?>
			<table id="ctManualTbl" class="ctManualForm analystForm">
				<tr>
					<td><label for="ctTrialName"  class="labelHeading">Trial Name:<span class="required">*</span></label></td>
					<td colspan="5">
						<p>
							<input type="text" name="trial_name" value="<?php echo $arrClinicalTrial['trial_name'];?>" id="ctTrialName" class="required fullWidth"></input>
						</p>
					</td>
				</tr>
				<tr>
					<td><label for="ctTrialName" class="labelHeading">Official Title:</label></td>
					<td colspan="5">
						<p>
							<input class="fullWidth" type="text" name="official_title" value="<?php echo $arrClinicalTrial['official_title'];?>"></input>
						</p>
					</td>
				</tr>
				<tr>
					<td><label for="ctLink"  class="labelHeading">Trial URL:</label></td>
					<td colspan="5">
						<p>
							<input class="fullWidth" type="text" name="trial_link" value="<?php echo $arrClinicalTrial['link'];?>" id="ctTrialUrl"></input>
						</p>
					</td>
				</tr>
				<tr>
					<td><label>Role:</label></td>
					<td>
						<select name="kol_role">
							<option value="">--Select--</option> 
							<?php 
								foreach($arrKOLRoles as $key => $value){
									if($key == $arrClinicalTrial['kol_role'])
										echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
									else
										echo '<option value="'.$key.'">'.$value.'</option>';
								}
							?>
						</select>
					</td>
					<td><label for="ctCondition">Study Type:</label></td>
					<td>
						<p>
							<input type="text" name="study_type" value="<?php echo $arrClinicalTrial['study_type'];?>" id="ctStudyType"></input>
						</p>
					</td>
					<td><label for="ctPhase">Phase:</label></td>
					<td>
						<p><input type="text" name="phase" id="ctPhase" value="<?php echo $arrClinicalTrial['phase'];?>" />
							<!-- <select name="phase" id="ctPhase">
								<option value="">--Select--</option>
								<?php 
									foreach($arrPhaseIds as $key => $value){
									if($key == $arrClinicalTrial['phase'])
										echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
									else
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								?>
							</select> -->
						</p>
					</td>
				</tr>
				<tr>
					
					<td><label for="ctCondition">Condition:</label></td>
					<td colspan="2">
						<p>
							<input type="text" class="fullWidth" name="condition" value="<?php echo $arrClinicalTrial['condition'];?>" id="ctCondition"></input>
						</p>
					</td>
					<td><label for="ctCollaborator">Collaborator:</label></td>
					<td colspan="2">
						<input class="fullWidth" type="text" name="collaborator" value="<?php echo $arrClinicalTrial['collaborator'];?>" id="ctCollaborator"></input>
					</td>
				</tr>
				<tr>
					<td><label>Purpose:</label></td>
					<td colspan="5"><textarea name="purpose" class="fullWidth" rows="" cols=""><?php echo $arrClinicalTrial['purpose'];?></textarea></td>
				</tr>
				<tr>
					<td colspan="6">
						<fieldset style="margin-bottom: 0px;">
							<legend>Recruitment Information</legend>
							<table style="margin-bottom: 0px;">
								<tr>
									<td>Status</td>
									<td><select name="status_id" id="ctStatusId">
									  	<!--<option value="">--Select--</option> 
										-->
										<?php 
											foreach($arrStatusIds as $key => $value){
												if($key == $arrClinicalTrial['status_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
											}
										?>
									</select></td>
									<td>Start Date</td><td><input type="text" id="clinical_start_id" name="start_date" value="<?php echo $arrClinicalTrial['start_date'];?>"/></td>
									<td>End Date</td>
										<td><input type="text" id="clinical_end_id" name="end_date" value="<?php echo $arrClinicalTrial['end_date'];?>"/>
											<label class="error" id="dateError" style="display: none;">End date should be greater than start date</label>
										</td>
								</tr>
								<tr>
									<td>Minimum Age</td><td><input type="text" name="min_age" value="<?php echo $arrClinicalTrial['min_age'];?>" /></td>
									<td>Maximum Age</td><td><input type="text" name="max_age" value="<?php echo $arrClinicalTrial['max_age'];?>" /></td>
									<td>Gender</td><td>
										<input type="text" name="gender" id="ctGender" value="<?php echo $arrClinicalTrial['gender'];?>" />
										<!-- <select name="gender" id="ctGender">
										  	<option value="">--Select--</option> 
											<?php 
												foreach($arrGenders as $key => $value){
													if($key == $arrClinicalTrial['gender'])
														echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
													else
														echo '<option value="'.$key.'">'.$value.'</option>';
												}
											?>
										</select> -->
									</td>
								</tr>
								<tr>
									<td>No. of Enrollees</td><td><input type="text" name="no_of_enrollees" value="<?php echo $arrClinicalTrial['no_of_enrollees'];?>" /></td>
									<td>Number of Trial Sites </td><td><input type="text" name="no_of_trial_sites" value="<?php echo $arrClinicalTrial['no_of_trial_sites'];?>" /></td>
								</tr>
							</table>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="vAlignTop extraPadding"><label for="ctIntervention">Intervention:</label></td>
					<td class="vAlignTop extraPadding" colspan="2">
						<div>
							<input type="hidden" name="interventionId"  value="<?php echo $arrIntervention['id'];?>" id="ctInterventionId"></input>
							<input type="hidden" name="no_of_intervention" id="noOfInterventions" value="<?php echo $arrClinicalTrial['no_of_intervention'];?>"/>
							<input class="floatLeft" type="text" name="intervention" value="<?php echo $arrIntervention['intervention'];?>" id="ctIntervention"></input>
							<div class="actionIcon addIcon" id="addMoreInterventions"><a href="#" onclick="return false;">&nbsp;</a></div>
						</div>
						<div id="addInterventionContainer">
						<?php //pr($arrMultipleInterventions);?>
							<?php if(isset($arrMultipleInterventions) && sizeof($arrMultipleInterventions)>=1){?>
								<?php 
									$i=0;
									foreach($arrMultipleInterventions as $intervention){
										$i++;
										if($i == 1)
											continue;?>
										<div id="ctInterventionDelete<?php echo $i?>">	
    										<input type="hidden" name="interventionId<?php echo $i?>"  value="<?php echo $intervention['id'];?>" id="interventionId<?php echo $i?>"></input>
    										<input type="text"  name="intervention<?php echo $i?>" value="<?php echo $intervention['name'];?>" id="ctIntervention<?php echo $i?>"></input>
    										<a onclick="deleteIntervention(<?php echo $i?>);return false;" href="#"><img title="Delete" alt="Delete" src="<?php echo base_url();?>images/cross_blue.svg"></a>
										</div>
								<?php }?>
							<?php 	}?>
						</div>
					</td>
					<td class="vAlignTop extraPadding"><label for="ctSponsor">Sponsor:</label></td>
					<td class="vAlignTop extraPadding" colspan="2">
						<div>
							<input type="hidden" name="sponsorId"  value="<?php echo $arrSponsor['id'];?>" id="ctSponsorId"></input>
							<input type="hidden" name="no_of_sponsors" id="noOfSponsors" value="<?php echo $arrClinicalTrial['no_of_sponsors'];?>"/>
							<input class="floatLeft" type="text" name="sponsor" value="<?php echo $arrSponsor['sponsor'];?>" id="ctSponsor"></input>
							<div class="actionIcon addIcon" id="addMoreSponsors"><a href="#" onclick="return false;">&nbsp;</a></div>
						</div>
						<div id="addSponsorContainer">
							<?php if(isset($arrMultipleSponsors) && sizeof($arrMultipleSponsors)>=1){
								$i=0;
								foreach($arrMultipleSponsors as $sponsor){
									$i++;
									if($i == 1)
										continue;?>
								<div id="ctSponsorDelete<?php echo $i?>">				
									<input type="hidden" name="sponsorId<?php echo $i?>"  value="<?php echo $sponsor['id'];?>" id="sponsorId<?php echo $i?>"></input>
									<input type="text" name="sponsor<?php echo $i?>" value="<?php echo $sponsor['agency'];?>" id="ctSponsor<?php echo $i?>"></input>
									<a onclick="deleteSponsor(<?php echo $i?>);return false;" href="#"><img title="Delete" alt="Delete" src="<?php echo base_url();?>images/cross_blue.svg"></a>
								</div>	
							<?php }
							}?>
						</div>
						
					</td>
				</tr>
				<tr style="background-color: #eee;">
					<td class="vAlignTop extraPadding"><label>Keywords:</label></td>
					<td class="vAlignTop extraPadding" colspan="2">
						<div>
							<input type="hidden" name="keywordId"  value="<?php echo $arrKeyword['id'];?>" id="ctKeywordId"></input>
							<input type="hidden" name="no_of_keywords" id="noOfKeywords" value="<?php echo $arrClinicalTrial['no_of_keywords'];?>"/>
							<input class="floatLeft" type="text" name="keywords" value="<?php echo $arrKeyword['keywords'];?>" id="ctKeywords"></input>
							<div class="actionIcon addIcon" id="addMoreKeywords"><a href="#" onclick="return false;">&nbsp;</a></div>
						</div>
						<div id="addKeywordContainer">
							<?php if(isset($arrMultipleKeywords) && sizeof($arrMultipleKeywords)>=1){?>
								<?php 
									$i=0;
									foreach($arrMultipleKeywords as $key=>$keyword){
										$i++;
										if($i == 1)
											continue;?>
										<div id="ctKeywordsDelete<?php echo $i?>">	
    										<input type="hidden" name="keywordId<?php echo $i?>"  value="<?php echo $keyword['id'];?>" id="ctKeywordId<?php echo $i?>"></input>
    										<input type="text" name="keywords<?php echo $i?>" value="<?php echo $keyword['name'];?>" id="ctKeywords<?php echo $i?>"></input>
    										<a onclick="deleteKeyword(<?php echo $i?>);return false;" href="#"><img title="Delete" alt="Delete" src="<?php echo base_url();?>images/cross_blue.svg"></a>
										</div>
								<?php }?>
							<?php 	}?>
						</div>
					</td>
					<td class="vAlignTop extraPadding"><label>MeSH Terms:</label></td>
					<td class="vAlignTop extraPadding" colspan="2">
						<div>
							<input type="hidden" name="meshtermsId"  value="<?php echo $arrMeshterm['id'];?>" id="ctMeshtermsId"></input>
							<input type="hidden" name="no_of_meshterms" id="noOfMeshterms" value="<?php echo $arrClinicalTrial['no_of_meshterms'];?>"/>
							<input class="floatLeft" type="text" name="meshterms" value="<?php echo $arrMeshterm['meshterms'];?>" id="ctMeshterms"></input>
							<div class="actionIcon addIcon" id="addMoreMeshterms"><a href="#" onclick="return false;">&nbsp;</a></div>
						</div>
						<div id="addMeshtermContainer">
							<?php if(isset($arrMultipleMeshterms) && sizeof($arrMultipleMeshterms)>=1){?>
								<?php 
									$i=0;
									foreach($arrMultipleMeshterms as $meshterm){
										$i++;
										if($i == 1)
											continue;?>
										<div id="ctMeshtermsDelete<?php echo $i?>">		
    										<input type="hidden" name="meshtermId<?php echo $i?>"  value="<?php echo $meshterm['id'];?>" id="ctMeshtermId<?php echo $i?>"></input>
    										<input type="text" name="meshterms<?php echo $i?>" value="<?php echo $meshterm['term_name'];?>" id="ctMeshterms<?php echo $i?>"></input>
    										<a onclick="deleteMeshterm(<?php echo $i?>);return false;" href="#"><img title="Delete" alt="Delete" src="<?php echo base_url();?>images/cross_blue.svg"></a>
										</div>
								<?php }?>
							<?php 	}?>
						</div>
					</td>
				</tr>
				<tr>
					<td class="vAlignTop extraPadding"><label for="ctInvestigators">Investigators:</label></td>
					<td class="vAlignTop extraPadding" colspan="2">
						<div>
							<input type="hidden" name="investigatorId"  value="<?php echo $arrInvestigator['id'];?>" id="ctInvestigatorId"></input>
							<input type="hidden" name="no_of_investigators" id="noOfInvestigators" value="<?php echo $arrClinicalTrial['no_of_investigators'];?>"/>
							<input class="floatLeft" type="text" name="investigators" value="<?php echo $arrInvestigator['investigators'];?>" id="ctInvestigators"></input>
							<div class="actionIcon addIcon"><a href="#" id="addMoreInvestigators" onclick="return false;">&nbsp;</a></div>
						</div>
						<div id="addInvestigatorContainer">
							<?php if(isset($arrMultipleInvestigators) && sizeof($arrMultipleInvestigators)>=1){?>
								<?php 
									$i=0;
									foreach($arrMultipleInvestigators as $investigator){
										$i++;
										if($i == 1)
											continue;?>
									<div id="ctInvestigatorsDelete<?php echo $i?>">
										<input type="hidden" name="investigatorId<?php echo $i?>"  value="<?php echo $investigator['id'];?>" id="ctInvestigatorId<?php echo $i?>"></input>
										<input type="text" name="investigators<?php echo $i?>" value="<?php echo $investigator['last_name'];?>" id="ctInvestigators<?php echo $i?>"></input>
										<a onclick="deleteInvestigator(<?php echo $i?>);return false;" href="#"><img title="Delete" alt="Delete" src="<?php echo base_url();?>images/cross_blue.svg"></a>
									</div>						
								<?php }?>
							<?php 	}?>
						</div>
					</td>
					<td colspan="3"></td>
				</tr>
			<!--<tr>
				<td>
					<p>
						<label for="ctTrialName">Trial Name:<span class="required">*</span></label>
						<input type="text" name="trial_name" value="<?php echo $arrClinicalTrial['trial_name'];?>" id="ctTrialName" class="required"></input>
					</p>
				</td>
				<td>
					<p>
						<label for="ctStatusId">Status:</label>
						<select name="status_id" id="ctStatusId">
						  	<option value="">--Select--</option> 
							<?php 
								foreach($arrStatusIds as $key => $value){
								if($key == $arrClinicalTrial['status_id'])
									echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
								else
									echo '<option value="'.$key.'">'.$value.'</option>';
								}
							?>
						</select>
					</p>
	    		</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="ctCondition">Condition:</label>
						<input type="text" name="condition" value="<?php echo $arrClinicalTrial['condition'];?>" id="ctCondition"></input>
					</p>
				</td>
				<td>
					<p>
						<label for="ctPhase">Phase:</label>
						<select name="phase" id="ctPhase">
							<option value="">--Select--</option>
							<?php 
								foreach($arrPhaseIds as $key => $value){
								if($key == $arrClinicalTrial['phase'])
									echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
								else
									echo '<option value="'.$key.'">'.$value.'</option>';
								}
							?>
						</select>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<input type="hidden" name="sponsorId"  value="<?php echo $arrSponsor['id'];?>" id="ctSponsorId"></input>
						<input type="hidden" name="no_of_sponsors" id="noOfSponsors" value="<?php echo $arrClinicalTrial['no_of_sponsors'];?>"/>
						<label for="ctSponsor">Sponsor:</label>
						<input type="text" name="sponsor" value="<?php echo $arrSponsor['sponsor'];?>" id="ctSponsor"></input>
					</p>
				</td>
				<?php if($arrClinicalTrial['id']==''){?>
					<td>
						<a href="#" id="addMoreSponsors"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add Anothr Sponsor" title="Add Anothr Sponsor"/></a>
					</td>
				<?php }?>
				
			</tr>
			<tr>		
				<td>
					<div id="addSponsorContainer">
						<?php if(isset($arrMultipleSponsors) && sizeof($arrMultipleSponsors)>=1){?>
							<?php 
								$i=0;
								foreach($arrMultipleSponsors as $sponsor){
									$i++;
									if($i == 1)
										continue;?>
		
									<input type="hidden" name="sponsorId<?php echo $i?>"  value="<?php echo $sponsor['id'];?>" id="sponsorId<?php echo $i?>"></input>
									<label for="ctSponsor<?php echo $i?>">Sponsor:</label>
									<input type="text" name="sponsor<?php echo $i?>" value="<?php echo $sponsor['agency'];?>" id="ctSponsor<?php echo $i?>"></input>
							<?php }?>
						<?php 	}?>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<input type="hidden" name="interventionId"  value="<?php echo $arrIntervention['id'];?>" id="ctInterventionId"></input>
						<input type="hidden" name="no_of_intervention" id="noOfInterventions" value="<?php echo $arrClinicalTrial['no_of_intervention'];?>"/>
						<label for="ctIntervention">Intervention:</label>
						<input type="text" name="intervention" value="<?php echo $arrIntervention['intervention'];?>" id="ctIntervention"></input>
					</p>
				</td>
				<?php if($arrClinicalTrial['id']==''){?>
					<td>
						<a href="#" id="addMoreInterventions"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add Anothr Intervention" title="Add Anothr Intervention"/></a>
					</td>
				<?php }?>
				
			</tr>
			<tr>		
				<td>
					<div id="addInterventionContainer">
						<?php if(isset($arrMultipleInterventions) && sizeof($arrMultipleInterventions)>=1){?>
							<?php 
								$i=0;
								foreach($arrMultipleInterventions as $intervention){
									$i++;
									if($i == 1)
										continue;?>
									<input type="hidden" name="interventionId<?php echo $i?>"  value="<?php echo $intervention['id'];?>" id="interventionId<?php echo $i?>"></input>
									<label for="ctIntervention<?php echo $i?>">Intervention:</label>
									<input type="text" name="intervention<?php echo $i?>" value="<?php echo $intervention['name'];?>" id="ctIntervention<?php echo $i?>"></input>
							<?php }?>
						<?php 	}?>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<input type="hidden" name="investigatorId"  value="<?php echo $arrInvestigator['id'];?>" id="ctInvestigatorId"></input>
						<input type="hidden" name="no_of_investigators" id="noOfInvestigators" value="<?php echo $arrClinicalTrial['no_of_investigators'];?>"/>
						<label for="ctInvestigators">Investigators:</label>
						<input type="text" name="investigators" value="<?php echo $arrInvestigator['investigators'];?>" id="ctInvestigators"></input>
					</p>
				</td>
				<?php if($arrClinicalTrial['id']==''){?>
					<td>
						<a href="#" id="addMoreInvestigators"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add Anothr Investigator" title="Add Anothr Investigator"/></a>
					</td>
				<?php }?>
			</tr>
			<tr>		
				<td>
					<div id="addInvestigatorContainer">
						<?php if(isset($arrMultipleInvestigators) && sizeof($arrMultipleInvestigators)>=1){?>
							<?php 
								$i=0;
								foreach($arrMultipleInvestigators as $investigator){
									$i++;
									if($i == 1)
										continue;?>
									<input type="hidden" name="investigatorId<?php echo $i?>"  value="<?php echo $investigator['id'];?>" id="ctInvestigatorId<?php echo $i?>"></input>
									<label for="ctInvestigators<?php echo $i?>">Investigators:</label>
									<input type="text" name="investigators<?php echo $i?>" value="<?php echo $investigator['last_name'];?>" id="ctInvestigators<?php echo $i?>"></input>
							<?php }?>
						<?php 	}?>
					</div>
				</td>
			</tr>
			--><tr>
				<td colspan="6">
					<div class="formButtons">
						<input type="submit" value="Save" name="submit" id="saveCtManual" ></input>
					</div>
				</td>
			</tr>
		</table>
		</form>
		<!-- End of ctManualForm Form-->
	</div>