<?php
/**
 * Controller is for generating reports of client events  
 * 
 * @author Laxman K
 * @since	3.4
 * @package application.controllers	 
 * @created on 23-11-11
 */

class Monthly_reports extends Controller{
	
	private $loggedUserId	= null;
	//Constructor
	function Monthly_reports(){
		parent::Controller();
		$this->load->model('monthly_report');
		$this->load->model('common_helpers');
		$this->load->model('kol');
		$this->load->model('payment');
		$this->load->model('client_user');
	}
	
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."/login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}
	
	function list_monthly_events($subContentPage=''){

		$data['contentPage'] 	=	'monthly_events/monthly_events_report';
		$data['subContentPage']	=	$subContentPage;
		$this->load->view('layouts/client_view',$data);		
	}
	
	/**
	 * List the "list monthly events for grid"
	 * @author Laxman K
	 * @since 3.4
	 * @created 23-11-11 
	 *
	 */
	function list_monthly_events_grid_details($clientId,$fromMonth=null,$toMonth=null)
	{
		$page					= (int)$this->input->post('page'); // get the requested page 
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$monthlyEventsResultSet = $this->monthly_report->getAllMonthlyEvents($clientId,$fromMonth,$toMonth);
		$toalAmount 			= 0;
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		foreach($monthlyEventsResultSet as $row){
			$rowData['id']=$row['id'];
			$rowData['region']=$row['region_country'];
			$rowData['date']= sql_date_to_app_date($row['event_date']);
			$arrEventPayments =  $this->monthly_report->getClentEventPayments($rowData['id']);
			$rowData['presenter']="";
			foreach ($arrEventPayments as $eventPayment){
				if($eventPayment['kol_status']==PRENEW || $eventPayment['kol_status']==COMPLETED){
//					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'kols/view/'.$eventPayment['kol_id'].'">'.$arrSalutations[$eventPayment['salutation']]." ".$eventPayment[FIRST_ORDER].' '.$eventPayment[SECOND_ORDER].' '.$eventPayment[THIRD_ORDER].'</a>';
					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'kols/view/'.$eventPayment['kol_id'].'">'.$arrSalutations[$eventPayment['salutation']]." ".$this->common_helpers->get_name_format($eventPayment['first_name'],$eventPayment['middle_name'],$eventPayment['last_name']).'</a>';
				}elseif($eventPayment['kol_status']==New1 || $eventPayment['kol_status']==APPROVED){
//					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$eventPayment['salutation']]." ".$eventPayment[FIRST_ORDER].' '.$eventPayment[SECOND_ORDER].' '.$eventPayment[THIRD_ORDER].'</a>';
					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$eventPayment['salutation']]." ".$this->common_helpers->get_name_format($eventPayment['first_name'],$eventPayment['middle_name'],$eventPayment['last_name']).'</a>';
				}elseif($eventPayment['kol_status']=='rejected' ){
//					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$eventPayment['salutation']]." ".$eventPayment[FIRST_ORDER].' '.$eventPayment[SECOND_ORDER].' '.$eventPayment[THIRD_ORDER].'</a>';
					$rowData['presenter'] .= '<a target="_NEW" href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$eventPayment['salutation']]." ".$this->common_helpers->get_name_format($eventPayment['first_name'],$eventPayment['middle_name'],$eventPayment['last_name']).'</a>';
				}else{
//					$rowData['presenter'] .= $arrSalutations[$eventPayment['salutation']]." ".$eventPayment[FIRST_ORDER].' '.$eventPayment[SECOND_ORDER].' '.$eventPayment[THIRD_ORDER];
					$rowData['presenter'] .= $arrSalutations[$eventPayment['salutation']]." ".$this->common_helpers->get_name_format($eventPayment['first_name'],$eventPayment['middle_name'],$arrPaymentResult['last_name']);
				}
				$rowData['event_date'] = sql_date_to_app_date($eventPayment['date']);
			}
			//$rowData['presenter']=$row['presenter'];
			$rowData['topics']=$row['topics'];
			$rowData['feedback']=$row['feedback'];
			$rowData['type']=$row['meeting_type'];
			$rowData['attendees']=$row['no_of_attendees'];
			$rowData['amount']=$row['amount'];
			$toalAmount = $toalAmount+(int)$rowData['amount'];
			$monthlyEventsRecords[]=$rowData;
		}
		$count=sizeof($monthlyEventsRecords);				
		if( $count >0 ){ 
			$total_pages = ceil($count/$limit); 
		}else{ 
			$total_pages = 0; 
		}
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$monthlyEventsRecords;
		$userdata['amount'] = $toalAmount;
		$userdata['region'] = "Total :";
		$data['userdata'] = $userdata;

		echo json_encode($data);
	}

	/**
	 * Prepares the data for Client Event Form and Gives it to the add client event form
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @created 24-11-11 
	 */
	function add_client_event($eventId=null){
		$arrPayees = $this->payment->getAllPaymentsPaidBy();
		$arrRequesters = $this->payment->getAllPaymentsRequestedBy();
		$data['arrPayees'] = $arrPayees;
		$data['arrRequesters'] = $arrRequesters;
		
		if($eventId == null)
			$this->load->view('monthly_events/clent_event_form',$data);
		else{
			$arrClientEventDatails	=	$this->monthly_report->getClentEvent($eventId);
			$arrEventPayments =  $this->monthly_report->getClentEventPayments($eventId);
			$arrClientEventDatails['requested_by'] = (isset($arrEventPayments[0]['requested_by'])?$arrEventPayments[0]['requested_by']:'');
			$arrClientEventDatails['paid_by'] = (isset($arrEventPayments[0]['paid_by'])?$arrEventPayments[0]['paid_by']:'');
			$data['arrEventPayments'] = $arrEventPayments;
			$data['noOfAttendeesEntered'] = sizeof($arrEventPayments);
			$data['arrClientEventDatails']=$arrClientEventDatails;
			$this->load->view('monthly_events/clent_event_form',$data);
		}
	}
	
	/**
	 * Gets the Client Event details from the form and saves the record
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @created 24-11-11 
	 */
	function save_client_event(){
		$clientId	=		$this->session->userdata('client_id');
		$userId		=		$this->session->userdata('user_id');
		$eventId	=		$this->input->post('event_id');
		
		$arrClientEventDatails	=	array();
		if($eventId != null)
			$arrClientEventDatails['id']=$eventId;
		$arrClientEventDatails['region_country']=$this->input->post('region_country');
		$arrClientEventDatails['event_date']=app_date_to_sql_date($this->input->post('event_date'));
		$arrClientEventDatails['meeting_type']=$this->input->post('meeting_type');
		$arrClientEventDatails['no_of_attendees']=$this->input->post('no_of_attendees');
		$arrClientEventDatails['topics']=$this->input->post('topics');
		$arrClientEventDatails['feedback']=$this->input->post('feedback');
		$arrClientEventDatails['amount']=$this->input->post('total_amount');
		$arrClientEventDatails['client_id']=$clientId;
		$arrClientEventDatails['user_id']=$userId;
		
		$arrKols = $this->payment->getAllKolsName1();
		
		if(isset($arrClientEventDatails['id'])){
			$this->monthly_report->updateClientEvent($arrClientEventDatails);
			
			$paymentDetails = array();
			$paymentDetails['requested_by'] = $this->input->post('requested_by');
			$paymentDetails['paid_by'] = $this->input->post('paid_by');
			$paymentDetails['date'] = $arrClientEventDatails['event_date'];
			
			$noOfAttendeesEntered = $this->input->post('no-of-attendees-entered');
			for ($i=1; $i <= $noOfAttendeesEntered; $i++){
				if($this->input->post('presenter_name_'.$i)!='' && $this->input->post('presenter_name_'.$i)!=null){
					$kolName		= $this->input->post('presenter_name_'.$i);
				//$kolId = array_search($kolName,$arrKols);
				//$kolId=$this->kol->getKolId($kolName);
				$kolId= trim($this->input->post('presenter_'.$i));
				if($kolId==''){
					$kolId= array_search($kolName,$arrKols);
				}
				if($kolId == '')
					$kolId = $this->saveNonProfiledKOL($kolName,$arrKols);
					$paymentDetails['kol_id'] = $kolId;
					$paymentDetails['amount'] = $this->input->post('amount_'.$i);
					
					$paymentId = $this->input->post('payment_id_'.$i);
					if(isset($paymentId) && $paymentId != null){
						$paymentDetails['id'] = $paymentId;
						$paymentDetails['modified_by']=$userId;
						$paymentDetails['modified_on']=date('Y-m-d H:i:s');
						$this->payment->updatePayment($paymentDetails);
						
						//Update payment split
						$paymentSplit = array();
						$paymentSplit['amount'] = $paymentDetails['amount'];
						$paymentSplit['payment_id'] = $paymentId;
						$this->payment->updatePaymentSplitClientEvent($paymentSplit);
					}
					else{
						unset($paymentDetails['id']);
						$paymentDetails['client_id']=$clientId;
						$paymentDetails['created_by']=$userId;
						$paymentDetails['created_on']=date('Y-m-d H:i:s');
						$paymentId = $this->payment->savePayment($paymentDetails);
						
						unset($paymentDetails['client_id']);
						unset($paymentDetails['created_by']);
						unset($paymentDetails['created_on']);
						
						//Save payment split
						$paymentSplit = array();
					$paymentSplit['type'] = $this->monthly_report->getEventPaymentTypeId();
						$paymentSplit['payment_id'] = $paymentId;
						$paymentSplit['amount'] = $paymentDetails['amount'];
						$this->payment->savePaymentSplit($paymentSplit);
						
						//save event payments
						$eventPayment = array();
						$eventPayment['client_event_id'] = $eventId;
						$eventPayment['payment_id'] = $paymentId;
						$this->monthly_report->eventPayment($eventPayment);
					}
				}
			}
			
			//$this->update->insertUpdateEntry(KOL_PROFILE_EVENT_UPDATE,$arrClientEventDatails['id'], MODULE_KOL_EVENT, $arrClientEventDatails['kol_id']);
		}else{
			$eventId = $this->monthly_report->saveClientEvent($arrClientEventDatails);
			$paymentDetails = array();
			$paymentDetails['requested_by'] = $this->input->post('requested_by');
			$paymentDetails['paid_by'] = $this->input->post('paid_by');
			$paymentDetails['date'] = $arrClientEventDatails['event_date'];
			$paymentDetails['client_id']=$clientId;
			$paymentDetails['created_by']=$userId;
			$paymentDetails['created_on']=date('Y-m-d H:i:s');
			
			$noOfAttendeesEntered = $this->input->post('no-of-attendees-entered');
			for ($i=1; $i <= $noOfAttendeesEntered; $i++){
					
				if($this->input->post('presenter_name_'.$i)!='' && $this->input->post('presenter_name_'.$i)!=null){
					$kolName		= $this->input->post('presenter_name_'.$i);
				//$kolId = array_search($kolName,$arrKols);
					//$kolId=$this->kol->getKolId($kolName);
					$kolId= trim($this->input->post('presenter_'.$i));
					if($kolId==''){
						$kolId= array_search($kolName,$arrKols);
					}
					
					if($kolId == '')
					$kolId = $this->saveNonProfiledKOL($kolName,$arrKols);
					$paymentDetails['kol_id'] = $kolId;
					$paymentDetails['amount'] = $this->input->post('amount_'.$i);
					//save payment
					$paymentId = $this->payment->savePayment($paymentDetails);
					
					//Save payment split
					$paymentSplit = array();
				//All the payments for events will br considered a payment of type 'event'
				$paymentSplit['type'] = $this->monthly_report->getEventPaymentTypeId(); 
					$paymentSplit['payment_id'] = $paymentId;
					$paymentSplit['amount'] = $paymentDetails['amount'];
					$this->payment->savePaymentSplit($paymentSplit);
					
					//save event payments
					$eventPayment = array();
					$eventPayment['client_event_id'] = $eventId;
					$eventPayment['payment_id'] = $paymentId;
					$this->monthly_report->eventPayment($eventPayment);
				}
			}
			
			//$this->update->insertUpdateEntry(KOL_PROFILE_EVENT_ADD,$arrClientEventDatails['id'], MODULE_KOL_EVENT, $arrClientEventDatails['kol_id']);
			return true;
		}
		//redirect(base_url().'monthly_reports/list_monthly_events');
	}
	
	/**
	 * Deletes the client event with the given id
	 * 
	 * @author Ramesh B
	 * @since 3.4
	 * @param $eventId
	 * @created 24-11-11 
	 */
	function delete_client_event($eventId){
		$isDeleted	=	$this->monthly_report->deleteClientEvent($eventId);
		//$this->update->insertUpdateEntry(KOL_PROFILE_EVENT_DELETE,$isDeleted['id'], MODULE_KOL_EVENT, $eventId['kol_id']);
		echo $isDeleted;
	}
	
	function view($eventId){
		$arrPayees				= $this->payment->getAllPaymentsPaidBy();
		$arrRequesters			= $this->payment->getAllPaymentsRequestedBy();
		$data['arrPayees']		= $arrPayees;
		$data['arrRequesters']	= $arrRequesters;
		$arrClientEventDatails	=	$this->monthly_report->getClentEvent($eventId);
		$arrEventPayments 		=  $this->monthly_report->getClentEventPayments($eventId);
		$arrClientEventDatails['event_date'] 	= sql_date_to_app_date($arrClientEventDatails['event_date']);
		$arrClientEventDatails['requested_by']	= (isset($arrEventPayments[0]['requested_by'])?$arrEventPayments[0]['requested_by']:'');
		$arrClientEventDatails['paid_by']		= (isset($arrEventPayments[0]['paid_by'])?$arrEventPayments[0]['paid_by']:'');
		$data['arrEventPayments']				= $arrEventPayments;
		$data['noOfAttendeesEntered']			= sizeof($arrEventPayments);
		$data['arrClientEventDatails']			= $arrClientEventDatails;
		$this->load->view('monthly_events/view',$data);
	}
		
	function delete_payment_association($paymentId){
		$this->payment->deletePaymentById($paymentId);
	}
	
	function saveNonProfiledKOL($kolName,$arrKols){
		$kolSaved='';
		$checkCamma = strpos($kolName,',');
		$kolDetail=array();
		if($checkCamma!=''){
			
			$kolNameExplodeBy = explode(',',$kolName);
			//pr($kolNameExplodeBy);
			if(sizeOf($kolNameExplodeBy)==1){
					$kolDetail['first_name'] = $kolNameExplodeBy[0];
				}
			if(sizeOf($kolNameExplodeBy)==2){
					$kolDetail['last_name'] = $kolNameExplodeBy[0];
					$kolDetail['first_name'] = $kolNameExplodeBy[1];
				}
			if(sizeOf($kolNameExplodeBy)==3){
				$kolDetail['last_name'] = $kolNameExplodeBy[0];
				$kolDetail['first_name'] = $kolNameExplodeBy[1];
				$kolDetail['middle_name'] = $kolNameExplodeBy[2];
			}
			
			$checkKolname = $kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
			$kolId = array_search($checkKolname,$arrKols);
			if($kolId==''){
				$kolDetail['created_by'] = $this->session->userdata('user_id');
				$kolDetail['status'] = PRENEW;
				$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
			}else{
				$paymentDetails['kol_id'] =$kolId;
			}
			$kolSaved = 'Saved';
			
		}
		if($kolSaved!='Saved'){
			$splitByspace = explode(" ",$kolName);
		
			if(sizeOf($splitByspace)==2){
					
				$kolDetail['first_name'] = $splitByspace[0];
					$kolDetail['last_name'] = $splitByspace[1];
			}
			
			if(sizeOf($splitByspace)==3){
			
				$kolDetail['first_name'] = $splitByspace[0];
				$kolDetail['middle_name'] = $splitByspace[1];
				$kolDetail['last_name'] = $splitByspace[2];
				
			}
			
			if(sizeOf($splitByspace)>3){
				$kolDetail['first_name'] = $splitByspace[0];
				$kolDetail['middle_name'] = $splitByspace[1];
				$kolDetail['last_name'] = $splitByspace[2]." ". $splitByspace[3];
			
			}
			$kolDetail['created_by'] = $this->session->userdata('user_id');
			$kolDetail['status'] = PRENEW;
			$paymentDetails['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
		}
		
		return $paymentDetails['kol_id'];
				
	}
	
	function export_event_report(){
		$arrPayees = $this->payment->getAllPaymentsPaidBy();
		$arrRequesters = $this->payment->getAllPaymentsRequestedBy();
		$eventId = $this->input->post('ids');
		$eventIds = explode(',',$eventId);
		$monthlyEventsResultSet = $this->monthly_report->getEventReportDetail($eventIds);
		
		$toalAmount = 0;
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$monthlyEventsRecords[0] = array('Presenter(s)','Topics(s)','Date','Meeting Type','Attendees','Region','Amount','Requested By','Paid By','Feedback');
		foreach($monthlyEventsResultSet as $row){
			$arrEventPayments =  $this->monthly_report->getClentEventPayments($row['id']);
			$rowData[0]="";
			$seperator='';
			foreach ($arrEventPayments as $eventPayment){
					$rowData[0] .= $seperator.$arrSalutations[$eventPayment['salutation']]." ".$eventPayment['first_name'].' '.$eventPayment['middle_name'].' '.$eventPayment['last_name'];
					$seperator =' , ';
			}
			$rowData[1]=$row['topics'];
			$rowData[2]= sql_date_to_app_date($row['event_date']);
			
			$rowData[3]=$row['meeting_type'];
			$rowData[4]=$row['no_of_attendees'];
			$rowData[5]=$row['region_country'];
			$rowData[6]=$row['amount'];
			$rowData[7]=$arrRequesters[$arrEventPayments[0]['requested_by']];
			$rowData[8]=$arrPayees[$arrEventPayments[0]['paid_by']];
			$rowData[9]=$row['feedback'];
			$monthlyEventsRecords[]=$rowData;
		}
		
		//pr($monthlyEventsRecords);
	//pr($arrInteractions);
		$this->load->plugin('phpxls/writer');
		$workbook = new Spreadsheet_Excel_Writer();
		
		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
		$format_und->setAlign('centre');
		$format_und->setSize(12);
			
		$format_reg =& $workbook->addFormat();
	//	$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		
		$excelFilters = $this->input->post('filters');
		$filters = array();
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		$filterHeaders[0] = 'Filter Name';
		$filterHeaders[1] = 'Filter Value';
		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != ''){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
		
		
		$arr = array(
		      	'Event Report' => $monthlyEventsRecords,
				'Filters' => $filters
		      );

		foreach($arr as $wbname=>$rows)
		{
		    
			$rowcount = count($rows);
			$colcount = count($rows[0]);
			
			$worksheet =& $workbook->addWorksheet($wbname);
			if($wbname=='Event Report'){
				$worksheet->setColumn(0,0, 40);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,20.00);
				$worksheet->setColumn(2,2, 15.00);
				$worksheet->setColumn(3,3, 25.00);
				$worksheet->setColumn(4,4, 25.00);
				$worksheet->setColumn(5,5, 20.00);
				$worksheet->setColumn(6,6, 20.00);
				$worksheet->setColumn(7,7,20.00);
				$worksheet->setColumn(8,11,20.00);
				$worksheet->setColumn(9,12,40.00);
			}
			
			if($wbname == 'Filters'){
				$worksheet->setColumn(0,0,25);
			    $worksheet->setColumn(1,1,25);
			}

			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
			          
					if ($j==0){
						$fmt =& $format_und;
					                    
					}
					if (isset($rows[$j][$i]))
					{
						$data=$rows[$j][$i];
						$worksheet->write($j, $i, $data, $fmt);
					}
				}
			}
		}
		
		$userId=$this->session->userdata('user_id');
		$userName = $this->client_user->getUserNameById($userId);
		$fileName = $userName."_event_report";
		if($kolId != null){
			$kolDetails = $this->kol->getKolName($kolId);
			$kolName = $kolDetails['first_name'].' '.$kolDetails['middle_name'].' '.$kolDetails['last_name'];
			$fileName = $userName."_".$kolName."_event_report";
		}
		//for downloading the file
		$workbook->send($fileName.'.xls');
		$workbook->close();
	}
	
	
}