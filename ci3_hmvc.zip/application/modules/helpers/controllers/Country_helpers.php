<?php
class Country_helpers extends MX_Controller{
	function Country_helpers(){
		parent::__construct();
		$this->load->Model('Country_helper');
	}	
	/*
	 * function to get states belongs to county 
	 * takes 'country_id' as parameter
	 */
	function get_states_by_countryid(){
		$countryId=$this->input->post('country_id');	
		$arrState=$this->Country_helper->getStatesByCountryId($countryId);		
		echo json_encode($arrState);
	}
	/*
	 * function to get cities belongs to state
	 * takes 'state_id' as parameter
	 */
	function get_cities_by_stateid(){	
		$state_id=$this->input->post('state_id');
		$arrCity=$this->Country_helper->getCitiesByStateId($state_id);
		echo json_encode($arrCity);
	}
}
