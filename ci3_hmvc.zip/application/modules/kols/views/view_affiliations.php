<script type="text/javascript">
	var edit_permission='<?php $role_permissions=$this->config->item('role_permissions');echo $role_permissions[$module_id]["edit"];?>';
	var delete_permission='<?php echo $role_permissions[$module_id]["delete"];?>';
	var data={};
	var kolId=<?php echo $arrKol['kols_client_visibility_id'];?>;
	var kol_unique_id 	= '<?php echo $arrKol['kols_client_visibility_unique_id']?>'; 
	var org_contract = '<?php echo ORGS_CONTRACT;?>';
	var contractType = "kol";
	var subContentPage	= '<?php echo $subContentPage;?>';
	var arrExcludeColumnsInExcelExport = new Array('act'); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by');
	$(document).ready(function(){
		load_jqgrid();
	});
</script>
<link href="<?php echo base_url().ASSETS;?>c3js/c3.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css"  rel="stylesheet"/>
<link href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css"  rel="stylesheet"/>
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
			'jqgrid/jquery.jqGrid.min_3.8',
			'c3js/c3.min',
			'c3js/d3.c3.min',
			'js/custom_js/jqgridExportToExcel',
			'modules/kols/js/view_affiliations',
			//'modules/contracts/js/contracts',
			'alerts/jquery.alerts',
		'js/jquery.autocomplete',
		'jquery_validator/dist/jquery.validate'
	);    
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>

<style>
.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
    color: #000;
}
.action_icons {
    font-size: 16px;
    padding: 0px 5px;
}
.excelExportIcon{
float:right;
margin-right: 50px;
margin-right: 20px !important;
}
</style>
<?php switch($subContentPage){
			case 'university':?><div id="university">
										<div class="row">
											<div class="pull-right row_padding">
												<button onClick="toggleAffiliationGrouping('JQBlistUniversityResultSet', 'toggleUnivGrouping');" type="button" class="btn custom-btn" id="toggleUnivGrouping" >All Affiliations</button>
													<?php if($role_permissions[$module_id]["add"]==1){?>
														<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
													<?php }?>
												<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left"  onclick="exportExcel('#JQBlistUniversityResultSet','university');">
	                                            	<a href="#" rel="tooltip" title="Export University Details into Excel format">&nbsp;</a>
	                                            </div>
											</div>
										</div>
										<div class="gridWrapper" id="universityGridContainer">
											<table id="JQBlistUniversityResultSet"></table>
											<div id="listUniversityPager"></div>
										</div>
									</div>
			<?php break;
			case 'associations':?><div id="society">
										<div class="row">
											<div class="pull-right row_padding">
												<button onClick="toggleAffiliationGrouping('JQBlistAssociationResultSet', 'toggleAssocGrouping');" type="button" class="btn custom-btn" id="toggleAssocGrouping" >All Affiliations</button>
													<?php if($role_permissions[$module_id]["add"]==1){?>
														<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
													<?php }?>												
												<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left"  onclick="exportExcel('#JQBlistAssociationResultSet','association');">
	                                            	<a href="#" rel="tooltip" title="Export Association Details into Excel format">&nbsp;</a>
	                                            </div>
											</div>
										</div>
										<div class="gridWrapper" id="associationGridContainer">
											<table id="JQBlistAssociationResultSet"></table>
											<div id="listAssociationPager"></div>
										</div>
					  				</div>
									<?php break;
			case 'industry':?><div id="industry">
										<div class="row">
											<div class="pull-right row_padding">
												<button onClick="toggleAffiliationGrouping('JQBlistIndustryResultSet','toggleIndustryGrouping');" type="button" class="btn custom-btn" id="toggleIndustryGrouping" >All Affiliations</button>
												<?php if($role_permissions[$module_id]["add"]==1){?>
														<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
												<?php }?>
												<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left"  onclick="exportExcel('#JQBlistIndustryResultSet','industry');">
	                                            	<a href="#" rel="tooltip" title="Export Industry Details into Excel format">&nbsp;</a>
	                                            </div>
											</div>
										</div>
										<div class="gridWrapper" id="industryGridContainer">
											<table id="JQBlistIndustryResultSet"></table>
											<div id="listIndustryPager"></div>
										</div>
								</div>
								<?php break;
			case 'govt_agency':?><div id="govt">
										<div class="row">
											<div class="pull-right row_padding">
												<button onClick="toggleAffiliationGrouping('JQBlistGovernmentResultSet', 'toggleGovtGrouping');" type="button" class="btn custom-btn" id="toggleGovtGrouping" >All Affiliations</button>
												<?php if($role_permissions[$module_id]["add"]==1){?>
														<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
												<?php }?>
												<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#JQBlistGovernmentResultSet','GovernmentAgency');">
	                                            	<a href="#" rel="tooltip" title="Export Government Agency Details into Excel format">&nbsp;</a>
	                                            </div>
											</div>
										</div>
										<div class="gridWrapper" id="governmentGridContainer">
											<table id="JQBlistGovernmentResultSet"></table>
											<div id="listGovernmentPager"></div>
										</div>
								</div>
								<?php break;
			case 'others':?><div id="others">
								<div class="row">
									<div class="pull-right row_padding">
										<button onClick="toggleAffiliationGrouping('JQBlistOthersResultSet', 'toggleOthersGrouping');" type="button" class="btn custom-btn" id="toggleOthersGrouping" >All Affiliations</button>
										<?php if($role_permissions[$module_id]["add"]==1){?>
												<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
										<?php }?>
										<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#JQBlistOthersResultSet','other');">
	                                    	<a href="#" rel="tooltip" title="Export Other Details into Excel format">&nbsp;</a>
	                                    </div>
									</div>
								</div>	
									<div class="gridWrapper" id="othersGridContainer">
										<table id="JQBlistOthersResultSet"></table>
										<div id="listOthersPager"></div>
									</div>
							</div>
							<?php break;
			case 'reports_org':?><div class="row">
									<div class="col-sm-6">
										<div class="panel panel-default">
										  <div class="panel-heading">
										    <h3 class="panel-title">Affiliations By Organization Type</h3>
										  </div>
										  <div class="panel-body">
										    <div id="affiliationsChartByOrgType"></div>
										  </div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="panel panel-default">
											  <div class="panel-heading">
											    <h3 class="panel-title">Affiliations By Engagement Type</h3>
											  </div>
											  <div class="panel-body">
											    <div id="affiliationsChartByEngType">
											    Click on Organization Type
											    </div>
											  </div>
										</div>
									</div>
								</div>
			<?php break;
			case 'reports_eng':?><div class="row">
									<div class="col-sm-6">
										<div class="panel panel-default">
										  <div class="panel-heading">
										    <h3 class="panel-title">Affiliations By Engagement Type</h3>
										  </div>
										  <div class="panel-body">
										    <div id="affiliationsChartByEngType"></div>
										  </div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="panel panel-default">
											  <div class="panel-heading">
											    <h3 class="panel-title">Affiliations By Organization Type</h3>
											  </div>
											  <div class="panel-body">
											    <div id="affiliationsChartByOrgType">
											    Click on Organization Type
											    </div>
											  </div>
										</div>
									</div>
								</div>
			<?php break;
			default:?><div id="all">
						<div class="row">
							<div class="pull-right row_padding">
								<?php if($role_permissions[$module_id]["add"]==1){?>
										<a type="button" href="<?php echo base_url().'kols/kols/add_client_affiliations/'.$arrKol['kols_client_visibility_unique_id'];?>"  class="btn custom-btn" title="Add Affiliation">Add Affiliation</a>
								<?php }?>
								<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#JQBlistAllResultSet','allAffilations');">
	                           	<a href="#" rel="tooltip" title="Export All Affilations Details into Excel format">&nbsp;</a>
	                           </div>
							</div>
						</div>
						<div class="gridWrapper" id="allAfiliationGridContainer">
							<table id="JQBlistAllResultSet"></table>
							<div id="listAllPager"></div>
						</div>		
					</div>
			<?php break;
}?>
