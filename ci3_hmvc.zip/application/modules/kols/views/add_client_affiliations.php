<?php
 $autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";

$queued_js_scripts = array('js/jquery.autocomplete','jquery_validator/dist/jquery.validate');    
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/jquery.autocomplete.js"></script>
<div class="panel panel-default">
	<div class="panel-heading align_center"><?php if($affId>0)echo 'Update Affiliation Details';else echo 'Add Affiliation';?></div>
	<div class="panel-body">
		<div class="col-md-10 col-md-offset-2 uniMsgBox alert alert-success" role="alert" style="display:none"></div>
		<form action="save_membership" method="post" id="universityForm" name="universityForm" class="validateForm">
			<input type="hidden" name="type" value="university"/>
	    	<input type="hidden" name="id" id="uniId" value="<?php echo $affId;?>"/>
	    	<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId?>"/>
			<div class="form-group row" id="show_add_file_name" >
				<label class="col-sm-2 align_right">Organization Name:<span class="required">*</span></label>
				<div class="col-sm-10">
					<input type="hidden" name="institute_id" id="uniNameId"/>
					<input type="text" name="name" id="uniName" class="required form-control autocompleteInputBox" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['org_name'];}?>"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Org Type:<span class="required">*</span></label>
				<div class="col-sm-4">
					<select name="type" id="type" class="form-control required">
						<option value="">--- Select ---</option>
						<option value="association" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'association') echo 'selected';}?>>Association</option>
						<option value="government" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'government') echo 'selected';}?>>Government</option>
						<option value="industry" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'industry') echo 'selected';}?>>Industry</option>
						<option value="university" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'university') echo 'selected';}?>>University</option>
						<option value="others" <?php if($arrAffiliationsData){ if($arrAffiliationsData['org_type'] == 'others') echo 'selected';}?>>Others</option>
					</select>
		    	</div>
		    	<label class="col-sm-2 align_right">Engagement Type:</label>
				<div class="col-sm-4">
		  			<select name="engagement_id" id="uniEngagement" class="form-control">
						<option value="0">--- Select ---</option>
							<?php 
							foreach($arrEngagementTypes as $key => $value){
							if($arrAffiliationsData['engagement_id'] == $key)
								echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
							else
								echo '<option value="'.$key.'">'.$value.'</option>';
							}
							?>
					</select>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Dept/Committee:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="department" id="uniDepartment" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['department'];}?>"/>
		    	</div>
		    	<label class="col-sm-2 align_right">Title:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="role" id="uniRole" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['role'];}?>"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Start Year:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="start_date" id="uniStartDate" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['start_date'];}?>" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"/>
		    	</div>
		    	<label class="col-sm-2 align_right">End Year:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="end_date" id="uniEndDate" value="<?php if($arrAffiliationsData){echo $arrAffiliationsData['end_date'];}?>" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"/>
		    		<div class="msgBox instNotFound" style="display: none;">Invalid Year.End Year Should be Greater than Start Year</div>
		    	</div>
			</div>
			<div class="form-group row" style="text-align: center;">
	   			<a type="button" onclick="saveAllAffiliations();return false;" class="btn custom-btn">Save</a>
	            <a type="button" onclick="goBack();return false;" class="btn custom-btn">Cancel</a>
			</div>
		</form>
	</div>
</div>
<script>
//Validate function
$(document).ready(function() {	
	$('div.uniMsgBox').hide();
	$("#universityForm").validate({
		debug:true,
		onkeyup:true,
		rules: validationRules,
		messages: validationMessages
	});
 });
function validate(){
	var startDate=$("#uniStartDate").val();
	var endDate=$("#uniEndDate").val();
	if(endDate!=''){	
		if(startDate>endDate){
			$(".msgBox").show();
			disableButton();
			return false;
		}else{
			$(".msgBox").hide();
			enableButton();
		}
	}
	return true;
}
var options, a;
// Autocomplet Options for the  Name' field of 'University / Hospital' ,'Assocition','Industry','Gvt','Others'
// Autocomplet Options for the 'Institute Name' field searches From the lookuptable
	var uniInstituteNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>kols/kols/get_institute_names',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var selText = $(event).children('.educations').html();
		var selId = $(event).children('.educations').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#uniName').val(selText);
		$('#uniNameId').val(selId);
		if(event.length>20){
			//$('#orgIdForAutocomplete').val(kolId);
			if(event.substring(0,21)=="No results found for "){
				return false;
			}
		}
	}
};	
var validationRules	=  {
	name: {
		required:true
	},
	type:{
		required:true
	}
};
var validationMessages = {
	name: {
		required: "Required"
	},
	type: {
		required: "Required"
	}
};

/**
* Validate the text for 'Numeric Only'
*/
function allowNumericOnly(src) {
	if(!src.value.match(/^\d*$/)) {
		src.value=src.value.replace(/[^0-9]/g,'');  
	}
}
//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
$('div[id^="AutocompleteContainter_"]').remove();	
// Trigger the Autocompleter for 'Event Name' field of type 'Conference Event'
a = $('#uniName').autocomplete(uniInstituteNameAutoCompleteOptions);
function saveAllAffiliations(){
	// Disable the SAVE Button
	disableButton();
	$("#universityForm").validate().resetForm();
	if(!$("#universityForm").validate().form()){
		enableButton();
		return false;
	}
	if(!(validate())){
		return false;
	}
	// Check if the Institute Name is present in Master table or not
	instituteName	=	$("#uniName").val(); 
	// URL to get the Institute ID, if Name is present
	urlAction = base_url+'kols/kols/get_institute_id_else_save/institute_name';
	// Variable to hold the Institute Id
	instituteId	= '';
	postdata = {'name':instituteName}
	$.post(urlAction,postdata,
			function(returnData){
				if(returnData){
					instituteId	= returnData;				
					saveAffiliationDetails(instituteId);
				}else{
					enableButton();
					// Set the user entered name in the 'Add New Institute' form
					$("#instituteName").val(instituteName);
					return false;
				}
			},"json");
		//- End of checking the Intitute Name in Master Table
};			 
function saveAffiliationDetails(instituteId){
	$("#uniNameId").val(instituteId);
	$('div.uniMsgBox').removeClass('alert-success');
	$('div.uniMsgBox').addClass('alert-warning');
	$('div.uniMsgBox').show();
	$('div.uniMsgBox').html('Saving the data... <img src="'+base_url+'assets/images/ajax_loader_black.gif" />');
	//If Institute Id is present then perform save or update
	var id = $("#uniId").val();
	if(id == ''){
		formAction = base_url+'kols/kols/save_membership';
	}else{
		formAction = base_url+'kols/kols/update_membership';
	}				
	$.post(formAction, $("#universityForm").serialize(),function(returnData){
		$('.uniMsgBox').text(returnData.msg);
		$('html, body').animate({
            scrollTop: $("div.uniMsgBox").first().offset().top-100
        });
		if(returnData.saved == true){
			$('div.uniMsgBox').removeClass('alert-warning');
			$('div.uniMsgBox').addClass('alert-success');				
     	}else{
     		enableButton("saveConference");
			$('div.uniMsgBox').removeClass('alert-success');
			$('div.uniMsgBox').addClass('alert-danger');
	    }
		$('div.uniMsgBox').fadeOut(10000);
	},"json");
}
function disableButton(){
	$("#saveAffiliations").attr('disabled','disabled');
}
function enableButton(){
	$('#saveAffiliations').removeAttr('disabled');
}
</script>