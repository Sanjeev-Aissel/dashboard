<?php
class Assessment_score extends CI_Model {
	function getAllAsmtRules($countryId){
		$client_id = $this->session->userdata('client_id');
		$arrAsmtRules	= array();
		$resultSet		= '';
		$this->db->select("asmt_rules.*,asmt_categories.name as cat_name,asmt_criteria.criteria,asmt_ratings.rating,asmt_ratings_client_association.rating_score");
		$this->db->join('asmt_categories_client_association','asmt_categories_client_association.id=asmt_rules.category_id','inner');
		$this->db->join('asmt_categories','asmt_categories.id=asmt_categories_client_association.asmt_category_id','inner');
		
		$this->db->join('asmt_criteria_client_association','asmt_criteria_client_association.id=asmt_rules.criteria_id','inner');
		$this->db->join('asmt_criteria','asmt_criteria.id=asmt_criteria_client_association.asmt_criteria_id','inner');
		
		$this->db->join('asmt_ratings_client_association','asmt_ratings_client_association.id=asmt_rules.rating_id','inner');
		$this->db->join('asmt_ratings','asmt_ratings.id=asmt_ratings_client_association.asmt_rating_id','inner');
		
		$this->db->order_by('asmt_rules.category_id','asc');
		$this->db->order_by('asmt_rules.criteria_id','asc');
		$this->db->order_by('asmt_rules.order_no','asc');
		$this->db->where('asmt_rules.country_id',$countryId);
		$this->db->where('asmt_rules.client_id',$client_id);
		$resultSet	= $this->db->get('asmt_rules');
// 		echo $this->db->last_query();
		foreach($resultSet->result_array() as $row){
			$arrAsmtRules[]	= $row;
		}
		return $arrAsmtRules;
	}
	function saveKolRatings($arrDetails){
		$arrRatingDetails['created_on']	=date('Y-m-d H:i:s');
		$arrRatingDetails['created_by']	=$this->session->userdata('user_id');
		$arrRatingDetails['kol_id']		=$arrDetails['kol_id'];
		unset($arrDetails['kol_id']);
		
		foreach($arrDetails as $cat_crit_key_pair=>$rating_id){
			$cat_crit_key_pair=explode('_', $cat_crit_key_pair);
			$arrRatingDetails['category_id']=$cat_crit_key_pair[0];
			$arrRatingDetails['criteria_id']=$cat_crit_key_pair[1];
			$arrRatingDetails['rating_id']=$rating_id;

			$this->db->where('kol_id',$arrRatingDetails['kol_id']);
			$this->db->where('category_id',$arrRatingDetails['category_id']);
			$this->db->where('criteria_id',$arrRatingDetails['criteria_id']);
			$this->db->where('created_by',$arrRatingDetails['created_by']);
			$resultSet	= $this->db->get('asmt_kols_rating');
			
			if(($resultSet->num_rows()) >0){
				//if data already exists, jus update, updated date-time and rating 
				$arrUpdataData=array();
				$arrUpdataData['modified_on']=date('Y-m-d H:i:s');
				$arrUpdataData['rating_id']=$arrRatingDetails['rating_id'];
				$this->db->where('kol_id',$arrRatingDetails['kol_id']);
				$this->db->where('category_id',$arrRatingDetails['category_id']);
				$this->db->where('criteria_id',$arrRatingDetails['criteria_id']);
				$this->db->where('created_by',$arrRatingDetails['created_by']);
				$this->db->update('asmt_kols_rating',$arrUpdataData);
			}else{
				$this->db->insert('asmt_kols_rating',$arrRatingDetails);
			}
		}		
	}
	function getAsmtChartScore($kolId){
		$client_id = $this->session->userdata('client_id');
		$arrData	= array();
		$resultSet	= $this->db->query('SELECT temp_table.category_id as cat_id,temp_table.category_name,AVG(temp_table.total_rating) as total_cat_score,temp_table.cat_max_score,temp_table.cat_criteria_count
										FROM
										(
										SELECT asmtkr.id,asmtkr.category_id,ac.name as category_name,asmtkr.created_by,
										    sum(arca.rating_score) as total_rating,
										    max(arca.rating_score) as cat_max_score, 
											count(arca.rating_score) as cat_criteria_count 
										FROM asmt_kols_rating asmtkr
										JOIN asmt_ratings_client_association arca on arca.id=asmtkr.rating_id
										JOIN asmt_categories_client_association acca on acca.id=asmtkr.category_id
										JOIN asmt_categories ac on ac.id=acca.asmt_category_id
										    
										WHERE kol_id='.$kolId.'
										GROUP BY asmtkr.category_id,asmtkr.created_by  
										ORDER BY asmtkr.created_by ASC,asmtkr.category_id ASC
										)as temp_table
										GROUP by temp_table.category_id');
		$resultSetCri	= $this->db->query('select arules.catid,sum(arules.maxcriscore) as criteriamaxcount
											from(
											     select asmtr.category_id as catid,ac.*,max(arca.rating_score) as maxcriscore 
											    from asmt_rules asmtr
											    JOIN asmt_criteria ac on ac.id=asmtr.criteria_id
											    JOIN asmt_ratings_client_association arca on arca.id=asmtr.rating_id
											    JOIN asmt_ratings ar on arca.asmt_rating_id=ar.id
											    WHERE asmtr.client_id='.$client_id.'
											    group by asmtr.criteria_id
											) as arules
											group by arules.catid');
		$arrCriteriaMaxCount	= $resultSetCri->result_array();
		if($resultSet->num_rows()>0){
			$i	= 0;
			foreach($resultSet->result_array() as $row){
				$criteriaMaxCount			= $arrCriteriaMaxCount[$i++]['criteriamaxcount'];
				$row['percentage']			= (int)(($row['total_cat_score']/($criteriaMaxCount))*100);
				$arrData[$row['cat_id']]	= $row;
			}
		}else{
			$this->db->select('asmt_categories_client_association.id ,asmt_categories.name as category_name');
			$this->db->where('asmt_categories_client_association.client_id',$client_id);
			$this->db->join('asmt_categories','asmt_categories.id=asmt_categories_client_association.asmt_category_id','inner');
			$resultSet	= $this->db->get('asmt_categories_client_association');
			foreach($resultSet->result_array() as $row){
				$row['percentage']		= 0;
				$row['total_cat_score']	= 0;
				$arrData[$row['id']]	= $row;
			}
		}
		return $arrData;
	}
	function getKolRatings($kolId){
		$arrCriteriaRating	= array();
		$this->db->select('criteria_id,rating_id');
		$this->db->where('kol_id',$kolId);
		$resultSet	= $this->db->get('asmt_kols_rating');
		if($resultSet->num_rows()>0){
			foreach($resultSet->result_array() as $row){
				$arrCriteriaRating[$row['criteria_id']]	= $row['rating_id'];
			}
		}
		return $arrCriteriaRating;
	}
}