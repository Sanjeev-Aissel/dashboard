<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for kols from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 11-06-2018
 * @Refactored : 12-06-2018
 */
class Kol extends CI_Model {
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveKol()
	 * @param  : KOL details in array
	 * @return : last insert kol id
	 */
	function saveKol($arrKol) {
		$this->db->where('first_name', $arrKol['first_name']);
		$this->db->where('middle_name', $arrKol['middle_name']);
		$this->db->where('last_name', $arrKol['last_name']);
		$this->db->where('specialty', $arrKol['specialty']);
		$arrKolDetail = $this->db->get('kols');
	
		if ($arrKolDetail->num_rows() != 0) {
			return false;
		} else {
			if ($arrKol['org_id'] == 0 || empty($arrKol['org_id'])) {
				$arrKol['org_id'] = null;
			}
			if ($this->db->insert('kols', $arrKol)) {
				return $this->db->insert_id();
			} else {
				return false;
			}
		}
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolIdByVisibilityId()
	 * @param  : Visibility id
	 * @return : kol id
	 */
	function getKolIdByVisibilityId($id){
		$this->db->select('kol_id');
		$this->db->where('id', $id);
		$query = $this->db->get('kols_client_visibility');
		$result = $query->result_array();
		$returnId = $result[0]['kol_id'];
		return $returnId;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : updateKolInfo()
	 * @param  : KOL details in array
	 * @return : updated kols details in array
	 */
	function updateKolInfo($arrKol) {
		if ($arrKol["is_primary"] == "1" && $arrKol["title"] > 0) {
			$title_id = array('title' => $arrKol["title"]);
			$this->db->where('id', $arrKol['id']);
			$this->db->update('kols', $title_id);
		}
		$id = $arrKol['id'];
		$this->db->where('id', $id);
		$arrKol = $this->db->update('kols', $arrKol);
		
		//Client specific condition
		$analystSelectedclientId = $this->session->userdata('analyst_client');
		if(!empty($analystSelectedclientId)){
			$arrKolVisibility['kol_id'] = $id;
			$arrKolVisibility['client_id'] = $analystSelectedclientId;
			$arrKolVisibility['is_visible'] = 1;
			$arrKolVisibility['profile_type'] = null;
			
			$this->db->insert('kols_client_visibility', $arrKolVisibility);
		}
		return $arrKol;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : resetProfileImage()
	 * @return : boolean value : true | false
	 */
	function resetProfileImage($kolId) {
		$arrData['profile_image'] = '';
		$this->db->where_in('id', $kolId);
		if ($this->db->update('kols', $arrData)) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : getProcessedKols()
	 * @return : all kols associated to client
	 */
	function getProcessedKols($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = '') {
		if (!$doCount) {
			$this->db->select(array('kols.id', 'kols.pin', 'kols.is_imported', 'kols.salutation', 'kols.first_name', 'kols.middle_name', 'kols.last_name', 'kols.gender', 'specialties.specialty', 'organizations.name as org_name', 'kols.is_pubmed_processed', 'kols.is_clinical_trial_processed', 'kols.status', 'client_users.user_name as user_full_name', 'kols_client_visibility.id as vid'));
		}
		$this->db->join('client_users', 'client_users.id = kols.created_by', 'left');
		$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
		$this->db->join('organizations', 'kols.org_id = organizations.id', 'left');
		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
	
		//Add the where conditions for any jqgrid filters
		if (isset($where['kol_name'])) {
			$this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%')");
		}
		if (isset($where['specialty'])) {
			$this->db->like('specialties.specialty', $where['specialty']);
		}
		if (isset($where['gender'])) {
			$this->db->like('kols.gender', $where['gender']);
		}
		if (isset($where['organization'])) {
			$this->db->like('organizations.name', $where['organization']);
		}
		if (isset($where['pubmed_processed'])) {
			if (preg_match("/[yes]{1,}/i", $where['pubmed_processed']))
				$where['pubmed_processed'] = 1;
				elseif (preg_match("/[no]{1,}/i", $where['pubmed_processed']))
				$where['pubmed_processed'] = 0;
				elseif (preg_match("/[re crawl]{1,}/i", $where['pubmed_processed']))
				$where['pubmed_processed'] = 2;
				$this->db->like('kols.is_pubmed_processed', $where['pubmed_processed']);
		}
		if (isset($where['trial_processed'])) {
			if (preg_match("/[yes]{1,}/i", $where['trial_processed']))
				$where['trial_processed'] = 1;
				elseif (preg_match("/[no]{1,}/i", $where['trial_processed']))
				$where['trial_processed'] = 0;
				$this->db->like('kols.is_clinical_trial_processed', $where['trial_processed']);
		}
		if (isset($where['created_by'])) {
			$this->db->like('client_users.user_name', $where['created_by']);
		}
		if (isset($where['pin'])) {
			$this->db->like('kols.pin', $where['pin']);
		}
		if (isset($where['status'])) {
			$this->db->like('kols.status', $where['status']);
		}
	
		//Client specific condition
		$analystSelectedclientId = $this->session->userdata('analyst_client');
		$this->db->where('kols_client_visibility.client_id', $analystSelectedclientId);
	
		if ($doCount) {
			$count = $this->db->count_all_results('kols');
			return $count;
		} else {
			if ($sidx != '' && $sord != '') {
				switch ($sidx) {
					case 'kol_name' : $this->db->order_by("kols.first_name", $sord);
					break;
					case 'specialty' :$this->db->order_by("specialties.specialty", $sord);
					break;
					case 'gender' :$this->db->order_by("kols.gender", $sord);
					break;
					case 'organization' :$this->db->order_by("organizations.name", $sord);
					break;
					case 'pubmed_processed' :$this->db->order_by("kols.is_pubmed_processed", $sord);
					break;
					case 'trial_processed' :$this->db->order_by("kols.is_clinical_trial_processed", $sord);
					break;
					case 'created_by' :$this->db->order_by("client_users.user_name", $sord);
					break;
					case 'status' :$this->db->order_by("kols.status", $sord);
					break;
				}
			}
			$this->db->order_by('first_name', 'asc');
	
			$arrKolDetail = $this->db->get('kols', $limit, $startFrom);
			return $arrKolDetail;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolsLike1()
	 * @return : list of kols
	 */
	function getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null, $arrKolIds = null, $isFrmInfluenceMap = false, $arrQueryOptions = array(),$checkClientBasedVisibilityByClientId=0) {
		$sizeOfKeywords = sizeof($arrKeywords);
		if ($sizeOfKeywords > 0 && empty($arrKeywords[0])) {
			$sizeOfKeywords = 0;
		}
		$currentController = $this->uri->segment(1);
		$currentControllerIpad = $this->uri->segment(2);
	
		$arrKols = array();
		$client_id = $this->session->userdata('client_id');
		$user_id = $this->session->userdata('user_id');
	
		if ($doCount == false && $doGroupBy == false) {
			$this->db->select('concat(m.first_name," ",m.last_name) as modified_by, concat(c.first_name," ",c.last_name) as created_by, kols.opt_in_out_status,kols.opt_in_out_date,kols.id,kols.salutation,kols.first_name,kols.unique_id,kols.middle_name,kols.last_name,kols.gender,kols.profile_image,kols.primary_phone,kols.primary_email,kols.specialty,kols.org_id,organizations.name,specialties.specialty as specs,countries.country,states.name as state,cities.City AS city,kol_locations.latitude as lat,kol_locations.longitude as lang,cities.city,kols.profile_type, kols.request_status,kols.created_on, kols.modified_on,kols.created_by as created_by_id,kols.status', false);
			$this->db->join('client_users as c', 'c.id = kols.created_by', 'left');
			$this->db->join('client_users as m', 'm.id = kols.created_by', 'left');
			$this->db->join('kol_locations', 'kols.id = kol_locations.kol_id and kol_locations.is_primary=1', 'left');
		}
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('titles', 'titles.id = kols.title', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('country_regions', 'country_regions.country_id = countries.countryId','left');
		$this->db->join('states', 'states.id = kols.state_id', 'left');
		$this->db->join('cities', 'cities.CityId = kols.city_id', 'left');
		$this->db->select('opt_inout_statuses.name as opt_status_name');
		$this->db->join('opt_inout_statuses', 'opt_inout_statuses.id = kols.opt_in_out_status', 'left');
		if ($arrFilterFields != null && $arrFilterFields['education'] != null && isset($arrFilterFields['education']) && sizeof($arrFilterFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
			$this->db->distinct();
			$this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
			$this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
			$this->db->where_in('institutions.id', $arrFilterFields['education']);
			$this->db->where('kol_educations.type', 'education');
		}
		if ($arrFilterFields != null && $arrFilterFields['event_id'] != null && isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
			$this->db->distinct();
			$this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
			$this->db->join('events', 'kol_events.event_id = events.id', 'left');
			$this->db->where_in('kol_events.event_id', $arrFilterFields['event_id']);
		}
		if ($arrFilterFields != null && $arrFilterFields['list_id'] != null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
			$this->db->distinct();
			$this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
			$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
			$this->db->where_in('list_names.id', $arrFilterFields['list_id']);
		}
		if ($arrFilterFields != null && $arrFilterFields['type'] != null && isset($arrFilterFields['type']) && sizeof($arrFilterFields['type']) > 0 && !($doGroupBy == true && $groupByCategory == 'type')) {
			$this->db->distinct();
			$this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
			$this->db->where_in('organization_types.id', $arrFilterFields['type']);
		}
		if ($arrFilterFields != null && $arrFilterFields['title'] != null && isset($arrFilterFields['title']) && $arrFilterFields['title'] != '' && sizeof($arrFilterFields['title']) > 0 && !($doGroupBy == true && $groupByCategory == 'title')) {
			$this->db->distinct();
			$this->db->where_in('titles.id', $arrFilterFields['title']);
		}
		if ($arrFilterFields != null && $arrFilterFields['region'] != null && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region']) > 0 && !($doGroupBy == true && $groupByCategory == 'region')) {
			$this->db->distinct();
			$this->db->where_in('country_regions.region_id', $arrFilterFields['region']);
			$this->db->where('country_regions.client_id',$client_id);
		}
		if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != null && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout')) {
			$this->db->distinct();
			$this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
		}
		$keywordSearchByAutoComplete = 0;
		$keywordSearchByAutoComplete = $this->session->userdata('keywordSearchByAutoComplete');
		switch ($sizeOfKeywords) {
			case 1:
				$name = trim($arrKeywords[0]);
				$where = '(kols.first_name LIKE "%' . $name . '%" OR kols.last_name LIKE "%' . $name . '" OR kols.middle_name LIKE "%' . $name . '%")';
				if ($keywordSearchByAutoComplete) {
					$where = '(kols.first_name = "' . $name . '")';
				}
				$this->db->where($where);
				break;
			case 2:
				$name1 = trim($arrKeywords[0]);
				$name2 = trim($arrKeywords[1]);
				$where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "'))";
				if ($keywordSearchByAutoComplete) {
					$where = '((kols.first_name = "' . $name1 . '" AND kols.last_name="' . $name2 . '") or (kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '"))';
				}
				$this->db->where($where);
				break;
			case 3:
				$name1 = trim($arrKeywords[0]);
				$name2 = trim($arrKeywords[1]);
				$name3 = trim($arrKeywords[2]);
				$where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "'))";
				if ($keywordSearchByAutoComplete) {
					$where = '(kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '" AND kols.last_name="' . $name3 . '")';
				}
				$this->db->where($where);
				break;
		}
		if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
			$this->db->where_in('countries.countryId', $arrFilterFields['country']);
			if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state')) {
				$this->db->where_in('states.id', $arrFilterFields['state']);
			}
			if ($arrFilterFields != null && $arrFilterFields['city'] != '' && isset($arrFilterFields['city']) && sizeof($arrFilterFields['city']) > 0 && !($doGroupBy == true && $groupByCategory == 'city')) {
				$this->db->where_in('cities.CityId', $arrFilterFields['city']);
			}
			if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
				$this->db->where_in('organizations.id', $arrFilterFields['organization']);
			}
			if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
				$this->db->where_in('organizations.id', $arrFilterFields['organization']);
			}
			if ($arrFilterFields != null && $arrFilterFields['specialty'] != '' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty')) {
				$this->db->where_in('specialties.id', $arrFilterFields['specialty']);
			}
			if ($arrFilterFields != null && $arrFilterFields['kol_id'] != '') {
				$this->db->where_in('kols.id', $arrFilterFields['kol_id']);
			}
			if ($arrFilterFields != null && $arrFilterFields['profile_type'] != '' && $arrFilterFields['profile_type'] != "undefined") {
				$this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
			}
			if ($arrKolIds != null && isset($arrKolIds) && sizeof($arrKolIds) > 0) {
				$this->db->where_in('kols.id', $arrKolIds);
			}
			if ($arrFilterFields != null && $arrFilterFields['global_region'] != '' && isset($arrFilterFields['global_region']) && sizeof($arrFilterFields['global_region']) > 0 && !($doGroupBy == true && $groupByCategory == 'global_region'))
				$this->db->where_in('countries.GlobalRegion', $arrFilterFields['global_region']);
				if(KOL_CONSENT){
					if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != '' && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout'))
						$this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
				}
				if ($doCount) {
					if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
						$this->db->where_in('kols.status', array(COMPLETED));
					} else {
						$this->db->where('kols.customer_status', "ACTV");
					}
						
					$this->db->select('COUNT(DISTINCT kols.id) AS count');
					if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
						$this->db->where_in('kols.id', $arrFilterFields['viewType']);
					}
					if ($arrFilterFields['profile_type'] != "" && $arrFilterFields['profile_type'] != "undefined") {
						$this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
					}
					$loggedInuserClientId	= $client_id;
					if($checkClientBasedVisibilityByClientId>0){
						$loggedInuserClientId	= $checkClientBasedVisibilityByClientId;
					}
					if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
						$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
						$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
					}
					$arrKolDetailsResult = $this->db->get('kols');
					$resultRow = $arrKolDetailsResult->row();
					$count = $resultRow->count;
					return $count;
				} else {
					if ($doGroupBy) {
						if ($groupByCategory == 'country') {
							$this->db->select('kols.country_id,countries.country,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('country_id');
						}
						if ($groupByCategory == 'state') {
							$this->db->select('kols.state_id,states.name as state,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('state_id');
						}
						if ($groupByCategory == 'city') {
							$this->db->select('kols.city_id,cities.City as city,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('city_id');
						}
						if ($groupByCategory == 'specialty') {
							$this->db->select('kols.specialty,specialties.specialty as specs,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('specialty');
						}
						if ($groupByCategory == 'organization') {
							$this->db->select('organizations.id as org_id,organizations.name,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('organizations.id');
						}
						if ($groupByCategory == 'education') {
							$this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name,kol_educations.institute_id');
							$this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
							$this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
							$this->db->where('kol_educations.type', 'education');
							$this->db->where('institutions.id > 0');
							$this->db->group_by('kol_educations.institute_id');
						}
						if ($groupByCategory == 'event') {
							$this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name,kol_events.event_id as event_id');
							$this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
							$this->db->join('events', 'kol_events.event_id = events.id', 'left');
							$this->db->where('events.id > 0');
							$this->db->group_by('kol_events.event_id');
						}
						if ($groupByCategory == 'list') {
							$this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(DISTINCT kols.id) AS count');
							$this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
							$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
							$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
							$this->db->where('list_categories.client_id', $client_id);
							$where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
							$this->db->where($where);
							$this->db->group_by('list_kols.list_name_id');
						}
						if ($groupByCategory == 'global_region') {
						}
	
						if ($groupByCategory == 'type') {
							$this->db->select('organization_types.type,organization_types.id as org_type_id,COUNT(DISTINCT kols.id) as count');
							$this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
							$this->db->group_by('organization_types.id');
						}
	
						if ($groupByCategory == 'title') {
							$this->db->select('titles.title,titles.id as title_id,COUNT(DISTINCT kols.id) as count');
							$this->db->group_by('titles.id');
						}
	
						if ($groupByCategory == 'region') {
							$this->db->select('regions.name as global_region_name,regions.id as global_region_id,COUNT(DISTINCT kols.id) as count');
							$this->db->join('regions','country_regions.region_id=regions.id', 'left');
							$this->db->group_by('regions.id');
						}
						if(KOL_CONSENT){
							if ($groupByCategory == 'opt_inout') {
								$this->db->select('opt_inout_statuses.name as opt_name, opt_inout_statuses.id as opt_in_out_id,COUNT(DISTINCT kols.id) as count');
								$this->db->where('kols.opt_in_out_status !=', 0);
								$this->db->group_by('opt_inout_statuses.name');
							}
						}
						$this->db->order_by('count', 'desc');
					} else {
						if (!$isFrmInfluenceMap)
							$this->db->limit($limit, $startFrom);
					}
					if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
					} else {
						$this->db->where('kols.customer_status', "ACTV");
					}
					if ($arrFilterFields['profile_type'] != "" && $arrFilterFields['profile_type'] != "undefined") {
						$this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
					}
					if (sizeof($arrQueryOptions) > 0) {
						switch ($arrQueryOptions['sort_by']) {
							case 'name':
								if ($this->session->userdata('name_order') == 2) {
									$this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
								} else {
									$this->db->order_by('kols.first_name', $arrQueryOptions['sort_order']);
									$this->db->order_by('kols.middle_name', $arrQueryOptions['sort_order']);
									$this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
								}
								break;
							case 'specialty':$this->db->order_by('specialties.specialty', $arrQueryOptions['sort_order']);
							break;
							case 'state':$this->db->order_by('states.name', $arrQueryOptions['sort_order']);
							break;
							case 'city':$this->db->order_by('cities.City', $arrQueryOptions['sort_order']);
							break;
							case 'country':$this->db->order_by('countries.country', $arrQueryOptions['sort_order']);
							break;
							case 'opt_status':$this->db->order_by('kols.opt_in_out_status', $arrQueryOptions['sort_order']);
							break;
						}
					} else if (!$doGroupBy) {
						if ($this->session->userdata('name_order') == 2) {
							$this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
						} else {
							$this->db->order_by('kols.first_name');
						}
					}
					if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
						$this->db->where_in('kols.id', $arrFilterFields['viewType']);
					}
					$loggedInuserClientId	= $client_id;
					if($checkClientBasedVisibilityByClientId>0){
						$loggedInuserClientId	= $checkClientBasedVisibilityByClientId;
					}
					if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
						$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
						$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
					}
					$arrKolDetailsResult = $this->db->get('kols');
					foreach ($arrKolDetailsResult->result_array() as $row) {
						$arrKols[] = $row;
					}
					return $arrKols;
				}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateStatus()
	 * @return : return true on update, false on update failure
	 */
	function updateStatus($arrKolId) {
		$arr['status'] = $arrKolId['status'];
		$arr['modified_by'] = $arrKolId['modified_by'];
		$arr['modified_on'] = date("Y-m-d H:i:s");
		$this->db->where_in('id', $arrKolId['kolId']);
	
		if ($this->db->update('kols', $arr)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : editKol()
	 * @Param  : kol visibility id
	 * @return : return kol details
	 */
	function editKol($id) {
		$arrKolDetails = array();
		$this->db->select('kols.*, titles.title as title_name, specialties.specialty as specialty_name, degrees.degree,kol_locations.private_practice,kol_locations.latitude,kol_locations.longitude, kols_client_visibility.id as vid');
		$this->db->where('kols_client_visibility.id', $id);
		//$this->db->where('kol_locations.is_primary', '1');
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
		$this->db->join('degrees', 'kols.degree_id = degrees.id', 'left');
		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('kol_locations', 'kols_client_visibility.id = kol_locations.kol_id and kol_locations.is_primary = 1', 'left',false);
		if ($arrKolDetailResult = $this->db->get('kols')) {
			// If the results are not available
			if ($arrKolDetailResult->num_rows() == 0) {
				return false;
			}
			foreach ($arrKolDetailResult->result_array() as $arrKol){
				$arrKolDetails = $arrKol;
				if (is_numeric($arrKolDetails['title']))
					$arrKolDetails['title_id'] = $arrKolDetails['title'];
					$arrKolDetails['title'] = $arrKolDetails['title_name'];
			}
			return $arrKolDetails;
		}else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgId()
	 * @Param  : org id
	 * @return : return org name
	 */
	function getOrgId($orgId) {
		$name = '';
		$this->db->where('id', $orgId);
		$result = $this->db->get('organizations');
		foreach ($result->result_array() as $row) {
			$name = $row['name'];
		}
		return $name;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgName()
	 * @Param  : org name
	 * @return : return org id
	 */
	function getOrgName($orgName) {
		$id = '';
		$this->db->where('name', $orgName);
		$result = $this->db->get('organizations');
		foreach ($result->result_array() as $row) {
			$id = $row['id'];
		}
		return $id;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : listContacts()
	 * @Param  : kol visibility id
	 * @return : return array of contact details for kol
	 */
	function listContacts($kolId = null) {
		$arrContactDetails = array();
		if ($kolId != null) {
			$this->db->where('kol_id', $kolId);
		}
		if ($arrContactDetailsResult = $this->db->get('kol_additional_contacts')) {
			if ($arrContactDetailsResult->num_rows() == 0) {
				return false;
			}
			foreach ($arrContactDetailsResult->result_array() as $row) {
				$arrContactDetails[] = $row;
			}
			return $arrContactDetails;
		}else{
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveTitle()
	 * @Param  : titles
	 * @return : returns (last inserted id) or (existing title id)
	 */
	function saveTitle($tit) {
		$get = $this->db->get_where("titles",array("title"=>$tit));
		if($get->num_rows()==0){
			$this->db->insert("titles",array("title"=>$tit,"is_active"=>1,"abbr"=>' ',"client_id"=>INTERNAL_CLIENT_ID));
			return $this->db->insert_id();
		}
		return $get->row()->id;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateKol()
	 * @Param  : $arrKol
	 * @return : returns updated kol details
	 */
	function updateKol($arrKol) {
		if ($arrKol["is_primary"] == "1" && $arrKol["title"] > 0) {
			$title_id = array('title' => $arrKol["title"]);
			$this->db->where('id', $arrKol['id']);
			$this->db->update('kols', $title_id);
		}
		$id = $arrKol['id'];
		$this->db->where('id', $id);
		$arrKol = $this->db->update('kols', $arrKol);
		return $arrKol;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateKolLocationLatitudeLongitude()
	 * @Param  : $arrKolLatLongData
	 * @return : returns true on update and false on failure
	 */
	function updateKolLocationLatitudeLongitude($arrKolLatLongData){
		$this->db->where('kol_id', $arrKolLatLongData['kol_id']);
		$this->db->where('is_primary', 1);
		if ($this->db->update('kol_locations', $arrKolLatLongData)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveContact()
	 * @Param  : $contactDetails
	 * @return : returns last inserted and false on failure
	 */
	function saveContact($contactDetails) {
		if ($this->db->insert('kol_additional_contacts', $contactDetails)) {
			return $this->db->insert_id();
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateContact()
	 * @Param  : $contactDetails
	 * @return : returns true on update and false on failure
	 */
	function updateContact($contactDetails) {
		$this->db->where('id', $contactDetails['id']);
		if ($this->db->update('kol_additional_contacts', $contactDetails)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : deleteContactById()
	 * @Param  : $id
	 * @return : returns true on delete and false on failure
	 */
	function deleteContactById($id) {
	
		$this->db->where('id', $id);
		if ($query = $this->db->delete('kol_additional_contacts')) {
			return true;
		} else
			return false;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllActiveTitles()
	 * @Param  : $listAll set as null
	 * @return : returns array of titles
	 */
	function getAllActiveTitles($listAll='') {
		$client_id = $this->session->userdata('client_id');
		$this->db->select('titles.*');
		$this->db->where('is_active', 1);
		$this->db->group_by('title');
		$this->db->order_by('title', 'asc');
		$this->db->order_by('id', 'asc');
		if ($client_id != INTERNAL_CLIENT_ID  && $this->session->userdata('user_role_id') != ROLE_ADMIN)
			$this->db->where('client_id', $client_id);
			$res = $this->db->get('titles');
			return $res->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : listLocationDetails()
	 * @Param  : $kolId
	 * @return : array of locations associated with kol id
	 */
	function listLocationDetails($kolId) {
		$this->db->select('kol_locations.id, concat(COALESCE(kol_locations.address1,""), ", ", COALESCE(kol_locations.address2,""), ", ", COALESCE(kol_locations.address3,"")) as address, organizations.name as org_name,organization_types.type as org_type, cities.City as city,states.name as state,kol_locations.postal_code,kol_locations.is_primary,kol_locations.address_type,kol_locations.private_practice,kol_locations.created_by,kol_locations.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name', false);
		$this->db->where('kol_id', $kolId);
		$this->db->join('client_users', 'kol_locations.created_by = client_users.id','left');
		$this->db->join('states', 'kol_locations.state_id = states.id', 'left');
		$this->db->join('organizations', 'kol_locations.org_institution_id = organizations.id', 'left');
		$this->db->join('organization_types', 'organizations.type_id = organization_types.id', 'left');
		$this->db->join('cities', 'kol_locations.city_id = cities.CityId', 'left');
		$this->db->order_by('is_primary', "DESC");
		$res = $this->db->get('kol_locations');
		return $res->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolLocationByOrgInstId()
	 * @Param  : $arrLocation
	 * @return : row id
	 */
	function getKolLocationByOrgInstId($arrLocation){
		$data = '';
		$this->db->where('org_institution_id', $arrLocation['org_institution_id']);
		$this->db->where('kol_id', $arrLocation['kol_id']);
		$query = $this->db->get('kol_locations');
		if ($query->num_rows() > 0) {
			$rowInfo = $query->row();
			$data = $rowInfo->id;
			return $data;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : checkCityIfExistElseAdd()
	 * @Param  : $city,$stateId,$country
	 * @return : if exists city id / inserted id in cities table
	 */
	function checkCityIfExistElseAdd($city,$stateId,$country){
		$this->db->select('CityId');
		$this->db->where('city',$city);
		$this->db->limit(1);
		$query = $this->db->get('cities');
		$result = $query->result_array();
	
		if($result['0']['CityId'] == ""){
			$data = array(
					'CountryID' => $country,
					'RegionID' => $stateId,
					'City'	=>	$city
			);
			$this->db->insert('cities', $data);
			return $this->db->insert_id();
		}else{
			return $result['0']['CityId'];
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveLocation()
	 * @Param  : $arrLocation
	 * @return : row id
	 */
	function saveLocation($arrLocation) {
		if (isset($arrLocation['id'])) {
			$id = $arrLocation['id'];
			unset($arrLocation['id']);
				
			if ($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('kol_id', $arrLocation['kol_id']);
				$this->db->update('kol_locations', $primary_flag);
			}
			if ($arrLocation["is_primary"] == "1" && $arrLocation["title"] > 0 && $arrLocation["division"] > 0) {
				$title_id = array('title' => $arrLocation["title"],'division' => $arrLocation["division"]);
				$this->db->where('id', $arrLocation['kol_id']);
				$this->db->update('kols', $title_id);
			}
				
			$this->db->where('id', $id);
			if ($this->db->update('kol_locations', $arrLocation)) {
				return true;
			} else {
				return false;
			}
		} else {
			$dataType = 'User Added';
			$client_id =$this->session->userdata('client_id');
			if($client_id == INTERNAL_CLIENT_ID){
				$dataType = 'Aissel Analyst';
			}
			$arrLocation['data_type_indicator'] = $dataType;
			if ($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('kol_id', $arrLocation['kol_id']);
				$this->db->update('kol_locations', $primary_flag);
			}
			if ($arrLocation["is_primary"] == "1" && $arrLocation["title"] > 0 && $arrLocation["division"] > 0) {
				$title_id = array('title' => $arrLocation["title"],'division' => $arrLocation["division"]);
				$this->db->where('id', $arrLocation['kol_id']);
				$this->db->update('kols', $title_id);
			}
			if ($this->db->insert('kol_locations', $arrLocation)) {
				return $this->db->insert_id();
			} else {
				return false;
			}
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : deleteLocation()
	 * @Param  : $arrPhoneData
	 * @return : returns true : deleted | false : not deleted
	 */
	function deleteLocation(){
		
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getPhones()
	 * @Param  : $id, $type
	 * @return :  array of phone associated with kol id
	 */
	function getPhones($id, $type) {
		$this->db->select('organizations.name,phone_numbers.*,kol_locations.address1,phone_type.name as phone_type,phone_numbers.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		//            $this->db->where('contact',$id);
		//            $this->db->where('contact_type',$type);
		if ($type == 'location') {
			$this->db->where('location_id', $id);
		}
		if ($type == 'kol') {
			$this->db->where('phone_numbers.contact', $id);
			$this->db->where('contact_type !=', 'organization');
		}
		$this->db->join('client_users', 'phone_numbers.created_by = client_users.id','left');
		$this->db->join("phone_type", "phone_type.id = phone_numbers.type", "left");
		$this->db->join('kol_locations', 'kol_locations.id = phone_numbers.location_id', 'left');
		$this->db->join('organizations', 'organizations.id = kol_locations.org_institution_id', 'left');
		$res = $this->db->get('phone_numbers');
		$arrData = array();
		foreach ($res->result_array() as $row) {
			if ($row['name'] == '')
				$row['name'] = $row['address1'];
	
				$arrData[] = $row;
		}
		//print $this->db->last_query();
		//exit();
		return $arrData;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : savePhone()
	 * @Param  : $arrPhoneData
	 * @return : last inserted id in phone_number table
	 */
	function savePhone($arrPhoneData) {
		if ($arrPhoneData['is_primary'] == "1") {
			$this->db->where('contact', $arrPhoneData['contact']);
			//                $this->db->where('contact_type',$arrPhoneData['contact_type']);
			$this->db->update('phone_numbers', array('is_primary' => "0"));
	
			if ($arrPhoneData['contact_type'] == "kol") {
				$this->db->where('id', $arrPhoneData['contact']);
				$this->db->update('kols', array('primary_phone' => $arrPhoneData['number']));
			}
			if ($arrPhoneData['contact_type'] == "organization") {
				$this->db->where('id', $arrPhoneData['contact']);
				$this->db->update('organizations', array('phone' => $arrPhoneData['number']));
			}
		}
		if ($this->db->insert('phone_numbers', $arrPhoneData)) {
			return $this->db->insert_id();
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : insertOrUpdatePhoneNumber()
	 * @Param  : $arrPhoneData
	 * @return : insert or update phone data
	 */
	function insertOrUpdatePhoneNumber($arrPhoneData){
		$id=$arrPhoneData['id'];
		$data['status'] = false;
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrData['type'] = trim($arrPhoneData['phone_type']);
		$arrData['number'] = trim($arrPhoneData['phone_number']);
		$arrData['contact_type'] = trim($arrPhoneData['contact_type']);
		$arrData['contact'] = trim($arrPhoneData['contact']);
		$arrData['is_primary'] = (trim($arrPhoneData['phone_is_primary']) == "on") ? "1" : "0";
		$arrData['modified_by'] =$user_id;
		$arrData['modified_on'] = date('Y-m-d H:i:s');
		$arrData['location_id'] = trim($arrPhoneData['phone_location']);
		$arrData['data_type_indicator'] = $dataType;
		if($arrData['is_primary'] == 1){
			$data['details'] = $arrData;
		}else{
			$data['details'] = '';
		}
		if ($arrData['is_primary'] == "1") {
			$this->db->where('contact', $arrData['contact']);
			$this->db->update('phone_numbers', array('is_primary' => "0"));
				
			if ($arrData['contact_type'] == "kol") {
				$this->db->where('id', $arrData['contact']);
				$this->db->update('kols', array('primary_phone' => $arrData['number']));
			}
			if ($arrData['contact_type'] == "organization") {
				$this->db->where('id', $arrData['contact']);
				$this->db->update('organizations', array('phone' => $arrData['number']));
			}
		}
		if ($id != "" || $id != null) {
			$this->db->where('id', $id);
			if ($this->db->update('phone_numbers', $arrData)) {
				$data['status'] = true;
			} else {
				$data['status'] = false;
			}
		} else {
			$arrData['created_by'] = $user_id;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			if ($this->db->insert('phone_numbers', $arrData)) {
				$lastPhoneId =$this->db->insert_id();
			} else {
				$lastPhoneId =false;
			}
			if ($lastPhoneId) {
				$data['status'] = true;
				$data['id'] = $lastPhoneId;
			}
		}
		return $data;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : deletePhone()
	 * @Param  : phone id
	 * @return : returns true : deleted | false : not deleted
	 */
	function deletePhone(){
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getStaffs()
	 * @Param  : $id, $type
	 * @return : array of staffs associated with kol id
	 */
	function getStaffs($id, $type) {
		$this->db->select('organizations.name as loc_name,staffs.*,kol_locations.address1,staff_title.name as staff_title,phone_type.name as phone_type,staffs.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		//            $this->db->where('contact',$id);
		//            $this->db->where('contact_type',$type);
		if ($type == 'location') {
			$this->db->where('location_id', $id);
		}
		if ($type == 'kol') {
			$this->db->where('staffs.contact', $id);
			$this->db->where('contact_type !=', 'organization');
		}
		//			$this->db->where('location_id',$id);
		$this->db->join('client_users', 'staffs.created_by = client_users.id','left');
		$this->db->join("staff_title", "staff_title.id = staffs.title", "left");
		$this->db->join("phone_type", "phone_type.id = staffs.phone_type", "left");
		$this->db->join('kol_locations', 'kol_locations.id = staffs.location_id', 'left');
		$this->db->join('organizations', 'organizations.id = kol_locations.org_institution_id', 'left');
		$res = $this->db->get('staffs');
		$arrData = array();
		foreach ($res->result_array() as $row) {
			if ($row['loc_name'] == '')
				$row['loc_name'] = $row['address1'];
	
				$arrData[] = $row;
		}
		return $arrData;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : insertOrUpdateStaff()
	 * @Param  : $arrStaffData
	 * @return : insert or update staff data
	 */
	function insertOrUpdateStaff($arrStaffData){
		$id=$arrStaffData['id'];
		$data['status'] = false;
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrData['title'] = trim($arrStaffData['staff_title']);
		$arrData['name'] = trim($arrStaffData['staff_name']);
		$arrData['phone_number'] = trim($arrStaffData['staff_phone']);
		$arrData['phone_type'] = trim($arrStaffData['phone_type']);
		$arrData['email'] = trim($arrStaffData['email']);
		$arrData['contact_type'] = trim($arrStaffData['contact_type']);
		$arrData['contact'] = trim($arrStaffData['contact']);
		$arrData['modified_by'] = $user_id;
		$arrData['modified_on'] = date('Y-m-d H:i:s');
		$arrData['location_id'] = trim($arrStaffData['staff_location']);
		$arrData['data_type_indicator'] = $dataType;
		if ($id >0) {
			$this->db->where('id', $id);
			if ($this->db->update('staffs', $arrData)) {
				$data['status'] = true;
			}
		}else{
			$arrData['created_by'] =$user_id;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			if ($this->db->insert('staffs', $arrData)) {
				$lastStaffId = $this->db->insert_id();
			}
			if ($lastStaffId) {
				$data['status'] = true;
				$data['id'] = $lastStaffId;
			}
		}
		return $data;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getEmails()
	 * @Param  : $id
	 * @return : array of emails associated with kol id
	 */
	function getEmails($id) {
		$this->db->select('emails.*,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('client_users', 'emails.created_by = client_users.id','left');
		$this->db->where('emails.contact', $id);
		$res = $this->db->get('emails');
		return $res->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : insertOrUpdateEmail()
	 * @Param  : $arrEmailData
	 * @return : insert or update email data
	 */
	function insertOrUpdateEmail($arrEmailData){
		$id=$arrEmailData['id'];
		$data['status'] = false;
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$data=array();
		$arrData['type'] = trim($arrEmailData['email_type']);
		$arrData['email'] = trim($arrEmailData['email']);
		if (trim($arrEmailData['email_is_primary']) == "on"){
			$arrData['is_primary'] = 1;
			$data['details'] = $arrData['email'];
		}else{
			$arrData['is_primary'] = 0;
			$data['details'] = '';
		}
		$arrData['contact'] = trim($arrEmailData['contact']);
		$arrData['contact_type'] = trim($arrEmailData['contact_type']);
		$arrData['modified_by'] = $user_id;
		$arrData['modified_on'] = date('Y-m-d H:i:s');
		$arrData['data_type_indicator'] = $dataType;
	
		$contact_type = $arrData['contact_type'];
		unset($arrData['contact_type']);
		if ($arrData['is_primary'] == "1") {
			$this->db->where('contact', $arrData['contact']);
			$this->db->update('emails', array('is_primary' => "0"));
			if($contact_type == "kol") {
				$this->db->where('id', $arrData['contact']);
				$this->db->update('kols', array('primary_email' => $arrData['email']));
			}
		}
		if ($id>0) {
			$this->db->where('id', $id);
			if($this->db->update('emails', $arrData)){
				$data['status']=true;
			}
		} else {
			$arrData['created_by'] = $user_id;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			if ($this->db->insert('emails', $arrData)) {
				$lastEmailId = $this->db->insert_id();
			} else {
				$lastEmailId = false;
			}
			if ($lastEmailId) {
				$data['status'] = true;
				$data['id'] = $lastEmailId;
			}
		}
		return $data;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getStateLicences()
	 * @Param  : $id
	 * @return : array of staff associated with kol id
	 */
	function getStateLicences($id) {
		$this->db->select('state_licenses.*,states.name as state_name,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('client_users', 'state_licenses.created_by = client_users.id','left');
		$this->db->join('states', 'states.id = state_licenses.region', 'left');
		$this->db->where('state_licenses.contact', $id);
		$res = $this->db->get('state_licenses');
		return $res->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : insertOrUpdateStateLicense()
	 * @Param  : $arrLicenseData
	 * @return : insert or update state licnese data
	 */
	function insertOrUpdateStateLicense($arrLicenseData){
		$id=$arrLicenseData['id'];
		$data['status'] = false;
		$dataType = 'User Added';
		$client_id 		=$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrData['state_license'] = $arrLicenseData['state_license_number'];
		$arrData['region'] = $arrLicenseData['state_id'];
		$arrData['country_id'] = $arrLicenseData['country_id'];
		$arrData['contact'] = $arrLicenseData['contact'];
		$arrData['modified_by'] = $user_id;
		$arrData['modified_on'] = date('Y-m-d H:i:s');
		if (trim($arrLicenseData['license_is_primary']) == "on")
			$arrData['is_primary'] = 1;
			else
				$arrData['is_primary'] = 0;
				$arrData['data_type_indicator'] = $dataType;
				if ($arrData['is_primary'] == "1") {
					$this->db->where('contact', $arrData['contact']);
					$this->db->update('state_licenses', array('is_primary' => "0"));
					$this->db->where('id', $arrData['contact']);
					$this->db->update('kols', array('license' => $arrData['state_license']));
				}
				if ($id>0) {
					$this->db->where('id', $id);
					if ($this->db->update('state_licenses', $arrData)) {
						$data['status']=true;
					}
				}else{
					$arrData['created_by'] = $user_id;
					$arrData['created_on'] = date('Y-m-d H:i:s');
					$lastLicenseId=$this->db->insert('state_licenses', $arrData);
					if ($lastLicenseId) {
						$data['status'] = true;
						//$data['id'] = $lastLicenseId;
					}
				}
				return $data;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getStateLicences()
	 * @Param  : $kolid
	 * @return : array of users associated with kol id
	 */
	function getAssignedUsers($kolId){
		$clientId = $this->session->userdata('client_id');
		$this->db->select("user_kols.id,user_kols.user_id,user_kols.data_type_indicator,client_created_by.client_id,CONCAT(client_users.first_name,' ',client_users.last_name) AS name,client_users.email,kol_user_conatct_type.name as type,CONCAT(client_created_by.first_name,' ',client_created_by.last_name) as created_by",false);
		$this->db->join('client_users','client_users.id=user_kols.user_id');
		$this->db->join('client_users as client_created_by','client_created_by.id=user_kols.created_by');
		$this->db->join('kols','kols.id = user_kols.kol_id','left');
		$this->db->join('kol_user_conatct_type','kol_user_conatct_type.id=user_kols.type','left');
		$this->db->where('user_kols.kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		$arrResult = $this->db->get('user_kols');
		return $arrResult->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : insertOrUpdateAssignClient()
	 * @Param  : $arrAssignData
	 * @return : insert or update user kol align data
	 */
	function insertOrUpdateAssignClient($arrAssignData){
		$id=$arrAssignData['id'];
		$data['status'] = false;
		$dataType 		= 'User Added';
		$client_id 		=$this->session->userdata('client_id');
		$user_id 		=$this->session->userdata('user_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$arrData['user_id'] = $arrAssignData['client'];
		$arrData['kol_id'] 	=  $arrAssignData['kol_id'];
		$arrData['type'] 	= $arrAssignData['client_type'];
		if ($id >0) {
			$arrData['modified_by'] =$user_id;
			$arrData['modified_on'] = date('Y-m-d H:i:s');
			$this->db->where('id',$id);
			if ($this->db->update('user_kols',$arrData)){
				$data['status'] =true;
			}
		}else{
			$arrData['created_by'] = $user_id;
			$arrData['created_on'] = date('Y-m-d H:i:s');
			$arrData['data_type_indicator'] = $dataType;
			$lastAssignId = $this->db->insert('user_kols',$arrData);
			if($lastAssignId){
				$data['status'] = true;
				//$data['id'] = $lastAssignId;
			}
		}
		return $data;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllInstituteNames()
	 * @Param  : null
	 * @return : array	- ID, and InstituteNames
	 */
	function getAllInstituteNames() {
		$arrAllInstituteNames = array();
	
		$arrInstituteNamesResult = $this->db->get('institutions');
		foreach ($arrInstituteNamesResult->result_array() as $arrInstituteName) {
			$arrAllInstituteNames[$arrInstituteName['id']] = $arrInstituteName['name'];
		}
		return $arrAllInstituteNames;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getInstituteId()
	 * @Param  : $name
	 * @return : institution id
	 */
	function getInstituteId($name = null) {
		if ($name != null) {
			$this->db->select('id');
			$this->db->where('name', $name);
			$arrResultSet = $this->db->get('institutions');
	
			if ($arrResultSet->num_rows() == 0) {
				return false;
			}
			$arrInstituteId = array();
			foreach ($arrResultSet->result_array() as $arrRow) {
				return $arrRow['id'];
			}
	
			return $arrInstituteId;
		} else
			return false;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : listEducationDetails()
	 * @Param  : $type, $kolId
	 * @return : array	education details
	 */
	function listEducationDetails($type, $kolId = null) {
		$clientId = $this->session->userdata('client_id');
		$arrEducationDetails = array();
		//Get the Events of KolId
		if ($kolId != null) {
			$this->db->where('kol_id', $kolId);
			if ($type != 'all') {
				$this->db->where('type', $type);
			}else{
				$this->db->where('type !=', 'honors_awards');
			}
			//if ($type != 'honors_awards') {
			$this->db->select(array('kol_educations.*', 'institutions.name','client_users.first_name','client_users.last_name'));
			$this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
			$this->db->join('client_users', 'client_users.id = kol_educations.created_by', 'left');
			//}
		}
		if ($clientId != INTERNAL_CLIENT_ID) {
			$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=" . INTERNAL_CLIENT_ID . ")");
		}
		$this->db->order_by('kol_educations.start_date','desc');
	
		if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
			foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
				if ($type != 'honors_awards') {
					$arrEducation['institute_id'] = $arrEducation['name'];
				}
				if ($arrEducation['url1'] != '') {
					$arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
				}
				if ($arrEducation['url2'] != '') {
					$arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
				}
				$arrEducation['eAllowed'] = $this->common_helper->isActionAllowed('kol_details', 'edit', $arrEducation);
				$arrEducationDetails[] = $arrEducation;
			}
			return $arrEducationDetails;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveEducationDetail()
	 * @Param  : $educationDetails
	 * @return : true : last inserted data | false : failure
	 */
	function saveEducationDetail($educationDetails) {
		if ($this->db->insert('kol_educations', $educationDetails)) {
			return $this->db->insert_id();
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getEducationById()
	 * @Param  : $educationId
	 * @return : array of EducationDetails
	 */
	function getEducationById($educationId) {
		$arrEducationDetails = array();
		$clientId = $this->session->userdata('client_id');
		$this->db->where('kol_educations.id', $educationId);
		$this->db->select(array('kol_educations.*', 'institutions.name','institutions.id as institutionsId','client_users.first_name','client_users.last_name'));
		$this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
		$this->db->join('client_users', 'client_users.id = kol_educations.created_by', 'left');
		if ($clientId != INTERNAL_CLIENT_ID) {
			//$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$arrEducationDetailsResult = $this->db->get('kol_educations');
		foreach ($arrEducationDetailsResult->result_array() as $arrRow) {
			$arrEducationDetails = $arrRow;
		}
		return $arrEducationDetails;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateEducationDetail()
	 * @Param  : $educationDetails
	 * @return : true : update | false : failure
	 */
	function updateEducationDetail($educationDetails) {
		$result = array();
		$this->db->where('id', $educationDetails['id']);
		if ($this->db->update('kol_educations', $educationDetails)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getInstituteName()
	 * @Param  : inst id
	 * @return : inst names
	 */
	function getInstituteName($id) {
		$instituteName = '';
		$this->db->select('name');
		$this->db->where('id', $id);
		$instituteName = $this->db->get('institutions');
		foreach ($instituteName->result_array() as $row) {
			$instituteName = $row['name'];
		}
		return $instituteName;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getInstituteNameById()
	 * @Param  : array of inst id's
	 * @return : array of inst names
	 */
	function getInstituteNameById($arrId) {
		$instituteName = array();
		$arrayIds = array();
		if(!empty($arrId)){
			foreach($arrId as $key=>$value){
				if(is_numeric($value)){
					$arrayIds[$key] =  $value;
				}
			}
			$this->db->select('id,name');
			$this->db->where_in('id', $arrayIds);
			$resultSet = $this->db->get('institutions');
			foreach ($resultSet->result_array() as $row) {
				$instituteName[$row['id']] = $row['name'];
			}
		}
		return $instituteName;
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : getTopicsBySpecialty()
	 * @Param  : $specialtyId
	 * @return : array of topics
	 */
	function getTopicsBySpecialty($specialtyId) {
		$arrTopics = array();
		$this->db->where('specialty_id', $specialtyId);
		$this->db->order_by("name", "asc");
		$result = $this->db->get('event_topics');
		foreach ($result->result_array() as $row) {
			$arrTopics[$row['id']] = $row;
		}
		return $arrTopics;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getEventRoles()
	 * @Param  : none
	 * @return : array of event roles
	 */
	function getEventRoles() {
		$this->db->order_by('role asc');
		$arrResultSet = $this->db->get('event_roles');
		foreach ($arrResultSet->result_array() as $row) {
				
			$arrRoles[$row['id']] = $row['role'];
		}
		return $arrRoles;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : listAll()
	 * @Param  : none
	 * @return : array of requested users
	 */
	function listAll(){
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		//$this->db->select('user_requests.*,client_users.*,kols.salutation,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name');
		$this->db->select('user_requests.status,user_requests.request_for,user_requests.comments,user_requests.is_re_request,user_requests.profile_type,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_requests.id,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,client_users.user_name as user_full_name,organizations.name,countries.country, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,user_requests.requested_on,user_requests.rej_or_appr_on');
		$this->db->join('client_users','client_users.id = user_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_requests.rej_or_appr_by','left');
		$this->db->join('kols','kols.id = user_requests.kol_id','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		if($clientId != INTERNAL_CLIENT_ID)
			$this->db->where('client_users.client_id',$clientId);
			$this->db->order_by("user_requests.rej_or_appr_on","desc");
			$results = $this->db->get('user_requests');
			//echo $this->db->last_query();
			if(is_object($results) && $results->num_rows() > 0)
				$arrResults = $results->result_array();
				return $arrResults;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get()
	 * @Param  : $id, $idType
	 * @return : $rowData
	 */
	function get($id, $idType = false){
		$rowData = array();
		//Flag is set to differentiate KolId and userRequestId
		if($idType == 'userRequestId'){
			$this->db->where('id',$id);
		}else{
			$this->db->where('kol_id',$id);
		}
		$results = $this->db->get('user_requests');
		if($results->num_rows() > 0)
			$rowData = $results->row_array();
	
			return $rowData;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : update()
	 * @Param  : $rowData
	 * @return : returns true :update | false: failure
	 */
	function update($rowData){
		$this->db->where('id',$rowData['id']);
		if($this->db->update('user_requests',$rowData))
			return true;
			else
				return false;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getUserEmailId()
	 * @Param  : $userId
	 * @return : returns email id of associated users
	 */
	function getUserEmailId($userId){
		$email = '';
		$this->db->select('email');
		$this->db->where('id',$userId);
		//	$this->db->where('user_role_id',2);
		$emailResultSet = $this->db->get('client_users');
		foreach($emailResultSet->result_array() as $row){
			$email=$row['email'];
		}
		return $email;
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getUserManagerEmailId()
	 * @Param  : $userId
	 * @return : returns email id of associated managers
	 */
	function getUserManagerEmailId($userId){
		$emaiId = $userId;
		$arrUserIds	= array();
		if(!is_array($userId)){
			$arrUserIds[]	= $userId;
		}
		$this->db->select('managers.email');
		$this->db->where_in('client_users.id',$arrUserIds);
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->join('client_users as managers','managers.id = client_users.manager_id');
		$results = $this->db->get('client_users');
		if($results->num_rows() > 0){
			$row = $results->row_array();
			$emaiId = $row['email'];
		}
		return $emaiId;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getNonProfiledKols()
	 * @Param  : $profileStatus ,$clientId,$limit,$startFrom,$doCount,$sidx,$sord,$where 
	 * @return : returns email id of associated managers
	 */
	function getNonProfiledKols($profileStatus ,$clientId,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		$arrKols = array();
		$this->db->select('countries.country,kols.salutation,kols.primary_email,kols.address1,kols.primary_phone,specialties.specialty,organizations.name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.created_by,client_users.id,client_users.email,client_users.user_role_id,client_users.client_id,,client_users.first_name as user_full_name,kols.status');
		$this->db->join('client_users','client_users.id=kols.created_by','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('specialties','specialties.id=kols.specialty','left');
		if(is_array($profileStatus)){
			$this->db->where_in("kols.status",$profileStatus);
		}else{
			$this->db->where("(kols.status='".$profileStatus ."' or kols.status='".REJECT."')");
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(client_users.client_id=$clientId or client_users.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if(!empty($where)){
			if(isset($where['kol_name'])){
				$this->db->where("(kols.first_name LIKE '%".$where['kol_name']."%' or kols.middle_name LIKE '%".$where['kol_name']."%' or kols.last_name LIKE '%".$where['kol_name']."%')");
			}
			if(isset($where['name']))
				$this->db->like('organizations.name',$where['name']);
				if(isset($where['specialty']))
					$this->db->like('specialties.specialty',$where['specialty']);
					if(isset($where['country']))
						$this->db->like('countries.Country',$where['country']);
						if(isset($where['primary_phone']))
							$this->db->like('kols.primary_phone',$where['primary_phone']);
							if(isset($where['primary_email']))
								$this->db->like('kols.primary_email',$where['primary_email']);
								if(isset($where['user_full_name'])){
									$cliId = INTERNAL_CLIENT_ID;
									$whereUsername	= "(concat(client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%' or (concat('Aissel Analyst',' ',client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%') AND client_users.client_id=".$cliId.")";
									$this->db->where($whereUsername);
								}
								if(isset($where['status'])){
									$str = $where['status'];
									if (preg_match("/$str/i","Requested")) {
										$this->db->where("(kols.status LIKE '%New%' OR kols.status LIKE '%".$where['status']."%')");
									}else if (preg_match("/$str/i","New")){
										$this->db->where("(kols.status NOT LIKE '%New%' AND kols.status LIKE '%".$where['status']."%')");
									}else{
										$this->db->like('kols.status',$where['status']);
									}
								}
		}
		if($limit != null){
			$this->db->limit($limit);
		}
		if($startFrom != null){
			$this->db->offset($startFrom);
		}
	
		if($sidx != null){
			switch($sidx){
				case 'name' : $this->db->order_by("organizations.name",$sord);
				break;
				case 'kol_name' : $this->db->order_by("kols.first_name",$sord);
				break;
				case 'specialty' : $this->db->order_by("specialties.specialty",$sord);
				break;
				case 'country' : $this->db->order_by("countries.Country",$sord);
				break;
				case 'primary_phone' : $this->db->order_by("kols.primary_phone",$sord);
				break;
				case 'primary_email' : $this->db->order_by("kols.primary_email",$sord);
				break;
				case 'status' :
					$this->db->order_by("kols.status",$sord);
					break;
				case 'user_full_name' :
					$this->db->order_by("client_users.client_id",$sord);
					$this->db->order_by("client_users.first_name",$sord);
					break;
			}
		}
		if(!$doCount){
			$resultSet = $this->db->get('kols');
			//			echo $this->db->last_query();
			//			exit();
			foreach($resultSet->result_array() as $row){
				$arrKols[]	= $row;
			}
			return $arrKols;
		}else{
			$resultSet = $this->db->count_all_results('kols');
			return $resultSet;
		}
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolsAssociatedWithClient()
	 * @Param  : $clientId
	 * @return : array of kols associated with client
	 */
	function getKolsAssociatedWithClient($clientId){
		$this->db->select(array('kols.id as id', 'kols.id as kol_id', 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
		$this->db->join ( 'kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left' );
		$this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
		$this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
		$this->db->where ( 'kols_client_visibility.client_id', $clientId );
		$this->db->order_by( 'kol_name', 'asc' );
		$arrKolsResult = $this->db->get ( 'kols' );
		//pr($this->db->last_query());exit;
		return $arrKolsResult->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolsIdAndPin()
	 * @Param  : none
	 * @return : $arrKols
	 */
	function getKolsIdAndPin() {
		$kolResult = array();
		$arrKols = array();
		$this->db->select('id,pin');
		$kolResult = $this->db->get('kols');
		foreach ($kolResult->result_array() as $row) {
			$arrKols[$row['id']] = $row['pin'];
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAffiliationsByParam()
	 * @Param  : $fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType,$arrCountries,$arrSpecialities,$selectType,$arrListNamesIds,$arrStates,$arrProfileType,$viewType,$arrGlobalRegionIds,$analystSelectedClientId,$fromType
	 * @return : $arrAffiliationsDetail
	 */
	function getAffiliationsByParam($fromYear, $toYear, $arrKolIds = 0, $arrEngTypes = '', $arrOrgType = '', $arrCountries = 0, $arrSpecialities = 0, $selectType, $arrListNamesIds = 0, $arrStates = 0, $arrProfileType = '', $viewType=array(), $arrGlobalRegionIds = 0, $analystSelectedClientId = 0,$fromType=0) {
		$arrAffiliationsDetail = array();
		$isKolsJoined = false;
	
		$referer = $_SERVER['HTTP_REFERER'];
		$arrSegments = explode('/', $referer);
		$referer = $arrSegments[sizeof($arrSegments) - 1];
	
		$countType = 'kol_memberships.id';
		if ($referer == 'affiliations' || $referer == 'affiliations#')
			$countType = 'kol_memberships.institute_id';
				
			$this->db->select($selectType . ',count(DISTINCT ' . $countType . ') as count');
			if ($fromYear != 0 && $toYear != 0) {
				//	$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
				$this->db->where("((kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . ") or (kol_memberships.start_date=0 or kol_memberships.start_date=''))");
			}
			$this->db->join('engagement_types', 'engagement_types.id=kol_memberships.engagement_id', 'left');
				
			//Adding where condition for KolId if Exist
			if (is_array($arrKolIds) && sizeof($arrKolIds)>0) {
				$this->db->where_in('kol_memberships.kol_id', $arrKolIds);
			} else if ($arrKolIds != 0) {
				$this->db->where('kol_memberships.kol_id', $arrKolIds);
			}
				
			//Adding where condition for EngTypeId if Exist
			if (is_array($arrEngTypes)) {
				if (is_numeric($arrEngTypes[0]))
					$this->db->where_in('engagement_types.id', $arrEngTypes);
					else
						$this->db->where_in('engagement_types.engagement_type', $arrEngTypes);
			}else if ($arrEngTypes != '') {
				if (is_numeric($arrEngTypes))
					$this->db->where('engagement_types.id', $arrEngTypes);
					else
						$this->db->where('engagement_types.engagement_type', $arrEngTypes);
			}
				
			//Adding where condition for OrgType if Exist
			if (is_array($arrOrgType)) {
				$this->db->where_in('kol_memberships.type', $arrOrgType);
			} else if ($arrOrgType != '') {
				$this->db->where('kol_memberships.type', $arrOrgType);
			}
				
			//Adding where condition for Gobal Region's if Exist
			if (is_array($arrGlobalRegionIds)) {
				$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			} else if ($arrGlobalRegionIds != 0) {
				$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
				$isKolsJoined = true;
				$this->db->join('countries','kols.country_id=countries.countryId','left');
				$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
			}
				
			//Adding where condition for Country's if Exist
			if (is_array($arrCountries)) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where_in('kols.country_id', $arrCountries);
			} else if ($arrCountries != 0) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where('kols.country_id', $arrCountries);
			}
			if (is_array($arrStates)) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where_in('kols.state_id', $arrStates);
			}else if ($arrStates != 0) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where('kols.state_id', $arrStates);
			}
				
			//Adding where condition for Speciality's if Exist
			if (is_array($arrSpecialities)) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where_in('kols.specialty', $arrSpecialities);
			}else if ($arrSpecialities != 0) {
				if (!$isKolsJoined)
					$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
					$isKolsJoined = true;
					$this->db->where('kols.specialty', $arrSpecialities);
			}
				
			if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
				$userId = $this->session->userdata('user_id');
				$clientId = $this->session->userdata('client_id');
				$this->db->join('list_kols', 'list_kols.kol_id=kol_memberships.kol_id', 'left');
				$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
				$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
				$this->db->where_in('list_names.id', $arrListNamesIds);
				$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
			if($fromType=='1'){
				if ($arrProfileType != ''){
					$this->db->where('kols.profile_type', $arrProfileType);
				}
			}else{
				if ($arrProfileType != ''){
					if($arrProfileType == DISCOVERY){
						$this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
					}else{
						$this->db->where('kols.profile_type', $arrProfileType);
						$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
					}
					//             $this->db->where('kols.profile_type', $arrProfileType);
				}else{
					$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
				}
			}
			$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
			if (sizeof($viewType) > 0) {
				$this->db->where_in('kols.id', $viewType);
			}
			//$this->db->where_not_in('kol_memberships.type','others');
			// even if the records with KOL ID = 0 or type = 0 then it should be ignored
			$this->db->where_not_in('type', array('0',''));
			$this->db->where('kol_memberships.kol_id>',0,false);
			if (!$isKolsJoined)
				$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
	
	
				//$this->db->where('kols.status',COMPLETED);// To Load Charts Comment on Profile Request as well Non Profile Request
	
	
				$this->db->group_by($selectType);
	
				if($analystSelectedClientId != null || $analystSelectedClientId > 0){
					$client_id = $analystSelectedClientId;
				}else{
					$client_id = $this->session->userdata('client_id');
				}
				if($client_id !== INTERNAL_CLIENT_ID){
					$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
					$this->db->where('kols_client_visibility.client_id', $client_id);
				}
	
				$arrAffiliations = $this->db->get('kol_memberships');
				//         pr($this->db->last_query());exit;
				foreach ($arrAffiliations->result_array() as $row) {
					$arrAffiliationsDetail[] = $row;
				}
				return $arrAffiliationsDetail;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKolName()
	 * @Param  : $id
	 * @return : $arrKol
	 */
	function getKolName($id) {
		$arrKol = array();
		$this->db->select('id,unique_id,salutation,first_name,middle_name,last_name,suffix,status');
		$this->db->where('id', $id);
		$arrKolNameresult = $this->db->get('kols');
		foreach ($arrKolNameresult->result_array() as $row) {
			$arrKol = $row;
		}
		return $arrKol;
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getEventTypesCountByTimeLine()
	 * @Param  : $fromYear, $toYear, $arrKolIds, $arrEngTypes, $arrOrgType,$arrCountries,$arrSpecialities,$selectType,$arrListNamesIds,$arrStates,$arrProfileType,$viewType,$arrGlobalRegionIds
	 * @return : $arrEventDatails
	 */
	function getEventTypesCountByTimeLine($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {
	
		$sqlQuery = "SELECT conf_event_types.event_type, COUNT(distinct kol_events.event_id) as count, YEAR(kol_events.start) as year
										FROM kol_events
										LEFT JOIN conf_event_types ON conf_event_types.id=kol_events.event_type
										LEFT JOIN kols ON kols.id=kol_events.kol_id
        								left join countries on kols.country_id=countries.countryId
										";
	
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$sqlQuery .= "left join kols_client_visibility on kols_client_visibility.kol_id = kols.id";
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
				
			$userId = $this->session->userdata('user_id');
			$clientId = $this->session->userdata('client_id');
				
			$commaistNamesIds = $this->common_helper->convertArrayToCommaSeparatedElements($arrListNamesIds);
			$sqlQuery .= " left join list_kols on list_kols.kol_id=kol_events.kol_id
	 		                 left join  list_names on list_kols.list_name_id=list_names.id
	 		                 left join list_categories on list_names.category_id=list_categories.id
            				 ";
		}
		$sqlQuery .= " WHERE 	`kol_events`.`event_type` != 'null'
						AND YEAR(kol_events.start)!='' ";
	
		if($client_id !== INTERNAL_CLIENT_ID){
			$sqlQuery .= " AND kols_client_visibility.client_id=".$client_id;
		}
		//Adding where condition for Kol's if Exist
		if (is_array($arrKolIds)) {
			$commaKolIds = $this->common_helper->convertArrayToCommaSeparatedElements($arrKolIds);
			$sqlQuery .= " AND kol_events.kol_id IN($commaKolIds) ";
		} else if ($arrKolIds != 0) {
			$sqlQuery .= " AND kol_events.kol_id='$arrKolIds' ";
		}
		//Adding where condition for Country's if Exist
		if (is_array($arrGlobalRegionIds) && sizeof($arrGlobalRegionIds) > 0) {
			$count = sizeof($arrGlobalRegionIds);
			$i;
			$commaGlobalRegion = '';
			$seprator = '';
			foreach($arrGlobalRegionIds as $value){
				$commaGlobalRegion .= $seprator."'".$value."'";
				$seprator = ',';
				$i++;
			}
			$sqlQuery .= " AND countries.GlobalRegion IN($commaGlobalRegion) ";
		}
		//Adding where condition for Country's if Exist
		if (is_array($arrCountries) && sizeof($arrCountries) > 0) {
			$commaCountries = $this->common_helper->convertArrayToCommaSeparatedElements($arrCountries);
			$sqlQuery .= " AND kols.country_id IN($commaCountries) ";
		}
		if (is_array($arrStatesIds)) {
			$commaStates = $this->common_helper->convertArrayToCommaSeparatedElements($arrStatesIds);
			$sqlQuery .= " AND kols.state_id IN($commaStates) ";
		} else if ($arrStatesIds != 0) {
			$sqlQuery .= " AND kols.state_id='$arrStatesIds' ";
		}
		//Adding where condition for Speciality's if Exist
		if (is_array($arrSpecialities) && sizeof($arrSpecialities) > 0) {
			$arrEventDatails = array();
			$commaSpecialities = $this->common_helper->convertArrayToCommaSeparatedElements($arrSpecialities);
			$sqlQuery .= " AND kols.specialty IN($commaSpecialities) ";
		}
		//Adding where condition for Country's if Exist
		if (is_array($arrCountries) && sizeof($arrCountries) > 0) {
			$sqlQuery .= " AND kols.country_id IN($commaCountries) ";
		}
	
		if (is_array($arrStatesIds)) {
			$sqlQuery .= " AND kols.state_id IN($commaStates) ";
		} else if ($arrStatesIds != 0) {
			$sqlQuery .= " AND kols.state_id='$arrStatesIds' ";
		}
	
		//Adding where condition for Speciality's if Exist
		if (is_array($arrSpecialities) && sizeof($arrSpecialities) > 0) {
			$sqlQuery .= " AND kols.specialty IN($commaSpecialities) ";
		}
		if ($profileType != '') {
			if($profileType == DISCOVERY){
				$sqlQuery .= " AND (kols.imported_as = 2 or kols.imported_as = 3)";
			}else{
				$sqlQuery .= " AND kols.profile_type='$profileType' ";
				$sqlQuery .= " AND (kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)";
			}
			//             $this->db->where('kols.profile_type', $arrProfileType);
		}else{
			//$sqlQuery .= " AND (kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)";
		}
		if (isset($viewType) && sizeof($viewType) > 0) {
			$viewType = implode(",", $viewType);
			$sqlQuery .= " AND kols.id IN($viewType) ";
			//			$this->db->where_in('kols.id',$viewType);
		}
		if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
			$sqlQuery .= " and list_names.id in ($commaistNamesIds) and ((list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 )))";
		}
		//Adding year range condition
		if ($fromYear != 0 && $toYear != 0)
			$sqlQuery .=" AND (YEAR(kol_events.start) BETWEEN '$fromYear' AND '$toYear' OR year(kol_events.start)=0)";
			$sqlQuery .=" GROUP BY kol_events.event_type, YEAR(kol_events.start)";
			$result = $this->db->query($sqlQuery);
			foreach ($result->result_array() as $row) {
				$arrEventDatails[] = $row;
			}
			return $arrEventDatails;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getCoEventedKols()
	 * @Param  : $arrKolIds
	 * @return : $arrKols
	 */
	function getCoEventedKols($arrKolIds = null) {
		//Old Querry
		$arrKols = array();
		$this->db->select("e2.kol_id, COUNT(DISTINCT e2.event_id) as count");
		$this->db->join('kol_events as e2', 'kol_events.event_id=e2.event_id', 'left');
		$this->db->join('kols', 'e2.kol_id = kols.id', 'left');
		//$where="kol_events.kol_id='$arrKolIds' AND e2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_events.kol_id', $arrKolIds);
		$this->db->where('e2.kol_id !=', $arrKolIds);
		//$this->db->where('kols.status', COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->group_by('e2.kol_id');
		$results = $this->db->get('kol_events');
		foreach ($results->result_array() as $row) {
			$arrKols[] = $row;
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getCoAffiliatedKols()
	 * @Param  : $arrKolIds
	 * @return : $arrKols
	 */
	function getCoAffiliatedKols($arrKolIds = null) {
		//Old Querry
		$arrKols = array();
		$this->db->select("m2.kol_id, COUNT(DISTINCT m2.institute_id) as count");
		$this->db->join('kol_memberships as m2', 'kol_memberships.institute_id=m2.institute_id', 'left');
		$this->db->join('kols', 'm2.kol_id = kols.id', 'left');
		//$where="kol_memberships.kol_id='$arrKolIds' AND m2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_memberships.kol_id', $arrKolIds);
		$this->db->where('m2.kol_id !=', $arrKolIds);
		$this->db->where('kol_memberships.type', "university");
		$this->db->where('m2.type', "university");
		//$this->db->where('kols.status', COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->group_by('m2.kol_id');
		$results = $this->db->get('kol_memberships');
		foreach ($results->result_array() as $row) {
			$arrKols[] = $row;
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getCoEducatedKols()
	 * @Param  : $arrKolIds
	 * @return : $arrKols
	 */
	function getCoEducatedKols($arrKolIds = null) {
		//Old Querry
		$arrKols = array();
		$this->db->select("edu2.kol_id, COUNT(DISTINCT edu2.kol_id) as count");
		$this->db->join('kol_educations as edu2', 'kol_educations.institute_id=edu2.institute_id', 'inner');
		$this->db->join('kols', 'edu2.kol_id = kols.id', 'left');
		$this->db->where('kol_educations.kol_id', $arrKolIds);
		$this->db->where('edu2.kol_id !=', $arrKolIds);
		$this->db->where('edu2.institute_id !=', 0);
		$this->db->where('kol_educations.type', 'education');
		$this->db->where('edu2.type', 'education');
		//         $this->db->where('kols.status', COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->group_by('edu2.kol_id');
		$results = $this->db->get('kol_educations');
		foreach ($results->result_array() as $row) {
			$arrKols[] = $row;
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getCoOrganizedKols()
	 * @Param  : $arrKolIds
	 * @return : $arrKols
	 */
	function getCoOrganizedKols($arrKolIds = null) {
		//Old Querry
		$arrKols = array();
		$client_id = $this->session->userdata('client_id');
		$this->db->select("k2.id as kol_id, COUNT(DISTINCT k2.id) as count");
		$this->db->join('kols as k2', 'kols.org_id=k2.org_id', 'inner');
		$this->db->where('kols.id', $arrKolIds);
		$this->db->where('k2.id !=', $arrKolIds);
		//         $this->db->where('kols.status', COMPLETED);
		//         $this->db->where('k2.status', COMPLETED);
		$this->db->where('kols.org_id !=', '');
	
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = k2.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(k2.imported_as IS NULL or k2.imported_as = 2 or k2.imported_as = 0 or k2.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
	
		$results = $this->db->get('kols');
		foreach ($results->result_array() as $row) {
			$arrKols[] = $row;
		}
		return $arrKols;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllAffiliationsTypeIndustry()
	 * @Param  : $type, $where
	 * @return : $arrMembershipDetails
	 */
	function getAllAffiliationsTypeIndustry($type = '', $where) {
		$clientId = $this->session->userdata('client_id');
		$arrMembershipDetails = array();
		//		if($kolId != null){
		//Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
		$this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
		$this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
		$this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
		if ($where['kol_id'] != '')
			$this->db->where('kol_memberships.kol_id', $where['kol_id']);
	
			$this->db->where('institutions.name', $where['organizer']);
			if ($where['start'] != '')
				$this->db->where('kol_memberships.start_date', $where['start']);
			if ($where['start'] != '')
				$this->db->where('kol_memberships.end_date', $where['end']);

			if ($clientId != INTERNAL_CLIENT_ID) {
				$this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
			}
			if ($type != '')
				$this->db->where('type', $type);
			else
				$this->db->where('type !=', 'industry');

			$this->db->order_by('institutions.name', 'asc');
			if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
				if ($arrMembershipDetailResult->num_rows() == 0) {
					return false;
				}

				foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
					$arrMembershipDetails[] = $arrMembership;
				}
				return $arrMembershipDetails;
				
			} else
				return false;

	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllAffiliationsTypeIndustry()
	 * @Param  : $institutionDetails
	 * @return : array of row id
	 */
	function getInstituteIdElseSave($institutionDetails) {
		if ($institutionDetails['name'] != null || !empty($institutionDetails['name'])) {
			$this->db->select('id');
			$this->db->where('name', $institutionDetails['name']);
			$arrResultSet = $this->db->get('institutions');
	
			if ($arrResultSet->num_rows() == 0) {
				$institutionDetails['created_by'] = $this->session->userdata('user_id');
				$institutionDetails['created_on'] = date("Y-m-d H:i:s");
				$this->db->insert('institutions', $institutionDetails);
				return $this->db->insert_id();
			} else {
				foreach ($arrResultSet->result_array() as $arrRow) {
					return $arrRow['id'];
				}
			}
		} else
			return false;
	}
}
