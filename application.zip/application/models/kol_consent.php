<?php

/**
 * This is Model file of 'Opt_inout'
 *
 * @package application.models
 * @author Vinod R H
 * @since
 * @created on  23-06-2017
 */
class Kol_consent extends Model {
    
    //Constructor
    function Kol_consent() {
        parent::Model();
        $this->load->model("common_helpers");
        $this->load->model('Country_helper');
        $this->load->model('Client_User');
        $this->load->library('SimpleLoginSecure');
    }
    
    function generateUrlLink($arrLinkData){
        $this->db->select('id,unique_id');
        $this->db->where('kol_id',$arrLinkData['kol_id']);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                $this->db->where('id', $row->id);
                $this->db->where('status !=',0);
                $this->db->update('opt_inout',$arrLinkData);
                $id = $arrLinkData['kol_id'];
                $date = date('Y-m-d H:i:s');
                $this->db->query("update kols Set kols.opt_in_out_status = 2,modified_on = '$date',opt_in_out_date = '$date' Where kols.id = $id");
            }
            return 'updated';
        }else{
            if ($this->db->insert('opt_inout', $arrLinkData)) {
                $id = $arrLinkData['kol_id'];
                $date = date('Y-m-d H:i:s');
                $this->db->query("update kols Set kols.opt_in_out_status = 2,modified_on = '$date',opt_in_out_date = '$date' Where kols.id = $id");
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }
    
    function updateKolModifiedDate($kolId){
        $date = date('Y-m-d H:i:s');
        $this->db->query("update kols Set modified_on = '$date',opt_in_out_date = '$date' Where kols.id = $kolId");
    }
    
    function getKolNameByKolId($kolId){
        $arrSalutations = array(0 => '', 'Dr. ', 'Prof. ', 'Mr. ', 'Ms. ');
        $this->db->select('first_name,last_name,salutation');
        $this->db->where('id',$kolId);
        $query = $this->db->get('kols');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $arrSalutations[$row->salutation].$row->first_name.' '.$row->last_name;
            }
        }
    }
    
    function getKolEmailByKolId($kolId){
        $this->db->select('primary_email');
        $this->db->where('id',$kolId);
        $query = $this->db->get('kols');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->primary_email;
            }
        }
    }
    
    function getCreatedByKolId($kolId){
        $this->db->select('created_by');
        $this->db->where('id',$kolId);
        $query = $this->db->get('kols');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->created_by;
            }
        }
    }
    
    function getClientIdByCreatedByIdOfKolId($kolId){
        $this->db->select('client_users.client_id');
        $this->db->join('kols','kols.created_by = client_users.id','left');
        $this->db->where('kols.id',$kolId);
        $query = $this->db->get('client_users');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->client_id;
            }
        }
    }
    
    function getUrlStatusByKolId($kolId){
        $this->db->select('id,unique_id');
        $this->db->where('kol_id',$kolId);
        $this->db->where('status',0);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->unique_id;
            }
        }else{
            return false;
        }
    }
    
    function getUrlStatusByUniqueId($uniqueId){
        $this->db->select('kol_id');
        $this->db->where('status',0);
        $this->db->where('unique_id',$uniqueId);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->kol_id;
            }
        }else{
            return false;
        }
    }
    
    function getKolOptExist($kolId){
        $this->db->select('id');
        $this->db->where('kol_id',$kolId);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            return true;
        }else{
            return false;
        }
    }
    
    function getKolDetails($kolId){
        $arrKolDetails = array();
        $this->db->select("kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.sub_specialty,kols.division,kols.external_profile_id,kols.primary_email,specialties.specialty,titles.title as title_name,
    	kol_locations.address1,kol_locations.address2,kol_locations.division as department,kol_locations.postal_code,organizations.name as org_name,
    	organization_types.type as org_type,countries.GlobalRegion as global_region, countries.Country as country_name,regions.Region as state_name,cities.City as city_name,phone_numbers.number,phone_type.name as phone_type");
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join("specialties","specialties.id = kols.specialty","left");
        //     	$this->db->join("kol_sub_specialty","kol_sub_specialty.kol_sub_specialty_id = specialties.id AND kol_sub_specialty.priority = 0","left",false);
        $this->db->join("kol_locations","kol_locations.kol_id = kols.id AND kol_locations.is_primary = 1", "left",false);
        $this->db->join("phone_numbers","phone_numbers.location_id = kol_locations.id AND phone_numbers.is_primary = 1", "left",false);
        $this->db->join("phone_type","phone_type.id = phone_numbers.type","left");
        $this->db->join("organizations","organizations.id = kol_locations.org_institution_id","left");
        $this->db->join("organization_types","organization_types.id = organizations.type_id","left");
        $this->db->join("countries","countries.CountryId = kols.country_id","left");
        $this->db->join("regions","regions.RegionID = kols.state_id","left");
        $this->db->join("cities","cities.CityId = kols.city_id","left");
        $this->db->where('kols.id',$kolId);
        $arrData = $this->db->get('kols');
        foreach($arrData->result_array() as $arrKol){
            $arrKolDetails = $arrKol;
        }
        return $arrKolDetails;
    }
    
    function updateStatusOfOptInOut($optValue,$uniqueId,$isKolId = false){
        if($optValue == 1){
            $optkolValue = 3;
        }
        $date = date('Y-m-d H:i:s');
        if($isKolId){
            $this->db->query("update kols Set opt_in_out_status = $optkolValue,modified_on = '$date',opt_in_out_date = '$date' Where id = '$uniqueId'");
            $this->db->query("update opt_inout Set opt_inout.status = $optValue Where opt_inout.kol_id = '$uniqueId'");
        }else{
            $this->db->query("update kols left join opt_inout on opt_inout.kol_id=kols.id Set kols.opt_in_out_status = $optkolValue,modified_on = '$date',opt_in_out_date = '$date' Where opt_inout.unique_id = '$uniqueId'");
            $this->db->query("update opt_inout Set opt_inout.status = $optValue Where opt_inout.unique_id = '$uniqueId'");
        }
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            return false;
        }else{
            return true;
        }
    }
    
    function updateKolDetails($arrkolData,$uniqueId,$kolId){
        $this->db->where('unique_id',$uniqueId);
        $this->db->update('opt_inout',$arrkolData);
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            return false;
        }else{
            $status = 4;
            $date = date('Y-m-d H:i:s');
            $this->db->set('opt_in_out_status',$status);
            $this->db->set('modified_on',$date);
            $this->db->set('opt_in_out_date',$date);
            $this->db->where('id',$kolId);
            $this->db->update('kols');
            return true;
        }
    }
    
    function getAssignedUserEmails($kolId){
        $arrUserEmails = array();
        $this->db->select('client_users.email');
        $this->db->join('client_users','client_users.id = user_kols.user_id','left');
        $this->db->where('user_kols.kol_id',$kolId);
        $this->db->where_in('user_kols.type',array(1,2));
        $query = $this->db->get('user_kols');
        foreach($query->result_array() as $row){
            $arrUserEmails[] =  $row['email'];
        }
        return $arrUserEmails;
    }
    
    
    function getUrlStatusValue($uniqueId){
        $this->db->select('opt_inout.status');
        $this->db->where('unique_id',$uniqueId);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->status;
            }
        }else{
            return false;
        }
    }
    
    function deleteKolVisibility($kolId){
        $this->db->where('kol_id', $kolId);
        $this->db->delete('kols_client_visibility');
        return true;
    }
    
    function getKolTitle(){
        $arrDatas=array();
        $arrTitle = $this->db->get('titles');
        foreach($arrTitle->result_array() as $row){
            $arrDatas[$row['id']]	= $row['title'];
        }
        return $arrDatas;
    }
    
    function getYearRange($kolId){
        $this->db->select('kols.id,optin_optout_settings.duration');
        $this->db->join("client_users","client_users.id = kols.created_by","left");
        $this->db->join("countries","countries.CountryId = client_users.country","left");
        $this->db->join("groups","groups.group_name = countries.GlobalRegion","left");
        $this->db->join("optin_optout_settings","optin_optout_settings.region = groups.group_id","left");
        $this->db->where('kols.id',$kolId);
        $this->db->where('optin_optout_settings.isEnabled',1);
        $query = $this->db->get('kols');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->duration;
            }
        }else{
            return false;
        }
    }
    
    function getOrgIdByOrgName($orgName){
        $this->db->where('name',$orgName);
        $this->db->select('id');
        $result = $this->db->get('organizations');
        if($result->num_rows()>0){
            $row = $result->row();
            if (isset($row))
            {
                return $row->id;
            }
        }else{
            return false;
        }
    }
    
    function getExpiredKolIds(){
        $arrKolIds = array();
        $date = date('Y-m-d');
        $modifyDate = date('Y-m-d H:i:s');
        $this->db->select("CONCAT(client_users.first_name,' ',client_users.last_name) as user_name",false);
        $this->db->select('opt_inout.kol_id,client_users.email');
        $this->db->where('opt_inout.expire_date',$date);
        $this->db->join("kols","kols.id = opt_inout.kol_id","left");
        $this->db->join("client_users","client_users.id = kols.created_by","left");
        $query = $this->db->get('opt_inout');
        $result = $query->result_array();
        foreach($result as $row){
            $arrKolIds[] = $row['kol_id'];
        }
        if(sizeof($arrKolIds) > 0){
            $this->db->set('opt_in_out_status', 5);
            $this->db->set('modified_on', $modifyDate);
            $this->db->set('opt_in_out_date', $modifyDate);
            $this->db->where_in('id',$arrKolIds);
            $this->db->update('kols');
            return  $query->result_array();
        }else{
            return false;
        }
    }
    
    function getWithOutResponseExpiredKolIds(){
        $arrKolIds = array();
        $date = date('Y-m-d', strtotime("-60 days"));
        $this->db->select("CONCAT(client_users.first_name,' ',client_users.last_name) as user_name",false);
        $this->db->select('opt_inout.kol_id,client_users.email,client_users.id as client_id');
        $this->db->where('opt_inout.created_on',$date);
        $this->db->where('opt_inout.status','0');
        $this->db->join("kols","kols.id = opt_inout.kol_id","left");
        $this->db->join("client_users","client_users.id = kols.created_by","left");
        $query = $this->db->get('opt_inout');
        $result = $query->result();
        if(sizeof($result) > 0){
            return $query->result_array();
        }else{
            return false;
        }
    }
    
    function getWithOutResponseExpiredNoLinkKolIds(){
        $arrKolIds = array();
        $date = date('Y-m-d', strtotime("-30 days"));
        $this->db->select("CONCAT(client_users.first_name,' ',client_users.last_name) as user_name",false);
        $this->db->select('kols.id,client_users.email,client_users.id as client_id');
        $this->db->join("client_users","client_users.id = kols.created_by","left");
        $this->db->where("DATE(kols.opt_in_out_date) = '$date'","",false);
        $this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
        $this->db->where('kols.opt_in_out_status',1);
        $query = $this->db->get('kols');
        $result = $query->result();
        if(sizeof($result) > 0){
            return $query->result_array();
        }else{
            return false;
        }
    }
    
    
    function getToInimateExpiredKolIds(){
        $date = date('Y-m-d', strtotime("+30 days"));
        $this->db->select("CONCAT(client_users.first_name,' ',client_users.last_name) as user_name",false);
        $this->db->select('opt_inout.kol_id,client_users.email');
        $this->db->where('opt_inout.expire_date',$date);
        $this->db->join("kols","kols.id = opt_inout.kol_id","left");
        $this->db->join("client_users","client_users.id = kols.created_by","left");
        $query = $this->db->get('opt_inout');
        $result = $query->result();
        if(sizeof($result) > 0){
            return $query->result_array();
        }else{
            return false;
        }
    }
    
    function checkKtlByEmailId($emailid){
        $this->db->select('id');
        $this->db->where('primary_email',$emailid);
        $query = $this->db->get('kols');
        $result = $query->result();
        if(sizeof($result) > 0){
            return true;
        }else{
            return false;
        }
    }
    
    function checkKtlByFNLNCI($arrData){
        $this->db->select('id');
        $this->db->where('first_name',$arrData['first_name']);
        $this->db->where('last_name',$arrData['last_name']);
        $this->db->where('country_id',$arrData['country_id']);
        $query = $this->db->get('kols');
        $result = $query->result();
        if(sizeof($result) > 0){
            return true;
        }else{
            return false;
        }
    }
    
    function getUserIdByEmail($userEmail){
        $this->db->select('id');
        $this->db->where('email',$userEmail);
        $query = $this->db->get('client_users');
        if($query->num_rows()>0){
            $row = $query->row_array();
            return $row['id'];
        }else{
            return false;
        }
    }
    
    function getUserClientIdByEmail($userEmail){
        $this->db->select('client_id');
        $this->db->where('email',$userEmail);
        $query = $this->db->get('client_users');
        if($query->num_rows()>0){
            $row = $query->row_array();
            return $row['client_id'];
        }else{
            return false;
        }
    }
    
    function getLanguageNameByLangId($kolId){
        $this->db->select('languages.lang_value');
        $this->db->join('languages','languages.id = kols.primary_language_id','left');
        $this->db->where('kols.id',$kolId);
        $query = $this->db->get('kols');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->lang_value;
            }
        }else{
            return false;
        }
    }
    
    function getKolNameByUniqueId($uniqueId){
        $this->db->select('kol_id');
        $this->db->where('unique_id',$uniqueId);
        $query = $this->db->get('opt_inout');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->kol_id;
            }
        }else{
            return false;
        }
    }
    
    function getKolStatusDetails($kolId){
        $this->db->select("kols.id,kols.opt_in_out_status,kols.salutation,CONCAT(kols.first_name,' ',kols.last_name) as name",false);
        $this->db->where('id',$kolId);
        $query = $this->db->get('kols');
        return $query->row();
    }
    /**
     * Get OptInOutKols details
     * @param int $limit
     * @param int $start
     * @param string $sidx
     * @param string $sord
     * @return array - $arrOptinOutKolsDetails - Returns
     */
    function getOptInOutKols($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where){
        $this->db->select("CONCAT(kols.first_name,' ',kols.last_name) as name",false);
        $this->db->select('kols.id,countries.Country as country_name,regions.Region as state_name,cities.City as city_name,opt_inout_statuses.name as status_name,opt_inout.expire_date');
        $this->db->join("countries","countries.CountryId = kols.country_id","left");
        $this->db->join("regions","regions.RegionID = kols.state_id","left");
        $this->db->join("cities","cities.CityId = kols.city_id","left");
        $this->db->join("opt_inout_statuses","opt_inout_statuses.id = kols.opt_in_out_status","left");
        $this->db->join("opt_inout","opt_inout.kol_id = kols.id","left");
        $this->db->where("kols.opt_in_out_status !=",0);
        if(isset($where['name'])){
            $this->db->where("(kols.first_name LIKE '%" . $where['name'] . "%' or kols.last_name LIKE '%" . $where['name'] . "%')");
        }
        if(isset($where['country_name'])){
            $this->db->like('countries.Country',$where['country_name']);
        }
        if(isset($where['state_name'])){
            $this->db->like('regions.Region',$where['state_name']);
        }
        if(isset($where['city_name'])){
            $this->db->like('cities.City',$where['city_name']);
        }
        if(isset($where['status_name'])){
            $this->db->like('opt_inout_statuses.name',$where['status_name']);
        }
        if(isset($where['expire_date'])){
            $this->db->like('opt_inout.expire_date',$where['expire_date']);
        }
        if($doCount){
            $count = $this->db->count_all_results('kols');
            return $count;
        }else{
            if($sidx!='' && $sord!=''){
                switch($sidx){
                    case 'name' : $this->db->order_by('kols.first_name', $sord);
                    $this->db->order_by('kols.last_name', $sord);
                    break;
                    case 'country_name' :$this->db->order_by("countries.Country",$sord);
                    break;
                    case 'state_name' : $this->db->order_by("regions.Region",$sord);
                    break;
                    case 'city_name' :$this->db->order_by("cities.City",$sord);
                    break;
                    case 'status_name' : $this->db->order_by("opt_inout_statuses.name",$sord);
                    break;
                    case 'expire_date' :$this->db->order_by("opt_inout.expire_date",$sord);
                    break;
                }
                //$this->db->order_by($sidx,$sord);
            }
        }
        $arrOptinOutKolsDetails = $this->db->get('kols',$limit,$startFrom);
        return $arrOptinOutKolsDetails;
    }
    
    function getOptInOutStatusNames(){
        $query = $this->db->get('opt_inout_statuses');
        return $query->result_array();
    }
    
    function updateStatusId($kolId,$statusId){
        $this->db->set('opt_in_out_status',$statusId);
        $this->db->where('id',$kolId);
        $this->db->update('kols');
        //Add Log activity
        $arrLogDetails = array(
        		'type' => EDIT_RECORD,
        		'description' => 'Update Kols opt_in_out_status',
        		'status' => STATUS_SUCCESS,
        		'kols_or_org_type' => 'Kol',
        		'kols_or_org_id' => $kolId,
        		'transaction_id' =>  $kolId,
        		'transaction_table_id' => KOLS,
        		'transaction_name' => 'Update Kols opt_in_out_status',
        		'parent_object_id' =>  $kolId
        );
        $this->config->set_item('log_details', $arrLogDetails);
    }
    
    function getLangNameById($langId){
        $this->db->select('lang_value');
        $this->db->where('id',$langId);
        $query = $this->db->get('languages');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->lang_value;
            }
        }else{
            return false;
        }
    }
    
    function getLangIdByName($langName){
        $this->db->select('id');
        $this->db->where('lang_name',$langName);
        $query = $this->db->get('languages');
        if($query->num_rows()>0){
            $row = $query->row();
            if (isset($row))
            {
                return $row->id;
            }
        }else{
            return false;
        }
    }
    
    function saveTitle($tit,$clientId) {
        $get = $this->db->get_where("titles",array("title"=>$tit,"client_id"=>$clientId));
        if($get->num_rows()==0){
            $this->db->insert("titles",array("title"=>$tit,"is_active"=>1,"abbr"=>' ',"client_id"=>$clientId));
            $dataData = array();
            $dataData['status'] = true;
            $dataData['id'] = $this->db->insert_id();
            return $dataData;
        }else{
            $dataData = array();
            $dataData['status'] = false;
            $dataData['id'] = $get->row()->id;
            return $dataData;
        }
    }
    
    function updateGlobalRegionByCountryId($countryId,$globalRegion){
        $this->db->set('GlobalRegion',$globalRegion);
        $this->db->where('CountryId',$countryId);
        $this->db->update('countries');
        return true;
    }
    
    function updateDeleteRequest($arrData){
        $this->db->set('deleted_optin_no_response',$arrData['deleted_optin_no_response']);
        $this->db->where('id',$arrData['id']);
        $this->db->update('kols');
    }
    
}